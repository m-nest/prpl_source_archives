/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ddns_priv.h"
#include "ddns.h"
#include "ddns_error_codes.h"
#include "ddns_config.h"
#include "hostname/hostname.h"

#define ME "ddns"

/**
   @brief
   Get client struct. Initialize it if it's not created.

   @param[in] instance Object with the DynamicDNS.Client.{}.Hostname instance.

   @return
   Pointer to the Hostname internal structure.
 */
ddns_hostname_t* get_hostname(amxd_object_t* instance) {
    SAH_TRACEZ_IN(ME);
    ddns_hostname_t* hostname = NULL;

    when_null_trace(instance, exit, ERROR, "DynamicDNS.Client.{}.Hostname object is NULL");

    hostname = (ddns_hostname_t*) instance->priv;
    if(hostname == NULL) {
        hostname = (ddns_hostname_t*) calloc(1, sizeof(ddns_hostname_t));
        hostname->last_status = ddns_hostname_error;
        instance->priv = hostname;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return hostname;
}

/**
   @brief
   Clean the host_check associated with an Hostname object.

   @param[in] instance Object with the Client.Hostname's instance.
 */
void clean_hostname(amxd_object_t* instance) {
    ddns_hostname_t* hostname = NULL;

    when_null_trace(instance, exit, ERROR, "DynamicDNS.Client.Hostname object is NULL");
    hostname = (ddns_hostname_t*) instance->priv;
    when_null(hostname, exit);
    if(hostname->retry_timer != NULL) {
        amxp_timer_delete(&(hostname->retry_timer));
    }
    if(hostname->check_interval_timer != NULL) {
        amxp_timer_delete(&(hostname->check_interval_timer));
    }
    if(hostname->status_timer != NULL) {
        amxp_timer_delete(&(hostname->status_timer));
    }
    FREE(hostname);
    instance->priv = NULL;

exit:
    return;
}

