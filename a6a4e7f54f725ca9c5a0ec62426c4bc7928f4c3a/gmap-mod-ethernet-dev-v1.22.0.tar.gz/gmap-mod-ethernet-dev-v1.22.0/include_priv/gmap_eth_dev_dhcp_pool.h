/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_ETH_DEV_DHCP_POOL_H__)
#define __GMAP_ETH_DEV_DHCP_POOL_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file Reads from TR-181 DHCPv4 datamodel and monitors which pool instance belongs
 * to which interface.
 */


#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <stdbool.h>

typedef struct gmap_eth_dev_dhcp_pool gmap_eth_dev_dhcp_pool_t;
typedef struct gmap_eth_dev_dhcp_pool_subscription gmap_eth_dev_dhcp_pool_subscription_t;

void PRIVATE gmap_eth_dev_dhcp_pool_new(gmap_eth_dev_dhcp_pool_t** pool, amxb_bus_ctx_t* ctx);
void PRIVATE gmap_eth_dev_dhcp_pool_delete(gmap_eth_dev_dhcp_pool_t** pool);

/**
 * Called when a pool<->interface match changes.
 * @param pool gmap_eth_dev_dhcp_pool_t instance that invoked the callback.
 * @param path Full path of the dhcp pool instance.
 * @param iface Interface name for which the callback was subscribed.
 * @param matching @code true if the pool at the given path is assigned to the subscription interface,
 *                 @code false if the pool is no longer assigned to the subscription interface.
 * @param priv private data pointer set on the subscription.
 */
typedef void (* gmap_eth_dev_dhcp_pool_cb_t) (gmap_eth_dev_dhcp_pool_t* pool,
                                              const char* path,
                                              const char* iface,
                                              bool matching,
                                              void* const priv);
/**
 * Subscribes the given callback for matching pools.
 * The callback will be called for any pools already matching before this function returns.
 */
gmap_eth_dev_dhcp_pool_subscription_t*
PRIVATE gmap_eth_dev_dhcp_pool_subscribe(gmap_eth_dev_dhcp_pool_t* pool,
                                         const char* iface,
                                         gmap_eth_dev_dhcp_pool_cb_t cb,
                                         void* priv);
/**
 * Unsubscribes the given callback for the given interface.
 * The callback will NOT be called for any pools still matching.
 */
void PRIVATE gmap_eth_dev_dhcp_pool_unsubscribe(gmap_eth_dev_dhcp_pool_subscription_t* subscription);

gmap_eth_dev_dhcp_pool_t* PRIVATE gmap_eth_dev_get_pool(void);

#ifdef __cplusplus
}
#endif

#endif