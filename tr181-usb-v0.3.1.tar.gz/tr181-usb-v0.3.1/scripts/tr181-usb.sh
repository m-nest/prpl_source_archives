#!/bin/sh
. /usr/lib/amx/scripts/amx_init_functions.sh

name="tr181-usb"

case $1 in
    boot)
        process_boot ${name} -D
        ;;
    start)
        process_start ${name} -D
        ;;
    stop)
        process_stop ${name} 20
        ;;
    shutdown)
        process_shutdown ${name}
        ;;
    debuginfo)
        process_debug_info "USB"
        ;;
    restart)
        $0 stop
        $0 start
        ;;
    *)
        echo "Usage : $0 [start|boot|stop|shutdown|debuginfo|restart]"
        ;;
esac
