/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file dmm_connect_mngr.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contain implementation for functions related to the services connection to the
 *          DM Mapper like pWHM, WiFi-Sensing etc.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2025 Inango
 *
 */

#include <errno.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <amxp/amxp.h>
#include <debug/sahtrace.h>
#include <amxb/amxb_be_intf.h>
#include <amxb/amxb_register.h>
#include <amxrt/amxrt.h>
#include "dmm_connect_mngr.h"

#include "dmm_subscribe.h"
#include "dmm.h"

#define ME "dmm"                                                            /*!< Prefix for SAH logger method */

#define MAPPER_LISTEN_SOCK_CONFIG "dmm-usp-listen-sock"                     /*!< Name of the ODL config variable, that holds URI of the Mapper socket */
#define MAPPER_LISTEN_SOCK_DEFAULT "usp:/var/run/dm-mapper-controller.sock" /*!< USP UDS socket for services connection like pWHM or prplMesh etc.*/

amxb_bus_ctx_t* l_bus_ctx = NULL;

static void dmm_accept_cb(UNUSED int fd, UNUSED void* data);
static amxb_bus_ctx_t* dmm_find_ctx(const char* dm_path);
void dmm_real_object_verify(const char* path);

/**
 * @brief An access function that is guaranteed to always fail.
 *
 * This static function is intended to be used as a stub or in situations
 * where a read operation must consistently return an error (e.g., for
 * a disabled or unavailable interface).
 *
 * @param[in] ctx Pointer to the context structure. This parameter is unused (`UNUSED`).
 * @return Always returns **-1**, indicating a standard failure in C.
 */
static int always_failing_read(UNUSED void* ctx) {
    return -1;
}

/**
 * @brief timer used to re-register datamodel in obuspa
 */
amxp_timer_t* reregister_timer;

/**
 * @brief Trigger re-registration of the datamodel
 *
 * @param timer timer used to call the function
 * @param priv bus context used to re-register DM
 */
static void reregister_dm(amxp_timer_t* timer, void* priv) {
    amxb_bus_ctx_t* bus_ctx = (amxb_bus_ctx_t*) priv;

    amxb_deregister(bus_ctx, dmm_get_dm());
    amxb_register(bus_ctx, dmm_get_dm());
}

/**
 * @brief Triggers USP Agent reregistration by forcing a connection drop.
 *
 * Currently, forces amxrt to drop the USP connection
 *
 * amxrt will reconnect after some timeout (provided usp.connect-retry=true)
 * and the USP Broker will send us GET_SUPPORTED_DM again
 */
static void trigger_usp_reregistration() {
    amxp_connection_t* usp_conn = NULL;

    amxc_llist_for_each(it, amxp_connection_get_connections()) {
        amxp_connection_t* conn = amxc_llist_it_get_data(it, amxp_connection_t, it);
        if(conn->type != AMXP_CONNECTION_BUS) {
            continue;
        }
        if(!conn->reader) {
            continue;
        }
        if(conn->uri && (strncmp(conn->uri, "usp:", 4) == 0)) {
            usp_conn = conn;
            break;
        }
    }
    if(!usp_conn) {
        SAH_TRACEZ_INFO(ME, "No USP connection found. Already awaiting reconnection?");
        return;
    }

    SAH_TRACEZ_INFO(ME, "Starting USP datamodel re-registration");

    if(reregister_timer) {
        amxp_timer_delete(&reregister_timer);
    }

    amxb_bus_ctx_t* bus_ctx = usp_conn->priv;
    amxp_timer_new(&reregister_timer, reregister_dm, bus_ctx);
    amxp_timer_start(reregister_timer, GET_INT32(amxrt_get_config(), "dmm-re-registration-timeout"));
}

/**
 * @brief Connection read callback function for the Data Model Manager (DMM).
 *
 * This function is registered as the read handler for a bus connection (e.g.,
 * a USP connection). It attempts to read data from the bus using
 * **amxb_read()**.
 *
 * If **amxb_read()** returns **-1**, it signifies that the connection has been
 * closed by the peer. In this case, the function performs the necessary
 * cleanup:
 * 1. Clears the bus context from all associated DMM context lists (`bus_ctx_list`).
 * 2. Unregisters the data model elements associated with the connection's
 * root path using `dmm_unregister_by_real_path()`.
 * 3. Frees the bus context (`amxb_free()`).
 * 4. Removes the file descriptor from the event loop (`amxp_connection_remove()`).
 * 5. Calls `trigger_usp_reregistration()` to prompt the USP Agent to re-register
 * the updated data model.
 *
 * @param[in] fd File descriptor of the connection. Unused (`UNUSED`).
 * @param[in] data Pointer to the `amxb_bus_ctx_t` structure.
 */
static void dmm_read_cb(UNUSED int fd, UNUSED void* data) {
    int rv = 0;
    amxb_bus_ctx_t* bus_ctx = (amxb_bus_ctx_t*) data;
    rv = amxb_read(bus_ctx);

    SAH_TRACEZ_INFO(ME, "amxb_read(fd=%d) ret=%d", fd, rv);
    if(rv == -1) {
        SAH_TRACEZ_INFO(ME, "Closing connection");
        amxc_llist_for_each(it, bus_ctx_list) {
            actx_llist_t* actx_list_item = amxc_container_of(it, actx_llist_t, it);
            if(actx_list_item->a_bus_ctx == bus_ctx) {
                actx_list_item->a_bus_ctx = NULL;
                SAH_TRACEZ_INFO(ME, "Cleared bus ctx for root path: %s", actx_list_item->root_path);
                dmm_unsubscribe_root(actx_list_item->root_path);
                dmm_unregister_by_real_path(actx_list_item->root_path);
            }
        }
        amxb_free(&bus_ctx);
        amxp_connection_remove(fd);
        trigger_usp_reregistration(); // Re-register updated DM
    }
}

/**
 * @brief Callback to accept connection from one of the prplmesh components.
 *
 * @param[in] a_bus_ctx bus context of the component
 *
 * @return whether the callback was accepted (e.g. it matched a root object) or not
 */
static bool do_accept_callback(amxb_bus_ctx_t* a_bus_ctx) {
    bool duplicate_connection = false;
    actx_llist_t* actx_list_item = NULL;
    amxc_var_t* ret_var = NULL;
    bool matched_root_path = false;
    amxc_var_t root_paths;
    amxc_var_init(&root_paths);
    amxc_var_set_type(&root_paths, AMXC_VAR_ID_LIST);

    amxb_be_cache_set_size(0);
    amxb_be_cache_set_size(5);
    SAH_TRACEZ_INFO(ME, "amxb_be_cache_set_size -> 0 -> 5");

    amxc_var_new(&ret_var);
    amxc_llist_for_each(it, bus_ctx_list) {
        actx_list_item = amxc_container_of(it, actx_llist_t, it);
        amxd_status_t status = amxb_get(a_bus_ctx, actx_list_item->root_path, 0, ret_var, 1);
        if(status != amxd_status_ok) {
            continue;
        }
        matched_root_path = true;
        amxc_var_t* ret_entries = GETI_ARG(ret_var, 0);
        if(ret_entries) {
            SAH_TRACEZ_INFO(ME, "Bus ctx is matched to path: %s", actx_list_item->root_path);
            if((duplicate_connection = actx_list_item->a_bus_ctx)) {
                SAH_TRACEZ_WARNING(ME, "Bus ctx already exists for path: %s, rejecting connection", actx_list_item->root_path);
                amxb_free(&a_bus_ctx);
                break;
            }
            actx_list_item->a_bus_ctx = a_bus_ctx;
            amxc_var_add(cstring_t, &root_paths, actx_list_item->root_path);
            dmm_subscribe_root(a_bus_ctx, actx_list_item->root_path, actx_list_item->mapped_path);
        }
    }
    amxc_var_delete(&ret_var);

    if(duplicate_connection || !matched_root_path) {
        goto out;
    }

    amxp_connection_add(amxb_get_fd(a_bus_ctx), dmm_read_cb, NULL, AMXO_BUS, (void*) a_bus_ctx);
    amxc_var_for_each(var, &root_paths) {
        const char* path = amxc_var_constcast(cstring_t, var);
        SAH_TRACEZ_INFO(ME, "Path: [%s]", path);
        dmm_real_object_verify(path);
    }
    trigger_usp_reregistration(); // Re-register updated DM

out:
    amxc_var_clean(&root_paths);
    return matched_root_path;
}

/**
 * @brief Structure describes connection and amount of retries for services
 *
 */
struct DmmAcceptCallbackData {
    amxb_bus_ctx_t* a_bus_ctx; /*!< Pointer to the proper USP context */
    uint32_t retry_count;      /*!< Counter for retry connection */
};

/**
 * @brief Deferred function to call by timer trigger to retry accepting connection from the prplmesh component.
 *
 * @param[in] timer the timer used to call the function
 * @param[in] priv private data that hold the DmmAcceptCallbackData struct
 */
void dmm_accept_callback_deferred(amxp_timer_t* timer, void* priv) {
    struct DmmAcceptCallbackData* accept_data = (struct DmmAcceptCallbackData*) priv;
    when_null(accept_data, exit);

    accept_data->retry_count--;

    if(do_accept_callback(accept_data->a_bus_ctx) || (accept_data->retry_count == 0)) {
        amxp_timer_delete(&timer);
        free(accept_data);
        return;
    }

    SAH_TRACEZ_WARNING(ME, "Failed to accept callback after tiemout, left attemtps: %u", accept_data->retry_count);

exit:
    return;
}

/**
 * @brief Accept the callback from the prplmesh component, retry if needed.
 *
 * @param fd (unused) file descriptor of the bus context used by the component
 * @param data (unused) extra private data
 */
static void dmm_accept_cb(UNUSED int fd, UNUSED void* data) {
    amxb_bus_ctx_t* a_bus_ctx = NULL;

    SAH_TRACEZ_INFO(ME, "Waiting for connection ...");
    if(amxb_accept(l_bus_ctx, &a_bus_ctx) != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "Error on accept() call: %s", strerror(errno));
    }

    if(!do_accept_callback(a_bus_ctx)) {
        SAH_TRACEZ_WARNING(ME, "Failed to accept callback");
        uint32_t retry_count = GET_UINT32(amxrt_get_config(), DMM_ROOTOBJ_RETRY_COUNT);
        uint32_t retry_interval = GET_UINT32(amxrt_get_config(), DMM_ROOTOBJ_RETRY_INTERVAL) * 1000; // seconds to ms
        SAH_TRACEZ_INFO(ME, "amxb_accept: retry count: %u, retry interval: %u", retry_count, retry_interval);
        if((retry_count == 0) || (retry_interval == 0)) {
            SAH_TRACEZ_INFO(ME, "Interval or retry count is 0, not retrying");
            return;
        }
        struct DmmAcceptCallbackData* accept_data = malloc(sizeof(struct DmmAcceptCallbackData));
        when_null(accept_data, exit);

        accept_data->a_bus_ctx = a_bus_ctx;
        accept_data->retry_count = retry_count;

        amxp_timer_t* timer = NULL;
        amxp_timer_new(&timer, dmm_accept_callback_deferred, accept_data);
        amxp_timer_set_interval(timer, retry_interval);
        if(amxp_timer_start(timer, retry_interval)) {
            SAH_TRACEZ_WARNING(ME, "Cannot start accept-callback timer");
            amxp_timer_delete(&timer);
            free(accept_data);
        }
    }

exit:
    return;
}

/**
 * @brief Get the pointer to the end of root object starting from the dm_path
 *
 * @param[in] dm_path pointer to the start of the object to find end of the root object
 *
 * @return pointer to the end of the root object or NULL if it cannot be found
 */
static const char* get_root_path_end(const char* dm_path) {

    const char* s_ptr = strchr(dm_path, '.');
    if(s_ptr == NULL) {
        SAH_TRACEZ_ERROR(ME, "Root path without . at end: %s", dm_path);
        return NULL;
    }
    s_ptr++;
    return s_ptr;
}

/**
 * @brief Finds the associated bus context for a given data model path.
 *
 * This function determines the root path (the top-level object path ending
 * with a '.') from the full data model path (`dm_path`).
 *
 * The root path extraction logic handles paths that may optionally start with
 * "Device." (common in TR-181/USP contexts) by skipping this prefix if present.
 *
 * Once the root path is extracted, the function searches the global list of
 * active contexts (`bus_ctx_list`) for an entry matching the root path and
 * returns the associated active bus context (`amxb_bus_ctx_t*`).
 *
 * @note The extracted root path must contain a '.' at the end, and its length
 * is checked against `ROOT_PATH_LEN`.
 *
 * @param[in] dm_path The full data model path (e.g., "Device.Hosts.Host.1.Name").
 * @return A pointer to the active `amxb_bus_ctx_t` associated with the root
 * path of the data model, or **NULL** if no matching context is found, or if
 * the path is invalid.
 */
static amxb_bus_ctx_t* dmm_find_ctx(const char* dm_path) {
    when_null(dm_path, exit);

    const char* s_ptr = NULL;
    char root_path[ROOT_PATH_LEN] = {0};

    if(strstr(dm_path, "Device.") == dm_path) {
        // starts with Device.
        s_ptr = get_root_path_end(dm_path + strlen("Device."));
    } else {
        // does not start with Device.
        s_ptr = get_root_path_end(dm_path);
    }

    if(s_ptr == NULL) {
        SAH_TRACEZ_ERROR(ME, "Root path without . at end: %s", dm_path);
        return NULL;
    }

    if((s_ptr - dm_path) >= sizeof(root_path)) {
        SAH_TRACEZ_ERROR(ME, "Root path too large in object path: %s", dm_path);
        return NULL;
    }

    memcpy(root_path, dm_path, s_ptr - dm_path);

    amxc_llist_for_each(it, bus_ctx_list) {
        actx_llist_t* actx_list_item = amxc_container_of(it, actx_llist_t, it);
        if(strcmp(root_path, actx_list_item->root_path) == 0) {
            if(actx_list_item->a_bus_ctx != NULL) {
                SAH_TRACEZ_INFO(ME, "Found ctx in cache list for root path: %s", root_path);
                return actx_list_item->a_bus_ctx;
            }
        }
    }
    SAH_TRACEZ_INFO(ME, "No bus ctx found for root path: %s", root_path);

exit:
    return NULL;
}

amxb_bus_ctx_t* dmm_get_connection(const char* param_path) {
    amxb_bus_ctx_t* a_bus_ctx = NULL;

    a_bus_ctx = dmm_find_ctx(param_path);
    if(a_bus_ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "No connection ctx for given path: %s", param_path);
        return NULL;
    } else {
        SAH_TRACEZ_INFO(ME, "Found bus ctx [%p] - %s", (void*) a_bus_ctx, (a_bus_ctx->bus_fn) ? a_bus_ctx->bus_fn->name : "");
    }

    return a_bus_ctx;
}

/**
 * @brief Initializes and starts the AMX bus listener for incoming USP Agent connections.
 *
 * This function sets up the listening socket for the Data Model Manager (DMM)
 * to accept connections from the USP Agent (likely `amxrt`).
 *
 * 1. **Configuration:** It first attempts to retrieve the listening socket path
 * from the configuration key defined by `MAPPER_LISTEN_SOCK_CONFIG`.
 * 2. **Default Fallback:** If the configuration is not found, it uses the
 * `MAPPER_LISTEN_SOCK_DEFAULT` path.
 * 3. **Listening:** It calls **amxb_listen()** to create the bus context
 * and start listening on the determined Unix domain socket path. If listening
 * fails, an error is logged.
 * 4. **Event Loop Registration:** If successful, the listening file descriptor
 * is registered with the event loop (`amxp_connection_add`) using
 * `dmm_accept_cb` as the callback function to handle new connection requests.
 */
void dmm_start_amx_listen() {
    const char* mapper_usp_listen_socket = GET_CHAR(amxrt_get_config(), MAPPER_LISTEN_SOCK_CONFIG);
    if(!mapper_usp_listen_socket) {
        mapper_usp_listen_socket = MAPPER_LISTEN_SOCK_DEFAULT;
    }
    if(amxb_listen(&l_bus_ctx, mapper_usp_listen_socket) != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "Failed to create listen socket %s", mapper_usp_listen_socket);
        return;
    }

    amxp_connection_add(amxb_get_fd(l_bus_ctx), dmm_accept_cb, NULL, AMXP_CONNECTION_LISTEN, NULL);
}
