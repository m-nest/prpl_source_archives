{% 
    // find out how many wan interfaces we have
    let wan_interfaces=0;
    for (let Itf in BD.Interfaces) {
        if (Itf.Upstream == "true" || Itf.DefaultUpstream == "true") {
            wan_interfaces++;
        }
    }
%}
#include "mod_sahtrace.odl";
#include "global_variables.odl";

%config {
    name = "tr069-discovery";
    storage-type = "odl";
    storage-path = "${rw_data_path}/${name}";

    // persistent storage location
    odl = {
        dm-load = true,
        dm-save = true,
        dm-save-on-changed = true,
        dm-save-delay = 1000,
        directory = "${storage-path}/odl"
    };

    sahtrace = {
        type = "syslog",
        level = "${default_log_level}"
    };

    trace-zones = {
        discovery = "${default_trace_zone_level}",
        event_handler = "${default_trace_zone_level}",
        dhcp_provision = "${default_trace_zone_level}"
    };

    ubus = {
        watch-ubus-events = true,
        register-on-start-event = true
    };

    definition_file = "${name}_definition.odl";

    pcm_svc_config = {
        "Objects" = "${global_vendor_prefix_}TR069Discovery",
        "BackupFiles" = "${name}"
    };
    
    /**
    * The interval in seconds at which ACS Discovery will initiate a DHCP lease renewal in an 
    * attempt to obtain a new ACS address, when DHCP provisioning is
    * enabled (State.DHCPProvisionInUse == true) and a CWMP session cannot be established 
    * within a specified timeout using the previously obtained address or 
    * if no such address is available.
    */
    DHCPReDiscoveryInterval = 300;

    /**
    * Duration in milliseconds to wait for obtaining the ACS address via DHCPv6 before
    * enabling DHCP provisioning at service startup.
    */
    DHCPv6WaitTime = 3000;
    
{% if (wan_interfaces != 0) : %}
    NetModelIntfAlias = "ip-wan";
    DHCPv4ClientReference = "DHCPv4Client.Client.wan";
    DHCPv6ClientReference = "DHCPv6Client.Client.wan";
{% else %}
    NetModelIntfAlias = "ip-lan";
    DHCPv4ClientReference = "DHCPv4Client.Client.lan";
    DHCPv6ClientReference = "DHCPv6Client.Client.lan";
{% endif %}

}

requires "NetModel.";
requires "ManagementServer.";
requires "DHCPv4Client.";
requires "DHCPv6Client.";

import "${name}.so" as "${name}";

include "${definition_file}";

%define {
    entry-point tr069-discovery.tr069_discovery_main;
}

%populate {
    on event "app:start" call tr069_discovery_start;
    on event "app:stop" call tr069_discovery_stop;
}
