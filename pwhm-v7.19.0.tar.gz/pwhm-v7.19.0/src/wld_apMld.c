/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wld.h"
#include "wld_util.h"
#include "wld_accesspoint.h"
#include "wld_ssid.h"
#include "wld_radio.h"
#include "wld_assocdev.h"
#include "wld_apMld.h"
#include "wld_eventing.h"

#include "wld_nl80211.h"
#include "wld_ssid_nl80211_priv.h"
#include "wld_nl80211_types.h"

#define ME "apMld"

/**
 * Return whether all the BSSes in a given mldUnit are enabled.
 *
 * @param mldUnit: the mld unit of the apMld with which to match.
 *
 * @return
 * This will return true, if mldUnit >= 0 and if for every T_SSID known to the system, of with pSSID->mldUnit matches mldUnit, and, that pSSID is enabled
 * and the radio on which that pSSID is present is also enabled.
 *
 * This will return false otherwise.
 *
 */
bool wld_apMld_areAllBssEnabled(int32_t mldUnit) {
    if(mldUnit < 0) {
        return false;
    }

    T_Radio* pRad = NULL;
    wld_for_eachRad(pRad) {
        T_AccessPoint* tmpAp = NULL;
        wld_rad_forEachAp(tmpAp, pRad) {
            if(tmpAp->pSSID == NULL) {
                continue;
            }

            if(tmpAp->pSSID->mldUnit != mldUnit) {
                continue;
            }
            if(pRad->enable == 0) {
                return false;
            }

            if(tmpAp->enable == 0) {
                return false;
            }
        }

        T_EndPoint* tmpEp = NULL;
        wld_rad_forEachEp(tmpEp, pRad) {
            if(tmpEp->pSSID == NULL) {
                continue;
            }

            if(tmpEp->pSSID->mldUnit != mldUnit) {
                continue;
            }
            if(pRad->enable == 0) {
                return false;
            }

            if(tmpEp->enable == 0) {
                return false;
            }
        }
    }
    return true;
}

/*
 * @brief check whether one APMLD link have applicable and shared
 * ssid and security configurations (secMode, keypass) values
 * with the other links
 */
bool wld_apMld_hasSharedConnectionConf(T_AccessPoint* pAP) {
    ASSERTS_NOT_NULL(pAP, false, ME, "NULL");
    T_SSID* pSSID = pAP->pSSID;
    ASSERTS_NOT_NULL(pSSID, false, ME, "NULL");
    wld_mldLink_t* pLink = pSSID->pMldLink;
    if(!wld_mld_checkUsableLinkBasicConditions(pLink)) {
        return false;
    }

    uint32_t countUsable = 0;
    uint32_t countSharedConf = 0;
    wld_mldLink_t* pNgLink = NULL;
    wld_for_eachNeighMldLink(pNgLink, pLink) {
        if(!wld_mld_checkUsableLinkBasicConditions(pNgLink)) {
            continue;
        }
        countUsable++;
        T_SSID* pNgLinkSSID = wld_mld_getLinkSsid(pNgLink);
        if(swl_str_matches(pNgLinkSSID->SSID, pSSID->SSID) &&
           wld_ap_sec_checkSharedSecConfigs(pNgLinkSSID->AP_HOOK, pAP)) {
            countSharedConf++;
        }
    }
    SAH_TRACEZ_INFO(ME, "%s: countUsableLinks:%d countSharedConfLinks:%d",
                    pAP->alias, countUsable, countSharedConf);

    /*
     * APMLD links must have same SSID and valid shared security config (mode,psk,saePassPhrase)
     * in order to be usable.
     * otherwise, the link configs are misaligned, so the MLD is split into individual links.
     */
    if((countUsable > 0) && (countSharedConf > 0) &&
       (countUsable == countSharedConf)) {
        return true;
    }
    return false;
}

/**
 * @brief Update AffiliatedAP MLO statistics parameters in the Data Model.
 *
 * This helper function sets the Packets, Bytes, and Error counters
 * under the given AffiliatedAP object based on the provided MLO stats.
 *
 * @param obj   AffiliatedAP object in the Data Model.
 * @param stats Pointer to the collected MLO statistics structure.
 */
static void s_update_affAP_MloStats(amxd_object_t* const obj, wld_mloStats_t* stats) {
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "PacketsSent", stats->txPackets);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "PacketsReceived", stats->rxPackets);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "UnicastBytesSent", stats->txUbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "UnicastBytesReceived", stats->rxUbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "ErrorsSent", stats->txEbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "MulticastBytesSent", stats->txMbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "MulticastBytesReceived", stats->rxMbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "BroadcastBytesSent", stats->txBbyte);
    SWLA_OBJECT_SET_PARAM_UINT32(obj, "BroadcastBytesReceived", stats->rxBbyte);
}

/**
 * @brief ORF callback to retrieve MLO statistics for an AffiliatedAP object.
 *
 * This function is invoked when reading parameters under
 * Device.WiFi.APMLD.{i}.AffiliatedAP.{i}. It collects per-link MLO
 * statistics via the driver hook and updates the DM object.
 *
 * @param object         Target AffiliatedAP object being read.
 * @param param          DM parameter being accessed.
 * @param reason         Action reason (must be read).
 * @param args           Optional input arguments.
 * @param action_retval  Action return value.
 * @param priv           Private context (unused).
 *
 * @return amxd_status_t
 *         - amxd_status_ok if handled successfully
 *         - amxd_status_function_not_implemented if not a read action
 *         - amxd_status_object_not_found if the parent link is missing
 */
amxd_status_t _wld_affAP_getMloStats_orf(amxd_object_t* const object,
                                         amxd_param_t* const param,
                                         amxd_action_t reason,
                                         const amxc_var_t* const args,
                                         amxc_var_t* const action_retval,
                                         void* priv) {
    SAH_TRACEZ_IN(ME);
    if(reason != action_object_read) {
        return amxd_status_function_not_implemented;
    }
    amxd_object_t* afApObj = amxd_object_get_parent(object);
    ASSERTS_EQUALS(amxd_object_get_type(afApObj), amxd_object_instance, amxd_status_object_not_found, ME, "obj is not instance");
    T_SSID* pSSID = (T_SSID*) afApObj->priv;
    ASSERT_EQUALS(wld_ssid_getType(pSSID), WLD_SSID_TYPE_AP, amxd_status_object_not_found, ME, "AffiliatedAP object not found!");
    wld_mloStats_t mloStats;
    T_AccessPoint* pAP = pSSID->AP_HOOK;
    memset(&mloStats, 0, sizeof(wld_mloStats_t));
    if(pAP->pFA->mfn_wvap_getMloStats(pAP, &mloStats) >= SWL_RC_OK) {
        s_update_affAP_MloStats(object, &mloStats);
    }
    return amxd_action_object_read(object, param, reason, args, action_retval, priv);
}

static amxd_object_t* s_linkIdExists(amxd_object_t* affiliatedAPTemp, int16_t linkId) {
    amxd_object_for_each(instance, it, affiliatedAPTemp) {
        amxd_object_t* object = amxc_llist_it_get_data(it, amxd_object_t, it);
        int8_t tmpLinkId = amxc_var_dyncast(int8_t, amxd_object_get_param_value(object, "LinkID"));
        if(tmpLinkId == linkId) {
            return object;
        }
    }
    return NULL;
}

/**
 * @brief amxo callback, called when new AffiliatedAP object instance is added
 *
 * This function allows to map the instance being created with the relative SSID
 * internal context through the link BSSID
 *
 * @param object         AffiliatedAP Template object.
 * @param param          DM parameter being accessed.
 * @param reason         Action reason.
 * @param args           action (instance adding) input arguments.
 * @param retval         action (instance adding) return value.
 * @param priv           Private context (unused).
 *
 * @return amxd_status_t: amxd_status_ok on success, error code otherwise
 */
amxd_status_t _wld_apmld_addAffAp_oaf(amxd_object_t* object,
                                      amxd_param_t* param,
                                      amxd_action_t reason,
                                      const amxc_var_t* const args,
                                      amxc_var_t* const retval,
                                      void* priv) {
    amxd_status_t status = amxd_status_ok;
    status = amxd_action_object_add_inst(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "add inst failed with error: %d", status);
    amxd_object_t* instance = amxd_object_get_instance(object, NULL, GET_UINT32(retval, "index"));
    ASSERT_NOT_NULL(instance, status, ME, "no instance");
    T_SSID* pSSID = NULL;
    swl_macBin_t bssid = SWL_MAC_BIN_NEW();
    if(swl_typeMacBin_fromChar(&bssid, GETP_CHAR(args, "parameters.BSSID")) && !swl_mac_binIsNull(&bssid)) {
        pSSID = wld_ssid_getSsidByBssid(&bssid);
    }
    ASSERTS_NOT_NULL(pSSID, status, ME, "no ssid match");
    SAH_TRACEZ_INFO(ME, "mapping AfAp instance %p to %s: unit(%d) LinkId(%d)",
                    instance, pSSID->Name, pSSID->mldUnit, pSSID->mldLinkId);
    if(pSSID->pMldLink) {
        pSSID->pMldLink->AffObj = instance;
    }
    instance->priv = pSSID;
    return status;
}

/**
 * @brief amxo callback, called when AffiliatedAP instance is destroyed
 *
 * This function allows to unmap the instance with its relative internal context,
 * and free resources
 *
 * @param object         AffiliatedAP instance object.
 * @param param          DM parameter being accessed.
 * @param reason         Action reason.
 * @param args           action (instance destruction) input arguments.
 * @param retval         action (instance destruction) return value.
 * @param priv           Private context (unused).
 *
 * @return amxd_status_t: amxd_status_ok on success, error code otherwise
 */
amxd_status_t _wld_affAP_delAffAp_odf(amxd_object_t* object,
                                      amxd_param_t* param,
                                      amxd_action_t reason,
                                      const amxc_var_t* const args,
                                      amxc_var_t* const retval,
                                      void* priv) {
    amxd_status_t status = amxd_action_object_destroy(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "Fail to destroy obj instance st:%d", status);
    ASSERTS_EQUALS(amxd_object_get_type(object), amxd_object_instance, status, ME, "obj is not instance");
    T_SSID* pSSID = object->priv;
    object->priv = NULL;
    ASSERTS_NOT_NULL(pSSID, status, ME, "no ssid match");
    SAH_TRACEZ_INFO(ME, "unmapping AfAp instance %p to %s: unit(%d) LinkId(%d)",
                    object, pSSID->Name, pSSID->mldUnit, pSSID->mldLinkId);
    if(pSSID->pMldLink) {
        pSSID->pMldLink->AffObj = NULL;
    }
    return status;
}


static bool s_isSSIDMLD(wld_mld_t* pMld, T_SSID* pSSID) {
    ASSERT_NOT_NULL(pMld, false, ME, "pMld NULL");
    ASSERT_NOT_NULL(pSSID, false, ME, "pSSID NULL");
    amxc_llist_for_each(it, &pMld->links) {
        wld_mldLink_t* pLink = amxc_container_of(it, wld_mldLink_t, it);
        T_SSID* pLinkSSID = wld_mld_getLinkSsid(pLink);
        if((pLinkSSID == pSSID) && wld_ssid_hasValidMLDLinkID(pLinkSSID)) {
            return true;
        }
    }
    return false;
}

/**
 * @brief clean AffiliatedAP objects: only those invalid, or dropping all of them
 *
 * @param pMld mld context
 * @param all : flag indicating whether to drop all AffiliatedAP obj instances
 *
 * @return void
 */
static void s_cleanAfApObjs(wld_mld_t* pMld, bool all) {
    ASSERTS_NOT_NULL(pMld, , ME, "pMld NULL");
    amxd_object_t* affiliatedAPTemp = amxd_object_get_child(pMld->object, "AffiliatedAP");
    ASSERTS_NOT_NULL(affiliatedAPTemp, , ME, "No AffiliatedAP template");
    amxd_object_for_each(instance, it, affiliatedAPTemp) {
        amxd_object_t* object = amxc_llist_it_get_data(it, amxd_object_t, it);
        T_SSID* pSSID = object->priv;
        if(all || ((pSSID == NULL) || !s_isSSIDMLD(pMld, pSSID))) {
            swl_object_delInstWithTransOnLocalDm(object);
        }
    }
}

void s_flushMldParams(wld_mld_t* pMld) {
    ASSERT_NOT_NULL(pMld, , ME, "pMld NULL");
    ASSERT_NOT_NULL(pMld->object, , ME, "No MLD instance %d", pMld->unit);

    amxd_trans_t trans;
    ASSERT_TRANSACTION_INIT(pMld->object, &trans, , ME, "trans init failure");
    amxd_trans_set_value(cstring_t, &trans, "MLDMACAddress", "");
    ASSERT_TRANSACTION_LOCAL_DM_END(&trans, , ME, "Failed to update params");

    s_cleanAfApObjs(pMld, true);
}

static void s_clearDmParams(wld_mld_t* pMld) {
    ASSERT_NOT_NULL(pMld, , ME, "pMld NULL");
    ASSERT_NOT_NULL(pMld->object, , ME, "No MLD instance %d", pMld->unit);

    s_flushMldParams(pMld);

    pMld->object->priv = NULL;
    pMld->object = NULL;
}

static swl_rc_ne s_updateDmParams(wld_mld_t* pMld) {
    ASSERT_NOT_NULL(pMld, SWL_RC_INVALID_PARAM, ME, "pMld NULL");
    ASSERT_NOT_NULL(pMld->object, SWL_RC_ERROR, ME, "No MLD instance %d", pMld->unit);

    swl_macChar_t mldMacAddress;
    memset(&mldMacAddress, 0, sizeof(mldMacAddress));

    if(pMld->pPrimLink != NULL) {
        T_SSID* pPrimSSID = wld_mld_getLinkSsid(pMld->pPrimLink);
        if((pPrimSSID != NULL) && !swl_mac_binIsNull((swl_macBin_t*) pPrimSSID->MACAddress) && wld_ssid_hasValidMLDLinkID(pPrimSSID)) {
            SWL_MAC_BIN_TO_CHAR(&mldMacAddress, (swl_macBin_t*) pPrimSSID->MACAddress);
        }
    }

    if(swl_str_isEmpty(mldMacAddress.cMac)) {
        s_flushMldParams(pMld);
        return SWL_RC_OK;
    }

    amxd_trans_t trans;
    ASSERT_TRANSACTION_INIT(pMld->object, &trans, , ME, "trans init failure");
    amxd_trans_set_value(cstring_t, &trans, "MLDMACAddress", mldMacAddress.cMac);
    ASSERT_TRANSACTION_LOCAL_DM_END(&trans, , ME, "Failed to update params");

    amxd_object_t* affiliatedAPTemp = amxd_object_get(pMld->object, "AffiliatedAP");
    ASSERT_NOT_NULL(affiliatedAPTemp, , ME, "No AffiliatedAP template");

    /* Flush AffiliatedAPs that are no longer part of the MLD */
    s_cleanAfApObjs(pMld, false);

    /* Update all AffiliatedAPs */
    wld_mldLink_t* pLink = NULL;
    amxc_llist_for_each(it, &pMld->links) {
        pLink = amxc_container_of(it, wld_mldLink_t, it);
        T_SSID* pLinkSSID = wld_mld_getLinkSsid(pLink);
        if((pLinkSSID == NULL)
           || !wld_ssid_hasValidMLDLinkID(pLinkSSID)
           || swl_mac_binIsNull((swl_macBin_t*) pLinkSSID->BSSID)) {
            continue;
        }

        amxd_object_t* affiliatedApObj = s_linkIdExists(affiliatedAPTemp, pLinkSSID->mldLinkId);
        amxd_trans_t trans;
        if(affiliatedApObj == NULL) {
            ASSERT_TRANSACTION_INIT(affiliatedAPTemp, &trans, , ME, "trans init failure");
            uint32_t newIndex = swla_object_getFirstAvailableIndex(affiliatedAPTemp);
            amxd_trans_add_inst(&trans, newIndex, NULL);
        } else {
            ASSERT_TRANSACTION_INIT(affiliatedApObj, &trans, , ME, "trans init failure");
        }
        amxd_trans_set_value(int8_t, &trans, "LinkID", pLinkSSID->mldLinkId);
        swl_typeMacBin_toTransParamStringRef(&trans, "BSSID", (swl_macBin_t*) pLinkSSID->BSSID);
        ASSERT_TRANSACTION_LOCAL_DM_END(&trans, , ME, "Failed to update params");
        ASSERT_NOT_NULL(trans.current, , ME, "NULL instance");

        // update obj/ctx mappings
        affiliatedApObj = trans.current;
        affiliatedApObj->priv = pLinkSSID;
        pLink->AffObj = affiliatedApObj;
    }

    return SWL_RC_OK;
}

static swl_rc_ne s_createDmInstance(wld_mld_t* pMld) {
    ASSERT_NOT_NULL(pMld, SWL_RC_INVALID_PARAM, ME, "pMld NULL");
    amxd_object_t* apMldTemplate = amxd_object_get(get_wld_object(), "APMLD");
    ASSERT_NOT_NULL(apMldTemplate, SWL_RC_ERROR, ME, "No APMLD template");
    amxd_object_t* mldObject = wld_mld_mldIdObjectExists(apMldTemplate, pMld->unit);

    //Reuse old instance
    if(mldObject != NULL) {
        pMld->object = mldObject;
        pMld->object->priv = pMld;
        wld_mld_getConfigFromObject(amxd_object_findf(mldObject, "APMLDConfig"), &pMld->Cfg);
        return SWL_RC_OK;
    }

    uint32_t newIndex = swla_object_getFirstAvailableIndex(apMldTemplate);

    amxd_trans_t trans;
    ASSERT_TRANSACTION_INIT(apMldTemplate, &trans, SWL_RC_ERROR, ME, "trans init failure");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(int32_t, &trans, "MLDID", pMld->unit);

    /*
     * initialize mld config of new APMLD, using driver capabilities
     */
    T_SSID* pFstLinkSSID = wld_mld_getLinkSsid(wld_mld_firstLink(pMld));
    if((pFstLinkSSID != NULL) && (pFstLinkSSID->RADIO_PARENT != NULL)) {
        pMld->Cfg.emlmrEnable = pFstLinkSSID->RADIO_PARENT->cap.apCap7.emlmrSupported;
        pMld->Cfg.emlsrEnable = pFstLinkSSID->RADIO_PARENT->cap.apCap7.emlsrSupported;
        pMld->Cfg.strEnable = pFstLinkSSID->RADIO_PARENT->cap.apCap7.strSupported;
        pMld->Cfg.nstrEnable = pFstLinkSSID->RADIO_PARENT->cap.apCap7.nstrSupported;
        amxd_trans_select_pathf(&trans, ".APMLDConfig");
        wld_mld_addConfigToTrans(&trans, &pMld->Cfg);
    }

    ASSERT_TRANSACTION_LOCAL_DM_END(&trans, SWL_RC_ERROR, ME, "Failed to create instance");

    pMld->object = amxd_object_get_instance(apMldTemplate, NULL, newIndex);
    ASSERT_NOT_NULL(pMld->object, SWL_RC_ERROR, ME, "Failed to get instance");
    pMld->object->priv = pMld;

    SAH_TRACEZ_INFO(ME, "Created APMLD for mldUnit %d", pMld->unit);

    return SWL_RC_OK;
}

static void s_mldChange(wld_mldChange_t* event) {
    ASSERT_NOT_NULL(event, , ME, "NULL event");
    SAH_TRACEZ_INFO(ME, "detect mld event %d mldtype %d unit %d", event->event, event->mldType, event->mldUnit);
    ASSERTI_EQUALS(event->mldType, WLD_SSID_TYPE_AP, , ME, "wrong mld type");
    T_SSID* pSSID = event->pEvtLinkSsid;
    ASSERT_NOT_NULL(pSSID, , ME, "No link ssid");
    T_Radio* pRad = pSSID->RADIO_PARENT;
    ASSERT_NOT_NULL(pRad, , ME, "No link radio");
    wld_mld_t* pMld = wld_mld_getMldByUnit(WLD_SSID_TYPE_AP, event->mldUnit);

    if(event->event == WLD_MLD_EVT_ADD) {
        s_createDmInstance(pMld);
        s_updateDmParams(pMld);
    } else if(event->event == WLD_MLD_EVT_UPDATE) {
        s_updateDmParams(pMld);
    } else if(event->event == WLD_MLD_EVT_DEL) {
        s_clearDmParams(pMld);
    }
}

/**
 * Update APMLD object
 */
void wld_apMld_update() {
    amxd_object_t* apMldObject = amxd_object_get(get_wld_object(), "APMLD");
    ASSERTS_NOT_NULL(apMldObject, , ME, "No APMLD template");
    amxd_object_for_each(instance, it, apMldObject) {
        amxd_object_t* object = amxc_llist_it_get_data(it, amxd_object_t, it);
        wld_mld_t* pMld = (wld_mld_t*) object->priv;
        s_updateDmParams(pMld);
    }
}

static wld_event_callback_t s_onMldChange = {
    .callback = (wld_event_callback_fun) s_mldChange,
};

void wld_apMld_init() {
    wld_event_add_callback(gWld_queue_mld_onChangeEvent, &s_onMldChange);
}

/**
 * @brief Apply current MLD configuration to all affiliated AP links.
 *
 * Iterates over all links of the MLD and updates their Access Point
 * configuration (emlmr, emlsr, str, nstr flags). Each change is logged,
 * and the updated configuration is pushed to the firmware adapter.
 *
 * @param pMld   Pointer to the MLD instance containing configuration.
 */
static void s_setApMldConfig(wld_mld_t* pMld) {
    SAH_TRACEZ_IN(ME);
    ASSERT_NOT_NULL(pMld, , ME, "pMld is NULL");

    amxc_llist_it_t* it = NULL;
    wld_mldLink_t* pLink = NULL;

    amxc_llist_for_each(it, &pMld->links) {
        pLink = amxc_llist_it_get_data(it, wld_mldLink_t, it);
        if((pLink == NULL) || (pLink->pSSID == NULL) || (pLink->pSSID->AP_HOOK == NULL)) {
            continue;
        }

        T_SSID* pSSID = pLink->pSSID;
        T_AccessPoint* pAP = pSSID->AP_HOOK;
        bool changed = false;

        if(pMld->Cfg.emlmrEnable != pAP->mldCfg.emlmrEnable) {
            pAP->mldCfg.emlmrEnable = pMld->Cfg.emlmrEnable;
            SAH_TRACEZ_INFO(ME, "Updated : %s emlmr_enable: new value %d", pSSID->Name, pAP->mldCfg.emlmrEnable);
            changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "%s emlmr_enable value : %d same as parent mld", pSSID->Name, pAP->mldCfg.emlmrEnable);
        }
        if(pMld->Cfg.emlsrEnable != pAP->mldCfg.emlsrEnable) {
            pAP->mldCfg.emlsrEnable = pMld->Cfg.emlsrEnable;
            SAH_TRACEZ_INFO(ME, "Updated : %s emlsr_enable: new value %d", pSSID->Name, pAP->mldCfg.emlsrEnable);
            changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "%s emlsr_enable value : %d same as parent mld", pSSID->Name, pAP->mldCfg.emlsrEnable);
        }
        if(pMld->Cfg.strEnable != pAP->mldCfg.strEnable) {
            pAP->mldCfg.strEnable = pMld->Cfg.strEnable;
            SAH_TRACEZ_INFO(ME, "Updated : %s str_enable: new value %d", pSSID->Name, pAP->mldCfg.strEnable);
            changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "%s str_enable value : %d same as parent mld", pSSID->Name, pAP->mldCfg.strEnable);
        }
        if(pMld->Cfg.nstrEnable != pAP->mldCfg.nstrEnable) {
            pAP->mldCfg.nstrEnable = pMld->Cfg.nstrEnable;
            SAH_TRACEZ_INFO(ME, "Updated : %s nstr_enable: new value %d", pSSID->Name, pAP->mldCfg.nstrEnable);
            changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "%s nstr_enable value : %d same as parent mld", pSSID->Name, pAP->mldCfg.nstrEnable);
        }

        if(changed) {
            pAP->pFA->mfn_wvap_setMldCfg(pAP);
        }

        SAH_TRACEZ_INFO(ME, "LinkID: %d, SSID Name: %s Updated Config", pLink->linkId, pSSID->Name);
    }

    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Handle APMLD MLO modes configuration
 * For preconfigured APMLD instances in the config, wld_mld_t context will not be created at startup but later in the boot process.
 * Config parameters will be retrieved at wld_mld_t creation.
 *
 * @param priv             Private pointer (unused).
 * @param object           MLD config DM object.
 * @param newParamValues   Updated parameter values.
 */
static void s_setMloModes(void* priv _UNUSED, amxd_object_t* object, const amxc_var_t* const newParamValues) {
    amxd_object_t* mldObj = amxd_object_get_parent(object);
    ASSERTS_NOT_NULL(mldObj, , ME, "NULL");
    wld_mld_t* pMld = (wld_mld_t*) mldObj->priv;
    ASSERT_NOT_NULL(pMld, , ME, "NULL");
    SAH_TRACEZ_IN(ME);
    pMld->Cfg.emlmrEnable = swl_typeBool_findInMapDef(newParamValues, "EMLMREnabled", pMld->Cfg.emlmrEnable);
    pMld->Cfg.emlsrEnable = swl_typeBool_findInMapDef(newParamValues, "EMLSREnabled", pMld->Cfg.emlsrEnable);
    pMld->Cfg.strEnable = swl_typeBool_findInMapDef(newParamValues, "STREnabled", pMld->Cfg.strEnable);
    pMld->Cfg.nstrEnable = swl_typeBool_findInMapDef(newParamValues, "NSTREnabled", pMld->Cfg.nstrEnable);
    uint32_t numLinks = amxc_llist_size(&pMld->links);
    if(numLinks > 0) {
        SAH_TRACEZ_INFO(ME, "%d: Calling set ap mld config", pMld->unit);
        s_setApMldConfig(pMld);
    }

    SAH_TRACEZ_OUT(ME);
}

SWLA_DM_HDLRS(sApMldCfgHdlrs, ARR(), );

SWLA_DM_GRP_HDLRS(sApMldCfgGrpHdlrs,
                  ARR(SWLA_DM_PARAMGRP_HDLR(s_setMloModes, SWLA_DM_PARAMGRP("EMLMREnabled", "EMLSREnabled", "STREnabled", "NSTREnabled")),
                      ));

void _wld_ap_setMLDConfig_ocf(const char* const sig_name,
                              const amxc_var_t* const data,
                              void* const priv) {
    swla_dm_procObjectEvtAndGroupOfLocalDm(&sApMldCfgHdlrs, &sApMldCfgGrpHdlrs, sig_name, data, priv);
}
