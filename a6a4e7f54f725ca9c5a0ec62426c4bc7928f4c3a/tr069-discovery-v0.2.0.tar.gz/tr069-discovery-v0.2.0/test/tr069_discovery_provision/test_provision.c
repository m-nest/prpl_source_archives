/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>

#include "tr069_discovery.h"

#include "test_provision.h"
#include "../common/dm_functions.h"
#include "../common/mock_netmodel.h"
#include "../common/mock_amxp.h"

#define UNUSED __attribute__((unused))

#define TEST_DHCP4_ACS_URL_1 "http://192.168.1.101:830"
#define TEST_DHCP4_PROVISIONING_CODE_1 "extender4_1"
#define TEST_DHCP4_ACS_URL_2 "http://192.168.1.102:830"
#define TEST_DHCP4_PROVISIONING_CODE_2 "extender4_2"
#define TEST_DHCP6_ACS_URL "http://[3004:3000::46]:830"
#define TEST_DHCP6_PROVISIONING_CODE "extender4"

#define TEST_USER_ACS_URL "http://acs-download.qacafe.com"

#define TR069_DISCOVERY_DEF "tr069-discovery.odl"
#define TR069_MANAGER_DEF "../common/tr069-manager.odl"
#define TR181_DEVICEINFO_DEF "../common/tr181-deviceinfo.odl"
#define TR181_DHCP4CLIENT_DEF "../common/tr181-dhcpv4client.odl"
#define TR181_DHCP6CLIENT_DEF "../common/tr181-dhcpv6client.odl"

int test_setup(UNUSED void** state) {
    amxut_bus_setup(state);

    resolver_add_all_functions(amxut_bus_parser());

    amxut_dm_load_odl(TR069_DISCOVERY_DEF);
    amxut_dm_load_odl(TR069_MANAGER_DEF);
    amxut_dm_load_odl(TR181_DEVICEINFO_DEF);
    amxut_dm_load_odl(TR181_DHCP4CLIENT_DEF);
    amxut_dm_load_odl(TR181_DHCP6CLIENT_DEF);

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

static void start_tr069_discovery(void) {
    assert_int_equal(_tr069_discovery_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    assert_int_equal(_tr069_discovery_start(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);

    assert_int_equal(app.dhcp_rediscovery_interval_s, 300);
    assert_int_equal(app.dhcpv6_wait_time_ms, 3);
    assert_string_equal(app.netmodel_intf_alias, "ip-wan");
    assert_string_equal(app.dhcpv4_client_ref, "DHCPv4Client.Client.wan");
    assert_string_equal(app.dhcpv6_client_ref, "DHCPv6Client.Client.wan");

    assert_non_null(app.dhcpv6_wait_timer);
    assert_int_equal(app.dhcpv6_wait_timer->state, amxp_timer_started);
    assert_non_null(app.dhcpv6_wait_timer->cb);

    mock_amxp_trigger_timer(app.dhcpv6_wait_timer);

    assert_non_null(app.option_17_subscription);
    assert_non_null(app.option_125_subscription);
    assert_non_null(app.management_server_subscription);

    amxut_bus_handle_events();
}

static void stop_tr069_discovery(void) {
    assert_int_equal(_tr069_discovery_stop(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    assert_int_equal(_tr069_discovery_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
}

static void _assert_dm_string_equal(const char* obj_path, const char* param_name, const char* expected_value) {
    amxb_bus_ctx_t* ctx = amxb_be_who_has(obj_path);
    assert_non_null(ctx);

    char param_path[PATH_BUFFER_SIZE];
    snprintf(param_path, sizeof(param_path), "%s%s", obj_path, param_name);

    amxc_var_t result;
    amxc_var_init(&result);
    assert_int_equal(amxb_get(ctx, param_path, 0, &result, 1), 0);

    amxc_var_t* params = amxc_var_get_first(amxc_var_get_first(&result));
    char* actual_value = amxc_var_dyncast(cstring_t, GET_ARG(params, param_name));
    bool is_equal = !strcmp(actual_value, expected_value);
    amxc_var_clean(&result);
    free(actual_value);

    assert_true(is_equal);
}

void test_tr069_discovery_can_start(UNUSED void** state) {
    start_tr069_discovery();
}

void test_tr069_discovery_can_stop(UNUSED void** state) {
    stop_tr069_discovery();
}

void test_does_not_use_dhcp_provisioned_config_if_management_server_url_is_non_empty(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, TEST_DHCP6_ACS_URL, TEST_DHCP6_PROVISIONING_CODE);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", TEST_USER_ACS_URL);

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "false");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_USER_ACS_URL);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", "");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPANY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "0");

    stop_tr069_discovery();
}

void test_apply_dhcpv4_provisioned_config_at_startup(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, NULL, NULL);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_DHCP4_ACS_URL_1);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", TEST_DHCP4_PROVISIONING_CODE_1);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPV4ONLY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "4");

    stop_tr069_discovery();
}

void test_apply_dhcpv6_provisioned_config_at_startup(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, TEST_DHCP6_ACS_URL, TEST_DHCP6_PROVISIONING_CODE);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_DHCP6_ACS_URL);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", TEST_DHCP6_PROVISIONING_CODE);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPV6PREFERRED");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "6");

    stop_tr069_discovery();
}

void test_disable_provisioning_after_setting_non_empty_management_server_url_by_user(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, NULL, NULL);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");

    // emulate setting non-empty ManagementServer.URL by user
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", TEST_USER_ACS_URL);
    amxut_bus_handle_events();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "false");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_USER_ACS_URL);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPANY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "0");

    stop_tr069_discovery();
}

void test_disable_provisioning_after_stopping_the_service(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, NULL, NULL);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");

    // disable service
    assert_int_equal(_tr069_discovery_stop(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "false");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", "");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPANY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "0");

    stop_tr069_discovery();
}

void test_enable_provisioning_after_setting_empty_management_server_url_by_user(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, NULL, NULL);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", TEST_USER_ACS_URL);

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "false");

    // emulate setting empty ManagementServer.URL by user
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");
    amxut_bus_handle_events();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_DHCP4_ACS_URL_1);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", TEST_DHCP4_PROVISIONING_CODE_1);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPV4ONLY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "4");

    stop_tr069_discovery();
}

void test_apply_provisioned_config_update_after_startup(UNUSED void** state) {
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_1, TEST_DHCP4_PROVISIONING_CODE_1, NULL, NULL);
    set_string_parameter_value(MANAGEMENT_SERVER, "URL", "");

    start_tr069_discovery();

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_DHCP4_ACS_URL_1);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", TEST_DHCP4_PROVISIONING_CODE_1);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPV4ONLY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "4");

    // emulate DHCPv4 option 125 update
    mock_netmodel_set_dhcp_suboptions(TEST_DHCP4_ACS_URL_2, TEST_DHCP4_PROVISIONING_CODE_2, NULL, NULL);
    mock_netmodel_client_handle(app.option_125_subscription);

    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "FirstSuccessfulProvision", "None");
    _assert_dm_string_equal(ACS_DISCOVERY_STATE, "DHCPProvisionInUse", "true");
    _assert_dm_string_equal(MANAGEMENT_SERVER, "URL", TEST_DHCP4_ACS_URL_2);
    _assert_dm_string_equal(DEVICE_INFO, "ProvisioningCode", TEST_DHCP4_PROVISIONING_CODE_2);
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "PreferredIPVersion", "IPV4ONLY");
    _assert_dm_string_equal(MANAGEMENT_SERVER_INTERNAL_SETTINGS, "ACSAddrFamily", "4");

    stop_tr069_discovery();
}
