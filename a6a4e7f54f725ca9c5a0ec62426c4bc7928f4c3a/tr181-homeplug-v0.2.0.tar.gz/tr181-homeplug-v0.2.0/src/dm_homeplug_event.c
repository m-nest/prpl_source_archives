/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include "homeplug.h"
#include "dm_homeplug.h"

/**
   @brief Updates the MAC address of a HomePlug interface object.

   Reads the MAC address from the given interface and writes it to the
   corresponding parameter in the HomePlug object.

   @param homeplug_obj Pointer to the HomePlug data model object.
   @param interface    Name of the interface to query for the MAC address.

   @return - 0 on success.
           - > 0 on failure.
 */
static int dm_homeplug_interface_macaddress(amxd_object_t* homeplug_obj, char* interface) {
    amxd_trans_t transaction;
    amxc_var_t* var_param = NULL;
    char* name = NULL;
    int retval = 0;

    when_null_trace(homeplug_obj, exit, ERROR, "homeplug_obj is NULL pointer");

    var_param = netmodel_getFirstParameter(interface, "MACAddress", NULL, "down");
    name = amxc_var_dyncast(cstring_t, var_param);

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, homeplug_obj);
    amxd_trans_set_value(cstring_t, &transaction, "MACAddress", name);
    retval = amxd_trans_apply(&transaction, homeplug_get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to update macaddress");
    }

    amxd_trans_clean(&transaction);
    amxc_var_delete(&var_param);
    free(name);
exit:

    return retval;
}

/**
   @brief Creates and enables a HomePlug interface instance.

   If the given interface object does not contain an interface instance,
   this function creates one from the object's parameters, updates its
   MAC address, enables it, and sets its status as "Up".

   @param interface_obj_x Pointer to the interface object instance.

   @return - 0 on success.
           - -1 if interface creation or enabling fails.
 */
static int create_and_enable_interface(amxd_object_t* interface_obj_x) {
    int retval = -1;
    char* key = NULL;
    homeplug_interface_t* interface = interface_obj_x->priv;
    if(interface == NULL) {
        amxc_var_t params;
        key = amxd_object_get_value(cstring_t, interface_obj_x, "Alias", NULL);
        SAH_TRACEZ_INFO(ME, "create new interface %s", key);
        when_str_empty_trace(key, exit, ERROR, "empty key interface instance");
        amxc_var_init(&params);
        amxd_object_get_params(interface_obj_x, &params, amxd_dm_access_private);
        interface = homeplug_interface_create(key, &params);
        amxc_var_clean(&params);
        when_null_trace(interface, exit, ERROR, "can not create interface %s", key);
        interface_obj_x->priv = interface;
        interface->interface_obj = interface_obj_x;
    }
    dm_homeplug_interface_macaddress(interface_obj_x, interface->interface);
    homeplug_interface_enable(interface);
    dm_homeplug_interface_update_status(interface_obj_x, "Up");

    retval = 0;
exit:
    free(key);
    return retval;
}

/**
   @brief Disables a HomePlug interface instance.

   If the given interface object contains an interface instance, it is disabled.
   The interface's status is set to "Down".

   @param interface_obj_x Pointer to the interface object instance.
 */
static void disable_interface(amxd_object_t* interface_obj_x) {
    homeplug_interface_t* interface = interface_obj_x->priv;
    if(interface != NULL) {
        homeplug_interface_disable(interface);
    }
    dm_homeplug_interface_update_status(interface_obj_x, "Down");
    return;
}

/**
   @brief Callback invoked to create and enable a HomePlug interface instance.

   This function is intended to be used as a callback for iterating
   over interface objects that need to be enabled. It calls
   @c create_and_enable_interface() for the given interface object.

   @param templ           Template object pointer (Unused).
   @param interface_obj_x Pointer to the interface object instance to enable.
   @param priv            Private data pointer (Unused).

   @return - 0 on success.
           - -1 if interface creation or enabling fails.
 */
static int interface_obj_x_enabled(UNUSED amxd_object_t* templ,
                                   amxd_object_t* interface_obj_x,
                                   UNUSED void* priv) {
    return(create_and_enable_interface(interface_obj_x));
}

/**
   @brief Callback invoked to disable a HomePlug interface instance.

   This function is intended to be used as a callback for iterating
   over interface objects that need to be disabled. It calls
   @c disable_interface() for the given interface object.

   @param templ           Template object pointer (Unused).
   @param interface_obj_x Pointer to the interface object instance to disable.
   @param priv            Private data pointer (Unused).

   @return 0.
 */
static int interface_obj_x_disabled(UNUSED amxd_object_t* templ,
                                    amxd_object_t* interface_obj_x,
                                    UNUSED void* priv) {
    disable_interface(interface_obj_x);
    return 0;
}

void _dm_homeplug_enable_changed(UNUSED const char* const event_name,
                                 const amxc_var_t* const event_data,
                                 UNUSED void* const priv) {
    bool enable = false;
    amxd_dm_t* dm = NULL;
    amxd_object_t* homeplug_obj = NULL;
    amxd_object_t* interface_obj = NULL;
    const char* filter = "";
    amxd_instance_cb_t fn = NULL;

    SAH_TRACEZ_INFO(ME, "homeplug toggle");
    dm = homeplug_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get HomePlug data model object.");
    homeplug_obj = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(homeplug_obj, exit, ERROR, "Unable to get the modified HomePlug object.");
    enable = amxd_object_get_value(bool, homeplug_obj, "Enable", NULL);
    enable ? homeplug_enable() : homeplug_disable();
    filter = "[Enable == true].";
    if(enable) {
        dm_homeplug_update_status(homeplug_obj, "Enabled");
        fn = interface_obj_x_enabled;
    } else {
        dm_homeplug_update_status(homeplug_obj, "Disabled");
        fn = interface_obj_x_disabled;
    }
    interface_obj = amxd_object_get_child(homeplug_obj, "Interface");
    when_null_trace(interface_obj, exit, ERROR, "interface obj is NULL pointer");
    amxd_object_for_all(interface_obj, filter, fn, (void*) NULL);

exit:
    return;

}

void _app_start(UNUSED const char* const event_name,
                UNUSED const amxc_var_t* const event_data,
                UNUSED void* const priv) {
    bool enable = false;
    amxd_dm_t* dm = NULL;
    amxd_object_t* homeplug_obj = NULL;
    amxd_object_t* interface_obj = NULL;
    const char* filter = "[Enable == true].";
    amxd_instance_cb_t fn = NULL;

    SAH_TRACEZ_INFO(ME, "app_start");

    dm = homeplug_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get HomePlug data model object.");
    homeplug_obj = amxd_dm_findf(dm, "HomePlug");
    when_null_trace(homeplug_obj, exit, ERROR, "Unable to get HomePlug object.");

    enable = amxd_object_get_value(bool, homeplug_obj, "Enable", NULL);
    if(enable) {
        homeplug_enable();
        dm_homeplug_update_status(homeplug_obj, "Enabled");
        fn = interface_obj_x_enabled;
        interface_obj = amxd_object_get_child(homeplug_obj, "Interface");
        when_null_trace(interface_obj, exit, ERROR, "interface obj is NULL pointer");
        amxd_object_for_all(interface_obj, filter, fn, (void*) NULL);
    }
exit:
    return;
}

void _dm_homeplug_interface_enable_changed(UNUSED const char* const event_name,
                                           const amxc_var_t* const event_data,
                                           UNUSED void* const priv) {

    amxd_object_t* interface_obj_x = NULL;
    amxd_object_t* homeplug_obj = NULL;
    bool interface_is_enabled = false;
    bool homeplug_is_enabled = false;

    SAH_TRACEZ_INFO(ME, "homeplug_interface_enable_changed");
    when_null_trace(event_data, exit, ERROR, "event_data is NULL pointer");

    interface_obj_x = amxd_dm_signal_get_object(homeplug_get_dm(), event_data);
    when_null_trace(interface_obj_x, exit, ERROR, "interface instance obj is NULL pointer");
    homeplug_obj = amxd_dm_findf(homeplug_get_dm(), "HomePlug.");
    when_null_trace(interface_obj_x, exit, ERROR, "homeplug obj is NULL pointer");
    interface_is_enabled = GETP_BOOL(event_data, "parameters.Enable.to");
    homeplug_is_enabled = amxd_object_get_value(bool, homeplug_obj, "Enable", NULL);
    if(interface_is_enabled && homeplug_is_enabled) {
        SAH_TRACEZ_INFO(ME, "interface enable");
        create_and_enable_interface(interface_obj_x);
    } else {
        SAH_TRACEZ_INFO(ME, "interface disable");
        disable_interface(interface_obj_x);
    }
exit:
    return;
}

void _dm_homeplug_interface_delete(UNUSED const char* const event_name,
                                   const amxc_var_t* const event_data,
                                   UNUSED void* const priv) {
    const char* name = NULL;
    SAH_TRACEZ_INFO(ME, "interface delete");
    when_null_trace(event_data, exit, ERROR, "event_data is NULL pointer");
    name = GET_CHAR(event_data, "name");
    when_str_empty_trace(name, exit, ERROR, "name is empty string");
    homeplug_interface_delete(name);
exit:
    return;
}

void _dm_homeplug_interface_added(UNUSED const char* const event_name,
                                  const amxc_var_t* const event_data,
                                  UNUSED void* const priv) {
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_x = NULL;
    amxd_object_t* homeplug_obj = NULL;
    bool homeplug_is_enabled = false;
    bool interface_is_enabled = false;
    int32_t index;
    SAH_TRACEZ_INFO(ME, "interface added");
    when_null_trace(event_data, exit, ERROR, "event_data is NULL pointer");
    interface_obj = amxd_dm_signal_get_object(homeplug_get_dm(), event_data);
    when_null_trace(interface_obj, exit, ERROR, "interface obj is NULL pointer");
    homeplug_obj = amxd_object_get_parent(interface_obj);
    when_null_trace(homeplug_obj, exit, ERROR, "homeplug obj is NULL pointer");
    homeplug_is_enabled = amxd_object_get_value(bool, homeplug_obj, "Enable", NULL);
    if(homeplug_is_enabled) {
        index = GET_UINT32(event_data, "index");
        interface_obj_x = amxd_object_get_instance(interface_obj, NULL, index);
        when_null_trace(interface_obj_x, exit, ERROR, "interface instance obj is NULL pointer");
        interface_is_enabled = amxd_object_get_value(bool, interface_obj_x, "Enable", NULL);
        if(interface_is_enabled) {
            SAH_TRACEZ_INFO(ME, "interface enable");
            create_and_enable_interface(interface_obj_x);
        }
    }
exit:
    return;
}

