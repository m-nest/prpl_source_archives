/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__DM_HOMEPLUG_H__)
#define __DM_HOMEPLUG_H__

#ifdef __cplusplus
extern "C"
{
#endif
// data model event handlers

#include "homeplug.h"

// dm homeplug event

/**
   @defgroup dm_homeplug
 */

/**
   @ingroup dm_homeplug
   @brief Event handler invoked when an "app:start" event is received.

   This function checks whether the HomePlug object is enabled in the
   data model and, if so, calls @c homeplug_enable(), updates the Homeplug
   object's status, and enables all child interfaces that have their "Enable"
   parameter set to @c true.

   @param event_name Name of the triggering event (Unused).
   @param event_data Event payload (Unused).
   @param priv       Private data (Unused).

   @note - If the HomePlug object is disabled, no initialization is performed.
         - If the HomePlug object is enabled, its status is updated to "Enabled"
           and all enabled child interfaces are activated.
 */
void _app_start(const char* const event_name,
                const amxc_var_t* const event_data,
                void* const priv);

/**
   @ingroup dm_homeplug
   @brief Event handler invoked when Homeplug's "Enable" parameter is changed in the data model.

   This function updates the HomePlug status, calls the appropriate
   enable/disable handler, and applies the change to all child interface objects.

   @param event_name Name of the triggering event (Unused).
   @param event_data Event payload containing the modified HomePlug object.
   @param priv       Private data (Unused).

   @note - If "Enable" is set to @c true, the HomePlug object status is updated
           to "Enabled", and all child interfaces are marked enabled.
         - If "Enable" is set to @c false, the HomePlug object status is updated
           to "Disabled", and all child interfaces are marked disabled.
 */
void _dm_homeplug_enable_changed(const char* const event_name,
                                 const amxc_var_t* const event_data,
                                 void* const priv);

/**
   @ingroup dm_homeplug
   @brief Event handler invoked when a Homeplug child interface's "Enable" parameter is changed
          in the data model.

   This function updates the interface's state based on the new "Enable" value and the enable
   state of the parent HomePlug object.

   @param event_name Name of the triggering event (Unused).
   @param event_data Event payload containing the interface instance and
                     updated parameter values.
   @param priv       Private data (Unused).

   @note - If the interface's "Enable" parameter is set to @c true:
           The interface is enabled only if the parent HomePlug object is enabled.
           If the HomePlug object is disabled, the interface is disabled.
         - If the interface's "Enable" parameter is set to @c false:
           The interface is disabled regardless of the HomePlug object state.
 */
void _dm_homeplug_interface_enable_changed(const char* const event_name,
                                           const amxc_var_t* const event_data,
                                           void* const priv);

/**
   @ingroup dm_homeplug
   @brief Event handler invoked when a HomePlug interface instance is removed.

   This function extracts the interface name from the event
   data and deletes the corresponding interface.

   @param event_name Name of the triggering event (Unused).
   @param event_data Event payload containing the interface information.
   @param priv       Private data (Unused).

   @note - The @c name field in @p event_data must be present and non-empty.
         - If the name is valid, the function invokes @c homeplug_interface_delete().
 */
void _dm_homeplug_interface_delete(UNUSED const char* const event_name,
                                   const amxc_var_t* const event_data,
                                   UNUSED void* const priv);

/**
   @ingroup dm_homeplug
   @brief Event handler invoked when a HomePlug interface instance is added.

   This function checks whether the parent HomePlug object
   is enabled, and if so, enables the newly added interface if its
   "Enable" parameter is set to @c true.

   @param event_name Name of the triggering event (Unused).
   @param event_data Event payload containing the interface object reference.
   @param priv       Private data (Unused).

   @note - If the HomePlug object is disabled, no action is taken.
         - When the HomePlug object is enabled, the new interface is retrieved
           using its @c index and enabled if its "Enable" parameter is set.
 */
void _dm_homeplug_interface_added(UNUSED const char* const event_name,
                                  const amxc_var_t* const event_data,
                                  UNUSED void* const priv);

// dm homeplug object
#define  dm_homeplug_interface_update_status dm_homeplug_update_status
/**
   @ingroup dm_homeplug
   @brief Update the status of a HomePlug object.

   Updates the operational status of a HomePlug interface in the data model.

   @param homeplug_obj HomePlug object to update.
   @param status       New status string.

   @return 0 when update succeeded. Any other value indicates an error.
 */
int dm_homeplug_update_status(amxd_object_t* homeplug_obj, const char* status);

/**
   @ingroup dm_homeplug
   @brief Add or update a HomePlug device in the interface object.

   @param homeplug_interface_obj_x Interface object in the data model.
   @param device_mac               MAC address of the device.
   @param device_params            Device parameters to set.

   @return true if added or updated successfully, false otherwise.
 */
bool dm_interface_add_or_update_device(amxd_object_t* homeplug_interface_obj_x,
                                       const uint8_t* device_mac,
                                       amxc_var_t* device_params);

/**
   @ingroup dm_homeplug
   @brief Remove inactive devices from the interface object.

   @param homeplug_interface_obj_x Interface object in the data model.
   @param active_devices           List of active devices to keep.

   @return true if cleanup was successful.
 */
bool dm_interface_cleanup_inactive_devices(amxd_object_t* homeplug_interface_obj_x,
                                           amxc_llist_t* active_devices);

/**
   @ingroup dm_homeplug
   @brief Update associated devices for a given HomePlug device.

   @param homeplug_interface_obj_x Interface object in the data model.
   @param device_mac               MAC address of the device.
   @param associated_devices       Updated associated device list.

   @return true if updated successfully, false otherwise.
 */
bool dm_device_update_associated_devices(amxd_object_t* homeplug_interface_obj_x,
                                         const uint8_t* device_mac,
                                         amxc_var_t* associated_devices);

#ifdef __cplusplus
}
#endif

#endif // __DM_HOMEPLUG_H__


