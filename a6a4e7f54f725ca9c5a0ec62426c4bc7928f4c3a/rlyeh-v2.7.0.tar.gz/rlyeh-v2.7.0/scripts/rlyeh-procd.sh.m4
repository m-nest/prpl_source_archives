#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="rlyeh"
PROG="/usr/bin/rlyeh"
datamodel_root="Rlyeh"
PROG_OPTIONS=""

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

preservice_hook() {
    if ${log_trace};then
        logger -s "pre-service hook ${name}"
    fi
    procd_append_env_opts LD_LIBRARY_PATH="/opt/prplos/usr/lib/"
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    if ${log_trace};then
#        logger -s "post-service hook ${name}"
#    fi
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

