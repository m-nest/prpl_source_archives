/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* System headers */
#include <string.h> /* memset() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h> /* when_null() */
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>     /* amxd_dm_findf() */

/* Own headers */
#include "sfpmgr.h"
#include "sfpmgr_main.h" /* sfp_get_dm() */
#include "optical_if.h"

/**
 * @brief Handles the insertion of an SFP (Small Form-factor Pluggable) device.
 *
 * @param[in] cage_index: index of SFPs.SFPCage.{i} instance
 * @param[in] sfp_type: SFP type of the SFP present in the cage identified by
 *    @a cage_index. Normally the caller of this function should not pass this
 *    info: the function can find the SFP type in the private data of type
 *    sfp_cage_t attached to the SFPs.SFPCage.{i} instance. But the unit tests
 *    in test/test-tr181_sfp call sfpmgr_sfp_inserted() directly. And it needs
 *    to pass the SFP type for the unit tests in that folder to pass.
 *
 * @return int Returns 0 on success, or a non-zero value if an error occurs.
 */
int sfpmgr_sfp_inserted(uint32_t cage_index, sfp_types_e sfp_type) {
    int rv = -1;
    sfp_info_t* sfp_info = NULL;
    sfp_cage_t* sfp_cage_info = NULL;

    SAH_TRACEZ_INFO(ME, "SFP Insert Handling for Cage %d", cage_index);

    /* Retreive Cage and SFP object
     * populate the SFP object with Ethtool information */
    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, cage_index);
    when_null(sfp_cage_object, exit);

    sfp_cage_info = (sfp_cage_t*) sfp_cage_object->priv;
    when_null(sfp_cage_info, exit);
    /**
     * The next line is not needed by tr181-sfp: 'sfp_cage_info->sfp_type'
     * already has the correct value. But the unit tests in test/test-tr181_sfp
     * call sfpmgr_sfp_inserted() directly.
     */
    sfp_cage_info->sfp_type = sfp_type;

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, cage_index);
    when_null(sfp_object, exit);

    SAH_TRACEZ_INFO(ME, "Updating Optical IF Instance");
    sfp_info = (sfp_info_t*) sfp_object->priv;
    if(sfp_info == NULL) {
        sfp_info = calloc(1, sizeof(sfp_info_t));
        when_null(sfp_info, exit);
        SAH_TRACEZ_INFO(ME, "inside sfp_info");
        sfp_object->priv = sfp_info;
    } else {
        memset(sfp_info, 0, sizeof(sfp_info_t));
    }
    /* update state */
    sfp_info->sfp_cage_id = cage_index;
    SAH_TRACEZ_INFO(ME, "sfp_cage_id %d sfp type: %d", cage_index, sfp_type);
    sfp_info->rx_los = true;
    SAH_TRACEZ_INFO(ME, "rx_los ");
    sfp_cage_info->state = SFP_STATE_RX_LOS;
    SAH_TRACEZ_INFO(ME, "Updated All sfp_info ");

    /* update static parameters */
    sfpmgr_object_init(sfp_cage_object, sfp_object);
    SAH_TRACEZ_INFO(ME, " calling sfpmgr_object_init success");

    /* update dynamic parameters */
    sfpmgr_object_update(sfp_cage_object, sfp_object);

    optical_interface_link_status(sfp_cage_info);
    SAH_TRACEZ_INFO(ME, "Updated Cage Info [%d] SFP inserted", sfp_cage_info->cage_id);
    rv = 0;

exit:
    return rv;
}

/**
 * @brief Handles the removal of an SFP (Small Form-factor Pluggable) module.
 *
 * @param[in] cage_index: index of SFPs.SFPCage.{i} instance
 *
 * @return int Returns 0 on success, or a negative error code on failure.
 */
int sfpmgr_sfp_removed(uint32_t cage_index) {
    int rv = -1;
    sfp_ethtool_t* sfp_param = calloc(1, sizeof(sfp_ethtool_t));
    if(sfp_param == NULL) {
        SAH_TRACEZ_INFO(ME, "sfp param is NULL");
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "SFP Remove Handling");
    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, cage_index);
    when_null(sfp_cage_object, exit);

    sfp_cage_t* sfp_cage_info = (sfp_cage_t*) sfp_cage_object->priv;
    when_null(sfp_cage_info, exit);
    sfp_cage_info->sfp_type = SFP_UNSUPPORTED;

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, cage_index);
    when_null(sfp_object, exit);
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);

    sfp_info->rx_los = true;

    memset(sfp_param, 0, sizeof(sfp_ethtool_t));
    SAH_TRACEZ_INFO(ME, "sfpmgr_update_static_params with empty value");
    sfpmgr_update_static_params(sfp_cage_object, sfp_object, sfp_param);
    SAH_TRACEZ_INFO(ME, "sfpmgr_update_dynamic_params with empty value");
    sfpmgr_update_dynamic_params(sfp_cage_object, sfp_object, sfp_param);

    /* reset the SFP object parameters to default */
    /* update state */
    sfp_cage_info->state = SFP_STATE_REMOVED;
    optical_interface_link_status(sfp_cage_info);
    SAH_TRACEZ_INFO(ME, "Updated Cage Info [%d] SFP removed", sfp_cage_info->cage_id);
    rv = 0;

exit:
    if(sfp_param != NULL) {
        free(sfp_param);
    }
    return rv;
}

/**
 * @brief Handles the event of an SFP module receiving a loss of signal (Rx LOS).
 *
 * @param[in] cage_index: index of SFPs.SFPCage.{i} instance
 *
 * @return int Returns 0 on success, or a negative error code on failure.
 */
int sfpmgr_sfp_rxlos(uint32_t cage_index) {
    int rv = -1;

    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, cage_index);
    when_null(sfp_cage_object, exit);

    sfp_cage_t* sfp_cage_info = (sfp_cage_t*) sfp_cage_object->priv;
    when_null(sfp_cage_info, exit);

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, cage_index);
    when_null(sfp_object, exit);
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);
    sfp_info->rx_los = true;

    /* reset the SFP object parameters to default */
    /* update state */
    sfp_cage_info->state = SFP_STATE_RX_LOS;
    optical_interface_link_status(sfp_cage_info);
    SAH_TRACEZ_INFO(ME, "Updated Cag Info [%d] updated Rx Los", sfp_cage_info->cage_id);
    rv = 0;

exit:
    return rv;
}

/**
 * @brief Handles the event when the Rx LOS (Loss of Signal) is cleared on an SFP.
 *
 * @param[in] cage_index: index of SFPs.SFPCage.{i} instance
 *
 * @return int Returns 0 on success, or a negative error code on failure.
 */
int sfpmgr_sfp_rxlos_cleared(uint32_t cage_index) {
    int rv = -1;

    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, cage_index);
    when_null(sfp_cage_object, exit);

    sfp_cage_t* sfp_cage_info = (sfp_cage_t*) sfp_cage_object->priv;
    when_null(sfp_cage_info, exit);

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, cage_index);
    when_null(sfp_object, exit);
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);
    sfp_info->rx_los = false;

    /* update state */
    sfp_cage_info->state = SFP_STATE_RX_LOS_CLEARED;
    optical_interface_link_status(sfp_cage_info);
    SAH_TRACEZ_INFO(ME, "Updated Cage Info [%d] updated Rx Los Clear", sfp_cage_info->cage_id);
    rv = 0;

exit:
    return rv;
}

/**
 * @brief Updates the information for an SFP cage.
 *
 * @param[in] sfp_cage_info A pointer to the `sfp_cage_t` structure containing the cage info.
 *
 * @return int Returns 0 on success, or a negative error code on failure.
 */
int sfpmgr_cage_info_update(sfp_cage_t* sfp_cage_info) {
    int rv = -1;
    const uint32_t index = sfp_cage_info->cage_id; /* alias */

    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, index);
    when_null(sfp_cage_object, exit);
    when_null(sfp_cage_info, exit);

    sfp_cage_object->priv = sfp_cage_info;
    SAH_TRACEZ_INFO(ME, "Updated Cage Info [%d]", index);

    /* initialize the optical interface dm for this cage */
    rv = optical_if_update_interface_instance(sfp_cage_info);

exit:
    return rv;
}


