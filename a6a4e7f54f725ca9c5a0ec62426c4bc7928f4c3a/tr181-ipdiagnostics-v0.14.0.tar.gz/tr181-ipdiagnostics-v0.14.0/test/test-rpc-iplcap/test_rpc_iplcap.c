/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>
#include <yajl/yajl_gen.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>
#include <amxb/amxb_register.h>
#include <amxb/amxb_connect.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include <amxj/amxj_variant.h>

#include "test_rpc_iplcap.h"
#include "iplcap.h"
#include "priv_iplcap.h"
#include "ip_diagnostics.h"
#include "ip_diagnostics_priv.h"
#include "rpc.h"
#include "dummy_backend.h"
#include "test_common.h"
#include "test_common_rpc.h"

static const char* odl_defs = "../../odl/tr181-ipdiagnostics_definition.odl";
static const char* mock_odl_defs = "../mock_odl/mock.odl";
static const char* mock_odl_ip = "../mock_odl/mock_ip.odl";

static amxd_dm_t dm;
static amxo_parser_t parser;
static amxc_var_t args;
static amxb_bus_ctx_t* bus_ctx = NULL;
static amxc_var_t ret;

static void clean_variables() {
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

static void common_end_test() {
    handle_events();
    clean_variables();
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;
    amxd_object_t* ipd = NULL;
    amxd_object_t* ipd_iplcap = NULL;
    int ret_value = 0;

    ret_value = system("udpst -x -T");
    assert_int_equal(ret_value, 0);

    ret_value = system("pgrep udpst > /dev/null");
    assert_int_equal(ret_value, 0);

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);
    assert_int_equal(test_register_dummy_be(), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    amxo_connection_add(&parser,
                        amxb_get_fd(bus_ctx),
                        connection_read,
                        "dummy:/tmp/dummy.sock",
                        AMXO_BUS,
                        bus_ctx);
    amxb_register(bus_ctx, &dm);

    assert_int_equal(amxo_resolver_ftab_add(&parser,
                                            "IPDiagnostics.IPLayerCapacity",
                                            AMXO_FUNC(_IPLayerCapacity)
                                            ), 0);
    assert_int_equal(amxo_resolver_ftab_add(&parser,
                                            "ipd_iplcap_check_dst",
                                            AMXO_FUNC(_ipd_iplcap_check_dst)
                                            ), 0);
    assert_int_equal(amxo_resolver_ftab_add(&parser,
                                            "write_iplcapstate_params",
                                            AMXO_FUNC(_write_iplcapstate_params)
                                            ), 0);
    assert_int_equal(amxo_resolver_ftab_add(&parser,
                                            "ipd_iplcap_writable_dm_changed",
                                            AMXO_FUNC(_ipd_iplcap_writable_dm_changed)
                                            ), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, mock_odl_defs, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, mock_odl_ip, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);

    // empty signal handler for 'amxp_slot_connect'
    amxp_sigmngr_add_signal(NULL, "connection-deleted");

    assert_int_equal(_ip_diagnostics_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    ipd = amxd_object_get(root_obj, "IPDiagnostics");
    ipd_iplcap = amxd_object_get(ipd, "IPLayerCapacityMetrics");
    if(ipd_iplcap == NULL) {
        ret_value = 1;
        assert_int_equal(ret_value, 0);
    }

    return 0;
}

/* Helper: Standardize IPLCAP input arguments for tests */
typedef struct iplcap_inputs_s {
    cstring_t interface;
    cstring_t role;
    cstring_t server_list;
    bool jumbo_frames_permitted;
    uint32_t mtu;
    bool local_interface_rate_included;
    bool authentication_enabled;
    cstring_t authentication_code;
    cstring_t authentication_alias;
    cstring_t authentication_key_file_location;
    uint32_t flow_count;
    uint32_t maximum_flows;
    uint8_t ethernet_priority;
    uint8_t dscp;
    cstring_t protocol_version;
    uint32_t udp_payload_min;
    uint32_t udp_payload_max;
    cstring_t udp_payload_content;
    uint32_t port_min;
    uint32_t port_max;
    uint32_t port_optional_min;
    uint32_t port_optional_max;
    cstring_t test_type;
    bool ipdv_enable;
    bool iprr_enable;
    bool ripr_enable;
    uint32_t preamble_duration;
    uint32_t maximum_test_bandwidth;
    uint32_t start_sending_rate;
    uint32_t start_sending_rate_index;
    uint32_t number_test_sub_intervals;
    uint32_t number_first_mode_test_sub_intervals;
    uint32_t test_sub_interval;
    uint32_t status_feedback_interval;
    uint32_t timeout_no_test_traffic;
    uint32_t timeout_no_status_message;
    uint32_t tmax;
    uint32_t tmax_rtt;
    uint32_t timestamp_resolution;
    uint32_t seq_err_thresh;
    bool reord_dup_ignore_enable;
    uint32_t lower_thresh;
    uint32_t upper_thresh;
    uint32_t retry_thresh;
    uint32_t high_speed_delta;
    cstring_t rate_adj_algorithm;
    uint32_t slow_adj_thresh;
    uint32_t hspeed_thresh;
} iplcap_inputs_t;

static void iplcap_inputs_set_defaults(iplcap_inputs_t* in) {
    in->interface = "";
    in->role = "Sender";
    in->server_list = "127.0.0.1:25000";
    in->jumbo_frames_permitted = true;
    in->mtu = 1500;
    in->local_interface_rate_included = true;
    in->authentication_enabled = false;
    in->authentication_code = "";
    in->authentication_alias = "";
    in->authentication_key_file_location = "";
    in->flow_count = 0;
    in->maximum_flows = 0;
    in->ethernet_priority = 0;
    in->dscp = 0;
    in->protocol_version = "Any";
    in->udp_payload_min = 52;
    in->udp_payload_max = 8972;
    in->udp_payload_content = "zeroes";
    in->port_min = 49152;
    in->port_max = 65535;
    in->port_optional_min = 0;
    in->port_optional_max = 0;
    in->test_type = "Search";
    in->ipdv_enable = false;
    in->iprr_enable = true;
    in->ripr_enable = true;
    in->preamble_duration = 0;
    in->maximum_test_bandwidth = 0;
    in->start_sending_rate = 500;
    in->start_sending_rate_index = 0;
    in->number_test_sub_intervals = 5;
    in->number_first_mode_test_sub_intervals = 0;
    in->test_sub_interval = 1000;
    in->status_feedback_interval = 50;
    in->timeout_no_test_traffic = 1000;
    in->timeout_no_status_message = 1000;
    in->tmax = 1000;
    in->tmax_rtt = 3000;
    in->timestamp_resolution = 1;
    in->seq_err_thresh = 10;
    in->reord_dup_ignore_enable = true;
    in->lower_thresh = 30;
    in->upper_thresh = 90;
    in->retry_thresh = 5;
    in->high_speed_delta = 10;
    in->rate_adj_algorithm = "B";
    in->slow_adj_thresh = 3;
    in->hspeed_thresh = 1000000000;
}

/* Helper: Run test with inputs, wait for completion, collect dm_out */
static void iplcap_run_and_collect(const iplcap_inputs_t* in, amxc_var_t* dm_out) {
    int32_t fd = -1;
    cstring_t str_status = NULL;
    amxd_status_t status;
    amxd_object_t* ipd_iplcap_object = NULL;
    bool jumbo_frames_permitted = in->jumbo_frames_permitted;
    uint32_t mtu = in->mtu;
    bool local_interface_rate_included = in->local_interface_rate_included;
    bool authentication_enabled = in->authentication_enabled;
    uint32_t flow_count = in->flow_count;
    uint32_t maximum_flows = in->maximum_flows;
    uint8_t ethernet_priority = in->ethernet_priority;
    uint8_t dscp = in->dscp;
    uint32_t udp_payload_min = in->udp_payload_min;
    uint32_t udp_payload_max = in->udp_payload_max;
    uint32_t port_min = in->port_min;
    uint32_t port_max = in->port_max;
    uint32_t port_optional_min = in->port_optional_min;
    uint32_t port_optional_max = in->port_optional_max;
    bool ipdv_enable = in->ipdv_enable;
    bool iprr_enable = in->iprr_enable;
    bool ripr_enable = in->ripr_enable;
    uint32_t preamble_duration = in->preamble_duration;
    uint32_t maximum_test_bandwidth = in->maximum_test_bandwidth;
    uint32_t start_sending_rate = in->start_sending_rate;
    uint32_t start_sending_rate_index = in->start_sending_rate_index;
    uint32_t number_test_sub_intervals = in->number_test_sub_intervals;
    uint32_t number_first_mode_test_sub_intervals = in->number_first_mode_test_sub_intervals;
    uint32_t test_sub_interval = in->test_sub_interval;
    uint32_t status_feedback_interval = in->status_feedback_interval;
    uint32_t timeout_no_test_traffic = in->timeout_no_test_traffic;
    uint32_t timeout_no_status_message = in->timeout_no_status_message;
    uint32_t tmax = in->tmax;
    uint32_t tmax_rtt = in->tmax_rtt;
    uint32_t timestamp_resolution = in->timestamp_resolution;
    uint32_t seq_err_thresh = in->seq_err_thresh;
    bool reord_dup_ignore_enable = in->reord_dup_ignore_enable;
    uint32_t lower_thresh = in->lower_thresh;
    uint32_t upper_thresh = in->upper_thresh;
    uint32_t retry_thresh = in->retry_thresh;
    uint32_t high_speed_delta = in->high_speed_delta;
    uint32_t slow_adj_thresh = in->slow_adj_thresh;
    uint32_t hspeed_thresh = in->hspeed_thresh;

    status = ipd_iplcap_diagnostics(&dm, &args, &ret,
                                    in->interface, in->role, in->server_list,
                                    &jumbo_frames_permitted, &mtu,
                                    &local_interface_rate_included,
                                    &authentication_enabled,
                                    in->authentication_code,
                                    in->authentication_alias,
                                    in->authentication_key_file_location,
                                    &flow_count, &maximum_flows,
                                    &ethernet_priority, &dscp,
                                    in->protocol_version,
                                    &udp_payload_min, &udp_payload_max,
                                    in->udp_payload_content,
                                    &port_min, &port_max,
                                    &port_optional_min, &port_optional_max,
                                    in->test_type,
                                    &ipdv_enable, &iprr_enable, &ripr_enable,
                                    &preamble_duration,
                                    &maximum_test_bandwidth,
                                    &start_sending_rate,
                                    &start_sending_rate_index,
                                    &number_test_sub_intervals,
                                    &number_first_mode_test_sub_intervals,
                                    &test_sub_interval,
                                    &status_feedback_interval,
                                    &timeout_no_test_traffic,
                                    &timeout_no_status_message,
                                    &tmax, &tmax_rtt,
                                    &timestamp_resolution,
                                    &seq_err_thresh,
                                    &reord_dup_ignore_enable,
                                    &lower_thresh, &upper_thresh,
                                    &retry_thresh,
                                    &high_speed_delta,
                                    in->rate_adj_algorithm,
                                    &slow_adj_thresh,
                                    &hspeed_thresh);

    assert_int_equal(status, amxd_status_deferred);

    fd = get_iplcap_test_fd_from_dm(&dm);
    str_status = get_iplcap_test_status_from_dm(&dm);
    while(strcmp(str_status, IPLCAP_STATUS_COMPLETE) &&
          strcmp(str_status, IPLCAP_STATUS_ERROR) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_HOST_NAME) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_ROUTE) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_INIT_CONN) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_NO_RESP) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_PWD_REQ) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_LOGIN) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_REJECTED) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_SIZE) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_TIMEOUT) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_INTERNAL) &&
          strcmp(str_status, IPLCAP_STATUS_ERR_OTHER)) {
        ipd_iplcap_check(fd, NULL);
        handle_events();
        str_status = get_iplcap_test_status_from_dm(&dm);
    }

    common_end_test();

    ipd_iplcap_object = amxd_dm_findf(&dm, "IPDiagnostics.IPLayerCapacityMetrics.");
    assert_non_null(ipd_iplcap_object);
    ipd_obj_data_to_var(ipd_iplcap_object, NULL, dm_out);
}

/* Helper: Verify all required output parameters from IPLCAP test results */
static void iplcap_verify_output_parameters(const amxc_var_t* dm_out, const iplcap_inputs_t* in) {
    // Verify all required output parameters

    uint32_t active_flows = GET_UINT32(dm_out, IPLCAP_RET_KEY_ACTIVE_FLOWS);
    assert_true(active_flows == 0);

    const char* interface_eth_mbps = GETP_CHAR(dm_out, IPLCAP_RET_KEY_ETH_MBPS_MAX);
    assert_non_null(interface_eth_mbps);
    assert_true(strlen(interface_eth_mbps) > 0);

    const char* interface_eth_mbps_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_ETH_MBPS_SUM);
    assert_non_null(interface_eth_mbps_summary);
    assert_true(strlen(interface_eth_mbps_summary) > 0);

    const char* ip_cap_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_IP_CAP_SUMMARY);
    assert_non_null(ip_cap_summary);
    assert_true(strlen(ip_cap_summary) > 0);

    const char* loss_ratio = GETP_CHAR(dm_out, IPLCAP_RET_KEY_LOSS_RATIO_MAX);
    assert_non_null(loss_ratio);
    assert_true(strlen(loss_ratio) > 0);

    const char* loss_ratio_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_LOSS_RATIO_SUM);
    assert_non_null(loss_ratio_summary);
    assert_true(strlen(loss_ratio_summary) > 0);

    const char* max_eth_no_fcs = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MAX_ETH_NO_FCS);
    assert_non_null(max_eth_no_fcs);
    assert_true(strlen(max_eth_no_fcs) > 0);

    const char* max_eth_with_fcs = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MAX_ETH_WITH_FCS);
    assert_non_null(max_eth_with_fcs);
    assert_true(strlen(max_eth_with_fcs) > 0);

    const char* max_eth_with_vlan = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MAX_ETH_WITH_VLAN);
    assert_non_null(max_eth_with_vlan);
    assert_true(strlen(max_eth_with_vlan) > 0);

    const char* max_ip_cap = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MAX_IP_CAP);
    assert_non_null(max_ip_cap);
    assert_true(strlen(max_ip_cap) > 0);

    const char* min_owd = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MIN_OWD_MAX);
    assert_non_null(min_owd);
    assert_true(strlen(min_owd) > 0);

    const char* min_owd_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MIN_OWD_SUM);
    assert_non_null(min_owd_summary);
    assert_true(strlen(min_owd_summary) > 0);

    const char* min_rtt_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_MIN_RTT_SUM);
    assert_non_null(min_rtt_summary);
    assert_true(strlen(min_rtt_summary) > 0);

    const char* pdv_range = GETP_CHAR(dm_out, IPLCAP_RET_KEY_PDV_RANGE_MAX);
    assert_non_null(pdv_range);
    assert_true(strlen(pdv_range) > 0);

    const char* pdv_range_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_PDV_RANGE_SUM);
    assert_non_null(pdv_range_summary);
    assert_true(strlen(pdv_range_summary) > 0);

    const char* reordered_ratio = GETP_CHAR(dm_out, IPLCAP_RET_KEY_REORD_RATIO_MAX);
    assert_non_null(reordered_ratio);
    assert_true(strlen(reordered_ratio) > 0);

    const char* reordered_ratio_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_REORD_RATIO_SUM);
    assert_non_null(reordered_ratio_summary);
    assert_true(strlen(reordered_ratio_summary) > 0);

    const char* replicated_ratio = GETP_CHAR(dm_out, IPLCAP_RET_KEY_REPL_RATIO_MAX);
    assert_non_null(replicated_ratio);
    assert_true(strlen(replicated_ratio) > 0);

    const char* replicated_ratio_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_REPL_RATIO_SUM);
    assert_non_null(replicated_ratio_summary);
    assert_true(strlen(replicated_ratio_summary) > 0);

    const char* rtt_max = GETP_CHAR(dm_out, IPLCAP_RET_KEY_RTT_MAX_MAX);
    assert_non_null(rtt_max);
    assert_true(strlen(rtt_max) > 0);

    const char* rtt_min = GETP_CHAR(dm_out, IPLCAP_RET_KEY_RTT_MIN_MAX);
    assert_non_null(rtt_min);
    assert_true(strlen(rtt_min) > 0);

    const char* rtt_range = GETP_CHAR(dm_out, IPLCAP_RET_KEY_RTT_RANGE_MAX);
    assert_non_null(rtt_range);
    assert_true(strlen(rtt_range) > 0);

    const char* rtt_range_summary = GETP_CHAR(dm_out, IPLCAP_RET_KEY_RTT_RANGE_SUM);
    assert_non_null(rtt_range_summary);
    assert_true(strlen(rtt_range_summary) > 0);

    uint32_t status_code = GET_UINT32(dm_out, IPLCAP_RET_KEY_STATUS_CODE);
    assert_true(status_code == 0);

    uint32_t test_interval = GET_UINT32(dm_out, IPLCAP_RET_KEY_TEST_INTERVAL);
    assert_true(test_interval == (uint32_t) (in->test_sub_interval * in->number_test_sub_intervals / 1000));

    uint32_t timestamp_res_used = GET_UINT32(dm_out, IPLCAP_RET_KEY_TS_RES_USED);
    assert_true(timestamp_res_used > 0);

    uint32_t tmax_rtt_used = GET_UINT32(dm_out, IPLCAP_RET_KEY_TMAX_RTT_USED);
    assert_true(tmax_rtt_used > 0);

    uint32_t tmax_used = GET_UINT32(dm_out, IPLCAP_RET_KEY_TMAX_USED);
    assert_true(tmax_used > 0);

    // Verify table instances
    // Check IncrementalResult table has the expected number of instances
    amxc_var_t* incremental_result = amxc_var_get_key(dm_out, IPLCAP_RET_KEY_INC, AMXC_VAR_FLAG_DEFAULT);
    assert_non_null(incremental_result);
    assert_int_equal(amxc_var_type_of(incremental_result), AMXC_VAR_ID_HTABLE);

    uint32_t incremental_count = amxc_htable_size(&incremental_result->data.vm);
    assert_true(incremental_count == in->number_test_sub_intervals);

    if(in->number_first_mode_test_sub_intervals > 0) {
        // Check ModalResult table instances (only if bimodal test is configured)
        amxc_var_t* modal_result = amxc_var_get_key(dm_out, IPLCAP_RET_KEY_MODAL, AMXC_VAR_FLAG_DEFAULT);
        assert_non_null(modal_result);
        assert_int_equal(amxc_var_type_of(modal_result), AMXC_VAR_ID_HTABLE);

        uint32_t modal_count = amxc_htable_size(&modal_result->data.vm);
        assert_true(modal_count == 1);
    }
}

/* Helper: Attempt to start IPLCAP with inputs and return status (for invalid tests) */
static amxd_status_t iplcap_try_start(const iplcap_inputs_t* in) {
    /* Local copies to safely pass addresses */
    bool jumbo_frames_permitted = in->jumbo_frames_permitted;
    uint32_t mtu = in->mtu;
    bool local_interface_rate_included = in->local_interface_rate_included;
    bool authentication_enabled = in->authentication_enabled;
    uint32_t flow_count = in->flow_count;
    uint32_t maximum_flows = in->maximum_flows;
    uint8_t ethernet_priority = in->ethernet_priority;
    uint8_t dscp = in->dscp;
    uint32_t udp_payload_min = in->udp_payload_min;
    uint32_t udp_payload_max = in->udp_payload_max;
    uint32_t port_min = in->port_min;
    uint32_t port_max = in->port_max;
    uint32_t port_optional_min = in->port_optional_min;
    uint32_t port_optional_max = in->port_optional_max;
    bool ipdv_enable = in->ipdv_enable;
    bool iprr_enable = in->iprr_enable;
    bool ripr_enable = in->ripr_enable;
    uint32_t preamble_duration = in->preamble_duration;
    uint32_t maximum_test_bandwidth = in->maximum_test_bandwidth;
    uint32_t start_sending_rate = in->start_sending_rate;
    uint32_t start_sending_rate_index = in->start_sending_rate_index;
    uint32_t number_test_sub_intervals = in->number_test_sub_intervals;
    uint32_t number_first_mode_test_sub_intervals = in->number_first_mode_test_sub_intervals;
    uint32_t test_sub_interval = in->test_sub_interval;
    uint32_t status_feedback_interval = in->status_feedback_interval;
    uint32_t timeout_no_test_traffic = in->timeout_no_test_traffic;
    uint32_t timeout_no_status_message = in->timeout_no_status_message;
    uint32_t tmax = in->tmax;
    uint32_t tmax_rtt = in->tmax_rtt;
    uint32_t timestamp_resolution = in->timestamp_resolution;
    uint32_t seq_err_thresh = in->seq_err_thresh;
    bool reord_dup_ignore_enable = in->reord_dup_ignore_enable;
    uint32_t lower_thresh = in->lower_thresh;
    uint32_t upper_thresh = in->upper_thresh;
    uint32_t retry_thresh = in->retry_thresh;
    uint32_t high_speed_delta = in->high_speed_delta;
    uint32_t slow_adj_thresh = in->slow_adj_thresh;
    uint32_t hspeed_thresh = in->hspeed_thresh;

    return ipd_iplcap_diagnostics(&dm, &args, &ret,
                                  in->interface, in->role, in->server_list,
                                  &jumbo_frames_permitted, &mtu,
                                  &local_interface_rate_included,
                                  &authentication_enabled,
                                  in->authentication_code,
                                  in->authentication_alias,
                                  in->authentication_key_file_location,
                                  &flow_count, &maximum_flows,
                                  &ethernet_priority, &dscp,
                                  in->protocol_version,
                                  &udp_payload_min, &udp_payload_max,
                                  in->udp_payload_content,
                                  &port_min, &port_max,
                                  &port_optional_min, &port_optional_max,
                                  in->test_type,
                                  &ipdv_enable, &iprr_enable, &ripr_enable,
                                  &preamble_duration,
                                  &maximum_test_bandwidth,
                                  &start_sending_rate,
                                  &start_sending_rate_index,
                                  &number_test_sub_intervals,
                                  &number_first_mode_test_sub_intervals,
                                  &test_sub_interval,
                                  &status_feedback_interval,
                                  &timeout_no_test_traffic,
                                  &timeout_no_status_message,
                                  &tmax, &tmax_rtt,
                                  &timestamp_resolution,
                                  &seq_err_thresh,
                                  &reord_dup_ignore_enable,
                                  &lower_thresh, &upper_thresh,
                                  &retry_thresh,
                                  &high_speed_delta,
                                  in->rate_adj_algorithm,
                                  &slow_adj_thresh,
                                  &hspeed_thresh);
}

int test_teardown(UNUSED void** state) {
    system("pkill udpst");

    int ret = system("pgrep udpst > /dev/null");
    assert_int_not_equal(ret, 0);
    assert_int_equal(_ip_diagnostics_main(1, &dm, &parser), 0);

    amxb_free(&bus_ctx);
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
    clean_variables();

    test_unregister_dummy_be();
    return 0;
}

void test_iplcap_failed_invalid_parameter(UNUSED void** state) {
    iplcap_inputs_t in;
    amxd_status_t status;

    iplcap_inputs_set_defaults(&in);
    /* Introduce invalid rate adjustment algorithm value */
    in.rate_adj_algorithm = "A";

    status = iplcap_try_start(&in);
    assert_int_equal(status, amxd_status_invalid_value);
    common_end_test();
}

void test_iplcap_failed_missing_mandatory_parameter(UNUSED void** state) {
    iplcap_inputs_t in;
    amxd_status_t status;

    iplcap_inputs_set_defaults(&in);
    /* Introduce invalid rate adjustment algorithm value */
    in.server_list = NULL;

    status = iplcap_try_start(&in);
    assert_int_equal(status, amxd_status_invalid_function_argument);
    common_end_test();
}

void test_iplcap_success_default_arguments(UNUSED void** state) {
    iplcap_inputs_t in;
    amxc_var_t dm_out;
    cstring_t str_status = NULL;
    amxd_object_t* ipd_iplcap_object = NULL;

    iplcap_inputs_set_defaults(&in);
    amxc_var_init(&dm_out);
    amxc_var_set_type(&dm_out, AMXC_VAR_ID_HTABLE);

    iplcap_run_and_collect(&in, &dm_out);

    ipd_iplcap_object = amxd_dm_findf(&dm, "IPDiagnostics.IPLayerCapacityMetrics.");
    assert_non_null(ipd_iplcap_object);
    str_status = get_iplcap_test_status_from_dm(&dm);
    assert_string_equal(str_status, IPLCAP_STATUS_COMPLETE);

    // Verify all required output parameters
    iplcap_verify_output_parameters(&dm_out, &in);

    amxc_var_clean(&dm_out);
}

void test_iplcap_success_transition_new_test_while_running(UNUSED void** state) {
    iplcap_inputs_t in2;
    amxd_status_t status2;
    amxc_var_t dm_out;
    amxd_trans_t transaction;
    int32_t ret_value;
    amxd_object_t* ipd_iplcap_object = NULL;
    cstring_t str_status = NULL;

    // Start the default test
    ipd_iplcap_object = amxd_dm_findf(&dm, "IPDiagnostics.IPLayerCapacityMetrics.");
    assert_non_null(ipd_iplcap_object);

    ret_value = amxd_trans_init(&transaction);
    assert_int_equal(ret_value, 0);

    ret_value = amxd_trans_select_object(&transaction, ipd_iplcap_object);
    assert_int_equal(ret_value, 0);

    amxd_trans_set_value(cstring_t, &transaction, IPLCAP_RET_KEY_DST, IPLCAP_STATUS_REQUESTED);

    ret_value = amxd_trans_apply(&transaction, &dm);
    assert_int_equal(ret_value, 0);

    amxd_trans_clean(&transaction);

    handle_events();

    str_status = get_iplcap_test_status_from_dm(&dm);
    assert_string_equal(str_status, IPLCAP_STATUS_REQUESTED);

    // Set up second test with different parameters
    iplcap_inputs_set_defaults(&in2);
    in2.number_first_mode_test_sub_intervals = 1;

    amxc_var_init(&dm_out);
    amxc_var_set_type(&dm_out, AMXC_VAR_ID_HTABLE);

    // Immediately start second test (this should stop the first test)
    status2 = iplcap_try_start(&in2);
    assert_int_equal(status2, amxd_status_deferred);

    // Let the test complete and collect results
    iplcap_run_and_collect(&in2, &dm_out);

    // Verify all required output parameters should be from the second test
    iplcap_verify_output_parameters(&dm_out, &in2);

    amxc_var_clean(&dm_out);
}

void test_iplcap_success_launch_new_test_after_cancel(UNUSED void** state) {
    iplcap_inputs_t in;
    amxd_trans_t transaction;
    int32_t ret_value;
    amxd_object_t* ipd_iplcap_object = NULL;
    amxc_var_t dm_out;
    cstring_t str_status = NULL;

    // Set up test with specific parameters for cancel/new test scenario
    iplcap_inputs_set_defaults(&in);
    in.number_first_mode_test_sub_intervals = 1;

    amxc_var_init(&dm_out);
    amxc_var_set_type(&dm_out, AMXC_VAR_ID_HTABLE);

    // Start first test
    amxd_status_t status = iplcap_try_start(&in);
    assert_int_equal(status, amxd_status_deferred);

    // Cancel the test
    ipd_iplcap_object = amxd_dm_findf(&dm, "IPDiagnostics.IPLayerCapacityMetrics.");
    assert_non_null(ipd_iplcap_object);

    ret_value = amxd_trans_init(&transaction);
    assert_int_equal(ret_value, 0);

    ret_value = amxd_trans_select_object(&transaction, ipd_iplcap_object);
    assert_int_equal(ret_value, 0);

    amxd_trans_set_value(cstring_t, &transaction, IPLCAP_RET_KEY_DST, IPLCAP_STATUS_CANCELED);

    ret_value = amxd_trans_apply(&transaction, &dm);
    assert_int_equal(ret_value, 0);

    amxd_trans_clean(&transaction);

    handle_events();

    str_status = get_iplcap_test_status_from_dm(&dm);
    assert_string_equal(str_status, IPLCAP_STATUS_NONE);
    common_end_test();

    // Start new test and collect results
    iplcap_run_and_collect(&in, &dm_out);

    // Verify all required output parameters
    iplcap_verify_output_parameters(&dm_out, &in);

    amxc_var_clean(&dm_out);
}
