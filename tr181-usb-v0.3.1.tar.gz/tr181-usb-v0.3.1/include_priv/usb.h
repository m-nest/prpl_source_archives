/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
/**
 * @mainpage Overview
 * @version 1.0
 *
 * @section intro_sec Introduction
 *
 * This documentation presents the APIs used by usb manager.
 *
 * The APIs expose the followings :
 *
 *  - Receives Add/Del device events via `event2usb`.
 *  - Manages the `tr181-usb` data model by creating/removing objects.
 *  - Implements APIs to add/remove USB devices and hosts.
 *
 *
 * @section copyright_sec Copyright
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: 2025 Sagemcom
 *
 * This code is subject to the terms of the BSD+Patent license.
 *
 * See LICENSE file for more details.
 *
 *
 * By using this library, third parties must ensure of their code is compatible with this license. Feel free to ask in case of doubt.
 *
 *
 *
 * @section changelog_sec Changelog
 *
 * Version 1.0 : First release of USB limited data model
 *
 * @section architecture_sec Architecture overview
 *
 * @image html usb_overview.png "Architecture overview" width=900px height=600px
 *
 * The global architecture can be represented by the above chart which is composed by the tr181-usb plugin which is built on top of the Ambiorix framework. It uses the `event2usb` to receive device events and updates the data model to reflect the current state of USB devices. The plugin provides APIs to add and remove USB devices and hosts.
   `event2usb`  is a binary parser that retrieves usb information from environment variables when an USB event is triggered.
 *
 * @section usage_sec Usage Overview
 *
 * @subsection components_sec Components
 *
 * 1. **tr181-usb Plugin**:
 *  - Receives Add/Del device events via `event2usb`.
 *  - Manages the `tr181-usb` data model by creating/removing objects.
 *  - Implements APIs to add/remove USB devices and hosts.
 *  - The plugin consists on the following parts:
 *   -- **usb.c**: Initializes the plugin and handles the main entry points.
 *   -- **usb_port.c**: Manages USB ports, including finding and creating ports.
 *   -- **usb_host.c**: Manages USB hosts, including adding and removing devices.
 *   -- **usb_dm.c**: Handles data model updates and device actions.
 *   -- **usb_device.c**: Manages USB devices, including creating and deleting device objects.
 *   -- **usb_controller.c**: Provides utility functions and error handling.
 *   -- **usb_configuration.c**: Manages USB configurations and interfaces.
 *
 * 2. **hotplug2usb Module**:
 *  - By default event2usb is provided by hotplug2usb module that relies on <code>hotplug</code>.
 *  - The event2usb is called by linux hotplug each time a new device is added or deleted in the file system.
 *  - The event2usb will then send notification via ubus with information related to the devices to tr181-usb to inform about the usb devices' insertion and removal.
 *
 * 3. **mdev2usb Module**:
 *  - This module is used when the CONFIG_AMX_TR181_USB_BUSYBOX_MDEV_OPTIONS token is enabled.
 *  - Implements the event2usb binary.
 *  - The event2usb is called by by Busybox mdev each time a new device is added or deleted in the file system.
 *  - The event2usb will then send notification via ubus with information related to the devices to tr181-usb to inform about the usb devices' insertion and removal.
 *
 * @subsection workflow_sec Workflow
 *
 * 1. **Event Handling**:
 *   - `event2usb` triggers events for device addition/removal.
 *
 * 2. **Data Model Update**:
 *   - The plugin updates the data model based on the events.
 *
 *
 * @subsection api_sec APIs
 *
 * The `tr181-usb` plugin provides the following APIs:
 *
 * @subsubsection addbus_sec addBus
 * Creates a USB host controller.
 * - **Parameters**:
 *  - `busnum`: The bus number.
 *  - `usbversion`: The USB version.
 *  - `usbtype`: The USB type.
 * - **Example**: `addBus(busnum="4", usbversion="3.10", usbtype="xHCI")`
 *
 *
 * @subsubsection adddev_sec addDev
 * Creates a USB device.
 * - **Parameters**:
 *  - `type`: The device type.
 *  - `sysfs`: The sysfs ID.
 *  - `name`: The device name.
 * - **Example**: `addDev(type="disk", sysfs="4-1", name="sda")`
 *
 *
 * @subsubsection deldev_sec delDev
 * Removes a USB device.
 * - **Parameters**:
 *  - `type`: The device type.
 *  - `sysfs`: The sysfs ID.
 *  - `name`: The device name.
 * - **Example**: `delDev(type="disk", sysfs="4-1", name="sda")`
 *
 *
 * @subsection notes_sec Notes
 * - The usb dev system name is exposed in the  data model via the protected parameter SysDevName.
 *   Example: USB.USBHosts.Host.4.Device.1.SysDevName="/dev/sda".
 * - The USB driver modules must be loaded at target startup by the system.
 *   The following is an example of script :
 *
   @code
 #!/bin/sh

   USB_MODULES="ehci-hcd ehci-platform ehci-pci ohci-hcd ohci-platform ohci-pci xhci-hcd xhci-plat-hcd"

   case $1 in
         load)
                 local mod
                 for mod in $USB_MODULES; do
                       insmod /lib/modules/$(uname -r)/kernel/drivers/usb/host/$mod
                 done
                 ;;
        unload)
                for mod in $USB_MODULES; do
                    rmmod $mod
               done
              ;;
 *)
              echo "Usage : $0 load | unload"
              ;;
   esac
   @endcode
 *
 * @section config_sec Configuration
 *
 * The following table lists the configuration required for the USB manager:
 *
 * | Category              | Tokens                                                            | Default     |
 * |-----------------------|-------------------------------------------------------------------|-------------|
 * | `Kernel`              | CONFIG_USB_HID                                                    | `yes`       |
 * |                       | CONFIG_USB_OHCI_LITTLE_ENDIAN                                     | `yes`       |
 * |                       | CONFIG_USB_SUPPORT                                                | `yes`       |
 * |                       | CONFIG_USB_COMMON                                                 | `yes`       |
 * |                       | CONFIG_USB_ARCH_HAS_HCD                                           | `yes`       |
 * |                       | CONFIG_USB                                                        | `yes`       |
 * |                       | CONFIG_USB_PCI                                                    | `yes`       |
 * |                       | CONFIG_USB_XHCI_HCD                                               | `yes`       |
 * |                       | CONFIG_USB_XHCI_PCI                                               | `yes`       |
 * |                       | CONFIG_USB_XHCI_PLATFORM                                          | `yes`       |
 * |                       | CONFIG_USB_EHCI_HCD                                               | `yes`       |
 * |                       | CONFIG_USB_EHCI_PCI                                               | `yes`       |
 * |                       | CONFIG_USB_EHCI_HCD_PLATFORM                                      | `yes`       |
 * |                       | CONFIG_USB_OHCI_HCD                                               | `yes`       |
 * |                       | CONFIG_USB_OHCI_HCD_PCI                                           | `yes`       |
 * |                       | CONFIG_USB_OHCI_HCD_PLATFORM                                      | `yes`       |
 * |                       | CONFIG_USB_ACM                                                    | `yes`       |
 * |                       | CONFIG_USB_STORAGE                                                | `yes`       |
 * |                       | CONFIG_USB_UAS                                                    | `yes`       |
 * |                       |                                                                   |             |
 * | `tr181-usb`           | CONFIG_PACKAGE_tr181-usb                                          | `yes`       |
 * |                       | CONFIG_AMX_TR181_USB                                              | `yes`       |
 * |                       | CONFIG_AMX_TR181_USB_ORDER=81                                     | `81`        |
 * |                       | CONFIG_AMX_TR181_USB_BUSYBOX_MDEV_OPTIONS                         | `no`        |
 * |                       |                                                                   |             |
 * | `OpenWRT`             | CONFIG_BUSYBOX_CONFIG_FEATURE_MDEV_CONF                           | `no`        |
 * |                       | CONFIG_BUSYBOX_CONFIG_FEATURE_MDEV_RENAME                         | `no`        |
 * |                       | CONFIG_BUSYBOX_CONFIG_FEATURE_MDEV_RENAME_REGEXP                  | `no`        |
 * |                       | CONFIG_BUSYBOX_CONFIG_FEATURE_MDEV_EXEC                           | `no`        |
 *
 * @section test_sec Functional Tests
 *
 * - Plug USB device to the DUT.
 * - Check USB data model using ba-cli.
 *
 * @subsection dm_sec Data Model
 * - The display result will look like below:
 *
   @code
   ba-cli Device.USB.USBHosts.Host.?

   Device.USB.USBHosts.Host.4.Device.1.

   Device.USB.USBHosts.Host.4.Device.1.ConfigurationNumberOfEntries=1

   Device.USB.USBHosts.Host.4.Device.1.DeviceClass="00"

   Device.USB.USBHosts.Host.4.Device.1.DeviceNumber=4

   Device.USB.USBHosts.Host.4.Device.1.DeviceProtocol="00"

   Device.USB.USBHosts.Host.4.Device.1.DeviceSubClass="00"

   Device.USB.USBHosts.Host.4.Device.1.DeviceVersion=1

   Device.USB.USBHosts.Host.4.Device.1.IsSelfPowered=0

   Device.USB.USBHosts.Host.4.Device.1.IsSuspended=0

   Device.USB.USBHosts.Host.4.Device.1.Manufacturer="Kingston"

   Device.USB.USBHosts.Host.4.Device.1.MaxChildren=0

   Device.USB.USBHosts.Host.4.Device.1.Parent=""

   Device.USB.USBHosts.Host.4.Device.1.Port=1

   Device.USB.USBHosts.Host.4.Device.1.ProductClass="DataTraveler 3.0"

   Device.USB.USBHosts.Host.4.Device.1.ProductID=5734

   Device.USB.USBHosts.Host.4.Device.1.Rate="Super"

   Device.USB.USBHosts.Host.4.Device.1.SerialNumber="08606E6D3FDEF36107069ECA"

   Device.USB.USBHosts.Host.4.Device.1.SysDevName="/dev/sda"

   Device.USB.USBHosts.Host.4.Device.1.SysfsId="4-1"

   Device.USB.USBHosts.Host.4.Device.1.USBPort="USB.Port.1."

   Device.USB.USBHosts.Host.4.Device.1.USBVersion="3.10"

   Device.USB.USBHosts.Host.4.Device.1.VendorID=2385

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.ConfigurationNumber=1

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.InterfaceNumberOfEntries=1

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.Interface.1.

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.Interface.1.InterfaceClass="08"

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.Interface.1.InterfaceNumber=0

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.Interface.1.InterfaceProtocol="50"

   Device.USB.USBHosts.Host.4.Device.1.Configuration.1.Interface.1.InterfaceSubClass="06"
   @endcode
 *
 *
 *
 */
/**
 * @file   usb.h
 * @brief  USB manager APIs
 * @date   01/01/2025
 */
#ifndef __TR181_USB_H__
#define __TR181_USB_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bsd/string.h>
#include <ctype.h>
#include <sysfs/libsysfs.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/usbdevice_fs.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <amxm/amxm.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

// max size of the Ids
#define MAX_ID_SIZE                 64

// USB speed string in sysfs format
#define USB_SPEED_LOW_STR           "1.5\n"
#define USB_SPEED_FULL_STR          "12\n"
#define USB_SPEED_HIGH_STR          "480\n"
#define USB_SPEED_SUPER_STR         "5000\n"

// error codes
#define ERR_HOST_NOT_FOUND      1
#define ERR_HOST_ALREADY_EXISTS     2
#define ERR_DEVICE_ALREADY_EXISTS   3
#define ERR_DEVICE_NOT_FOUND        4
#define ERR_PORT_NOT_FOUND      5
#define ERR_PORT_ALREADY_EXISTS     6
#define ERR_PORT_ALREADY_CONNECTED  7
#define ERR_ID_TOO_LONG             8

// Power Management Controller
#define PWR_CTRL "PowerController"          // Name of module for power management

// Name of the module namespace that you want to use to execute the functions
#define MOD_PWR_CTRL "pwr-ctrl"

// Define the name of the module to be used when the controllers fail to load
#define DUMMY_PWR_MOD_NAME "mod-pwr-dummy"

#define HOSTPORT_VOID_ID            ""

#define INTERFACE_NUMBER_MAX        100
#define CONFIGURATION_NUMBER_MAX    100
#define SYSFS_GET_MAX_RETRIES       5
#define INTERFACE_STORAGE_CLASS     "08"
#define INTERFACE_PRINTER_CLASS     "07"

#define MOD_TABLE_SIZE              5
#define MOD_NOTIF_MAX_RETRIES       3
#define MOD_NOTIF_RETRY_INTERVAL    3

/*********************************************************************************
* Port functions
*********************************************************************************/
/**
 * @brief Find a host port identified by its filesystem id.
 *
 * @param id A unique key to identify the host port.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_host_port(const char* id);

/**
 * @brief Find a host port identified by its name.
 *
 * @param name A unique key to identify the host port.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_host_port_by_name(const char* name);

/**
 * @brief Find a host port identified by its index.
 *
 * @param uid An index to identify the host port.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_host_port_by_uid(int uid);

/**
 * @brief Find a port identified by its filesystem id.
 *
 * @param id A unique key to identify the port.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_port(const char* id);

/**
 * @brief Create a new instance in USB.Port.
 *
 * @param id A unique key to identify the port.
 * @param type The USB port type.
 * @param error A returned error code.
 * @param standard The USB port standard.
 * @param rate The USB port rate.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* port_create_object(const char* id, const char* type, int* error, const char* standard, const char* rate);

/**
 * @brief Delete an instance in USB.Port.
 *
 * @param port Object to be deleted.
 * @return True on success, false on failure.
 */
int port_delete_object(amxd_object_t* port);

/**
 * @brief Create a new hub instance in USB.Port.
 *
 * @param id A unique key to identify the hub port.
 * @param type The USB hub port type.
 * @param error A returned error code.
 * @param standard The USB hub port standard.
 * @param rate The USB hub port rate.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* hubport_create_object(const char* id, int* error, const char* standard, const char* rate);

/**
 * @brief Delete a hub instance in USB.Port.
 *
 * @param port Object to be deleted.
 * @return True on success, false on failure.
 */
int hubport_delete_object(amxd_object_t* port);

/*********************************************************************************
* Host functions
*********************************************************************************/
/**
 * @brief Find a device using the given filesystem id.
 *
 * @param id A unique key to identify the device.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_device(const char* id);

/**
 * @brief Find a host using the given filesystem id.
 *
 * @param id A unique key to identify the host.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* find_host(const char* id);

/**
 * @brief Reset a host using the given filesystem id.
 *
 * @param host A pointer to the host object.
 * @return 0 on success, -1 on failure.
 */
int reset_host(amxd_object_t* host);

/**
 * @brief Add a device to the host.
 *
 * @param host_id A unique key to identify the host.
 * @param device_name The name of the device.
 * @param device_id A unique key to identify the device.
 * @param connected_port_id The id of the port to which the device is connected.
 * @return True on success, false on failure.
 */
int host_add_device(const char* host_id, const char* device_name, const char* device_id, const char* connected_port_id);

/**
 * @brief Delete a device from the host.
 *
 * @param device_id A unique key to identify the device.
 * @param check_is_authorized When true, only remove device when it is authorized.
 * @return True on success, false on failure.
 */
int host_del_device(const char* device_id, bool check_is_authorized);

/**
 * @brief Create a new hub instance in USB.USBHosts.Host.*.Device.
 *
 * @param host Object on which the device will be created.
 * @param connected_port Port to which the hub is connected.
 * @param name The name of the hub.
 * @param id A unique key to identify the hub.
 * @param error A returned error code.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* create_hub_object(amxd_object_t* host, amxd_object_t* connected_port, const char* name, const char* id, int* error);

/**
 * @brief Create a new instance in USB.USBHosts.Host.
 *
 * @param bus_num The system bus name.
 * @param usb_version The system USB version.
 * @param usb_type The system bus type.
 */
void add_host(const char* bus_num, const char* usb_version, const char* usb_type);

/*********************************************************************************
* Device functions
*********************************************************************************/
/**
 * @brief Create a new instance in USB.USBHosts.Host.*.Device.
 *
 * @param host Object on which the device will be created.
 * @param connected_port Port to which the device is connected.
 * @param name The name of the device.
 * @param id A unique key to identify the device.
 * @param error A returned error code.
 * @return A pointer to the created object on success, null on failure.
 */
amxd_object_t* device_create_object(amxd_object_t* host, amxd_object_t* connected_port, const char* name, const char* id, int* error);

/**
 * @brief Delete an instance in USB.USBHosts.Host.*.Device.
 *
 * @param host Object from which the device will be deleted.
 * @param device Object to be deleted.
 * @return True on success, false on failure.
 */
int device_delete_object(amxd_object_t* host, amxd_object_t* device);

/**
 * @brief Fill the transaction with its system information.
 *
 * @param trans Transaction pointer.
 * @param sysfs_id The filesystem device id.
 * @param connected_port Port to which the device is connected.
 * @param error A returned error code.
 * @return True on success, false on failure.
 */
int device_set_info(amxd_trans_t* trans, const char* sysfs_id, amxd_object_t* connected_port, int* error);

/**
 * @brief Retrieve the device system information and fill the global parameters using this information.
 *
 * @param sysfs_id The filesystem device id.
 * @param error A returned error code.
 * @return True on success, false on failure.
 */
int device_get_sysfs_info(const char* sysfs_id, int* error);

/*********************************************************************************
* Configuration functions
*********************************************************************************/
/**
 * @brief Create a new instance in USB.USBHosts.Host.*.Device.*.Configuration.
 *
 * @param trans Transaction used to create the configuration.
 * @param sysfs_id The filesystem device id.
 * @param id A unique key to identify the configuration.
 * @param nb_interfaces Number of interfaces in the configuration.
 * @return A pointer to the created object on success, null on failure.
 */
int configuration_create_object(amxd_trans_t* trans, const char* sys_fs_id, const char* id, int nb_interfaces);

/**
 * @brief Create a new instance in USB.USBHosts.Host.*.Device.*.Configuration.*.Interface.
 *
 * @param trans Transaction used to create the interface.
 * @param id A unique key to identify the interface.
 * @return A pointer to the created object on success, null on failure.
 */
int interface_create_object(amxd_trans_t* trans, const char* id);

/**
 * @brief Set the interface id.
 *
 * @param trans Transaction used to update the interface.
 * @param id Id to be set.
 * @return True on success, false on failure.
 */
int interface_set_info(amxd_trans_t* trans, const char* id);

/*********************************************************************************
* Controller & RPCs functions
*********************************************************************************/
/**
 * @brief Trim a string and return the trimmed string.
 *
 * @param str String to be trimmed.
 * @return Trimmed string.
 */
char* trim_str(char* str);

/**
 * @brief Return the error message related to the given error code.
 *
 * @param error Error code.
 * @return Error message.
 */
const char* get_error_message(int error);

/**
 * @brief RPC to Add USB device called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 */
void add_device(const char* device_name);

/**
 * @brief RPC to Delete USB device called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param check_is_authorized When true, only remove device when it is authorized.
 */
void delete_device(const char* device_name, bool check_is_authorized);

/**
 * @brief RPC to Add USB disk (storage device) called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void add_disk(const char* device_name, const char* sysfs_id);

/**
 * @brief RPC to Delete USB disk (storage device) called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void delete_disk(const char* device_name, const char* sysfs_id);

/**
 * @brief RPC to Add USB printer called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void add_printer(const char* device_name, const char* sysfs_id);

/**
 * @brief RPC to Delete USB printer called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void delete_printer(const char* device_name, const char* sysfs_id);

/**
 * @brief RPC to Add USB tty device called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void add_tty(const char* device_name, const char* sysfs_id);

/**
 * @brief RPC to Delete USB tty device called from event2usb binary on system event.
 *
 * @param device_name System name of the USB device.
 * @param sysfs_id Filesystem id of the USB device.
 */
void delete_tty(const char* device_name, const char* sysfs_id);

/**
 * @brief The main function of storage plugin.
 *
 * @param reason Reason for the function call.
 * @param dm Data model pointer.
 * @param parser Parser pointer.
 * @return Status of the operation.
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
 * @brief Get data model pointer of storage.
 *
 * @return Data model pointer.
 */
amxd_dm_t* get_dm(void);

/**
 * @brief Handler for the app:start signal.
 *
 * Initializes TR-181 USB saved objects and power management procedure in the data model.
 * Runs after the entry point so that saved DM objects, which do not emit
 * events, are properly initialized.
 *
 * @param sig_name Name of the received signal.
 * @param data Optional signal payload.
 * @param priv User-provided context pointer.
 */
void _app_start(const char* const sig_name,
                const amxc_var_t* const data,
                void* const priv);

#ifdef __cplusplus
}
#endif

#endif // __TR181_USB_H__
