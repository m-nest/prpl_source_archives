/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "pools.h"
#include "pool_info.h"
#include "firewall_utility.h"

#include <amxm/amxm.h>
#include <amxb/amxb_operators.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>

#define ME "pools"

/**
 * @brief
 * Removes all inactive TR181 DHCPv4.Server.Pool.{i}.Client.{i}.IPv4Address instances.
 *
 * @return 0 on success
 */
int pools_delete_expired_leases(void) {
    amxc_ts_t now;
    amxc_llist_t paths;
    amxd_object_t* pools = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.");
    int r = -1;

    when_null_trace(pools, exit, ERROR, "DHCPv4.Server.Pool data model object not found");

    amxc_ts_now(&now);

    amxc_llist_init(&paths);

    r = amxd_object_resolve_pathf(pools, &paths, ".*.Client.*.IPv4Address.*");
    when_failed_trace(r, clean, ERROR, "Problem getting clients from data model");

    r = -1;
    amxc_llist_for_each(it, (&paths)) {
        amxd_object_t* obj = NULL;
        amxc_ts_t* expires = NULL;
        const char* path = amxc_string_get(amxc_string_from_llist_it(it), 0);
        when_null_trace(path, clean, ERROR, "Problem getting client path from data model");

        obj = amxd_dm_findf(dhcp_get_dm(), "%s", path);
        when_null_trace(obj, clean, ERROR, "Client data model object not found");

        expires = amxd_object_get_value(amxc_ts_t, obj, "LeaseTimeRemaining", NULL);
        if(expires == NULL) {
            SAH_TRACEZ_ERROR(ME, "LeaseTimeRemaining not found in TR-181 data model");
        } else {
            if(amxc_ts_compare(&now, expires) > 0) {
                SAH_TRACEZ_INFO(ME, "Deleting expired DHCP lease '%s'...", path);
                amxd_object_emit_del_inst(obj);
                amxd_object_delete(&obj);
            }
            free(expires);
        }
    }
    r = 0;
clean:
    amxc_llist_clean(&paths, amxc_string_list_it_free);
exit:
    return r;
}

/** @brief
 * Get the maximum number of valid addresses in a pool based on its
 * configuration
 *
 * @param pool The pool to check
 * @return A uint32_t with the number of the valid addresses
 */
static uint32_t pools_get_valid_addresses(amxd_object_t* pool) {
    struct in_addr max_addr;
    struct in_addr min_addr;
    struct in_addr sub_addr;
    cstring_t min_addr_str = NULL;
    cstring_t max_addr_str = NULL;
    cstring_t subnet_addr_str = NULL;
    uint32_t ret = 0;
    uint32_t min = 0;
    uint32_t max = 0;
    uint32_t sub = 0;

    when_null(pool, exit);
    min_addr_str = amxd_object_get_value(cstring_t, pool, "MinAddress", NULL);
    max_addr_str = amxd_object_get_value(cstring_t, pool, "MaxAddress", NULL);
    subnet_addr_str = amxd_object_get_value(cstring_t, pool, "SubnetMask", NULL);

    when_false_trace(subnet_addr_str != NULL || (min_addr_str != NULL && max_addr_str != NULL),
                     exit, ERROR, "No sufficient material to continue");

    if((min_addr_str != NULL) && (inet_pton(AF_INET, min_addr_str, &min_addr) == 1)) {
        min = ntohl(min_addr.s_addr);
    }
    if((max_addr_str != NULL) && (inet_pton(AF_INET, max_addr_str, &max_addr) == 1)) {
        max = ntohl(max_addr.s_addr);
    }
    if((subnet_addr_str != NULL) && (inet_pton(AF_INET, subnet_addr_str, &sub_addr) == 1)) {
        sub = ntohl(sub_addr.s_addr);
    }

    if(sub > 0) {
        min = (min > 0) ? (~sub & min) : 2;          // Do not count the first if !min
        max = (max > 0) ? ((~sub & max) + 1) : ~sub; // Do not count the broadcast if !max
    }
    ret = max - min;
    if(max <= min) {
        SAH_TRACEZ_ERROR(ME, "pool is probably missconfigured");
        ret = 0;
    }

exit:
    free(min_addr_str);
    free(max_addr_str);
    free(subnet_addr_str);

    return ret;
}

/**
 * @brief
 * Find a client using the client id. If that fails use mac address instead
 *
 * @param pool The pool in which we're searching
 * @param hwaddr The mac address to use for the search
 * @param clientid The client id to use for the search
 */
static amxd_object_t* pools_get_client_from_id(amxd_object_t* pool,
                                               const cstring_t hwaddr,
                                               const cstring_t clientid) {
    amxd_object_t* ret = NULL;
    amxc_llist_t paths;
    amxc_string_t mac_up;
    amxc_string_t mac_low;
    int r = -1;

    amxc_llist_init(&paths);
    amxc_string_init(&mac_up, 0);
    amxc_string_init(&mac_low, 0);
    amxc_string_set(&mac_up, hwaddr);
    amxc_string_set(&mac_low, hwaddr);
    amxc_string_to_upper(&mac_up);
    amxc_string_to_lower(&mac_low);

    r = amxd_object_resolve_pathf(pool, &paths, ".Client.[Chaddr == '%s' || Chaddr == '%s']",
                                  amxc_string_get(&mac_up, 0), amxc_string_get(&mac_low, 0));
    when_failed(r, exit);
    amxc_llist_for_each(it, &paths) {
        amxd_object_t* tmp_client = NULL;
        amxd_object_t* option_dm = NULL;
        const char* path = amxc_string_get(amxc_string_from_llist_it(it), 0);
        tmp_client = amxd_dm_findf(dhcp_get_dm(), "%s", path);
        if(!str_empty(clientid)) {
            option_dm = amxd_object_findf(tmp_client, ".Option.[Tag == 61 && Value == '%s']", clientid);
            if(option_dm) {
                ret = tmp_client;
            }
        } else {
            /* Make sure, if the client has a clientid it is empty */
            option_dm = amxd_object_findf(tmp_client, ".Option.[Tag == 61 && Value != '']");
            if(!option_dm) {
                ret = tmp_client;
            }
        }
        if(ret != NULL) {
            break;
        }
    }
exit:
    amxc_llist_clean(&paths, amxc_string_list_it_free);
    amxc_string_clean(&mac_up);
    amxc_string_clean(&mac_low);

    return ret;
}

/**
 * @brief
 * Find a client's associated binding by matching the clientid and the chaddr
 *
 * @param client The client that has the associated binding
 */
static amxd_object_t* pools_get_binding_from_client(amxd_object_t* client) {
    amxd_object_t* pool = NULL;
    amxd_object_t* option_dm = NULL;
    amxd_object_t* ret = NULL;
    cstring_t hwaddr = NULL;
    cstring_t clientid = NULL;
    amxc_string_t mac_up;
    amxc_string_t mac_low;
    amxc_string_init(&mac_up, 0);
    amxc_string_init(&mac_low, 0);

    when_null(client, exit);
    pool = amxd_object_get_parent(amxd_object_get_parent(client));
    hwaddr = amxd_object_get_value(cstring_t, client, "Chaddr", NULL);
    amxc_string_set(&mac_up, hwaddr);
    amxc_string_set(&mac_low, hwaddr);
    amxc_string_to_upper(&mac_up);
    amxc_string_to_lower(&mac_low);

    option_dm = amxd_object_findf(client, ".Option.[Tag == 61].");
    if(option_dm != NULL) {
        clientid = amxd_object_get_value(cstring_t, option_dm, "Value", NULL);
    }

    ret = amxd_object_findf(pool, ".AssignedLeases.[(Chaddr == '%s' || Chaddr == '%s') && ClientID =='%s'].",
                            amxc_string_get(&mac_up, 0), amxc_string_get(&mac_low, 0),
                            clientid ? clientid : "");

exit:
    amxc_string_clean(&mac_up);
    amxc_string_clean(&mac_low);
    free(hwaddr);
    free(clientid);
    return ret;
}

/**
 * @brief
 * Based on a binding's clientid and chaddr find the associated client
 *
 * @param binding The binding
 */
static amxd_object_t* pools_get_client_from_binding(amxd_object_t* binding) {
    amxd_object_t* pool = NULL;
    amxd_object_t* ret = NULL;
    cstring_t hwaddr = NULL;
    cstring_t clientid = NULL;

    when_null(binding, exit);
    pool = amxd_object_get_parent(amxd_object_get_parent(binding));
    hwaddr = amxd_object_get_value(cstring_t, binding, "Chaddr", NULL);
    clientid = amxd_object_get_value(cstring_t, binding, "ClientID", NULL);
    ret = pools_get_client_from_id(pool, hwaddr, clientid);
exit:
    free(hwaddr);
    free(clientid);

    return ret;
}

/**
 * @brief
 * Remove AssignedLeases
 *
 * @param pool The pool on which this func operates
 * @return Number of bindings that were removed
 */
uint32_t pools_remove_bindings(amxd_object_t* pool) {
    uint32_t ret = 0;
    uint32_t cnt = 0;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    when_null(pool, exit);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, pool);
    amxd_trans_select_pathf(&trans, ".AssignedLeases.");

    amxd_object_for_each(instance, it, amxd_object_findf(pool, ".AssignedLeases.")) {
        amxd_object_t* binding = amxc_container_of(it, amxd_object_t, it);
        amxd_trans_del_inst(&trans, amxd_object_get_index(binding), NULL);
        cnt += 1;
    }

    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR,
                      "Cannot remove bindings");
    ret = cnt;

exit:
    amxd_trans_clean(&trans);
    return ret;
}

/**
 * @brief
 * Removed AssignedLeases with certain hw/ip address
 *
 * @param pool The pool on which this func operates
 * @param hwaddr The mac address that will be used to match against.
 * @param ipaddr The ip address that will be used to match against.
 * @return Number of bindings that were removed
 */
uint32_t pools_remove_binding(amxd_object_t* pool, const cstring_t hwaddr,
                              const cstring_t ipaddr) {
    amxc_string_t mac_up;
    amxc_string_t mac_low;
    amxc_llist_t paths;
    amxd_trans_t trans;
    uint32_t ret = 0;
    uint32_t tmp = 0;
    int rv = -1;

    amxc_string_init(&mac_up, 0);
    amxc_string_init(&mac_low, 0);
    amxc_llist_init(&paths);
    amxd_trans_init(&trans);
    when_null(pool, exit);
    when_true((str_empty(hwaddr) && str_empty(ipaddr)), exit);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, amxd_object_findf(pool, "AssignedLeases."));

    amxc_string_set(&mac_up, hwaddr);
    amxc_string_set(&mac_low, hwaddr);
    amxc_string_to_upper(&mac_up);
    amxc_string_to_lower(&mac_low);
    rv = amxd_object_resolve_pathf(pool, &paths, ".AssignedLeases.[Chaddr == '%s' || Chaddr == '%s' || IPAddress == '%s']",
                                   amxc_string_get(&mac_up, 0), amxc_string_get(&mac_low, 0),
                                   ipaddr);
    when_failed(rv, exit);
    amxc_llist_for_each(it, &paths) {
        const char* path = amxc_string_get(amxc_string_from_llist_it(it), 0);
        amxd_object_t* binding = amxd_dm_findf(dhcp_get_dm(), "%s", path);
        if(binding != NULL) {
            amxd_trans_del_inst(&trans, amxd_object_get_index(binding), NULL);
            tmp += 1;
        }

    }
    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR,
                      "Failed to remove leases with address %s", hwaddr);
    if(tmp > 0) {
        pools_set_previous_bindings(amxd_object_get_parent(pool));
    }
    ret = tmp;

exit:
    amxd_trans_clean(&trans);
    amxc_llist_clean(&paths, amxc_string_list_it_free);
    amxc_string_clean(&mac_up);
    amxc_string_clean(&mac_low);

    return ret;
}

/**
 * @brief
 * Sets the active parameter of a DHCP server pool client in the TR-181 data model.
 *
 * @param path DHCP server pool client TR-181 path
 * @param active True if the DHCP server pool client is active
 * @return 0 on success
 */
int pools_set_client_active(const char* path, bool active) {
    amxd_object_t* pool = NULL;
    amxd_object_t* object = NULL;
    amxd_object_t* binding = NULL;
    amxd_trans_t trans;
    bool force_update = false;
    int r = -1;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(path, exit, ERROR, "Invalid path argument");
    object = amxd_dm_findf(dhcp_get_dm(), "%s", path);
    when_null_trace(object, exit, ERROR, "Client data model object not found");
    binding = pools_get_binding_from_client(object);

    amxd_trans_select_object(&trans, object);
    amxd_trans_set_value(bool, &trans, "Active", active);
    if(binding != NULL) {
        pool = amxd_object_get_parent(amxd_object_get_parent(object));
        uint32_t assigned_no = amxd_object_get_value(uint32_t, pool, "AssignedLeasesNumberOfEntries", NULL);
        uint32_t static_no = amxd_object_get_value(uint32_t, pool, "StaticAddressNumberOfEntries", NULL);
        if((!active) && ((assigned_no + static_no) >= pools_get_valid_addresses(pool))) {
            /* Pool is full. Remove this binding to make some room */
            amxd_trans_select_object(&trans, amxd_object_findf(pool, "AssignedLeases."));
            amxd_trans_del_inst(&trans, amxd_object_get_index(binding), NULL);
            force_update = true;
        } else {
            amxc_ts_t now;
            amxc_ts_now(&now);
            amxd_trans_select_object(&trans, binding);
            amxd_trans_set_value(amxc_ts_t, &trans, "LastSeen", &now);
        }
    }
    r = amxd_trans_apply(&trans, dhcp_get_dm());
    when_failed_trace(r, exit, ERROR, "Problem applying data model transaction");
    if(force_update) {
        pools_set_previous_bindings(amxd_object_get_parent(pool));
    }

exit:
    amxd_trans_clean(&trans);
    return r;
}

/**
 * @brief
 * Removes all inactive TR181 DHCPv4.Server.Pool.{i}.Client instances.
 *
 * @return 0 on success
 */
int pools_delete_inactive_clients(void) {
    amxd_object_t* pools = NULL;
    amxc_llist_t paths;
    int r = -1;
    pools = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.");
    when_null_trace(pools, exit, ERROR, "DHCPv4.Server.Pool data model object not found");
    amxc_llist_init(&paths);
    r = amxd_object_resolve_pathf(pools, &paths, ".*.Client.[Active==false]");
    when_failed_trace(r, clean, ERROR, "Problem getting inactive client paths from data model");
    r = -1;
    amxc_llist_for_each(it, (&paths)) {
        amxd_object_t* obj = NULL;
        const char* path = amxc_string_get(amxc_string_from_llist_it(it), 0);
        when_null_trace(path, clean, ERROR, "Problem getting client path from data model");
        obj = amxd_dm_findf(dhcp_get_dm(), "%s", path);
        when_null_trace(obj, exit, ERROR, "Client data model object not found");
        SAH_TRACEZ_INFO(ME, "Deleting inactive DHCP client %s", path);
        amxd_object_emit_del_inst(obj);
        amxd_object_delete(&obj);
    }
    r = 0;
clean:
    amxc_llist_clean(&paths, amxc_string_list_it_free);
exit:
    return r;
}

/**
 * @brief
 * Disables all static addresses of a pool.
 */
void pools_disable_all_pool_static_addresses(amxd_object_t* pool) {
    amxd_object_t* static_ips = amxd_object_findf(pool, "StaticAddress.");
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(static_ips, exit, ERROR, "StaticAddress data model object not found");
    amxd_object_for_each(instance, it, static_ips) {
        amxd_object_t* obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxd_trans_select_object(&trans, obj);
        amxd_trans_set_value(bool, &trans, "Enable", false);
    }
    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot change Enable of static address");
exit:
    amxd_trans_clean(&trans);
    return;
}

/**
 * @brief
 * Fill the variant data for a static address to be pass to the controller.
 *
 * @param pool the pool object that the static ip address is associate to.
 * @param addr the static ip address object to be pass to the controller.
 * @param data the data variant to be fill in.
 */
static void create_controller_addr_data(amxd_object_t* pool, amxd_object_t* addr, amxc_var_t* data) {
    amxc_var_t* tmp_var = NULL;

    when_null_trace(pool, exit, ERROR, "No pool for static ip");
    when_null_trace(addr, exit, ERROR, "No static ip given");
    when_null_trace(data, exit, ERROR, "No data to fill given");

    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);

    tmp_var = amxc_var_add_key(amxc_htable_t, data, "pool", NULL);
    amxd_object_get_params(pool, tmp_var, amxd_dm_access_protected);
    tmp_var = amxc_var_add_key(amxc_htable_t, data, "addr", NULL);
    amxd_object_get_params(addr, tmp_var, amxd_dm_access_protected);
exit:
    return;
}

/**
 * @brief
 * Fill the variant data for a pool to be pass to the controller.
 *
 * @param info the private pool info.
 * @param data the data to be filled in.
 */
static void create_controller_pool_data(pool_info_t* info, amxc_var_t* data) {
    amxc_var_t var_tag;
    amxc_var_t* tmp_var = NULL;
    char* allow = NULL;

    amxc_var_init(&var_tag);

    when_null_trace(info, exit, ERROR, "No private data for pool found.");
    when_null_trace(info->obj, exit, ERROR, "No pool object found.");
    when_null_trace(data, exit, ERROR, "No data to fill initialised.");

    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);

    allow = amxd_object_get_value(cstring_t, info->obj, "AllowedDevices", NULL);
    when_str_empty_trace(allow, exit, ERROR, "No allow devices criterion");

    amxd_object_get_params(info->obj, data, amxd_dm_access_protected);
    amxc_var_set(cstring_t, &var_tag, info->intf_alias);
    amxc_var_set_key(data, "IntfName", &var_tag, AMXC_VAR_FLAG_COPY);

    tmp_var = amxc_var_add_key(amxc_llist_t, data, "Option", NULL);

    amxd_object_for_each(instance, it, amxd_object_findf(info->obj, ".Option.")) {
        amxd_object_t* option = amxc_container_of(it, amxd_object_t, it);
        amxc_var_t* option_list = NULL;
        amxc_string_t force_param;
        amxo_parser_t* parser = dhcp_get_parser();
        bool force = 0;

        amxc_string_init(&force_param, 0);
        option_list = amxc_var_add(amxc_htable_t, tmp_var, NULL);

        amxd_object_get_params(option, option_list, amxd_dm_access_public);
        amxc_string_setf(&force_param, "%sForce", GET_CHAR(&parser->config, "global_vendor_prefix_"));
        force = amxd_object_get_value(bool, option, amxc_string_get(&force_param, 0), NULL);
        amxc_var_add_key(bool, option_list, "Force", force);

        amxc_string_clean(&force_param);
    }

    if(strcmp(allow, "All") != 0) {
        tmp_var = amxc_var_add_key(amxc_htable_t, data, "MACs", NULL);
        amxd_object_for_each(instance, it, amxd_object_findf(info->obj, ".Client.")) {
            amxd_object_t* client = amxc_container_of(it, amxd_object_t, it);
            char* mac = amxd_object_get_value(cstring_t, client, "Chaddr", NULL);

            if(!str_empty(mac)) {
                amxc_var_add_key(bool, tmp_var, mac, 1);
            }
            free(mac);
        }
        amxd_object_for_each(instance, it, amxd_object_findf(info->obj, ".StaticAddress.")) {
            amxd_object_t* addr = amxc_container_of(it, amxd_object_t, it);
            char* mac = amxd_object_get_value(cstring_t, addr, "Chaddr", NULL);

            if((!str_empty(mac)) && (!GET_BOOL(tmp_var, mac))) {
                amxc_var_add_key(bool, tmp_var, mac, 1);
            }
            free(mac);
        }
    }
exit:
    free(allow);
    amxc_var_clean(&var_tag);
    return;
}

/**
 * @brief
 * Fill the variant data for a binding to be passed to the controller.
 *
 * @param pools The pool multi-instance object.
 * @param data the data variant to be fill in.
 */
static amxd_status_t create_controller_binding_data(amxd_object_t* pools, amxc_var_t* data) {
    amxd_status_t rv = amxd_status_unknown_error;

    when_null_trace(pools, exit, WARNING, "Pool object does not exist");
    amxd_object_iterate(instance, pit, pools) {
        amxd_object_t* pool = amxc_container_of(pit, amxd_object_t, it);
        amxd_object_t* leases = amxd_object_findf(pool, ".AssignedLeases.");
        amxc_var_t* pool_ht = amxc_var_add(amxc_htable_t, data, NULL);
        amxc_var_t* leases_ll = NULL;

        amxd_object_get_params(pool, pool_ht, amxd_dm_access_protected);
        leases_ll = amxc_var_add_key(amxc_llist_t, pool_ht, "AssignedLeases", NULL);
        when_null_trace(leases_ll, exit, ERROR, "Unable to create list");

        amxd_object_iterate(instance, lit, leases) {
            amxd_object_t* lease = amxc_container_of(lit, amxd_object_t, it);
            amxc_var_t* tmp = amxc_var_add(amxc_htable_t, leases_ll, NULL);
            amxd_object_get_params(lease, tmp, amxd_dm_access_protected);
        }
    }
    rv = amxd_status_ok;

exit:
    return rv;
}

/**
 * @brief
 * Sets the TR-181 DHCPv4.Server.Pool.{i}.Status parameter value and configure the server on the system.
 *
 * @param pool DHCPv4.Server.Pool instance object
 */
int pools_update_pool_status(amxd_object_t* pool) {
    int status = 1;
    pool_info_t* info = NULL;
    amxd_trans_t trans;
    amxc_var_t ret;
    amxc_var_t data;
    char* controller = NULL;
    amxd_object_t* server_obj = NULL;
    bool server_enabled = false;

    amxc_var_init(&ret);
    amxc_var_init(&data);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(pool, exit, ERROR, "Invalid pool argument");
    when_null_trace(pool->priv, exit, ERROR, "Cannot get private data from pool object");
    info = (pool_info_t*) pool->priv;

    server_obj = amxd_object_get_parent(amxd_object_get_parent(info->obj));
    when_null_trace(server_obj, exit, ERROR, "No server object found");

    server_enabled = amxd_object_get_value(bool, server_obj, "Enable", NULL);
    if(!server_enabled) {
        if(info->flags.bit.fw_up) {
            firewall_close_dhcp_port(info);
            info->flags.bit.fw_up = 0;
        }
        bool was_active = info->flags.bit.config_ok || info->flags.bit.fw_up;
        if(was_active && info->flags.bit.intf_alias) {
            controller = amxd_object_get_value(cstring_t, server_obj, "Controller", NULL);
            if(controller) {
                create_controller_pool_data(info, &data);
                SAH_TRACE_INFO("Calling disable-dhcp-pool (server disabled).");
                amxm_execute_function(controller,
                                      controller,
                                      "disable-dhcp-pool",
                                      &data,
                                      &ret);
            }
            info->flags.bit.config_ok = 0;
        }

        amxd_trans_select_object(&trans, pool);
        amxd_trans_set_value(cstring_t, &trans, "Status", "Disabled");
        when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR,
                          "Cannot sync DHCPv4Server.Pool object.");
        goto exit;
    }

    if((info->flags.bit.fw_up) && !(info->flags.bit.enable)) {
        firewall_close_dhcp_port(info);
        info->flags.bit.fw_up = 0;
    }

    if(!(info->flags.bit.fw_up) && (info->flags.bit.enable)) {
        firewall_open_dhcp_port(info);
        info->flags.bit.fw_up = 1;
    }

    controller = amxd_object_get_value(cstring_t, server_obj, "Controller", NULL);
    when_null_trace(controller, exit, ERROR, "Cannot get controller from pool.");

    if(info->flags.bit.intf_alias) {
        create_controller_pool_data(info, &data);
        SAH_TRACE_INFO("Calling %s function.", info->flags.bit.enable ? "enable-dhcp-pool" : "disable-dhcp-pool");
        status = amxm_execute_function(controller,
                                       controller,
                                       info->flags.bit.enable ? "enable-dhcp-pool" : "disable-dhcp-pool",
                                       &data,
                                       &ret);
        info->flags.bit.config_ok = status == amxd_status_ok;
    }

    amxd_trans_select_object(&trans, pool);
    if(!info->flags.bit.enable) {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Disabled");
    } else if(info->flags.bit.addr_ok &&
              info->flags.bit.intf_ok &&
              info->flags.bit.intf_alias &&
              info->flags.bit.enable &&
              info->flags.bit.config_ok &&
              info->flags.bit.fw_up) {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Enabled");
    } else {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Error_Misconfigured");
    }

    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot sync DHCPv4Server.Pool object.");
exit:
    free(controller);
    amxd_trans_clean(&trans);
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return 0;
}

/**
 * @brief
 * Update a lease in the tr181 data model.
 *
 * @param client the client object to add the lease to.
 * @param lease the variant that contain all information about the lease and the client.
 * @param default_lease_time the default lease time to use if no lease time is given by the lease data.
 */
static void update_client_lease(amxd_object_t* client, amxc_var_t* lease, UNUSED int default_lease_time) {
    amxd_trans_t trans;
    amxc_ts_t expires;
    amxc_ts_t* tmp = NULL;
    amxc_var_t* time = NULL;
    amxc_ts_t now;
    amxd_object_t* lease_obj = NULL;
    const char* ipv4_addr = NULL;

    amxc_ts_now(&now);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_attr(&trans, amxd_tattr_change_prot, true);

    // for now we only want 1 IPv4 address by client, other address will be keep in back-end cache but not showed
    // there should never be an other index than 1
    lease_obj = amxd_object_findf(client, ".IPv4Address.1.");
    if(lease_obj != NULL) {
        amxd_trans_select_object(&trans, lease_obj);
    } else {
        amxd_trans_select_object(&trans, client);
        amxd_trans_select_pathf(&trans, ".IPv4Address.");
        amxd_trans_add_inst(&trans, 1, NULL);
    }

    amxd_trans_set_value(amxc_ts_t, &trans, "LastUpdate", &now);

    time = GET_ARG(lease, "LeaseTimeRemaining");
    if((time == NULL) || ((tmp = amxc_var_dyncast(amxc_ts_t, time)) == NULL)) {
        expires = (amxc_ts_t) {.sec = now.sec + default_lease_time};
        amxd_trans_set_value(amxc_ts_t, &trans, "LeaseTimeRemaining", &expires);
    } else {
        amxd_trans_set_value(amxc_ts_t, &trans, "LeaseTimeRemaining", tmp);
        free(tmp);
    }

    ipv4_addr = GET_CHAR(lease, "IPv4Address");
    when_null_trace(ipv4_addr, exit, ERROR, "No ipv4 given from the lease, not updating the client");

    amxd_trans_set_value(cstring_t, &trans, "IPAddress", ipv4_addr);
    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot update lease");
exit:
    amxd_trans_clean(&trans);
    return;
}

/** @brief
 * Find the oldest inactive binding
 *
 * @param pool The pool to check
 * @return The oldest inactive binding that is to be removed, or NULL
 */
static amxd_object_t* pools_get_inactive_binding(amxd_object_t* pool) {
    amxd_object_t* ret = NULL;
    amxc_ts_t* expires = NULL;
    amxc_llist_t paths;
    int r = -1;

    amxc_llist_init(&paths);
    when_null(pool, exit);
    r = amxd_object_resolve_pathf(pool, &paths, ".AssignedLeases.*");
    when_failed_trace(r, exit, INFO, "Couldn't find an inactive binding");
    amxc_llist_for_each(it, &paths) {
        const char* path = amxc_string_get(amxc_string_from_llist_it(it), 0);
        amxd_object_t* tmp_binding = NULL;
        amxd_object_t* tmp_client = NULL;

        tmp_binding = amxd_dm_findf(dhcp_get_dm(), "%s", path);
        tmp_client = pools_get_client_from_binding(tmp_binding);
        /* No client or inactive client makes the binding a candidate */
        if((tmp_client == NULL) || (amxd_object_get_value(bool, tmp_client, "Active", NULL) == false)) {
            amxc_ts_t* tmp_expires = amxd_object_get_value(amxc_ts_t, tmp_binding, "LastSeen", NULL);
            if((expires == NULL) || (amxc_ts_compare(tmp_expires, expires) < 0)) {
                free(expires);
                ret = tmp_binding;
                expires = tmp_expires;
            } else {
                free(tmp_expires);
            }
        }
    }
exit:
    free(expires);
    amxc_llist_clean(&paths, amxc_string_list_it_free);

    return ret;
}

/**
 * @brief
 * Add a binding in the DM. Also apply it to the backend module
 *
 * @param pool The pool that the binding is associated with.
 * @param client The client that the binding is associated with.
 * @param lease Variant that holds the binding information.
 */
static void update_client_binding(amxd_object_t* pool, amxd_object_t* client,
                                  amxc_var_t* lease) {
    amxd_object_t* binding = NULL;
    amxd_object_t* static_lease = NULL;
    amxc_string_t mac_up;
    amxc_string_t mac_low;
    amxd_object_t* option_dm = NULL;
    amxd_object_t* server_dm = NULL;
    const char* ipaddr = GET_CHAR(lease, "IPv4Address");
    char* hwaddr = NULL;
    char* clientid = NULL;
    char* controller = NULL;
    char* tag = NULL;
    char* alias = NULL;
    int status = 1;
    bool force_binding_rewrite = false;
    amxd_trans_t trans;
    amxc_var_t data;
    amxc_var_t ret;
    amxc_ts_t now;
    uint32_t assigned_no = 0;
    uint32_t static_no = 0;

    amxc_string_init(&mac_up, 0);
    amxc_string_init(&mac_low, 0);
    amxd_trans_init(&trans);
    amxc_var_init(&data);
    amxc_var_init(&ret);

    binding = pools_get_binding_from_client(client);
    when_not_null(binding, exit);

    hwaddr = amxd_object_get_value(cstring_t, client, "Chaddr", NULL);
    when_true_trace(str_empty(hwaddr), exit, ERROR, "Mac address cannot be emtpy");
    /* If there is an associated static lease the binding is not needed */
    amxc_string_set(&mac_up, hwaddr);
    amxc_string_set(&mac_low, hwaddr);
    amxc_string_to_upper(&mac_up);
    amxc_string_to_lower(&mac_low);
    static_lease = amxd_object_findf(pool, ".StaticAddress.[(Chaddr == '%s' || Chaddr == '%s') && Enable == true].",
                                     amxc_string_get(&mac_up, 0), amxc_string_get(&mac_low, 0));
    when_not_null(static_lease, exit);

    /* Adding a new binding. If the pool is full we need to make room for
     * another lease in the future */
    assigned_no = amxd_object_get_value(uint32_t, pool, "AssignedLeasesNumberOfEntries", NULL);
    static_no = amxd_object_get_value(uint32_t, pool, "StaticAddressNumberOfEntries", NULL);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, amxd_object_findf(pool, "AssignedLeases."));
    if((assigned_no + static_no + 1) >= pools_get_valid_addresses(pool)) {
        /* The pool is already full and we need to remove a binding asap (if not
         * now, when the next client becomes inactive */
        binding = pools_get_inactive_binding(pool);
        if(binding != NULL) {
            amxd_trans_del_inst(&trans, amxd_object_get_index(binding), NULL);
            force_binding_rewrite = true;
        }
    }
    option_dm = amxd_object_findf(client, ".Option.[Tag == 61].");
    if(option_dm != NULL) {
        clientid = amxd_object_get_value(cstring_t, option_dm, "Value", NULL);
    }
    /* Add instance to DM */
    amxc_ts_now(&now);
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "Chaddr", hwaddr);
    amxd_trans_set_value(cstring_t, &trans, "IPAddress", ipaddr);
    amxd_trans_set_value(cstring_t, &trans, "ClientID", clientid ? clientid : "");
    amxd_trans_set_value(amxc_ts_t, &trans, "LastSeen", &now);
    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR,
                      "Failed to update client");

    /* Update backend module as well */
    if(force_binding_rewrite) {
        pools_set_previous_bindings(amxd_object_get_parent(pool));
    } else {
        server_dm = amxd_object_get_parent(amxd_object_get_parent(pool));
        when_null_trace(server_dm, exit, ERROR, "No server object found");
        controller = amxd_object_get_value(cstring_t, server_dm, "Controller", NULL);
        when_null_trace(controller, exit, ERROR, "Cannot get controller from pool.");
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        tag = amxd_object_get_value(cstring_t, pool, "Tag", NULL);
        alias = amxd_object_get_value(cstring_t, pool, "Alias", NULL);
        amxc_var_add_key(cstring_t, &data, "Tag", tag);
        amxc_var_add_key(cstring_t, &data, "Alias", alias);
        amxc_var_add_key(cstring_t, &data, "Chaddr", hwaddr);
        amxc_var_add_key(cstring_t, &data, "IPAddress", ipaddr);
        if(clientid != NULL) {
            amxc_var_add_key(cstring_t, &data, "ClientID", clientid);
        }

        status = amxm_execute_function(controller, controller, "add-single-binding",
                                       &data, &ret);
        when_failed_trace(status, exit, ERROR, "Could not send the binding to the backend");
    }

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&data);
    amxd_trans_clean(&trans);
    amxc_string_clean(&mac_up);
    amxc_string_clean(&mac_low);
    free(tag);
    free(alias);
    free(controller);
    free(hwaddr);
    free(clientid);
}

/**
 * @brief
 * Create a client in the tr181 data model.
 *
 * @param pool the pool object to add the client to.
 * @param lease the variant that contain all information about the lease and the client.
 * @param client_chaddr the client MAC address.
 *
 * @return The newly created client on success or NULL if creation failed.
 */
static amxd_object_t* create_client(amxd_object_t* pool, amxc_var_t* lease, const char* client_chaddr) {
    amxd_trans_t trans;
    amxc_string_t client_alias;
    amxd_object_t* client = NULL;

    amxc_string_init(&client_alias, 0);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(pool, exit, ERROR, "No pool given to add the client");
    when_null_trace(client_chaddr, exit, ERROR, "No chaddr for client given");

    amxc_string_setf(&client_alias, "client-%s", client_chaddr);

    amxd_trans_select_object(&trans, pool);
    amxd_trans_select_pathf(&trans, ".Client.");
    amxd_trans_add_inst(&trans, 0, NULL);

    amxd_trans_set_value(cstring_t, &trans, "Alias", amxc_string_get(&client_alias, 0));
    amxd_trans_set_value(cstring_t, &trans, "Chaddr", client_chaddr);

    amxd_trans_select_pathf(&trans, ".Option.");
    amxc_var_for_each(option, GET_ARG(lease, "Option")) {
        const char* tag = amxc_var_key(option);
        amxd_trans_add_inst(&trans, 0, NULL);
        amxd_trans_set_value(cstring_t, &trans, "Tag", tag);
        amxd_trans_set_value(cstring_t, &trans, "Value", GET_CHAR(option, NULL));
        amxd_trans_select_pathf(&trans, ".^");
    }

    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot add client");
    client = amxd_object_findf(pool, "Client.client-%s.", client_chaddr);
exit:
    amxd_trans_clean(&trans);
    amxc_string_clean(&client_alias);
    return client;
}

/**
 * @brief
 * Update a client in the tr181 data model.
 *
 * @param client Client whose lease got update.
 * @param lease the variant that contain all information about the lease and the client.
 *
 * @return true on success
 */
static bool update_client(amxd_object_t* client, amxc_var_t* lease) {
    bool rv = false;
    amxd_status_t res = amxd_status_unknown_error;
    amxd_object_t* dm_options = amxd_object_findf(client, "Option.");
    amxc_var_t* lease_options = GET_ARG(lease, "Option");
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(dm_options, exit, ERROR, "Failed to find client options");
    when_null_trace(lease_options, exit, ERROR, "Failed to find lease options");

    res = amxd_trans_select_object(&trans, client);
    when_failed_trace(res, exit, ERROR, "Failed to select Client instance: %d", res);
    amxd_trans_set_value(bool, &trans, "Active", true);

    // Remove no longer relevant options from DM
    res = amxd_trans_select_object(&trans, dm_options);
    when_failed_trace(res, exit, ERROR, "Failed to select Client Option object: %d", res);
    amxd_object_for_each(instance, it, dm_options) {
        amxc_var_t* lease_option = NULL;
        amxd_object_t* dm_option = amxc_container_of(it, amxd_object_t, it);
        char* tag = amxd_object_get_value(cstring_t, dm_option, "Tag", NULL);
        when_null_trace(tag, del_loop_exit, ERROR, "client option had no tag");

        lease_option = GET_ARG(lease_options, tag);
        when_not_null(lease_option, del_loop_exit);

        when_failed_trace(amxd_trans_del_inst(&trans, amxd_object_get_index(dm_option), NULL),
                          del_loop_exit, ERROR, "Failed to delete client option %d", amxd_object_get_index(dm_option));
del_loop_exit:
        free(tag);
    }

    // Add or update lease options into DM
    amxc_var_for_each(lease_option, lease_options) {
        const char* tag = amxc_var_key(lease_option);
        amxd_object_t* dm_option = amxd_object_findf(dm_options, ".[Tag == %s].", tag);
        if(dm_option == NULL) {
            res = amxd_trans_select_object(&trans, dm_options);
            when_failed_trace(res, exit, ERROR, "Failed to select Client Option object: %d", res);

            res = amxd_trans_add_inst(&trans, 0, NULL);
            when_failed_trace(res, exit, ERROR, "Failed to add Client Option object: %d", res);

            amxd_trans_set_value(cstring_t, &trans, "Tag", tag);
        } else {
            res = amxd_trans_select_object(&trans, dm_option);
            when_failed_trace(res, exit, ERROR, "Failed to select Client Option object: %d", res);
        }
        amxd_trans_set_value(cstring_t, &trans, "Value", GET_CHAR(lease_option, NULL));
    }

    res = amxd_trans_apply(&trans, dhcp_get_dm());
    when_failed_trace(res, exit, ERROR, "Failed(%d) to update client", res);

    rv = true;
exit:
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief
 * Add or update a lease in the tr181 data model. If the client is not available in the data model, then it is created.
 *
 * @param function_name teh function name called.
 * @param args the variant data that contains client and lease information.
 * @param ret return variant.
 * @return 0 on success
 */
int pools_set_client_lease(UNUSED const char* function_name,
                           amxc_var_t* args,
                           UNUSED amxc_var_t* ret) {
    amxd_object_t* pool = NULL;
    amxd_object_t* client = NULL;
    const char* pool_alias = NULL;
    const char* client_chaddr = NULL;
    int rv = 1;

    when_null_trace(args, exit, ERROR, "No lease to add");

    pool_alias = GET_CHAR(args, "Alias");
    when_null_trace(pool_alias, exit, ERROR, "No pool alias found");

    pool = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.%s.", pool_alias);
    when_null_trace(pool, exit, ERROR, "Lease pool does not exist");

    client_chaddr = GET_CHAR(args, "Chaddr");
    when_null_trace(client_chaddr, exit, ERROR, "No chaddr client given");
    client = amxd_object_findf(pool, "Client.client-%s.", client_chaddr);
    if(client == NULL) {
        client = create_client(pool, args, client_chaddr);
        when_null_trace(client, exit, ERROR, "Cannot create client %s in pool", client_chaddr);
    } else {
        when_false_trace(update_client(client, args), exit, ERROR, "Cannot update client: %s", client_chaddr);
    }

    update_client_lease(client, args, amxd_object_get_value(uint32_t, pool, "LeaseTime", NULL));
    update_client_binding(pool, client, args);
    rv = 0;
exit:
    return rv;
}

/**
 * @brief
 * Add or update a lease in the tr181 data model. If the client is also not in the data model, then it is created.
 *
 * @param function_name the function name called.
 * @param args the variant data that contains client and lease information.
 * @param ret return variant.
 * @return 0 on success
 */
int pools_remove_client_lease(UNUSED const char* function_name,
                              amxc_var_t* args,
                              UNUSED amxc_var_t* ret) {
    amxd_object_t* pool = NULL;
    amxd_object_t* client = NULL;
    amxd_object_t* lease = NULL;
    const char* pool_alias = NULL;
    const char* client_chaddr = NULL;
    const char* ipv4_addr = NULL;
    int rv = 1;

    when_null_trace(args, exit, ERROR, "No lease to remove");
    pool_alias = GET_CHAR(args, "Alias");
    when_null_trace(pool_alias, exit, ERROR, "No pool alias found");

    pool = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.%s.", pool_alias);
    when_null_trace(pool, exit, ERROR, "Lease pool does not exist");

    client_chaddr = GET_CHAR(args, "Chaddr");
    when_null_trace(client_chaddr, exit, ERROR, "No chaddr client given");
    client = amxd_object_findf(pool, "Client.client-%s.", client_chaddr);
    when_null_trace(client, exit, ERROR, "Cannot get client in pool");

    ipv4_addr = GET_CHAR(args, "IPv4Address");
    when_null_trace(ipv4_addr, exit, ERROR, "No ipv4 given from the lease");
    lease = amxd_object_findf(client, "IPv4Address.[IPAddress=='%s']", ipv4_addr);
    when_null_trace(lease, exit, ERROR, "Cannot get lease in client : %s", ipv4_addr);

    amxd_object_emit_del_inst(lease);
    amxd_object_delete(&lease);
    rv = 0;
exit:
    return rv;
}


/**
 * @brief
 * Set and send the configuration to the controller to enable a static ip address.
 *
 * @param pool the pool object that the static ip address is link to.
 * @param addr the static ip address object to enable in the configuration.
 * @return 0 on success
 */
int pools_enable_pool_static_address(amxd_object_t* pool, amxd_object_t* addr) {
    int status = 0;
    char* controller = NULL;
    amxc_var_t data;
    amxc_var_t ret;
    amxd_object_t* server_obj = NULL;

    amxc_var_init(&ret);
    amxc_var_init(&data);

    when_null_trace(pool, exit, ERROR, "No pool given for the static ip");
    when_null_trace(addr, exit, ERROR, "No static ip given");

    server_obj = amxd_object_get_parent(amxd_object_get_parent(pool));
    when_null_trace(server_obj, exit, ERROR, "No server object found");

    controller = amxd_object_get_value(cstring_t, server_obj, "Controller", NULL);
    when_null_trace(controller, exit, ERROR, "Cannot get controller from pool.");

    create_controller_addr_data(pool, addr, &data);

    status = amxm_execute_function(controller,
                                   controller,
                                   "enable-static-ip",
                                   &data,
                                   &ret);
exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    free(controller);
    return status;
}

/**
 * @brief
 * Call the controller to disable a static ip address.
 *
 * @param event_data the data comming from a remove of the static ip
 * @param pool the pool object that the static ip address is linked to.
 * @param addr the static ip address object to disable in the configuration.
 * @return 0 on success
 */
int pools_disable_pool_static_address(const amxc_var_t* const event_data, amxd_object_t* pool, amxd_object_t* addr) {
    int status = 1;
    char* controller = NULL;
    amxc_var_t data;
    amxc_var_t ret;
    amxd_object_t* server_obj = NULL;

    amxc_var_init(&ret);
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    when_null_trace(pool, exit, ERROR, "No pool given for the static ip");
    when_null_trace(addr, exit, ERROR, "No alias of the static ip given");

    server_obj = amxd_object_get_parent(amxd_object_get_parent(pool));
    when_null_trace(server_obj, exit, ERROR, "No server object found");

    controller = amxd_object_get_value(cstring_t, server_obj, "Controller", NULL);
    when_null_trace(controller, exit, ERROR, "Cannot get controller from pool.");

    create_controller_addr_data(pool, addr, &data);

    if(event_data != NULL) {
        amxc_var_set(cstring_t, GETP_ARG(&data, "addr.Alias"), GETP_CHAR(event_data, "parameters.Alias"));
        amxc_var_set(cstring_t, GETP_ARG(&data, "addr.Chaddr"), GETP_CHAR(event_data, "parameters.Chaddr"));
    }

    status = amxm_execute_function(controller,
                                   controller,
                                   "disable-static-ip",
                                   &data,
                                   &ret);
exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&data);
    free(controller);
    return status;
}

/**
 * @brief
 * Assign a available ip address to the static ip address
 *
 * @param pool The pool the static address is assigned to.
 * @param addr The static address to assign the ip address to.
 * @return int 0 on success
 */
int pools_set_pool_static_address(amxd_object_t* pool, amxd_object_t* addr) {
    int rc = 1;
    amxd_trans_t trans;
    struct in_addr ip_addr;
    struct in_addr min_addr;
    char* ip_addr_str = NULL;
    char* min_addr_str = NULL;
    char str[INET_ADDRSTRLEN + 1];

    amxd_trans_init(&trans);

    when_null_trace(pool, exit, ERROR, "No pool object given")
    when_null_trace(addr, exit, ERROR, "No static address object given");

    ip_addr_str = amxd_object_get_value(cstring_t, pool, "MaxAddress", NULL);
    when_str_empty_trace(ip_addr_str, exit, ERROR, "No address available for auto assign");

    min_addr_str = amxd_object_get_value(cstring_t, pool, "MinAddress", NULL);
    when_str_empty_trace(min_addr_str, exit, ERROR, "No minimum address given");
    rc = inet_pton(AF_INET, min_addr_str, &min_addr);
    when_false_trace(rc == 1, exit, ERROR, "Bad Address parameter '%s'", min_addr_str);
    strncpy(str, ip_addr_str, INET_ADDRSTRLEN);
    str[INET_ADDRSTRLEN] = '\0';
    do {
        rc = inet_pton(AF_INET, str, &ip_addr);
        when_false_trace(rc == 1, exit, ERROR, "Bad Address parameter '%s'", str);
        amxd_trans_select_object(&trans, addr);
        amxd_trans_set_value(cstring_t, &trans, "Yiaddr", str);
        rc = amxd_trans_apply(&trans, dhcp_get_dm());
        when_true(rc == amxd_status_ok, exit);
        SAH_TRACEZ_INFO(ME, "Unable to apply address %s, trying next one", str);
        amxd_trans_clean(&trans);
        amxd_trans_init(&trans);

        // need to decrease by one the ip address for iteration, so a conversion to hex format of the ip is needed before applying the math
        ip_addr.s_addr = ntohl(htonl(ip_addr.s_addr) - 1);
        inet_ntop(AF_INET, &ip_addr, str, INET_ADDRSTRLEN);
    } while(htonl(ip_addr.s_addr) > htonl(min_addr.s_addr));
    when_failed_trace(rc, exit, ERROR, "No address found for static ip letting the address to be manually set");
exit:
    free(ip_addr_str);
    free(min_addr_str);
    amxd_trans_clean(&trans);
    return rc;
}

/**
 * @brief
 * Populate back-end with persistent leases.
 * This function creates inner list to match the way pcm parse data
 *
 * @param pools template pool object
 * @param controller backend controller
 */
amxd_status_t pools_set_previous_leases(amxd_object_t* pools) {
    amxc_var_t clients_var;
    amxc_var_t* list = NULL;
    amxd_status_t rc = amxd_status_invalid_arg;
    amxc_var_t ret;
    char* controller = NULL;

    amxc_var_init(&clients_var);
    amxc_var_init(&ret);
    amxc_var_set_type(&clients_var, AMXC_VAR_ID_HTABLE);

    list = amxc_var_add_key(amxc_llist_t, &clients_var, "Clients", NULL);
    when_null_trace(list, exit, ERROR, "Unable to create list");

    amxd_object_iterate(instance, pit, pools) {
        amxd_object_t* pool = amxc_container_of(pit, amxd_object_t, it);
        amxd_object_t* clients = amxd_object_findf(pool, ".Client.");
        amxd_object_iterate(instance, cit, clients) {
            amxd_object_t* client = amxc_container_of(cit, amxd_object_t, it);
            amxc_var_t* temp_list = NULL;
            amxd_object_t* options = amxd_object_findf(client, ".Option.");
            amxd_object_t* leases = amxd_object_findf(client, ".IPv4Address.");
            amxc_var_t* leases_list = NULL;
            amxc_var_t* options_list = NULL;
            amxc_var_t client_var;
            amxc_var_t* tmp = NULL;

            amxc_var_init(&client_var);
            amxc_var_set_type(&client_var, AMXC_VAR_ID_HTABLE);

            amxd_object_get_params(client, &client_var, amxd_dm_access_protected);

            leases_list = amxc_var_add_key(amxc_llist_t, &client_var, "IPv4Address", NULL);
            if(leases_list == NULL) {
                amxc_var_clean(&client_var);
                SAH_TRACEZ_ERROR(ME, "Unable to create leases list for client %s", amxd_object_get_name(client, AMXD_OBJECT_NAMED));
                continue;
            }
            amxd_object_iterate(instance, lit, leases) {
                amxd_object_t* lease = amxc_container_of(lit, amxd_object_t, it);
                amxc_var_t lease_var;

                amxc_var_init(&lease_var);

                amxd_object_get_params(lease, &lease_var, amxd_dm_access_protected);
                temp_list = amxc_var_add(amxc_llist_t, leases_list, NULL);
                tmp = amxc_var_add(amxc_htable_t, temp_list, NULL);
                if(tmp == NULL) {
                    amxc_var_clean(&lease_var);
                    continue;
                }
                amxc_var_move(tmp, &lease_var);
            }

            options_list = amxc_var_add_key(amxc_llist_t, &client_var, "Option", NULL);
            if(options_list == NULL) {
                amxc_var_clean(&client_var);
                SAH_TRACEZ_ERROR(ME, "Unable to create option list for client %s", amxd_object_get_name(client, AMXD_OBJECT_NAMED));
                continue;
            }
            amxd_object_iterate(instance, oit, options) {
                amxd_object_t* option = amxc_container_of(oit, amxd_object_t, it);
                amxc_var_t option_var;

                amxc_var_init(&option_var);

                amxd_object_get_params(option, &option_var, amxd_dm_access_protected);
                temp_list = amxc_var_add(amxc_llist_t, options_list, NULL);
                tmp = amxc_var_add(amxc_htable_t, temp_list, NULL);
                if(tmp == NULL) {
                    amxc_var_clean(&option_var);
                    continue;
                }
                amxc_var_move(tmp, &option_var);
            }
            temp_list = amxc_var_add(amxc_htable_t, list, NULL);
            tmp = amxc_var_add_key(amxc_htable_t, temp_list, "0", NULL);
            if(tmp == NULL) {
                amxc_var_clean(&client_var);
                SAH_TRACEZ_ERROR(ME, "Unable to add client %s", amxd_object_get_name(client, AMXD_OBJECT_NAMED));
                continue;
            }
            amxc_var_move(tmp, &client_var);
        }
    }

    controller = amxd_object_get_value(cstring_t, amxd_object_get_parent(pools), "Controller", NULL);
    rc = amxm_execute_function(controller, controller, "update-dhcp-leases", &clients_var, &ret);
    when_failed_trace(rc, exit, ERROR, "Unable to restore the DHCPv4Server leases");

exit:
    free(controller);
    amxc_var_clean(&ret);
    amxc_var_clean(&clients_var);

    return rc;
}

/**
 * @brief
 * Restores persistent assigned bindings by updating the backend module.
 * ONLY to be executed on start-up.
 *
 * @param pool The pool multi-instance object.
 */
amxd_status_t pools_set_previous_bindings(amxd_object_t* pool) {
    amxd_status_t rv = amxd_status_unknown_error;
    cstring_t controller = NULL;
    amxc_var_t data;
    amxc_var_t ret;

    amxc_var_init(&data);
    amxc_var_init(&ret);
    amxc_var_set_type(&data, AMXC_VAR_ID_LIST);
    when_null_trace(pool, exit, ERROR, "No pool given for the static ip");
    controller = amxd_object_get_value(cstring_t, amxd_object_get_parent(pool),
                                       "Controller", NULL);
    create_controller_binding_data(pool, &data);
    rv = amxm_execute_function(controller, controller, "update-bindings", &data,
                               &ret);
    free(controller);

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);

    return rv;
}
