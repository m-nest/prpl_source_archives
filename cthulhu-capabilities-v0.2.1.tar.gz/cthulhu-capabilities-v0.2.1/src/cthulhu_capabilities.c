/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file cthulhu_capabilities.c
 * @brief Implementation of the Cthulhu Capabilities plugin.
 *
 * Provides functions for managing user roles, capabilities, and integration with the data model.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb_wait_for.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_helpers.h>
#include <cthulhu/cthulhu_config.h>
#include <cthulhu/cthulhu_error.h>

#include <lcm/lcm_assert.h>
#include <lcm/amxc_data.h>
#include <debug/sahtrace.h>

#include "cthulhu_capabilities.h"
#include "cthulhu_capabilities_common.h"
#include "cthulhu_user_role.h"
#include "cthulhu_user_object.h"
#include "cthulhu-capabilities/cthulhu_capabilities_defines.h"

#define ME "capabilities"

/**
 * @brief Pointer to the data model instance.
 */
static amxd_dm_t* dm = NULL;
/**
 * @brief Pointer to the shared object instance.
 */
static amxm_shared_object_t* so = NULL;
/**
 * @brief Pointer to the module instance.
 */
static amxm_module_t* mod = NULL;

/**
 * @brief Gets the data model instance.
 * @return Pointer to the data model instance.
 */
amxd_dm_t* get_dm(void) {
    return dm;
}


/**
 * @brief Finds a sandbox object by its ID.
 * @param sb_id Sandbox ID string.
 * @return Pointer to the sandbox object, or NULL if not found.
 */
static inline amxd_object_t* sb_get(const char* const sb_id) {
    return amxd_dm_findf(dm, CTHULHU_DM_SANDBOX_INSTANCES ".[" CTHULHU_SANDBOX_ID "==\"%s\"].", sb_id);
}

/**
 * @brief Finds a container object by its ID.
 * @param ctr_id Container ID string.
 * @return Pointer to the container object, or NULL if not found.
 */
static inline amxd_object_t* ctr_get(const char* const ctr_id) {
    return amxd_dm_findf(dm, CTHULHU_DM_CONTAINER_INSTANCES ".[" CTHULHU_CONTAINER_ID "==\"%s\"].", ctr_id);
}

/**
 * @brief Sets a validation error in the return variable.
 * @param ret Return variable to populate with error info.
 * @param fault Fault type.
 * @param reason Error reason format string.
 * @param ... Arguments for the format string.
 */
static void set_validate_error(amxc_var_t* ret, tr181_fault_type_t fault, const char* reason, ...) {
    va_list args;
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_int32_t(ret, CTHULHU_NOTIF_ERROR_TYPE, fault);
    if(STRING_EMPTY(reason)) {
        return;
    }
    amxc_string_t r;
    amxc_string_init(&r, 0);
    va_start(args, reason);
    amxc_string_vsetf(&r, reason, args);
    va_end(args);
    amxc_var_add_new_key_cstring_t(ret, CTHULHU_NOTIF_REASON, amxc_string_get(&r, 0));
    SAH_TRACEZ_ERROR(ME, "ERR[%d:%s] %s", fault, tr181_fault_type_to_string(fault), amxc_string_get(&r, 0));
    amxc_string_clean(&r);
}

/**
 * @brief Converts a CSV string to a list variable.
 * @param input The input CSV string.
 * @param list The output variable list.
 * @param reason Optional pointer to a string describing the reason for failure.
 * @return 0 on success, non-zero on failure.
 */
int csv_string_to_list(const char* input, amxc_var_t* list, const char** reason) {
    int res = -1;
    amxc_string_t input_str;
    amxc_string_split_status_t split_res;

    amxc_string_init(&input_str, 0);
    amxc_string_set(&input_str, input);
    split_res = amxc_string_csv_to_var(&input_str, list, reason);
    if(split_res != AMXC_STRING_SPLIT_OK) {
        goto exit;
    }
    res = 0;
exit:
    amxc_string_clean(&input_str);
    return res;
}

/**
 * @brief Checks if a value exists in a linked list of strings.
 * @param list The linked list to search.
 * @param value The value to look for.
 * @return true if value is found, false otherwise.
 */
static bool list_contains(amxc_llist_t* list, const char* value) {
    amxc_llist_for_each(it, list) {
        amxc_string_t* s = amxc_string_from_llist_it(it);
        if(strcmp(amxc_string_get(s, 0), value) == 0) {
            return true;
        }
    }
    return false;
}

/**
 * @brief Checks if a value exists in a variable list.
 * @param list The variable list to search.
 * @param value The value to look for.
 * @return true if value is found, false otherwise.
 */
bool var_list_contains(amxc_var_t* list, const char* value) {
    amxc_var_for_each(entry, list) {
        const char* s = amxc_var_constcast(cstring_t, entry);
        if(strcmp(s, value) == 0) {
            return true;
        }
    }
    return false;
}

/**
 * @brief Converts a CSV string to a list and validates the result.
 * @param input The input CSV string.
 * @param list The output variable list.
 * @param argument_name Name of the argument being validated.
 * @param ret Return variable for error reporting.
 * @return 0 on success, -1 on failure.
 */
static int csv_string_to_list_validate(const char* input, amxc_var_t* list, const char* argument_name, amxc_var_t* ret) {
    const char* split_error = NULL;

    if(csv_string_to_list(input, list, &split_error) != 0) {
        set_validate_error(ret, tr181_fault_invalid_arguments,
                           "Failed to split argument [%s] value [%s] error (%s)",
                           argument_name, input, split_error);
        return -1;
    }
    return 0;
}

/**
 * @brief Validates that required roles
 *
 * - The RequiredUserRole should be an AvailableUserRole of the sandbox
 * - and it should still be defined in Devise.Users.Role
 *
 * @param required_roles List of required roles.
 * @param ctr_id Container ID.
 * @param ctr_sb_id Sandbox ID (optional).
 * @param ret Return variable for error reporting.
 * @return 0 on success, -1 on failure.
 */
static int validate_required_roles(amxc_var_t* required_roles, const char* ctr_id, const char* ctr_sb_id, amxc_var_t* ret) {
    int res = -1;
    amxd_object_t* ctr_obj = NULL;
    amxd_object_t* sb_obj = NULL;
    char* sb_available_roles = NULL;
    amxc_var_t sb_available_roles_list;
    char* sb_id = NULL;

    amxc_var_init(&sb_available_roles_list);
    if(ctr_sb_id) {
        sb_id = strdup(ctr_sb_id);
    } else {
        // update path
        ctr_obj = ctr_get(ctr_id);
        if(!ctr_obj) {
            set_validate_error(ret, tr181_fault_invalid_arguments, "CTR[%s] Container not found in datamodel", ctr_id);
            goto exit;
        }
        sb_id = amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_SANDBOX, NULL);
        if(!sb_id) {
            set_validate_error(ret, tr181_fault_invalid_arguments, "CTR[%s] Sandbox ID not found in datamodel", ctr_id);
            goto exit;
        }
    }
    sb_obj = sb_get(sb_id);
    if(!sb_obj) {
        set_validate_error(ret, tr181_fault_invalid_arguments, "CTR[%s] Sandbox [%s] not found in datamodel", ctr_id, sb_id);
        goto exit;
    }

    sb_available_roles = amxd_object_get_cstring_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, NULL);
    ASSERT_SUCCESS(csv_string_to_list_validate(sb_available_roles, &sb_available_roles_list, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, ret), goto exit, "String split failed");

    // now validate the roles
    amxc_var_for_each(req_role, required_roles) {
        const char* req_rolename = GET_CHAR(req_role, NULL);
        CHECK_STR_EMPTY_LOG(INFO, req_rolename, continue, "Role name is empty, it will be ignored");
        // check if the role is in the available roles of the sandbox
        bool found = false;
        amxc_var_for_each(available_role, &sb_available_roles_list) {
            const char* available_rolename = GET_CHAR(available_role, NULL);
            if(strcmp(req_rolename, available_rolename) == 0) {
                found = true;
                break;
            }
        }
        if(!found) {
            set_validate_error(ret, tr181_fault_unavailable_user_role,
                               "Sandbox [%s] does not have the required role [%s]", sb_id, req_rolename);
            goto exit;
        }
        // extra check if the role is in the cached roles
        if(!user_role_find_by_name(req_rolename)) {
            set_validate_error(ret, tr181_fault_unavailable_user_role,
                               "Role [%s] is not present in [%s]", req_rolename, USERS_ROOT);
            goto exit;
        }
    }

    res = 0;
exit:
    free(sb_id);
    free(sb_available_roles);
    amxc_var_clean(&sb_available_roles_list);
    return res;
}

/**
 * @brief Initializes the Cthulhu Capabilities plugin.
 * @param function_name Name of the function being called.
 * @param args Arguments for initialization.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_init(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    ASSERT_NOT_NULL(args, goto exit);
    dm = (amxd_dm_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_DATAMODEL);
    ASSERT_NOT_NULL(dm, goto exit);

    cthulhu_user_object_init();

    res = 0;
exit:
    return res;
}

/* Functions template */

/**
 * @brief Cleans up the Cthulhu Capabilities plugin.
 * @param function_name Name of the function being called.
 * @param args Arguments for cleanup.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_cleanup(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    cthulhu_user_object_teardown();
    user_role_list_clean();
    return 0;
}

static int cthulhu_capabilities_ctr_import(UNUSED const char* function_name,
                                           amxc_var_t* args,
                                           UNUSED amxc_var_t* ret) {
    int res = -1;

    amxc_var_t* import_data = (amxc_var_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_IMPORT_DATA);
    amxc_var_t* out_data = (amxc_var_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_OUT_DATA);
    ASSERT_NOT_NULL(import_data, goto exit);
    ASSERT_NOT_NULL(out_data, goto exit);

    amxc_var_add_key(cstring_t, out_data, CTHULHU_CONTAINER_REQUIRED_USER_ROLES,
                     GET_CHAR(import_data, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES));

    res = 0;
exit:
    return res;
}

static int cthulhu_capabilities_sb_import(UNUSED const char* function_name,
                                          amxc_var_t* args,
                                          UNUSED amxc_var_t* ret) {
    int res = -1;

    amxc_var_t* import_data = (amxc_var_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_IMPORT_DATA);
    amxc_var_t* out_data = (amxc_var_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_OUT_DATA);
    ASSERT_NOT_NULL(import_data, goto exit);
    ASSERT_NOT_NULL(out_data, goto exit);

    amxc_var_add_key(cstring_t, out_data, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES,
                     GET_CHAR(import_data, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES));

    res = 0;
exit:
    return res;
}

/**
 * @brief Store the RequiredUserRoles on container creation.
 *
 * If RequiredUserRoles are provided and valid, then they will be stored in the datmodel.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for creation.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_ctr_create(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = -1;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    const char* ctr_required_roles = NULL;
    amxc_var_t ctr_required_roles_list;
    amxd_trans_t trans;
    amxc_var_t role_name_list;
    amxc_var_t role_path_list;
    amxc_string_t role_name_csv;
    amxc_string_t role_path_csv;
    amxc_var_t* var_data = NULL;
    amxd_status_t status;

    amxc_var_init(&ctr_required_roles_list);
    amxd_trans_init(&trans);
    amxc_var_init(&role_name_list);
    amxc_var_init(&role_path_list);
    amxc_string_init(&role_name_csv, 0);
    amxc_string_init(&role_path_csv, 0);

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_STR_NOT_EMPTY(ctr_id, goto exit, "Argument [%s] is not provided", CTHULHU_PLUGIN_ARG_CTR_ID);
    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit, "CTR[%s] not found in datamodel", ctr_id);


    // init values to empty
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, ctr_obj);

    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, "");
    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_REQUIRED_USER_ROLES, "");

    var_data = GET_ARG(args, CTHULHU_PLUGIN_ARG_CREATE_DATA);
    ASSERT_NOT_NULL(var_data, goto exit);

    if(!GET_ARG(var_data, CTHULHU_CONTAINER_REQUIRED_USER_ROLES)) {
        // early return if the parameter is not present, keep existing settings
        res = 0;
        goto exit;
    }
    ctr_required_roles = GET_CHAR(var_data, CTHULHU_CONTAINER_REQUIRED_USER_ROLES);
    if(STRING_EMPTY(ctr_required_roles)) {
        // empty users present. Reset exisiting users.
        res = 0;
        goto trans_apply;
    }
    ASSERT_SUCCESS(csv_string_to_list_validate(ctr_required_roles, &ctr_required_roles_list, CTHULHU_CONTAINER_REQUIRED_USER_ROLES, ret), goto trans_apply, "String split failed");

    // validate the input
    ASSERT_SUCCESS(validate_required_roles(&ctr_required_roles_list, ctr_id, NULL, ret), goto trans_apply, "Validation of required roles failed");

    // the users are validated, so they can be added to the datamodel
    amxc_var_set_type(&role_name_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(&role_path_list, AMXC_VAR_ID_LIST);

    amxc_var_for_each(role, &ctr_required_roles_list) {
        const char* rolename = GET_CHAR(role, NULL);
        CHECK_STR_EMPTY_LOG(INFO, rolename, continue, "Role name is empty, it will be ignored");
        ASSERT_SUCCESS(add_role_to_list(rolename, &role_name_list, &role_path_list), goto trans_apply, "Could not add role [%s]", rolename);
    }
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_name_csv, &role_name_list), goto trans_apply, "Failed to convert role names to csv string");
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_path_csv, &role_path_list), goto trans_apply, "Failed to convert role paths to csv string");

    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, amxc_string_get(&role_name_csv, 0));
    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_REQUIRED_USER_ROLES, amxc_string_get(&role_path_csv, 0));

    res = 0;
trans_apply:
    status = amxd_trans_apply(&trans, dm);
    ASSERT_EQUAL(status, amxd_status_ok, res = -1; goto exit,
                 "Transaction failed. " CTHULHU_CONTAINER_REQUIRED_USER_ROLES " & " CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES " not added to DM. Status: %d", status);
exit:
    amxd_trans_clean(&trans);
    amxc_var_clean(&role_name_list);
    amxc_var_clean(&role_path_list);
    amxc_string_clean(&role_name_csv);
    amxc_string_clean(&role_path_csv);
    amxc_var_clean(&ctr_required_roles_list);
    return res;
}

/**
 * @brief Validates the container creation arguments for capabilities.
 *
 * - Check that the RequiredUserRoles is a csv string, if it is provided.
 * - Check if the required user roles exist.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for validation.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_ctr_validate(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = 1;
    const char* ctr_id = NULL;
    const char* ctr_required_roles = NULL;
    amxc_var_t ctr_required_roles_list;

    amxc_var_init(&ctr_required_roles_list);

    // validate the input

    // early return if the parameter is not present
    ctr_required_roles = GET_CHAR(args, CTHULHU_CONTAINER_REQUIRED_USER_ROLES);
    if(STRING_EMPTY(ctr_required_roles)) {
        res = 0;
        goto exit;
    }
    ASSERT_SUCCESS(csv_string_to_list_validate(ctr_required_roles, &ctr_required_roles_list, CTHULHU_CONTAINER_REQUIRED_USER_ROLES, ret), goto exit, "String split failed");

    ctr_id = GET_CHAR(args, CTHULHU_CONTAINER_ID);
    if(STRING_EMPTY(ctr_id)) {
        set_validate_error(ret, tr181_fault_invalid_arguments, "Argument [%s] not present", CTHULHU_CONTAINER_ID);
        goto exit;
    }
    const char* sb_id = GET_CHAR(args, CTHULHU_CONTAINER_SANDBOX);
    ASSERT_SUCCESS(validate_required_roles(&ctr_required_roles_list, ctr_id, sb_id, ret), goto exit, "Validation of required roles failed");

    res = 0;
exit:
    amxc_var_clean(&ctr_required_roles_list);
    return res;
}

/**
 * @brief Pre-start hook for container capabilities.
 *
 * For each required role, the capabilities will be retrieved and added to the start_data, so the
 * container backend module can configure the capabilities of the container.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for pre-start.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_ctr_prestart(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    cthulhu_ctr_start_data_t* start_data = NULL;
    amxd_object_t* ctr_obj = NULL;
    char* required_roles = NULL;
    amxc_var_t required_roles_list;
    amxc_llist_t capabilities;
    amxc_string_t role_name_csv;
    amxc_string_t role_path_csv;
    amxd_trans_t trans;
    amxd_status_t status;
    amxc_string_t caps_csv;

    amxd_trans_init(&trans);
    amxc_llist_init(&capabilities);
    amxc_var_init(&required_roles_list);
    amxc_string_init(&role_name_csv, 0);
    amxc_string_init(&role_path_csv, 0);
    amxc_string_init(&caps_csv, 0);

    const char* ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_STR_NOT_EMPTY(ctr_id, goto exit, "Argument [%s] not present", CTHULHU_PLUGIN_ARG_CTR_ID);
    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit);
    start_data = (cthulhu_ctr_start_data_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_START_DATA);
    ASSERT_NOT_NULL(start_data, goto exit, "Argument [%s] not present", CTHULHU_PLUGIN_ARG_START_DATA);

    required_roles = amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, NULL);
    ASSERT_SUCCESS(csv_string_to_list_validate(required_roles, &required_roles_list, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, ret), goto apply_caps, "String split failed");

    amxc_var_for_each(role, &required_roles_list) {
        const char* rolename = GET_CHAR(role, NULL);
        user_role_t* user_role = user_role_find_by_name(rolename);
        // when a user role cannot be found, its capabilities will not be added. So it is ok to continue here
        if(!user_role) {
            SAH_TRACEZ_ERROR(ME, "User Role [%s] does not exit. The container will not start.", rolename);
            amxc_llist_clean(&capabilities, amxc_string_list_it_free);
            goto apply_caps;
        }
        // add capabilities
        amxc_var_for_each(cap, &user_role->capabilities) {
            const char* capname = GET_CHAR(cap, NULL);
            if(!list_contains(&capabilities, capname)) {
                amxc_llist_add_string(&capabilities, capname);
            }
        }
    }
    res = 0;
apply_caps:
    amxc_string_join_llist(&caps_csv, &capabilities, ',');
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, ctr_obj);

    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_AVAILABLE_USER_ROLE_CAPABILITIES, amxc_string_get(&caps_csv, 0));
    status = amxd_trans_apply(&trans, dm);
    ASSERT_EQUAL(status, amxd_status_ok, NO_INSTRUCTION,
                 "Transaction failed. " CTHULHU_CONTAINER_AVAILABLE_USER_ROLE_CAPABILITIES " not added to DM. Status: %d", status);

    free_null(start_data->capabilities);
    if(amxc_llist_is_empty(&capabilities)) {
        start_data->capabilities = strdup("none");
        goto exit;
    }
    amxc_string_t capsjoined;
    amxc_string_init(&capsjoined, 0);
    amxc_string_join_llist(&capsjoined, &capabilities, ' ');
    start_data->capabilities = amxc_string_take_buffer(&capsjoined);
    amxc_string_clean(&capsjoined);

exit:
    if(start_data) {
        SAH_TRACEZ_INFO(ME, "CTR[%s] capabilities [%s]", ctr_id, start_data->capabilities);
    }
    amxc_var_clean(&required_roles_list);
    amxc_string_clean(&role_name_csv);
    amxc_string_clean(&role_path_csv);
    amxc_string_clean(&caps_csv);
    amxd_trans_clean(&trans);

    free(required_roles);
    amxc_llist_clean(&capabilities, amxc_string_list_it_free);
    return res;
}

/**
 * @brief Validates the sandbox creation arguments for capabilities.
 *
 * - Check that the AvailableUserRoles is a csv string, if it is provided.
 * - Check if the provided user roles exist.
 * - If roles are removed, check that the removed roles are not used by any containers in the sandbox.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for validation.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_sb_validate(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    amxd_object_t* sb_obj = NULL;
    const char* new_available_roles = NULL;
    amxc_var_t new_available_roles_list;
    char* old_available_roles = NULL;
    amxc_var_t old_available_roles_list;
    amxd_object_t* container_instances = NULL;
    char* ctr_id = NULL;
    char* ctr_sb = NULL;
    char* ctr_req_roles = NULL;
    amxc_var_t ctr_req_roles_list;
    amxc_llist_t removed_roles;
    int rc = 0;

    amxc_llist_init(&removed_roles);
    amxc_var_init(&new_available_roles_list);
    amxc_var_init(&old_available_roles_list);
    amxc_var_init(&ctr_req_roles_list);

    const char* sb_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_SB_ID);
    if(sb_id == NULL) {
        sb_id = GET_CHAR(args, CTHULHU_SANDBOX_ID);
    }
    ASSERT_NOT_NULL(sb_id, goto exit);
    ASSERT_STR_NOT_EMPTY(sb_id, goto exit, "Argument [%s] not present", CTHULHU_PLUGIN_ARG_SB_ID);
    // early return if the parameter is not present
    new_available_roles = GET_CHAR(args, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES);
    if(STRING_EMPTY(new_available_roles)) {
        res = 0;
        goto exit;
    }
    rc = csv_string_to_list_validate(new_available_roles, &new_available_roles_list,
                                     CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, ret);
    ASSERT_SUCCESS(rc, res = 1; goto exit, "String split failed");

    // check if requested roles are defined in Device.Users.Role
    amxc_var_for_each(role, &new_available_roles_list) {
        const char* role_name = amxc_var_constcast(cstring_t, role);
        if(!user_role_find_by_name(role_name)) {
            res = 1;
            set_validate_error(ret, tr181_fault_invalid_arguments,
                               "User role [%s] does not exist in %s", role_name, ROLE_DM);
            goto exit;
        }
    }

    sb_obj = sb_get(sb_id);
    if(!sb_obj) {
        //sb does not exist yet, no further validation is needed
        res = 0;
        goto exit;
    }
    old_available_roles = amxd_object_get_cstring_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, NULL);
    rc = csv_string_to_list_validate(old_available_roles, &old_available_roles_list,
                                     CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, ret);
    ASSERT_SUCCESS(rc, res = 1; goto exit, "String split failed");

    // check if some roles are removed
    amxc_var_for_each(role, &old_available_roles_list) {
        const char* role_name = amxc_var_constcast(cstring_t, role);
        if(!var_list_contains(&new_available_roles_list, role_name)) {
            SAH_TRACEZ_INFO(ME, "SB[%s] Role [%s] is removed", sb_id, role_name);
            amxc_llist_add_string(&removed_roles, role_name);
        }
    }
    if(amxc_llist_is_empty(&removed_roles)) {
        // no roles are removed
        res = 0;
        goto exit;
    }

    container_instances = amxd_dm_findf(dm, CTHULHU_DM_CONTAINER_INSTANCES ".");
    ASSERT_NOT_NULL(container_instances, goto exit, "Could not get [%s] from the datamodel", CTHULHU_DM_CONTAINER_INSTANCES);
    amxd_object_for_each(instance, it, container_instances) {
        amxd_object_t* ctr_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        ctr_id = amxd_object_get_cstring_t(ctr_instance, CTHULHU_CONTAINER_ID, NULL);
        ctr_sb = amxd_object_get_cstring_t(ctr_instance, CTHULHU_CONTAINER_SANDBOX, NULL);
        ASSERT_STR_NOT_EMPTY(ctr_sb, goto exit, "Could not get parameter [%s] from container", CTHULHU_CONTAINER_SANDBOX);
        ctr_req_roles = amxd_object_get_cstring_t(ctr_instance, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, NULL);
        if(STRING_EMPTY(ctr_req_roles)) {
            free_null(ctr_id);
            free_null(ctr_sb);
            free_null(ctr_req_roles);
            continue;
        }
        rc = csv_string_to_list_validate(ctr_req_roles, &ctr_req_roles_list, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, ret);
        ASSERT_SUCCESS(rc, res = 1; goto exit, "String split failed for container [%s]", ctr_id);
        // check if the container requires a role that is removed
        amxc_var_for_each(req_role, &ctr_req_roles_list) {
            const char* req_role_name = amxc_var_constcast(cstring_t, req_role);
            if(list_contains(&removed_roles, req_role_name)) {
                res = 1;
                set_validate_error(ret, tr181_fault_invalid_arguments,
                                   "Role [%s] can't be removed as it is used by CTR [%s]", req_role_name, ctr_id);
                goto exit;
            }
        }
        free_null(ctr_sb);
        free_null(ctr_id);
        free_null(ctr_req_roles);
        amxc_var_clean(&ctr_req_roles_list);
    }


    res = 0;
exit:
    free(old_available_roles);
    free(ctr_sb);
    free(ctr_id);
    free(ctr_req_roles);
    amxc_var_clean(&new_available_roles_list);
    amxc_var_clean(&old_available_roles_list);
    amxc_var_clean(&ctr_req_roles_list);
    amxc_llist_clean(&removed_roles, amxc_string_list_it_free);

    return res;
}


/**
 * @brief Store the available roles on sandbox creation.
 *
 * If AvailableUserRoles are provided in the arguments, then the UserRoles exist in the Device.Users.UserRoles,
 * then they will be stored in the datamodel as available.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for creation.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_capabilities_sb_create(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    amxd_trans_t trans;
    const char* sb_id = NULL;
    amxd_object_t* sb_obj = NULL;
    amxc_var_t role_name_list;
    amxc_var_t role_path_list;
    amxc_string_t role_name_csv;
    amxc_string_t role_path_csv;
    amxd_status_t status;

    amxd_trans_init(&trans);
    amxc_var_init(&role_name_list);
    amxc_var_init(&role_path_list);
    amxc_string_init(&role_name_csv, 0);
    amxc_string_init(&role_path_csv, 0);

    sb_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_SB_ID);
    if(STRING_EMPTY(sb_id)) {
        sb_id = GET_CHAR(args, CTHULHU_SANDBOX_ID);
    }
    ASSERT_STR_NOT_EMPTY(sb_id, goto exit, "Argument [%s] or [%s] is not provided", CTHULHU_PLUGIN_ARG_SB_ID, CTHULHU_SANDBOX_ID);

    sb_obj = sb_get(sb_id);
    ASSERT_NOT_NULL(sb_obj, goto exit, "Sandbox [%s] not found in datamodel", sb_id);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, sb_obj);
    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, "");
    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, "");

    ASSERT_STR_NOT_EMPTY(sb_id, goto trans_apply);
    amxc_var_t* var_data = GET_ARG(args, CTHULHU_PLUGIN_ARG_CREATE_DATA);

    if(!var_data) {
        res = 0;
        goto trans_apply;
    }
    amxc_var_t* var_availableroles = GET_ARG(var_data, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES);
    if(!var_availableroles) {
        res = 0;
        goto trans_apply;
    }

    amxc_var_cast(var_availableroles, AMXC_VAR_ID_LIST);
    amxc_var_set_type(&role_name_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(&role_path_list, AMXC_VAR_ID_LIST);

    amxc_var_for_each(role, var_availableroles) {
        const char* rolename = GET_CHAR(role, NULL);
        CHECK_STR_EMPTY_LOG(INFO, rolename, continue, "Role name is empty, it will be ignored");
        ASSERT_SUCCESS(add_role_to_list(rolename, &role_name_list, &role_path_list), goto trans_apply, "Could not add role [%s]", rolename);
    }
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_name_csv, &role_name_list), goto trans_apply, "Failed to convert role names to csv string");
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_path_csv, &role_path_list), goto trans_apply, "Failed to convert role paths to csv string");

    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, amxc_string_get(&role_name_csv, 0));
    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, amxc_string_get(&role_path_csv, 0));
    res = 0;

trans_apply:
    status = amxd_trans_apply(&trans, dm);
    ASSERT_EQUAL(status, amxd_status_ok, goto exit,
                 "Transaction failed. " CTHULHU_SANDBOX_AVAILABLE_USER_ROLES " & " CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES " not added to DM. Status: %d", status);

exit:
    amxd_trans_clean(&trans);
    amxc_var_clean(&role_name_list);
    amxc_var_clean(&role_path_list);
    amxc_string_clean(&role_name_csv);
    amxc_string_clean(&role_path_csv);
    return res;
}

/**
 * @brief Registers a function with the module.
 * @param func_name Name of the function to register.
 * @param cb Callback function pointer.
 * @return 0 on success, -1 on failure.
 */
static int register_function(const char* const func_name, amxm_callback_t cb) {
    ASSERT_SUCCESS(amxm_module_add_function(mod, func_name, cb), return -1, "Could not add function [%s]", func_name);
    return 0;
}

/**
 * @brief Module constructor for the Cthulhu Capabilities plugin.
 *        Called automatically when the module is loaded.
 * @return 0 on success, non-zero on failure.
 */
AMXM_CONSTRUCTOR module_init(void) {
    int ret = 1;

    so = amxm_so_get_current();
    ASSERT_NOT_NULL(so, goto exit, "Could not get shared object");
    ASSERT_SUCCESS(amxm_module_register(&mod, so, CTHULHU_PLUGIN), goto exit, "Could not register module %s", CTHULHU_PLUGIN);

    /* Init hook */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_INIT, cthulhu_capabilities_init), goto exit);

    /* Hooks template */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_IMPORT, cthulhu_capabilities_ctr_import), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_IMPORT, cthulhu_capabilities_sb_import), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CLEANUP, cthulhu_capabilities_cleanup), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_CREATE, cthulhu_capabilities_ctr_create), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_VALIDATE, cthulhu_capabilities_ctr_validate), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_PRESTART, cthulhu_capabilities_ctr_prestart), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_VALIDATE, cthulhu_capabilities_sb_validate), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_CREATE, cthulhu_capabilities_sb_create), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_MODIFY, cthulhu_capabilities_sb_create), goto exit);

    ret = 0;
exit:
    return ret;
}


/**
 * @brief Module destructor for the Cthulhu Capabilities plugin.
 *        Called automatically when the module is unloaded.
 * @return 0 on success.
 */
AMXM_DESTRUCTOR module_exit(void) {
    return 0;
}
