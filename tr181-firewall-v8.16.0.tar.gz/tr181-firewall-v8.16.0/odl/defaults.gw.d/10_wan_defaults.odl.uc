{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
%populate {
    object Firewall {
        object InterfaceSetting {
            instance add(Alias=wan) {
                parameter Interface = "${logical_intf_wan}";
                parameter IPv4SpoofingProtection = false;
                parameter IPv6SpoofingProtection = false;
            }
{% if (has_failover): %}
            instance add(Alias=wan-cellular) {
                parameter Interface = "${logical_intf_wan_cellular}";
                parameter IPv4SpoofingProtection = false;
                parameter IPv6SpoofingProtection = false;
            }
{% endif; %}
        }
        object Service {
            instance add(Alias=igmp-wan) {
                parameter Protocol = "2";
                parameter Interface = "${logical_intf_wan}";
                parameter Enable = 1;
                parameter IPVersion = 4;
                parameter Persistent = 1;
            }
        }
    }
    object NAT.InterfaceSetting {
        instance add(Alias=wan) {
            parameter Interface = "${logical_intf_wan}";
            parameter Enable = 1;
            parameter SourceNetwork = "${ip_intf_lan}IPv4Address,${ip_intf_guest}IPv4Address,${ip_intf_lcm}IPv4Address";
        }
{% if (has_failover): %}
        instance add(Alias=wan-cellular) {
            parameter Interface = "${logical_intf_wan_cellular}";
            parameter Enable = 1;
        }
{% endif; %}
    }
}
