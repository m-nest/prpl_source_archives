/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__HOMEPLUG_AV_PROTOCOLH__)
#define __HOMEPLUG_AV_PROTOCOL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define ETHERTYPE_HOMEPLUG_AV    0x88e1

#define HOMEPLUG_AV_VERSION_1_0  0x00
#define HOMEPLUG_AV_VERSION_1_1  0x01

#define MMTYPE_REQ               0x0000
#define MMTYPE_CNF               0x0001
#define MMTYPE_IND               0x0002
#define MMTYPE_RSP               0x0003

#define MMTYPE_STA_CCO           0x0000
#define MMTYPE_CC                0x0000
#define MMTYPE_PROXY_CO          0x2000
#define MMTYPE_CP                0x2000
#define MMTYPE_CCO_CCO           0x4000
#define MMTYPE_STA_STA           0x6000
#define MMTYPE_CM                0x6000
#define MMTYPE_MAN_SPEC          0x8000
#define MMTYPE_VENDOR_SPEC       0xA000

#define MMTYPE_CM_BRG_INFO       0x0020
#define MMTYPE_VS_NW_INFO        0x0038
#define MMTYPE_CM_NW_STATS       0x0048
#define MMTYPE_CM_HIFD           0x0040

#define MMTYPE_ATHEROS_SW_VER    0x0000

#define CM_BRG_INFO_REQ (MMTYPE_CM | MMTYPE_CM_BRG_INFO | MMTYPE_REQ)
#define CM_BRG_INFO_CNF (MMTYPE_CM | MMTYPE_CM_BRG_INFO | MMTYPE_CNF)

#define VS_NW_INFO_REQ  (MMTYPE_VENDOR_SPEC | MMTYPE_VS_NW_INFO | MMTYPE_REQ)
#define VS_NW_INFO_CNF  (MMTYPE_VENDOR_SPEC | MMTYPE_VS_NW_INFO | MMTYPE_CNF)
#define CM_NW_STATS_REQ (MMTYPE_CM | MMTYPE_CM_NW_STATS | MMTYPE_REQ)
#define CM_NW_STATS_CNF (MMTYPE_CM | MMTYPE_CM_NW_STATS | MMTYPE_CNF)

#define CM_HIFD_REQ (MMTYPE_CM | MMTYPE_CM_HIFD | MMTYPE_REQ)
#define CM_HIFD_CNF (MMTYPE_CM | MMTYPE_CM_HIFD | MMTYPE_CNF)

#define ATHEROS_SW_VER_REQ (MMTYPE_VENDOR_SPEC /*| MMTYPE_ATHEROS_SW_VER | MMTYPE_REQ */)
#define ATHEROS_SW_VER_CNF (MMTYPE_VENDOR_SPEC /*| MMTYPE_ATHEROS_SW_VER*/ | MMTYPE_CNF)

#define FRAME_SIZE_MAX (1518 - ETHER_HDR_LEN)

typedef struct _homeplug_av_hdr {
    uint8_t mmv;                 /**< Management Message Version (0x01 = HomePlug AV 1.1) */
    uint8_t mm_type_LSB;         /**< Message Type least significant byte */
    uint8_t mm_type_MSB;         /**< Message Type most significant byte */
    uint8_t fmi_nf : 4;          /**< Number of fragments (Fragmentation Management Info) */
    uint8_t fmi_fn : 4;          /**< Fragment number (Fragmentation Management Info) */
    uint8_t fmsn;                /**< Fragmented message sequence number */
} homeplug_av_hdr_t;

typedef homeplug_av_hdr_t cm_brg_info_req_t; /**< Bridge Info Request shares header only */

typedef struct _cm_brg_info_cnf {
    homeplug_av_hdr_t hdr;        /**< HomePlug AV header */
    uint8_t bsd;                  /**< Bridging Station flag */
    uint8_t btei;                 /**< STEI of the bridge */
    uint8_t nbda;                 /**< Number of bridge destinations */
    uint8_t bda[][6];             /**< Array of bridge destination MAC addresses */
} cm_brg_info_cnf_t;

typedef homeplug_av_hdr_t cm_nw_stats_req_t; /**< Network Stats Request shares header only */

typedef struct _cm_nw_stats_cnf_data {
    uint8_t DA[6];               /**< MAC address of the destination STA */
    uint8_t avgPHYDR_TX;         /**< Average PHY TX rate (Mbps) from STA to DA */
    uint8_t avgPHYDR_RX;         /**< Average PHY RX rate (Mbps) from DA to STA */
} cm_nw_stats_cnf_data_t;

typedef struct _cm_nw_stats_cnf {
    homeplug_av_hdr_t hdr;         /**< HomePlug AV header */
    uint8_t numSTA;                /**< Number of AV STAs included */
    cm_nw_stats_cnf_data_t data[]; /**< Per-STA statistics */
} cm_nw_stats_cnf_t;

typedef struct _cm_hfid_req {
    homeplug_av_hdr_t hdr;       /**< HomePlug AV header */
    uint8_t req_type;            /**< Request type */
    uint8_t data[];              /**< Additional data + padding */
} cm_hfid_req_t;

typedef struct _cm_hfid_cnf {
    homeplug_av_hdr_t hdr;       /**< HomePlug AV header */
    uint8_t res_type;            /**< Response type */
    uint8_t hfid[64];            /**< Human Friendly Identifier */
} cm_hfid_cnf_t;

typedef struct _vendor_specific_hdr {
    uint8_t mmv;                 /**< Management Message Version */
    uint8_t mm_type_LSB;         /**< Message Type LSB */
    uint8_t mm_type_MSB;         /**< Message Type MSB */
    uint8_t vendorOUI[3];        /**< Vendor Organizationally Unique Identifier */
} vendor_specific_hdr_t;

typedef vendor_specific_hdr_t atheros_sw_ver_req_t; /**< Atheros SW version request */

typedef struct _atheros_sw_ver_cnf {
    vendor_specific_hdr_t hdr;   /**< Vendor-specific header */
    uint8_t status;              /**< MME status */
    uint8_t deviceid;            /**< Device ID */
    uint8_t verlength;           /**< Length of version string */
    uint8_t version[128];        /**< Null-padded version string */
    uint8_t rsvd[5];             /**< Reserved */
} atheros_sw_ver_cnf_t;

typedef struct _vs_nw_info_req {
    homeplug_av_hdr_t hdr;       /**< HomePlug AV header */
    uint8_t vendorOUI[3];        /**< Vendor OUI */
    uint8_t subversion;          /**< Vendor subversion */
    uint8_t res[3];              /**< Reserved */
} vs_nw_info_req_t;

typedef struct _sta_data {
    uint8_t mac[6];             /**< MAC address of STA */
    uint8_t tei;                /**< Terminal Equipment Identifier */
    uint8_t reserved[3];        /**< Reserved, must be zero */
    uint8_t bda[6];             /**< Bridge Destination Address */
    uint16_t avgtx;             /**< Average TX PHY Data Rate (Mbps) */
    uint8_t coupling;           /**< Coupling type */
    uint8_t reserved3;          /**< Reserved */
    uint16_t avgrx;             /**< Average RX PHY Data Rate (Mbps) */
    uint16_t reserved4;         /**< Reserved */
} sta_data_t;

typedef struct _network_data {
    uint8_t nid[7];             /**< Network Identifier */
    uint8_t reserved1[2];       /**< Reserved */
    uint8_t snid;               /**< Short Network ID */
    uint8_t tei;                /**< TEI of this device */
    uint8_t reserved2[4];       /**< Reserved */
    uint8_t role;               /**< Role (CCO, STA, etc.) */
    uint8_t cco_mac[6];         /**< MAC address of CCO */
    uint8_t cco_tei;            /**< TEI of CCO */
    uint8_t reserved3[3];       /**< Reserved */
    uint8_t numStas;            /**< Number of stations in network */
    uint8_t reserved4[5];       /**< Reserved */
    sta_data_t sta[];           /**< Array of STA data */
} network_data_t;

typedef struct _vs_nw_info_cnf {
    homeplug_av_hdr_t hdr;       /**< HomePlug AV header */
    uint8_t vendorOUI[3];        /**< Vendor OUI */
    uint8_t reserved;
    uint16_t data_len;           /**< Length of network data in bytes */
    uint8_t reserved1;
    uint8_t numAvlns;            /**< Number of AV LANs */
    network_data_t network[];    /**< Array of network data structures */
} vs_nw_info_cnf_t;

#ifdef __cplusplus
}
#endif

#endif // __HOMEPLUG_AV_PROTOCOL_H__
