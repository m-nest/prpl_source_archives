/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "zone/dm_zone.h"
#include "dm_relay.h"
#include "dm_common.h"
#include "netdevname.h"
#include "zone/zone.h"
#include "internal_zone.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

static bool restart_done = false;

static void restart_zone_host(zone_host_t* zone_host) {
    when_null(zone_host, exit);
    zone_host_disable(zone_host, false);
    zone_host_enable(zone_host);
exit:
    restart_done = true;
    return;
}

static void restart_zone(zone_t* zone) {
    when_null(zone, exit);
    zone_disable(zone, false);
    zone_enable(zone);
exit:
    restart_done = true;
    return;
}

static void convert_csv_to_llist(amxc_llist_t* list, const csv_string_t csv_string) {
    amxc_var_t tmp_list_var;

    amxc_var_init(&tmp_list_var);

    when_null(list, exit);
    amxc_llist_clean(list, amxc_string_list_it_free);
    amxc_llist_init(list);
    when_str_empty(csv_string, exit);

    amxc_var_set_type(&tmp_list_var, AMXC_VAR_ID_CSV_STRING);
    amxc_var_set(csv_string_t, &tmp_list_var, csv_string);
    amxc_var_cast(&tmp_list_var, AMXC_VAR_ID_LIST);
    amxc_var_for_each(value, &tmp_list_var) {
        const char* element = GET_CHAR(value, NULL);
        if(STRING_EMPTY(element)) {
            continue;
        }
        amxc_llist_add_string(list, element);
    }

exit:
    amxc_var_clean(&tmp_list_var);
    return;
}

static void zone_host_hostnames_changed(UNUSED const char* sig_name, UNUSED const amxc_var_t* result, void* priv) {
    zone_host_t* zone_host = (zone_host_t*) priv;
    when_null(zone_host, exit);

    SAH_TRACEZ_INFO(ME, "Hosts query result changed");
    restart_zone_host(zone_host);
exit:
    return;
}

static void zone_netdevname_changed(UNUSED const char* sig_name, const amxc_var_t* result, void* priv) {
    zone_t* zone = (zone_t*) priv;
    const char* netdevname = GET_CHAR(result, NULL);

    when_true(strcmp_safe(zone->netdevname, netdevname) == 0, exit);

    SAH_TRACEZ_INFO(ME, "%s netdevname query result changed %s -> %s", amxd_object_get_name(zone->obj, AMXD_OBJECT_NAMED), zone->netdevname, netdevname);

    FREE(zone->netdevname);
    zone->netdevname = netdevname != NULL ? strdup(netdevname) : NULL;
    restart_zone(zone);
exit:
    return;
}

static void host_param_changed(zone_host_t* zone_host, bool added) {
    const char* host = NULL;

    when_null(zone_host, exit);

    if(zone_host->query_hosts != NULL) {
        hosts_closeQuery(zone_host->query_hosts);
        FREE(zone_host->query_hosts);
    }

    host = object_da_string(zone_host->obj, "Host");
    if(!STRING_EMPTY(host)) {
        zone_host->query_hosts = hosts_openQuery(host, zone_host_hostnames_changed, zone_host);
        when_null_trace(zone_host->query_hosts, exit, ERROR, "Failed to open Host query");
        if(!restart_done && added) {
            restart_zone_host(zone_host);
        }
    }
exit:
    return;
}

static void zone_iface_changed(zone_t* zone, bool added) {
    const char* iface = NULL;

    when_null(zone, exit);

    if(zone->query_netdevname != NULL) {
        CLOSE_QUERY(zone->query_netdevname);
        FREE(zone->netdevname);
    }

    iface = object_da_string(zone->obj, "Interface");
    if(!STRING_EMPTY(iface)) {
        zone->query_netdevname = query_netdevname(iface, zone_netdevname_changed, zone);
        when_null_trace(zone->query_netdevname, exit, ERROR, "Failed to open query");
        if(!restart_done && added) {
            restart_zone(zone);
        }
    }
exit:
    return;
}

static int zone_host_init(amxd_object_t* obj) {
    int rv = -1;
    zone_host_t* zone_host = NULL;
    const char* origin = NULL;

    when_null(obj, exit);
    zone_host = (zone_host_t*) obj->priv;
    when_not_null(zone_host, exit);
    zone_host = zone_host_new(obj);
    when_null(zone_host, exit);

    zone_host->enable = amxd_object_get_value(bool, obj, "Enable", NULL);
    convert_csv_to_llist(&zone_host->list_hostnames, object_da_string(obj, "Name"));

    origin = object_da_string(obj, "Origin");
    if((origin == NULL) || (strcmp(origin, "User") == 0)) {
        zone_host->is_user = true;
    } else {
        unset_object_persistency(obj);
    }

    restart_done = false;
    host_param_changed(zone_host, true);
    rv = 0;
exit:
    return rv;
}

static int zone_init(amxd_object_t* obj) {
    int rv = -1;
    zone_t* zone = NULL;
    const char* origin = NULL;
    const cstring_t domain = NULL;

    when_null(obj, exit);
    zone = (zone_t*) obj->priv;
    when_not_null(zone, exit);
    zone = zone_new(obj);
    when_null(zone, exit);

    zone->enable = amxd_object_get_value(bool, obj, "Enable", NULL);
    domain = object_da_string(obj, "Name");
    if(domain != NULL) {
        zone->domain = strdup(domain);
    }

    origin = object_da_string(obj, "Origin");
    if((origin == NULL) || (strcmp(origin, "User") == 0)) {
        zone->is_user = true;
    } else {
        unset_object_persistency(obj);
    }

    restart_done = false;
    zone_iface_changed(zone, true);
    rv = 0;
exit:
    return rv;
}

void _zone_added(UNUSED const char* const sig_name,
                 const amxc_var_t* const data,
                 UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(get_dm(), data);
    amxd_object_t* obj = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));

    when_null(obj, exit);
    when_failed(zone_init(obj), exit);
exit:
    return;
}


amxd_status_t _zone_removed(amxd_object_t* obj,
                            UNUSED amxd_param_t* param,
                            amxd_action_t reason,
                            UNUSED const amxc_var_t* const args,
                            UNUSED amxc_var_t* const retval,
                            UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    zone_t* zone = NULL;

    when_null(obj, exit);
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);

    zone = (zone_t*) obj->priv;
    when_null_status(zone, exit, status = amxd_status_ok);

    SAH_TRACEZ_INFO(ME, "Object[%s] is about to be destroyed", zone->name);

    zone_disable(zone, true);
    obj->priv = NULL;

    status = amxd_status_ok;
exit:
    return status;
}

void _zone_changed(UNUSED const char* const sig_name,
                   const amxc_var_t* const data,
                   UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(get_dm(), data);
    zone_t* zone = NULL;
    bool changed_dm = false;

    when_null(obj, exit);
    when_null(obj->priv, exit);
    when_null(data, exit);
    restart_done = false;
    zone = (zone_t*) obj->priv;

    if(GETP_ARG(data, "parameters.Enable.to") != NULL) {
        changed_dm = true;
        zone->enable = GETP_BOOL(data, "parameters.Enable.to");
    }

    if(GETP_ARG(data, "parameters.Name.to") != NULL) {
        changed_dm = true;
        FREE(zone->domain);
        zone->domain = strdup(GETP_CHAR(data, "parameters.Name.to"));
    }

    if(GETP_ARG(data, "parameters.Interface.to") != NULL) {
        changed_dm = true;
        zone_iface_changed(zone, false);
    }

    if(!restart_done && changed_dm) {
        restart_zone(zone);
    }
exit:
    return;
}

void _zone_host_added(UNUSED const char* const sig_name,
                      const amxc_var_t* const data,
                      UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(get_dm(), data);
    amxd_object_t* obj = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));

    when_null(obj, exit);
    when_failed(zone_host_init(obj), exit);
exit:
    return;
}

void _zone_host_changed(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(get_dm(), data);
    zone_host_t* zone_host = NULL;
    bool changed_dm = false;

    when_null(obj, exit);
    when_null(obj->priv, exit);
    when_null(data, exit);
    restart_done = false;
    zone_host = (zone_host_t*) obj->priv;

    if(GETP_ARG(data, "parameters.Enable.to") != NULL) {
        changed_dm = true;
        zone_host->enable = GETP_BOOL(data, "parameters.Enable.to");
    }

    if(GETP_ARG(data, "parameters.Name.to") != NULL) {
        changed_dm = true;
        convert_csv_to_llist(&zone_host->list_hostnames, GETP_CHAR(data, "parameters.Name.to"));
    }

    if(GETP_ARG(data, "parameters.Host.to") != NULL) {
        changed_dm = true;
        host_param_changed(zone_host, false);
    }

    if(!restart_done && changed_dm) {
        restart_zone_host(zone_host);
    }
exit:
    return;
}

amxd_status_t _zone_host_removed(amxd_object_t* obj,
                                 UNUSED amxd_param_t* param,
                                 amxd_action_t reason,
                                 UNUSED const amxc_var_t* const args,
                                 UNUSED amxc_var_t* const retval,
                                 UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    zone_host_t* zone_host = NULL;

    when_null(obj, exit);
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);

    zone_host = (zone_host_t*) obj->priv;
    when_null_status(zone_host, exit, status = amxd_status_ok);

    SAH_TRACEZ_INFO(ME, "Object[%s] is about to be destroyed", zone_host->name);

    zone_host_disable(zone_host, true);
    obj->priv = NULL;

    status = amxd_status_ok;
exit:
    return status;
}

static void zone_hosts_start(amxd_object_t* zone_obj) {
    when_null(zone_obj, exit);
    amxd_object_for_each(instance, it, amxd_object_findf(zone_obj, ".%s.", "Host")) {
        amxd_object_t* zone_host_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        restart_done = false;
        zone_host_init(zone_host_obj);
        if(!restart_done) {
            restart_zone(zone_host_obj->priv);
        }
    }
exit:
    return;
}

void zones_start(void) {
    amxd_object_for_each(instance, it_zone, amxd_dm_findf(get_dm(), "DNS.Zone.")) {
        amxd_object_t* zone_obj = amxc_llist_it_get_data(it_zone, amxd_object_t, it);
        restart_done = false;
        zone_init(zone_obj);
        if(!restart_done) {
            restart_zone(zone_obj->priv);
        }
        zone_hosts_start(zone_obj);
    }
}
