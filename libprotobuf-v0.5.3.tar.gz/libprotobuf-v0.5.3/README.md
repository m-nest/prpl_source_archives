This library is indented to generate the protobuf code from the .proto files defined by BBF (USP)

sudo apt install protobuf-compiler libprotobuf-c-dev
