#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="deviceinfo-manager"
PROG="/usr/bin/deviceinfo-manager"
datamodel_root="DeviceInfo"
PROG_OPTIONS=""

prepare(){
    hash=$(software_version_hash.sh)
    hash_old=$(cat /cfg/dbversion)
    if [ "$hash" != "$hash_old" ]; then
        procd_append_env_opts LAST_UPGRADE_DATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    fi
}

#Guideline- this function has the instructions to execute before
#starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    prepare
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}
