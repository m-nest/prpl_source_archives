/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <yajl/yajl_gen.h>
#include <amxc/amxc.h>
#include <cthulhu/cthulhu_defines.h>
#include <timingila/timingila_defines.h>

#include <debug/sahtrace.h>

#include "helpers.h"
#include "wrappers.h"

amxc_var_t expected_dustatechange;
char last_cmd_id[16];


amxc_var_t* get_expected_dustatechange(void) {
    return &expected_dustatechange;
}

char* get_last_cmd_id(void) {
    return last_cmd_id;
}

int __wrap_amxb_describe(amxb_bus_ctx_t* const bus_ctx,
                         UNUSED const char* object,
                         UNUSED uint32_t flags,
                         amxc_var_t* ret,
                         UNUSED int timeout) {

    amxc_var_t* var = NULL;

    int retval = amxd_status_unknown_error;

    if(bus_ctx == NULL) {
        return retval;
    }

    if(bus_ctx == (amxb_bus_ctx_t*) 1) {
        var = filejson_to_amxc_var("config/cthulhu_cmd_args.json");
        if(var) {
            amxc_var_init(ret);
            amxc_var_move(ret, var);
            amxc_var_delete(&var);
            retval = amxd_status_ok;
        }
    } else if(bus_ctx == (amxb_bus_ctx_t*) 2) {
        return retval;
    } else if(bus_ctx == (amxb_bus_ctx_t*) 3) {
        amxc_var_init(ret);
        amxc_var_set_type(ret, AMXC_VAR_ID_CSTRING);
    }

    return retval;
}

int __wrap_amxm_execute_function(UNUSED const char* const shared_object_name,
                                 const char* const module_name,
                                 const char* const func_name,
                                 UNUSED amxc_var_t* args,
                                 UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_INFO(ME, "EVENT: %s %s", module_name, func_name);
    if(strcmp(module_name, "dm-event") == 0) {
        if(strcmp(func_name, "dustatechange") == 0) {
            // check received dustatechange with expected
            amxc_var_dump(args, STDOUT_FILENO);
            compare_arg(&expected_dustatechange, args, SM_DM_EVENT_DUSTATECHANGE_UUID);
            compare_arg(&expected_dustatechange, args, SM_DM_EVENT_DUSTATECHANGE_STARTTIME);
            compare_arg(&expected_dustatechange, args, SM_DM_EVENT_DUSTATECHANGE_OPERATION);
            compare_arg(&expected_dustatechange, args, SM_DM_EVENT_DUSTATECHANGE_FAULTSTRING);
            compare_arg(&expected_dustatechange, args, SM_DM_EVENT_DUSTATECHANGE_FAULTCODE);

            amxc_var_t* var = GET_ARG(&expected_dustatechange, SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME);
            if(var) {
                SAH_TRACEZ_INFO(ME, "compare %s", SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME);
                amxc_ts_t* start_time = amxc_var_get_amxc_ts_t(var);
                var = GET_ARG(args, SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME);
                amxc_ts_t* complete_time = amxc_var_get_amxc_ts_t(var);
                assert_true(amxc_ts_compare(start_time, complete_time) < 0);
                free(start_time);
                free(complete_time);
            }
        }
    }
    return 0;
}

amxb_request_t* __wrap_amxb_async_call(UNUSED amxb_bus_ctx_t* const bus_ctx,
                                       UNUSED const char* object,
                                       UNUSED const char* method,
                                       UNUSED amxc_var_t* args,
                                       UNUSED amxb_be_done_cb_fn_t done_fn,
                                       UNUSED void* priv) {
    static amxb_request_t req;
    const char* cmd_id = GET_CHAR(args, CTHULHU_NOTIF_COMMAND_ID);
    SAH_TRACEZ_INFO(ME, "WRAP CMD: %s COMD_ID: %s", method, cmd_id);
    snprintf(last_cmd_id, sizeof(last_cmd_id) - 1, cmd_id);

    return &req;
}