/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <inttypes.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_timer.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_function.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "usb-pwr.h"
#include "usb-pwr-utils.h"
#include "usb.h"

#define ME "pwr"
#define CHANGE_POWER_MODE_TIMEOUT_MS 1000    // Timeout for asynchronous power mode changes

/**
 * @brief Tracks the state of a deferred USB power mode change request.
 *
 * Stores the deferred call identifier, timeout timer, and the target port name
 * with the requested power state while an asynchronous change is in progress.
 */
typedef struct usb_async_change_pwr_s {
    bool call_busy;             // Boolean value representing if a call ongoing
    uint64_t call_id;           // Unique identifier of the ongoing call
    amxp_timer_t* timer;        // Timout timer for the call
    char* port_name;            // Name of the USB port for which the power change is requested
    char* new_state;            // New state to be applied to the ethernet interface
} usb_async_change_pwr_t;

/**
 * @brief Global context for the currently pending asynchronous power mode change.
 */
static usb_async_change_pwr_t s_async_change_power_mode = {
    .call_busy = false,
    .call_id = 0,
    .timer = NULL,
    .port_name = NULL,
    .new_state = NULL,
};

/**
 * @brief Reset the asynchronous power mode change context.
 *
 * Clears the deferred call state, deletes the timeout timer, and releases
 * any dynamically allocated strings associated with the pending request.
 */
static void reset_async_change_power_mode_status(void) {
    SAH_TRACEZ_IN(ME);
    s_async_change_power_mode.call_busy = false;
    s_async_change_power_mode.call_id = 0;
    amxp_timer_delete(&s_async_change_power_mode.timer);
    if(s_async_change_power_mode.port_name != NULL) {
        free(s_async_change_power_mode.port_name);
        s_async_change_power_mode.port_name = NULL;
    }
    if(s_async_change_power_mode.new_state != NULL) {
        free(s_async_change_power_mode.new_state);
        s_async_change_power_mode.new_state = NULL;
    }
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Cancel a deferred power mode change when the timeout expires.
 *
 * Removes the pending deferred function call and resets the asynchronous
 * tracking context.
 *
 * @param timer Unused timer that triggered the callback.
 * @param priv Unused private data.
 */
static void usb_async_change_power_mode_status_cancel(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Deferred call removed (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);
    amxd_function_deferred_remove(s_async_change_power_mode.call_id);
    reset_async_change_power_mode_status();
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Complete a deferred USB power mode change.
 *
 * When a low-level power mode change completes, this callback updates the
 * corresponding USB port PowerStatus parameter and completes the deferred
 * data model function call. If the asynchronous context is no longer active,
 * the deferred call is treated as timed out and removed.
 *
 * @param function_name Name of the completed function.
 * @param args Callback arguments.
 * @param ret Callback return value.
 * @return 0 on success, or an amxd_status_t error code on failure.
 */
int usb_async_change_power_mode_status_set_done(UNUSED const char* function_name,
                                                UNUSED amxc_var_t* args,
                                                UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_dm_t* dm = get_dm();
    amxd_object_t* usb_obj = NULL;

    if(s_async_change_power_mode.call_busy) {
        SAH_TRACEZ_INFO(ME, "LL API call done (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);

        usb_obj = amxd_dm_findf(dm, "USB.Port.%s", s_async_change_power_mode.port_name);
        when_null_trace(usb_obj, exit, ERROR, "Problem amxd_dm_findf cannot find USB.Port. object");

        amxd_object_set_attr(usb_obj, amxd_oattr_read_only, true);
        rv = amxd_object_set_value(cstring_t, usb_obj, "PowerStatus", s_async_change_power_mode.new_state);
        if(rv != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Failed to set PowerState synchronously; rv=%d", rv);
            amxd_function_deferred_remove(s_async_change_power_mode.call_id);
            reset_async_change_power_mode_status();
            goto exit;
        }
        rv = amxd_function_deferred_done(s_async_change_power_mode.call_id, rv, NULL, NULL);
        if(rv != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Failed to complete deferred ChangePowerMode call; rv=%d", rv);
        }
        reset_async_change_power_mode_status();
    } else {
        SAH_TRACEZ_INFO(ME, "LL API call timeout (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);
        rv = amxd_status_timeout;
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Handle the ChangePowerMode data model function asynchronously.
 *
 * This function validates the requested power state, cancels any already
 * pending power change, creates a new deferred call, starts a timeout timer,
 * and forwards the request to the low-level power management module.
 *
 * @param object Pointer to the USB port object.
 * @param func Pointer to the invoked function descriptor.
 * @param args Function arguments containing the requested PowerState.
 * @param ret Deferred return value container.
 * @return amxd_status_deferred when the request is accepted, or an error
 *         status if validation or setup fails.
 */
amxd_status_t _ChangePowerMode(amxd_object_t* object,
                               amxd_function_t* func,
                               amxc_var_t* args,
                               amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t rv = amxd_status_ok;
    const char* port_name = object->name;
    const char* new_state = GET_CHAR(args, "PowerState");

    when_str_empty_status(port_name, exit, rv = amxd_status_invalid_value);
    when_str_empty_status(new_state, exit, rv = amxd_status_invalid_value);

    if(s_async_change_power_mode.call_busy) {
        SAH_TRACEZ_INFO(ME, "Previous ChangePowerMode() in progress; canceling old call_id=%" PRIu64, s_async_change_power_mode.call_id);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
    }

    s_async_change_power_mode.port_name = strdup(port_name);
    s_async_change_power_mode.new_state = strdup(new_state);

    if(s_async_change_power_mode.port_name == NULL) {
        reset_async_change_power_mode_status();
        return amxd_status_out_of_mem;
    }

    if(s_async_change_power_mode.new_state == NULL) {
        reset_async_change_power_mode_status();
        return amxd_status_out_of_mem;
    }

    rv = amxd_function_defer(func, &s_async_change_power_mode.call_id, ret, NULL, NULL);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "amxd_function_defer() failed; rv=%d", rv);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Deferred call created (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);

    s_async_change_power_mode.call_busy = true;

    rv = amxp_timer_new(&s_async_change_power_mode.timer, usb_async_change_power_mode_status_cancel, NULL);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to create async power mode timer; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    rv = amxp_timer_start(s_async_change_power_mode.timer, CHANGE_POWER_MODE_TIMEOUT_MS);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start async power mode timer; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Setting PowerState (deferred) to '%s'", s_async_change_power_mode.new_state);
    rv = mod_usb_set_pwr_mode(s_async_change_power_mode.port_name, s_async_change_power_mode.new_state);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to set PowerState synchronously; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Deferred call_id=%" PRIu64 " done (rv=%d)", s_async_change_power_mode.call_id, rv);

    rv = amxd_status_deferred;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}
