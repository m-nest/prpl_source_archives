#include "device.h"
#include "helpers.h"
#include "device_list.h"
#include "mod_usb_filter.h"

#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <string.h>

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param state Enum value representing authentication state.
 * @return When allowed 1, When blocked 0, -1 otherwise
 */
int auth_state_to_int(auth_state_t state) {
    int rv = -1;

    switch((int) state) {
    case ALLOWED:
        rv = 1;
        break;
    case BLOCKED:
        rv = 0;
        break;
    }

    return rv;
}

/**
 * @brief Create an internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param template_object Template object of the Device Object.
 * @param parameters Hashtable containing device settings.
 * @return Internal usb device object
 */
usb_device_t* create_usb_device(device_type_t type, amxd_object_t* template_object, amxc_var_t* parameters) {
    usb_device_t* device = NULL;

    when_null(parameters, exit);

    device = (usb_device_t*) calloc(1, sizeof(usb_device_t));
    when_null_trace(device, exit, ERROR, "Failed to execute calloc");

    usb_interface_list_init(device);
    device->device_class = set_hex_value(GET_CHAR(parameters, "DeviceClass"));
    device->device_subclass = set_hex_value(GET_CHAR(parameters, "DeviceSubClass"));
    device->device_protocol = set_hex_value(GET_CHAR(parameters, "DeviceProtocol"));
    device->type = type;

    if(type == DEVICE) {
        device->product_id = int_to_hex_value(GET_UINT32(parameters, "ProductID"));
        device->vendor_id = int_to_hex_value(GET_UINT32(parameters, "VendorID"));
        device->sysfs_id = strdup(GET_CHAR(parameters, "SysfsId"));
        device->object = amxd_object_findf(template_object, ".[SysfsId == '%s']", GET_CHAR(parameters, "SysfsId"));
    } else if(type == ALLOWED_DEVICE) {
        device->product_id = set_hex_value(GET_CHAR(parameters, "ProductID"));
        device->vendor_id = set_hex_value(GET_CHAR(parameters, "VendorID"));
        device->enable = GET_BOOL(parameters, "Enable");
    }

    if(amxc_var_get_key(parameters, "Interfaces", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxc_string_t interfaces_str;
        amxc_llist_t interfaces_list;
        char* cleaned_up_interfaces = set_hex_value(GET_CHAR(parameters, "Interfaces"));

        amxc_string_init(&interfaces_str, 0);
        amxc_llist_init(&interfaces_list);

        amxc_string_set(&interfaces_str, cleaned_up_interfaces);
        amxc_string_split_to_llist(&interfaces_str, &interfaces_list, ',');

        amxc_llist_for_each(it, &interfaces_list) {
            amxc_string_t* str_part = amxc_string_from_llist_it(it);
            usb_device_interface_t intf;
            usb_interface_list_entry_t* entry = NULL;

            if(STR_EMPTY(amxc_string_get(str_part, 0))) {
                continue;
            }

            intf = create_usb_device_interface(amxc_string_get(str_part, 0));
            entry = usb_interface_list_add(device, &intf);
            if(entry == NULL) {
                usb_device_interface_clean(&intf);
                continue;
            }
            amxc_llist_append(device->interface_list, &(entry->it));
            usb_device_interface_clean(&intf);
        }

        SAFE_DELETE(cleaned_up_interfaces);
        amxc_llist_clean(&interfaces_list, amxc_string_list_it_free);
        amxc_string_clean(&interfaces_str);
    }

exit:
    return device;
}

/**
 * @brief Cleanup an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_device_clean(usb_device_t* usb_device) {
    SAFE_DELETE(usb_device->device_class);
    SAFE_DELETE(usb_device->device_subclass);
    SAFE_DELETE(usb_device->device_protocol);
    SAFE_DELETE(usb_device->product_id);
    SAFE_DELETE(usb_device->vendor_id);
    SAFE_DELETE(usb_device->sysfs_id);

    usb_interface_list_clean(usb_device);
    SAFE_DELETE(usb_device->interface_list);
}

/**
 * @brief Change interface for a certain internal usb device structure
 *
 * @param device Internal device structure.
 * @param old_intf Old interface structure.
 * @param new_parameters Hashtable containing interface settings.
 */
void usb_device_change_interface(usb_device_t* device, usb_device_interface_t* old_intf, const amxc_var_t* const new_parameters) {
    when_null(device, exit);
    when_null(old_intf, exit);
    when_null(new_parameters, exit);

    usb_interface_list_delete(device, old_intf);
    usb_interface_list_add_by_parameters(device, new_parameters);

exit:
    return;
}

/**
 * @brief Create an internal interface structure.
 *
 * @param interface String representation of interface class, subclass and protocol
 * @return Internal usb interface object
 */
usb_device_interface_t create_usb_device_interface(const char* interface) {
    usb_device_interface_t intf;

    amxc_string_t intf_str;
    amxc_llist_t intf_list;
    amxc_string_t* str_part = NULL;

    amxc_string_init(&intf_str, 0);
    amxc_llist_init(&intf_list);

    when_str_empty(interface, exit);

    amxc_string_set(&intf_str, interface);
    amxc_string_split_to_llist(&intf_str, &intf_list, ':');

    str_part = amxc_llist_size(&intf_list) > 0 ? amxc_string_from_llist_it(amxc_llist_get_at(&intf_list, 0)) : NULL;
    intf.interface_class = str_part == NULL ? strdup("") : strdup(amxc_string_get(str_part, 0));

    str_part = amxc_llist_size(&intf_list) > 1 ? amxc_string_from_llist_it(amxc_llist_get_at(&intf_list, 1)) : NULL;
    intf.interface_subclass = str_part == NULL ? strdup("") :  strdup(amxc_string_get(str_part, 0));

    str_part = amxc_llist_size(&intf_list) > 2 ? amxc_string_from_llist_it(amxc_llist_get_at(&intf_list, 2)) : NULL;
    intf.interface_protocol = str_part == NULL ? strdup("") :  strdup(amxc_string_get(str_part, 0));

exit:
    amxc_string_clean(&intf_str);
    amxc_llist_clean(&intf_list, amxc_string_list_it_free);
    return intf;
}

/**
 * @brief Cleanup an internal interface structure.
 *
 * @param interface Internal usb interface object
 */
void usb_device_interface_clean(usb_device_interface_t* interface) {
    when_null(interface, exit);

    SAFE_DELETE(interface->interface_class);
    SAFE_DELETE(interface->interface_subclass);
    SAFE_DELETE(interface->interface_protocol);

exit:
    return;
}
