/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef OBUSPA_INTERFACE
#define OBUSPA_INTERFACE
#include <amxc/amxc.h>

#include "usp_discovery.h"

/**
 * @file obuspa_interface.h
 * @brief OBUSPA interface for the usp_discovery to communicate with USP.
 */

/**
 * Add or replace controller in the obuspa, including all the MTP
 * information for the controller.
 *
 * @param Alias alias of the new controller; if controller with the same alias already
 * exists in the datamodel, it would be replaced
 * @param controller the USP controller information from the DHCP
 *
 * @return 0 if no error happened
 */
int add_or_replace_controller(const char* Alias, struct DHCPControllerInformation* controller);

/**
 * Remove controller and all the connected MTP objects (if any) from the
 * datamodel
 *
 * @param Alias alias of the controller
 *
 * @return 0 if no error happened
 */
int remove_controller(const char* Alias);

/**
 * Remove all USP controllers, configured by usp_discovery
 * The function removes all USP controllers and connected
 * MTP objects (if any) if their Alias parameter starts with
 * the 'usp_discovery' string
 *
 * @return 0 if no error happened
 */
int remove_all_controllers(void);

#ifndef IGNORE_STACK_REFERENCE
/**
 * Update stack preference to match last configured USP controller
 *
 * @param dhcp_type dhcp type of the last configured USP controller
 *
 * @return 0 if no error happened
 */
int set_stack_preference(enum DHCPType dhcp_type);
#endif

/**
 * MTP of the USP controller
 */
enum MTP {
    MTP_MQTT,
    MTP_MQTTS,
    MTP_STOMP,
    MTP_WS,
    MTP_WSS,
    MTP_Unknown
};

#endif
