/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__MOCK_DISCOPING_H__)
#define __MOCK_DISCOPING_H__

#ifdef __cplusplus
extern "C"
{
#endif

typedef void (* socket_common_reply_cb_t) (const char* ip_sender, const char* mac_sender, void* userdata);

typedef struct {
    void* userdata;
    char* my_ip;
    socket_common_reply_cb_t cb;
    amxp_timer_t* cb_timer;
} arp_socket_t;

typedef struct {
    void* userdata;
    char* my_ip;
    socket_common_reply_cb_t cb;
    amxp_timer_t* cb_timer;
} ndp_socket_t;

extern bool arp_send_fails;
extern bool nd_send_fails;
extern bool arp_fails;
extern bool nd_fails;

bool __wrap_arp_socket_new(arp_socket_t** self,
                           amxo_parser_t* odl_parser, const char* netdev_name,
                           const char* ip_from,
                           socket_common_reply_cb_t cb);

void __wrap_arp_socket_delete(arp_socket_t** self);

bool __wrap_arp_socket_send_request(arp_socket_t* self, const char* ip_from,
                                    const char* ip_to, const char* mac_to);

void __wrap_arp_socket_set_userdata(arp_socket_t** self, void* userdata);

bool __wrap_ndp_socket_new(ndp_socket_t** socket,
                           amxo_parser_t* parser,
                           const char* netdev_name,
                           const char* ip,
                           socket_common_reply_cb_t cb);

void __wrap_ndp_socket_delete(ndp_socket_t** socket);

bool __wrap_ndp_socket_send_request(ndp_socket_t* self, const char* ip_from,
                                    const char* ip_to, const char* mac_from);

void __wrap_ndp_socket_set_userdata(ndp_socket_t** self, void* userdata);

#ifdef __cplusplus
}
#endif

#endif // __MOCK_DISCOPING_H__