/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>


#include "reboot.h"
#include "reboot_time.h"

static void handle_ntp_synchronized(UNUSED const char* const event_name,
                                    const amxc_var_t* const event_data,
                                    UNUSED void* const priv) {
    double offset = 0;
    amxc_ts_t* ref_time = NULL;
    char str_ts[200] = {0};
    const char* notification_name = NULL;

    when_true(amxc_var_is_null(event_data), exit);

    notification_name = GETP_CHAR(event_data, "notification");
    when_str_empty(notification_name, exit);
    when_false(strcmp(notification_name, "NTPServerSynchronized!") == 0, exit);

    offset = amxc_var_dyncast(double, GET_ARG(event_data, "Offset"));
    ref_time = amxc_var_dyncast(amxc_ts_t, GET_ARG(event_data, "ReferenceTime"));

    SAH_TRACEZ_INFO(ME, "Event NTPServerSynchronized! received:");
    SAH_TRACEZ_INFO(ME, "    offset = %f", offset);
    if(ref_time != NULL) {
        amxc_ts_format(ref_time, str_ts, 200);
        SAH_TRACEZ_INFO(ME, "    ref_time = %s", str_ts);
    }

    reboot_dm_update_last_entry_timestamp(offset);

    // once the entry has been update, remove the subscription
    when_failed_trace(amxb_unsubscribe(amxb_be_who_has("Time."), "Time.", handle_ntp_synchronized, NULL),
                      exit, ERROR, "Failed to amxb_unsubscribe from NTPServerSynchronized! event");
exit:
    free(ref_time);
}

static void reboot_time_ntp_sync_subscribe(amxb_bus_ctx_t* time_ctx) {
    int rv = -1;

    when_null_trace(time_ctx, exit, ERROR, "No Time bus context found");
    SAH_TRACEZ_INFO(ME, "Time object available, subscribe NTP synchronizaton event");
    rv = amxb_subscribe(time_ctx, "Time.", "notification == 'NTPServerSynchronized!'", handle_ntp_synchronized, NULL);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Time subscribription failed");
    }
exit:
    return;
}

static void reboot_time_ntp_sync_subscribe_cb(UNUSED const char* signame,
                                              UNUSED const amxc_var_t* const data,
                                              UNUSED void* const priv) {

    reboot_time_ntp_sync_subscribe(amxb_be_who_has("Time."));
}

int reboot_time_ntp_sync_register(void) {
    int rv = 0;
    amxb_bus_ctx_t* time_ctx = amxb_be_who_has("Time.");

    if(time_ctx == NULL) {
        SAH_TRACEZ_INFO(ME, "Time object isn't available, wait for it");
        amxb_wait_for_object("Time.");

        rv = amxp_slot_connect_filtered(NULL, "^wait:Time\\.$", NULL, reboot_time_ntp_sync_subscribe_cb, NULL);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to wait for Time to be available");
        }
    } else {
        reboot_time_ntp_sync_subscribe(time_ctx);
    }

    return rv;
}

bool reboot_time_is_ntp_sync(void) {
    bool is_sync = false;
    amxc_var_t response;
    amxc_var_t* status;
    const char* name = NULL;
    amxb_bus_ctx_t* time_ctx = amxb_be_who_has("Time.");

    amxc_var_init(&response);

    when_null(time_ctx, exit);
    amxb_get(time_ctx, "Time.Status", 0, &response, 1);
    when_true_trace(amxc_var_is_null(&response), exit, ERROR, "Time.Status result is null");

    status = GETP_ARG(&response, "0.0.Status");
    when_null_trace(status, exit, ERROR, "Failed to parse get Status");

    name = amxc_var_constcast(cstring_t, status);
    when_str_empty_trace(name, exit, ERROR, "Time.Status is empty");
    when_false(strcmp(name, "Synchronized") == 0, exit);

    is_sync = true;

exit:
    SAH_TRACEZ_INFO(ME, "is_sync = %s", is_sync ? "true":"false");
    amxc_var_clean(&response);
    return is_sync;
}

amxc_ts_t reboot_time_subtract_offset(const amxc_ts_t ts, double offset) {
    amxc_ts_t result = ts;

    int64_t seconds = (int64_t) offset;
    int32_t nanoseconds = (int32_t) ((offset - seconds) * 1e9);

    result.sec -= seconds;
    result.nsec -= nanoseconds;

    // Handle nsec underflow/overflow by borrowing or carrying 1 second
    if(result.nsec < 0) {
        result.nsec += 1e9; // Borrow 1 second in nanoseconds
        result.sec--;       // Decrease seconds by 1
    } else if(result.nsec >= 1e9) {
        result.nsec -= 1e9; // Remove excess nanoseconds
        result.sec++;       // Increase seconds by 1
    }

    return result;
}