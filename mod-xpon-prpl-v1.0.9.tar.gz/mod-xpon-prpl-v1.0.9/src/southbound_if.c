/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "southbound_if.h"

/* System headers */
#include <string.h> /* strlen() */
#include <stdlib.h> /* atoi() */

#ifdef _DEBUG_
#include <stdio.h>  /* printf() */
#include <unistd.h> /* STDOUT_FILENO */
#endif

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* when_false() */
#include <amxb/amxb.h>        /* AMXB_FLAG_INSTANCES */

/* Own headers */
#include "amxb_wrapper.h"   /* amxb_wrap_call() */
#include "mod_xpon_trace.h"

static const int AMXB_CALL_TIMEOUT_S = 3; /* seconds */

/**
 * Construct string with dot appended.
 *
 * @param[in] path                input string
 * @param[in,out] path_with_dot   function assigns @a path to this parameter,
 *                                and it appends a dot if it does not end with a
 *                                dot yet.
 */
static void string_append_dot(const char* const path,
                              amxc_string_t* path_with_dot) {

    const size_t len = strlen(path);
    when_false(len != 0, exit);

    amxc_string_set(path_with_dot, path);

    if(path[len - 1] != '.') {
        amxc_string_append(path_with_dot, ".", 1);
    }

exit:
    return;
}

/**
 * Wrapper around amxb_call().
 *
 * @param[in] ctx        bus context
 * @param[in] path       object in prpl xpon_onu DM
 * @param[in] method     name of the function being called
 * @param[in] args       the function arguments in a amxc variant htable type.
 *                       The caller can pass NULL if @a method does not have any
 *                       arguments.
 * @param[in,out] ret    will contain the return value(s). The caller can pass
 *                       NULL if he does not expect any return value(s).
 *
 * @return true on success, else false
 */
static bool call_function_common(amxb_bus_ctx_t* ctx,
                                 const amxc_string_t* const path,
                                 const char* const method,
                                 amxc_var_t* args,
                                 amxc_var_t* ret) {
    bool rv = false;

    amxc_string_t path_dot;/* path with dot appended */
    amxc_string_init(&path_dot, 0);

    when_null_trace(ctx, exit, ERROR, "No bus context");

    const char* const path_cstr = amxc_string_get(path, 0);
    string_append_dot(path_cstr, &path_dot);
    const char* const path_dot_cstr = amxc_string_get(&path_dot, 0);

    const int rc =
        amxb_wrap_call(ctx, path_dot_cstr, method, args, ret, AMXB_CALL_TIMEOUT_S);
    when_failed_trace(rc, exit, ERROR, "amxb_call %s%s() failed: rc=%d",
                      path_dot_cstr, method, rc);

    rv = true;
exit:
    amxc_string_clean(&path_dot);
    return rv;
}



/**
 * Call enable() or disable() for a prpl xpon_onu object.
 *
 * @param[in] ctx     bus context
 * @param[in] path    object in prpl xpon_onu DM to call enable() or disable() on
 * @param[in] enable  if true, call enable(), else call disable().
 *
 * Examples for @a prpl_path:
 * - "xpon_onu.2"
 * - "xpon_onu.1.ani.1"
 *
 * @return true on success, else false
 */
bool sbi_enable(amxb_bus_ctx_t* ctx,
                const amxc_string_t* const path,
                bool enable) {

    const char* const method = enable ? "enable" : "disable";

    SAH_TRACEZ_DEBUG(ME, "path='%s' enable=%d", amxc_string_get(path, 0), enable);

    return call_function_common(ctx, path, method, /*args=*/ NULL, /*ret=*/ NULL);
}

#ifdef _DEBUG_
static void dump_param_values(const char* const func_name,
                              const amxc_string_t* const path,
                              const amxc_var_t* const param_values) {

    const char* const path_cstr = amxc_string_get(path, 0);
    printf("mod_xpon_prpl: %s.%s(): dump(param_values):\n", path_cstr, func_name);
    amxc_var_dump(param_values, STDOUT_FILENO);
}
#endif

/**
 * Call get() on a prpl xpon_onu object to get the values of its params.
 *
 * @param[in] ctx               bus context
 * @param[in] path              object in prpl xpon_onu DM to call get() on
 * @param[in,out] param_values  function returns param values via this parameter
 *
 * Example:
 * xpon_onu.1.ani.1.tc.onu_activation.get() returns:
 *   {
 *       onu_id = 1,
 *       onu_state = "O2",
 *       serial_number = "ABCD12345678"
 *       vendor_id = "XYZ1",
 *   }
 *
 * Note - the values are some test values, and do not come from a real setup.
 *
 * @return true on success, else false
 */
bool sbi_query_object(amxb_bus_ctx_t* ctx,
                      const amxc_string_t* const path,
                      amxc_var_t* const param_values) {

    const bool rv = call_function_common(ctx, path, "get", /*args=*/ NULL, param_values);

#ifdef _DEBUG_
    if(rv) {
        dump_param_values("query_object", path, param_values);
    }
#endif
    return rv;
}

/**
 * Call get_params() on a prpl xpon_onu object to get certain param values.
 *
 * @param[in] ctx               bus context
 * @param[in] path              object in prpl xpon_onu DM to call get_params() on
 * @param[in] names             list of param names to be queried, formatted as
 *                              a comma-separated list.
 * @param[in,out] param_values  function returns param values via this parameter
 *
 * Example:
 * xpon_onu.1.ani.1.transceiver.1.get_params("rx_power") returns:
 *   {
 *       rx_power = -18123
 *   }
 *
 * Note - the value is some test value, and does not come from a real setup.
 *
 * @return true on success, else false
 */
bool sbi_query_params(amxb_bus_ctx_t* ctx,
                      const amxc_string_t* const path,
                      const char* const names,
                      amxc_var_t* const param_values) {

    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "names", names);

    const bool rv = call_function_common(ctx, path, "get_params", &args, param_values);

#ifdef _DEBUG_
    if(rv) {
        dump_param_values("query_params", path, param_values);
    }
#endif

    amxc_var_clean(&args);
    return rv;
}

/**
 * Structure to help querying the instances of a template object.
 *
 * - path: path to a template object in the prpl xpon_onu DM. It has a dot at
 *         the end. E.g. "xpon_onu.1.software_image.".
 * - path_len: set to strlen(path)
 * - indexes: this module adds indexes of the instances of the template object
 *            idenfified by 'path' to this member. It's formatted as a
 *            comma-separated integers, e.g. "1,2".
 */
typedef struct _instances_info {
    const char* path;
    const size_t path_len;
    amxc_string_t* const indexes;
} instances_info_t;

/**
 * Character classification function.
 *
 * @param[in] c: a single character
 *
 * @return true if @a c is a dot, else false
 */
static int string_strip_dot(int c) {
    if(c == '.') {
        return 1;
    } else {
        return 0;
    }
}

/**
 * Callback function for the amxb_list() call done by sbi_get_instances().
 *
 * @param[in] bus_ctx: bus context
 * @param[in] data: one element/node found by the amxb_list() call or NULL if
 *                  amxb_list() no longer finds any elements/nodes
 * @param[in,out] priv: pointer to instance of type 'instances_info_t'. The
 *                      function adds max 1 instance to the member 'indexes'
 *                      upon each invocation
 *
 * If the module calls amxb_list() for "xpon_onu.1.ani.", this function is
 * called multiple times with following values for the string in the 1st element
 * in the list in 'data' (assuming there is 1 GEM port and 1 transceiver):
 * - "xpon_onu.1.ani.1."
 * - "xpon_onu.1.ani.1.tc.alarms."
 * - "xpon_onu.1.ani.1.tc.gem.port.1."
 * - "xpon_onu.1.ani.1.tc.gem.port.1.pm."
 * - "xpon_onu.1.ani.1.tc.onu_activation."
 * - "xpon_onu.1.ani.1.tc.performance_thresholds."
 * - "xpon_onu.1.ani.1.tc.pm.gem."
 * - "xpon_onu.1.ani.1.tc.pm.omci."
 * - "xpon_onu.1.ani.1.tc.pm.phy."
 * - "xpon_onu.1.ani.1.tc.pm.ploam."
 * - "xpon_onu.1.ani.1.transceiver.1."
 * And then it's called one time with data == NULL. Based on those results,
 * the module must determine that "xpon_onu.1.ani." has 1 instance with index 1.
 */
static void list_cb(UNUSED const amxb_bus_ctx_t* bus_ctx,
                    const amxc_var_t* const data,
                    void* priv) {

    amxc_llist_t* list = NULL;
    amxc_string_t instance_str;
    amxc_string_t index_str;

    amxc_string_init(&instance_str, 0);
    amxc_string_init(&index_str, 0);

    when_null(priv, exit);

#ifdef _DEBUG_
    printf("list_cb()\n");
    amxc_var_dump(data, STDOUT_FILENO);
#endif

    instances_info_t* const info = (instances_info_t* const) priv;
    when_null_trace(data, exit, DEBUG, "%s: no (more) data", info->path);
    const amxc_var_type_id_t type_id = amxc_var_type_of(data);
    when_false_trace(AMXC_VAR_ID_LIST == type_id, exit, ERROR, "Not a list");
    list = amxc_var_dyncast(amxc_llist_t, data);
    when_true_trace(amxc_llist_is_empty(list), exit, DEBUG,
                    "%s: empty list", info->path);
    const amxc_var_t* const first = amxc_var_get_first(data);
    when_null_trace(first, exit, ERROR, "Failed to get first elem");
    const char* const instance = amxc_var_constcast(cstring_t, first);
    SAH_TRACEZ_DEBUG2(ME, "instance='%s'", instance);
    amxc_string_setf(&instance_str, "%s", instance);
    amxc_string_trimr(&instance_str, string_strip_dot);
    const size_t instance_len = amxc_string_text_length(&instance_str);
    when_false_trace(instance_len > info->path_len, exit, ERROR,
                     "instance_len [%zd] <= path_len [%zd]", instance_len,
                     info->path_len);
    const char* const instance_index = amxc_string_get(&instance_str, info->path_len);
    amxc_string_setf(&index_str, "%s", instance_index);
    SAH_TRACEZ_DEBUG2(ME, "instance_index='%s'", instance_index);
    when_false_trace(amxc_string_is_numeric(&index_str), exit, DEBUG,
                     "%s: index_str='%s' is not numeric: ignore", info->path, instance_index);
    const int index = atoi(instance_index);
    SAH_TRACEZ_DEBUG(ME, "%s: instance with index=%d found", info->path, index);
    if(amxc_string_is_empty(info->indexes)) {
        amxc_string_appendf(info->indexes, "%d", index);
    } else {
        amxc_string_appendf(info->indexes, ",%d", index);
    }

exit:
    if(list) {
        amxc_llist_delete(&list, variant_list_it_free);
    }
    amxc_string_clean(&instance_str);
    amxc_string_clean(&index_str);
}

/**
 * Query which instances exist for a template object.
 *
 * @param[in] ctx: bus context
 * @param[in] path: path to a template object in the prpl xpon_onu DM, e.g.
 *                  "xpon_onu.1.software_image".
 * @param[in,out] indexes: function returns list of instances via this
 *                         parameter, formatted as comma-separated integers.
 *                         See below for an example.
 *
 * Example:
 * if the function finds out that xpon_onu.1.software_image has the instances:
 * - xpon_onu.1.software_image.1 and
 * - xpon_onu.1.software_image.2,
 * it assigns "1,2" to @a indexes.
 *
 * @return true on success, else false
 */
bool sbi_get_instances(amxb_bus_ctx_t* ctx,
                       const char* const path,
                       amxc_string_t* const indexes) {

    bool rv = false;
    amxc_string_t path_dot;/* path with dot appended */
    amxc_string_init(&path_dot, 0);

    when_null(ctx, exit);
    when_null(path, exit);
    when_null(indexes, exit);

    string_append_dot(path, &path_dot);
    const char* const path_dot_cstr = amxc_string_get(&path_dot, 0);

    instances_info_t info = {
        .path = path_dot_cstr,
        .path_len = strlen(path_dot_cstr),
        .indexes = indexes
    };
    const int rc =
        amxb_wrap_list(ctx, path_dot_cstr, AMXB_FLAG_INSTANCES, list_cb, &info);
    if(amxc_string_text_length(indexes) != 0) {
        when_failed_trace(rc, exit, ERROR, "%s: amxb_list() failed: rc=%d",
                          path, rc);
    } else {
        /**
         * TODO amxb_list() returns error 4 (= amxd_status_parameter_not_found)
         * when it can not find any instances. A more sensible error is
         * amxd_status_object_not_found. It returns 4 because ubus_lookup() returns
         * 4 = UBUS_STATUS_NOT_FOUND and because it does not convert that to an
         * amxd_status_t value. See ST-1573 (amxb_list() returns unexpected
         * value for nonexistent object for ubus as back end).
         * Therefore for now only return an error if rc == -1 or if
         * rc == amxd_status_unknown_error. If ST-1573 is fixed, the statement
         * below should become:
         *
         * when_true_trace(rc != amxd_status_object_not_found, exit, ERROR,
         *                 "%s: amxb_list() failed: rc=%d", path, rc);
         */
        when_true_trace((-1 == rc) || (amxd_status_unknown_error == rc), exit,
                        ERROR, "%s: amxb_list() failed: rc=%d", path, rc);
    }
    rv = true;

exit:
    amxc_string_clean(&path_dot);
    return rv;
}

/**
 * Change the power state of an ONU.
 *
 * @param[in] ctx: bus context
 * @param[in] path: path to an ONU, e.g. "xpon_onu.1"
 * @param[in] call_id:  unique ID to identify this change_power_mode() call
 * @param[in] power_state: requested power state ("On", "Off", or "LowPower")
 * @param[in] timeout_ms: timeout in milliseconds within which tr181-xpon
 *     expects a reply via set_change_power_mode_result() (see
 *     handle_change_power_mode_result()).
 *
 * @return true on success, else false
 */
bool sbi_change_power_mode(amxb_bus_ctx_t* ctx,
                           const amxc_string_t* const path,
                           uint32_t call_id,
                           const char* const power_state,
                           uint32_t timeout_ms) {
    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, &args, "call_id", call_id);
    amxc_var_add_key(cstring_t, &args, "power_state", power_state);
    amxc_var_add_key(uint32_t, &args, "timeout_ms", timeout_ms);
    const char* const path_cstr = amxc_string_get(path, 0);
    SAH_TRACEZ_DEBUG(ME, "path='%s' call_id=%u power_state=%s timeout_ms=%u",
                     path_cstr, call_id, power_state, timeout_ms);

    const bool rv = call_function_common(ctx, path, "change_power_mode", &args, /*ret=*/ NULL);

    amxc_var_clean(&args);
    return rv;
}

