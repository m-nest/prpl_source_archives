/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdbool.h>
#include "tr181-temperature.h"
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ME "tmp_alm"

static void emit_alarm_signal(bool cond, bool overheat) {
    amxd_object_t* obj = NULL;
    amxc_var_t data;

    amxc_var_init(&data);
    obj = amxd_dm_findf(get_dm(), "TemperatureStatus.");
    when_null_trace(obj, exit, ERROR, "Couldn't find Temperature. object.");
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &data, "Status", cond);
    overheat ? amxd_object_emit_signal(obj, "HighTemperatureAlarm!", &data) : amxd_object_emit_signal(obj, "LowTemperatureAlarm!", &data);

exit:
    amxc_var_clean(&data);
}

static void handle_signals(bool onoff, bool overheat) {
    uint32_t sensors = overheat ? get_overheated_sensors() : get_underheated_sensors();

    if(onoff) {
        if(sensors == 0) {
            emit_alarm_signal(true, overheat);
        }
        sensors += 1;
    } else {
        if(sensors == 0) {
            return;
        }
        sensors -= 1;
        if(sensors == 0) {
            emit_alarm_signal(false, overheat);
        }
    }
    overheat ? set_overheated_sensors(sensors) : set_underheated_sensors(sensors);
}

static void tempsensor_handle_high_alarms(tempsensor_info_t* info) {
    if((info->high_alarm_value == get_bad_temp()) || (info->alarm_enabled == false)) {
        return;
    }

    if((info->value > info->high_alarm_value) && (info->high_alarm_state == false)) {
        info->high_hysteresis += 1;
        if(info->high_hysteresis >= (int32_t) get_hysteresis()) {
            info->high_alarm_state = true;
            handle_signals(true, true);
        }
    }
    if((info->value < info->high_alarm_value) && (info->high_alarm_state == true)) {
        info->high_hysteresis -= 1;
        if(info->high_hysteresis <= 0) {
            info->high_alarm_state = false;
            handle_signals(false, true);
        }
    }
}

static void tempsensor_handle_low_alarms(tempsensor_info_t* info) {
    if((info->low_alarm_value == get_bad_temp()) || (info->alarm_enabled == false)) {
        return;
    }

    if((info->value < info->low_alarm_value) && (info->low_alarm_state == false)) {
        info->low_hysteresis += 1;
        if(info->low_hysteresis >= (int32_t) get_hysteresis()) {
            info->low_alarm_state = true;
            handle_signals(true, false);
        }
    }
    if((info->value > info->low_alarm_value) && (info->low_alarm_state == true)) {
        info->low_hysteresis -= 1;
        if(info->low_hysteresis <= 0) {
            info->low_alarm_state = false;
            handle_signals(false, false);
        }
    }
}

void tempsensor_handle_alarms(tempsensor_info_t* info) {
    tempsensor_handle_high_alarms(info);
    tempsensor_handle_low_alarms(info);
}

void tempsensor_high_alarm_reset(tempsensor_info_t* info) {
    if(info->high_alarm_state) {
        handle_signals(false, true);
        info->high_alarm_state = false;
    }
}

void tempsensor_low_alarm_reset(tempsensor_info_t* info) {
    if(info->low_alarm_state) {
        handle_signals(false, false);
        info->low_alarm_state = false;
    }
}
