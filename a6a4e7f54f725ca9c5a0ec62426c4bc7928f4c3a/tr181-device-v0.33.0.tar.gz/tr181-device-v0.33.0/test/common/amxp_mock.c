/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>

#include "amxp_mock.h"

static amxc_string_t* amxp_cmd = NULL;
static amxc_string_t* expected_cmd = NULL;

void expect_factory_reset_command(const char* expected_string) {
    if(expected_cmd == NULL) {
        amxc_string_new(&expected_cmd, 0);
    }
    amxc_string_clean(expected_cmd);
    if(expected_string != NULL) {
        amxc_string_setf(expected_cmd, "%s", expected_string);
    }
}

int amxp_subproc_vstart_wait(UNUSED amxp_subproc_t* subproc, UNUSED int timeout_msec, char** cmd) {
    int rv = -1;
    size_t i = 0;

    if(amxp_cmd == NULL) {
        amxc_string_new(&amxp_cmd, 0);
    }
    amxc_string_clean(amxp_cmd);

    when_null(cmd, exit);
    when_null(*cmd, exit);

    // By convention, the first argument is always the executable name
    amxc_string_appendf(amxp_cmd, "%s", cmd[0]);

    i = 1;
    while(cmd[i] != NULL) {
        amxc_string_appendf(amxp_cmd, " %s", cmd[i]);
        i++;
    }

    rv = 0;
exit:
    return rv;
}

int amxp_subproc_get_exitstatus(UNUSED amxp_subproc_t* subproc) {
    assert_string_equal(amxc_string_get(expected_cmd, 0), amxc_string_get(amxp_cmd, 0));
    return 0;
}

void amxp_mock_cleanup(void) {
    amxc_string_delete(&expected_cmd);
    amxc_string_delete(&amxp_cmd);
}