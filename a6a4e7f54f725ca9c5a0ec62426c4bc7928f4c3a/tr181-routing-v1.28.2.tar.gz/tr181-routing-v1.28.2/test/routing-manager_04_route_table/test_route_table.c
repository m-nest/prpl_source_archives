/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_route_table.h"
#include "routing_table.h"
#include "test_utils.h"

#include <stdlib.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>

static cstring_t get_rt_table_entry(int32_t table_id) {
    cstring_t table_name = NULL;
    FILE* fp = fopen("rt_tables", "r+");
    char line[256] = {0};

    assert_non_null(fp);
    while(fgets(line, sizeof(line), fp) != NULL) {
        int existing_table_id = -1;
        char existing_table_name[256] = {0};

        if(sscanf(line, "%d %255s", &existing_table_id, existing_table_name) == 2) {
            if(existing_table_id == table_id) {
                table_name = strdup(existing_table_name);
                break;
            }
        }
    }
    return table_name;
}

static void check_route_entry(uint32_t id, const cstring_t exp_name) {
    cstring_t table_name = get_rt_table_entry(id);

    if(exp_name == NULL) {
        assert_null(table_name);
    } else {
        assert_string_equal(table_name, exp_name);
    }
    free(table_name);
}

static amxd_object_t* add_route_table(const cstring_t alias, const cstring_t table_name, uint32_t table_id) {
    amxd_trans_t trans;
    amxd_dm_t* dm = NULL;
    amxd_object_t* router = NULL;

    dm = test_get_dm();
    router = amxd_dm_findf(dm, "Routing.Router.");
    assert_non_null(router);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, router);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(&trans, 0, NULL);

    amxd_trans_set_value(cstring_t, &trans, "Alias", alias);
    amxd_trans_set_value(cstring_t, &trans, "Name", table_name);
    amxd_trans_set_value(uint32_t, &trans, "ID", table_id);
    amxd_trans_set_value(bool, &trans, "Enable", 1);
    assert_int_equal(amxd_trans_apply(&trans, dm), amxd_status_ok);

    amxd_trans_clean(&trans);

    return amxd_dm_findf(dm, "Routing.Router.[Alias == '%s']", alias);
}

void test_add_route_entries(UNUSED void** state) {
    init_rt_tables();
    assert_int_equal(set_rt_table_entry(1, "my_route_table"), 0);
    check_route_entry(1, "my_route_table");

    assert_int_equal(set_rt_table_entry(1, "my_updated_table"), 0);
    check_route_entry(1, "my_updated_table");

    assert_int_equal(del_rt_table_entry(1), 0);
    check_route_entry(1, NULL);

    // check that function returns correctly for non-existing table id
    assert_int_equal(del_rt_table_entry(1), 0);

    assert_int_equal(set_rt_table_entry(254, "new_main"), -1);
    check_route_entry(254, "main");

    del_rt_tables();
}

void test_validate_route_entries(UNUSED void** state) {
    assert_true(is_valid_rt_table_entry(1, "my_route_table"));
    assert_true(is_valid_rt_table_entry(119, "another_route_table"));
    assert_true(is_valid_rt_table_entry(128, "prelocal"));

    assert_false(is_valid_rt_table_entry(253, "definitely_not_default"));
    assert_false(is_valid_rt_table_entry(255, "prelocal"));
    assert_false(is_valid_rt_table_entry(1, "local"));
}

void test_add_route_table(UNUSED void** state) {
    amxd_object_t* route_table = NULL;
    amxd_trans_t trans;
    amxd_dm_t* dm = NULL;

    amxd_trans_init(&trans);

    init_rt_tables();
    dm = test_get_dm();
    route_table = add_route_table("my_table", "my_table", 42);
    assert_non_null(route_table);
    test_handle_events();

    check_route_entry(42, "my_table");

    amxd_trans_select_object(&trans, route_table);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_value(cstring_t, &trans, "Name", "my_other_table");
    assert_int_equal(amxd_trans_apply(&trans, dm), amxd_status_ok);
    amxd_trans_clean(&trans);
    test_handle_events();

    check_route_entry(42, "my_other_table");

    amxd_trans_select_pathf(&trans, "Routing.Router.");
    amxd_trans_del_inst(&trans, 0, "my_table");
    assert_int_equal(amxd_trans_apply(&trans, dm), amxd_status_ok);
    amxd_trans_clean(&trans);
    test_handle_events();

    check_route_entry(42, NULL);
    del_rt_tables();
}

