/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "test_promise.h"

static uint32_t number = 100;
static amxc_var_t data;

static amxp_promise_t* chain_step(amxp_promise_t* chained,
                                  amxp_promise_t* current,
                                  UNUSED amxc_var_t* output,
                                  void* const provider_priv) {
    check_expected(provider_priv);
    function_called();

    amxp_promise_t* p1 = NULL;
    assert_true(amxp_promise_is_pending(chained));
    if(current != NULL) {
        assert_true(amxp_promise_is_fulfilled(current));
    }
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), AMXP_PROMISE_STATUS_OK);
    assert_true(amxp_promise_is_pending(p1));
    return p1;
}

static amxp_promise_t* chain_step_reject(amxp_promise_t* chained,
                                         UNUSED amxp_promise_t* current,
                                         UNUSED amxc_var_t* output,
                                         UNUSED void* const provider_priv) {

    // a step should not reject or fulfill a chained promise in this way.
    // but the promise implementation should be able to handle it.

    // when calling amxp_promise_reject on the chained promise, an error must be returned
    assert_int_equal(amxp_promise_reject(chained, 101), AMXP_PROMISE_STATUS_NOT_SUPPORTED);
    // return NULL to abort the chain
    return NULL;
}

static amxp_promise_t* chain_step_fulfill(amxp_promise_t* chained,
                                          UNUSED amxp_promise_t* current,
                                          UNUSED amxc_var_t* output,
                                          UNUSED void* const provider_priv) {

    // a step should not reject or fulfill a chained promise in this way.
    // but the promise implementation should be able to handle it.

    // when calling amxp_promise_reject on the chained promise, an error must be returned
    assert_int_equal(amxp_promise_fulfill(chained, NULL), AMXP_PROMISE_STATUS_NOT_SUPPORTED);
    // return NULL to abort the chain
    return NULL;
}

static amxp_promise_t* chain_step_null(UNUSED amxp_promise_t* chained,
                                       UNUSED amxp_promise_t* current,
                                       UNUSED amxc_var_t* output,
                                       UNUSED void* const provider_priv) {
    // returning NULL will abort the chain
    return NULL;
}

static amxp_promise_t* chain_step_fulfilled(amxp_promise_t* chained,
                                            amxp_promise_t* current,
                                            UNUSED amxc_var_t* output,
                                            void* const provider_priv) {
    check_expected(provider_priv);
    function_called();

    amxp_promise_t* p1 = NULL;
    assert_true(amxp_promise_is_pending(chained));
    if(current != NULL) {
        assert_true(amxp_promise_is_fulfilled(current));
    }
    amxp_promise_new(&p1, cancel_callback, NULL, NULL);
    amxp_promise_fulfill(p1, NULL);
    assert_true(amxp_promise_is_fulfilled(p1));
    return p1;
}

static amxp_promise_t* chain_step_never_settles(amxp_promise_t* chained,
                                                UNUSED amxp_promise_t* current,
                                                UNUSED amxc_var_t* output,
                                                void* const provider_priv) {
    check_expected(provider_priv);
    function_called();

    amxp_promise_t* p1 = NULL;
    assert_true(amxp_promise_is_pending(chained));
    amxp_promise_new(&p1, cancel_callback, NULL, NULL);
    assert_true(amxp_promise_is_pending(p1));

    return p1;
}

static amxp_promise_t* chain_step_fulfilled_with_data(amxp_promise_t* chained,
                                                      amxp_promise_t* current,
                                                      UNUSED amxc_var_t* output,
                                                      void* const provider_priv) {
    check_expected(provider_priv);
    function_called();

    amxp_promise_t* p1 = NULL;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "Field1", "Hello");
    amxc_var_add_key(cstring_t, &data, "Field2", "Hello");
    amxc_var_add_key(uint32_t, &data, "Field3", 101);

    assert_true(amxp_promise_is_pending(chained));
    if(current != NULL) {
        assert_true(amxp_promise_is_fulfilled(current));
    }

    amxp_promise_new(&p1, cancel_callback, NULL, NULL);
    amxp_promise_fulfill(p1, &data);
    assert_true(amxp_promise_is_fulfilled(p1));
    return p1;
}

static amxp_promise_t* chain_step_rejected(amxp_promise_t* chained,
                                           amxp_promise_t* current,
                                           UNUSED amxc_var_t* output,
                                           void* const provider_priv) {
    check_expected(provider_priv);
    function_called();

    amxp_promise_t* p1 = NULL;
    assert_true(amxp_promise_is_pending(chained));
    if(current != NULL) {
        assert_true(amxp_promise_is_fulfilled(current));
    }
    amxp_promise_new(&p1, cancel_callback, NULL, NULL);
    amxp_promise_reject(p1, 101);
    assert_true(amxp_promise_is_rejected(p1));
    return p1;
}

static amxp_promise_t* chain_step_returns_chained(amxp_promise_t* chained,
                                                  UNUSED amxp_promise_t* current,
                                                  UNUSED amxc_var_t* output,
                                                  UNUSED void* const provider_priv) {
    function_called();
    return chained; // return the chained promise, this will cause the chain to be aborted
}


static amxp_promise_t* chain_step_waitable(UNUSED amxp_promise_t* chained,
                                           UNUSED amxp_promise_t* current,
                                           UNUSED amxc_var_t* output,
                                           UNUSED void* const provider_priv) {
    amxp_promise_t* next = NULL;
    printf("=> function called -> chain_step_waitable\n");
    fflush(stdout);
    function_called();
    assert_int_equal(amxp_promise_new(&next, cancel_callback, wait_fulfill, provider_priv), AMXP_PROMISE_STATUS_OK);
    assert_non_null(next);
    assert_true(amxp_promise_is_pending(next));
    return next;
}

static void chain_final(amxp_promise_t* chained,
                        amxp_promise_t* current,
                        UNUSED amxc_var_t* output,
                        void* const provider_priv) {
    function_called();
    check_expected(provider_priv);

    assert_true(amxp_promise_is_pending(chained) ||
                amxp_promise_get_status(chained) == AMXP_PROMISE_STATUS_CANCELED ||
                amxp_promise_get_status(chained) == AMXP_PROMISE_STATUS_TIMEOUT);
    if(current != NULL) {
        assert_true(amxp_promise_is_settled(current));
    }
}

static void chain_final_set_future(amxp_promise_t* chained,
                                   amxp_promise_t* current,
                                   amxc_var_t* output,
                                   void* const provider_priv) {
    function_called();
    check_expected(provider_priv);

    assert_true(amxp_promise_is_pending(chained));
    if(current != NULL) {
        assert_true(amxp_promise_is_settled(current));
    }

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "Field3", "WWW");
    amxc_var_add_key(cstring_t, &data, "Field4", "XXX");
    amxc_var_add_key(uint32_t, &data, "Field5", 666);

    amxc_var_copy(output, &data);
}

int test_promise_chain_setup(void** state) {
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, chain_final, &number,
                                              /* build the chain here */
                                              chain_step,
                                              chain_step,
                                              chain_step,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps
    (*state) = p1;

    return 0;
}

int test_promise_chain_teardown(void** state) {
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);

    if(amxp_promise_is_pending(p1)) {
        // if the promise is still in pending state
        // the current step must be canceled when the chained promise is deleted
        expect_function_call(cancel_callback);
        expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
        expect_value(cancel_callback, promise, p1->info.chained.current);
        expect_value(cancel_callback, provider_priv, NULL);
        // and the final must be called
        expect_function_call(chain_final);
        expect_value(chain_final, provider_priv, &number);
    }

    amxp_promise_delete(&p1);
    return 0;
}

void test_chained_promise_is_pending_after_creation(void** state) {
    // when a chained promise is created (see test_promise_chain_setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);
    // and at least one step is in pending state, it is in pending state
    assert_true(amxp_promise_is_pending(p1));
    assert_false(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
}

void test_chained_promise_deletion_calls_rejected_callback(void** state) {
    // when a chained promise is created (see test_promise_chain_setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);

    // and a rejected callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // it must call the rejected callback function when deleted
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(rejected_callback, promise, p1);

    //it must call the cancel callback of the promise of the current step
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1->info.chained.current);
    expect_value(cancel_callback, provider_priv, NULL);

    // the final must be called
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);

    amxp_promise_delete(&p1);
}

void test_chained_promise_is_fulfilled_after_creation_if_all_steps_are_fulfilled(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are fulfilled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, chain_final, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_is_rejected_after_creation_if_one_step_is_rejected(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    // if a step is rejected immediately the chain is rejected
    // all functions in chain are called until the rejected
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_rejected);
    expect_value(chain_step_rejected, provider_priv, &number);
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, chain_final, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_rejected,
                                              chain_step_fulfilled,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_is_watching_current_promise(void** state) {
    // when a chained promise is created (see test setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);

    // then the promise struct should contain the current promise it is watching
    // the final function is set as well.
    // note: as this is a test, accessing the internal data for test verification
    //       and correctness of the internal state.
    assert_non_null(p1->info.chained.current);
    assert_ptr_equal(p1->info.chained.final, chain_final);
}

void test_chained_promise_can_get_fulfilled(void** state) {
    // when a chained promise is created (see test setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);
    amxp_promise_t* current = p1->info.chained.current;

    // and resolving all intermediate promises
    // the chain step functions must be called in this order
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);
    while(current != NULL) {
        assert_true(amxp_promise_is_pending(p1));
        assert_int_equal(amxp_promise_fulfill(current, NULL), AMXP_PROMISE_STATUS_OK);
        assert_ptr_not_equal(current, p1->info.chained.current);
        current = p1->info.chained.current;
    }

    // the chained must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));
}

void test_chained_promise_can_get_rejected(void** state) {
    // when a chained promise is created (see test setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);
    amxp_promise_t* current = p1->info.chained.current;

    // and resolving some intermediate promises
    // the chain step functions must be called in this order
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    assert_int_equal(amxp_promise_fulfill(current, NULL), AMXP_PROMISE_STATUS_OK);
    assert_ptr_not_equal(current, p1->info.chained.current);
    assert_true(amxp_promise_is_pending(p1));
    current = p1->info.chained.current;
    // and rejecting the next step
    assert_int_equal(amxp_promise_reject(current, 101), AMXP_PROMISE_STATUS_OK);
    assert_null(p1->info.chained.current);

    // the chained must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
}

void test_chained_promise_can_be_created_without_final_fulfilled(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are fulfilled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_can_be_created_without_final_rejected(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are settled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_rejected);
    expect_value(chain_step_rejected, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_rejected,
                                              chain_step_fulfilled,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_takes_future_of_last_step_if_not_set_in_steps(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    int result = 0;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are fulfilled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled_with_data);
    expect_value(chain_step_fulfilled_with_data, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                                              chain_step_fulfilled_with_data,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));
    amxc_var_compare(&data, amxp_promise_get_future(p1), &result);
    assert_int_equal(result, 0);

    amxc_var_clean(&data);
    amxp_promise_delete(&p1);
}

void test_chained_promise_does_not_change_future_if_already_set(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    int result = 0;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are fulfilled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_final_set_future);
    expect_value(chain_final_set_future, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained(&p1, chain_final_set_future, &number,
                                              /* build the chain here */
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                                              chain_step_fulfilled,
                         /* terminate the chain*/
                                              NULL),
                     3); // returns the number of chained steps

    // the chained promise must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));
    amxc_var_compare(&data, amxp_promise_get_future(p1), &result);
    assert_int_equal(result, 0);

    amxc_var_clean(&data);
    amxp_promise_delete(&p1);
}

void test_chained_promise_calls_callback_when_fulfilled(void** state) {
    // when a chained promise is created (see test_promise_chain_setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);
    amxp_promise_t* current = p1->info.chained.current;

    // and a fulfilled callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // and resolving all intermediate promises
    // the chain step functions must be called in this order
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);
    // it must call the fulfilled callback function when fulfilled
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, p1);

    while(current != NULL) {
        assert_true(amxp_promise_is_pending(p1));
        assert_int_equal(amxp_promise_fulfill(current, NULL), AMXP_PROMISE_STATUS_OK);
        assert_ptr_not_equal(current, p1->info.chained.current);
        current = p1->info.chained.current;
    }
}

void test_chained_promise_step_can_not_fulfill_chained_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_fulfill,
                                              chain_step,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps

    // the step "chain_step_fulfill" tries to fulfill the promise
    // and returns a NULL pointer as the next promise which aborts the chain
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_step_can_not_reject_chained_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_reject,
                                              chain_step,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps

    // the step "chain_step_reject" tries to reject the promise
    // and returns a NULL pointer as the next promise which aborts the chain
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_step_can_abort_chained_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_null,
                                              chain_step,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps

    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_create_using_array(UNUSED void** state) {
    amxp_promise_chain_fn_t steps[3] = { chain_step_fulfilled, chain_step_fulfilled, chain_step_fulfilled };
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise, it will start the chain
    // if all intermediate steps are fulfilled immediately
    // all functions in chain are called including the final
    // they must all get the correct provider priv
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, &number);
    assert_int_equal(amxp_promise_new_chained_array(&p1, NULL, &number, 3, steps), 3); // returns the number of chained steps

    // the chained promise must be fulfilled
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_create_must_fail_when_no_steps_provided(UNUSED void** state) {
    amxp_promise_chain_fn_t steps[3] = { NULL, NULL, NULL };
    amxp_promise_t* p1 = NULL;

    // when creating a chained promise with no steps it must fail
    assert_int_equal(amxp_promise_new_chained_array(&p1, NULL, &number, 3, steps), -1);
    assert_null(p1);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, &number, NULL), -1);
    assert_null(p1);

    amxp_promise_delete(&p1);
}

void test_chained_promise_api_can_handle_null_pointers_as_input(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxp_promise_chain_fn_t steps[3] = { chain_step_fulfilled, chain_step_fulfilled, chain_step_fulfilled };

    assert_int_equal(amxp_promise_new_chained_array(NULL, NULL, NULL, 0, NULL), -1);
    assert_int_equal(amxp_promise_new_chained_array(&p1, NULL, NULL, 10, NULL), -1);
    assert_int_equal(amxp_promise_new_chained_array(&p1, NULL, NULL, 0, steps), -1);
    assert_int_equal(amxp_promise_new_chained(NULL, NULL, NULL, NULL), -1);
}

void test_chained_promise_rejected_fails_from_external_source(void** state) {
    // when a chained promise is created (see test_promise_chain_setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);

    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_NOT_SUPPORTED);
}

void test_chained_promise_is_automatically_rejected_after_timeout(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxp_promise_chain_fn_t steps[3] = { chain_step_fulfilled, chain_step_never_settles, chain_step_fulfilled };

    // when a promise is created
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, NULL);
    expect_function_call(chain_step_never_settles);
    expect_value(chain_step_never_settles, provider_priv, NULL);
    assert_int_equal(amxp_promise_new_chained_array(&p1, NULL, NULL, 3, steps), 3);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(p1, 1000), AMXP_PROMISE_STATUS_OK);
    // a timer must be set on the promise
    assert_non_null(p1->reject_timer);

    // the promise is rejected if not settled within the given time
    // and the rejected callback is expected to be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(rejected_callback, promise, p1);

    // and the current pending is canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1->info.chained.current);
    expect_value(cancel_callback, provider_priv, NULL);

    // emulate event-loop and watch SIGALRM
    read_sigalrm();
    // and the timer is deleted
    assert_null(p1->reject_timer);

    // after the timeout the promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));

    // and the status is set to timeout
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_TIMEOUT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_is_automatically_rejected_after_timeout_and_final_is_called(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxp_promise_chain_fn_t steps[3] = { chain_step_fulfilled, chain_step_never_settles, chain_step_fulfilled };

    // when a promise is created
    expect_function_call(chain_step_fulfilled);
    expect_value(chain_step_fulfilled, provider_priv, NULL);
    expect_function_call(chain_step_never_settles);
    expect_value(chain_step_never_settles, provider_priv, NULL);
    assert_int_equal(amxp_promise_new_chained_array(&p1, chain_final, NULL, 3, steps), 3);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(p1, 1000), AMXP_PROMISE_STATUS_OK);
    // a timer must be set on the promise
    assert_non_null(p1->reject_timer);

    // the promise is rejected if not settled within the given time

    // the rejected callback is expected to be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(rejected_callback, promise, p1);

    // the current pending is canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1->info.chained.current);
    expect_value(cancel_callback, provider_priv, NULL);

    // the final must be called
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, NULL);

    // emulate event-loop and watch SIGALRM
    read_sigalrm();
    // and the timer is deleted
    assert_null(p1->reject_timer);

    // after the timeout the promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));

    // and the status is set to timeout
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_TIMEOUT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_gets_aborted_if_chained_promise_is_returned_by_step(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxp_promise_t* current = NULL;

    // when a promise is created
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, NULL);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step,
                                              chain_step_returns_chained,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps

    // and one of the steps return the chained promise
    expect_function_call(chain_step_returns_chained);
    current = p1->info.chained.current;
    while(current != NULL) {
        assert_true(amxp_promise_is_pending(p1));
        assert_int_equal(amxp_promise_fulfill(current, NULL), AMXP_PROMISE_STATUS_OK);
        assert_ptr_not_equal(current, p1->info.chained.current);
        current = p1->info.chained.current;
    }

    // then the chain is invalid and is aborted.
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_gets_aborted_if_first_step_returns_null(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created of which the first step returns NULL
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_null,
                                              chain_step,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps


    // then the chain is aborted immediately
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void test_chained_promise_gets_aborted_if_first_step_chained_promise_self(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created of which the first step returns NULL
    expect_function_call(chain_step_returns_chained);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_returns_chained,
                                              chain_step,
                                              chain_step,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps


    // then the chain is aborted immediately
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_ABORT);

    amxp_promise_delete(&p1);
}

void teat_chained_promise_settle_callback_deletes_promise(void** state) {
    // when a chained promise is created (see test_promise_chain_setup)
    amxp_promise_t* p1 = (amxp_promise_t*) (*state);
    amxp_promise_t* current = p1->info.chained.current;

    // and a settled callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_deletes, NULL), AMXP_PROMISE_STATUS_OK);

    // and resolving all intermediate promises
    // the chain step functions must be called in this order
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, &number);
    expect_function_call(chain_final);
    expect_value(chain_final, provider_priv, &number);
    // it must call the fulfilled callback function when fulfilled
    expect_function_call(settle_callback_deletes);
    expect_value(settle_callback_deletes, promise, p1);
    expect_value(settle_callback_deletes, status, AMXP_PROMISE_STATUS_OK);
    expect_value(settle_callback_deletes, state, amxp_promise_state_fulfilled);

    while(current != NULL) {
        uint32_t size = amxc_llist_size(&p1->watches);
        assert_true(amxp_promise_is_pending(p1));
        assert_int_equal(amxp_promise_fulfill(current, NULL), AMXP_PROMISE_STATUS_OK);
        if(size > 0) {
            // don't do this check on the last step
            // the chained promise is deleted
            assert_ptr_not_equal(current, p1->info.chained.current);
            current = p1->info.chained.current;
        } else {
            current = NULL;
        }
    }
}

void test_chained_promise_can_be_waited_on_if_all_steps_are_waitable(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created of which all steps are waitable
    expect_function_call(chain_step_waitable);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_waitable,
                                              chain_step_waitable,
                                              chain_step_waitable,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps


    // the chained promise is waitable
    expect_function_call(chain_step_waitable);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, NULL);
    expect_function_call(chain_step_waitable);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, NULL);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, NULL);
    assert_int_equal(amxp_promise_wait(p1, 1000), AMXP_PROMISE_STATUS_OK);
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_chained_promise_waited_fails_if_one_step_is_not_waitable(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created of which a step is not waitable
    expect_function_call(chain_step_waitable);
    assert_int_equal(amxp_promise_new_chained(&p1, NULL, NULL,
                                              /* build the chain here */
                                              chain_step_waitable,
                                              chain_step,
                                              chain_step_waitable,
                                              /* terminate the chain*/
                                              NULL),
                     3);                      // returns the number of chained steps


    expect_function_call(chain_step);
    expect_value(chain_step, provider_priv, NULL);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, NULL);
    // then the amxp_promise_wait will return not supported
    assert_int_equal(amxp_promise_wait(p1, 1000), AMXP_PROMISE_STATUS_NOT_SUPPORTED);
    // and the promise is still pending
    assert_true(amxp_promise_is_pending(p1));

    // and the current pending is canceled when the chain is deleted
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1->info.chained.current);
    expect_value(cancel_callback, provider_priv, NULL);

    amxp_promise_delete(&p1);
}

