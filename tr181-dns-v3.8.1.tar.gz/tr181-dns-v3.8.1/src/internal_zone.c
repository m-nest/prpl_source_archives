/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>
#include "tr181-dns.h"
#include "internal_zone.h"
#include "host/host.h"
#include "host/dm_host.h"

#define ME "dns"

static amxc_llist_t zones;

static void zoneaddr_delete_it(amxc_llist_it_t* it) {
    zoneaddr_t* zoneaddr = amxc_container_of(it, zoneaddr_t, it);

    when_null(zoneaddr, exit);
    FREE(zoneaddr->ipaddr);
    FREE(zoneaddr);
exit:
    return;
}

static void zoneaddr_delete(zoneaddr_t** zoneaddr) {
    when_null(zoneaddr, exit);
    when_null(*zoneaddr, exit);

    FREE((*zoneaddr)->ipaddr);
    amxc_llist_it_clean(&(*zoneaddr)->it, NULL);
    FREE(*zoneaddr);

exit:
    return;
}

/**
 * @brief allocates new zone IP address, refcount will be 0
 */
static zoneaddr_t* zoneaddr_new(internal_zone_t* zone, const char* ipaddr, ipversion_t ipversion) {
    zoneaddr_t* zoneaddr = NULL;
    amxc_llist_t* list = NULL;

    when_null(zone, exit);
    when_null(ipaddr, exit);

    switch(ipversion) {
    case IPv4:
        list = &zone->ipv4addr;
        break;
    case IPv6:
        list = &zone->ipv6addr;
        break;
    case IP_ERROR:
        break;
        // no default so the compiler warns for missing cases in this switch when a new enum is added
    }
    when_null_trace(list, exit, ERROR, "Bad IP version %d", ipversion);

    zoneaddr = (zoneaddr_t*) calloc(1, sizeof(zoneaddr_t));
    when_null(zoneaddr, exit);

    amxc_llist_it_init(&zoneaddr->it);
    zoneaddr->ipaddr = strdup(ipaddr);
    if(zoneaddr->ipaddr == NULL) {
        zoneaddr_delete(&zoneaddr);
        goto exit;
    }
    amxc_llist_append(list, &zoneaddr->it);

exit:
    return zoneaddr;
}

static zoneaddr_t* zoneaddr_find(internal_zone_t* zone, const char* ipaddr, ipversion_t ipversion) {
    zoneaddr_t* zoneaddr = NULL;

    when_null(zone, exit);
    when_null(ipaddr, exit);

    amxc_llist_for_each(it, ipversion == IPv4 ? &zone->ipv4addr : &zone->ipv6addr) {
        zoneaddr = (zoneaddr_t*) amxc_llist_it_get_data(it, zoneaddr_t, it);
        if(strcmp(ipaddr, zoneaddr->ipaddr) == 0) {
            break;
        }
        zoneaddr = NULL;
    }

exit:
    return zoneaddr;
}

internal_zone_t* internal_zone_find(const char* domain, const char* iface) {
    internal_zone_t* zone = NULL;

    when_null(domain, exit);
    when_null(iface, exit);

    amxc_llist_for_each(it, &zones) {
        zone = (internal_zone_t*) amxc_llist_it_get_data(it, internal_zone_t, it);
        if((strcmp(domain, zone->domain) == 0) &&
           (strcmp(iface, zone->iface) == 0)) {
            break;
        }
        zone = NULL;
    }

exit:
    return zone;
}

static void zone_delete_it(amxc_llist_it_t* it) {
    internal_zone_t* zone = amxc_container_of(it, internal_zone_t, it);

    when_null(zone, exit);
    amxc_llist_clean(&zone->ipv4addr, zoneaddr_delete_it);
    amxc_llist_clean(&zone->ipv6addr, zoneaddr_delete_it);
    FREE(zone->domain);
    FREE(zone->iface);
    FREE(zone);
exit:
    return;
}

static void internal_zone_delete(internal_zone_t** zone) {

    when_null(zone, exit);
    when_null(*zone, exit);

    amxc_llist_it_clean(&(*zone)->it, NULL);
    amxc_llist_clean(&(*zone)->ipv4addr, zoneaddr_delete_it);
    amxc_llist_clean(&(*zone)->ipv6addr, zoneaddr_delete_it);
    FREE((*zone)->domain);
    FREE((*zone)->iface);
    FREE(*zone);

exit:
    return;
}

internal_zone_t* internal_zone_new(const char* domain, const char* iface) {
    internal_zone_t* zone = NULL;

    when_null(domain, exit);
    when_null(iface, exit);

    zone = (internal_zone_t*) calloc(1, sizeof(internal_zone_t));
    when_null(zone, exit);

    zone->domain = strdup(domain);
    zone->iface = strdup(iface);
    if((zone->domain == NULL) ||
       (zone->iface == NULL)) {
        internal_zone_delete(&zone);
        goto exit;
    }

    amxc_llist_init(&zone->ipv4addr);
    amxc_llist_init(&zone->ipv6addr);

    amxc_llist_it_init(&zone->it);
    amxc_llist_append(&zones, &zone->it);

exit:
    return zone;
}

/**
 * @param added Set to true only when new IP address is added, else the value is not modified
 */
void internal_zone_add_zoneaddr(internal_zone_t* zone, const char* ipaddr, const char* local_domain, bool* added) {
    zoneaddr_t* zoneaddr = NULL;
    int family = AF_INET_INVALID;

    family = ipat_text_family(ipaddr);
    when_false_trace((family == AF_INET) || (family == AF_INET6), exit, ERROR, "Malformed IP address %s", ipaddr);

    zoneaddr = zoneaddr_find(zone, ipaddr, family == AF_INET ? IPv4 : IPv6);
    if(zoneaddr == NULL) {
        zoneaddr = zoneaddr_new(zone, ipaddr, family == AF_INET ? IPv4 : IPv6);
        when_null_trace(zoneaddr, exit, ERROR, "Failed to add IP address %s", ipaddr);
        *added = true;
    }

    zoneaddr->refcount++;
    when_null(zone, exit);
    if(local_domain != NULL) {
        if(zone->refcount_local_domain == 0) {
            *added = true;
        }
        zone->refcount_local_domain++;
    }

exit:
    // Klocwork suppress: The internal_zone is an API that saves the data that is used in the list 'zones', so the memory is not lost as klocwork reports.
    // The zoneaddr is free'd throughout the code everytime the zoneaddr_delete is called
    // In the worst case scenario it's cleaned by the destructor 'internal_zone_cleanall'
    return;
}

/**
 * @param removed Set to true only when new IP address is removed, else the value is not modified
 */
void internal_zone_remove_zoneaddr(internal_zone_t* zone, const char* ipaddr, const char* local_domain, bool* removed) {
    zoneaddr_t* zoneaddr = NULL;
    int family = AF_INET_INVALID;

    family = ipat_text_family(ipaddr);
    when_false_trace((family == AF_INET) || (family == AF_INET6), exit, ERROR, "Malformed IP address %s", ipaddr);

    zoneaddr = zoneaddr_find(zone, ipaddr, family == AF_INET ? IPv4 : IPv6);
    when_null_trace(zoneaddr, exit, INFO, "Zone %s has no IP address %s to remove", zone->domain, ipaddr);

    zoneaddr->refcount--;

    if(zoneaddr->refcount <= 0) {
        zoneaddr_delete(&zoneaddr);
        *removed = true;
    }

    when_null(zone, exit);
    if((local_domain != NULL) && (zone->refcount_local_domain > 0)) {
        zone->refcount_local_domain--;
        if(zone->refcount_local_domain == 0) {
            *removed = true;
        }
    }
exit:
    return;
}

/**
 * Informs the backend of new IP addresses for domain name.
 * The backend should be using exclusivly the list of addresses handed to it for this domain/interface.
 */
bool internal_zone_backend_set_addresses(internal_zone_t* zone, const char* local_domain) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* ipv4 = NULL;
    amxc_var_t* ipv6 = NULL;
    uint32_t count = 0;
    bool rv = false;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", zone->domain);
    amxc_var_add_key(cstring_t, &args, "interface", zone->iface);
    ipv4 = amxc_var_add_key(amxc_llist_t, &args, "ipv4_addresses", NULL);
    ipv6 = amxc_var_add_key(amxc_llist_t, &args, "ipv6_addresses", NULL);

    amxc_llist_for_each(it, &zone->ipv4addr) {
        zoneaddr_t* zoneaddr = (zoneaddr_t*) amxc_llist_it_get_data(it, zoneaddr_t, it);
        amxc_var_add(cstring_t, ipv4, zoneaddr->ipaddr);
        count++;
    }

    amxc_llist_for_each(it, &zone->ipv6addr) {
        zoneaddr_t* zoneaddr = (zoneaddr_t*) amxc_llist_it_get_data(it, zoneaddr_t, it);
        amxc_var_add(cstring_t, ipv6, zoneaddr->ipaddr);
        count++;
    }

    if(local_domain != NULL) {
        if(zone->refcount_local_domain > 0) {
            amxc_var_add_key(cstring_t, &args, "local_domain", local_domain);
        } else {
            amxc_var_add_key(cstring_t, &args, "local_domain", "");
        }
    }

    if(count == 0) {
        SAH_TRACEZ_INFO(ME, "Domain %s (iface %s) has no IP addresses", zone->domain, zone->iface);
        rv = true;
        goto exit;
    }

    when_failed_trace(set_host(&args, &ret), exit, ERROR, "Failed to add domain %s", zone->domain);

    rv = true;

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return rv;
}

static bool internal_zone_backend_remove_domain(internal_zone_t* zone) {
    amxc_var_t args;
    amxc_var_t ret;
    bool rv = false;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", zone->domain);
    amxc_var_add_key(cstring_t, &args, "interface", zone->iface);

    when_failed_trace(remove_host(&args, &ret), exit, ERROR, "Failed to remove %s", zone->domain);

    rv = true;

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return rv;
}

bool internal_zone_backend_evaluate_addresses(internal_zone_t* zone, const char* local_domain) {
    bool rv = false;

    when_null(zone, exit);

    if(!amxc_llist_is_empty(&zone->ipv4addr) ||
       !amxc_llist_is_empty(&zone->ipv6addr)) {
        rv = internal_zone_backend_set_addresses(zone, local_domain);
    } else {
        rv = internal_zone_backend_remove_domain(zone);
        internal_zone_delete(&zone);
    }

exit:
    return rv;
}

bool internal_zone_add_ipaddr(const char* iface, const char* hostname, const char* local_domain, const char* ipaddr) {
    bool rv = false;
    internal_zone_t* zone = NULL;
    bool call_backend = false;

    when_str_empty(ipaddr, exit);
    when_str_empty(hostname, exit);
    when_str_empty(iface, exit);

    zone = internal_zone_find(hostname, iface);
    if(zone == NULL) {
        zone = internal_zone_new(hostname, iface);
        when_null_trace(zone, exit, ERROR, "Failed to add zone for hostname %s", hostname);
    }

    internal_zone_add_zoneaddr(zone, ipaddr, local_domain, &call_backend);

    // maybe only the refcount was increased
    when_false_status(call_backend, exit, rv = true);

    rv = internal_zone_backend_set_addresses(zone, local_domain);

exit:
    // Klocwork suppress: The internal_zone is an API that saves the data that is used in the list 'zones', so the memory is not lost as klocwork reports.
    // The zone is free'd throughout the code everytime the internal_zone_delete is called
    // In the worst case scenario it's cleaned by the destructor 'internal_zone_cleanall'
    // There is no failure scenario that this memory should be free'd
    return rv;
}

// todo test may need change because remove-host-addr is not called (instead either add-host or delete-host)
bool internal_zone_remove_ipaddr(const char* iface, const char* hostname, const char* local_domain, const char* ipaddr) {
    bool rv = false;
    internal_zone_t* zone = NULL;
    bool call_backend = false;

    when_str_empty(ipaddr, exit);
    when_str_empty(hostname, exit);
    when_str_empty(iface, exit);

    zone = internal_zone_find(hostname, iface);
    when_null_trace(zone, exit, INFO, "No zone for hostname %s", hostname);

    internal_zone_remove_zoneaddr(zone, ipaddr, local_domain, &call_backend);

    if(!call_backend) { // maybe only the refcount was decreased
        rv = true;
        goto exit;
    }

    rv = internal_zone_backend_evaluate_addresses(zone, local_domain);

exit:
    return rv;
}

__attribute((constructor))
static void zones_init(void) {
    amxc_llist_init(&zones);
}

__attribute((destructor))
void internal_zone_cleanall(void) {
    amxc_llist_clean(&zones, zone_delete_it);
}
