/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_trie_translator.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief DMM trie translatior allows translating requests/responses
 * @version 1.0.0
 * @date 2025-12-03
 *
 * @copyright Copyright (c) 2025 Inango
 */

#ifndef DMM_TRIE_TRANSLATOR
#define DMM_TRIE_TRANSLATOR

#include <amxc/amxc_variant.h>
#include <amxc/amxc_lqueue.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>

#include "dmm_trie.h"

/**
 * @brief Action for the whole path
 */
typedef enum {
    RenamePathAction,   /*!< Path needs to be renamed */
    HidePathAction,     /*!< Path needs to be hidden */
    NoActionPathAction  /*!< No action for path is needed */
} PathActionType;

/**
 * @brief Path action with new name and reference to node
 */
typedef struct {
    PathActionType action;       /*!< Action for the path */
    amxc_string_t rename_to;     /*!< If action==Rename, new name for the path */
    const TreeNode* node;        /*!< Reference to the last node of the path */
} PathAction;

/**
 * @brief Translate request result
 */
typedef struct {
    amxd_status_t status;       /*!< Translation status: amxd_status_object_not_found if hidden/renamed */
    amxc_string_t translated;   /*!< Output string */
    const TreeNode* fwd_node;   /*!< Forward trie node for the last name of the path, or NULL if trie ends */
    const TreeNode* bwd_node;   /*!< Backward trie node for the last name of the path, or NULL if trie ends */
} TranslateReqResult;

typedef  PathAction (dmm_translator_f)(const TreeNode*, const char*); /*!< Function to use for request and response translating*/

/**
 * @brief Cleans path action.
 *
 * @param[in,out] action path action to clean
 */
void clean_path_action(PathAction* action);

/**
 * @brief Cleans translate request result.
 *
 * @param[in,out] result translate request result to clean
 */
void clean_translate_req_result(TranslateReqResult* result);

/**
 * @brief Translate nonterminal (e.g. object) path.
 *
 * Search exresions are _not_ supported by this function.
 *
 * @param[in] root of the translation
 * @param[in] nonterminals_path object path to translate
 *
 * @return PathAction, if action==rename, `rename_to` will contain
 * full renamed path
 */
PathAction translate_nonterminal_path(const TreeNode* root, const char* nonterminals_path);

/**
 * @brief Translate nonterminal (e.g. object) path.
 *
 * Search exresions and other reffollows _are_ supported by this function.
 *
 * @param[in] forward_root forward trie root
 * @param[in] backward_root backward trie root
 * @param[in] objpath object path to translate
 *
 * @return TranslateReqResult
 * `status` indicating success or failure (like when requested object is hidden or renamed),
 * `translated` containing translated object path,
 * `node` containing last node for the path if it was renamed
 */
TranslateReqResult translate_nonterminal_request_path(const TreeNode* forward_root, const TreeNode* backward_root, const char* objpath);

/**
 * @brief Translates single nonterminal name (e.g. direct object child of the current object).
 *
 * @param[in] object_node current object node whos child to translate
 * @param[in] nonterminal_name name of the child object to translate
 *
 * @return PathAction, if action==rename the `rename_to` would contain
 * new name for the object.
 */
PathAction translate_nonterminal_name(const TreeNode* object_node, const char* nonterminal_name);

/**
 * @brief Translates single terminal name (e.g. direct NON-object child of the current object).
 *
 * @param[in] object_node current object node whos child to translate
 * @param[in] terminal_name name of the child terminal to translate
 *
 * @return PathAction, if action==rename the `rename_to` would contain
 * new name for the terminal.
 */
PathAction translate_terminal_name(const TreeNode* object_node, const char* terminal_name);

/**
 * @brief Translates single event name without prefix.
 *
 * @param[in] object_node current object node whos child to translate
 * @param[in] event_name name of the child event to translate
 *
 * @return PathAction, if action==rename the `rename_to` would contain
 * new name for the event.
 */
PathAction translate_event_name(const TreeNode* object_node, const char* event_name);

/**
 * @brief Translates single rpc name without prefix.
 *
 * @param[in] object_node current object node whos child to translate
 * @param[in] rpc_name name of the child rpc to translate
 *
 * @return PathAction, if action==rename the `rename_to` would contain
 * new name for the rpc.
 */
PathAction translate_rpc_name(const TreeNode* object_node, const char* rpc_name);

/**
 * @brief translate _get_supported response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_get_supported_response(amxc_var_t* response);

/**
 * @brief translate _get response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_get_response(amxc_var_t* response);

/**
 * @brief translate _set response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_set_response(amxc_var_t* response);

/**
 * @brief translate _get_instances response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_get_instances_response(amxc_var_t* response);

/**
 * @brief translate _add response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_add_response(amxc_var_t* response);

/**
 * @brief translate _del response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_del_response(amxc_var_t* response);

/**
 * @brief translate _list response
 *
 * @param[in] backward_node for the requested path (NULL if nothing to rename/hide)
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_list_response(const TreeNode* backward_node, amxc_var_t* response);


/**
 * @brief translate _describe response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_describe_response(amxc_var_t* response);

/**
 * @brief translate event response
 *
 * @param[in,out] response response from the prplmesh component
 *
 * @return 0 if no error
 */
int translate_event_response(amxc_var_t* response);

/**
 * @brief print PathAction structure to logs
 *
 * @param[in] action action to print
 */
void print_path_action(PathAction action);

#endif
