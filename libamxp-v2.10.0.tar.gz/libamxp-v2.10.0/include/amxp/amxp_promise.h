/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__AMXP_PROMISE_H__)
#define __AMXP_PROMISE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_variant.h>
#include <amxc/amxc_llist.h>
#include <amxp/amxp_timer.h>

/**
   @file
   @brief
   Ambiorix promise
 */

/**
   @defgroup amxp_promise Promises

   A promise refers to a construct used for synchronizing program execution in some concurrent programming techniques.
   It describes an object that acts as a proxy for a result that is initially unknown, usually because the computation
   of its value is not yet complete. The initially unknown result is called the future.

   A future is a read-only placeholder view of a variable, while a promise is a writable, single assignment container
   which sets the value of the future. This implementation doesn't separate the implementation of promises and futures.

   A single promise contains a single future and only the owning promise can set the future. The future can be accessed and
   read even if the promise is not yet fulfilled. The future is implemented as an amxc_var_t. When the promise is in the
   pending state (not fulfilled) or rejected the value of the future will be undefined and is implementation specific,
   depending on the implementation of the promise provider. When the promise is fulfilled the future will contain the final
   result and can not be changed afterwards.

   A rejected promise will have its status code set to a non-zero value. This status code should indicate why
   the promise is rejected. The exact meaning of the status code may depend on the promise provider.

   A promise is very useful in asynchronous I/O operations and provides a common interface to handle asynchronous I/O.
   It enables clean composition of asynchronous operations through chaining and aggregation patterns, avoiding
   callback hell and providing better error handling mechanisms.

   Multiple promises can be aggregated in a single promise. This aggregated promise will settle depending on the aggregation
   strategy used and the final result of the sub-promises.

   A promise can be waitable, that is a blocking wait can be done on the promise until it is settled or until a timeout occurs.
   Setting the wait function can only be done by the promise provider/creator.

   @section amxp_promise_chaining Promise Chaining

   Promise chaining allows you to sequence asynchronous operations by creating new promises in the callback functions
   of existing promises. This enables building complex asynchronous workflows where each step depends on the result
   of the previous step, while maintaining a clean and readable code structure.

   A chained promise can be created using one of these functions:
   - @ref amxp_promise_new_chained
   - @ref amxp_promise_new_chained_array

   @subsection amxp_promise_chaining_concept Chaining Concept

   Promise chaining works by creating a new promise and providing a sequence of functions.

   The key principle is that each step in the chain creates a new promise that represents the next asynchronous operation,
   allowing the chain to continue until all operations complete or any operation fails.

   @subsection amxp_promise_chaining_pitfalls Important Notes

   Each step in the chain, must return the next promise. This next promise can be a chained promise as well.
   When a step is returning a chained promise be aware that it could lead to a never ending chain if not constructed properly.
   Make sure that no recursive chains are created.

   @subsection amxp_promise_chaining_wait Chained Promise Waiting

   A chained promise is a waitable promise as far as all the individual steps in the chain are waitable promises.
   The function @ref amxp_promise_is_waitable will always return true when called on a chained promise, but
   the function @ref amxp_promise_wait can return AMXP_PROMISE_STATUS_NOT_SUPPORTED as soon as a step returns
   a non-waitable promise.

   @subsection amxp_promise_chaining_final Chained Promise Final

   A final callback can be provided when creating a chained promise. This final callback function is always called, disregarding
   the outcome of the chain. The final callback gets the last step promise, and the chained promise. The final step can reject
   or fulfill the chained promise and can set the future of the chained promise.

   @warning
   When a chained promise gets canceled or automatically rejected after a timeout set using @ref amxp_promise_reject_after,
   the final is called as well, but the chained promise will be in the rejected state and the last step promise will be a NULL
   pointer. It is recommended to verify the state of the chained promise in the final callback function.

   @section amxp_promise_aggregation Promise Aggregation Strategies

   Promise aggregation allows combining multiple promises into a single aggregated promise that settles based on
   different strategies. The aggregated promise's behavior depends on the chosen aggregation type.

   @see amxp_promise_aggregate_type_t

   An aggregated promise can be created using one of these functions:
   - @ref amxp_promise_new_aggregate
   - @ref amxp_promise_new_aggregate_list
   - @ref amxp_promise_new_aggregate_array

   @subsection amxp_promise_aggregate_all All Strategy

   @see amxp_promise_aggregate_all

   The aggregated promise fulfills when **all** sub-promises are fulfilled, and rejects when **any** sub-promise is rejected.

   Behavior:
   - **Fulfills**: When every sub-promise has been fulfilled
   - **Rejects**: As soon as any sub-promise is rejected
   - **Cancellation**: When one sub-promise rejects, all remaining pending sub-promises are canceled
   - **Future Value**: List variant containing all sub-promise results in the order they were added

   Use Case: When you need all operations to succeed before proceeding (e.g., loading multiple required resources).

   @subsection amxp_promise_aggregate_all_settled All Settled Strategy

   @see amxp_promise_aggregate_all_settled

   The aggregated promise fulfills when **all** sub-promises have settled (either fulfilled or rejected).

   Behavior:
   - **Fulfills**: When every sub-promise has settled (fulfilled or rejected)
   - **Rejects**: This strategy never rejects the aggregated promise
   - **No Cancellation**: Sub-promises are never canceled due to other sub-promise failures
   - **Future Value**: List variant containing all sub-promise results, including NULL variants for rejected promises

   Use Case: When you want to wait for all operations to complete regardless of their individual success/failure
   (e.g., cleanup operations, gathering results from multiple optional sources).

   @subsection amxp_promise_aggregate_any Any Strategy

   @see amxp_promise_aggregate_any

   The aggregated promise fulfills when **any** sub-promise is fulfilled, and rejects when **all** sub-promises are rejected.

   Behavior:
   - **Fulfills**: As soon as any sub-promise is fulfilled
   - **Rejects**: When all sub-promises have been rejected
   - **Cancellation**: When one sub-promise fulfills, all remaining pending sub-promises are canceled
   - **Future Value**: The result of the first sub-promise that fulfilled

   Use Case: When you have multiple alternative ways to achieve the same goal and only need one to succeed
   (e.g., trying multiple servers, fallback mechanisms).

   @subsection amxp_promise_aggregate_race Race Strategy

   @see amxp_promise_aggregate_race

   The aggregated promise settles when **any** sub-promise settles (either fulfilled or rejected).

   Behavior:
   - **Fulfills**: As soon as any sub-promise is fulfilled
   - **Rejects**:  As soon as any sub-promise is rejected
   - **Cancellation**: When one sub-promise settles, all remaining pending sub-promises are canceled
   - **Future Value**: The result of the first sub-promise that settled (or NULL if it was rejected)

   Use Case: When you want the fastest response regardless of success/failure, or when implementing timeouts
   (e.g., racing an operation against a timeout, getting the quickest response from multiple sources).

   @subsection amxp_promise_aggregation_notes Important Notes

   - **Future Access**: For aggregated promises, use amxp_promise_get_future() to access the combined results
   - **Error Handling**: Check individual sub-promise states when needed using the aggregation callbacks
   - **Memory Management**: The aggregated promise takes ownership of all sub-promises
   - **Callback Order**: Sub-promise results appear in the future list in the order they were added to the aggregation
   - **Status Codes**: The status code of the first sub-promise that was rejected. Check the individual status codes of the
     sub-promises to determine the specific reason for rejection of each of them.

   @section amxp_promise_api Promise API Overview

   The promise structure definition is publicly available, but it is recommended to never access the members of the structure
   directly, it is a better approach to use the provided methods/API.

   @subsection amxp_promise_construction_destruction Creation And Deletion

   - @ref amxp_promise_new - creates a single promise
   - @ref amxp_promise_new_aggregate - creates an aggregated promise
   - @ref amxp_promise_new_aggregate_list - creates an aggregated promise from a list of promises
   - @ref amxp_promise_new_aggregate_array -  creates an aggregated promise from an array of promises
   - @ref amxp_promise_new_chained - creates a chained promise
   - @ref amxp_promise_new_chained_array -  creates a chained promise from an array of functions
   - @ref amxp_promise_delete - deletes the promise

   @subsection amxp_promise_callbacks Set Callback Functions

   - @ref amxp_promise_when - set one or more callback functions

   @subsection amxp_promise_state Query The State

   - @ref amxp_promise_is_pending - checks if the state is pending
   - @ref amxp_promise_is_rejected - checks if the state is rejected
   - @ref amxp_promise_is_fulfilled - checks if the state is fulfilled
   - @ref amxp_promise_is_settled - checks if the state is not pending
   - @ref amxp_promise_get_status - gets the current status of the promise, the status for fulfilled or pending promises is always
     AMXP_PROMISE_STATUS_OK. The status of a rejected promise indicates why the promise was rejected and is provided by the
     promise provider/creator.
   - @ref amxp_promise_get_future - gets the future (value) of the promise, for pending or rejected promises the value is
     undefined and can be implementation specific (depending on the promise provider implementation).
     For aggregated promises the content of the future can be different depending on the aggregation strategy used.

   @subsection amxp_promise_waitable Waitable Promises

   - @ref amxp_promise_is_waitable - checks if a promise is waitable. For settled promises this is always true. For pending
     promises the promise provider/creator must provide a wait function to make the promise waitable.
   - @ref amxp_promise_wait - wait until the promise is settled, can only be done on waitable promises.
     For settled promises this function is a no-op.

   @subsection amxp_promise_settle Settling a Promise

   - @ref amxp_promise_fulfill - sets the state of the promise to fulfilled, The future is set to the final value.
   - @ref amxp_promise_reject - sets the state of the promise to rejected. The status of the promise provides the reason.
 */

typedef struct _promise amxp_promise_t;

/**
   @ingroup amxp_promise
   @brief
   Callback function type for promise state changes.

   This callback function is invoked when a promise changes state (fulfilled, rejected).

   @param promise Pointer to the promise that changed state
   @param priv Private data pointer passed when the callback was registered
 */
typedef void (* amxp_promise_cb_fn_t) (amxp_promise_t* promise, void* const priv);

/**
   @ingroup amxp_promise
   @brief
   Callback function type for promise chains.

   This callback function is invoked when a chained promise needs the next promise.
   A callback is only called when the previous promise in the chain was fulfilled.
   The first callback function in the sequence is always called to get the first promise in the chain.

   @param chained Pointer to the chained promise.
   @param current Future (value) of the previous promise in the chain. For the first in the chain this will be NULL
   @param output Future of the chained promise, each callback can update the chained future.
   @param provider_priv Private data pointer passed when the chained promise was created.

   @return Pointer to the next promise in the chain
   @return NULL if the chain is terminated
 */
typedef amxp_promise_t* (* amxp_promise_chain_fn_t) (amxp_promise_t* chained, amxp_promise_t* current, amxc_var_t* output, void* const provider_priv);

/**
   @ingroup amxp_promise
   @brief
   Callback function type for chained promise final result.

   This callback function is invoked when a chained promise is finished, all steps are done.
   The final gets the result of the last promise in the chain, and can set the final result.

   @param chained Pointer to the chained promise.
   @param current Future (value) of the last executed promise
   @param output Future of the chained promise, each callback can update the chained future.
   @param provider_priv Private data pointer passed when the chained promise was created.
 */
typedef void (* amxp_promise_final_fn_t) (amxp_promise_t* chained, amxp_promise_t* current, amxc_var_t* output, void* const provider_priv);

/**
   @ingroup amxp_promise
   @brief
   Callback function type for promise wait operations.

   This callback function is invoked when a blocking wait is performed on a promise.
   The implementation should block until the promise is settled or the timeout expires.

   @param promise Pointer to the promise being waited on
   @param timeout Maximum time to wait in milliseconds (0 = wait indefinitely)
   @param provider_priv Private data pointer passed when the promise was created.

   @return 0 on success (promise settled), non-zero on timeout or error
 */
typedef int (* amxp_promise_wait_cb_fn_t) (amxp_promise_t* promise, uint32_t timeout, void* const provider_priv);

/**
   @ingroup amxp_promise
   @brief
   Enumeration of promise aggregation types.

   Defines how multiple promises are combined in an aggregated promise.
 */
typedef enum _promise_aggregate_type {
    amxp_promise_aggregate_all,         /**< Fulfills when all of the promises fulfill; rejects when any of the promises rejects. */
    amxp_promise_aggregate_all_settled, /**< Fulfills when all promises settle. */
    amxp_promise_aggregate_any,         /**< Fulfills when any of the promises fulfills; rejects when all of the promises reject. */
    amxp_promise_aggregate_race         /**< Settles when any of the promises settles. In other words, fulfills when any of the promises fulfills; rejects when any of the promises rejects. */
} amxp_promise_aggregate_type_t;

/**
   @ingroup amxp_promise
   @brief
   Enumeration of promise states.

   Defines the possible states a promise can be in during its lifecycle.
 */
typedef enum _promise_state {
    amxp_promise_state_pending,       /**< The initial state of a promise when it is created */
    amxp_promise_state_fulfilled,     /**< The promise is fulfilled, the future has its final value */
    amxp_promise_state_rejected,      /**< The promise is rejected, the status code is filled with the reason */
    amxp_promise_state_settled,       /**< Superstate - When a promise is either fulfilled or rejected it is also in the settled state */
} amxp_promise_state_t;

#define AMXP_PROMISE_STATUS_OK            0  /**< OK/Success */
#define AMXP_PROMISE_STATUS_CANCELED      1  /**< Canceled */
#define AMXP_PROMISE_STATUS_ABORT         2  /**< Chained promise is aborted */
#define AMXP_PROMISE_STATUS_TIMEOUT       3  /**< Timeout occurred */
#define AMXP_PROMISE_STATUS_REJECTED      4  /**< Explicitly rejected */
#define AMXP_PROMISE_STATUS_FULFILLED     5  /**< Explicitly fulfilled */
#define AMXP_PROMISE_STATUS_NOT_SUPPORTED 6  /**< Operation not supported */

#define AMXP_PROMISE_FLAG_WAITING         1  /**< The promise is being waited on (synchronous mode) - deletion is not allowed */
#define AMXP_PROMISE_FLAG_CANCELING       2  /**< The promise is getting canceled (synchronous mode) - deletion is not allowed */
#define AMXP_PROMISE_FLAG_DELETE          4  /**< The promise must be deleted after wait is finished */

typedef struct _chained {
    amxp_promise_t* current;
    amxp_promise_final_fn_t final;
} amxp_promise_chained_t;

/**
   @ingroup amxp_promise
   @brief
   Structure containing the promise information.

   This structure contains the current state of the promise together with a set of callback
   functions that can be called when the promise is settled.
 */
struct _promise {
    amxc_llist_it_t it;                 /**< Linked list iterator, can be used to store the promise in a linked list, used by aggregation */
    amxp_promise_state_t state;         /**< The current state of the promise */
    amxc_var_t* future;                 /**< A variant that will hold the data when the promise is fulfilled */
    int32_t status;                     /**< A status code that will contain an indication why the promise was rejected */
    amxc_llist_t watches;               /**< Linked list of promises that are watched by this promise for aggregated promises
                                             Linked list of functions that return the next promise for chained promises */
    uint32_t flags;                     /**< Flags that indicates if the promise can be deleted */
    union {
        uint32_t watch_count;           /**< Number of watched promises that are not yet settled for aggregated promise */
        amxp_promise_chained_t chained; /**< Chained promise information */
    } info;
    amxp_timer_t* reject_timer;         /**< Reject the promise if not settled when the timer expires */
    amxp_promise_cb_fn_t fulfilled;     /**< Callback function that is called when the promise is fulfilled, callback should be provided by promise watcher */
    amxp_promise_cb_fn_t rejected;      /**< Callback function that is called when the promise is rejected, callback should be provided by promise watcher */
    amxp_promise_cb_fn_t canceled;      /**< Callback function that is called when the promise is canceled, callback should be provide by promise creator */
    amxp_promise_wait_cb_fn_t wait;     /**< Callback function that is called when the promise is waited on until settled, callback should be provided by promise creator */
    void* watch_priv;                   /**< Private data that needs to be passed to the fulfilled or rejected callback */
    void* provider_priv;                /**< Private data that needs to be passed to the canceled or wait callback */
};

/**
   @ingroup amxp_promise
   @brief
   Creates a new promise.

   Allocates and initializes a new promise in the pending state. The promise can be made
   waitable by providing a wait callback function, and can handle cancellation through
   the cancel callback function.

   @param promise Pointer to store the newly created promise (output parameter)
   @param cancelfn Optional callback function called when the promise is canceled (can be NULL)
   @param waitfn Optional callback function to make the promise waitable (can be NULL)
   @param provider_priv Private data pointer passed to the cancel and wait callbacks

   @return 0 on success, non-zero error code on failure

   @note The caller is responsible for freeing the promise using @ref amxp_promise_delete or must transfer ownership
   @note If waitfn is NULL, the promise will not be waitable in pending state
 */
int amxp_promise_new(amxp_promise_t** promise, amxp_promise_cb_fn_t cancelfn, amxp_promise_wait_cb_fn_t waitfn, void* provider_priv);

/**
   @ingroup amxp_promise
   @brief
   Creates a new aggregated promise from a list of promises.

   Creates an aggregated promise that combines multiple promises according to the specified
   aggregation type. The behavior depends on the aggregation type:
   - all: fulfills when all promises fulfill, rejects when any rejects
   - all_settled: fulfills when all promises settle (regardless of state)
   - any: fulfills when any promise fulfills, rejects when all reject
   - race: settles when the first promise settles

   @param aggregated Pointer to store the newly created aggregated promise (output parameter)
   @param aggr_type Type of aggregation to perform
   @param promises Linked list containing the promises to aggregate

   @return -1 on failure
   @return The number of promises aggregated on success

   @note
   The aggregated promise takes ownership of the promises in the list.
   The caller must not free these promises.

   @note
   The caller is responsible for freeing the aggregated promise using @ref amxp_promise_delete
   or must transfer ownership.
 */
int amxp_promise_new_aggregate_list(amxp_promise_t** aggregated, amxp_promise_aggregate_type_t aggr_type, amxc_llist_t* promises);

/**
   @ingroup amxp_promise
   @brief
   Creates a new aggregated promise from an array of promises.

   Creates an aggregated promise that combines multiple promises from an array according
   to the specified aggregation type. The behavior depends on the aggregation type:
   - all: fulfills when all promises fulfill, rejects when any rejects
   - all_settled: fulfills when all promises settle (regardless of state)
   - any: fulfills when any promise fulfills, rejects when all reject
   - race: settles when the first promise settles

   @param aggregated Pointer to store the newly created aggregated promise (output parameter)
   @param aggr_type Type of aggregation to perform
   @param count Number of promises in the array. Must be greater than 0.
   @param promises Array of promise pointers to aggregate. Must not be NULL and all elements must be valid promise pointers.

   @return -1 on failure
   @return The number of promises aggregated on success

   @note
   The aggregated promise takes ownership of the promises in the array.
   The caller must not free these promises.

   @note
   The caller is responsible for freeing the aggregated promise using @ref amxp_promise_delete
   or must transfer ownership.

   @note
   NULL pointers in the array will be skipped.

   @note
   The count parameter must accurately reflect the number of elements in the array.
 */
int amxp_promise_new_aggregate_array(amxp_promise_t** aggregated, amxp_promise_aggregate_type_t aggr_type, uint32_t count, amxp_promise_t* promises[]);

/**
   @ingroup amxp_promise
   @brief
   Creates a new aggregated promise from a variable argument list of promises.

   Creates an aggregated promise that combines multiple promises according to the specified
   aggregation type. The behavior depends on the aggregation type:
   - all: fulfills when all promises fulfill, rejects when any rejects
   - all_settled: fulfills when all promises settle (regardless of state)
   - any: fulfills when any promise fulfills, rejects when all reject
   - race: settles when the first promise settles

   The function accepts a variable number of promise pointers, terminated by NULL.

   @param aggregated Pointer to store the newly created aggregated promise (output parameter)
   @param aggr_type Type of aggregation to perform
   @param ... Variable argument list of amxp_promise_t* pointers, must be NULL-terminated

   @return -1 on failure
   @return The number of promises aggregated on success

   @note
   The aggregated promise takes ownership of the promises passed as arguments.
   The caller must not free these promises.

   @note
   The caller is responsible for freeing the aggregated promise using @ref amxp_promise_delete
   or must transfer ownership

   @note
   The variable argument list must be NULL-terminated to indicate the end of the promise list.

   @note
   If any of the promise pointers in the argument list is NULL it will be considered as the end of the list
   The remaining promises in the list are not taken into account and will not be added to the aggregated promise.
 */
int amxp_promise_new_aggregate(amxp_promise_t** aggregated, amxp_promise_aggregate_type_t aggr_type, ...);

/**
   @ingroup amxp_promise
   @brief
   Creates a new chained promise that executes a sequence of operations.

   Creates a promise chain where operations are executed sequentially, with each operation
   potentially depending on the result of the previous one.

   The function accepts a variable number of chain function pointers that define the sequence
   of operations to be executed. Each chain function is responsible for creating and managing
   its part of the chain and must return a amxp_promise_t pointer or NULL to break and
   terminate the chain.

   Optionally a final callback function can be provided. This function will be called after the last
   promise in the chain is settled. The final callback is always invoked regardless of outcome.

   @param chained Pointer to store the newly created chained promise (output parameter).
                  This promise will represent the final result of the entire chain.
   @param final The final function, this function will be called after the last promise in the chain settles.
                This allows to fill the chained promise future.
                This function is optional and can be NULL
   @param provider_priv Private data pointer that will be passed to chain functions and callbacks.
                        This allows sharing context and state throughout the chain execution.
   @param ... Variable argument list of additional amxp_promise_chain_fn_t function pointers,
              terminated by NULL. Each function represents a step in the chain.

   @return -1 on failure
   @return The number of steps in the chain

   @note
   The caller is responsible for freeing the chained promise using @ref amxp_promise_delete or must transfer ownership

   @note
   The variable argument list must be NULL-terminated to indicate the end of the function list

   @note
   If any of the function pointers in the argument list is NULL it will be considered as the end of the list
   The remaining functions in the list are not taken into account.

   @warning
   When one of the steps creates a chained promise again, make sure that it is not creating a recursive chain.
   This can lead to infinite loops and never ending chains.
 */
int amxp_promise_new_chained(amxp_promise_t** chained, amxp_promise_final_fn_t final, void* provider_priv, ...);

/**
   @ingroup amxp_promise
   @brief
   Creates a new chained promise that executes a sequence of operations.

   Creates a promise chain where operations are executed sequentially, with each operation
   potentially depending on the result of the previous one.

   The function accepts an array of function pointers that define the sequence
   of operations to be executed. Each chain function is responsible for creating and managing
   its part of the chain and must return a amxp_promise_t pointer or NULL to break and
   terminate the chain.

   Optionally a final function can be provided. This function will be called after that the last
   promise in the chain is fulfilled. When the chain fails (one of the promises in the chain is reject)
   this function is not called and the chained promise is rejected as well.

   @param chained Pointer to store the newly created chained promise (output parameter).
                  This promise will represent the final result of the entire chain.
   @param final The final function, this function will be called after the last promise in the chain settles.
                This allows to fill the chained promise future.
                This function is optional and can be NULL
   @param provider_priv Private data pointer that will be passed to chain functions and callbacks.
                        This allows sharing context and state throughout the chain execution.
   @param count Number of functions in the array. Must be greater than 0.
   @param promises Array of function pointers that define the sequence.

   @return -1 on failure
   @return The number of steps in the chain

   @note
   NULL pointers in the array will be skipped.

   @note
   The caller is responsible for freeing the chained promise using @ref amxp_promise_delete or must transfer ownership

   @warning
   When one of the steps creates a chained promise again, make sure that it is not creating a recursive chain.
   This can lead to infinite loops and never ending chains.
 */
int amxp_promise_new_chained_array(amxp_promise_t** chained, amxp_promise_final_fn_t final, void* provider_priv, uint32_t count, amxp_promise_chain_fn_t promises[]);

/**
   @ingroup amxp_promise
   @brief
   Deletes the promise and frees all associated resources.

   Destroys a promise and releases all memory and resources associated with it.
   If the promise is still pending, it will be automatically rejected with status
   AMXP_PROMISE_STATUS_CANCELED before deletion. Any active timers associated with
   the promise will be stopped and cleaned up.

   For aggregated promises, this function will also clean up all watched sub-promises
   and their associated resources. Each pending sub-promise will be canceled.

   For chained promises, this function will stop the chain and cancel the current
   pending sub-promise.

   @param promise Pointer to the promise pointer to delete. The pointer will be set to NULL after deletion.

   @note The promise pointer will be set to NULL after successful deletion
   @note If the promise is pending when deleted, any registered cancel callback will be invoked
   @note It is safe to call this function with a NULL pointer or a pointer to NULL
   @note After calling this function, the promise pointer should not be used
   @note It is allowed to delete a promise from within the fulfilled or rejected callback.

   @warning
   A promise provider can not delete a promise. After creation the ownership of a promise is
   transferred to the watcher. Deleting a promise from within a cancel callback or wait callback
   will have no effect.
 */
void amxp_promise_delete(amxp_promise_t** promise);

/**
   @ingroup amxp_promise
   @brief
   Fulfills the promise and sets the final value to the future.

   Transitions the promise from pending state to fulfilled state and sets the future
   value to the provided data. Once a promise is fulfilled, its state cannot be changed.
   If the promise has registered fulfilled callbacks, they will be invoked.

   @warning
   It is not allowed to fulfill a chained or aggregated promise directly.
   This function will return AMXP_PROMISE_STATUS_NOT_SUPPORTED if you try to do that.
   The aggregated promise or chained promise will continue until settled.
   It is allowed to use @ref amxp_promise_reject_after on chained and aggregated promises.

   @param promise Pointer to the promise to fulfill. Must not be NULL and must be in pending state.
   @param data Pointer to the variant containing the result data. The data will be copied into the promise's future.
               When NULL the current value of the future is untouched.

   @retval AMXP_PROMISE_STATUS_OK on success
   @retval AMXP_PROMISE_STATUS_REJECTED if the promise was rejected before (not pending)
   @retval AMXP_PROMISE_STATUS_FULFILLED if the promise was already fulfilled before (not pending)

   @note The promise must be in pending state for this operation to succeed
   @note Once fulfilled, the promise state cannot be changed
   @note The data is copied into the promise, so the caller retains ownership of the input data
   @note Any registered fulfilled callback will be invoked after the state change

   @warning
   Only the creator of the promise can fulfill it. Don't call this function on a promise you received from a function.
 */
int amxp_promise_fulfill(amxp_promise_t* promise, const amxc_var_t* data);

/**
   @ingroup amxp_promise
   @brief
   Rejects the promise and sets status code to indicate why the promise is rejected.

   Transitions the promise from pending state to rejected state and sets the status
   code to indicate the reason for rejection. Once a promise is rejected, its state
   cannot be changed. If the promise has registered rejected callbacks, they will be invoked.

   @warning
   It is not allowed to reject a chained or aggregated promise directly.
   This function will return AMXP_PROMISE_STATUS_NOT_SUPPORTED if you try to do that.
   The aggregated promise or chained promise will continue until settled.
   It is allowed to use @ref amxp_promise_reject_after on chained and aggregated promises.

   @param promise Pointer to the promise to reject. Must not be NULL and must be in pending state.
   @param status Status code indicating the reason for rejection. Should be non-zero.
                 Common values include AMXP_PROMISE_STATUS_CANCELED, AMXP_PROMISE_STATUS_TIMEOUT, etc.
                 The status code can be any value, it is recommended to use values below 0 or higher than 10.
                 Values between 0-10 (inclusive) are reserved for the promise implementation.

   @retval AMXP_PROMISE_STATUS_OK on success
   @retval AMXP_PROMISE_STATUS_REJECTED if the promise was already rejected before (not pending)
   @retval AMXP_PROMISE_STATUS_FULFILLED if the promise was fulfilled before (not pending)
   @retval AMXP_PROMISE_STATUS_NOT_SUPPORTED if the promise is a chained or aggregated promise

   @note The promise must be in pending state for this operation to succeed
   @note Once rejected, the promise state cannot be changed
   @note The status code should be non-zero to indicate the rejection reason
   @note Any registered rejected callback will be invoked after the state change

   @warning
   Only the creator of the promise can reject it. Don't call this function on a promise you received from a function.
 */
int amxp_promise_reject(amxp_promise_t* promise, int status);

/**
   @ingroup amxp_promise
   @brief
   Rejects the promise if it is not settled after the specified time.

   Sets up a timer that will automatically reject the promise with AMXP_PROMISE_STATUS_TIMEOUT
   if the promise is still in pending state when the timer expires. If the promise is already
   settled or becomes settled before the timer expires, the timer is automatically canceled.

   @param promise Pointer to the promise to set timeout for. Must not be NULL.
   @param time_ms Timeout duration in milliseconds. Must be greater than 0.

   @return 0 on success, non-zero error code on failure

   @note
   The promise will be rejected with AMXP_PROMISE_STATUS_TIMEOUT when the timer expires

   @note
   If the promise settles before the timeout, the timer is automatically canceled

   @note
   Only one timeout timer can be active per promise - calling this function multiple times will restart the existing timer
   with the new timeout duration.

   @note
   The timer is automatically cleaned up when the promise is deleted
 */
int amxp_promise_reject_after(amxp_promise_t* promise, uint32_t time_ms);

/**
   @ingroup amxp_promise
   @brief
   Sets one or more callback functions for specific promise states.

   Registers callback functions to be invoked when the promise transitions to specific states.
   If the promise is already in the specified state, the callback is invoked immediately.

   @param promise Pointer to the promise to set callbacks for. Must not be NULL.
   @param state The promise state for which to register the callback. Can be:
                - amxp_promise_state_fulfilled: callback invoked when promise is fulfilled
                - amxp_promise_state_rejected: callback invoked when promise is rejected
                - amxp_promise_state_settled: callback invoked when promise is settled (fulfilled or rejected)
   @param fn Callback function to invoke. Can be NULL to clear the callback for the specified state.
   @param watcher_priv Private data pointer passed to the callback function when invoked.

   @return 0 on success, non-zero error code on failure

   @note
   If the promise is already in the specified state, the callback is invoked immediately

   @note
   The private data pointer is stored and passed to the callback - ensure it remains valid

   @note
   Setting a callback to NULL will clear any previously registered callback for that state

   @note
   Only one callback can be registered for a specific state, calling this function multiple times
   will overwrite the previous callback

   @note
   For settled state, the callback is invoked for both fulfilled and rejected states
 */
int amxp_promise_when(amxp_promise_t* promise, amxp_promise_state_t state, amxp_promise_cb_fn_t fn, void* watcher_priv);

/**
   @ingroup amxp_promise
   @brief
   Wait until the promise is settled. This is a blocking call, the function will return when the promise is settled or
   the timeout occurs.

   Blocks the calling thread until the promise is settled (fulfilled or rejected) or until the
   specified timeout expires. The promise must be waitable for this operation to succeed.
   A promise is waitable if it's already settled or if a wait callback function was provided
   during promise creation.

   @param promise Pointer to the promise to wait for. Must not be NULL and must be waitable.
   @param timeout Maximum time to wait in milliseconds. Use 0 to wait indefinitely.

   @retval AMXP_PROMISE_STATUS_NOT_SUPPORTED if the promise is not waitable
   @retval 0 if the promise settled within the timeout period
   @retval non-zero on timeout or error, check the documentation of the promise provider for details.

   @note This is a blocking operation that will suspend the calling thread until the promise is settled
   @note The promise must be waitable (have a wait callback or be already settled)
   @note A timeout of 0 means wait indefinitely until the promise settles
   @note The function returns when the promise settles, regardless of whether it was fulfilled or rejected
   @note Use amxp_promise_is_waitable() to check if a promise can be waited on
   @note A chained promise is waitable, but if one of the steps in the chain returns a non-waitable promise
         this function might return AMXP_PROMISE_STATUS_NOT_SUPPORTED.
 */
int amxp_promise_wait(amxp_promise_t* promise, uint32_t timeout);

/**
   @ingroup amxp_promise
   @brief
   Checks if the promise is rejected.

   Determines whether the promise is currently in the rejected state.
   A promise is rejected when it has failed to complete successfully
   and has been explicitly rejected with a status code.

   @param promise Pointer to the promise to check. Must not be NULL.

   @return true if the promise is in rejected state, false otherwise

   @note A rejected promise will have a non-zero status code accessible via amxp_promise_get_status()
   @note Once rejected, a promise cannot transition to any other state
   @note This function is safe to call on promises in any state
 */
bool amxp_promise_is_rejected(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Checks if the promise is fulfilled.

   Determines whether the promise is currently in the fulfilled state.
   A promise is fulfilled when it has completed successfully and
   contains a final result value in its future.

   @param promise Pointer to the promise to check. Must not be NULL.

   @return true if the promise is in fulfilled state, false otherwise

   @note A fulfilled promise will have its future set to the final result value
   @note Once fulfilled, a promise cannot transition to any other state
   @note This function is safe to call on promises in any state
 */
bool amxp_promise_is_fulfilled(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Checks if the promise is not pending.

   Determines whether the promise has been settled, meaning it is either
   fulfilled or rejected. A settled promise is no longer in the pending state
   and will not change state again.

   @param promise Pointer to the promise to check. Must not be NULL.

   @return true if the promise is settled (fulfilled or rejected), false if pending

   @note A settled promise is either fulfilled or rejected, never pending
   @note Once settled, a promise's state will never change again
   @note This is equivalent to checking (!amxp_promise_is_pending(promise))
   @note This function is safe to call on promises in any state
 */
bool amxp_promise_is_settled(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Checks if the promise is pending.

   Determines whether the promise is currently in the pending state.
   A promise is pending when it has been created but has not yet been
   fulfilled or rejected.

   @param promise Pointer to the promise to check. Must not be NULL.

   @return true if the promise is in pending state, false otherwise

   @note A pending promise has not yet been settled and may still change state
   @note This is the initial state of all newly created promises
   @note This is equivalent to checking (!amxp_promise_is_settled(promise))
   @note This function is safe to call on promises in any state
 */
bool amxp_promise_is_pending(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Checks if the promise is a waitable promise.

   Determines whether the promise can be waited on using amxp_promise_wait().
   A promise is waitable if it's already settled or if a wait callback function
   was provided during promise creation.

   @param promise Pointer to the promise to check. Must not be NULL.

   @return true if the promise can be waited on, false otherwise

   @note Settled promises are always waitable regardless of whether they have a wait callback
   @note Pending promises are only waitable if they have a wait callback function
   @note Use this function before calling amxp_promise_wait() to avoid errors
   @note This function is safe to call on promises in any state
   @note This function will return true on a chained promise, but if one of the steps in the chain
         is not waitable, the @ref amxp_promise_wait will return AMXP_PROMISE_STATUS_NOT_SUPPORTED
 */
bool amxp_promise_is_waitable(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Gets the current status of the promise.

   Returns the status code of the promise. For fulfilled or pending promises,
   this is always AMXP_PROMISE_STATUS_OK. For rejected promises, this returns
   the status code that was provided when the promise was rejected, indicating
   the reason for rejection.

   @param promise Pointer to the promise to get status from. Must not be NULL.

   @return Status code of the promise. Common values include:
           - AMXP_PROMISE_STATUS_OK: Promise is fulfilled or pending
           - AMXP_PROMISE_STATUS_ABORTED: Chained promise was aborted.
           - AMXP_PROMISE_STATUS_CANCELED: Promise was canceled
           - AMXP_PROMISE_STATUS_TIMEOUT: Promise timed out
           - AMXP_PROMISE_STATUS_REJECTED: Promise was explicitly rejected
           - Other custom status codes as defined by the promise provider

   @note For pending and fulfilled promises, this always returns AMXP_PROMISE_STATUS_OK
   @note For rejected promises, this returns the rejection reason provided to amxp_promise_reject()
   @note The status code is set by the promise provider/creator when rejecting the promise
   @note This function is safe to call on promises in any state
 */
int32_t amxp_promise_get_status(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Gets the current value of the future.

   Returns a read-only pointer to the future value of the promise. For pending
   or rejected promises, the value is undefined. For fulfilled promises,
   this contains the final result value.

   @param promise Pointer to the promise to get the future from. Must not be NULL.

   @return Pointer to the future variant, or NULL if the promise is NULL.
           - For pending promises: variant with undefined content
           - For rejected promises: variant with undefined content
           - For fulfilled promises: variant containing the final result value

   @note The returned pointer is read-only and should not be modified
   @note The returned pointer remains valid until the promise is deleted
   @note Do not free or modify the returned variant - it is owned by the promise
   @note This function is safe to call on promises in any state
 */
const amxc_var_t* amxp_promise_get_future(const amxp_promise_t* promise);

/**
   @ingroup amxp_promise
   @brief
   Removes the future from the promise and claim ownership.

   Transfers ownership of the future variant from the promise to the caller.
   After this call, the promise's future will be set to NULL, and the caller
   becomes responsible for managing the returned variant's memory. This function
   can only be called on settled promises (fulfilled or rejected).

   @param promise Pointer to the promise to take the future from. Must not be NULL and must be settled.

   @return Pointer to the future variant that was removed from the promise, or NULL if:
           - The promise is NULL
           - The promise is not settled (still pending)
           - The future was already taken

   @note The caller takes ownership of the returned variant and must free it using amxc_var_delete()
   @note After this call, @ref amxp_promise_get_future() will return NULL for this promise
   @note This function can only be called on settled promises (fulfilled or rejected)
   @note The promise remains valid after this call, but its future will be NULL
   @note This function should only be called once per promise
 */
amxc_var_t* amxp_promise_take_future(amxp_promise_t* promise);

#ifdef __cplusplus
}
#endif

#endif // __AMXP_PROMISE_H