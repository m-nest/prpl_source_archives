/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "test_helpers.h"

int UpdateConnectionRequestURL(int service);

static void test_return_to_default(UNUSED void** st) {
    strncpy(gListenPort, "50805", 6);
    gListenPort[5] = '\0';
    g_call_update_ret = 0;

    int rc = UpdateConnectionRequestURL(SERVICE_NONE);
    assert_int_equal(rc, SUCCESS);
    assert_string_equal(g_last_host, "127.0.0.1");
    assert_string_equal(g_last_port, "50805");
}

static void test_ipv4_service(UNUSED void** st) {
    IGD.Updated = 1;
    snprintf(IGD.ExternalIPAddress, sizeof(IGD.ExternalIPAddress), "%s", "203.0.113.9");
    gExternalPort = 50806;
    g_call_update_ret = 0;

    int rc = UpdateConnectionRequestURL(SERVICE_WANIPCONNECTION);
    assert_int_equal(rc, SUCCESS);
    assert_string_equal(g_last_host, "203.0.113.9");
    assert_string_equal(g_last_port, "50806");
}

static void test_ipv6_service(UNUSED void** st) {
    IGD.Updated = 1;
    snprintf(IGD.ExternalIPAddress, sizeof(IGD.ExternalIPAddress), "%s", "ignored");
    strncpy(gListenPort, "50807", 6);
    gListenPort[5] = '\0';
    gUserIpMode = IP_MODE_IPV6;
    gIp6String = "2001:db8::dead:beef";
    g_call_update_ret = 0;

    int rc = UpdateConnectionRequestURL(SERVICE_WANIPV6FIREWALLCONTROL);
    assert_int_equal(rc, SUCCESS);
    assert_string_equal(g_last_host, "[2001:db8::dead:beef]");
    assert_string_equal(g_last_port, "50807");
}

static void test_call_fail_current_behavior(UNUSED void** st) {
    IGD.Updated = 1;
    snprintf(IGD.ExternalIPAddress, sizeof(IGD.ExternalIPAddress), "%s", "198.51.100.7");
    gExternalPort = 50808;
    g_call_update_ret = 1;

    int rc = UpdateConnectionRequestURL(SERVICE_WANIPCONNECTION);
    assert_int_equal(rc, SUCCESS); //Must be ERROR her !!!!!!!!!!!!
}

const struct CMUnitTest g_update_connreq_tests[] = {
    cmocka_unit_test(test_return_to_default),
    cmocka_unit_test(test_ipv4_service),
    cmocka_unit_test(test_ipv6_service),
    cmocka_unit_test(test_call_fail_current_behavior),
};
const size_t g_update_connreq_tests_count =
    sizeof(g_update_connreq_tests) / sizeof(g_update_connreq_tests[0]);
