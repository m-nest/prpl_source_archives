/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__RLYEH_CURL_H__)
#define __RLYEH_CURL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <rlyeh/rlyeh_status.h>
#include <rlyeh/rlyeh_auth.h>
#include <rlyeh/rlyeh_utils.h>

#include <amxc/amxc_string.h>
#include <curl/curl.h>

// Only for GET request
typedef enum _rlyeh_curl_file_type {
    FILE_TYPE_MANIFEST  = 0,
    FILE_TYPE_CONFIG  = 1,
    FILE_TYPE_BLOB = 2,
    FILE_TYPE_SIG = 3
} rlyeh_curl_file_type_t;

typedef enum {
    RLYEH_INVALID_INPUT_PARAMETER = -2,
    RLYEH_INVALID_SOURCE_OR_DESTINATION = -1,
    RLYEH_OK
} rlyeh_error_t;

typedef struct _rlyeh_curl_parameters {
    const char* username;
    const char* password;
    const char* token;
    const rlyeh_curl_file_type_t type;
    rlyeh_auth_type_t auth_type;
    bool cv; /* signature verification */
} rlyeh_curl_parameters_t;


int rlyeh_curl_init(void);
void rlyeh_curl_cleanup(void);

rlyeh_status_t rlyeh_curl_download_content(const rlyeh_curl_parameters_t* parameters, const amxc_string_t* url, void* data, curl_off_t* size, char* err_msg);

rlyeh_status_t rlyeh_curl_head(const rlyeh_curl_parameters_t* parameters, const amxc_string_t* url, void* data, curl_off_t* size, char* err_msg);

rlyeh_status_t rlyeh_curl_get_httpauthentication(const amxc_string_t* url, void* buf, long* auth, char* err_msg, bool cv);

rlyeh_status_t rlyeh_curl_get(const amxc_string_t* url, rlyeh_image_parameters_t* src, void* data, char* err_msg, bool cv);

rlyeh_error_t rlyeh_curl_parse_uri(const char* uri, rlyeh_image_parameters_t* image_params);
#ifdef __cplusplus
}
#endif

#endif // __RLYEH_CURL_H__
