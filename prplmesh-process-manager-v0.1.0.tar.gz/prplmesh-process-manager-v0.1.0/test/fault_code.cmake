set(PPM_CURRENT_TEST "fault_code")

add_executable(${PPM_CURRENT_TEST} fault_code.c common.h common.c)
target_compile_options(${PPM_CURRENT_TEST} PRIVATE -fPIC)
target_include_directories(${PPM_CURRENT_TEST} PRIVATE ${CMAKE_SOURCE_DIR}/include_priv)
target_link_libraries(${PPM_CURRENT_TEST} ${NAME}_objects amxc amxd amxo amxp amxj amxrt amxut sahtrace cmocka)
target_link_options(${PPM_CURRENT_TEST} PRIVATE -Wl,--wrap=amxrt_get_dm)
target_link_options(${PPM_CURRENT_TEST} PRIVATE -Wl,--wrap=process_monitor_service_status)
target_link_options(${PPM_CURRENT_TEST} PRIVATE -Wl,--wrap=process_monitor_service_control)

add_valgrind_test(${PPM_CURRENT_TEST} $<TARGET_FILE:${PPM_CURRENT_TEST}>)
