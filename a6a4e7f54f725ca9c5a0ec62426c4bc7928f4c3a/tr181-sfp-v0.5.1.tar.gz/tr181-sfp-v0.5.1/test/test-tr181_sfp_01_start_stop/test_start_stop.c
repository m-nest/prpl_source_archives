/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_start_stop.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

/* Other libraries' headers */
#include <amxc/amxc.h>        /* needed by amxd_types.h */
#include <amxc/amxc_macros.h> /* UNUSED */
#include <amxp/amxp_signal.h> /* needed by amxd_types.h */
#include <amxd/amxd_types.h>  /* amxd_dm_t */
#include <amxo/amxo_types.h>  /* amxo_parser_t */

/* Own headers */
#include "setup_and_teardown.h" /* setup_common() */
#include "sfpmgr_main.h"        /* _sfpmgr_main_) */
#include "sfpmgr_trace.h"

#undef ME
#define ME "runtest"

static amxd_dm_t dm;
static amxo_parser_t parser;

int test_setup(UNUSED void** state) {
    return setup_common(&dm, &parser, /*invoke_main_entry_point=*/ false);
}

int test_teardown(UNUSED void** state) {
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ false);
}

void test_start_plugin(UNUSED void** state) {
    const int rc = _sfpmgr_main(AMXO_START, &dm, &parser);
    assert_int_equal(rc, 0);
}

void test_invoke_main_entry_point_with_invalid_reason(UNUSED void** state) {
    const int invalid_reason = 99;
    const int rc = _sfpmgr_main(invalid_reason, &dm, &parser);
    assert_int_equal(rc, -1);
}

void test_invoke_main_entry_point_with_invalid_args(UNUSED void** state) {
    int rc;

    rc = _sfpmgr_main(AMXO_START, &dm, NULL);
    assert_int_equal(rc, -1);

    rc = _sfpmgr_main(AMXO_START, NULL, &parser);
    assert_int_equal(rc, -1);
}

void test_stop_plugin(UNUSED void** state) {
    const int rc = _sfpmgr_main(AMXO_STOP, &dm, &parser);
    assert_int_equal(rc, 0);
}
