/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_string.h>
#include <amxp/amxp.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <stdio.h>

#include <netmodel/client.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#include "amxc/amxc_string.h"
#include "tr181-gatewayinfo.h"
#include "event_handler.h"
#include "dm_interface.h"

struct App app;

#define ME "gatewayinfo"

/**
 * @file tr181-gatewayinfo.c
 * @brief Implementation of the TR-181 GatewayInfo. object.
 */

int _gatewayinfo_main(int reason, UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser) {
    int rc = 0;

    switch(reason) {
    case AMXO_START:
        app_init(&app);
        if(!netmodel_initialize()) {
            SAH_TRACEZ_ERROR(ME, "Cannot initialize libnetmodel");
            rc = -1;
            goto netmodel_init_failed;
        }
        rc = setup_subscriptions();
        if(rc) {
            SAH_TRACEZ_ERROR(ME, "Cannot initialize subscriptions, got %d", rc);
            goto setup_subscriptions_failed;
        }
        rc = register_cwmp_dm();
        if(rc) {
            SAH_TRACEZ_ERROR(ME, "Cannot register CWMP dm, got %d", rc);
            goto regitster_cwmp_dm_failed;
        }

        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*       tr181-gatewayinfo started      *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        break;
    case AMXO_STOP:
        deregister_cwmp_dm();

regitster_cwmp_dm_failed:
setup_subscriptions_failed:
        netmodel_cleanup();

netmodel_init_failed:
        DHCPGatewayInformation_deinit(&app.dhcpv6_gateway);
        DHCPGatewayInformation_deinit(&app.dhcpv4_gateway);
        memset(&app, 0, sizeof(struct App));

        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*      tr181-gatewayinfo stopped     *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        break;
    }

    return rc;
}

void DHCPGatewayInformation_init(struct DHCPGatewayInformation* gateway_information) {
    amxc_string_init(&gateway_information->DeviceManufacturerOUI, DEFAULT_STRING_BUFFER_SIZE);
    amxc_string_init(&gateway_information->DeviceProductClass, DEFAULT_STRING_BUFFER_SIZE);
    amxc_string_init(&gateway_information->DeviceSerialNumber, DEFAULT_STRING_BUFFER_SIZE);
}

void DHCPGatewayInformation_deinit(struct DHCPGatewayInformation* gateway_information) {
    amxc_string_clean(&gateway_information->DeviceManufacturerOUI);
    amxc_string_clean(&gateway_information->DeviceProductClass);
    amxc_string_clean(&gateway_information->DeviceSerialNumber);
}

void DHCPGatewayInformation_reset(struct DHCPGatewayInformation* gateway_information) {
    amxc_string_reset(&gateway_information->DeviceManufacturerOUI);
    amxc_string_reset(&gateway_information->DeviceProductClass);
    amxc_string_reset(&gateway_information->DeviceSerialNumber);
}

void DHCPGatewayInformation_copy(const struct DHCPGatewayInformation* src, struct DHCPGatewayInformation* dst) {
    amxc_string_copy(&dst->DeviceManufacturerOUI, &src->DeviceManufacturerOUI);
    amxc_string_copy(&dst->DeviceProductClass, &src->DeviceProductClass);
    amxc_string_copy(&dst->DeviceSerialNumber, &src->DeviceSerialNumber);
}

bool DHCPGatewayInformation_is_emtpy(const struct DHCPGatewayInformation* gateway_information) {
    return amxc_string_is_empty(&gateway_information->DeviceManufacturerOUI) &&
           amxc_string_is_empty(&gateway_information->DeviceProductClass) &&
           amxc_string_is_empty(&gateway_information->DeviceSerialNumber);
}

/**
 * Checks whether two amxc_string_t instances are equal
 *
 * @param[in] lhs first instance
 * @param[in] rhs second instance
 *
 * @return whether tow strings are equal
 */
static bool amxc_strings_equal(const amxc_string_t* lhs, const amxc_string_t* rhs) {
    return !strcmp(amxc_string_get(lhs, 0), amxc_string_get(rhs, 0));
}

bool DHCPGatewayInformation_equal(const struct DHCPGatewayInformation* lhs, const struct DHCPGatewayInformation* rhs) {
    return amxc_strings_equal(&lhs->DeviceManufacturerOUI, &rhs->DeviceManufacturerOUI) && amxc_strings_equal(&lhs->DeviceProductClass, &rhs->DeviceProductClass) && amxc_strings_equal(&lhs->DeviceSerialNumber, &rhs->DeviceSerialNumber);
}

void app_init(struct App* application) {
    memset(application, 0, sizeof(struct App));
    DHCPGatewayInformation_init(&app.dhcpv4_gateway);
    DHCPGatewayInformation_init(&app.dhcpv6_gateway);
}
