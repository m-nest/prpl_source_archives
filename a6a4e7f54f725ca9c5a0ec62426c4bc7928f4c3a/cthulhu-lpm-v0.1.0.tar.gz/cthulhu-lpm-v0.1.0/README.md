# Local Policy Manager Plugin

[[_TOC_]]

---

## Introduction

The **cthulhu-lpm** plugin extends the [Cthulhu](https://gitlab.com/prpl-foundation/lcm/applications/cthulhu) container management system by adding the capability to manage containers during the upgrade phase through policy configuration. This allows you to specify which containers should be installed, upgraded, removed, or restored.

The **cthulhu-lpm** plugin uses the `cthulhu_prestartup_config_t` structure to provide Cthulhu with the list of containers to be restored, installed, upgraded, or removed.  
**Note:** This plugin does not handle the actual installation, removal, restoration, or upgrade of containers; it only manages the configuration.
**Note:** This plugin does not manage the pre-embedding of container images required for installation or upgrade.

---
## Configuration

### Policy File Overview

The policy file is the primary configuration file used by the Local Policy Manager. Its location is specified by the data model parameter:  
`Cthulhu.Information.LocalPolicyManager.PolicyFile`

This file is written in JSON format and consists of two main sections:

- **Global Container Policy**
- **Application-Specific Container Policy**

---

### Global Container Policy

The global section defines default actions for all containers based on specific events. It consists of a list of:

- **EVENTS:** Types of situations that can occur for any container.
- **ACTIONS:** The corresponding actions to perform for each event.

---

### Application-Specific Container Policy

The application-specific section allows you to override global actions for individual containers. Each entry includes:

- `uuid`: The unique identifier for the container/application (as specified in the `InstallDU()` command with the UUID parameter).
- **EVENTS:** Specific situations or transitions for this container.
- **ACTIONS:** The actions to take for each event.
- `description` (optional): A field for debugging or descriptive purposes.

---

### Policy Resolution Logic

When an event occurs, the system first checks for an application-specific policy for the relevant container. If none exists, or if the event is not defined for that application, the system falls back to the global policy.

- For application-specific policies, only the `uuid` field is mandatory. All other fields are optional.
- **Note:** If no matching event is found during policy processing, a fatal exception is raised and all container upgrades are aborted. (See the error handling section for details.)

---

### Supported EVENTS and ACTIONS

| EVENT                | Description                                                                 | Possible ACTIONS         |
|----------------------|-----------------------------------------------------------------------------|-------------------------|
| `onNew`              | New container present in firmware, not currently installed on the gateway   | INSTALL, IGNORE         |
| `onExistingUpgrade`  | Container present in new firmware and already installed; firmware version is higher than installed version | UPDATE, UNINSTALL, IGNORE |
| `onExistingDowngrade`| Container present in new firmware and already installed; firmware version is lower than installed version | UPDATE, UNINSTALL, IGNORE |
| `onExisting`         | Container present in new firmware and already installed; versions are equal or no specific upgrade/downgrade policy | UPDATE, UNINSTALL, IGNORE |
| `onUnknown`          | Container not present in firmware but currently installed on the gateway    | UNINSTALL, IGNORE       |

---

### Example Policy File

```json
{
  "containerpolicy": {
    "global": {
      "onNew": "INSTALL",
      "onExisting": "IGNORE",
      "onExistingUpgrade": "UPDATE",
      "onExistingDowngrade": "IGNORE",
      "onUnknown": "IGNORE"
    },
    "applications": [
      {
        "uuid": "37a49331-0b30-4afc-8e3e-2a33e5f560b7",
        "description": "first container",
        "onNew": "IGNORE",
        "onExisting": "UNINSTALL"
      },
      {
        "uuid": "edc8f3cb-e91a-4c8c-88e8-043a4ff96ee0",
        "description": "second container",
        "onExisting": "UNINSTALL"
      }
      // Additional application-specific entries...
    ]
  }
}
```

### Version Management

To determine whether an `onExistingUpgrade` or `onExistingDowngrade` event has occurred, containers are compared using the version specified in the `ModuleVersion` field.  
`ModuleVersion` is a global version identifier and is not linked to the OCI image tag.

- Versions must follow [Semantic Versioning 2.0.0](https://semver.org/), but only the `<version core>` component (i.e., the numerical part) is supported.

#### Valid semantic versioning formats:

```shell
<valid semver> ::= <version core>
                | <version core> "-" <pre-release>
                | <version core> "+" <build>
                | <version core> "-" <pre-release> "+" <build>

<version core> ::= <major> "." <minor> "." <patch>
<major>        ::= <numeric identifier>
<minor>        ::= <numeric identifier>
<patch>        ::= <numeric identifier>
```

However, **only the `<version core>` format** (e.g., `1.2.3`) is supported. Pre-release and build metadata are not allowed.

If the version does not conform to the `<version core>` format, policy execution will not be possible.




## Building, installing and testing

### Building

### Docker container

You could install all tools needed for testing and developing on your local machine, but it is easier to just use a pre-configured environment. Such an environment is already prepared for you as a docker container.

1. Install docker

    Docker must be installed on your system.

    If you have no clue how to do this here are some links that could help you:

    - [Get Docker Engine - Community for Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

    Make sure you user id is added to the docker group:

    ```
    sudo usermod -aG docker $USER
    ```

1. Fetch the container image

    To get access to the pre-configured environment, all you need to do is pull the image and launch a container.

    Pull the image:

    ```bash
    docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest
    ```

    Before launching the container, you should create a directory which will be shared between your local machine and the container.

    ```bash
    mkdir -p ~/workspace/lcm
    ```

    Launch the container:

    ```bash
    docker run -ti -d --name oss-dbg --restart always --cap-add=SYS_PTRACE --sysctl net.ipv6.conf.all.disable_ipv6=1 -e "USER=$USER" -e "UID=$(id -u)" -e "GID=$(id -g)" -v ~/amx/:/home/$USER/workspace/lcm/ registry.gitlab.com/soft.at.home/docker/oss-dbg:latest
    ```

    The `-v` option bind mounts the local directory for the lcm project in the container, at the exact same place.
    The `-e` options create environment variables in the container. These variables are used to create a user name with exactly the same user id and group id in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

    ```bash
    docker exec -ti --user $USER oss-dbg /bin/bash
    ```

#### Prerequisites

- [lib\_amxc](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxc)
- [lib\_amxp](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxp)
- [lib\_amxd](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxd)
- [lib\_amxo](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxo)
- [lib\_amxm](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxm)
- [lib\_amxb](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxb)
- [libcthulhu](https://gitlab.com/prpl-foundation/lcm/libraries/libcthulhu)
- [liblcm](https://gitlab.com/prpl-foundation/lcm/libraries/liblcm)
- [lib\_sahtrace](https://gitlab.com/prpl-foundation/components/core/libraries/libsahtrace)


#### Build cthulhu-lpm

1. Clone the git repository

    To be able to build it, you need the source code. So make a directory for the LCM and clone this library in it.

    ```bash
    mkdir -p ~/workspace/lcm/plugins/cthulhu
    cd ~/workspace/lcm/plugins/cthulhu
    git clone https://gitlab.com/prpl-foundation/lcm/plugins/cthulhu/cthulhu-lpm
    ```

1. Install dependencies

    Although the container will contain all tools needed for building, it does not contain all the libraries needed for building `cthulhu-lpm`. To be able to build `libcthulhu` you need certain libraries to be installed in the container.

    ```bash
    sudo apt update
    sudo apt install libamxc
    sudo apt install libamxp
    sudo apt install libamxd
    sudo apt install libamxo
    sudo apt install libamxm
    sudo apt install libamxb
    sudo apt install liblcm
    sudo apt install libcthulhu
    sudo apt install libsahtrace
    ```

1. Build it

   In the container:

    ```bash
    cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm
    make
    ```

### Installing

#### Using make target install

You can install your own compiled version easily in the container by running the install target.

```bash
cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm
sudo -E make install
```

#### Using package

From within the container you can create packages.

```bash
cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm
make package
```

The packages generated are:

```
~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/output/x86_64-linux-gnu/cthulhu-lpm-<VERSION>.tar.gz
~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/output/x86_64-linux-gnu/cthulhu-lpm<VERSION>.deb
```

You can copy these packages and extract/install them.

For ubuntu or debian distributions use dpkg:

```bash
sudo dpkg -i ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/output/x86_64-linux-gnu/cthulhu-lpm_<VERSION>.deb
```

### Testing

#### Prerequisites

No extra components are needed for testing.

#### Run tests

You can run the tests by executing the following command.

```bash
cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/tests
make test
```

Or this command if you also want the coverage tests to run:

```bash
cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/tests
make run coverage
```

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each file (*.c files) is printed in your console after the tests are run.
A HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used.
Example: using native gcc
When the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/workspace/lcm/plugins/cthulhu/cthulhu-lpm/cthulhu/output/x86_64-linux-gnu/coverage/report.`

You can easily access the reports in your browser.
In the container start a python3 http server in background.

```bash
cd ~/workspace/lcm/plugins/cthulhu/cthulhu-lpm
python3 -m http.server 8080 &
```

Use the following url to access the reports `http://<IP ADDRESS OF YOUR CONTAINER>:8080/workspace/lcm/plugins/cthulhu/cthulhu-lpm/output/<MACHINE>/coverage/report`
You can find the ip address of your container by using the `ip` command in the container.

Example:

```bash
$ ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host
       valid_lft forever preferred_lft forever
173: eth0@if174: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default
    link/ether 02:42:ac:11:00:07 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet 172.17.0.7/16 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 2001:db8:1::242:ac11:7/64 scope global nodad
       valid_lft forever preferred_lft forever
    inet6 fe80::42:acff:fe11:7/64 scope link
       valid_lft forever preferred_lft forever
```

in this case the ip address of the container is `172.17.0.7`.
So the uri you should use is: `http://172.17.0.7:8080/workspace/lcm/plugins/cthulhu/cthulhu-lpm/output/x86_64-linux-gnu/coverage/report/`

