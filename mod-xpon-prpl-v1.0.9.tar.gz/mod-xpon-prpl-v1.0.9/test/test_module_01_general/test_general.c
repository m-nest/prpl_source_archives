/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_general.h"

/* System headers */
#include <errno.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h> /* strcmp() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>

/* Own headers */
#include "mod_xpon_trace.h"

#undef ME
#define ME "runtest"

#define MOD_NAME "module"
#define MOD_PATH "../module_under_test/" MOD_NAME ".so"
#define MOD_PON_CTRL "pon_ctrl"

/**
 * Set up the unit tests.
 */
int test_general_setup(UNUSED void** state) {
    sahTraceOpen("mytest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "module");  /* traces from the module under test */
    sahTraceAddZone(500, "runtest"); /* traces from the run_test program */
    return 0;
}

/**
 * Tear down the unit tests.
 */
int test_general_teardown(UNUSED void** state) {
    return 0;
}

/**
 * Test that the module under test can be loaded.
 *
 * Load the module ../module_under_test/module.so.
 */
void test_can_load_module(UNUSED void** state) {

    SAH_TRACEZ_INFO(ME, "*** test_can_load_module");
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

/**
 * Test the function set_max_nr_of_onus().
 *
 * Call set_max_nr_of_onus() to set the nr of ONUs to 1 and check that the call
 * succeeds.
 */
void test_set_max_nr_of_onus(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "*** test_set_max_nr_of_onus");

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set(uint32_t, &args, 1);
    const int rc =
        amxm_execute_function(MOD_NAME, MOD_PON_CTRL, "set_max_nr_of_onus",
                              &args, &ret);
    assert_int_equal(rc, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

/**
 * Test the get_list_of_instances() for XPON.ONU.
 *
 * Call get_list_of_instances() to query the number of instances of XPON.ONU.
 * Check it returns there is one instance with index 1.
 */
static void test_onu_instances(void) {
    SAH_TRACEZ_INFO(ME, "*** test_onu_instances");

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set(cstring_t, &args, "XPON.ONU");
    const int rc =
        amxm_execute_function(MOD_NAME, MOD_PON_CTRL, "get_list_of_instances",
                              &args, &ret);
    assert_int_equal(rc, 0);
    const char* const indexes = GET_CHAR(&ret, "indexes");
    assert_non_null(indexes);
    assert_int_equal(strcmp(indexes, "1"), 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

/**
 * Test the get_list_of_instances() for XPON.ONU.1.SoftwareImage.
 *
 * Call get_list_of_instances() to query the number of instances of
 * XPON.ONU.1.SoftwareImage. Check it returns there are 2 instances with indexes
 * 1 and 2.
 */
static void test_sw_images_instances(void) {
    SAH_TRACEZ_INFO(ME, "*** test_sw_images_instances");

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set(cstring_t, &args, "XPON.ONU.1.SoftwareImage");
    const int rc =
        amxm_execute_function(MOD_NAME, MOD_PON_CTRL, "get_list_of_instances",
                              &args, &ret);
    assert_int_equal(rc, 0);
    const char* const indexes = GET_CHAR(&ret, "indexes");
    assert_non_null(indexes);
    assert_int_equal(strcmp(indexes, "1,2"), 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

/**
 * Test the function get_list_of_instances().
 *
 * Call get_list_of_instances() for 2 template objects:
 * - XPON.ONU
 * - XPON.ONU.1.SoftwareImage
 *
 * Check the calls succeed and return the correct number of instances.
 */
void test_get_list_of_instances(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "*** test_get_list_of_instances");
    test_onu_instances();
    test_sw_images_instances();
}

/**
 * Test the function get_object_content() for XPON.ONU.1.
 *
 * Call get_object_content() to get the content of XPON.ONU.1 and check if it's
 * as expected.
 */
static void test_onu_content(void) {
    SAH_TRACEZ_INFO(ME, "*** test_onu_content");

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    amxc_var_add_key(uint32_t, &args, "index", 1);
    const int rc =
        amxm_execute_function(MOD_NAME, MOD_PON_CTRL, "get_object_content",
                              &args, &ret);
    assert_int_equal(rc, 0);

    /* Check content of 'ret' */
    assert_true(amxc_var_type_of(&ret) == AMXC_VAR_ID_HTABLE);
    const amxc_var_t* const keys = GET_ARG(&ret, "keys");
    const amxc_var_t* const parameters = GET_ARG(&ret, "parameters");
    assert_non_null(keys);
    assert_non_null(parameters);
    const char* const name = GET_CHAR(keys, "Name");
    assert_int_equal(strcmp(name, "ONU_ONE"), 0);
    const bool enable = GET_BOOL(parameters, "Enable");
    assert_true(enable);
    const char* const version = GET_CHAR(parameters, "Version");
    assert_int_equal(strcmp(version, "v1.2.3"), 0);
    const char* const equipment_id = GET_CHAR(parameters, "EquipmentID");
    assert_int_equal(strcmp(equipment_id, "MyEquipment"), 0);
    const char* const power_capability = GET_CHAR(parameters, "PowerCapability");
    assert_int_equal(strcmp(power_capability, "On,Off,LowPower"), 0);
    const char* const power_status = GET_CHAR(parameters, "PowerStatus");
    assert_int_equal(strcmp(power_status, "On"), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

/**
 * Test the function get_object_content() for XPON.ONU.1.EthernetUNI.1.
 *
 * Call get_object_content() to get the content of XPON.ONU.1.EthernetUNI.1 and
 * check if it's as expected.
 */
static void test_ethernet_uni_content(void) {
    SAH_TRACEZ_INFO(ME, "*** test_ethernet_uni_content");

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU.1.EthernetUNI");
    amxc_var_add_key(uint32_t, &args, "index", 1);
    const int rc =
        amxm_execute_function(MOD_NAME, MOD_PON_CTRL, "get_object_content",
                              &args, &ret);
    assert_int_equal(rc, 0);

    /* Check content of 'ret' */
    assert_true(amxc_var_type_of(&ret) == AMXC_VAR_ID_HTABLE);
    const amxc_var_t* const keys = GET_ARG(&ret, "keys");
    const amxc_var_t* const parameters = GET_ARG(&ret, "parameters");
    assert_non_null(keys);
    assert_non_null(parameters);
    const char* const name = GET_CHAR(keys, "Name");
    assert_int_equal(strcmp(name, "MyEthernetUNI"), 0);
    const char* const status = GET_CHAR(parameters, "Status");
    assert_int_equal(strcmp(status, "Up"), 0);
    const char* const anis = GET_CHAR(parameters, "ANIs");
    assert_int_equal(strcmp(anis, "XPON.ONU.1.ANI.1"), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

/**
 * Test the function test_get_object_content().
 *
 * Get the content of following objects and check their content is as expected:
 * - XPON.ONU.1
 * - XPON.ONU.1.EthernetUNI.1
 */
void test_get_object_content(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "*** test_get_object_content");

    test_onu_content();
    test_ethernet_uni_content();
}

/**
 * Test unloading the module.
 */
void test_can_close_module(UNUSED void** state) {
    SAH_TRACEZ_DEBUG(ME, "*** test_can_close_module");
    assert_int_equal(amxm_close_all(), 0);
}

