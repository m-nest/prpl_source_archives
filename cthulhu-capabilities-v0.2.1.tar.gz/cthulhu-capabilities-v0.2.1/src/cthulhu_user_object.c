/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


/**
 * @file cthulhu_user_object.c
 * @brief User object management implementation for the Cthulhu Capabilities plugin.
 *
 * Handles connection to the Device.Users component, user role caching, and bus event subscriptions.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>
#include <amxb/amxb_be_intf.h>
#include <amxd/amxd_transaction.h>

#include <lcm/lcm_assert.h>
#include <debug/sahtrace.h>
#include <cthulhu/cthulhu_defines.h>

#include "cthulhu_capabilities_common.h"
#include "cthulhu_user_object.h"
#include "cthulhu_user_role.h"
#include "cthulhu-capabilities/cthulhu_capabilities_defines.h"

#define ME "capabilities"

#define GET_TIMEOUT 10

#define ENABLE "Enable"
#define ROLEID "RoleID"
#define ROLENAME "RoleName"
#define REQUIREDCAPABILITIES "RequiredCapabilities"

static amxb_bus_ctx_t* amxb_bus_ctx_user = NULL;



/**
 * @brief Gets the bus context for the user component, connecting if necessary.
 * @return Pointer to the bus context, or NULL if not available.
 */
static amxb_bus_ctx_t* get_user_busctx(void);

/**
 * @brief Unsubscribes from user-related bus events.
 * @param all If true, unsubscribes from all events including app start/stop.
 */
static void user_unsubscribe(bool all);

/**
 * @brief Waits for the user component to become available and connects.
 * @return 0 on success, non-zero on failure.
 */
static int wait_and_connect_user(void);

/**
 * @brief Callback for when the bus connection is deleted.
 */
static void connection_deleted_callback(UNUSED const char* const sig_name,
                                        UNUSED const amxc_var_t* const data,
                                        UNUSED void* priv) {
    if(amxc_var_type_of(data) != AMXC_VAR_ID_FD) {
        return;
    }

    amxb_bus_ctx_t* ctx = get_user_busctx();
    if(ctx && (amxb_get_fd(ctx) == amxc_var_dyncast(fd_t, data))) {
        SAH_TRACEZ_WARNING(ME, "Connection to bus implementing [%s] lost", USERS_ROOT);
        amxb_bus_ctx_user = NULL;
    }
}

static amxb_bus_ctx_t* get_user_busctx(void) {
    amxb_bus_ctx_t* bus_ctx = amxb_bus_ctx_user;
    if(bus_ctx) {
        goto exit;
    }
    bus_ctx = amxb_be_who_has_ex(USERS_ROOT, true);
    CHECK_NULL_LOG(WARNING, bus_ctx, goto exit, "[" USERS_ROOT "] is not present in the datamodel");
    amxb_bus_ctx_user = bus_ctx;
    amxp_slot_connect(NULL, "connection-deleted", NULL, connection_deleted_callback, NULL);
exit:
    return bus_ctx;
}

/**
 * @brief Sets the available user roles for a sandbox object.
 *
 * Updates the sandbox object with the provided list of available user roles and their paths.
 *
 * @param sb_obj Pointer to the sandbox object.
 * @param new_available_roles List of new available roles.
 * @return 0 on success, non-zero on failure.
 */
static int sb_set_available_user_roles(amxd_object_t* sb_obj, amxc_var_t* new_available_roles) {
    int res = -1;
    amxd_trans_t trans;
    amxc_var_t role_name_list;
    amxc_var_t role_path_list;
    amxc_string_t role_name_csv;
    amxc_string_t role_path_csv;
    amxd_status_t status;

    amxd_trans_init(&trans);
    amxc_var_init(&role_name_list);
    amxc_var_init(&role_path_list);
    amxc_string_init(&role_name_csv, 0);
    amxc_string_init(&role_path_csv, 0);

    amxc_var_set_type(&role_name_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(&role_path_list, AMXC_VAR_ID_LIST);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, sb_obj);

    amxc_var_for_each(role, new_available_roles) {
        const char* rolename = GET_CHAR(role, NULL);
        CHECK_STR_EMPTY_LOG(INFO, rolename, continue, "Role name is empty, it will be ignored");
        user_role_t* user_role = user_role_find_by_name(rolename);
        if(user_role) {
            ASSERT_NOT_NULL(amxc_var_add_new_cstring_t(&role_name_list, user_role->name), goto exit,
                            "Failed to add name for user role [%s:%s]", rolename, user_role->name);
            ASSERT_NOT_NULL(amxc_var_add_new_cstring_t(&role_path_list, user_role->named_path), goto exit,
                            "Failed to add path for user role [%s:%s]", rolename, user_role->named_path);
        } else {
            SAH_TRACEZ_NOTICE(ME, "Role [%s] is not present anymore in %s so it will be removed from the sandbox", rolename, ROLE_DM);
        }
    }
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_name_csv, &role_name_list), goto exit, "Failed to convert role names to csv string");
    ASSERT_SUCCESS(amxc_string_csv_join_var(&role_path_csv, &role_path_list), goto exit, "Failed to convert role paths to csv string");

    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, amxc_string_get(&role_name_csv, 0));
    amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, amxc_string_get(&role_path_csv, 0));

    status = amxd_trans_apply(&trans, get_dm());
    ASSERT_EQUAL(status, amxd_status_ok, goto exit,
                 "Transaction failed. " CTHULHU_SANDBOX_AVAILABLE_USER_ROLES " & " CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES " not added to DM. Status: %d", status);

    res = 0;
exit:
    amxd_trans_clean(&trans);
    amxc_var_clean(&role_name_list);
    amxc_var_clean(&role_path_list);
    amxc_string_clean(&role_name_csv);
    amxc_string_clean(&role_path_csv);
    return res;

}

/**
 * @brief Removes a user role from all sandboxes where it is present.
 *
 * @param rolename Name of the role to remove.
 * @return 0 on success, non-zero on failure.
 */
static int user_role_remove_from_sb(const char* rolename) {
    int res = -1;
    amxd_object_t* sb_instances = NULL;
    char* old_available_roles = NULL;
    amxc_var_t old_available_roles_list;

    amxc_var_init(&old_available_roles_list);

    sb_instances = amxd_dm_findf(get_dm(), CTHULHU_DM_SANDBOX_INSTANCES ".");
    ASSERT_NOT_NULL(sb_instances, goto exit, "Could not get [%s] from the datamodel", CTHULHU_DM_SANDBOX_INSTANCES);
    amxd_object_for_each(instance, it, sb_instances) {
        amxd_object_t* sb_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        old_available_roles = amxd_object_get_cstring_t(sb_instance, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, NULL);
        if(STRING_EMPTY(old_available_roles)) {
            free_null(old_available_roles);
            continue;
        }
        if(csv_string_to_list(old_available_roles, &old_available_roles_list, NULL)) {
            SAH_TRACEZ_ERROR(ME, "String split failed of roles [%s]", old_available_roles);
            free_null(old_available_roles);
            amxc_var_clean(&old_available_roles_list);
            continue;
        }
        if(var_list_contains(&old_available_roles_list, rolename)) {
            SAH_TRACEZ_INFO(ME, "Remove user role [%s] from sandbox", rolename);
            // sb_set_available_user_roles will check if the roles exist, and
            // skip the non-existing ones. This is why it is acceptable to provide
            // old_available_roles_list here
            sb_set_available_user_roles(sb_instance, &old_available_roles_list);
        }
        free_null(old_available_roles);
        amxc_var_clean(&old_available_roles_list);
    }

    res = 0;
exit:
    amxc_var_clean(&old_available_roles_list);

    return res;
}

/**
 * @brief Callback for when a user role is added in the data model.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data containing role information.
 * @param priv Private data (unused).
 */
static void user_role_added(UNUSED const char* const sig_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv) {
    user_role_t* user_role = NULL;
    const char* path = GET_CHAR(data, "path");
    char* indexed_path = NULL;

    if(strncmp(path, ROLE_DM, (sizeof(ROLE_DM) - 1)) != 0) {
        SAH_TRACEZ_INFO(ME, "Subscription returned notification on child: %s", path);
        return;
    }

    amxc_var_t* parameters = GET_ARG(data, "parameters");
    bool enabled = GET_BOOL(parameters, ENABLE);
    if(!enabled) {
        return;
    }
    const char* rolename = GET_CHAR(parameters, ROLENAME);
    const char* capabilities = GET_CHAR(parameters, REQUIREDCAPABILITIES);
    int index = GET_UINT32(data, "index");
    ASSERT_TRUE(asprintf(&indexed_path, "%s%u.", path, index) > 0, goto exit, "failed to create string");


    user_role_add(&user_role, rolename, indexed_path, capabilities);
    ASSERT_TRUE(user_role, return , "Failed to create a user_role object");

    SAH_TRACEZ_INFO(ME, "Added Role '%s' (%s) to the cached list", user_role->name, user_role->indexed_path);
exit:
    free(indexed_path);
}

/**
 * @brief Callback for when a user role is removed from the data model.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data containing role information.
 * @param priv Private data (unused).
 */
static void user_role_removed(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    user_role_t* user_role = NULL;
    const char* path = GET_CHAR(data, "path");

    if(strncmp(path, ROLE_DM, (sizeof(ROLE_DM) - 1)) != 0) {
        SAH_TRACEZ_INFO(ME, "Subscription returned notification on child: %s", path);
        return;
    }

    amxc_var_t* parameters = GET_ARG(data, "parameters");
    const char* rolename = GET_CHAR(parameters, ROLENAME);
    ASSERT_STR_NOT_EMPTY(rolename, return , "Argument [%s] is empty", ROLENAME);

    user_role = user_role_find_by_name(rolename);
    CHECK_NULL_LOG(NOTICE, user_role, return , "User role [%s] is not found in the cache", rolename);

    ASSERT_SUCCESS(user_role_delete(&user_role), return , "Failed to remove user [%s] from the cache", rolename);
    user_role_remove_from_sb(rolename);

    SAH_TRACEZ_INFO(ME, "Removed role [%s] from the cache", rolename);
}

/**
 * @brief Adds a user role from a given data model path.
 *
 * @param path Data model path to the user role.
 */
static void user_add_from_path(const char* path) {
    amxc_var_t result;
    amxc_var_t* role;
    amxc_var_init(&result);
    ASSERT_STR_NOT_EMPTY(path, goto exit);

    amxb_bus_ctx_t* bus_ctx = get_user_busctx();
    ASSERT_TRUE(bus_ctx, goto exit);

    ASSERT_SUCCESS(amxb_get(bus_ctx, path, 0, &result, GET_TIMEOUT), goto exit,
                   "[%s] is not present in the datamodel", path);
    role = amxc_var_get_first(amxc_var_get_first(&result));
    ASSERT_TRUE(role, goto exit, "Could not get data for role [%s]", path);
    const char* rolename = GET_CHAR(role, ROLENAME);
    const char* capabilities = GET_CHAR(role, REQUIREDCAPABILITIES);
    user_role_t* user_role = NULL;
    user_role_add(&user_role, rolename, path, capabilities);

exit:
    amxc_var_clean(&result);
}

/**
 * @brief Callback for when a user role is changed in the data model.
 *
 * Handles changes to Enable and RequiredCapabilities fields.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data containing change information.
 * @param priv Private data (unused).
 */
static void user_role_changed(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    // check if Enable changed
    amxc_var_t* var = amxc_var_get_path(data, "parameters.Enable.to", AMXC_VAR_FLAG_DEFAULT);
    if(var) {
        bool enable = GET_BOOL(var, NULL);
        if(enable) {
            // add the user since it got enabled
            user_add_from_path(GET_CHAR(data, "path"));
        } else {
            const char* path = GET_CHAR(data, "path");
            user_role_t* user_role = user_role_find_by_indexed_path(path);
            if(user_role) {
                SAH_TRACEZ_INFO(ME, "Remove disabled role [%s]", path);
                char* rolename = strdup(user_role->name);
                user_role_delete(&user_role);
                user_role_remove_from_sb(rolename);
                free(rolename);
            }
        }
        // since user is added or removed, other changes are irrelevant
        return;
    }
    // check if Capabilities changed
    var = amxc_var_get_path(data, "parameters.RequiredCapabilities.to", AMXC_VAR_FLAG_DEFAULT);
    if(var) {
        // update capabilities of user
        const char* path = GET_CHAR(data, "path");
        user_role_t* user_role = user_role_find_by_indexed_path(path);
        if(user_role) {
            const char* new_caps = GET_CHAR(var, NULL);
            SAH_TRACEZ_INFO(ME, "update capabilities of user [%s] to [%s]", path, new_caps);
            amxc_var_clean(&user_role->capabilities);
            const char* reason = NULL;
            if(csv_string_to_list(new_caps, &user_role->capabilities, &reason)) {
                SAH_TRACEZ_ERROR(ME, "Could not convert string [%s] to list. Error (%s)", new_caps, reason);
            }
        }
    }
}

/**
 * @brief Callback for when the user application stops.
 *
 * Cleans up and prepares to reconnect when the app restarts.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data (unused).
 * @param priv Private data (unused).
 */
static void user_app_stopped(UNUSED const char* const sig_name,
                             UNUSED const amxc_var_t* const data,
                             UNUSED void* const priv) {
    SAH_TRACEZ_ERROR(ME, "[%s] app stopped, trying to recover when it gets back up", USERS_ROOT);
    user_unsubscribe(false);
    amxb_bus_ctx_user = NULL;
    user_role_list_clean();
    wait_and_connect_user();
}

/**
 * @brief Callback for when the user application starts.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data (unused).
 * @param priv Private data (unused).
 */
static void user_app_started(UNUSED const char* const sig_name,
                             UNUSED const amxc_var_t* const data,
                             UNUSED void* const priv) {
    SAH_TRACEZ_ERROR(ME, "[%s] app started", USERS_ROOT);

}

/**
 * @brief Probes the user data model and populates the user role cache.
 *
 * Subscribes to role add/remove/change events and app start/stop events.
 *
 * @return 0 on success, non-zero on failure.
 */
static int user_probe(void) {
    int res = -1;
    amxc_var_t roles;

    amxc_var_init(&roles);

    amxb_bus_ctx_t* bus_ctx = get_user_busctx();
    CHECK_NULL_LOG(WARNING, bus_ctx, goto exit);

    ASSERT_SUCCESS(amxb_get(bus_ctx, ROLE_DM, 0, &roles, GET_TIMEOUT), goto exit,
                   "["ROLE_DM "] is not present in the datamodel");

    amxc_var_t* roles_list = amxc_var_get_first(&roles);
    ASSERT_NOT_NULL(roles_list, goto exit, "Variant returned is not a list");

    user_role_list_clean();

    amxc_var_for_each(role, roles_list) {
        bool enable = GET_BOOL(role, ENABLE);
        if(!enable) {
            continue;
        }
        const char* rolepath = amxc_var_key(role);
        const char* rolename = GET_CHAR(role, ROLENAME);
        const char* capabilities = GET_CHAR(role, REQUIREDCAPABILITIES);

        user_role_t* user_role = NULL;
        user_role_add(&user_role, rolename, rolepath, capabilities);
        ASSERT_TRUE(user_role, goto exit, "Failed to create a user_role object");

        SAH_TRACEZ_INFO(ME, "Added Role '%s' (%s) to the cached list", user_role->name, user_role->indexed_path);
    }

    ASSERT_EQUAL(amxb_subscribe(bus_ctx, ROLE_DM, "notification == 'dm:instance-added'", user_role_added, NULL),
                 AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to added instances on %s", ROLE_DM);

    ASSERT_EQUAL(amxb_subscribe(bus_ctx, ROLE_DM, "notification == 'dm:instance-removed'", user_role_removed, NULL),
                 AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to removed instances on %s", ROLE_DM);

    ASSERT_EQUAL(amxb_subscribe(bus_ctx, ROLE_DM, "notification == 'dm:object-changed'", user_role_changed, NULL),
                 AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to object changed on %s", ROLE_DM);

    ASSERT_EQUAL(amxb_subscribe_ex(bus_ctx, USERS_ROOT, 0, AMXB_BE_EVENT_TYPE_EVENT, "notification == 'app:stop'",
                                   user_app_stopped, NULL), AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to stopping of the " USERS_ROOT);

    ASSERT_EQUAL(amxb_subscribe_ex(bus_ctx, USERS_ROOT, 0, AMXB_BE_EVENT_TYPE_EVENT, "notification == 'app:start'",
                                   user_app_started, NULL), AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to starting of the " USERS_ROOT);

exit:
    amxc_var_clean(&roles);
    return res;
}

/**
 * @brief Callback for when the user data model becomes available.
 *
 * @param sig_name Signal name (unused).
 * @param data Event data (unused).
 * @param priv Private data (unused).
 */
static void user_dm_available_event(UNUSED const char* const sig_name,
                                    UNUSED const amxc_var_t* const data,
                                    UNUSED void* priv) {
    user_probe();
    amxp_slot_disconnect(NULL, USERS_WAIT_EVENT, user_dm_available_event);
}

static void user_unsubscribe(bool all) {
    amxb_bus_ctx_t* bus_ctx = get_user_busctx();
    if(bus_ctx) {
        amxb_unsubscribe(bus_ctx, ROLE_DM, user_role_added, NULL);
        amxb_unsubscribe(bus_ctx, ROLE_DM, user_role_removed, NULL);
        amxb_unsubscribe(bus_ctx, ROLE_DM, user_role_changed, NULL);
        if(all) {
            amxb_unsubscribe(bus_ctx, ROLE_DM, user_app_stopped, NULL);
            amxb_unsubscribe(bus_ctx, ROLE_DM, user_app_started, NULL);
        }
    }
}

static int wait_and_connect_user(void) {
    int res = -1;
    ASSERT_SUCCESS(amxp_slot_connect_filtered(NULL, USERS_WAIT_EVENT, NULL, user_dm_available_event, NULL),
                   goto exit, "Could not subscribe to wait event");

    amxb_wait_for_object(USERS_ROOT);
    res = 0;
exit:
    return res;
}

/**
 * @brief Initializes the user object subsystem.
 *
 * Manages the connection to the Device.Users component on the bus.
 *
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_user_object_init(void) {
    int res = -1;
    if(user_probe() != 0) {
        ASSERT_SUCCESS(wait_and_connect_user(), goto exit);
    }
    res = 0;
exit:
    return res;
}

/**
 * @brief Tears down the user object subsystem and releases resources.
 */
void cthulhu_user_object_teardown(void) {
    amxp_slot_disconnect(NULL, USERS_WAIT_EVENT, user_dm_available_event);
    user_unsubscribe(true);
}
