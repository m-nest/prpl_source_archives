#!/bin/sh

echo "Stopping ssh-server due to reset"

# Stop SSH server
/etc/init.d/ssh-server stop
