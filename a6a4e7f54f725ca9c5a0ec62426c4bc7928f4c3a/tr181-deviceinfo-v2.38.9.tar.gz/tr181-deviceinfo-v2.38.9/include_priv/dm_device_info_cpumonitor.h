/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef RESMON_CPU_H
#define RESMON_CPU_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_dm_functions.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <math.h>
#include <sys/sysinfo.h>
#include <debug/sahtrace.h>
#include <deviceinfo.h>
#include <debug/sahtrace_macros.h>

#include <dirent.h>
#include <regex.h>
#include <inttypes.h>


// Macro Definitions


#define RM_CPU_PERCENT_VALUE 100

// Used to store the output of a line from a file pointer
#define RM_LINE_OUTPUT_BUFFER_SIZE 256

// Used to store a timestamp
#define RM_TIMESTAMP_BUFFER_SIZE 25

// Used to store a character path
#define RM_FILE_PATH_BUFFER_SIZE 128

#define RM_ITEM_SIZE   64
#define RM_UNIT_SIZE   16
#define RM_CPU_LABEL 10

#define RM_CPU_PATH "DeviceInfo.ProcessStatus.CPU"
#define RM_CPU_FALL_THRESHOLD_DEFAULT 60
#define RM_CPU_RISE_THRESHOLD_DEFAULT 80
#define RM_CPU_POLLING_INTERVAL_DEFAULT 5
#define RM_CPU_USAGE_FILENAME "/proc/stat"
#define RM_CPU_SYS_PATH "/sys/devices/system/cpu/"
#define RM_CPU_PROC_STAT_PATH "/proc/stat"
#define RM_CPU_PROC_STAT_COUNT 8

#define CMON_SYSLOG_PATH                         "Syslog."
#define CMON_TIMEOUT                             5
#define CMON_ALIAS                               "Alias"
#define CMON_ALIAS_LOG                           "cmon-cpu"
#define STR_EMPTY(x) ((NULL == (x)) || ('\0' == (x)[0]))
#define RM_CMON                                  "Logcpu"


#define RM_CPU_POLLING_INTERVAL            "PollInterval"
#define RM_CPU_CRITICAL_FALL_THRESHOLD     "CriticalFallThreshold"
#define RM_CPU_CRITICAL_RISE_THRESHOLD     "CriticalRiseThreshold"
#define RM_CPU_ENABLE                      "Enable"
#define RM_CPU_ENABLE_CRITICAL_LOG         "EnableCriticalLog"
#define RM_CPU_CPU_UTILIZATION             "CPUUtilization"
#define RM_CPU_VENDOR_LOG_FILE_REF         "VendorLogFileRef"
#define RM_CPU_FILE_PATH                   "FilePath"
#define RM_CPU_CRITICAL_RISE_TIMESTAMP     "CriticalRiseTimeStamp"
#define RM_CPU_CRITICAL_FALL_TIMESTAMP     "CriticalFallTimeStamp"
#define RM_CPU_CRITICAL_STATE_EVENT        "CPUCriticalState!"
#define RM_CPU_SYSTEM_MODE_UTILIZATION     "SystemModeUtilization"
#define RM_CPU_USER_MODE_UTILIZATION       "UserModeUtilization"
#define RM_CPU_IDLE_MODE_UTILIZATION       "IdleModeUtilization"
#define RM_CPU_UP_TIME                     "UpTime"
#define RM_CPU_NUM_SAMPLES                 "NumSamples"
#define RM_CPU_NAME                        "Name"


#define RM_CPU_SUCCESS 0
#define RM_CPU_FAILURE -1

/**
 * @enum rm_cpu_state_e
 * @brief Represents the state of a CPU core in the monitoring system.
 */
typedef enum {
    RM_CPU_STATE_NORMAL = 0,  /**< CPU is operating within normal thresholds. */
    RM_CPU_STATE_CRITICAL = 1 /**< CPU usage has exceeded critical thresholds. */
} rm_cpu_state_e;

/**
 * @struct resmon_cpu_monitor_t
 * @brief Stores monitoring data and configuration for a single CPU core.
 */
typedef struct {
    bool cpu_enabled;                              /**< Indicates if monitoring is enabled for this core. */
    rm_cpu_state_e cpu_state;                      /**< Current state of the CPU core (NORMAL or CRITICAL). */
    uint32_t fall_threshold;                       /**< Threshold below which the state transitions to NORMAL. */
    uint32_t rise_threshold;                       /**< Threshold above which the state transitions to CRITICAL. */
    uint32_t polling_interval;                     /**< Polling interval in seconds. */
    uint32_t total_cpu_usage;                      /**< Total CPU usage percentage. */
    char fall_timestamp[RM_TIMESTAMP_BUFFER_SIZE]; /**< Timestamp when CPU transitioned to NORMAL state. */
    char rise_timestamp[RM_TIMESTAMP_BUFFER_SIZE]; /**< Timestamp when CPU transitioned to CRITICAL state. */
    uint32_t user_mode_usage;                      /**< CPU usage in user mode. */
    uint32_t system_mode_usage;                    /**< CPU usage in system mode. */
    uint32_t idle_mode_usage;                      /**< CPU idle percentage. */
    uint64_t up_time;                              /**< System uptime in seconds. */
    uint32_t num_samples;                          /**< Number of samples used for moving average calculation. */
} resmon_cpu_monitor_t;

/**
 * @struct cpu_timer_ctx_t
 * @brief Holds timer context information for a specific CPU core.
 */
typedef struct {
    amxp_timer_t* timer; /**< Pointer to the timer object. */
    int instance;        /**< Index of the CPU core associated with this timer. */
} cpu_timer_ctx_t;


/**
 * @struct cpu_usage_buffer_t
 * @brief Holds CPU usage samples information for a specific CPU core.
 */
typedef struct {
    double* samples;          // Circular buffer for CPU usage samples
    int32_t head_index;       // Index of the oldest sample
    int32_t sample_count;     // Number of samples currently in buffer
    double sample_sum;        // Sum of samples for moving average
    int32_t buffer_size;      // Size of the circular buffer
} cpu_usage_buffer_t;

/**
 * @brief Timer handler that reads memory usage and updates state.
 */
void cpu_usage_handler(amxp_timer_t* timer, void* priv);

/**
 * @brief Handles transition from critical to normal state.
 * @param usage Current memory usage percentage.
 */
void cpu_critical_state_handler(uint32_t instance, uint32_t usage);

/**
 * @brief Handles transition from critical to normal state.
 * @param usage Current memory usage percentage.
 */
void cpu_normal_state_handler(uint32_t instance, uint32_t usage);

/**
 * @brief Initializes the CPU monitoring system during device initialization.
 */
void _resmon_cpu_init(const char* const sig_name,
                      const amxc_var_t* const data,
                      void* const priv);

/**
 * @brief Shuts down the CPU monitoring system and frees allocated resources.
 */
void resmon_cpu_shutdown(void);

/**
 * @brief Reads total CPU utilization for a specific core.
 * @return amxd_status_t Status of the read operation.
 */
amxd_status_t _read_cpu_utilization(amxd_object_t* object,
                                    amxd_param_t* param,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv);

/**
 * @brief Clears CPU monitor state and resets usage and timestamps for a specific core.
 * @param index CPU core index.
 * @return int32_t Return value indicating success (0) or failure (-1).
 */
int32_t resmon_cpu_clear(uint32_t index);

/**
 * @brief Starts CPU monitoring for a specific core.
 * @param index CPU core index.
 */
void resmon_start_cpu_monitor(uint32_t index);

/**
 * @brief Stops CPU monitoring for a specific core.
 * @param index CPU core index.
 */
void resmon_stop_cpu_monitor(uint32_t index);

/**
 * @brief Gets current CPU usage for a specific core.
 * @param index CPU core index.
 * @return double CPU usage percentage.
 */
double get_current_cpu_usage(uint32_t index);

/**
 * @brief Handles CPU monitor state transitions based on usage.
 * @param index CPU core index.
 */
void handle_cpu_monitor_state(uint32_t index);

/**
 * @brief Handles CPU enable parameter change.
 */
void _rm_cpu_enable_change(const char* const sig_name,
                           const amxc_var_t* const data,
                           void* const priv);

/**
 * @brief Handles polling interval or threshold parameter changes.
 */
void _rm_cpu_polling_threshold_samples_change(const char* const sig_name,
                                              const amxc_var_t* const data,
                                              void* const priv);

/**
 * @brief Handles vendor log enable or file path changes.
 */
void _rm_cpu_vendor_enable_filePath_change(const char* const sig_name,
                                           const amxc_var_t* const data,
                                           void* const priv);

/**
 * @brief Handles CPU critical state signal and logs to vendor file.
 * @param sig_name Signal name.
 * @param data Signal data.
 * @return int Return value indicating success or failure.
 */
int _cpucriticalstate(const char* const sig_name,
                      const amxc_var_t* const data,
                      void* const priv);

/**
 * @brief Sets a specific CPU monitor parameter in the data model.
 * @param param_name Name of the parameter to set.
 * @param index CPU core index.
 * @return amxd_status_t Status of the operation.
 */
amxd_status_t set_cpu_param_instance(const char* param_name, uint32_t index);

/**
 * @brief Validates CPU monitor threshold parameters.
 * @param object CPU monitoring object.
 * @param param Parameter to validate.
 * @param reason Validation reason (unused).
 * @param args Input value to validate.
 * @param retval Return value container (unused).
 * @param priv Private data (unused).
 * @return amxd_status_t Status of the validation.
 */
amxd_status_t _validate_cpumonitor(amxd_object_t* object,
                                   amxd_param_t* param,
                                   amxd_action_t reason,
                                   const amxc_var_t* const args,
                                   amxc_var_t* const retval,
                                   void* priv);

/**
 * @brief Gets current system uptime.
 * @return uint64_t Uptime in seconds.
 */
uint64_t get_current_up_time(void);

/**
 * @brief Reads CPU mode utilization or uptime for a specific core.
 * @return amxd_status_t Status of the read operation.
 */
amxd_status_t _read_cpu_modes_and_uptime(amxd_object_t* object,
                                         amxd_param_t* param,
                                         amxd_action_t reason,
                                         const amxc_var_t* const args,
                                         amxc_var_t* const retval,
                                         void* priv);

/**
 * @brief Initializes CPU usage monitoring buffers.
 * @param num_cores Number of CPU cores.
 * @return RM_CPU_SUCCESS on success, RM_CPU_FAILURE on failure.
 */
int32_t cpu_usage_init(uint32_t num_cores);

/**
 * @brief Creates a circular buffer for CPU usage monitoring.
 * @param core_index CPU core index.
 * @param buffer_size Number of samples to store.
 * @return RM_CPU_SUCCESS on success, RM_CPU_FAILURE on failure.
 */
int32_t cpu_usage_buffer_create(uint32_t core_index, int32_t buffer_size);

/**
 * @brief Initializes contents of an existing CPU usage buffer.
 * @param core_index CPU core index.
 * @return void
 */
void cpu_usage_buffer_clear(uint32_t core_index);

/**
 * @brief Deletes the circular buffer for a specific CPU core.
 * @param core_index CPU core index.
 */
void cpu_usage_buffer_delete(uint32_t core_index);

/**
 * @brief Adds a new CPU usage sample to the buffer.
 * @param core_index CPU core index.
 * @param sample CPU usage sample.
 * @return RM_CPU_SUCCESS on success, RM_CPU_FAILURE on failure.
 */
int32_t cpu_usage_add_sample(uint32_t core_index, double sample);

/**
 * @brief Gets the moving average of CPU usage for a specific core.
 * @param core_index CPU core index.
 * @return double Moving average value.
 */
uint32_t cpu_usage_get_average(uint32_t core_index);

/**
 * @brief Updates CPU usage buffer and returns the new moving average.
 * @param index CPU core index.
 */
void cpu_usage_update_and_get_average(uint32_t index);

/**
 * @brief Frees all CPU usage buffers.
 */
void cpu_usage_buffers_free(void);

/**
 * @brief Gets aggregated mode usage for a specific core.
 * @param index CPU core index.
 */
void get_current_agg_mode_usage(uint32_t index);

/**
 * @brief Executes actions when CPU enters critical state.
 * @param instance CPU core index.
 * @return int32_t Status of the action.
 */
int32_t cpucriticalstate_actions(uint32_t instance);

/**
 * @brief Updates VendorLogFileRef for a specific CPU monitor instance.
 *
 * Synchronizes the log file path and critical log enable status with the syslog configuration
 * for the given CPU monitor instance.
 *
 * @param instance Index of the CPU monitor object to update.
 */
void cmon_update_vendorlogfileref_syslog(uint32_t instance);

/**
 * @brief Handles updates to log file path or critical log enable flag for CPU monitor.
 *
 */

void _cmon_handle_filename_enablelog_change(const char* const sig_name,
                                            const amxc_var_t* const data,
                                            void* const priv);

#endif // RESMON_CPU_H
