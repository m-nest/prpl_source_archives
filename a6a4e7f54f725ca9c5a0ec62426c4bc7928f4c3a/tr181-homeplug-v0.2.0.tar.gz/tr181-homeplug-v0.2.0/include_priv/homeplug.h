/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__HOMEPLUG_H__)
#define __HOMEPLUG_H__

#ifdef __cplusplus
extern "C"
{
#endif
#include <stdint.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>

#include <sys/socket.h>
#include <linux/if_packet.h>
#include <net/ethernet.h> /* the L2 protocols */

#include <netmodel/common_api.h>
#include <netmodel/client.h>

#define ME "homeplug"

typedef struct _homeplug_interface homeplug_interface_t;

// common types

typedef struct _homeplug_socket {
    int socket_fd;
    char* devname;
    struct sockaddr_ll* addr;
    homeplug_interface_t* interface;
} homeplug_socket_t;


struct _homeplug_interface {
    amxc_htable_it_t it;
    char* name;
    char* interface;
    homeplug_socket_t* sock;
    netmodel_query_t* up_query;
    bool up;
    bool enabled;
    amxd_object_t* interface_obj;
    amxc_llist_t active_devices;
};

// modules functions

/**
   @defgroup homeplug
 */

// homeplug_main
/**
   @ingroup homeplug
   @brief Enable the HomePlug module.
 */
void homeplug_enable(void);

/**
   @ingroup homeplug
   @brief Disable the HomePlug module.
 */
void homeplug_disable(void);

/**
   @ingroup homeplug
   @brief Get the HomePlug data model.

   @return Pointer to the data model object.
 */
amxd_dm_t* homeplug_get_dm(void);

/**
   @ingroup homeplug
   @brief Get the parser for HomePlug data model extensions.

   @return Pointer to the parser object.
 */
amxo_parser_t* homeplug_get_parser(void);

/**
   @ingroup homeplug
   @brief Homeplug entry point.

   @param reason Start/Stop the homeplug module.
   @param dm     Pointer to data model object.
   @param parser Pointer to parser object.

   @return 0.
 */
int _homeplug_main(int reason,
                   amxd_dm_t* dm,
                   amxo_parser_t* parser);

// ---------------------------------------------------------------------------
// Interface management functions
// ---------------------------------------------------------------------------

/**
   @ingroup homeplug
   @brief Initialize the HomePlug interface subsystem.
 */
void homeplug_interface_initialize(void);

/**
   @ingroup homeplug
   @brief Clean up the HomePlug interface subsystem.
 */
void homeplug_interface_cleanup(void);

/**
   @ingroup homeplug
   @brief Create a new HomePlug interface object.

   @param key    Unique identifier for the interface.
   @param params Initialization parameters.

   @return Newly created interface object, or NULL on failure.
 */
homeplug_interface_t* homeplug_interface_create(const char* key, amxc_var_t* params);

/**
   @ingroup homeplug
   @brief Delete a HomePlug interface by key.

   @param key Unique identifier of the interface.
 */
void homeplug_interface_delete(const char* key);

/**
   @ingroup homeplug
   @brief Enable a HomePlug interface.

   @param interface Interface object.
   @return true if successful, false otherwise.
 */
bool homeplug_interface_enable(homeplug_interface_t* interface);

/**
   @ingroup homeplug
   @brief Disable a HomePlug interface.

   @param interface Interface object.
 */
void homeplug_interface_disable(homeplug_interface_t* interface);

/**
   @ingroup homeplug
   @brief Callback for link state changes.

   @param sig_name Name of the signal.
   @param data     Signal payload.
   @param priv     Private data, expected to be homeplug_interface_t*
 */
void homeplug_interface_up_cb(const char* sig_name,
                              const amxc_var_t* data,
                              void* priv);

/**
   @ingroup homeplug
   @brief Remove inactive devices from all interfaces.
 */
void homeplug_interface_cleanup_inactive_devices(void);

/**
   @ingroup homeplug
   @brief Add a device to the active list of an interface.

   @param interface Interface object.
   @param devicemac MAC address of the device.

   @return true if successfully added, false otherwise.
 */
bool homeplug_interface_add_activedevice(homeplug_interface_t* interface, const uint8_t* devicemac);

/**
   @ingroup homeplug
   @brief Send a discovery request on all interfaces.
 */
void homeplug_interface_send_discovery_request(void);

// ---------------------------------------------------------------------------
// Socket functions
// ---------------------------------------------------------------------------

/**
   @ingroup homeplug
   @brief Create a new HomePlug socket on a given device.

   @param dev_name Network device name.
   @return Pointer to socket object, or NULL on failure.
 */
homeplug_socket_t* homeplug_socket_new(const char* dev_name);

/**
   @ingroup homeplug
   @brief Delete a HomePlug socket.

   @param sock Socket object to free.
 */
void homeplug_socket_delete(homeplug_socket_t* sock);

/**
   @ingroup homeplug
   @brief Send a discovery request via a HomePlug socket.

   @param sock Socket to use.
 */
void homeplug_socket_send_discovery_request(homeplug_socket_t* sock);

/**
   @ingroup homeplug
   @brief Send a request for associated devices.

   @param sock Socket to use.
   @param addr Target MAC address.
 */
void homeplug_socket_send_associated_devices_request(homeplug_socket_t* sock, const uint8_t addr[8]);

/**
   @ingroup homeplug
   @brief Send a generic request.

   @param sock         Socket to use.
   @param addr         Target MAC address.
   @param message      Request buffer.
   @param message_size Length of request buffer.

   @return true if sent successfully, false otherwise.
 */
bool homeplug_socket_send_request(homeplug_socket_t* sock, const uint8_t addr[8], uint8_t* message, size_t message_size);

/**
   @ingroup homeplug
   @brief Socket read callback.

   Triggered when data is available on the raw socket.

   @param socket_fd File descriptor.
   @param priv      Private data, expected to be homeplug_socket_t*
 */
void homeplug_socket_read_socket_cb(int socket_fd, void* priv);

// ---------------------------------------------------------------------------
// AV Protocol functions
// ---------------------------------------------------------------------------

/**
   @ingroup homeplug
   @brief Create a CM_BRIDGE_INFO request message.

   @param[out] messagesize Pointer to a variable that will be set to the
                           size of the allocated message in bytes.

   @return Pointer to the allocated message buffer cast to @c uint8_t*.

   @note - The caller is responsible for freeing the allocated buffer.
 */
uint8_t* homeplug_av_protocol_create_cm_brg_info_req(size_t* messagesize);

/**
   @ingroup homeplug
   @brief Create a CM_NETWORK_STATS request message.

   @param[out] messagesize Pointer to a variable that will be set to the
                           size of the allocated message in bytes.

   @return Pointer to the allocated message buffer cast to @c uint8_t*.

   @note - The caller is responsible for freeing the allocated buffer.
 */
uint8_t* homeplug_av_protocol_create_cm_nw_stats_req(size_t* messagesize);

/**
   @ingroup homeplug
   @brief Create a VS_NETWORK_INFO request message.

   @param[out] messagesize Pointer to a variable that will be set to the
                           size of the allocated message in bytes.

   @return Pointer to the allocated message buffer cast to @c uint8_t*.

   @note - The caller is responsible for freeing the allocated buffer.
 */
uint8_t* homeplug_av_protocol_create_vs_nw_info_req(size_t* messagesize);

/**
   @ingroup homeplug
   @brief Create a CM_HFID request message.

   @param reqtype          Request type (must be @c 0x00 or @c 0x01).
   @param nid              Network identifier (Unused).
   @param nidlength        Length of the network identifier (Unused).
   @param hfid             HFID data (Unused).
   @param hfidlength       Length of the HFID data (unused).
   @param[out] messagesize Pointer to a variable that will be set to the
                            size of the allocated message in bytes.

   @return Pointer to the allocated message buffer cast to @c uint8_t*,
           or @c NULL if the request type is invalid.

   @note - The caller is responsible for freeing the allocated buffer.
 */
uint8_t* homeplug_av_protocol_create_cm_hfid_req(uint8_t reqtype, uint8_t nid[], uint8_t nidlength, uint8_t hfid[], uint8_t hfidlength, size_t* messagesize);

/**
   @ingroup homeplug
   @brief Create a vendor-specific Atheros SW version request message.

   @param[out] messagesize Pointer to a variable that will be set to the
                           size of the allocated message in bytes.

   @return Pointer to the allocated message buffer cast to @c uint8_t*.

   @note - The caller is responsible for freeing the allocated buffer.
 */
uint8_t* homeplug_av_protocol_create_atheros_sw_ver_req(size_t* messagesize);

/**
   @ingroup homeplug
   @brief Handle an incoming HomePlug AV frame.

   @param sock        Socket on which the frame was received.
   @param frame       Frame data.
   @param framelength Length of frame.
   @param sll_addr    Source MAC address.
 */
void homeplug_av_protocol_handle_rcvd_msg(homeplug_socket_t* sock, uint8_t* frame, size_t framelength, const uint8_t sll_addr[8]);

#ifdef __cplusplus
}
#endif

#endif // __HOMEPLUG_H__

