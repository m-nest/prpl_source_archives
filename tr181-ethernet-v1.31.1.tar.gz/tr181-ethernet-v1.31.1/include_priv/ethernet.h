/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
    @file ethernet.h
    @brief Ethernet manager public API and data structures.

   This header defines the main data structures and API for the Ethernet
   manager module.

   SPDX-License-Identifier: BSD-2-Clause-Patent
   Copyright (c) 2025 SoftAtHome
 */

/**
   @defgroup ethernet Ethernet Manager
   @ingroup tr181-ethernet
   @brief Ethernet entry point and core data structures.

   This module provides the main API and data structures for the Ethernet manager.
   @{
 */

#if !defined(__ETHERNET_MANAGER_H__)
#define __ETHERNET_MANAGER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>

#include <amxb/amxb.h>

#include <amxo/amxo.h>
#include <amxo/amxo_save.h>

#include <amxm/amxm.h>

#include <amxs/amxs.h>

#include <netmodel/client.h>

#define str_empty(x) ((x == NULL) || (*x == '\0'))

// Defines for manually used status' in this code
#define STATUS_DOWN "down"
#define STATUS_ERROR "Error"
// Status used for the LED object status
#define STATUS_ENABLED "Enabled"
#define STATUS_DISABLED "Disabled"
#define STATUS_NOT_PRESENT "NotPresent"
#define STATUS_UNKNOWN "Unknown"

// Defines for status used in RMONSTATES
#define RMONSTATS_STATUS_DISABLED "Disabled"
#define RMONSTATS_STATUS_ENABLED "Enabled"
#define RMONSTATS_STATUS_ERR_MISCONFIGURED "Error_Misconfigured"
#define RMONSTATS_STATUS_ERR "Error"

// Name of Control Parameter in the datamodel
#define VLAN_CTRL "VLANController"
#define ETH_LLA_CTRL "DefaultController"
#define ETH_LED_CTRL "LEDController"
#define ETH_RMONSTATS_CTRL "RMONStatsController"
#define PWR_CTRL "PowerController"          // Name of module for power management

// Name of the module namespace that you want to use to execute the functions
#define MOD_VLAN_CTRL "vlan-ctrl"
#define MOD_ETH_LLA_CTRL "eth-lla-ctrl"
#define MOD_ETH_LED_CTRL "eth-led-ctrl"
#define MOD_ETH_RMONSTATS_CTRL "eth-rmonstats-ctrl"
#define MOD_PWR_CTRL "pwr-ctrl"

// Define the name of the module to be used when the controllers fail to load
#define DUMMY_VLAN_MOD_NAME "mod-vlan-dummy"
#define DUMMY_LED_MOD_NAME "mod-led-dummy"
#define DUMMY_PWR_MOD_NAME "mod-pwr-dummy"

/**
   @enum rmonstats_status_t
   @brief RMON statistics status enumeration.
 */

typedef enum rmonstats_status {
    RMONSTATS_DISABLED,
    RMONSTATS_ENABLED,
    RMONSTATS_ERR_MISCONFIGURED,
    RMONSTATS_ERR,
    RMONSTATS_NUM_STATUS
} rmonstats_status_t;

/**
   @enum ethernet_instance_type_t
   @brief Ethernet instance type enumeration.
 */
typedef enum _ethernet_instance_type {
    ETHERNET_INTERFACE,
    ETHERNET_LINK,
    ETHERNET_VLANTERMINATION,
} ethernet_instance_type_t;

/**
   @struct ethernet_app_t
   @brief Main application context for Ethernet manager.
 */
typedef struct _ethernet_app {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxb_bus_ctx_t* netdev_ctx;
    bool vlan_mods_are_loaded;
    bool led_mods_are_loaded;
    bool pwr_mods_are_loaded;
} ethernet_app_t;

/**
   @struct ethernet_info_t
   @brief Information about an Ethernet instance.
 */
typedef struct _ethernet_info {
    amxd_object_t* object;                             // pointer to object this structure belongs to
    ethernet_instance_type_t type;                     // type of ethernet instance this info struct belongs to
    char* netdev_intf;                                 // netdev interface name
    amxb_subscription_t* netdev_status_subscription;   // subscription to be informed of status updates in NetDev
    amxb_subscription_t* netdev_new_link_subscription; // subscription to be informed of new matching links, added in NetDev
    amxb_subscription_t* netdev_mac_subscription;      // subscription to be informed of LLaddress updates in NetDev
    amxb_subscription_t* sfp_subscription;             // subscription to be informed of SFP cage presence and type
    char* sfp_path;
    uint32_t last_change;                              // time definition for time of last status change
    netmodel_query_t* query;                           // netmodel query for the ethernet link netdev name used for VLANs or the ethernet interface status used for link
    bool present;                                      // true if interface is present, used for SFPs
    char* link_name;                                   // Netdev name of the ethernet link, used for VLANs
    amxd_object_t* led_object;                         // pointer to led object
    amxs_sync_ctx_t* sync_to_switch;                   // pointer to data model sync context to sync to switch
    amxs_sync_ctx_t* sync_from_switch;                 // pointer to data model sync context to sync from switch
    amxs_sync_ctx_t* sync_from_cpu_port;               // pointer to data model sync context to sync from cpu port interface
} ethernet_info_t;

/**
   @struct rmonstate_states_conv_t
   @brief Conversion between RMON status string and enum.
 */
typedef struct rmonstate_states_conv {
    const char* str_status;
    rmonstats_status_t enum_status;
} rmonstate_states_conv_t;

/**
   @struct ethernet_rmonstats_info_t
   @brief RMON statistics information for Ethernet.
 */
typedef struct _ethernet_rmonstats_info {
    bool enable;
    rmonstats_status_t status;

    //The statistics parameters
    char* interface;

    amxd_object_t* object;
} ethernet_rmonstats_info_t;

/**
   @brief Get the Ethernet data model.

   @return Pointer to the data model.
 */
amxd_dm_t* PRIVATE ethernet_get_dm(void);

/**
   @brief Get the Netdev bus context.

   @return Pointer to the Netdev bus context.
 */
amxb_bus_ctx_t* PRIVATE ethernet_get_netdev_ctx(void);

/**
   @brief Get the ODL parser.

   @return Pointer to the ODL parser.
 */
amxo_parser_t* PRIVATE ethernet_get_parser(void);

/**
   @brief Check if VLAN modules are loaded.

   @return true if loaded, false otherwise.
 */
bool PRIVATE ethernet_vlan_mods_are_loaded(void);

/**
   @brief Check if LED modules are loaded.

   @return true if loaded, false otherwise.
 */
bool PRIVATE ethernet_led_mods_are_loaded(void);

/**
   @brief Check if power modules are loaded.

   @return true if loaded, false otherwise.
 */
bool PRIVATE ethernet_pwr_mods_are_loaded(void);

/**
   @brief Main entry point for the Ethernet manager.

   @param reason Reason for invocation.
   @param dm Pointer to the data model.
   @param parser Pointer to the ODL parser.
   @return 0 on success, error code otherwise.
 */
int _ethernet_manager_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
   @brief Subscribe to SFP events.

   @return 0 on success, error code otherwise.
 */
int subscribe_to_sfp(void);

/**
   @brief Application start event handler.

   @param event_name Name of the event.
   @param event_data Event data.
   @param priv Private data.
 */
void _app_start(const char* const event_name,
                const amxc_var_t* const event_data,
                void* const priv);

#ifdef __cplusplus
}
#endif

/** @} */

#endif // __ETHERNET_MANAGER_H__
