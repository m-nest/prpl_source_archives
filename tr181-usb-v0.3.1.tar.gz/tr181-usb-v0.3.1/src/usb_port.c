/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"
#include "usb-pwr-utils.h"

#define ME "port"

/**
 * @brief Finds a host port by its ID.
 *
 * @param id The port ID.
 * @return amxd_object_t* The host port object.
 */
amxd_object_t* find_host_port(const char* id) {
    if(id == NULL) {
        return NULL;             // Add null check
    }
    return amxd_dm_findf(get_dm(), "USB.Port.[SysfsId == '%s' and Type == 'Host']", id);
}

/**
 * @brief Finds a host port by its name.
 *
 * @param name The port name.
 * @return amxd_object_t* The host port object.
 */
amxd_object_t* find_host_port_by_name(const char* name) {
    if(name == NULL) {
        return NULL;               // Add null check
    }
    return amxd_dm_findf(get_dm(), "USB.Port.[Name == '%s']", name);
}

/**
 * @brief Finds a host port by its UID.
 *
 * @param uid The port UID.
 * @return amxd_object_t* The host port object.
 */
amxd_object_t* find_host_port_by_uid(int uid) {
    return amxd_dm_findf(get_dm(), "USB.Port.%d.", uid);
}

/**
 * @brief Finds a port by its ID.
 *
 * @param id The port ID.
 * @return amxd_object_t* The port object.
 */
amxd_object_t* find_port(const char* id) {
    if(id == NULL) {
        return NULL;             // Add null check
    }
    amxd_object_t* port;

    // Find Port in HostPorts
    if((port = find_host_port(id)) != NULL) {
        return port;
    }

    return NULL;
}

/**
 * @brief Deletes a hub port object.
 *
 * @param port The port object.
 * @return int The status of the operation.
 */
int hubport_delete_object(amxd_object_t* port) {
    return port_delete_object(port);
}

/**
 * @brief Creates a hub port object.
 *
 * @param id The port ID.
 * @param error The error code.
 * @param standard The standard.
 * @param rate The rate.
 * @return amxd_object_t* The hub port object.
 */
amxd_object_t* hubport_create_object(const char* id, int* error, const char* standard, const char* rate) {
    if((id == NULL) || (standard == NULL) || (rate == NULL)) {
        return NULL;                                                 // Add null check
    }
    SAH_TRACEZ_NOTICE(ME, "Create HubPort %s...", id);
    amxd_object_t* port = port_create_object(id, "Device", error, standard, rate);
    return port;
}

/**
 * @brief Deletes a port object.
 *
 * @param port The port object.
 * @return int The status of the operation.
 */
int port_delete_object(amxd_object_t* port) {
    if(port == NULL) {
        return -1;               // Add null check
    }
    SAH_TRACEZ_NOTICE(ME, "Delete Port DM object...");
    amxd_trans_t trans;
    int rv = 0;
    int index;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.Port.");
    index = amxd_object_get_index(port);
    amxd_trans_del_inst(&trans, index, NULL);

    rv = amxd_trans_apply(&trans, get_dm());

    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

exit:
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief Creates a port object.
 *
 * @param id The port ID.
 * @param type The port type.
 * @param error The error code.
 * @param standard The standard.
 * @param rate The rate.
 * @return amxd_object_t* The port object.
 */
amxd_object_t* port_create_object(const char* id, const char* type, int* error, const char* standard, const char* rate) {
    if((id == NULL) || (type == NULL) || (standard == NULL) || (rate == NULL)) {
        return NULL;                                                                 // Add null check
    }
    int rv = 0;
    amxd_trans_t trans;
    amxc_string_t search;
    amxc_string_t name;
    amxd_object_t* port = NULL;

    amxc_string_init(&search, 0);
    amxc_string_init(&name, 0);
    amxd_trans_init(&trans);

    SAH_TRACEZ_NOTICE(ME, "Create Port %s...", id);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.Port.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxc_string_setf(&name, "Port_%s", id);
    // Set parameters
    amxd_trans_set_value(cstring_t, &trans, "Name", amxc_string_get(&search, 0));
    amxd_trans_set_value(cstring_t, &trans, "SysfsId", id);
    amxd_trans_set_value(cstring_t, &trans, "Receptacle", standard);
    amxd_trans_set_value(cstring_t, &trans, "Rate", rate);
    amxd_trans_set_value(cstring_t, &trans, "Type", type);
    amxd_trans_set_value(cstring_t, &trans, "Power", "Unknown");

    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

    rv = dm_usb_soc_set_pwr(amxc_string_get(&search, 0));
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to write PowerStatus for '%s'", amxc_string_get(&search, 0));
    }

    amxc_string_setf(&search, "USB.Port.[Name=='%s']", amxc_string_get(&search, 0));
    port = amxd_dm_findf(get_dm(), "%s", amxc_string_get(&search, 0));

exit:
    *error = rv;
    amxd_trans_clean(&trans);
    amxc_string_clean(&search);
    amxc_string_clean(&name);
    return port;
}
