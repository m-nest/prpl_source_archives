#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="wifi-sensing"
PROG="/usr/bin/wifi-sensing"
datamodel_root="X_PRPLWARE-COM_WiFiSensing"
PROG_OPTIONS=""

ifelse(DISABLE_AUTOSTART, `y',
enable() {
    logger -t $name -p daemon.warn "prplMesh WiFi Sensing autostart handled by prplMesh Process Manager"
    return 0
})

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    mkdir -p 0755 /var/run/wifisensing
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}
