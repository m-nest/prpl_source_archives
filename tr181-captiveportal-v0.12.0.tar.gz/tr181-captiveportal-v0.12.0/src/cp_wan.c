/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>

#include "captive_portal.h"
#include "cp_wan.h"
#include "cp_opennds.h"
#include "dm_cp.h"

static void network_changed_cb(UNUSED const char* sig_name,
                               const amxc_var_t* data,
                               UNUSED void* priv) {
    bool isup = amxc_var_dyncast(bool, data);
    amxd_object_t* root_obj = amxd_dm_findf(cp_get_dm(), "CaptivePortal.");
    amxd_object_t* lan_obj = amxd_object_findf(root_obj, "LANInterface.1.");    // For now we just use a single interface
    char* state = amxd_object_get_value(cstring_t, root_obj, "State", NULL);
    char* lan_status = NULL;

    SAH_TRACEZ_INFO(ME, "WAN is %s and State is %s", isup ? "up" : "down", state);
    when_str_empty(state, exit);
    when_null(lan_obj, exit);

    if(!amxd_object_get_value(bool, lan_obj, "Enable", NULL)) {
        SAH_TRACEZ_WARNING(ME, "LANInterface is disabled, not starting captive portal");
        goto exit;
    }

    lan_status = amxd_object_get_value(cstring_t, lan_obj, "Status", NULL);
    when_str_empty(lan_status, exit);

    if(strcmp(lan_status, "Init") == 0) {
        SAH_TRACEZ_INFO(ME, "LANInterface not done with init, not starting captive portal");
        goto exit;
    }

    if(isup) {
        cp_wan_network_up(state, lan_obj);
    } else {
        cp_wan_network_down(state, lan_obj);
    }

exit:
    free(lan_status);
    free(state);
}

int cp_wan_network_up(const char* state, amxd_object_t* const lan_obj) {
    int retval = -1;

    if(strcmp(state, "Running") == 0) {
        cp_opennds_stop();
        retval = cp_opennds_dns_redirect_stop(lan_obj);
        when_failed_trace(retval, exit, ERROR, "Failed to stop redirecting DNS");
    } else if(strcmp(state, "Restart") == 0) {
        retval = dm_cp_set_value(NULL, "State", "Stopping");
    }

exit:
    return retval;
}

int cp_wan_network_down(const char* state, amxd_object_t* const lan_obj) {
    int retval = -1;

    if((strcmp(state, "Init") == 0) || (strcmp(state, "Stopped") == 0) || (strcmp(state, "Restart") == 0)) {
        retval = cp_opennds_start(lan_obj);
        when_failed_trace(retval, exit, ERROR, "Failed to start opennds, not redirecting DNS");
        retval = cp_opennds_dns_redirect_start(lan_obj);
        when_failed_trace(retval, exit, ERROR, "Error redirecting DNS");
    } else if(strcmp(state, "Stopping") == 0) {
        retval = dm_cp_set_value(NULL, "State", "Restart");
    }

exit:
    return retval;
}

void cp_wan_query_open(void) {
    cp_app_t* app = cp_get_app();
    amxc_string_t* dotted_path = NULL;

    dotted_path = dm_cp_wan_intf_get_dotted();
    when_null(dotted_path, exit);
    SAH_TRACEZ_INFO(ME, "Open query with flag ipv4-up to check if %s is up", amxc_string_get(dotted_path, 0));

    app->wan_query = netmodel_openQuery_isUp(amxc_string_get(dotted_path, 0), ME, "ipv4-up", "down", network_changed_cb, NULL);
    when_null_trace(app->wan_query, exit, ERROR, "Failed to open query for WAN up/down");

exit:
    amxc_string_delete(&dotted_path);
}

void cp_wan_query_close(void) {
    cp_app_t* app = cp_get_app();

    SAH_TRACEZ_INFO(ME, "Stop querying WAN interface");
    netmodel_closeQuery(app->wan_query);
    app->wan_query = NULL;
}
