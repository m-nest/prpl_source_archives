/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/common_api.h>

#include "event_handler.h"
#include "tr069_discovery.h"

#define ME "event_handler"

static void read_dhcp_option_change_event(const amxc_var_t* data, dhcp_option_t* option) {
    memset(option, 0, sizeof(dhcp_option_t));
    amxc_var_t* options_var = GETP_ARG(data, "0.Data");
    if(!options_var) {
        return;
    }
    amxc_var_for_each(option_var, options_var) {
        uint32_t option_code = GET_UINT32(option_var, "Code");
        const char* option_data_str = GET_CHAR(option_var, "Data");
        switch(option_code) {
        case DHCP_OPTION_17_URL_OF_ACS_CODE:
        case DHCP_OPTION_125_URL_OF_ACS_CODE:
            snprintf(option->url_of_acs, sizeof(option->url_of_acs), "%s", option_data_str);
            break;
        case DHCP_OPTION_17_PROVISION_CODE:
        case DHCP_OPTION_125_PROVISION_CODE:
            snprintf(option->provisioning_code, sizeof(option->provisioning_code), "%s", option_data_str);
            break;
        }
    }
}

static void handle_dhcpv4_option_change_event(UNUSED const char* sig_name,
                                              const amxc_var_t* const data,
                                              UNUSED void* const priv) {
    dhcp_option_t option;
    read_dhcp_option_change_event(data, &option);
    option.dhcp_version = DHCPv4;
    handle_dhcp_option_change(&option);
}

static void handle_dhcpv6_option_change_event(UNUSED const char* sig_name,
                                              const amxc_var_t* const data,
                                              UNUSED void* const priv) {
    dhcp_option_t option;
    read_dhcp_option_change_event(data, &option);
    option.dhcp_version = DHCPv6;
    handle_dhcp_option_change(&option);
}

static int subscribe_on_dhcp_option_change_event(const char* netmodel_iface_alias, int option_tag,
                                                 netmodel_query_t** option_subscription,
                                                 netmodel_callback_t handler,
                                                 dhcp_version_t version) {
    int rc = -1;

    amxc_var_t parameters;
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "type", version == DHCPv4 ? "req" : "req6");
    amxc_var_add_key(uint16_t, &parameters, "tag", option_tag);

    *option_subscription = netmodel_openQuery(netmodel_iface_alias, app.name, "getDHCPOption",
                                              &parameters, handler, NULL);
    when_null_trace(*option_subscription, exit, ERROR,
                    "Cannot subscribe to DHCP option %d", option_tag);

    rc = 0;
exit:
    amxc_var_clean(&parameters);
    return rc;
}

static void handle_management_server_change_event(UNUSED const char* const sig_name,
                                                  const amxc_var_t* const data,
                                                  UNUSED void* const priv) {
    const char* path = GET_CHAR(data, "path");
    amxc_var_t* params = GET_ARG(data, "parameters");
    const amxc_htable_t* tparams = amxc_var_constcast(amxc_htable_t, params);

    amxc_htable_for_each(hit, tparams) {
        const char* name = amxc_htable_it_get_key(hit);
        amxc_var_t* value_var = amxc_var_from_htable_it(hit);
        char* value_from = amxc_var_dyncast(cstring_t, GET_ARG(value_var, "from"));
        char* value_to = amxc_var_dyncast(cstring_t, GET_ARG(value_var, "to"));
        if(!strcmp(path, MANAGEMENT_SERVER_STATE)) {
            if(!strcmp(name, "LastSession")) {
                handle_cwmp_session_establishment();
            }
        } else if(!strcmp(path, MANAGEMENT_SERVER)) {
            if(!strcmp(name, "URL")) {
                handle_management_server_url_change(value_to);
            }
        }
        free(value_from);
        free(value_to);
    }

    return;
}

static int subscribe_on_management_server_change_events(void) {
    int rc = -1;

    amxb_bus_ctx_t* ctx = amxb_be_who_has(MANAGEMENT_SERVER);
    when_null_trace(ctx, exit, ERROR, "Failed to get \"%s\" context", MANAGEMENT_SERVER);
    rc = amxb_subscription_new(&app.management_server_subscription, ctx, MANAGEMENT_SERVER,
                               "notification == 'dm:object-changed'", handle_management_server_change_event, NULL);
    when_failed_trace(rc, exit, ERROR, "Failed to subscribe on \"%s\" change events", MANAGEMENT_SERVER);

exit:
    return rc;
}

int setup_subscriptions(const char* netmodel_iface_alias) {
    int rc = subscribe_on_dhcp_option_change_event(netmodel_iface_alias, 17, &app.option_17_subscription,
                                                   handle_dhcpv6_option_change_event, DHCPv6);
    when_failed_trace(rc, exit, ERROR, "Failed to subscribe on option 17");
    rc = subscribe_on_dhcp_option_change_event(netmodel_iface_alias, 125, &app.option_125_subscription,
                                               handle_dhcpv4_option_change_event, DHCPv4);
    when_failed_trace(rc, exit, ERROR, "Failed to subscribe on option 125");
    rc = subscribe_on_management_server_change_events();
    when_failed_trace(rc, exit, ERROR, "Failed to subscribe on CWMP agent updates");

exit:
    return rc;
}

void cleanup_subscriptions(void) {
    netmodel_closeQuery(app.option_125_subscription);
    app.option_125_subscription = NULL;
    netmodel_closeQuery(app.option_17_subscription);
    app.option_17_subscription = NULL;
    if(amxb_subscription_delete(&app.management_server_subscription)) {
        SAH_TRACEZ_ERROR(ME, "Failed to delete subscription on \"%s\" changes", MANAGEMENT_SERVER);
    }
}
