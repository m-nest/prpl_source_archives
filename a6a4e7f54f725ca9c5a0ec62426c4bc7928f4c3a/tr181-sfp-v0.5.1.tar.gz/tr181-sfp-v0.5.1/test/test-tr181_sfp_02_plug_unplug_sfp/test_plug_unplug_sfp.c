/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_plug_unplug_sfp.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <unistd.h> /* unlink() */

/* Other libraries' headers */
#include <amxc/amxc.h>                  /* needed by amxd_types.h */
#include <amxc/amxc_macros.h>           /* UNUSED */
#include <amxp/amxp_signal.h>           /* needed by amxd_types.h */
#include <amxd/amxd_types.h>            /* amxd_dm_t */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxo/amxo_types.h>            /* amxo_parser_t */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "common_dm_functions.h"     /* check_no_sfp_is_present() */
#include "common_functions.h"        /* read_sig_alarm() */
#include "file_utils.h"              /* create_folder() */
#include "json_utils.h"              /* read_json_from_file() */
#include "setup_and_teardown.h"      /* setup_common() */
#include "sfpmgr_trace.h"
#include "sfp_types_and_constants.h" /* SFP_ID_UNKNOWN */

#undef ME
#define ME "runtest"

static amxd_dm_t dm;
static amxo_parser_t parser;

static const char* const SCRIPT_FOLDER = "/tmp/tr181-sfp/scripts";
static const char* const GET_EEPROM_INFO = "/tmp/tr181-sfp/scripts/get_eeprom_info.sh";
static const char* const GET_RXLOS = "/tmp/tr181-sfp/scripts/get_rxlos.sh";

static void check_transceiver_parameters(void) {
    amxd_status_t rc;
    int result = -1;
    amxc_var_t dm_params;
    amxc_var_init(&dm_params);

    amxd_object_t* const trx =
        amxd_dm_findf(&dm, "SFPs.Mgmt.SFF8472.1.Transceiver.");
    assert_non_null(trx);
    rc = amxd_object_get_params(trx, &dm_params, amxd_dm_access_public);
    assert_int_equal(rc, 0);

    amxc_var_t* data_expected =
        read_json_from_file("../test_data/G-PON_test_data/G-PON_dm_transceiver.json");
    assert_non_null(data_expected);
    rc = amxc_var_compare(&dm_params, data_expected, &result);
    assert_int_equal(rc, 0);
    assert_int_equal(result, 0);

    amxc_var_delete(&data_expected);
    amxc_var_clean(&dm_params);
}

static void check_dm_of_inserted_sfp(const char* sfp_type) {
    check_sfp_cage_parameters(&dm, sfp_type);
    check_transceiver_parameters();
}

int test_setup(UNUSED void** state) {
    int rc;
    rc = setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
    assert_int_equal(rc, 0);
    create_folder(SCRIPT_FOLDER);
    return 0;
}

int test_teardown(UNUSED void** state) {
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

/**
 * Test plugging and unplugging an SFP.
 *
 * - Check that the parameters of SFPs.SFPCage.1 indicate there is no SFP.
 * - Write script get_eeprom_info.sh such that it indicates there is an SFP
 *   with an SFF-8472 management interface.
 * - Write get_rxlos.sh such that it indicates the network interface
 *   corresponding to SFPs.SFPCage.1 is down.
 * - Copy G-PON_ethtool_data.txt to EXAMPLE_ETHTOOL_OUTPUT.
 * - Call read_sig_alarm() a few times to trigger the timer calling the script
 *   get_eeprom_info.sh to check for SFP presence. tr181-sfp should detect an
 *   SFP is present. When running the unit tests, tr181-sfp is compiled such
 *   that it parses EXAMPLE_ETHTOOL_OUTPUT instead of running ethtool. Upon
 *   detecting an SFP tr181-sfp call get_rxlos.sh. (The read_sig_alarm() calls
 *   also trigger the timer which polls the diagnostics.)
 * - Check that tr181-sfp updated the DM. Check the parameters of:
 *   - SFPs.SFPCage.1
 *   - SFPs.Mgmt.SFF8472.1.Transceiver
 * - Write script get_eeprom_info.sh such that it indicates there is no SFP
 *   present.
 * - Call read_sig_alarm() a few times to trigger the timer calling the script
 *   get_eeprom_info.sh to check for SFP presence. tr181-sfp should detect the
 *   SFP is no longer present. Check that tr181-sfp updated the DM: check the
 *   parameters of SFPs.SFPCage.1.
 */
void test_plug_unplug_sfp(UNUSED void** state) {

    int i;
    int rc;
    char eeprom_info[64];

    check_no_sfp_is_present(&dm);

    rc = snprintf(eeprom_info, 64, "echo \"3\" \"0\" \"0\" \"0d\"");
    assert_true(rc > 0 && rc < 64);
    create_script(GET_EEPROM_INFO, eeprom_info);
    create_script(GET_RXLOS, "echo DOWN");
    copy_file("../test_data/G-PON_test_data/G-PON_ethtool_data.txt",
              EXAMPLE_ETHTOOL_OUTPUT);

    for(i = 0; i < 2; ++i) {
        read_sig_alarm(1);
    }

    check_dm_of_inserted_sfp("G-PON");

    rc = snprintf(eeprom_info, 64, "echo \"0\" \"0\" \"0\" \"0\"");
    assert_true(rc > 0 && rc < 64);
    create_script(GET_EEPROM_INFO, eeprom_info);
    unlink(EXAMPLE_ETHTOOL_OUTPUT);
    unlink(GET_RXLOS);

    for(i = 0; i < 3; ++i) {
        read_sig_alarm(2);
    }

    check_no_sfp_is_present(&dm);
}

