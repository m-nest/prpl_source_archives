/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef RESMON_MEM_H
#define RESMON_MEM_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_dm_functions.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <math.h>
#include <sys/sysinfo.h>
#include <debug/sahtrace.h>
#include <deviceinfo.h>
#include <debug/sahtrace_macros.h>
#include <inttypes.h>

// Macro Definitions

#define RM_MEM_PERCENT_VALUE 100

#define RM_MEM_PARAM_NAME_BUF_SIZE 256
#define RM_MEM_TIME_STAMP_BUF_SIZE  25
#define RM_MEM_LINE_BUF_SIZE 128
/* If RM_MEM_ITEM_SIZE or RM_MEM_UNIT_SIZE is modified,
   ensure the sscanf logic in get_current_memory_usage() is updated accordingly. */
#define RM_MEM_ITEM_SIZE   64
#define RM_MEM_UNIT_SIZE   16

#define RM_MEM_PATH "DeviceInfo.MemoryStatus.MemoryMonitor"

// Default Fall and Rise Threshold values (based on TR-181 Data Model)
#define RM_MEM_FALL_THRESHOLD_DEFAULT 60
#define RM_MEM_RISE_THRESHOLD_DEFAULT 80
#define RM_MEM_POLLING_INTERVAL 5
#define RM_MEM_USAGE_FILENAME "/proc/meminfo"
#define RM_MEM_SUCCESS 0
#define RM_MEM_FAILURE -1
#define RM_MMON "mmonLog"
#define MMON_SYSLOG_PATH                         "Syslog."
#define MMON_TIMEOUT                             5
#define MMON_ALIAS                               "Alias"
#define MMON_ALIAS_LOG                           "resmon-mmon"
#define STR_EMPTY(x) ((NULL == (x)) || ('\0' == (x)[0]))


#define RM_MEMORY_POLLING_INTERVAL            "PollingInterval"
#define RM_MEMORY_CRITICAL_FALL_THRESHOLD     "CriticalFallThreshold"
#define RM_MEMORY_CRITICAL_RISE_THRESHOLD     "CriticalRiseThreshold"
#define RM_MEMORY_ENABLE                      "Enable"
#define RM_MEMORY_ENABLE_CRITICAL_LOG         "EnableCriticalLog"
#define RM_MEMORY_MEM_UTILIZATION             "MemUtilization"
#define RM_MEMORY_VENDOR_LOG_FILE_REF         "VendorLogFileRef"
#define RM_MEMORY_FILE_PATH                   "FilePath"
#define RM_MEMORY_CRITICAL_RISE_TIMESTAMP     "CriticalRiseTimeStamp"
#define RM_MEMORY_CRITICAL_FALL_TIMESTAMP     "CriticalFallTimeStamp"
#define RM_MEMORY_CRITICAL_STATE_EVENT        "MemoryCriticalState!"


/**
 * @enum rm_memory_state_e
 * @brief Memory state indicator.
 */
typedef enum {
    /** Normal memory usage. */
    RM_MEMORY_STATE_NORMAL = 0,

    /** Critical memory usage. */
    RM_MEMORY_STATE_CRITICAL = 1
} rm_memory_state_e;

/**
 * @brief Memory monitor structure for resource monitoring.
 */
typedef struct {
    amxd_object_t* object;                           /**< Pointer to the associated AMXD object. */
    bool mem_enabled;                                /**< Flag indicating if memory monitoring is enabled. */
    rm_memory_state_e mem_state;                     /**< Current memory state. */
    uint32_t fall_threshold;                         /**< Threshold for memory usage fall event. */
    uint32_t rise_threshold;                         /**< Threshold for memory usage rise event. */
    uint32_t polling_interval;                       /**< Interval for polling memory usage (in ms or sec). */
    uint32_t total_mem_usage;                        /**< Current total memory usage. */
    char fall_timestamp[RM_MEM_TIME_STAMP_BUF_SIZE]; /**< Timestamp of last fall event. */
    char rise_timestamp[RM_MEM_TIME_STAMP_BUF_SIZE]; /**< Timestamp of last rise event. */
} resmon_mem_monitor_t;

// Function Declarations

/**
 * @brief Timer handler that reads memory usage and updates state.
 */
void memory_usage_handler(amxp_timer_t* timer, void* priv);

/**
 * @brief Handles transition when current state is critical
 * @param usage Current memory usage percentage.
 */
void memory_critical_state_handler(uint32_t usage);

/**
 * @brief Handles transition when current state is normal
 * @param usage Current memory usage percentage.
 */
void memory_normal_state_handler(uint32_t usage);

/**
 * @brief Initializes the memory monitor during device initialization.
 */
void _resmon_mem_init(void);

/**
 * @brief This function updates MemUtilization parameter using the global variable mmon.total_mem_usage
 */
amxd_status_t _read_memory_utilization(amxd_object_t* object, amxd_param_t* param,
                                       amxd_action_t reason, const amxc_var_t* const args,
                                       amxc_var_t* const retval, void* priv);

/**
 * @brief Clears memory monitor state and resets usage and timestamps.
 * @return uint32_t Return value indicating success (0) or failure (-1).
 */
int32_t resmon_mem_clear(void);

/**
 * @brief Starts the memory monitoring timer if enabled.
 */
void resmon_start_mem_monitor(void);

/**
 * @brief Stops the memory monitoring timer.
 */
void resmon_stop_mem_monitor(void);

/**
 * @brief Reads memory usage from /proc/meminfo and updates usage percentage.
 * @return int32_t Return value indicating success (RM_SUCCESS) or failure (RM_FAILURE).
 */
uint32_t get_current_memory_usage(void);


/**
 * @brief Handles memory state transitions based on usage.
 */
void handle_memory_monitor_state(void);

/**
 * @brief Handles memory enable parameter change.
 */
void _rm_mem_enable_change(const char* const sig_name,
                           const amxc_var_t* const data,
                           void* const priv);

/**
 * @brief Handles polling interval or threshold parameter changes.
 */
void _rm_mem_polling_threshold_change(const char* const sig_name,
                                      const amxc_var_t* const data,
                                      void* const priv);

/**
 * @brief Handles memory critical state signal and logs to vendor file.
 * @return int Return value indicating success or failure.
 */
int _memorycriticalstate_handler(const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv);

/**
 * @brief Sets a specific memory monitor parameter in the data model.
 * @param param_name Name of the parameter to set.
 * @return amxd_status_t Status of the operation.
 */
amxd_status_t set_mem_param(const char* param_name);

/**
 * @brief Validates memory monitor threshold parameters.
 * @return amxd_status_t Status of the validation.
 */
amxd_status_t _validate_memmonitor(amxd_object_t* object, amxd_param_t* param,
                                   amxd_action_t reason, const amxc_var_t* const args,
                                   amxc_var_t* const retval, void* priv);

/**
 * @brief Performs actions when memory enters a critical state.
 *
 * @return RM_MEM_SUCCESS if the action is performed successfully.
 * @return RM_MEM_FAILURE if the action could not be performed.
 */
uint32_t memorycriticalstate_actions(void);

/**
 * @brief Updates VendorLogFileRef for the memory monitor based on current log settings.
 *
 * Synchronizes the log file path and critical log enable status with the syslog configuration.
 */

void mmon_update_vendorlogfileref_syslog(void);


/**
 * @brief Handles updates to log file path or critical log enable flag for memory monitor.
 *
 */

void _mmon_handle_filename_enablelog_change(const char* const sig_name,
                                            const amxc_var_t* const data,
                                            void* const priv);

#endif // RESMON_MEM_H
