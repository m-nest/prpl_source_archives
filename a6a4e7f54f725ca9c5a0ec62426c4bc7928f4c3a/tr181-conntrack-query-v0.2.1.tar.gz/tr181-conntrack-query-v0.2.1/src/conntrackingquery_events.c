/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "conntrackingquery.h"


/**
 * @brief Validates the number of query instances against a maximum limit.
 *
 * This function checks if the number of instances created from a query template
 * is less than or equal to the allowed maximum (`MAX_NOTIFY_QUERIES`).
 * It is only executed during the `action_object_validate` phase.
 *
 * @params reason check if the object is for validating the input
 * @return amxd_status_t Returns amxd_status_ok if the instance count is within the limit,
 *                       otherwise returns an appropriate error status.
 */

amxd_status_t _check_max_instances(UNUSED amxd_object_t* object, UNUSED amxd_param_t* param,
                                   amxd_action_t reason, UNUSED const amxc_var_t* const args,
                                   UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status = amxd_status_not_instantiated;
    when_true_status(reason != action_object_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    uint32_t max_notify_queries;
    amxd_object_t* ct_obj = NULL;

    amxd_dm_t* dm = query_get_dm();
    ct_obj = amxd_dm_findf(dm, "ConnectionTrackingQuery");
    max_notify_queries = amxd_object_get_value(uint32_t, ct_obj, "MaxNotifyQueries", NULL);

    amxd_object_t* queries = query_template(dm);
    uint32_t instanceCount = amxd_object_get_instance_count(queries);

    SAH_TRACEZ_INFO(ME, "Notify Flow Instance count, %d ", instanceCount);

    if(instanceCount <= max_notify_queries) {
        status = amxd_status_ok;
    }

exit:
    return status;
}

/**
 * @brief Validates the IP address provided is valid or not.
 *
 * This function is called during the `query_check_ip` phase to check
 * if the provided IP address is valid.
 *
 * @param *ip  IP address in string format
 * @return int 0 or -1, 0 indicates a valid ip address, -1 is for invalid address
 *
 */
int check_ip_type(const char* ip) {
    struct in_addr ipv4;
    struct in6_addr ipv6;

    if(inet_pton(AF_INET, ip, &ipv4) == 1) {
        return 0;
    } else if(inet_pton(AF_INET6, ip, &ipv6) == 1) {
        return 0;
    } else {
        return -1;
    }
}

/**
 * @brief Validates the IP address parameter during query configuration.
 *
 * This function is called during the `action_param_validate` phase to check
 * if the provided IP address is valid. If the IP address string is empty,
 * it still returns success. Otherwise, it assumes the IP is valid and returns success.

 *
 * @return amxd_status_t Returns amxd_status_ok if validation passes,
 *                       or amxd_status_function_not_implemented if called for a different reason.
 */

amxd_status_t _query_check_IP(amxd_object_t* object, UNUSED amxd_param_t* param,
                              amxd_action_t reason, const amxc_var_t* const args,
                              UNUSED amxc_var_t* const retval, UNUSED void* priv) {

    amxd_status_t status = amxd_status_unknown_error;
    const char* ip_address = NULL;
    (void) object;

    when_true_status(reason != action_param_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    ip_address = amxc_var_constcast(cstring_t, args);
    when_null_status(ip_address, exit, status = amxd_status_invalid_value);

    if(strlen(ip_address) > 0) {
        if(check_ip_type(ip_address) == -1) {
            goto exit;
        }
    }

    status = amxd_status_ok;

exit:
    return status;
}


/**
 * @brief Validates the protocol parameter for a query.
 *
 * This function checks if the given protocol string is valid during the
 * `action_param_validate` phase. It uses a dummy query structure to test
 * if the protocol can be set successfully.
 *
 * @return amxd_status_t Returns amxd_status_ok if the protocol is valid or empty,
 *                       otherwise returns an error status.
 */

amxd_status_t _query_check_protocol(UNUSED amxd_object_t* object, UNUSED amxd_param_t* param,
                                    amxd_action_t reason, const amxc_var_t* const args,
                                    UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    const char* protocol = NULL;
    query_t dummy;

    when_true_status(reason != action_param_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    protocol = amxc_var_constcast(cstring_t, args);
    when_null_status(protocol, exit, status = amxd_status_invalid_value);
    if(strlen(protocol) > 0) {
        if((strcmp(protocol, "tcp") == 0) || (strcmp(protocol, "udp") == 0)) {

        } else {
            goto exit;
        }
    }
    memset(&dummy, 0, sizeof(query_t));

    if(query_set_protocol(&dummy, protocol)) {
        status = amxd_status_ok;
    }

exit:
    return status;
}


/**
 * @brief ODL validator API for port parameters.
 *
 * This function is called by ODL during parameter validation to check if the given
 * port string is valid. It calls the dedicated validate_port_range() API for strict
 * validation (numeric, range 0-65535, or empty).
 *
 * @return amxd_status_t Returns amxd_status_ok if the port is valid or empty,
 *                       otherwise returns amxd_status_invalid_value.
 */

amxd_status_t _query_check_port(UNUSED amxd_object_t* object, UNUSED amxd_param_t* param,
                                amxd_action_t reason, const amxc_var_t* const args,
                                UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status = amxd_status_invalid_value;
    const char* port_str = NULL;

    when_true_status(reason != action_param_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    port_str = amxc_var_constcast(cstring_t, args);
    when_null_status(port_str, exit, status = amxd_status_invalid_value);

    /* Use dedicated validation API */
    if(validate_port_range(port_str)) {
        status = amxd_status_ok;
    }

exit:
    return status;
}


/**
 * @brief Validates the event parameter for the notify query.
 *
 * This function checks if the given event string is valid during the
 * `action_param_validate` phase. It uses a dummy query structure to test
 * if the event filter is valid or not.
 *
 * @return amxd_status_t Returns amxd_status_ok if the port is valid or empty,
 *                       otherwise returns an error status.
 */

amxd_status_t _query_check_event_filter(UNUSED amxd_object_t* object, UNUSED amxd_param_t* param,
                                        amxd_action_t reason, const amxc_var_t* const args,
                                        UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    const char* event_filter = NULL;
    query_t dummy;

    when_true_status(reason != action_param_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    event_filter = amxc_var_constcast(cstring_t, args);
    when_null_status(event_filter, exit, status = amxd_status_invalid_value);
    if(strlen(event_filter) > 0) {
        if((strcmp(event_filter, "New") == 0) || (strcmp(event_filter, "Update") == 0) || (strcmp(event_filter, "Delete") == 0)) {
            status = amxd_status_ok;
        } else {
            goto exit;
        }

    }
    status = amxd_status_ok;

    memset(&dummy, 0, sizeof(query_t));

    if(query_set_event_filter(&dummy, event_filter)) {
        status = amxd_status_ok;
    }

exit:
    return status;
}


/**
 * @brief Cleans up a query instance when it is being destroyed.
 *
 * This function is called during the `action_object_destroy` phase to perform
 * cleanup operations for a query instance. It ensures that any associated
 * resources are properly released.
 *
 * @return amxd_status_t Returns amxd_status_ok if cleanup is successful,
 *                       or amxd_status_function_not_implemented if called for a different reason.
 */

amxd_status_t _query_instance_cleanup(amxd_object_t* object, UNUSED amxd_param_t* param, amxd_action_t reason,
                                      UNUSED const amxc_var_t* const args, UNUSED amxc_var_t* const retval,
                                      UNUSED void* priv) {

    amxd_status_t status = amxd_status_unknown_error;

    when_null(object, exit);
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);


    query_cleanup(NULL, object, NULL);

    status = amxd_status_ok;
exit:
    return status;
}


/**
 * @brief Initializes a query instance with default values and starts processing.
 *
 * This function sets up a new query instance by assigning its index, initializing
 * its fields (such as name, IP addresses, protocol, and ports), and starting a
 * worker thread for processing. It also creates a notification timer for the query.
 *
 * @param[in] templ   Unused. The template object.
 * @param[in] instance The query instance to initialize.
 * @param[in] index    The index of the instance.
 * @param[in] priv     Unused. Private data.
 *
 * @return int Always returns 1 after initialization.
 */


static int query_init(UNUSED amxd_object_t* templ, amxd_object_t* instance, uint32_t index, UNUSED void* priv) {
    query_t* query = NULL;

    when_null(instance, exit);

    query = (query_t*) instance->priv;
    if(query == NULL) {
        query = query_create(instance);
        when_null(query, exit);
    }

    query->index = index;
    amxc_string_set(&(query->name), object_da_string(query->object, "Name"));
    query_set_address(query, object_da_string(query->object, "SourceIP"), true);
    query_set_address(query, object_da_string(query->object, "DestIP"), false);
    query_set_protocol(query, object_da_string(query->object, "Protocol"));
    query_set_port(query, object_da_string(query->object, "SourcePort"), true);
    query_set_port(query, object_da_string(query->object, "DestPort"), false);
    query_set_event_filter(query, object_da_string(query->object, "Event"));
    query->notify_time = 500;
    query->process = NULL;

    // spawn thread
    start_notify_query_worker(query);

    query_create_unix_socket();

exit:
    return 1;
}

/**
 * @brief Handles the event when a new notifyflow query is added.
 *
 * This function is triggered by a signal indicating that a new notifyflow
 * query has been added. It retrieves the corresponding query object and
 * initializes it using the `query_init` function.
 *
 * @param[in] sig_name    The name of the received signal.
 * @param[in] event_data  The event data containing the query index and object info.
 * @param[in] priv        Unused private data.
 */

void _conntrack_notifyflow_query_added (UNUSED const char* const sig_name, const amxc_var_t* const event_data, UNUSED void* const priv) {
    amxd_dm_t* dm = query_get_dm();
    uint32_t index = GET_UINT32(event_data, "index");
    amxd_object_t* queries = amxd_dm_signal_get_object(dm, event_data);
    amxd_object_t* query = amxd_object_get_instance(queries, NULL, GET_UINT32(event_data, "index"));

    SAH_TRACEZ_INFO(ME, "Received event: [%s]", sig_name);
    SAH_TRACEZ_INFO(ME, "New Notifyflow query added");

    when_null(query, exit);

    query_init(queries, query, index, NULL);

exit:
    return;
}
