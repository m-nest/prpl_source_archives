/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "wld/wld.h"
#include "wld/wld_radio.h"
#include "wld/wld_ssid.h"
#include "wld/wld_endpoint.h"
#include "wld/wld_linuxIfUtils.h"
#include "wld/wld_wpaSupp_cfgFile.h"
#include "wifiGen_wpaSupp.h"
#include "wifiGen_hapd.h"
#include "wifiGen_wpaSupp.h"
#include "wifiGen_fsm.h"
#include "wld/wld_util.h"

#define ME "genWsup"
#define WPASUPP_CONF_FILE_PATH_FORMAT "/tmp/%s_wpa_supplicant.conf"
#define WPASUPP_CMD "wpa_supplicant"
#define WPASUPP_ARGS_FORMAT_EXT "-ddK -b%s -i%s -Dnl80211 -c%s"
#define WPASUPP_ARGS_FORMAT "-ddK -i%s -Dnl80211 -c%s"
#define WPASUPP_CTRL_IFACE_DIR "/var/run/wpa_supplicant"

#define WPA_SUPP_EXIT_REASON_LOAD_FAIL 255

static void s_restartWpaSuppCb(wld_secDmn_t* pSecDmn, void* userdata) {
    T_EndPoint* pEP = (T_EndPoint*) userdata;
    ASSERT_NOT_NULL(pEP, , ME, "NULL");
    const char* mainIface = pEP->Name;
    ASSERTW_TRUE(wld_endpoint_hasStackEnabled(pEP), , ME, "%s: ep iface %s is not startable", pEP->alias, mainIface);
    ASSERTW_FALSE(wifiGen_wpaSupp_isRunning(pEP), , ME, "%s: wpa_supplicant running", mainIface);
    SAH_TRACEZ_WARNING(ME, "%s: restarting wpa_supp", mainIface);
    wld_secDmn_restartCb(pSecDmn);
}

static void s_onStopWpaSuppCb(wld_secDmn_t* pSecDmn _UNUSED, void* userdata) {
    T_EndPoint* pEP = (T_EndPoint*) userdata;
    ASSERT_NOT_NULL(pEP, , ME, "NULL");
    const char* mainIface = pEP->Name;
    SAH_TRACEZ_WARNING(ME, "%s: wpa_supp stopped", mainIface);
    wld_deamonExitInfo_t* pExitInfo = &pSecDmn->dmnProcess->lastExitInfo;
    if((pExitInfo != NULL) && (pExitInfo->isExited) &&
       (pExitInfo->exitStatus == WPA_SUPP_EXIT_REASON_LOAD_FAIL)) {
        SAH_TRACEZ_ERROR(ME, "%s: invalid wpa_supp configuration", mainIface);
    }
    wld_endpoint_sync_connection(pEP, false, EPE_NONE);
    if(pEP->wpsSessionInfo.WPS_PairingInProgress) {
        wld_endpoint_sendPairingNotification(pEP, NOTIFY_PAIRING_DONE, WPS_CAUSE_CANCELLED, NULL);
    }
    //finalize wpa_supp cleanup
    wifiGen_wpaSupp_stopDaemon(pEP);
}

static void s_onStartWpaSuppCb(wld_secDmn_t* pSecDmn _UNUSED, void* userdata) {
    T_EndPoint* pEP = (T_EndPoint*) userdata;
    ASSERT_NOT_NULL(pEP, , ME, "NULL");
    const char* mainIface = pEP->Name;
    SAH_TRACEZ_WARNING(ME, "%s: wpa_supp started", mainIface);
    wld_wpaCtrlMngr_connect(wld_secDmn_getWpaCtrlMgr(pEP->wpaSupp));
}

static char* s_getWpaSupArgsCb(wld_secDmn_t* pSecDmn, void* userdata _UNUSED) {
    char* args = NULL;
    ASSERT_NOT_NULL(pSecDmn, args, ME, "NULL");
    T_EndPoint* pEP = (T_EndPoint*) userdata;
    ASSERT_NOT_NULL(pEP, args, ME, "NULL");
    char startArgs[256] = {0};
    //custom arguments
    swl_str_copy(startArgs, sizeof(startArgs), wld_dmnMgt_getStartArgs(WPASUPP_CMD));
    //per interface arguments
    swl_strlst_catFormat(startArgs, sizeof(startArgs), " ", "-i %s", pEP->Name);
    swl_strlst_catFormat(startArgs, sizeof(startArgs), " ", "-Dnl80211");
    if(!swl_str_isEmpty(pEP->bridgeName)) {
        swl_strlst_catFormat(startArgs, sizeof(startArgs), " ", "-b %s", pEP->bridgeName);
    }
    if(!swl_str_isEmpty(pSecDmn->cfgFile)) {
        swl_strlst_catFormat(startArgs, sizeof(startArgs), " ", "-c %s", pSecDmn->cfgFile);
    }
    swl_str_copyMalloc(&args, startArgs);
    return args;
}

swl_rc_ne wifiGen_wpaSupp_init(T_EndPoint* pEP) {
    ASSERT_NOT_NULL(pEP, SWL_RC_INVALID_PARAM, ME, "NULL");
    char confFilePath[128] = {0};
    bool ret = swl_str_catFormat(confFilePath, sizeof(confFilePath), WPASUPP_CONF_FILE_PATH_FORMAT, pEP->Name);
    ASSERTI_TRUE(ret, SWL_RC_ERROR, ME, "%s: writing wpaSupplicantConfigPath error", pEP->Name);

    swl_rc_ne rc = wld_secDmn_init(&pEP->wpaSupp, WPASUPP_CMD, NULL, confFilePath, WPASUPP_CTRL_IFACE_DIR);
    ASSERT_FALSE(rc < SWL_RC_OK, rc, ME, "%s: Fail to init wpa_supplicant", pEP->Name);
    wld_secDmnEvtHandlers handlers;
    memset(&handlers, 0, sizeof(handlers));
    handlers.restartCb = s_restartWpaSuppCb;
    handlers.stopCb = s_onStopWpaSuppCb;
    handlers.startCb = s_onStartWpaSuppCb;
    handlers.getArgs = s_getWpaSupArgsCb;
    wld_secDmn_setEvtHandlers(pEP->wpaSupp, &handlers, pEP);
    ASSERT_TRUE(wld_wpaCtrlInterface_init(&pEP->wpaCtrlInterface, pEP->Name, pEP->wpaSupp->ctrlIfaceDir),
                SWL_RC_ERROR, ME, "%s: Fail to init EP interface", pEP->Name);
    ASSERT_TRUE(wld_wpaCtrlMngr_registerInterface(pEP->wpaSupp->wpaCtrlMngr, pEP->wpaCtrlInterface),
                SWL_RC_ERROR, ME, "%s: fail to add wpa_ctrl interface to mngr", pEP->Name);
    return SWL_RC_OK;
}

void wifiGen_wpaSupp_cleanup(T_EndPoint* pEP) {
    ASSERT_NOT_NULL(pEP, , ME, "NULL");
    SAH_TRACEZ_INFO(ME, "%s: Destroy wpa_supplicant", pEP->Name);
    wld_secDmn_cleanup(&pEP->wpaSupp);
}

swl_rc_ne wifiGen_wpaSupp_startDaemon(T_EndPoint* pEP) {
    ASSERT_NOT_NULL(pEP, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERT_NOT_NULL(pEP->wpaSupp, SWL_RC_INVALID_STATE, ME, "%s: wpaSupp not initialized", pEP->Name);
    SAH_TRACEZ_WARNING(ME, "%s: Start wpa_supplicant", pEP->Name);
    wld_wpaCtrlInterface_setEnable(pEP->wpaCtrlInterface, pEP->enable);
    return wld_secDmn_start(pEP->wpaSupp);
}

swl_rc_ne wifiGen_wpaSupp_stopDaemon(T_EndPoint* pEP) {
    ASSERTS_NOT_NULL(pEP, SWL_RC_INVALID_PARAM, ME, "NULL");
    SAH_TRACEZ_WARNING(ME, "%s: Stop wpa_supplicant", pEP->Name);
    swl_rc_ne rc = wld_secDmn_stop(pEP->wpaSupp);
    wld_ssid_setMLDLinkID(pEP->pSSID, NO_LINK_ID);
    wld_ssid_setMLDRole(pEP->pSSID, SWL_MLO_ROLE_NONE);
    ASSERTI_NOT_EQUALS(rc, SWL_RC_CONTINUE, rc, ME, "%s: wpa_supp being stopped", pEP->Name);
    wld_linuxIfUtils_setStateExt(pEP->Name, 0);
    ASSERTI_FALSE(rc < SWL_RC_OK, rc, ME, "%s: wpa_supplicant not running", pEP->Name);
    return SWL_RC_OK;
}

swl_rc_ne wifiGen_wpaSupp_reloadDaemon(T_EndPoint* pEP) {
    ASSERTS_NOT_NULL(pEP, SWL_RC_INVALID_PARAM, ME, "NULL");
    SAH_TRACEZ_INFO(ME, "%s : Reload wpa_supplicant", pEP->Name);
    return wld_secDmn_reload(pEP->wpaSupp);
}

void wifiGen_wpaSupp_writeConfig(T_EndPoint* pEP) {
    ASSERTS_NOT_NULL(pEP, , ME, "NULL");
    wld_wpaSupp_cfgFile_createExt(pEP);
}

bool wifiGen_wpaSupp_isRunning(T_EndPoint* pEP) {
    return ((pEP != NULL) && (wld_secDmn_isRunning(pEP->wpaSupp)));
}

bool wifiGen_wpaSupp_isAlive(T_EndPoint* pEP) {
    return ((pEP != NULL) && (wld_secDmn_isAlive(pEP->wpaSupp)));
}

void wifiGen_wpaSupp_restartDaemon(T_EndPoint* pEP) {
    ASSERTS_NOT_NULL(pEP, , ME, "NULL");
    SAH_TRACEZ_INFO(ME, "restart %s", pEP->Name);
    if(wld_secDmn_isRunning(pEP->wpaSupp)) {
        wld_secDmn_restart(pEP->wpaSupp);
    }
}

void wifiGen_wpaSupp_restartAllDaemons(vendor_t* pVdr) {
    T_Radio* pRad;
    wld_for_eachRad(pRad) {
        if((pRad == NULL) || (pRad->vendor != pVdr)) {
            continue;
        }
        T_EndPoint* pEP = NULL;
        wld_rad_forEachEp(pEP, pRad) {
            wifiGen_wpaSupp_restartDaemon(pEP);
        }
    }
}

/**
 * @brief handle custom arguments changes and restart daemons if needed
 *
 * @param pVdr pointer to vendor context
 * @param pCfg pointer to daemon execution settings
 *
 * @return true when a restart is needed to apply change
 */
static bool s_handleCustomArguments(vendor_t* pVdr, wld_dmnMgt_dmnExecSettings_t* pCfg) {
    ASSERT_NOT_NULL(pVdr, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERT_NOT_NULL(pCfg, SWL_RC_INVALID_PARAM, ME, "NULL");

    bool restartNeeded = false;
    T_Radio* pRad;
    wld_for_eachRad(pRad) {
        if(pRad->vendor != pVdr) {
            continue;
        }

        T_EndPoint* pEP = NULL;
        wld_rad_forEachEp(pEP, pRad) {
            if(!(pEP && pEP->wpaSupp && pEP->wpaSupp->dmnProcess)) {
                continue;
            }

            wld_process_t* dmnProcess = pEP->wpaSupp->dmnProcess;
            if(dmnProcess->handlers.getArgsCb == NULL) {
                continue;
            }

            char* newArgs = dmnProcess->handlers.getArgsCb(dmnProcess, dmnProcess->userData);
            //compare newly built cmdline args, against those saved in dmn proc context
            if(!swl_str_isEmpty(dmnProcess->args) && !swl_str_matches(dmnProcess->args, newArgs)) {
                SAH_TRACEZ_INFO(ME, "Args diff: \"%s\" to \"%s\", restart needed %s wpaSupp %s", dmnProcess->args, newArgs, pEP->Name, pVdr->name);
                restartNeeded = true;
            }
            free(newArgs);
        }
    }
    return restartNeeded;
}

/**
 * @brief handle the conf changes of daemon execution settings for wpa_supplicant
 *
 * @param pVdr pointer to vendor context
 * @param pCfg pointer to daemon execution settings
 *
 * @return SWL_RC_OK on success, error code otherwise
 */
swl_rc_ne wifiGen_wpaSupp_setDmnExecSettings(vendor_t* pVdr, wld_dmnMgt_dmnExecSettings_t* pCfg) {
    ASSERT_NOT_NULL(pVdr, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERT_NOT_NULL(pCfg, SWL_RC_INVALID_PARAM, ME, "NULL");

    bool restartNeeded = s_handleCustomArguments(pVdr, pCfg);
    if(restartNeeded) {
        wifiGen_wpaSupp_restartAllDaemons(pVdr);
    }
    return SWL_RC_OK;
}
