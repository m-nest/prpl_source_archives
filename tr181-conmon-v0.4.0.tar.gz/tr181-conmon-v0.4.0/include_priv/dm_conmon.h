/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__DM_CONMON_H__)
#define __DM_CONMON_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "conmon.h"

/**
   @file
   @brief
   Handlers used when interacting with ConMon.Entry.i data model
 */

/**
   @ingroup conmon
   @defgroup dm_conmon ConMon data model interaction

   Functions relatives to the interaction with the ConMOn.entry.i data model
 */

/**
   @ingroup dm_conmon
   @brief
   Event handler when a ConMon.Entry.i is added to the data model. This initialise internal structures and subscribe to the needed objects on the datamodel.

   @param sig_name The signal send on the bus by the caller
   @param data The data send by the event. In this function the data contains the path and the parameter of the added entry
   @param priv Additionnal data send by the caller. In this function no extra data are expected
 */
void _conmon_entry_added(const char* const sig_name,
                         const amxc_var_t* const data,
                         void* const priv);

/**
   @ingroup dm_conmon
   @brief
   Event handler when the parameter enable of a ConMon.Entry.i is changed

   @param sig_name The signal send on the bus by the caller
   @param data The data send by the event. In this function the data contains the previous and the currently value of the Enable parameter
   @param priv Additionnal data send by the caller. In this function no extra data are expected
 */
void _conmon_entry_enable_changed(const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv);

/**
   @ingroup dm_conmon
   @brief
   Action handler when a ConMon.Entry.i is removed from the datamodel. This function ensure that all structure, subscription and memory is cleaned for a specific ConMon.Entry.i object

    @param object The amxd_object removed from the data model
    @param param List of the removed object parameters
    @param reason The reason of the action called. In this case the function should only accept action_object_destroy action
    @param args Arguments passed when removed the ConMon.Entry.i object. In this function there is no extra arguments expected
    @param retval Variant containing axtra information when this function return. In this function no extra return values are expected
    @param priv Additionnal structure passed by the caller. In this function no extra structures are expected

    @return
    amxd_status_ok when everything was correctly cleared
    amxd_status_invalid_action if the action called is not action_object_destroy
    amxd_status_invalid_function_argument elsewhere
 */
amxd_status_t _conmon_entry_removed(amxd_object_t* object,
                                    amxd_param_t* param,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv);

#ifdef __cplusplus
}
#endif

#endif // __DM_CONMON_H__
