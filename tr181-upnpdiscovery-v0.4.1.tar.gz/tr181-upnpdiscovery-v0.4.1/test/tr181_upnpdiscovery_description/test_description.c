/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <upnp/upnp.h>

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>

#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"
#include "tr181-description.h"
#include "test_description.h"

int test_setup(UNUSED void** state) {
    amxut_bus_setup(state);
    int retval = 0;
    const char* odl =
        "%config {"
        "    include-dirs = ["
        "        \"../../odl/\""
        "    ];"
        "    modules = {"
        "        fw-directory = \"../common/modules/\""
        "    };"
        "    lan = \"Device.IP.Interface.lan.\";"
        "}"
        "include \"tr181-upnpdiscovery_definition.odl\";"
        "include \"tr181-upnpdescription_definition.odl\";"
        "include \"../test/common/mock_netmodel.odl\";"
        "%define {"
        "}"
        "%populate {"
        "on event \"app:start\" call app_start;"
        "}";

    //events
    amxo_resolver_ftab_add(amxut_bus_parser(), "app_start", AMXO_FUNC(_app_start));
    amxo_resolver_ftab_add(amxut_bus_parser(), "upnp_discovery_service_added", AMXO_FUNC(_upnp_discovery_service_added));
    amxo_resolver_ftab_add(amxut_bus_parser(), "upnp_discovery_device_added", AMXO_FUNC(_upnp_discovery_device_added));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_discovery_item_destroyed", AMXO_FUNC(_dm_discovery_item_destroyed));
    amxo_resolver_ftab_add(amxut_bus_parser(), "upnp_description_object_added", AMXO_FUNC(_upnp_description_object_added));
    amxo_resolver_ftab_add(amxut_bus_parser(), "upnp_description_device_added", AMXO_FUNC(_upnp_description_device_added));
    amxo_resolver_ftab_add(amxut_bus_parser(), "upnp_description_service_added", AMXO_FUNC(_upnp_description_service_added));

    retval = amxo_parser_parse_string(amxut_bus_parser(), odl, amxd_dm_get_root(amxut_bus_dm()));
    if(retval) {
        printf("PARSER MESSAGE = %s\n", amxc_string_get(&amxut_bus_parser()->msg, 0));
    }
    assert_int_equal(retval, 0);

    assert_int_equal(_main(0, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();
    amxp_sigmngr_emit_signal(&amxut_bus_dm()->sigmngr, "app:start", NULL);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxp_sigmngr_emit_signal(&amxut_bus_dm()->sigmngr, "app:stop", NULL);
    amxut_bus_handle_events();

    assert_int_equal(_main(1, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);

    return 0;
}

void test_description_full_xml(UNUSED void** state) {
    device_desc_t data = {0};

    data.xmlDoc = ixmlLoadDocument("rootDesc.xml");
    assert_non_null(data.xmlDoc);
    data.location = "http://192.168.1.1:5000/rootDesc.xml";
    upnp_description_extract_ipaddress(&data);
    assert_string_equal(data.ip_address, "192.168.1.1");
    data.device_desc = upnp_description_get_device_description(data.location);
    assert_non_null(data.device_desc);
    parse_xmlnode(data.xmlDoc->n.firstChild, &data);
    amxut_bus_handle_events();
    free(data.ip_address);
    ixmlDocument_free(data.xmlDoc);
}

void test_description_extract_ip(UNUSED void** state) {
    device_desc_t data = {0};

    data.location = "";
    upnp_description_extract_ipaddress(&data);
    assert_null(data.ip_address);
    data.location = "http://localhost:5000/rootDesc.xml";
    upnp_description_extract_ipaddress(&data);
    assert_string_equal(data.ip_address, "localhost");
    free(data.ip_address);
    data.ip_address = NULL;
    data.location = "http://192.168.1.1:5000/rootDesc.xml";
    upnp_description_extract_ipaddress(&data);
    assert_string_equal(data.ip_address, "192.168.1.1");
    free(data.ip_address);
    data.ip_address = NULL;
    data.location = "http://[fe80::b7a:972d:c514:8b40]:5000/rootDesc.xml";
    upnp_description_extract_ipaddress(&data);
    assert_string_equal(data.ip_address, "fe80::b7a:972d:c514:8b40");
    free(data.ip_address);
    data.ip_address = NULL;

}