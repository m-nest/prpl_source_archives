/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>

#include "routing_table.h"

#define ME "routing-table"

#define RT_TABLES_PATH "/etc/iproute2/rt_tables"

bool is_valid_rt_table_entry(int table_id, const char* table_name) {
    bool ret = false;

    when_true(table_id <= 0, exit);
    when_str_empty(table_name, exit);

    switch(table_id) {
    case 128:
        if(strcmp(table_name, "prelocal") == 0) {
            ret = true;
        }
        goto exit;
    case 253:
        if(strcmp(table_name, "default") == 0) {
            ret = true;
        }
        goto exit;
    case 254:
        if(strcmp(table_name, "main") == 0) {
            ret = true;
        }
        goto exit;
    case 255:
        if(strcmp(table_name, "local") == 0) {
            ret = true;
        }
        goto exit;
    }

    if((strcmp(table_name, "unspec") == 0) || (strcmp(table_name, "prelocal") == 0) ||
       (strcmp(table_name, "local") == 0) || (strcmp(table_name, "main") == 0) ||
       (strcmp(table_name, "default") == 0)) {
        // table name is a predefined value but doesn't match the right table id, so invalid entry
        goto exit;
    }

    ret = true;
exit:
    return ret;
}

int set_rt_table_entry(int table_id, const char* table_name) {
    int rv = -1;
    char line[256] = {0};
    bool found = false;
    long file_pos = 0;
    long entry_pos = -1;
    FILE* fp = fopen(RT_TABLES_PATH, "r+");

    when_null_trace(fp, exit, ERROR, "Failed to open %s with error %s", RT_TABLES_PATH, strerror(errno));

    when_false_trace(is_valid_rt_table_entry(table_id, table_name), exit, ERROR, "Table entry %d-%s is invalid", table_id, table_name);

    while(fgets(line, sizeof(line), fp) != NULL) {
        int existing_table_id = -1;
        char existing_table_name[256] = {0};

        if(sscanf(line, "%d %255s", &existing_table_id, existing_table_name) == 2) {
            if(existing_table_id == table_id) {
                entry_pos = file_pos;
                found = true;
                break;
            }
        }
        file_pos = ftell(fp);
    }

    if(found) {
        fseek(fp, entry_pos, SEEK_SET);
        fprintf(fp, "%d\t%s\n", table_id, table_name);
    } else {
        fseek(fp, 0, SEEK_END);
        fprintf(fp, "%d\t%s\n", table_id, table_name);
    }
    rv = 0;
exit:
    if(fp != NULL) {
        fclose(fp);
    }
    return rv;
}

int del_rt_table_entry(int table_id) {
    int rv = -1;
    FILE* fp = fopen(RT_TABLES_PATH, "r+");
    char temp_file[] = "/etc/iproute2/rt_tables_temp";
    FILE* temp_fp = NULL;
    char line[256] = {0};
    bool deleted = false;

    if((table_id <= 0) || (table_id == 128) || ((table_id >= 253) && (table_id <= 255))) {
        // table_id is equal to a predefined value, this entry shouldn't be deleted.
        SAH_TRACEZ_ERROR(ME, "Not allowed to delete table %d", table_id);
        goto exit;
    }

    when_null_trace(fp, exit, ERROR, "Failed to open %s with error %s", RT_TABLES_PATH, strerror(errno));

    temp_fp = fopen(temp_file, "w");
    when_null_trace(temp_fp, exit, ERROR, "Failed to open %s with error %s", temp_file, strerror(errno))

    while(fgets(line, sizeof(line), fp)) {
        int existing_table_id;
        if(sscanf(line, "%d", &existing_table_id) == 1) {
            if(existing_table_id == table_id) {
                deleted = true;
                continue;
            }
        }
        fputs(line, temp_fp);
    }
    fclose(temp_fp);
    when_false_status(deleted, exit, rv = 0); // nothing changed
    when_failed_trace(rename(temp_file, RT_TABLES_PATH), exit, ERROR,
                      "Failed to delete routing table %d, error %s", table_id, strerror(errno));

    rv = 0;
exit:
    remove(temp_file);
    if(fp != NULL) {
        fclose(fp);
    }
    return rv;
}
