TR181-Temperature
============

# Requirements

## Introduction and High-Level Description

The Temperature Monitoring Module is designed to provide monitoring of thermal conditions within Customer Premises Equipment (CPE). This module leverages the TR-181 data model to ensure  reporting and management of temperature-related events.


## Use Case Definition

TR181-Tempeature pugin provides teh following features: 

- **Temperature Reporting and Logging**
  - Implementation of a TR-181 v2.17 `Device.DeviceInfo.TemperatureStatus` datamodel.
  - Provide an Enable switch for individual sensors.
  - Expose current temperature and names of sensors.
  - Provide minimum and maximum recorded values along with timestamps.
  - Configuration of polling interval for temperature readings.
  - Configure of low and high alarm threshold values.
  - Expose initial timestamps when alarm values were triggered.
  - Reset command to clear alarm timestamps.

- **LL-API Interface**
  - Read sensor values from standard Linux thermal zones as described in the [Linux Thermal Sysfs API](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt).
  - Option to configure the path of the sysfs device driver from configuration settings.

- **Safety Mechanisms**
  - Handle a graceful shutdown of the router when temperature exceeds defined thresholds.


## References

* TR-181  TemperatureStatus datamodel: [https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.TemperatureStatus.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus.)
* Linux kernel thermal sysfs API: [https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt)
 


# Architecture

TR181-Temperature is a standard ambiorix application connected to the bus and exposing datamodel. It is polling sys fs periodically

![TR181-Temperature Architecture diagram](image/TemperatureArchitecture.png)


#### **Temperature polling**

The tr181-temperature plugin must periodically poll the temperature values of the configured sensors. This polling interval must be configurable by the user and can be modified on the go. 

If no polling interval is set, a default value will be used as polling interval. This value must be internal to the plugin and hidden form the user.

#### **Temperature statistics**

The tr181-temperature plugin must provide multiple temperature statistics data to the user. 

A maximum temperature value can be set by the user and will let the plugin record the moment in time where the value is reached. This will be readable by the user as a time stamp.

The maximum effective reached temperature will also be stored in the datamodel and be readable by the user.

A minimum temperature value can be set by the user and will let the plugin record the moment in time where the value is reached. This will be readable by the user as a time stamp.

The minimum effective reached temperature will also be stored in the datamodel and be readable by the user.

#### **Reset of the temperature sensor's statistics**

The temperature sensor's statistics can be reset to defaults values. When reset, the upper and lower temperature limits will be set to \-274 degrees Celsius, disabling them.

The stored upper and lower temperature time stamp will be removed and the sensor will be set to a disabled state. The user will have to manually enable the sensor via the datamodel.

#### **Source of the temperature readings**

The parameter "Name" is used to store the path to the temperature file in sysfs.

# Implementation
 
## Data Model

Datamodel is implemented according to TR181: [https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.TemperatureStatus.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus.)

HighTemperatureAlarm on high alarm mark is defined, but not part of TR-181. No low temperature alarm event is defined.

## Low-Level API

TR181-Temperature relies relies on linux kernel thermal zones as defined in [https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt)

## API

## Files

All files used by the component are in `/amx/tr181-temperature/.`

Component polls regularly `/sys/class/thermal/thermal_zone*` to fetch temperature data.



## Dependants and Dependencies

### Dependants

Weak dependancy from [reboot-service](https://gitlab.com/prpl-foundation/components/core/plugins/reboot-service) plugin that subscribe to HighAlarm events to handle reboot. see Reboot-Service documentaiton for more details.

### Dependencies

TR181-Temperature is dependent on ambiorix framework:

* lib\_amxc  
* lib\_amxd  
* lib\_amxp  
* lib\_amxo  
* lib\_sahtrace

TR181-Temperature also depends on following modules to build an initial configuration retrieving system available sensors in sysfs:

* odl-generator:  
* ucode-mod-fs : used

## Configuration

Main configuration file is in `/etc/amx/tr181-temperature/tr181-temperature.odl`

By default, on firstboot, initial instances are created by looking for all `thermal_zone` files in `/sys/class/thermal/`. This is implemented through `/etc/amx/tr181-temperature/defaults.d/tr181-temperature_defaults.odl.uc` processed by odl-generator.

This can be easily overridden by providing a default `/etc/amx/tr181-temperature/defaults.d/tr181-temperature_defaults.odl` file.

Note that, in case of and SDK upstep, any change in the list of thermal zones or their names, there is no guarantee that the data model still behaves correctly. A factory reset might be needed to correct it. It is important for the System Integrator to verify this on SDK upsteps.

## Backup/Restore, Upgrade, Reset

TR181-Temperature doesn’t have any persistent parameter as temperature data is considered to be relevant only for a given boot.
LowAlarmValue, HighAlarmValue, PollingInterval should be persistent.


# Considerations

## Security

The plugin executes with the tr181\_app user and drops all the capabilities except:

* CAP\_DAC\_OVERRIDE: To allow read access to temperature

## Remote Management

Few parameters are writeable to set thresholds and pollingInterval. A Reset() command is also available. Refer to TR-181 datamodel.

## Unit Tests

Tests are available in gitlab: [https://gitlab.com/prpl-foundation/components/core/plugins/tr181-temperature/-/tree/main/test?ref\_type=heads](https://gitlab.com/prpl-foundation/components/core/plugins/tr181-temperature/-/tree/main/test?ref_type=heads)

Hereafter is a high level description of the tests:

| Test name | Description |
| :---- | :---- |
| test\_start\_plugin | \-Registers the datamodel of the plugin → Checks that the datamodel is indeed reachable through the bus. |
| test\_stop\_plugin | \-Stops the plugin and unregisters it from the bus → Checks that the datamodel is indeed freed from the bus and that the plugin structure has been freed. |
| test\_launch\_cycle | \-Enable sensor number 1 → check if the status of the polling timer is different from "amxp\_timer\_off". Showing that the timer has started. |
| test\_wait\_for\_cycle | \-Comes after test\_launch\_cycle → checks if the cycle has made at least one measurement by checking the value of the private data of the object |
| test\_tempsensor\_exists | \-Checks if the thermal sensor exists → Uses a function from the code and certifies that "tempsensor\_device\_exists" can effectively show that the path to a sensor can be reached or not. |
| test\_probe\_tempsensor | \-Checks the value of the temperature sensor → Uses "probe\_tempsensor" to show that the value of the temperature sensor can be read by the method used by the code of the plugin. |
| test\_toggled | \-Toggle the "Enable" parameter in the datamodel → check if the status changes accordingly. Enabled, Disabled.  |
| test\_update | \-Updates "PollingInterval" → Checks if the timer has a timeout smaller than 2000 milliseconds \-Updates "HighAlarmTime"→ Checks if the registered max time has changed or not. \-Updates "LowAlarmTime"→ Checks if the registered min time has changed or not. |
| test\_reset | \-Invokes the "Reset" function of the datamodel→ Checks if all the values of the sensor are indeed set back to their default state |

## Logging and Debugging

Following trace zones are available:

* `tmp_start` : logs related to plugin initialization  
* `tmp_cycl`: logs related to temperature cycling probing  
* `tmp_dev`: logs related to interaction swith temperature sensor device  
* `tmp_mn`: global plugin trace zone

## Functional Tests

| Step | Test designation | Description  | Expected result |
| :---- | :---- | :---- | :---- |
| 1 | Datamodel is reachable | `Device.DeviceInfo.TemperatureStatus.?` | Datamodel should be displayed with detected thermal\_zones |
| 2 | Monitor temperature rise | in ba-cli: `Device.DeviceInfo.TemperatureStatus.?&`Raise the temperature | Value on sensor should raise.MaxValue should be adjusted if it was lower than value and MaxTime set to the time when the max was reached |
| 3 | Test High alarms | in ba-cli: `Device.DeviceInfo.TemperatureStatus.TemperatureSensor.1.HighAlarmValue=67` then raise temperature note chosen value should be higher than current temp but still easil reachable. | Time should be reset HighAlarmTime should be set to the date of the High alarm |
| 4 | reset HighAlarms | in ba-cli: `Device.DeviceInfo.TemperatureStatus.TemperatureSensor.1.HighAlarmValue=-274` | HighAlarmTime should be reset |


Note those tests assume you have a way to control the temperature read by the sensors. A possible way to raise temperatures is to max out the CPUs. A possibility is to use multiple dummy processes as such:  
`cat /dev/urandom > /dev/null &`  
`cat /dev/urandom > /dev/null &`  
`cat /dev/urandom > /dev/null &`  
`cat /dev/urandom > /dev/null &`

you could stop them with `killall cat` command and temperature should lower naturally. 

## CI Tests

Real temperature testing is very environment dependent, so it is difficult to test properly in CI testbed.
A minimal test fetching the datamodel and maybe checking temperature are in a reasonable range can be performed. 
