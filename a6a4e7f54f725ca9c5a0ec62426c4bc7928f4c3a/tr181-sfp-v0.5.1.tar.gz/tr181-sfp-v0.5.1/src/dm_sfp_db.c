/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "dm_sfp_db.h"

/* System headers */
#include <stddef.h> /* NULL */
#include <string.h> /* strcmp() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* when_str_empty() */
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h> /* amxd_object_for_each() */
#include <amxo/amxo.h>        /* amxo_parser_get_config() */

/* Own headers */
#include "sfpmgr_trace.h"
#include "sfpmgr_main.h" /* sfp_get_parser() */

static amxd_dm_t* s_dm = NULL;
static amxc_string_t s_sfp_db_path; /* path to SFP DB in DM */

/**
 * Determine and assign value to s_sfp_db_path.
 *
 * Query global_vendor_prefix_ and use it to determine and assign value to
 * s_sfp_db_path.
 */
static void determime_sfp_db_path(void) {

    int rc;

    amxc_string_init(&s_sfp_db_path, 0);

    amxo_parser_t* const parser = sfp_get_parser();
    when_null_trace(parser, exit, ERROR, "parser is NULL");

    const amxc_var_t* const prefix_var =
        amxo_parser_get_config(parser, "global_vendor_prefix_");
    when_null_trace(prefix_var, exit, ERROR, "Failed to get global_vendor_prefix_");

    const char* const prefix = GET_CHAR(prefix_var, NULL);
    when_null_trace(prefix, exit, ERROR, "Failed to extract value for global_vendor_prefix_");

    rc = amxc_string_setf(&s_sfp_db_path, "SFPs.%sSFPDatabase", prefix);
    when_failed_trace(rc, exit, ERROR, "amxc_string_setf() failed");

exit:
    return;
}

void dm_sfp_db_init(amxd_dm_t* dm) {
    s_dm = dm;
    determime_sfp_db_path();
}

void dm_sfp_db_cleanup(void) {
    amxc_string_clean(&s_sfp_db_path);
}

#define NR_OF_SFP_DB_KEYS 2
static const char* const SFP_DB_KEYS[NR_OF_SFP_DB_KEYS] = { "VendorName", "VendorPN" };

/**
 * Look up the SFP type for a certain vendor name and part number in the SFP DB.
 *
 * @param[in] vendor_name: vendor name of the SFP
 * @param[in] vendor_pn: part number of the SFP
 *
 * The function looks for an entry in the SFP DB with @a vendor_name and @a
 * vendor_pn as keys. It returns the value of the parameter SFPType for that
 * entry converted to `sfp_types_e`.
 *
 * @return SFP_UNSUPPORTED if the SFP does not occur in the SFP DB
 * @return one of the other values of sfp_types_e if the SFP occurs in the SFP
 *         DB with a valid SFP type value
 */
sfp_types_e dm_sfp_db_look_up_sfp_type(const char* vendor_name, const char* vendor_pn) {

    sfp_types_e result = SFP_UNSUPPORTED;
    const amxc_var_t* var;
    const char* key;
    const char* value;
    bool match;
    int i;

    const char* const needles[NR_OF_SFP_DB_KEYS] = { vendor_name, vendor_pn };

    when_null_trace(s_dm, exit, ERROR, "s_dm is NULL");

    when_str_empty(vendor_name, exit);
    when_str_empty(vendor_pn, exit);

    const char* const sfp_db_path = amxc_string_get(&s_sfp_db_path, 0);
    when_null_trace(sfp_db_path, exit, ERROR, "Failed to get SFP DB path");

    amxd_object_t* const sfp_db = amxd_dm_findf(s_dm, "%s", sfp_db_path);
    when_null_trace(sfp_db, exit, ERROR, "Failed to find %s", sfp_db_path);

    amxd_object_for_each(instance, it, sfp_db) {
        amxd_object_t* inst = amxc_llist_it_get_data(it, amxd_object_t, it);
        when_null_trace(inst, exit, ERROR, "Failed to get %s instance", sfp_db_path);

        for(i = 0; i < NR_OF_SFP_DB_KEYS; ++i) {
            key = SFP_DB_KEYS[i]; /* alias */
            var = amxd_object_get_param_value(inst, key);
            when_null_trace(var, exit, ERROR, "Failed to get %s", key);
            value = GET_CHAR(var, NULL);
            when_str_empty_trace(value, exit, ERROR, "Failed to get C string for %s", key);
            match = (strcmp(value, needles[i]) == 0);
            when_false(match, end_of_loop);
        }

        /* We have a match */
        var = amxd_object_get_param_value(inst, "SFPType");
        when_null_trace(var, exit, ERROR, "Name='%s' PN='%s: failed to get SFPType",
                        vendor_name, vendor_pn);
        value = GET_CHAR(var, NULL);
        when_str_empty_trace(value, exit, ERROR,
                             "Name='%s' PN='%s: failed to get C string for SFPType",
                             vendor_name, vendor_pn);
        SAH_TRACEZ_INFO(ME, "Name='%s' PN='%s': SFPType='%s'", vendor_name,
                        vendor_pn, value);
        result = sfp_type_str_to_enum(value);
        break;

end_of_loop:
        continue;
    }
exit:
    return result;
}

