/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_device_info_memmonitor.h"

resmon_mem_monitor_t mmon;
amxp_timer_t* memory_timer = NULL;

/**
 * @brief Sets a timestamp string in ISO 8601 format.
 * @param target Pointer to the target string buffer.
 */
static void set_timestamp(char* target);

/**
 * @brief Emits a memory critical event.
 */
static void raise_mem_critical_event(void);


/**=======================================================================================================
 * @brief _read_memory_utilization
 * @details This function updates the MemUtilization parameter using the global variable mmon.total_mem_usage
 * @param[in] object pointer which holds the object name (UNUSED)
 * @param[in] param pointer which holds the parameter name (UNUSED)
 * @param[in] reason holds the type of action (UNUSED)
 * @param[in] args Argument which holds the function arguments (UNUSED)
 * @param[out] retval holds the return value of this function
 * @param[out] priv Pointer for private data(UNUSED)
 *
 * @retval amxd_status_ok when success
 *         appropriate error code when failure
 *
 *==========================================================================================================*/
amxd_status_t _read_memory_utilization(UNUSED amxd_object_t* object, UNUSED amxd_param_t* param,
                                       UNUSED amxd_action_t reason, UNUSED const amxc_var_t* const args,
                                       amxc_var_t* const retval, UNUSED void* priv) {

    amxd_status_t status = amxd_status_unknown_error;

    // Validate input parameter
    when_null_trace(retval, exit, ERROR, "retval is NULL - cannot store memory utilization result");

    // Log the current memory usage before setting it
    SAH_TRACEZ_INFO(ME, "Setting memory utilization value: %d", mmon.total_mem_usage);

    // Set the retrieved memory usage value in retval
    status = amxc_var_set(uint32_t, retval, mmon.total_mem_usage);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set memory utilization value in retval (status: %d)", status);

    SAH_TRACEZ_INFO(ME, "Memory utilization successfully set in retval");
    return amxd_status_ok;

exit:
    SAH_TRACEZ_ERROR(ME, "Exiting _read_memory_utilization with status: %d", status);
    return status;
}


/**=======================================================================================================
 * @brief resmon_mem_init
 * @details Initializes the memory monitor by retrieving configuration parameters from the data model.
 *          Sets up thresholds, polling interval, and state, and starts the memory monitoring timer if enabled.
 *==========================================================================================================*/
void _resmon_mem_init(void) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxc_var_t value;

    when_null(dm, exit);

    memset(&mmon, 0, sizeof(resmon_mem_monitor_t));

    mmon.object = amxd_dm_findf(dm, RM_MEM_PATH);
    when_null(mmon.object, exit);

    SAH_TRACEZ_INFO(ME, "Initializing memory monitor from data model");

    // Read and set values from the data model
    amxc_var_init(&value);

    if(amxd_object_get_param(mmon.object, RM_MEMORY_ENABLE, &value) == amxd_status_ok) {
        mmon.mem_enabled = amxc_var_dyncast(bool, &value);
        SAH_TRACEZ_INFO(ME, "Memory monitoring enable retrieved: %s", mmon.mem_enabled ? "true" : "false");
    } else {
        mmon.mem_enabled = false;
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve memory monitoring enable flag, defaulting to disabled");
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_CRITICAL_FALL_THRESHOLD, &value) == amxd_status_ok) {
        mmon.fall_threshold = amxc_var_dyncast(uint32_t, &value);
        SAH_TRACEZ_INFO(ME, "Fall threshold retrieved: %u", mmon.fall_threshold);
    } else {
        mmon.fall_threshold = RM_MEM_FALL_THRESHOLD_DEFAULT;
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve fall threshold, using default: %u", mmon.fall_threshold);
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_CRITICAL_RISE_THRESHOLD, &value) == amxd_status_ok) {
        mmon.rise_threshold = amxc_var_dyncast(uint32_t, &value);
        SAH_TRACEZ_INFO(ME, "Rise threshold retrieved: %u", mmon.rise_threshold);
    } else {
        mmon.rise_threshold = RM_MEM_RISE_THRESHOLD_DEFAULT;
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve rise threshold, using default: %u", mmon.rise_threshold);
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_POLLING_INTERVAL, &value) == amxd_status_ok) {
        mmon.polling_interval = amxc_var_dyncast(uint32_t, &value);
        SAH_TRACEZ_INFO(ME, "Polling interval retrieved: %u seconds", mmon.polling_interval);
    } else {
        mmon.polling_interval = RM_MEM_POLLING_INTERVAL;
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve polling interval, using default: %u seconds", mmon.polling_interval);
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_MEM_UTILIZATION, &value) == amxd_status_ok) {
        mmon.total_mem_usage = amxc_var_dyncast(uint32_t, &value);
        SAH_TRACEZ_INFO(ME, "Current memory utilization: %u", mmon.total_mem_usage);
    } else {
        mmon.total_mem_usage = 1;
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve memory utilization, defaulting to 1");
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_CRITICAL_FALL_TIMESTAMP, &value) == amxd_status_ok) {
        const char* fall_ts = amxc_var_constcast(cstring_t, &value);
        if(fall_ts != NULL) {
            strncpy(mmon.fall_timestamp, fall_ts, sizeof(mmon.fall_timestamp) - 1);
            mmon.fall_timestamp[sizeof(mmon.fall_timestamp) - 1] = '\0';
            SAH_TRACEZ_INFO(ME, "Loaded Fall timestamp from object:: %s", mmon.fall_timestamp);
        } else {
            // Set default timestamp
            strncpy(mmon.fall_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.fall_timestamp) - 1);
            mmon.fall_timestamp[sizeof(mmon.fall_timestamp) - 1] = '\0';
            SAH_TRACEZ_WARNING(ME, "Fall timestamp is NULL, setting default value");
        }
    } else {
        // Set default timestamp
        strncpy(mmon.fall_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.fall_timestamp) - 1);
        mmon.fall_timestamp[sizeof(mmon.fall_timestamp) - 1] = '\0';
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve fall timestamp, setting default value");
    }

    if(amxd_object_get_param(mmon.object, RM_MEMORY_CRITICAL_RISE_TIMESTAMP, &value) == amxd_status_ok) {
        const char* rise_ts = amxc_var_constcast(cstring_t, &value);
        if(rise_ts != NULL) {
            strncpy(mmon.rise_timestamp, rise_ts, sizeof(mmon.rise_timestamp) - 1);
            mmon.rise_timestamp[sizeof(mmon.rise_timestamp) - 1] = '\0';
            SAH_TRACEZ_INFO(ME, "Loaded rise timestamp from object: %s", mmon.rise_timestamp);
        } else {
            // Set default timestamp
            strncpy(mmon.rise_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.rise_timestamp) - 1);
            mmon.rise_timestamp[sizeof(mmon.rise_timestamp) - 1] = '\0';
            SAH_TRACEZ_WARNING(ME, "Rise timestamp is NULL, setting default value");
        }
    } else {
        // Set default timestamp
        strncpy(mmon.rise_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.rise_timestamp) - 1);
        mmon.rise_timestamp[sizeof(mmon.rise_timestamp) - 1] = '\0';
        SAH_TRACEZ_WARNING(ME, "Failed to retrieve rise timestamp from object, setting default value");
    }

    SAH_TRACEZ_INFO(ME, "Starting memory monitor...");

    // Start memory monitor
    resmon_start_mem_monitor();

    amxc_var_clean(&value);

exit:
    return;
}

/**=======================================================================================================
 * @brief resmon_mem_clear
 * @details Clears memory monitoring state including usage, timestamps, and resets the state to NORMAL.
 * @return uint32_t Return value indicating success (0) or failure (-1).
 *==========================================================================================================*/
int32_t resmon_mem_clear(void) {
    int32_t ret = RM_MEM_FAILURE;
    amxd_status_t status = amxd_status_unknown_error;

    mmon.mem_state = RM_MEMORY_STATE_NORMAL;
    mmon.total_mem_usage = 0;

    strncpy(mmon.fall_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.fall_timestamp) - 1);
    mmon.fall_timestamp[sizeof(mmon.fall_timestamp) - 1] = '\0';

    strncpy(mmon.rise_timestamp, "0001-01-01T00:00:00Z", sizeof(mmon.rise_timestamp) - 1);
    mmon.rise_timestamp[sizeof(mmon.rise_timestamp) - 1] = '\0';

    status = set_mem_param(RM_MEMORY_MEM_UTILIZATION);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Failed to set RM_MEMORY_MEM_UTILIZATION in resmon_mem_clear, status = %d", status);

    status = set_mem_param(RM_MEMORY_CRITICAL_FALL_TIMESTAMP);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Failed to set RM_MEMORY_CRITICAL_FALL_TIMESTAMP in resmon_mem_clear, status = %d", status);

    status = set_mem_param(RM_MEMORY_CRITICAL_RISE_TIMESTAMP);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Failed to set RM_MEMORY_CRITICAL_RISE_TIMESTAMP in resmon_mem_clear, status = %d", status);

exit:
    if(status == amxd_status_ok) {
        ret = RM_MEM_SUCCESS;
    }

    if(ret != RM_MEM_SUCCESS) {
        SAH_TRACEZ_ERROR(ME, "Memory monitor clear failed with ret = %d, status = %d", ret, status);
    } else {
        SAH_TRACEZ_INFO(ME, "Memory monitor clear completed successfully");
    }

    return ret;
}

/**=======================================================================================================
 * @brief _rm_mem_enable_change
 * @details Callback triggered when the memory monitoring enable parameter changes.
 *          Starts or stops the memory monitor based on the new enable status.
 * @param sig_name Signal name (unused).
 * @param data Signal data (unused).
 * @param priv Private data (unused).
 *==========================================================================================================*/

void _rm_mem_enable_change(UNUSED const char* const sig_name,
                           UNUSED const amxc_var_t* const data,
                           UNUSED void* const priv) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object;
    bool current_status = mmon.mem_enabled;
    int32_t ret = RM_MEM_FAILURE;
    when_null(dm, exit);

    /* Retrieving object from resource monitoring data model */
    object = amxd_dm_findf(dm, RM_MEM_PATH);
    when_null(object, exit);


    /* Read the Memory object parameters from ODL */
    mmon.mem_enabled = amxd_object_get_value(bool, object, RM_MEMORY_ENABLE, NULL);


    if((current_status == false) && (mmon.mem_enabled == true)) {
        SAH_TRACEZ_INFO(ME, "Memory Monitoring Enable changed False to True");
        ret = resmon_mem_clear();
        when_true_trace(ret != RM_MEM_SUCCESS, exit, ERROR, "Failed to clear memory utilization. Cannot start Memory monitoring");
        resmon_start_mem_monitor();

    } else if((current_status == true) && (mmon.mem_enabled == false)) {
        SAH_TRACEZ_INFO(ME, "Memory Monitoring Enable changed True to False");
        resmon_stop_mem_monitor();
        ret = resmon_mem_clear();
        when_true_trace(ret != RM_MEM_SUCCESS, exit, ERROR, "Failed to clear memory utilization.");

    } else {
        SAH_TRACEZ_INFO(ME, "Memory Monitoring Enable - No Change");
    }

exit:
    return;
}

/**=======================================================================================================
 * @brief resmon_start_mem_monitor
 * @details Starts the memory monitoring timer if memory monitoring is enabled.
 *==========================================================================================================*/

void resmon_start_mem_monitor(void) {
    if(!mmon.mem_enabled) {
        SAH_TRACEZ_ERROR(ME, " Memory monitor not enabled. Cannot start Memory monitoring");
        return;
    }

    /* As per TR-181 specification, if the polling interval is set to 0,
       the device selects its own polling interval. In this implementation,
       we use a default polling interval of 5 seconds when the value is 0. */

    if(mmon.polling_interval == 0) {
        mmon.polling_interval = RM_MEM_POLLING_INTERVAL;
    }

    if(amxp_timer_new(&memory_timer, memory_usage_handler, NULL) == 0) {
        amxp_timer_set_interval(memory_timer, (mmon.polling_interval * 1000));
        SAH_TRACEZ_INFO(ME, " Starting Memory Monitoring Timer");
        amxp_timer_start(memory_timer, (mmon.polling_interval * 1000));
    }

    return;
}


/**=======================================================================================================
 * @brief resmon_stop_mem_monitor
 * @details Stops and deletes the memory monitoring timer.
 *==========================================================================================================*/

void resmon_stop_mem_monitor(void) {
    if(memory_timer) {
        SAH_TRACEZ_INFO(ME, "Stopping Memory Monitoring Timer");
        amxp_timer_stop(memory_timer);
        amxp_timer_delete(&memory_timer);
    } else {
        SAH_TRACEZ_ERROR(ME, "Memory Monitoring Timer does not exist");
    }

}

/**=======================================================================================================
 * @brief memory_usage_handler
 * @details Timer handler that reads current memory usage and updates the data model.
 *          Also triggers state transitions if thresholds are crossed.
 * @param timer Pointer to the timer object (unused).
 * @param priv Private data (unused).
 *==========================================================================================================*/


void memory_usage_handler(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    char* vendorlog_ref_path = NULL;

    // Retrieve VendorLogFileRef from memory monitor object
    vendorlog_ref_path = amxd_object_get_value(cstring_t, mmon.object, RM_MEMORY_VENDOR_LOG_FILE_REF, NULL);

    // VendorLogFileRef can't be set during MemoryMonitor init as DeviceInfo isn't ready.
    // Update it here once MemoryMonitor is enabled
    if(STR_EMPTY(vendorlog_ref_path)) {
        if(vendorlog_ref_path != NULL) {
            SAH_TRACEZ_INFO(ME, "VendorLogFileRef is not set. Initiating update via mmon_update_vendorlogfileref_syslog().");
            mmon_update_vendorlogfileref_syslog();
        }
    }

    mmon.total_mem_usage = get_current_memory_usage();

    status = set_mem_param(RM_MEMORY_MEM_UTILIZATION);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Failed to set RM_MEMORY_MEM_UTILIZATION (status = %d)", status);

    handle_memory_monitor_state();

exit:
    free(vendorlog_ref_path);
    return;
}

/**=======================================================================================================
 * @brief get_current_memory_usage
 * @details Reads memory statistics from /proc/meminfo and calculates memory usage percentage.
 *          Updates the global memory monitor structure with the new usage value.
 * @return int32_t Return value indicating success (RM_MEM_SUCCESS) or failure (RM_MEM_FAILURE).
 *==========================================================================================================*/
uint32_t get_current_memory_usage(void) {
    FILE* fp = NULL;
    char buf[RM_MEM_LINE_BUF_SIZE];
    char item[RM_MEM_ITEM_SIZE];
    char unit[RM_MEM_UNIT_SIZE];
    uint64_t value = 0;
    int32_t result = 0;
    uint64_t total = 0, free = 0, used = 0;
    uint32_t usage = 0;
    fp = fopen(RM_MEM_USAGE_FILENAME, "r");
    when_null_trace(fp, error, ERROR, "Failed to open %s, error: %s", RM_MEM_USAGE_FILENAME, strerror(errno));

    while(fgets(buf, sizeof(buf), fp) != NULL) {
        memset(item, '\0', sizeof(item));
        memset(unit, '\0', sizeof(unit));
        result = sscanf(buf, "%63s %" PRIu64 " %15s", item, &value, unit);
        if(result == 3) {
            if(strncmp(item, "MemTotal:", strlen("MemTotal:")) == 0) {
                total = value;
            } else if(strncmp(item, "MemAvailable:", strlen("MemAvailable:")) == 0) {
                free = value;
            } else if(strncmp(item, "Cached:", strlen("Cached:")) == 0) {
                break;  // Avoid reading swapCached
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "sscanf failed to parse expected format in /proc/meminfo");
        }
    }

    fclose(fp);

    used = total - free;
    when_true_trace(total <= 0, error, ERROR, "Invalid total memory value: %lu", total);

    usage = (uint32_t) (((used * RM_MEM_PERCENT_VALUE) / total));
    SAH_TRACEZ_INFO(ME, " Computed MemUtilization = %d ", usage);
    return usage;
error:
    return usage;
}

/**=======================================================================================================
 * @brief handle_memory_monitor_state
 * @details Evaluates the current memory usage and triggers state transitions between NORMAL and CRITICAL.
 *==========================================================================================================*/
void handle_memory_monitor_state(void) {
    uint32_t usage = mmon.total_mem_usage;
    /*When Current state is Normal*/
    if(mmon.mem_state == RM_MEMORY_STATE_NORMAL) {
        /*Call Normal state handler*/
        memory_normal_state_handler(usage);
        /*When Current state is Critical*/
    } else if(mmon.mem_state == RM_MEMORY_STATE_CRITICAL) {
        /*Call Critical state handler*/
        memory_critical_state_handler(usage);
    } else {
        SAH_TRACEZ_INFO(ME, "Memory Monitor-Invalid state");
    }
}

/**=======================================================================================================
 * @brief set_timestamp
 * @details Generates a UTC timestamp in ISO 8601 format and stores it in the provided buffer.
 * @param target Pointer to the buffer where the timestamp will be stored.
 *==========================================================================================================*/

static void set_timestamp(char* target) {
    time_t current_time;
    struct tm* time_info;
    time(&current_time);
    time_info = gmtime(&current_time);
    when_null(time_info, exit);
    strftime(target, 25, "%Y-%m-%dT%H:%M:%SZ", time_info);
exit:
    return;
}
/**=======================================================================================================
 * @brief raise_mem_critical_event
 * @details Emits a memory critical state event.
 *==========================================================================================================*/
static void raise_mem_critical_event(void) {
    amxc_var_t values;
    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    // Emit a signal 'MEMORY_CRITICAL_STATE_EVENT'
    SAH_TRACEZ_INFO(ME, "Emitting signal for memory critical event");
    amxc_var_add_key(uint32_t, &values, RM_MEMORY_MEM_UTILIZATION, mmon.total_mem_usage);
    amxd_object_emit_signal(mmon.object, RM_MEMORY_CRITICAL_STATE_EVENT, &values);

    // Perform critical state actions
    if(memorycriticalstate_actions() != RM_MEM_SUCCESS) {
        SAH_TRACEZ_ERROR(ME, "Failed to perform memory critical state actions");
    }
    amxc_var_clean(&values);
}



/**=======================================================================================================
 * @brief memory_normal_state_handler
 * @details Handles transition from NORMAL to CRITICAL state if usage exceeds the rise threshold.
 * @param usage Current memory usage percentage.
 *==========================================================================================================*/

void memory_normal_state_handler(uint32_t usage) {
    if(usage >= mmon.rise_threshold) {

        mmon.mem_state = RM_MEMORY_STATE_CRITICAL;
        SAH_TRACEZ_ERROR(ME, "Memory state changed to CRITICAL");

        set_timestamp(mmon.rise_timestamp);

        set_mem_param(RM_MEMORY_CRITICAL_RISE_TIMESTAMP);

        raise_mem_critical_event();
    }
}

/**=======================================================================================================
 * @brief memory_critical_state_handler
 * @details Handles transition from CRITICAL to NORMAL state if usage falls below the fall threshold.
 * @param usage Current memory usage percentage.
 *==========================================================================================================*/

void memory_critical_state_handler(uint32_t usage) {
    bool enable_critical_log = false;

    if(usage < mmon.fall_threshold) {

        mmon.mem_state = RM_MEMORY_STATE_NORMAL;
        SAH_TRACEZ_INFO(ME, "Memory state changed to NORMAL");

        // Get EnableCriticalLog from data model
        enable_critical_log = amxd_object_get_value(bool, mmon.object, RM_MEMORY_ENABLE_CRITICAL_LOG, false);

        if(enable_critical_log) {
            // write to Vendor log file
            SAH_TRACEZ_ERROR(RM_MMON, "Memory critical state cleared. Utilization: %u%%", mmon.total_mem_usage);
        }

        set_timestamp(mmon.fall_timestamp);

        set_mem_param(RM_MEMORY_CRITICAL_FALL_TIMESTAMP);
    }
}
/**=======================================================================================================
 * @brief Performs actions when memory enters a critical state.
 *
 * @return RM_MEM_SUCCESS if the action is performed successfully.
 * @return RM_MEM_FAILURE if the action could not be performed.
 *==========================================================================================================*/

uint32_t memorycriticalstate_actions(void) {
    uint32_t retval = RM_MEM_FAILURE;
    bool enable_critical_log = false;

    // Log to system log
    SAH_TRACEZ_ERROR(ME, "Memory critical state reached. Utilization: %u%%", mmon.total_mem_usage);

    // Get EnableCriticalLog from data model
    enable_critical_log = amxd_object_get_value(bool, mmon.object, RM_MEMORY_ENABLE_CRITICAL_LOG, false);

    if(enable_critical_log) {
        // write to Vendor log file
        SAH_TRACEZ_ERROR(RM_MMON, "Memory critical state reached. Utilization: %u%%", mmon.total_mem_usage);
    }

    retval = RM_MEM_SUCCESS;
    return retval;
}

/**=======================================================================================================
 * @brief set_mem_param
 * @details Sets a specific memory monitoring parameter in the data model using a transaction.
 * @param param_name Name of the parameter to be updated.
 * @return amxd_status_t Status of the operation.
 *==========================================================================================================*/
amxd_status_t set_mem_param(const char* param_name) {
    amxd_status_t status = amxd_status_unknown_error;
    amxd_trans_t transaction;

    amxd_trans_init(&transaction);
    when_null(mmon.object, exit);

    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, mmon.object);

    if(strcmp(param_name, RM_MEMORY_MEM_UTILIZATION) == 0) {
        amxd_trans_set_value(uint32_t, &transaction, RM_MEMORY_MEM_UTILIZATION, mmon.total_mem_usage);
    } else if(strcmp(param_name, RM_MEMORY_CRITICAL_FALL_TIMESTAMP) == 0) {
        amxd_trans_set_value(cstring_t, &transaction, RM_MEMORY_CRITICAL_FALL_TIMESTAMP, mmon.fall_timestamp);
    } else if(strcmp(param_name, RM_MEMORY_CRITICAL_RISE_TIMESTAMP) == 0) {
        amxd_trans_set_value(cstring_t, &transaction, RM_MEMORY_CRITICAL_RISE_TIMESTAMP, mmon.rise_timestamp);
    } else {
        SAH_TRACEZ_INFO(ME, "Unknown parameter: %s", param_name);
        goto exit;
    }

    status = amxd_trans_apply(&transaction, deviceinfo_get_dm());
    when_true_trace(status != AMXB_STATUS_OK, exit, ERROR, "Failed to apply parameter: %s", param_name);

exit:
    amxd_trans_clean(&transaction);
    return status;
}

/**=======================================================================================================
 * @brief _rm_mem_polling_threshold_change
 * @details Callback triggered when polling interval or threshold parameters change.
 *          Updates the memory monitor configuration and restarts the monitoring timer.
 * @param sig_name Name of the signal received.
 * @param data Signal data (unused).
 * @param priv Private data (unused).
 *==========================================================================================================*/
void _rm_mem_polling_threshold_change(UNUSED const char* const sig_name,
                                      UNUSED const amxc_var_t* const data,
                                      UNUSED void* const priv) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object;
    int32_t ret = RM_MEM_FAILURE;

    when_null(dm, exit);
    /* Retrieving object from resource monitoring data model */
    object = amxd_dm_findf(dm, RM_MEM_PATH);
    when_null(object, exit);

    /* Read the Memory object parameters from ODL */
    mmon.polling_interval = amxd_object_get_value(uint32_t, object, RM_MEMORY_POLLING_INTERVAL, NULL);
    mmon.rise_threshold = amxd_object_get_value(uint32_t, object, RM_MEMORY_CRITICAL_RISE_THRESHOLD, NULL);
    mmon.fall_threshold = amxd_object_get_value(uint32_t, object, RM_MEMORY_CRITICAL_FALL_THRESHOLD, NULL);

    resmon_stop_mem_monitor();

    ret = resmon_mem_clear();

    when_true_trace(ret != RM_MEM_SUCCESS, exit, ERROR, "Failed to clear memory utilization. ");

    resmon_start_mem_monitor();
exit:
    return;
}

/**=======================================================================================================
 * @brief _validate_memmonitor
 * @details Validates memory threshold parameters to ensure logical consistency between rise and fall values.
 * @param object Pointer to the memory monitoring object.
 * @param param Pointer to the parameter being validated.
 * @param reason Reason for validation (unused).
 * @param args Input value to validate.
 * @param retval Return value (unused).
 * @param priv Private data (unused).
 * @return amxd_status_t Status of the validation.
 *==========================================================================================================*/


amxd_status_t _validate_memmonitor(amxd_object_t* object, amxd_param_t* param,
                                   UNUSED amxd_action_t reason, const amxc_var_t* const args,
                                   UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status;
    char input_param_name[RM_MEM_PARAM_NAME_BUF_SIZE] = {0};
    int32_t current_value = 0;
    int32_t input_value = 0;
    int32_t reference_value = 0;

    status = amxd_status_object_not_found;
    when_null_trace(object, exit, ERROR, "Object is NULL");

    status = amxd_status_parameter_not_found;
    when_null_trace(param, exit, ERROR, "Parameter is NULL");

    status = amxd_status_invalid_function_argument;
    when_null(args, exit);

    status = amxd_status_ok;

    // Copy parameter name
    strncpy(input_param_name, amxd_param_get_name(param), sizeof(input_param_name) - 1);
    input_param_name[sizeof(input_param_name) - 1] = '\0';  // Ensure null-termination

    // Get current and input values
    current_value = amxc_var_dyncast(uint32_t, &param->value);
    input_value = amxc_var_dyncast(uint32_t, args);

    // Reject zero input
    if(input_value == 0) {
        SAH_TRACEZ_ERROR(ME, "Input value for %s cannot be zero", input_param_name);
        return amxd_status_invalid_value;
    }

    // Skip validation if values are the same
    if(input_value == current_value) {
        SAH_TRACEZ_INFO(ME, "Input value %d is same as current value %d for %s", input_value, current_value, input_param_name);
        return amxd_status_ok;
    }

    // Threshold validation
    if(strcmp(input_param_name, RM_MEMORY_CRITICAL_FALL_THRESHOLD) == 0) {

        reference_value = amxd_object_get_value(uint32_t, object, RM_MEMORY_CRITICAL_RISE_THRESHOLD, NULL);

        if(reference_value == 0) {
            SAH_TRACEZ_INFO(ME, "Reference value for %s is not set yet", input_param_name);
            return amxd_status_ok;
        }

        if(input_value >= reference_value) {
            SAH_TRACEZ_ERROR(ME, "Fall threshold (%d) must be less than rise threshold (%d)", input_value, reference_value);
            status = amxd_status_invalid_value;
        }

    } else if(strcmp(input_param_name, RM_MEMORY_CRITICAL_RISE_THRESHOLD) == 0) {

        reference_value = amxd_object_get_value(uint32_t, object, RM_MEMORY_CRITICAL_FALL_THRESHOLD, NULL);

        if(reference_value == 0) {
            SAH_TRACEZ_INFO(ME, "Reference value for %s is not set yet", input_param_name);
            return amxd_status_ok;
        }
        if(input_value <= reference_value) {
            SAH_TRACEZ_ERROR(ME, "Rise threshold (%d) must be greater than fall threshold (%d)", input_value, reference_value);
            status = amxd_status_invalid_value;
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "Unsupported parameter for validation: %s", input_param_name);
        status = amxd_status_parameter_not_found;
    }

exit:
    return status;
}

/**
 * @brief Updates VendorLogFileRef for the memory monitor.
 *
 * Synchronizes the log file path and critical log enable status with the syslog configuration.
 */
void mmon_update_vendorlogfileref_syslog(void) {
    char* memory_file_path = NULL;
    bool enable_critical_log = false;
    amxb_bus_ctx_t* syslog_ctx = NULL;

    amxc_var_t result, parameters, response;
    amxc_var_t* action_entry = NULL;
    char logfile_path[256] = {0};
    const char* vendorlog_ref_path = NULL;

    amxc_var_init(&result);
    amxc_var_init(&parameters);
    amxc_var_init(&response);

    SAH_TRACEZ_INFO(ME, "Syncing memory monitor log settings with Syslog");

    // Validate memory monitor object
    when_null_trace(mmon.object, exit, ERROR, "Memory monitor object is NULL");

    // Get memory monitor file path
    memory_file_path = amxd_object_get_value(cstring_t, mmon.object, RM_MEMORY_FILE_PATH, NULL);
    when_null_trace(memory_file_path, exit, ERROR, "Memory file path is NULL");

    // Get critical log enable flag
    enable_critical_log = amxd_object_get_value(bool, mmon.object, RM_MEMORY_ENABLE_CRITICAL_LOG, NULL);

    // Get Syslog bus context
    syslog_ctx = amxb_be_who_has(MMON_SYSLOG_PATH);
    when_null_trace(syslog_ctx, exit, ERROR, "Syslog bus context not found");

    // Search for Syslog.Action.{i} with Alias == "resmon-mmon"
    char query[RM_MEM_PARAM_NAME_BUF_SIZE];
    snprintf(query, sizeof(query), "Syslog.Action.[Alias == '%s'].", MMON_ALIAS_LOG);

    int rc = amxb_get(syslog_ctx, query, 1, &result, MMON_TIMEOUT);
    when_true_trace(rc != 0, exit, ERROR, "Failed to locate Syslog.Action instance with Alias == 'resmon-mmon'");

    // Get first matching instance
    action_entry = amxc_var_get_first(&result);
    when_null_trace(action_entry, exit, ERROR, "No matching Syslog.Action instance found");

    // Get full object path

    amxc_var_for_each(entry, action_entry) {
        const char* key = amxc_var_key(entry);
        if((key != NULL) && (strstr(key, "LogFile") != NULL)) {
            snprintf(logfile_path, sizeof(logfile_path), "%s", key);
            break;
        }
    }

    SAH_TRACEZ_INFO(ME, "computed logfile_path = %s", logfile_path);
    // Prepare parameters to update
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, RM_MEMORY_FILE_PATH, memory_file_path);
    amxc_var_add_key(bool, &parameters, RM_MEMORY_ENABLE, enable_critical_log);

    // Update LogFile settings
    rc = amxb_set(syslog_ctx, logfile_path, &parameters, &response, MMON_TIMEOUT);
    when_true_trace(rc != 0, exit, ERROR, "Failed to update Syslog.LogFile settings at path: %s, error: %d", logfile_path, rc);

    // Get VendorLogFileRef from updated data
    vendorlog_ref_path = GET_CHAR(GET_ARG(action_entry, logfile_path), RM_MEMORY_VENDOR_LOG_FILE_REF);
    when_null_trace(vendorlog_ref_path, exit, ERROR, "VendorLogFileRef not found");

    SAH_TRACEZ_INFO(ME, "Setting VendorLogFileRef = %s", vendorlog_ref_path);
    rc = amxd_object_set_value(cstring_t, mmon.object, RM_MEMORY_VENDOR_LOG_FILE_REF, vendorlog_ref_path);
    when_true_trace(rc != 0, exit, ERROR, "Failed to set VendorLogFileRef");

exit:
    free(memory_file_path);
    amxc_var_clean(&result);
    amxc_var_clean(&parameters);
    amxc_var_clean(&response);
}

/**
 * @brief Handles configuration change signals for log file or Enable critical log changes.
 *
 * This function is triggered when a configuration change signal is received.
 *
 * @param sig_name Name of the signal (unused).
 * @param data     Signal data containing object path and metadata(unused).
 * @param priv     Private data (unused).
 */
void _mmon_handle_filename_enablelog_change(UNUSED const char* const sig_name,
                                            UNUSED const amxc_var_t* const data,
                                            UNUSED void* const priv) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object;

    SAH_TRACEZ_INFO(ME, "FileName/Enable Critical Log change triggered");
    when_null_trace(dm, exit, ERROR, "Memory Monitor DM is NULL");

    /* Retrieving object from resource monitoring data model */
    object = amxd_dm_findf(dm, RM_MEM_PATH);

    when_null_trace(object, exit, ERROR, "Memory Monitor Object is NULL");

    //Update FileName and Enable Critical Log to Syslog. Update VendorLogFileRef from Syslog to DeviceInfo
    mmon_update_vendorlogfileref_syslog();

exit:
    return;
}
