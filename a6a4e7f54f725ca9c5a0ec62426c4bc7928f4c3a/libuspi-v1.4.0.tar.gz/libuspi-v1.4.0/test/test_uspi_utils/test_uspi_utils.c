/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>
#include <amxb/amxb_register.h>
#include <amxo/amxo.h>
#include <usp/uspl.h>

#include "uspi.h"
#include "uspi/uspi_connection.h"
#include "uspi/uspi_utils.h"

#include "test_uspi_utils.h"
#include "dummy_be.h"
#include "common.h"

static amxd_dm_t dm;
static amxb_bus_ctx_t* bus_ctx = NULL;
static amxo_parser_t parser;
static const char* phonebook_definition = "../common/phonebook_definition.odl";
static const char* localagent_definition = "../common/tr181-localagent_definition.odl";
static const char* localagent_defaults = "../common/tr181-localagent_defaults.odl";

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);
    assert_int_equal(test_register_dummy_be(), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    amxo_connection_add(&parser, 101, connection_read, "dummy:/tmp/dummy.sock", AMXO_BUS, bus_ctx);

    amxb_register(bus_ctx, &dm);
    capture_sigalrm();

    assert_int_equal(amxo_parser_parse_file(&parser, phonebook_definition, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, localagent_definition, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, localagent_defaults, root_obj), 0);

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxb_free(&bus_ctx);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    test_unregister_dummy_be();
    return 0;
}

void test_uspi_utils_add_controller(UNUSED void** state) {
    const char* from_id = "proto::controller";
    const char* param_name = "Recipient";
    amxc_var_t params;

    assert_int_not_equal(uspi_utils_add_controller(NULL, NULL, NULL, NULL), 0);
    assert_int_not_equal(uspi_utils_add_controller(bus_ctx, NULL, NULL, NULL), 0);
    assert_int_not_equal(uspi_utils_add_controller(bus_ctx, "", NULL, NULL), 0);
    assert_int_not_equal(uspi_utils_add_controller(bus_ctx, from_id, NULL, NULL), 0);
    assert_int_not_equal(uspi_utils_add_controller(bus_ctx, from_id, &params, NULL), 0);
    assert_int_not_equal(uspi_utils_add_controller(bus_ctx, from_id, &params, ""), 0);

    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

    assert_int_equal(uspi_utils_add_controller(bus_ctx, from_id, &params, param_name), 0);
    amxc_var_dump(&params, STDOUT_FILENO);
    assert_true(test_verify_data(&params, param_name, "Device.LocalAgent.Controller.1"));

    amxc_var_clean(&params);
}

void test_uspi_utils_matches(UNUSED void** state) {
    const char* valid_regex = "^(Device\\.)?LocalAgent\\.Subscription\\.$";

    assert_false(uspi_utils_matches(NULL, NULL));
    assert_false(uspi_utils_matches("", NULL));
    assert_false(uspi_utils_matches(valid_regex, NULL));
    assert_false(uspi_utils_matches(valid_regex, ""));
    assert_false(uspi_utils_matches(valid_regex, "Device.LocalAgent.Subscription"));
    assert_false(uspi_utils_matches(valid_regex, "Agent.Subscription"));

    assert_true(uspi_utils_matches(valid_regex, "LocalAgent.Subscription."));
    assert_true(uspi_utils_matches(valid_regex, "Device.LocalAgent.Subscription."));
}

void test_uspi_utils_add_dot(UNUSED void** state) {
    amxc_string_t* dotted_path = NULL;

    assert_null(uspi_utils_add_dot(NULL));
    assert_null(uspi_utils_add_dot(""));

    dotted_path = uspi_utils_add_dot("LocalAgent");
    assert_non_null(dotted_path);
    assert_string_equal(amxc_string_get(dotted_path, 0), "LocalAgent.");
    amxc_string_delete(&dotted_path);

    dotted_path = uspi_utils_add_dot("LocalAgent.");
    assert_non_null(dotted_path);
    assert_string_equal(amxc_string_get(dotted_path, 0), "LocalAgent.");
    amxc_string_delete(&dotted_path);
}

void test_uspi_utils_get_con_type(UNUSED void** state) {
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_SUPPORTED_DM), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_INSTANCES), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__SET), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__ADD), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__DELETE), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__OPERATE), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__NOTIFY_RESP), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_SUPPORTED_PROTO), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__REGISTER_RESP), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__DEREGISTER_RESP), USPI_CON_CONTROLLER);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_SUPPORTED_DM_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_INSTANCES_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__SET_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__ADD_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__DELETE_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__OPERATE_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__NOTIFY), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__GET_SUPPORTED_PROTO_RESP), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__REGISTER), USPI_CON_AGENT);
    assert_int_equal(uspi_utils_get_con_type(USP__HEADER__MSG_TYPE__DEREGISTER), USPI_CON_AGENT);
}

void test_uspi_utils_check_sender(UNUSED void** state) {
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_SUPPORTED_DM, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_INSTANCES, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__SET, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__ADD, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__DELETE, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__OPERATE, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__NOTIFY_RESP, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_SUPPORTED_PROTO, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__REGISTER_RESP, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__DEREGISTER_RESP, USPI_CON_CONTROLLER));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_SUPPORTED_DM_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_INSTANCES_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__SET_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__ADD_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__DELETE_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__OPERATE_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__NOTIFY, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__GET_SUPPORTED_PROTO_RESP, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__REGISTER, USPI_CON_AGENT));
    assert_true(uspi_utils_check_sender(USP__HEADER__MSG_TYPE__DEREGISTER, USPI_CON_AGENT));
}
