/*
 * ----------------------------------------------------------------------------
 *                                 Apache License
 *                           Version 2.0, January 2004
 *                        http://www.apache.org/licenses/
 *
 *   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
 *
 *   1. Definitions.
 *
 *      "License" shall mean the terms and conditions for use, reproduction,
 *      and distribution as defined by Sections 1 through 9 of this document.
 *
 *      "Licensor" shall mean the copyright owner or entity authorized by
 *      the copyright owner that is granting the License.
 *
 *      "Legal Entity" shall mean the union of the acting entity and all
 *      other entities that control, are controlled by, or are under common
 *      control with that entity. For the purposes of this definition,
 *      "control" means (i) the power, direct or indirect, to cause the
 *      direction or management of such entity, whether by contract or
 *      otherwise, or (ii) ownership of fifty percent (50%) or more of the
 *      outstanding shares, or (iii) beneficial ownership of such entity.
 *
 *      "You" (or "Your") shall mean an individual or Legal Entity
 *      exercising permissions granted by this License.
 *
 *      "Source" form shall mean the preferred form for making modifications,
 *      including but not limited to software source code, documentation
 *      source, and configuration files.
 *
 *      "Object" form shall mean any form resulting from mechanical
 *      transformation or translation of a Source form, including but
 *      not limited to compiled object code, generated documentation,
 *      and conversions to other media types.
 *
 *      "Work" shall mean the work of authorship, whether in Source or
 *      Object form, made available under the License, as indicated by a
 *      copyright notice that is included in or attached to the work
 *      (an example is provided in the Appendix below).
 *
 *      "Derivative Works" shall mean any work, whether in Source or Object
 *      form, that is based on (or derived from) the Work and for which the
 *      editorial revisions, annotations, elaborations, or other modifications
 *      represent, as a whole, an original work of authorship. For the purposes
 *      of this License, Derivative Works shall not include works that remain
 *      separable from, or merely link (or bind by name) to the interfaces of,
 *      the Work and Derivative Works thereof.
 *
 *      "Contribution" shall mean any work of authorship, including
 *      the original version of the Work and any modifications or additions
 *      to that Work or Derivative Works thereof, that is intentionally
 *      submitted to Licensor for inclusion in the Work by the copyright owner
 *      or by an individual or Legal Entity authorized to submit on behalf of
 *      the copyright owner. For the purposes of this definition, "submitted"
 *      means any form of electronic, verbal, or written communication sent
 *      to the Licensor or its representatives, including but not limited to
 *      communication on electronic mailing lists, source code control systems,
 *      and issue tracking systems that are managed by, or on behalf of, the
 *      Licensor for the purpose of discussing and improving the Work, but
 *      excluding communication that is conspicuously marked or otherwise
 *      designated in writing by the copyright owner as "Not a Contribution."
 *
 *      "Contributor" shall mean Licensor and any individual or Legal Entity
 *      on behalf of whom a Contribution has been received by Licensor and
 *      subsequently incorporated within the Work.
 *
 *   2. Grant of Copyright License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      copyright license to reproduce, prepare Derivative Works of,
 *      publicly display, publicly perform, sublicense, and distribute the
 *      Work and such Derivative Works in Source or Object form.
 *
 *   3. Grant of Patent License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      (except as stated in this section) patent license to make, have made,
 *      use, offer to sell, sell, import, and otherwise transfer the Work,
 *      where such license applies only to those patent claims licensable
 *      by such Contributor that are necessarily infringed by their
 *      Contribution(s) alone or by combination of their Contribution(s)
 *      with the Work to which such Contribution(s) was submitted. If You
 *      institute patent litigation against any entity (including a
 *      cross-claim or counterclaim in a lawsuit) alleging that the Work
 *      or a Contribution incorporated within the Work constitutes direct
 *      or contributory patent infringement, then any patent licenses
 *      granted to You under this License for that Work shall terminate
 *      as of the date such litigation is filed.
 *
 *   4. Redistribution. You may reproduce and distribute copies of the
 *      Work or Derivative Works thereof in any medium, with or without
 *      modifications, and in Source or Object form, provided that You
 *      meet the following conditions:
 *
 *      (a) You must give any other recipients of the Work or
 *          Derivative Works a copy of this License; and
 *
 *      (b) You must cause any modified files to carry prominent notices
 *          stating that You changed the files; and
 *
 *      (c) You must retain, in the Source form of any Derivative Works
 *          that You distribute, all copyright, patent, trademark, and
 *          attribution notices from the Source form of the Work,
 *          excluding those notices that do not pertain to any part of
 *          the Derivative Works; and
 *
 *      (d) If the Work includes a "NOTICE" text file as part of its
 *          distribution, then any Derivative Works that You distribute must
 *          include a readable copy of the attribution notices contained
 *          within such NOTICE file, excluding those notices that do not
 *          pertain to any part of the Derivative Works, in at least one
 *          of the following places: within a NOTICE text file distributed
 *          as part of the Derivative Works; within the Source form or
 *          documentation, if provided along with the Derivative Works; or,
 *          within a display generated by the Derivative Works, if and
 *          wherever such third-party notices normally appear. The contents
 *          of the NOTICE file are for informational purposes only and
 *          do not modify the License. You may add Your own attribution
 *          notices within Derivative Works that You distribute, alongside
 *          or as an addendum to the NOTICE text from the Work, provided
 *          that such additional attribution notices cannot be construed
 *          as modifying the License.
 *
 *      You may add Your own copyright statement to Your modifications and
 *      may provide additional or different license terms and conditions
 *      for use, reproduction, or distribution of Your modifications, or
 *      for any such Derivative Works as a whole, provided Your use,
 *      reproduction, and distribution of the Work otherwise complies with
 *      the conditions stated in this License.
 *
 *   5. Submission of Contributions. Unless You explicitly state otherwise,
 *      any Contribution intentionally submitted for inclusion in the Work
 *      by You to the Licensor shall be under the terms and conditions of
 *      this License, without any additional terms or conditions.
 *      Notwithstanding the above, nothing herein shall supersede or modify
 *      the terms of any separate license agreement you may have executed
 *      with Licensor regarding such Contributions.
 *
 *   6. Trademarks. This License does not grant permission to use the trade
 *      names, trademarks, service marks, or product names of the Licensor,
 *      except as required for reasonable and customary use in describing the
 *      origin of the Work and reproducing the content of the NOTICE file.
 *
 *   7. Disclaimer of Warranty. Unless required by applicable law or
 *      agreed to in writing, Licensor provides the Work (and each
 *      Contributor provides its Contributions) on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *      implied, including, without limitation, any warranties or conditions
 *      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
 *      PARTICULAR PURPOSE. You are solely responsible for determining the
 *      appropriateness of using or redistributing the Work and assume any
 *      risks associated with Your exercise of permissions under this License.
 *
 *   8. Limitation of Liability. In no event and under no legal theory,
 *      whether in tort (including negligence), contract, or otherwise,
 *      unless required by applicable law (such as deliberate and grossly
 *      negligent acts) or agreed to in writing, shall any Contributor be
 *      liable to You for damages, including any direct, indirect, special,
 *      incidental, or consequential damages of any character arising as a
 *      result of this License or out of the use or inability to use the
 *      Work (including but not limited to damages for loss of goodwill,
 *      work stoppage, computer failure or malfunction, or any and all
 *      other commercial damages or losses), even if such Contributor
 *      has been advised of the possibility of such damages.
 *
 *   9. Accepting Warranty or Additional Liability. While redistributing
 *      the Work or Derivative Works thereof, You may choose to offer,
 *      and charge a fee for, acceptance of support, warranty, indemnity,
 *      or other liability obligations and/or rights consistent with this
 *      License. However, in accepting such obligations, You may act only
 *      on Your own behalf and on Your sole responsibility, not on behalf
 *      of any other Contributor, and only if You agree to indemnify,
 *      defend, and hold each Contributor harmless for any liability
 *      incurred by, or claims asserted against, such Contributor by reason
 *      of your accepting any such warranty or additional liability.
 *
 *   END OF TERMS AND CONDITIONS
 *
 *   APPENDIX: How to apply the Apache License to your work.
 *
 *      To apply the Apache License to your work, attach the following
 *      boilerplate notice, with the fields enclosed by brackets "[]"
 *      replaced with your own identifying information. (Don't include
 *      the brackets!)  The text should be enclosed in the appropriate
 *      comment syntax for the file format. We also recommend that a
 *      file or class name and description of purpose be included on the
 *      same "printed page" as the copyright notice for easier
 *      identification within third-party archives.
 *
 *   Copyright [2025] [SoftAtHome]
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 * ---------------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>
#include <stdlib.h>
#include <setjmp.h>
#include <cmocka.h>
#include "mock.h"
#include <amxut/amxut_timer.h>
#include <debug/sahtrace.h>

char* g_randomCpeUrl = "/test";

static DM_ENG_ParameterValueStruct* build_param_struct(void) {
    DM_ENG_ParameterValueStruct* HWversion = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* PCode = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* SWversion = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* IPAdd = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* ABAdd = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* CRURL = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* PKey = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    DM_ENG_ParameterValueStruct* RDMversion = calloc(1, sizeof(DM_ENG_ParameterValueStruct));
    HWversion->parameterName = strdup("Device.DeviceInfo.HardwareVersion");
    HWversion->timestamp = 0;
    HWversion->type = DM_ENG_ParameterType_STRING;
    HWversion->value = strdup("1.0");
    HWversion->next = PCode;
    PCode->parameterName = strdup("Device.DeviceInfo.ProvisioningCode");
    PCode->timestamp = 0;
    PCode->type = DM_ENG_ParameterType_STRING;
    PCode->value = strdup("");
    PCode->next = SWversion;
    SWversion->parameterName = strdup("Device.DeviceInfo.SoftwareVersion");
    SWversion->timestamp = 0;
    SWversion->type = DM_ENG_ParameterType_STRING;
    SWversion->value = strdup("4.0.9.2");
    SWversion->next = IPAdd;
    IPAdd->parameterName = strdup("Device.IP.Interface.2.IPv4Address.1.IPAddress");
    IPAdd->timestamp = 0;
    IPAdd->type = DM_ENG_ParameterType_STRING;
    IPAdd->value = strdup("192.168.24.102");
    IPAdd->next = ABAdd;
    ABAdd->parameterName = strdup("Device.ManagementServer.AliasBasedAddressing");
    ABAdd->timestamp = 0;
    ABAdd->type = DM_ENG_ParameterType_BOOLEAN;
    ABAdd->value = strdup("0");
    ABAdd->next = CRURL;
    CRURL->parameterName = strdup("Device.ManagementServer.ConnectionRequestURL");
    CRURL->timestamp = 0;
    CRURL->type = DM_ENG_ParameterType_STRING;
    CRURL->value = strdup("http://ybt-fibre.internet-box.ch:4567/GykbafltJWRhfEND");
    CRURL->next = PKey;
    PKey->parameterName = strdup("Device.ManagementServer.ParameterKey");
    PKey->timestamp = 0;
    PKey->type = DM_ENG_ParameterType_STRING;
    PKey->value = strdup("3955546611");
    PKey->next = RDMversion;
    RDMversion->parameterName = strdup("Device.RootDataModelVersion");
    RDMversion->timestamp = 0;
    RDMversion->type = DM_ENG_ParameterType_STRING;
    RDMversion->value = strdup("2.14");
    RDMversion->next = NULL;

    return HWversion;
}

static void write_string_to_file(const char* content) {
    const char* filename = "/tmp/message_sent.xml";
    size_t len = 0;
    ssize_t written = 0;
    int fd = 0;

    fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if(fd == -1) {
        print_message("open failed");
        return;
    }

    len = strlen(content);
    written = write(fd, content, len);
    if((written < 0) || ((size_t) written != len)) {
        print_message("write failed");
        close(fd);
        return;
    }

    if(fsync(fd) == -1) {
        print_message("fsync failed");
        close(fd);
        return;
    }

    close(fd);
}

int __wrap_DM_SendHttpMessage(const char* msgToSendStr) {
    if(msgToSendStr) {
        write_string_to_file(msgToSendStr);
    }
    return 0;
}
int __wrap_client_startSession() {
    return 0;
}
int __wrap_DM_CloseHttpSession(int closeMode) {
    (void) closeMode;
    return 0;
}
int __wrap_DM_ENG_GetManagementServerValue(DM_ENG_EntityType entity, DM_ENG_SystemParameter_t parameter, char** pResult) {
    check_expected(entity);
    check_expected(parameter);

    *pResult = mock_ptr_type(char*);

    return mock_type(int);
}

DM_ENG_NotificationStatus __wrap_DM_ENG_NotificationInterface_timerStart(const char* name, int waitTime, int intervalTime, timerHandler handler) {
    char* timer_name = strdup(name);

    amxut_timer_go_to_future_ms(waitTime);
    handler(timer_name);
    amxut_timer_go_to_future_ms(intervalTime);
    handler(timer_name);

    free(timer_name);

    return DM_ENG_SESSION_OPENING;
}


void __wrap_DM_ENG_SessionOpened(DM_ENG_EntityType entity) {
    (void) entity;
    return;
}

DM_ENG_ParameterValueStruct* __wrap_DM_ENG_ParameterAttributesCacheGetForcedParams(bool updateCache, bool* parameterChanged) {
    (void) updateCache;
    (void) parameterChanged;
    return build_param_struct();
}

DM_ENG_NotificationStatus __wrap_DM_ENG_NotificationInterface_inform(DM_ENG_DeviceIdStruct* id, DM_ENG_EventStruct* events[], DM_ENG_ParameterValueStruct* parameterList[], time_t currentTime, unsigned int retryCount) {
    //test id
    assert_true(strcmp(id->manufacturer, "WNC") == 0);
    assert_true(strcmp(id->OUI, "000B6B") == 0);
    assert_true(strcmp(id->productClass, "CR1000A") == 0);
    assert_true(strcmp(id->serialNumber, "ABV31002350") == 0);

    //test events
    assert_true(strcmp(events[0]->eventCode, "14 HEARTBEAT") == 0);
    assert_true(events[1] == NULL);

    //test parameterList
    assert_true(strcmp(parameterList[0]->parameterName, "Device.DeviceInfo.HardwareVersion") == 0);
    assert_true(strcmp(parameterList[0]->value, "1.0") == 0);
    assert_true(strcmp(parameterList[0]->next->parameterName, "Device.DeviceInfo.ProvisioningCode") == 0);
    assert_true(strcmp(parameterList[0]->next->value, "") == 0);
    assert_true(strcmp(parameterList[0]->next->next->parameterName, "Device.DeviceInfo.SoftwareVersion") == 0);
    assert_true(strcmp(parameterList[0]->next->next->value, "4.0.9.2") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->parameterName, "Device.IP.Interface.2.IPv4Address.1.IPAddress") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->value, "192.168.24.102") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->parameterName, "Device.ManagementServer.AliasBasedAddressing") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->value, "0") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->parameterName, "Device.ManagementServer.ConnectionRequestURL") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->value, "http://ybt-fibre.internet-box.ch:4567/GykbafltJWRhfEND") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->next->parameterName, "Device.ManagementServer.ParameterKey") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->next->value, "3955546611") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->next->next->parameterName, "Device.RootDataModelVersion") == 0);
    assert_true(strcmp(parameterList[0]->next->next->next->next->next->next->next->value, "2.14") == 0);

    return __real_DM_ENG_NotificationInterface_inform(id, events, parameterList, currentTime, retryCount);
}

int __wrap_DM_ENG_GetInformParameterValues(DM_ENG_EventStruct* eventList, DM_ENG_ParameterValueStruct** pvsList) {
    (void) eventList;
    (void) pvsList;
    return 0;
}
