/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_dhcp_pool.h"
#include "test_dhcp_context.h"

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include "gmap_eth_dev_dhcp_pool.h"
#include <string.h>
#include <sys/socket.h>
#include <stdio.h>
#include <amxc/amxc.h> // needed for <amxp/amxp.h>
#include <amxp/amxp.h> // needed for <amxd/amxd_object.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <malloc.h>

#include "../common/test-setup.h"
#include "../common/test-util.h"
#include "../common/mock_gmap.h"
#include "../common/mock_discoping.h"
#include "../common/mock_netmodel.h"


int test_gmap_eth_dev_dhcp_pool_setup(UNUSED void** state) {
    int result = test_setup_without_component_init(state);
    if(result == 0) {
        amxut_dm_load_odl("dhcpv4-dm.odl");
        amxut_bus_handle_events();
    }
    return result;
}

int test_gmap_eth_dev_dhcp_pool_teardown(UNUSED void** state) {
    return test_teardown_without_component_cleanup(state);
}

static uint32_t s_create_pool(const char* iface) {
    amxc_var_t params;
    amxc_var_t ret;
    amxd_status_t status;
    uint32_t index = 0;

    amxc_var_init(&params);
    amxc_var_init(&ret);

    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &params, "Interface", iface);

    status = amxb_add(amxut_bus_ctx(), "DHCPv4Server.Pool.", 0, NULL, &params, &ret, 5);
    assert_int_equal(status, amxd_status_ok);

    index = GET_UINT32(GETI_ARG(&ret, 0), "index");
    assert_int_not_equal(index, 0);

    amxc_var_clean(&ret);
    amxc_var_clean(&params);

    return index;
}

static void s_mod_pool(uint32_t index, const char* iface) {
    amxd_trans_t trans;
    amxd_status_t status;

    amxd_trans_init(&trans);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "DHCPv4Server.Pool.%d.", index);
    amxd_trans_set_value(cstring_t, &trans, "Interface", iface);

    status = amxd_trans_apply(&trans, amxut_bus_dm());
    assert_int_equal(status, amxd_status_ok);

    amxd_trans_clean(&trans);
}

static void s_pool_cb_t(gmap_eth_dev_dhcp_pool_t* pool,
                        const char* path,
                        const char* iface,
                        bool matching,
                        void* const priv) {
    check_expected(pool);
    check_expected(path);
    check_expected(iface);
    check_expected(matching);
    check_expected(priv);
}

void test_gmap_eth_dev_dhcp_pool_added_matching(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub = NULL;

    // GIVEN a dhcp pool
    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    // WHEN subscribed for a specific interface
    sub = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1.", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_non_null(sub);

    // AND that interface is added
    amxut_dm_load_odl("dhcpv4-mockdata-pool-1.odl");

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    // WHEN another interface is added
    amxut_dm_load_odl("dhcpv4-mockdata-pool-2.odl");

    // THEN the callback is not called
    amxut_bus_handle_events();

    // WHEN data is changed within the pool
    amxut_dm_load_odl("dhcpv4-mockdata-normal.odl");

    // THEN the callback is not called again
    amxut_bus_handle_events();

    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
}

void test_gmap_eth_dev_dhcp_pool_removed_matching(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub = NULL;

    // GIVEN a dhcp pool
    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    // WHEN subscribed for a specific interface
    sub = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1.", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_non_null(sub);

    // AND that interface is added
    amxut_dm_load_odl("dhcpv4-mockdata-pool-1.odl");

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    // WHEN that interface is removed
    amxb_del(amxut_bus_ctx(), "DHCPv4Server.Pool.", 1, NULL, NULL, 5);

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, false);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
}

void test_gmap_eth_dev_dhcp_pool_changed_matching(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    uint32_t index = 0;
    gmap_eth_dev_dhcp_pool_subscription_t* sub1 = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub2 = NULL;

    // GIVEN a dhcp pool
    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    // WHEN subscribed for two specific interfaces
    sub1 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1.", s_pool_cb_t, (void*) (uintptr_t) 1);
    sub2 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.2.", s_pool_cb_t, (void*) (uintptr_t) 2);
    assert_non_null(sub1);
    assert_non_null(sub2);

    // AND a non-matching pool is added
    index = s_create_pool("Device.IP.Interface.33.");
    assert_int_not_equal(index, 0);

    // THEN the callback is not called
    amxut_bus_handle_events();

    //WHEN the interface is changed
    s_mod_pool(index, "Device.IP.Interface.1.");

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    //WHEN the interface is changed again
    s_mod_pool(index, "Device.IP.Interface.2.");

    // THEN both callbacks are called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, false);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);

    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    //WHEN a subscription is removed
    gmap_eth_dev_dhcp_pool_unsubscribe(sub1);

    // AND the interface is changed again
    s_mod_pool(index, "Device.IP.Interface.1.");

    // THEN only one callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, false);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
}

void test_gmap_eth_dev_dhcp_pool_initial_matching(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub1 = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub2 = NULL;

    // GIVEN a existing pool
    amxut_dm_load_odl("dhcpv4-mockdata-pool-1.odl");
    amxut_bus_handle_events();

    // WHEN the pool listener is created
    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    // AND another pool is added
    amxut_dm_load_odl("dhcpv4-mockdata-pool-2.odl");
    amxut_bus_handle_events();

    // THEN callbacks are called when their subscriptions are added
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    sub1 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1.", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_non_null(sub1);

    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.2.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    sub2 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.2.", s_pool_cb_t, (void*) (uintptr_t) 2);
    assert_non_null(sub2);


    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
}

/* Similar to the other tests above, except now the subscriptions don't use the
 * trailing dot in the subscription iface path. */
void test_gmap_eth_dev_dhcp_pool_no_trailing_dot(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    uint32_t index = 0;
    gmap_eth_dev_dhcp_pool_subscription_t* sub1 = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub2 = NULL;

    // GIVEN a existing pool
    amxut_dm_load_odl("dhcpv4-mockdata-pool-1-no-tr-dot.odl");
    amxut_bus_handle_events();

    // WHEN the pool listener is created
    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    // AND another pool is added
    amxut_dm_load_odl("dhcpv4-mockdata-pool-2-no-tr-dot.odl");
    amxut_bus_handle_events();

    // THEN callbacks are called when their subscriptions are added
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.1.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    sub1 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_non_null(sub1);

    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.2.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    sub2 = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.2", s_pool_cb_t, (void*) (uintptr_t) 2);
    assert_non_null(sub2);

    ////////////////////////////////////////////////////////////////////////////
    // WHEN a non-matching pool is added
    index = s_create_pool("Device.IP.Interface.33");
    assert_int_not_equal(index, 0);

    // THEN the callback is not called
    amxut_bus_handle_events();

    ////////////////////////////////////////////////////////////////////////////
    // WHEN the interface is changed
    s_mod_pool(index, "Device.IP.Interface.1");

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.3.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    ////////////////////////////////////////////////////////////////////////////
    //WHEN the interface is changed again
    s_mod_pool(index, "Device.IP.Interface.2");

    // THEN both callbacks are called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.3.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.1");
    expect_value(s_pool_cb_t, matching, false);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 1);

    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.3.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    ////////////////////////////////////////////////////////////////////////////
    // WHEN a matching pool is added without trailing dot
    index = s_create_pool("Device.IP.Interface.2");
    assert_int_not_equal(index, 0);

    // THEN the callback is called without trailing dot
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.4.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();


    ////////////////////////////////////////////////////////////////////////////
    // WHEN a matching pool is added with trailing dot
    index = s_create_pool("Device.IP.Interface.2.");
    assert_int_not_equal(index, 0);

    // THEN the callback is called without trailing dot
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.5.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, true);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    ////////////////////////////////////////////////////////////////////////////
    // WHEN that interface is removed
    amxb_del(amxut_bus_ctx(), "DHCPv4Server.Pool.", index, NULL, NULL, 5);

    // THEN the callback is called
    expect_value(s_pool_cb_t, pool, pool);
    expect_string(s_pool_cb_t, path, "DHCPv4Server.Pool.5.");
    expect_string(s_pool_cb_t, iface, "Device.IP.Interface.2");
    expect_value(s_pool_cb_t, matching, false);
    expect_value(s_pool_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    // cleanup
    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
}

void test_gmap_eth_dev_dhcp_pool_bad_args(UNUSED void** state) {
    gmap_eth_dev_dhcp_pool_t* pool = NULL;
    gmap_eth_dev_dhcp_pool_subscription_t* sub = NULL;

    // GIVEN a existing pool
    amxut_dm_load_odl("dhcpv4-mockdata-pool-1-no-tr-dot.odl");
    amxut_bus_handle_events();

    // EXPECT proper behavior on bad parameters
    gmap_eth_dev_dhcp_pool_new(&pool, NULL);
    assert_null(pool);
    gmap_eth_dev_dhcp_pool_new(NULL, amxut_bus_ctx());

    gmap_eth_dev_dhcp_pool_new(&pool, amxut_bus_ctx());
    assert_non_null(pool);

    sub = gmap_eth_dev_dhcp_pool_subscribe(pool, "Device.IP.Interface.1", NULL, (void*) (uintptr_t) 1);
    assert_null(sub);
    sub = gmap_eth_dev_dhcp_pool_subscribe(pool, "", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_null(sub);
    sub = gmap_eth_dev_dhcp_pool_subscribe(pool, NULL, s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_null(sub);
    sub = gmap_eth_dev_dhcp_pool_subscribe(NULL, "Device.IP.Interface.1", s_pool_cb_t, (void*) (uintptr_t) 1);
    assert_null(sub);

    gmap_eth_dev_dhcp_pool_unsubscribe(NULL);

    // cleanup
    gmap_eth_dev_dhcp_pool_delete(NULL);
    gmap_eth_dev_dhcp_pool_delete(&pool);
    assert_null(pool);
    gmap_eth_dev_dhcp_pool_delete(&pool);
}
