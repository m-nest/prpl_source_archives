/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object_event.h>
#include <amxrt/amxrt.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "event_handler.h"
#include "dm_interface.h"
#include "tr181-gatewayinfo.h"

#define ME "gatewayinfo"

#define GATEWAYINFO_ROOT "GatewayInfo."

/**
 * @file dm_interface.c
 * @brief Implementation of the datamodel interface for the tr181-gatewayinfo.
 */

int register_cwmp_dm(void) {
    int rc = -1;

    amxc_var_for_each(proxy_object, GET_ARG(amxrt_get_config(), "proxy-object")) {
        const char* proxy = amxc_var_key(proxy_object);
        const char* real = amxc_var_constcast(cstring_t, proxy_object);
        SAH_TRACEZ_INFO(ME, "Registering '%s' as '%s'", proxy, real);

        amxb_bus_ctx_t* ctx = amxb_be_who_has("ProxyManager");
        when_null_trace(ctx, exit, WARNING, "Cannot register CWMP model: cannot obtain bus ctx for 'ProxyManager'");

        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "proxy", proxy);
        amxc_var_add_key(cstring_t, &parameters, "real", real);

        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_call(ctx, "ProxyManager.", "register", &parameters, &ret, BUS_OPERATION_TIMEOUT);

        amxc_var_clean(&ret);
        amxc_var_clean(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot register proxy '%s' -> '%s', got %d", proxy, real, status);
    }

    rc = 0;
exit:
    return rc;
}


int deregister_cwmp_dm(void) {
    int rc = -1;

    amxc_var_for_each(proxy_object, GET_ARG(amxrt_get_config(), "proxy-object")) {
        const char* proxy = amxc_var_key(proxy_object);
        SAH_TRACEZ_INFO(ME, "Deregistering '%s'", proxy);

        amxb_bus_ctx_t* ctx = amxb_be_who_has("ProxyManager");
        when_null_trace(ctx, exit, WARNING, "Cannot deregister CWMP model: cannot obtain bus ctx for 'ProxyManager'");

        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "proxy", proxy);

        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_call(ctx, "ProxyManager.", "unregister", &parameters, &ret, BUS_OPERATION_TIMEOUT);

        amxc_var_clean(&ret);
        amxc_var_clean(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot unregister proxy '%s', got %d", proxy, status);
    }

    rc = 0;
exit:
    return rc;
}

/**
 * Send CWMPGatewayDiscovered! notification with the appropriate parameters:
 *   - ManufacturerOUI
 *   - ProductClass
 *   - SerialNumber
 *
 * @param[in] gatewayinfo the DHCP-discovered information about the gateway
 *
 * @return 0 if notification sending was successful
 */
static int cwmp_gateway_discovered_notify(const struct DHCPGatewayInformation* gatewayinfo) {
    int rc = -1;

    amxd_object_t* gateway_info_root_object = amxd_dm_get_object(amxrt_get_dm(), GATEWAYINFO_ROOT);
    when_null_trace(gateway_info_root_object, exit, WARNING, "Cannot find too object '%s'", GATEWAYINFO_ROOT);

    amxc_var_t notif_data;
    amxc_var_init(&notif_data);
    amxc_var_set_type(&notif_data, AMXC_VAR_ID_HTABLE);

    amxc_var_t* vardata = amxc_var_add_key(amxc_htable_t, &notif_data, "data", NULL);

    amxc_var_add_key(cstring_t, vardata, "ManufacturerOUI", amxc_string_get(&gatewayinfo->DeviceManufacturerOUI, 0));
    amxc_var_add_key(cstring_t, vardata, "ProductClass", amxc_string_get(&gatewayinfo->DeviceProductClass, 0));
    amxc_var_add_key(cstring_t, vardata, "SerialNumber", amxc_string_get(&gatewayinfo->DeviceSerialNumber, 0));

    amxd_object_emit_signal(gateway_info_root_object, "CWMPGatewayDiscovered!", &notif_data);

    amxc_var_clean(&notif_data);
    rc = 0;

exit:
    return rc;
}

/**
 * Get the 'ManagementProtocol' parameter value from the gatewayinfo
 *
 * @param[in] gatewayinfo the DHCP-discovered gatewayinfo
 *
 * @return the value of the ManagementProtocol parameter
 */
static const char* get_management_protocol(const struct DHCPGatewayInformation* gatewayinfo) {
    if(DHCPGatewayInformation_is_emtpy(gatewayinfo)) {
        return "";
    }
    return "CWMP";
}

int dm_update_gatewayinfo(const struct DHCPGatewayInformation* gatewayinfo) {
    int rc = -1;

    amxd_trans_t trans;
    when_failed_trace(amxd_trans_init(&trans), exit, WARNING, "Cannot initialize transaction");
    when_failed_trace(amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true), exit, WARNING, "Cannot set 'amxd_tattr_change_ro' attr for the transaction");
    when_failed_trace(amxd_trans_select_pathf(&trans, GATEWAYINFO_ROOT), exit, WARNING, "Cannot select 'GatewayInfo.' object for the transaction");

    when_failed_trace(amxd_trans_set_cstring_t(&trans, "ManufacturerOUI", amxc_string_get(&gatewayinfo->DeviceManufacturerOUI, 0)), exit, WARNING, "Cannot set 'ManufacturerOUI' parameter");
    when_failed_trace(amxd_trans_set_cstring_t(&trans, "ProductClass", amxc_string_get(&gatewayinfo->DeviceProductClass, 0)), exit, WARNING, "Cannot set 'ProductClass' parameter");
    when_failed_trace(amxd_trans_set_cstring_t(&trans, "SerialNumber", amxc_string_get(&gatewayinfo->DeviceSerialNumber, 0)), exit, WARNING, "Cannot set 'SerialNumber' parameter");
    when_failed_trace(amxd_trans_set_cstring_t(&trans, "ManagementProtocol", get_management_protocol(gatewayinfo)), exit, WARNING, "Cannot set 'ManagementProtocol' parameter");

    when_failed_trace(rc = amxd_trans_apply(&trans, amxrt_get_dm()), exit, WARNING, "Cannot apply transaction, got %d", rc);
    rc = (DHCPGatewayInformation_is_emtpy(gatewayinfo)) ? 0 : cwmp_gateway_discovered_notify(gatewayinfo);
    amxd_trans_clean(&trans);
exit:
    return rc;
}
