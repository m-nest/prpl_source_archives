/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/common_api.h>

#include "ddns_priv.h"
#include "ddns.h"
#include "ddns_error_codes.h"
#include "ddns_config.h"
#include "client/client.h"
#include "client/dm_client.h"
#include "hostname/hostname.h"
#include "hostname/dm_hostname.h"
#include "server/dm_server.h"
#include "ddns/module_functions.h"

#define ME "ddns"

static void retry_hostname_cb(amxp_timer_t* timer, void* data) {
    SAH_TRACEZ_IN(ME);
    ddns_status_t status = ddns_status_error_config;
    amxd_object_t* obj_ddns_client = NULL;
    bool enable_server = false;
    bool enable_global = false;
    bool enable_local = false;
    amxd_object_t* obj_ddns_client_hostname = (amxd_object_t*) data;
    ddns_hostname_t* hostname = NULL;
    ddns_client_t* client = NULL;
    cstring_t obj_path = NULL;

    when_null_trace(obj_ddns_client_hostname, exit, INFO, "Data is NULL.");
    obj_path = amxd_object_get_path(obj_ddns_client_hostname, AMXD_OBJECT_INDEXED | AMXD_OBJECT_TERMINATE);
    when_null_trace(obj_path, exit, INFO, "Object path is NULL.");
    obj_ddns_client = ddns_client_from_hostname(obj_ddns_client_hostname);
    when_null_trace(obj_ddns_client, exit, ERROR, "DynamicDNS.Client object is NULL");
    client = (ddns_client_t*) obj_ddns_client->priv;
    when_null_trace(client, exit, ERROR, "Client struct is NULL");

    hostname = get_hostname(obj_ddns_client_hostname);
    when_null_trace(hostname, exit, INFO, "Hostname struct is NULL.");

    if(hostname->retry_counter >= client->dm_number_retries) {
        hostname->retry_counter = 0;
        amxp_timer_stop(timer);
        SAH_TRACEZ_ERROR(ME, "The amount of retries of %s reached the MaxRetries(%d)", obj_path, client->dm_number_retries);
        goto exit;
    } else {
        SAH_TRACEZ_ERROR(ME, "Triggered retry for %s (%d/%d)", obj_path, hostname->retry_counter + 1, client->dm_number_retries);
    }
    hostname->retry_counter++;

    enable_local = amxd_object_get_value(bool, obj_ddns_client_hostname, "Enable", NULL);
    enable_server = get_server_enable(obj_ddns_client, NULL);
    enable_global = amxd_object_get_value(bool, obj_ddns_client, "Enable", NULL);

    status = retry_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname));
    post_ddns_operations(obj_ddns_client, obj_ddns_client_hostname, status, enable_server, enable_global, enable_local);

exit:
    FREE(obj_path);
    SAH_TRACEZ_OUT(ME);
    return;
}

static void check_interval_ddns_cb(UNUSED amxp_timer_t* const timer, void* data) {
    SAH_TRACEZ_IN(ME);
    ddns_status_t status;
    amxd_object_t* obj_ddns_client_hostname = (amxd_object_t*) data;
    amxd_object_t* obj_ddns_client = NULL;
    ddns_client_t* client = NULL;
    const cstring_t server = NULL;
    const cstring_t username = NULL;
    const cstring_t password = NULL;
    const char* interface = NULL;
    const char* ip_interface = NULL;
    const cstring_t domain = NULL;
    bool enable_hostname = false;
    bool enable_server = false;
    bool enable_client = false;
    bool enable = false;

    when_null_trace(obj_ddns_client_hostname, exit, ERROR, "DynamicDNS.Client.{}.Hostname object is NULL");
    obj_ddns_client = ddns_client_from_hostname(obj_ddns_client_hostname);
    when_null_trace(obj_ddns_client, exit, ERROR, "DynamicDNS.Client object is NULL");
    client = (ddns_client_t*) obj_ddns_client->priv;
    when_null_trace(client, exit, ERROR, "Client struct is NULL");

    server = ddns_get_string_param(obj_ddns_client, NULL, "Server");
    username = ddns_get_string_param(obj_ddns_client, NULL, "Username");
    password = ddns_get_string_param(obj_ddns_client, NULL, "Password");
    domain = ddns_get_string_param(obj_ddns_client_hostname, NULL, "Name");
    enable_hostname = amxd_object_get_value(bool, obj_ddns_client_hostname, "Enable", NULL);
    enable_server = get_server_enable(obj_ddns_client, NULL);
    enable_client = amxd_object_get_value(bool, obj_ddns_client, "Enable", NULL);
    interface = amxc_string_get(&(client->linux_intf), 0);
    ip_interface = amxc_string_get(&(client->ip_ref_linux_intf), 0);

    enable = enable_hostname;
    if(!enable_server || !enable_client) {
        enable = false;
    }

    status = edit_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname), domain, server, interface, ip_interface, username, password, enable, NULL);
    post_ddns_operations(obj_ddns_client, obj_ddns_client_hostname, status, enable_server, enable_client, enable_hostname);

exit:
    SAH_TRACEZ_OUT(ME);
}

static void check_status_cb(amxp_timer_t* timer, void* data) {
    SAH_TRACEZ_IN(ME);
    ddns_error_t error = ddns_error_dns;
    const amxc_var_t* tmp_var = NULL;
    const cstring_t status_hostname = NULL;
    const cstring_t server = NULL;
    bool last_error_config = false;
    int host_num_of_entries = 0;
    int count_error = 0;
    int count_disable = 0;
    amxd_object_t* obj_ddns_client = NULL;
    amxd_object_t* tmpl_ddns_client_hostname = NULL;
    ddns_hostname_t* hostname = NULL;
    amxd_object_t* obj_ddns_client_hostname = (amxd_object_t*) data;
    ddns_client_t* client = NULL;
    amxc_var_t* curr_time = NULL;
    sah_trace_level log_level = TRACE_LEVEL_ERROR;
    int ret_value = 0;
    cstring_t obj_path = NULL;

    amxc_var_new(&curr_time);
    ret_value = ddns_get_current_time(curr_time);
    if(ret_value != 0) {
        amxc_var_delete(&curr_time);
        curr_time = NULL;
    }

    when_null_trace(obj_ddns_client_hostname, exit, INFO, "Data is NULL.");
    obj_path = amxd_object_get_path(obj_ddns_client_hostname, AMXD_OBJECT_INDEXED | AMXD_OBJECT_TERMINATE);
    hostname = get_hostname(obj_ddns_client_hostname);
    when_null_trace(hostname, exit, INFO, "Wrapper is NULL.");

    obj_ddns_client = ddns_client_from_hostname(obj_ddns_client_hostname);
    when_null_trace(obj_ddns_client, exit, INFO, "DynamicDNS.Client object is NULL");
    client = (ddns_client_t*) obj_ddns_client->priv;
    when_null_trace(client, exit, INFO, "Client struct is NULL.");
    tmpl_ddns_client_hostname = amxd_object_findf(obj_ddns_client, ".Hostname.");
    when_null_trace(tmpl_ddns_client_hostname, exit, INFO, "DynamicDNS.Client.Hostname template is NULL");

    tmp_var = amxd_object_get_param_value(obj_ddns_client, "LastError");
    if(tmp_var != NULL) {
        if(strcmp(GET_CHAR(tmp_var, NULL), DDNS_ERROR(ddns_error_config)) == 0) {
            last_error_config = true;
        }
    }

    tmp_var = amxd_object_get_param_value(obj_ddns_client_hostname, "Status");
    if(tmp_var != NULL) {
        status_hostname = GET_CHAR(tmp_var, NULL);
    } else {
        status_hostname = "";
    }

    server = ddns_get_string_param(obj_ddns_client, NULL, "Server");

    error = check_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname));
    if((error == ddns_error_updating) || (error == ddns_error_no)) {
        SAH_TRACEZ_INFO(ME, "ddns status = %d [%s]", error, obj_path);
    } else {
        SAH_TRACEZ_ERROR(ME, "ddns error = %d [%s]", error, obj_path);
    }

    SAH_TRACEZ_INFO(ME, "check status counter = %d/%d [%s]", hostname->status_counter + 1, CHECK_STATUS_TIMER_MAX_COUNTER, obj_path);
    if(error == ddns_error_updating) {
        if(hostname->status_counter >= CHECK_STATUS_TIMER_MAX_COUNTER) {
            error = ddns_error_timeout;
        } else {
            amxp_timer_start(timer, CHECK_STATUS_TIMER_INTERVAL);
            hostname->status_counter++;
            goto rearm;
        }
    }

    if(error == ddns_error_no) {
        log_level = TRACE_LEVEL_INFO;
    }

    if(error == ddns_error_dns) {
        if(!str_empty(server)) {
            if((strcmp(status_hostname, "Error") != 0) && (!last_error_config)) {
                set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(error), log_level);
            }
        } else {
            set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(ddns_error_config), log_level);
            last_error_config = true;
        }
        set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_error), log_level);
        hostname->last_status = ddns_hostname_error;
    } else if(error != ddns_error_no) {
        set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(error), log_level);
        last_error_config = (error == ddns_error_config);
        set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_error), log_level);
        hostname->last_status = ddns_hostname_error;
    } else {
        if(!str_empty(server)) {
            if(!hostname->enable || !client->enable) {
                set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_disabled), TRACE_LEVEL_INFO);
                hostname->last_status = ddns_hostname_disabled;
            } else {
                if((hostname->last_status != ddns_hostname_registered) || client->changed_dm) {
                    if(curr_time != NULL) {
                        set_on_dm(obj_ddns_client_hostname, "LastUpdate", GET_CHAR(curr_time, NULL), TRACE_LEVEL_INFO);
                    }
                }
                set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_registered), TRACE_LEVEL_INFO);
                hostname->last_status = ddns_hostname_registered;
            }
        } else {
            set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_error), TRACE_LEVEL_ERROR);
            hostname->last_status = ddns_hostname_error;
        }
    }

    amxd_object_for_each(instance, it, tmpl_ddns_client_hostname) {
        amxd_object_t* intance = amxc_container_of(it, amxd_object_t, it);
        host_num_of_entries++;

        tmp_var = amxd_object_get_param_value(intance, "Status");
        if(tmp_var != NULL) {
            status_hostname = GET_CHAR(tmp_var, NULL);
        }

        if(status_hostname != NULL) {
            if((strcmp(status_hostname, "Error") == 0) || (strcmp(status_hostname, "UpdateNeeded") == 0)) {
                count_error++;
            } else if(strcmp(status_hostname, "Disabled") == 0) {
                count_disable++;
            }
        }
    }

    if(str_empty(server)) {
        set_on_dm(obj_ddns_client, "Status", DDNS_STATUS(ddns_status_error_config), log_level);
        set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(ddns_error_config), log_level);
    } else if(count_error == host_num_of_entries) {
        if(last_error_config) {
            set_on_dm(obj_ddns_client, "Status", DDNS_STATUS(ddns_status_error_config), log_level);
        } else {
            set_on_dm(obj_ddns_client, "Status", DDNS_STATUS(ddns_status_error), log_level);
        }
    } else if(count_disable == host_num_of_entries) {
        set_on_dm(obj_ddns_client, "Status", DDNS_STATUS(ddns_status_disabled), log_level);
        set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(ddns_error_no), log_level);
    } else {
        set_on_dm(obj_ddns_client, "Status", DDNS_STATUS(ddns_status_updated), log_level);
        set_on_dm(obj_ddns_client, "LastError", DDNS_ERROR(ddns_error_no), log_level);
    }

exit:
    if(error != ddns_error_updating) {
        dump_ddns_logs(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname), log_level);
    }
    stop_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname));
    amxp_timer_stop(timer);
    if(hostname != NULL) {
        hostname->checking = false;
        hostname->status_counter = 0;
    }
    if(client != NULL) {
        client->changed_dm = false;
        if(hostname != NULL) {
            if((hostname->last_status == ddns_hostname_error) && (hostname->retry_counter < client->dm_number_retries) && (client->dm_retry_interval > 0)) {
                if(obj_path != NULL) {
                    SAH_TRACEZ_ERROR(ME, "Retrying %s in %d milliseconds. (%d/%d)", obj_path, client->dm_retry_interval, hostname->retry_counter, client->dm_number_retries);
                }
                set_on_dm(obj_ddns_client_hostname, "Status", DDNS_HOSTNAME_STATUS(ddns_hostname_up_needed), TRACE_LEVEL_INFO);
                amxp_timer_start(hostname->retry_timer, client->dm_retry_interval);
            } else {
                hostname->retry_counter = 0;
                amxp_timer_stop(hostname->retry_timer);
            }
        }
    }

rearm:
    amxc_var_delete(&curr_time);
    FREE(obj_path);
    SAH_TRACEZ_OUT(ME);
}

/**
   @brief
   Initialise the Hostname internal structure.

   @param[in] instance Object with the Hostname's instance.
   @param[in] index Index of the client's instance.

   @return
   0 if success, 1 if failed.
 */
static int ddns_hostname_init(amxd_object_t* instance, int index) {
    SAH_TRACEZ_IN(ME);
    ddns_hostname_t* hostname = NULL;
    int ret_value = 1;

    when_null(instance, exit);

    hostname = get_hostname(instance);
    when_null(hostname, exit);

    hostname->index = index;
    amxp_timer_new(&(hostname->check_interval_timer), check_interval_ddns_cb, instance);
    amxp_timer_new(&(hostname->status_timer), check_status_cb, instance);
    amxp_timer_new(&(hostname->retry_timer), retry_hostname_cb, instance);

    ret_value = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return ret_value;
}

void _client_hostname_added(UNUSED const char* const sig_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    ddns_status_t status = ddns_status_error_config;
    const amxc_var_t* tmp_var = NULL;
    const amxc_var_t* parameters = NULL;
    const cstring_t domain = NULL;
    bool enable_server = false;
    bool enable_global = false;
    bool enable_local = false;
    bool enable = false;
    amxd_object_t* tmpl_ddns_client_hostname = amxd_dm_signal_get_object(ddns_get_dm(), event_data);
    amxd_object_t* obj_ddns_client = NULL;
    amxd_object_t* obj_ddns_client_hostname = NULL;

    SAH_TRACEZ_INFO(ME, "Received event: %s", sig_name);

    when_null_trace(tmpl_ddns_client_hostname, exit, ERROR, "DynamicDNS.Client.Hostname template is NULL");
    obj_ddns_client = amxd_object_findf(tmpl_ddns_client_hostname, ".^");
    when_null_trace(obj_ddns_client, exit, ERROR, "DynamicDNS.Client object is NULL");
    obj_ddns_client_hostname = amxd_object_findf(tmpl_ddns_client_hostname, ".%d.", GET_INT32(event_data, "index"));
    when_null_trace(obj_ddns_client_hostname, exit, ERROR, "DynamicDNS.Client.Hostname object is NULL");

    when_failed(ddns_hostname_init(obj_ddns_client_hostname, GET_INT32(event_data, "index")), exit);

    parameters = GET_ARG(event_data, "parameters");
    when_null(parameters, exit);

    domain = ddns_get_string_param(NULL, parameters, "Name");

    tmp_var = GET_ARG(parameters, "Enable");
    if(tmp_var != NULL) {
        enable_local = GET_BOOL(tmp_var, NULL);
    }

    enable_server = get_server_enable(obj_ddns_client, NULL);
    enable_global = amxd_object_get_value(uint32_t, obj_ddns_client, "Enable", NULL);

    if(!enable_server || !enable_global) {
        enable = false;
    } else {
        enable = enable_local;
    }

    status = add_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname), domain, enable);
    post_ddns_operations(obj_ddns_client, obj_ddns_client_hostname, status, enable_server, enable_global, enable_local);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

void _client_hostname_changed(UNUSED const char* const sig_name,
                              const amxc_var_t* const event_data,
                              UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    ddns_status_t status = ddns_status_error_config;
    const amxc_var_t* tmp_var = NULL;
    const amxc_var_t* parameters = NULL;
    const cstring_t interface = NULL;
    const cstring_t ip_interface = NULL;
    const cstring_t new_domain = NULL;
    bool enable_server = false;
    bool enable_global = false;
    bool enable_local = false;
    bool enable = false;
    amxd_object_t* obj_ddns_client_hostname = amxd_dm_signal_get_object(ddns_get_dm(), event_data);
    amxd_object_t* tmpl_ddns_client_hostname = NULL;
    amxd_object_t* obj_ddns_client = NULL;
    ddns_client_t* client = NULL;
    ddns_hostname_t* hostname = NULL;

    SAH_TRACEZ_NOTICE(ME, "Received event: %s", sig_name);

    when_null_trace(obj_ddns_client_hostname, exit, ERROR, "DynamicDNS.Client.Hostname object is NULL");
    hostname = get_hostname(obj_ddns_client_hostname);
    when_null_trace(hostname, exit, INFO, "Wrapper is NULL.");

    amxp_timer_stop(hostname->check_interval_timer);
    amxp_timer_stop(hostname->status_timer);
    amxp_timer_stop(hostname->retry_timer);
    hostname->retry_counter = 0;
    hostname->status_counter = 0;

    tmpl_ddns_client_hostname = amxd_object_findf(obj_ddns_client_hostname, ".^");
    when_null_trace(tmpl_ddns_client_hostname, exit, ERROR, "DynamicDNS.Client.Hostname template is NULL");
    obj_ddns_client = ddns_client_from_hostname(obj_ddns_client_hostname);
    when_null_trace(obj_ddns_client, exit, ERROR, "DynamicDNS.Client object is NULL");

    parameters = GET_ARG(event_data, "parameters");
    when_null(parameters, exit);

    new_domain = ddns_get_string_param(NULL, parameters, "Name");

    tmp_var = GET_ARG(parameters, "Enable");
    if(tmp_var != NULL) {
        enable_local = GET_BOOL(tmp_var, "to");
    } else {
        tmp_var = amxd_object_get_param_value(obj_ddns_client_hostname, "Enable");
        when_null_trace(tmp_var, exit, ERROR, "The enable could not be extracted.");
        enable_local = GET_BOOL(tmp_var, NULL);
    }
    enable = enable_local;

    enable_server = get_server_enable(obj_ddns_client, NULL);
    enable_global = amxd_object_get_value(bool, obj_ddns_client, "Enable", NULL);

    if(!enable_server || !enable_global) {
        enable = false;
    }

    client = (ddns_client_t*) obj_ddns_client->priv;
    if(client != NULL) {
        interface = amxc_string_get(&(client->linux_intf), 0);
        ip_interface = amxc_string_get(&(client->ip_ref_linux_intf), 0);
        client->changed_dm = true;
    }

    status = edit_ddns(obj_ddns_client, amxd_object_get_index(obj_ddns_client_hostname), new_domain, NULL, interface, ip_interface, NULL, NULL, enable, NULL);
    post_ddns_operations(obj_ddns_client, obj_ddns_client_hostname, status, enable_server, enable_global, enable_local);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}
