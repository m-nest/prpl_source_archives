/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include <amxo/amxo.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"

#include "mock.h"
#include "test_common.h"
#include "test_parameter_management.h"

void test_add_parameter(UNUSED void** state) {
    add_parameter("BulkData.Profile.simple_profile.", "Device.Firewall.Enable", "");
    amxd_object_t* instance = amxd_dm_findf(mock_get_dm(), "BulkData.Profile.simple_profile.Parameter.2.");
    assert_non_null(instance);
    assert_string_equal(amxc_var_constcast(cstring_t, amxd_object_get_param_value(instance, "Reference")), "Device.Firewall.Enable");
    assert_string_equal(amxc_var_constcast(cstring_t, amxd_object_get_param_value(instance, "Name")), "");
}

void test_report_name_empty(UNUSED void** state) {
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains Reference */
    assert_non_null(GET_ARG(last_report, "Device.Firewall.Enable"));
    /* Cleanup */
    amxc_var_delete(&last_report);
}

void test_report_name_not_empty(UNUSED void** state) {
    set_bulkdata_parameter_name("BulkData.Profile.simple_profile.Parameter.2.", "FWEnable");
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains Name as key instead of Reference */
    assert_null(GET_ARG(last_report, "Device.Firewall.Enable"));
    assert_non_null(GET_ARG(last_report, "FWEnable"));
    /* Cleanup */
    amxc_var_delete(&last_report);
}

void test_report_name_not_empty_reference_is_object(UNUSED void** state) {
    set_bulkdata_parameter_reference("BulkData.Profile.simple_profile.Parameter.2.", "Device.Firewall.Chain.1.Rule.1.");
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains Name as key instead of Reference */
    assert_non_null(GET_ARG(last_report, "FWEnable.Enable"));
    assert_non_null(GET_ARG(last_report, "FWEnable.Status"));
    /* Cleanup */
    amxc_var_delete(&last_report);
}

void test_reference_refused_wildcard_disabled(UNUSED void** state) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "BulkData.Profile.simple_profile.Parameter.2.");
    amxd_trans_set_value(cstring_t, &transaction, "Reference", "Device.Firewall.Chain.*.Enable");
    assert_int_not_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void test_name_empty_wilcard_enabled(UNUSED void** state) {
    /* Enable wildcard support */
    set_bulkdata_wildcard(true);
    /* Set Name empty and set Reference with wildcard */
    set_bulkdata_parameter_name("BulkData.Profile.simple_profile.Parameter.2.", "");
    set_bulkdata_parameter_reference("BulkData.Profile.simple_profile.Parameter.2.", "Device.Firewall.Chain.*.Enable");
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains resolved path according to Reference */
    assert_non_null(GET_ARG(last_report, "Device.Firewall.Chain.1.Enable"));
    assert_non_null(GET_ARG(last_report, "Device.Firewall.Chain.2.Enable"));
    /* Cleanup */
    amxc_var_delete(&last_report);

}

void test_name_not_empty_wilcard_enabled(UNUSED void** state) {
    /* Set Name and set Reference with wildcard */
    set_bulkdata_parameter_name("BulkData.Profile.simple_profile.Parameter.2.", "FWRuleEnable");
    set_bulkdata_parameter_reference("BulkData.Profile.simple_profile.Parameter.2.", "Device.Firewall.Chain.*.Rule.*.Enable");
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains Name with instances' numbers of resolved path according to Reference */
    assert_non_null(GET_ARG(last_report, "FWRuleEnable.1.1"));
    assert_non_null(GET_ARG(last_report, "FWRuleEnable.1.2"));
    assert_non_null(GET_ARG(last_report, "FWRuleEnable.2.1"));
    assert_non_null(GET_ARG(last_report, "FWRuleEnable.2.2"));
    assert_non_null(GET_ARG(last_report, "FWRuleEnable.2.3"));
    /* Cleanup */
    amxc_var_delete(&last_report);

}

void test_name_not_empty_wilcard_enabled_reference_is_object(UNUSED void** state) {
    /* Set Name and set Reference with wildcard */
    set_bulkdata_parameter_name("BulkData.Profile.simple_profile.Parameter.2.", "FWRule");
    set_bulkdata_parameter_reference("BulkData.Profile.simple_profile.Parameter.2.", "Device.Firewall.Chain.*.Rule.*.");
    /* Check we have a Push! notification */
    amxc_var_t* last_report = NULL;
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);
    /* Check last_report contains Name with instances' numbers of resolved path according to Reference */
    assert_non_null(GET_ARG(last_report, "FWRule.1.1.Enable"));
    assert_non_null(GET_ARG(last_report, "FWRule.1.1.Status"));
    assert_non_null(GET_ARG(last_report, "FWRule.1.2.Enable"));
    assert_non_null(GET_ARG(last_report, "FWRule.1.2.Status"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.1.Enable"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.1.Status"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.2.Enable"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.2.Status"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.3.Enable"));
    assert_non_null(GET_ARG(last_report, "FWRule.2.3.Status"));
    /* Cleanup */
    amxc_var_delete(&last_report);

}

void test_delete_parameter(UNUSED void** state) {
    delete_parameter("BulkData.Profile.simple_profile.Parameter.2.");
    amxd_object_t* instance = amxd_dm_findf(mock_get_dm(), "BulkData.Profile.simple_profile.Parameter.2.");
    assert_null(instance);
}

void test_object_hierarchy_format(UNUSED void** state) {
    amxc_var_t* last_report = NULL;
    /* Enable wildcard support */
    set_bulkdata_wildcard(true);
    /* Set JSON format to ObjectHierarchy*/
    set_bulkdata_report_format("BulkData.Profile.simple_profile.", "ObjectHierarchy");
    /* Set Name empty and set Reference with wildcard */
    set_bulkdata_parameter_name("BulkData.Profile.simple_profile.Parameter.2.", "");
    set_bulkdata_parameter_reference("BulkData.Profile.simple_profile.Parameter.2.", "Device.Firewall.Chain.*.Enable");
    /* Check we have a Push! notification */
    assert_int_equal(amxc_var_new(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, last_report), 0);
    go_to_future_ms(5000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, last_report), 0);

    /* Check last_report contains resolved path according to Reference */
    assert_non_null(GETP_ARG(last_report, "Device.Firewall.Chain.1.Enable"));
    assert_non_null(GETP_ARG(last_report, "Device.Firewall.Chain.2.Enable"));
    /* Cleanup */
    set_bulkdata_report_format("BulkData.Profile.simple_profile.", "NameValuePair"); //set back to NVP so this does not impact other tests
    amxc_var_delete(&last_report);

}