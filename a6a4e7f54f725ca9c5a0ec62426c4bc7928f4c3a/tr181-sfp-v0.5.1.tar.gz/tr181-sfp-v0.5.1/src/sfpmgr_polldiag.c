/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h> /* UNUSED */
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>     /* amxd_dm_findf() */
#include <amxp/amxp_timer.h>  /* amxp_timer_t */

/* Own headers */
#include "sfpmgr.h"
#include "sfpmgr_main.h"

#define SFPMGR_SFP_DIAG_POLL_TIMEOUT    2000 /*ms */

/**
 * @brief Periodically polls and updates the SFP cage and transceiver status.
 *
 * @param[in] timer The timer object for scheduling the next polling event.
 * @param[in] priv  A pointer to private data (unused).
 */
void sfpmgr_poll_sfp (amxp_timer_t* timer, UNUSED void* priv) {
    amxd_object_t* cage_object = NULL;
    amxd_object_t* sfp_object = NULL;

    for(int count = 1; count <= get_max_cage(); count++) {
        cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, count);
        when_null_trace(cage_object, exit, ERROR, "sfpmgr_poll_sfp: cage_object is null");

        sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, count);
        when_null_trace(sfp_object, exit, ERROR, "sfpmgr_poll_sfp: Transceiver is null");

        sfp_cage_t* cage_info = (sfp_cage_t*) cage_object->priv;
        when_null(cage_info, exit);

        if(cage_info->state != SFP_STATE_REMOVED) {
            SAH_TRACEZ_INFO(ME, "Updating SFP Cage %d periodically", cage_info->cage_id);
            sfpmgr_object_update(cage_object, sfp_object);
        } else {
            SAH_TRACEZ_INFO(ME, "Skipping because SFP Cage %d state", cage_info->state);
        }
    }
    amxp_timer_start(timer, SFPMGR_SFP_DIAG_POLL_TIMEOUT);
exit:
    return;
}
