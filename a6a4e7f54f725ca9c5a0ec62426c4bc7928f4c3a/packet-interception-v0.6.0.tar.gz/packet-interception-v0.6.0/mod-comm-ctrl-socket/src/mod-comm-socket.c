/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod-comm-socket.h"
#include "socket.h"

#define ME "socket"

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxm_module_t* mod;
    bool global_enable;
} socket_config_app_t;

static socket_config_app_t app;

amxd_dm_t* PRIVATE socket_get_dm(void) {
    return app.dm;
}

amxo_parser_t* PRIVATE socket_get_parser(void) {
    return app.parser;
}

amxm_module_t* PRIVATE socket_get_module(void) {
    return app.mod;
}

void socket_set_global_enable(bool enable) {
    app.global_enable = enable;
    socket_config_activate_deactivate_all(enable);
}

bool socket_get_global_enable(void) {
    return app.global_enable;
}

const char* object_da_string(amxd_object_t* const object, const char* const name) {
    const char* res = NULL;
    const amxc_var_t* var = NULL;

    when_null(object, out);
    when_str_empty(name, out);

    var = amxd_object_get_param_value(object, name);
    if(var != NULL) {
        res = amxc_var_constcast(cstring_t, var);
    }
out:
    return res;
}

static const char* read_status(status_t status) {
    switch(status) {
    case INTERCEPTION_DISABLED:
        return "Disabled";
    case INTERCEPTION_ERROR:
        return "Error";
    case INTERCEPTION_ERROR_MISCONFIG:
        return "Error_Misconfigured";
    case INTERCEPTION_ENABLED:
    default:
        return "Enabled";
    }
}

void set_status(common_t* c, status_t status) {
    c->status = status;

    when_null(amxd_object_get_param_def(c->object, "Status"), out);

    amxd_object_set_cstring_t(c->object, "Status", read_status(status));
out:
    return;
}

static void socket_config_main_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    amxm_shared_object_t* so = amxm_get_so("self");

    app.dm = dm;
    app.parser = parser;
    app.global_enable = amxd_object_get_value(bool, amxd_dm_findf(dm, "PacketInterception"), "Enable", NULL);

    amxm_module_register(&app.mod, so, ME);

    socket_config_init();
}

static void socket_config_main_exit(UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser) {
    app.dm = NULL;
    app.parser = NULL;
    app.mod = NULL;

    socket_config_cleanup();
}

int _socket_config_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_INFO(ME, "entry point [%s], reason: [%d]", __func__, reason);
    switch(reason) {
    case 0:     // START
        socket_config_main_init(dm, parser);
        break;
    case 1:     // STOP
        socket_config_main_exit(dm, parser);
        break;
    default:
        break;
    }

    return 0;
}
