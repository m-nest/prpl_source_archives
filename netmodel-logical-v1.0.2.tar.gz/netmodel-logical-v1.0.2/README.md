# netmodel-logical

This repo contains the client code to sync netmodel interfaces marked with the "logical" flag to Logical.Interface. instances