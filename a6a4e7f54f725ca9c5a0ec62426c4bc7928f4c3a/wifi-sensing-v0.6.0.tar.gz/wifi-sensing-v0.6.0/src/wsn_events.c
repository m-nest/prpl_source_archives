/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wsn_common.h"
#include "wsn_events.h"
#include "wsn_main.h"
#include "wsn_exchange.h"

#define ME "wsnevents"

/**
 * @brief wsn_event_causeToStr
 *
 * Converts event cause to char
 *
 * @param cause contains event reason
 * @return
 *     - event cause in char format
 */
static const char* wsn_event_causeToStr(wsn_exchange_termEvent_reason_e cause) {
    static const char* strings[] = { "STAUnavailable", "RadioUnavailable", "Completed", "STARejected", "ResourceUnavailable"};
    if(cause < SWL_ARRAY_SIZE(strings)) {
        return strings[cause];
    }
    return "";
}

/**
 * @brief wsn_events_cb
 *
 * Callback function for events that can terminate exchange once exchange is started
 *
 * @param sig_name the name of the signal
 * @param data the data of the signal
 * @param priv a pointer to some data, provided when connecting
 */
void wsn_events_cb(const char* const sig_name _UNUSED,
                   const amxc_var_t* const data,
                   void* const priv) {

    SAH_TRACEZ_IN(ME);

    wsn_eventInfo_t* info = (wsn_eventInfo_t*) priv;
    wsn_exchange_termEvent_reason_e evtcause;

    amxc_var_t notifMap;
    amxc_var_init(&notifMap);
    amxc_var_set_type(&notifMap, AMXC_VAR_ID_HTABLE);

    SAH_TRACEZ_INFO(ME, "ExchangeID from private event data is %u", info->exchange_id);
    SAH_TRACEZ_INFO(ME, "MACAddress from private event data is %s", info->staMac);
    SAH_TRACEZ_INFO(ME, "Radiopath from private event data is %s", info->radio_path);

    if(info->exchangeObj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Exchange object is NULL");
    }
    amxc_string_t path;
    amxc_var_t retvar;
    amxc_var_init(&retvar);
    amxc_string_init(&path, 0);
    bool radio_status = false;
    int rv = -1;

    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");

    amxc_string_setf(&path, "%sEnable", info->radio_path);
    rv = amxb_get(ctx, amxc_string_get(&path, 0), 0, &retvar, 0);

    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get object");
    }

    radio_status = GETP_BOOL(&retvar, "0.0.Enable");
    SAH_TRACEZ_INFO(ME, "Radio Enable is %d", radio_status);

    if((strcmp(GET_CHAR(data, "notification"), "Disassociation") == 0) && (radio_status == false)) {
        SAH_TRACEZ_INFO(ME, "Ignore Dissassociation event called when radio is down");
        goto exit;
    }

    if(strcmp(GET_CHAR(data, "notification"), "Disassociation") == 0) {
        SAH_TRACEZ_INFO(ME, "Setting cause to STAUnavailable");
        amxc_var_t* ret = amxc_var_get_key(data, "Data", AMXC_VAR_FLAG_DEFAULT);

        SAH_TRACEZ_INFO(ME, "MACAddress from event data is = %s", GET_CHAR(ret, "MACAddress"));
        if(swl_str_matches(info->staMac, GET_CHAR(ret, "MACAddress"))) {
            evtcause = WSN_EXCHANGE_TERM_EVENT_REASON_STA_UNAVAIL;
            amxc_var_add_key(cstring_t, &notifMap, "Cause", wsn_event_causeToStr(evtcause));
        } else {
            SAH_TRACE_WARNING("MACAddresses are not the same");
            goto exit;
        }
    } else if(strcmp(GET_CHAR(data, "notification"), "dm:object-changed") == 0) {
        SAH_TRACEZ_INFO(ME, "Setting cause to RadioUnavailable");
        evtcause = WSN_EXCHANGE_TERM_EVENT_REASON_RAD_UNAVAIL;
        amxc_var_add_key(cstring_t, &notifMap, "Cause", wsn_event_causeToStr(evtcause));

    } else {
        SAH_TRACEZ_WARNING(ME, "Invalid signal name");
        goto exit;
    }

    amxc_var_add_key(uint32_t, &notifMap, "ExchangeID", info->exchange_id);

    SAH_TRACEZ_INFO(ME, "Calling ExchangeTerminated event");
    amxd_object_trigger_signal(info->exchangeObj, "ExchangeTerminated!", &notifMap);
    amxc_var_clean(&notifMap);

    SAH_TRACEZ_INFO(ME, "Calling ExchangeTerminated event callback");
    amxc_var_t val;
    amxc_var_init(&val);
    amxc_var_set_type(&val, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, &val, "ExchangeID", info->exchange_id);
    wsn_exchangeTerminated_event_cb(NULL, &val, info->exchangeObj);
    amxc_var_clean(&val);

    rv = amxb_unsubscribe(ctx, "WiFi.AccessPoint.", wsn_events_cb, priv);

    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to unsubscribe to Disassociation event");
    } else {
        SAH_TRACEZ_INFO(ME, "Unsubscribed to Disassociation event");
    }

    rv = amxb_unsubscribe(ctx, info->radio_path, wsn_events_cb, priv);

    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to unsubscribe to object changed event");
    } else {
        SAH_TRACEZ_INFO(ME, "Unsubscribed to object-changed event");
    }

    free(info);
exit:
    amxc_var_clean(&notifMap);
    amxc_string_clean(&path);
    amxc_var_clean(&retvar);
    SAH_TRACEZ_OUT(ME);
    return;
}

