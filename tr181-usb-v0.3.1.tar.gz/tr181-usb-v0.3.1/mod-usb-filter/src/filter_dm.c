#include "filter_dm.h"
#include "device_list.h"
#include "mod_usb_filter.h"
#include "helpers.h"
#include "filter.h"

#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <string.h>

static usb_device_list_entry_t* get_device_list_entry(device_type_t t, const amxc_var_t* const data) {
    amxd_object_t* object = NULL;
    usb_device_list_entry_t* entry = NULL;
    const char* identifier = NULL;

    when_null(data, exit);
    object = amxd_dm_signal_get_object(get_dm(), data);
    when_null(object, exit);

    identifier = GET_CHAR(amxd_object_get_param_value(object, t == DEVICE ? "SysfsId" : "Alias"), NULL);
    when_str_empty(identifier, exit);

    entry = usb_device_list_find(t, identifier);

exit:
    return entry;
}

static void device_changed(device_type_t t, const amxc_var_t* const data) {
    amxc_var_t* changed_parameters = NULL;
    usb_device_list_entry_t* entry = NULL;

    when_null(data, exit);

    changed_parameters = GET_ARG(data, "parameters");
    when_null(changed_parameters, exit);

    entry = get_device_list_entry(t, data);
    when_null(entry, exit);

    if(amxc_var_get_key(changed_parameters, "Enable", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        entry->device->enable = GETP_BOOL(changed_parameters, "Enable.to");
    }
    if(amxc_var_get_key(changed_parameters, "DeviceClass", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        SAFE_DELETE(entry->device->device_class);
        entry->device->device_class = set_hex_value(GETP_CHAR(changed_parameters, "DeviceClass.to"));
    }
    if(amxc_var_get_key(changed_parameters, "DeviceSubClass", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        SAFE_DELETE(entry->device->device_subclass);
        entry->device->device_subclass = set_hex_value(GETP_CHAR(changed_parameters, "DeviceSubClass.to"));
    }
    if(amxc_var_get_key(changed_parameters, "DeviceProtocol", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        SAFE_DELETE(entry->device->device_protocol);
        entry->device->device_protocol = set_hex_value(GETP_CHAR(changed_parameters, "DeviceProtocol.to"));
    }
    if(amxc_var_get_key(changed_parameters, "ProductID", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        SAFE_DELETE(entry->device->product_id);
        if(t == DEVICE) {
            entry->device->product_id = int_to_hex_value(GETP_UINT32(changed_parameters, "ProductID.to"));
        } else if(t == ALLOWED_DEVICE) {
            entry->device->product_id = set_hex_value(GETP_CHAR(changed_parameters, "ProductID.to"));
        }
    }
    if(amxc_var_get_key(changed_parameters, "VendorID", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        SAFE_DELETE(entry->device->vendor_id);
        if(t == DEVICE) {
            entry->device->vendor_id = int_to_hex_value(GETP_UINT32(changed_parameters, "VendorID.to"));
        } else if(t == ALLOWED_DEVICE) {
            entry->device->vendor_id = set_hex_value(GETP_CHAR(changed_parameters, "VendorID.to"));
        }
    }
    if(amxc_var_get_key(changed_parameters, "Interfaces", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxc_string_t interfaces_str;
        amxc_llist_t interfaces_list;
        char* cleaned_up_interfaces = set_hex_value(GETP_CHAR(changed_parameters, "Interfaces.to"));

        amxc_string_init(&interfaces_str, 0);
        amxc_llist_init(&interfaces_list);

        amxc_string_set(&interfaces_str, cleaned_up_interfaces);
        amxc_string_split_to_llist(&interfaces_str, &interfaces_list, ',');

        // Cleanup old interfaces
        amxc_llist_for_each(it, entry->device->interface_list) {
            usb_interface_list_delete_item(it);
        }

        amxc_llist_for_each(it, &interfaces_list) {
            amxc_string_t* str_part = amxc_string_from_llist_it(it);
            usb_device_interface_t intf;
            usb_interface_list_entry_t* intf_entry = NULL;

            if(STR_EMPTY(amxc_string_get(str_part, 0))) {
                continue;
            }

            intf = create_usb_device_interface(amxc_string_get(str_part, 0));
            intf_entry = usb_interface_list_add(entry->device, &intf);
            if(intf_entry == NULL) {
                usb_device_interface_clean(&intf);
                continue;
            }
            amxc_llist_append(entry->device->interface_list, &(intf_entry->it));
            usb_device_interface_clean(&intf);
        }

        SAFE_DELETE(cleaned_up_interfaces);
        amxc_llist_clean(&interfaces_list, amxc_string_list_it_free);
        amxc_string_clean(&interfaces_str);
    }

exit:
    return;
}

/**
 * @brief Handles enable/disable of usb filter.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_filter_enable_changed(UNUSED const char* const sig_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxc_var_t* changed_parameters = NULL;
    SAH_TRACEZ_INFO(ME, "USB Filter enable changed");

    when_null(data, exit);
    changed_parameters = GET_ARG(data, "parameters");
    when_null(changed_parameters, exit);

    if(amxc_var_get_key(changed_parameters, "AllowAllDevices", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        set_allow_all_devices(GETP_BOOL(changed_parameters, "AllowAllDevices.to"));
        allow_devices_after_allowed_change();
    }

exit:
    return;
}

/**
 * @brief Handles a new usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_added(UNUSED const char* const sig_name,
                       const amxc_var_t* const data,
                       UNUSED void* const priv) {
    usb_device_list_entry_t* added_device_entry = NULL;
    amxd_object_t* template_object = NULL;

    SAH_TRACEZ_INFO(ME, "USB Device added");

    when_null(data, exit);
    template_object = amxd_dm_signal_get_object(get_dm(), data);
    when_null(template_object, exit);

    added_device_entry = usb_device_list_add(DEVICE, template_object, GET_ARG(data, "parameters"));

    allow_changed_device(added_device_entry);

exit:
    return;
}

/**
 * @brief Handles a change to an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_changed(UNUSED const char* const sig_name,
                         const amxc_var_t* const data,
                         UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "USB Device changed");

    when_null(data, exit);
    device_changed(DEVICE, data);
    allow_changed_device(get_device_list_entry(DEVICE, data));

exit:
    return;
}

/**
 * @brief Handles the removal of an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_removed(UNUSED const char* const sig_name,
                         const amxc_var_t* const data,
                         UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "USB Device removed");

    when_null(data, exit);
    usb_device_list_delete(DEVICE, GET_CHAR(GET_ARG(data, "parameters"), "SysfsId"));

exit:
    return;
}

/**
 * @brief Handles a new interface to an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_added(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    amxd_object_t* object = NULL;
    amxd_object_t* device_obj = NULL;
    usb_device_list_entry_t* entry = NULL;
    const char* sysfs_id = NULL;

    SAH_TRACEZ_INFO(ME, "USB Device Interface added");

    when_null(data, exit);
    object = amxd_dm_signal_get_object(get_dm(), data);
    when_null(object, exit);
    device_obj = amxd_object_findf(object, "^.^.^."); // Going from USB.USBHosts.Host.{i}.Device.{i}.Configuration.{i}.Interface.
                                                      // to USB.(...).Device.{i}.
    when_null(device_obj, exit);

    sysfs_id = GET_CHAR(amxd_object_get_param_value(device_obj, "SysfsId"), NULL);
    when_str_empty(sysfs_id, exit);

    entry = usb_device_list_find(DEVICE, sysfs_id);
    when_null(entry, exit);

    usb_interface_list_add_by_parameters(entry->device, GET_ARG(data, "parameters"));
    allow_changed_device(entry);

exit:
    return;
}

/**
 * @brief Handles a change to an existing usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_changed(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    amxd_object_t* object = NULL;
    amxd_object_t* device_obj = NULL;
    amxc_var_t new_params;
    usb_device_list_entry_t* entry = NULL;
    usb_device_interface_t old_intf;
    const char* sysfs_id = NULL;
    amxc_var_t* changed_parameters = NULL;

    amxc_var_init(&new_params);

    SAH_TRACEZ_INFO(ME, "USB Device Interface changed");

    when_null(data, exit);

    changed_parameters = GET_ARG(data, "parameters");
    when_null(changed_parameters, exit);

    object = amxd_dm_signal_get_object(get_dm(), data);
    when_null(object, exit);
    device_obj = amxd_object_findf(object, "^.^.^.^."); // Going from USB.USBHosts.Host.{i}.Device.{i}.Configuration.{i}.Interface.{i}.
                                                        // to USB.(...).Device.{i}.
    when_null(device_obj, exit);

    sysfs_id = GET_CHAR(amxd_object_get_param_value(device_obj, "SysfsId"), NULL);
    when_str_empty(sysfs_id, exit);

    entry = usb_device_list_find(DEVICE, sysfs_id);
    when_null(entry, exit);

    amxd_object_get_params(object, &new_params, amxd_dm_access_protected);

    // Copy new values in old_intf
    if(amxc_var_get_key(changed_parameters, "InterfaceClass", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        old_intf.interface_class = set_hex_value(GETP_CHAR(changed_parameters, "InterfaceClass.from"));
    } else {
        old_intf.interface_class = set_hex_value(GET_CHAR(&new_params, "InterfaceClass"));
    }
    if(amxc_var_get_key(changed_parameters, "InterfaceProtocol", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        old_intf.interface_protocol = set_hex_value(GETP_CHAR(changed_parameters, "InterfaceProtocol.from"));
    } else {
        old_intf.interface_protocol = set_hex_value(GET_CHAR(&new_params, "InterfaceProtocol"));
    }
    if(amxc_var_get_key(changed_parameters, "InterfaceSubClass", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        old_intf.interface_subclass = set_hex_value(GETP_CHAR(changed_parameters, "InterfaceSubClass.from"));
    } else {
        old_intf.interface_subclass = set_hex_value(GET_CHAR(&new_params, "InterfaceSubClass"));
    }

    usb_device_change_interface(entry->device, &old_intf, &new_params);
    usb_device_interface_clean(&old_intf);
    allow_changed_device(entry);

exit:
    amxc_var_clean(&new_params);
    return;
}

/**
 * @brief Handles the removal of an existing usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_removed(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    amxd_object_t* object = NULL;
    amxd_object_t* device_obj = NULL;
    usb_device_list_entry_t* entry = NULL;
    const char* sysfs_id = NULL;
    amxc_var_t* parameters = NULL;
    char* intf_class = NULL;
    char* intf_subclass = NULL;
    char* intf_protocol = NULL;

    SAH_TRACEZ_INFO(ME, "USB Device Interface removed");

    when_null(data, exit);

    parameters = GET_ARG(data, "parameters");
    when_null(parameters, exit);

    object = amxd_dm_signal_get_object(get_dm(), data);
    when_null(object, exit);
    device_obj = amxd_object_findf(object, "^.^.^."); // Going from USB.USBHosts.Host.{i}.Device.{i}.Configuration.{i}.Interface.
                                                      // to USB.(...).Device.{i}.
    when_null(device_obj, exit);

    sysfs_id = GET_CHAR(amxd_object_get_param_value(device_obj, "SysfsId"), NULL);
    when_str_empty(sysfs_id, exit);
    entry = usb_device_list_find(DEVICE, sysfs_id);
    when_null(entry, exit);

    intf_class = set_hex_value(GET_CHAR(parameters, "InterfaceClass"));
    intf_subclass = set_hex_value(GET_CHAR(parameters, "InterfaceSubClass"));
    intf_protocol = set_hex_value(GET_CHAR(parameters, "InterfaceProtocol"));

    usb_interface_list_delete_by_values(entry->device, intf_class, intf_subclass, intf_protocol);
    allow_changed_device(entry);

exit:
    SAFE_DELETE(intf_class);
    SAFE_DELETE(intf_subclass);
    SAFE_DELETE(intf_protocol);
}

/**
 * @brief Handles a new allowed usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_added(UNUSED const char* const sig_name,
                               const amxc_var_t* const data,
                               UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "USB Allowed Device added");

    when_null(data, exit);
    usb_device_list_add(ALLOWED_DEVICE, NULL, GET_ARG(data, "parameters"));

    allow_devices_after_allowed_change();

exit:
    return;
}

/**
 * @brief Handles a change to an existing allowed usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_changed(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "USB Allowed Device changed");

    when_null(data, exit);
    device_changed(ALLOWED_DEVICE, data);

    allow_devices_after_allowed_change();

exit:
    return;
}

/**
 * @brief Handles the removal of an existing allowed usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_removed(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "USB Allowed Device removed");

    when_null(data, exit);
    usb_device_list_delete(ALLOWED_DEVICE, GET_CHAR(GET_ARG(data, "parameters"), "Alias"));

    allow_devices_after_allowed_change();

exit:
    return;
}
