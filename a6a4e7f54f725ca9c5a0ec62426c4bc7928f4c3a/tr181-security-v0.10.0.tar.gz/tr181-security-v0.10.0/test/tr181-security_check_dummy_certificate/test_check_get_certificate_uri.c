/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <cmocka.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include "security.h"

#include "test_check_get_certificate_uri.h"


void test_check_get_certificate_uri(UNUSED void** state) {
    amxd_object_t* cert_inst = NULL;
    amxc_var_t security_var;
    amxd_status_t status = amxd_status_ok;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&security_var);
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    cert_inst = amxd_dm_findf(security_get_dm(), "Security.Certificate.1.");
    assert_non_null(cert_inst);

    status = amxd_object_get_params(cert_inst, &security_var, amxd_dm_access_private);
    assert_int_equal(status, 0);

    assert_int_equal(amxd_object_invoke_function(cert_inst,
                                                 "GetCertificateURI",
                                                 &args,
                                                 &ret),
                     amxd_status_ok);

    assert_string_equal(GET_CHAR(&args, "CertificateURI"), GET_CHAR(&security_var, "CertificateURI"));
    assert_string_equal(GET_CHAR(&args, "PrivateKeyURI"), GET_CHAR(&security_var, "PrivateKeyURI"));

    amxc_var_clean(&security_var);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}
