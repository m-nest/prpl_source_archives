/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dmz/dm_dmz.h"
#include "dmz/dmz.h"
#include "nat/masquerade.h" // for is_nat_enabled_interface
#include "usp_utils.h"
#include "firewall.h"       // for fw_get_dm
#include "init_cleanup.h"
#include "profiling/profiling.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>
#include "nat/masquerade.h"
#include "logs/logs.h"

#define ME "dmz"

const char* dmz_get_lan_address(void) {
    amxd_object_t* obj = amxd_dm_findf(fw_get_dm(), "Firewall.DMZ.");
    firewall_interface_t* fwiface = (firewall_interface_t*) obj->priv;
    const char* address = NULL;

    when_null_trace(fwiface, exit, ERROR, "DMZ template has no private data");

    address = address_first_ipv4_char(&fwiface->address);

exit:
    return address;
}

static void dmz_set_interface(dmz_t* dmz, char* interface) {
    firewall_interface_t* fwiface = &dmz->common.src_fwiface;
    if(!STRING_EMPTY(interface)) {
        if(!is_nat_enabled_interface(interface)) {
            init_firewall_interface(fwiface);
            fwiface->netdev_required = true;
            fwiface->addr_required = true;
            common_set_status(&dmz->common, FIREWALL_ERROR);
            SAH_TRACEZ_WARNING(ME, "Interface needs to have nat enabled");
            return;
        }
        open_ip_address_query(interface, IPv4, "ipv4", fwiface);
    } else {
        init_firewall_interface(fwiface);
        fwiface->netdev_required = true;
        fwiface->addr_required = true;
    }
    free(interface);
}

static void dmz_lan_interface_changed(firewall_interface_t* fwiface) {
    FW_PROFILING_IN(TRACE_CALLBACK);
    amxd_object_t* templ = amxd_dm_findf(fw_get_dm(), "Firewall.DMZ.");
    (void) fwiface; // when tracing is disabled, variable is not used anymore

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        common_t* common = instance->priv;
        if(common == NULL) {
            continue;
        }
        common->flags = FW_MODIFIED;
    }

    dmz_implement_changes();
    FW_PROFILING_OUT();
}

static void dmz_template_init(void) {
    amxd_object_t* object = amxd_dm_findf(fw_get_dm(), "Firewall.DMZ.");
    firewall_interface_t* fwiface = NULL;
    amxc_string_t lan_interface;
    bool ret = false;

    amxc_string_init(&lan_interface, 0);

    when_null_trace(object, exit, ERROR, "Object is NULL");
    when_false(object->priv == NULL, exit);

    ip_lan_interface_objpath(&lan_interface);
    when_str_empty_trace(amxc_string_get(&lan_interface, 0), exit, ERROR, "DMZ[%s] LAN interface not defined", OBJECT_NAMED);

    fwiface = calloc(1, sizeof(firewall_interface_t));
    when_null(fwiface, exit);

    init_firewall_interface(fwiface);

    fwiface->query_result_changed = dmz_lan_interface_changed;
    ret = open_ip_address_query(amxc_string_get(&lan_interface, 0), IPv4, "ipv4", fwiface);
    when_false(ret, exit);

    object->priv = fwiface;
    ret = true;

exit:
    amxc_string_clean(&lan_interface);
    if(!ret && (fwiface != NULL)) {
        clean_firewall_interface(fwiface);
        free(fwiface);
    }
    return;
}

static bool dmz_init(amxd_object_t* object) {
    dmz_t* dmz = NULL;
    bool res = false;

    when_null_trace(object, exit, ERROR, "Object is NULL");
    when_false(object->priv == NULL, exit);

    dmz = dmz_create(object);
    when_null(dmz, exit);

    dmz_set_interface(dmz, refparam_to_objpath(object, "Interface"));

    log_init(object, &dmz->common.folders.log, &dmz->common.src_fwiface, !EXCLUDE_SRC_INTERFACE, NULL, !EXCLUDE_DST_INTERFACE, !USE_LOG_CONTROLLER_INTERFACE,
             log_get_dm_enable_param(object, NULL, NULL), log_get_dm_controller_param(object, NULL, NULL), TARGET_ACCEPT);

    //Initialize reverse log without subscribing
    log_init(object, &dmz->reverse.log, NULL, !EXCLUDE_DST_INTERFACE, &dmz->common.src_fwiface, !EXCLUDE_SRC_INTERFACE, !USE_LOG_CONTROLLER_INTERFACE,
             log_get_dm_enable_param(object, NULL, NULL), log_get_dm_controller_param(object, NULL, NULL), TARGET_ACCEPT);

    res = true;

exit:
    return res;
}

void _dmz_added(UNUSED const char* const sig_name,
                const amxc_var_t* const event_data,
                UNUSED void* const priv) {
    FW_PROFILING_IN(TRACE_DM_EVENT);
    amxd_object_t* templ = amxd_dm_signal_get_object(fw_get_dm(), event_data);
    amxd_object_t* object = amxd_object_get_instance(templ, NULL, GET_UINT32(event_data, "index"));

    when_null(object, exit);

    when_false(dmz_init(object), exit);
    dmz_implement_changes();
exit:
    FW_PROFILING_OUT();
    return;
}

void _dmz_changed(UNUSED const char* const sig_name,
                  const amxc_var_t* const event_data,
                  UNUSED void* const priv) {
    FW_PROFILING_IN(TRACE_DM_EVENT);
    amxd_object_t* object = amxd_dm_signal_get_object(fw_get_dm(), event_data);
    dmz_t* dmz = NULL;
    amxc_var_t* params = GET_ARG(event_data, "parameters");
    amxc_var_t* var = NULL;

    when_null(object, exit);
    when_null(object->priv, exit);
    dmz = (dmz_t*) object->priv;

    dmz->common.flags = FW_MODIFIED;

    var = GET_ARG(params, "Interface");
    if(var != NULL) {
        dmz_set_interface(dmz, refparam_to_objpath(object, "Interface"));
    }

    update_dmz_logs(dmz, NULL, event_data, NULL);

    dmz_implement_changes();

exit:
    FW_PROFILING_OUT();
    return;
}

static int _dm_dmz_init(UNUSED amxd_object_t* templ, amxd_object_t* object, UNUSED void* priv) {
    dmz_init(object);
    return amxd_status_ok;
}

void dm_dmz_init(void) {
    FW_PROFILING_IN(TRACE_INTERNAL);
    dmz_template_init();

    amxd_object_for_all(amxd_dm_findf(fw_get_dm(), "Firewall"), ".DMZ.*.", _dm_dmz_init, NULL);
    dmz_implement_changes();
    FW_PROFILING_OUT();
}

/**
   @brief
   Callback function to update the LOG.

   @param[in] templ The root object.
   @param[in] object The object to update.
   @param[in] priv Pointer to the common internal structure.

   @return
   0 if success, 1 if failed.
 */
int dmz_log_update_cb(UNUSED amxd_object_t* templ, amxd_object_t* object, void* priv) {
    FW_PROFILING_IN(TRACE_CALLBACK);
    const amxc_var_t* data_log = (amxc_var_t*) priv;
    dmz_t* dmz = NULL;

    when_null_trace(object, exit, ERROR, "Object is NULL");
    dmz = (dmz_t*) object->priv;
    when_null_trace(dmz, exit, ERROR, "DMZ[%s] is NULL", OBJECT_NAMED);

    if(update_dmz_logs(NULL, object, NULL, data_log)) {
        dmz->common.flags = FW_MODIFIED;
        dmz_implement_changes();
    }

exit:
    FW_PROFILING_OUT();
    return amxd_status_ok;
}