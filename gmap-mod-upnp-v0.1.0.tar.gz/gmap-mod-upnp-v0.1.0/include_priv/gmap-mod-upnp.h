/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef UPNP_RESOLVE_H
#define UPNP_RESOLVE_H

#ifdef __cplusplus
extern "C"
{
#endif

/**
   @defgroup gmap_mod_upnp Generic upnp functions
   @defgroup gmap_upnp_service functions for upnp services

   Core functions for managing the gmap upnp.
 */

#include <amxc/amxc.h>
#include <amxc/amxc_string.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <amxs/amxs.h>

#include <gmap/gmap.h>
#include <gmap/extensions/ip/gmap_ext_ip_devices.h>
#include <gmap/gmap_devices.h>
#include <gmap/gmap_devices_flags.h>
#include <gmap/gmap_device.h>

#define ME "gmap_upnp"
#define PRIO 1

/**
 * @ingroup gmap_mod_upnp
 * @brief Device entry stored in the hash table.
 *
 * This structure represents a device-level context entry used in a hash table.
 * It maintains synchronization contexts related to device discovery and
 * management, as well as a list of associated service contexts.
 */
typedef struct _ctx_htable_device_entry {
    amxc_htable_it_t it;                    /**< Hash table iterator */
    amxs_sync_ctx_t* ctx_device;            /**< Synchronization context for the device */
    amxs_sync_ctx_t* ctx_discovery;         /**< Synchronization context for device discovery */
    amxb_subscription_t* discover_device_subscription;
    /**< Subscription used to discover devices */
    amxc_llist_t ctx_services_llist;        /**< List of service synchronization contexts */
    char* device_name;                      /**< Device name or identifier */
    int32_t index;                          /**< Device index */
} ctx_htable_device_entry_t;

/**
 * @ingroup gmap_mod_upnp
 * @brief Service synchronization context list entry.
 *
 * This structure represents an entry in a linked list that holds
 * service-level synchronization contexts associated with a device.
 */
typedef struct _sync_ctx_htable_entry {
    amxc_llist_it_t it;                    /**< Linked list iterator */
    amxs_sync_ctx_t* ctx_service;          /**< Synchronization context for the service */
    char* device_name;                     /**< Name of the parent device */
    int32_t gmap_index;                    /**< GMAP service index */
    int32_t upnp_index;                    /**< UPnP service index */
} sync_ctx_service_llist_entry_t;

/**
   @ingroup gmap_mod_upnp
   @brief Query list entry.

   This structure represents a linked list entry containing a query
   object used during device or service discovery.
 */
typedef struct _query_llist_entry {
    amxc_llist_it_t it;                     /**< Linked list iterator */
    gmap_query_t* query;                    /**< Query object */
} query_llist_entry_t;

/**
   @ingroup gmap_mod_upnp

   @brief UPNP module entry point.

   Handles subscribe/unsubscribe operations triggered by the data model
   or parser during module initialization or cleanup.

   @param reason  Operation reason:
                 - 0: subscribe
                 - 1: unsubscribe
   @param dm      Pointer to the data model. Must not be NULL.
   @param parser  Pointer to the parser object. Must not be NULL.

   @return 1 on success, -1 on error.
 */
int _gmap_upnp_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
   @ingroup gmap_mod_upnp

   @brief Cleans and removes a device entry from the internal table.

   PRIVATE: For internal module use only.

   @param key  Key identifying the device entry.
   @param it   Iterator pointing to the entry inside the hash table.

   @return None
 */
void PRIVATE mod_upnp_clean_device_entry(const char* key, amxc_htable_it_t* it);

/**
   @ingroup gmap_mod_upnp

   @brief Cleans and removes an entry from the sync list.

   PRIVATE: For internal module use only.

   @param it  Iterator pointing to the list entry to remove.

   @return None
 */
void PRIVATE mod_upnp_clean_sync_entry(amxc_llist_it_t* it);

/**
   @ingroup gmap_mod_upnp

   @brief Cleans and removes a query entry.

   PRIVATE: For internal module use only.

   @param it  Iterator pointing to the query entry to remove.

   @return None
 */
void PRIVATE mod_upnp_clean_query_entry(amxc_llist_it_t* it);

/**
   @ingroup gmap_mod_upnp

   @brief Retrieves the internal UPNP entry table.

   PRIVATE: For internal module use only.

   @param None
   @return Pointer to the internal hash table of device/service entries.
 */
amxc_htable_t* PRIVATE mod_upnp_get_entry_table(void);

/**
   @ingroup gmap_mod_upnp

   @brief Retrieves the internal UPNP query list.

   PRIVATE: For internal module use only.

   @param None
   @return Pointer to the internal linked list of pending queries.
 */
amxc_llist_t* PRIVATE mod_upnp_get_query_list(void);

/**
   @ingroup gmap_upnp_service

   @brief Adds a UPNP device instance.

   PRIVATE: For internal module use only.

   @param sig_name  Signal name triggering the addition. Must not be NULL.
   @param data      Pointer to the UPNP device data. Must not be NULL.
   @param priv      Module-private data pointer (optional).

   @return None
 */
void PRIVATE upnp_add_device_instance(const char* const sig_name,
                                      const amxc_var_t* const data,
                                      void* const priv);

/**
   @ingroup gmap_upnp_service

   @brief Adds a UPNP service instance.

   PRIVATE: For internal module use only.

   @param sig_name  Signal name triggering the addition. Must not be NULL.
   @param data      Pointer to the UPNP service data. Must not be NULL.
   @param priv      Module-private data pointer (optional).

   @return None
 */
void PRIVATE upnp_add_service_instance(const char* const sig_name,
                                       const amxc_var_t* const data,
                                       void* const priv);

/**
   @ingroup gmap_upnp_service

   @brief Removes a UPNP device instance.

   PRIVATE: For internal module use only.

   @param sig_name  Signal name triggering the removal. Must not be NULL.
   @param data      Pointer to the UPNP device data. Must not be NULL.
   @param priv      Module-private data pointer (optional).

   @return None
 */
void PRIVATE upnp_remove_deviceinstance(const char* const sig_name,
                                        const amxc_var_t* const data,
                                        void* const priv);

/**
   @ingroup gmap_upnp_service

   @brief Removes a UPNP service instance.

   PRIVATE: For internal module use only.

   @param sig_name  Signal name triggering the removal. Must not be NULL.
   @param data      Pointer to the UPNP service data. Must not be NULL.
   @param priv      Module-private data pointer (optional).

   @return None
 */
void PRIVATE upnp_remove_serviceinstance(const char* const sig_name,
                                         const amxc_var_t* const data,
                                         void* const priv);

#ifdef __cplusplus
}
#endif

#endif  /* UPNP_RESOLVE_H */
