/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#if !defined(__CTHULHU_SYSLOG_OBJECT_H__)
#define __CTHULHU_SYSLOG_OBJECT_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Initialize the syslog object
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int syslog_object_init(void);

/**
 * @brief Clean up and tear down the syslog object
 */
void syslog_object_teardown(void);

/**
 * @brief Delete a syslog object at the specified path
 *
 * @param object_path Path to the syslog object to be deleted
 * @return int Returns 0 on success, non-zero on failure
 */
int syslog_object_del(const char* object_path);

/**
 * @brief Configure a syslog source with the given parameters
 *
 * @param alias Unique identifier for the syslog source
 * @param socket_path Path to the socket used for logging
 * @param enable Flag to enable/disable the source
 * @return char* Returns a string reference to the source path on success, NULL on failure
 */
char* syslog_source_configure(const char* alias,
                              const char* socket_path,
                              bool enable);

/**
 * @brief Enable or disable a configured syslog source
 *
 * @param alias Identifier of the syslog source
 * @param enable true to enable, false to disable
 * @return int Returns 0 on success, non-zero on failure
 */
int syslog_source_enable(const char* alias,
                         bool enable);

/**
 * @brief Get the socket path for a configured syslog source
 *
 * @param alias Identifier of the syslog source
 * @return char* Returns the socket path string, NULL if not found
 */
char* syslog_socket_path_get(const char* alias);

/**
 * @brief Get the vendor log file reference for a syslog source
 *
 * @param alias Identifier of the syslog source
 * @return char* Returns the vendor log file reference string, NULL if not found
 */
char* syslog_vendorlogfileref_get(const char* alias);

/**
 * @brief Configure a syslog template
 *
 * @param alias Unique identifier for the template
 * @param template The template string to use
 * @return char* Returns a string reference on success, NULL on failure
 */
char* syslog_template_configure(const char* alias,
                                const char* template);

/**
 * @brief Configure a syslog action
 *
 * @param alias Unique identifier for the action
 * @param source_ref Reference to the configured source
 * @param template_ref Reference to the configured template
 * @param log_path Path where the logs should be written
 * @return char* Returns a string reference to the action path on success, NULL on failure
 */
char* syslog_action_configure(const char* alias,
                              const char* source_ref,
                              const char* template_ref,
                              const char* log_path);

/**
 * @brief Subscribe to syslog events for a specific object
 *
 * @param object_path Path to the object to subscribe to
 * @param expression Event expression to filter events
 * @param slot_cb Callback function to handle events
 * @param priv Private data passed to the callback
 * @return int Returns 0 on success, non-zero on failure
 */
int syslog_subscribe(const char* object_path,
                     const char* expression,
                     amxp_slot_fn_t slot_cb,
                     void* priv);

/**
 * @brief Unsubscribe a callback for syslog events
 *
 * @param object_path Path to the object to unsubscribe from
 * @param slot_cb Callback function used during subscription
 * @param priv Private data used during subscription
 * @return int Returns 0 on success, non-zero on failure
 */
int syslog_unsubscribe(const char* object_path,
                       amxp_slot_fn_t slot_cb,
                       void* priv);

#ifdef __cplusplus
}
#endif

#endif // __CTHULHU_SYSLOG_OBJECT_H__