/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__AMXB_PRIV_H__)
#define __AMXB_PRIV_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include "amxb_priv_stats.h"

typedef struct _sub {
    amxc_llist_it_t it;
    amxb_subscription_t data;
} amxb_sub_t;

typedef struct _req {
    amxc_llist_it_t it;
    amxb_request_t data;
    bool local;
    bool in_flight;
    bool closed;
    bool wait;
} amxb_req_t;

#define amxb_is_valid_be_func(ft, member, ptr) \
    (ft != NULL && offsetof(amxb_be_funcs_t, member) < ft->size && ptr != NULL)

void PRIVATE amxb_dm_event_to_object_event(const char* const sig_name,
                                           const amxc_var_t* const data,
                                           void* const priv);

amxd_object_t* amxb_fetch_local_object(amxb_bus_ctx_t* ctx,
                                       const char* object);

bool PRIVATE amxb_is_local_object(amxb_bus_ctx_t* ctx,
                                  const char* obj_path);

int PRIVATE amxb_subscribe_no_check(amxb_bus_ctx_t* const ctx,
                                    const char* object,
                                    const char* expression,
                                    amxp_slot_fn_t slot_cb,
                                    void* priv);

int PRIVATE amxb_subscription_remove(amxb_subscription_t* subscription);

int PRIVATE amxb_set_impl(amxb_bus_ctx_t* const bus_ctx,
                          const char* object,
                          uint32_t flags,
                          amxc_var_t* values,
                          amxc_var_t* ovalues,
                          amxc_var_t* ret,
                          int timeout);

int PRIVATE amxb_follow_reference(amxb_bus_ctx_t* const bus_ctx,
                                  amxd_path_t* reference,
                                  int timeout);

uint32_t PRIVATE amxb_be_get_capabilities(amxb_bus_ctx_t* bus_ctx);

int PRIVATE amxb_uri_parse(const char* uri,
                           char** scheme,
                           char** host,
                           char** port,
                           char** path);

PRIVATE
void amxb_build_path(amxc_var_t* info, amxd_path_t* path);

#ifdef __cplusplus
}
#endif

#endif // __AMXB_PRIV_H__
