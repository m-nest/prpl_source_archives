/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_util.h>

#include <amxrt/amxrt.h>

#include "dmm.h"
#include "dmm_trie.h"

#define TEST_COMMON_FOLDER "../test/common"

static void assert_node_no_terminals(const TreeNode* node) {
    assert_true(amxc_htable_is_empty(&node->terminals));
    assert_true(amxc_htable_is_empty(&node->parameters));
    assert_true(amxc_htable_is_empty(&node->functions));
    assert_true(amxc_htable_is_empty(&node->events));
}


static void assert_node_no_nonterminals(const TreeNode* node) {
    assert_true(amxc_htable_is_empty(&node->nonterminals));

}

static void assert_node_empty(const TreeNode* node) {
    assert_node_no_nonterminals(node);
    assert_node_no_terminals(node);
}

void test_can_parse_hide_mapping(UNUSED void** state) {

    amxc_var_t* hide_mapping = amxut_util_read_json_from_file(TEST_COMMON_FOLDER "/mapping/hide.json");
    assert_non_null(hide_mapping);

    amxc_var_t* config = amxrt_get_config();
    assert_non_null(config);
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_HIDE, hide_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    assert_int_equal(init_tree(), 0);
    assert_int_equal(parse_mapping(), 0);

    // forward (should be empty)
    {
        const TreeNode* wifi_mapped = find_exact_node(&forward_tree, "WiFiMapped", NULL);
        assert_null(wifi_mapped);
    }

    // backward trie (should be filled)
    {
        const TreeNode* wifi_mapped = find_exact_node(&backward_tree, "WiFiMapped", NULL);
        assert_non_null(wifi_mapped);

        //WiFiMapped.Foo.
        {
            const TreeNode* foo = find_exact_node(wifi_mapped, "Foo", NULL);
            assert_non_null(foo);
            assert_int_equal(foo->action, NodeAction_Hide);

            assert_node_empty(foo);
        }

        //WiFiMapped.Bar.
        {
            const TreeNode* bar = find_exact_node(wifi_mapped, "Bar", NULL);
            assert_non_null(bar);
            assert_int_equal(bar->action, NodeAction_Empty);

            assert_int_equal(amxc_htable_size(&bar->terminals), 3);
            assert_int_equal(amxc_htable_size(&bar->nonterminals), 1);
            assert_int_equal(amxc_htable_size(&bar->functions), 1);
            assert_int_equal(amxc_htable_size(&bar->events), 1);
            assert_int_equal(amxc_htable_size(&bar->parameters), 1);

            //WiFiMapped.Bar.Parameter
            {
                const TreeNode* parameter = find_exact_node(bar, NULL, "Parameter");
                assert_non_null(parameter);
                assert_int_equal(parameter->action, NodeAction_Hide);

                assert_node_empty(parameter);
            }
            //WiFiMapped.Bar.Function()
            {
                const TreeNode* function = find_exact_node(bar, NULL, "Function()");
                assert_non_null(function);
                assert_int_equal(function->action, NodeAction_Hide);

                assert_node_empty(function);
            }
            //WiFiMapped.Bar.Event!
            {
                const TreeNode* event = find_exact_node(bar, NULL, "Event!");
                assert_non_null(event);
                assert_int_equal(event->action, NodeAction_Hide);

                assert_node_empty(event);
            }
            //WiFiMapped.Bar.Object.
            {
                const TreeNode* object = find_exact_node(bar, "Object.", NULL);
                assert_non_null(object);
                assert_int_equal(object->action, NodeAction_Hide);

                assert_node_empty(object);
            }

        }

    }

    amxc_var_delete(&hide_mapping);
    clean_tree();
}

static void assert_node_renamed(const TreeNode* node, const char* rename_to) {
    assert_int_equal(node->action, NodeAction_Rename);
    assert_non_null(node->rename_to);
    assert_string_equal(amxc_string_get(node->rename_to, 0), rename_to);
}


void test_can_parse_rename_mapping(UNUSED void** state) {

    amxc_var_t* rename_mapping = amxut_util_read_json_from_file(TEST_COMMON_FOLDER "/mapping/rename.json");
    assert_non_null(rename_mapping);

    amxc_var_t* config = amxrt_get_config();
    assert_non_null(config);
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_RENAME, rename_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    assert_int_equal(init_tree(), 0);
    assert_int_equal(parse_mapping(), 0);

    // forward trie (should be filled)
    {
        const TreeNode* wifi_mapped = find_exact_node(&forward_tree, "WiFiMapped", NULL);
        assert_non_null(wifi_mapped);

        //WiFiMapped.Foo.
        {
            const TreeNode* foo = find_exact_node(wifi_mapped, "Foo1", NULL);
            assert_non_null(foo);
            assert_node_renamed(foo, "Foo.");
            assert_node_empty(foo);
        }
        //WiFiMapped.Bar.
        {
            const TreeNode* bar = find_exact_node(wifi_mapped, "Bar", NULL);
            assert_non_null(bar);
            assert_int_equal(bar->action, NodeAction_Empty);

            assert_int_equal(amxc_htable_size(&bar->terminals), 3);
            assert_int_equal(amxc_htable_size(&bar->nonterminals), 1);
            assert_int_equal(amxc_htable_size(&bar->functions), 1);
            assert_int_equal(amxc_htable_size(&bar->events), 1);
            assert_int_equal(amxc_htable_size(&bar->parameters), 1);

            //WiFiMapped.Bar.Parameter
            {
                const TreeNode* parameter = find_exact_node(bar, NULL, "Parameter1");
                assert_non_null(parameter);
                assert_node_renamed(parameter, "Parameter");
                assert_node_empty(parameter);
            }
            //WiFiMapped.Bar.Function()
            {
                const TreeNode* function = find_exact_node(bar, NULL, "Function1()");
                assert_non_null(function);
                assert_node_renamed(function, "Function()");
                assert_node_empty(function);
            }
            //WiFiMapped.Bar.Event!
            {
                const TreeNode* event = find_exact_node(bar, NULL, "Event1!");
                assert_non_null(event);
                assert_node_renamed(event, "Event!");
                assert_node_empty(event);
            }
            //WiFiMapped.Bar.Object.
            {
                const TreeNode* object = find_exact_node(bar, "Object1.", NULL);
                assert_non_null(object);
                assert_node_renamed(object, "Object.");
                assert_node_empty(object);
            }

        }

    }

    // backward trie (should be filled)
    {
        const TreeNode* wifi_mapped = find_exact_node(&backward_tree, "WiFiMapped", NULL);
        assert_non_null(wifi_mapped);

        //WiFiMapped.Foo.
        {
            const TreeNode* foo = find_exact_node(wifi_mapped, "Foo", NULL);
            assert_non_null(foo);
            assert_node_renamed(foo, "Foo1.");
            assert_node_empty(foo);
        }
        //WiFiMapped.Bar.
        {
            const TreeNode* bar = find_exact_node(wifi_mapped, "Bar", NULL);
            assert_non_null(bar);
            assert_int_equal(bar->action, NodeAction_Empty);

            assert_int_equal(amxc_htable_size(&bar->terminals), 3);
            assert_int_equal(amxc_htable_size(&bar->nonterminals), 1);
            assert_int_equal(amxc_htable_size(&bar->functions), 1);
            assert_int_equal(amxc_htable_size(&bar->events), 1);
            assert_int_equal(amxc_htable_size(&bar->parameters), 1);

            //WiFiMapped.Bar.Parameter
            {
                const TreeNode* parameter = find_exact_node(bar, NULL, "Parameter");
                assert_non_null(parameter);
                assert_node_renamed(parameter, "Parameter1");
                assert_node_empty(parameter);
            }
            //WiFiMapped.Bar.Function()
            {
                const TreeNode* function = find_exact_node(bar, NULL, "Function()");
                assert_non_null(function);
                assert_node_renamed(function, "Function1()");
                assert_node_empty(function);
            }
            //WiFiMapped.Bar.Event!
            {
                const TreeNode* event = find_exact_node(bar, NULL, "Event!");
                assert_non_null(event);
                assert_node_renamed(event, "Event1!");
                assert_node_empty(event);
            }
            //WiFiMapped.Bar.Object.
            {
                const TreeNode* object = find_exact_node(bar, "Object.", NULL);
                assert_non_null(object);
                assert_node_renamed(object, "Object1.");
                assert_node_empty(object);
            }

        }

    }

    amxc_var_delete(&rename_mapping);
    clean_tree();
}

void test_can_parse_rename_table_mapping(UNUSED void** state) {

    amxc_var_t* rename_mapping = amxut_util_read_json_from_file(TEST_COMMON_FOLDER "/mapping/rename_table.json");
    assert_non_null(rename_mapping);

    amxc_var_t* config = amxrt_get_config();
    assert_non_null(config);
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_RENAME, rename_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    assert_int_equal(init_tree(), 0);
    assert_int_equal(parse_mapping(), 0);

    // forward trie (should be filled)
    {
        const TreeNode* wifi_mapped = find_exact_node(&forward_tree, "WiFiMapped", NULL);
        assert_non_null(wifi_mapped);

        //WiFiMapped.Table1.{i}.
        {
            const TreeNode* table = find_exact_node(wifi_mapped, "Table1", NULL);
            assert_non_null(table);
            assert_node_renamed(table, "Table.");
            assert_true(table->is_multiinstance);
            assert_node_no_terminals(table);

            //WiFiMapped.Table1.{i}.Object1.
            {
                const TreeNode* object = find_exact_node(table, "Object1", NULL);
                assert_non_null(object);
                assert_node_renamed(object, "Object.");
                assert_false(object->is_multiinstance);
                assert_node_empty(object);
            }

        }

    }

    // backward trie (should be filled)
    {
        const TreeNode* wifi_mapped = find_exact_node(&backward_tree, "WiFiMapped", NULL);
        assert_non_null(wifi_mapped);

        //WiFiMapped.Table.{i}.
        {
            const TreeNode* table = find_exact_node(wifi_mapped, "Table", NULL);
            assert_non_null(table);
            assert_node_renamed(table, "Table1.");
            assert_true(table->is_multiinstance);
            assert_node_no_terminals(table);

            //WiFiMapped.Table.{i}.Object.
            {
                const TreeNode* object = find_exact_node(table, "Object", NULL);
                assert_non_null(object);
                assert_node_renamed(object, "Object1.");
                assert_false(object->is_multiinstance);
                assert_node_empty(object);
            }

        }

    }

    amxc_var_delete(&rename_mapping);
    clean_tree();
}



int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_can_parse_hide_mapping),
        cmocka_unit_test(test_can_parse_rename_mapping),
        cmocka_unit_test(test_can_parse_rename_table_mapping),
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
