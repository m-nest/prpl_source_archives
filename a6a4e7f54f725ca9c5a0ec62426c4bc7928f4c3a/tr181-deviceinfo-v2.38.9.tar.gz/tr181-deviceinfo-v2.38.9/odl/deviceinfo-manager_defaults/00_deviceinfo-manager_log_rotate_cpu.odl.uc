{% import * as fs from 'fs'; %}
%populate {
    object "${prefix_}DeviceInfo" {
        object LogRotate {
            instance add(0, 'syslog-resmon-mmon', 'Alias' = "syslog-resmon-mmon") {
                 parameter 'DelayCompression' = true;
                 parameter 'NumberOfFiles' = 3;
                 parameter 'RollOver' = 0;
                 parameter 'Enable' = true;
                 parameter 'MaxFileSize' = 64;
                 parameter 'Retention' = 0;
                 parameter 'Name' = "file://${log-dir}/resmon-memory.log";
                 parameter 'Alias';
                 parameter 'Compression' = "None";
                 object 'LogFile' {
                 }
            }
{% for (let cpu in fs.lsdir("/sys/devices/system/cpu/")) : -%}
{% if (match(cpu, regexp("^cpu[0-9]+$")) != null): %}
{% let core_id = match(cpu, regexp("^cpu([0-9]+)$"))[1]; %}
            instance add(0, 'syslog-cmon-cpu{{ core_id }}', 'Alias' = "syslog-cmon-cpu{{ core_id }}") {
                parameter 'DelayCompression' = true;
                parameter 'NumberOfFiles' = 3;
                parameter 'RollOver' = 0;
                parameter 'Enable' = true;
                parameter 'MaxFileSize' = 64;
                parameter 'Retention' = 0;
                parameter 'Name' = "file://${log-dir}/resmon-cpu{{ core_id }}.log";
                parameter 'Alias';
                parameter 'Compression' = "None";
                object 'LogFile' {
                }
            }
{% endif %}
{% endfor -%}
        }
    }
}
