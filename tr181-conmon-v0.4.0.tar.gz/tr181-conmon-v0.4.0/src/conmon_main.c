/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "conmon.h"
#include "dm_conmon.h"
#include "conmon_utils.h"

#include <amxm/amxm.h>
#include <amxrt/amxrt.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxm_module_t* mod;
} conmon_t;
static conmon_t conmon = {0};

amxd_dm_t* conmon_get_dm(void) {
    return conmon.dm;
}

amxo_parser_t* conmon_get_parser(void) {
    return conmon.parser;
}


static int conmon_load_controllers(void) {
    SAH_TRACEZ_IN(ME);

    int retval = 0;
    amxc_string_t mod_path;
    amxc_string_init(&mod_path, 0);

    const char* module_dir = GET_CHAR(&(conmon_get_parser()->config), "module-client-dir");
    const char* name = "mod-discoping";
    amxm_shared_object_t* so = NULL;

    retval = 1;

    when_str_empty_trace(module_dir, exit, ERROR, "Missing or empty parameter 'module-client-dir'");

    amxc_string_setf(&mod_path, "%s/%s.so", module_dir, name);
    SAH_TRACEZ_INFO(ME, "Loading controller '%s' (file = %s)",
                    name, amxc_string_get(&mod_path, 0));
    retval = amxm_so_open(&so, name, amxc_string_get(&mod_path, 0));
    when_failed_trace(retval, exit, WARNING,
                      "Loading controller '%s' failed", name);
exit:

    amxc_string_clean(&mod_path);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

static int conmon_register_core_mod(void) {
    SAH_TRACEZ_IN(ME);
    int retval = -1;
    when_failed_trace(amxm_module_register(&conmon.mod, NULL, MOD_CORE), exit, ERROR,
                      "Failed to register mod %s", MOD_CORE);
    retval = amxm_module_add_function(conmon.mod, "update-dm", conmon_update_dm);
exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

static int conmon_init(void) {
    SAH_TRACEZ_IN(ME);

    int rv = -1;

    SAH_TRACEZ_INFO(ME, "ConMon start");
    when_false_trace(netmodel_initialize(), exit, ERROR, "Failed to initialize libnetmodel");

    rv = amxo_parser_parse_string(conmon_get_parser(), "?include '${odl.directory}/${name}.odl':'${odl.dm-defaults}';", amxd_dm_get_root(conmon_get_dm()));
    rv |= conmon_load_controllers();
    rv |= conmon_register_core_mod();

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int conmon_clean(void) {
    SAH_TRACEZ_IN(ME);

    amxm_module_deregister(&conmon.mod);
    netmodel_cleanup();

    SAH_TRACEZ_INFO(ME, "ConMon stop");

    SAH_TRACEZ_OUT(ME);
    return 0;
}

int _conmon_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);

    int rv = 0;

    switch(reason) {
    case AMXO_START:
        conmon.dm = dm;
        conmon.parser = parser;
        rv = conmon_init();
        break;
    case AMXO_STOP:
        rv = conmon_clean();
        conmon.dm = NULL;
        conmon.parser = NULL;
        break;
    default:
        rv = -1;
    }

    SAH_TRACEZ_OUT(ME);
    return rv;
}
