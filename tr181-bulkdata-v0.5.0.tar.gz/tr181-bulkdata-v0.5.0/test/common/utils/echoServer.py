import http.server
import ssl
import json
import sys
import os

FIFO_PATH = "/tmp/echo_pipe"
failure_count = 0
max_failures = 0

# Ensure the named pipe (FIFO) exists
if not os.path.exists(FIFO_PATH):
    print(f"Create {FIFO_PATH}")
    os.mkfifo(FIFO_PATH)

class EchoHandler(http.server.BaseHTTPRequestHandler):
    def _write_to_pipe(self, data):
        print("1 _write_to_pipe")
        try:
            fifo_fd = os.open(FIFO_PATH, os.O_WRONLY | os.O_NONBLOCK)
            with os.fdopen(fifo_fd, "w", buffering=1) as fifo:
                print("2 _write_to_pipe")
                fifo.write(data + "\n")
                print("3 _write_to_pipe")
        except OSError:
            print("Warning: No reader for FIFO pipe", file=sys.stderr)
        print("4 _write_to_pipe")

    def _echo_response(self):
        global failure_count, max_failures
        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length else b""
        content_type = self.headers.get("Content-Type", "")

        if failure_count < max_failures:
            failure_count += 1
            self.send_response(503)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Temporary server error"}).encode("utf-8"))
            print(f"Simulated failure {failure_count}/{max_failures}")
            return

        # Print received headers
        print("Received headers:")
        for header, value in self.headers.items():
            print(f"    {header}: {value}")

        # Print the received body with special formatting for JSON
        print("Received body:")
        decoded_body = body.decode("utf-8", errors="ignore")
        if "application/json" in content_type.lower():
            try:
                parsed_json = json.loads(decoded_body)
                print(json.dumps(parsed_json, indent=4))
            except json.JSONDecodeError:
                print("    Invalid JSON received:")
                print(f"    {decoded_body}")
        else:
            print(f"    {decoded_body}")

        failure_count = 0

        # Prepare response
        response = {
            "method": self.command,
            "path": self.path,
            "headers": dict(self.headers),
            "body": decoded_body
        }
        response_data = json.dumps(response, indent=4)

        # Write to the named pipe (uncomment to use)
        # self._write_to_pipe(response_data)

        # Send response
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(response_data.encode("utf-8"))


    def do_GET(self):
        print("GET request is not handled")

    def do_POST(self):
        self._echo_response()

    def do_PUT(self):
        self._echo_response()

    def do_DELETE(self):
        print("DELETE request is not handled")

# Start HTTP or HTTPS server
def run(server_class=http.server.HTTPServer, handler_class=EchoHandler, port=8080, use_https=False):
    server_address = ("0.0.0.0", port)
    httpd = server_class(server_address, handler_class)
    
    if use_https:
        httpd.socket = ssl.wrap_socket(
            httpd.socket,
            certfile="server.pem",  # Use PEM file here
            server_side=True
        )
        print(f"HTTPS Server running on https://localhost:{port}")
    else:
        print(f"HTTP Server running on http://localhost:{port}")

    httpd.serve_forever()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Simple HTTP/HTTPS Echo Server")
    parser.add_argument("--port", type=int, default=8080, help="Port number (default: 8080)")
    parser.add_argument("--https", action="store_true", help="Enable HTTPS mode")
    parser.add_argument("--simulate-failure", nargs="?", const=3, type=int,
                        help="Simulate failures for the first N requests (default 3 if no number is given)")
    args = parser.parse_args()

        # Set max_failures based on option
    if args.simulate_failure:
        max_failures = args.simulate_failure
        print(f"Simulating {max_failures} failures before successful responses.")
    
    SIMULATE_FAILURE = args.simulate_failure
    run(port=args.port, use_https=args.https)
