/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxrt/amxrt.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_verify.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <limits.h>

#include "tr181-gatewayinfo.h"

#include "tr181-gatewayinfo_test.h"
// #include "../common/functions.h"

#define ME "gatewayinfo"

int test_setup(void** state) {
    assert_int_equal(amxut_bus_setup(state), 0);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

bool __wrap_netmodel_initialize(void) {
    function_called();
    return mock_type(bool);
}

int __wrap_setup_subscriptions(void) {
    function_called();
    return mock_type(int);
}
int __wrap_register_cwmp_dm(void) {
    function_called();
    return mock_type(int);
}


void test_can_start_plugin(UNUSED void** state) {
    expect_function_call(__wrap_netmodel_initialize);
    will_return(__wrap_netmodel_initialize, true);

    expect_function_call(__wrap_setup_subscriptions);
    will_return(__wrap_setup_subscriptions, 0);

    expect_function_call(__wrap_register_cwmp_dm);
    will_return(__wrap_register_cwmp_dm, 0);

    assert_int_equal(_gatewayinfo_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
}

int __wrap_deregister_cwmp_dm(void) {
    function_called();
    return mock_type(int);
}

void __wrap_netmodel_cleanup(void) {
    function_called();
}


void test_can_stop_plugin(UNUSED void** state) {
    will_return(__wrap_deregister_cwmp_dm, 0);
    expect_function_call(__wrap_deregister_cwmp_dm);

    expect_function_call(__wrap_netmodel_cleanup);
    assert_int_equal(_gatewayinfo_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
}
void test_DHCPGatewayInformation_init_deinit(UNUSED void** state) {
    struct DHCPGatewayInformation gateway_info;
    DHCPGatewayInformation_init(&gateway_info);

    assert_int_equal(amxc_string_buffer_length(&gateway_info.DeviceManufacturerOUI), DEFAULT_STRING_BUFFER_SIZE);
    assert_int_equal(amxc_string_buffer_length(&gateway_info.DeviceProductClass), DEFAULT_STRING_BUFFER_SIZE);
    assert_int_equal(amxc_string_buffer_length(&gateway_info.DeviceSerialNumber), DEFAULT_STRING_BUFFER_SIZE);

    DHCPGatewayInformation_deinit(&gateway_info); // leak is tested using valgrind
}

void test_DHCPGatewayInformation_reset(UNUSED void** state) {
    struct DHCPGatewayInformation gateway_info;
    DHCPGatewayInformation_init(&gateway_info);

    amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
    amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
    amxc_string_set(&gateway_info.DeviceSerialNumber, "DeviceSerialNumber");

    assert_string_equal(amxc_string_get(&gateway_info.DeviceManufacturerOUI, 0), "DeviceManufacturerOUI");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceProductClass, 0), "DeviceProductClass");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceSerialNumber, 0), "DeviceSerialNumber");

    DHCPGatewayInformation_reset(&gateway_info);

    assert_string_equal(amxc_string_get(&gateway_info.DeviceManufacturerOUI, 0), "");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceProductClass, 0), "");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceSerialNumber, 0), "");

    DHCPGatewayInformation_deinit(&gateway_info);
}


void test_DHCPGatewayInformation_copy(UNUSED void** state) {
    struct DHCPGatewayInformation gateway_info1;
    DHCPGatewayInformation_init(&gateway_info1);

    amxc_string_set(&gateway_info1.DeviceManufacturerOUI, "DeviceManufacturerOUI");
    amxc_string_set(&gateway_info1.DeviceProductClass, "DeviceProductClass");
    amxc_string_set(&gateway_info1.DeviceSerialNumber, "DeviceSerialNumber");

    struct DHCPGatewayInformation gateway_info2;
    DHCPGatewayInformation_init(&gateway_info2);
    DHCPGatewayInformation_copy(&gateway_info1, &gateway_info2);

    assert_string_equal(amxc_string_get(&gateway_info1.DeviceManufacturerOUI, 0), "DeviceManufacturerOUI");
    assert_string_equal(amxc_string_get(&gateway_info1.DeviceProductClass, 0), "DeviceProductClass");
    assert_string_equal(amxc_string_get(&gateway_info1.DeviceSerialNumber, 0), "DeviceSerialNumber");

    assert_string_equal(amxc_string_get(&gateway_info2.DeviceManufacturerOUI, 0), "DeviceManufacturerOUI");
    assert_string_equal(amxc_string_get(&gateway_info2.DeviceProductClass, 0), "DeviceProductClass");
    assert_string_equal(amxc_string_get(&gateway_info2.DeviceSerialNumber, 0), "DeviceSerialNumber");

    DHCPGatewayInformation_deinit(&gateway_info1);
    DHCPGatewayInformation_deinit(&gateway_info2);
}

void test_DHCPGatewayInformation_is_emtpy(UNUSED void** state) {
    struct DHCPGatewayInformation gateway_info;
    DHCPGatewayInformation_init(&gateway_info);

    assert_string_equal(amxc_string_get(&gateway_info.DeviceManufacturerOUI, 0), "");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceProductClass, 0), "");
    assert_string_equal(amxc_string_get(&gateway_info.DeviceSerialNumber, 0), "");

    assert_true(DHCPGatewayInformation_is_emtpy(&gateway_info));

    amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
    amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
    amxc_string_set(&gateway_info.DeviceSerialNumber, "DeviceSerialNumber");

    assert_false(DHCPGatewayInformation_is_emtpy(&gateway_info));

    DHCPGatewayInformation_deinit(&gateway_info);
}

void test_DHCPGatewayInformation_equal(UNUSED void** state) {
    struct DHCPGatewayInformation gateway_info1;
    DHCPGatewayInformation_init(&gateway_info1);

    amxc_string_set(&gateway_info1.DeviceManufacturerOUI, "DeviceManufacturerOUI");
    amxc_string_set(&gateway_info1.DeviceProductClass, "DeviceProductClass");
    amxc_string_set(&gateway_info1.DeviceSerialNumber, "DeviceSerialNumber");

    struct DHCPGatewayInformation gateway_info2;
    DHCPGatewayInformation_init(&gateway_info2);

    assert_false(DHCPGatewayInformation_equal(&gateway_info1, &gateway_info2));

    DHCPGatewayInformation_copy(&gateway_info1, &gateway_info2);

    assert_true(DHCPGatewayInformation_equal(&gateway_info1, &gateway_info2));

    DHCPGatewayInformation_deinit(&gateway_info1);
    DHCPGatewayInformation_deinit(&gateway_info2);

}