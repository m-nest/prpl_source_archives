#ifndef __TEST_HELPERS_H__
#define __TEST_HELPERS_H__

#ifdef __cplusplus
extern "C"
{
#endif

int test_setup(void** state);
int test_teardown(void** state);

void test_set_hex_value(void** state);
void test_int_to_hex_value(void** state);
void test_create_usb_device_interface(void** state);
void test_valid_hex_value(void** state);

#ifdef __cplusplus
}
#endif

#endif // __TEST_HELPERS_H__
