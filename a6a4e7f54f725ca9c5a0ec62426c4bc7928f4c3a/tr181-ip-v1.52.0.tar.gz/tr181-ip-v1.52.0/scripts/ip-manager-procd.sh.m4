#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="ip-manager"
PROG="/usr/bin/ip-manager"
datamodel_root="IP"
PROG_OPTIONS=""

start_service() {
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
}
