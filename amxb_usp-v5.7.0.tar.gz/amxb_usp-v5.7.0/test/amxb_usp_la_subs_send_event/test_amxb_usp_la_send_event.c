/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2026 Inango
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc_llist.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <setjmp.h>
#include <cmocka.h>
#include <stdio.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>

#include <amxut/amxut_util.h>

#include "amxb_usp.h"
#include "amxb_usp_la.h"
#include "test_amxb_usp_la_send_event.h"

#define UNUSED __attribute__((unused))

static amxb_usp_t* usp_ctx = NULL;
static amxd_dm_t* dm = NULL;
static amxd_dm_t* la_dm = NULL;

static amxd_object_t* tmp_obj = NULL;

static amxd_status_t dynamic_get(UNUSED amxd_object_t* object,
                                 UNUSED amxd_function_t* func,
                                 amxc_var_t* args,
                                 amxc_var_t* ret) {
    function_called();

    assert_int_equal(GET_INT32(args, "depth"), 0);

    const char* rel_path = GET_CHAR(args, "rel_path");
    const char* rel_path_expected = mock_ptr_type(const char*);
    assert_string_equal(rel_path, rel_path_expected);

    const amxc_var_t* ret_result = mock_ptr_type(amxc_var_t*);
    amxc_var_copy(ret, ret_result);

    return mock_type(amxd_status_t);
}

// Dynamic.             // dynamic
static void init_dm(void) {
    assert_int_equal(amxd_dm_new(&dm), amxd_status_ok);
    amxd_object_t* root = amxd_dm_get_root(dm);
    root->priv = usp_ctx;

    {
        amxd_object_t* dynamic_obj = NULL;

        assert_int_equal(amxd_object_new(&dynamic_obj, amxd_object_singleton, "Dynamic"), amxd_status_ok);
        assert_int_equal(amxd_dm_add_root_object(dm, dynamic_obj), amxd_status_ok);
        dynamic_obj->priv = usp_ctx;
        amxd_object_change_function(dynamic_obj, "_get", dynamic_get);

    }
}

static void init_la_dm() {
    assert_int_equal(amxd_dm_new(&la_dm), amxd_status_ok);
    amxd_object_t* root = amxd_dm_get_root(la_dm);
    root->priv = usp_ctx;
}

int test_setup(UNUSED void** state) {
    amxut_bus_setup(state);

    usp_ctx = calloc(sizeof(amxb_usp_t), 1);
    usp_ctx->eid = "usp";

    init_dm();
    init_la_dm();

    usp_ctx->dm = dm;
    usp_ctx->la_dm = la_dm;

    amxd_object_new(&tmp_obj, amxd_object_singleton, "TmpObj");
    tmp_obj->priv = usp_ctx;

    amxut_bus_handle_events();

    amxb_usp_la_subscription_added(NULL, NULL, NULL); // should connect notification slot

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxut_bus_teardown(state);

    amxd_dm_delete(&la_dm);
    amxd_dm_delete(&dm);
    free(usp_ctx);

    return 0;
}

amxd_object_t* __wrap_amxd_object_get_instance(UNUSED const amxd_object_t* object,
                                               UNUSED const char* name,
                                               UNUSED uint32_t index) {
    return tmp_obj;
}

typedef bool (* send_event_check_fn_t)(const char* event_name,
                                       amxd_path_t* path,
                                       const amxc_llist_t* resolved,
                                       const amxc_var_t* event,
                                       amxc_var_t* event_list);

typedef struct _event_data {
    const char* event;
    const amxc_var_t* data;
    uspi_notify_type_t type;
    send_event_check_fn_t check_fn;
    int* fd_buffer;
    int fd_count;
} event_data_t;


static bool dummy_send_event(UNUSED const char* event_name,
                             UNUSED amxd_path_t* path,
                             const amxc_llist_t* resolved,
                             UNUSED const amxc_var_t* event,
                             UNUSED amxc_var_t* event_list) {

    assert_int_equal(amxc_llist_size(resolved), mock_type(int));

    amxc_llist_for_each(it, resolved) {
        amxc_string_t* p = amxc_container_of(it, amxc_string_t, it);
        assert_string_equal(mock_ptr_type(const char*), amxc_string_get(p, 0));
    }

    return false;
}
void __wrap_amxd_object_for_all(amxd_object_t* object,
                                UNUSED const char* rel_spath,
                                amxd_mobject_cb_t fn,
                                void* priv) {

    event_data_t* event_data = (event_data_t*) priv;
    event_data->check_fn = dummy_send_event;


    amxd_object_t* dynamic = amxd_dm_findf(dm, "Dynamic.");
    assert_non_null(dynamic);
    fn(object, dynamic, priv);
}

const amxc_var_t* __wrap_amxd_object_get_param_value(UNUSED const amxd_object_t* const object,
                                                     UNUSED const char* name) {
    return mock_ptr_type(amxc_var_t*);
}

static amxc_var_t* create_get_response(const char* path) {
    amxc_var_t* args = NULL;
    amxc_var_new(&args);
    amxc_var_set_type(args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key(args, path);

    return args;
}

void test_send_event_dynamic_dm(UNUSED void** state) {
    amxc_var_t* reference_list = NULL;
    amxc_var_new(&reference_list);
    amxc_var_set_type(reference_list, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, reference_list, "ReferenceList", "Dynamic.Foo.Bar.");

    will_return(__wrap_amxd_object_get_param_value, reference_list);

    expect_function_call(dynamic_get);
    will_return(dynamic_get, "Foo.Bar.");
    amxc_var_t* get_resp = create_get_response("Dynamic.Foo.Bar.");
    will_return(dynamic_get, get_resp);
    will_return(dynamic_get, amxd_status_ok);

    will_return(dummy_send_event, 1);
    will_return(dummy_send_event, "Dynamic.Foo.Bar.");

    amxp_sigmngr_emit_signal(&dm->sigmngr, "dm:object-changed", NULL);

    amxut_bus_handle_events();

    amxc_var_delete(&get_resp);
    amxc_var_delete(&reference_list);
}
