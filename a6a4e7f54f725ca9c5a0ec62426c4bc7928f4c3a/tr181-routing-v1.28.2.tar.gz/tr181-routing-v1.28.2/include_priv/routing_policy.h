/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __ROUTING_POLICY_H__
#define __ROUTING_POLICY_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <netmodel/client.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ROUTING_POLICY_SET "set-policy"
#define ROUTING_POLICY_REMOVE "remove-policy"

/**
   @file
   @brief
   Header file which includes functions to configure routing policies defined by Routing.Policy objects
 */

/**
 * @defgroup routing_policy Routing Policy Management
 * @ingroup tr181-routing
 * @brief Functions to manage Routing.Policy instance objects.
 * @{
 */

typedef enum policy_status {
    STATUS_ENABLED,
    STATUS_DISABLED,
    STATUS_ERROR
} policy_status_t;

/**
 * @brief Sets the routing policy for a Routing.Policy instance object.
 *
 * Applies the routing policy configuration of the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object for which the policy is set.
 * @return AMXD_STATUS_OK on success, or an error code on failure.
 */
amxd_status_t set_routing_policy(amxd_object_t* object);

/**
 * @brief Removes the routing policy from a Routing.Policy instance object.
 *
 * Removes any routing policy configuration associated with the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object for which the policy is removed.
 * @return AMXD_STATUS_OK on success, or an error code on failure.
 */
amxd_status_t remove_routing_policy(amxd_object_t* object);

/**
 * @brief Sets the status of the routing policy for a Routing.Policy instance object.
 *
 * Updates the internal status of the routing policy (enabled, disabled, or error)
 * for the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object.
 * @param status The new status to set for the policy.
 */
void policy_set_status(amxd_object_t* object, policy_status_t status);

/**
 * @brief Creates and initializes policy information for a Routing.Policy instance object.
 *
 * Allocates and sets up any internal data structures needed to manage
 * routing policy information for the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object.
 */
void create_policy_info(amxd_object_t* object);

/**
 * @brief Destroys and cleans up policy information for a Routing.Policy instance object.
 *
 * Frees any resources or data structures associated with the routing policy
 * for the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object.
 */
void destroy_policy_info(amxd_object_t* object);

/**
 * @brief Opens a query for the output interface (OIF) of a Routing.Policy instance object.
 *
 * Initiates a query to determine or configure the output interface for
 * the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object.
 */
void open_oif_query(amxd_object_t* object);

/**
 * @brief Opens a query for the input interface (IIF) of a Routing.Policy instance object.
 *
 * Initiates a query to determine or configure the input interface for
 * the specified Routing.Policy instance object.
 *
 * @param object Pointer to the Routing.Policy instance object.
 */
void open_iif_query(amxd_object_t* object);

/** @} */ // end of routing_policy group

#ifdef __cplusplus
}
#endif

#endif // __ROUTING_POLICY_H__
