/*******************************************************************************
 *
 * Copyright (c) 2000-2003 Intel Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * - Neither name of Intel Corporation nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/
/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef UTIL_H
#define UTIL_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <ithread.h>
#include <ixml.h> /* for IXML_Document, IXML_Element */
#include <upnp.h> /* for Upnp_EventType */
#include <upnptools.h>

#include <stdlib.h>
#include <string.h>

/**
 * @file util.h
 * @brief The auxiliary functions.
 */

/* mutex to control displaying of events */
extern ithread_mutex_t display_mutex;

/**
 * @brief Given a DOM node such as \<Channel>11\</Channel>, this routine
 * extracts the value (e.g., 11) from the node and returns it as
 * a string. The string must be freed by the caller using free.
 *
 * @return The DOM node as a string.
 */
char* Util_GetElementValue(
    /** [in] The DOM node from which to extract the value. */
    IXML_Element* element);

/**
 * @brief Given a document node, this routine searches for the first element
 * named by the input string item, and returns its value as a string.
 * String must be freed by caller using free.
 */
char* Util_GetFirstDocumentItem(
    /** [in] The DOM document from which to extract the value. */
    IXML_Document* doc,
    /** [in] The item to search for. */
    const char* item);

/**
 * @brief Given a DOM element, this routine searches for the first element
 * named by the input string item, and returns its value as a string.
 * The string must be freed using free.
 */
char* Util_GetFirstElementItem(
    /** [in] The DOM element from which to extract the value. */
    IXML_Element* element,
    /** [in] The item to search for. */
    const char* item);

/**
 * @brief Prints a callback event type as a string.
 */
void Util_PrintEventType(
    /** [in] The callback event. */
    Upnp_EventType S);

/**
 * @brief Prints callback event structure details.
 */
int Util_PrintEvent(
    /** [in] The type of callback event. */
    Upnp_EventType EventType,
    /** [in] The callback event structure. */
    const void* Event);

/**
 * @brief This routine finds the first occurance of a service in a DOM
 * representation of a description document and parses it.  Note that this
 * function currently assumes that the eventURL and controlURL values in
 * the service definitions are full URLs.  Relative URLs are not handled here.
 */
int Util_FindAndParseService (
    /** [in] The DOM description document. */
    IXML_Document* DescDoc,
    /** [in] The location of the description document. */
    const char* location,
    /** [in] The type of service to search for. */
    const char* serviceType,
    /** [out] The service ID. */
    char** serviceId,
    /** [out] The event URL for the service. */
    char** eventURL,
    /** [out] The control URL for the service. */
    char** controlURL);

/**
 * @brief Prototype for displaying strings. All printing done by the device,
 * control point, and util, ultimately use this to display strings
 * to the user.
 */
typedef void (*print_string)(
    /** [in] Format. */
    const char* string,
    /** [in] Arguments. */
    ...)
#if (__GNUC__ >= 3)
/* This enables printf like format checking by the compiler */
__attribute__((format(__printf__, 1, 2)))
#endif
;

/** global print function used by util */
extern print_string gPrintFun;

/**
 * @brief Initializes the util. Must be called before any util
 * functions. May be called multiple times.
 */
int Util_Initialize(
    /** [in] Print function to use in Util_Print. */
    print_string print_function);

/**
 * @brief Releases Resources held by util.
 */
int Util_Finish();

/**
 * @brief Function emulating printf that ultimately calls the registered print
 * function with the formatted string.
 *
 * Provides platform-specific print functionality.  This function should be
 * called when you want to print content suitable for console output (i.e.,
 * in a large text box or on a screen).  If your device/operating system is
 * not supported here, you should add a port.
 *
 * @return The same as printf.
 */
int Util_Print(
    /** [in] Format (see printf). */
    const char* fmt,
    /** [in] Format data. */
    ...)
#if (__GNUC__ >= 3)
/* This enables printf like format checking by the compiler */
__attribute__((format(__printf__, 1, 2)))
#endif
;

/**
 * @brief Prints a string to standard out.
 */
void linux_print(const char* format, ...)
#if (__GNUC__ >= 3)
/* This enables printf like format checking by the compiler */
__attribute__((format(__printf__, 1, 2)))
#endif
;

#ifdef __cplusplus
};
#endif /* __cplusplus */

#endif /* UTIL_H */
