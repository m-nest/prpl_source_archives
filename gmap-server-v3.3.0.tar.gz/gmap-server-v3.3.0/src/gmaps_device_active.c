/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include <stdlib.h>
#include <string.h>

/** The lowest possible number for a priority (expressing the highest possible priority) */
#define GMAPS_DEVICE_ACTIVE_PRIORITY_MIN 1
/** The highest possible number for a priority (expressing the lowest possible priority) */
#define GMAPS_DEVICE_ACTIVE_PRIORITY_MAX 100

#include "gmaps_priv.h"
#include "debug/sahtrace.h"
#include "debug/sahtrace_macros.h"

#define ME "gmaps"

typedef struct _gmaps_device_active {
    amxc_htable_it_t it;        /**< iterator within priv_data.actives, key = source */
    uint8_t priority;           /**< Current priority, within [1,100] */
    bool active;                /**< Whether the device is active according to this source */
    amxd_object_t* instance;    /**< Data model object pointer to the object representing this entry */
} gmaps_device_active_t;


static void s_active_entry_cleanup(UNUSED const char* key, amxc_htable_it_t* it) {
    gmaps_device_active_t* entry = amxc_htable_it_get_data(it, gmaps_device_active_t, it);
    free(entry);
}

void gmaps_device_active_device_init(amxd_object_t* device, gmap_device_priv_data_t* data) {
    amxd_status_t status;
    amxc_var_t value;

    amxc_var_init(&value);

    when_null(device, exit);
    when_null(data, exit);

    status = amxd_object_get_param(device, "Active", &value);
    when_failed_trace(status, exit, ERROR, "Failed to init active for device '%s'", amxd_object_get_name(device, AMXD_OBJECT_NAMED));
    data->active = amxc_var_constcast(bool, &value);

    amxc_htable_init(&data->actives, 4);
    amxd_object_iterate(instance, it, amxd_object_get_child(device, "Actives")) {
        amxd_object_t* instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        gmaps_device_active_t* entry;
        int32_t prio;
        const char* source = NULL;

        entry = malloc(sizeof(gmaps_device_active_t));
        when_null_trace(entry, exit, ERROR, "Out of memory");
        amxc_htable_it_init(&entry->it);
        entry->instance = instance;

        status = amxd_object_get_param(instance, "Active", &value);
        when_failed_trace(status, error, ERROR, "Failed to init active for device '%s'", amxd_object_get_name(device, AMXD_OBJECT_NAMED));
        entry->active = amxc_var_constcast(bool, &value);

        status = amxd_object_get_param(instance, "Priority", &value);
        when_failed_trace(status, error, ERROR, "Failed to init active for device '%s'", amxd_object_get_name(device, AMXD_OBJECT_NAMED));
        prio = amxc_var_dyncast(uint32_t, &value);
        if((prio > 100) || (prio < 1)) {
            entry->priority = 100;
        } else {
            entry->priority = (uint8_t) prio;
        }

        status = amxd_object_get_param(instance, "Source", &value);
        when_failed_trace(status, error, ERROR, "Failed to init active for device '%s'", amxd_object_get_name(device, AMXD_OBJECT_NAMED));
        source = amxc_var_constcast(cstring_t, &value);
        when_str_empty_trace(source, error, ERROR, "Failed to init active for device '%s'", amxd_object_get_name(device, AMXD_OBJECT_NAMED));

        when_failed_trace(amxc_htable_insert(&data->actives, source, &entry->it), error, ERROR, "Out of memory");

        continue;
error:
        amxc_htable_it_clean(&entry->it, s_active_entry_cleanup);
    }

exit:
    amxc_var_clean(&value);
    return;
}

void gmaps_device_active_device_clean(UNUSED amxd_object_t* device, gmap_device_priv_data_t* data) {
    when_null(data, exit);

    amxc_htable_clean(&data->actives, s_active_entry_cleanup);
exit:
    return;
}

static bool s_active_calc(const gmap_device_priv_data_t* data) {
    bool active = false;
    uint32_t prio = GMAPS_DEVICE_ACTIVE_PRIORITY_MAX + 1;

    when_null(data, exit);

    amxc_htable_for_each(it, &data->actives) {
        gmaps_device_active_t* entry = amxc_htable_it_get_data(it, gmaps_device_active_t, it);
        if(entry->priority == prio) {
            // From the spec: "if multiple instances have the highest priority
            //                 then it's a AND between all the values."
            active = active && entry->active;
        } else if(entry->priority < prio) {
            // From the spec: "The instance in Devices.Device.{i}.Actives with
            //                 the highest priority is selected"
            //           and: "With 1 the highest priority"
            active = entry->active;
            prio = entry->priority;
        }
    }

exit:
    return active;
}

static gmaps_device_active_t* s_create_active(amxd_object_t* device,
                                              const char* source,
                                              bool active,
                                              uint32_t priority,
                                              const amxc_ts_t* now) {
    amxd_status_t status = amxd_status_unknown_error;
    gmaps_device_active_t* entry = NULL;
    amxd_object_t* inst = NULL;
    amxc_var_t data;

    entry = malloc(sizeof(gmaps_device_active_t));
    when_null_trace(entry, exit, ERROR, "Out of memory");

    amxc_htable_it_init(&entry->it);
    entry->active = active;
    entry->priority = priority;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "Source", source);
    amxc_var_add_key(uint32_t, &data, "Priority", priority);
    amxc_var_add_key(bool, &data, "Active", active);
    if(now != NULL) {
        amxc_var_add_key(amxc_ts_t, &data, "Time", now);
    }

    status = amxd_object_add_instance(&inst, amxd_object_get_child(device, "Actives"), source, 0, &data);
    when_failed_trace(status, exit, ERROR,
                      "Failed to create new actives instance %s.%s: %d",
                      amxd_object_get_name(device, AMXD_OBJECT_NAMED), source, status);

    entry->instance = inst;

    amxd_object_emit_add_inst(inst);

exit:
    if((status != 0) && (entry != NULL)) {
        amxc_htable_it_clean(&entry->it, s_active_entry_cleanup);
        entry = NULL;
    }
    amxc_var_clean(&data);
    return entry;
}

static bool s_modify_active(UNUSED amxd_object_t* device,
                            gmaps_device_active_t* entry,
                            UNUSED const char* source,
                            bool active,
                            uint32_t priority,
                            const amxc_ts_t* now) {
    bool success = false;
    amxc_var_t data;

    amxc_var_init(&data);

    when_null_trace(entry, exit, ERROR, "Null pointer");
    when_null_trace(entry->instance, exit, ERROR, "BUG: Actives entry not linked to data model instance");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    if(entry->priority != priority) {
        when_failed_trace(amxd_object_set_value(uint32_t, entry->instance, "Priority", priority), exit,
                          ERROR, "Failed to set priority of Device active %s.%s",
                          amxd_object_get_name(device, AMXD_OBJECT_NAMED), source);
        amxc_var_add_key(uint32_t, &data, "Priority", entry->priority);
        entry->priority = priority;
    }
    if(entry->active != active) {
        when_failed_trace(amxd_object_set_value(bool, entry->instance, "Active", active), exit,
                          ERROR, "Failed to set active of Device active %s.%s",
                          amxd_object_get_name(device, AMXD_OBJECT_NAMED), source);
        amxc_var_add_key(bool, &data, "Active", entry->active);
        entry->active = active;

        if(now != NULL) {
            /* .Time is volatile, no need to add it to the changed data and
             * failure to modify should not prevent sending out the event. */
            if(amxd_object_set_value(amxc_ts_t, entry->instance, "Time", now) != amxd_status_ok) {
                SAH_TRACEZ_ERROR(ME, "Failed to set time of Device active %s.%s",
                                 amxd_object_get_name(device, AMXD_OBJECT_NAMED), source);
            }
        }
    }

    amxd_object_emit_changed(entry->instance, &data);
    success = true;

exit:
    amxc_var_clean(&data);
    return success;
}

static bool s_apply_active(amxd_object_t* device,
                           gmap_device_priv_data_t* priv,
                           bool active,
                           const amxc_ts_t* now) {
    bool success = false;
    amxc_var_t data;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    when_failed_trace(amxd_object_set_value(bool, device, "Active", active), exit,
                      ERROR, "Failed to set active of Device %s",
                      amxd_object_get_name(device, AMXD_OBJECT_NAMED));
    amxc_var_add_key(bool, &data, "Active", priv->active);
    priv->active = active;

    if(now != NULL) {
        /* .LastConnection is volatile, no need to add it to the changed data and
         * failure to modify should not prevent sending out the event. */
        if(amxd_object_set_value(amxc_ts_t, device, "LastConnection", now) != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Failed to set LastConnection of Device %s",
                             amxd_object_get_name(device, AMXD_OBJECT_NAMED));
        }
    }

    amxd_object_emit_changed(device, &data);
    success = true;

exit:
    amxc_var_clean(&data);
    return success;
}

static gmap_status_t s_set_active(amxd_object_t* device,
                                  const char* source,
                                  bool active,
                                  uint32_t priority,
                                  const amxc_ts_t* now) {
    gmap_status_t status = gmap_status_unknown_error;
    gmap_device_priv_data_t* data = NULL;
    amxc_htable_it_t* it = NULL;
    gmaps_device_active_t* entry = NULL;
    bool new_active;

    when_null_status(device, exit, status = gmap_status_device_not_found);
    when_str_empty_status(source, exit, status = gmap_status_invalid_parameter);
    when_true_status(priority > GMAPS_DEVICE_ACTIVE_PRIORITY_MAX, exit, status = gmap_status_invalid_parameter);
    when_true_status(priority < GMAPS_DEVICE_ACTIVE_PRIORITY_MIN, exit, status = gmap_status_invalid_parameter);

    data = gmaps_device_private_data(device);
    when_null_trace(data, exit, ERROR, "BUG: no private data for device");

    it = amxc_htable_get(&data->actives, source);
    if(it == NULL) {
        entry = s_create_active(device, source, active, priority, now);
        when_null(entry, exit);
        amxc_htable_insert(&data->actives, source, &entry->it);
    } else {
        entry = amxc_htable_it_get_data(it, gmaps_device_active_t, it);
        when_true_status(entry->active == active && entry->priority == priority,
                         exit, status = gmap_status_ok);
        when_false(s_modify_active(device, entry, source, active, priority, now), exit);
    }

    new_active = s_active_calc(data);
    if(new_active != data->active) {
        when_false(s_apply_active(device, data, new_active, now), exit);
    }

    status = gmap_status_ok;

exit:
    return status;
}

gmap_status_t gmaps_device_set_active(amxd_object_t* device,
                                      bool active_of_source,
                                      const char* source,
                                      uint32_t priority) {
    gmap_status_t retval = gmap_status_device_not_found;
    amxc_ts_t now;
    amxc_ts_t* now_ptr = NULL;

    when_null_trace(device, exit, ERROR, "NULL device");

    if(gmap_is_ntp_synchronized()) {
        if(0 == amxc_ts_now(&now)) {
            now_ptr = &now;
        } else {
            SAH_TRACEZ_ERROR(ME, "Failed to get current time.");
        }
    }

    retval = s_set_active(device, source, active_of_source, priority, now_ptr);

exit:
    return retval;
}

bool gmaps_device_is_active(amxd_object_t* device) {
    bool active = false;
    gmap_device_priv_data_t* data = gmaps_device_private_data(device);

    when_null(data, exit);

    active = data->active;

exit:
    return active;
}
