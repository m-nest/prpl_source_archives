#!/bin/bash

set +e
IS_UDPST_RUNNING=$(pgrep udpst)
if [ ! -z "${IS_UDPST_RUNNING}" -a "${IS_UDPST_RUNNING}" != "" -a "${IS_UDPST_RUNNING}" != " " ]; then
    pkill udpst
fi

if udpst -v | grep -q 'UDP Speed Test' ; then
    echo 
    echo "UDP Speed Test (udpst) is installed"
    echo
    exit 0
else
    echo 
    echo "No UDP Speed Test (udpst) is installed, test will fail"
    echo 
    exit 1
fi