/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _GNU_SOURCE

#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdio.h>
#include <errno.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <filetransfer/filetransfer.h>
#include <zlib.h>
#include <libgen.h>
#include "libperiodicfileupload.h"
#include "periodicfileupload.h"

#define ME "libperiodicup"
#define str_empty(str) (str == NULL || str[0] == '\0')

/**
 * @brief Closes two file descriptors if their values are valid.
 *
 * @param fd1 First file descriptor.
 * @param fd2 Second file descriptor.
 */
static void close_two_fds(int fd1, int fd2) {
    if(fd1 >= 0) {
        close(fd1);
    }
    if(fd2 >= 0) {
        close(fd2);
    }
}

/**
 * @brief Timer callback for HTTP request retry
 *
 * Called when the retry timer expires to initiate a new upload attempt
 * for a failed HTTP request.
 *
 * @param[in] timer Timer object that triggered (unused)
 * @param[in] priv Private data containing pfu_file_t pointer
 */
static void pfu_http_retry_request(UNUSED amxp_timer_t* timer, void* priv) {
    pfu_file_t* file = (pfu_file_t*) priv;

    SAH_TRACEZ_NOTICE(ME, "Retry for file %s", file->id);
    pfu_do_request(file, true);
}

/**
 * @brief HTTP response callback handler
 *
 * Processes the HTTP response and handles success, failure, and retry logic.
 * Manages cleanup of temporary files and retry scheduling.
 *
 * @param[in] req HTTP request object containing response data
 * @param[in] priv Private data containing pfu_file_t pointer
 *
 * @return true to indicate callback completion
 *
 * @note On success: deletes retry timer and cleans up compressed files
 * @note On failure with retry enabled: schedules retry with exponential backoff
 * @note On failure without retry: cleans up compressed files immediately
 * @note Calls pfu_post_transfer for final success/failure without retry
 */
static bool pfu_http_response(ftx_request_t* req, void* priv) {
    pfu_file_t* file = (pfu_file_t*) priv;
    periodicfileupload_state_t state = pfu_state_error;

    when_null(file, exit);
    if(ftx_request_get_error_code(req) == ftx_error_code_no_error) {
        state = pfu_state_success;
        amxp_timer_delete(&file->http_retry_timer);
        if(!str_empty(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN))) {
            unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
            amxc_string_delete(&file->compressed_name);
        }
    } else {
        if(file->http_retry_timer != NULL) {
            amxp_timer_start(file->http_retry_timer, file->http_retry_wait_time * file->http_retry_time_multiplier);
            pfu_transfer_cb(file, pfu_state_retrying, ftx_request_get_error_code(req));
            if(file->http_nb_retry < HTTP_RETRY_MAX_NB_INCR) {
                ++file->http_nb_retry;
                file->http_retry_wait_time *= HTTP_RETRY_WAIT_TIME_MULTIPLIER;
            }
        } else if(!str_empty(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN))) {
            unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
            amxc_string_delete(&file->compressed_name);
        }
        SAH_TRACEZ_WARNING(ME, "HTTP request ended with: %d (%s)", ftx_request_get_error_code(req), ftx_request_get_error_reason(req));
    }
exit:
    if((ftx_request_get_error_code(req) == ftx_error_code_no_error) || (file->http_retry_timer == NULL)) {
        pfu_post_transfer(file, state, ftx_request_get_error_code(req));
    }
    ftx_request_delete(&req);
    return true;
}

/**
 * @brief Removes the "file://" scheme from a URI if present
 *
 * This function examines the URI contained in the amxc variant and removes
 * the "file://" prefix if it is present at the beginning of the URI.
 * If the URI does not start with "file://", it remains unchanged.
 *
 * @param[in,out] uri Pointer to the amxc_var_t containing the URI to process.
 *                    Must be of type AMXC_VAR_ID_CSTRING.
 *                    Can be NULL (function returns without effect).
 *
 */
static void remove_file_scheme (amxc_var_t* uri) {
    char* original_uri = NULL;
    const char* file_scheme = URI_FILE_SCHEME;
    size_t scheme_len = strlen(file_scheme);

    when_null(uri, exit);
    when_str_empty(amxc_var_constcast(cstring_t, uri), exit);
    original_uri = strdup(amxc_var_constcast(cstring_t, uri));
    if(strncmp(original_uri, file_scheme, scheme_len) == 0) {
        amxc_var_set(cstring_t, uri, original_uri + scheme_len);
    }
exit:
    free(original_uri);
    return;
}
/**
 * @brief Recursively searches for first occurrence of a key in variant data
 *
 * Traverses a variant structure (hashtable or list) to find the first
 * occurrence of the specified key, supporting nested data structures.
 *
 * @param[in] key Key name to search for
 * @param[in] ret Variant data structure to search in
 *
 * @return Pointer to first found value, NULL if key not found
 */
static amxc_var_t* get_first_value_from_var(const char* key, amxc_var_t* ret) {
    amxc_var_t* rv = NULL;

    switch(amxc_var_type_of(ret)) {
    case AMXC_VAR_ID_HTABLE:
        rv = GET_ARG(ret, key);
        break;
    case AMXC_VAR_ID_LIST:
        amxc_var_for_each(item, ret) {
            rv = get_first_value_from_var(key, item);
            if(rv != NULL) {
                break;
            }
        }
        break;
    default:
        break;
    }
    return rv;
}

/**
 * @brief Extracts the engine name from a URI scheme.
 *
 * @param uri The URI string to parse
 * @return const char* The corresponding engine name, or NULL if no match found
 */
static const char* get_engine_from_uri(const char* uri) {
    static struct {const char* scheme; const char* engine;} engine_mnemo[] = {
        {"pkcs11:", "pkcs11"},
    };

    when_str_empty(uri, exit);
    for(uint32_t i = 0; i < STRUCT_ARRAY_SIZE(engine_mnemo); ++i) {
        if(strncmp(uri, engine_mnemo[i].scheme, strlen(engine_mnemo[i].scheme)) == 0) {
            return engine_mnemo[i].engine;
        }
    }
exit:
    return NULL;
}

/**
 * @brief Configures HTTPS settings for HTTP request
 *
 * Sets up SSL/TLS certificates and CA bundles for secure HTTPS connections
 * by retrieving certificate information from the data model.
 *
 * @param[in] req HTTP request object to configure
 * @param[in] http_dm HTTP configuration from data model
 *
 * @return 0 on success, non-zero on failure
 *
 * @note Configures CA certificates if CABundle is specified
 * @note Sets up client certificates if Certificate is specified
 * @note Uses data model calls to retrieve certificate URIs (Device.Security.)
 */
static int pfu_http_request_https(ftx_request_t* req, amxc_var_t* http_dm) {
    int rv = 0;
    amxc_var_t dm;
    amxc_string_t cabundle_dotted_path;
    amxc_string_t certificate_dotted_path;
    amxc_var_t cafile;
    amxc_var_t args;
    amxc_var_t ret;
    amxb_bus_ctx_t* ctx = amxb_be_who_has(SECURITY_ROOT_DM_PATH);

    amxc_string_init(&cabundle_dotted_path, 0);
    amxc_string_init(&certificate_dotted_path, 0);
    amxc_var_init(&cafile);
    amxc_var_init(&dm);
    amxc_var_init(&args);
    amxc_var_init(&ret);
    when_null_status(ctx, exit, SAH_TRACEZ_ERROR(ME, "Couldn't get bus ctx for %s", SECURITY_ROOT_DM_PATH); rv = -1);
    if(!str_empty(GET_CHAR(http_dm, "CABundle"))) {
        amxc_string_setf(&cabundle_dotted_path, "%s.", GET_CHAR(http_dm, "CABundle"));
        amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
        rv = amxb_call(ctx, amxc_string_get(&cabundle_dotted_path, 0), "CAFile", &args, &ret, AMXB_CALL_TIMEOUT);
        when_failed_trace(rv, exit, ERROR, "Couldn't get CABundle datamodel for %s (%d)", amxc_string_get(&cabundle_dotted_path, 0), rv);
        amxc_var_set(cstring_t, &cafile, GET_CHAR(get_first_value_from_var("CAFile", &ret), NULL));
        remove_file_scheme(&cafile);
        rv = amxb_call(ctx, amxc_string_get(&cabundle_dotted_path, 0), "CADir", &args, &ret, AMXB_CALL_TIMEOUT);
        when_failed_trace(rv, exit, ERROR, "Couldn't call CABundle.CADir() for %s (%d)", amxc_string_get(&cabundle_dotted_path, 0), rv);
        remove_file_scheme(get_first_value_from_var("CADir", &ret));
        ftx_request_set_ca_certificates(req, GET_CHAR(&cafile, NULL), GET_CHAR(get_first_value_from_var("CADir", &ret), NULL));
    }
    if(!str_empty(GET_CHAR(http_dm, "Certificate"))) {
        amxc_string_setf(&certificate_dotted_path, "%s.", GET_CHAR(http_dm, "Certificate"));
        amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
        rv = amxb_call(ctx, amxc_string_get(&certificate_dotted_path, 0), "GetCertificateURI", &args, &ret, AMXB_CALL_TIMEOUT);
        when_failed_trace(rv, exit, ERROR, "Couldn't call Certificate.GetCertificateURI() for %s (%d)", amxc_string_get(&certificate_dotted_path, 0), rv);
        remove_file_scheme(get_first_value_from_var("CertificateURI", &ret));
        remove_file_scheme(get_first_value_from_var("PrivateKeyURI", &ret));
        ftx_request_set_client_certificates(req, get_engine_from_uri(GET_CHAR(get_first_value_from_var("PrivateKeyURI", &ret), NULL)), GET_CHAR(get_first_value_from_var("CertificateURI", &ret), NULL), GET_CHAR(get_first_value_from_var("PrivateKeyURI", &ret), NULL));
    }
exit:
    amxc_string_clean(&cabundle_dotted_path);
    amxc_string_clean(&certificate_dotted_path);
    amxc_var_clean(&cafile);
    amxc_var_clean(&dm);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Adds custom HTTP header from data model reference
 *
 * Retrieves a header value from a data model reference and adds it
 * as an HTTP header to the request.
 *
 * @param[in] req HTTP request object to add header to
 * @param[in] name Header name
 * @param[in] reference Data model path reference for header value
 *
 * @return 0 on success, -1 on failure
 *
 * @note Validates that referenced value exists and is not empty
 * @note Uses amxb_get to retrieve value from data model
 */
static int pfu_http_request_add_custom_header_ref(ftx_request_t* req, const char* name, const char* reference) {
    amxc_var_t ret;
    const amxc_htable_t* htable = NULL;
    char* value = NULL;
    int rv = -1;

    amxc_var_init(&ret);
    when_failed_trace(amxb_get(get_periodicfileupload_bus(), reference, AMXB_GET_DEPTH, &ret, AMXB_GET_TIMEOUT), exit, ERROR, "Couldn't amxb_get ref %s", reference);
    htable = amxc_var_constcast(amxc_htable_t, GETP_ARG(&ret, "0.0."));
    when_true_trace((htable == NULL) || (amxc_htable_get_first(htable) == NULL) || (amxc_htable_it_get_data(amxc_htable_get_first(htable), amxc_var_t, hit) == NULL), exit, ERROR, "Couldn't get the variable value: %s", reference);
    value = amxc_var_dyncast(cstring_t, amxc_htable_it_get_data(amxc_htable_get_first(htable), amxc_var_t, hit));
    when_str_empty_trace(value, exit, ERROR, "Value can't be empty for name %s -> %s", name, reference);
    rv = ftx_request_set_http_header(req, name, value);
exit:
    free(value);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Adds all custom HTTP headers to request
 *
 * Iterates through RequestHeaderParameter objects in the profile configuration
 * and adds them as HTTP headers, supporting both direct values and references.
 *
 * @param[in] req HTTP request object to add headers to
 * @param[in] file File transfer object containing profile path
 * @param[in] dm Complete data model containing header configurations
 *
 * @return 0 on success, -1 on failure
 *
 * @note Validates header names are not empty
 */
static int pfu_http_request_add_custom_headers(ftx_request_t* req, pfu_file_t* file, amxc_var_t* dm) {
    int rv = -1;
    amxc_string_t expected_path;

    amxc_string_init(&expected_path, 0);
    amxc_string_setf(&expected_path, "%sHTTP.RequestHeaderParameter.", file->profile_path);
    amxc_var_for_each(obj, GETP_ARG(dm, "0.")) {
        if(strcmp(amxc_var_key(obj), amxc_string_get(&expected_path, AMXC_STRING_BEGIN)) == 0) { // Case for template object
            continue;
        }
        if(strncmp(amxc_var_key(obj), amxc_string_get(&expected_path, AMXC_STRING_BEGIN), amxc_string_text_length(&expected_path)) == 0) {
            when_str_empty_trace(GET_CHAR(obj, "Name"), exit, ERROR, "custom header Name parameter shouldn't empty");
            if(!str_empty(GET_CHAR(obj, "Value"))) {
                ftx_request_set_http_header(req, GET_CHAR(obj, "Name"), GET_CHAR(obj, "Value"));
            } else if(!str_empty(GET_CHAR(obj, "Reference"))) {
                when_failed(pfu_http_request_add_custom_header_ref(req, GET_CHAR(obj, "Name"), GET_CHAR(obj, "Reference")), exit);
            }
        }
    }
    rv = 0;
exit:
    amxc_string_clean(&expected_path);
    return rv;
}

/**
 * @brief Adds URL parameter from data model reference
 *
 * Retrieves a parameter value from a data model reference and adds it
 * as a URL query parameter.
 *
 * @param[in,out] url URL string to append parameter to
 * @param[in] name Parameter name
 * @param[in] reference Data model path reference for parameter value
 * @param[in] nb_param Number of existing parameters (for ? vs & separator)
 *
 * @return 0 on success, -1 on failure
 *
 * @note Validates that referenced value exists and is not empty
 */
static int pfu_http_forge_request_url_reference(amxc_string_t* url, const char* name, const char* reference, uint32_t nb_param) {
    amxc_var_t ret;
    const amxc_htable_t* htable = NULL;
    char* value = NULL;
    int rv = -1;

    amxc_var_init(&ret);
    when_failed_trace(amxb_get(get_periodicfileupload_bus(), reference, AMXB_GET_DEPTH, &ret, AMXB_GET_TIMEOUT), exit, ERROR, "Couldn't amxb_get ref %s", reference);
    htable = amxc_var_constcast(amxc_htable_t, GETP_ARG(&ret, "0.0."));
    when_true_trace((htable == NULL) || (amxc_htable_get_first(htable) == NULL) || (amxc_htable_it_get_data(amxc_htable_get_first(htable), amxc_var_t, hit) == NULL), exit, ERROR, "Couldn't get the variable value: %s", reference);
    value = amxc_var_dyncast(cstring_t, amxc_htable_it_get_data(amxc_htable_get_first(htable), amxc_var_t, hit));
    when_str_empty_trace(value, exit, ERROR, "Value can't be empty for name %s -> %s", name, reference);
    if(nb_param == 0) {
        amxc_string_appendf(url, "?%s=%s", name, value);
    } else {
        amxc_string_appendf(url, "&%s=%s", name, value);
    }
    rv = 0;
exit:
    free(value);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Constructs complete HTTP request URL
 *
 * Builds the full request URL by combining base URL, filename, and any
 * configured URI parameters from the profile configuration.
 *
 * @param[in] file File transfer object containing profile and file info
 * @param[in] dm Complete data model containing URL configuration
 * @param[out] url Constructed URL string
 *
 * @return 0 on success, -1 on failure
 *
 * @note Combines base URL with filename from file path
 * @note Adds query parameters from RequestURIParameter objects
 * @note Validates URL and filename are not empty
 */
static int pfu_http_forge_request_url(pfu_file_t* file, amxc_var_t* dm, amxc_string_t* url) {
    int rv = -1;
    amxc_var_t* http_dm = amxc_var_get_pathf(dm, AMXC_VAR_FLAG_DEFAULT, "0.'%sHTTP.'.", file->profile_path);
    amxc_string_t expected_path;
    uint32_t nb_param = 0;

    amxc_string_init(&expected_path, 0);
    when_null_trace(http_dm, exit, ERROR, "HTTP dm couldn't be found");
    when_str_empty_trace(GET_CHAR(http_dm, "URL"), exit, ERROR, "Profile %s has empty URL.", file->profile_path);
    when_str_empty_trace(basename(file->file_url), exit, ERROR, "Profile %s has no filename.", file->file_url);
    amxc_string_setf(url, "%s/%s", GET_CHAR(http_dm, "URL"), basename(file->file_url));
    amxc_string_setf(&expected_path, "%sHTTP.RequestURIParameter.", file->profile_path);
    amxc_var_for_each(obj, GETP_ARG(dm, "0.")) {
        if(strcmp(amxc_var_key(obj), amxc_string_get(&expected_path, AMXC_STRING_BEGIN)) == 0) {         // Case for template object
            continue;
        }
        if(strncmp(amxc_var_key(obj), amxc_string_get(&expected_path, AMXC_STRING_BEGIN), amxc_string_text_length(&expected_path)) == 0) {
            when_str_empty_trace(GET_CHAR(obj, "Name"), exit, ERROR, "custom URI Name parameter shouldn't empty");
            if(!str_empty(GET_CHAR(obj, "Reference"))) {
                when_failed(pfu_http_forge_request_url_reference(url, GET_CHAR(obj, "Name"), GET_CHAR(obj, "Reference"), nb_param), exit);
            } else {
                SAH_TRACEZ_ERROR(ME, "Value and Reference for %s can't be empty at the same time", GET_CHAR(obj, "Name"));
                goto exit;
            }
            ++nb_param;
        }
    }
    rv = 0;
exit:
    amxc_string_clean(&expected_path);
    return rv;
}

/**
 * @brief Initializes HTTP retry mechanism for file upload
 *
 * Sets up the retry timer and parameters for HTTP upload requests based on
 * the configuration from the data model. Only initializes if retry is enabled
 * and not already configured.
 *
 * @param[in] file File transfer object to configure retry for
 * @param[in] http_dm HTTP configuration from data model containing retry settings
 *
 * @note Only initializes if RetryEnable is true in configuration
 * @note Prevents double initialization by checking existing timer
 * @note Creates timer with pfu_http_retry_request callback
 */
static void pfu_http_request_init_retry(pfu_file_t* file, amxc_var_t* http_dm) {
    when_false(GET_BOOL(http_dm, "RetryEnable"), exit);
    when_true_trace(file->http_retry_timer != NULL, exit, ERROR, "Stop initiating retry, http_retry_timer already initialized");
    file->http_retry_wait_time = GET_UINT32(http_dm, "RetryMinimumWaitInterval");
    file->http_retry_time_multiplier = GET_UINT32(http_dm, "RetryIntervalMultiplier");
    file->http_nb_retry = 0;
    amxp_timer_new(&file->http_retry_timer, pfu_http_retry_request, file);
exit:
    return;
}

/**
 * @brief Compresses a file using zlib COMPRESS compression
 *
 * Creates a zlib-compressed version of the source file in the temporary
 * compression folder and updates the HTTP request to use the compressed file.
 * Uses zlib's high-level compress() function.
 *
 * @param[in] req HTTP request object to update with compressed file
 * @param[in] file File transfer object containing source file path
 *
 * @return 0 on success, -1 on failure
 *
 * @note Creates compressed file in COMPRESSION_TMP_FOLDER with .Z extension
 * @note Uses zlib's compress() function with default compression settings
 * @note Updates file->compressed_name with the compressed file path
 */
static int pfu_http_do_compress(ftx_request_t* req, pfu_file_t* file) {
    int fd_in = -1;
    int fd_out = -1;
    int rv = -1;
    struct stat st = {0};
    void* mapped_file = NULL;
    void* compressed_buffer = NULL;
    uLongf compressed_len = 0;

    amxc_string_new(&file->compressed_name, 0);
    amxc_string_setf(file->compressed_name, "%s/%s.Z", COMPRESSION_TMP_FOLDER, basename(file->file_url));
    fd_in = open(file->file_url, O_RDONLY);
    when_false_trace(fd_in != -1, exit, ERROR, "Couldn't open file %s", file->file_url);
    fd_out = open(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN), O_CREAT | O_RDWR | O_TRUNC, 0644);
    when_false_trace(fd_out != -1, exit, ERROR, "Couldn't open new file %s", amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    when_failed_trace(stat(file->file_url, &st), exit, ERROR, "Couldn't stat %s", file->file_url);
    compressed_len = compressBound(st.st_size);
    when_false_trace((mapped_file = mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd_in, 0)) != MAP_FAILED, exit, ERROR, "Couldn't map the file %s", file->file_url);
    when_null_trace((compressed_buffer = malloc(compressed_len)), exit, ERROR, "Couldn't allocate space for new file of size %lu", compressed_len);
    when_false_trace(compress((Bytef*) compressed_buffer, &compressed_len, mapped_file, st.st_size) == Z_OK, exit, ERROR, "Error while compress()");
    when_false_trace(write(fd_out, compressed_buffer, compressed_len) == (ssize_t) compressed_len, exit, ERROR, "Error while writing the compressed file");
    rv = ftx_request_set_target_file(req, amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
exit:
    if(rv != 0) {
        unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
        amxc_string_delete(&file->compressed_name);
    }
    free(compressed_buffer);
    munmap(mapped_file, st.st_size);
    close_two_fds(fd_in, fd_out);
    return rv;
}

/**
 * @brief Compresses a file using DEFLATE compression
 *
 * Creates a DEFLATE-compressed version of the source file in the temporary
 * compression folder and updates the HTTP request to use the compressed file.
 * Uses zlib library for compression with default compression level.
 *
 * @param[in] req HTTP request object to update with compressed file
 * @param[in] file File transfer object containing source file path
 *
 * @return 0 on success, -1 on failure
 *
 * @note Creates compressed file in COMPRESSION_TMP_FOLDER with .z extension
 * @note Uses Z_DEFAULT_COMPRESSION level for balanced speed/size ratio
 * @note Updates file->compressed_name with the compressed file path
 */
static int pfu_http_do_deflate(ftx_request_t* req, pfu_file_t* file) {
    int fd_in = -1;
    int fd_out = -1;
    int rv = -1;
    struct stat st = {0};
    void* mapped_file = NULL;
    void* compressed_buffer = NULL;
    uLongf compressed_len;
    z_stream ctx = {0};

    amxc_string_new(&file->compressed_name, 0);
    amxc_string_setf(file->compressed_name, "%s/%s.z", COMPRESSION_TMP_FOLDER, basename(file->file_url));
    fd_in = open(file->file_url, O_RDONLY);
    when_false_trace(fd_in != -1, exit, ERROR, "Couldn't open file %s", file->file_url);
    fd_out = open(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN), O_CREAT | O_RDWR | O_TRUNC, 0644);
    when_false_trace(fd_out != -1, exit, ERROR, "Couldn't open new file %s", amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    when_failed_trace(stat(file->file_url, &st), exit, ERROR, "Couldn't stat %s", file->file_url);
    compressed_len = compressBound(st.st_size);
    when_false_trace((mapped_file = mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd_in, 0)) != MAP_FAILED, exit, ERROR, "Couldn't map the file %s", file->file_url);
    when_null_trace((compressed_buffer = calloc(compressed_len + 1, sizeof(uint8_t))), exit, ERROR, "Couldn't allocate space for new file of size %lu", compressed_len);
    when_true_trace((deflateInit(&ctx, Z_DEFAULT_COMPRESSION) != Z_OK), exit, ERROR, "DeflateInit failed");
    ctx.next_in = mapped_file;
    ctx.avail_in = st.st_size;
    ctx.next_out = compressed_buffer;
    ctx.avail_out = compressed_len;
    rv = deflate(&ctx, Z_FINISH);
    deflateEnd(&ctx);
    when_false_trace(rv == Z_STREAM_END || rv == Z_OK, exit, ERROR, "Error while deflate(): %d", rv);
    when_false_trace(write(fd_out, compressed_buffer, compressed_len) == (ssize_t) compressed_len, exit, ERROR, "Error while writing the compressed file");
    rv = ftx_request_set_target_file(req, amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
exit:
    if(rv != 0) {
        unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
        amxc_string_delete(&file->compressed_name);
    }
    free(compressed_buffer);
    munmap(mapped_file, st.st_size);
    if(fd_in >= 0) {
        close(fd_in);
    }
    if(fd_out >= 0) {
        close(fd_out);
    }
    return rv;
}

/**
 * @brief Compresses a file using GZIP compression
 *
 * Creates a GZIP-compressed version of the source file in the temporary
 * compression folder and updates the HTTP request to use the compressed file.
 *
 * @param[in] req HTTP request object to update with compressed file
 * @param[in] file File transfer object containing source file path
 *
 * @return 0 on success, -1 on failure
 *
 * @note Creates compressed file in COMPRESSION_TMP_FOLDER with .gzip extension
 * @note Updates file->compressed_name with the compressed file path
 */
static int pfu_http_do_gzip(ftx_request_t* req, pfu_file_t* file) {
    int fd_in = -1;
    gzFile fd_out = NULL;
    int rv = -1;
    struct stat st = {0};
    void* mapped_file = NULL;

    amxc_string_new(&file->compressed_name, 0);
    amxc_string_setf(file->compressed_name, "%s/%s.gzip", COMPRESSION_TMP_FOLDER, basename(file->file_url));
    fd_out = gzopen(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN), "wb");
    when_null_trace(fd_out, exit, ERROR, "Couldn't open new file %s", amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    fd_in = open(file->file_url, O_RDONLY);
    when_false_trace(fd_in != -1, exit, ERROR, "Couldn't open file %s", file->file_url);
    when_failed_trace(stat(file->file_url, &st), exit, ERROR, "Couldn't stat file %s", file->file_url);
    when_false_trace((mapped_file = mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd_in, 0)) != MAP_FAILED, exit, ERROR, "Couldn't map the file %s", file->file_url);
    when_false_trace(gzwrite(fd_out, mapped_file, st.st_size) == st.st_size, exit, ERROR, "Error while writing the compressed file");
    rv = ftx_request_set_target_file(req, amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
exit:
    if(rv != 0) {
        unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
        amxc_string_delete(&file->compressed_name);
    }
    munmap(mapped_file, st.st_size);
    if(fd_in >= 0) {
        close(fd_in);
    }
    if(fd_out != NULL) {
        gzclose(fd_out);
    }
    return rv;
}

/**
 * @brief Handles file compression for HTTP upload requests
 *
 * Applies the configured compression method to the file before upload.
 * Supports multiple compression algorithms and sets appropriate HTTP headers.
 *
 * @param[in] req HTTP request object to configure
 * @param[in] file File transfer object containing compression settings
 * @param[in] http_dm HTTP configuration from data model
 * @param[in] is_retrying Flag indicating if this is a retry attempt
 *
 * @return 0 on success, -1 on failure
 *
 * @note Supports "Compress", "Deflate", and "GZIP" compression methods
 * @note Uses existing compressed file on retry attempts
 * @note Sets Content-Encoding HTTP header for compressed uploads
 * @note Skips compression if method is "None" or already compressed
 */
static int pfu_http_compress(ftx_request_t* req, pfu_file_t* file, amxc_var_t* http_dm, bool is_retrying) {
    int rv = -1;
    struct {int (* fn)(ftx_request_t*, pfu_file_t*); const char* mnemo; const char* http;} compress_fn[] = {
        {pfu_http_do_compress, "Compress", "compress"},
        {pfu_http_do_deflate, "Deflate", "deflate"},
        {pfu_http_do_gzip, "GZIP", "gzip"},
    };

    if(is_retrying && !str_empty(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN))) {
        when_failed(ftx_request_set_target_file(req, amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN)), exit);
    }
    when_true_status(is_retrying, exit, rv = 0);
    when_true_status(strcmp("None", GET_CHAR(http_dm, "Compression")) == 0, exit, rv = 0);
    when_not_null_trace(file->compressed_name, exit, ERROR, "Compression is requested while compressed_name is already set (%s)", amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    for(uint32_t i = 0; i < STRUCT_ARRAY_SIZE(compress_fn); ++i) {
        if(strcmp(compress_fn[i].mnemo, GET_CHAR(http_dm, "Compression")) == 0) {
            when_failed(ftx_request_set_http_header(req, "Content-Encoding", compress_fn[i].http), exit);
            rv = compress_fn[i].fn(req, file);
            break;
        }
    }
exit:
    return rv;
}

void pfu_http_request(pfu_file_t* file, amxc_var_t* dm, bool is_retrying) {
    amxc_var_t* http_dm = amxc_var_get_pathf(dm, AMXC_VAR_FLAG_DEFAULT, "0.'%sHTTP.'.", file->profile_path);
    amxc_var_t* profile_dm = amxc_var_get_pathf(dm, AMXC_VAR_FLAG_DEFAULT, "0.'%s'.", file->profile_path);
    ftx_request_t* req = NULL;
    amxc_string_t url;

    amxc_string_init(&url, 0);
    when_failed_trace(ftx_request_new(&req, ftx_request_type_upload, pfu_http_response), error, ERROR, "Couldn't create new HTTP request (libfiletransfer)");
    when_failed(ftx_request_set_data(req, file), error);
    when_failed_trace(access(file->file_url, F_OK), error, ERROR, "The file to be uploaded doesn't exist %s", file->file_url);
    when_failed(ftx_request_set_target_file(req, file->file_url), error);
    when_failed_trace(pfu_http_forge_request_url(file, dm, &url), error, ERROR, "Error while trying to forge URL for file: %s", file->id);
    when_failed(ftx_request_set_url(req, amxc_string_get(&url, AMXC_STRING_BEGIN)), error);
    if(strcmp(GET_CHAR(http_dm, "Method"), "POST") == 0) {
        when_failed(ftx_request_set_upload_method(req, ftx_upload_method_post), error);
    } else if(strcmp(GET_CHAR(http_dm, "Method"), "PUT") == 0) {
        when_failed(ftx_request_set_upload_method(req, ftx_upload_method_put), error);
    } else {
        SAH_TRACEZ_WARNING(ME, "Unknown method, using libfiletransfer default one");
    }
    if(!str_empty(GET_CHAR(http_dm, "Username"))) {
        // Not sure if any authentication works
        when_failed(ftx_request_set_credentials(req, ftx_authentication_any, GET_CHAR(http_dm, "Username"), GET_CHAR(http_dm, "Password")), error);
    }
    if(strcmp(GET_CHAR(profile_dm, "Protocol"), "HTTPS") == 0) {
        when_failed(pfu_http_request_https(req, http_dm), error);
    }
    if(!is_retrying && (file->interval != 0)) {
        pfu_http_request_init_retry(file, http_dm);
    }
    when_failed_trace(pfu_http_compress(req, file, http_dm, is_retrying), error, ERROR, "Error while compressing file");
    when_failed(pfu_http_request_add_custom_headers(req, file, dm), error);
    when_failed(ftx_request_set_preferred_ipversion(req, GET_INT32(http_dm, "IPVersion")), error);
    when_failed_trace(ftx_request_send(req), error, ERROR, "Failed to send the request");
    amxc_string_clean(&url);
    return;
error:
    amxc_string_clean(&url);
    ftx_request_delete(&req);
    pfu_post_transfer(file, pfu_state_error, ftx_error_code_invalid_arguments);
}
