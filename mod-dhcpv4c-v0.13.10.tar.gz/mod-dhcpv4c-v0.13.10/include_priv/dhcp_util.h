/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__DHCP_UTIL_H__)
#define __DHCP_UTIL_H__

#include <stdint.h>

#include <amxc/amxc.h>
#include <amxp/amxp_timer.h>

#define ERR_NO_ERROR         0
#define ERR_COM_NO_MEM       1
#define ERR_COM_NO_RESOURCES 2
#define ERR_COM_INV_PARAM    3
#define ERR_COM_INV_CONFIG   4
#define ERR_COM_INV_MSG      5
#define ERR_COM_INV_STATE    6
#define ERR_COM_UNEXP_COND   7
#define ERR_COM_INV_ID       8
#define ERR_COM_EAGAIN       9
#define ERR_COM_TIMEOUT      0x81
#define ERR_COM_INIT_FAIL    0x86

#define DHCLIENT_ERR_NONE                   0
#define DHCLIENT_ERR_LOCAL_RELEASE          1
#define DHCLIENT_ERR_REMOTE_NACK            2
#define DHCLIENT_ERR_RENEWING_TIMEOUT       3
#define DHCLIENT_ERR_REBINDING_TIMEOUT      4
#define DHCLIENT_ERR_REQUESTING_TIMEOUT     5
#define DHCLIENT_ERR_INFORM_TIMEOUT         6
#define DHCLIENT_ERR_XID_FAILURE            7
#define DHCLIENT_ERR_SERVER_IP_FAILURE      8
#define DHCLIENT_ERR_IP_ADDR_FAILURE        9
#define DHCLIENT_ERR_STATE_FAILURE          10
#define DHCLIENT_ERR_MSG_FAILURE            11
#define DHCLIENT_ERR_LINK_FAILURE           12
#define DHCLIENT_ERR_AUTHENTICATION_FAILURE 13

#define str_empty(x) ((x == NULL) || (*x == '\0'))

#define INFINITE_DELAY INT32_MAX

#define DHCP_IP_QUAD(addr) ((unsigned char*) &addr)[0], ((unsigned char*) &addr)[1], ((unsigned char*) &addr)[2], ((unsigned char*) &addr)[3]

uint32_t ip_to_classfull_mask(uint32_t ip);

// Create a raw socket and attach filter on it
int dhcp_util_create_raw_socket(const char* ifname, unsigned int port);

char* bin_to_hex(unsigned char* bin, int len);
unsigned char* hex_to_bin(const char* hex, unsigned int* len);
void get_timestamp(struct timeval* now);
void set_timer(amxp_timer_t* timer, struct timeval* tv);
void randomize_time(struct timeval* time, struct timeval* res);
void init_rand(void);

#endif // __DHCP_UTIL_H__
