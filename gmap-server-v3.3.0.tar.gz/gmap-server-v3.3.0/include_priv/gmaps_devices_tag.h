/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAPS_DEVICES_TAG_H__)
#define __GMAPS_DEVICES_TAG_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup gmaps_common_tags Common device tags
 *
 * @{
 */

#define GMAPS_DEVICES_TAG_DHCP "dhcp"
#define GMAPS_DEVICES_TAG_EDEV "edev"
#define GMAPS_DEVICES_TAG_HGW "hgw"
#define GMAPS_DEVICES_TAG_INTERFACE "interface"
#define GMAPS_DEVICES_TAG_LAN "lan"
#define GMAPS_DEVICES_TAG_LOGICAL "logical"
#define GMAPS_DEVICES_TAG_MAC "mac"
#define GMAPS_DEVICES_TAG_PHYSICAL "physical"
#define GMAPS_DEVICES_TAG_PLACEHOLDER "placeholder"
#define GMAPS_DEVICES_TAG_PROTECTED "protected"
#define GMAPS_DEVICES_TAG_RANDOMIZED_MAC "randomized_mac"
#define GMAPS_DEVICES_TAG_SELF "self"
#define GMAPS_DEVICES_TAG_UPNP "upnp"
#define GMAPS_DEVICES_TAG_USB "usb"

/** @} */

void GMAPS_PRIVATE gmaps_device_tag_device_init(amxd_object_t* device, gmap_device_priv_data_t* priv);
void GMAPS_PRIVATE gmaps_device_tag_device_clean(amxd_object_t* device, gmap_device_priv_data_t* priv);
amxc_set_t* GMAPS_PRIVATE gmaps_device_tag_parse(const ssv_string_t tags);
bool GMAPS_PRIVATE gmaps_device_tag_has(const amxd_object_t* device, const char* tag);
bool GMAPS_PRIVATE gmaps_device_tag_has_all(const amxd_object_t* device, const amxc_set_t* tags);

/**
 * Add tags to the Tags parameter of the given device object.
 * This function allows to set the tags of "physical", "self" and "lan".
 * As those may only be set at the creation of the device
 */
bool GMAPS_PRIVATE gmaps_device_tag_set_unchecked(amxd_object_t* device, const amxc_set_t* tags);

/**
 * Add tags to the Tags parameter of the given device object.
 * This function does not allow setting the tags to "physical", "self" and "lan".
 * This can only be done at the creation of the device
 */
bool GMAPS_PRIVATE gmaps_device_tag_set(amxd_object_t* device, const amxc_set_t* tags);
bool GMAPS_PRIVATE gmaps_device_tag_clear(amxd_object_t* device, const amxc_set_t* tags);
bool GMAPS_PRIVATE gmaps_device_tag_reset(amxd_object_t* device);

#ifdef __cplusplus
}
#endif

#endif // __GMAPS_DEVICES_TAG_H__