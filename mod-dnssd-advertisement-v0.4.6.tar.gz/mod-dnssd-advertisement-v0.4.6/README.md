# mod-dnssd-advertisement
## Using mod-dnssd-advertisement

This plugins is intended to be used with the [tr181-dnssd plugin](https://gitlab.com/prpl-foundation/components/core/plugins/tr181-dnssd) and, as for now, not available for the open source community.

## compile and install

```
make
sudo make install
```
## run test

No test are available for now.

## run plugin inside a Ambiorix Docker container

Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

### compile/install dependencies: (make + sudo make install)

mod_sahtrace

### run dependencies

tr181-dnssd

### activate mod_dnssd_advertise
```
sudo tr181-dnssd -D
```
if tr181-dnssd was already started, you need to restart it as the module is load with the odl file.

## tips & trick
### add a service to the data model
```
ubus call DNSSD.X_PRPL-COM_Advertise _add '{ "parameters":{"InstanceName":"ssh_test", "ApplicationProtocol":"ssh", "TransportProtocol":"TCP", "Enable":True, "Port":505}}'
ubus call DNSSD.X_PRPL-COM_Advertise.X.TextRecord _add '{ "parameters":{"Key":"deamon", "Value":"dropbear"}}'
```
Do not forget to remplace the X variable with the alias or index of the created advertised service.
This will create a service under /etc/umdns/ and restart the umdns deamon.
The service can be checked with avahi on an other client with :
```
$avahi-browse -d local _ssh._tcp --resolve
```
