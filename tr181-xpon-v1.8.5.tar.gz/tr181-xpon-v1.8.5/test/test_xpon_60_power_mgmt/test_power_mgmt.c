/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_power_mgmt.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>           /* needed by amxd_dm.h */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxm/amxm.h>                  /* amxm_module_t */
#include <amxd/amxd_object_function.h>  /* amxd_object_invoke_function() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "common_functions.h"   /* read_sig_alarm() */
#include "setup_and_teardown.h" /* setup_common() */
#include "xpon_trace.h"

#undef ME
#define ME "runtest"

static const char* const NAME_PARAMETER = "Name";
static const char* const ON_OFF_LOW_POWER = "On,Off,LowPower";

static amxd_dm_t dm;
static amxo_parser_t parser;

static void add_ONU_instance(void) {
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    amxc_var_t* const keys = amxc_var_add_key(amxc_htable_t, &args, "keys", NULL);
    assert_non_null(keys);
    v = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, "ONU-1");
    assert_non_null(v);

    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    v = amxc_var_add_key(csv_string_t, parameters, "PowerCapability", ON_OFF_LOW_POWER);
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("dm_instance_added", &args);
    assert_int_equal(rc, 0);

    /* Call handle_events() to trigger _onu_added() */
    handle_events();

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "ONU-1");
    assert_int_equal(amxd_object_get_param(obj, "PowerCapability", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), ON_OFF_LOW_POWER);
    assert_int_equal(amxd_object_get_param(obj, "PowerStatus", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "Error");

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void remove_ONU_instance(void) {
    amxc_var_t* v;
    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);

    call_xpon_mngr_pon_stat_function("dm_instance_removed", &args);

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_null(obj);

    amxc_var_clean(&args);
}

int test_power_mgmt_setup(UNUSED void** state) {
    setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);

    /**
     * Call read_sig_alarm() once. It triggers the timer to populate the XPON DM
     * at startup. It won't actually populate the DM: the call
     * 'get_list_of_instances(XPON.ONU)' fails because the dummy vendor module
     * does not implement it. But if read_sig_alarm() is not called, something
     * goes wrong in the unit tests.
     */
    read_sig_alarm();

    add_ONU_instance();

    return 0;
}

int test_power_mgmt_teardown(UNUSED void** state) {
    remove_ONU_instance();
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

static void test_change_power_mode(void) {
    amxc_var_t* v;
    amxc_var_t args;
    amxc_var_t ret;

    amxd_object_t* onu = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(onu);

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "PowerState", "Off");
    assert_non_null(v);

    const amxd_status_t rc =
        amxd_object_invoke_function(onu, "ChangePowerMode", &args, &ret);
    assert_int_equal(rc, amxd_status_deferred);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

static void test_set_change_power_mode_result(void) {
    amxc_var_t* v;
    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    /**
     * tr181-xpon assigns 1 as value to call_id upon 1st invocation of
     * change_power_mode() call on an ONU.
     */
    v = amxc_var_add_key(uint32_t, &args, "call_id", 1);
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "result", 0);
    assert_non_null(v);

    call_xpon_mngr_pon_stat_function("set_change_power_mode_result", &args);

    amxc_var_clean(&args);
}

/**
 * Call ChangePowerMode() and report result with set_change_power_mode_result().
 *
 * Call XPON.ONU.1.ChangePowerMode("Off") and check the function returns
 * amxd_status_deferred.
 *
 * Call set_change_power_mode_result() in the pon_stat namespace of tr181-xpon to
 * notify tr181-xpon of the result of the ChangePowerMode() call. Check that
 * set_change_power_mode_result() returns 0 to indicate success.
 */
void test_change_power_mode_and_vm_reporting_result(UNUSED void** state) {
    test_change_power_mode();
    test_set_change_power_mode_result();
}

/**
 * Call ChangePowerMode() with an invalid power state, namely "InvalidState".
 *
 * Check that the call returns amxd_status_invalid_arg.
 */
void test_change_power_mode_with_invalid_state(UNUSED void** state) {
    amxc_var_t* v;
    amxc_var_t args;
    amxc_var_t ret;

    amxd_object_t* onu = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(onu);

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "PowerState", "InvalidState");
    assert_non_null(v);

    const amxd_status_t rc =
        amxd_object_invoke_function(onu, "ChangePowerMode", &args, &ret);
    assert_int_equal(rc, amxd_status_invalid_arg);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

static void test_calling_set_change_power_mode_result_with_invalid_call_id(void) {
    amxc_var_t* v;
    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    /* Use a value for call_id which can't be valid. */
    v = amxc_var_add_key(uint32_t, &args, "call_id", 5555);
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "result", 0);
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("set_change_power_mode_result", &args);
    assert_int_equal(rc, -1);

    amxc_var_clean(&args);
}

/**
 * Call set_change_power_mode_result() with invalid call ID.
 *
 * Call XPON.ONU.1.ChangePowerMode("Off") and check the function returns
 * amxd_status_deferred.
 *
 * Call set_change_power_mode_result() in the pon_stat namespace of tr181-xpon
 * to notify tr181-xpon of the result of the ChangePowerMode() call. But use an
 * invalid call ID. Check that set_change_power_mode_result() returns -1
 * indicating an error occurred.
 */
void test_report_result_with_invalid_call_id(UNUSED void** state) {
    test_change_power_mode();
    test_calling_set_change_power_mode_result_with_invalid_call_id();
}

/**
 * Call ChangePowerMode() and let it time out.
 *
 * I do not see how I can check that ChangePowerMode() returns
 * amxd_status_timeout. But the test should at least trigger the function which
 * declares the ChangePowerMode() as timed out.
 */
void test_change_power_mode_times_out(UNUSED void** state) {
    int i;
    test_change_power_mode();
    /**
     * tr181-xpon lets ChangePowerMode() time out after 5 seconds. Call
     * read_sig_alarm() 6 times. read_sig_alarm() waits 1 s for a timer to
     * expire. So one of the last read_sig_alarm() calls should trigger the
     * function which declares the ChangePowerMode() as timed out.
     */
    for(i = 0; i < 6; ++i) {
        read_sig_alarm();
    }
}

