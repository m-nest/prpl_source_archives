/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __PERIODICFILEUPLOAD_H__
#define __PERIODICFILEUPLOAD_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <libperiodicfileupload.h>

#define PFU_ROOT_DM_PATH "PeriodicFileTransfer."
#define SECURITY_ROOT_DM_PATH "Device.Security."
#define AMXB_GET_TIMEOUT 1
#define AMXB_CALL_TIMEOUT 5
#define NEXT_TRANSFER_TIMER_STR_LEN 36
#define HTTP_RETRY_MAX_NB_INCR 10
#define HTTP_RETRY_WAIT_TIME_MULTIPLIER 2
#define AMXC_STRING_BEGIN 0
#define AMXB_GET_DEPTH 10
#define DEFAULT_PFU_INTERVAL 0
#define COMPRESSION_TMP_FOLDER "/tmp"
#define DEFAULT_PFU_TIMEREF "1970-01-01T00:00:00Z"
#define URI_FILE_SCHEME "file://"

#define STRUCT_ARRAY_SIZE(array) (sizeof(array) / sizeof(*array))

/**
 * @brief Status codes for the profiles availabilty
 *
 * Defines the possible status values returned by profile operations
 * in the periodic file transfer functionality.
 */
typedef enum pfu_profile_status_e {
    pfu_profile_status_ok = 0,          /**< Profile operation successful */
    pfu_profile_status_not_found,       /**< Profile not found */
    pfu_profile_status_unknown          /**< Unknown profile status */
} pfu_profile_status_t;

/**
 * @brief File upload management structure
 *
 * Contains all information and state for managing a periodic file upload,
 * including timing, callbacks, retry logic, and compression handling.
 */
typedef struct pfu_file_s {
    char* id;                                     /**< Unique identifier for this file upload */
    char* file_url;                               /**< Path to the file to be uploaded */
    char* profile_path;                           /**< Data model path to upload profile configuration */
    uint32_t interval;                            /**< Upload interval in seconds (0 = no periodic upload) */
    amxc_ts_t time_ref;                           /**< Reference timestamp for interval calculations */
    pfu_profile_status_t status;                  /**< Current status of the upload profile */
    periodicfileupload_state_t state;             /**< Current state of the file transfer */
    periodicfileupload_cb_t preupload_cb;         /**< Pre-upload callback function */
    void* preupload_data;                         /**< Private data for pre-upload callback */
    periodicfileupload_cb_t postupload_cb;        /**< Post-upload callback function */
    void* postupload_data;                        /**< Private data for post-upload callback */
    periodicfileupload_transfer_cb_t transfer_cb; /**< Transfer state change callback */
    void* transfer_data;                          /**< Private data for transfer callback */
    amxp_timer_t* upload_timer;                   /**< Timer for periodic uploads */
    uint32_t http_nb_retry;                       /**< Current number of HTTP retries performed */
    uint32_t http_retry_wait_time;                /**< Current retry wait time in seconds */
    uint32_t http_retry_time_multiplier;          /**< Multiplier for exponential backoff */
    amxp_timer_t* http_retry_timer;               /**< Timer for HTTP retry attempts */
    amxc_string_t* compressed_name;               /**< Path to compressed temporary file (if compression used) */
    bool empty_file_url;                          /**< State boolean for empty file url */
    amxc_llist_it_t lit;                          /**< List iterator for global file list */
} pfu_file_t;

/**
 * @brief Script execution context
 *
 * Manages the execution of pre-upload and post-upload scripts including
 * process control and timeout handling.
 */
typedef struct pfu_script_ctx_s {
    amxp_subproc_t* proc;                      /**< Subprocess object for script execution */
    const char* id;                            /**< File transfer ID associated with this script */
    amxp_timer_t* timeout_timer;               /**< Timer for script execution timeout */
} pfu_script_ctx_t;

/**
 * @brief Initiates an HTTP file upload request
 *
 * Creates and sends an HTTP upload request for the specified file using the
 * configured profile settings. Handles authentication, compression, custom
 * headers, and retry logic.
 *
 * @param[in] file File transfer object containing upload details
 * @param[in] dm Data model containing profile configuration
 * @param[in] is_retrying Flag indicating if this is a retry attempt
 */
void pfu_http_request(pfu_file_t* file, amxc_var_t* dm, bool is_retrying);

/**
 * @brief Handles post-transfer operations and scheduling
 *
 * Processes the completion of a file transfer by scheduling the next upload
 * interval, executing transfer callbacks, and running post-upload hooks.
 *
 * @param[in] file File transfer object
 * @param[in] state Final state of the transfer operation
 * @param[in] error_code Error code if transfer failed (0 for success)
 *
 * @return 0 on success, -1 on failure
 */
int pfu_post_transfer(pfu_file_t* file, periodicfileupload_state_t state, uint32_t error_code);

/**
 * @brief Gets the bus context for periodic file upload data model
 *
 * Returns the bus context that provides the periodic file upload data model
 * object by querying which backend handles the root data model path.
 *
 * @return Pointer to the bus context handling the PFU data model, or NULL if not found
 *
 * @note This is an inline function for performance
 * @note Uses PFU_ROOT_DM_PATH constant for the data model path
 */
amxb_bus_ctx_t* get_periodicfileupload_bus(void);

/**
 * @brief Executes a file upload request
 *
 * Initiates a file upload using the configured profile settings. Validates
 * the profile status and delegates to the appropriate protocol handler.
 *
 * @param[in] file File transfer object containing upload details
 * @param[in] is_retrying Flag indicating if this is a retry attempt
 *
 * @return 0 on success, -1 on failure
 *
 * @note Currently supports HTTP and HTTPS protocols only
 * @note Sets transfer state to uploading before starting request
 * @note Validates profile is enabled and available before proceeding
 * @note Retrieves fresh profile configuration from data model
 */
int pfu_do_request(pfu_file_t* file, bool is_retrying);

/**
 * @brief Executes transfer state change callback
 *
 * Updates the file transfer state and invokes the registered callback with
 * state information including error codes and next transfer timing.
 *
 * @param[in] file File transfer object
 * @param[in] state New transfer state
 * @param[in] error_code Error code for failed states (0 for success)
 *
 * @note Updates file->state before calling callback
 * @note Includes NextTransfer time for idle, success, retrying, and error states
 * @note Includes Error code for retrying and error states
 * @note Uses deferred signal manager call for callback execution
 */
void pfu_transfer_cb(pfu_file_t* file, periodicfileupload_state_t state, uint32_t error_code);

#ifdef __cplusplus
}
#endif

#endif // __PERIODICFILEUPLOAD_H__