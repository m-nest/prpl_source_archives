# tr181-usb Plugin Documentation
![USB logo](doc/img/usb_overview.png)

## Table of Contents
- [Introduction](#introduction)
- [Overview](#overview)
- [Architecture](#architecture)
- [APIs](#apis)
- [Power Management](#power-management)
- [Building, Installing, and Testing](#building-installing-and-testing)
- [Documentation](#documentation)

## Introduction

The `tr181-usb` plugin is designed to manage USB devices within the Ambiorix framework. It handles the addition and removal of USB devices and updates the data model accordingly.

## Overview

The `tr181-usb` plugin is built on top of the Ambiorix framework. It uses the `event2usb` to receive device events and updates the data model to reflect the current state of USB devices. The plugin provides APIs to add and remove USB devices and hosts. `event2usb` is a binary parser that retrieves USB information from environment variables when a USB event is triggered.

## Architecture

The `tr181-usb` plugin consists of several components, each responsible for different aspects of USB device management:

### Components

1. **tr181-usb Plugin**:
   - Receives Add/Del device events via `event2usb`.
   - Manages the `tr181-usb` data model by creating/removing objects.
   - Implements APIs to add/remove USB devices and hosts.
   - The plugin consists of the following parts:
     - **usb.c**: Initializes the plugin and handles the main entry points.
     - **usb_port.c**: Manages USB ports, including finding and creating ports.
     - **usb_host.c**: Manages USB hosts, including adding and removing devices.
     - **usb_dm.c**: Handles data model updates and device actions.
     - **usb_device.c**: Manages USB devices, including creating and deleting device objects.
     - **usb_controller.c**: Provides utility functions and error handling.
     - **usb_configuration.c**: Manages USB configurations and interfaces.

2. **hotplug2usb Module**:
   - By default, `event2usb` is provided by the `hotplug2usb` module that relies on `hotplug`.
   - The `event2usb` is called by Linux hotplug each time a new device is added or deleted in the file system.
   - The `event2usb` will then send notifications via `ubus` with information related to the devices to `tr181-usb` to inform about the USB devices' insertion and removal.

3. **mdev2usb Module**:
   - This module is used when the `CONFIG_AMX_TR181_USB_BUSYBOX_MDEV_OPTIONS` token is enabled.
   - Implements the `event2usb` binary.
   - The `event2usb` is called by Busybox mdev each time a new device is added or deleted in the file system.
   - The `event2usb` will then send notifications via `ubus` with information related to the devices to `tr181-usb` to inform about the USB devices' insertion and removal.

4. **mod-usb-filter**:
   - This modules extends the tr181-usb plugin with USB filtering functionality that makes it possible to unauthorize certain USB devices making them unusable on the system.
   - All USB devices are authorized (allowed) by default. This can be changed by disabling `USB.USBHosts.AllowAllDevices` in the data model. Doing this unauthorizes all USB devices that do not have a matching `USB.USBHosts.AllowedDevice` instance (see below).
   - It is possible to configure a whitelist of authorized USB devices when `USB.USBHosts.AllowAllDevices` is set to false by adding `USB.USBHosts.AllowedDevice` instances where the parameters match the USB attributes reported by the USB interface.

5. **mod-pwr-dummy**:
   - Implements a framework for power management integration. It gets the system PowerCapability and PowerStatus via LL-API. This module is a template for future hardware-specific power management implementations.

### Data Flow:
1. **Event Handling**: `event2usb` triggers events for device addition/removal.
2. **Data Model Update**: The plugin updates the data model based on the events.
3. **Power Management**: Power mode changes are handled asynchronously and reflected in the data model.

## APIs

The `tr181-usb` plugin provides the following APIs:

### addBus
Creates a USB host controller.
- **Parameters**:
  - `busnum`: The bus number.
  - `usbversion`: The USB version.
  - `usbtype`: The USB type.
- **Example**: `addBus(busnum="4", usbversion="3.10", usbtype="xHCI")`

### addDev
Creates a USB device.
- **Parameters**:
  - `type`: The device type.
  - `sysfs`: The sysfs ID.
  - `name`: The device name.
- **Example**: `addDev(type="disk", sysfs="4-1", name="sda")`

### delDev
Removes a USB device.
- **Parameters**:
  - `type`: The device type.
  - `sysfs`: The sysfs ID.
  - `name`: The device name.
- **Example**: `delDev(type="disk", sysfs="4-1", name="sda")`

### ChangePowerMode
Changes the PowerStatus of a USB Port asynchronously.
- **Parameters**:
  - `PowerState`: The power mode name.
- **Example**: `ChangePowerMode(PowerState="On")`

The plugin supports power management for USB Ports. It provides to change the power mode of a USB Port via the data model or through the provided API. Power mode changes are handled asynchronously. The status of the operation is updated in the data model once the operation completes.

## Power Management

This service supports USB Port power management capabilities, allowing each port to be configured in different power states. The power management feature includes:

- **Power Capability** - The `PowerCapability` parameter describes the possible power states supported by the port (for example `On`, `Off`, `LowPower`).
- **Power Status** - The `PowerStatus` parameter reports the current power state of the port.
- **Power State** - The `PowerState` parameter stores the requested target power state.
- **ChangePowerMode** - An asynchronous function `ChangePowerMode(PowerState)` that triggers a power state transition.

### External Modules

Power management is implemented through power controller modules that can be developed in a separate repository:

- Power controller modules are loaded from `tr181-usb.mod-dir` (default: `/usr/lib/amx/tr181-usb/modules`).
- Modules must register the AMXM module name `pwr-ctrl` and expose `pwr-mode-set`, `pwr-capabilities-get`, and `pwr-status-get`.
- The selected controller can be configured globally with `USB.PowerController` or per port with `USB.Port.{i}.PowerController`.
- `ChangePowerMode()` is deferred and must be completed by the controller through the internal callback function `pwr-async-done`.
- The in-tree `mod-pwr-dummy` module is a reference implementation that can be reused as a template.

For detailed information on implementing a USB power management module in a separate repository, including required function signatures, return keys, asynchronous completion, and integration steps, see [POWER_MODULE_API.md](POWER_MODULE_API.md).

### Notes:
- The USB device system name is exposed in the data model via the protected parameter `SysDevName`.
  Example: `USB.USBHosts.Host.4.Device.1.SysDevName="/dev/sda"`.

- The USB driver modules must be loaded at target startup by the system.

## Building, Installing, and Testing

### Docker Container

You could install all tools needed for testing and developing on your local machine, or use a pre-configured environment. Such an environment is already prepared for you as a Docker container.

1. **Install Docker**

    Docker must be installed on your system. Here are some links that could help you:

    - [Get Docker Engine - Community for Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

    Make sure your user ID is added to the Docker group:

        sudo usermod -aG docker $USER

2. **Fetch the Container Image**

    To get access to the pre-configured environment, pull the image and launch a container.

    Pull the image:

        docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    Before launching the container, you should create a directory which will be shared between your local machine and the container.

        mkdir -p ~/amx/libraries/

    Launch the container:

        docker run -ti -d \
            --name oss-dbg \
            --restart=always \
            --cap-add=SYS_PTRACE \
            --sysctl net.ipv6.conf.all.disable_ipv6=1 \
            -e "USER=$USER" \
            -e "UID=$(id -u)" \
            -e "GID=$(id -g)" \
            -v ~/amx:/home/$USER/amx \
            registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    The `-v` option bind mounts the local directory for the AMX project in the container, at the exact same place. The `-e` options create environment variables in the container. These variables are used to create a user name with exactly the same user ID and group ID in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

        docker exec -ti --user $USER oss-dbg /bin/bash

### Building

#### Prerequisites

`tr181-usb` depends on the following libraries:

- libamxb
- libamxc
- libamxd
- libamxm
- libamxo
- libamxp
- libsahtrace
- libsysfs

These libraries can be installed in the container:

    sudo apt-get install libamxb libamxc libamxd libamxm libamxo libamxp mod-sahtrace sah-lib-sahtrace-dev

#### Required Kernel Modules
USB devices require a set of kernel modules to be available depending on the target in order to be correctly detected. The most important are:

- CONFIG_USB
- CONFIG_USB_ACM
- CONFIG_USB_ARCH_HAS_HCD
- CONFIG_USB_COMMON
- CONFIG_USB_EHCI_HCD
- CONFIG_USB_EHCI_HCD_PLATFORM
- CONFIG_USB_EHCI_PCI
- CONFIG_USB_OHCI_HCD
- CONFIG_USB_OHCI_HCD_PCI
- CONFIG_USB_OHCI_HCD_PLATFORM
- CONFIG_USB_OHCI_LITTLE_ENDIAN
- CONFIG_USB_PCI
- CONFIG_USB_STORAGE
- CONFIG_USB_SUPPORT
- CONFIG_USB_UAS
- CONFIG_USB_XHCI_HCD
- CONFIG_USB_XHCI_PCI
- CONFIG_USB_XHCI_PLATFORM

#### Build tr181-usb

1. **Clone the Git Repository**

    To be able to build it, you need the source code. So open the directory just created for the Ambiorix project and clone this library in it (on your local machine).

        cd ~/amx/plugins/
        git clone git@gitlab.com:prpl-foundation/components/core/plugins/tr181-usb.git

2. **Build it**

        cd ~/amx/plugins/tr181-usb
        make

### Installing

#### Using make target install

You can install your own compiled version easily in the container by running the install target.

    cd ~/amx/plugins/tr181-usb
    sudo make install

#### Using package

From within the container you can create packages.

    cd ~/amx/plugins/tr181-usb
    make package

The packages generated are:

    ~/amx/plugins/tr181-usb/tr181-usb_<VERSION>.tar.gz
    ~/amx/plugins/tr181-usb/tr181-usb_<VERSION>.deb

You can copy these packages and extract/install them.

For Ubuntu or Debian distributions use dpkg:

    sudo dpkg -i ~/amx/plugins/tr181-usb/tr181-usb_<VERSION>.deb

### Testing

#### Prerequisites

No extra components are needed for testing `tr181-usb`. Make sure to install all Ambiorix libraries (including libamxut for unit tests) and these extra libs from PRPL: libsahtrace, mod-dmext, mod-amxb-dummy and these libs: libsysfs-dev, libbsd-dev. An up-to-date list of compile time dependencies can be found in the makefile: ~/amx/plugins/tr181-usb/src/Makefile.

For more details on development environment: https://gitlab.com/prpl-foundation/components/ambiorix/tutorials/getting-started#the-development-environment.

#### Run tests

You can run the tests by executing the following command:

    cd ~/amx/plugins/tr181-usb/test
    make

Or this command if you also want the coverage tests to run:

    cd ~/amx/plugins/tr181-usb/tests
    make run coverage

You can combine both commands:

    cd ~/amx/plugins/tr181-usb
    make test

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each C-file is printed in your console after the tests are run. A HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used. For example, when using native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/amx/plugins/tr181-usb/output/x86_64-linux-gnu/coverage/report`.

You can easily access the reports in your browser. In the container, start a python3 HTTP server in the background.

    cd ~/amx/
    python3 -m http.server 8080 &

Use the following URL to access the reports:

    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-usb/output/<MACHINE>/coverage/report

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    USER@<CID>:~/amx/plugins/tr181-usb$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is:
`http://172.17.0.3:8080/plugins/tr181-usb/output/x86_64-linux-gnu/coverage/report/`

### Documentation

#### Prerequisites

To generate the documentation, [Doxygen](https://www.doxygen.nl) is required and already available in the container. In case you want to install this on your local machine:

    sudo apt-get install doxygen

#### Paths

The documentation is split into two parts, starting from the repository path:

    cd ~/amx/plugins/tr181-usb

Here, you can find:

- README.md: This file is used on GitLab and is the main page for the Doxygen documentation.
- docs directory: Contains the Doxygen settings, code examples, and additional pages used in Doxygen.

The code itself is documented in the appropriate header and source files.

#### Generate documentation

To generate the documentation, Doxygen needs to be installed. Alternatively, `amxo-cg` and `amxo-xml-to` packages can be installed to generate the documentation. You can generate the documentation by executing the following command:

    cd ~/amx/plugins/tr181-usb
    make doc

The full documentation is available in the `output` directory. You can easily access the documentation in your browser. As described in the coverage reports section, you can start an HTTP server in the container.

    cd ~/amx/
    python3 -m http.server 8080 &

Use the following URL to access the reports:

    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-usb/output/html/index.html

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    USER@<CID>:~/amx/plugins/tr181-usb$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is:
`http://172.17.0.3:8080/plugins/tr181-usb/output/html/index.html`

Alternatively, you can open the documentation via command:

    xdg-open tr181-usb/output/html/index.html
