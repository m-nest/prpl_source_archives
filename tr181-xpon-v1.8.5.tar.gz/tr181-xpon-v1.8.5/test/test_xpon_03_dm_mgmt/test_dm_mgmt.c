/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_dm_mgmt.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>           /* needed by amxd_dm.h */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "common_functions.h"   /* read_sig_alarm() */
#include "setup_and_teardown.h" /* setup_common() */
#include "xpon_trace.h"

static const char* const NAME_PARAMETER = "Name";

#undef ME
#define ME "runtest"

static amxd_dm_t dm;
static amxo_parser_t parser;

int test_setup(UNUSED void** state) {
    setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);

    /**
     * Call read_sig_alarm() once. It triggers the timer to populate the XPON DM
     * at startup. It won't actually populate the DM: the call
     * 'get_list_of_instances(XPON.ONU)' fails because the dummy vendor module
     * does not implement it. But if read_sig_alarm() is not called, something
     * goes wrong in the unit tests.
     */
    read_sig_alarm();

    return 0;
}

int test_teardown(UNUSED void** state) {
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

static void test_adding_ONU_instance_common(const char* func_name) {
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    SAH_TRACEZ_INFO(ME, "** test_adding_ONU_instance() **");
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    amxc_var_t* const keys = amxc_var_add_key(amxc_htable_t, &args, "keys", NULL);
    assert_non_null(keys);
    v = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, "ONU-1");
    assert_non_null(v);

    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    v = amxc_var_add_key(cstring_t, parameters, "Version", "0123456789ABCD");
    assert_non_null(v);
    v = amxc_var_add_key(cstring_t, parameters, "EquipmentID", "0123456789ABCDEFGHIJ");
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function(func_name, &args);
    assert_int_equal(rc, 0);

    /* Call handle_events() to trigger _onu_added() */
    handle_events();

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "ONU-1");

    assert_int_equal(amxd_object_get_param(obj, "Version", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "0123456789ABCD");
    assert_int_equal(amxd_object_get_param(obj, "EquipmentID", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "0123456789ABCDEFGHIJ");

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void test_adding_ONU_instance(void) {
    test_adding_ONU_instance_common("dm_instance_added");
}

static void test_adding_ANI_instance(void) {

    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    SAH_TRACEZ_INFO(ME, "** test_adding_ANI_instance() **");
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU.1.ANI");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    amxc_var_t* const keys = amxc_var_add_key(amxc_htable_t, &args, "keys", NULL);
    assert_non_null(keys);
    v = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, "ANI-1");
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("dm_instance_added", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "ANI-1");

    /* Call handle_events() to trigger _ani_added() */
    handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void test_modifying_ONU_instance_with_dm_object_changed(void) {
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    SAH_TRACEZ_INFO(ME, "** test_modifying_ONU_instance_with_dm_object_changed() **");
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);
    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    v = amxc_var_add_key(cstring_t, parameters, "Version", "ABCD9876543210");
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("dm_object_changed", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, "Version", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "ABCD9876543210");

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void test_modifying_ONU_instance_with_dm_add_or_change_instance(void) {
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    SAH_TRACEZ_INFO(ME, "** test_modifying_ONU_instance_with_dm_add_or_change_instance() **");
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);

    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    v = amxc_var_add_key(cstring_t, parameters, "Version", "ABCD9876543210");
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("dm_add_or_change_instance", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, "Version", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "ABCD9876543210");

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void test_removing_ONU_instance(void) {
    amxc_var_t* v;
    amxc_var_t args;
    SAH_TRACEZ_INFO(ME, "** test_removing_ONU_instance() **");
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", 1);
    assert_non_null(v);

    const int rc = call_xpon_mngr_pon_stat_function("dm_instance_removed", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_null(obj);

    amxc_var_clean(&args);
}

static void test_adding_ONU_instance_with_dm_add_or_change_instance(void) {
    test_adding_ONU_instance_common("dm_add_or_change_instance");
}

void test_dm_mgmt(UNUSED void** state) {
    test_adding_ONU_instance();
    test_adding_ANI_instance();
    test_modifying_ONU_instance_with_dm_object_changed();
    test_modifying_ONU_instance_with_dm_add_or_change_instance();
    test_removing_ONU_instance();

    test_adding_ONU_instance_with_dm_add_or_change_instance();
    test_removing_ONU_instance();
}

