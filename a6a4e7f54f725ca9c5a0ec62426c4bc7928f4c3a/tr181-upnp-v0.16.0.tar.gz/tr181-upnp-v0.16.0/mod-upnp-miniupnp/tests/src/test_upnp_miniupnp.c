/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <fcntl.h>
#include <cmocka.h>

#include <string.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>

#include "upnp_miniupnp.h"
#include "test_upnp_miniupnp.h"

extern void generate_miniupnpd_uuid(void);
extern int create_miniupnpd_conf_file(void);
extern int init_config(UNUSED const char* function_name, amxc_var_t* args,
                       UNUSED amxc_var_t* ret);
extern char* miniupnpd_uuid;
extern char* ext_ifname;
extern char* ext_ifname6;
extern char* listening_ip;
extern amxc_var_t* plugin_config;
extern amxc_var_t* external_config;

static amxo_parser_t* parser = NULL;
static amxd_dm_t* dm = NULL;

extern int __real_open(const char*, int, ...);
extern ssize_t __real_read(int, void*, size_t);
extern int __real_close(int);
extern ssize_t __real_write(int, const void*, size_t);
extern char* __real_strdup(const char*);
extern FILE* __real_fopen(const char*, const char*);
extern ssize_t __real_fwrite(const void*, size_t, size_t, FILE*);
extern ssize_t __real_fread(void*, size_t, size_t, FILE*);
extern int __real_fclose(FILE*);
/* Flag to adjust behavior of mocked file operation function calls
 * without breaking other tests that use them */
static int g_open_strict = 0;

/* Wrapers */
int __wrap_open(const char* path, int flags, ...) {
    if(!g_open_strict) {
        va_list ap;
        mode_t mode = 0;
        if(flags & O_CREAT) {
            va_start(ap, flags);
            mode = (mode_t) va_arg(ap, int);
            va_end(ap);
            return __real_open(path, flags, mode);
        } else {
            return __real_open(path, flags);
        }
    }
    check_expected_ptr(path);
    check_expected(flags);
    return mock_type(int);
}

ssize_t __wrap_read(int fd, void* buf, size_t count) {
    if(!g_open_strict) {
        return __real_read(fd, buf, count);
    }
    check_expected(fd);
    check_expected(count);
    char* src = mock_ptr_type(char*);
    if(src) {
        memcpy(buf, src, count);
    }
    return mock_type(ssize_t);
}

ssize_t __wrap_write(int fd, const void* buf, size_t count) {
    if(!g_open_strict) {
        return __real_write(fd, buf, count);
    }

    check_expected(fd);
    check_expected(buf);
    check_expected(count);

    const char* expected_str = mock_ptr_type(const char*);
    if(expected_str) {
        assert_memory_equal(buf, expected_str, count);
    }
    return mock_type(ssize_t);
}

ssize_t __wrap_fread(void* ptr, size_t size, size_t nmemb, FILE* stream) {
    if(!g_open_strict) {
        return __real_fread(ptr, size, nmemb, stream);
    }

    check_expected_ptr(ptr);
    check_expected(size);
    check_expected(nmemb);
    check_expected_ptr(stream);

    char* src = mock_ptr_type(char*);
    if(src) {
        memcpy(ptr, src, size * nmemb);
    }
    return mock_type(ssize_t);
}

int __wrap_close(int fd) {
    if(!g_open_strict) {
        return __real_close(fd);
    }
    check_expected(fd);
    return 0;
}

FILE* __wrap_fopen(const char* path, const char* mode) {
    if(!g_open_strict) {
        return __real_fopen(path, mode);
    }
    check_expected_ptr(path);
    check_expected_ptr(mode);
    return mock_type(FILE*);
}

ssize_t __wrap_fwrite(const void* ptr, size_t size, size_t nmemb,
                      FILE* stream) {
    if(!g_open_strict) {
        return __real_fwrite(ptr, size, nmemb, stream);
    }

    check_expected_ptr(ptr);
    check_expected(size);
    check_expected(nmemb);
    check_expected_ptr(stream);

    const char* expected_str = mock_ptr_type(const char*);
    if(expected_str) {
        assert_memory_equal(ptr, expected_str, size * nmemb);
    }

    return mock_type(ssize_t);
}

int __wrap_fclose(FILE* stream) {
    if(!g_open_strict) {
        return __real_fclose(stream);
    }
    check_expected_ptr(stream);
    return 0;
}

char* __wrap_strdup(const char* s) {
    if(!g_open_strict) {
        return __real_strdup(s);
    }
    check_expected_ptr(s);
    return mock_ptr_type(char*);
}

/* Setup */
int test_setup(UNUSED void** state) {
    const char* odl = "%config { ip_intf_lan = \"Device.IP.Interface.3.\"; }";
    amxd_object_t* root = NULL;
    int retval = 0;
    miniupnpd_uuid = NULL;

    assert_int_equal(amxd_dm_new(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_new(&parser), 0);

    root = amxd_dm_get_root(dm);
    assert_non_null(root);

    retval = amxo_parser_parse_string(parser, odl, root);
    assert_int_equal(retval, 0);

    return 0;
}

int test_teardown(UNUSED void** state) {
    return 0;
}

/* Tests */
void test_mod_init(UNUSED void** state) {
    assert_non_null(amxo_parser_get_config(parser, "."));
    init_config(NULL, amxo_parser_get_config(parser, "."), NULL);
}

void test_generate_uuid_success(UNUSED void** state) {

    const char* fake_uuid = "12345678-1234-1234-1234-123456789abc";
    char* fake_strdup = strdup(fake_uuid);

    g_open_strict = 1;

    expect_string(__wrap_open, path, "/proc/sys/kernel/random/uuid");
    expect_value(__wrap_open, flags, O_RDONLY);
    will_return(__wrap_open, 42);

    expect_value(__wrap_read, fd, 42);
    expect_value(__wrap_read, count, strlen(fake_uuid));
    will_return(__wrap_read, (char*) fake_uuid);
    will_return(__wrap_read, (ssize_t) strlen(fake_uuid));

    expect_value(__wrap_close, fd, 42);

    expect_string(__wrap_strdup, s, fake_uuid);
    will_return(__wrap_strdup, fake_strdup);

    generate_miniupnpd_uuid();

    assert_non_null(miniupnpd_uuid);
    assert_string_equal(miniupnpd_uuid, fake_uuid);

    g_open_strict = 0;
}

/* Init the external config,
 * so that create_miniupnpd_conf_file can read values from it */
static void init_external_config(void) {
    ext_ifname = strdup("eth1");
    ext_ifname6 = strdup("eth1");
    listening_ip = strdup("br-lan");

    amxc_var_delete(&external_config);
    amxc_var_new(&external_config);
    amxc_var_set_type(external_config, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(bool, external_config, "enable_natpmp", true);
    amxc_var_add_key(bool, external_config, "enable_ipv6", true);
    amxc_var_add_key(bool, external_config, "allow_reserved_addr", true);

    amxc_var_add_key(cstring_t, external_config, "friendly_name",
                     "TestFriendlyName");
    amxc_var_add_key(cstring_t, external_config, "manufacturer_name",
                     "TestManufacturer");
    amxc_var_add_key(cstring_t, external_config, "manufacturer_url",
                     "http://test.com");
    amxc_var_add_key(cstring_t, external_config, "model_name", "TestModel");
    amxc_var_add_key(cstring_t, external_config, "model_description",
                     "TestModelDescription");
    amxc_var_add_key(cstring_t, external_config, "model_url",
                     "http://testmodel.com");
    amxc_var_add_key(cstring_t, external_config, "serial", "SN123456789");
    amxc_var_add_key(cstring_t, external_config, "upnp_amx_wan_interface",
                     "Device.Logical.Interface.1.");
    amxc_var_add_key(cstring_t, external_config, "wan_access_provider",
                     "TestISP");
}

/**
 * Test creating miniupnpd conf file when override file with saved UUID
 * is not present, so a new UUID is generated and saved.
 */
void test_create_miniupnpd_conf_file_success_no_override(UNUSED void** state) {
    const char* fake_uuid = "12345678-1234-1234-1234-123456789cba";
    char* fake_strdup = strdup(fake_uuid);
    const char* expected_override_content =
        "uuid=12345678-1234-1234-1234-123456789cba\n";
    int fake_uuid_fd = 42;
    int fake_miniupnpd_fd = 43;
    FILE* fake_override_file = (FILE*) 44;
    const char* expected_miniupnpd_conf_content =
        "ext_ifname=eth1\n"
        "ext_ifname6=eth1\n"
        "listening_ip=br-lan\n"
        "enable_natpmp=yes\n"
        "pf_allow_reserved_addr=yes\n"
        "ipv6_disable=no\n"
        "enable_upnp=yes\n"
        "secure_mode=yes\n"
        "system_uptime=yes\n"
        "force_igd_desc_v1=no\n"
        "bitrate_download=8388608\n"
        "bitrate_upload=4194304\n"
        "port=5000\n"
        "uuid=12345678-1234-1234-1234-123456789cba\n"
        "ext_perform_stun=no\n"
        "friendly_name=TestFriendlyName\n"
        "manufacturer_name=TestManufacturer\n"
        "manufacturer_url=http://test.com\n"
        "model_name=TestModel\n"
        "model_description=TestModelDescription\n"
        "model_url=http://testmodel.com\n"
        "serial=SN123456789\n"
        "upnp_amx_wan_interface=Device.Logical.Interface.1.\n"
        "wan_access_provider=TestISP\n"
        "allow 1024-65535 0.0.0.0/0 1024-65535\n"
        "deny 0-65535 0.0.0.0/0 0-65535\n";

    init_external_config();

    g_open_strict = 1;

    /* Expect creating miniupnpd conf file */
    expect_string(__wrap_open, path, MINIUPNP_CONF_FILE);
    expect_value(__wrap_open, flags, O_CREAT | O_TRUNC | O_WRONLY);
    will_return(__wrap_open, fake_miniupnpd_fd);

    /* Expect checking for override file */
    expect_string(__wrap_fopen, path, MINIUPNP_CONF_OVERRIDE_FILE);
    expect_string(__wrap_fopen, mode, "r");
    will_return(__wrap_fopen, NULL);  // Simulate file not existing

    /* Expect calls to generate_miniupnpd_uuid,
    * because override file does not exist, so
    * copy from test_generate_miniupnpd_uuid */
    expect_string(__wrap_open, path, "/proc/sys/kernel/random/uuid");
    expect_value(__wrap_open, flags, O_RDONLY);
    will_return(__wrap_open, fake_uuid_fd);

    expect_value(__wrap_read, fd, fake_uuid_fd);
    expect_value(__wrap_read, count, strlen(fake_uuid));
    will_return(__wrap_read, (char*) fake_uuid);
    will_return(__wrap_read, (ssize_t) strlen(fake_uuid));

    expect_value(__wrap_close, fd, fake_uuid_fd);

    expect_string(__wrap_strdup, s, fake_uuid);
    will_return(__wrap_strdup, fake_strdup);
    /* end copy */

    /* Expect creating override file to save generated UUID */
    expect_string(__wrap_fopen, path, MINIUPNP_CONF_OVERRIDE_FILE);
    expect_string(__wrap_fopen, mode, "w");
    will_return(__wrap_fopen, fake_override_file);

    expect_any(__wrap_fwrite, ptr);
    expect_value(__wrap_fwrite, size, (size_t) 1);
    expect_value(__wrap_fwrite, nmemb, strlen(expected_override_content));
    expect_value(__wrap_fwrite, stream, fake_override_file);
    will_return(__wrap_fwrite, expected_override_content);
    will_return(__wrap_fwrite, strlen(expected_override_content));

    expect_value(__wrap_fclose, stream, fake_override_file);

    /* Expect writing miniupnpd conf file */
    expect_value(__wrap_write, fd, fake_miniupnpd_fd);
    expect_any(__wrap_write, buf);
    expect_value(__wrap_write, count,
                 (size_t) strlen(expected_miniupnpd_conf_content));
    will_return(__wrap_write, expected_miniupnpd_conf_content);
    will_return(__wrap_write, (ssize_t) strlen(expected_miniupnpd_conf_content));

    expect_value(__wrap_close, fd, fake_miniupnpd_fd);

    int ret = create_miniupnpd_conf_file();

    assert_int_equal(ret, 0);

    assert_non_null(miniupnpd_uuid);
    assert_string_equal(miniupnpd_uuid, fake_uuid);

    g_open_strict = 0;
}

/**
 * Test creating miniupnpd conf file when override file with saved UUID
 * is present, so the saved UUID is used.
 */
void test_create_miniupnpd_conf_file_success_with_override(
    UNUSED void** state) {
    const char* fake_uuid = "12345678-1234-1234-1234-123456789abc";
    const char* expected_override_content =
        "uuid=12345678-1234-1234-1234-123456789abc\n";
    int fake_miniupnpd_fd = 43;
    FILE* fake_override_file = (FILE*) 44;
    const char* expected_miniupnpd_conf_content =
        "ext_ifname=eth1\n"
        "ext_ifname6=eth1\n"
        "listening_ip=br-lan\n"
        "enable_natpmp=yes\n"
        "pf_allow_reserved_addr=yes\n"
        "ipv6_disable=no\n"
        "enable_upnp=yes\n"
        "secure_mode=yes\n"
        "system_uptime=yes\n"
        "force_igd_desc_v1=no\n"
        "bitrate_download=8388608\n"
        "bitrate_upload=4194304\n"
        "port=5000\n"
        "uuid=12345678-1234-1234-1234-123456789abc\n"
        "ext_perform_stun=no\n"
        "friendly_name=TestFriendlyName\n"
        "manufacturer_name=TestManufacturer\n"
        "manufacturer_url=http://test.com\n"
        "model_name=TestModel\n"
        "model_description=TestModelDescription\n"
        "model_url=http://testmodel.com\n"
        "serial=SN123456789\n"
        "upnp_amx_wan_interface=Device.Logical.Interface.1.\n"
        "wan_access_provider=TestISP\n"
        "allow 1024-65535 0.0.0.0/0 1024-65535\n"
        "deny 0-65535 0.0.0.0/0 0-65535\n";

    init_external_config();

    g_open_strict = 1;

    /* Expect creating miniupnpd conf file */
    expect_string(__wrap_open, path, MINIUPNP_CONF_FILE);
    expect_value(__wrap_open, flags, O_CREAT | O_TRUNC | O_WRONLY);
    will_return(__wrap_open, fake_miniupnpd_fd);

    /* Expect checking for override file */
    expect_string(__wrap_fopen, path, MINIUPNP_CONF_OVERRIDE_FILE);
    expect_string(__wrap_fopen, mode, "r");
    will_return(__wrap_fopen, fake_override_file);  // Simulate file existing

    /* Expect reading saved UUID from override file */
    expect_any(__wrap_fread, ptr);
    expect_value(__wrap_fread, size, (size_t) 1);
    expect_value(__wrap_fread, nmemb, strlen(expected_override_content));
    expect_value(__wrap_fread, stream, fake_override_file);
    will_return(__wrap_fread, (char*) expected_override_content);
    will_return(__wrap_fread, (ssize_t) strlen(expected_override_content));

    expect_value(__wrap_fclose, stream, fake_override_file);

    /* Expect writing miniupnpd conf file */
    expect_value(__wrap_write, fd, fake_miniupnpd_fd);
    expect_any(__wrap_write, buf);
    expect_value(__wrap_write, count,
                 (size_t) strlen(expected_miniupnpd_conf_content));
    will_return(__wrap_write, expected_miniupnpd_conf_content);
    will_return(__wrap_write, (ssize_t) strlen(expected_miniupnpd_conf_content));

    expect_value(__wrap_close, fd, fake_miniupnpd_fd);

    int ret = create_miniupnpd_conf_file();

    assert_int_equal(ret, 0);

    assert_non_null(miniupnpd_uuid);
    assert_string_equal(miniupnpd_uuid, fake_uuid);

    g_open_strict = 0;
}
