/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "common.h"
#include "routing_manager.h"
#include "netdev_interface_name.h"
#include "netmodel/common_api.h"
#include "routing_ipvforwarding_info.h"

#include <amxb/amxb.h>
#include <amxd/amxd_object.h>
#include <amxs/amxs_resolve.h>

#include <stdlib.h>
#include <string.h>

/**
 * @defgroup netdev_interface_name NetDev Interface Name Resolution
 * @ingroup tr181-routing
 * @brief Functions for resolving and setting NetDev and TR-181 interface names for route forwarding instances.
 * @{
 */

/**********************************************************
* Type definitions
**********************************************************/

/**********************************************************
* Macro definitions
**********************************************************/

#define NETDEV_LINK_INDEX_OFFSET (2)

/**********************************************************
* Variable declarations
**********************************************************/

/**********************************************************
* Function Prototypes
**********************************************************/

static cstring_t netdev_get_interface(int link);
/**********************************************************
* Functions
**********************************************************/

/**
 * @ingroup netdev_interface_name
 * @brief Callback for when the NetModel interface path changes.
 *
 * This function is called when the NetModel interface path changes for a route forwarding instance.
 * It updates the route_forwarding_info structure with the new interface path and sets the value
 * of the "Interface" parameter in the associated object.
 *
 * @param sig_name Name of the event signal.
 * @param data Pointer to the event data containing the new interface path.
 * @param priv Pointer to the route_forwarding_info_t structure.
 */
static void netmodel_interface_path_changed_cb(UNUSED const char* const sig_name,
                                               const amxc_var_t* const data,
                                               void* const priv) {
    SAH_TRACEZ_IN(ME);
    route_forwarding_info_t* route_forwarding_info = (route_forwarding_info_t*) priv;

    when_null_trace(route_forwarding_info, exit, ERROR, "Event did not have a valid route_forwarding_info");

    when_null_trace(data, exit, ERROR, "Event did not have a valid data");
    free(route_forwarding_info->intf_path);
    route_forwarding_info->intf_path = amxc_var_dyncast(cstring_t, data);

    SAH_TRACEZ_INFO(ME, "Converting parameter Interface from netdev name '%s' to TR181 path %s", route_forwarding_info->intf_name, route_forwarding_info->intf_path);
    amxd_object_set_value(cstring_t, route_forwarding_info->obj, "Interface", str_empty(route_forwarding_info->intf_path) ? route_forwarding_info->intf_name : route_forwarding_info->intf_path);
exit:
    SAH_TRACEZ_OUT(ME);
}

static void find_netmodel_interface_cb(const char* const path, bool match, void* const priv) {
    SAH_TRACEZ_IN(ME);
    route_forwarding_info_t* route_forwarding_info = (route_forwarding_info_t*) priv;

    when_null_trace(route_forwarding_info, exit, ERROR, "Failed to get route forwarding info");
    when_str_empty_trace(path, exit, ERROR, "Bad input path");

    if(match) {
        when_not_null_trace(route_forwarding_info->nm_query_intf_path, exit, ERROR, "Interface path query should be null");
        route_forwarding_info->nm_query_intf_path = netmodel_openQuery_getFirstParameter(path, "routing-manager", "InterfacePath", "ip", netmodel_traverse_up, netmodel_interface_path_changed_cb, (void*) route_forwarding_info);
        when_null_trace(route_forwarding_info->nm_query_intf_path, exit, ERROR, "Failed to create a NetModel query for %s", path);
    } else {
        when_null_trace(route_forwarding_info->nm_query_intf_path, exit, ERROR, "Interface path query should not be null");
        netmodel_closeQuery(route_forwarding_info->nm_query_intf_path);
        route_forwarding_info->nm_query_intf_path = NULL;
        SAH_TRACEZ_INFO(ME, "No TR181 interface path found, setting 'Interface' back to netdev name : %s", route_forwarding_info->intf_name);
        amxd_object_set_value(cstring_t, route_forwarding_info->obj, "Interface", route_forwarding_info->intf_name);
    }

exit:
    SAH_TRACEZ_OUT(ME);
}

/**
 * @ingroup netdev_interface_name
 * @brief Finds the NetModel interface path for a given interface name.
 *
 * This function creates a resolve context to find the NetModel interface path
 * corresponding to the specified interface name and updates the route_forwarding_info structure.
 *
 * @param interface The name of the network interface.
 * @param route_forwarding_info Pointer to the route_forwarding_info_t structure to update.
 */
static void find_netmodel_interface(const char* interface, route_forwarding_info_t* route_forwarding_info) {
    SAH_TRACEZ_IN(ME);
    amxc_string_t path;
    amxs_status_t ret = amxs_status_unknown_error;

    amxc_string_init(&path, 0);

    when_str_empty_trace(interface, exit, ERROR, "Bad input interface variable");
    when_null_trace(route_forwarding_info, exit, ERROR, "Failed to get route forwarding info");

    when_not_null_trace(route_forwarding_info->resolve_ctx_netdev_name, exit, ERROR, "Resolve context is already initialized");

    amxc_string_setf(&path, "NetModel.Intf.[ NetDevName == '%s' ].", interface);
    ret = amxs_resolve_ctx_new(&route_forwarding_info->resolve_ctx_netdev_name, amxc_string_get(&path, 0), find_netmodel_interface_cb, route_forwarding_info);
    when_failed_trace(ret, exit, ERROR, "Could not create resolve context and subscritions for interface '%s'", interface);
exit:
    amxc_string_clean(&path);
    SAH_TRACEZ_OUT(ME);
}

static cstring_t netdev_get_interface(int link) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t query;
    amxc_string_t path;
    cstring_t interface = NULL;
    amxc_var_init(&query);
    amxc_string_init(&path, 0);

    amxc_string_setf(&path, "NetDev.Link.%d.", link);
    if(AMXB_STATUS_OK == amxb_get(routing_manager_get_netdev_context(), amxc_string_get(&path, 0), 0, &query, 10)) {
        const cstring_t name = GETP_CHAR(&query, "0.0.Name");
        if(name != NULL) {
            interface = strdup(name);
        }
    }

    amxc_string_clean(&path);
    amxc_var_clean(&query);
    SAH_TRACEZ_OUT(ME);
    return interface;
}

static int netdev_link_from_path(const cstring_t path) {
    SAH_TRACEZ_IN(ME);
    int index = 0;
    amxc_string_t str;
    amxc_llist_t words;

    amxc_string_init(&str, 0);
    amxc_llist_init(&words);

    when_null(path, exit);
    amxc_string_set(&str, path);
    if(AMXC_STRING_SPLIT_OK == amxc_string_split_to_llist(&str, &words, '.')) {
        const cstring_t netdev_index_word = amxc_string_get_text_from_llist(&words, NETDEV_LINK_INDEX_OFFSET);
        if(NULL != netdev_index_word) {
            index = atoi(netdev_index_word);
        }
    }

exit:
    amxc_llist_clean(&words, amxc_string_list_it_free);
    amxc_string_clean(&str);
    SAH_TRACEZ_OUT(ME);
    return index;
}

/**
 * @ingroup netdev_interface_name
 * @brief Sets the interface name for a route forwarding instance object.
 *
 * This function extracts the interface index from the given NetDev path, retrieves the
 * corresponding interface name, assigns it to the route_forwarding_info structure, sets
 * the "Interface" parameter in the associated object, and initiates a NetModel resolve
 * context to find the TR-181 interface path.
 *
 * @param path The NetDev path string.
 * @param object Pointer to the route forwarding instance object.
 * @return rmi_ok on success, rmi_error on failure.
 */
rmi_return_code_t netdev_set_interface_name(const char* path, amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    char* interface_name = NULL;
    route_forwarding_info_t* route_forwarding_info = NULL;
    rmi_return_code_t rc = rmi_error;

    int index = -1;

    when_str_empty_trace(path, exit, ERROR, "Bad input path variable");
    when_null_trace(object, exit, ERROR, "Bad input object variable");
    when_null_trace(object->priv, exit, ERROR, "Failed to get route forwarding info");
    route_forwarding_info = (route_forwarding_info_t*) object->priv;

    index = netdev_link_from_path(path);
    when_false_trace(index != 0, exit, ERROR, "Failed to get the index for %s", path);
    interface_name = netdev_get_interface(index);
    when_null_trace(interface_name, exit, ERROR, "Failed to find the interface name for %s", path);

    route_forwarding_info->intf_name = interface_name;
    // Default to set the netdev interface name, will be overwritten by the TR181 path
    amxd_object_set_value(cstring_t, object, "Interface", interface_name);
    find_netmodel_interface(interface_name, route_forwarding_info);

    rc = rmi_ok;
exit:
    SAH_TRACEZ_OUT(ME);
    return rc;
}

/** @} */ // end of netdev_interface_name group
