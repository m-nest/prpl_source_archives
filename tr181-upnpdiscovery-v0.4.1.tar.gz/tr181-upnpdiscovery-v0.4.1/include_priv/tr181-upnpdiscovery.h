/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __TR181_UPNP_H__
#define __TR181_UPNP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <netmodel/common_api.h>

#define string_empty(X) ((X == NULL) || (*X == '\0'))

/**
 * @brief Main entry point for the component.
 *
 * Handles initialization and cleanup based on the provided reason.
 *
 * @param reason Specifies why the entry point is called. Can be:
 *               - @c AMXO_START: Initialize the module.
 *               - @c AMXO_STOP: Perform cleanup.
 * @param dm     Pointer to the device manager instance.
 * @param parser Pointer to the parser used for module configuration.
 *
 * @return 0 on success, non-zero on failure during initialization or cleanup.
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
 * @brief Handles the application start signal.
 *
 * Initializes the UPnP subscription and starts the LAN query if UPnP is enabled.
 *
 * @param sig_name Unused signal name.
 * @param data     Unused data associated with the signal.
 * @param priv     Unused private data pointer.
 */
void _app_start(UNUSED const char* const sig_name,
                UNUSED const amxc_var_t* const data,
                UNUSED void* const priv);

/**
 * @brief Returns the current data model instance.
 *
 * @return Pointer to the application's @c amxd_dm_t instance.
 */
amxd_dm_t* get_dm(void);

/**
 * @brief Returns the current parser instance.
 *
 * @return Pointer to the application's @c amxo_parser_t instance.
 */
amxo_parser_t* get_parser(void);

/**
 * @brief Returns the configuration variable of the current parser.
 *
 * Retrieves the @c config field from the application's @c amxo_parser_t instance.
 *
 * @return Pointer to the parser's @c amxc_var_t configuration, or NULL if the parser is not initialized.
 */
amxc_var_t* get_config(void);

/**
 * @brief Retrieves the linked list of LAN addresses.
 *
 * Provides access to the application's cached list of LAN addresses.
 *
 * @return Pointer to the @c amxc_llist_t containing LAN addresses, or NULL if not initialized.
 */
amxc_llist_t* get_lan_addrs(void);

/**
 * @brief Retrieves the LAN interface name used by the application.
 *
 * This function returns the current LAN interface as a C string.
 *
 * @return Pointer to a null-terminated string containing the LAN interface name.
 */
const char* get_lan_intf(void);

/**
 * @brief Callback invoked when LAN addresses change.
 *
 * Updates the application's LAN interface and address list based on the
 * provided data. Starts UPnP discovery if the interface name has changed.
 *
 * @param sig_name Signal name associated with the change.
 * @param data     Data containing the updated LAN addresses and interface info.
 * @param priv     Unused private pointer.
 */
void lan_addr_changed(const char* sig_name, const amxc_var_t* data, UNUSED void* priv);

#ifdef __cplusplus
}
#endif

#endif // __TR181_UPNP_H__
