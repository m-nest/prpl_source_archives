/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <dirent.h>

#include <rnp/rnp.h>
#include <rnp/rnp_err.h>
#define SIG_IDX 0

#include <rlyeh/rlyeh_curl.h>
#include <rlyeh/rlyeh_defines.h>
#include "image_authentication.h"

#define ME "authentication"
#define TMP_DIR "/tmp/"

typedef struct _sig_data {
    const char* signature_url;
    const char* manifest_hash;
    const char* image_name;
    const char* server;
    const char* version;
} sig_data_t;


static amxm_shared_object_t* so = NULL;
static amxm_module_t* mod = NULL;
static amxd_dm_t* datamodel = NULL;
static uint32_t num_success = 0;
static uint32_t num_failure = 0;

#define OCI_SIGNATURE_DOCKER_REFERENCE "docker-reference"
#define OCI_SIGNATURE_DOCKER_MANIFEST_DIGEST "docker-manifest-digest"
#define OCI_SIGNATURE_TYPE "type"

#define AUTH_SIGNATURE_TYPE "atomic container signature"
#define DEFAULT_KEY_LOCATION "/usr/share/rlyeh/keys"
const char* rnp_status_txt(rnp_result_t sigstatus);

static int fetch_signature(const sig_data_t* sigdata, const char* sigfile) {
    int ret = -1;
    amxc_string_t url;
    curl_off_t* size = NULL;
    FILE* fd = NULL;
    const char* signature_url = sigdata->signature_url;
    rlyeh_curl_parameters_t curl_param = {
        .type = FILE_TYPE_SIG,
        .token = NULL,
        .auth_type = NO_AUTHENTICATION,
        .username = NULL,
        .password = NULL,
    };

    ASSERT_STR_NOT_EMPTY(signature_url, return ret, "Signature URL is empty");

    amxc_string_init(&url, 0);
    amxc_string_set_at(&url, 0, signature_url, strlen(signature_url), amxc_string_no_flags);

    fd = fopen(sigfile, "w");
    ASSERT_NOT_NULL(fd, goto exit, "Failed to create signature file");

    ret = rlyeh_curl_download_content(&curl_param, &url, (void*) fd, size, NULL);
    ASSERT_SUCCESS(ret, NO_INSTRUCTION, "Failed to fetch signature file");
    fclose(fd);

exit:
    amxc_string_clean(&url);
    return ret;
}

static void verification_stats(void) {
    if(datamodel) {
        amxd_object_t* stats = amxd_dm_findf(datamodel, RLYEH_DM "." AUTHENTICATION ".Stats");
        ASSERT_NOT_NULL(stats, return , "stats object not found. Stats not updated");

        amxd_object_set_uint32_t(stats, "SuccessAuthentication", num_success);
        amxd_object_set_uint32_t(stats, "FailedAuthentication", num_failure);
    }
}

static int load_signing_keys(rnp_ffi_t rnp_ffi) {
    int result = 1;
    rnp_input_t input = NULL;
    struct dirent* entry;
    char* res = NULL;
    char* location = NULL;
    DIR* dp = NULL;

    if(datamodel) {
        amxd_object_t* auth = amxd_dm_findf(datamodel, RLYEH_DM "." AUTHENTICATION);
        ASSERT_NOT_NULL(auth, return result, "%s datamodel object not found", AUTHENTICATION);
        location = amxd_object_get_cstring_t(auth, KEY_LOCATION, NULL);
        ASSERT_STR_NOT_EMPTY(location, goto exit, "Key location cannot be empty or missing");
    } else {
        location = strdup(DEFAULT_KEY_LOCATION);
        SAH_TRACEZ_WARNING(ME, "No Datamodel loaded: Using default key location %s", DEFAULT_KEY_LOCATION);
    }

    dp = opendir(location);
    ASSERT_NOT_NULL(dp, goto exit, "Failed to read dir content");

    while((entry = readdir(dp))) {
        res = NULL;
        char file[512] = {0};
        snprintf(file, sizeof(file), "%s/%s", location, entry->d_name);
        // Only regular files are handled.
        if(lcm_filetype(file) == FILE_TYPE_REGULAR) {
            ASSERT_EQUAL(rnp_input_from_path(&input, file), RNP_SUCCESS,
                         continue, "Failed to create input file to import");
            ASSERT_EQUAL(rnp_import_keys(rnp_ffi, input, RNP_LOAD_SAVE_PUBLIC_KEYS, &res),
                         RNP_SUCCESS, NO_INSTRUCTION, "Failed to import %s as key", entry->d_name);

            SAH_TRACEZ_ERROR(ME, "res %s", res);
            rnp_buffer_destroy(res);
            rnp_input_destroy(input);
        }
    }

    result = 0;
exit:
    free(location);
    closedir(dp);

    return result;
}

int authentication_init(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = 0;
    datamodel = (amxd_dm_t*) GET_DATA(args, RLYEH_PLUGIN_ARG_DATAMODEL);
    CHECK_NULL_LOG(WARNING, datamodel, NO_INSTRUCTION, "No datamodel provided: Plugin will use default values");

    amxc_var_set(int32_t, ret, res);
    return res;
}

const char* rnp_status_txt(rnp_result_t sigstatus) {
    switch(sigstatus) {
    case RNP_SUCCESS:
        return "Success";
    case RNP_ERROR_SIGNATURE_EXPIRED:
        return "Signature expired";
    case RNP_ERROR_KEY_NOT_FOUND:
        return "Signing key not found";
    case RNP_ERROR_SIGNATURE_INVALID:
        return "Signature is invalid";
    default:
        return "Unknown";
    }
}

static int extract_and_verify_signature(const char* sigfile, int sigdatafile_fd) {
    rnp_op_verify_t verify = NULL;
    rnp_input_t input = NULL;
    rnp_output_t output = NULL;
    uint8_t* buf = NULL;
    size_t buf_len = 0;
    size_t sigcount = 0;
    int result = 1;
    rnp_op_verify_signature_t sig = NULL;
    rnp_result_t sigstatus = RNP_SUCCESS;
    rnp_key_handle_t key = NULL;
    char* keyid = NULL;
    rnp_ffi_t ffi = NULL;
    int size = -1;

    // Initialize struct and load keys
    ASSERT_EQUAL(rnp_ffi_create(&ffi, RNP_KEYSTORE_GPG, RNP_KEYSTORE_GPG), RNP_SUCCESS,
                 goto end, "Failed to init FFI object");
    ASSERT_EQUAL(load_signing_keys(ffi), RNP_SUCCESS,
                 goto end, "Failed to initialize keyring with existing keys");

    // Init structs for signature verification
    ASSERT_EQUAL(rnp_input_from_path(&input, sigfile), RNP_SUCCESS,
                 goto end, "Failed to read signature file");
    ASSERT_EQUAL(rnp_output_to_memory(&output, 0), RNP_SUCCESS,
                 goto end, "Failed to create output object");
    ASSERT_EQUAL(rnp_op_verify_create(&verify, ffi, input, output), RNP_SUCCESS,
                 goto end, "Failed to create verification context");
    ASSERT_EQUAL(rnp_op_verify_execute(verify), RNP_SUCCESS,
                 goto end, "Failed to execute verification operation");

    // Check number of available signatures : Only a single signature is allowed.
    ASSERT_EQUAL(rnp_op_verify_get_signature_count(verify, &sigcount),
                 RNP_SUCCESS, goto end, "Failed to get signature count");
    ASSERT_EQUAL(sigcount, 1, goto end, "Multiple signatures (%zu) not allowed found",
                 sigcount);

    // Get signature and verify its validity
    ASSERT_EQUAL(rnp_op_verify_get_signature_at(verify, SIG_IDX, &sig), RNP_SUCCESS,
                 goto end, "Failed to get signature");
    sigstatus = rnp_op_verify_signature_get_status(sig);
    ASSERT_EQUAL(sigstatus, RNP_SUCCESS, goto end,
                 "%s", rnp_status_txt(sigstatus));

    // Signing key id is only logged for info
    if((rnp_op_verify_signature_get_key(sig, &key) == RNP_SUCCESS) &&
       (rnp_key_get_keyid(key, &keyid) == RNP_SUCCESS)) {
        SAH_TRACEZ_INFO(ME, "Signature used key %s", keyid);
    }

    rnp_buffer_destroy(keyid);
    rnp_key_handle_destroy(key);

    // Get the signed message for further verification
    ASSERT_EQUAL(rnp_output_memory_get_buf(output, &buf, &buf_len, true),
                 RNP_SUCCESS, goto end, "Failed to get result");

    size = write(sigdatafile_fd, buf, buf_len * sizeof(char));
    ASSERT_NOT_EQUAL(size, -1, goto end, "Failed to write the signature data to output file");

    result = 0;
end:
    rnp_buffer_destroy(buf);
    rnp_ffi_destroy(ffi);
    rnp_op_verify_destroy(verify);
    rnp_input_destroy(input);
    rnp_output_destroy(output);
    return result;
}

static int check_docker_reference(amxc_var_t* obj, const sig_data_t* sigdata) {
    int ret = -3;
    amxc_var_t* var_docker_reference;
    const char* str_docker_reference;
    amxc_string_t expected_docker_reference;
    amxc_string_init(&expected_docker_reference, 256);
    amxc_string_setf(&expected_docker_reference, "%s/%s:%s", sigdata->server, sigdata->image_name, sigdata->version);

    amxc_var_t* identity = GET_ARG(obj, "identity");
    ASSERT_NOT_NULL(identity, goto exit, "Wrong key in json signature");

    var_docker_reference = amxc_var_get_path(identity, OCI_SIGNATURE_DOCKER_REFERENCE, AMXC_VAR_FLAG_DEFAULT);
    ASSERT_NOT_NULL(var_docker_reference, goto exit, "%s missing", OCI_SIGNATURE_DOCKER_REFERENCE);

    str_docker_reference = amxc_var_constcast(cstring_t, var_docker_reference);
    ASSERT_STR_NOT_EMPTY(str_docker_reference, goto exit, "%s is empty", OCI_SIGNATURE_DOCKER_REFERENCE)

    ret = 3;
    ASSERT_STR_EQUAL(str_docker_reference, amxc_string_get(&expected_docker_reference, 0), goto exit,
                     "Invalid %s in signature: '%s'", OCI_SIGNATURE_DOCKER_REFERENCE, str_docker_reference)

    ret = 0;
exit:
    amxc_string_clean(&expected_docker_reference);
    return ret;
}

static int check_manifest_hash(amxc_var_t* obj, const sig_data_t* sigdata) {
    int ret = -4;
    amxc_var_t* var_docker_manifest_digest;
    const char* str_docker_manifest_digest;
    amxc_string_t expected_manifest_hash;
    amxc_string_init(&expected_manifest_hash, 0);
    amxc_string_setf(&expected_manifest_hash, "sha256:%s", sigdata->manifest_hash);

    amxc_var_t* image = GET_ARG(obj, "image");
    ASSERT_NOT_NULL(image, goto exit, "Wrong key in json signature");

    var_docker_manifest_digest = amxc_var_get_path(image, OCI_SIGNATURE_DOCKER_MANIFEST_DIGEST, AMXC_VAR_FLAG_DEFAULT);
    ASSERT_NOT_NULL(var_docker_manifest_digest, goto exit, "%s missing", OCI_SIGNATURE_DOCKER_MANIFEST_DIGEST);

    str_docker_manifest_digest = amxc_var_constcast(cstring_t, var_docker_manifest_digest);
    ASSERT_STR_NOT_EMPTY(str_docker_manifest_digest, goto exit, "%s is empty", OCI_SIGNATURE_DOCKER_MANIFEST_DIGEST);

    ret = 4;
    ASSERT_STR_EQUAL(str_docker_manifest_digest, amxc_string_get(&expected_manifest_hash, 0), goto exit,
                     "Invalid %s in signature: '%s'", OCI_SIGNATURE_DOCKER_MANIFEST_DIGEST, str_docker_manifest_digest);

    ret = 0;
exit:
    amxc_string_clean(&expected_manifest_hash);
    return ret;
}

static int check_type(amxc_var_t* obj) {
    amxc_var_t* var_type = amxc_var_get_path(obj, OCI_SIGNATURE_TYPE, AMXC_VAR_FLAG_DEFAULT);
    ASSERT_NOT_NULL(var_type, return -5, "%s missing", OCI_SIGNATURE_TYPE);

    const char* str_type = amxc_var_constcast(cstring_t, var_type);
    ASSERT_STR_NOT_EMPTY(str_type, return -5, "%s is empty", OCI_SIGNATURE_TYPE);

    ASSERT_STR_EQUAL(str_type, AUTH_SIGNATURE_TYPE, return 5, "Invalid %s in signature: '%s'",
                     OCI_SIGNATURE_TYPE, str_type);

    return 0;
}

static int signature_content_verification(const char* sigdatafile, const sig_data_t* sigdata) {
    int ret = -1;
    amxc_var_t* config_data = NULL;
    amxc_var_t* critical = NULL;

    config_data = read_config(sigdatafile);
    ASSERT_NOT_NULL(config_data, goto exit, "Can't parse signature");

    // Parse data here and compare to docker reference and digest
    critical = GET_ARG(config_data, "critical");
    ret = -2;
    ASSERT_NOT_NULL(critical, goto exit, "Wrong key in json signature");

    ret = check_docker_reference(critical, sigdata);
    ASSERT_SUCCESS(ret, goto exit);

    ret = check_manifest_hash(critical, sigdata);
    ASSERT_SUCCESS(ret, goto exit);

    ret = check_type(critical);
    ASSERT_SUCCESS(ret, goto exit);

exit:
    amxc_var_delete(&config_data);
    return ret;
}

int authentication_verify(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = -1;
    sig_data_t sigdata;
    char sigfile[] = "/tmp/signatureXXXXXXXX";
    char sigdatafile[] = "/tmp/signaturedataXXXXXXXX";
    int sigfile_fd = -1;
    int sigdatafile_fd = -1;

    const char* signature_url = GET_CHAR(args, RLYEH_PLUGIN_ARG_URL);
    const char* manifest_hash = GET_CHAR(args, RLYEH_PLUGIN_ARG_MANIFEST_HASH);
    const char* image_name = GET_CHAR(args, RLYEH_PLUGIN_ARG_IMAGE_NAME);
    const char* server = GET_CHAR(args, RLYEH_PLUGIN_ARG_SERVER);
    const char* version = GET_CHAR(args, RLYEH_PLUGIN_ARG_VERSION);

    ASSERT_STR_NOT_EMPTY(signature_url, return res);
    ASSERT_STR_NOT_EMPTY(manifest_hash, return res);
    ASSERT_STR_NOT_EMPTY(image_name, return res);
    ASSERT_STR_NOT_EMPTY(server, return res);
    ASSERT_STR_NOT_EMPTY(version, return res);

    sigdata.signature_url = signature_url;
    sigdata.manifest_hash = manifest_hash;
    sigdata.image_name = image_name;
    sigdata.server = server;
    sigdata.version = version;

    sigfile_fd = mkstemp(sigfile);
    sigdatafile_fd = mkstemp(sigdatafile);

    ASSERT_NOT_EQUAL(sigfile_fd, -1, goto exit, "Failed to create tmp sigfile");
    ASSERT_NOT_EQUAL(sigdatafile_fd, -1, goto exit, "Failed to create tmp sigdatafile");

    SAH_TRACEZ_INFO(ME, "sigfile: '%s' | sigdatafile: '%s'", sigfile, sigdatafile);

    // Fetch signature from provide URL or preconfigured path
    res = fetch_signature(&sigdata, sigfile);
    ASSERT_SUCCESS(res, goto exit, "Can't fetch the signature for image %s", image_name);

    // Verify signature
    res = extract_and_verify_signature(sigfile, sigdatafile_fd);
    ASSERT_SUCCESS(res, goto exit, "Signature check failed (%d)", res);

    // Check signature info (manifest signature, docker reference, manifest digest
    res = signature_content_verification(sigdatafile, &sigdata);
    ASSERT_SUCCESS(res, goto exit, "Invalid signature (%d)", res);

exit:
    if(res == 0) {
        num_success++;
    } else {
        num_failure++;
    }

    verification_stats();
    // Delete signature
    if(sigfile_fd > -1) {
        SAH_TRACEZ_INFO(ME, "Removing: '%s'", sigfile);
        close(sigfile_fd);
        remove(sigfile);
    }
    if(sigdatafile_fd > -1) {
        SAH_TRACEZ_INFO(ME, "Removing: '%s'", sigdatafile);
        close(sigdatafile_fd);
        remove(sigdatafile);
    }

    amxc_var_set(int32_t, ret, res);
    return res;
}

int authentication_cleanup(UNUSED const char* function_name, UNUSED amxc_var_t* args, amxc_var_t* ret) {
    int res = 0;

    amxc_var_set(int32_t, ret, res);
    return res;
}

static int register_function(const char* const func_name, amxm_callback_t cb) {
    ASSERT_SUCCESS(amxm_module_add_function(mod, func_name, cb), return -1, "Could not add function [%s]", func_name);
    return 0;
}

AMXM_CONSTRUCTOR module_init(void) {
    SAH_TRACEZ_INFO(ME, ">>> Rlyeh image authentication constructor");
    int ret = 1;

    so = amxm_so_get_current();
    ASSERT_NOT_NULL(so, goto exit, "Could not get shared object");
    ASSERT_SUCCESS(amxm_module_register(&mod, so, RLYEH_PLUGIN), goto exit, "Could not register module %s", RLYEH_PLUGIN);
    ASSERT_SUCCESS(register_function(RLYEH_PLUGIN_INIT, authentication_init), goto exit);
    ASSERT_SUCCESS(register_function(RLYEH_PLUGIN_IMAGE_AUTHENTICATION, authentication_verify), goto exit);
    ASSERT_SUCCESS(register_function(RLYEH_PLUGIN_CLEANUP, authentication_cleanup), goto exit);

    ret = 0;
exit:
    SAH_TRACEZ_INFO(ME, "<<< Rlyeh image authentication constructor");
    return ret;
}

AMXM_DESTRUCTOR module_exit(void) {
    SAH_TRACEZ_INFO(ME, ">>> Rlyeh image authentication destructor");
    SAH_TRACEZ_INFO(ME, "<<< Rlyeh image authentication destructor");
    return 0;
}
