/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxrt/amxrt.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_verify.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <limits.h>

#include "usp_discovery.h"
#include "event_handler.h"
#include "obuspa_interface.h"

#include "usp_discovery_test.h"
#include "../common/functions.h"

#define ME "usp_discovery"

int test_setup(void** state) {
    assert_int_equal(amxut_bus_setup(state), 0);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

bool __wrap_netmodel_initialize(void) {
    function_called();
    return mock_type(bool);
}

netmodel_query_t* __wrap_netmodel_openQuery(UNUSED const char* intf,
                                            UNUSED const char* subscriber,
                                            UNUSED const char* function,
                                            UNUSED const amxc_var_t* args,
                                            UNUSED netmodel_callback_t handler,
                                            UNUSED void* userdata) {

    function_called();
    return mock_ptr_type(netmodel_query_t*);
}

int __wrap_remove_all_controllers(void) {
    function_called();
    return mock_type(int);
}

void test_can_start_plugin(UNUSED void** state) {
    expect_function_call(__wrap_remove_all_controllers);
    will_return(__wrap_remove_all_controllers, 0);

    expect_function_call(__wrap_netmodel_initialize);
    will_return(__wrap_netmodel_initialize, true);

    expect_function_call(__wrap_netmodel_openQuery);
    will_return(__wrap_netmodel_openQuery, "netmodel_query_t*");

    expect_function_call(__wrap_netmodel_openQuery);
    will_return(__wrap_netmodel_openQuery, "netmodel_query_t*");

    amxc_var_t* config = amxrt_get_config();
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, config, "NetModelIntfName", "ip-wan");
    assert_int_equal(_usp_discovery_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxc_var_clean(config);
}

void __wrap_netmodel_cleanup(void) {
    function_called();
}

void test_can_stop_plugin(UNUSED void** state) {
    will_return(__wrap_remove_all_controllers, 0);
    expect_function_call(__wrap_remove_all_controllers);

    expect_function_call(__wrap_netmodel_cleanup);
    assert_int_equal(_usp_discovery_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
}

void test_DHCPControllerInformation_free(UNUSED void** state) {
    struct DHCPControllerInformation controller_inf;
    controller_inf.EndpointID = strdup("EndpointID");
    controller_inf.ProvisioningCode = strdup("ProvisioningCode");
    controller_inf.URL = strdup("URL");
    controller_inf.USPNotifRetryIntervalMultiplier = 1024;
    controller_inf.USPNotifRetryMinimumWaitInterval = 2048;
    DHCPControllerInformation_free(&controller_inf); // leak is tested using valgrind
}

void test_DHCPControllerInformation_clone(UNUSED void** state) {
    struct DHCPControllerInformation controller_inf1;
    controller_inf1.EndpointID = strdup("EndpointID");
    controller_inf1.ProvisioningCode = strdup("ProvisioningCode");
    controller_inf1.URL = strdup("URL");
    controller_inf1.USPNotifRetryIntervalMultiplier = 1024;
    controller_inf1.USPNotifRetryMinimumWaitInterval = 2048;

    struct DHCPControllerInformation controller_inf2 = DHCPControllerInformation_clone(controller_inf1);

    assert_string_equal(controller_inf1.EndpointID, controller_inf2.EndpointID);
    assert_string_equal(controller_inf1.ProvisioningCode, controller_inf2.ProvisioningCode);
    assert_string_equal(controller_inf1.URL, controller_inf2.URL);
    assert_int_equal(controller_inf1.USPNotifRetryIntervalMultiplier, controller_inf2.USPNotifRetryIntervalMultiplier);
    assert_int_equal(controller_inf1.USPNotifRetryMinimumWaitInterval, controller_inf2.USPNotifRetryMinimumWaitInterval);

    DHCPControllerInformation_free(&controller_inf1);
    DHCPControllerInformation_free(&controller_inf2);
}

void test_DHCPControllerInformation_equals(UNUSED void** state) {
    struct DHCPControllerInformation controller_inf1;
    controller_inf1.EndpointID = strdup("EndpointID");
    controller_inf1.ProvisioningCode = strdup("ProvisioningCode");
    controller_inf1.URL = strdup("URL");
    controller_inf1.USPNotifRetryIntervalMultiplier = 1024;
    controller_inf1.USPNotifRetryMinimumWaitInterval = 2048;

    struct DHCPControllerInformation controller_inf2 = DHCPControllerInformation_clone(controller_inf1);

    assert_true(DHCPControllerInformation_equals(&controller_inf1, &controller_inf2));

    controller_inf2.USPNotifRetryIntervalMultiplier = 2048;

    assert_false(DHCPControllerInformation_equals(&controller_inf1, &controller_inf2));

    DHCPControllerInformation_free(&controller_inf1);
    DHCPControllerInformation_free(&controller_inf2);
}

void test_DHCPStatus_reset(UNUSED void** state) {
    struct DHCPStatus dhcp_status;
    dhcp_status.controller_information.EndpointID = strdup("EndpointID");
    dhcp_status.controller_information.ProvisioningCode = strdup("ProvisioningCode");
    dhcp_status.controller_information.URL = strdup("URL");
    dhcp_status.controller_information.USPNotifRetryIntervalMultiplier = 1024;
    dhcp_status.controller_information.USPNotifRetryMinimumWaitInterval = 2048;

    amxc_string_init(&dhcp_status.alias, PATH_BUFFER_SIZE);
    amxc_string_set(&dhcp_status.alias, "alias");
    dhcp_status.in_use = true;

    DHCPStatus_reset(&dhcp_status);

    assert_null(dhcp_status.controller_information.EndpointID);
    assert_null(dhcp_status.controller_information.ProvisioningCode);
    assert_null(dhcp_status.controller_information.URL);
    assert_int_equal(dhcp_status.controller_information.USPNotifRetryIntervalMultiplier, 0);
    assert_int_equal(dhcp_status.controller_information.USPNotifRetryMinimumWaitInterval, 0);

    assert_string_equal(amxc_string_get(&dhcp_status.alias, 0), "");

    assert_false(dhcp_status.in_use);

    amxc_string_clean(&dhcp_status.alias);
}
