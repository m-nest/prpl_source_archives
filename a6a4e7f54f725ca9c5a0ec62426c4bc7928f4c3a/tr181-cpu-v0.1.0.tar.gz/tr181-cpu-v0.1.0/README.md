# TR181-CPU Data Model

An Ambiorix-based application that provides a TR-181 compliant data model interface for managing and monitoring CPU Dynamic Voltage and Frequency Scaling (DVFS) on Linux systems.

## Architecture

![tr181-cpu architecture logo](doc/img/tr181-cpu_architecture.png)

## Overview

This application exposes CPU frequency scaling controls through a standardized TR-181 data model, allowing management systems to:

- **Monitor CPU frequency information** - Current, minimum, and maximum operating frequencies
- **Control CPU power management** - Enable/disable DVFS and configure frequency limits
- **Configure frequency governors** - Select CPU scheduling policies (performance, powersave, ondemand, etc.)

The application interacts with the Linux kernel's cpufreq subsystem through sysfs (`/sys/devices/system/cpu/cpuX/cpufreq/`).

## Features

- **Automatic CPU Discovery** - Detects all CPUs and their DVFS capabilities at runtime
- **State Preservation** - Saves and restores original system DVFS settings on startup/shutdown
- **Real-time Validation** - Ensures frequency limits are within hardware capabilities
- **Event-driven Updates** - Changes to parameters immediately affect system configuration
- **Persistent Configuration** - Settings are saved and restored across reboots
- **Configurable Paths** - Supports custom sysfs paths for testing scenarios

## Data Model Structure

```
CPUs
└── CPU[] (multi-instance)
    └── DVFS
        ├── Enable (bool)                        - Enable/disable DVFS
        ├── Status (string)                      - "Enabled", "Disabled", or "Unsupported"
        ├── Supported (bool)                     - Hardware DVFS capability
        ├── CurrentFrequency (uint64)            - Current frequency in kHz (read-only)
        ├── MinFrequency (uint64)                - Hardware minimum frequency (read-only)
        ├── MaxFrequency (uint64)                - Hardware maximum frequency (read-only)
        ├── ScalingMinFrequency (uint64)         - User-configured minimum frequency
        ├── ScalingMaxFrequency (uint64)         - User-configured maximum frequency
        ├── ScalingAvailableFrequencies (string) - Available frequencies (read-only)
        ├── ScalingGovernor (string)             - Selected frequency governor
        └── ScalingAvailableGovernors (string)   - Available governors (read-only)
```

## Architecture

### Source Files

- **cpu_main.c** - Application entry point and lifecycle management
- **cpu_utils.c** - Low-level sysfs interface for reading/writing CPU parameters
- **cpu_dm_utils.c** - Data model initialization and utility functions
- **cpu_dm_dvfs_actions.c** - Parameter read/write/validate action handlers
- **cpu_dm_event.c** - Event handlers for data model changes

### Configuration Files

- **tr181-cpu.odl** - Main ODL configuration file
- **tr181-cpu_definition.odl** - Data model structure definition

## Configuration

### Key Configuration Options

The application can be configured through the ODL config section:

- **`DVFS_PATH`** - Custom sysfs path template (default: `/sys/devices/system/cpu/%s/cpufreq/%s`)
  - Useful for testing with mock filesystems
  - Example: `DVFS_PATH = "/tmp/cpu/%s/cpufreq/%s"`

- **`storage-path`** - Directory for persistent data model storage
  - Default: `${rw_data_path}/tr181-cpu/`

- **`dm-save-delay`** - Delay in milliseconds before saving data model changes
  - Default: 1000ms

### Trace Zones

The application defines several trace zones for debugging:

- `cpu-main` - Main application lifecycle
- `cpu-utils` - Low-level sysfs operations
- `cpu-dm-utils` - Data model utilities
- `cpu-dm-actions` - Parameter action handlers
- `cpu-dm-event` - Event handlers

Trace levels can be configured via the `trace-zones` config section.

## How It Works

### Initialization Sequence

1. **Startup** (`cpu_main.c`):
   - Application loads and initializes data model
   - Saves current system DVFS settings as defaults

2. **CPU Discovery** (`cpu_dm_utils.c`):
   - Scans for CPUs (cpu0, cpu1, cpu2, etc.)
   - Checks DVFS support by looking for `scaling_available_governors` file
   - Creates data model instances for each supported CPU

3. **Parameter Population** (`cpu_dm_utils.c`):
   - Reads current values from sysfs for each CPU:
     - Current/min/max frequencies
     - Available frequencies and governors
     - Current governor and scaling limits
   - Populates data model parameters

### Runtime Behavior

**When Enable parameter changes** (`cpu_dm_event.c`):
- **Enable = true**: 
  - Validates DVFS is supported
  - Writes configured values to sysfs:
    - ScalingGovernor → `scaling_governor`
    - ScalingMinFrequency → `scaling_min_freq`
    - ScalingMaxFrequency → `scaling_max_freq`
  - Sets Status to "Enabled"
  
- **Enable = false**:
  - Restores original system defaults
  - Sets Status to "Disabled"

**When parameters are read** (`cpu_dm_dvfs_actions.c`):
- Values are fetched directly from sysfs
- Ensures data model reflects actual system state
- `Limitation:` For CPUs where the `Enable` parameter is set, the read value may not always match the configured DM value. On CPUs managed by group policies, changing the parameter for one CPU may affect others in the group (see in sysfs the `affected_cpus` file under `/sys/devices/system/cpu/cpufreq/policyX/` it contains the list of online CPUs belonging to this policy). In such cases, the DM value read for other CPUs may not reflect the configured setting.

**When parameters are written** (`cpu_dm_dvfs_actions.c`):
- Values are validated against hardware limits
- If DVFS is enabled, changes are immediately written to sysfs
- If disabled, changes are stored but not applied

### Shutdown

When the application stops:
- Restores all original DVFS settings
- Ensures system is left in its initial state

## Validation Rules

The application enforces several validation rules:

1. **Frequency Constraints**:
   - `MinFrequency ≤ ScalingMinFrequency ≤ MaxFrequency`
   - `MinFrequency ≤ ScalingMaxFrequency ≤ MaxFrequency`
   - `ScalingMinFrequency ≤ ScalingMaxFrequency`

2. **Available Values**:
   - ScalingGovernor must be in ScalingAvailableGovernors list
   - If `scaling_available_frequencies` exists, scaling frequencies must match available values

3. **Read-only Parameters**:
   - Hardware limits (MinFrequency, MaxFrequency) cannot be modified
   - Status and Supported are system-determined

## Dependencies

### Ambiorix Libraries

- **libamxc** - Core data structures and utilities
- **libamxp** - Signal/slot mechanism
- **libamxd** - Data model implementation
- **libamxo** - ODL parser
- **libsahtrace** - Logging and tracing

### System Requirements

- Linux kernel with cpufreq support
- Sysfs mounted at `/sys`
- CPUs with DVFS capability (optional - application handles unsupported CPUs gracefully)

## Supported CPU Governors

The application supports standard Linux CPU frequency governors:

- **performance** - Always run at maximum frequency
- **powersave** - Always run at minimum frequency
- **ondemand** - Dynamically scale based on CPU load
- **conservative** - Similar to ondemand but with smoother transitions
- **userspace** - Allow userspace programs to set frequency
- **schedutil** - Scheduler-driven frequency scaling

Availability depends on kernel configuration and CPU support.

## Integration

### PCM Service Integration

The application integrates with the PCM (Persistent Configuration Manager) service:

```odl
pcm_svc_config = {
    "Objects" = "CPUs",
    "BackupFiles" = "tr181-cpu"
};
```

This ensures the CPUs data model is backed up and can be restored.

## Troubleshooting

### Common Issues

**DVFS shows as "Unsupported"**:
- Check if CPU supports frequency scaling: `ls /sys/devices/system/cpu/cpu0/cpufreq/`
- Verify kernel has cpufreq drivers loaded: `lsmod | grep cpufreq`

**Cannot write frequency values**:
- Check permissions on sysfs files
- Ensure DVFS.Enable is set to true
- Verify values are within Min/MaxFrequency range

**Changes not persisting**:
- Check storage-path is writable
- Verify dm-save configuration is enabled
