#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

[ -f /etc/environment ] && source /etc/environment
ulimit -c ${ULIMIT_CONFIGURATION:0}

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="cellular-manager"
PROG="/usr/bin/cellular-manager"
datamodel_root=""
PROG_OPTIONS=""

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

#preservice_hook() {
#    logger -s "pre-service hook ${name}"
#}

#Guideline- this function has instructions to execute after
#stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    #preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

restart () {
    stop
    sleep 2s
    start
}

debuginfo() {
    ubus-cli "protected;Cellular.?"
}
