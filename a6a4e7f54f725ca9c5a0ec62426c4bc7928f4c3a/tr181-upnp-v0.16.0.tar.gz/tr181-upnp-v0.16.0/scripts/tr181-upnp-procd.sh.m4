#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-upnp"
PROG="/usr/bin/tr181-upnp"
datamodel_root="UPnP"
PROG_OPTIONS=""

start_service() {
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
}

debuginfo() {
    process_debug_info ${datamodel_root}
    echo "Print miniupnpd generated config file"
    cat /var/etc/miniupnpd.conf
}
