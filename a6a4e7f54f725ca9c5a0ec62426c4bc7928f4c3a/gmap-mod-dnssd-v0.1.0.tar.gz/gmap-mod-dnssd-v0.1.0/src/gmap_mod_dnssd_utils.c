/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE
#include <stdio.h>

#include <errno.h>
#include <signal.h>

#include <netdb.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <sys/time.h>
#include <sys/ioctl.h>

#include "gmap_mod_dnssd.h"
#include "gmap_mod_dnssd_utils.h"

#define ME "gmap-mod-dnssd-utils"
#define GMAP_DNSSD_PATH_INIT_LEN 64
#define GMAP_DNSSD_BUS_TIMEOUT 5
#define TEXT_RECORD_LEN 10

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Builds the path to the TextRecord object of a given mDNS service.
 *
 * This utility constructs a DM path of the form:
 * `"mDNSService.<service>.TextRecord"`
 * and returns it as a newly allocated string.
 *
 * The caller becomes the owner of the returned buffer and must free it
 * using `free()` when no longer needed.
 *
 * @param service  The service instance identifier (e.g. "1" or "MyService").
 *
 * @return A newly allocated string containing the full TextRecord path,
 *         or NULL if memory allocation fails.
 */
static char* gmap_device_service_records_path(const char* service) {
    char* retval = NULL;
    amxc_string_t path;
    amxc_string_init(&path, GMAP_DNSSD_PATH_INIT_LEN);
    amxc_string_appendf(&path, "mDNSService.%s.TextRecord", service);

    retval = amxc_string_take_buffer(&path);

    amxc_string_clean(&path);

    return retval;
}


/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Retrieves the GMAP device key associated with an IP address list of the host.
 *
 * This function receives a host string containing one or more IP addresses
 * (optionally comma-separated). It parses the string into a list and iterates
 * over each IP address.
 *
 * For each entry, it tries to resolve the device key using
 * `gmap_devices_findByIp()`.
 * The first non-empty key found is returned.
 *
 * The returned pointer is not dynamically allocated by this function;
 * it comes from `gmap_devices_findByIp()` and must not be freed by the caller.
 *
 * @param host  A string containing an IP address or a list of IP addresses.
 *              Example: `"192.168.1.10"` or `"192.168.1.10,10.0.0.5"`.
 *
 * @return A pointer to the device key if found, or NULL otherwise.
 */
static char* gmap_key_by_ip_host(const char* host) {
    char* key = NULL;
    amxc_string_t string;
    amxc_var_t variant;

    amxc_var_init(&variant);

    amxc_string_init(&string, 0);
    amxc_string_appendf(&string, "%s", host);
    amxc_string_csv_to_var(&string, &variant, NULL);
    amxc_var_for_each(ip_addr, &variant) {
        key = gmap_devices_findByIp(amxc_var_constcast(cstring_t, ip_addr));
        if(key && *key) {
            break;
        }
    }

    amxc_string_clean(&string);
    amxc_var_clean(&variant);

    return key;
}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Generates a normalized mDNS service key from protocol fields.
 *
 * This function builds a service key string using the values found in the
 * provided `data` variable.
 *
 * The expected fields are:
 *  - `"ApplicationProtocol"` (e.g. `"http"`)
 *  - `"TransportProtocol"` (e.g. `"TCP"`)
 *
 * The function converts the transport protocol to lowercase and constructs
 * a key using the format:
 *
 *     _<ApplicationProtocol>__<transportprotocol>
 *
 * Example:
 *     ApplicationProtocol = "http"
 *     TransportProtocol   = "TCP"
 *
 *     Result → `"_http__tcp"`
 *
 * The returned buffer is dynamically allocated via `amxc_string_take_buffer()`
 * and **must be freed by the caller**.
 *
 * @param data  Input variable containing the protocol fields.
 *
 * @return A newly allocated service key string, or NULL if required fields
 *         are missing.
 */
static char* generate_service_key(const amxc_var_t* const data) {
    char* retval = NULL;
    amxc_string_t service_key;
    amxc_string_init(&service_key, 0);

    amxc_string_t protocol_lowered;
    amxc_string_init(&protocol_lowered, 0);

    const char* app_protocol = GET_CHAR(data, "ApplicationProtocol");
    when_str_empty_trace(app_protocol, error, ERROR, "No ApplicationProtocol path found");

    const char* protocol = GET_CHAR(data, "TransportProtocol");
    when_str_empty_trace(protocol, error, ERROR, "No ApplicationProtocol path found");

    amxc_string_appendf(&protocol_lowered, "%s", protocol);
    amxc_string_to_lower(&protocol_lowered);

    amxc_string_appendf(&service_key, "_%s__%s", app_protocol, protocol_lowered.buffer);

    retval = amxc_string_take_buffer(&service_key);

error:
    amxc_string_clean(&service_key);
    amxc_string_clean(&protocol_lowered);

    return retval;

}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Generates an mDNS service name from the application and transport protocols.
 *
 * This function builds an mDNS service name using the two protocol fields found
 * in the provided `data` variable:
 *
 *  - `"ApplicationProtocol"` (e.g. `"http"`)
 *  - `"TransportProtocol"`   (e.g. `"TCP"`)
 *
 * The transport protocol is converted to lowercase, and the service name is
 * created using the standard mDNS format:
 *
 *     _<ApplicationProtocol>._<transportprotocol>
 *
 * Example:
 *     ApplicationProtocol = "http"
 *     TransportProtocol   = "TCP"
 *
 *     Result → `"_http._tcp"`
 *
 * The returned string is dynamically allocated using `amxc_string_take_buffer()`
 * and **must be freed by the caller**.
 *
 * @param data  Input variable containing the protocol fields.
 *
 * @return A newly allocated mDNS service name string, or NULL if required
 *         fields are missing.
 */
static char* generate_service_name(const amxc_var_t* const data) {
    char* retval = NULL;
    amxc_string_t service_name;
    amxc_string_init(&service_name, 0);

    amxc_string_t protocol_lowered;
    amxc_string_init(&protocol_lowered, 0);

    const char* app_protocol = GET_CHAR(data, "ApplicationProtocol");
    when_str_empty_trace(app_protocol, error, ERROR, "No ApplicationProtocol path found");

    const char* protocol = GET_CHAR(data, "TransportProtocol");
    when_str_empty_trace(protocol, error, ERROR, "No ApplicationProtocol path found");

    amxc_string_appendf(&protocol_lowered, "%s", protocol);
    amxc_string_to_lower(&protocol_lowered);

    amxc_string_appendf(&service_name, "_%s._%s", app_protocol, protocol_lowered.buffer);

    retval = amxc_string_take_buffer(&service_name);

error:
    amxc_string_clean(&service_name);
    amxc_string_clean(&protocol_lowered);

    return retval;
}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Extracts the service path from a TextRecord path.
 *
 * This function expects a path that ends with `"TextRecord"` (e.g.
 * `"DNSSD.Service.1.TextRecord"`).
 *
 * It strips the `"TextRecord"` suffix and returns the service path only:
 *
 * Example:
 *     Input:  `"DNSSD.Service.1.TextRecord"`
 *     Output: `"DNSSD.Service.1"`
 *
 * The function validates that `"TextRecord"` appears in the input string.
 * If not found, an error is logged and NULL is returned.
 *
 * The returned buffer is allocated using `calloc()` and **must be freed by
 * the caller**.
 *
 * @param record  The full TextRecord path.
 *
 * @return A newly allocated service path string without the TextRecord
 *         suffix, or NULL in case of invalid input.
 */
static char* generate_service_path_of_record(const char* record) {
    char* service_path = NULL;

    when_null_trace(strstr(record, "TextRecord"), error, ERROR, "Invalid txt record path");

    service_path = calloc(strlen(record) - TEXT_RECORD_LEN, sizeof(char));
    memcpy(service_path, record, strlen(record) - (TEXT_RECORD_LEN + 1));

error:
    return service_path;
}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Processes a DNSSD TXT record and triggers its addition.
 *
 * This function retrieves the full instance data for a given TXT record and
 * prepares it for addition via `txt_record_addition()`.
 * The function performs the following steps:
 *   1. Constructs the instance path by combining `record_template_path` and `record`.
 *   2. Retrieves the DNSSD instance data from the backend.
 *   3. Extracts the first instance element matching the path.
 *   4. Packages the path and parameters into an argument variable.
 *   5. Calls `txt_record_addition()` to process the record.
 *
 * @param record                The record identifier to process (usually an index or key).
 * @param record_template_path  The base path template for the DNSSD record.
 *
 * @note Memory for intermediate strings and variables is managed locally and
 *       cleaned up at the end of the function.
 *
 * @warning If the record cannot be retrieved or does not exist, the function
 *          logs an error and returns silently.
 */
static void process_record(amxc_var_t* record, const char* record_template_path) {
    amxc_var_t args;
    amxc_var_t record_instance_values;
    amxc_var_t* record_instance_data = NULL;
    amxc_string_t instance_path;

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_init(&record_instance_values);

    amxc_string_init(&instance_path, 0);
    amxc_string_appendf(&instance_path, "%s%s.", record_template_path, amxc_var_constcast(cstring_t, record));

    when_failed_trace(amxb_get(retrieve_dnssd_ctx(), amxc_string_get(&instance_path, 0), 0, &record_instance_values, GMAP_DNSSD_BUS_TIMEOUT), error, ERROR, "Could not find service data");
    record_instance_data = amxc_var_get_pathf(&record_instance_values, AMXC_VAR_FLAG_DEFAULT, "0.'%s'", amxc_string_get(&instance_path, 0));
    when_null_trace(record_instance_data, error, ERROR, "Could not find service data.");
    amxc_var_add_key(cstring_t, &args, "path", amxc_string_get(&instance_path, 0));
    amxc_var_add_key(amxc_htable_t, &args, "parameters", &record_instance_data->data.vm);
    txt_record_addition(&args);

error:
    amxc_string_clean(&instance_path);
    amxc_var_clean(&args);
    amxc_var_clean(&record_instance_values);

}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Initializes all TXT records for a given DNSSD record template.
 *
 * This function retrieves all instances of a DNSSD record described by
 * `record_template_path` and processes each one using `process_record()`.
 *
 * The steps performed are:
 *   1. Retrieves the record data from the DNSSD backend using `amxb_describe()`.
 *   2. Extracts the list of instances from the retrieved data.
 *   3. Iterates over each instance and calls `process_record()` to handle it.
 *
 * @param record_template_path  The base path template of the DNSSD record
 *                              to initialize (e.g., `"mDNSService.1.TextRecord"`).
 *
 * @note Memory for intermediate variables is cleaned up at the end of the function.
 *
 * @warning If the record data or instances cannot be retrieved, an error is
 *          logged and the function returns silently.
 */
static void record_initialization(const char* record_template_path) {

    amxc_var_t record_values;
    amxc_var_t* record_data = NULL;
    amxc_var_t* record_instances = NULL;
    amxc_var_init(&record_values);

    when_failed_trace(amxb_describe(retrieve_dnssd_ctx(), record_template_path, AMXB_FLAG_INSTANCES, &record_values, 5), error, ERROR, "Could not find record data");
    record_data = amxc_var_get_index(&record_values, 0, AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(record_data, error, ERROR, "Could not find service data.");
    record_instances = amxc_var_get_path(record_data, "instances", AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(record_instances, error, ERROR, "Could not find service data.");

    amxc_var_for_each(record, record_instances) {
        process_record(record, record_template_path);
    }

error:
    amxc_var_clean(&record_values);
}

/**
 * @ingroup gmap_mod_dnssd_utils
 *
 * @brief Processes a DNSSD service and its associated TXT records.
 *
 * This function performs the following steps:
 *   1. Constructs the instance path for the service.
 *   2. Constructs the TextRecord template path for the service.
 *   3. Retrieves the service instance data from the DNSSD backend.
 *   4. Packages the path and parameters into an argument variable.
 *   5. Calls `service_addition()` to process the service instance.
 *   6. Initializes all TXT records associated with the service using
 *      `record_initialization()`.
 *
 * @param service  The service instance identifier to process (usually a string key).
 *
 * @note Memory for intermediate strings and variables is cleaned up at the end
 *       of the function.
 *
 * @warning If the service data cannot be retrieved, an error is logged and the
 *          function returns silently.
 */
static void process_service(amxc_var_t* service) {
    amxc_string_t instance_path;
    amxc_string_t instance_record_template_path;
    amxc_var_t args;
    amxc_var_t service_instance_values;
    amxc_var_t* service_instance_data = NULL;

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_string_init(&instance_path, 0);
    amxc_string_appendf(&instance_path, "DNSSD.Service.%s.", amxc_var_constcast(cstring_t, service));
    amxc_string_init(&instance_record_template_path, 0);
    amxc_string_appendf(&instance_record_template_path, "DNSSD.Service.%s.TextRecord.", amxc_var_constcast(cstring_t, service));

    amxc_var_init(&service_instance_values);
    when_failed_trace(amxb_get(retrieve_dnssd_ctx(), amxc_string_get(&instance_path, 0), 0, &service_instance_values, GMAP_DNSSD_BUS_TIMEOUT), error, ERROR, "Could not find service data");
    service_instance_data = amxc_var_get_pathf(&service_instance_values, AMXC_VAR_FLAG_DEFAULT, "0.'%s'", amxc_string_get(&instance_path, 0));
    when_null_trace(service_instance_data, error, ERROR, "Could not find service data.");
    amxc_var_add_key(cstring_t, &args, "path", amxc_string_get(&instance_path, 0));
    amxc_var_add_key(amxc_htable_t, &args, "parameters", &service_instance_data->data.vm);
    service_addition(&args);
    record_initialization(amxc_string_get(&instance_record_template_path, 0));

error:
    amxc_string_clean(&instance_path);
    amxc_string_clean(&instance_record_template_path);
    amxc_var_clean(&args);
    amxc_var_clean(&service_instance_values);

}

void service_initialization(void) {

    amxc_var_t service_values;
    amxc_var_t* service_data = NULL;
    amxc_var_t* service_instances = NULL;
    amxc_var_init(&service_values);

    when_failed_trace(amxb_describe(retrieve_dnssd_ctx(), "DNSSD.Service.", AMXB_FLAG_INSTANCES, &service_values, 5), error, ERROR, "Could not find service data");
    service_data = amxc_var_get_index(&service_values, 0, AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(service_data, error, ERROR, "Could not find service data.");
    service_instances = amxc_var_get_path(service_data, "instances", AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(service_instances, error, ERROR, "Could not find service data.");

    amxc_var_for_each(service, service_instances) {
        process_service(service);
    }

error:
    amxc_var_clean(&service_values);
}

void service_addition(amxc_var_t* data) {
    char* gmap_key = NULL;
    char* service_key = NULL;
    char* service_name = NULL;
    char* target_dup = NULL;

    amxc_var_t values;
    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    amxc_var_t ret;
    amxc_var_init(&ret);

    amxc_var_t* params = GET_ARG(data, "parameters");
    when_null_trace(params, error, ERROR, "Cannot fetch object parameters");

    const char* ip = GET_CHAR(params, "IPAddresses");
    when_str_empty_trace(ip, error, ERROR, "Cannot identify ip address on new service");
    SAH_TRACEZ_INFO(ME, "new service on ip: %s", ip);

    gmap_key = gmap_key_by_ip_host(ip);
    when_str_empty_trace(gmap_key, error, ERROR, "Cannot identify associated gmap device on new service");
    SAH_TRACEZ_INFO(ME, "new service on gmap device: %s", gmap_key);

    // add the dnssd tag to the device
    when_false_trace(gmap_device_setTag(gmap_key, "dnssd", NULL, gmap_traverse_this), error, ERROR, "Failed to set 'dnssd' tag on %s", gmap_key);
    SAH_TRACEZ_INFO(ME, "set dnssd tag on gmap device: %s", gmap_key);

    service_key = generate_service_key(params);
    when_str_empty_trace(service_key, error, ERROR, "Cannot generate service_key");
    SAH_TRACEZ_INFO(ME, "service key: %s", service_key);

    service_name = generate_service_name(params);
    when_str_empty_trace(service_name, error, ERROR, "Cannot generate service_name");
    SAH_TRACEZ_INFO(ME, "service name: %s", service_name);

    amxc_var_add_key(cstring_t, &values, "Alias", service_key);
    amxc_var_add_key(cstring_t, &values, "ServiceName", service_name);
    amxc_var_add_key(uint32_t, &values, "Port", GET_UINT32(params, "Port"));
    amxc_var_add_key(cstring_t, &values, "Name", GET_CHAR(params, "InstanceName"));

    const char* target = GET_CHAR(params, "Target");
    when_str_empty_trace(target, error, ERROR, "Cannot identify Target on new service");

    target_dup = strdup(target);
    when_str_empty_trace(target_dup, error, ERROR, "Cannot duplicate target string.");

    const char delimiter = '.';
    char* domain = strrchr(target_dup, delimiter);
    when_str_empty_trace(domain, error, ERROR, "Cannot identify Target on new service");

    amxc_var_add_key(cstring_t, &values, "Domain", domain + 1);
    SAH_TRACEZ_INFO(ME, "domain: %s", domain + 1);

    gmap_add_instance(gmap_key, "mDNSService", &values);

    *domain = '\0';
    when_false_trace(gmap_device_setName(gmap_key, target_dup, "mdns"), error, ERROR, "Failed to set 'mdns' name %s on %s", target_dup, gmap_key);
    SAH_TRACEZ_INFO(ME, "mdns name: %s", target_dup);
    *domain = delimiter;

error:
    free(gmap_key);
    free(service_key);
    free(service_name);
    free(target_dup);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);

    return;

}

void service_removal(const amxc_var_t* const data) {
    char* gmap_key = NULL;
    char* service_key = NULL;
    amxc_string_t service_path;

    amxc_string_init(&service_path, 0);

    amxc_var_t* params = GET_ARG(data, "parameters");
    when_null_trace(params, error, ERROR, "Cannot fetch object parameters");

    const char* ip = GET_CHAR(params, "IPAddresses");
    when_str_empty_trace(ip, error, ERROR, "Cannot identify ip Host on new service");

    gmap_key = gmap_key_by_ip_host(ip);
    when_str_empty_trace(gmap_key, error, ERROR, "Cannot identify associated gmap device on new service");

    service_key = generate_service_key(params);
    when_str_empty_trace(service_key, error, ERROR, "Cannot generate service_key");

    amxc_string_appendf(&service_path, "mDNSService.%s", service_key);

    gmap_delete_instance(gmap_key, amxc_string_get(&service_path, 0), 0);

error:
    free(gmap_key);
    free(service_key);
    amxc_string_clean(&service_path);

    return;

}

void txt_record_addition(amxc_var_t* data) {
    char* gmap_key = NULL;
    char* service_path = NULL;
    char* service_key = NULL;
    char* service_name = NULL;
    char* template_path = NULL;

    amxc_var_t values;
    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    amxc_var_t ret;
    amxc_var_init(&ret);

    amxc_var_t service_values;
    amxc_var_t* service_data = NULL;
    amxc_var_init(&service_values);

    amxc_var_t* params = GET_ARG(data, "parameters");
    when_null_trace(params, error, ERROR, "Cannot fetch object parameters");

    const char* path = GET_CHAR(data, "path");

    service_path = generate_service_path_of_record(path);

    when_failed_trace(amxb_get(retrieve_dnssd_ctx(), service_path, 0, &service_values, GMAP_DNSSD_BUS_TIMEOUT), error, ERROR, "Could not find service corresponding to record");
    service_data = amxc_var_get_pathf(&service_values, AMXC_VAR_FLAG_DEFAULT, "0.'%s'", service_path);
    when_null_trace(service_data, error, ERROR, "Could not find service corresponding to record");

    const char* ip = GET_CHAR(service_data, "IPAddresses");
    when_str_empty_trace(ip, error, ERROR, "Cannot identify Host on new service");
    SAH_TRACEZ_INFO(ME, " record host: %s", ip);

    gmap_key = gmap_key_by_ip_host(ip);
    when_str_empty_trace(gmap_key, error, ERROR, "Cannot identify associated gmap device on new service");
    SAH_TRACEZ_INFO(ME, " record gmap key: %s", gmap_key);

    service_key = generate_service_key(service_data);
    when_str_empty_trace(service_key, error, ERROR, "Cannot generate service_key");
    SAH_TRACEZ_INFO(ME, " record service_key: %s", service_key);

    template_path = gmap_device_service_records_path(service_key);
    when_str_empty_trace(template_path, error, ERROR, "Cannot generate path to record template");
    SAH_TRACEZ_INFO(ME, " record template path: %s", template_path);

    const char* record_key = GET_CHAR(params, "Key");
    when_str_empty_trace(record_key, error, ERROR, "Cannot identify Key on new record");
    SAH_TRACEZ_INFO(ME, " record key: %s", record_key);

    const char* record_value = GET_CHAR(params, "Value");
    when_str_empty_trace(record_value, error, ERROR, "Cannot identify Value on new record");
    SAH_TRACEZ_INFO(ME, " record value: %s", record_value);

    amxc_var_add_key(cstring_t, &values, "Key", record_key);
    amxc_var_add_key(cstring_t, &values, "Alias", record_key);
    amxc_var_add_key(cstring_t, &values, "Value", record_value);

    gmap_add_instance(gmap_key, template_path, &values);

error:
    free(gmap_key);
    free(service_path);
    free(service_name);
    free(template_path);
    amxc_var_clean(&values);
    amxc_var_clean(&service_values);
    amxc_var_clean(&ret);

    return;

}
