/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>
#include <debug/sahtrace.h>

#include <lcm/amxc_data.h>
#include <lcm/lcm_assert.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_defines.h>

#include "cthulhu_capabilities.h"
#include "cthulhu_capabilities_common.h"
#include "cthulhu-capabilities/cthulhu_capabilities_defines.h"
#include "cthulhu_user_role.h"
#include "log.h"
#include "test_setup.h"
#include "dummy_be.h"
#include "test_caps_init.h"

static amxb_bus_ctx_t* bus_ctx = NULL;


int test_setup(UNUSED void** state) {
    assert_int_equal(test_caps_setup(), 0);
    assert_int_equal(test_register_dummy_be(), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);

    return 0;
}

int test_teardown(UNUSED void** state) {
    test_caps_teardown();
    amxb_disconnect(bus_ctx);
    amxb_free(&bus_ctx);
    test_unregister_dummy_be();
    return 0;
}

static void clear_dm(void) {
    amxd_object_t* device_obj = amxd_dm_findf(test_get_dummy_dm(), "Device.");
    if(device_obj) {
        amxd_object_free(&device_obj);
    }
    user_role_list_clean();
}

static void set_sb_roles(void) {
    amxd_object_t* sb_obj = test_sb_get("generic");
    assert_non_null(sb_obj);
    assert_int_equal(amxd_object_set_csv_string_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, "Role2,Role4"), 0);
    assert_int_equal(amxd_object_set_csv_string_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, "Device.Users.Role.[RoleName==\"Role2\"],Device.Users.Role.[RoleName==\"Role4\"]"), 0);
}

void test_caps_init_empty(UNUSED void** state) {
    LOG_ENTRY
    int res = cthulhu_capabilities_init("capabilities_init", NULL, NULL);
    assert_int_equal(res, -1);
    LOG_EXIT
}

void test_caps_init_no_dm(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, -1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    LOG_EXIT
}

void test_caps_init_no_users(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_true(amxc_llist_is_empty(get_user_role_list()));
    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}


void test_caps_init_users_before_init(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_string_t capabilities;
    amxc_string_init(&capabilities, 0);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();
    assert_false(amxc_llist_is_empty(get_user_role_list()));
    // Role2
    user_role_t* user_role = user_role_find_by_name("Role2");
    assert_true(user_role);
    assert_string_equal(user_role->name, "Role2");
    assert_string_equal(user_role->indexed_path, "Device.Users.Role.2.");
    assert_string_equal(user_role->named_path, "Device.Users.Role.[RoleName==\"Role2\"]");
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_NET_RAW,CAP_MKNOD");
    amxc_string_clean(&capabilities);

    // disabled user is not added
    user_role = user_role_find_by_name("Role3");
    assert_false(user_role);
    // Role4
    user_role = user_role_find_by_name("Role4");
    assert_true(user_role);
    assert_string_equal(user_role->name, "Role4");
    assert_string_equal(user_role->indexed_path, "Device.Users.Role.4.");
    assert_string_equal(user_role->named_path, "Device.Users.Role.[RoleName==\"Role4\"]");
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_NET_RAW,CAP_KILL");
    amxc_string_clean(&capabilities);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}

void test_caps_init_users_after_init(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_string_t capabilities;
    amxc_string_init(&capabilities, 0);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();

    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role2");
    assert_true(user_role);
    assert_string_equal(user_role->name, "Role2");
    assert_string_equal(user_role->indexed_path, "Device.Users.Role.2.");
    assert_string_equal(user_role->named_path, "Device.Users.Role.[RoleName==\"Role2\"]");
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_NET_RAW,CAP_MKNOD");
    amxc_string_clean(&capabilities);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}

void test_caps_init_disable_user(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();

    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role4");
    assert_true(user_role);

    // change enabled flag
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role.4."), 0);
    assert_int_equal(amxd_trans_set_value(bool, &transaction, "Enable", false), 0);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);


    test_handle_events();
    user_role = user_role_find_by_name("Role4");
    assert_false(user_role);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}


void test_caps_init_enable_user(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_string_t capabilities;
    amxc_string_init(&capabilities, 0);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();
    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role3");
    assert_false(user_role);

    // change enabled flag
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role.3."), 0);
    assert_int_equal(amxd_trans_set_bool(&transaction, "Enable", true), 0);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);

    test_handle_events();
    user_role = user_role_find_by_name("Role3");
    assert_true(user_role);
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_IPC_OWNER");
    amxc_string_clean(&capabilities);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}

void test_caps_init_change_caps(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_string_t capabilities;
    amxc_string_init(&capabilities, 0);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();

    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role2");
    assert_true(user_role);
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_NET_RAW,CAP_MKNOD");
    amxc_string_clean(&capabilities);

    // change capabilities
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role.2."), 0);
    assert_int_equal(amxd_trans_set_cstring_t(&transaction, "RequiredCapabilities", "CAP_NET_ADMIN"), 0);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);


    test_handle_events();
    user_role = user_role_find_by_name("Role2");
    assert_true(user_role);
    amxc_string_csv_join_var(&capabilities, &user_role->capabilities);
    assert_string_equal(amxc_string_get(&capabilities, 0), "CAP_NET_ADMIN");
    amxc_string_clean(&capabilities);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}

void test_caps_init_user_removed(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    clear_dm();

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();

    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role4");
    assert_true(user_role);

    // remove user 4
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role."), 0);
    amxd_trans_del_inst(&transaction, 4, NULL);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);


    test_handle_events();
    user_role = user_role_find_by_name("Role4");
    assert_false(user_role);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}

void test_caps_init_user_removed_used_by_sb(UNUSED void** state) {
    LOG_ENTRY

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxd_object_t* sb_obj = NULL;
    char* str = NULL;

    clear_dm();
    test_add_sb("generic");
    set_sb_roles();

    sb_obj = test_sb_get("generic");
    assert_string_equal(str = amxd_object_get_cstring_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, NULL), "Role2,Role4");
    free(str);

    test_load_dummy_remote("../odl/device_users.odl");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    test_handle_events();

    assert_false(amxc_llist_is_empty(get_user_role_list()));
    user_role_t* user_role = user_role_find_by_name("Role4");
    assert_true(user_role);

    // change enabled flag
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role."), 0);
    amxd_trans_del_inst(&transaction, 4, NULL);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);

    test_handle_events();
    user_role = user_role_find_by_name("Role4");
    assert_false(user_role);
    assert_string_equal(str = amxd_object_get_cstring_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, NULL), "Role2");
    free(str);

    cthulhu_capabilities_cleanup(NULL, NULL, NULL);
    LOG_EXIT
}