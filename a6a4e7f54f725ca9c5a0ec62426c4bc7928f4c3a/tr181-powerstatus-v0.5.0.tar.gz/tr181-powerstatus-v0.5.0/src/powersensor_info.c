/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "powersensor_info.h"
#include "tr181-powerstatus.h"

#define ME "powersensor"

/**
 * @brief
 * Create private information for a PowerSensor
 *
 * @param obj The PowerSensor instance object in the DM
 */
void powersensor_info_create(amxd_object_t* obj) {
    powersensor_info_t* info = NULL;

    when_null_trace(obj, exit, ERROR, "Object is NULL");
    when_false_trace(obj->priv == NULL, exit, ERROR, " Object '%s' already have private info", obj->name);

    info = (powersensor_info_t*) calloc(1, sizeof(powersensor_info_t));
    when_null_trace(info, exit, ERROR, "Cannot allocate memory for sensor info");
    obj->priv = info;
    info->obj = obj;

    when_failed_trace(amxp_timer_new(&info->polling_timer, powersensor_timer_cb, info), exit, ERROR, "Cannot create polling timer");

exit:
    return;
}

/**
 * @brief
 * Clean the information of a PowerSensor. This function only need to be called when the PowerSensor will not be used anymore.
 *
 * @param info The private data of the PowerSensor to clean.
 */
void powersensor_info_clear(powersensor_info_t* info) {
    when_null(info, exit);

    if(info->obj != NULL) {
        info->obj->priv = NULL;
    }

    amxp_timer_delete(&info->polling_timer);
    free(info);
    info = NULL;
exit:
    return;
}