/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "button.h"
#include "dm_button.h"
#include <yajl/yajl_gen.h>
#include <amxj/amxj_variant.h>


static void button_action_handle(action_method_t method_type, const char* action_object, const char* message) {
    amxb_bus_ctx_t* ctx = NULL;
    amxc_var_t json_message;
    amxc_var_t* method = NULL;
    amxc_var_t* args = NULL;
    amxd_path_t path;
    amxc_var_t paths;

    amxc_var_init(&json_message);
    amxd_path_init(&path, action_object);
    amxc_var_init(&paths);

    ctx = amxb_be_who_has(action_object);
    when_null_trace(ctx, exit, ERROR, "Can not get bus ctx for [%s]", action_object);
    when_null_trace(message, exit, ERROR, "Invalid message");

    when_failed_trace(amxc_var_set(jstring_t, &json_message, message), exit, ERROR, "Could not transform string to json var [%s]", message);
    amxc_var_cast(&json_message, AMXC_VAR_ID_HTABLE);

    if(method_type == BUTTON_ACTION_METHOD_SET) {
        args = amxc_var_take_key(&json_message, "parameters");
        when_null_trace(args, exit, ERROR, "Invalid parameters");
    } else {
        method = amxc_var_take_key(&json_message, "method");
        args = amxc_var_take_key(&json_message, "args");
        when_null_trace(method, exit, ERROR, "Invalid method");
    }

    if(amxd_path_get_type(&path) == amxd_path_search) {
        int rv = amxb_resolve(ctx, &path, &paths);
        when_true_trace((rv != 0) || amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, &paths)), exit, ERROR, "No objects found");
    } else {
        amxc_var_set_type(&paths, AMXC_VAR_ID_LIST);
        amxc_var_add(cstring_t, &paths, amxd_path_get(&path, AMXD_OBJECT_TERMINATE));
    }

    amxc_var_for_each(object, &paths) {
        const char* object_path = GET_CHAR(object, NULL);
        if(method_type == BUTTON_ACTION_METHOD_SET) {
            when_true_trace(amxb_set(ctx, object_path, args, NULL, 5), exit, ERROR, "Action trigger is Fail");
        } else {
            when_true_trace(amxb_call(ctx, object_path, GET_CHAR(method, NULL), args, NULL, 5), exit, ERROR, "Action trigger is Fail");
        }
    }

exit:
    if(method != NULL) {
        amxc_var_delete(&method);
    }
    if(args != NULL) {
        amxc_var_delete(&args);
    }
    amxc_var_clean(&json_message);
    amxd_path_clean(&path);
    amxc_var_clean(&paths);
    return;
}

void button_action_trigger(amxd_object_t* action_instance) {
    amxc_var_t params;
    amxc_var_init(&params);

    when_null(action_instance, exit);
    SAH_TRACEZ_INFO(ME, "Triger action [%s]", amxd_object_get_name(action_instance, AMXD_OBJECT_NAMED));
    amxd_object_get_params(action_instance, &params, amxd_dm_access_protected);

    if(strcmp("Set", GET_CHAR(&params, "Method")) == 0) {
        button_action_handle(BUTTON_ACTION_METHOD_SET, GET_CHAR(&params, "Object"), GET_CHAR(&params, "Message"));
    } else if(strcmp("Exec", GET_CHAR(&params, "Method")) == 0) {
        button_action_handle(BUTTON_ACTION_METHOD_EXEC, GET_CHAR(&params, "Object"), GET_CHAR(&params, "Message"));
    }

exit:
    amxc_var_clean(&params);
}