/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__UTILS_H__)
#define __UTILS_H__

/**
 * @brief check is version is valid
 *
 * Helper function:
 * check if the version is of the format "x.y.z"
 *
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t is_valid_version_string(const char* version);

/**
 * @brief compare versions
 *
 * Helper function:
 * Compare version1 with version2.
 * Versions must follow Semantic Versioning 2.0.0,
 * but only the <version core> component (i.e., the numerical part) is supported.
 *
 * @param version1 version 1
 * @param version2 version 2
 * @return 0 if equal, -1 version1 is older than version2, +1 if version1 is newer than version2
 */
int compare_version_string(const char* version1, const char* version2);


/**
 * @brief print variant as trace
 *
 * Helper function:
 * print the contents of a variant as a trace using sahtrace.
 *
 * @param prefix  string to be added to the beginning of the trace
 * @param var  the variant to be printed
 */
void print_variant_as_trace(const char* prefix, amxc_var_t* var);

/**
 * @brief send trigger with Action logs
 *
 * send one or all Action logs using a trigger
 *
 * @param obj  Action log entry object to be sent in the trigger
 *             if NULL, all logs will be sent
 * @param command_id  if not NULL, command id will be added to the trigger
 * @param notification_type  notification type, one of
 *                                  CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_LIST
 *                                  CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_UPDATED
 *                                  CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_REMOVED
 */
void send_trigger(amxd_object_t* obj, const char* command_id, const char* notification_type);

/**
 * @brief add Action log to datamodel
 *
 * Helper function:
 * add an Action log entry to the datamodel to log a policy action or error
 */
void add_action_entry_to_dm(amxd_dm_t* dm, policylog_t* log, const char* id);


/**
 * @brief update status in existing datamodel log entry.
 *
 * Helper function:
 * update the container status in an existing datamodel log entry.
 */
void change_action_status(amxd_dm_t* dm, const char* id, const char* new_status);

/**
 * @brief add errorinfo to log object
 *
 * Helper function:
 * Add a free format string (with printf-like addtional arguments) to the ErrorInfo member of a log object.
 * When called multiple times on the same log object,
 * the string is appended to the previous one with a newline in between.
 *
 * @param log the log object
 * @param info the error string
 */
void add_log_error_info(policylog_t* log, const char* info, ...);

/**
 * @brief add list to hash variant
 *
 * Helper function:
 * add a new list to a hash table variant
 * @param list the hash table variant
 * @param sublist the key string of the new list
 */
void add_new_sublist(amxc_var_t* list, const char* sublist);

#endif // __UTILS_H__
