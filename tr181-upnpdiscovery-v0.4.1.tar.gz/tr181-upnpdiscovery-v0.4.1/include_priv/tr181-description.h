/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __TR181_DESCRIPTION_H__
#define __TR181_DESCRIPTION_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxp/amxp.h>
#include <amxc/amxc.h>
#include <amxd/amxd_object.h>

#define UPNP_DESCRIPTION_DEVDESC_OBJ_PATH "UPnPDescription.DeviceDescription."
#define UPNP_DESCRIPTION_DEVINST_OBJ_PATH "UPnPDescription.DeviceInstance."
#define UPNP_DESCRIPTION_SERVINST_OBJ_PATH "UPnPDescription.ServiceInstance."

/**
 * @brief Structure representing a UPnP device description.
 *
 * Contains information about the device's location, description object,
 * XML document, and IP address.
 */
typedef struct _device_desc {
    const char* location;          /**< URL location of the device description XML */
    amxd_object_t* device_desc;    /**< Pointer to the device description object */
    IXML_Document* xmlDoc;         /**< Pointer to the XML document of the device description */
    char* ip_address;              /**< IP address of the device */
} device_desc_t;


/**
 * @brief Updates the local device description by retrieving and parsing
 *        a UPnP device description document from a given location.
 *
 * Downloads the UPnP XML description from the specified @p location,
 * extracts the device's IP address and description, and parses the XML
 * content to update the internal representation.
 *
 * @param location The URL of the UPnP device description XML document.
 *                 Must not be NULL or empty.
 *
 * @return 0 on success,
 *        -1 on failure (e.g., invalid location, unreachable resource,
 *        download error, or missing device description).
 */
int upnp_description_update_from_location(const char* location);

/**
 * @brief Updates the ServiceDiscovery parameter of a UPnP service object
 *        by matching it against discovered services.
 *
 * Looks up the discovery service object in the data model and searches
 * its instances for a match with the service type of the given @p service.
 * If a match is found, the ServiceDiscovery parameter of @p service is
 * updated with the corresponding USP path.
 *
 * @param service Pointer to the UPnP service object whose discovery
 *                information should be updated. Must not be NULL.
 *
 * @return 0 on success,
 *        -1 if the discovery service object is missing or an error occurs.
 */
int upnp_description_update_service_discovery(amxd_object_t* service);

/**
 * @brief Updates the DiscoveryDevice parameter of a UPnP device object
 *        by matching it against discovered devices.
 *
 * Searches the discovery device object in the data model and iterates
 * over its instances to find one whose USN contains the type of the
 * given @p device. If a match is found, the DiscoveryDevice parameter
 * of @p device is updated through a transaction with the corresponding
 * USP path.
 *
 * @param device Pointer to the UPnP device object whose discovery
 *               information should be updated. Must not be NULL.
 *
 * @return 0 on success,
 *        -1 if the discovery device object is missing or if an error occurs
 *           while applying the update.
 */
int upnp_description_update_device_discovery(amxd_object_t* device);

/**
 * @brief Extracts the IP address from a UPnP device description URL.
 *
 * Parses the @c location field of the given @p data structure and
 * extracts the host IP address (IPv4 or IPv6) into @c data->ip_address.
 * For IPv6 addresses, brackets are removed. For IPv4, the substring
 * before ':' or '/' is used.
 *
 * @param data Pointer to a device description structure. Must contain
 *             a valid @c location string. On success, the @c ip_address
 *             field is allocated and set.
 *
 * @note The caller is responsible for freeing @c data->ip_address.
 */
void upnp_description_extract_ipaddress(device_desc_t* data);

/**
 * @brief Retrieves or creates a UPnP device description object for the given location.
 *
 * Searches the data model for a device description instance matching the
 * specified @p location (via the @c URLBase parameter). If no matching
 * object exists, a new one is created using
 * @c upnp_description_create_device_description.
 *
 * @param location The UPnP device description URL (used to match against
 *                 @c URLBase in the data model). Must not be NULL or empty.
 *
 * @return Pointer to the matching or newly created device description
 *         object, or NULL if none could be found or created.
 */
amxd_object_t* upnp_description_get_device_description(const char* location);

/**
 * @brief Recursively parses an XML node tree to extract UPnP device description data.
 *
 * Iterates over the given XML node and its siblings. For each node that
 * has child elements, the function looks up a matching handler in the
 * global @_node_func array based on the node name. If a handler is found,
 * it is invoked with the node's first child and the provided device
 * description data structure. If no handler matches, the function recurses
 * into the child node to continue parsing.
 *
 * @param node  Pointer to the current XML node to parse.
 * @param data  Pointer to the device description structure to be filled.
 *
 * @return Always returns 0.
 */
int parse_xmlnode(IXML_Node* node, device_desc_t* data);

/**
 * @brief Sets the parent device identifier.
 *
 * Updates the global or module-level string @_parent_device with the
 * specified @p parent value.
 *
 * @param parent Pointer to a null-terminated string representing the
 *               parent device. Must not be NULL.
 */
void set_parent(const char* parent);

/**
 * @brief Updates or creates a UPnP device instance in the data model.
 *
 * Finds an existing device instance using the UDN from @p var or creates
 * a new one if none exists. Sets all relevant device parameters such as
 * ParentDevice, DeviceType, FriendlyName, Manufacturer, Model, SerialNumber,
 * PresentationURL, and IPAddress based on the provided @p var and @p data.
 *
 * @param var  Pointer to an @c amxc_var_t containing the device parameters.
 *             Must not be NULL and must contain a valid "UDN" string.
 * @param data Pointer to a @c device_desc_t structure containing additional
 *             device data (e.g., IP address). Must not be NULL.
 *
 * @return 0 on success, or a non-zero error code if the device instance
 *         could not be created or updated.
 */
int upnp_description_update_device(amxc_var_t* var, device_desc_t* data);

/**
 * @brief Updates or creates a UPnP service instance in the data model.
 *
 * Finds an existing service instance using the ParentDevice and ServiceId
 * from @p var, or creates a new one if none exists. Sets all relevant
 * service parameters such as ServiceType, SCPDURL, ControlURL, and
 * EventSubURL based on the provided @p var.
 *
 * @param var Pointer to an @c amxc_var_t containing the service parameters.
 *            Must not be NULL and must contain a valid "ServiceId" string.
 *
 * @return 0 on success, or a non-zero error code if the service instance
 *         could not be created or updated.
 */
int upnp_description_update_service(amxc_var_t* var);

/**
 * @brief Callback invoked when a UPnP description object is added.
 *
 * Retrieves the newly added object from the data model using the
 * provided @p data information, obtains its Location parameter,
 * and updates the corresponding device description by calling
 * @c upnp_description_update_from_location.
 *
 * @param sig_name Ignored in this function.
 * @param data     Pointer to a variable containing the object info
 *                 (must include "object" and "index").
 * @param priv     Ignored in this function.
 */
void _upnp_description_object_added(UNUSED const char* const sig_name,
                                    const amxc_var_t* const data,
                                    UNUSED void* const priv);

/**
 * @brief Callback invoked when a UPnP service object is added.
 *
 * Retrieves the newly added service object from the data model using
 * the provided @p data information and updates its service discovery
 * information by calling @c upnp_description_update_service_discovery.
 *
 * @param sig_name Ignored in this function.
 * @param data     Pointer to a variable containing the service info
 *                 (must include "object" and "index").
 * @param priv     Ignored in this function.
 */
void _upnp_description_service_added(UNUSED const char* const sig_name,
                                     const amxc_var_t* const data,
                                     UNUSED void* const priv);

/**
 * @brief Callback invoked when a UPnP device object is added.
 *
 * Retrieves the newly added device object from the data model using
 * the provided @p data information and updates its device discovery
 * information by calling @c upnp_description_update_device_discovery.
 *
 * @param sig_name Ignored in this function.
 * @param data     Pointer to a variable containing the device info
 *                 (must include "object" and "index").
 * @param priv     Ignored in this function.
 */
void _upnp_description_device_added(UNUSED const char* const sig_name,
                                    const amxc_var_t* const data,
                                    UNUSED void* const priv);

/**
 * @brief Adds a UPnP device instance to the data model.
 *
 * Extracts the "values" and "ParentDevice" parameters from @p args,
 * sets the parent device, and updates the device instance using
 * @c upnp_description_update_device. Only the "UDN" field in
 * @c values must be provided; other fields are optional.
 *
 * @param object Ignored in this function.
 * @param func   Ignored in this function.
 * @param args   Input arguments containing device values. Must include
 *               "values.UDN" and "values.ParentDevice".
 * @param ret    Output variable that will be set to @c true if the
 *               device instance was successfully added, @c false otherwise.
 *
 * @return Always returns @c amxd_status_ok.
 */
amxd_status_t _addDeviceInstance(UNUSED amxd_object_t* object,
                                 UNUSED amxd_function_t* func,
                                 amxc_var_t* args,
                                 amxc_var_t* ret);

/**
 * @brief Adds a UPnP service instance to the data model.
 *
 * Extracts the "values" and "ParentDevice" parameters from @p args,
 * sets the parent device, and updates the service instance using
 * @c upnp_description_update_service. Only the "ServiceId" field in
 * @c values must be provided; other fields are optional.
 *
 * @param object Ignored in this function.
 * @param func   Ignored in this function.
 * @param args   Input arguments containing service values. Must include
 *               "values.ParentDevice" and "values.ServiceId".
 * @param ret    Output variable that will be set to @c true if the
 *               service instance was successfully added, @c false otherwise.
 *
 * @return Always returns @c amxd_status_ok.
 */
amxd_status_t _addServiceInstance(UNUSED amxd_object_t* object,
                                  UNUSED amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret);

/**
 * @brief Deletes a UPnP device instance from the data model.
 *
 * Removes the device instance identified by the "index" parameter from
 * the given @p object using a transaction. The operation sets @p ret
 * to true if the deletion was successful, or false otherwise.
 *
 * @param object The device object containing the instance to delete.
 *               Must not be NULL.
 * @param func   Ignored in this function.
 * @param args   Input arguments containing the instance index to delete
 *               ("index"). Must be greater than 0.
 * @param ret    Output variable that will be set to @c true if the
 *               instance was successfully deleted, @c false otherwise.
 *
 * @return Always returns @c amxd_status_ok.
 */
amxd_status_t _deleteDeviceInstance(amxd_object_t* object,
                                    UNUSED amxd_function_t* func,
                                    amxc_var_t* args,
                                    amxc_var_t* ret);

/**
 * @brief Deletes a UPnP service instance from the data model.
 *
 * Removes the service instance identified by the "index" parameter from
 * the given @p object using a transaction. Sets @p ret to true if the
 * deletion was successful, or false otherwise.
 *
 * @param object The service object containing the instance to delete.
 *               Must not be NULL.
 * @param func   Ignored in this function.
 * @param args   Input arguments containing the instance index to delete
 *               ("index"). Must be greater than 0.
 * @param ret    Output variable that will be set to @c true if the
 *               instance was successfully deleted, @c false otherwise.
 *
 * @return Always returns @c amxd_status_ok.
 */
amxd_status_t _deleteServiceInstance(amxd_object_t* object,
                                     UNUSED amxd_function_t* func,
                                     amxc_var_t* args,
                                     amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __TR181_DESCRIPTION_H__
