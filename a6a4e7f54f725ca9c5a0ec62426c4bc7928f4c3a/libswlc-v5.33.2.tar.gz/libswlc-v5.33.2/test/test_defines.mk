ifndef STAGINGDIR
	$(error "STAGINGDIR not defined")
endif

MKFILE_PATH := $(abspath $(lastword $(MAKEFILE_LIST)))
SUT_DIR = $(dir $(MKFILE_PATH))..
$(info $$SUT_DIR is [${SUT_DIR}])

