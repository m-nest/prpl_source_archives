{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
%populate {
    object Firewall {
        object Policy {
            instance add(Alias=WAN2GUEST_low) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2GUEST_medium) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2GUEST_high) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='High_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2GUEST_Custom) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=IPV6_WAN2GUEST_low) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2GUEST_medium) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2GUEST_high) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='IPV6_High_Out']";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2GUEST_Custom) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 6;
            }
{% if (has_failover): %}
            instance add(Alias=WANCELLULAR2GUEST_low) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2GUEST_medium) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2GUEST_high) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='High_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2GUEST_Custom) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=IPV6_WANCELLULAR2GUEST_low) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2GUEST_medium) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2GUEST_high) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='IPV6_High_Out']";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2GUEST_Custom) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_guest}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 6;
            }
{% endif; %}
        }
        object InterfaceSetting {
            instance add(Alias=guest) {
                parameter Interface = "${ip_intf_guest}";
                parameter IPv4AcceptICMPEchoRequest = true;
                parameter IPv6AcceptICMPEchoRequest = true;
                parameter IsolateInterface = "Firewall.InterfaceSetting.[Alias=='lan']";
                parameter IPv4AcceptUDPTraceroute = true;
                parameter IPv6AcceptUDPTraceroute = true;
                parameter StealthMode = false;
            }
        }
    }
}
