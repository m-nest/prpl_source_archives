# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.1.0 - 2025-07-29(07:20:53 +0000)

### Other

- - [UPnP Discovery]Support Link with Hosts data model.

