/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__CTHULHU_LPM_DEFINES_H__)
#define __CTHULHU_LPM_DEFINES_H__

#include <cthulhu/cthulhu_defines.h>

#define LA "LocalPolicyManager"
#define LPMI CTHULHU_DM_INFO "." LA
#define LPMC CTHULHU_DM_CONFIG "." LA
#define LPM_ACTION LPMI ".Action"
#define POLICYFILE "PolicyFile"
#define POLICYFILEOVERRIDE "PolicyFileOverride"
#define EXECUTEDAFTERUPGRADE "ExecutedAfterUpgrade"

// Cthulhu LocalManagement Action (LA) Parameters
#define LA_ALIAS "Alias"
#define LA_UUID "UUID"
#define LA_EXECENVNAME "ExecEnvName"
#define LA_ACTION "Action"
#define LA_PREVIOUSMODULEVERSION "PreviousModuleVersion"
#define LA_CURRENTMODULEVERSION "CurrentModuleVersion"
#define LA_STATUS "Status"
#define LA_FAULTMESSAGE "FaultMessage"
#define LA_EVENT "Event"
#define LA_POLICYSCOPE "PolicyScope"
#define LA_DATE "Date"

#define POLICY_SCOPE_GLOBAL "Global"
#define POLICY_SCOPE_APPLICATION "Application"

#define POLICY_JSON_APPLICATIONS "applications"
#define POLICY_JSON_SANDBOXES "sandboxes"
#define POLICY_JSON_GLOBAL "global"

#define ACTION_STATUS_VALIDATIONERROR "ValidationError"
#define ACTION_STATUS_UNINSTALL "Uninstall"
#define ACTION_STATUS_SUCCESS "Success"
#define ACTION_STATUS_INPROGRESS "InProgress"

typedef enum _policy_event {
    PE_ERROR = 0,
    PE_ONNEW,
    PE_ONEXISTING,
    PE_ONEXISTINGUPGRADE,
    PE_ONEXISTINGDOWNGRADE,
    PE_ONUNKNOWN
} policy_event_t;

typedef enum _policy_action {
    PA_ERROR = 0,
    PA_INSTALL,
    PA_UNINSTALL,
    PA_UPDATE,
    PA_IGNORE
} policy_action_t;

typedef enum _policy_type {
    PT_CONTAINER,
    PT_SANDBOX
} policy_type_t;

typedef struct _policylog {
    const char* policy_event;
    const char* policy_action;
    const char* policy_scope;
    const char* old_version;
    const char* new_version;
    const char* execenv;
    amxc_string_t error_info;
} policylog_t;

amxd_dm_t* get_dm(void);

#endif // __CTHULHU_LPM_DEFINES_H__
