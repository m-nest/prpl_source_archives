/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __TEST_DM_PINHOLE_H__
#define __TEST_DM_PINHOLE_H__

int test_pinhole_setup(void** state);
int test_pinhole_teardown(void** state);

void test_pinhole_initialization(void** state);

void test_add_pinhole(void** state);
void test_add_pinhole_success(void** state);
void test_add_twos_pinhole_failed(void** state);
void test_pinhole_add_1_to_source_prefixes(void** state);
void test_pinhole_remove_1_from_source_prefixes(void** state);
void test_pinhole_disable(void** state);
void test_pinhole_remove_1_from_source_prefixes_while_disabled(void** state);
void test_pinhole_enable(void** state);
void test_pinhole_swap_to_inactive_schedule_ref(void** state);
void test_pinhole_add_active_schedule_ref(void** state);
void test_pinhole_remove_inactive_schedule_ref(void** state);
void test_pinhole_add_disabled_schedule_ref(void** state);
void test_pinhole_remove_active_schedule_ref(void** state);
void test_pinhole_swap_to_active_schedule_ref(void** state);
void test_pinhole_clear_schedule_ref(void** state);
void test_remove_pinhole(void** state);
void test_remove_source_port(void** state);
void test_add_source_port(void** state);
void test_change_integer_protocol(void** state);
void test_change_wrong_protocol(void** state);
void test_remove_destination_port(void** state);
void test_add_destination_port(void** state);
void test_change_ipversion_to_ipv6(void** state);
void test_change_ipversion_to_unused(void** state);
void test_change_ipversion_to_ipv4(void** state);
void test_ipversion4_change_dest_ip_to_ipv6(void** state);
void test_ipversion4_change_dest_ip_to_ipv4(void** state);
void test_ipversion6_change_dest_ip_to_ipv6(void** state);
void test_ipversion6_change_dest_ip_to_ipv4(void** state);
void test_ipversionx_change_dest_ip_to_ipv6(void** state);
void test_ipversionx_change_dest_ip_to_ipv4(void** state);
void test_pinhole_lease_time(void** state);
void test_pinhole_dest_range(void** state);
void test_pinhole_src_range(void** state);
void test_pinhole_range(void** state);
void test_pinhole_destmac(void** state);
void test_pinhole_expired_endtime(void** state);

void test_method_setPinhole(void** state);
void test_method_updatePinhole(void** state);
void test_method_list_one_pinhole(void** state);
void test_method_list_all_pinholes(void** state);
void test_method_deletePinhole(void** state);

#endif // __TEST_DM_PINHOLE_H__
