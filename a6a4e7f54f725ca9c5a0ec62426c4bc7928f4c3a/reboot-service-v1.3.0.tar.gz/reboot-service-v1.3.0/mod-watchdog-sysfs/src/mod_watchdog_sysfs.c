/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <linux/watchdog.h>
#include <debug/sahtrace.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "mod_watchdog_sysfs.h"
#include "reboot_wd.h"

#ifndef UNIT_TEST
#define BOOTSTATUS_FMT "/sys/class/watchdog/%s/bootstatus"
#else
#define BOOTSTATUS_FMT "../config/%s"
#endif

static int get_wd_status(UNUSED const char* function_name,
                         amxc_var_t* args,
                         amxc_var_t* ret) {
    const char* device = GET_CHAR(args, "device");
    amxc_string_t bootstatus_str;
    FILE* fp = NULL;
    uint32_t bootstatus = 0;
    int32_t res = REBOOT_WD_REASON_NONE;

    if(device == NULL) {
        device = "watchdog0";
    }

    amxc_string_init(&bootstatus_str, 0);
    amxc_string_setf(&bootstatus_str, BOOTSTATUS_FMT, device);
    fp = fopen(amxc_string_get(&bootstatus_str, 0), "r");
    when_null_trace(fp, exit, WARNING, "Watchdog device does not exist: %s", amxc_string_get(&bootstatus_str, 0));
    if(fscanf(fp, "%u", &bootstatus) != 1) {
        SAH_TRACEZ_WARNING(ME, "Watchdog device read error");
        res = REBOOT_WD_REASON_NONE;
    }
    fclose(fp);

    if(bootstatus & WDIOF_OVERHEAT) {
        res = REBOOT_WD_REASON_OVERHEAT;
    } else if(bootstatus & WDIOF_FANFAULT) {
        res = REBOOT_WD_REASON_FANFAULT;
    } else if(bootstatus & (WDIOF_POWERUNDER | WDIOF_POWEROVER)) {
        res = REBOOT_WD_REASON_POWER;
    } else if(bootstatus & WDIOF_CARDRESET) {
        res = REBOOT_WD_REASON_CARDRESET;
    } else if(bootstatus > 0) {
        res = REBOOT_WD_REASON_UNKNOWN;
    }

    amxc_var_set(int32_t, ret, res);
exit:
    amxc_string_clean(&bootstatus_str);

    return 0;
}

static AMXM_CONSTRUCTOR sysfs_wd_module_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, "mod-watchdog-sysfs");
    amxm_module_add_function(mod, "get-wd-status", get_wd_status);

    return 0;
}

static AMXM_DESTRUCTOR sysfs_wd_module_stop(void) {
    return 0;
}
