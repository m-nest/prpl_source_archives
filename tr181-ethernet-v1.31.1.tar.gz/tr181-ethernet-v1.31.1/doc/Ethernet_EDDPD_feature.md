﻿# **Energy Detect Power Down**
BBF Jira: DEV2DM-1175

Reference: <https://microchip.my.site.com/s/article/Use-of-the-Energy-Detect-Power-Down-mode-in-LAN87x0-Ethernet-PHY-Devices>

Linux / Ethtool: <https://man7.org/linux/man-pages/man8/ethtool.8.html>

Parameter proposal:

EDPD Capability: when retrieving the EDPD parameters fail treat it as unsupported.

EDPD Enable: True / False. 

EDPD Status: Disable, Active, Inactive and unsupported.
```
do_get_phy_tunable
...
if (send_ioctl(ctx, &cont.ds) < 0) {
» » » perror("Cannot Get PHY Energy Detect Power Down value");
» » » return 87;
» » }

» » if (cont.msecs == ETHTOOL\_PHY\_EDPD\_DISABLE)
» » » fprintf(stdout, "Energy Detect Power Down: disabled\n");
» » else if (cont.msecs == ETHTOOL\_PHY\_EDPD\_NO\_TX)
» » » fprintf(stdout,
» » » » "Energy Detect Power Down: enabled, TX disabled\n");
» » else
» » » fprintf(stdout,
» » » » "Energy Detect Power Down: enabled, TX %u msecs\n",
» » » » cont.msecs);
» } else {
...
```

Do we want to set the Tx pulse timings?

see <https://man7.org/linux/man-pages/man8/ethtool.8.html>

--set-phy-tunable energy-detect-power-down on 

**msecs** *N* Some PHYs support configuration of the wake-up interval to send TX pulses. This setting allows the control of this interval, and 0 disables TX pulses if the PHY supports this. Disabling TX pulses can create a lock-up situation where neither of the PHYs wakes the other one. If unspecified the default value (in milliseconds) will be used by the PHY.

[DAVIDC]: I am in favour of leaving this up to the implementation.

My feeling is that this will be hardware specific and should not be altered by a higher level power management entity.
# **Data model**

|Device.Ethernet.Interface.{i}.|object(0:)|R|<p>Ethernet interface table (a stackable interface object as described in [[Section 4.2/TR-181i2](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.TR-181i2)]). This table models physical Ethernet ports, but in terms of the interface stack it only models the PHY and Connection Access Method of the Ethernet interface MAC. A [*Link*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Link.) is also required to model a full Ethernet device.</p><p>At most one entry in this table can exist with a given value for [*Alias*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Alias), or with a given value for [*Name*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Name).</p><p>**Changes since 2.16:**</p><p>- Added [*EDPDCapability*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.EDPDCapability) parameter</p><p>- Added [*EDPDEnable*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.EDPDEnable) parameter</p><p>- Added [*EDPDStatus*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.EDPDStatus) parameter</p>|-|2\.0|
| :- | :- | :- | :- | :- | :- |
|Status|string|R|<p>The current operational state of the interface (see [[Section 4.2.2/TR-181i2](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.TR-181i2)]). Enumeration of:</p><p>- *Up*</p><p>- *Down*</p><p>- *Unknown*</p><p>- *Dormant*</p><p>- *NotPresent*</p><p>- *LowerLayerDown*</p><p>- *Error* (OPTIONAL)</p><p>When [*Enable*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Enable) is *false* then *Status* SHOULD normally be [*Down*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Down) (or [*NotPresent*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.NotPresent) or [*Error*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Error) if there is a fault condition on the interface).</p><p>When [*Enable*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Enable) is changed to *true* then *Status* SHOULD change to [*Up*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Up) if and only if the interface is able to transmit and receive network traffic; it SHOULD change to [*Dormant*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Dormant) if and only if the interface is operable but is waiting for external actions before it can transmit and receive network traffic (and subsequently change to [*Up*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Up) if still operable when the expected actions have completed); it SHOULD change to [*LowerLayerDown*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.LowerLayerDown) if and only if the interface is prevented from entering the [*Up*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Up) state because one or more of the interfaces beneath it is down; it SHOULD remain in the [*Error*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Error) state if there is an error or other fault condition detected on the interface; it SHOULD remain in the [*NotPresent*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.NotPresent) state if the interface has missing (typically hardware) components; it SHOULD change to [*Unknown*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.Unknown) if the state of the interface can not be determined for some reason.</p><p>This parameter is based on *ifOperStatus* from [[RFC2863](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.RFC2863)].</p><p>Because the interface includes layer 1, the [*LowerLayerDown*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.Status.LowerLayerDown) value SHOULD never be used.</p>|-|2\.0|
|EDPDCapability|boolean|R|<p>Indicates whether this physical ethernet port supports Energy Detect Power Down (EDPD).</p><p>Energy Detect Power Down is not part of [[802.3-2015](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.802.3-2015)] standard, implementations of this feature are vendor specific.</p>|-|2\.19|
|EDPDEnable|boolean|W|<p>Indicates whether Energy Detect Power Down (EDPD) support is currently enabled. When enabled, depending on the type of hardware, either the transmit power is disabled or the link impulses are sent a greater impuleses.</p><p>Energy Detect Power Down is not part of [[802.3-2015](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.802.3-2015)] standard, implementations of this feature are vendor specific.</p>|-|2\.19|
|EDPDStatus|string|R|<p>Indicates the active state of Energy Detect Power Down (EDPD).</p><p>Energy Detect Power Down is not part of [[802.3-2015](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#R.802.3-2015)] standard, implementations of this feature are vendor specific.</p><p>Enumeration of:</p><p>- *Disabled* (Indictes that EDPD is disabled)</p><p>- *Enabled* (Indicates that [*EDPDEnable*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.EDPDEnable) is enabled and supported by the physical interface. In this state EDPD will be used)</p><p>- *Unsupported* (Indicates that this physical interface does not support EDPD. In which case [*EDPDCapability*](https://build.broadband-forum.org/artifact/BUSDM-DEV2DMDEV792/MORE/build-2/HTML/tr-181-2-usp-diffs.html#D.Device:2.Device.Ethernet.Interface.EDPDCapability) will be *false*)</p>|-|2\.19|

