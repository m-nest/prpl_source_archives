/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>

#include "button.h"
#include "dm_button.h"
#include "mock.h"
#include "test_event.h"


#define BUTTON_TEST_DM_DEFAULTS "button_event.odl"

static amxd_dm_t dm;
static amxo_parser_t parser;

static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void handle_alarm(int sig) {
    printf("sig %d\n", sig);
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "button_event_changed", AMXO_FUNC(_button_event_changed));
    amxo_resolver_ftab_add(&parser, "button_event_added", AMXO_FUNC(_button_event_added));
    amxo_resolver_ftab_add(&parser, "button_event_removed", AMXO_FUNC(_button_event_removed));
    amxo_resolver_ftab_add(&parser, "Push", AMXO_FUNC(_Push));
    amxo_resolver_ftab_add(&parser, "Release", AMXO_FUNC(_Release));

    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_DM_DEFAULTS, root_obj), 0);
    assert_int_equal(_button_main(AMXO_START, &dm, &parser), 0);

    signal(SIGALRM, handle_alarm);
    _button_app_start(NULL, NULL, NULL);
    wait_for_sigalarm(1);
    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_button_main(AMXO_STOP, &dm, &parser), 0);
    amxo_resolver_import_close_all();
    amxm_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_event_change(UNUSED void** state) {
    amxd_object_t* button_event_instance = amxd_dm_findf(&dm, "Buttons.Button.Reset.Event.Press.");
    amxd_trans_t trans;
    button_event_t* event_info = NULL;

    assert_non_null(button_event_instance);
    event_info = button_event_instance->priv;

    assert_non_null(event_info);
    assert_false(event_info->enabled);
    assert_int_not_equal(event_info->min, 1000);
    assert_int_not_equal(event_info->max, 5000);
    assert_int_not_equal(event_info->timeout, 10000);
    assert_int_not_equal(event_info->type, BUTTON_EVENT_TYPE_RELEASED);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Buttons.Button.Reset.Event.Press.");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(uint32_t, &trans, "Min", 1000);
    amxd_trans_set_value(uint32_t, &trans, "Max", 5000);
    amxd_trans_set_value(uint32_t, &trans, "Timeout", 10000);
    amxd_trans_set_value(cstring_t, &trans, "Type", "Released");
    assert_int_equal(amxd_trans_apply(&trans, &dm), amxd_status_ok);
    handle_events();
    assert_true(event_info->enabled);
    assert_int_equal(event_info->min, 1000);
    assert_int_equal(event_info->max, 5000);
    assert_int_equal(event_info->timeout, 10000);
    assert_int_equal(event_info->type, BUTTON_EVENT_TYPE_RELEASED);
    amxd_trans_clean(&trans);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Buttons.Button.Reset.Event.Press.");
    amxd_trans_set_value(cstring_t, &trans, "Type", "Timeout");
    assert_int_equal(amxd_trans_apply(&trans, &dm), amxd_status_ok);
    handle_events();
    assert_int_equal(event_info->type, BUTTON_EVENT_TYPE_TIMEOUT);
    amxd_trans_clean(&trans);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Buttons.Button.Reset.Event.Press.");
    amxd_trans_set_value(cstring_t, &trans, "Type", "Pressed");
    assert_int_equal(amxd_trans_apply(&trans, &dm), amxd_status_ok);
    handle_events();
    assert_int_equal(event_info->type, BUTTON_EVENT_TYPE_PRESSED);
    amxd_trans_clean(&trans);
}

void test_event_addition(UNUSED void** state) {
    amxd_object_t* button_instance = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    button_instance_t* priv_data = NULL;
    amxd_trans_t trans;
    uint8_t len_events = 0;

    assert_non_null(button_instance);
    priv_data = (button_instance_t*) button_instance->priv;
    assert_non_null(priv_data);

    len_events = amxc_llist_size(priv_data->llist_event);
    assert_int_not_equal(len_events, 0);
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Buttons.Button.Reset.Event.");
    amxd_trans_add_inst(&trans, 0, "event_new");
    assert_int_equal(amxd_trans_apply(&trans, &dm), amxd_status_ok);
    handle_events();
    assert_int_equal(amxc_llist_size(priv_data->llist_event), len_events + 1);
    amxd_trans_clean(&trans);
}

void test_event_removal(UNUSED void** state) {
    amxd_object_t* button_instance = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    button_instance_t* priv_data = NULL;
    amxd_trans_t trans;
    uint8_t len_events = 0;

    assert_non_null(button_instance);
    priv_data = (button_instance_t*) button_instance->priv;
    assert_non_null(priv_data);

    len_events = amxc_llist_size(priv_data->llist_event);
    assert_int_not_equal(len_events, 0);
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Buttons.Button.Reset.Event.");
    amxd_trans_del_inst(&trans, len_events - 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, &dm), amxd_status_ok);
    handle_events();
    assert_int_equal(amxc_llist_size(priv_data->llist_event), len_events - 1);
    amxd_trans_clean(&trans);
}
