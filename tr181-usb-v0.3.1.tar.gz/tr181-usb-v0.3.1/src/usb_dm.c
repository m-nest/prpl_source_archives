/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"
#include "usb-dm.h"
#include "usb-pwr-utils.h"

#define STR_EMPTY(x) (((x) == NULL) || ((x)[0] == '\0'))
#define USB_DM_ROOT_PATH "USB."
#define USB_DM_PORT_OBJECTS_PATH ".Port.*."

#define ME "usb"

/**
 * @brief Adds a USB device to the data model.
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _addDev(UNUSED amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    char* type = NULL;
    char* name = NULL;
    char* sysfs = NULL;
    when_null_trace(args, exit, ERROR, "Failed to get args"); // Add null check
    type = amxc_var_dyncast(cstring_t, GET_ARG(args, "type"));
    name = amxc_var_dyncast(cstring_t, GET_ARG(args, "name"));
    sysfs = amxc_var_dyncast(cstring_t, GET_ARG(args, "sysfs"));
    when_null_trace(type, exit, ERROR, "Failed to get type");
    when_null_trace(name, exit, ERROR, "Failed to get name");
    when_null_trace(sysfs, exit, ERROR, "Failed to get sysfs");

    if(strncmp(type, "dev", sizeof("dev") - 1) == 0) {
        add_device(name);
    } else if(strncmp(type, "disk", sizeof("disk") - 1) == 0) {
        add_disk(name, sysfs);
    } else if(strncmp(type, "printer", sizeof("printer") - 1) == 0) {
        add_printer(name, sysfs);
    } else if(strncmp(type, "tty", sizeof("tty") - 1) == 0) {
        add_tty(name, sysfs);
    } else {
        SAH_TRACEZ_ERROR(ME, "Unsupported Action");
        goto exit;
    }
    status = amxd_status_ok;

exit:
    free(type);
    free(name);
    free(sysfs);
    return status;
}

/**
 * @brief Deletes a USB device from the data model.
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _delDev(UNUSED amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    char* type = NULL;
    char* name = NULL;
    char* sysfs = NULL;
    when_null_trace(args, exit, ERROR, "Failed to get args"); // Add null check
    type = amxc_var_dyncast(cstring_t, GET_ARG(args, "type"));
    name = amxc_var_dyncast(cstring_t, GET_ARG(args, "name"));
    sysfs = amxc_var_dyncast(cstring_t, GET_ARG(args, "sysfs"));
    when_null_trace(type, exit, ERROR, "Failed to get type");
    when_null_trace(name, exit, ERROR, "Failed to get name");
    when_null_trace(sysfs, exit, ERROR, "Failed to get sysfs");

    if(strncmp(type, "dev", sizeof("dev") - 1) == 0) {
        delete_device(name, true);
    } else if(strncmp(type, "disk", sizeof("disk") - 1) == 0) {
        delete_disk(name, sysfs);
    } else if(strncmp(type, "printer", sizeof("printer") - 1) == 0) {
        delete_printer(name, sysfs);
    } else if(strncmp(type, "tty", sizeof("tty") - 1) == 0) {
        delete_tty(name, sysfs);
    } else if(strncmp(type, "usb_device", sizeof("usb_device") - 1) == 0) {
        // Used to unbind device
        delete_device(sysfs, true);
    } else {
        SAH_TRACEZ_ERROR(ME, "Unsupported Action");
        goto exit;
    }
    status = amxd_status_ok;

exit:
    free(type);
    free(name);
    free(sysfs);
    return status;
}

/**
 * @brief RPC to signal a USB device unbinding called from event2usb binary on system event.
 *        This is used when a device authorization changes.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _unbindDev(UNUSED amxd_object_t* object,
                         UNUSED amxd_function_t* func,
                         amxc_var_t* args,
                         UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    char* type = NULL;
    char* name = NULL;
    char* sysfs = NULL;
    when_null_trace(args, exit, ERROR, "Failed to get args"); // Add null check
    type = amxc_var_dyncast(cstring_t, GET_ARG(args, "type"));
    name = amxc_var_dyncast(cstring_t, GET_ARG(args, "name"));
    sysfs = amxc_var_dyncast(cstring_t, GET_ARG(args, "sysfs"));
    when_null_trace(type, exit, ERROR, "Failed to get type");
    when_null_trace(name, exit, ERROR, "Failed to get name");
    when_null_trace(sysfs, exit, ERROR, "Failed to get sysfs");

    if(strncmp(type, "usb_device", sizeof("usb_device") - 1) == 0) {
        delete_device(sysfs, false);
    } else {
        SAH_TRACEZ_ERROR(ME, "Unsupported Action");
        goto exit;
    }
    status = amxd_status_ok;

exit:
    free(type);
    free(name);
    free(sysfs);
    return status;
}

/**
 * @brief Ejects a USB device.
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _eject(UNUSED amxd_object_t* object,
                     UNUSED amxd_function_t* func,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    char* id = NULL;
    char* device = NULL;
    when_null_trace(args, exit, ERROR, "Failed to get args");   // Add null check
    device = amxc_var_dyncast(cstring_t, GET_ARG(args, "device"));
    when_null_trace(device, exit, ERROR, "Failed to get args"); // Add null check

    SAH_TRACEZ_NOTICE(ME, "Trying to eject: %s", device);
    amxd_object_t* dev = amxd_dm_findf(get_dm(), "%s", device);
    if(dev == NULL) {
        SAH_TRACEZ_ERROR(ME, "Device not found");
        goto exit;
    }

    id = amxd_object_get_value(cstring_t, dev, "SysfsId", NULL);
    when_null_trace(id, exit, ERROR, "Device SysfsId not found"); // Add null check

    delete_device(id, false);
    status = amxd_status_ok;
exit:
    free(id);
    free(device);
    return status;
}

/**
 * @brief Adds a USB bus to the data model.
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _addBus(UNUSED amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    char* bus_num = NULL;
    char* usb_version = NULL;
    char* usb_type = NULL;
    when_null_trace(args, exit, ERROR, "Failed to get args"); // Add null check
    bus_num = amxc_var_dyncast(cstring_t, GET_ARG(args, "busnum"));
    usb_version = amxc_var_dyncast(cstring_t, GET_ARG(args, "usbversion"));
    usb_type = amxc_var_dyncast(cstring_t, GET_ARG(args, "usbtype"));

    when_null_trace(bus_num, exit, ERROR, "Failed to get args");     // Add null check
    when_null_trace(usb_version, exit, ERROR, "Failed to get args"); // Add null check
    when_null_trace(usb_type, exit, ERROR, "Failed to get args");    // Add null check

    add_host(bus_num, usb_version, usb_type);
    status = amxd_status_ok;
exit:
    free(bus_num);
    free(usb_version);
    free(usb_type);
    return status;
}

/**
 * @brief Reset the Host Controller and apply the reset signaling to all of the Host Controller Hub downstream ports.
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _Reset(UNUSED amxd_object_t* object,
                     UNUSED amxd_function_t* func,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_ok;
    when_null_trace(args, exit, ERROR, "Failed to get args"); // Add null check
    status = reset_host(object);
    return status;
exit:
    status = amxd_status_unknown_error;
    return status;
}

/**
 * @brief Handles host reset changes.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _host_reset_changed(UNUSED const char* const sig_name,
                                  UNUSED const amxc_var_t* const data,
                                  UNUSED void* const priv) {
    amxd_status_t status = amxd_status_ok;
    when_null_trace(data, exit, ERROR, "Failed to get args"); // Add null check
    amxd_object_t* host = amxd_dm_signal_get_object(get_dm(), data);
    when_null_trace(host, exit, ERROR, "USB.USBHosts.Host. object is NULL");

    bool reset = amxd_object_get_value(bool, host, "Reset", NULL);
    if(reset) {
        status = reset_host(host);
        amxd_object_set_value(bool, host, "Reset", 0);
    }
    return status;
exit:
    status = amxd_status_unknown_error;
    return status;
}

/**
 * @brief Prints events for debugging purposes.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _print_event(const char* const sig_name,
                  const amxc_var_t* const data,
                  UNUSED void* const priv) {
    printf("Event received - %s\n", sig_name);
    if(data != NULL) {
        printf("Event data = \n");
        fflush(stdout);
        amxc_var_dump(data, STDOUT_FILENO);
    }
}

/**
 * @brief Initialize power management for a USB port object.
 *
 * This function sets up power management features for the specified USB port object.
 * @param object Pointer to the USB port AMXD object.
 */
void usb_port_pwr_init(amxd_object_t* object) {
    int rv = 0;
    const char* name = NULL;

    when_null_trace(object, exit, ERROR, "Object is NULL"); // in case event is handled after object is removed?
    when_false(object->priv == NULL, exit);

    name = GET_CHAR(amxd_object_get_param_value(object, "Name"), NULL);

    if(!STR_EMPTY(name)) {
        SAH_TRACEZ_INFO(ME, "Power management started for USB Port: '%s'", name);

        rv = dm_usb_soc_set_pwr(name);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to write PowerStatus for '%s'", name);
        }
    }

exit:
    return;
}

/**
 * @brief Initializes a USB Port instance during enumeration.
 *
 * Callback used by `amxd_object_for_all` to initialize each existing
 * USB Port instance's power management state.
 *
 * @param templ Unused template object for the traversal.
 * @param object The USB Port instance object to initialize.
 * @param priv Unused user context pointer.
 * @return int Returns `amxd_status_ok` on completion.
 */
static int dm_usb_port_init(UNUSED amxd_object_t* templ, amxd_object_t* object, UNUSED void* priv) {
    usb_port_pwr_init(object);
    return amxd_status_ok;
}

/**
 * @brief Initialize power management for all saved USB port objects in the data model.
 *
 * This function iterates through all existing USB port objects in the data model and initializes
 * their power management settings.
 */
void dm_usb_ports_pwr_init(void) {
    SAH_TRACEZ_INFO(ME, "app:start - TR-181 USB initializing power management for saved Port objects...");
    amxd_dm_t* dm = get_dm();
    amxd_object_t* usb_obj = amxd_dm_findf(dm, USB_DM_ROOT_PATH);

    amxd_object_for_all(usb_obj, USB_DM_PORT_OBJECTS_PATH, dm_usb_port_init, NULL);
}

/**
 * @brief Called when a USB port is added.
 *
 * This function is triggered when a new USB port is detected and added to the system.
 *
 * @param sig_name Name of the signal.
 * @param data Pointer to the AMXC variable containing the data.
 * @param priv Pointer to private data.
 */
void _usb_port_added(UNUSED const char* const sig_name,
                     const amxc_var_t* const data,
                     UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_dm_t* dm = get_dm();
    amxd_object_t* port_templ_obj = amxd_dm_signal_get_object(dm, data);
    amxd_object_t* port_obj = NULL;
    const char* name = GETP_CHAR(data, "parameters.Name");

    when_null_trace(port_templ_obj, exit, ERROR, "Could not get template object");
    port_obj = amxd_object_get_instance(port_templ_obj, NULL, GET_UINT32(data, "index"));
    when_null_trace(port_obj, exit, ERROR, "Could not get the added instance");

    when_not_null(port_obj->priv, exit);

    rv = dm_usb_soc_set_pwr(name);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to write PowerState for '%s'", name);
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}
