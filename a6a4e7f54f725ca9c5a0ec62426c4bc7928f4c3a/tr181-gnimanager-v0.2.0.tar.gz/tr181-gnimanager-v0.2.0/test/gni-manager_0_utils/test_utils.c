/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxut/amxut_bus.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>
#include "test_utils.h"

#include "../common/common_functions.h"
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>


int test_setup(void** state) {
    common_setup(state);
    return 0;
}

int test_teardown(void** state) {
    common_teardown(state);
    return 0;
}

/*
 * Checks if the system uptime increases
 * Allow for a range of -1s and +1s for inaccuracies
 */
void test_get_sysuptime(UNUSED void** state) {
    int initial_uptime = get_sysuptime();
    sleep(5);
    assert_in_range(get_sysuptime(), initial_uptime + 4, initial_uptime + 6);
}

void test_gni_info(UNUSED void** state) {
    int rv = -1;
    gni_info_t* gni = NULL;

    rv = gni_info_clean(&gni);
    assert_int_equal(rv, amxd_status_ok);

    rv = gni_info_new(NULL, NULL);
    assert_int_equal(rv, amxd_status_invalid_function_argument);

    rv = gni_info_new(&gni, NULL);
    assert_int_equal(rv, amxd_status_invalid_function_argument);

    rv = gni_info_new(&gni, "");
    assert_int_equal(rv, amxd_status_invalid_function_argument);

    rv = gni_info_new(NULL, "eth0");
    assert_int_equal(rv, amxd_status_invalid_function_argument);

    rv = gni_info_new(&gni, "eth0");
    assert_int_equal(rv, amxd_status_ok);
    assert_non_null(gni);

    rv = gni_info_clean(NULL);
    assert_int_equal(rv, amxd_status_ok);

    rv = gni_info_clean(&gni);
    assert_int_equal(rv, amxd_status_ok);
    assert_null(gni);
}


void test_gni_interface_status_update(UNUSED void** state) {
    int rv = -1;
    gni_info_t* temp_gni = NULL;
    char* status = NULL;
    amxd_trans_t trans;
    char input_states[7][20] = {"notpresent", "down", "dormant", "up", "Error",
        "unknown", "invalid_state"};
    char output_states[7][20] = {"NotPresent", "Down", "Dormant", "Up", "Error",
        "Unknown", "Unknown"};

    rv = gni_info_new(&temp_gni, "eth0");
    assert_int_equal(rv, amxd_status_ok);
    assert_non_null(temp_gni);

    temp_gni->object = amxd_dm_findf(amxut_bus_dm(), "GenericNetworkInterface.Interface.eth0.");
    assert_non_null(temp_gni->object);

    for(int i = 0; i < 7; i++) {
        amxd_trans_init(&trans);
        amxd_trans_select_pathf(&trans, "NetDev.Link.1.");
        amxd_trans_set_value(cstring_t, &trans, "State", input_states[i]);
        assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
        amxd_trans_clean(&trans);
        amxut_bus_handle_events();

        status = amxd_object_get_value(cstring_t, temp_gni->object, "Status", NULL);
        assert_int_equal(strcmp(output_states[i], status), 0);
        free(status);
    }
    gni_info_clean(&temp_gni);
    assert_int_equal(0, 0);
}

void test_wrong_reasons(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "GenericNetworkInterface.Interface.");
    amxd_trans_add_inst(&trans, 0, "lo2");
    amxd_trans_set_value(cstring_t, &trans, "Name", "lo2");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_invalid_value);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}
