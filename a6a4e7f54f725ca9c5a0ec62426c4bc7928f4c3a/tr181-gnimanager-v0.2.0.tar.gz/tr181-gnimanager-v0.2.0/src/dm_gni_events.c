/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dm_gni_manager.h"
#include "gni_utils.h"
#include "gni_events.h"

#define ME "gnievents"
static bool skip_validation = true;
/**
 * @brief   Callback triggered when a GNI interface is added.
 *
 * @details This function is called upon the addition of a new GNI interface.
 *          It processes the associated signal name and data, while private context is unused.
 *
 * @param   sig_name  Unused. Constant pointer to the signal name string.
 * @param   data      Pointer to the AMXC variable containing event-related data.
 * @param   priv      Unused. Pointer to user-defined private data.
 */
void _gni_instance_added(UNUSED const char* const sig_name,
                         const amxc_var_t* const data,
                         UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);

    int rv = -1;
    gni_info_t* gni = NULL;
    const char* intf_name = NULL;
    amxd_object_t* interface_templ_obj = NULL;
    amxd_object_t* interface_obj = NULL;

    amxd_dm_t* dm = gni_get_dm();

    when_null_trace(data, exit, ERROR, "Data is null");

    interface_templ_obj = amxd_dm_signal_get_object(dm, data);
    when_null_trace(interface_templ_obj, exit, ERROR, "Could not get template object");

    intf_name = GETP_CHAR(data, "parameters.Name");
    when_null_trace(intf_name, exit, ERROR, "gni interface name is NULL");

    interface_obj = amxd_object_get_instance(interface_templ_obj, NULL, GET_UINT32(data, "index"));
    when_null_trace(interface_obj, exit, ERROR, "Could not get the added instance for gni");

    when_not_null(interface_obj->priv, exit);

    rv = gni_info_new(&gni, intf_name);
    when_failed(rv, exit);

    interface_obj->priv = gni;
    gni->object = interface_obj;

    /* Currently set to GNI_INTERFACE. This type could be extended in the future
     * to support different types of lower-layer interfaces. */
    gni->type = GNI_INTERFACE;

    SAH_TRACEZ_INFO(ME, "netdev_link_added_subscription_new invoked");
    gni_subscribe_netdev_link_state(gni);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief   Callback invoked when a GNI instance is removed.
 *
 * @details This function handles the removal event for a GNI instance.
 *          It's triggered during object lifecycle management when an instance is deleted.
 *          Most parameters are unused as no additional data processing is required.
 *
 * @param   object   Pointer to the AMXD object being removed.
 * @param   param    Unused. Pointer to the AMXD parameter.
 * @param   reason   Reason for the action, typically related to instance removal.
 * @param   args     Unused. Pointer to constant AMXC variable arguments.
 * @param   retval   Unused. Pointer to AMXC variable for storing results.
 * @param   priv     Unused. Pointer to private user-defined data.
 *
 * @return  amxd_status_t  Status code indicating the success or failure of the removal operation.
 */
amxd_status_t _gni_instance_removed(amxd_object_t* object,
                                    UNUSED amxd_param_t* param,
                                    amxd_action_t reason,
                                    UNUSED const amxc_var_t* const args,
                                    UNUSED amxc_var_t* const retval,
                                    UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    gni_info_t* gni = NULL;
    amxd_status_t rv = amxd_status_invalid_function_argument;

    if(reason != action_object_destroy) {
        SAH_TRACEZ_NOTICE(ME, "Incorrect reason, expected action_object_destroy(%d) got %d",
                          action_object_destroy, reason);
        rv = amxd_status_invalid_action;
        goto exit;
    }

    when_null_trace(object, exit, ERROR, "Object is NULL");

    SAH_TRACEZ_INFO(ME, "Removing: %s", amxd_object_get_name(object, AMXD_OBJECT_NAMED));

    if(object->type != amxd_object_instance) {
        SAH_TRACEZ_INFO(ME, "Skipping template object, only remove instances");
        rv = amxd_status_ok;
        goto exit;
    }

    when_null_trace(object->priv, exit, ERROR, "Object priv is NULL");
    gni = (gni_info_t*) object->priv;

    rv = gni_info_clean(&gni);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief   Callback triggered on read event for 'lastchange' parameter.
 *
 * @details This function handles read operations for the 'lastchange' object.
 *          It checks the system time and updates the result accordingly.
 *
 * @param   object   Pointer to the AMXD object being accessed.
 * @param   param    Pointer to the AMXD parameter associated with the read event.
 * @param   reason   Reason for the action; expected value is action_param_read.
 * @param   args     Pointer to AMXC variable arguments passed to the callback.
 * @param   retval   Pointer to AMXC variable where the read result will be stored.
 * @param   priv     Pointer to user-defined private data.
 *
 * @return  amxd_status_t  Status code indicating success or failure of the operation.
 */
amxd_status_t _lastchange_on_read(amxd_object_t* const object,
                                  UNUSED amxd_param_t* const param,
                                  amxd_action_t reason,
                                  UNUSED const amxc_var_t* const args,
                                  amxc_var_t* const retval,
                                  UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_unknown_error;
    gni_info_t* gni = NULL;
    uint32_t since_change = 0;
    uint32_t uptime = 0;

    if(reason != action_param_read) {
        SAH_TRACEZ_ERROR(ME, "incorrect reason, expected action_param_read(%d) got %d", action_param_read, reason);
        rv = amxd_status_invalid_action;
        goto exit;
    }

    // retval needs to be set, in case of error lastchange will be 0
    when_null_trace(retval, exit, ERROR, "retval can not be NULL");

    amxc_var_set_uint32_t(retval, 0);

    when_null_trace(object, exit, ERROR, "object can not be NULL");

    when_null(object->priv, exit);

    gni = (gni_info_t*) object->priv;

    uptime = get_sysuptime();

    when_true_trace(uptime < gni->last_change, exit, ERROR, "not expected, uptime is smaller than the last change");

    // Calculate the time since the last change
    since_change = uptime - gni->last_change;

    when_failed_trace(amxc_var_set_uint32_t(retval, since_change), exit, ERROR, "failed to set parameter for lastchange");

    rv = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Validates the instance name of a network interface.
 *
 * This function checks whether the provided reference name is valid for a network interface.
 * It performs the following validations:
 * - Ensures the reference name is not empty.
 * - Rejects names that start with "lo"
 *
 * It also delegates to `amxd_action_param_validate` for standard parameter validation.
 *
 * @param[in] object Pointer to the AMXD object.
 * @param[in] param Pointer to the AMXD parameter being validated.
 * @param[in] reason Reason for the validation
 * @param[in] args Arguments passed for validation, expected to contain the reference name.
 * @param[out] retval Optional return value container.
 * @param[in] priv Private data passed to the validation function.
 *
 * @return amxd_status_t Returns `amxd_status_ok` if valid, or an appropriate error status.
 */
amxd_status_t _gni_instance_is_valid(amxd_object_t* object,
                                     amxd_param_t* param,
                                     amxd_action_t reason,
                                     const amxc_var_t* const args,
                                     amxc_var_t* const retval,
                                     void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    const char* ref_name = NULL;

    if(skip_validation) {
        return amxd_status_ok;
    }

    status = amxd_action_param_validate(object, param, reason, args, retval, priv);
    when_failed(status, exit);

    ref_name = amxc_var_constcast(cstring_t, args);
    when_str_empty_status(ref_name, exit, status = amxd_status_ok);

    // Check if ref_name starts with "lo" and is followed by a number between 1 and 99
    if(strncmp(ref_name, "lo", 2) == 0) {
        if(strlen(ref_name) == 2) {
            status = amxd_status_invalid_value;
            goto exit;
        }
        const char* num_part = ref_name + 2;
        char* endptr = NULL;
        long num = strtol(num_part, &endptr, 10);

        if((endptr != num_part) && (*endptr == '\0') && ((num >= 1) && (num <= 99))) {
            status = amxd_status_invalid_value;
            goto exit;
        }
    }
    status = check_netmodel_netdev_entry(ref_name);

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}


/**
 * @brief Validates the presence of a NetDev entry and checks for conflicts in NetModel.
 *
 * This function ensures that a network device with the given name (`ref_name`)
 * exists in the `NetDev` data model. If the device is found, it further checks
 * whether a corresponding interface already exists in the `NetModel` data model
 * to prevent configuration conflicts.
 *
 * The NetDev interface **must be present** for the configuration to succeed.
 * If the NetDev entry is missing or a matching NetModel interface already exists,
 * the function returns an error status.
 *
 * @param[in] ref_name The name of the network device to validate.
 *
 * @return amxd_status_t
 * - `amxd_status_ok` if the NetDev entry exists and no NetModel conflict is found.
 * - `amxd_status_invalid_value` if the NetDev entry is missing or a conflict is detected.
 */
amxd_status_t check_netmodel_netdev_entry(const char* ref_name) {
    SAH_TRACEZ_IN(ME);
    int rv = AMXB_ERROR_UNKNOWN;
    const char* new = NULL;
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t path;
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t data;

    ctx = amxb_be_who_has("NetDev.");

    amxc_string_init(&path, 0);
    amxc_var_init(&data);
    when_null_trace(ctx, exit, WARNING, "ctx not known");

    if(ctx != NULL) {
        amxc_string_setf(&path, "NetDev.Link.[Name==\"%s\"]", ref_name);
        rv = amxb_get(ctx, amxc_string_get(&path, 0), 0, &data, 1);
        if(rv != AMXB_STATUS_OK) {
            SAH_TRACEZ_ERROR(ME, "amxb_get() failed, not found");
        } else {
            new = GETP_CHAR(&data, "0.0.Name");
        }
    }

    if(new == NULL) {
        SAH_TRACEZ_ERROR(ME, "netdev entry is not found");
        status = amxd_status_invalid_value;
        goto exit;
    }

    ctx = NULL;
    ctx = amxb_be_who_has("NetModel.");

    if(ctx == NULL) {
        SAH_TRACEZ_WARNING(ME, "ctx not found");
        goto exit;
    }

    if(ctx != NULL) {
        amxc_string_setf(&path, "NetModel.Intf.[NetDevName==\"%s\"]", ref_name);
        rv = amxb_get(ctx, amxc_string_get(&path, 0), 0, &data, 1);
        if(rv != AMXB_STATUS_OK) {
            SAH_TRACEZ_ERROR(ME, "NetModel not found");
            status = amxd_status_invalid_value;
            goto exit;
        } else {
            new = GETP_CHAR(&data, "0.0.NetDevName");
        }
    }

    if(new != NULL) {
        SAH_TRACEZ_ERROR(ME, "interface with similar name is existing");
        status = amxd_status_invalid_value;
        goto exit;
    }

    status = amxd_status_ok;

exit:
    amxc_string_clean(&path);
    amxc_var_clean(&data);
    SAH_TRACEZ_OUT(ME);
    return status;
}


/**
 * @brief Initializes application state on signal reception.
 *
 * This function is called when a specific signal is received. It resets
 * the `skip_validation` flag to false, indicating that validation should
 * not be skipped. All parameters are marked as UNUSED since they are not
 * used in this implementation.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data     Associated signal data (unused).
 * @param[in] priv     Private user data (unused).
 */
void _app_start(UNUSED const char* const sig_name,
                UNUSED const amxc_var_t* const data,
                UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    skip_validation = false;
    SAH_TRACEZ_OUT(ME);
}
