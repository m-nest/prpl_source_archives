/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __MOCK_AMX_H__
#define __MOCK_AMX_H__

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxp/amxp_timer.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>

typedef struct _amxp_state {
    amxp_slot_fn_t sub_cb;
    amxb_bus_ctx_t* bus;
    amxp_slot_fn_t cust_cb;
    amxp_slot_fn_t plug_init_cb;
    amxp_slot_fn_t plug_cb;
} amxb_state_t;

void amxb_trigger_subscribe_cb(amxc_var_t* data);
void amxb_trigger_custom_cb(amxc_var_t* data, void* priv);
void amxb_trigger_plugin_init_cb(void* priv);
void amxb_trigger_plugin_cb(void* priv);

// wrapped function
int __wrap_amxp_timer_new(amxp_timer_t** timer, amxp_timer_cb_t cb, void* priv);
void __wrap_amxp_timer_delete(amxp_timer_t** timer);
int __wrap_amxp_timer_start(amxp_timer_t* timer, unsigned int timeout_msec);
int __wrap_amxp_timer_stop(amxp_timer_t* timer);
amxp_timer_state_t __wrap_amxp_timer_get_state(amxp_timer_t* timer);
unsigned int __wrap_amxp_timer_remaining_time(amxp_timer_t* timer);

int __wrap_amxp_subproc_new(amxp_subproc_t** subproc);
int __wrap_amxp_subproc_delete(amxp_subproc_t** subproc);
int __wrap_amxp_subproc_start(amxp_subproc_t* const subproc, char* cmd, ...);
bool __wrap_amxp_subproc_is_running(const amxp_subproc_t* const subproc);
int __wrap_amxp_subproc_wait(amxp_subproc_t* subproc, int timeout_msec);
int __wrap_amxp_subproc_kill(const amxp_subproc_t* const subproc, const int sig);

int __wrap_amxb_call(amxb_bus_ctx_t* const bus_ctx, const char* object, const char* method, amxc_var_t* args, amxc_var_t* ret, int timeout);
int __real_amxb_call(amxb_bus_ctx_t* const bus_ctx, const char* object, const char* method, amxc_var_t* args, amxc_var_t* ret, int timeout);

amxb_bus_ctx_t* __wrap_amxb_be_who_has(const char* object_path);

int __wrap_amxb_subscribe(amxb_bus_ctx_t* const bus_ctx,
                          const char* object,
                          const char* expression,
                          amxp_slot_fn_t slot_cb,
                          void* priv);

int __wrap_amxb_unsubscribe(amxb_bus_ctx_t* const bus_ctx,
                            const char* object,
                            amxp_slot_fn_t slot_cb,
                            void* priv);

int __wrap_amxp_slot_connect(amxp_signal_mngr_t* const sig_mngr,
                             const char* const sig_name,
                             const char* const expression,
                             amxp_slot_fn_t fn,
                             void* const priv);

int __wrap_amxp_slot_connect_filtered(amxp_signal_mngr_t* const sig_mngr,
                                      const char* const sig_reg_exp,
                                      const char* const expression,
                                      amxp_slot_fn_t fn,
                                      void* const priv);

// mock function
void set_amxb_bus_obj_off();
void set_amxb_bus_obj_on();
void mock_amxp_trigger_timer(amxp_timer_t* timer);
void mock_amxb_init(void);

#endif // __MOCK_AMX_H__
