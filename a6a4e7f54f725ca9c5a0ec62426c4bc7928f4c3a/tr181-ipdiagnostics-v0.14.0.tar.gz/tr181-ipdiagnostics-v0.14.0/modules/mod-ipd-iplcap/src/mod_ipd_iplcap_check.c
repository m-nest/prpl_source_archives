/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <regex.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_types.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_ipd_iplcap.h"
#include "mod_ipd_iplcap_common.h"
#include "mod_ipd_iplcap_status.h"
#include "iplcap.h"
#include "ip_diagnostics.h"
#include "mod_ipd_common.h"

// module trace zone
#define ME "mod-iplcap-check"

/**
 * @brief Structure for mapping JSON fields to data model keys and types.
 *
 * This structure defines a mapping between a JSON field (or path) and a corresponding
 * data model key, along with the expected variant type and an optional sub-mapping
 * for nested or list fields. It is used to facilitate the conversion of JSON output
 * from IPLCAP tests into the internal data model representation.
 */
struct iplcap_field_mapping_t;

/**
 * @struct iplcap_field_mapping_t
 * @brief Field mapping entry for JSON-to-data model conversion.
 *
 * @var iplcap_field_mapping_t::json_path
 *   The path to the field in the JSON object (may be a nested path, e.g., "Output.Summary.LossRatioSummary").
 * @var iplcap_field_mapping_t::dm_key
 *   The key in the data model to which the JSON value should be mapped.
 * @var iplcap_field_mapping_t::var_type
 *   The variant type (AMXC_VAR_ID_*) expected for this field.
 * @var iplcap_field_mapping_t::sub_mapping
 *   Pointer to a sub-mapping table for nested or list fields, or NULL if not applicable.
 */
typedef struct iplcap_field_mapping_t {
    const char* json_path;                              /**< JSON field path */
    const char* dm_key;                                 /**< Data model key */
    uint32_t var_type;                                  /**< Variant type (AMXC_VAR_ID_*) */
    const struct iplcap_field_mapping_t* sub_mapping;   /**< Sub-mapping for nested/list fields */
} iplcap_field_mapping_t;

/**
 *@brief Field mapping table for ModalResult JSON to data model conversions
 */
static const iplcap_field_mapping_t iplcap_field_mappings_modal_result[] = {
    {IPLCAP_JSON_KEY_MODAL_TIME_MAX, IPLCAP_RET_KEY_MODAL_TIME_MAX, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_KEY_MODAL_LOSS_RATIO, IPLCAP_RET_KEY_MODAL_LOSS_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_REORD_RATIO, IPLCAP_RET_KEY_MODAL_REORD_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_REPL_RATIO, IPLCAP_RET_KEY_MODAL_REPL_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_PDV_RANGE, IPLCAP_RET_KEY_MODAL_PDV_RANGE, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_RTT_RANGE, IPLCAP_RET_KEY_MODAL_RTT_RANGE, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_MAX_IP_CAP, IPLCAP_RET_KEY_MODAL_MAX_IP_CAP, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_ETH_MBPS, IPLCAP_RET_KEY_MODAL_ETH_MBPS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_MAX_ETH_NO_FCS, IPLCAP_RET_KEY_MODAL_MAX_ETH_NO_FCS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_MAX_ETH_WITH_FCS, IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_FCS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_MAX_ETH_WITH_VLAN, IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_VLAN, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_MODAL_MIN_OWD, IPLCAP_RET_KEY_MODAL_MIN_OWD, AMXC_VAR_ID_DOUBLE, NULL},
    { NULL, NULL, 0, NULL}
};

/**
 *@brief Comprehensive field mapping table for IncrementalResult JSON to data model conversions
 */
static const iplcap_field_mapping_t iplcap_field_mappings_incremental_result[] = {
    {IPLCAP_JSON_KEY_INC_TIME, IPLCAP_RET_KEY_INC_TIME, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_KEY_INC_LOSS_RATIO, IPLCAP_RET_KEY_INC_LOSS_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_REORD_RATIO, IPLCAP_RET_KEY_INC_REORD_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_REPL_RATIO, IPLCAP_RET_KEY_INC_REPL_RATIO, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_PDV_RANGE, IPLCAP_RET_KEY_INC_PDV_RANGE, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_RTT_RANGE, IPLCAP_RET_KEY_INC_RTT_RANGE, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_IP_CAP, IPLCAP_RET_KEY_INC_IP_CAP, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_ETH_MBPS, IPLCAP_RET_KEY_INC_ETH_MBPS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_KEY_INC_MIN_OWD, IPLCAP_RET_KEY_INC_MIN_OWD, AMXC_VAR_ID_DOUBLE, NULL},
    {NULL, NULL, 0, NULL}
};

/**
 *@brief Comprehensive field mapping table for all JSON to data model conversions
 */
static const iplcap_field_mapping_t iplcap_field_mappings_all[] = {
    // Common information mappings
    {IPLCAP_JSON_PATH_MAX_CONN, IPLCAP_RET_KEY_MAX_CONN, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_MAX_INC_RES, IPLCAP_RET_KEY_MAX_INC_RES, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_SUPP_SW_VER, IPLCAP_RET_KEY_SUPP_SW_VER, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_SUPP_CTRL_VER, IPLCAP_RET_KEY_SUPP_CTRL_VER, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_SUPP_METRICS, IPLCAP_RET_KEY_SUPP_METRICS, AMXC_VAR_ID_CSTRING, NULL},

    // Input section mappings
    {IPLCAP_JSON_PATH_ROLE, IPLCAP_RET_KEY_ROLE, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_JUMBO_FRAMES, IPLCAP_RET_KEY_JUMBO_FRAMES, AMXC_VAR_ID_BOOL, NULL},
    {IPLCAP_JSON_PATH_TEST_TYPE, IPLCAP_RET_KEY_TEST_TYPE, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_DSCP, IPLCAP_RET_KEY_DSCP, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_IPDV_ENABLE, IPLCAP_RET_KEY_IPDV_ENABLE, AMXC_VAR_ID_BOOL, NULL},
    {IPLCAP_JSON_PATH_IPRR_ENABLE, IPLCAP_RET_KEY_IPRR_ENABLE, AMXC_VAR_ID_BOOL, NULL},
    {IPLCAP_JSON_PATH_RIPR_ENABLE, IPLCAP_RET_KEY_RIPR_ENABLE, AMXC_VAR_ID_BOOL, NULL},
    {IPLCAP_JSON_PATH_PREAMBLE_DUR, IPLCAP_RET_KEY_PREAMBLE_DUR, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_START_RATE_INDEX, IPLCAP_RET_KEY_START_RATE_INDEX, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_NUM_SUB_INTERVALS, IPLCAP_RET_KEY_NUM_SUB_INTERVALS, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_NUM_FIRST_MODE, IPLCAP_RET_KEY_NUM_FIRST_MODE, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_SUB_INTERVAL, IPLCAP_RET_KEY_SUB_INTERVAL, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_FEEDBACK_INTERVAL, IPLCAP_RET_KEY_FEEDBACK_INTERVAL, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TIMEOUT_NO_TEST_TRAFFIC, IPLCAP_RET_KEY_TIMEOUT_NO_TEST_TRAFFIC, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TIMEOUT_NO_STATUS_MESSAGE, IPLCAP_RET_KEY_TIMEOUT_NO_STATUS_MESSAGE, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TMAX, IPLCAP_RET_KEY_TMAX, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TMAX_RTT, IPLCAP_RET_KEY_TMAX_RTT, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TIMESTAMP_RES, IPLCAP_RET_KEY_TIMESTAMP_RES, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_SEQ_ERR_THRESH, IPLCAP_RET_KEY_SEQ_ERR_THRESH, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_REORD_DUP_IGNORE, IPLCAP_RET_KEY_REORD_DUP_IGNORE, AMXC_VAR_ID_BOOL, NULL},
    {IPLCAP_JSON_PATH_LOWER_THRESH, IPLCAP_RET_KEY_LOWER_THRESH, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_UPPER_THRESH, IPLCAP_RET_KEY_UPPER_THRESH, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_HIGH_SPEED_DELTA, IPLCAP_RET_KEY_HIGH_SPEED_DELTA, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_SLOW_ADJ_THRESH, IPLCAP_RET_KEY_SLOW_ADJ_THRESH, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_HSPEED_THRESH, IPLCAP_RET_KEY_HSPEED_THRESH, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_RATE_ADJ_ALGO, IPLCAP_RET_KEY_RATE_ADJ_ALGO, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_UDP_PAYLOAD_CONTENT, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_UDP_PAYLOAD_MIN, IPLCAP_RET_KEY_UDP_PAYLOAD_MIN, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_UDP_PAYLOAD_MAX, IPLCAP_RET_KEY_UDP_PAYLOAD_MAX, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_PRTCLV, IPLCAP_RET_KEY_PRTCLV, AMXC_VAR_ID_CSTRING, NULL},

    // Output basic section mappings
    {IPLCAP_JSON_PATH_BOM_TIME, IPLCAP_RET_KEY_BOM_TIME, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_EOM_TIME, IPLCAP_RET_KEY_EOM_TIME, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_TMAX_USED, IPLCAP_RET_KEY_TMAX_USED, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TEST_INTERVAL, IPLCAP_RET_KEY_TEST_INTERVAL, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TMAX_RTT_USED, IPLCAP_RET_KEY_TMAX_RTT_USED, AMXC_VAR_ID_UINT32, NULL},
    {IPLCAP_JSON_PATH_TS_RES_USED, IPLCAP_RET_KEY_TS_RES_USED, AMXC_VAR_ID_UINT32, NULL},

    // Summary section mappings
    {IPLCAP_JSON_PATH_LOSS_RATIO_SUM, IPLCAP_RET_KEY_LOSS_RATIO_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_REORD_RATIO_SUM, IPLCAP_RET_KEY_REORD_RATIO_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_REPL_RATIO_SUM, IPLCAP_RET_KEY_REPL_RATIO_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_PDV_RANGE_SUM, IPLCAP_RET_KEY_PDV_RANGE_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_RTT_RANGE_SUM, IPLCAP_RET_KEY_RTT_RANGE_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_IP_CAP_SUMMARY, IPLCAP_RET_KEY_IP_CAP_SUMMARY, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_ETH_MBPS_SUM, IPLCAP_RET_KEY_ETH_MBPS_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MIN_OWD_SUM, IPLCAP_RET_KEY_MIN_OWD_SUM, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MIN_RTT_SUM, IPLCAP_RET_KEY_MIN_RTT_SUM, AMXC_VAR_ID_DOUBLE, NULL},

    // AtMax section mappings
    {IPLCAP_JSON_PATH_TIME_OF_MAX, IPLCAP_RET_KEY_TIME_OF_MAX, AMXC_VAR_ID_CSTRING, NULL},
    {IPLCAP_JSON_PATH_LOSS_RATIO_MAX, IPLCAP_RET_KEY_LOSS_RATIO_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_REORD_RATIO_MAX, IPLCAP_RET_KEY_REORD_RATIO_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_REPL_RATIO_MAX, IPLCAP_RET_KEY_REPL_RATIO_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_RTT_MAX_MAX, IPLCAP_RET_KEY_RTT_MAX_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_RTT_MIN_MAX, IPLCAP_RET_KEY_RTT_MIN_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_PDV_RANGE_MAX, IPLCAP_RET_KEY_PDV_RANGE_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_RTT_RANGE_MAX, IPLCAP_RET_KEY_RTT_RANGE_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MAX_IP_CAP, IPLCAP_RET_KEY_MAX_IP_CAP, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_ETH_MBPS_MAX, IPLCAP_RET_KEY_ETH_MBPS_MAX, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MAX_ETH_NO_FCS, IPLCAP_RET_KEY_MAX_ETH_NO_FCS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MAX_ETH_WITH_FCS, IPLCAP_RET_KEY_MAX_ETH_WITH_FCS, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MAX_ETH_WITH_VLAN, IPLCAP_RET_KEY_MAX_ETH_WITH_VLAN, AMXC_VAR_ID_DOUBLE, NULL},
    {IPLCAP_JSON_PATH_MIN_OWD_MAX, IPLCAP_RET_KEY_MIN_OWD_MAX, AMXC_VAR_ID_DOUBLE, NULL},

    // Incremental result mappings
    {IPLCAP_JSON_PATH_INC, IPLCAP_RET_KEY_INC, AMXC_VAR_ID_LIST, iplcap_field_mappings_incremental_result},

    // Modal result mappings
    {IPLCAP_JSON_PATH_MODAL, IPLCAP_RET_KEY_MODAL, AMXC_VAR_ID_LIST, iplcap_field_mappings_modal_result},
    {NULL, NULL, 0, NULL}
};

/**
 *@brief Static mapping table for error patterns to TR-181 status codes
 */
static const iplcap_error_pattern_t error_patterns[] = {
    // Error_CannotResolveHostName - Network resolution failures
    { "^ERROR: Server hostname or IP address required when client", iplcap_test_error_err_cannot_resolve_host_name },
    { "^ERROR: Invalid format for IPv6 address with port number", iplcap_test_error_err_cannot_resolve_host_name },
    { "^ERROR: Specified IP address does not match address family", iplcap_test_error_err_cannot_resolve_host_name },

    // Error_NoRouteToHost - Network connectivity and routing issues
    { "^ERROR: Socket mgmt, action [0-9]+ failure for [^:]+:[0-9]+", iplcap_test_error_err_no_route_to_host },
    { "^SOCKET ERROR: .+ \\([^:]+:[0-9]+\\)", iplcap_test_error_err_no_route_to_host },
    { "^BIND ERROR: .+ \\([^:]+:[0-9]+\\)", iplcap_test_error_err_no_route_to_host },
    { "^\\[[0-9]+\\]CONNECT ERROR: .+", iplcap_test_error_err_no_route_to_host },
    { "^ERROR: Connection allocation failure on server", iplcap_test_error_err_no_route_to_host },
    { "^ERROR: Max connections exceeded", iplcap_test_error_err_no_route_to_host },
    { "^ERROR: Minimum required connections \\([0-9]+\\) unavailable", iplcap_test_error_err_no_route_to_host },
    { "^ERROR: Multi-connection parameters rejected by server", iplcap_test_error_err_no_route_to_host },

    // Error_InitConnectionFailed - Connection setup and initialization failures
    { "^ERROR: Unable to open epoll file descriptor", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Unable to modify standard I/O FDs", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Unable to install exit signal handler", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: fork\\(\\) failed", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Memory allocation\\(s\\) failed", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Sending rate table build failure \\(overrun\\)", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Invalid multi-connection parameters \\([0-9]+,[0-9]+\\) in setup request from", iplcap_test_error_err_init_connection_failed },
    { "^ERROR: Client protocol version \\([0-9]+\\) not accepted by server \\([0-9]+\\)", iplcap_test_error_err_init_connection_failed },

    // Error_NoResponse - Server communication and response issues
    { "^ERROR: Unexpected CRSP \\([0-9]+\\) in setup response from server", iplcap_test_error_err_no_response },
    { "^ERROR: Unexpected CRSP \\([0-9]+\\) in test activation response from server [^:]+:[0-9]+", iplcap_test_error_err_no_response },
    { "^ERROR: Requested test parameter\\(s\\) rejected by server [^:]+:[0-9]+", iplcap_test_error_err_no_response },
    { "^ERROR: Invalid version \\([0-9]+\\) in setup request from", iplcap_test_error_err_no_response },
    { "^ERROR: Invalid jumbo datagram option in setup request from", iplcap_test_error_err_no_response },
    { "^ERROR: Invalid traditional MTU option in setup request from", iplcap_test_error_err_no_response },
    { "^ERROR: Required bandwidth not specified in setup request from", iplcap_test_error_err_no_response },
    { "^ERROR: Server count exceeds maximum \\([0-9]+\\)", iplcap_test_error_err_no_response },

    // Error_PasswordRequestFailed - Authentication key and credential issues
    { "^ERROR: Authentication key exceeds [0-9]+ characters", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Authentication key ID requires authentication key or key file", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Authentication key ID \\([0-9]+\\) not found in key file", iplcap_test_error_err_password_request_failed },
    { "^ERROR: No authentication keys found in key file", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Built without authentication functionality", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Authentication key and key file are mutually exclusive", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry has insufficient field count \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry has invalid numeric ID \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry has out-of-range ID \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry has duplicate ID \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry has oversized key \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },
    { "^ERROR: Key file entry count exceeds maximum \\(line [0-9]+\\)", iplcap_test_error_err_password_request_failed },

    // Error_LoginFailed - Authentication verification failures
    { "^ERROR: Authentication verification failed at server", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication failure of setup request from", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication time invalid in setup request from", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication time outside time window of server", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication not configured on server", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication required by server", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication method does not match server", iplcap_test_error_err_login_failed },
    { "^ERROR: Unexpected authentication in setup request from", iplcap_test_error_err_login_failed },
    { "^ERROR: Authentication missing in setup request from", iplcap_test_error_err_login_failed },
    { "^ERROR: Invalid authentication method in setup request from", iplcap_test_error_err_login_failed },

    // Error_RejectedByRemote - Server-side rejections and policy violations
    { "^ERROR: Required max bandwidth exceeds available capacity on server", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Max bandwidth option required by server", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Capacity exceeded \\([0-9]+\\.[0-9]+\\) by required bandwidth \\([0-9]+\\) in setup request from", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Client jumbo datagram size option does not match server", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Client traditional MTU option does not match server", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Server only allows one local bind address or hostname", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: One test execution only valid when server", iplcap_test_error_err_rejected_by_remote },
    { "^ERROR: Log file only valid when server", iplcap_test_error_err_rejected_by_remote },

    // Error_IncorrectSize - Parameter validation and size-related errors
    { "^ERROR: Parameter <[0-9]+> out-of-range \\([0-9]+-[0-9]+\\)", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Low delay variation threshold > upper delay variation threshold", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Sub-interval period is greater than test interval time", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Minimum connection count > maximum connection count", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Bimodal count must be less than total sub-intervals", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Output file name length exceeds maximum", iplcap_test_error_err_incorrect_size },
    { "^ERROR: GSO incompatible with IP fragmentation \\(disable jumbo sizes or increase MTU\\)", iplcap_test_error_err_incorrect_size },
    { "^ERROR: Maximum from local interface requires local interface option", iplcap_test_error_err_incorrect_size },

    // Error_Timeout - Timing and timeout-related errors
    { "^ERROR: Clock resolution \\([0-9]+ ns\\) out of range \\[see compile-time option DISABLE_INT_TIMER\\]", iplcap_test_error_err_timeout },
    { "^CLOCK_GETRES ERROR: .+", iplcap_test_error_err_timeout },
    { "^SIGALRM ERROR: .+", iplcap_test_error_err_timeout },
    { "^ITIMER ERROR: .+", iplcap_test_error_err_timeout },
    { "^ERROR: Invalid epoll_wait user data [0-9]+", iplcap_test_error_err_timeout },
    { "^WARNING: Timeout awaiting response from server [^:]+:[0-9]+", iplcap_test_error_err_timeout },
    { "^\\[[0-9]+\\]ERROR: Invalid fd \\([0-9]+\\) from epoll_wait", iplcap_test_error_err_timeout },

    // Error_Internal - Internal system and configuration errors
    { "^ERROR: [^ ]+ and [^ ]+ options are mutually exclusive", iplcap_test_error_err_internal },
    { "^ERROR: Multi-connection count only set by client", iplcap_test_error_err_internal },
    { "^ERROR: Ouput format options only available to client", iplcap_test_error_err_internal },
    { "^ERROR: Execution as daemon only valid when server", iplcap_test_error_err_internal },
    { "^ERROR: Log file only supported when executing as daemon", iplcap_test_error_err_internal },
    { "^ERROR: Debug only available when used with verbose", iplcap_test_error_err_internal },
    { "^ERROR: Verbose not available with JSON output format option", iplcap_test_error_err_internal },
    { "^ERROR: '[^']+' is not a valid output format", iplcap_test_error_err_internal },
    { "^ERROR: '[^']+' is not a valid rate adjustment algorithm", iplcap_test_error_err_internal },
    { "^ERROR: Invalid number of rate adjustment algorithm identifiers", iplcap_test_error_err_internal },
    { "^ERROR: Null pointer for rate adjustment algorithm identifier", iplcap_test_error_err_internal },
    { "^ERROR: Output file not defined", iplcap_test_error_err_internal },
    { "^ERROR: Maximum multi-connection count must be >= server count", iplcap_test_error_err_internal },

    // Error_Other - File I/O, socket configuration, and miscellaneous errors
    { "^OPEN ERROR: .+ \\(.+\\)", iplcap_test_error_err_other },
    { "^FOPEN ERROR: <[^>]+> .+", iplcap_test_error_err_other },
    { "^FSTAT ERROR: <[^>]+> .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]F_SETFL ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]EPOLL_CTL ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]SET SO_REUSEADDR ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]SET SO_SNDBUF ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]SET SO_RCVBUF ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]GET SO_SNDBUF ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]GET SO_RCVBUF ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]GETSOCKNAME ERROR: .+", iplcap_test_error_err_other },
    { "^\\[[0-9]+\\]GETPEERNAME ERROR: .+", iplcap_test_error_err_other },
    { "^IPV6_V6ONLY ERROR: .+", iplcap_test_error_err_other },
    { "^ERROR: Failure setting IP ToS/TClass \\([0-9]+\\) .+", iplcap_test_error_err_other }
};

/**
 * @brief Number of error patterns in the error_patterns array
 */
static const size_t error_patterns_count = sizeof(error_patterns) / sizeof(error_patterns[0]);

/**
 * @brief Checks if an error message matches a regular expression pattern.
 *
 * @details
 * This function takes an error message string (as an amxc_string_t*) and a regular expression pattern,
 * and checks if the error message matches the given pattern using POSIX regular expressions.
 * It returns 1 if the pattern matches, 0 if there is no match, and -1 if there is a regex compilation
 * or input error (such as a NULL argument or failed regex compilation).
 *
 * @param[in]  error_string  The error message string to search in (as amxc_string_t*).
 * @param[in]  regexp_str    The regular expression pattern to match against.
 *
 * @return 1 if the pattern matches the error string,
 *         0 if there is no match,
 *        -1 if there is a regex compilation or input error.
 */
static int iplcap_error_pattern_match(amxc_string_t* error_string, const char* regexp_str) {
    if((error_string == NULL) || (regexp_str == NULL)) {
        return -1;
    }

    const char* error_text = amxc_string_get(error_string, 0);
    if(error_text == NULL) {
        return -1;
    }

    regex_t regexp;
    int rv = regcomp(&regexp, regexp_str, REG_EXTENDED | REG_NOSUB);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Regex compilation failed for pattern: %s", regexp_str);
        return -1;
    }

    int match = (regexec(&regexp, error_text, 0, NULL, 0) == 0) ? 1 : 0;
    regfree(&regexp);

    return match;
}

iplcap_test_status_t iplcap_map_error_message_to_status(const char* error_msg) {
    if(error_msg == NULL) {
        return iplcap_test_error_err_other;
    }

    amxc_string_t error_string;
    amxc_string_init(&error_string, strlen(error_msg) + 1);
    amxc_string_set(&error_string, error_msg);

    for(size_t i = 0; i < error_patterns_count; i++) {
        int match = iplcap_error_pattern_match(&error_string, error_patterns[i].pattern);
        if(match == 1) {
            amxc_string_clean(&error_string);
            return error_patterns[i].status;
        }
        if(match == -1) { // regex error
            SAH_TRACEZ_ERROR(ME, "Invalid regex: %s", error_patterns[i].pattern);
            break;
        }
    }

    amxc_string_clean(&error_string);
    return iplcap_test_error_err_other;
}

/**
 * @brief Parses JSON fields into a variant using a comprehensive mapping table.
 *
 * @details
 * This function parses JSON fields into a variant using a comprehensive mapping table.
 * It supports nested fields and lists, and handles different variant types.
 *
 * @param[in]  json_data      JSON data to parse (owned by caller).
 * @param[in]  ret            Output variant to store results (owned by caller).
 * @param[in]  field_mappings Field mapping table to use for parsing.
 *
 * @return 0 on success, -1 on failure.
 */
static int iplcap_parse_fields_unified(amxc_var_t* json_data, amxc_var_t* ret, const iplcap_field_mapping_t* field_mappings) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxc_var_t* value = NULL;
    amxc_var_t* source_section = NULL;
    const char* json_key = NULL;
    amxc_var_t* var_llist_json = NULL;
    amxc_var_t* var_llist_ret = NULL;

    when_null_trace(json_data, exit, ERROR, "JSON data parameter is null");
    when_null_trace(ret, exit, ERROR, "Return variant parameter is null");
    when_null_trace(field_mappings, exit, ERROR, "Field mappings parameter is null");

    for(const iplcap_field_mapping_t* field_mappings_item = field_mappings;
        field_mappings_item->json_path != NULL;
        field_mappings_item++) {
        // If the field type is a list, parse the sub-mapping
        if((field_mappings_item->var_type == AMXC_VAR_ID_LIST) &&
           (field_mappings_item->sub_mapping != NULL)) {
            int index = 1;
            char index_str[12] = {0};

            // Get the list JSON section
            var_llist_json = GETP_ARG(json_data, field_mappings_item->json_path);
            when_null_trace(var_llist_json, exit, ERROR,
                            "List JSON section is null for key: %s",
                            field_mappings_item->json_path);

            // Get the list return section
            var_llist_ret = amxc_var_get_key(ret, field_mappings_item->dm_key, AMXC_VAR_FLAG_DEFAULT);
            if(var_llist_ret == NULL) {
                var_llist_ret = amxc_var_add_key(amxc_htable_t, ret, field_mappings_item->dm_key, NULL);
            }

            // Parse the sub-mapping for each item in the list
            amxc_var_for_each(var_llist_json_item, var_llist_json) {
                snprintf(index_str, sizeof(index_str), "%d", index);
                amxc_var_t* var_llist_ret_item = amxc_var_add_key(amxc_htable_t,
                                                                  var_llist_ret,
                                                                  index_str,
                                                                  NULL);
                // Parse the sub-mapping for the item
                rv = iplcap_parse_fields_unified(var_llist_json_item,
                                                 var_llist_ret_item,
                                                 field_mappings_item->sub_mapping);
                when_failed_trace(rv, exit, ERROR,
                                  "Failed to parse fields for key: %s",
                                  field_mappings_item->json_path);
                index++;
            }
        } else {
            when_true_trace(field_mappings_item->sub_mapping != NULL, exit, ERROR, "Sub-mapping in field mapping is not null when not a list");
            // If the field type is not a list, parse the field
            // Extract JSON key from full path (e.g., "Input.Role" -> "Role")
            json_key = strrchr(field_mappings_item->json_path, '.');
            if(json_key == NULL) {
                json_key = field_mappings_item->json_path;
            } else {
                json_key++; // Skip the '.'
            }

            // Navigate to the source section in JSON using dynamic path navigation
            // For paths like "Output.Summary.LossRatioSummary", we need to get the parent section "Output.Summary"
            // and then use the json_key "LossRatioSummary" to get the specific field
            if(strcmp(json_key, field_mappings_item->json_path) == 0) {
                // Root level field (no dots in path)
                source_section = json_data;
            } else {
                // Nested field - get the parent section by removing the last key from the path
                char parent_path[256];
                const char* last_dot = strrchr(field_mappings_item->json_path, '.');
                if(last_dot != NULL) {
                    size_t parent_len = last_dot - field_mappings_item->json_path;
                    if(parent_len < sizeof(parent_path)) {
                        strncpy(parent_path, field_mappings_item->json_path, parent_len);
                        parent_path[parent_len] = '\0';
                        source_section = GETP_ARG(json_data, parent_path);
                    } else {
                        SAH_TRACEZ_ERROR(ME, "Path too long: %s", field_mappings_item->json_path);
                        continue;
                    }
                } else {
                    source_section = json_data;
                }
            }

            when_null_trace(source_section, exit, ERROR, "Source section is null for key: %s", field_mappings_item->json_path);

            // Get or create the target key in ret
            value = amxc_var_get_key(ret, field_mappings_item->dm_key, AMXC_VAR_FLAG_DEFAULT);
            if(value == NULL) {
                // Create the key with the appropriate type
                switch(field_mappings_item->var_type) {
                case AMXC_VAR_ID_CSTRING:
                    value = amxc_var_add_key(cstring_t, ret, field_mappings_item->dm_key, "");
                    break;
                case AMXC_VAR_ID_UINT32:
                    value = amxc_var_add_key(uint32_t, ret, field_mappings_item->dm_key, 0);
                    break;
                case AMXC_VAR_ID_BOOL:
                    value = amxc_var_add_key(bool, ret, field_mappings_item->dm_key, false);
                    break;
                case AMXC_VAR_ID_DOUBLE:
                    value = amxc_var_add_key(double, ret, field_mappings_item->dm_key, 0.0);
                    break;
                default:
                    SAH_TRACEZ_WARNING(ME, "Unsupported variant type: %d", field_mappings_item->var_type);
                    continue;
                }
            }

            // Parse based on variant type
            switch(field_mappings_item->var_type) {
            case AMXC_VAR_ID_CSTRING:
                amxc_var_set(cstring_t, value, GETP_CHAR(source_section, json_key));
                break;
            case AMXC_VAR_ID_UINT32:
                amxc_var_set(uint32_t, value, GETP_UINT32(source_section, json_key));
                break;
            case AMXC_VAR_ID_BOOL:
                amxc_var_set(bool, value, GETP_BOOL(source_section, json_key));
                break;
            case AMXC_VAR_ID_DOUBLE:
                amxc_var_set(double, value, GETP_DOUBLE(source_section, json_key));
                break;
            default:
                SAH_TRACEZ_WARNING(ME, "Unsupported variant type: %d", field_mappings_item->var_type);
                break;
            }
        }
    }
    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Parses the error status from JSON output and updates the result variant.
 *
 * @details
 * This function parses the error status from JSON output and updates the result variant.
 * It sets the StatusCode and StatusMessage in the ret variant, and maps the error message
 * to a more specific status if possible.
 *
 * @param[in]  json_data  JSON data to parse (owned by caller).
 * @param[in]  ret        Output variant to store results (owned by caller).
 *
 * @return The status of the test as iplcap_test_status_t.
 */
static iplcap_test_status_t iplcap_parse_error_status(amxc_var_t* json_data, amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    iplcap_test_status_t status = iplcap_test_error_err_other;
    amxc_var_t* value = NULL;
    amxc_var_t* output = NULL;

    // Check ErrorStatus first
    int error_status = GETP_INT32(json_data, "ErrorStatus");
    const char* error_msg = GETP_CHAR(json_data, "ErrorMessage");
    const char* error_msg2 = GETP_CHAR(json_data, "ErrorMessage2");

    // Set StatusCode and StatusMessage in ret
    value = GETP_ARG(ret, IPLCAP_RET_KEY_STATUS_CODE);
    amxc_var_set(int32_t, value, (int32_t) error_status);

    value = GETP_ARG(ret, IPLCAP_RET_KEY_STATUS_MSG);
    // Combine error_msg and error_msg2 if both are present
    if(!str_empty(error_msg) && !str_empty(error_msg2)) {
        amxc_string_t combined_msg;
        amxc_string_init(&combined_msg, strlen(error_msg) + strlen(error_msg2) + 3);
        amxc_string_setf(&combined_msg, "%s, %s", error_msg, error_msg2);
        amxc_var_set(cstring_t, value, amxc_string_get(&combined_msg, 0));
        amxc_string_clean(&combined_msg);
    } else if(!str_empty(error_msg)) {
        amxc_var_set(cstring_t, value, error_msg);
    } else if(!str_empty(error_msg2)) {
        amxc_var_set(cstring_t, value, error_msg2);
    } else {
        amxc_var_set(cstring_t, value, "");
    }

    // Determine status based on ErrorStatus
    if(error_status != 0) {
        // Map Error_Other to more specific status based on error message
        // Use error_msg for mapping (primary error message)
        status = iplcap_map_error_message_to_status(error_msg2 ? error_msg2 : error_msg);
    } else {
        // Check Output.Status only if ErrorStatus is 0
        output = GETP_ARG(json_data, "Output");
        const char* status_str = GETP_CHAR(output, IPLCAP_RET_KEY_STATUS);

        if(status_str != NULL) {
            status = iplcap_st_str_to_st_int(status_str);
            // If status is Error_Other, try to map to more specific status based on error message
            if((status == iplcap_test_error_err_other) && (error_msg != NULL)) {
                iplcap_test_status_t mapped_status = iplcap_map_error_message_to_status(error_msg2 ? error_msg2 : error_msg);
                if(mapped_status != iplcap_test_error_err_other) {
                    status = mapped_status;
                }
            }
        }
    }

    SAH_TRACEZ_OUT(ME);
    return status;
}


/**
 * @brief Parses the result from the standard output string.
 *
 * @details
 * This function parses the result from the standard output string.
 * It checks for error patterns and sets the StatusMessage accordingly.
 *
 * @param[in]  str_stdout  String containing the output to parse (owned by caller).
 * @param[out] ret         Output variant to store results (owned by caller).
 *
 * @return The status of the test as iplcap_test_status_t.
 */
static iplcap_test_status_t iplcap_parse_result(amxc_string_t* str_stdout, amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    iplcap_test_status_t status = iplcap_test_error_err_other;
    amxc_var_t json_str;  // Local variant, will be cleaned up
    amxc_var_t* json_data = NULL;
    amxc_var_t* ret_status = NULL;
    int rv = 0;

    when_null_trace(str_stdout, exit, ERROR, "Null input string");
    when_null_trace(ret, exit, ERROR, "Null return variant");
    when_str_empty_trace(amxc_string_get(str_stdout, 0), exit, ERROR, "Empty input string");
    status = iplcap_test_error_err_other;

    if(iplcap_error_pattern_match(str_stdout, "^ERROR:")) {
        amxc_var_set(cstring_t, GETP_ARG(ret, IPLCAP_RET_KEY_STATUS_MSG), amxc_string_get(str_stdout, 0));
        goto exit;
    }

    // Initialize local variant
    amxc_var_init(&json_str);

    // Set the JSON string in the variant
    rv = amxc_var_set(jstring_t, &json_str, amxc_string_get(str_stdout, 0));
    when_failed_trace(rv, clean_json, ERROR, "Failed to set JSON string in variant");

    // Cast the JSON string to a variant
    rv = amxc_var_cast(&json_str, AMXC_VAR_ID_ANY);
    when_failed_trace(rv, clean_json, ERROR, "Failed to cast JSON string");

    // Get the parsed data
    json_data = &json_str;

    // First check error status
    status = iplcap_parse_error_status(json_data, ret);

    // Parse all sections using unified field mapping parser
    rv = iplcap_parse_fields_unified(json_data, ret, iplcap_field_mappings_all);
    when_failed_trace(rv, clean_json, ERROR, "Failed to parse all sections using unified mapping");

clean_json:
    amxc_var_clean(&json_str);
exit:
    // Set DiagnosticsState in return variant
    ret_status = amxc_var_get_key(ret, IPLCAP_RET_KEY_DST, AMXC_VAR_FLAG_DEFAULT);
    amxc_var_set(cstring_t, ret_status, str_iplcap_test_status[status]);
    SAH_TRACEZ_OUT(ME);
    return status;
}

int mod_iplcap_test_check(UNUSED const char* function_name,
                          amxc_var_t* params,
                          amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    amxp_subproc_t* proc_iplcap = NULL;
    amxc_string_t string_stdout;
    amxc_var_t* stat_var = NULL;
    int ret_value = 0;
    iplcap_test_status_t status = iplcap_test_error_err_other;
    const int32_t pid = GETP_INT32(params, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_PID);
    const int32_t fd_stdout = GETP_INT32(params, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_FD_STDOUT);
    const int32_t fd_stderr = GETP_INT32(params, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_FD_STDERR);

    amxc_var_move(ret, params);
    amxc_string_init(&string_stdout, 0);

    when_true_trace(fd_stdout == 0, not_complete, ERROR, "No test is running - invalid stdout fd");
    when_true_trace(fd_stderr == 0, not_complete, ERROR, "No test is running - invalid stderr fd");
    when_true_trace(pid == 0, not_complete, ERROR, "No test is running - invalid pid");
    status = iplcap_test_not_complete;

    proc_iplcap = amxp_subproc_find(pid);

#ifndef IP_DIAGNOSTICS_UNIT_TEST
    when_null_trace(proc_iplcap, exit, ERROR, "No sub process found for PID: %d", pid);
#endif

    ret_value = amxp_subproc_wait(proc_iplcap, 1);
    status = iplcap_test_error_err_other;
    when_true_trace(ret_value == -1, exit, ERROR, "Failed while running iplcap process for command: %s", GET_CHAR(ret, IPLCAP_RET_KEY_CMD));
#ifdef IP_DIAGNOSTICS_UNIT_TEST
    ret_value = 1;
#endif

    // timeout reached, child is still running
    if(ret_value == 1) {
        status = iplcap_test_not_complete;
        goto not_complete;
    } else if(ret_value == 0) {
        when_false_trace(mod_ipd_read_large_from_fd(fd_stdout, &string_stdout), exit, ERROR, "Failed to read from stdout file descriptor");
        when_false_trace(mod_ipd_read_large_from_fd(fd_stderr, &string_stdout), exit, ERROR, "Failed to read from stderr file descriptor");
    } else {
        SAH_TRACEZ_ERROR(ME, "Unknown return value: %d", ret_value);
        status = iplcap_test_error_err_internal;
        goto exit;
    }

    status = iplcap_parse_result(&string_stdout, ret);
    if(status == iplcap_test_not_complete) {
        SAH_TRACEZ_ERROR(ME, "Process not running while output shows it's not complete");
        status = iplcap_test_error_err_other;
        goto exit;
    }

exit:
    // Kill the process in case something goes wrong
    if(iplcap_kill_iplcap_test(ret) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to kill process");
        status = iplcap_test_error_err_other;
    }
    iplcap_delete_test_script();

not_complete:
    stat_var = amxc_var_get_key(ret, IPLCAP_RET_KEY_DST, AMXC_VAR_FLAG_DEFAULT);
    amxc_var_set(cstring_t, stat_var, (cstring_t) str_iplcap_test_status[status]);
    amxc_string_clean(&string_stdout);
    SAH_TRACEZ_OUT(ME);
    return status;
}
