/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>
#include <debug/sahtrace.h>

#include <lcm/amxc_data.h>
#include <lcm/lcm_assert.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_error.h>
#include <cthulhu/cthulhu_ctr_start_data.h>

#include "cthulhu_capabilities.h"
#include "cthulhu_capabilities_common.h"
#include "cthulhu-capabilities/cthulhu_capabilities_defines.h"
#include "cthulhu_user_role.h"
#include "log.h"
#include "test_setup.h"
#include "dummy_be.h"
#include "test_caps_ctr_prestart.h"

static amxb_bus_ctx_t* bus_ctx = NULL;



static void set_sb_roles(void) {
    amxd_object_t* sb_obj = test_sb_get("generic");
    assert_non_null(sb_obj);
    assert_int_equal(amxd_object_set_csv_string_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES_NAMES, "Role2,Role4"), 0);
    assert_int_equal(amxd_object_set_csv_string_t(sb_obj, CTHULHU_SANDBOX_AVAILABLE_USER_ROLES, "Device.Users.Role.[RoleName==\"Role2\"],Device.Users.Role.[RoleName==\"Role4\"]"), 0);
}

static void set_ctr_roles(const char* ctr_id) {
    amxd_object_t* ctr_obj = test_ctr_get(ctr_id);
    assert_non_null(ctr_obj);
    assert_int_equal(amxd_object_set_csv_string_t(ctr_obj, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, "Role2,Role4"), 0);
    assert_int_equal(amxd_object_set_csv_string_t(ctr_obj, CTHULHU_CONTAINER_REQUIRED_USER_ROLES, "Device.Users.Role.[RoleName==\"Role2\"],Device.Users.Role.[RoleName==\"Role4\"]"), 0);
}

static void test_init(void) {
    amxc_var_t args;
    amxc_var_t ret;

    assert_int_equal(test_load_dummy_remote("../odl/device_users.odl"), 0);

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_dm());

    int res = cthulhu_capabilities_init("capabilities_init", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

int test_setup(UNUSED void** state) {
    assert_int_equal(test_caps_setup(), 0);
    assert_int_equal(test_register_dummy_be(), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    test_init();
    test_add_sb("generic");
    test_add_ctr("ctr1", "generic");
    set_sb_roles();
    set_ctr_roles("ctr1");

    return 0;
}

int test_teardown(UNUSED void** state) {
    test_caps_teardown();
    cthulhu_capabilities_cleanup(NULL, NULL, NULL);

    amxb_disconnect(bus_ctx);
    amxb_free(&bus_ctx);
    test_unregister_dummy_be();
    return 0;
}

void test_caps_ctr_prestart_no_ctrid(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    int res = cthulhu_capabilities_ctr_prestart("capabilities_ctr_prestart", &args, &ret);
    assert_int_equal(res, -1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    LOG_EXIT
}

void test_caps_ctr_prestart_no_start_data(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, "ctr1");

    int res = cthulhu_capabilities_ctr_prestart("capabilities_ctr_prestart", &args, &ret);
    assert_int_equal(res, -1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    LOG_EXIT
}

void test_caps_ctr_prestart_invalid_roles(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    cthulhu_ctr_start_data_t start_data;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    cthulhu_ctr_start_data_init(&start_data);

    amxd_object_t* ctr_obj = test_ctr_get("ctr1");
    assert_non_null(ctr_obj);
    assert_int_equal(amxd_object_set_csv_string_t(ctr_obj, CTHULHU_CONTAINER_REQUIRED_USER_ROLES_NAMES, "Role2,Role4}"), 0);


    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, "ctr1");
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_START_DATA, &start_data);

    int res = cthulhu_capabilities_ctr_prestart("capabilities_ctr_prestart", &args, &ret);
    assert_int_equal(res, -1);
    int fault = GET_INT32(&ret, CTHULHU_NOTIF_ERROR_TYPE);
    assert_int_equal(fault, tr181_fault_invalid_arguments);
    const char* err = GET_CHAR(&ret, CTHULHU_NOTIF_REASON);
    assert_string_equal(err, "Failed to split argument [RequiredUserRolesNames] value [Role2,Role4}] error (Missing opening curly bracket - {)");
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    assert_string_equal(start_data.capabilities, "none");

    cthulhu_ctr_start_data_clean(&start_data);
    LOG_EXIT
}

void test_caps_ctr_prestart_valid_roles(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    cthulhu_ctr_start_data_t start_data;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    cthulhu_ctr_start_data_init(&start_data);

    set_ctr_roles("ctr1");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, "ctr1");
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_START_DATA, &start_data);

    int res = cthulhu_capabilities_ctr_prestart("capabilities_ctr_prestart", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    assert_string_equal(start_data.capabilities, "CAP_NET_RAW CAP_MKNOD CAP_KILL");

    amxd_object_t* ctr_obj = test_ctr_get("ctr1");
    assert_non_null(ctr_obj);
    char* str = NULL;
    assert_string_equal(str = amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_AVAILABLE_USER_ROLE_CAPABILITIES, NULL), "CAP_NET_RAW,CAP_MKNOD,CAP_KILL");
    free(str);

    cthulhu_ctr_start_data_clean(&start_data);
    LOG_EXIT
}

void test_caps_ctr_prestart_user_removed(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    cthulhu_ctr_start_data_t start_data;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    cthulhu_ctr_start_data_init(&start_data);

    set_ctr_roles("ctr1");

    // remove user 4
    amxd_trans_t transaction;
    assert_int_equal(amxd_trans_init(&transaction), 0);
    assert_int_equal(amxd_trans_select_pathf(&transaction, "Device.Users.Role."), 0);
    amxd_trans_del_inst(&transaction, 4, NULL);
    assert_int_equal(amxd_trans_apply(&transaction, test_get_dummy_dm()), 0);
    amxd_trans_clean(&transaction);
    test_handle_events();

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, "ctr1");
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_START_DATA, &start_data);

    int res = cthulhu_capabilities_ctr_prestart("capabilities_ctr_prestart", &args, &ret);
    assert_int_equal(res, -1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    assert_string_equal(start_data.capabilities, "none");

    test_handle_events();

    amxd_object_t* ctr_obj = test_ctr_get("ctr1");
    assert_non_null(ctr_obj);
    char* str = NULL;
    assert_string_equal(str = amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_AVAILABLE_USER_ROLE_CAPABILITIES, NULL), "");
    free(str);

    cthulhu_ctr_start_data_clean(&start_data);
    LOG_EXIT
}