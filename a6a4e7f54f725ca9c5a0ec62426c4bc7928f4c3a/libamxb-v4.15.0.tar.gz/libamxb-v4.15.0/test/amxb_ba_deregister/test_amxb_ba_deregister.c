/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc_variant.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_lqueue.h>

#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_types.h>

#include <amxb/amxb_be.h>
#include <amxb/amxb.h>
#include <amxb/amxb_register.h>

#include "test_amxb_ba_deregister.h"

#include <amxc/amxc_macros.h>
static char* dummy_ctx = "xbus";
static char verify_host[64];
static char verify_port[64];
static char verify_path[64];
static int return_val;

static amxd_dm_t mydm;

int __wrap_dlclose(void* handle);

static void* dummy_connect(const char* host,
                           const char* port,
                           const char* path,
                           UNUSED amxp_signal_mngr_t* sigmngr) {
    strcpy(verify_host, host);
    strcpy(verify_port, port);
    strcpy(verify_path, path);

    return dummy_ctx;
}

static int dummy_disconnect(void* ctx) {
    assert_ptr_equal(ctx, dummy_ctx);
    return return_val;
}

static int dummy_get_fd(void* ctx) {
    assert_ptr_equal(ctx, dummy_ctx);
    return return_val;
}

static void dummy_free(void* ctx) {
    assert_ptr_equal(ctx, dummy_ctx);
}

static int dummy_read(void* const ctx) {
    assert_ptr_equal(ctx, dummy_ctx);
    return return_val;
}

amxd_dm_t* registered_dm = NULL;

static int dummy_register(void* const ctx,
                          amxd_dm_t* const dm) {
    assert_ptr_equal(ctx, dummy_ctx);
    assert_ptr_equal(dm, &mydm);

    registered_dm = dm;

    return return_val;
}

static int dummy_deregister(void* const ctx,
                            amxd_dm_t* const dm) {
    assert_ptr_equal(ctx, dummy_ctx);
    assert_ptr_equal(dm, &mydm);

    if(registered_dm) {
        assert_ptr_equal(registered_dm, dm);
        registered_dm = NULL;
    }

    return return_val;
}


static int dummy_describe(UNUSED void* const bus_ctx,
                          const char* object,
                          UNUSED const char* search_path,
                          UNUSED uint32_t flags,
                          UNUSED uint32_t access,
                          UNUSED amxc_var_t* retval,
                          UNUSED int timeout) {
    amxc_var_set(cstring_t, retval, "test");

    if(!registered_dm) {
        return amxd_status_object_not_found;
    }
    return (amxd_dm_findf(registered_dm, "%s", object) ? amxd_status_ok : amxd_status_object_not_found);
}

static amxb_be_funcs_t dummy_be1 = {
    .connect = dummy_connect,
    .disconnect = dummy_disconnect,
    .get_fd = dummy_get_fd,
    .read = dummy_read,
    .register_dm = dummy_register,
    .deregister_dm = dummy_deregister,
    .free = dummy_free,
    .describe = dummy_describe,
    .name = "xbus",
    .size = sizeof(amxb_be_funcs_t),
};

static amxb_be_funcs_t dummy_be3 = {
    .connect = dummy_connect,
    .name = "zbus",
    .size = sizeof(amxb_be_funcs_t),
};

int __wrap_dlclose(UNUSED void* handle) {
    return 0;
}

void test_amxb_deregister(UNUSED void** state) {
    amxb_bus_ctx_t* ctx = NULL;

    assert_int_equal(amxd_dm_init(&mydm), 0);
    assert_int_equal(amxb_be_register(&dummy_be1), 0);
    assert_int_equal(amxb_be_register(&dummy_be3), 0);

    return_val = 0;
    assert_int_equal(amxb_connect(&ctx, "xbus://test:80/var/run/xbus.sock"), 0);
    assert_int_not_equal(amxb_register(ctx, NULL), 0);
    assert_int_not_equal(amxb_deregister(ctx, NULL), 0);
    assert_int_equal(amxb_register(ctx, &mydm), return_val);
    assert_int_equal(amxb_deregister(ctx, &mydm), return_val);
    amxb_free(&ctx);

    assert_int_equal(amxb_connect(&ctx, "xbus://test:80/var/run/xbus.sock"), 0);
    return_val = 1;
    assert_int_equal(amxb_register(ctx, &mydm), return_val);
    assert_int_equal(amxb_deregister(ctx, &mydm), return_val);
    amxb_free(&ctx);

    return_val = 0;
    assert_int_equal(amxb_connect(&ctx, "zbus://test:80/var/run/zbus.sock"), 0);
    assert_int_equal(amxb_register(ctx, &mydm), AMXB_ERROR_NOT_SUPPORTED_OP);
    assert_int_equal(amxb_deregister(ctx, &mydm), AMXB_ERROR_NOT_SUPPORTED_OP);
    amxb_free(&ctx);

    return_val = 0;
    assert_int_equal(amxb_connect(&ctx, "xbus://test:80/var/run/xbus.sock"), 0);
    amxb_disconnect(ctx);
    assert_int_not_equal(amxb_register(ctx, &mydm), 0);
    assert_int_not_equal(amxb_deregister(ctx, &mydm), 0);
    amxb_free(&ctx);

    // Can deregister twice
    return_val = 0;
    assert_int_equal(amxb_connect(&ctx, "xbus://test:80/var/run/xbus.sock"), 0);
    assert_int_equal(amxb_register(ctx, &mydm), return_val);
    assert_int_equal(amxb_deregister(ctx, &mydm), return_val);
    assert_int_equal(amxb_deregister(ctx, &mydm), return_val);
    amxb_free(&ctx);

    assert_int_not_equal(amxb_register(ctx, &mydm), 0);
    assert_int_not_equal(amxb_deregister(ctx, &mydm), 0);

    assert_int_equal(amxb_be_unregister(&dummy_be1), 0);
    assert_int_equal(amxb_be_unregister(&dummy_be3), 0);

    amxd_dm_clean(&mydm);
}

void test_amxb_who_has(UNUSED void** state) {
    amxb_bus_ctx_t* ctx = NULL;

    assert_int_equal(amxd_dm_init(&mydm), 0);

    const char* root_object_name = "Main";

    amxd_object_t* root;
    assert_true(amxd_object_new(&root, amxd_object_singleton, root_object_name) == amxd_status_ok);
    assert_true(amxd_dm_add_root_object(&mydm, root) == amxd_status_ok);

    assert_int_equal(amxb_be_register(&dummy_be1), 0);

    return_val = 0;
    assert_int_equal(amxb_connect(&ctx, "xbus://test:80/var/run/xbus.sock"), 0);
    assert_int_equal(amxb_register(ctx, &mydm), return_val);

    assert_ptr_equal(amxb_be_who_has("Main"), ctx);

    assert_int_equal(amxb_deregister(ctx, &mydm), return_val);

    assert_null(amxb_be_who_has("Main"));

    amxb_free(&ctx);
    assert_int_equal(amxb_be_unregister(&dummy_be1), 0);
    amxd_dm_clean(&mydm);
}
