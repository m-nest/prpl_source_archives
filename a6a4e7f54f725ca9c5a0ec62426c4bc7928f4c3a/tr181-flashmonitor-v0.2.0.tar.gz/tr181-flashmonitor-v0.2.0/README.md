# tr181-flashmonitor

## Summary

Flash health Manager for monitoring the health of flash in the system

## Description

The tr181-flashmointor will monitor the health of the flash components.
The component enhances operational visibility into flash degradation,
enabling smarter lifecycle management and reducing field failures in prplOS deployments.

## Installation

You can build and install the flash monitor by running
```
make && sudo make install
```

### compile and install

```
make
sudo make install
```

### run test

```
make test
```

### run plugin inside a Ambiorix Docker container
Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

compile/install dependencies: (make + sudo make install)

 * libsahtrace
 * libamxb
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxj

## General requirements
- Enumerates all flash devices (eMMC, NAND via UBI) and exposes wear metrics
- Supports vendor-specific and standard wear indicators via mmc-utils and ubinfo
- Enables operators to assess device reliability and take preemptive action
- Proposes TR-181 extension for flash health, targeting BBF standardization


## Implementation
- Check Sysfs repositories to check for flash device info
- The corresponding block data has info on the lifetime of eMMC and bad blocks info for NAND
