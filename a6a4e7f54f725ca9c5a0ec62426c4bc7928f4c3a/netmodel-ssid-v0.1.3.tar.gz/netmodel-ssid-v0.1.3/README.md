# netmodel-ssid

This netmodel client handles the synchronization between netmodel interfaces marked with the ssid flag and the WiFi.SSID. instances.
