/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"

#define USB_SYSFS_DEVICES_PATH "/sys/bus/usb/devices"
#define USB_SYSFS_AUTH_FILENAME "authorized"

#define ME "host"

/**
 * @brief Finds a USB device by its ID.
 *
 * @param id The device ID.
 * @return amxd_object_t* The USB device object.
 */
amxd_object_t* find_device(const char* id) {
    if(id == NULL) {
        return NULL;             // Add null check
    }
    const char* ptr;
    char host_id[5];
    size_t size;
    ptr = strchr(id, '-');
    when_false_trace(ptr != NULL, error, ERROR, "Failed to process %s", id);
    size = ptr - id;
    when_false_trace(size < sizeof(host_id), error, ERROR, "Failed to process %s", id);
    memcpy(host_id, id, size);
    host_id[size] = '\0';
    return amxd_dm_findf(get_dm(), "USB.USBHosts.Host.%s.Device.[SysfsId == '%s']", host_id, id);
error:
    return NULL;
}

/**
 * @brief Reset a host using the given filesystem id.
 *
 * @param host A pointer to the host object.
 * @return 0 on success, -1 on failure.
 */
int reset_host(amxd_object_t* host) {
    int error = -1;
    int fd;
    // Get Host DEVNAME (e.g., /dev/bus/usb/001/004)
    char host_devname[64];
    uint32_t idx = amxd_object_get_index(host);
    snprintf(host_devname, sizeof(host_devname) - 1, "/dev/bus/usb/00%u/00%u", idx, idx);

    fd = open(host_devname, O_WRONLY);
    if(fd < 0) {
        SAH_TRACEZ_ERROR(ME, "Error opening %s", host_devname);
        return error;
    }

    SAH_TRACEZ_NOTICE(ME, "Resetting USB host %s", host_devname);
    error = ioctl(fd, USBDEVFS_RESET, 0);
    if(error < 0) {
        perror("Error in ioctl");
        SAH_TRACEZ_ERROR(ME, "Error ioctl on %s", host_devname);
        goto exit;
    }
    SAH_TRACEZ_NOTICE(ME, "Reset successful");

    error = 0;
exit:
    close(fd);
    return error;
}

/**
 * @brief Checks if the given ID is a host port ID.
 *
 * @param id The ID to check.
 * @return bool True if it is a host port ID, false otherwise.
 */
static bool is_host_port_id(const char* id) {
    if(id == NULL) {
        return false;             // Add null check
    }
    return (strlen(id) >= 3 && id[0] >= '1' && id[0] <= '9' && id[1] == '-' && id[2] >= '1' && id[2] <= '9');
}

/**
 * @brief Checks if the given device ID is a hub.
 *
 * @param device_id The device ID.
 * @return bool True if it is a hub, false otherwise.
 */
static bool is_hub(const char* device_id) {
    if(device_id == NULL) {
        return false;                    // Add null check
    }
    struct sysfs_device* device = NULL;
    struct dlist* attrlist;
    int nb_ports = 0;
    bool is_hub = false;

    // Find the device
    device = sysfs_open_device("usb", device_id);

    // Get device info list
    attrlist = sysfs_get_device_attributes(device);

    // Navigate the list
    if(attrlist != NULL) {
        struct sysfs_attribute* attr;
        dlist_for_each_data(attrlist, attr, struct sysfs_attribute) {
            if(strncmp(attr->name, "maxchild", sizeof("maxchild") - 1) == 0) {
                char* tmp = malloc(sizeof(attr->name));
                strlcpy(tmp, attr->value, sizeof(attr->name));
                trim_str(tmp);
                nb_ports = strtol((const char*) tmp, (char**) NULL, 10);
                free(tmp);
            }
        }
    }

    is_hub = (nb_ports > 0);
    sysfs_close_device(device);

    return is_hub;
}

/**
 * @brief Creates hub ports for a device.
 *
 * @param device The device object.
 * @param id The device ID.
 * @return int The status of the operation.
 */
static int create_hub_ports(amxd_object_t* device, const char* id) {
    if((device == NULL) || (id == NULL)) {
        return -1;                               // Add null check
    }
    char id_port[80];
    int error = 0;
    uint32_t max_children = amxd_object_get_value(uint32_t, device, "maxChildren", NULL);
    SAH_TRACEZ_NOTICE(ME, "Create %d Hub ports...", max_children);

    for(unsigned int i = 1; i <= max_children; i++) {
        snprintf(id_port, sizeof(id_port), "%s.%u", id, i);
        if(strlen(id_port) < MAX_ID_SIZE) {
            if(find_port(id_port) != NULL) {
                SAH_TRACEZ_ERROR(ME, "Can't create Hub port %s: Already exists", id_port);
            } else {
                amxd_object_t* hub_port = hubport_create_object(id_port, &error, "1.0", "Low");
                if((hub_port != NULL) && (error != 0)) {
                    hubport_delete_object(hub_port);
                }
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "id_port length too long: %zu", strlen(id_port));
            error = ERR_ID_TOO_LONG;
        }
    }

    return error;
}

/**
 * @brief Creates a hub object.
 *
 * @param host The host object.
 * @param connected_port The connected port object.
 * @param name The hub name.
 * @param id The hub ID.
 * @param error The error code.
 * @return amxd_object_t* The hub object.
 */
amxd_object_t* create_hub_object(amxd_object_t* host, amxd_object_t* connected_port, const char* name, const char* id, int* error) {
    if((host == NULL) || (connected_port == NULL) || (name == NULL) || (id == NULL)) {
        return NULL;                                                                       // Add null check
    }
    SAH_TRACEZ_NOTICE(ME, "Create Hub %s (on Port %d)...", id, amxd_object_get_index(connected_port));
    amxd_object_t* device = device_create_object(host, connected_port, name, id, error);

    // Create the HubPorts
    *error = create_hub_ports(device, id);
    return device;
}

/**
 * @brief Adds a device to a host.
 *
 * @param host_id The host ID.
 * @param device_name The device name.
 * @param device_id The device ID.
 * @param connected_port_id The connected port ID.
 * @return int The status of the operation.
 */
int host_add_device(const char* host_id, const char* device_name, const char* device_id, const char* connected_port_id) {
    int error = 0;
    if((host_id == NULL) || (device_name == NULL) || (device_id == NULL) || (connected_port_id == NULL)) {
        goto stop;                                                                                           // Add null check
    }
    amxd_object_t* connected_port = NULL;
    amxd_object_t* connected_host_port = NULL;

    SAH_TRACEZ_NOTICE(ME, "Prepare creation of Device %s on host %s connected_port_id %s", device_id, host_id, connected_port_id);

    // Find the Host
    amxd_object_t* host = find_host(host_id);
    if(host == NULL) {
        error = ERR_HOST_NOT_FOUND;
        goto doReturn;
    }

    // Find the Port
    connected_port = find_port(connected_port_id);
    if(connected_port == NULL) {
        // Port not found
        if(is_host_port_id(connected_port_id)) {
            // It is a HostPort, find port number
            long tmp;
            const char* ptr;
            int port_num;
            char buffer_host_port[4];

            snprintf(buffer_host_port, 4, "%s", connected_port_id);
            ptr = strchr(connected_port_id, '-');
            when_false_trace(ptr != NULL, stop, ERROR, "Failed to process %s", connected_port_id);
            ptr++;
            tmp = strtoul(ptr, (char**) NULL, 10);
            when_false_trace(tmp < 65536, stop, ERROR, "Failed to process %s", connected_port_id);
            port_num = (int) tmp;

            SAH_TRACEZ_NOTICE(ME, "buffer_host_port: %s port: %d", buffer_host_port, port_num);
            // Try first to find HostPort with uid == portNumber
            if((connected_host_port = find_host_port_by_uid(port_num)) != NULL) {
                // One is found, define its Id
                amxd_object_set_value(cstring_t, connected_host_port, "SysfsId", buffer_host_port);
                connected_port = connected_host_port;
            } else if((connected_host_port = find_host_port((const char*) buffer_host_port)) != NULL) {
                amxd_object_set_value(cstring_t, connected_host_port, "SysfsId", buffer_host_port);
                connected_port = connected_host_port;
            } else if((connected_host_port = find_host_port_by_name(buffer_host_port)) != NULL) {
                amxd_object_set_value(cstring_t, connected_host_port, "SysfsId", buffer_host_port);
                connected_port = connected_host_port;
            } else if((connected_host_port = find_host_port(HOSTPORT_VOID_ID)) != NULL) {
                // One is found, define its Id
                amxd_object_set_value(cstring_t, connected_host_port, "SysfsId", buffer_host_port);
                connected_port = connected_host_port;
            } else {
                // Error port not found
                error = ERR_PORT_NOT_FOUND;
                goto doReturn;
            }
        } else {
            // Error port not found
            error = ERR_PORT_NOT_FOUND;
            goto doReturn;
        }
    }

    // Check if the Device already exists
    amxd_object_t* device = find_device(device_id);
    if(device != NULL) {
        // Error already exists
        error = ERR_DEVICE_ALREADY_EXISTS;
        goto doReturn;
    }

    if(is_hub(device_id)) {
        // Create the Hub
        device = create_hub_object(host, connected_port, device_name, device_id, &error);
    } else {
        // Create the Device
        device = device_create_object(host, connected_port, device_name, device_id, &error);
    }
    if((device != NULL) && (error != 0)) {
        device_delete_object(host, device);
    }

doReturn:
    if(error != 0) {
        if(connected_host_port != NULL) {
            char* type = amxd_object_get_value(cstring_t, connected_host_port, "Type", NULL);
            if(type && (strncmp(type, "host", sizeof("host") - 1) == 0)) {
                // Re-void HostPort Id
                amxd_object_set_value(cstring_t, connected_host_port, "SysfsId", HOSTPORT_VOID_ID);
            }
            free(type);
        }
    }

    return error;
stop:
    return -1;
}

/**
 * @brief Check if the device is still present under sysfs.
 * Used when deleteing a Device object since we don't know if it's actually unplugged (file does not exist) or unauthorized (file exist).
 *
 * @param device The device object.
 * @return True when device exists and is unauthorized, false otherwise.
 */
static bool device_exists_unauthorized(amxd_object_t* device) {
    FILE* fp = NULL;
    amxc_var_t sysfs_id_value;
    amxc_string_t authorized_path;
    const char* path = NULL;
    bool exists = false;

    amxc_var_init(&sysfs_id_value);
    amxc_string_init(&authorized_path, 0);

    when_null(device, exit);

    amxd_object_get_param(device, "SysfsId", &sysfs_id_value);

    amxc_string_setf(&authorized_path, USB_SYSFS_DEVICES_PATH "/%s/" USB_SYSFS_AUTH_FILENAME, amxc_var_constcast(cstring_t, &sysfs_id_value));
    path = amxc_string_get(&authorized_path, 0);

    fp = fopen(path, "r");
    if(fp != NULL) {
        int authorized = -1;
        int n = 0;
        n = fscanf(fp, "%d", &authorized);
        if(n < 1) {
            SAH_TRACEZ_WARNING(ME, "Could not read %s", path);
        }
        fclose(fp);
        exists = !authorized;
    }

exit:
    amxc_string_clean(&authorized_path);
    amxc_var_clean(&sysfs_id_value);
    return exists;
}

/**
 * @brief Deletes a device from a host.
 *
 * @param device_id The device ID.
 * @param check_is_authorized When true, only remove device when it is authorized.
 * @return int The status of the operation.
 */
int host_del_device(const char* device_id, bool check_is_authorized) {
    if(device_id == NULL) {
        return -1;                    // Add null check
    }
    SAH_TRACEZ_NOTICE(ME, "Prepare deletion of Usb Device %s", device_id);
    const char* ptr;
    char host_id[5];
    size_t size;
    ptr = strchr(device_id, '-');
    when_false_trace(ptr != NULL, stop, ERROR, "Failed to process %s", device_id);
    size = ptr - device_id;
    when_false_trace(size < sizeof(host_id), stop, ERROR, "Failed to process %s", device_id);
    memcpy(host_id, device_id, size);
    host_id[size] = '\0';

    amxd_object_t* host = find_host(host_id);
    amxd_object_t* device = find_device(device_id);
    if((device == NULL) || (host == NULL)) {
        return ERR_DEVICE_NOT_FOUND;
    }

    if(check_is_authorized && device_exists_unauthorized(device)) {
        SAH_TRACEZ_INFO(ME, "not deleting device since exists unauthorized");
        return 0;
    }

    return device_delete_object(host, device);
stop:
    return -1;
}

/**
 * @brief Creates a host object.
 *
 * @param bus_num The bus number.
 * @param usb_version The USB version.
 * @param usb_type The USB type.
 * @return int The status of the operation.
 */
static int create_host_object(const char* bus_num, const char* usb_version, const char* usb_type) {
    if((bus_num == NULL) || (usb_version == NULL) || (usb_type == NULL)) {
        return -1;                                                             // Add null check
    }
    amxc_string_t name;
    amxd_trans_t trans;
    int rv = 0;
    uint32_t busnum = atoi(bus_num);

    amxc_string_init(&name, 0);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    SAH_TRACEZ_NOTICE(ME, "Create Host %d...", busnum);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.");
    amxc_string_setf(&name, "usb-Host-%d", busnum);
    amxd_trans_add_inst(&trans, busnum, amxc_string_get(&name, 0));
    amxd_trans_set_value(cstring_t, &trans, "Name", amxc_string_get(&name, 0));
    amxd_trans_set_value(cstring_t, &trans, "Alias", amxc_string_get(&name, 0));
    amxd_trans_set_value(cstring_t, &trans, "USBVersion", usb_version);
    amxd_trans_set_value(cstring_t, &trans, "Type", usb_type);
    amxd_trans_set_value(bool, &trans, "Enable", true);
    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

exit:
    amxd_trans_clean(&trans);
    amxc_string_clean(&name);
    return rv;
}

/**
 * @brief Updates a host object.
 *
 * @param host The host object.
 * @param usb_version The USB version.
 * @param usb_type The USB type.
 * @return int The status of the operation.
 */
static int update_host_object(amxd_object_t* host, const char* usb_version, const char* usb_type) {
    if((host == NULL) || (usb_version == NULL) || (usb_type == NULL)) {
        return -1;                                                          // Add null check
    }
    amxd_trans_t trans;
    int rv = 0;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, host);
    amxd_trans_set_value(cstring_t, &trans, "USBVersion", usb_version);
    amxd_trans_set_value(cstring_t, &trans, "Type", usb_type);
    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

exit:
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief Adds a host.
 *
 * @param bus_num The bus number.
 * @param usb_version The USB version.
 * @param usb_type The USB type.
 */
void add_host(const char* bus_num, const char* usb_version, const char* usb_type) {
    if((bus_num == NULL) || (usb_version == NULL) || (usb_type == NULL)) {
        return;                                                             // Add null check
    }
    amxd_object_t* host = find_host(bus_num);
    if(host == NULL) {
        create_host_object(bus_num, usb_version, usb_type);
    } else {
        SAH_TRACEZ_NOTICE(ME, "Update Host: %s", bus_num);
        update_host_object(host, usb_version, usb_type);
    }
}
