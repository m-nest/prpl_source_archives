/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __MOCK_NETMODEL_H__
#define __MOCK_NETMODEL_H__

#include <netmodel/client.h>
#include <netmodel/common_api.h>

void mocknm_init(amxo_parser_t* parser, amxd_dm_t* dm, const char* nm_odl);
void mocknm_clean(void);
amxc_set_t* mocknm_get_current_flags(void);

void mocknm_expect_openQuery_getAddrs(const char* iface_path, const char* result);
void mocknm_expect_openQuery_getParameters(const char* iface_path, const char* result);
void mocknm_expect_openQuery_getFirstParameter(const char* iface_path, const char* result);

void mocknm_change_query_result(const char* nm_query_path, amxc_var_t* result);

netmodel_query_t* __wrap_netmodel_openQuery_getAddrs(const char* intf,
                                                     const char* subscriber,
                                                     const char* flag,
                                                     const char* traverse,
                                                     netmodel_callback_t handler,
                                                     void* userdata);
netmodel_query_t* __wrap_netmodel_openQuery_getFirstParameter(const char* const interface,
                                                              const char* const subscriber,
                                                              const char* const name,
                                                              const char* const flag,
                                                              const char* const traverse,
                                                              netmodel_callback_t handler,
                                                              void* const userdata);
netmodel_query_t* __wrap_netmodel_openQuery_getParameters(const char* const interface,
                                                          const char* const subscriber,
                                                          const char* const name,
                                                          const char* const flag,
                                                          const char* const traverse,
                                                          netmodel_callback_t handler,
                                                          void* const userdata);
void __wrap_netmodel_setFlag(const char* intf, const char* flag, const char* condition, const char* traverse);
void __wrap_netmodel_clearFlag(const char* intf, const char* flag, const char* condition, const char* traverse);
void __wrap_netmodel_closeQuery(netmodel_query_t* const netmodel_query);

char* __wrap_netmodel_luckyIntf(const char* interface, const char* flag, const char* traverse);

#endif // __MOCK_NETMODEL_H__
