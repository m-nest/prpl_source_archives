/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdlib.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>

#include "discoping_utils.h"
#include "discoping_list.h"

const char* state_as_string(conmon_state state) {
    static const char* STATES[] = {"DISABLED", "LINK_DOWN", "WAN_DOWN", "INIT",
        "REINIT", "MAINLOOP", "RETRY"};

    return (state >= 0 && state <= RETRY) ? STATES[state] : NULL;
}

void change_state(active_discoping_t* entry, conmon_state newstate) {
    SAH_TRACEZ_IN(ME);

    SAH_TRACEZ_INFO(ME, "[%s] Changed state from %s to %s", entry->alias, state_as_string(entry->state), state_as_string(newstate));
    entry->state = newstate;

    SAH_TRACEZ_OUT(ME);
}

void change_mainloop(active_discoping_t* entry, bool start_timer) {
    SAH_TRACEZ_IN(ME);

    if(entry->link_up && entry->wan_up && !str_empty(entry->interface_name) && !str_empty(entry->local_ip) && (entry->state != MAINLOOP)) {
        change_state(entry, MAINLOOP);
        if((entry->isdeferring == false) && start_timer) {
            amxp_timer_start(entry->main_timer, 0);
        }
    }

    SAH_TRACEZ_OUT(ME);
}

int cleanup_active_connections(void) {
    SAH_TRACEZ_IN(ME);

    discoping_list_delete_all();

    SAH_TRACEZ_OUT(ME);
    return 0;
}

static int is_dot(int c) {
    return (c == '.') ? 1 : 0;
}

static char* copy_path_without_dot(const char* orig) {
    char* rv = NULL;
    amxc_string_t stripped_path;
    amxc_string_init(&stripped_path, 0);

    when_str_empty(orig, exit);

    amxc_string_set(&stripped_path, orig);
    amxc_string_trimr(&stripped_path, is_dot);

    rv = amxc_string_take_buffer(&stripped_path);
exit:
    amxc_string_clean(&stripped_path);
    return rv;
}

static inline void update_path_without_dot(amxc_var_t* args, const char* key, char** var) {
    amxc_var_t* arg = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT);
    const char* str = NULL;
    when_null(arg, exit);
    str = GET_CHAR(arg, NULL);
    when_null(str, exit);
    free(*var);
    *var = copy_path_without_dot(str);
exit:
    return;
}

static inline void update_string(amxc_var_t* args, const char* key, char** var) {
    amxc_var_t* arg = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT);
    const char* str = NULL;
    when_null(arg, exit);
    str = GET_CHAR(arg, NULL);
    when_null(str, exit);

    free(*var);
    *var = strdup(str);
exit:
    return;
}

static inline void update_uint32(amxc_var_t* args, const char* key, uint32_t* var) {
    amxc_var_t* arg = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT);
    when_null(arg, exit);
    *var = GET_UINT32(arg, NULL);
exit:
    return;
}

typedef void (* update_entry_string_t)(active_discoping_t* entry, const char* arg);
static void update_entry_string(active_discoping_t* entry, amxc_var_t* args, const char* key, update_entry_string_t update) {
    amxc_var_t* arg = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT);
    when_null(arg, exit);
    update(entry, GET_CHAR(arg, NULL));
exit:
    return;

}

typedef void (* update_entry_bool_t)(active_discoping_t* entry, bool arg);
static void update_entry_bool(active_discoping_t* entry, amxc_var_t* args, const char* key, update_entry_bool_t update) {
    amxc_var_t* arg = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT);
    when_null(arg, exit);
    update(entry, GET_BOOL(arg, NULL));
exit:
    return;

}

static void update_local_ip(active_discoping_t* entry, const char* local_ip) {
    when_null(local_ip, exit);
    free(entry->local_ip);
    entry->local_ip = strdup(local_ip);
    change_mainloop(entry, true);
exit:
    return;
}

static void update_wan_ip(active_discoping_t* entry, const char* wan_ip) {
    when_null(wan_ip, exit);
    if(entry->wan_ip != NULL) {
        when_true(strcmp(entry->wan_ip, wan_ip) == 0, exit);
    }

    free(entry->wan_ip);
    entry->wan_ip = strdup(wan_ip);

    if(str_empty(entry->wan_ip)) {
        // WAN goes down
        change_state(entry, WAN_DOWN);
        entry->wan_up = false;
        amxp_timer_start(entry->main_timer, 0);
    } else {
        // WAN comes up
        entry->wan_up = true;
        change_mainloop(entry, true);
    }
exit:
    return;
}

static void update_up_changed(active_discoping_t* entry, bool up) {
    if(up == false) {
        // Link goes down
        change_state(entry, LINK_DOWN);
        entry->link_up = false;
        amxp_timer_start(entry->main_timer, 0);
    } else {
        // Link comes up
        entry->link_up = true;
        change_mainloop(entry, true);
    }
}

static void update_physup_changed(active_discoping_t* entry, bool up) {
    if(up == false) {
        // Physical link goes down
        change_state(entry, WAN_DOWN);
        entry->link_up = false;
        amxp_timer_start(entry->main_timer, 0);
    } else {
        // Physical link comes up
        entry->link_up = true;
        change_mainloop(entry, true);
    }
}

static void update_dhcpup_changed(active_discoping_t* entry, bool up) {
    if(up && entry->link_up) {
        // link (re)established
        change_mainloop(entry, true);
    }
}

void update_entry(active_discoping_t* entry, amxc_var_t* args) {
    SAH_TRACEZ_IN(ME);

    when_null(entry, exit);
    when_null(args, exit);

    update_string(args, "interface_name", &entry->interface_name);
    update_string(args, "logical_path", &entry->logical_path);
    update_string(args, "local_mac", &entry->local_mac);

    update_path_without_dot(args, "ll_interface_path", &entry->ll_interface_path);

    update_uint32(args, "retries_max", &entry->retries_max);
    update_uint32(args, "retry_interval", &entry->retry_interval);
    update_uint32(args, "main_interval", &entry->main_interval);
    update_uint32(args, "fail_interval", &entry->fail_interval);
    update_uint32(args, "arpns_errors_sent", &entry->arpns_errors_sent);
    update_uint32(args, "arpns_total_fail", &entry->arpns_total_fail);
    update_uint32(args, "total_dhcp_restarts", &entry->total_dhcp_restarts);

    update_entry_string(entry, args, "local_ip", update_local_ip);
    update_entry_string(entry, args, "wan_ip", update_wan_ip);

    update_entry_bool(entry, args, "up_changed", update_up_changed);
    update_entry_bool(entry, args, "physup_changed", update_physup_changed);
    update_entry_bool(entry, args, "dhcpup_changed", update_dhcpup_changed);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

static void set_dhcp(amxb_bus_ctx_t* bus, const char* path, const char* alias, bool enable) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t parameters;
    amxc_var_t ret;
    int rc = -1;

    amxc_var_init(&ret);
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    // Enable DHCP
    amxc_var_add_key(bool, &parameters, "Enable", enable);
    (void) alias; // use variable when tracing is disabled
    SAH_TRACEZ_INFO(ME, "[%s] Set %s%s to %d", alias, path, "Enable", enable);

    rc = amxb_set(bus, path, &parameters, &ret, 5);
    when_failed_trace(rc, exit, ERROR, "%s client set params failed with error code %d", path, rc);

exit:
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
}

void toggle_dhcp(active_discoping_t* entry) {
    SAH_TRACEZ_IN(ME);

    amxb_bus_ctx_t* bus = NULL;
    const char* client_path = NULL;
    amxc_var_t ret;
    amxc_string_t test_path;

    amxc_var_init(&ret);
    amxc_string_init(&test_path, 0);

    when_str_empty_trace(entry->ll_interface_path, exit, ERROR, "Can't toggle dhcp: interface path is empty");

    amxc_string_setf(&test_path, "DHCPv%dClient.", entry->ip_version);
    bus = amxb_be_who_has(amxc_string_get(&test_path, 0));
    when_null_trace(bus, exit, ERROR, "amxb_bus_ctx_t was empty");

    amxc_string_appendf(&test_path, "Client.[Interface=='%s'].", entry->ll_interface_path);
    amxb_get(bus, amxc_string_get(&test_path, 0), 0, &ret, 5);
    client_path = amxc_var_key(GETP_ARG(&ret, "0.0"));
    when_str_empty_trace(client_path, exit, INFO, "No results for '%s'", amxc_string_get(&test_path, 0));

    // Disable DHCP
    set_dhcp(bus, client_path, entry->alias, false);

    // Enable DHCP
    set_dhcp(bus, client_path, entry->alias, true);

exit:
    amxc_string_clean(&test_path);
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
}
