# Tr181 Bulkdata Extra


[[_TOC_]]

## Introduction
This document demonstrates how to use the BulkData feature. 
It includes instructions for setting up the test environment and using various BulkData configurations.

## Setting up the environment
The examples were performed on a Freedom board.
<!-- BEGIN-INTERNAL -->
You can find the image used for the demo at the following link: [link](https://nextcloud.softathome.com/index.php/s/egAeGJHeKGow6Lt) (password: s@hBulkdata*2025).
<!-- END-INTERNAL -->

 After downloading the image:
- Place it on a TFTP server
- Ensure that only one network interface is active on the board (either WAN or LAN)
- Connect to the board via serial connection and execute the following commands:
```bash
tftpboot 0x44000000 prplos-ipq95xx-generic-prpl_freedom-squashfs-sysupgrade_local.bin
setenv untar_addr_kernel; setenv untar_addr_root
untar 0x$fileaddr 0x$filesize kernel root
if test -n $untar_addr_kernel; then flash "0:HLOS" 0x$untar_addr_kernel 0x$untar_size_kernel; else echo "kernel is not found"; fi
if test -n $untar_addr_root; then flash "rootfs" 0x$untar_addr_root 0x$untar_size_root; else echo "rootfs is not found"; fi
reset
```

For more details, please refer to [prpl Foundation Freedom board](https://gitlab.com/prpl-foundation/prplos/prplos/-/wikis/prpl-Foundation-Freedom-board#flashing-sysupgrade-image-from-within-u-boot-bootloader)


## General configuration

**1. Time Synchronization Requirement for BulkData**

Check the parameter `needs-time-sync` in the configuration section of the module.

If its value is set to `True`, then to properly start BulkData:
- The `Time` plugin must be started.
- Ensure that system time is synchronized before BulkData initialization.

To view the plugin’s configuration parameters, start it with the `-d` option.
Example:
```
sudo tr181-bulkdata -d
INFO -- Load - Failed to load /etc/config/tr181-bulkdata//odl or directory is empty
INFO -- Load - Try to load default from tr181-bulkdata_defaults/

Configuration:
{
    auto-connect = true,
    auto-detect = true,
    auto-resolver-order = [
        "import",
        "*"
    ],
    needs-time-sync = false,
    ...
}
```

**2. ACL**

When collecting data using BulkData, ACLs (Access Control Lists) must be enforced.

This means that the controller used to create a BulkData profile must have the necessary permissions to access the referenced parameters.

Example:
- ACL enforcement is enabled.
```bash
head /etc/amx/tr181-bulkdata/tr181-bulkdata.odl
%config {
    // Application name
    name = "tr181-bulkdata";

    // odl parser config options
    acl_dir = "${prefix}/cfg/etc/acl";
    
    // checking for acl (disabled by default)
    acl_check_enabled = true;
```

- A new BulkData profile is created by a controller for an agent with EndpointID `proto::Agent-0914faeadcbe` using the following commands:
```bash
LocalController.usp_add("proto::Agent-0914faeadcbe", {
  allow_partial: true,
  requests: [{
    object_path: "BulkData.Profile.",
    parameters: [
      {param: "Protocol", value: "HTTP", required: false},
      {param: "ReportingInterval", value: 60, required: false},
      {param: "Enable", value: "false"},
      {param: "EncodingType", value: "JSON"},
      {param: "HTTP.URL", value: "http://localhost:8080"},
      {param: "HTTP.Method", value: "POST"},
      {param: "HTTP.RetryEnable", value: "true"},
      {param: "Alias", value: "Test", required: false},
      {param: "Name", value: "Test", required: false}
    ]
  }]
})

LocalController.usp_add("proto::Agent-0914faeadcbe", {
  allow_partial: true,
  requests: [{
    object_path: "BulkData.Profile.[Alias=='Test'].Parameter.",
    parameters: [
      {param: "Name", value: "UpTime-Name", required: false},
      {param: "Reference", value: "DeviceInfo.UpTime", required: false}
    ]
  }]
})
```

Result:

The created profile must include a reference to the controller that initiated the request:
```bash
BulkData.Profile.11.Controller="LocalAgent.Controller.1."
```

That controller must have the proper rights to access the parameter:
```bash
DeviceInfo.UpTime
```
<!-- BEGIN-INTERNAL -->
For more information about ACL, please refer to [ACL-Manager](https://gitlabinternal.softathome.com/ambiorix/applications/acl-manager).
<!-- END-INTERNAL -->

## BulkData
### Useful links
- [tr181-Bulkdata](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.BulkData.Protocols)

### HTTP/HTTPS Profile
#### 1. Set up a http/https echo server

execute the [echoServer.py](../test/common/utils/echoServer.py):
```bash
python3 echoServer.py
```

You can execute the following curl commands:
```bash
curl -X POST http://192.168.1.2:8080 -d "Hello from curl"
```

PS:
There are several online hosted echo servers available. Below are some examples:
- HTTTS post: https://postman-echo.com/post/
- HTTPS put: https://postman-echo.com/put/
- HTTPS with certification: https://httpbin.org/post


#### 2. HTTP Profiles
**2.1 HTTP Profile with JSON Encoding**
Create a new profile as following:

```bash
# Create the profile
BulkData.Profile.+{Alias="http_post_json_oh", EncodingType="JSON", Name="http_post_json_oh", Protocol="HTTP", Enable="false", ReportingInterval = 30}

# Set the HTTP params
BulkData.Profile.http_post_json_oh.HTTP.URL="http://192.168.1.2:8080"
BulkData.Profile.http_post_json_oh.HTTP.Method="POST"
BulkData.Profile.http_post_json_oh.HTTP.UseDateHeader=1

# Set the encoding type
BulkData.Profile.http_post_json_oh.JSONEncoding.ReportFormat="ObjectHierarchy"
BulkData.Profile.http_post_json_oh.JSONEncoding.ReportTimestamp="Unix-Epoch"

# Set which data to send
BulkData.Profile.http_post_json_oh.Parameter.+{Name="MemoryStatus", Reference="DeviceInfo.MemoryStatus."}

# Enable the profile
BulkData.Profile.http_post_json_oh.Enable=1
```

<details>
<summary>You can also enable the following trace zone to capture all logs in the syslog. – Click to expand</summary>

```bash
BulkData.set_trace_zone(zone = bulkdata, level = 500)
BulkData.set_trace_zone(zone = csv_encoding, level = 500)
BulkData.set_trace_zone(zone = encoding, level = 500)
BulkData.set_trace_zone(zone = request_uri_parameter, level = 500)
BulkData.set_trace_zone(zone = http, level = 500)
BulkData.set_trace_zone(zone = json_encoding, level = 500)
BulkData.set_trace_zone(zone = mqtt, level = 500)
BulkData.set_trace_zone(zone = parameter, level = 500)
BulkData.set_trace_zone(zone = profile, level = 500)
BulkData.set_trace_zone(zone = actions, level = 500)
BulkData.set_trace_zone(zone = events, level = 500)
BulkData.set_trace_zone(zone = imtp, level = 500)
BulkData.set_trace_zone(zone = ftx, level = 500)
BulkData.set_trace_zone(zone = ftx_uri, level = 500)
BulkData.set_trace_zone(zone = ftx_func, level = 500)
BulkData.set_trace_zone(zone = acl, level = 500)
```
</details> 

<details>
<summary>Example of traces in the echo server – Click to expand</summary>

```bash
Received headers:
    Host: 192.168.1.2:8080
    Accept: */*
    date: Fri, 18 Apr 2025 13:24:33 GMT
    bbf-report-format: ObjectHierarchy
    Content-Length: 105
    Content-Type: application/x-www-form-urlencoded
Received body:
    {"Report":[{"MemoryStatus":{"Total":"1903288320","Free":"1164775424"},"CollectionTime":"1744982673550"}]}
192.168.1.1 - - [18/Apr/2025 15:24:33] "POST / HTTP/1.1" 200 -
```
</details> 

<details>
<summary>Example of traces extracted from syslog. – Click to expand</summary>

```bash
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: profile - [i]Start profile http_post_json_oh - (bulkdata_start_profile@bulkdata_profile.c:357)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
2025 Apr 18 13:24:33 prplOS ba-cli: > BulkData.Profile.http_post_json_oh.Enable=1
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: profile - [i]Collect profile http_post_json_oh - (bulkdata_profile_collect@bulkdata_profile.c:284)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]root_object = DeviceInfo - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]key = DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Total = 1903288320 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Free = 1164775424 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]allocate file transfer request - (ftx_request_new@filetransfer_request.c:436)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 allocate request config - (ftx_request_new@filetransfer_request.c:444)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 initialize request config - (ftx_request_new@filetransfer_request.c:448)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 state change undefined -> created - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 append request to list - (ftx_request_new@filetransfer_request.c:453)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 state change created -> sent - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 state change sent -> waiting_for_reply - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (107)HTTPAUTH=-17 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10002)URL=http://192.168.1.2:8080 - (ftx_curl_setopt_cstring@filetransfer_curl.c:151)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10023)HTTPHEADER=not null - (ftx_curl_setopt_slist@filetransfer_curl.c:176)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]  date: Fri, 18 Apr 2025 13:24:33 GMT - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]  bbf-report-format: ObjectHierarchy - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (47)POST=1 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10015)POSTFIELDS=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (60)POSTFIELDSIZE=105 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]set opt (20011)WRITEFUNCTION=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]Response: len : 453. Reponse: {
    "method": "POST",
    "path": "/",
    "headers": {
        "Host": "192.168.1.2:8080",
        "Accept": "*/*",
        "date": "Fri, 18 Apr 2025 13:24:33 GMT",
        "bbf-report-format": "ObjectHierarchy",
        "Content-Length": "105",
        "Content-Type": "application/x-www-form-urlencoded"
    },
    "body": "{\"Report\":[{\"MemoryStatus\":{\"Total\":\"1903288320\",\"Free\":\"1164775424\"},\"CollectionTime\":\"1744982673550\"}]}"
} - (response_callback@filetransfer_curl.c:1094)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]Sending data return code 0 (No error) - (ftx_curl_send_stream@filetransfer_curl.c:1193)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]Content-Type: assume application/octet-stream - (ftx_curl_get_info@filetransfer_curl.c:885)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]request id 3 state change waiting_for_reply -> done - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http_post_json_oh' - (response_cb@bulkdata_profile_http.c:206)
2025 Apr 18 13:24:33 prplOS tr181-bulkdata: ftx     - [i]delete request id 3 - (ftx_request_delete@filetransfer_request.c:474)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: profile - [i]Collect profile mqtt_json_oh - (bulkdata_profile_collect@bulkdata_profile.c:284)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]root_object = DeviceInfo - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]key = DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Total = 1903288320 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Free = 1162711040 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: mqtt    - [i]Sending BulkData report to MQTT client - (bulkdata_profile_mqtt_send_data@bulkdata_profile_mqtt.c:279)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: imtp    - [i]Sending TLV chain over stream socket - (imtp_connection_write_impl@imtp_connection.c:277)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]Incoming message on fd: [21] - (mqtt_imtp_accepted_read@mqtt_imtp.c:202)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]Found TLV of type JSON - (mqtt_imtp_unpack_frame@mqtt_imtp.c:131)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]Publishing JSON string on topic: controller/proto::Controller-0914faeadcbe - (mqtt_imtp_unpack_and_publish@mqtt_imtp.c:180)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]Adding content-type property: application/json; charset=UTF-8 - (mqtt_publish@mqtt_mosquitto_interface.c:866)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]LOG 16 - Client B5A14C3B-421D-3289-0A9A-D27602B66702 sending PUBLISH (d0, q1, r0, m1248, 'controller/proto::Controller-0914faeadcbe', ... (105 bytes)) - (mqtt_on_log@mqtt_mosquitto_interface.c:449)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]LOG 16 - Client B5A14C3B-421D-3289-0A9A-D27602B66702 received PUBACK (Mid: 1248, RC:0) - (mqtt_on_log@mqtt_mosquitto_interface.c:449)
2025 Apr 18 13:24:36 prplOS tr181-mqtt: mqtt_cl - [i]Message published - (mqtt_client_published@dm_mqtt_events.c:423)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: events  - [i]Enable changed from "1" to "0" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 13:24:36 prplOS tr181-bulkdata: profile - [i]Stop profile http_post_json_oh - (bulkdata_stop_profile@bulkdata_profile.c:384)

```
</details> 


**2.2 HTTP Profile with JSON CSV-ParameterPerRow**

Create a new profile as following:

```bash
# Create the profile
BulkData.Profile.+{Alias="http_put_csv_ppr", EncodingType="CSV", Name="http_put_csv_ppr", Protocol="HTTP", Enable="false", ReportingInterval = 10}

# Set the HTTP params
BulkData.Profile.http_put_csv_ppr.HTTP.URL="http://192.168.1.2:8080"
BulkData.Profile.http_put_csv_ppr.HTTP.Method="PUT"
BulkData.Profile.http_put_csv_ppr.HTTP.UseDateHeader=1

# Set the encoding details
BulkData.Profile.http_put_csv_ppr.CSVEncoding.EscapeCharacter="&quot"
BulkData.Profile.http_put_csv_ppr.CSVEncoding.FieldSeparator=","
BulkData.Profile.http_put_csv_ppr.CSVEncoding.ReportFormat="ParameterPerRow"
BulkData.Profile.http_put_csv_ppr.CSVEncoding.RowSeparator="&#13;&#10;"
BulkData.Profile.http_put_csv_ppr.CSVEncoding.RowTimestamp="Unix-Epoch"

# Set which data to send
BulkData.Profile.http_put_csv_ppr.Parameter.+{Name="MemoryStatus", Reference="DeviceInfo.MemoryStatus."}

# Enable the profile
BulkData.Profile.http_put_csv_ppr.Enable=1
```

<details>
<summary>Example of traces in the echo server – Click to expand</summary>

```bash
Received headers:
    Host: 192.168.1.2:8080
    Accept: */*
    date: Fri, 18 Apr 2025 14:09:33 GMT
    bbf-report-format: ParameterPerRow
    Content-Length: 159
Received body:
    ReportTimestamp,ParameterName,ParameterValue,ParameterType
,1744985373109,MemoryStatus.Free,1162825728,int
,1744985373109,MemoryStatus.Total,1903288320,int

192.168.1.1 - - [18/Apr/2025 16:09:33] "PUT / HTTP/1.1" 200 -

```
</details> 

<details>
<summary>Example of traces extracted from syslog. – Click to expand</summary>

```bash
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: profile - [i]Start profile http_put_csv_ppr - (bulkdata_start_profile@bulkdata_profile.c:357)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
2025 Apr 18 14:09:33 prplOS ba-cli: > BulkData.Profile.http_put_csv_ppr.Enable=1
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: profile - [i]Collect profile http_put_csv_ppr - (bulkdata_profile_collect@bulkdata_profile.c:284)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:181)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]root_object = DeviceInfo - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:196)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:200)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]key = DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Total = 1903288320 | int - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Free = 1162825728 | int - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: csv_enc - [i]                MemoryStatus.Free  | 1162825728  | int - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: csv_enc - [i]                MemoryStatus.Total  | 1903288320  | int - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]allocate file transfer request - (ftx_request_new@filetransfer_request.c:436)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 allocate request config - (ftx_request_new@filetransfer_request.c:444)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 initialize request config - (ftx_request_new@filetransfer_request.c:448)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 state change undefined -> created - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 append request to list - (ftx_request_new@filetransfer_request.c:453)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 state change created -> sent - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 state change sent -> waiting_for_reply - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (107)HTTPAUTH=-17 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10002)URL=http://192.168.1.2:8080 - (ftx_curl_setopt_cstring@filetransfer_curl.c:151)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10023)HTTPHEADER=not null - (ftx_curl_setopt_slist@filetransfer_curl.c:176)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]  date: Fri, 18 Apr 2025 14:09:33 GMT - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]  bbf-report-format: ParameterPerRow - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (46)UPLOAD=1 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (10009)READDATA=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (14)=159 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]set opt (20011)WRITEFUNCTION=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]Response: len : 435. Reponse: {
    "method": "PUT",
    "path": "/",
    "headers": {
        "Host": "192.168.1.2:8080",
        "Accept": "*/*",
        "date": "Fri, 18 Apr 2025 14:09:33 GMT",
        "bbf-report-format": "ParameterPerRow",
        "Content-Length": "159"
    },
    "body": "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n,1744985373109,MemoryStatus.Free,1162825728,int\r\n,1744985373109,MemoryStatus.Total,1903288320,int\r\n"
} - (response_callback@filetransfer_curl.c:1094)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]Sending data return code 0 (No error) - (ftx_curl_send_stream@filetransfer_curl.c:1193)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]Content-Type: assume application/octet-stream - (ftx_curl_get_info@filetransfer_curl.c:885)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]request id 5 state change waiting_for_reply -> done - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http_put_csv_ppr' - (response_cb@bulkdata_profile_http.c:206)
2025 Apr 18 14:09:33 prplOS tr181-bulkdata: ftx     - [i]delete request id 5 - (ftx_request_delete@filetransfer_request.c:474)
2025 Apr 18 14:09:33 prplOS cwmpd: CWMPD   - [x]DNS lookup Failed next in 5 sec,ares_error [Timeout while contacting DNS servers] - (cwmp_dns_resolve_cb@cwmpd_dns.c:359)
2025 Apr 18 14:09:33 prplOS obuspa[2791]: tw_ulib_diags_lookup_host(host=controller.cdroutertest.com, acs_family_pref=Any): getaddrinfo() failed: Name does not resolve
2025 Apr 18 14:09:33 prplOS obuspa[2791]: ERROR: STOMP failed whilst attempting to connect to (host=controller.cdroutertest.com, port=61613)
2025 Apr 18 14:09:33 prplOS obuspa[2791]: Error on STOMP connection to (host controller.cdroutertest.com, port 61613). Closing connection.
2025 Apr 18 14:09:37 prplOS tr181-bulkdata: events  - [i]Enable changed from "1" to "0" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 14:09:37 prplOS tr181-bulkdata: profile - [i]Stop profile http_put_csv_ppr - (bulkdata_stop_profile@bulkdata_profile.c:384)
2025 Apr 18 14:09:37 prplOS ba-cli: > BulkData.Profile.http_put_csv_ppr.Enable=0
```
</details> 


**2.3 HTTP Profile with CSV-ParameterPerColumn**

Create a new profile as following:

```bash
# Create the profile
BulkData.Profile.+{Alias="http_put_csv_ppc", EncodingType="CSV", Name="http_put_csv_ppc", Protocol="HTTP", Enable="false", ReportingInterval = 10}

# Set the HTTP params
BulkData.Profile.http_put_csv_ppc.HTTP.URL="http://192.168.1.2:8080"
BulkData.Profile.http_put_csv_ppc.HTTP.Method="POST"
BulkData.Profile.http_put_csv_ppc.HTTP.UseDateHeader=1

# Set the encoding details
BulkData.Profile.http_put_csv_ppc.CSVEncoding.EscapeCharacter="&quot"
BulkData.Profile.http_put_csv_ppc.CSVEncoding.FieldSeparator=","
BulkData.Profile.http_put_csv_ppc.CSVEncoding.ReportFormat="ParameterPerColumn"
BulkData.Profile.http_put_csv_ppc.CSVEncoding.RowSeparator="&#13;&#10;"
BulkData.Profile.http_put_csv_ppc.CSVEncoding.RowTimestamp="Unix-Epoch"

# Set which data to send
BulkData.Profile.http_put_csv_ppc.Parameter.+{Name="MemoryStatusFree", Reference="DeviceInfo.MemoryStatus.Free"}
BulkData.Profile.http_put_csv_ppc.Parameter.+{Name="MemoryStatusStatus", Reference="Device.DeviceInfo.MemoryStatus.Total"}

# Enable the profile
BulkData.Profile.http_put_csv_ppc.Enable=1
```

<details>
<summary>Example of traces in the echo server – Click to expand</summary>

```bash
Received headers:
    Host: 192.168.1.2:8080
    Accept: */*
    date: Fri, 18 Apr 2025 14:22:56 GMT
    bbf-report-format: ParameterPerColumn
    Content-Length: 91
    Content-Type: application/x-www-form-urlencoded
Received body:
    ReportTimestamp,MemoryStatusStatus,MemoryStatusFree
,1744986176710,1903288320,1159499776

192.168.1.1 - - [18/Apr/2025 16:22:56] "POST / HTTP/1.1" 200 -
```
</details> 

<details>
<summary>Example of traces extracted from syslog. – Click to expand</summary>

```bash
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: profile - [i]Start profile http_put_csv_ppc - (bulkdata_start_profile@bulkdata_profile.c:357)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
2025 Apr 18 14:22:56 prplOS ba-cli: > BulkData.Profile.http_put_csv_ppc.Enable=1
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: profile - [i]Collect profile http_put_csv_ppc - (bulkdata_profile_collect@bulkdata_profile.c:284)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:181)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]root_object = DeviceInfo - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:196)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:200)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]key = DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]MemoryStatusFree = 1159499776 | int - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:181)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]root_object = Device - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:196)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:200)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]key = Device.DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: paramet - [i]MemoryStatusStatus = 1903288320 | int - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]allocate file transfer request - (ftx_request_new@filetransfer_request.c:436)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 allocate request config - (ftx_request_new@filetransfer_request.c:444)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 initialize request config - (ftx_request_new@filetransfer_request.c:448)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 state change undefined -> created - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 append request to list - (ftx_request_new@filetransfer_request.c:453)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 state change created -> sent - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 state change sent -> waiting_for_reply - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (107)HTTPAUTH=-17 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (10002)URL=http://192.168.1.2:8080 - (ftx_curl_setopt_cstring@filetransfer_curl.c:151)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (10023)HTTPHEADER=not null - (ftx_curl_setopt_slist@filetransfer_curl.c:176)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]  date: Fri, 18 Apr 2025 14:22:56 GMT - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]  bbf-report-format: ParameterPerColumn - (ftx_curl_setopt_slist@filetransfer_curl.c:178)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (47)POST=1 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (10015)POSTFIELDS=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (60)POSTFIELDSIZE=91 - (ftx_curl_setopt_long@filetransfer_curl.c:159)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]set opt (20011)WRITEFUNCTION=not null - (ftx_curl_setopt_ptr@filetransfer_curl.c:188)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]Response: len : 429. Reponse: {
    "method": "POST",
    "path": "/",
    "headers": {
        "Host": "192.168.1.2:8080",
        "Accept": "*/*",
        "date": "Fri, 18 Apr 2025 14:22:56 GMT",
        "bbf-report-format": "ParameterPerColumn",
        "Content-Length": "91",
        "Content-Type": "application/x-www-form-urlencoded"
    },
    "body": "ReportTimestamp,MemoryStatusStatus,MemoryStatusFree\r\n,1744986176710,1903288320,1159499776\r\n"
} - (response_callback@filetransfer_curl.c:1094)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]Sending data return code 0 (No error) - (ftx_curl_send_stream@filetransfer_curl.c:1193)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]Content-Type: assume application/octet-stream - (ftx_curl_get_info@filetransfer_curl.c:885)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]request id 7 state change waiting_for_reply -> done - (ftx_request_set_state@filetransfer_request.c:217)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http_put_csv_ppc' - (response_cb@bulkdata_profile_http.c:206)
2025 Apr 18 14:22:56 prplOS tr181-bulkdata: ftx     - [i]delete request id 7 - (ftx_request_delete@filetransfer_request.c:474)
2025 Apr 18 14:22:59 prplOS tr181-bulkdata: events  - [i]Enable changed from "1" to "0" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 14:22:59 prplOS tr181-bulkdata: profile - [i]Stop profile http_put_csv_ppc - (bulkdata_stop_profile@bulkdata_profile.c:384)
```
</details> 



### MQTT Profile
#### 1. Set up MQTT Client
Add a new MQTT client
```bash
# Add MQTT client
MQTT.Client.+{Alias="mqtt_BulkData", Name="mqtt_BulkData"}

MQTT.Client.mqtt_BulkData.BrokerAddress="192.168.25.32"
MQTT.Client.mqtt_BulkData.ProtocolVersion="5.0"
MQTT.Client.mqtt_BulkData.BrokerPort="1883"
MQTT.Client.mqtt_BulkData.TransportProtocol="TCP/IP"
MQTT.Client.mqtt_BulkData.Username="<hidden>"
MQTT.Client.mqtt_BulkData.Username="<hidden>"
MQTT.Client.mqtt_BulkData.Enable=1
MQTT.Client.mqtt_BulkData.ClientID=""
MQTT.Client.mqtt_BulkData.KeepAliveTime=60
```

#### 2. Add MQTT profile
```bash
# Create the profil
BulkData.Profile.+{Alias="mqtt_json_oh", EncodingType="JSON", Name="mqtt_json_oh", Protocol="MQTT", Enable="false", ReportingInterval = 10}

# Set the encoding details
BulkData.Profile.mqtt_json_oh.JSONEncoding.ReportFormat="ObjectHierarchy"
BulkData.Profile.mqtt_json_oh.JSONEncoding.ReportTimestamp="Unix-Epoch"

# Set the MQTT param
BulkData.Profile.mqtt_json_oh.MQTT.PublishTopic="controller/proto::Controller-0914faeadcbe"
BulkData.Profile.mqtt_json_oh.MQTT.Reference="MQTT.Client.5."

# Set which data to send
BulkData.Profile.mqtt_json_oh.Parameter.+{Name="MemoryStatus", Reference="DeviceInfo.MemoryStatus."}

# Enable the profile
BulkData.Profile.mqtt_json_oh.Enable=1
```

#### 3. Check Result

<details>
 <summary>Use "mosquitto_sub" tool to check if the report was sent. – Click to expand</summary>

```bash
mosquitto_sub  -h 192.168.25.32 -u <hidden> -P <hidden> -t controller/proto::Controller-0914faeadcbe -v -d
Client null sending CONNECT
Client null received CONNACK (0)
Client null sending SUBSCRIBE (Mid: 1, Topic: controller/proto::Controller-0914faeadcbe, QoS: 0, Options: 0x00)
Client null received SUBACK
Subscribed (mid: 1): 0
Client null received PUBLISH (d0, q0, r0, m0, 'controller/proto::Controller-0914faeadcbe', ... (105 bytes))
controller/proto::Controller-0914faeadcbe {"Report":[{"MemoryStatus":{"Total":"1903288320","Free":"1160306688"},"CollectionTime":"1744988978271"}]}
```
</details> 


<details>
 <summary>Check the syslog traces. – Click to expand</summary>

```bash
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: profile - [i]Start profile mqtt_json_oh - (bulkdata_start_profile@bulkdata_profile.c:357)
2025 Apr 18 15:09:38 prplOS ba-cli: > BulkData.Profile.mqtt_json_oh.Enable=1
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: mqtt    - [i]Setting up IMTP connection to MQTT.Client.5. - (bulkdata_mqtt_connect@bulkdata_profile_mqtt.c:153)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]CreateListenSocket is called for uri: usp:/var/run/imtp//bulkdata-mqtt-8.sock - (_Client_CreateListenSocket@dm_client_methods.c:134)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Start listening for connections on fd 20 - (_Client_CreateListenSocket@dm_client_methods.c:159)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: imtp    - [i]Creating client stream socket - (imtp_connection_client_stream_socket@imtp_connection.c:155)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: imtp    - [i]Connecting to socket on path = /var/run/imtp//bulkdata-mqtt-8.sock - (imtp_connection_connect@imtp_connection.c:421)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: mqtt    - [i]Connected to fd: [19] - (bulkdata_mqtt_connect@bulkdata_profile_mqtt.c:168)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Sending handshake with value 'proto::tr181-mqtt' - (mqtt_imtp_send_handshake@mqtt_imtp.c:78)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: imtp    - [i]Sending TLV chain over stream socket - (imtp_connection_write_impl@imtp_connection.c:277)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Accepted incoming connection on listen socket with fd: [22] - (mqtt_imtp_connection_accept@mqtt_imtp.c:317)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: profile - [i]Collect profile mqtt_json_oh - (bulkdata_profile_collect@bulkdata_profile.c:284)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]root_object = DeviceInfo - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]key = DeviceInfo.MemoryStatus. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Total = 1903288320 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: paramet - [i]MemoryStatus.Free = 1160306688 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: mqtt    - [i]Sending BulkData report to MQTT client - (bulkdata_profile_mqtt_send_data@bulkdata_profile_mqtt.c:279)
2025 Apr 18 15:09:38 prplOS tr181-bulkdata: imtp    - [i]Sending TLV chain over stream socket - (imtp_connection_write_impl@imtp_connection.c:277)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Incoming message on fd: [22] - (mqtt_imtp_accepted_read@mqtt_imtp.c:202)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Found TLV of type JSON - (mqtt_imtp_unpack_frame@mqtt_imtp.c:131)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Publishing JSON string on topic: controller/proto::Controller-0914faeadcbe - (mqtt_imtp_unpack_and_publish@mqtt_imtp.c:180)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Adding content-type property: application/json; charset=UTF-8 - (mqtt_publish@mqtt_mosquitto_interface.c:866)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]LOG 16 - Client D5DA4A22-22A5-1D40-FCFF-F884092A44CE sending PUBLISH (d0, q1, r0, m2, 'controller/proto::Controller-0914faeadcbe', ... (105 bytes)) - (mqtt_on_log@mqtt_mosquitto_interface.c:449)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]LOG 16 - Client D5DA4A22-22A5-1D40-FCFF-F884092A44CE received PUBACK (Mid: 2, RC:0) - (mqtt_on_log@mqtt_mosquitto_interface.c:449)
2025 Apr 18 15:09:38 prplOS tr181-mqtt: mqtt_cl - [i]Message published - (mqtt_client_published@dm_mqtt_events.c:423)
2025 Apr 18 15:09:40 prplOS tr181-bulkdata: events  - [i]Enable changed from "1" to "0" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
2025 Apr 18 15:09:40 prplOS tr181-bulkdata: profile - [i]Stop profile mqtt_json_oh - (bulkdata_stop_profile@bulkdata_profile.c:384)
2025 Apr 18 15:09:40 prplOS ba-cli: > BulkData.Profile.mqtt_json_oh.Enable=0
2025 Apr 18 15:09:40 prplOS tr181-mqtt: mqtt_cl - [i]Incoming message on fd: [22] - (mqtt_imtp_accepted_read@mqtt_imtp.c:202)
2025 Apr 18 15:09:40 prplOS tr181-mqtt: mqtt_cl - [!]Read fd returned with -1 - (mqtt_imtp_accepted_read@mqtt_imtp.c:205)
2025 Apr 18 15:09:40 prplOS tr181-mqtt: mqtt_cl - [x]Error reading data from socket, removing accepted connection - (mqtt_imtp_accepted_read@mqtt_imtp.c:211)
```
</details> 



### USP Profile
#### 1. Set up of OBUSPA environment
Start the obuspa
```bash
/usr/bin/obuspa -v 4 -s /tmp/broker_cli -r /root/broker_reset.txt -f /etc/obuspa.db
```

<details>
 <summary>broker_reset contains a factory reset database in text format. – Click to expand</summary>

```bash
#
# This file contains a factory reset database in text format
#
# If no USP database exists when OB-USP-AGENT starts, then OB-USP-AGENT will create a database containing
# the parameters specified in a text file located by the '-r' option.
# Example:
#    obuspa -p -v 4 -r factory_reset_example.txt
#
# Each line of this file contains either a comment (denoted by '#' at the start of the line)
# or a USP data model parameter and its factory reset value.
# The parameter and value are separated by whitespace.
# The value may optionally be enclosed in speech marks "" (this is the only way to specify an empty string)
#
##########################################################################################################
#
# Adding MQTT parameters to test the datamodel interface
#

Device.LocalAgent.EndpointID "proto::Agent-0914faeadcbe"

Device.LocalAgent.MTP.1.MQTT.ResponseTopicConfigured "agent/proto::Agent-0914faeadcbe"
Device.LocalAgent.MTP.1.MQTT.Reference "Device.MQTT.Client.1"
Device.MQTT.Client.1.BrokerAddress "192.168.25.32"
Device.MQTT.Client.1.ProtocolVersion "5.0"
Device.MQTT.Client.1.BrokerPort "1883"
Device.MQTT.Client.1.TransportProtocol "TCP/IP"
Device.MQTT.Client.1.Username "<hidden>"
Device.MQTT.Client.1.Password "<hidden>"
Device.MQTT.Client.1.Alias "cpe-1"
Device.MQTT.Client.1.Enable true
Device.MQTT.Client.1.ClientID ""
Device.MQTT.Client.1.KeepAliveTime "60"

Device.MQTT.Client.1.ConnectRetryTime "5"
Device.MQTT.Client.1.ConnectRetryIntervalMultiplier   "2000"
Device.MQTT.Client.1.ConnectRetryMaxInterval "60"

Device.LocalAgent.Controller.1.Alias "cpe-1"
Device.LocalAgent.Controller.1.Enable true
Device.LocalAgent.Controller.1.PeriodicNotifInterval "86400"
Device.LocalAgent.Controller.1.PeriodicNotifTime "0001-01-01T00:00:00Z"
Device.LocalAgent.Controller.1.ControllerCode ""
Device.LocalAgent.Controller.1.MTP.1.Alias "cpe-1"
Device.LocalAgent.Controller.1.MTP.1.Enable true
Device.LocalAgent.Controller.1.MTP.1.Protocol "MQTT"
Device.LocalAgent.Controller.1.EndpointID "proto::Controller-0914faeadcbe"
Device.LocalAgent.Controller.1.MTP.1.MQTT.Reference "Device.MQTT.Client.1"
Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic "controller/proto::Controller-0914faeadcbe"


#
# The following parameters may be modified
#
Device.LocalAgent.MTP.1.Alias "cpe-1"
Device.LocalAgent.MTP.1.Enable true
Device.LocalAgent.MTP.1.Protocol "MQTT"

#
# UDS
#
Device.UnixDomainSockets.UnixDomainSocket.1.Alias "cpe-1"
Device.UnixDomainSockets.UnixDomainSocket.1.Mode "Listen"
Device.UnixDomainSockets.UnixDomainSocket.1.Path "/var/run/usp/broker_controller_path"
Device.UnixDomainSockets.UnixDomainSocket.2.Alias "cpe-2"
Device.UnixDomainSockets.UnixDomainSocket.2.Mode "Listen"
Device.UnixDomainSockets.UnixDomainSocket.2.Path "/var/run/usp/broker_agent_path"
```
</details> 

<details>
 <summary>Check if the mqtt client in created and connected. – Click to expand</summary>

```bash
ba-cli
2025-04-18T15:31:21Z - root - [mod_ba connection] (0)
 > list

usp:/var/run/usp/broker_agent_path
usp:/var/run/usp/broker_controller_path

exit

ba-cli
root - * - [bus-cli] (0)
 > Device.MQTT.Client.?
Device.MQTT.Client.1.
Device.MQTT.Client.1.ALPN=""
Device.MQTT.Client.1.Alias="cpe-1"
Device.MQTT.Client.1.BrokerAddress="192.168.25.32"
Device.MQTT.Client.1.BrokerPort=1883
Device.MQTT.Client.1.CleanSession=1
Device.MQTT.Client.1.CleanStart=1
Device.MQTT.Client.1.ClientID="98BDDF3D-8D2E-79CE-7080-A4E3B99CEF86"
Device.MQTT.Client.1.ConnectRetryIntervalMultiplier=2000
Device.MQTT.Client.1.ConnectRetryMaxInterval=60
Device.MQTT.Client.1.ConnectRetryTime=5
Device.MQTT.Client.1.Enable=1
Device.MQTT.Client.1.KeepAliveTime=60
Device.MQTT.Client.1.Name=""
Device.MQTT.Client.1.Password=""
Device.MQTT.Client.1.ProtocolVersion=5.000000
Device.MQTT.Client.1.RequestResponseInfo=0
Device.MQTT.Client.1.ResponseInformation=""
Device.MQTT.Client.1.Status="Connected"
Device.MQTT.Client.1.SubscriptionNumberOfEntries=0
Device.MQTT.Client.1.TransportProtocol="TCP/IP"
Device.MQTT.Client.1.Username="sah_usp"


```
</details> 

#### 2. Deploy a secondary environment for capturing USP events.
For this example, I used a Docker container that runs the SoftAtHome USP controller `uspc` and `tr181-mqtt` along with the `mosquitto_pub` tool.

##### 2.1 MQTT client.
<details>
 <summary>Create MQTT client. – Click to expand</summary>

```bash
> MQTT.Client.2.?
MQTT.Client.2.
MQTT.Client.2.Alias="cpe-1"
MQTT.Client.2.BrokerAddress="192.168.25.32"
MQTT.Client.2.BrokerPort=1883
MQTT.Client.2.CleanSession=1
MQTT.Client.2.CleanStart=1
MQTT.Client.2.ClientID="48B5FE71-14CC-0123-FB04-454E3C71CDC4"
MQTT.Client.2.ConnectRetryIntervalMultiplier=2000
MQTT.Client.2.ConnectRetryMaxInterval=5120
MQTT.Client.2.ConnectRetryTime=5
MQTT.Client.2.Enable=1
MQTT.Client.2.ForceReconnect=0
MQTT.Client.2.Interface=""
MQTT.Client.2.KeepAliveTime=60
MQTT.Client.2.MessageRetryTime=5
MQTT.Client.2.Name=""
MQTT.Client.2.Password="broker_password"
MQTT.Client.2.ProtocolVersion="5.0"
MQTT.Client.2.ResponseInformation=""
MQTT.Client.2.Status="Connected"
MQTT.Client.2.SubscriptionNumberOfEntries=1
MQTT.Client.2.TransportProtocol="TCP/IP"
MQTT.Client.2.Username="sah_usp"
MQTT.Client.2.X_SOFTATHOME-COM_AutoReconnect=0
MQTT.Client.2.Stats.
MQTT.Client.2.Stats.BrokerConnectionEstablished="2025-04-17T11:35:54.764030578Z"
MQTT.Client.2.Stats.ConnectionErrors=0
MQTT.Client.2.Stats.LastPublishMessageReceived="0001-01-01T00:00:00Z"
MQTT.Client.2.Stats.LastPublishMessageSent="0001-01-01T00:00:00Z"
MQTT.Client.2.Stats.MQTTMessagesReceived=0
MQTT.Client.2.Stats.MQTTMessagesSent=0
MQTT.Client.2.Stats.PublishErrors=0
MQTT.Client.2.Stats.PublishReceived=10
MQTT.Client.2.Stats.PublishSent=5
MQTT.Client.2.Stats.SubscribeSent=2
MQTT.Client.2.Stats.UnSubscribeSent=0
MQTT.Client.2.Subscription.2.
MQTT.Client.2.Subscription.2.Alias="cpe-Subscription-2"
MQTT.Client.2.Subscription.2.Enable=1
MQTT.Client.2.Subscription.2.QoS=0
MQTT.Client.2.Subscription.2.Status="Subscribed"
MQTT.Client.2.Subscription.2.Topic="controller/proto::Controller-0914faeadcbe"
```
</details> 


##### 2.2 Local Controller.
<details>
 <summary>Check the local controller is attached with the correct MQTT client.. – Click to expand</summary>

```bash
> LocalController.?
LocalController
LocalController.ActiveMTP=LocalController.MTP.mtp-mqtt-controller
LocalController.Enable=1
LocalController.EndpointID=proto::Controller-0914faeadcbe
LocalController.SoftwareVersion=2.0.9
LocalController.UpTime=10279
LocalController.SupportedProtocols=MQTT,IMTP
LocalController.MTPNumberOfEntries=1
LocalController.AgentNumberOfEntries=0
LocalController.MTP
LocalController.MTP.mtp-mqtt-controller
LocalController.MTP.mtp-mqtt-controller.Alias=mtp-mqtt-controller
LocalController.MTP.mtp-mqtt-controller.Enable=1
LocalController.MTP.mtp-mqtt-controller.Status=Up
LocalController.MTP.mtp-mqtt-controller.Error=
LocalController.MTP.mtp-mqtt-controller.Protocol=MQTT
LocalController.MTP.mtp-mqtt-controller.MQTT
LocalController.MTP.mtp-mqtt-controller.MQTT.Reference=MQTT.Client.cpe-1.
LocalController.MTP.mtp-mqtt-controller.MQTT.ResponseTopicConfigured=controller/proto::Controller-0914faeadcbe
LocalController.MTP.mtp-mqtt-controller.MQTT.ResponseTopicDiscovered=
LocalController.MTP.mtp-mqtt-controller.MQTT.PublishQoS=0
LocalController.Agent
```
</details> 


##### 2.3 Check USP communication with freedom board and add a new `Push` subscription
<details>
 <summary>for this action, a usp_get is used. – Click to expand</summary>

```bash
LocalController.usp_get("proto::Agent-0914faeadcbe", {paths: ["Device.LocalAgent."], max_depth: 1})
LocalController.usp_get(MTP=LocalController.MTP.mtp-mqtt-controller) done
[2025-04-17T14:27:14Z] LocalController[usp:response|1000]{response=
[
    {
        result             : 
        {
            err_code       : 0,
            requested_path : Device.LocalAgent.
        },
        Device.LocalAgent. : 
        {
            UpTime                          : 547,
            SubscriptionNumberOfEntries     : 3,
            MTPNumberOfEntries              : 1,
            X_VANTIVA-COM_PreConnectTimeout : 60,
            ControllerNumberOfEntries       : 48,
            RequestNumberOfEntries          : 0,
            CertificateNumberOfEntries      : 0,
            EndpointID                      : proto::Agent-0914faeadcbe,
            SupportedProtocols              : STOMP, MQTT, UDS,
            SoftwareVersion                 : 9.0.8,
            SupportedFingerprintAlgorithms  : SHA-1, SHA-224, SHA-256, SHA-384, SHA-512
        }
    }
], header=
{
    type    : 2,
    msg_id  : 5,
    from_id : proto::Agent-0914faeadcbe,
    to_id   : proto::Controller-0914faeadcbe
}, object=LocalController., eobject=LocalController., path=LocalController.}

```
</details> 

<details>
 <summary>Add the sub in via your local controller. – Click to expand</summary>

```bash
LocalController.usp_add("proto::Agent-0914faeadcbe",{allow_partial: true, requests: [{object_path: "Device.LocalAgent.Subscription.", parameters: [{param: "ReferenceList", value: "Device.BulkData.Profile.*.Push!", required: false}, {param: "NotifType", value:  "Event", required: false}, {param: "Enable", value: "true"}]}]})		

LocalController.usp_add(MTP=LocalController.MTP.mtp-mqtt-controller) done
[2025-04-18T15:47:10Z] LocalController[usp:response|1000]{response=
[
    {
        result     : 
        {
            err_code       : 0,
            requested_path : Device.LocalAgent.Subscription.
        },
        object     : Device.LocalAgent.Subscription.1.,
        index      : 1,
        name       : cpe-1,
        parameters : 
        {
            Recipient : Device.LocalAgent.Controller.1,
            ID        : cpe-1,
            Alias     : cpe-1
        },
        path       : Device.LocalAgent.Subscription.1.
    }
], header=
{
    type    : 9,
    msg_id  : 12,
    from_id : proto::Agent-0914faeadcbe,
    to_id   : proto::Controller-0914faeadcbe
}, object=LocalController., eobject=LocalController., path=LocalController.}

```
</details> 



#### 3. Testing USP profile
On the freedom board:

<details>
 <summary>Add a new USP profile. – Click to expand</summary>

```bash
obuspa -s /tmp/broker_cli -c add Device.BulkData.Profile.
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Alias "USPEventNotif"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.EncodingType "JSON"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Name "USPEventNotif"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Protocol "USPEventNotif"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Enable false
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.ReportingInterval 10

obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.JSONEncoding.ReportFormat "ObjectHierarchy"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.JSONEncoding.ReportTimestamp "Unix-Epoch"


obuspa -s /tmp/broker_cli -c add Device.BulkData.Profile.1.Parameter
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Parameter.1.Name "MemoryStatus"
obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Parameter.1.Reference "Device.DeviceInfo.MemoryStatus."


obuspa -s /tmp/broker_cli -c set Device.BulkData.Profile.1.Enable true
```
</details> 


<details>
 <summary>check the obuspa logs and see push event on obuspa logs. – Click to expand</summary>

```bash
USP Record received at time 2025-04-18T15:54:43Z, from endpoint_id=proto::usp-953964809 over UDS (Broker's Agent path)
SET : processing at time 2025-04-18T15:54:43Z
SET_RESP sending at time 2025-04-18T15:54:43Z, to host proto::usp-953964809 over UDS
Sending USP RECORD to endpoint_id=proto::usp-953964809 on Broker's Agent path
GET sending at time 2025-04-18T15:54:48Z, to host proto::deviceinfo-manager over UDS
Sending USP RECORD to endpoint_id=proto::deviceinfo-manager on Broker's Controller path
USP Record received at time 2025-04-18T15:54:48Z, from endpoint_id=proto::deviceinfo-manager over UDS (Broker's Controller path)
Sending NotifyRequest (Event for path=Device.BulkData.Profile.1.Push!)
NOTIFY sending at time 2025-04-18T15:54:48Z, to host 192.168.25.32 over MQTT
Received PUBACK frame from (host=192.168.25.32, port=1883, mid=8)


```
</details> 


<details>
 <summary>check the logs where your controller is installed. – Click to expand</summary>

```bash

sudo tail -F /var/log/messages

Apr 18 15:54:48 0914faeadcbe tr181-mqtt: mqtt_cl - [i]LOG 16 - Client 48B5FE71-14CC-0123-FB04-454E3C71CDC4 received PUBLISH (d0, q0, r0, m0, 'controller/proto::Controller-0914faeadcbe', ... (302 bytes)) - (mqtt_on_log@mqtt_mosquitto_interface.c:449)
Apr 18 15:54:48 0914faeadcbe tr181-mqtt: mqtt_cl - [i]Message received for client - cpe-1 - (mqtt_client_message@dm_mqtt_events.c:335)
Apr 18 15:54:48 0914faeadcbe tr181-mqtt: mqtt_cl - [i]sending event [cpe-1] [controller/proto::Controller-0914faeadcbe] - (send_amx_event@dm_mqtt_events.c:321)
Apr 18 15:54:48 0914faeadcbe tr181-mqtt: mqtt_cl - [i]Sending message to agent with response-topic agent/proto::Agent-0914faeadcbe pattern controller/proto::Controller-0914faeadcbe - (mqtt_imtp_forward_message@mqtt_imtp.c:365)


```
</details> 
