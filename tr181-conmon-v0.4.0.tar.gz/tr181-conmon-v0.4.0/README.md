# tr181-conmon

![Conmon logo](doc/img/conmon_overview.png)

## Introduction
`tr181-conmon` is a plugin design to monitor the DHCP connection state of the given interfaces.

## Architecture

The global architecture consists of the `tr181-conmon` plugin, which open various netmodel queries to get information about the netorwk interfaces (interface state, dhcp state, WAN IP, DHCP valid route). The plugin implements the `mod-discoping` module that periodically sends ARP/NS messages and restart the DHCP client if needed.

### Components

1. **tr181-conmon**:
    - Opens netmodel queries to listen on the interface status, interface IP, DHCPvX status, and DHCPvX default route.
        - For IPv4: Default route provided by DHCPv4 (option 3) is monitored
        - For IPv6: Default route provided by Router Advertisement is monitored
    - Manages and updates the datamodel 
    - Communicates the configuration change to the `mod-discoping` module.

2. **mod-discoping**:
    - Periodically sends ARP (for IPv4) and Neignbor Sollicitation (for IPv6) heartbeats messages based on the timing provided by `tr181-conmon`.
    - Updates the statistics and `tr181-conmon` status  
    - Restarts the DHCP clients if needed.

### Workflow

 1. **Network/DHCP Netmodel Notifications**
    - Receives asynchronous updates for several flags and parameters from netmodel.
    - If the interface and DHCP is up, an IP is set and a default route is avaible, the plugins will start monitoring the default route by sending ARP/NS heartbeats via the `mod-discoping` module.

 2. **Network Failure Detection**
    - After that the configured number of failed ARP/NS messages is reached, the `mod-discoping` module restarts the DHCP client and updates the statistics and status.

 3. **Configuration Updates**
    - When the timeout configuration is changed via the datamodel, the plugin sends the necessary settings to the `mod-discoping` module.

### Features

 1. **WAN IPv4 Monitoring**
    - Send ARP (Address Resolution Protocol) heartbeat every MainInterval seconds to the interface default route.
    - If there is no response after ResponseTimeout, a new ARP message is sent every FailInterval seconds.
    - If none attempt is successful after NumberOfRetries, the DHCPv4 client Enabled parameter is toggle to restart a new DORA cycle.

 2. **WAN IPv6 Monitoring**
    - Send NS (Neighbor Sollication) heartbeat every MainInterval seconds to the interface default route.
    - If there is no response after ResponseTimeout, a new NS message is sent every FailInterval seconds.
    - If none attempt is successful after NumberOfRetries, the DHCPv6 client Enabled parameter is toggle to restart a new DORA cycle.

## Building, Installing, and Testing

### Docker Container

You can install all the necessary tools for testing and developing on your local machine or use a pre-configured environment. A pre-configured environment is available as a Docker container.

1. **Install Docker**:

    Docker must be installed on your system. Here are some links that could help you:

    - [Get Docker Engine - Community for Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

    Make sure your user ID is added to the Docker group:

        sudo usermod -aG docker $USER

2. **Fetch the Container Image**:

    To get access to the pre-configured environment, pull the image and launch a container.

    Pull the image:

        docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    Before launching the container, create a directory that will be shared between your local machine and the container.

        mkdir -p ~/amx/libraries/

    Launch the container:

        docker run -ti -d \
            --name oss-dbg \
            --restart=always \
            --cap-add=SYS_PTRACE \
            --sysctl net.ipv6.conf.all.disable_ipv6=1 \
            -e "USER=$USER" \
            -e "UID=$(id -u)" \
            -e "GID=$(id -g)" \
            -v ~/amx:/home/$USER/amx \
            registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    The `-v` option bind mounts the local directory for the AMX project in the container, at the exact same place. The `-e` options create environment variables in the container. These variables are used to create a user name with the same user ID and group ID in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

        docker exec -ti --user $USER oss-dbg /bin/bash

### Building

#### Prerequisites

`tr181-conmon` depends on the following libraries:

 * amxrt
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxrt
 * libdiscoping
 * libnetmodel
 * libsahtrace
 * mod-dmext

These libraries can be installed in the container:

    sudo apt-get install libamxb libamxc libamxd libamxm libamxo libamxp mod-sahtrace sah-lib-sahtrace-dev libnetmodel libdiscoping mod-dmext

### Testing

#### Prerequisites

No extra components are needed for testing `tr181-conmon`.

#### Run tests

You can run the tests by executing the following command:

    ```bash
    cd ~/amx/plugins/tr181-conmon/test
    make
    ```

Or this command if you also want the coverage tests to run:

    ```bash
    cd ~/amx/plugins/tr181-conmon/tests
    make run coverage
    ```

You can combine both commands:

    ```bash
    cd ~/amx/plugins/tr181-conmon
    make test
    ```

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each C file is printed in your console after the tests are run. An HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used. For example, when using native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/amx/plugins/tr181-conmon/output/x86_64-linux-gnu/coverage/report`.

You can easily access the reports in your browser. In the container, start a python3 HTTP server in the background.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-conmon/output/<MACHINE>/coverage/report
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/tr181-conmon$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/tr181-conmon/output/x86_64-linux-gnu/coverage/report/`

### Documentation

#### Prerequisites

To generate the documentation, [Doxygen](https://www.doxygen.nl) is required and already available in the container. In case you want to install this on your local machine:

    ```bash
    sudo apt-get install doxygen
    ```

#### Paths

The documentation is split into two parts, starting from the repository path:

    ```bash
    cd ~/amx/plugins/tr181-conmon
    ```

Here, you can find:

- `README.md`: This file is used on GitLab and is the main page for the Doxygen documentation.
- `docs` directory: Contains the Doxygen settings, code examples, and additional pages used in Doxygen.

The code itself is documented in the appropriate header and source files.

#### Generate documentation

To generate the documentation, Doxygen needs to be installed. Alternatively, `amxo-cg` and `amxo-xml-to` packages can be installed to generate the documentation. You can generate the documentation by executing the following command:

    ```bash
    cd ~/amx/plugins/tr181-conmon
    make doc
    ```

The full documentation is available in the `output` directory. You can easily access the documentation in your browser. As described in the coverage reports section, you can start an HTTP server in the container.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-conmon/output/html/index.html
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/tr181-conmon$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/tr181-conmon/output/html/index.html`

Alternatively, you can open the documentation via command:

    ```bash
    xdg-open tr181-conmon/output/html/index.html
    ```