/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__QOS_CLASSIFICATION_H__)
#define __QOS_CLASSIFICATION_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup qos_classification QoS Classification Management
 * @ingroup tr181-qos
 * @brief Functions and data structures for managing QoS.Classification instance objects.
 * @{
 */

#include <stdint.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <fwrules/fw_folder.h>
#include <fwrules/fw_rule.h>
#include <fwrules/fw.h>
#include <fwinterface/interface.h>
#include <netmodel/common_api.h>

#include "qos-config.h"

#define QOS_TR181_DEVICE_QOS_CLASSIFICATION_PATH "QoS.Classification"
#define QOS_TR181_DEVICE_QOS_CLASSIFICATION_INSTANCE "QoS.Classification."
#define QOS_TR181_DEVICE_QOS_CLASSIFICATION_OBJECT_NAME "Classification"
#define MAX_ALIAS_LEN 64
#define MAX_IP_LEN 39

typedef struct _qos_classification_device qos_classification_device_t;

// Struct to track interace queries and interface rules that may need to be updated when interfaces
// are updated
typedef struct _qos_classification_interface {
    netmodel_query_t* query_input_interface;       /**< Netmodel query for input interface */
    netmodel_query_t* query_output_interface;      /**< Netmodel query for output interface */
    char* netdev_input_interface;                  /**< NetDevName for input interface */
    char* netdev_output_interface;                 /**< NetDevName for output interface */
    fw_rule_t* rule_input_interface;               /**< Firewall rule for input interface */
    fw_rule_t* rule_output_interface;              /**< Firewall rule for output interface */
} qos_classification_interface_t;

//! [architecture classification struct]
typedef struct _qos_classification {
    amxd_object_t* dm_object; /**< The data model object */
    fw_folder_t* folder4;
    fw_folder_t* folder6;
    bool ip_based;            /**< Default true; set to false if device based classification */
    qos_classification_interface_t* class_intf;
    qos_classification_interface_t* class_bridge_intf;
    qos_classification_device_t* class_device;
} qos_classification_t;
//! [architecture classification struct]

fw_folder_t* qos_classification_get_folder(const qos_classification_t* const classification);
amxd_object_t* qos_classification_get_dm_object(const qos_classification_t* const classification);
static inline bool qos_classification_dm_get_enable(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "Enable", NULL);
}
static inline uint32_t qos_classification_dm_get_order(const qos_classification_t* const classification) {
    return classification == NULL ? 0 : amxd_object_get_value(uint32_t, classification->dm_object, "Order", NULL);
}
static inline const char* qos_classification_dm_get_alias(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "Alias"));
}
static inline const char* qos_classification_dm_get_dest_ip(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestIP"));
}
static inline const char* qos_classification_dm_get_dest_mask(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestMask"));
}
static inline bool qos_classification_dm_get_dest_ip_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DestIPExclude", NULL);
}
static inline bool qos_classification_dm_get_source_ip_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "SourceIPExclude", NULL);
}
static inline const char* qos_classification_dm_get_source_ip(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceIP"));
}
static inline const char* qos_classification_dm_get_source_mask(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceMask"));
}
static inline const char* qos_classification_dm_get_interface(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "Interface"));
}
static inline int32_t qos_classification_dm_get_dscp_check(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "DSCPCheck", NULL);
}
static inline int32_t qos_classification_dm_get_protocol(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "Protocol", NULL);
}
static inline bool qos_classification_dm_get_protocol_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "ProtocolExclude", NULL);
}
static inline int32_t qos_classification_dm_get_dest_port(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "DestPort", NULL);
}
static inline int32_t qos_classification_dm_get_dest_port_range_max(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "DestPortRangeMax", NULL);
}
static inline bool qos_classification_dm_get_dest_port_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DestPortExclude", NULL);
}
static inline int32_t qos_classification_dm_get_source_port(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "SourcePort", NULL);
}
static inline int32_t qos_classification_dm_get_source_port_range_max(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "SourcePortRangeMax", NULL);
}
static inline bool qos_classification_dm_get_source_port_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "SourcePortExclude", NULL);
}
static inline const char* qos_classification_dm_get_source_mac_address(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceMACAddress"));
}
static inline bool qos_classification_dm_get_source_mac_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "SourceMACExclude", NULL);
}
static inline int32_t qos_classification_dm_get_dscp_mark(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "DSCPMark", NULL);
}
static inline int32_t qos_classification_dm_get_ethernet_priority_check(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "EthernetPriorityCheck", NULL);
}
static inline int32_t qos_classification_dm_get_ethernet_priority_mark(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "EthernetPriorityMark", NULL);
}
static inline uint32_t qos_classification_dm_get_ip_length_min(const qos_classification_t* const classification) {
    return classification == NULL ? 0 : amxd_object_get_value(uint32_t, classification->dm_object, "IPLengthMin", NULL);
}
static inline uint32_t qos_classification_dm_get_ip_length_max(const qos_classification_t* const classification) {
    return classification == NULL ? 0 : amxd_object_get_value(uint32_t, classification->dm_object, "IPLengthMax", NULL);
}
static inline const char* qos_classification_dm_get_dest_mac_address(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestMACAddress"));
}
static inline bool qos_classification_dm_get_dest_mac_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DestMACExclude", NULL);
}
static inline int32_t qos_classification_dm_get_traffic_class(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "TrafficClass", NULL);
}
static inline uint32_t qos_classification_dm_get_forwarding_policy(const qos_classification_t* const classification) {
    return classification == NULL ? 0 : amxd_object_get_value(uint32_t, classification->dm_object, "ForwardingPolicy", NULL);
}
static inline bool qos_classification_dm_get_dscp_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DSCPExclude", NULL);
}
static inline uint32_t qos_classification_dm_get_mark_check(const qos_classification_t* const classification) {
    uint32_t retval = 0;
    amxc_string_t* mark_check_name_prefixed = NULL;
    if(classification != NULL) {
        mark_check_name_prefixed = qos_config_get_prefixed_parameter("MarkCheck");
        if(mark_check_name_prefixed != NULL) {
            retval = amxd_object_get_value(uint32_t, classification->dm_object, amxc_string_get(mark_check_name_prefixed, 0), NULL);
            amxc_string_delete(&mark_check_name_prefixed);
        }
    }
    return retval;
}
static inline uint32_t qos_classification_dm_get_mark_mask(const qos_classification_t* const classification) {
    uint32_t retval = 0;
    amxc_string_t* mark_mask_name_prefixed = NULL;
    if(classification != NULL) {
        mark_mask_name_prefixed = qos_config_get_prefixed_parameter("MarkMask");
        if(mark_mask_name_prefixed != NULL) {
            retval = amxd_object_get_value(uint32_t, classification->dm_object, amxc_string_get(mark_mask_name_prefixed, 0), NULL);
            amxc_string_delete(&mark_mask_name_prefixed);
        }
    }
    return retval;
}
static inline bool qos_classification_dm_get_return(const qos_classification_t* const classification) {
    bool retval = false;
    amxc_string_t* return_prefixed = NULL;
    if(classification != NULL) {
        return_prefixed = qos_config_get_prefixed_parameter("Return");
        if(return_prefixed != NULL) {
            retval = amxd_object_get_value(bool, classification->dm_object, amxc_string_get(return_prefixed, 0), NULL);
            amxc_string_delete(&return_prefixed);
        }
    }
    return retval;
}
static inline int32_t qos_classification_dm_get_ip_version(const qos_classification_t* const classification) {
    return classification == NULL ? -1 : amxd_object_get_value(int32_t, classification->dm_object, "IPVersion", NULL);
}
static inline uint32_t qos_classification_dm_get_classification_key(const qos_classification_t* const classification) {
    return classification == NULL ? 1 : amxd_object_get_value(uint32_t, classification->dm_object, "ClassificationKey", NULL);
}
static inline const char* qos_classification_dm_get_dhcp_type(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DHCPType"));
}
static inline const char* qos_classification_dm_get_source_vendor_class_id(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceVendorClassID"));
}
static inline const char* qos_classification_dm_get_source_vendor_class_id_v6(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceVendorClassIDv6"));
}
static inline bool qos_classification_dm_get_source_vendor_class_id_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "SourceVendorClassIDExclude", NULL);
}
static inline const char* qos_classification_dm_get_source_vendor_class_id_mode(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceVendorClassIDMode"));
}
static inline const char* qos_classification_dm_get_dest_vendor_class_id(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestVendorClassID"));
}
static inline const char* qos_classification_dm_get_dest_vendor_class_id_v6(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestVendorClassIDv6"));
}
static inline bool qos_classification_dm_get_dest_vendor_class_id_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DestVendorClassIDExclude", NULL);
}
static inline const char* qos_classification_dm_get_dest_vendor_class_id_mode(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestVendorClassIDMode"));
}
static inline const char* qos_classification_dm_get_source_user_class_id(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "SourceUserClassID"));
}
static inline bool qos_classification_dm_get_source_user_class_id_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "SourceUserClassIDExclude", NULL);
}
static inline const char* qos_classification_dm_get_dest_user_class_id(const qos_classification_t* const classification) {
    return classification == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(classification->dm_object, "DestUserClassID"));
}
static inline bool qos_classification_dm_get_dest_user_class_id_exclude(const qos_classification_t* const classification) {
    return classification == NULL ? false : amxd_object_get_value(bool, classification->dm_object, "DestUserClassIDExclude", NULL);
}
static inline bool qos_classification_dhcp_type_is_dhcpv4(const qos_classification_t* const classification) {
    return classification == NULL ? true : (strncmp(qos_classification_dm_get_dhcp_type(classification), "DHCPv4", strlen("DHCPv4")) == 0);
}

const char* qos_classification_dm_get_output_interface(const qos_classification_t* const classification);
const char* qos_classification_dm_get_direction(const qos_classification_t* const classification);
const char* qos_classification_dm_get_bridge_input_interface(const qos_classification_t* const classification);
const char* qos_classification_dm_get_bridge_output_interface(const qos_classification_t* const classification);

/**
 * @ingroup qos_classification
 * @brief Gets the value of the DoNotOffload parameter for a QoS.Classification instance object.
 *
 * Retrieves the value of the DoNotOffload parameter from the data model object associated
 * with the specified QoS classification instance.
 *
 * @param classification Pointer to the QoS classification instance object.
 * @return true if DoNotOffload is enabled, false otherwise.
 */
bool qos_classification_dm_get_do_not_offload(const qos_classification_t* const classification);


int qos_classification_new(qos_classification_t** classification, amxd_object_t* classification_instance);
int qos_classification_init(qos_classification_t* const classification, amxd_object_t* const classification_instance);
int qos_classification_delete(qos_classification_t** classification);
int qos_classification_deinit(qos_classification_t* const classification);

bool fw_rule_callback(const fw_rule_t* const rule, const fw_rule_flag_t flag, const char* chain, const char* table, int index);

int qos_classification_reset_folders(const qos_classification_t* const classification);
int qos_classification_activate(const qos_classification_t* const classification);
int qos_classification_deactivate(const qos_classification_t* const classification);

int qos_classification_dm_set_enable(const qos_classification_t* classification, const bool enable);
int qos_classification_dm_set_order(const qos_classification_t* const classification, const uint32_t order);
int qos_classification_dm_set_dest_ip_exclude(const qos_classification_t* const classification, const bool destipexclude);

int qos_classification_activate_failed(const qos_classification_t* const classification);

void qos_classification_input_interface_netdevname_changed(const char* sig_name, const amxc_var_t* data, void* priv);
void qos_classification_output_interface_netdevname_changed(const char* sig_name, const amxc_var_t* data, void* priv);
void qos_classification_bridge_input_interface_netdevname_changed(const char* sig_name, const amxc_var_t* data, void* priv);
void qos_classification_bridge_output_interface_netdevname_changed(const char* sig_name, const amxc_var_t* data, void* priv);

/** @} */ // end of qos_classification group

#ifdef __cplusplus
}
#endif

#endif // __QOS_CLASSIFICATION_H__
