/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

#define ME "tmp_cycl"

static int update_temp_dm(amxd_object_t* tempsensor_obj, const char* status) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t retval = amxd_status_unknown_error;
    amxd_trans_t trans;
    tempsensor_info_t* tempsensor_info = NULL;

    amxd_trans_init(&trans);

    when_str_empty_trace(status, exit, ERROR, "Status empty");
    when_null_trace(tempsensor_obj, exit, ERROR, "Temperature sensor object empty");
    tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    when_null_trace(tempsensor_info, exit, ERROR, "Tempsensor_info is empty");

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, tempsensor_obj);

    amxd_trans_set_value(cstring_t, &trans, "Status", status);
    if(!strcmp(status, TEMPSENSOR_ST_DISABLED) || !strcmp(status, TEMPSENSOR_ST_ERROR)) {
        goto trans_apply;
    }
    amxd_trans_set_value(int32_t, &trans, "Value", tempsensor_info->value);

    amxc_ts_to_local(&(tempsensor_info->last_update));
    amxd_trans_set_value(amxc_ts_t, &trans, "LastUpdate", &(tempsensor_info->last_update));

    amxd_trans_set_value(int32_t, &trans, "MinValue", tempsensor_info->min_value);
    amxc_ts_to_local(&(tempsensor_info->min_time));
    amxd_trans_set_value(amxc_ts_t, &trans, "MinTime", &(tempsensor_info->min_time));

    amxd_trans_set_value(int32_t, &trans, "MaxValue", tempsensor_info->max_value);
    amxc_ts_to_local(&(tempsensor_info->max_time));
    amxd_trans_set_value(amxc_ts_t, &trans, "MaxTime", &(tempsensor_info->max_time));

    amxc_ts_to_local(&(tempsensor_info->low_alarm_time));
    amxd_trans_set_value(amxc_ts_t, &trans, "LowAlarmTime", &(tempsensor_info->low_alarm_time));

    amxc_ts_to_local(&(tempsensor_info->high_alarm_time));
    amxd_trans_set_value(amxc_ts_t, &trans, "HighAlarmTime", &(tempsensor_info->high_alarm_time));

trans_apply:
    retval = amxd_trans_apply(&trans, get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction with code %d", retval);
    }

exit:
    amxd_trans_clean(&trans);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

void update_temp_dm_n_struct(amxp_timer_t* timer, void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* tempsensor_obj = (amxd_object_t*) priv;
    tempsensor_info_t* tempsensor_info = NULL;
    int32_t bad_temp = get_bad_temp();
    int32_t temp = 0;
    amxc_ts_t the_time;
    const char* status = NULL;

    when_null(tempsensor_obj, exit);
    tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    when_null(tempsensor_info, exit);

    // Probe the temperature of the sensor or check the status
    temp = probe_tempsensor(tempsensor_info);
    if((temp == bad_temp) || !tempsensor_info->enabled || tempsensor_info->err) {
        status = tempsensor_info->enabled ? TEMPSENSOR_ST_ERROR : TEMPSENSOR_ST_DISABLED;
        SAH_TRACEZ_INFO(ME, "Temperature sensor state: Temp = %d, Enabled = %d, err = %d", temp, tempsensor_info->enabled, tempsensor_info->err);
        goto skip_update_struct;
    } else {
        status = TEMPSENSOR_ST_ENABLED;
    }

    // Some time
    amxc_ts_now(&the_time);
    // Minimum value
    if((temp < tempsensor_info->min_value) || (tempsensor_info->min_value == bad_temp)) {
        tempsensor_info->min_value = temp;
        tempsensor_info->min_time = the_time;
    }
    // Maximum value
    if((temp > tempsensor_info->max_value) || (tempsensor_info->max_value == bad_temp)) {
        tempsensor_info->max_value = temp;
        tempsensor_info->max_time = the_time;
    }
    // Low alarm
    if((temp < tempsensor_info->low_alarm_value) && (tempsensor_info->low_alarm_value != bad_temp) && tempsensor_info->low_alarm_set) {
        tempsensor_info->low_alarm_time = the_time;
        tempsensor_info->low_alarm_set = false;
    }
    // High alarm
    if((temp > tempsensor_info->high_alarm_value) && ((tempsensor_info->high_alarm_value != bad_temp) && tempsensor_info->high_alarm_set)) {
        tempsensor_info->high_alarm_time = the_time;
        tempsensor_info->high_alarm_set = false;
    }
    // Measured value
    tempsensor_info->value = temp;
    tempsensor_info->last_update = the_time;
    tempsensor_handle_alarms(tempsensor_info);

skip_update_struct:

    // Set the values in the datamodel
    if(update_temp_dm(tempsensor_obj, status) != amxd_status_ok) {
        tempsensor_info->err = true;
    }

    // Stop timer depending on the state
    if(strcmp(status, TEMPSENSOR_ST_ENABLED)) {
        int32_t retry_max = get_retry();
        if((((int32_t) tempsensor_info->polling_retry_count >= retry_max) && (retry_max != -1)) || (!tempsensor_info->enabled)) {
            SAH_TRACEZ_ERROR(ME, "Timer stopped, invalid temperature sensor state - %s after %d try", status, tempsensor_info->polling_retry_count);
            amxp_timer_stop(timer);
            tempsensor_info->polling_retry_count = 0;
        } else {
            tempsensor_info->polling_retry_count += 1;
            if((retry_max != -1) && (tempsensor_info->polling_retry_count % (retry_max / 5) == 0 )) {
                SAH_TRACEZ_WARNING(ME, "Unable to read temperature sensor on try : %d", tempsensor_info->polling_retry_count);
            }
        }
    } else {
        tempsensor_info->polling_retry_count = 0;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}
