# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.7.0 - 2025-11-10(13:54:36 +0000)

## Release v0.6.0 - 2025-11-10(13:45:38 +0000)

## Release v0.5.1 - 2025-11-10(12:30:17 +0000)

### Other

- [gmap] port upnp module to prpl foundation

## Release v0.5.0 - 2025-06-04(06:51:31 +0000)

### Other

- [AppAmor][gmap-mod-*] AppAmor profile should be created for all gmap modules

## Release v0.4.1 - 2024-11-13(07:53:58 +0000)

### Other

- Rare crash on handling gmap query

## Release v0.4.0 - 2024-10-25(12:13:17 +0000)

### Other

- [gmap][mod-upnp] fill in server value

## Release v0.3.2 - 2024-09-26(14:33:33 +0000)

### Other

- [gmap][mod-upnp] upnp module crashes sometimes together with upnpdiscovery

## Release v0.3.1 - 2024-07-29(08:22:49 +0000)

### Other

- [gmap][mod-upnp] Add FriendlyName

## Release v0.3.0 - 2024-05-07(11:12:38 +0000)

### Other

- [gmap][mod-homeplug][mod-upnp] Adapt modules to new link API

## Release v0.2.2 - 2024-04-11(13:23:21 +0000)

### Other

- [gmap][mod-upnp] parentDevice path in UPnPDescription changed

## Release v0.2.1 - 2024-04-10(10:05:43 +0000)

### Changes

- Make amxb timeouts configurable

## Release v0.2.0 - 2023-10-26(07:59:26 +0000)

### Other

- [amx][gmap] move non-generic functions out of libgmap-client

## Release v0.1.9 - 2023-10-24(12:16:59 +0000)

### Other

- [GMAP] Server parameter is missing for upnp devices

## Release v0.1.8 - 2023-10-19(14:35:15 +0000)

### Other

- [gmap][mod-upnp] Fill the ModelName parameter

## Release v0.1.7 - 2023-10-19(09:44:04 +0000)

### Other

- [gmap][mod-upnp] Not use the UDN as Alias anymore, only index

## Release v0.1.6 - 2023-09-28(10:38:40 +0000)

### Other

- [gmap] [self] [mod] Self can be started after the modules, causing some detection issues.

## Release v0.1.5 - 2023-09-07(12:12:59 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release v0.1.4 - 2023-08-17(13:22:28 +0000)

### Other

- [gmap][mod-upnp] index in the 'ParentDevice' path does not work

## Release v0.1.3 - 2023-08-03(11:36:56 +0000)

### Other

- [gmap][mod-upnp] Obsolete code needs removal

## Release v0.1.2 - 2023-08-01(13:30:57 +0000)

### Other

- [gmap][mod-upnp] Services added before the device in UPnPDescription are not added in gmap

## Release v0.1.1 - 2023-07-20(12:50:52 +0000)

### Other

- [AMX][GMAP] gmap server crashes in the automated tests caused by a segmentation fault in mod_upnp

## Release v0.1.0 - 2023-05-04(14:30:51 +0000)

### Other

- [gmap][UPNPDiscovery] Add UPNP support in gMap

## Release v0.1.0 - 2023-01-23(11:37:46 +0000)

### Other

- [amx][gmap] Expose upnp information in gMap

