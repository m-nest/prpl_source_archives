/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef WSN_EXCHANGE_H
#define WSN_EXCHANGE_H

#include "wsn_common.h"

#define EXCHANGE_TYPE_MAX_LEN 64
#define DEFAULT_RATE 10
#define MAX_RATE 100

/**
 * @brief Structure representing a Exchange
 */
typedef struct {
    unsigned int rate;                        /* Inter-measurement interval in multiples of 10ms */
    unsigned int bandwidth;                   /* Requested bandwidth, in MHz, on which to report */
    char exchangetype[EXCHANGE_TYPE_MAX_LEN]; /* Exchange Type for the radio to which the Transmitter is associated */
    unsigned int datatype;                    /* Exchange Type for the radio to which the Receiver is associated */
    swl_macBin_t transmitter;                 /* MAC address of the STA transmitting the frame on which CSI data will be gathered */
    swl_macBin_t receiver;                    /* MAC address of the STA receiving the frame on which CSI data will be gathered */
    amxd_object_t* object;
} wsn_exchange_t;

typedef struct {
    char* radioPath;
    char* supportedDataTypes;
    char* supportedExchangeTypes;
    amxc_llist_it_t it;
} wsn_sensingCaps_t;

typedef struct {
    char* radioPath;
    char* operatingBandwidths;
    amxc_llist_it_t it;
} wsn_supportedRadioBandwidth_t;

amxd_status_t _RemoveExchange(amxd_object_t* obj,
                              amxd_function_t* func _UNUSED,
                              amxc_var_t* args,
                              amxc_var_t* ret _UNUSED);

/*
 * @brief enum define all exchangeTerminated event causes
 */
typedef enum {
    WSN_EXCHANGE_TERM_EVENT_REASON_STA_UNAVAIL,     /* STA no longer available */
    WSN_EXCHANGE_TERM_EVENT_REASON_RAD_UNAVAIL,     /* Radio shut down */
    WSN_EXCHANGE_TERM_EVENT_REASON_COMPLETED,       /* Single-shot measurement acquired */
    WSN_EXCHANGE_TERM_EVENT_REASON_STA_REJECTED,    /* STA rejected measurement during the polling phase */
    WSN_EXCHANGE_TERM_EVENT_REASON_RESOURCE_UNAVAIL /* Lower layer is unable to perform all the requested measurement exchanges */
} wsn_exchange_termEvent_reason_e;

void wsn_exchangeTerminated_event_cb(const char* const sig_name _UNUSED,
                                     const amxc_var_t* const data,
                                     void* const priv _UNUSED);

#endif /* __WSN_EXCHANGE_H__ */
