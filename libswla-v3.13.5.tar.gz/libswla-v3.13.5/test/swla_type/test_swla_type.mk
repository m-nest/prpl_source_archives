SUT_OBJECTS += $(SUT_DIR)/src/swla_type.o \
				$(SUT_DIR)/src/swla_conversion.o \
				$(SUT_DIR)/src/swla_typeDefs.o \
				$(SUT_DIR)/src/swla_delayExec.o\
				$(SUT_DIR)/src/swla_lib.o\
				$(SUT_DIR)/src/swla_object.o\

CFLAGS +=  -I$(TYPE_DIR)
LDFLAGS += -lm
