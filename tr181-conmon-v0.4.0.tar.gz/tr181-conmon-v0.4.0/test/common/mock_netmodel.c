/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include "mock_netmodel.h"

#include <setjmp.h>
#include <cmocka.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

bool __wrap_netmodel_initialize(void) {
    return true;
}

void __wrap_netmodel_cleanup(void) {
    return;
}

netmodel_query_t* __wrap_netmodel_openQuery_getFirstParameter(const char* intf,
                                                              const char* subscriber,
                                                              const char* name,
                                                              UNUSED const char* flag,
                                                              const char* traverse,
                                                              amxp_slot_fn_t handler,
                                                              void* userdata) {
    amxc_var_t data;
    amxc_var_init(&data);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_non_null(name);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_set(int32_t, &data, 2000);
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;
}

netmodel_query_t* __wrap_netmodel_openQuery_luckyAddrAddress(const char* intf,
                                                             const char* subscriber,
                                                             const char* flag,
                                                             const char* traverse,
                                                             amxp_slot_fn_t handler,
                                                             void* userdata) {
    amxc_var_t data;
    amxc_var_init(&data);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_non_null(flag);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_set(int32_t, &data, 2000);
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;

}

netmodel_query_t* __wrap_netmodel_openQuery_hasFlag(const char* intf,
                                                    const char* subscriber,
                                                    const char* flag,
                                                    const char* condition,
                                                    const char* traverse,
                                                    amxp_slot_fn_t handler,
                                                    void* userdata) {

    amxc_var_t data;
    amxc_var_init(&data);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_non_null(flag);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);
    assert_true(strcmp(condition, "") == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_set(int8_t, &data, 1);
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;
}

amxc_var_t* __wrap_netmodel_getFirstParameter(UNUSED const char* intf,
                                              UNUSED const char* name,
                                              UNUSED const char* flag,
                                              UNUSED const char* traverse) {
    amxc_var_t* data;
    amxc_var_new(&data);
    amxc_var_set(cstring_t, data, "eth0");
    return data;
}

netmodel_query_t* __wrap_netmodel_openQuery_luckyIntf(const char* intf,
                                                      const char* subscriber,
                                                      UNUSED const char* flag,
                                                      const char* traverse,
                                                      amxp_slot_fn_t handler,
                                                      UNUSED void* userdata) {
    amxc_var_t data;
    amxc_var_init(&data);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_non_null(intf);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_set(cstring_t, &data, "eth0");
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;
}

netmodel_query_t* __wrap_netmodel_openQuery_isUp(const char* intf,
                                                 const char* subscriber,
                                                 UNUSED const char* flag,
                                                 const char* traverse,
                                                 amxp_slot_fn_t handler,
                                                 UNUSED void* userdata) {
    amxc_var_t data;
    amxc_var_init(&data);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_set(int8_t, &data, 1);
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;
}

netmodel_query_t* __wrap_netmodel_openQuery_getDHCPOption(const char* intf,
                                                          const char* subscriber,
                                                          UNUSED const char* type,
                                                          UNUSED uint16_t tag,
                                                          const char* traverse,
                                                          amxp_slot_fn_t handler,
                                                          void* userdata) {
    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_LIST);

    assert_non_null(traverse);
    assert_non_null(handler);
    assert_true(strcmp(subscriber, PLUGIN_NAME) == 0);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    netmodel_query_t* q = malloc(sizeof(netmodel_query_t*));

    amxc_var_add(cstring_t, &data, "172.16.120.10");
    handler(NULL, &data, userdata);
    amxc_var_clean(&data);
    return q;
}

char* __wrap_netmodel_luckyAddrAddress(const char* intf, const char* flag, const char* traverse) {
    char* addr = NULL;

    assert_non_null(traverse);
    assert_true(strncmp(intf, "Device.Logical.", strlen("Device.Logical.")) == 0);

    if(strcmp(flag, "ipv6 && @gua")) {
        addr = strdup("2a02:1802:94:4200:10:18ff:fe01:701");
    }

    return addr;
}

void __wrap_netmodel_closeQuery(netmodel_query_t* query) {
    free(query);
}
