/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>

#include "mod-routing-dhcp.h"

#define ME "mod-routing-dhcp"
#define PREFIX "cpe-dhcp-"
#define ALIAS_SIZE 43
#define TIMEOUT 10

static mod_routing_dhcp_t routing_dhcp;

/**
 * @brief
 * Hash function for alias creation
 *
 * @param str String to hash
 * @return uint16_t Hashed string
 */
static uint16_t hash(const char* str) {
    uint16_t hash = 5381;
    int c;

    while((c = *str++)) {
        hash = ((hash << 5) + hash) ^ c; /* hash * 33 ^ c */
    }

    return hash;
}

/**
 * @brief
 *  Delete function to remove the IPv4Forwarding entry in dm and cleaning memory
 *
 * @param key Key of the hashtable entry
 * @param hit Hashtable iterator
 */
static void routing_htable_entry_delete(UNUSED const char* key, amxc_htable_it_t* hit) {
    routing_object_entry_t* data = amxc_htable_it_get_data(hit, routing_object_entry_t, it);
    amxd_object_t* obj = NULL;
    int index = 0;
    amxd_trans_t trans;

    amxd_trans_init(&trans);

    obj = amxd_dm_findf(routing_dhcp.dm, "Routing.Router.main.IPv4Forwarding.[Alias == '%s']", data->name);
    when_null_trace(obj, exit, ERROR, "No object found");
    index = amxd_object_get_index(obj);
    when_false_trace(index != 0, exit, ERROR, "No object found");

    amxd_trans_select_object(&trans, amxd_dm_findf(routing_dhcp.dm, "Routing.Router.main.IPv4Forwarding."));
    amxd_trans_del_inst(&trans, index, NULL);
    when_failed_trace(amxd_trans_apply(&trans, routing_dhcp.dm), exit, ERROR, "Cannot delete created object");
exit:
    amxd_trans_clean(&trans);
    free(data->name);
    free(data);
}

/**
 * @brief
 * Delete function to clean memory of dhcpv4 client state object
 *
 * @param key Key of the hashtable entry
 * @param hit Hashtable iterator
 */
static void routing_htable_dhcp_entry_delete(UNUSED const char* key, amxc_htable_it_t* hit) {
    routing_dhcp_entry_t* data = amxc_htable_it_get_data(hit, routing_dhcp_entry_t, it);
    amxb_bus_ctx_t* ctx = amxb_be_who_has("DHCPv4Client.Client.");
    amxb_unsubscribe(ctx, data->obj_path, mod_routing_possible_router_changed, NULL);
    if(data->netmodel_option_121_query != NULL) {
        netmodel_closeQuery(data->netmodel_option_121_query);
        data->netmodel_option_121_query = NULL;
    }
    amxc_htable_delete(&data->routing_created_htable, routing_htable_entry_delete);
    free(data->obj_path);
    free(data->interface);
    free(data->name);
    free(data);
    return;
}

/**
 * @brief
 * Create an IPv4forwarding object and add it to the data model
 *
 * @param dhcp_entry The related dhcpv4 client object that it is derived from
 * @param destination The destination of the route
 * @param route The route it self
 * @param prefix_length The prefix length of the route
 */
static void routing_create_entry(routing_dhcp_entry_t* dhcp_entry, const char* destination, const char* route, uint32_t prefix_length) {
    int ret = 1;
    amxd_trans_t trans;
    char* subnetmask = malloc(16);
    uint32_t mask = 0xFFFFFFFF;
    char* name = malloc(ALIAS_SIZE);
    routing_object_entry_t* entry = calloc(1, sizeof(routing_object_entry_t));

    amxd_trans_init(&trans);

    when_null_trace(destination, exit, ERROR, "No destination ip given");
    when_null_trace(route, exit, ERROR, "No router ip given");
    when_false_trace(prefix_length != 0, exit, ERROR, "no subnetmask given");

    mask <<= (32 - prefix_length);
    sprintf(subnetmask, "%d.%d.%d.%d", (mask >> 24) & 0xFF, (mask >> 16) & 0xFF, (mask >> 8) & 0xFF, mask & 0xFF);

    snprintf(name, ALIAS_SIZE, PREFIX "%d-%d", hash(destination), hash(route));

    amxd_trans_select_pathf(&trans, "Routing.Router.main.IPv4Forwarding.");
    amxd_trans_add_inst(&trans, 0, name);

    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "DestIPAddress", destination);
    amxd_trans_set_value(cstring_t, &trans, "DestSubnetMask", subnetmask);
    amxd_trans_set_value(cstring_t, &trans, "Interface", dhcp_entry->interface);
    amxd_trans_set_value(cstring_t, &trans, "Origin", "DHCPv4");
    when_failed_trace(amxd_trans_apply(&trans, routing_dhcp.dm), exit, ERROR, "Cannot add forward entry");

    entry->name = strdup(name);
    when_null_trace(entry->name, exit, ERROR, "Failed to allocate entry name");
    entry->need_del = false;
    ret = amxc_htable_insert(dhcp_entry->routing_created_htable, entry->name, &entry->it);
    when_false_trace(ret == 0, exit, ERROR, "Unable to add entry %s", entry->name);
    entry = NULL; // entry ownership passed to htable
exit:
    if(entry != NULL) {
        free(entry->name);
        free(entry);
    }
    free(name);
    free(subnetmask);
    amxd_trans_clean(&trans);
    return;
}

/**
 * @brief
 * Callback function for the dhcpv4 client option 121
 *
 * @param sig_name Name of the signal event
 * @param datas Data of the event signal
 * @param priv Private data (NULL)
 */
static void routing_dhcp_option_121_cb(UNUSED const char* const sig_name,
                                       const amxc_var_t* const datas,
                                       void* const priv) {
    routing_dhcp_entry_t* dhcp_entry = (routing_dhcp_entry_t*) priv;
    char* name = malloc(ALIAS_SIZE);

    when_null_trace(datas, exit, INFO, "no data in option 121");
    when_null_trace(priv, exit, ERROR, "no data entry found related to the query");

    amxc_htable_for_each(hit, dhcp_entry->routing_created_htable) {
        routing_object_entry_t* data = amxc_htable_it_get_data(hit, routing_object_entry_t, it);
        data->need_del = true;
    }

    amxc_var_for_each(data, datas) {
        amxc_htable_it_t* hit = NULL;
        const char* destination = GET_CHAR(data, "Destination");
        const char* router = GET_CHAR(data, "Router");
        uint32_t prefix_length = GET_UINT32(data, "PrefixLength");

        snprintf(name, ALIAS_SIZE, PREFIX "%d-%d", hash(destination), hash(router));

        if((hit = amxc_htable_get(dhcp_entry->routing_created_htable, name)) == NULL) {
            routing_create_entry(dhcp_entry, destination, router, prefix_length);
        } else {
            routing_object_entry_t* entry = amxc_htable_it_get_data(hit, routing_object_entry_t, it);
            entry->need_del = false;
        }
    }

    amxc_htable_for_each(hit, dhcp_entry->routing_created_htable) {
        routing_object_entry_t* data = amxc_htable_it_get_data(hit, routing_object_entry_t, it);
        if(data->need_del) {
            amxc_htable_it_clean(hit, routing_htable_entry_delete);
        }
    }
exit:
    free(name);
    return;
}

/**
 * @brief
 * Update function if the Interface of the dhcpv4 client have changed
 *
 * @param event_data The event data of the dm:object-change of the dhcpv4 client
 * @param entry The dhcpv4 client object that have already been created
 */
static void update_routing_dhcp_entry(const amxc_var_t* const event_data, routing_dhcp_entry_t* entry) {
    amxc_var_t* interface_var = NULL;

    when_null_trace(event_data, exit, ERROR, "No data to get parameter from");
    when_null_trace(entry, exit, ERROR, "No entry to update");

    interface_var = GETP_ARG(event_data, "parameters.Interface");

    if((interface_var != NULL) && ((entry->interface == NULL) || (strcmp(entry->interface, GET_CHAR(interface_var, "to"))))) {
        free(entry->interface);
        entry->interface = strdup(GET_CHAR(interface_var, "to"));
        if(entry->netmodel_option_121_query != NULL) {
            netmodel_closeQuery(entry->netmodel_option_121_query);
            entry->netmodel_option_121_query = NULL;
            amxc_htable_delete(&entry->routing_created_htable, routing_htable_entry_delete);
            amxc_htable_new(&entry->routing_created_htable, 0);
        }
        entry->netmodel_option_121_query = netmodel_openQuery_getDHCPOption(entry->interface,
                                                                            "routing_dhcp",
                                                                            "req",
                                                                            121,
                                                                            netmodel_traverse_down,
                                                                            routing_dhcp_option_121_cb,
                                                                            entry);
        when_null_trace(entry->netmodel_option_121_query, exit, ERROR, "Failed to add addr query to netmodel");
    }
exit:
    return;
}

/**
 * @brief
 * Create a dhcpv4 object to keep track of change and subscribe to a dhcpv4 client dm. It also creat a subscription to the dhcpv4 client if its dm change
 *
 * @param name Name of the dhcpv4 client
 * @param interface Listening interface of the dhcpv4 client
 * @param obj_path Path in the dm of the dhcpv4 client
 */
static void create_routing_dhcp_entry(const char* name, const char* interface, const char* obj_path) {
    int ret = -1;
    routing_dhcp_entry_t* entry = NULL;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("DHCPv4Client.Client.");
    amxc_string_t exps;

    amxc_string_init(&exps, 0);

    when_null_trace(name, exit, ERROR, "no name given for entry");
    when_null_trace(obj_path, exit, ERROR, "No object path given");

    entry = calloc(1, sizeof(routing_dhcp_entry_t));

    entry->name = strdup(name);
    entry->obj_path = strdup(obj_path);
    amxc_htable_new(&entry->routing_created_htable, 0);
    if((interface != NULL) && (interface[0] != '\0')) {
        entry->interface = strdup(interface);
        entry->netmodel_option_121_query = netmodel_openQuery_getDHCPOption(interface,
                                                                            "routing_dhcp",
                                                                            "req",
                                                                            121,
                                                                            netmodel_traverse_down,
                                                                            routing_dhcp_option_121_cb,
                                                                            entry);
        when_null_trace(entry->netmodel_option_121_query, clean, ERROR, "Failed to add addr query to netmodel");
    }

    ret = amxc_htable_insert(routing_dhcp.forward_htable, entry->name, &entry->it);
    when_false_trace(ret == 0, clean, ERROR, "Unable to add entry %s", name);
    amxc_string_setf(&exps, "notification == 'dm:object-changed' && path == '%s'", obj_path);
    int status = amxb_subscribe(ctx, obj_path, amxc_string_get(&exps, 0), mod_routing_possible_router_changed, NULL);
    when_false_trace(status == AMXB_STATUS_OK, exit, ERROR, "Failed to subscribe to %s (status=%d)", obj_path, status);
exit:
    amxc_string_clean(&exps);
    return;
clean:
    amxc_string_clean(&exps);
    free(entry->name);
    free(entry->obj_path);
    free(entry->interface);
    free(entry);
    return;
}

/**
 * @brief
 * Detect if a new dhcpv4 client is added
 *
 * @param event_name == dm:instance-added
 * @param event_data data of the newly added dhcpv4 client
 * @param priv Private data (NULL)
 */
void mod_routing_possible_router_added(UNUSED const char* const event_name,
                                       const amxc_var_t* const event_data,
                                       UNUSED void* const priv) {
    const char* name = NULL;
    const char* path = NULL;
    amxc_htable_it_t* hit = NULL;
    amxc_string_t obj_path;

    amxc_string_init(&obj_path, 0);

    SAH_TRACEZ_ERROR(ME, "New dhcpv4 client added detected");

    when_null_trace(event_data, exit, ERROR, "Invalid event_data");

    name = GET_CHAR(event_data, "name");
    when_null_trace(name, exit, ERROR, "No name given to dhcpv4 client");

    path = GET_CHAR(event_data, "path");
    when_null_trace(path, exit, ERROR, "no DHCPv4Client.Client. path given");

    amxc_string_setf(&obj_path, "%s%s.", path, name);

    hit = amxc_htable_get(routing_dhcp.forward_htable, name);
    if(hit == NULL) {
        create_routing_dhcp_entry(name, GETP_CHAR(event_data, "parameters.Interface"), amxc_string_get(&obj_path, 0));
    }
exit:
    amxc_string_clean(&obj_path);
    return;
}

/**
 * @brief
 * Function called when an already created object from a dhcpv4 client is changed in the data model
 *
 * @param event_name == dm:object-changed
 * @param event_data data of the changed event
 * @param priv Private data (NULL)
 */
void mod_routing_possible_router_changed(UNUSED const char* const event_name,
                                         const amxc_var_t* const event_data,
                                         UNUSED void* const priv) {
    amxc_htable_it_t* hit = NULL;
    amxc_var_t ret;
    amxc_string_t str_path;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("DHCPv4Client.Client.");
    const char* path = NULL;
    const char* name = NULL;

    SAH_TRACEZ_ERROR(ME, "dhcpv4 client object change detected");

    amxc_string_init(&str_path, 0);
    amxc_var_init(&ret);

    when_null_trace(event_data, exit, ERROR, "Invalid event_data name");

    path = GET_CHAR(event_data, "path");
    when_str_empty_trace(path, exit, ERROR, "Path not given for changed dhcpv4 client");

    amxc_string_setf(&str_path, "%sAlias", path);

    if(ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to lookup DHCPv4Client.Client. bus");
    }

    when_failed_trace(amxb_get(ctx, amxc_string_get(&str_path, 0), 0, &ret, TIMEOUT), exit, ERROR, "cannot get name of dhcpv4 client");

    name = GETP_CHAR(&ret, "0.0.Alias");
    hit = amxc_htable_get(routing_dhcp.forward_htable, name);

    when_null_trace(hit, exit, ERROR, "DHCPv4 client need to update but not in htable");
    update_routing_dhcp_entry(event_data, amxc_htable_it_get_data(hit, routing_dhcp_entry_t, it));
exit:
    amxc_string_clean(&str_path);
    amxc_var_clean(&ret);
    return;
}

/**
 * @brief
 * Function called when a dhcpv4 client is removed, it clean the related object created and clen the IPv4Forwarding entries created
 *
 * @param event_name == dm:object-delete
 * @param event_data Data of the delete event
 * @param priv Private data (NULL)
 */
void mod_routing_possible_router_removed(UNUSED const char* const event_name,
                                         const amxc_var_t* const event_data,
                                         UNUSED void* const priv) {
    amxc_htable_it_t* hit = NULL;
    const char* name = NULL;

    SAH_TRACEZ_INFO(ME, "dhcpv4 client removed");

    when_null_trace(event_data, exit, ERROR, "Invalid event_data name");

    name = GET_CHAR(event_data, "name");
    when_null_trace(name, exit, ERROR, "Cannot get object name");
    hit = amxc_htable_get(routing_dhcp.forward_htable, name);
    when_null_trace(hit, exit, INFO, "No entry found for removed forwarding");
    amxc_htable_it_clean(hit, routing_htable_dhcp_entry_delete);
exit:
    return;
}

/**
 * @brief
 * Initialisation of memory and read the dm of DHCPv4Client.Client to add already present client. It also create the subscription to the DHCP4Client.Client dm
 */
static void routing_dhcp_init(void) {
    amxb_bus_ctx_t* ctx = amxb_be_who_has("DHCPv4Client.Client.");
    amxc_var_t ret;

    amxc_var_init(&ret);

    when_null_trace(ctx, exit, ERROR, "No dhcpv4 client plugin found.");

    when_failed_trace(amxb_get(ctx, "DHCPv4Client.Client.", 0, &ret, TIMEOUT), exit, ERROR, "cannot get already present dhcpv4 clients");

    when_null_trace(ctx, exit, ERROR, "No dhcpv4 client plugin found.");

    amxc_var_for_each(dhcpclient, GETP_ARG(&ret, "0.")) {
        const char* name = GET_CHAR(dhcpclient, "Alias");
        const char* interface = GET_CHAR(dhcpclient, "Interface");
        amxc_string_t path;

        amxc_string_init(&path, 0);
        if((name != NULL) && (name[0] != '\0')) {
            amxc_string_setf(&path, "DHCPv4Client.Client.%s.", name);
            create_routing_dhcp_entry(name, interface, amxc_string_get(&path, 0));
        }
        amxc_string_clean(&path);
    }

    when_failed_trace(amxb_subscribe(ctx, "DHCPv4Client.Client.", "notification == 'dm:instance-added' && path == 'DHCPv4Client.Client.'", mod_routing_possible_router_added, NULL), exit, ERROR, "Failed to subscribe to DHCPv4Client.Client instance-added");
    when_failed_trace(amxb_subscribe(ctx, "DHCPv4Client.Client.", "notification == 'dm:instance-removed' && path == 'DHCPv4Client.Client.'", mod_routing_possible_router_removed, NULL), exit, ERROR, "Failed to subscribe to DHCPv4Client.Client instance-removed");
exit:
    amxc_var_clean(&ret);
    return;
}

/**
 * @brief
 * Clean the subscribtion to the DHCPv4Client.Client dm
 */
static void routing_dhcp_clean(void) {
    amxb_bus_ctx_t* ctx = amxb_be_who_has("DHCPv4Client.Client.");

    when_null_trace(ctx, exit, ERROR, "No dhcpv4 client plugin found.");

    amxb_unsubscribe(ctx, "DHCPv4Client.Client.", mod_routing_possible_router_added, NULL);
    amxb_unsubscribe(ctx, "DHCPv4Client.Client.", mod_routing_possible_router_removed, NULL);

exit:
    return;
}

/**
 * @brief
 * Entry point of the module
 *
 * @param reason State to change the plugin to
 * @param dm Linked dm
 * @param parser Parser that called the entry point
 * @return int 0 if succeed
 */
int _mod_routing_dhcp_main(int reason,
                           amxd_dm_t* dm,
                           amxo_parser_t* parser) {
    int retval = 0;
    SAH_TRACE_IN();
    switch(reason) {
    case 0:
        routing_dhcp.dm = dm;
        routing_dhcp.parser = parser;
        netmodel_initialize();
        routing_dhcp_init();
        break;
    case 1:
        routing_dhcp_clean();
        netmodel_cleanup();
        routing_dhcp.dm = NULL;
        routing_dhcp.parser = NULL;
        break;
    }
    SAH_TRACE_OUT();
    return retval;
}

static AMXM_CONSTRUCTOR mod_routing_dhcp_construct(void) {
    SAH_TRACEZ_IN(ME);
    amxc_htable_new(&routing_dhcp.forward_htable, 0);
    SAH_TRACEZ_OUT(ME);
    return 0;
}

static AMXM_DESTRUCTOR mod_routing_dhcp_destruct(void) {
    SAH_TRACEZ_IN(ME);
    amxc_htable_delete(&routing_dhcp.forward_htable, routing_htable_dhcp_entry_delete);
    SAH_TRACEZ_OUT(ME);
    return 0;
}
