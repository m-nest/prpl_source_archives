/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <inttypes.h>
#include <stdarg.h>
#include <signal.h>
#include <endian.h>
#include <libmnl/libmnl.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nfnetlink_conntrack.h>
#include <linux/netfilter/nf_conntrack_common.h>
#include <linux/netfilter/nf_conntrack_tcp.h>

#define MAX_NUM_ENTRIES 256
#define SIZE_PER_ENTRY  256

#define BUFSIZE (MAX_NUM_ENTRIES * SIZE_PER_ENTRY)  // allocated space for 256 entries of size 128 bytes
#define CONSOLE_PRINT 1
#define VALID_TUPLE_CNT 5

static int filter_proto = -1;
static char* filter_src_ip = NULL;
static char* filter_dst_ip = NULL;
static int filter_sport = -1;
static int filter_dport = -1;
static char* filter_name = NULL;
static int max_conn_entries = -1;
static char buf[BUFSIZE];
static char* line_buff = NULL;


/*
 * @breif Connection tracking entry structure
 * This structure holds attributes for representing conntrack entry during retrieval
 */

typedef struct centry {
    struct centry* next;            /* next */
    uint64_t ts_created;            /* time stamp created */
    char line_buf[SIZE_PER_ENTRY];  /* buffer to store the conn log */
} conn_entry;


/* brief: connection tracking entry list */
static conn_entry* conn_list = NULL;

void list_conntrack_entries();

/**
 * @brief creates a new connection tracking entry object
 *
 * @param void
 * @return conn_entry* returns a pointer to the new conntrack entry object
 */
conn_entry* new_conn_entry (void) {
    return(calloc(1, sizeof(conn_entry)));
}

/**
 * @brief Add connection entries
 *
 * the connection entry is added after its parameters have been populated and
 * the entry now gets inserted in the list, in the descending order of timestamp
 * therefore the list is now a Least recently created connection track entries
 *
 * @param entry	pointer to conntrack entries of type struct conn_entry
 * @return void
 */
void add_conn_entry(conn_entry* entry) {
    if(!conn_list || (entry->ts_created >= conn_list->ts_created)) {
        // Insert at the head
        entry->next = conn_list;
        conn_list = entry;
        return;
    }

    conn_entry* current = conn_list;
    while(current->next && current->next->ts_created > entry->ts_created) {
        current = current->next;
    }

    // Insert after current
    entry->next = current->next;
    current->next = entry;
}

/**
 * @brief writes the sorted entries to a /tmp file so that manager can retrieve it
 *
 * Function to write the sorted entries to a /tmp file so that manager can retrieve it
 *
 * @param void
 * @return void
 */
void write_conn_entries_to_file(void) {
    char filename[256];
    FILE* fp = NULL;

    sprintf(filename, "/tmp/ct_retrieve_%s.txt", filter_name);
    fp = fopen(filename, "w");
    if(!fp) {
        perror("Failed to open file");
        return;
    }

    conn_entry* current = conn_list;
    int count = 0;
    while(current && count < max_conn_entries) {
        fprintf(fp, "%s", current->line_buf);  // Assuming line_buf contains formatted output
        current = current->next;
        count++;
    }

    fclose(fp);
    return;
}


/**
 * @brief conntrack_retreive main function, it receives the 5 tuple as filters
 * conntrack_retreive main function, it receives the 5 tuple as filters and filters the appropriate conntract entries
 *
 * @param argc	number of arguments
 * @param argv	arguments
 *
 * @return int return 0 on success
 */
int main(int argc, char* argv[]) {

    // Parse command-line arguments for filters
    for(int i = 1; i < argc; i++) {
        if(strncmp(argv[i], "--proto=", 8) == 0) {
            if(strcmp(argv[i] + 8, "tcp") == 0) {
                filter_proto = 6;
            } else if(strcmp(argv[i] + 8, "udp") == 0) {
                filter_proto = 17;
            }
        } else if(strncmp(argv[i], "--src-ip=", 9) == 0) {
            filter_src_ip = argv[i] + 9;
        } else if(strncmp(argv[i], "--dst-ip=", 9) == 0) {
            filter_dst_ip = argv[i] + 9;
        } else if(strncmp(argv[i], "--sport=", 8) == 0) {
            filter_sport = atoi(argv[i] + 8);
        } else if(strncmp(argv[i], "--dport=", 8) == 0) {
            filter_dport = atoi(argv[i] + 8);
        } else if(strncmp(argv[i], "--name=", 7) == 0) {
            filter_name = argv[i] + 7;
        } else if(strncmp(argv[i], "--r_size=", 9) == 0) {
            max_conn_entries = atoi(argv[i] + 9);
        }
    }

    if(!filter_name) {
        filter_name = "default";
    }
    if(max_conn_entries == -1) {
        max_conn_entries = MAX_NUM_ENTRIES;
    }

    list_conntrack_entries();

    return EXIT_SUCCESS;

}

/**
 * @brief updates the connection tracking entry to a memory location
 * that is pointing to the buffer of a connection entry
 * watch out that line_buff is a global variable as it overcomes the
 * constraint of being logged through various mnl callbacks
 *
 * @param format pointer to format specifier
 * @return void
 */
void update_conntrack_entry_log(const char* format, ...) {
    va_list args;

#ifdef CONSOLE_PRINT
    // Print to console
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
#endif

    va_start(args, format);
    line_buff += vsprintf(line_buff, format, args);
    va_end(args);
}

/**
 * @brief callback function to parse the ip from the attributes
 *
 * Callback function to parse the ip from the attributes
 *
 * @param attr	pointer to netlink attribute type
 * @param data	void pointer to the passed data which will be parsed
 */
static int parse_ip_cb(const struct nlattr* attr, void* data) {

    const struct nlattr** tb = data;
    int type = mnl_attr_get_type(attr);

    if(mnl_attr_type_valid(attr, CTA_IP_MAX) < 0) {
        return MNL_CB_OK;
    }

    switch(type) {

    case CTA_IP_V4_SRC:
    case CTA_IP_V4_DST:
        if(mnl_attr_validate(attr, MNL_TYPE_U32) < 0) {
            return MNL_CB_ERROR;
        }
        break;

    case CTA_IP_V6_SRC:
    case CTA_IP_V6_DST:
        if(mnl_attr_validate2(attr, MNL_TYPE_BINARY,
                              sizeof(struct in6_addr)) < 0) {
            return MNL_CB_ERROR;
        }
        break;
    }
    tb[type] = attr;
    return MNL_CB_OK;
}

/**
 * @brief function to print/update the IP parameters to the log file
 *
 * @param nest pointer to netlink attribute structure
 * @return void
 */
static void print_ip(const struct nlattr* nest) {

    struct nlattr* tb[CTA_IP_MAX + 1] = {};

    mnl_attr_parse_nested(nest, parse_ip_cb, tb);

    if(tb[CTA_IP_V4_SRC]) {
        struct in_addr* in = mnl_attr_get_payload(tb[CTA_IP_V4_SRC]);
        update_conntrack_entry_log("src=%s ", inet_ntoa(*in));

    }

    if(tb[CTA_IP_V4_DST]) {
        struct in_addr* in = mnl_attr_get_payload(tb[CTA_IP_V4_DST]);
        update_conntrack_entry_log("dst=%s ", inet_ntoa(*in));
    }

    if(tb[CTA_IP_V6_SRC]) {
        struct in6_addr* in = mnl_attr_get_payload(tb[CTA_IP_V6_SRC]);
        char out[INET6_ADDRSTRLEN];

        if(!inet_ntop(AF_INET6, in, out, sizeof(out))) {
            update_conntrack_entry_log("src=%s ", out);
        }
    }

    if(tb[CTA_IP_V6_DST]) {
        struct in6_addr* in = mnl_attr_get_payload(tb[CTA_IP_V6_DST]);
        char out[INET6_ADDRSTRLEN];

        if(!inet_ntop(AF_INET6, in, out, sizeof(out))) {
            update_conntrack_entry_log("dst=%s ", out);
        }

    }
}

/**
 * @brief callback function to parse the proto from the attributes
 * Callback function to parse the protocol from the attributes
 *
 * @param attr  pointer to netlink attribute type
 * @param data  void pointer to the passed data which will be parsed
 */
static int parse_proto_cb(const struct nlattr* attr, void* data) {
    const struct nlattr** tb = data;
    int type = mnl_attr_get_type(attr);

    if(mnl_attr_type_valid(attr, CTA_PROTO_MAX) < 0) {
        return MNL_CB_OK;
    }

    switch(type) {

    case CTA_PROTO_NUM:
        if(mnl_attr_validate(attr, MNL_TYPE_U8) < 0) {
            return MNL_CB_ERROR;
        }
        break;

    case CTA_PROTO_SRC_PORT:
    case CTA_PROTO_DST_PORT:
        if(mnl_attr_validate(attr, MNL_TYPE_U16) < 0) {
            return MNL_CB_ERROR;
        }
        break;
    }

    tb[type] = attr;
    return MNL_CB_OK;
}


/**
 * @brief function to print/update the protocol parameters to the log file
 *
 * @param nest pointer to netlink attribute structure
 * @return void
 */
static void print_proto(const struct nlattr* nest) {
    struct nlattr* tb[CTA_PROTO_MAX + 1] = {};

    mnl_attr_parse_nested(nest, parse_proto_cb, tb);
    if(tb[CTA_PROTO_NUM]) {
        update_conntrack_entry_log("proto=%u ", mnl_attr_get_u8(tb[CTA_PROTO_NUM]));
    }

    if(tb[CTA_PROTO_SRC_PORT]) {
        update_conntrack_entry_log("sport=%u ",
                                   ntohs(mnl_attr_get_u16(tb[CTA_PROTO_SRC_PORT])));
    }

    if(tb[CTA_PROTO_DST_PORT]) {
        update_conntrack_entry_log("dport=%u ",
                                   ntohs(mnl_attr_get_u16(tb[CTA_PROTO_DST_PORT])));
    }
}

/**
 * @brief callback function to parse the tuple from the attributes
 * Callback function to parse the tuple from the attributes
 *
 * @param attr  pointer to netlink attribute type
 * @param data  void pointer to the passed data which will be parsed
 */
static int parse_tuple_cb(const struct nlattr* attr, void* data) {
    const struct nlattr** tb = data;
    int type = mnl_attr_get_type(attr);

    if(mnl_attr_type_valid(attr, CTA_TUPLE_MAX) < 0) {
        return MNL_CB_OK;
    }

    switch(type) {

    case CTA_TUPLE_IP:
        if(mnl_attr_validate(attr, MNL_TYPE_NESTED) < 0) {
            return MNL_CB_ERROR;
        }
        break;

    case CTA_TUPLE_PROTO:
        if(mnl_attr_validate(attr, MNL_TYPE_NESTED) < 0) {
            return MNL_CB_ERROR;
        }
        break;
    }

    tb[type] = attr;
    return MNL_CB_OK;
}

/**
 * @brief function to print/update the tuple parameters to the log file
 *
 * @param nest pointer to netlink attribute structure
 * @return void
 */
static void print_tuple(const struct nlattr* nest) {
    struct nlattr* tb[CTA_TUPLE_MAX + 1] = {};

    mnl_attr_parse_nested(nest, parse_tuple_cb, tb);
    if(tb[CTA_TUPLE_IP]) {
        print_ip(tb[CTA_TUPLE_IP]);
    }

    if(tb[CTA_TUPLE_PROTO]) {
        print_proto(tb[CTA_TUPLE_PROTO]);
    }
}


/**
 * @brief callback function to get the attributes the netlink data
 *
 * Callback function to get the attributes the netlink data
 *
 * @param attr  pointer to netlink attribute type
 * @param data  void pointer to the passed data which will be parsed
 */
static int data_attr_cb(const struct nlattr* attr, void* data) {
    const struct nlattr** tb = data;
    int type = mnl_attr_get_type(attr);

    if(mnl_attr_type_valid(attr, CTA_MAX) < 0) {
        return MNL_CB_OK;
    }

    switch(type) {

    case CTA_TUPLE_ORIG:
    case CTA_TUPLE_REPLY:
        if(mnl_attr_validate(attr, MNL_TYPE_NESTED) < 0) {
            return MNL_CB_ERROR;
        }
        break;

    case CTA_TIMESTAMP:
        break;

    case CTA_COUNTERS_ORIG:
        break;

    case CTA_COUNTERS_REPLY:
        break;

    }
    tb[type] = attr;
    return MNL_CB_OK;
}

/**
 * @brief parses and validates counter values
 *
 * @param attr  pointer to netlink attribute type
 * @param data  void pointer to the passed data which will be parsed
 * @return MNL_CB_OK if validated, else MNL_CB_ERROR
 */
static int parse_counters_cb(const struct nlattr* attr, void* data) {
    const struct nlattr** tb = data;
    int type = mnl_attr_get_type(attr);

    if(mnl_attr_type_valid(attr, CTA_COUNTERS_MAX) < 0) {
        return MNL_CB_OK;
    }

    switch(type) {
    case CTA_COUNTERS_PACKETS:
    case CTA_COUNTERS_BYTES:
        if(mnl_attr_validate(attr, MNL_TYPE_U64) < 0) {
            return MNL_CB_ERROR;
        }
        break;
    }
    tb[type] = attr;
    return MNL_CB_OK;
}

/**
 * @brief returns the timestamp of the connection entry creation
 *
 *
 * @param attr  pointer to netlink attribute type
 * @return timestamp as 64-bit value
 */
static uint64_t get_timestamp(const struct nlattr* attr) {
    struct nlattr* nested;
    mnl_attr_for_each_nested(nested, attr) {
        switch(mnl_attr_get_type(nested)) {
        case CTA_TIMESTAMP_START: {
            uint64_t start = be64toh(*(uint64_t*) mnl_attr_get_payload(nested));
            return start;
        }
        }
    }
    return 0;
}

/**
 * @brief prints the byte and packet counters pertaining to orig / reply entry

 * @param nest  pointer to netlink attribute type
 */
static void print_counters(const struct nlattr* nest) {
    struct nlattr* tb[CTA_COUNTERS_MAX + 1] = {};

    mnl_attr_parse_nested(nest, parse_counters_cb, tb);

    if(tb[CTA_COUNTERS_PACKETS]) {
        update_conntrack_entry_log("packets=%" PRIu64 " ",
                                   be64toh(mnl_attr_get_u64(tb[CTA_COUNTERS_PACKETS])));
    }
    if(tb[CTA_COUNTERS_BYTES]) {
        update_conntrack_entry_log("bytes=%" PRIu64 " ",
                                   be64toh(mnl_attr_get_u64(tb[CTA_COUNTERS_BYTES])));
    }
}

/**
 * @brief filters the matching conntrack entries with the configured tuples
 * only those entries matching will be allowed to be logged
 *
 * @param tuple_tb  pointer to netlink attribute type
 * @param origin	flow direction
 * @return 1 if entry matches, else 0
 */
static int filter_matching_tuples (struct nlattr** tuple_tb, int origin) {
    int match = 0;
    int ignore = 0;
    int l_filter_sport, l_filter_dport;
    char* l_filter_src_ip, * l_filter_dst_ip;


    if(origin) {
        l_filter_sport = filter_sport;
        l_filter_dport = filter_dport;
        l_filter_src_ip = filter_src_ip;
        l_filter_dst_ip = filter_dst_ip;

    } else {
        l_filter_sport = filter_dport;
        l_filter_dport = filter_sport;
        l_filter_src_ip = filter_dst_ip;
        l_filter_dst_ip = filter_src_ip;

    }

    if(tuple_tb[CTA_TUPLE_PROTO]) {
        struct nlattr* proto_tb[CTA_PROTO_MAX + 1] = {};
        mnl_attr_parse_nested(tuple_tb[CTA_TUPLE_PROTO], parse_proto_cb, proto_tb);
        if(filter_proto < 0) {
            ignore++;
        } else if(proto_tb[CTA_PROTO_NUM]) {
            uint8_t proto = mnl_attr_get_u8(proto_tb[CTA_PROTO_NUM]);
            if(proto == filter_proto) {
                match++;
            }
        }
        if(l_filter_sport < 0) {
            ignore++;
        } else if(proto_tb[CTA_PROTO_SRC_PORT]) {
            uint16_t sport = ntohs(mnl_attr_get_u16(proto_tb[CTA_PROTO_SRC_PORT]));
            if(sport == l_filter_sport) {
                match++;
            }
        }

        if(l_filter_dport < 0) {
            ignore++;
        } else if(proto_tb[CTA_PROTO_DST_PORT]) {
            uint16_t dport = ntohs(mnl_attr_get_u16(proto_tb[CTA_PROTO_DST_PORT]));
            if(dport == l_filter_dport) {
                match++;
            }
        }
    }

    if(tuple_tb[CTA_TUPLE_IP]) {
        struct nlattr* ip_tb[CTA_IP_MAX + 1] = {};
        mnl_attr_parse_nested(tuple_tb[CTA_TUPLE_IP], parse_ip_cb, ip_tb);
        if(!l_filter_src_ip) {
            ignore++;
        } else if(ip_tb[CTA_IP_V4_SRC]) {
            struct in_addr* in = mnl_attr_get_payload(ip_tb[CTA_IP_V4_SRC]);
            char ip_str[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, in, ip_str, sizeof(ip_str));
            if(strcmp(ip_str, l_filter_src_ip) == 0) {
                match++;
            }
        } else if(ip_tb[CTA_IP_V6_SRC]) {
            struct in6_addr* in = mnl_attr_get_payload(ip_tb[CTA_IP_V6_SRC]);
            char ip_str[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, in, ip_str, sizeof(ip_str));
            if(strcmp(ip_str, l_filter_src_ip) == 0) {
                match++;
            }

        }
        if(!l_filter_dst_ip) {
            ignore++;
        } else if(ip_tb[CTA_IP_V4_DST]) {
            struct in_addr* in = mnl_attr_get_payload(ip_tb[CTA_IP_V4_DST]);
            char ip_str[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, in, ip_str, sizeof(ip_str));
            if(strcmp(ip_str, l_filter_dst_ip) == 0) {
                match++;
            }
        } else if(ip_tb[CTA_IP_V6_DST]) {
            struct in6_addr* in = mnl_attr_get_payload(ip_tb[CTA_IP_V6_DST]);
            char ip_str[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, in, ip_str, sizeof(ip_str));
            if(strcmp(ip_str, l_filter_dst_ip) == 0) {
                match++;
            }
        }
    }
    if((match + ignore) == 5) {
        return 1;
    } else {
        return 0;
    }
}


/**
 * @brief Callback function that is passed to libmnl's mnl_cb_run()
 * to parse and print the conntrack tuple entries
 */
static int data_cb (const struct nlmsghdr* nlh, void* data) {
    struct nlattr* tb[CTA_MAX + 1] = {};
    struct nfgenmsg* nfg = mnl_nlmsg_get_payload(nlh);

    if(!data) {
        /* do nothing, avoid compilation warning */
    }

    /* check for IP Orig tuple and parse the src, dest, proto, port params
     * check the IP orig and reply tuple for the packet counters */
    mnl_attr_parse(nlh, sizeof(*nfg), data_attr_cb, tb);
    if((tb[CTA_TUPLE_ORIG]) || (tb[CTA_TUPLE_REPLY])) {
        struct nlattr* tuple_tb[CTA_TUPLE_MAX + 0] = {};
        if(tb[CTA_TUPLE_ORIG]) {
            mnl_attr_parse_nested(tb[CTA_TUPLE_ORIG], parse_tuple_cb, tuple_tb);
            if(!filter_matching_tuples(tuple_tb, 1)) {
                return MNL_CB_OK;
            }
        }
        if(tb[CTA_TUPLE_REPLY]) {
            mnl_attr_parse_nested(tb[CTA_TUPLE_REPLY], parse_tuple_cb, tuple_tb);

            if(!filter_matching_tuples(tuple_tb, 0)) {
                return MNL_CB_OK;
            }
        }
    }

    /* entry created for each conn entry */
    conn_entry* entry = new_conn_entry();
    if(!entry) {
        exit(1);
    }
    line_buff = entry->line_buf;

    if(tb[CTA_TUPLE_ORIG]) {
        print_tuple(tb[CTA_TUPLE_ORIG]);
        if(tb[CTA_COUNTERS_ORIG]) {
            print_counters(tb[CTA_COUNTERS_ORIG]);
        }
        if(tb[CTA_TIMESTAMP]) {
            entry->ts_created = get_timestamp(tb[CTA_TIMESTAMP]);
        }
    }
    if(tb[CTA_TUPLE_REPLY]) {
        /* print_tuple(tb[CTA_TUPLE_REPLY]); */
        if(tb[CTA_COUNTERS_REPLY]) {
            print_counters(tb[CTA_COUNTERS_REPLY]);
        }
    }
    update_conntrack_entry_log("\n");
    add_conn_entry(entry);   /* it will get inserted in the order of timestamp */
    return MNL_CB_OK;
}


/**
 * @brief callback Function to list all conntrack entries
 *
 * @param void
 * @return void
 */
void list_conntrack_entries() {

    struct mnl_socket* nl;
    struct nlmsghdr* nlh;
    struct nfgenmsg* nfh;
    uint32_t portid;
    unsigned int seq = (unsigned int) getpid();
    int ret, socket_read = 0;
    bool done = false;

    nl = mnl_socket_open(NETLINK_NETFILTER);
    if(!nl) {
        perror("mnl_socket_open error");
        exit(EXIT_FAILURE);
    }
    if(mnl_socket_bind(nl, 0, MNL_SOCKET_AUTOPID) < 0) {
        mnl_socket_close(nl);
        exit(EXIT_FAILURE);
    }
    nlh = mnl_nlmsg_put_header(buf);
    nlh->nlmsg_type = (NFNL_SUBSYS_CTNETLINK << 8) | IPCTNL_MSG_CT_GET;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
    nlh->nlmsg_seq = seq;

    nfh = mnl_nlmsg_put_extra_header(nlh, sizeof(struct nfgenmsg));
    nfh->version = NFNETLINK_V0;
    nfh->res_id = 0;

    if(mnl_socket_sendto(nl, buf, nlh->nlmsg_len) < 0) {
        mnl_socket_close(nl);
        exit(EXIT_FAILURE);
    }

    portid = mnl_socket_get_portid(nl);


    while(!done) {

        ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
        socket_read++;
        if(ret == -1) {
            exit(EXIT_FAILURE);
        }

        struct nlmsghdr* nlh = (struct nlmsghdr*) buf;
        // Loop through all Netlink messages in the buffer
        while(mnl_nlmsg_ok(nlh, ret)) {
            if(nlh->nlmsg_type == NLMSG_DONE) {
                // All conntrack entries have been received
                done = true;
            }
            if(nlh->nlmsg_type == NLMSG_ERROR) {
                struct nlmsgerr* err = (struct nlmsgerr*) mnl_nlmsg_get_payload(nlh);
                if(err->error == 0) {
                    // ACK received, continue
                } else {
                    fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
                    exit(EXIT_FAILURE);
                }
            }
            // Process the message
            int cb_ret = mnl_cb_run((char*) nlh, nlh->nlmsg_len, seq, portid, data_cb, NULL);
            if(cb_ret == -1) {
                fprintf(stderr, "mnl_cb_run error");
                exit(EXIT_FAILURE);
            }
            if(cb_ret <= MNL_CB_STOP) {
                done = true;
            }
            nlh = mnl_nlmsg_next(nlh, &ret);
        }
    }
    mnl_socket_close(nl);
    write_conn_entries_to_file();
}
