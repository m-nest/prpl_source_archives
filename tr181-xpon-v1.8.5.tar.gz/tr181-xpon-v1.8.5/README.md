# tr181-xpon

[[_TOC_]]

## Introduction

### Overview

`tr181-xpon` is the generic part of the TR-181 PON manager. A PON manager is responsible for managing a PON/OMCI stack. It hides the rest of the US management software from any vendor specific PON/OMCI implementation details.

### Abbreviations

| Abbreviation | Meaning                               |
| :----------- | :------------------------------------ |
| DM           | data model                            |
| IF           | interface                             |
| IPC          | interprocess communication            |
| OMCI         | ONU management and control interface  |
| ONU          | Optical Network Unit                  |
| PCM          | Persistent Configuration Manager      |
| PON          | Passive Optical Network               |
| PPTP         | Physical path termination point       |
| UNI          | User Network Interface                |
| US           | user space                            |
| VEIP         | Virtual Ethernet Interface Point      |

## Architecture

### Overall architecture

The diagram below shows the overall architecture:

```
             Bus (ubus, pcb, ...)
                    |
                    |
        TR-181 XPON | Manager (tr181-xpon)
     +----------------------------------------+
     |                                        |
     |                                        |
     |           +-----------------------------+
     |           | PON vendor module           |
     |           |                             |
     +-----------|                             |
                 +-----------------------------+
                        |
                 +-----------------------------+
                 |  PON/OMCI stack             |
                 |  (executables, libraries,   |
                 |   drivers, device nodes,    |
                 |   etc)                      |
                 +-----------------------------+
```

The northbound IF of `tr181-xpon` exposes the `XPON` object of the [TR-181 DM](https://usp-data-models.broadband-forum.org/#sec:current-data-models). `tr181-xpon` implements the vendor independent part. The vendor specific code is in modules.

`tr181-xpon` assumes there is only 1 vendor module present (in `/usr/lib/amx/tr181-xpon/modules/`). It loads this module, and reports the module it loaded in its DM in the field `XPON.ModuleName`.

`tr181-xpon` uses the Ambiorix modularity API ([libamxm](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxm)) to load a vendor module (and to unload the module upon stopping).


### More detailed architecture

The diagram below shows a more detailed architecture:

```
             Bus (ubus, pcb, ...)
                    |
                    |
        TR-181 XPON | Manager (tr181-xpon)
     +--------------------------------------------------------+
     |                                                        |
     |                                                        |
     |                                                        |
     |               +    module 'pon_stat'  module 'pon_cfg' |
     |               |              /|\           /|\         |
     |               |               |             |          |
     +---------------+---------------+-------------+----------+
            function |               |             |
               calls |      function |    function |
                     |         calls |       calls |
     PON vendor      |               |             |
     module          |               |             |
     +---------------+---------------+-------------+------------------+
     |               |               |             |                  |
     |              \ /              +             +                  |
     |   module 'pon_ctrl'                                            |
     |                                                                |
     +----------------------------------------------------------------+
                   /|\
                    |  Interaction with PON/OMCI stack
                    |  of vendor
                   \|/

               PON/OMCI stack
```

`tr181-xpon` and the vendor module use the Ambiorix modularity API (`libamxm`) to register namespaces with functions. This allows them to communicate via function calls:

- The vendor module must register the namespace `pon_ctrl` with functions such as `set_max_nr_of_onus()` and `set_enable()`.
- `tr181-xpon` registers the `pon_stat` namespace with functions such as `dm_instance_added()` and `dm_instance_removed()`.
- `tr181-xpon` registers the `pon_cfg` namespace. The vendor module can use it to query certain settings, such as the PON mode or whether it should use a VEIP or PPTP Ethernet UNI as IF to the non-OMCI domain.

Sections further below give more info about those namespaces.

The PON vendor module can communicate/interact in several ways with the PON/OMCI stack:
- IPC via Unix socket(s)
- Library calls.
- Start/stop executables.


## Namespaces

`tr181-xpon` and the vendor module must register namespaces with functions to communicate with each other via function calls.

They must register those namespaces during startup.

### pon\_stat namespace

#### General

`tr181-xpon` registers the `pon_stat` namespace with following functions before it loads the vendor module:

- `dm_instance_added`
- `dm_instance_removed`
- `dm_object_changed`
- `dm_add_or_change_instance`
- `omci_reset_mib`
- `dm_set_xpon_parameter`
- `watch_file_descriptor_start`
- `watch_file_descriptor_stop`
- `set_change_power_mode_result`

The vendor module can call the 1st 6 functions to notify `tr181-xpon` to update its DM.

`watch_file_descriptor_start()` instructs `tr181-xpon` to add a file descriptor to its event loop. `tr181-xpon`  calls `handle_file_descriptor()` (see section `pon_ctrl` below) if it detects the file descriptor is ready to read.

#### set\_change\_power\_mode\_result()

The VM should call this function to notify `tr181-xpon` of the result of the asynchronous `XPON.ONU.{i}.ChangePowerMode()` call. The value for the parameter `args` of `set_change_power_mode_result()` must be an htable with following 3 key-value pairs:
- `index` (`uint32_t`): identifies the ONU, e.g. 1 indicates "XPON.ONU.1"
- `call_id` (`uint32_t`): unique ID to identify the `change_power_mode()` invocation for which this call is a reply (see section "pon\_ctrl namespace")
- `result` (`uint32_t`): result of the `change_power_mode()` call: 0 indicates success; a value different from 0 indicates an error.

### pon\_cfg namespace

`tr181-xpon` registers the `pon_cfg` namespace with following functions before it loads the vendor module:

- `pon_cfg_get_param_value`

The vendor module can use this function to request a (configuration) value from the DM.

Example: the vendor module can request whether it should use a VEIP or PPTP Ethernet UNI as IF to the non-OMCI domain.

### pon\_ctrl namespace

#### General

The vendor module must register the `pon_ctrl` namespace with the following functions when it's loaded. The table indicates for each function if it is mandatory or not:


| Function name                | Mandatory                 |
| :--------------------------- | :------------------------ |
| `set_max_nr_of_onus`         | Yes                       |
| `set_enable`                 | Yes                       |
| `get_list_of_instances`      | Yes                       |
| `get_object_content`         | Yes                       |
| `get_param_values`           | Yes                       |
| `set_password`               | No                        |
| `handle_file_descriptor`     | No                        |
| `clean_up_all`               | Yes for systems with musl |
| `change_power_mode`          | Needed for `XPON.ONU.{i}.ChangePowerMode()` |


#### set\_password()

`tr181-xpon` calls the function `set_password((` if the `Password` parameter of the `TC.Authentication` object of an ANI instance is updated. If a project requires support for a PON password, the password should normally be configured via that parameter. Then the vendor module must implement `set_password()`.

If a project does not require support for a PON password, normally no one will update that parameter. If the vendor module is only used on such projects, there is no need for the vendor module to implement `set_password()`.

#### handle\_file\_descriptor()

A vendor module can call `watch_file_descriptor_start()` to instruct `tr181-xpon` to add a file descriptor to its event loop. `tr181-xpon` calls `handle_file_descriptor()` if such a file descriptor becomes ready to read.

A vendor module which calls `watch_file_descriptor_start()` must implement `handle_file_descriptor()`.

A vendor module which does not call `watch_file_descriptor_start()` does not have to implement `handle_file_descriptor()` (as `tr181-xpon` will never call it).

#### clean\_up\_all()

`tr181-xpon` unloads the vendor module upon stopping with the function call `amxm_so_close()`. This function in turn calls `dlclose()`. In theory this should call all destructors of that library. And that is what happens on systems with glibc. But on systems with musl as C library, `dlclose()` is a no-op, and destructors only run on exit. Vendor modules usually have one destructor which calls cleanup functions to clean up its resources. The desired behavior is that the vendor module calls those cleanup functions upon `dlclose()` before `tr181-xpon` and `amxrt` clean up all their resources. Therefore `tr181-xpon` calls `clean_up_all()` on systems with musl just before it calls `amxm_so_close()` to unload the vendor module. Then a system with musl behaves almost the same as a system with glibc: the vendor module cleans up its resources around the same time in both systems: just before or when `tr181-xpon` calls `amxm_so_close()`.

When the system with musl calls the destructor of the vendor module when `tr181-xpon` exits, the destructor has no work to do: the vendor module already cleaned up all resources.

#### change\_power\_mode()

`tr181-xpon` calls this function if `XPON.ONU.{i}.ChangePowerMode()` is called. The value for the parameter `args` of `change_power_mode()` must be an htable with following 4 key-value pairs:
- `path` (`cstring_t`): path to ONU for which `ChangePowerMode()` is called, e.g. "XPON.ONU.1".
- `call_id` (`uint32_t`): unique ID to identify this `change_power_mode()` invocation
- `power_state` (`cstring_t`): requested power state ("On", "Off", or "LowPower")
- `timeout_ms` (`uint32_t`): timeout in milliseconds within which `tr181-xpon` expects a reply via `set_change_power_mode_result()` (see section "pon\_stat namespace"). `tr181-xpon` sets this timeout to 5000 ms.

## Startup behavior

### General

The XPON DM is initially empty except for the `XPON` object and its parameters.

`tr181-xpon` asks the vendor module at startup for info to populate the DM.

More specifically it calls the functions `get_list_of_instances()` and `get_object_content()` to collect info to populate the DM. It first calls `get_list_of_instances()` to query the number of ONU instances. The vendor module might reply that there is just 1 instance: `XPON.ONU.1`. `tr181-xpon` does not create that instance in the DM yet upon receiving that reply. It first calls `get_object_content()` to get the values for one or more parameters of `XPON.ONU.1`. Upon receiving the reply, `tr181-xpon` creates the instance `XPON.ONU.1` and it assigns values to the parameters of that instance for which it got a value from the vendor module. `tr181-xpon` uses a transaction to create the object and to assign values to those parameters in 1 atomic operation.

Assume the vendor module indicated `XPON.ONU.1` exists. Besides querying the content of that instance, `tr181-xpon` also calls `get_list_of_instances()` 3 times to ask the vendor module how many instances there are of `XPON.ONU.1.SoftwareImage`, `XPON.ONU.1.EthernetUNI` and `XPON.ONU.1.ANI` respectively.

`tr181-xpon` populates the XPON DM by descending deeper into the hierarchy until it has queried all sub-objects.

### Maximum number of ONUs

`tr181-xpon` has following compile time setting to configure the max number of ONUs on the board:

```
CONFIG_SAH_AMX_TR181_XPON_MAX_ONUS
```

Its default value is 1. `tr181-xpon` regularly asks the vendor module at startup which instances there are for `XPON.ONU`. `tr181-xpon` assumes that the vendor module might not immediately know the correct answer. It might take a few minutes. A board might e.g. have a G-PON IF and an XGS-PON IF. After startup it might take a while before the vendor module sees those 2 PON IFs. If e.g. the G-PON IF appears, the vendor module might reply to `get_list_of_instances()` call (querying the ONU instances) that `XPON.ONU.1` exists, with `XPON.ONU.1` being the G-PON IF. A bit later the XGS-PON IF might appear, and then the vendor module will reply that there 2 `XPON.ONU` instances: `XPON.ONU.1` for the G-PON IF and `XPON.ONU.2` for the XGS-PON IF.

`tr181-xpon` queries the number of ONUs for about 5 minutes after startup until the number of instances reported by the vendor module is equal to `CONFIG_SAH_AMX_TR181_XPON_MAX_ONUS`. Then `tr181-xpon` assumes all PON IFs are 'found' and it stops polling.

### Populate DM immediately at startup

It's possible to let `tr181-xpon` create one or more `XPON.ONU` instances immediately at startup, before loading a vendor module (and hence before asking the vendor module for a list of instances with `get_list_of_instances()`). Do this by putting a `tr181-xpon_defaults.odl` in `/etc/amx/tr181-xpon/defaults.d`. The following example content creates one ONU instance with `G-PON` as PON mode and the parameter `UsePPTPEthernetUNIasIFtoNonOmciDomain` set to true (see section "VEIP versus PPTP Ethernet UNI" below for its meaning):

```
%populate {
    object XPON.ONU {
        instance add (Name = "ONU.1") {
            parameter PONMode = "G-PON";
            parameter UsePPTPEthernetUNIasIFtoNonOmciDomain = true;
        }
    }
}
```

This approach can be used for HGWs with one G-PON ONU and for which you want to use a PPTP Ethernet UNI (as IF to the non-OMCI domain).

If `tr181-xpon` afterwards receives info from the vendor module indicating there is one `XPON.ONU` instance, it does not have to create the `XPON.ONU` instance anymore; it only updates parameters of the instance if needed.

This is a possible approach to configure certain parameters at startup for an HGW. Another approach could be to let the vendor module pass this info to `tr181-xpon`.

## Persistency

### General

The only read-write parameters in the XPON DM which need to be persistent are:
- `XPON.ONU.{i}.Enable`
- `XPON.ONU.{i}.ANI.{i}.Enable`
- `XPON.ONU.{i}.ANI.{i}.TC.Authentication.HexadecimalPassword`
- `XPON.ONU.{i}.ANI.{i}.TC.Authentication.Password`

The object instances do not exist right after `tr181-xpon` has loaded the odl files defining the DM, and the \_defaults.odl file. The plugin creates them afterwards, while querying the state in the HAL, or when it receives a notification from the HAL to create such an instance. Therefore `tr181-xpon` does not use the odl mechanism to save and restore the values of the parameters above.

All the settings above must be upgrade persistent. Normally such parameters must be marked with `userflags %upc` in the odl file (`upc` stands for upgrade persistent configuration). But because `tr181-xpon` does not use the odl mechanism for persistency, it saves its settings in the folder the Persistent Configuration Manager, i.e. `tr181-pcm`, uses for the upc. That folder is default `/cfg/pcm`. `tr181-xpon` creates the subfolder `/cfg/pcm/tr181-xpon`, and saves its settings in that subfolder.

`tr181-xpon` creates the symlink `/etc/config/tr181-xpon` to `/cfg/pcm/tr181-xpon` for user convenience: users might look in /etc/config for debugging because that's where most components store their settings.


### Enabling an ONU

Upon creating an `XPON.ONU` instance,`tr181-xpon` checks its persistency files to determine if the instance is enabled. If it is, it sets its `Enable` parameter to 1. It does not immediately call `set_enable()` to let the vendor module know that the ONU is enabled. It rather schedules a timer with a timeout of 100 ms to check if the ONU has at least one `EthernetUNI` instance and one `ANI` instance. If that condition is not true, it reschedules the timer with a timeout of 1 s. When the condition is true, it calls `set_enable()` to let the vendor module know the ONU is enabled. This eases the implementation in the vendor module. If an ONU is enabled, a vendor module typically wants to update certain parameters in the `EthernetUNI` or `ANI` instance(s). But if they do not exist yet, `tr181-xpon` will log an error it is unable to do so. `tr181-xpon` keeps rescheduling the timer with a timeout of 1 s until there is at least one `EthernetUNI` instance and one `ANI` instance. If this is still not the case after a few times, it calls `set_enable()` anyway (and no longer reschedules the timer).


## Specific features

### VEIP versus PPTP Ethernet UNI

For a multi-managed ONU it must be possible to select the IF to the non-OMCI management domain. Cfr. BBF TR-280, R-68:

"Multi-managed ONU MUST implement either a Virtual Ethernet Interface Point (VEIP) interface or a Physical Path Termination Point (PPTP) UNI interface as the interface to the non OMCI management domain."

`tr181-xpon` defines the protected read-write parameter `UsePPTPEthernetUNIasIFtoNonOmciDomain` for the `ONU` object. Its default value is false. The ONU must use a PPTP Ethernet UNI if it is true, else the ONU must use a VEIP.

A vendor module can call `pon_cfg_get_param_value()` to get the value of that parameter. The vendor PON/OMCI stack should offer a way to configure this selection. Then the vendor module can do this selection depending on the value of `UsePPTPEthernetUNIasIFtoNonOmciDomain`.


## Tests

### General

This component has unit tests, and it's also possible to test the component interactively. Both require an Ambiorix docker container. Follow instructions on [Ambiorix getting started](https://gitlab.com/prpl-foundation/components/ambiorix/tutorials/getting-started) to set up such a development environment.

In addition, install `mod-sahtrace`:

```
apt install mod-sahtrace
```

You can also build and install `mod-sahtrace` manually: clone the repo somewhere in the folder shared between the host and the container:

```
git clone git@gitlab.com:prpl-foundation/components/core/modules/mod_sahtrace.git
```

Compile and install it in a non-root container shell:

```
cd mod_sahtrace
make
sudo -E make install
```

Also build and install `mod-dmext`. Clone the repo with:

```
git clone git@gitlab.com:prpl-foundation/components/core/modules/mod-dmext.git
```

### Unit tests

This component has a limited set of unit tests. You can run the tests by running following command in an Ambiorix container:

```
make test
```

The command prints test and coverage results to the terminal. You can use a browser to access the coverage report: it's in `output/x86_64-linux-gnu/coverage/report/index.html`.


### Interactively

#### General

Check out `tr181-xpon` and a PON vendor module somewhere in the workspace shared between the container and the host. Choose a vendor module which can be tested in a container.

Because the container does not install netmodel, remove all netmodel related code rom `odl/tr181-xpon.odl.m4`.

If you want to run `tr181-xpon` with more logging, set the trace level of the zones `xpon` and `module` in `odl/tr181-xpon.odl` to 500:

```
    trace-zones = {
        "xpon" = 500,
        "module" = 500
    };
```

:warning: Avoid committing `odl/tr181-xpon.odl.m4` with those changes.

All next steps must be done in the container. Compilation can be done in a shell without root permissions. The other steps must be done in a shell with root permissions.

In the container, compile and install `tr181-xpon` and the vendor module: in the top level folder of each, run `make` and `sudo -E make install`.

Ensure the folder with the vendor modules, `/usr/lib/amx/tr181-xpon/modules`, has only 1 vendor module: `tr181-xpon` will load the single vendor module from that folder.

If you want `tr181-xpon` to query the statistics with `mod_dmstats`, clone the repo somewhere in the folder shared between the host and the container:

```
git clone git@gitlab.com:prpl-foundation/components/core/modules/mod_dmstats.git
```

Compile and install it in a non-root container shell:

```
cd mod_dmstats
make
sudo -E make install
```

Make sure that the following config variable is defined at the end in `makefile.inc` to enable the netdev interface statistics:
```
CONFIG_SAH_AMX_TR181_XPON_USE_NETDEV_COUNTERS=y
```

In a shell with root permissions, run following commands:

```
rm -f /var/log/messages; syslog-ng
ubusd &
tail -f /var/log/messages
```

In another shell with root permissions, start `tr181-xpon`:

```
tr181-xpon
```

The `tr181-xpon` process should start and load the single vendor module. You can query the XPON DM in another shell, e.g. with `ubus-cli`:

```
ubus-cli "XPON.?"
```

If you also want to see the protected paramaters, run:

```
ubus-cli "protected;XPON.?"
```

Or start `ubus-cli` and run the following commands in the cli:

```
$ ubus-cli
> protected
> XPON.?
```

The DM should show the vendor module `tr181-xpon` loaded, and whether there was an error or not, e.g.:

```
XPON.ModuleName=mod-xpon-prpl
XPON.ModuleError=0
```

To query the trace levels, run following command in `ubus-cli`:

```
XPON.list_trace_zones()
```

This should give output which looks as follows:

```
 >  XPON.list_trace_zones()
XPON.list_trace_zones() returned
[
    {
        module = 200,
        xpon = 200
    }
]
```

To change the trace zone levels:

```
XPON.set_trace_zone(zone=xpon,level=500)
XPON.set_trace_zone(zone=module,level=500)
```

It depends on the vendor module which next steps you can test. If the vendor module created one instance of `XPON.ONU`, e.g. `XPON.ONU.1`, it normally should be possible to enable the ONU:

```
XPON.ONU.1.Enable=1
```

#### Power management

To test the `ChangePowerMode()` call, do e.g. the following in `ubus-cli`:

```
XPON.ONU.1.ChangePowerMode(PowerState = "Off")
```

