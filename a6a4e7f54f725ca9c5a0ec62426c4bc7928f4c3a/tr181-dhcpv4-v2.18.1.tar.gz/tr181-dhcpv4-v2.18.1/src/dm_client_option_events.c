/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "dm_client_option_events.h"
#include "dns_utility.h"

#define ME "client_option_events"

void _client_option_hostname_added(UNUSED const char* const event_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(dhcp_get_dm(), data);
    amxd_object_t* option_12 = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));
    amxc_var_t* params = GET_ARG(data, "parameters");
    const char* value_hex = GET_CHAR(params, "Value");
    uint32_t tag = GET_UINT32(params, "Tag");

    when_false_trace(tag == 12, exit, WARNING, "Unexpected DHCP option %u, HostName option is 12 (rfc2132)", tag);

    when_str_empty(value_hex, exit);

    dns_set_host(option_12, DNS_HOST_ARG_ALL);
exit:
    return;
}

static void dhcps_client_option_12_changed(amxd_object_t* option_12) {
    const char* value_hex = GET_CHAR(amxd_object_get_param_value(option_12, "Value"), NULL);
    if(!str_empty(value_hex)) {
        dns_set_host(option_12, DNS_HOST_ARG_HOSTNAME);
    } else {
        dns_remove_host(option_12);
    }
}

void _client_option_changed(UNUSED const char* const event_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv) {
    uint32_t tag = 0;
    amxd_object_t* option = amxd_dm_signal_get_object(dhcp_get_dm(), data);

    when_null_trace(option, exit, ERROR, "Couldn't resolve signal object: %s", GET_CHAR(data, "object"));

    tag = amxd_object_get_uint32_t(option, "Tag", NULL);

    switch(tag) {
    case 12:
        dhcps_client_option_12_changed(option);
        break;
    }
exit:
    return;
}