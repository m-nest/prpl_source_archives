/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__TR_HOSTS_SYNC_H__)
#define __TR_HOSTS_SYNC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>

#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxp/amxp_expression.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_expression.h>
#include <amxd/amxd_transaction.h>

#include <amxb/amxb.h>

#include <amxo/amxo.h>
#include <amxo/amxo_mibs.h>
#include <amxo/amxo_save.h>

#include <amxs/amxs.h>

#include <gmap/gmap.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

int hosts_sync_init(amxd_dm_t* dm, amxo_parser_t* parser);
int hosts_sync_cleanup(void);

/**
   @defgroup hosts_sync
 */

/**
   @ingroup hosts_sync
   @brief Imports host synchronization data into the data model.

   Processes reboot-persistent synchronization data, validating references
   and updating host-related objects in the data model accordingly. This
   prepares the system for a full PCM import by ensuring that the incoming
   data is consistent and safe to apply.

   @param data Pointer to the variable structure containing the synchronization
               data to be imported. Must not be NULL.

   @return
   - @c amxd_status_ok if the data was successfully imported.
   - An error code if validation or import failed.
 */
int hosts_sync_import(amxc_var_t* data);

/**
   @brief Callback invoked when a device query match state changes.

   Builds the alias path for the queried device and either sets up or
   destroys synchronization depending on the query action.

   @param lquery Unused pointer to the query object.
   @param key    The device key identifying the queried object.
                 Must not be NULL or empty.
   @param device Pointer to an @c amxc_var_t representing the device
                 being matched. Passed to @c hosts_setup_object_sync
                 when starting a match.
   @param action The query action, determining whether to set up
                 (@c gmap_query_expression_start_matching) or remove
                 (@c gmap_query_expression_stop_matching) object sync.
 */
void hosts_query_cb(gmap_query_t* lquery, const char* key, amxc_var_t* device, gmap_query_action_t action);

/**
   @ingroup hosts_sync
   @brief Cleans up the list of inactive hosts.

   Iterates through the list of inactive hosts and removes those that have
   been inactive longer than the specified threshold.

   @param min_inactive Minimum number of seconds a host must be inactive
          before it is removed.
          - 0: all inactive hosts are removed and inactivity time is ignored.
          - > 0: only hosts inactive longer than this threshold are removed.
                 In this case, system time must be synchronized; otherwise, no
                 hosts are removed.

   @param[out] out_nbr_removed Optional pointer to store the number of hosts
          that were removed. Can be NULL if the count is not required.

   @return
   - 0 if the operation completed successfully,
   - -1 if the operation could not be performed.
 */
int hosts_sync_remove_inactive_hosts(uint32_t min_inactive,
                                     uint32_t* out_nbr_removed);

/**
   @ingroup hosts_sync
   @brief Ensures that the number of inactive hosts does not exceed a limit.

   This function checks the number of currently inactive hosts and, if the
   count is greater than @p max_inactive_hosts, removes the oldest entries
   until the limit is respected.

   @param max_inactive_hosts Maximum number of inactive hosts to keep.
          - 0: remove all inactive hosts.
          - > 0: keep up to that many inactive hosts.
          - < 0: no action is taken.

   @note Requires that system time is synchronized. If time is not
         synchronized, no hosts are removed.
 */
void hosts_sync_ensure_inactive_host_count(int max_inactive_hosts);

#ifdef __cplusplus
}
#endif

#endif // __TR_HOSTS_SYNC_H__