/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>

#include "netmodel/nm_query.h"

#include "component.h"
#include "wan_manager_utils.h"
#include "netmodel/nm_query.h"
#include "upstream_intf.h"
#include "dm_wan_mode.h"

#define ME "wan-man"

typedef int (* upstream_toggle_func_t)(nm_query_ll_info_t*, bool);
static int toggle_ethernet(nm_query_ll_info_t* info, bool enable);
static int toggle_xpon(nm_query_ll_info_t* info, bool enable);
static int toggle_cellular(nm_query_ll_info_t* info, bool enable);

/**
 * phys_types are the names used in the datamodel:
 * ${prefix_}WANManager.WAN.{i}.PhysicalType
 * phys_types_flags are the names of the flags used in the netmodel query
 * NULL stands for 'not yet defined'
 *
 * Make sure their order of appearance matches
 */
const char* phys_types[physical_type_last] = {
    PHYS_TYPE_ETHERNET, PHYS_TYPE_BRIDGE, PHYS_TYPE_ADSL, PHYS_TYPE_VDSL, PHYS_TYPE_SFP, PHYS_TYPE_GPON, PHYS_TYPE_GFAST, PHYS_TYPE_WWAN
};
const char* phys_types_flags[physical_type_last] = {
    "eth_intf", "bridge", NULL, NULL, NULL, "xpon", NULL, NULL
};

static const upstream_toggle_func_t upstream_toggle[physical_type_last] = {
    toggle_ethernet, NULL, NULL, NULL, NULL, toggle_xpon, NULL, toggle_cellular
};

/**
 * This function will be called from toggle_upstream_intf when upstream_toggle for the given index is NULL.
 * If this function is called, a function should be implemented to handle the type for which it is called.
 */
static int toggle_dummy(nm_query_ll_info_t* info, UNUSED bool enable) {
    SAH_TRACEZ_IN(ME);
    when_null_trace(info, exit, ERROR, "No info structure provided");
    SAH_TRACEZ_ERROR(ME, "No toggle function defined for %s", physical_type_to_string(info->physical_type));
exit:
    SAH_TRACEZ_OUT(ME);
    return -1;
}

/**
 * This function is intended to toggle upstream interfaces of type "Ethernet".
 * The expected upstream_intf_path is something like "Device.Ethernet.Interface.1".
 * The enable parameter for this instance is toggled
 */
static int toggle_ethernet(nm_query_ll_info_t* info, bool enable) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    when_null_trace(info, exit, ERROR, "No info structure provided");
    SAH_TRACEZ_INFO(ME, "Toggling ethernet to %d", enable);

    rv = component_set_enable(info->upstream_intf_path, ethernet_get_context(), enable);
    when_failed_trace(rv, exit, ERROR, "Could not %s %s", enable ? "enable" : "disable", info->upstream_intf_path);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * This function is intended to toggle upstream interfaces of type "GPON".
 * The expected upstream_intf_path is something like "Device.XPON.ONU.1.EthernetUNI.1.".
 * Since we want to toggle the ONU instead of the EthernetUNI, everything starting from "EthernetUNI" is removed from the path.
 * This would result in a path like "Device.XPON.ONU.1." for which the enable parameter is toggled
 */
static int toggle_xpon(nm_query_ll_info_t* info, bool enable) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    int pos = -1;
    amxc_string_t path;

    amxc_string_init(&path, 0);

    when_null_trace(info, exit, ERROR, "No info structure provided");
    SAH_TRACEZ_INFO(ME, "Toggling xpon to %d", enable);

    amxc_string_setf(&path, "%s", info->upstream_intf_path);
    pos = amxc_string_search(&path, "EthernetUNI", 0);
    amxc_string_remove_at(&path, pos, UINT32_MAX);
    rv = component_set_enable(amxc_string_get(&path, 0), xpon_get_context(), enable);
    when_failed_trace(rv, exit, ERROR, "Could not %s %s", enable ? "enable" : "disable", amxc_string_get(&path, 0));

exit:
    amxc_string_clean(&path);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Toggle a WWAN upstream interface.
 *
 * Enables or disables the cellular upstream interface referenced by
 * @p info->upstream_intf_path (e.g., "Device.Cellular.Interface.1").
 *
 * @param[in] info    Pointer to query context; must not be NULL and must
 *                    contain a valid @c upstream_intf_path.
 * @param[in] enable  Set to true to enable the interface; false to disable.
 * @return 0 on success; non-zero on failure.
 */
static int toggle_cellular(nm_query_ll_info_t* info, bool enable) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    when_null_trace(info, exit, ERROR, "No info structure provided");
    SAH_TRACEZ_INFO(ME, "Toggling cellular to %d", enable);

    rv = component_set_enable(info->upstream_intf_path, cellular_get_context(), enable);
    when_failed_trace(rv, exit, ERROR, "Could not %s %s", enable ? "enable" : "disable", info->upstream_intf_path);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Converts the physical type from a string to a corresponding enum value.
 *  This enum value can be used to find the flags or toggle function corresponding with this type.
 * @param phys_type The physical type in string as it is stored in the "PhysicalType" parameter
 * @return An enum value of type physical_type_t if a valid physical type was provided, physical_type_last otherwise.
   error code and no changes in the data model are done.
 */
physical_type_t string_to_physical_type(const char* phys_type) {
    SAH_TRACEZ_IN(ME);
    physical_type_t rv = physical_type_last;
    int cnt = 0;
    when_str_empty_trace(phys_type, exit, WARNING, "PhysicalType name is empty");
    while(cnt < (int) physical_type_last) {
        if(strcmp(phys_type, phys_types[cnt]) == 0) {
            rv = cnt;
            break;
        }
        cnt++;
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Converts the physical type enum value to a physical type string
 * @param type An enum value of type physical_type_t that corresponds with the wanted physical type
 * @return The physical type in string as it is stored in the "PhysicalType" parameter, NULL if no valid index was provided
 */
const char* physical_type_to_string(physical_type_t type) {
    return (type >= 0 && type < physical_type_last) ? phys_types[type] : NULL;
}

/**
 * @brief Converts an enum value of type physical_type_t to a physical type flag string
 * @param type An enum value of type physical_type_t that corresponds with the wanted physical type for which the flags are wanted
 * @return The flags for the corresponding physical type in string, NULL if no valid index was provided
 */
const char* phys_type_to_flag(physical_type_t type) {
    SAH_TRACEZ_IN(ME);
    const char* rv = NULL;
    if((type >= 0) && (type < physical_type_last)) {
        rv = phys_types_flags[type];
    }
    SAH_TRACEZ_OUT(ME);
    return rv;
}


/**
 * @brief checks whether the given physical reference is used in an active WANMode
 *
 * @param physical_reference
 * @return true when physical reference is used in an active WANMode
 * @return false otherwise
 */
bool physical_reference_used(const char* physical_reference) {
    bool res = false;
    const char* active_wan_mode_str = get_current_wan_mode_str();
    physical_type_t physical_type = physical_type_last;
    amxc_string_t current_wan_modes_str;
    amxc_llist_t current_list;

    amxc_string_init(&current_wan_modes_str, 0);
    amxc_llist_init(&current_list);

    when_str_empty(active_wan_mode_str, exit);
    physical_type = get_physical_type_by_reference(physical_reference);

    amxc_string_set(&current_wan_modes_str, active_wan_mode_str);
    amxc_string_split_to_llist(&current_wan_modes_str, &current_list, ',');
    amxc_llist_for_each(it, &current_list) {
        const char* wan_mode = amxc_string_get(amxc_string_from_llist_it(it), 0);
        amxd_object_t* wan_mode_obj = get_wan_mode(wan_mode);
        when_null_trace(wan_mode_obj, exit, ERROR, "Cannot get WANMode object");
        when_false(physical_type == get_physical_type(wan_mode_obj), exit);
    }
    res = true;

exit:
    amxc_llist_clean(&current_list, amxc_string_list_it_free);
    amxc_string_clean(&current_wan_modes_str);
    return res;
}

/**
 * @brief Toggle the upstream interface for the current physical type.
 *
 * @param[in] wan_mode  WAN-mode object; must not be NULL.
 * @param[in] enable    Set to true to enable; false to disable.
 *
 * @return 0 on success; non-zero on failure.
 */
int toggle_upstream_intf(amxd_object_t* wan_mode, bool enable) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    nm_query_ll_info_t* info = NULL;

    char* param_name = NULL;
    bool skip_disable = false;

    when_null(wan_mode, exit);

    param_name = get_prefixed_parameter_name("SkipDisableUpstreamIntf");
    skip_disable = GET_BOOL(amxd_object_get_param_value(wan_mode, param_name), NULL);
    when_true_status(!enable && skip_disable, exit, rv = amxd_status_ok);

    info = (nm_query_ll_info_t*) wan_mode->priv;
    when_null_trace(info, exit, ERROR, "No info structure found");
    when_true_trace(info->physical_type >= physical_type_last, exit, ERROR, "Invalid physical type");

    if(upstream_toggle[info->physical_type] != NULL) {
        rv = upstream_toggle[info->physical_type](info, enable);
    } else {
        rv = toggle_dummy(info, enable);
    }

exit:
    free(param_name);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
