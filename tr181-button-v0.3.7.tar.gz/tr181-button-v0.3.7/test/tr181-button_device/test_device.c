/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxb/amxb_register.h>

#include "button.h"
#include "dm_button.h"
#include "mock.h"
#include "test_device.h"


#define BUTTON_TEST_DM_DEFAULTS "button_device.odl"

static amxd_dm_t dm;
static amxo_parser_t parser;

static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void handle_alarm(int sig) {
    printf("sig %d\n", sig);
}

static amxd_status_t invoke_release_fn(amxd_object_t* button_obj) {
    amxc_var_t args;
    amxc_var_t ret;
    int retval = amxd_status_unknown_error;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    retval = amxd_object_invoke_function(button_obj,
                                         "Release",
                                         &args,
                                         &ret);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return retval;
}

static amxd_status_t invoke_push_fn(amxd_object_t* button_obj) {
    amxc_var_t args;
    amxc_var_t ret;
    int retval = amxd_status_unknown_error;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    retval = amxd_object_invoke_function(button_obj,
                                         "Push",
                                         &args,
                                         &ret);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return retval;
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "button_event_changed", AMXO_FUNC(_button_event_changed));
    amxo_resolver_ftab_add(&parser, "button_event_added", AMXO_FUNC(_button_event_added));
    amxo_resolver_ftab_add(&parser, "button_event_removed", AMXO_FUNC(_button_event_removed));
    amxo_resolver_ftab_add(&parser, "Push", AMXO_FUNC(_Push));
    amxo_resolver_ftab_add(&parser, "Release", AMXO_FUNC(_Release));

    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_DM_DEFAULTS, root_obj), 0);
    assert_int_equal(_button_main(AMXO_START, &dm, &parser), 0);

    signal(SIGALRM, handle_alarm);
    _button_app_start(NULL, NULL, NULL);
    wait_for_sigalarm(1);
    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_button_main(AMXO_STOP, &dm, &parser), 0);
    amxo_resolver_import_close_all();
    amxm_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_device_update_status(UNUSED void** state) {
    amxd_object_t* button_device = NULL;
    amxc_var_t params;

    amxc_var_init(&params);

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_device);
    assert_int_equal(amxd_object_get_params(button_device, &params, amxd_dm_access_protected), 0);
    assert_string_equal(GET_CHAR(&params, "Status"), "Released");

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Test1.");
    assert_non_null(button_device);
    assert_int_equal(amxd_object_get_params(button_device, &params, amxd_dm_access_protected), 0);
    assert_string_equal(GET_CHAR(&params, "Status"), "Error");

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Test2.");
    assert_non_null(button_device);
    assert_int_equal(amxd_object_get_params(button_device, &params, amxd_dm_access_protected), 0);
    assert_string_equal(GET_CHAR(&params, "Status"), "Error");

    amxc_var_clean(&params);
}

void test_device_get_key_code(UNUSED void** state) {
    amxd_object_t* button_device = NULL;
    button_instance_t* priv_data = NULL;

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_device);

    priv_data = button_device->priv;
    assert_non_null(priv_data);
    assert_int_equal(priv_data->key_code, KEY_RESTART);
}

void test_device_simulate(UNUSED void** state) {
    amxd_object_t* button_device = NULL;
    button_instance_t* priv_data = NULL;

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_device);
    priv_data = button_device->priv;
    assert_non_null(priv_data);

    assert_int_equal(priv_data->status, BUTTON_RELEASED);

    // Test simmulate button input event is the same as the current status
    assert_int_equal(invoke_release_fn(button_device), amxd_status_unknown_error);
    handle_events();
    assert_int_equal(priv_data->status, BUTTON_RELEASED);

    // Simulate a button press
    assert_int_equal(invoke_push_fn(button_device), amxd_status_ok);
    handle_events();
    assert_int_equal(priv_data->status, BUTTON_PUSHED);

    // Simulate a button release
    assert_int_equal(invoke_release_fn(button_device), amxd_status_ok);
    handle_events();
    assert_int_equal(priv_data->status, BUTTON_RELEASED);
}

ssize_t __wrap_read(int fd, void* buf, size_t count);

ssize_t __wrap_read(int fd, void* buf, size_t count) {
    check_expected(fd);
    check_expected(count);

    struct input_event* mock_event = mock_type(struct input_event*);
    memcpy(buf, mock_event, sizeof(struct input_event));

    return sizeof(struct input_event);
}

void test_button_read_handler(UNUSED void** state) {
    amxd_object_t* button_device = NULL;
    button_instance_t* priv_data = NULL;
    amxc_ts_t now;

    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_device);
    priv_data = button_device->priv;
    assert_non_null(priv_data);

    assert_int_not_equal(priv_data->status, BUTTON_PUSHED);

    // Push
    amxc_ts_now(&now);
    struct input_event event_push = {
        .type = EV_KEY,
        .code = KEY_RESTART,
        .value = 1,
        .time = {.tv_sec = now.sec, .tv_usec = now.nsec * 1000}
    };
    expect_value(__wrap_read, fd, 0);
    expect_value(__wrap_read, count, sizeof(event_push));
    will_return(__wrap_read, &event_push);

    button_read_handler(0, NULL);
    handle_events();
    assert_int_equal(priv_data->status, BUTTON_PUSHED);

    // Release
    amxc_ts_now(&now);
    struct input_event event_release = {
        .type = EV_KEY,
        .code = KEY_RESTART,
        .value = 0,
        .time = {.tv_sec = now.sec, .tv_usec = now.nsec * 1000}
    };

    expect_value(__wrap_read, fd, 0);
    expect_value(__wrap_read, count, sizeof(event_release));
    will_return(__wrap_read, &event_release);

    button_read_handler(0, NULL);
    handle_events();
    assert_int_equal(priv_data->status, BUTTON_RELEASED);
}
