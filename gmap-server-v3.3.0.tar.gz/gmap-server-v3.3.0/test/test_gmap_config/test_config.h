/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __TEST_DEVICES_H__
#define __TEST_DEVICES_H__


#include "../test_common/test_common.h"


void test_rpc_can_create_config(void** state);
void test_rpc_can_create_config_subsequent(void** state);
void test_rpc_can_create_config_existing(void** state);
void test_internal_create_config_input_validation(void** state);

void test_rpc_can_set_config_existing(void** state);
void test_rpc_can_set_config_nonexisting(void** state);
void test_internal_set_config_input_validation(void** state);

void test_rpc_can_get_config_existing(void** state);
void test_rpc_cannot_get_config_nonexisting_module(void** state);
void test_rpc_cannot_get_config_nonexisting_option(void** state);
void test_internal_get_config_input_validation(void** state);

void test_rpc_can_save_config_existing(void** state);
void test_rpc_cannot_save_config_nonexisting(void** state);
void test_internal_save_config_input_validation(void** state);

void test_rpc_can_load_config_existing_saved(void** state);
void test_rpc_cannot_load_config_nonexisting(void** state);
void test_rpc_cannot_load_config_existing_saved_bad_file(void** state);
void test_internal_load_config_input_validation(void** state);
void test_config_scanmibdir(void** state);

void test_max_devices_removes_inactive_device(void** state);
void test_max_devices_limits_nr_of_active_devices(void** state);
void test_max_devices_doesnt_remove_protected(void** state);
void test_max_devices_removes_oldest_inactive_device(void** state);

void test_max_lan_devices_removes_inactive_lan_devices(void** state);
void test_max_lan_devices_limits_nr_of_devices(void** state);
void test_max_lan_devices_doesnt_remove_protected(void** state);
void test_only_lan_tag_is_no_lan_device(void** state);
void test_younger_device_not_removed(void** state);
void test_interval_removes_inactive_lan_devices_treshold(void** state);
void test_interval_removes_inactive_lan_devices(void** state);
void test_interval_removes_no_inactive_lan_devices(void** state);
void test_interval_removes_inactive_lan_devices_combo(void** state);

#endif  // __TEST_DEVICES_H__