/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <yajl/yajl_gen.h>
#include <image_authentication.h>
#include <rlyeh/rlyeh_defines.h>
#include <lcm/amxc_data.h>
#include <rlyeh/rlyeh_status.h>
#include "../common/test_setup.h"
#include "test_image_authentication.h"

#define UNUSED __attribute__((unused))
#define ME "TEST"
static amxd_dm_t datamodel;
static amxo_parser_t parser;

int test_authentication_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&datamodel);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, "../common/test_odls/rlyeh_definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/image-authentication/image-authentication-definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/image-authentication/image-authentication-config.odl", root_obj), 0);

    amxc_var_add_new_key_data(&args, RLYEH_PLUGIN_ARG_DATAMODEL, (void*) &datamodel);

    authentication_init("func_name", &args, &ret);
    assert_int_equal(amxc_var_dyncast(int32_t, &ret), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return res;
}

int test_authentication_teardown(UNUSED void** state) {
    int res = 0;
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&ret);
    amxc_var_init(&args);

    authentication_cleanup("func_name", &args, &ret);
    assert_int_equal(amxc_var_dyncast(int32_t, &ret), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&datamodel);

    return res;
}

void test_authentication_verify(UNUSED void** state) {
    LOG_ENTRY
    int status = -1;
    amxc_var_t ret;
    amxc_var_t args;

    // test good signature
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 0);
    printf("Check valid signature ok\n");

    // Unknown signing key
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18_bad_key.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 1);
    printf("Check signature with unknown key done\n");


    // Good key but bad signature file
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_20.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 3);
    printf("Check signature with correct key on different image done\n");


    // Hash value different
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6f");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 4);
    printf("Check correct signature but different image manifest hash done\n");


    // Image name value different
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine_diff");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 3);
    printf("Check correct signature but image name done\n");


    // Registry value different
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 3);
    printf("Check correct signature but different registry done\n");


    // Version value different
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/alpine_3_18.signature");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.20");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, 3);
    printf("Check correct signature but different registry done\n");


    // Signature URL is wrong (not found)
    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_URL, "http://testserver.com/wrong_url");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_MANIFEST_HASH, "d9a39933bee4ccb6d934b7b5632cdf8c42658f3cecc5029681338f397142af6e");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_IMAGE_NAME, "library/alpine");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_SERVER, "registry-1.docker.io");
    amxc_var_add_key(cstring_t, &args, RLYEH_PLUGIN_ARG_VERSION, "3.18");

    status = authentication_verify("func_name", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    assert_int_equal(status, RLYEH_ERROR_DOWNLOAD_FAILED);
    printf("Check wrong signature URL\n");

    LOG_EXIT
}
