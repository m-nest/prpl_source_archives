#!/bin/sh
# Script used to generate a simple network layout description from uci configuration
# It is intended to provide a default working layout description as input for default odl templates

NETLAYOUT=/etc/networklayout.json

. /usr/share/libubox/jshn.sh
. /lib/functions.sh
. /lib/functions/netlayout_from_uci.sh

# Bridges Naming
brLan="br-lan"

netlayout_add_wan_bridged_itf()
{
	local itf_name=$(uci -q get network.wan.ifname)
	[ -z "$itf_name" ] && itf_name=$(uci -q get network.wan.device)

	[ -z "$itf_name" ] && return

	netlayout_add_itf_description "$(itf_name_to_dt_alias "$itf_name")" "${itf_name}" "ethernet"
	netlayout_add_itf_to_bridge "Lan" "$(itf_name_to_dt_alias "$itf_name")" "${itf_name}"
}

netlayout_add_wireless_itf()
{
	local itf_name=$1
	local linux_itf=$2
	# local network=$3 only 'lan' network is supported for the extender
	local operFreq=$4
	local ssid=$5
	local itf_alias=$(itf_name_to_alias "$itf_name")

	#first add wireless interface description
	netlayout_add_itf_description "${itf_alias}" "${linux_itf}" "wireless" "${operFreq}" "${ssid}"

	#then if interface is part of lan or guest network add it to corresponding bridge
	#Currently, only lan (br-lan) bridge is supported for extender
	netlayout_add_itf_to_bridge "Lan" "${itf_name}" "${linux_itf}"
	wlan_port_idx=$((wlan_port_idx+1))

	# if new radio add the corresponding endpoint entry
	if ! echo "${op_rad_list}" | grep -q "${operFreq}"; then
		ep_itf_name="ep${operFreq:0:1}g0"
		ep_linux_itf=$(echo "$linux_itf" | sed 's/-1/-2/; t; s/$/-2/') # static wlanIDX-2 
		netlayout_add_ep_itf_description "${ep_itf_name}" "${ep_linux_itf}" "${operFreq}"
		netlayout_add_itf_to_bridge "Lan" "${ep_itf_name}" "${ep_linux_itf}"
		wlan_port_idx=$((wlan_port_idx+1))
		op_rad_list="${op_rad_list};${operFreq}"
	fi
}

# if not present, generate a default network layout description from uci config
if [ ! -s $NETLAYOUT ]; then
	netlayout_init
	netlayout_add_wan_bridged_itf
	netlayout_add_lan_bridged_itfs
	netlayout_add_lan_dsa_bridged_itfs
	wait_for_uci_wireless
	netlayout_add_wireless_itfs

	json_dump -i > $NETLAYOUT
fi
