#!/bin/sh
tar cf /tmp/oops.tar `ba-cli -l KernelFaults.StoragePath?`
