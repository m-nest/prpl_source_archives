/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "button.h"
#include "dm_button.h"

void _button_app_start(UNUSED const char* const sig_name,
                       UNUSED const amxc_var_t* const data,
                       UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "TR181-Button plugin starting");
    button_init_all();
}

void _button_event_changed(UNUSED const char* const event_name,
                           const amxc_var_t* const event_data,
                           UNUSED void* const priv) {
    amxd_object_t* event_instance = amxd_dm_signal_get_object(button_get_dm(), event_data);
    button_event_t* event_info = (button_event_t*) event_instance->priv;
    amxc_var_t* params = GET_ARG(event_data, "parameters");
    amxc_var_t* var = NULL;

    when_null(event_info, exit);
    when_null(params, exit);
    var = GET_ARG(params, "Enable");
    if(var != NULL) {
        event_info->enabled = GET_BOOL(var, "to");
    }
    var = GET_ARG(params, "Min");
    if(var != NULL) {
        event_info->min = GET_UINT32(var, "to");
    }
    var = GET_ARG(params, "Max");
    if(var != NULL) {
        event_info->max = GET_UINT32(var, "to");
    }
    var = GET_ARG(params, "Timeout");
    if(var != NULL) {
        event_info->timeout = GET_UINT32(var, "to");
    }
    var = GET_ARG(params, "Type");
    if(var != NULL) {
        if(strcmp("Pressed", GET_CHAR(var, "to")) == 0) {
            event_info->type = BUTTON_EVENT_TYPE_PRESSED;
        } else if(strcmp("Released", GET_CHAR(var, "to")) == 0) {
            event_info->type = BUTTON_EVENT_TYPE_RELEASED;
        } else if(strcmp("Timeout", GET_CHAR(var, "to")) == 0) {
            event_info->type = BUTTON_EVENT_TYPE_TIMEOUT;
        }
    }
    if((event_info->timer != NULL) && (amxp_timer_get_state(event_info->timer) == amxp_timer_running)) {
        amxp_timer_stop(event_info->timer);
    }
exit:
    return;
}

void _button_event_added(UNUSED const char* const event_name,
                         const amxc_var_t* const event_data,
                         UNUSED void* const priv) {
    amxd_object_t* button_events = amxd_dm_signal_get_object(button_get_dm(), event_data);
    amxd_object_t* event_instance = amxd_object_get_instance(button_events, NULL, GET_UINT32(event_data, "index"));
    amxd_object_t* button_instance = amxd_object_get_parent(button_get_object(GET_CHAR(event_data, "path")));
    button_event_t* event_info = NULL;
    button_instance_t* priv_data = (button_instance_t*) button_instance->priv;

    if((priv_data != NULL) && (priv_data->llist_event != NULL)) {
        event_info = (button_event_t*) calloc(1, sizeof(button_event_t));
        button_event_init(event_info, event_instance);
        if(amxc_llist_append(priv_data->llist_event, &event_info->ll_it)) {
            amxp_timer_delete(&event_info->timer);
            free(event_info->obj_path);
            free(event_info);
            event_info = NULL;
        }
    }
}

void _button_event_removed(UNUSED const char* const event_name,
                           const amxc_var_t* const event_data,
                           UNUSED void* const priv) {
    amxd_object_t* button_events = amxd_dm_signal_get_object(button_get_dm(), event_data);
    amxd_object_t* button_instance = amxd_object_get_parent(button_events);
    button_instance_t* priv_data = (button_instance_t*) button_instance->priv;
    button_event_t* event_info = NULL;

    amxc_llist_for_each(it, priv_data->llist_event) {
        event_info = amxc_llist_it_get_data(it, button_event_t, ll_it);
        if((event_info != NULL) && (event_info->index == GET_UINT32(event_data, "index"))) {
            break;
        }
    }
    amxc_llist_it_t* event_it = amxc_llist_get_at(priv_data->llist_event, amxc_llist_it_index_of(&event_info->ll_it));
    if(event_it != NULL) {
        button_event_clean(event_it);
    }
}
