/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "timezone.h"
#include "utils.h"
#include "configuration/time_configuration.h"

#define MAX_TZNAME_LEN 6

static bool parse_time(const char** ptr);
static bool parse_rule(const char** ptr);
static bool parse_number(const char** ptr, int* out, int min, int max);
/**
 * @brief
 * Test whether the given timezone string can be successfully applied by libc.
 *
 * Attempts to temporarily set the process TZ variable and call tzset().
 * Supports both POSIX TZ strings (e.g. "CET-1CEST,M3.5.0/2,M10.5.0/3"),
 * IANA zone identifiers (e.g. "Europe/Prague").
 *
 * The original TZ environment value is restored before returning.
 *
 * @param tz  Timezone string to test
 * @return    true if libc accepted the timezone, false otherwise
 */
bool can_apply_tz(const char* tz) {
    const char* prev_tz = getenv("TZ");
    bool rc = false;

    when_str_empty_trace(tz, exit, ERROR, "Empty timezone passed as argument");
    when_false_trace(setenv("TZ", tz, 1) == 0, exit, WARNING, "Failed to set TZ env variable to '%s': %s (errno=%d)", tz, strerror(errno), errno);

    tzset();

    // when a faulty timezone will be set, the default std ( UTC or Universal ) will be set
    rc = (tzname[0] != NULL) && (tzname[1] != NULL) && (strstr(tz, tzname[0]) != NULL) && ((strstr(tz, tzname[1]) != NULL) || (strlen(tzname[1]) == 0));

    if(prev_tz == NULL) {
        unsetenv("TZ");
    } else {
        when_false_trace(setenv("TZ", prev_tz, 1) == 0, exit, ERROR, "Failed to set TZ env variable to '%s': %s (errno=%d)", tz, strerror(errno), errno);
    }

    tzset();
exit:
    return rc;
}

/**
 * @brief
 * Parse and validate a timezone name component.
 *
 * Reads a sequence of alphabetic characters from the input string
 * representing a standard or DST timezone name. Advances the input pointer past the parsed name.
 *
 * @param ptr  Pointer to the input string pointer
 * @return     true if a valid timezone name was found, false otherwise
 */
static bool parse_tz_name(const char** ptr) {
    int len = 0;

    while(**ptr && isalpha(**ptr)) {
        len++;
        (*ptr)++;
    }

    return (len >= 1 && len <= MAX_TZNAME_LEN);
}
/**
 * @brief
 * Parse a numeric offset time in POSIX format.
 *
 * Handles optional sign (+/-) followed by hours, and optional minutes/seconds (hh[:mm[:ss]]).
 * Advances the input pointer past the parsed time offset.
 *
 * @param ptr  Pointer to the input string pointer
 * @return     true if the time offset was valid, false otherwise
 */
static bool parse_time(const char** ptr) {
    bool rv = false;
    const char* p = *ptr;
    int hours, mins, secs;

    if((*p == '+') || (*p == '-')) {
        p++;
    }
    when_false(parse_number(&p, &hours, 0, 24), exit);
    when_false(*p == ':', success);
    p++;

    when_false(parse_number(&p, &mins, 0, 59), exit);
    when_false(*p == ':', success);
    p++;

    when_false(parse_number(&p, &secs, 0, 59), exit);
success:
    *ptr = p;
    rv = true;

exit:
    return rv;
}
/**
 * @brief
 * Parse a rule describing daylight saving start or end.
 *
 * Handles formats like - Julian day: Jn (1..365)
 *   - Zero-based day: n (0..365)
 *   - Month-week-day: M<m>.<w>.<d> (optionally followed by /hh:mm:ss)
 * Advances the input pointer past the parsed rule.
 *
 * @param ptr  Pointer to the input string pointer.
 * @return     true if a valid rule was found, false otherwise
 */
static bool parse_rule(const char** ptr) {
    bool rv = false;
    const char* p = *ptr;
    int month, week, day;

    if(*p == 'J') {
        p++;
        when_false(parse_number(&p, &day, 1, 365), exit);
    } else if(*p == 'M') {
        p++;
        when_false(parse_number(&p, &month, 1, 12), exit);
        when_false(*p == '.', exit);
        p++;

        when_false(parse_number(&p, &week, 1, 5), exit);
        when_false(*p == '.', exit);
        p++;

        when_false(parse_number(&p, &day, 0, 6), exit);
    } else if(isdigit(*p)) {
        when_false(parse_number(&p, &day, 0, 365), exit);
    } else {
        goto exit;
    }

    if(*p == '/') {
        p++;

        when_false(parse_time(&p), exit);
    }

    *ptr = p;
    rv = true;
exit:
    return rv;
}
/**
 * @brief
 * Parse an integer from the input string within a specified range.
 *
 * Reads consecutive digits, converts to integer, and validates it against the given min/max bounds.
 *
 * @param ptr  Pointer to the input string pointer; updated to point past the parsed digits
 * @param out  Pointer to store parsed integer value
 * @param min  Minimum valid value
 * @param max  Maximum valid value
 * @return     true if a valid number within range was found, false otherwise
 */
static bool parse_number(const char** ptr, int* out, int min, int max) {
    bool rv = false;
    char buf[8] = {0};
    int i = 0, val = 0;

    while(isdigit(**ptr) && i < 7) {
        buf[i++] = *(*ptr)++;
    }

    when_false(i > 0, exit);

    val = atoi(buf);
    when_false((val >= min) && (val <= max), exit);

    if(out) {
        *out = val;
    }
    rv = true;
exit:
    return rv;
}
/**
 * @brief
 * Test whether the given timezone string is valid posix format.
 *
 * Does not test system acceptance, only string format.
 * Example valid strings: "EST5EDT,M3.2.0,M11.1.0", "PST8PDT"
 *
 *
 * @param tz  Input timezone string to validate
 * @return    true if the string conforms to POSIX timezone format, false otherwise
 */
bool validate_posix_tz(const char* tz) {
    const char* p = tz;

    if(!tz || (strlen(tz) == 0)) {
        return false;
    }

    if(!parse_tz_name(&p)) {
        return false;
    }

    if(!parse_time(&p)) {
        return false;
    }

    if(!isalpha(*p)) {
        return (*p == '\0');
    }

    if(!parse_tz_name(&p)) {
        return false;
    }

    if((*p == '+') || (*p == '-') || isdigit(*p)) {
        if(!parse_time(&p)) {
            return false;
        }
    }

    if(*p == ',') {
        p++;

        if(!parse_rule(&p)) {
            return false;
        }

        if(*p != ',') {
            return false;
        }
        p++;

        if(!parse_rule(&p)) {
            return false;
        }
    }

    return *p == '\0';
}
