/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <amxc/amxc.h>
#include <amxc/amxc_variant_type.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxm/amxm.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dnssd_advertisement.h"
#include "dnssd_advertisement_info.h"
#include "mod_umdns_advertisement.h"

/**
 * @brief
 * Check if all the parameters in the data model are ok.
 *
 * @param service the service object to advertise.
 */
bool dnssd_advertise_service_ok(amxd_object_t* service) {
    bool ret = false;
    amxc_var_t params;
    char* tmp = NULL;
    int nb_txt = 0;

    amxc_var_init(&params);

    when_null_trace(service, exit, ERROR, "No service object given.");

    amxd_object_get_params(service, &params, amxd_dm_access_public);

    tmp = amxd_object_get_value(cstring_t, service, "ApplicationProtocol", NULL);
    when_null_trace(tmp, exit, WARNING, "No application protocol given.");
    free(tmp);

    tmp = amxd_object_get_value(cstring_t, service, "InstanceName", NULL);
    when_null_trace(tmp, exit, WARNING, "No instance name given.");
    free(tmp);

    nb_txt = amxd_object_get_value(uint32_t, service, "TextRecordNumberOfEntries", NULL);
    when_false_trace(nb_txt > 0, exit, WARNING, "No text record given.");

    ret = true;
exit:
    amxc_var_clean(&params);
    return ret;
}
/**
 * @brief
 * Creat the data for the advertise controller.
 *
 * @param data The data to fill.
 * @param service the service object.
 */
static void create_data(amxc_var_t* data, amxd_object_t* service) {
    amxc_var_t* service_htable = NULL;
    amxc_var_t* txt_htable = NULL;
    amxd_object_t* text_entries = NULL;
    service_info_t* info = NULL;
    amxc_var_t* tmp = NULL;

    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);

    when_null_trace(service, exit, ERROR, "No service object given.");
    when_null_trace(service->priv, exit, ERROR, "No private data given for service object.");
    when_null_trace(data, exit, ERROR, "Data to fill not initialised.");
    info = (service_info_t*) service->priv;

    amxc_var_add_key(cstring_t, data, "file_name", info->file_service_name);
    service_htable = amxc_var_add_key(amxc_htable_t, data, "service", NULL);

    tmp = amxc_var_add_new_key(service_htable, "InstanceName");
    amxc_var_push(cstring_t, tmp, amxd_object_get_value(cstring_t, service, "InstanceName", NULL));
    tmp = amxc_var_add_new_key(service_htable, "ApplicationProtocol");
    amxc_var_push(cstring_t, tmp, amxd_object_get_value(cstring_t, service, "ApplicationProtocol", NULL));
    tmp = amxc_var_add_new_key(service_htable, "TransportProtocol");
    amxc_var_push(cstring_t, tmp, amxd_object_get_value(cstring_t, service, "TransportProtocol", NULL));
    amxc_var_add_key(uint16_t, service_htable, "Port", amxd_object_get_value(uint16_t, service, "Port", NULL));

    txt_htable = amxc_var_add_key(amxc_llist_t, service_htable, "TextRecord", NULL);
    text_entries = amxd_object_findf(service, ".TextRecord.");
    amxd_object_for_each(instance, it, text_entries) {
        amxd_object_t* text_entry = amxc_container_of(it, amxd_object_t, it);
        amxc_var_t* txt = amxc_var_add(amxc_htable_t, txt_htable, NULL);
        tmp = amxc_var_add_new_key(txt, "Key");
        amxc_var_push(cstring_t, tmp, amxd_object_get_value(cstring_t, text_entry, "Key", NULL));
        tmp = amxc_var_add_new_key(txt, "Value");
        amxc_var_push(cstring_t, tmp, amxd_object_get_value(cstring_t, text_entry, "Value", NULL));
    }
exit:
    return;
}

/**
 * @brief
 * Set the service status in the data model and creat the service file.
 *
 * @param service The service amxd object with the status to be update.
 */
static void sync_service_status(amxd_object_t* service) {
    int status = 1;
    service_info_t* info = NULL;
    amxc_var_t data;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxc_var_init(&data);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(service, exit, ERROR, "No service object found.");
    when_null_trace(service->priv, exit, ERROR, "No private info data found for service object.");
    info = (service_info_t*) service->priv;

    if((info->flags.all_flags & SERVICE_READY_CONF) == SERVICE_READY_CONF) {
        create_data(&data, service);

        status = umdns_add_advertisement_service(&data);
        info->flags.bit.config_ok = status == amxd_status_ok;
    } else {
        amxc_var_set_type(&data, AMXC_VAR_ID_CSTRING);
        amxc_var_set(cstring_t, &data, info->file_service_name);

        status = umdns_del_advertisement_service(&data);
        if(status != 0) {
            SAH_TRACEZ_ERROR(ME, "Unable to delete service.");
        }
        info->flags.bit.config_ok = 0;
    }

    amxd_trans_select_object(&trans, service);

    if(info->flags.all_flags == SERVICE_FLAGS_OK) {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Enabled");
    } else {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Error_Misconfigured");
    }
    if(!info->flags.bit.enable) {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Disabled");
    }

    when_failed_trace(amxd_trans_apply(&trans, dnssd_advertisement_get_dm()), exit, ERROR, "Cannot sync DNSSD object.");
exit:
    amxc_var_clean(&data);
    amxd_trans_clean(&trans);
    return;
}

/**
 * @brief
 * Set up the setup the service private data and enable the service.
 *
 * @param service The amxd service object.
 * @return amxd_status_ok if everything is well configured
 */
int enable_service(amxd_object_t* service) {
    service_info_t* info = NULL;

    when_null_trace(service, exit, ERROR, "Cannot get service object.");
    when_null_trace(service->priv, exit, ERROR, "Cannot get service object private data.");

    info = (service_info_t*) service->priv;
    info->flags.bit.enable = 1;
    service_info_enable(service);
    sync_service_status(service);
exit:
    return amxd_status_ok;
}

/**
 * @brief
 * Disable the service.
 *
 * @param service The amxd service object.
 * @return amxd_status_ok if everything for the service is close.
 */
int disable_service(amxd_object_t* service) {
    service_info_t* info = NULL;

    when_null_trace(service, exit, ERROR, "Cannot get service object.");
    when_null_trace(service->priv, exit, ERROR, "Cannot get service object private data.");

    info = (service_info_t*) service->priv;
    info->flags.bit.enable = 0;
    sync_service_status(service);
exit:
    return amxd_status_ok;
}