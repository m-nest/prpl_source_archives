/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#if !defined(_MOD_LIGHTTPD_GET_CERTIFICATE_URI_H_)
#define _MOD_LIGHTTPD_GET_CERTIFICATE_URI_H_

int get_certificate_uri(const char* fullpath, char** certuri, char** keyuri);
int mod_lighttpd_config_https_options(amxc_var_t* access, amxc_string_t* config);

#endif