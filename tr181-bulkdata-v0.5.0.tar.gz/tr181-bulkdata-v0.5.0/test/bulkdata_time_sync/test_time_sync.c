/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include <amxo/amxo.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"
#include "bulkdata_profile.h"

#include "mock.h"
#include "dummy_be.h"
#include "test_common.h"
#include "test_time_sync.h"

static const char* odl_defs = "../common/tr181-bulkdata_test.odl";
static const char* odl_device = "../common/test_device.odl";
static const char* odl_time = "test_time.odl";
static const char* odl_default = "tr181-bulkdata_test_single_profile.odl";
static amxb_bus_ctx_t* bus_ctx = NULL;
static amxo_parser_t parser;
static amxc_var_t last_report;

int test_time_sync_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;
    amxd_dm_t* dm = mock_get_dm();

    assert_int_equal(amxd_dm_init(dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    test_register_dummy_be();
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    amxo_connection_add(&parser, amxb_get_fd(bus_ctx), connection_read, "dummy:/tmp/dummy.sock", AMXO_BUS, bus_ctx);

    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "check_reference_is_valid", AMXO_FUNC(_check_reference_is_valid));
    amxo_resolver_ftab_add(&parser, "check_is_none_or_in", AMXO_FUNC(_check_is_none_or_in));
    amxo_resolver_ftab_add(&parser, "bulkdata_enable_changed", AMXO_FUNC(_bulkdata_enable_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_enable_changed", AMXO_FUNC(_bulkdata_profile_enable_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_added", AMXO_FUNC(_bulkdata_profile_added));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_reporting_interval_changed", AMXO_FUNC(_bulkdata_profile_reporting_interval_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_time_reference_changed", AMXO_FUNC(_bulkdata_profile_time_reference_changed));
    amxo_resolver_ftab_add(&parser, "ForceCollection", AMXO_FUNC(_ForceCollection));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_cleanup", AMXO_FUNC(_bulkdata_profile_cleanup));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_mqtt_cleanup", AMXO_FUNC(_bulkdata_profile_mqtt_cleanup));

    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_time, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_device, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_default, root_obj), 0);

    assert_int_equal(amxb_register(bus_ctx, dm), 0);

    assert_int_equal(amxc_var_init(&last_report), 0);
    assert_int_equal(amxb_subscribe(bus_ctx, "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, &last_report), 0);

    return 0;
}

int test_time_sync_teardown(UNUSED void** state) {
    amxd_dm_t* dm = mock_get_dm();

    assert_int_equal(amxb_unsubscribe(bus_ctx, "BulkData.Profile.simple_profile.", push_event_handler, &last_report), 0);
    amxc_var_clean(&last_report);

    assert_int_equal(_bulkdata_main(1, dm, &parser), 0);
    handle_events();
    amxb_free(&bus_ctx);

    amxo_parser_clean(&parser);
    amxd_dm_clean(dm);

    test_unregister_dummy_be();

    amxo_resolver_import_close_all();


    return 0;
}

void test_time_not_synced_does_not_start_profile(UNUSED void** state) {
    amxd_dm_t* dm = mock_get_dm();

    assert_int_equal(_bulkdata_main(0, dm, &parser), 0);
    handle_events();

    go_to_future_ms(5000);
    assert_null(amxc_var_get_first(&last_report));
}

void test_time_sync_starts_profile(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Time.");
    amxd_trans_set_value(cstring_t, &trans, "Status", "Synchronized");
    assert_int_equal(amxd_trans_apply(&trans, mock_get_dm()), 0);
    amxd_trans_clean(&trans);

    handle_events();

    go_to_future_ms(5000);
    assert_non_null(amxc_var_get_first(&last_report));
}

void test_time_sync_done_on_boot(UNUSED void** state) {
    amxd_dm_t* dm = mock_get_dm();

    // reset variant
    amxc_var_set_type(&last_report, AMXC_VAR_ID_HTABLE);

    set_bulkdata_enable(false);
    assert_int_equal(_bulkdata_main(1, dm, &parser), 0);
    handle_events();
    assert_int_equal(_bulkdata_main(0, dm, &parser), 0);

    set_bulkdata_enable(true);
    go_to_future_ms(5000);
    assert_non_null(amxc_var_get_first(&last_report));
}
