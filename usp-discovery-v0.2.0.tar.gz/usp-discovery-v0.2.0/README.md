# `usp_discovery`

TR-369 standard specifies [use of DHCP options for USP controller discovery](https://usp.technology/specification/index.htm#sec:dhcp-options-for-controller-discovery), the `usp_discovery` is a service intended to support USP controller discovery using those options, received from the gateway. Both DHCPv4 and DHCPv6 are supported:

| Encapsulated Option             | DHCPv4 Option 125 | DHCPv6 Option 17 | Parameter in the Device:2 Data Model                              |
|---------------------------------|-------------------|:----------------:|-------------------------------------------------------------------|
|   URL or FQDN of the Controller |         25        |        25        | Dependent on MTP                                                  |
|               Provisioning code |         26        |        26        | Device.LocalAgent.Controller.{i}.ProvisioningCode                 |
| USP retry minimum wait interval |         27        |        27        | Device.LocalAgent.Controller.{i}.USPNotifRetryMinimumWaitInterval |
|   USP retry interval multiplier |         28        |        28        | Device.LocalAgent.Controller.{i}.USPNotifRetryIntervalMultiplier  |
|   Endpoint ID of the Controller |         29        |        29        | Device.LocalAgent.Controller.{i}.EndpointID                       |

*Note:* DHCPv6 have higher priority than DHCPv4, if both DHCP methods provide USP controller information, the DHCPv6 would be preferred. 

## MTP support

### WebSocket
`usp_discovery` has first-class WebSocket MTP support meaning that no additional configuration is needed for that component.
WebSocket URI may have two forms:
* `ws://...` for unencrypted WebSocket communications
* `wss://...` for encrypted WebSocket communications

### MQTT
`usp_discovery` has MQTT MTP support also, it is enabled via `CONFIG_USP_DISCOVERY_SUPPORT_MQTT_MTP` config option
Additional config options for MQTT MTP `MQTT.`:
* `AgentReplyTopic` MQTT agent-reply topic, default to `/usp/controller` (required for MQTT to work)
* `ControllerResponseTopic` MQTT controller-response topic 
* `ProtocolVersion` MQTT protocol version ('3.1', '3.1.1.' or '5.0', see `Device.MQTT.Capabilities.ProtocolVersionsSupported`)

MQTT URI may have two forms:
* `mqtt://...` for unencrypted MQTT communications
* `mqtts://...` for encrypted MQTT communications

### STOMP
Additionally, STOMP is also supported by the `usp_discovery`, the support is enabled by the `CONFIG_USP_DISCOVERY_SUPPORT_STOMP_MTP` config option
Additional config options for STOMP MTP `STOMP.`:
* `AgentControllerDestination`, STOMP controller destination, default to `/usp/controller` (required for STOMP to work)
* `ControllerAgentDestination` STOMP agent's destination
* `ForceNoEncryption` whether encryption is disabled for STOMP

### DHCP version priority
USP Specification does not define preference between DHCPv4 and DHCPv6. But to align with the TR-069 standard if both DHCPv4 and DHCPv6 options are received, `usp_discovery` component prefers DHCPv6 one over DHCPv4:
* If USP Controller information is received over DHCPv4 and there is no USP Controller information over DHCPv6 by that time (or it has been expired), then DHCPv4 options are used to configure USP Agent.
* In all other cases, USP Controller information that has been received over DHCPv6 is used.

That means, if DHCPv4 and DHCP6 configure the same USP controller (e.g. with the same EndpointID) but have different parameters (for example, MTP URL differs) and CPE receives DHCPv4 first and DHCPv6 later, the DHCPv4 configuration would be overwritten and the USP agent would disconnect from the DHCPv4-provisioned USP controller (and connect to the DHCPv6 one).
