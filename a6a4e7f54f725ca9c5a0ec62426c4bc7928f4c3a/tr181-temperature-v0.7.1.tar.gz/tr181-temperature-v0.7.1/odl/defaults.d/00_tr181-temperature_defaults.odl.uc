{% import * as fs from 'fs'; %}
%populate {
    object TemperatureStatus {
        parameter PollingMaxRetry = -1;
        object TemperatureSensor {
{% for (let tz in fs.lsdir("/sys/class/thermal/")) : -%}
{% if (match(tz, regexp("thermal_zone[0-9]*")) != null):%}
            instance add(Alias="cpe-{{ tz }}") {
                parameter Enable = 1;
                parameter Name = "/sys/class/thermal/{{ tz }}";
                parameter PollingInterval = 3;
            }
{% endif %}
{% endfor -%}
        }
    }
}