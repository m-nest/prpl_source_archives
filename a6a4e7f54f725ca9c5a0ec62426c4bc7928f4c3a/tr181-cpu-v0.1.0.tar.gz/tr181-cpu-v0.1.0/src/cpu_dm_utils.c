/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "tr181-cpu.h"
#include "cpu_dm.h"
#include "cpu_dm_utils.h"
#include "cpu_utils.h"

#include "cpu_utils.h"

#define ME "cpu-dm-utils"

#define CPUS_CPU_TR181_PATH                "CPUs.CPU."
#define amxd_object_has_instances(object)  (amxd_object_first_instance(object) != NULL)

/**
   @ingroup  CPU Plugin
   @defgroup cpu_dm_utils
 */

/**
   @ingroup  cpu_dm_utils
   Structure mapping data model parameters to their corresponding sysfs files.

   This table defines which sysfs file to read for each data model parameter,
   and whether the value needs to be checked against the Enable parameter
   before being returned.
 */
typedef struct _cpu_reader {
    const char* param_name;  // Data model parameter name
    const char* file_name;   // Corresponding sysfs filename
    bool check;              // Whether to check Enable parameter before reading
} cpu_reader_t;

/**
   @ingroup  cpu_dm_utils
   Extracts the CPU name from a data model Alias parameter.

   The Alias parameter typically contains a value like "cpu0", "cpu1", etc.
   This function searches for the "cpu" substring and returns a pointer to it.

   Why extract from Alias: The data model uses Alias as the human-readable
   identifier for CPU instances. We need to map this back to the sysfs name
   (also "cpu0", "cpu1", etc.) to interact with the kernel.

   @param alias The Alias parameter value from the data model
   @param alias_str Temporary string buffer for manipulation
   @return Pointer to the CPU name within the alias, or NULL if not found
 */
static const char* cpu_dm_extract_name(const char* alias, amxc_string_t* alias_str) {
    SAH_TRACEZ_IN(ME);
    const char* cpu_name = NULL;
    int offset = 0;

    when_str_empty(alias, exit);
    when_true(amxc_string_setf(alias_str, "%s", alias), exit);
    offset = amxc_string_search(alias_str, "cpu", 0);
    when_true(offset == -1, exit);
    cpu_name = alias + offset;

exit:
    SAH_TRACEZ_OUT(ME);
    return cpu_name;
}

/**
   @ingroup  cpu_dm_utils
   Initializes a DVFS object with current system values.

   This function populates a data model DVFS object with values read from
   the system's sysfs interface. It reads frequencies, available governors,
   and current settings. The function intelligently handles:
   - CPUs that don't support DVFS (sets Supported=false, Status="Unsupported")
   - Existing configured values (doesn't overwrite user settings)
   - Missing sysfs files (gracefully skips unavailable parameters)

   Why check existing values: If the user has already configured certain
   parameters (like ScalingMinFrequency), we don't want to overwrite them
   with current system values. We only populate unset parameters.

   @param dvfs_obj Existing DVFS object to update (NULL if creating new)
   @param cpu_name The CPU identifier (e.g., "cpu0")
   @param trans Transaction to use for setting parameters
   @return Status code (amxd_status_ok on success)
 */
static amxd_status_t cpu_dm_dvfs_init(amxd_object_t* dvfs_obj, const char* cpu_name, amxd_trans_t* trans) {
    SAH_TRACEZ_IN(ME);

    static cpu_reader_t reader[] = {
        { "CurrentFrequency", "scaling_cur_freq", false },
        { "MinFrequency", "cpuinfo_min_freq", false },
        { "MaxFrequency", "cpuinfo_max_freq", false },
        { "ScalingMinFrequency", "scaling_min_freq", true },
        { "ScalingMaxFrequency", "scaling_max_freq", true },
        { "ScalingAvailableGovernors", "scaling_available_governors", false },
        { "ScalingAvailableFrequencies", "scaling_available_frequencies", false },
        { "ScalingGovernor", "scaling_governor", true },
    };

    amxd_status_t retval = amxd_status_ok;
    amxd_param_t* enable_param = NULL;
    bool enable = false;
    bool supported = false;

    // Check if DVFS is currently enabled (if object already exists)
    if(dvfs_obj != NULL) {
        enable_param = amxd_object_get_param_def(dvfs_obj, "Enable");
        enable = GET_BOOL(&enable_param->value, NULL);
    }

    // Check if this CPU hardware supports DVFS
    supported = cpu_scaling_is_supported(cpu_name);
    amxd_trans_set_value(bool, trans, "Supported", supported);

    if(!supported) {
        // CPU doesn't support DVFS - mark as unsupported and don't read any values
        amxd_trans_set_value(cstring_t, trans, "Status", "Unsupported");
    } else {
        amxc_var_t value;
        amxc_var_init(&value);

        // Set initial status based on Enable parameter
        amxd_trans_set_value(cstring_t, trans, "Status", enable? "Enabled":"Disabled");

        // Read each parameter from sysfs
        for(uint i = 0; i < sizeof(reader) / sizeof(reader[0]); i++) {
            // For parameters marked with check=true, skip if already configured
            if(reader[i].check && (dvfs_obj != NULL)) {
                amxd_param_t* param = amxd_object_get_param_def(dvfs_obj, reader[i].param_name);
                if(amxd_param_get_type(param) != AMXC_VAR_ID_CSTRING) {
                    // Numeric parameter - skip if non-zero
                    if(GET_UINT64(&param->value, NULL) != 0) {
                        continue;
                    }
                } else {
                    // String parameter - skip if non-empty
                    const char* str_value = GET_CHAR(&param->value, NULL);
                    if((str_value != NULL) && (*str_value != 0)) {
                        continue;
                    }
                }
            }
            // Read value from sysfs and set in data model
            if(cpu_read_value(cpu_name, reader[i].file_name, &value) == 0) {
                amxd_trans_set_param(trans, reader[i].param_name, &value);
            }
        }

        amxc_var_clean(&value);
    }

    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
   @ingroup  cpu_dm_utils
   Initializes all CPU instances in the data model.

   This is the main initialization function that discovers CPUs and creates/updates
   their data model representation. It handles two scenarios:

   1. Pre-existing CPU instances (from saved configuration):
      - Updates each existing instance with current system values
      - Preserves user-configured settings

   2. No existing instances (fresh start):
      - Auto-discovers all CPUs by scanning cpu0, cpu1, cpu2, etc.
      - Creates new data model instances for each discovered CPU
      - Initializes them with current system values

   Why two paths: On first run, we auto-discover. On subsequent runs, the data
   model is loaded from persistent storage and already has instances. We need
   to handle both cases to support persistence while also allowing dynamic discovery.

   @return 0 on success, -1 on error
 */
int cpu_dm_cpu_init(void) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* cpus = cpu_get_object(CPUS_CPU_TR181_PATH);
    amxc_string_t alias_str;
    amxd_trans_t trans;
    int retval = 0;

    SAH_TRACEZ_INFO(ME, "Initializing DVFS object!");
    amxc_string_init(&alias_str, 0);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    if(amxd_object_has_instances(cpus) > 0) {
        // Path 1: CPU instances already exist (loaded from persistent storage)
        // Update each existing instance with current system values
        amxd_object_for_each(instance, it, cpus) {
            amxd_object_t* cpu = amxc_container_of(it, amxd_object_t, it);
            amxd_param_t* alias_param = amxd_object_get_param_def(cpu, "Alias");
            const char* cpu_name = cpu_dm_extract_name(GET_CHAR(&alias_param->value, NULL), &alias_str);
            amxd_object_t* dvfs_obj = amxd_object_get(cpu, "DVFS");

            when_null_status(dvfs_obj, exit, retval = -1);
            amxd_trans_select_object(&trans, dvfs_obj);

            cpu_dm_dvfs_init(dvfs_obj, cpu_name, &trans);
        }
    } else {
        // Path 2: No instances exist - auto-discover CPUs and create instances
        char cpu_name[CPU_SYSFS_NAME_LEN];
        amxd_trans_select_object(&trans, cpus);

        // Scan for CPUs: cpu0, cpu1, cpu2, ... until one doesn't support DVFS
        for(int cpu = 0; ; cpu++) {
            snprintf(cpu_name, sizeof(cpu_name), "cpu%d", cpu);
            if(!cpu_scaling_is_supported(cpu_name)) {
                break;  // No more CPUs found
            }
            // Create new CPU instance and initialize its DVFS object
            amxd_trans_add_inst(&trans, 0, cpu_name);
            amxd_trans_select_pathf(&trans, ".DVFS");
            cpu_dm_dvfs_init(NULL, cpu_name, &trans);
            amxd_trans_select_pathf(&trans, ".^.^");  // Navigate back to CPUs
        }
    }

    // Apply all changes in a single transaction
    retval = amxd_trans_apply(&trans, cpu_get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction with error code %d at index %d", retval, trans.fail_index);
    }

exit:
    amxc_string_clean(&alias_str);
    amxd_trans_clean(&trans);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
   @ingroup  cpu_dm_utils
   Retrieves the CPU name from a DVFS data model object.

   Given a DVFS object (e.g., CPUs.CPU.1.DVFS), this function navigates to
   its parent CPU object and extracts the CPU name from the Alias parameter.

   Special case: If the CPU object is a template (not an instance), returns
   an empty string. This happens when validating the template definition itself.

   Why needed: Many action handlers receive only the DVFS object, but need
   to know which CPU it belongs to in order to read/write the correct sysfs files.

   @param dvfs_obj The DVFS data model object
   @return The CPU name (e.g., "cpu0"), empty string for templates, NULL on error
 */
const char* cpu_dm_dvfs_get_cpu_name(amxd_object_t* dvfs_obj) {
    amxd_param_t* alias_param = NULL;
    const char* cpu_name = NULL;
    amxc_string_t alias_str;
    amxd_object_t* cpu_obj = amxd_object_get_parent(dvfs_obj);

    amxc_string_init(&alias_str, 0);
    when_null_trace(cpu_obj, exit, ERROR, "CPU object could not be found");
    when_true_status(amxd_object_get_type(cpu_obj) == amxd_object_template, exit, cpu_name = "");

    alias_param = amxd_object_get_param_def(cpu_obj, "Alias");
    cpu_name = cpu_dm_extract_name(GET_CHAR(&alias_param->value, NULL), &alias_str);

exit:
    amxc_string_clean(&alias_str);
    return cpu_name;
}

/**
   @ingroup  cpu_dm_utils
   Updates the Status parameter of a DVFS object.

   The Status parameter is read-only from the external perspective, but the
   application needs to update it internally to reflect the current state.
   This function uses a transaction with the change_ro attribute to bypass
   the read-only restriction.

   Why read-only but internally writable: The Status reflects system state
   and should not be directly settable by users. However, the application
   must update it when Enable changes or during initialization.

   @param dvfs_obj The DVFS object to update
   @param new_status The new status value ("Enabled", "Disabled", or "Unsupported")
   @return Status code (amxd_status_ok on success)
 */
amxd_status_t cpu_dm_dfvs_set_status(amxd_object_t* dvfs_obj, const char* new_status) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t retval = amxd_status_unknown_error;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);  // Allow changing read-only params
    amxd_trans_select_object(&trans, dvfs_obj);

    amxd_trans_set_value(cstring_t, &trans, "Status", new_status);

    retval = amxd_trans_apply(&trans, cpu_get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction with error code %d", retval);
    }

    amxd_trans_clean(&trans);
    SAH_TRACEZ_OUT(ME);
    return retval;
}
