#ifndef __MOD_USB_FILTER_H__
#define __MOD_USB_FILTER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>

#define ME "filter"

amxd_dm_t* get_dm(void);

int _filter_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);
void _filter_app_start(const char* const sig_name,
                       const amxc_var_t* const data,
                       void* const priv);

#ifdef __cplusplus
}
#endif

#endif // __MOD_USB_FILTER_H__
