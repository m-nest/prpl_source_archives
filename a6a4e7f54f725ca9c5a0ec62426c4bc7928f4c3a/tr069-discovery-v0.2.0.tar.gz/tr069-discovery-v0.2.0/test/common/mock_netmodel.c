/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <setjmp.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <cmocka.h>

#include "mock_netmodel.h"


const char* _dhcp4_acs_url;
const char* _dhcp4_provisioning_code;
const char* _dhcp6_acs_url;
const char* _dhcp6_provisioning_code;

void mock_netmodel_set_dhcp_suboptions(const char* dhcp4_acs_url,
                                       const char* dhcp4_provisioning_code,
                                       const char* dhcp6_acs_url,
                                       const char* dhcp6_provisioning_code) {
    _dhcp4_acs_url = dhcp4_acs_url;
    _dhcp4_provisioning_code = dhcp4_provisioning_code;
    _dhcp6_acs_url = dhcp6_acs_url;
    _dhcp6_provisioning_code = dhcp6_provisioning_code;
}

bool __wrap_netmodel_initialize(void) {
    return true;
}

void __wrap_netmodel_cleanup(void) {
    return;
}

void mock_netmodel_client_handle(netmodel_query_t* query) {
    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_LIST);

    mock_netmodel_query_t* q = (mock_netmodel_query_t*) query;

    const char* acs_url = NULL;
    const char* provisioning_code = NULL;
    if(q->tag == 17) {
        acs_url = _dhcp6_acs_url;
        provisioning_code = _dhcp6_provisioning_code;
    } else {
        acs_url = _dhcp4_acs_url;
        provisioning_code = _dhcp4_provisioning_code;
    }
    amxc_var_t* event = amxc_var_add_new_amxc_htable_t(&data, NULL);
    amxc_var_t* event_data = amxc_var_add_new_key_amxc_llist_t(event, "Data", NULL);
    if(acs_url) {
        amxc_var_t* second_suboption = amxc_var_add_new_amxc_htable_t(event_data, NULL);
        amxc_var_add_new_key_uint32_t(second_suboption, "Code", q->tag == 17 ? 1 : 11);
        amxc_var_add_new_key_cstring_t(second_suboption, "Data", acs_url);
    }
    if(provisioning_code) {
        amxc_var_t* first_suboption = amxc_var_add_new_amxc_htable_t(event_data, NULL);
        amxc_var_add_new_key_uint32_t(first_suboption, "Code", q->tag == 17 ? 2 : 12);
        amxc_var_add_new_key_cstring_t(first_suboption, "Data", provisioning_code);
    }
    q->cb("", &data, NULL);

    amxc_var_clean(&data);
}

netmodel_query_t* __wrap_netmodel_openQuery(const char* intf,
                                            const char* subscriber,
                                            const char* function,
                                            const amxc_var_t* args,
                                            netmodel_callback_t handler,
                                            UNUSED void* userdata) {

    assert_non_null(handler);
    assert_string_equal(intf, "ip-wan");
    assert_string_equal(subscriber, "tr069-discovery");
    assert_string_equal(function, "getDHCPOption");
    assert_non_null(args);

    uint16_t arg_tag = amxc_var_dyncast(uint16_t, GET_ARG(args, "tag"));
    const char* arg_type = GET_CHAR(args, "type");

    assert_true(arg_tag == 17 || arg_tag == 125);
    if(arg_tag == 17) {
        assert_string_equal(arg_type, "req6");
    } else {
        assert_string_equal(arg_type, "req");
    }

    mock_netmodel_query_t* q = (mock_netmodel_query_t*) malloc(sizeof(mock_netmodel_query_t));
    q->tag = arg_tag;
    q->cb = handler;

    mock_netmodel_client_handle((netmodel_query_t*) q);

    return (netmodel_query_t*) q;
}

void __wrap_netmodel_closeQuery(netmodel_query_t* query) {
    free(query);
}
