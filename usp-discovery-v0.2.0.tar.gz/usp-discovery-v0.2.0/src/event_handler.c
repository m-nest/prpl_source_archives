/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxrt/amxrt.h>
#include <netmodel/common_api.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#include "event_handler.h"
#include "usp_discovery.h"
#include "obuspa_interface.h"

#define ME "usp_discovery"

/**
 * @file event_handler.c
 * @brief Handling netmodel events and configuring USP controller accordingly to the DHCP options.
 */

int setup_subscriptions(void) {
    int rc = -1;
    {
        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "type", "req");
        amxc_var_add_key(uint16_t, &parameters, "tag", 125);
        amxc_var_add_key(cstring_t, &parameters, "traverse",
                         netmodel_traverse_down);

        app.option_125_subscription = netmodel_openQuery(
            GET_CHAR(amxrt_get_config(), NETMODEL_INTF), ME, "getDHCPOption",
            &parameters, option_125_changed, NULL);
        amxc_var_clean(&parameters);
        when_null_trace(app.option_125_subscription, exit, ERROR,
                        "Cannot subscribe to 125 DHCPv4 option");
    }
    {
        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "type", "req6");
        amxc_var_add_key(uint16_t, &parameters, "tag", 17);
        amxc_var_add_key(cstring_t, &parameters, "traverse",
                         netmodel_traverse_down);

        app.option_17_subscription = netmodel_openQuery(
            GET_CHAR(amxrt_get_config(), NETMODEL_INTF), ME, "getDHCPOption",
            &parameters, option_17_changed, NULL);
        amxc_var_clean(&parameters);
        when_null_trace(app.option_17_subscription, exit, ERROR,
                        "Cannot subscribe to 17 DHCPv7 option");
    }
    rc = 0;
exit:
    return rc;
}

/**
 * Parse DHCP option from netmodel into DHCPControllerInformation
 *
 * @param[in] option option from the netmodel
 * @param[out] dhcp_controller_info DHCP controller information to fill
 *
 * @return 0 if no error happened
 */
static int parse_netmodel_dhcp_option(amxc_var_t* option, struct DHCPControllerInformation* dhcp_controller_info) {
    int rc = -1;

    when_null_trace(option, exit, WARNING, "Cannot parse NULL data");

    memset(dhcp_controller_info, 0, sizeof(struct DHCPControllerInformation));

    amxc_var_for_each(var, option) {
        uint32_t code = GET_UINT32(var, "Code");
        const char* data = GET_CHAR(var, "Data");

        SAH_TRACEZ_INFO(ME, "Suboption %us: %s", code, data);

        switch(code) {
        case DHCP_SUBOPT_URL:
            dhcp_controller_info->URL =
                amxc_var_dyncast(cstring_t, GET_ARG(var, "Data"));
            break;
        case DHCP_SUBOPT_PROV_CODE:
            dhcp_controller_info->ProvisioningCode =
                amxc_var_dyncast(cstring_t, GET_ARG(var, "Data"));
            break;
        case DHCP_SUBOPT_USP_NOTIF_MIN_INTERVAL:
            dhcp_controller_info->USPNotifRetryMinimumWaitInterval =
                amxc_var_dyncast(uint16_t, GET_ARG(var, "Data"));
            break;
        case DHCP_SUBOPT_USP_NOTIF_INTERVAL_MULTIPLIER:
            dhcp_controller_info->USPNotifRetryIntervalMultiplier =
                amxc_var_dyncast(uint16_t, GET_ARG(var, "Data"));
            break;
        case DHCP_SUBOPT_ENDPOINT_ID:
            dhcp_controller_info->EndpointID =
                amxc_var_dyncast(cstring_t, GET_ARG(var, "Data"));
            break;
        }
    }

    rc = 0;
exit:
    return rc;
}

/**
 * Prepare DHCP option from netmodel to be parsed
 *
 * @param[in] option option from the netmodel
 * @param[out] dhcp_controller_info DHCP controller information to fill
 *
 * @return 0 if no error happened

 */
static int parse_dhcp_option(const amxc_var_t* option, struct DHCPControllerInformation* dhcp_controller_info) {
    int rc = -1;

    when_null_trace(option, exit, WARNING, "NULL option provided");

    amxc_var_t* data = GETP_ARG(option, "0.Data");
    if(!data) {
        memset(dhcp_controller_info, 0, sizeof(struct DHCPControllerInformation));
        rc = 0;
        goto exit;
    }

    rc = parse_netmodel_dhcp_option(data, dhcp_controller_info);

exit:
    return rc;
}

/**
 * Get DHCPStatus instance for given DHCP type
 *
 * @param dhcp_type the type of status to give
 *
 * @return DHCPStatus instance
 */
static struct DHCPStatus* get_dhcpstatus(enum DHCPType dhcp_type) {
    switch(dhcp_type) {
    case DHCPType_DHCPv4:
        return &app.dhcpv4_status;
    case DHCPType_DHCPv6:
        return &app.dhcpv6_status;
    }
    return NULL;
}

/**
 * Get configured USP controller for given DHCP type
 *
 * @param dhcp_type the type of DHCP controller to give
 *
 * @return configured USP controller information for given DHCP type
 */
static amxc_string_t* get_configured_controller(enum DHCPType dhcp_type) {
    switch(dhcp_type) {
    case DHCPType_DHCPv4:
        return &app.dhcpv4_status.alias;
    case DHCPType_DHCPv6:
        return &app.dhcpv6_status.alias;
    }
    return NULL;
}

/**
 * Configure USP controller based on provided information from DHCP and DHCP type
 *
 * @param[in] parsed_option parsed DHCP controller information from the DHCP
 * @param dhcp_type current dhcp_type
 * @param force_dhcpv4_priority whether DHCPv4 have equal as DHCPv6 priority
 *
 * @return 0 if USP controller was configured successfully
 */
static int configure_controller(struct DHCPControllerInformation* parsed_option, enum DHCPType dhcp_type, bool force_dhcpv4_priority);

/**
 * Remove DHCP-configured USP controller
 *
 * @param dhcp_type type of controller to remove
 *
 * @return 0 if USP controller was removed successfully
 */
static int remove_dhcp_configured_controller(enum DHCPType dhcp_type) {
    int rc = -1;
    // if DHCPv4 and DHCPv6 configure the same controller (e.g. with the same EndpointID)
    // only reconfiguration to another DHCP (e.g. dhcpv4 -> dhcpv6 and dhcpv6 -> dhcpv4) is needed
    // and not actual removal
    if(!strcmp(amxc_string_get(&app.dhcpv4_status.alias, 0), amxc_string_get(&app.dhcpv6_status.alias, 0))) {
        // if the aliases are the same and current controller is in use
        // as other dhcp-configured controller, reconfigure to that another
        // controller
        if(get_dhcpstatus(dhcp_type)->in_use) {
            struct DHCPControllerInformation controller_information;
            enum DHCPType configuring_dhcp_type;
            switch(dhcp_type) {
            case DHCPType_DHCPv4:
                controller_information = DHCPControllerInformation_clone(app.dhcpv6_status.controller_information);
                configuring_dhcp_type = DHCPType_DHCPv6;
                break;
            case DHCPType_DHCPv6:
                controller_information = DHCPControllerInformation_clone(app.dhcpv4_status.controller_information);
                configuring_dhcp_type = DHCPType_DHCPv4;
                break;
            }
            rc = configure_controller(&controller_information, configuring_dhcp_type, true);
            DHCPControllerInformation_free(&controller_information);
        }
        // if the dhcpv4 and dhcpv6 configure different usp controllers
    } else {
        when_failed_trace(remove_controller(amxc_string_get(get_configured_controller(dhcp_type), 0)), exit, WARNING, "Cannot remove controller '%s'", amxc_string_get(get_configured_controller(dhcp_type), 0));
    }
    rc = 0;
    DHCPStatus_reset(get_dhcpstatus(dhcp_type));

exit:
    return rc;
}

static int configure_controller(struct DHCPControllerInformation* parsed_option, enum DHCPType dhcp_type, bool force_dhcpv4_priority) {
    int rc = -1;
    amxc_string_t alias;
    amxc_string_init(&alias, PATH_BUFFER_SIZE);

    // if no EndpointID or URL --- remove the controller
    if((parsed_option->EndpointID == NULL) && (parsed_option->URL == NULL)) {
        // if no controller configured --- nothing to do
        when_true_trace(amxc_string_is_empty(get_configured_controller(dhcp_type)), exit, INFO, "Cannot remove controller: no previous controller was configured");
        rc = remove_dhcp_configured_controller(dhcp_type);

        goto exit;
    }
    // Configure adding DHCP controller
    if(GET_BOOL(amxrt_get_config(), SINGLE_CONTROLLER_INSTANCE)) {
        amxc_string_setf(&alias, "usp_discovery");
    } else {
        amxc_string_setf(&alias, "usp_discovery_%s", parsed_option->EndpointID);
    }

    // DHCPv6 have higher priority
    if(!force_dhcpv4_priority && ((dhcp_type == DHCPType_DHCPv4) && !strcmp(amxc_string_get(&alias, 0), amxc_string_get(&app.dhcpv6_status.alias, 0)))) {
        SAH_TRACEZ_INFO(ME, "DHCPv4 USP Controller is not configured as DHCPv6 have higher priority");
        goto save_controller_info;
    }
#ifndef IGNORE_STACK_REFERENCE
    when_failed_trace(set_stack_preference(dhcp_type), exit, WARNING, "Cannot update 'Internal.DualStackPreference' value to match DHCP type");
#endif
    when_failed_trace(add_or_replace_controller(amxc_string_get(&alias, 0), parsed_option), exit, WARNING, "Cannot add DHCP controller with '%s'", amxc_string_get(&alias, 0))

/* *INDENT-OFF* */
save_controller_info:
/* *INDENT-ON* */
    amxc_string_copy(&get_dhcpstatus(dhcp_type)->alias, &alias);
    DHCPControllerInformation_free(&get_dhcpstatus(dhcp_type)->controller_information);
    get_dhcpstatus(dhcp_type)->controller_information = *parsed_option;
    get_dhcpstatus(dhcp_type)->in_use = true;
    memset(parsed_option, 0, sizeof(struct DHCPControllerInformation));

    rc = 0;

exit:
    amxc_string_clean(&alias);
    return rc;
}

/**
 * Middleware to configure USP controller if DHCP option has changed
 *
 * @param current_controller_info current USP controller config
 * @param previous_controller_info previous USP controller config
 * @param dhcp_type current DHCP type
 */
static void configure_controller_if_controller_info_changed(
    struct DHCPControllerInformation* current_controller_info,
    struct DHCPControllerInformation* previous_controller_info,
    enum DHCPType dhcp_type
    ) {
    if(DHCPControllerInformation_equals(current_controller_info, previous_controller_info)) {
        return;
    }
    DHCPControllerInformation_free(previous_controller_info);
    *previous_controller_info = DHCPControllerInformation_clone(*current_controller_info);
    configure_controller(current_controller_info, dhcp_type, false);
}

void option_125_changed(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    static struct DHCPControllerInformation* previous_parsed_option;
    struct DHCPControllerInformation parsed_option;

    if(!previous_parsed_option) {
        previous_parsed_option = malloc(sizeof(struct DHCPControllerInformation));
        memset(previous_parsed_option, 0, sizeof(struct DHCPControllerInformation));
    }
    if(parse_dhcp_option(data, &parsed_option)) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse DHCP option 125");
        return;
    }
    configure_controller_if_controller_info_changed(&parsed_option, previous_parsed_option, DHCPType_DHCPv4);
    DHCPControllerInformation_free(&parsed_option);
}

void option_17_changed(UNUSED const char* const sig_name,
                       const amxc_var_t* const data,
                       UNUSED void* const priv) {
    static struct DHCPControllerInformation* previous_parsed_option;
    struct DHCPControllerInformation parsed_option;

    if(!previous_parsed_option) {
        previous_parsed_option = malloc(sizeof(struct DHCPControllerInformation));
        memset(previous_parsed_option, 0, sizeof(struct DHCPControllerInformation));
    }

    if(parse_dhcp_option(data, &parsed_option)) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse DHCP option 17");
        return;
    }
    configure_controller_if_controller_info_changed(&parsed_option, previous_parsed_option, DHCPType_DHCPv6);
    DHCPControllerInformation_free(&parsed_option);
}
