/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __TEST_PROMISE_H__
#define __TEST_PROMISE_H__

#include <sys/time.h>
#include <sys/resource.h>
#include <sys/signalfd.h>
#include <signal.h>
#include <unistd.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <inttypes.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <cmocka.h>

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp_timer.h>
#include <amxp/amxp_promise.h>

// test utility functions
void read_sigalrm(void);
void settle_callback_rejects(amxp_promise_t* promise, void* const consumer_priv);
void settle_callback_fulfills(amxp_promise_t* promise, void* const consumer_priv);
void settle_callback_deletes(amxp_promise_t* promise, void* const consumer_priv);
void rejected_callback(amxp_promise_t* promise, void* const consumer_priv);
void fulfilled_callback(amxp_promise_t* promise, void* const consumer_priv);
void cancel_callback(amxp_promise_t* promise, void* const consumer_priv);
void cancel_callback_no_check(amxp_promise_t* promise, void* const provider_priv);
void cancel_callback_fulfills(amxp_promise_t* promise, void* const provider_priv);
void cancel_callback_deletes(amxp_promise_t* promise, void* const provider_priv);
int wait_fulfill(amxp_promise_t* promise, uint32_t timeout, void* const provider_priv);
int wait_reject(amxp_promise_t* promise, uint32_t timeout, void* const provider_priv);
int wait_fail(amxp_promise_t* promise, uint32_t timeout, void* const provider_priv);
int wait_success_not_resolving(amxp_promise_t* promise, uint32_t timeout, void* const provider_priv);

// simple promise tests
void test_promise_is_pending_after_creation(void** state);
void test_promise_can_reject_promise(void** state);
void test_promise_reject_with_status_0_sets_rejected_status(void** state);
void test_promise_can_fulfill_promise(void** state);
void test_promise_can_not_change_state_after_settled(void** state);
void test_promise_calls_correct_callback_when_rejected(void** state);
void test_promise_calls_correct_callback_when_fulfilled(void** state);
void test_promise_set_callback_on_pending_state_fails(void** state);
void test_promise_calls_cancel_callback_when_deleted(void** state);
void test_promise_is_not_waitable_by_default(void** state);
void test_promise_settled_promise_is_waitable(void** state);
void test_promise_with_wait_function_is_waitable(void** state);
void test_promise_with_wait_can_delete_promise_in_settled_callbacks(void** state);
void test_promise_failed_wait_error_code_is_propagated(void** state);
void test_promise_after_wait_the_promise_must_be_settled(void** state);
void test_promise_take_future_hands_over_ownership(void** state);
void test_promise_take_future_fails_when_pending(void** state);
void test_promise_api_can_handle_null_pointers_as_input(void** state);
void test_promise_is_automatically_rejected_after_timeout(void** state);
void test_promise_reject_after_timeout_can_be_changed(void** state);
void test_promise_settle_callback_misbehaves(void** state);
void test_promise_settle_callback_deletes_promise(void** state);
void test_promise_misbehaving_cancel_function(void** state);

// chained promise tests
int test_promise_chain_setup(void** state);
int test_promise_chain_teardown(void** state);

void test_chained_promise_is_pending_after_creation(void** state);
void test_chained_promise_deletion_calls_rejected_callback(void** state);
void test_chained_promise_is_fulfilled_after_creation_if_all_steps_are_fulfilled(void** state);
void test_chained_promise_is_rejected_after_creation_if_one_step_is_rejected(void** state);
void test_chained_promise_is_watching_current_promise(void** state);
void test_chained_promise_can_get_fulfilled(void** state);
void test_chained_promise_can_get_rejected(void** state);
void test_chained_promise_can_be_created_without_final_fulfilled(void** state);
void test_chained_promise_can_be_created_without_final_rejected(void** state);
void test_chained_promise_takes_future_of_last_step_if_not_set_in_steps(void** state);
void test_chained_promise_does_not_change_future_if_already_set(void** state);
void test_chained_promise_calls_callback_when_fulfilled(void** state);
void test_chained_promise_step_can_not_fulfill_chained_promise(void** state);
void test_chained_promise_step_can_not_reject_chained_promise(void** state);
void test_chained_promise_step_can_abort_chained_promise(void** state);
void test_chained_promise_create_using_array(void** state);
void test_chained_promise_create_must_fail_when_no_steps_provided(void** state);
void test_chained_promise_api_can_handle_null_pointers_as_input(void** state);
void test_chained_promise_rejected_fails_from_external_source(void** state);
void test_chained_promise_is_automatically_rejected_after_timeout(void** state);
void test_chained_promise_is_automatically_rejected_after_timeout_and_final_is_called(void** state);
void test_chained_promise_gets_aborted_if_chained_promise_is_returned_by_step(void** state);
void test_chained_promise_gets_aborted_if_first_step_returns_null(void** state);
void test_chained_promise_gets_aborted_if_first_step_chained_promise_self(void** state);
void teat_chained_promise_settle_callback_deletes_promise(void** state);

// aggregated promise tests
int test_promise_aggr_setup(void** state);
int test_promise_aggr_teardown(void** state);

void test_promise_aggr_can_create_all_type(void** state);
void test_promise_aggr_can_create_any_type(void** state);
void test_promise_aggr_can_create_race_type(void** state);
void test_promise_aggr_can_create_all_settled_type(void** state);
void test_promise_aggr_all_is_rejected_as_soon_as_a_subpromise_is_rejected(void** state);
void test_promise_aggr_any_is_rejected_when_all_subpromises_are_rejected(void** state);
void test_promise_aggr_race_is_rejected_if_the_first_settled_sub_promise_is_rejected(void** state);
void test_promise_aggr_all_settled_is_fulfilled_when_all_sub_promises_are_rejected(void** state);
void test_promise_aggr_all_is_fulfilled_as_soon_as_all_subpromises_are_fulfulled(void** state);
void test_promise_aggr_any_is_fulfilled_as_soon_as_a_subpromise_is_fulfilled(void** state);
void test_promise_aggr_race_is_fulfilled_if_the_first_settled_sub_promise_is_fulfilled(void** state);
void test_promise_aggr_all_settled_is_fulfilled_when_all_sub_promises_are_settled(void** state);
void test_promise_aggr_can_create_using_array_of_promises(void** state);
void test_promise_aggr_can_create_using_array_of_promises_containing_null_pointers(void** state);
void test_promise_aggr_can_create_using_list_of_promises(void** state);
void test_promise_aggr_all_is_rejected_at_creation_if_a_subpromise_is_already_rejected(void** state);
void test_promise_aggr_any_is_rejected_at_creation_if_all_subpromises_are_already_rejected(void** state);
void test_promise_aggr_race_is_rejected_at_creation_if_the_first_settled_is_rejected(void** state);
void test_promise_aggr_all_settled_is_fulfilled_at_creation_when_all_sub_promises_are_rejected(void** state);
void test_promise_aggr_all_is_fulfilled_at_creation_when_subpromises_are_fulfulled(void** state);
void test_promise_aggr_any_is_fulfilled_at_creation_if_at_least_one_subpromise_is_fulfilled(void** state);
void test_promise_aggr_race_is_fulfilled_at_creation_if_the_first_settled_subpromise_is_fulfilled(void** state);
void test_promise_aggr_all_settled_is_fulfilled_at_creation_when_all_sub_promises_are_settled(void** state);
void test_promise_aggr_not_allowed_to_reject_or_fulfill_directly(void** state);
void test_promise_aggr_is_waitable_if_all_subpromises_are_waitable(void** state);
void test_promise_aggr_wait_keeps_looping_until_aggregated_is_settled(void** state);
void test_promise_aggr_wait_skips_already_settled_subpromises(void** state);
void test_promise_aggr_if_a_subpromise_wait_fails_the_aggregated_wait_must_fail(void** state);
void test_promise_aggr_is_not_waitable_if_one_of_the_subpromises_is_not_waitable_at_creation(void** state);
void test_promise_aggr_api_can_handle_null_pointers_as_input(void** state);
void test_promise_aggr_create_without_promises_fail(void** state);
void test_promise_aggr_is_automatically_rejected_after_timeout(void** state);
void test_promise_aggr_timer_is_deleted_when_aggregate_settles_before_timeout(void** state);
void test_chained_promise_can_be_waited_on_if_all_steps_are_waitable(void** state);
void test_chained_promise_waited_fails_if_one_step_is_not_waitable(void** state);

#endif // __TEST_PROMISE_H__