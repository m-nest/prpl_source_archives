/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_dnssd_service.h"
#include "../common/dummy.h"
#include "../common/mock_amxp.h"
#include "gmap_mod_dnssd.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object_event.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_expression.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <amxo/amxo_mibs.h>

#include <gmap/gmap.h>

static amxb_bus_ctx_t* bus_ctx = NULL;

static bool device_has_tag(amxd_object_t* device,
                           const char* tag) {
    char* device_tags = NULL;
    bool found = false;
    device_tags = amxd_object_get_value(cstring_t, device, "Tags", NULL);
    if(strstr(device_tags, tag) != NULL) {
        found = true;
    }
    free(device_tags);
    return found;
}

static amxp_expr_status_t custom_field_fetcher(amxp_expr_t* expr,
                                               amxc_var_t* value,
                                               const char* path,
                                               void* priv) {
    amxp_expr_status_t status = amxp_expr_status_unknown_error;
    amxd_object_t* device = (amxd_object_t*) priv;
    if(path[0] == '.') {
        // Field is object path.
        status = amxd_object_expr_get_field(expr, value, path, device);
    } else {
        // Field is tag.
        amxc_var_set(bool, value, device_has_tag(device, path));
        status = amxp_expr_status_ok;
    }

    return status;
}

static bool device_matches(amxd_object_t* device,
                           amxp_expr_t* expression) {
    return amxp_expr_evaluate(expression, custom_field_fetcher, device, NULL);
}


static void add_tag(amxc_var_t* device_tags, const char* tag) {
    amxc_var_for_each(value, device_tags) {
        const char* str_val = GET_CHAR(value, NULL);
        if((str_val != NULL) && (strcmp(str_val, tag) == 0)) {
            goto exit;
        }
    }
    amxc_var_add(cstring_t, device_tags, tag);
exit:
    return;
}

amxd_status_t _setTag(amxd_object_t* object,
                      AMXB_UNUSED amxd_function_t* func,
                      amxc_var_t* args,
                      AMXB_UNUSED amxc_var_t* ret) {
    amxc_var_t tags;
    amxc_var_t* args_tags;

    amxc_var_init(&tags);

    amxd_object_get_param(object, "Tags", &tags);
    amxc_var_cast(&tags, AMXC_VAR_ID_SSV_STRING);
    amxc_var_cast(&tags, AMXC_VAR_ID_LIST);

    args_tags = GET_ARG(args, "tag");
    amxc_var_cast(args_tags, AMXC_VAR_ID_SSV_STRING);
    amxc_var_cast(args_tags, AMXC_VAR_ID_LIST);
    amxc_var_for_each(value, args_tags) {
        const char* tag = GET_CHAR(value, NULL);
        add_tag(&tags, tag);
    }

    amxc_var_cast(&tags, AMXC_VAR_ID_SSV_STRING);
    amxd_object_set_param(object, "Tags", &tags);

    amxo_parser_apply_mibs(test_get_parser(), object, device_matches);

    amxc_var_clean(&tags);
    return amxd_status_ok;
}

amxd_status_t _get(AMXB_UNUSED amxd_object_t* object,
                   AMXB_UNUSED amxd_function_t* func,
                   AMXB_UNUSED amxc_var_t* args,
                   AMXB_UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

amxd_status_t _createDevice(AMXB_UNUSED amxd_object_t* object,
                            AMXB_UNUSED amxd_function_t* func,
                            amxc_var_t* args,
                            AMXB_UNUSED amxc_var_t* ret) {
    int status = 0;
    amxc_var_t params;

    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &params, "Alias", GET_CHAR(args, "key"));
    amxc_var_add_key(cstring_t, &params, "Tags", GET_CHAR(args, "tags"));
    status = amxb_add(bus_ctx, "Devices.Device.", 0, NULL, &params, NULL, gmap_get_timeout());

    amxc_var_clean(&params);
    return status == 0 ? amxd_status_ok : amxd_status_unknown_error;
}

amxd_status_t _destroyDevice(AMXB_UNUSED amxd_object_t* object,
                             AMXB_UNUSED amxd_function_t* func,
                             amxc_var_t* args,
                             AMXB_UNUSED amxc_var_t* ret) {
    int status = 0;

    status = amxb_del(bus_ctx, "Devices.Device.", 0, GET_CHAR(args, "key"), NULL, gmap_get_timeout());

    return status == 0 ? amxd_status_ok : amxd_status_unknown_error;
}

amxd_status_t _linkAdd(AMXB_UNUSED amxd_object_t* object,
                       AMXB_UNUSED amxd_function_t* func,
                       amxc_var_t* args,
                       AMXB_UNUSED amxc_var_t* ret) {
    const char* uname = GET_CHAR(args, "upper_device");
    const char* lname = GET_CHAR(args, "lower_device");
    const char* type = GET_CHAR(args, "type");
    amxd_dm_t* dm = test_get_dm();
    amxc_var_t* u_gmap = NULL;
    amxc_var_t* l_gmap = NULL;
    amxd_object_t* udev = amxd_dm_findf(dm, "Devices.Device.%s.LDevice.%s.", uname, lname);
    amxd_object_t* ldev = amxd_dm_findf(dm, "Devices.Device.%s.UDevice.%s.", lname, uname);

    u_gmap = gmap_device_get(uname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    l_gmap = gmap_device_get(lname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    assert_non_null(u_gmap);
    assert_non_null(l_gmap);

    if(!udev) {
        amxc_var_t values;
        amxc_var_init(&values);
        amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &values, "Alias", lname);
        amxc_var_add_key(cstring_t, &values, "Type", type);

        gmap_add_instance(uname, "LDevice", &values);

        amxc_var_clean(&values);
    }
    if(!ldev) {
        amxc_var_t values;
        amxc_var_init(&values);
        amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &values, "Alias", uname);
        amxc_var_add_key(cstring_t, &values, "Type", type);

        gmap_add_instance(lname, "UDevice", &values);

        amxc_var_clean(&values);
    }

    amxc_var_delete(&u_gmap);
    amxc_var_delete(&l_gmap);
    return amxd_status_ok;
}

amxd_status_t _linkRemove(AMXB_UNUSED amxd_object_t* object,
                          AMXB_UNUSED amxd_function_t* func,
                          amxc_var_t* args,
                          AMXB_UNUSED amxc_var_t* ret) {
    const char* uname = GET_CHAR(args, "upper_device");
    const char* lname = GET_CHAR(args, "lower_device");
    amxd_dm_t* dm = test_get_dm();
    amxc_var_t* u_gmap = NULL;
    amxc_var_t* l_gmap = NULL;
    amxd_object_t* udev = amxd_dm_findf(dm, "Devices.Device.%s.LDevice.%s.", uname, lname);
    amxd_object_t* ldev = amxd_dm_findf(dm, "Devices.Device.%s.UDevice.%s.", lname, uname);

    u_gmap = gmap_device_get(uname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    l_gmap = gmap_device_get(lname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    assert_non_null(u_gmap);
    assert_non_null(l_gmap);

    if(udev) {
        int index = amxd_object_get_index(udev);
        gmap_delete_instance(uname, "LDevice", index);
    }
    if(ldev) {
        int index = amxd_object_get_index(ldev);
        gmap_delete_instance(lname, "UDevice", index);
    }

    amxc_var_delete(&u_gmap);
    amxc_var_delete(&l_gmap);
    return amxd_status_ok;
}

amxd_status_t _topology(amxd_object_t* object,
                        AMXB_UNUSED amxd_function_t* func,
                        AMXB_UNUSED amxc_var_t* args,
                        amxc_var_t* ret) {
    /* amxc_var_t topo;
       amxc_var_init(&topo);

       amxc_var_set_type(&topo, AMXC_VAR_ID_HTABLE); */
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    amxd_object_get_params(object, ret, amxd_dm_access_public);

    amxd_object_t* udevs = amxd_object_findf(object, "UDevice");
    amxd_object_t* ldevs = amxd_object_findf(object, "LDevice");

    amxc_var_t* ulist = amxc_var_add_key(amxc_llist_t, ret, "UDevice", NULL);
    amxc_var_t* llist = amxc_var_add_key(amxc_llist_t, ret, "LDevice", NULL);

    amxd_object_for_each(instance, it, udevs) {
        amxd_object_t* data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_t params;
        amxc_var_init(&params);
        amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

        amxd_object_get_params(data, &params, amxd_dm_access_public);
        amxc_var_add(amxc_htable_t, ulist, amxc_var_constcast(amxc_htable_t, &params));

        amxc_var_clean(&params);
    }

    amxd_object_for_each(instance, it, ldevs) {
        amxd_object_t* data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_t params;
        amxc_var_init(&params);
        amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

        amxd_object_get_params(data, &params, amxd_dm_access_public);
        amxc_var_add(amxc_htable_t, llist, amxc_var_constcast(amxc_htable_t, &params));

        amxc_var_clean(&params);
    }

    //amxc_var_add(amxc_htable_t, ret, amxc_var_constcast(amxc_htable_t, &topo));

    //amxc_var_clean(&topo);
    return amxd_status_ok;
}

amxd_status_t _find(amxd_object_t* object,
                    AMXB_UNUSED amxd_function_t* func,
                    amxc_var_t* args,
                    amxc_var_t* ret) {
    amxc_var_t dev_list;
    amxd_object_t* device = amxd_object_get_child(object, "Device");
    const char* expression = GETP_CHAR(args, "expression");

    amxc_var_init(&dev_list);
    amxc_var_set_type(&dev_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

    amxd_object_for_each(instance, it, device) {
        const char* dev_name = NULL;
        const char* ip = NULL;
        amxc_var_t params;
        amxd_object_t* data = NULL;

        amxc_var_init(&params);

        data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxd_object_get_params(data, &params, amxd_dm_access_public);

        dev_name = GETP_CHAR(&params, "Alias");
        ip = GETP_CHAR(&params, "IPAddress");

        if((ip != NULL) && (ip[0] != '\0') && strstr(expression, "IPv")) {
            if(strstr(expression, ip) != NULL) {
                amxc_var_add(cstring_t, ret, dev_name);
            }
        } else if(strstr(expression, dev_name) != NULL) {
            amxc_var_t devices;
            amxc_string_t service_id;
            amxc_string_t expr;

            amxc_var_init(&devices);
            amxc_string_init(&service_id, 0);
            amxc_string_init(&expr, 0);

            amxc_string_set(&service_id, expression);

            amxc_string_replace(&service_id, dev_name, "", 1);
            amxc_string_replace(&service_id, ".Key == \"\" and has_instance(\"Service\", \".ServiceId ^= '", "", 1);
            amxc_string_replace(&service_id, "'\")", "", 1);
            amxc_string_replace(&service_id, "'\")", "", 1);

            amxc_string_setf(&expr, "Devices.Device.%s.Service.[ServiceId == '%s'].", dev_name, amxc_string_get(&service_id, 0));
            printf("\n%s\n", amxc_string_get(&expr, 0));

            amxb_get(bus_ctx, amxc_string_get(&expr, 0), 0, &devices, gmap_get_timeout());

            if(amxc_llist_size(amxc_var_constcast(amxc_llist_t, GETI_ARG(&devices, 0))) != 0) {
                amxc_var_add(cstring_t, &dev_list, dev_name);
            }

            amxc_var_clean(&devices);
            amxc_string_clean(&service_id);
            amxc_string_clean(&expr);
        }
        amxc_var_clean(&params);
    }

    if(!amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, &dev_list))) {
        amxc_var_add(amxc_llist_t, ret, amxc_var_constcast(amxc_llist_t, &dev_list));
    }

    amxc_var_clean(&dev_list);
    return amxd_status_ok;
}

int test_mod_dnssd_setup(AMXB_UNUSED void** state) {
    printf("TEST SETUP\n");
    amxc_var_t* var = NULL;

    assert_int_equal(test_register_dummy(), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    gmap_client_init(bus_ctx);

    /* do not load import so files */
    var = amxo_parser_claim_config(test_get_parser(), "odl-import");
    amxc_var_set(bool, var, false);


    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "get", AMXO_FUNC(_get)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "createDevice", AMXO_FUNC(_createDevice)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "destroyDevice", AMXO_FUNC(_destroyDevice)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "linkAdd", AMXO_FUNC(_linkAdd)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "linkRemove", AMXO_FUNC(_linkRemove)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "topology", AMXO_FUNC(_topology)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "find", AMXO_FUNC(_find)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "setTag", AMXO_FUNC(_setTag)), 0);

    assert_int_equal(test_load_dummy_remote("../common/dummy_dnssd.odl"), 0);
    assert_int_equal(test_load_dummy_remote("../common/dummy_gmap.odl"), 0);

    // load_mib_module();

    handle_events();

    assert_int_equal(_gmap_mod_dnssd_entrypoint(0, test_get_dm(), test_get_parser()), 0);

    handle_events();

    return amxd_status_ok;
}

int test_mod_dnssd_teardown(AMXB_UNUSED void** state) {

    printf("TEST TEARDOWN\n");
    assert_int_equal(_gmap_mod_dnssd_entrypoint(1, test_get_dm(), test_get_parser()), 0);

    amxb_disconnect(bus_ctx);
    amxb_free(&bus_ctx);
    assert_int_equal(test_unregister_dummy(), 0);

    return amxd_status_ok;
}

// --------------------------------------------------------------------------------------------------------------------------
// TEST 1: Validate default DNSSD.Service.1 exists after module startup. Setup functions start and stop the module correctly.
// --------------------------------------------------------------------------------------------------------------------------

void test_dnssd_default_service(UNUSED void** state) {
    amxc_var_t* get_dnssd_values = NULL;
    amxc_var_t dnssd_value;
    amxc_var_init(&dnssd_value);

    // Check instance exists
    assert_int_equal(amxb_get(bus_ctx, "DNSSD.Service.1.", 0, &dnssd_value, 5), amxd_status_ok);
    get_dnssd_values = GETP_ARG(&dnssd_value, "0.0");

    assert_string_equal(GET_CHAR(get_dnssd_values, "ApplicationProtocol"), "webdav");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Domain"), "");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Host"), "Device.Hosts.Host.1");
    assert_string_equal(GET_CHAR(get_dnssd_values, "InstanceName"), "public files");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Status"), "LeaseActive");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Target"), "sah0513.local");
    assert_string_equal(GET_CHAR(get_dnssd_values, "TransportProtocol"), "TCP");
    assert_int_equal(GET_INT32(get_dnssd_values, "Port"), 46485);
    assert_int_equal(GET_INT32(get_dnssd_values, "Priority"), 0);
    assert_int_equal(GET_INT32(get_dnssd_values, "Weight"), 0);

    amxc_var_clean(&dnssd_value);

    return;
}



// ---------------------------------------------------------------------------------------
// TEST 2: Default service added correctly to gmap. Testing process_service functionality.
// ---------------------------------------------------------------------------------------

void test_dnssd_default_service_gmap(UNUSED void** state) {
    amxc_var_t* get_gmap_values = NULL;
    amxc_var_t gmap_value;
    amxc_var_init(&gmap_value);

    // Check instance exists
    assert_int_equal(amxb_get(bus_ctx, "Devices.Device.1.mDNSService.1.", 20, &gmap_value, 5), amxd_status_ok);
    get_gmap_values = GETP_ARG(&gmap_value, "0.0");

    assert_string_equal(GET_CHAR(get_gmap_values, "Alias"), "_webdav__tcp");
    assert_string_equal(GET_CHAR(get_gmap_values, "Domain"), "local");
    assert_string_equal(GET_CHAR(get_gmap_values, "Name"), "public files");
    assert_string_equal(GET_CHAR(get_gmap_values, "ServiceName"), "_webdav._tcp");
    assert_int_equal(GET_INT32(get_gmap_values, "Port"), 46485);

    amxc_var_clean(&gmap_value);
}


// --------------------------------------------
// TEST 3: New service added correctly to gmap.
// --------------------------------------------

void test_dnssd_add_service(UNUSED void** state) {
    int status = 0;
    amxc_var_t params;

    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &params, "ApplicationProtocol", "webdav");
    amxc_var_add_key(cstring_t, &params, "Domain", "testDomain");
    amxc_var_add_key(cstring_t, &params, "Host", "Device.Hosts.Host.1");
    amxc_var_add_key(cstring_t, &params, "InstanceName", "instance");
    amxc_var_add_key(cstring_t, &params, "LastUpdate", "2025-12-03T17:23:20.299674481Z");
    amxc_var_add_key(cstring_t, &params, "IPAddresses", "192.168.1.10");
    amxc_var_add_key(uint32_t, &params, "Port", 46486);
    amxc_var_add_key(uint32_t, &params, "Priority", 0);
    amxc_var_add_key(cstring_t, &params, "Status", "LeaseActive");
    amxc_var_add_key(cstring_t, &params, "Target", "sah0513.local");
    amxc_var_add_key(cstring_t, &params, "TransportProtocol", "UDP");
    amxc_var_add_key(uint32_t, &params, "Weight", 0);

    status = amxb_add(retrieve_dnssd_ctx(), "DNSSD.Service.", 0, NULL, &params, NULL, 10);
    assert_int_equal(status, 0);
    handle_events();

    amxc_var_clean(&params);

    // Check DNSSD.Service. instance exists
    amxc_var_t* get_dnssd_values = NULL;
    amxc_var_t dnssd_value;
    amxc_var_init(&dnssd_value);

    assert_int_equal(amxb_get(bus_ctx, "DNSSD.Service.2.", 0, &dnssd_value, 5), amxd_status_ok);
    get_dnssd_values = GETP_ARG(&dnssd_value, "0.0");

    assert_string_equal(GET_CHAR(get_dnssd_values, "ApplicationProtocol"), "webdav");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Domain"), "testDomain");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Host"), "Device.Hosts.Host.1");
    assert_string_equal(GET_CHAR(get_dnssd_values, "InstanceName"), "instance");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Status"), "LeaseActive");
    assert_string_equal(GET_CHAR(get_dnssd_values, "Target"), "sah0513.local");
    assert_string_equal(GET_CHAR(get_dnssd_values, "TransportProtocol"), "UDP");
    assert_int_equal(GET_INT32(get_dnssd_values, "Port"), 46486);
    assert_int_equal(GET_INT32(get_dnssd_values, "Priority"), 0);
    assert_int_equal(GET_INT32(get_dnssd_values, "Weight"), 0);

    amxc_var_clean(&dnssd_value);

    // Check gmap instance exists
    amxc_var_t* get_gmap_values = NULL;
    amxc_var_t gmap_value;
    amxc_var_init(&gmap_value);

    // Check instance exists
    assert_int_equal(amxb_get(bus_ctx, "Devices.Device.1.mDNSService.2.", 20, &gmap_value, 5), amxd_status_ok);
    get_gmap_values = GETP_ARG(&gmap_value, "0.1");

    assert_string_equal(GET_CHAR(get_gmap_values, "Alias"), "_webdav__udp");
    assert_string_equal(GET_CHAR(get_gmap_values, "Domain"), "local");
    assert_string_equal(GET_CHAR(get_gmap_values, "Name"), "instance");
    assert_string_equal(GET_CHAR(get_gmap_values, "ServiceName"), "_webdav._udp");
    assert_int_equal(GET_INT32(get_gmap_values, "Port"), 46486);

    amxc_var_clean(&gmap_value);
}

// -----------------------------------------------------------
// TEST 4: Remove service, verify removed correctly from gmap.
// -----------------------------------------------------------

void test_dnssd_remove_service(UNUSED void** state) {
    int status = 0;
    amxc_var_t ret;
    amxc_var_init(&ret);

    status = amxb_del(bus_ctx, "DNSSD.Service.1.", 0, NULL, &ret, 10);
    assert_int_equal(status, 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    handle_events();

    amxc_var_clean(&ret);
}
