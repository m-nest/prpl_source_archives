# shellcheck shell=ash
# shellcheck disable=SC2009 # Do not consider pgrep
# shellcheck disable=SC1091 # Do not follow sourced files
[ -f /etc/environment ] && amx_env_file="/etc/environment"

# Set core dump size according to environment
ulimit -c "${ULIMIT_CONFIGURATION:-0}"

log_trace=${log_trace:-false}

. /lib/functions/procd.sh

# Show DM entries
#
# usage: process_debug_info <datamodel_root> [protected_datamodel] [depth]
#
#   datamodel_root      - name of the process
#   protected_datamodel - show protected DM. Default: true
#   depth               - depth of the DM, default is deepest
process_debug_info(){
    datamodel_root="$1"
    protected_datamodel="${2:-true}"
    depth="${3:-}"

    if $protected_datamodel ; then
        ba-cli "ubus-protected; pcb-protected; ${datamodel_root}.?${depth}"
    else
        ba-cli "${datamodel_root}.?${depth}"
    fi
}

procd_append_env_opts() {
	procd_runtime_env_opts="${procd_runtime_env_opts}$1 "
}

export_procd_environment() {
  local env_file="$1"
  [ -n "$env_file" ] && [ -f "${env_file}" ] || return

  procd_set_param env PATH=$PATH
  while IFS='=' read -r key value; do
      key=${key#* }
      procd_append_param env "${key//\"/}=${value//\"/}"
  done < "$env_file"

  if [ -n "${procd_runtime_env_opts}" ];then
      for env_entry in ${procd_runtime_env_opts}
      do
            procd_append_param env "${env_entry//\"/}"
      done
  fi
}

preservice_hook()
{
     if ${log_trace};then
	logger -s "preservice_hook() init_functions"
     fi
}

postservice_hook()
{
     if ${log_trace};then
	logger -s "postservice_hook() init_functions"
     fi
}

register_service()
{
        local service_name=$1
        local command=$2
        local procd_respawn_threshold
        local procd_respawn_timeout
        local procd_respawn_retry

        if env | grep -q "respawn_threshold" >/dev/null; then
             procd_respawn_threshold=${respawn_threshold}
        else
             procd_respawn_threshold=300
        fi

        if env | grep -q "respawn_timeout" >/dev/null; then
             procd_respawn_timeout=${respawn_timeout}
        else
             procd_respawn_timeout=5
        fi

        if env | grep -q "respawn_retry" >/dev/null; then
             procd_respawn_retry=${respawn_retry}
        else
             procd_respawn_retry=3
        fi

        procd_open_instance ${service_name}
        export_procd_environment ${amx_env_file}
        procd_set_param command ${command}

        shift
        shift
        for opts in "$@"; do
                procd_append_param command ${opts}
        done

        procd_set_param respawn \
                        "${procd_respawn_threshold}" \
                        "${procd_respawn_timeout}" "${procd_respawn_retry}"

        # For certain processes, we rely on procd to manage and monitor their lifecycle, including tracking their PID.
        # To support this, we introduced the 'monitor_pid_file' variable, which holds the path to the process's PID file
        # (typically something like /var/run/${process}.pid). If this variable is set, we instruct procd to monitor the
        # specified PID file by passing it via the 'pidfile' parameter. This enables procd to supervise the process and
        # automatically restart it if it exits unexpectedly.

        if [ -n "${monitor_pid_file}" ];then
		procd_set_param pidfile ${monitor_pid_file}
	fi

        # For services managed by procd, we may need to control how long the system waits for a graceful shutdown.
        # To support this, we introduced the 'proc_termination_timeout' variable, which defines the number of seconds
        # procd should wait after sending a SIGTERM before forcefully terminating the process with SIGKILL.
        # If this variable is set, we pass it to procd using the 'term_timeout' parameter. This ensures that
        # services have sufficient time to clean up resources or save state before being forcibly stopped.
        # For certain processes/prplwares, we rely on procd to .

        if [ -n "${proc_termination_timeout}" ] && echo "${proc_termination_timeout}" | grep -Eq "^[0-9]+$"; then
		procd_set_param term_timeout ${proc_termination_timeout}
	fi

        procd_close_instance
}

deregister_service() {
     if ${log_trace};then
        logger -s "de-registering by procd"
     fi
}

shutdown() {
        stop
}

debuginfo() {
	if [ -n "${datamodel_root}" ];then
            process_debug_info ${datamodel_root}
	else
		logger -s "Error: debuginfo() failed — DataModel root invalid."
	fi
}

extra_command debuginfo "Show ${name} DataModel Entries"
extra_command shutdown "Shutting down ${name} service"
