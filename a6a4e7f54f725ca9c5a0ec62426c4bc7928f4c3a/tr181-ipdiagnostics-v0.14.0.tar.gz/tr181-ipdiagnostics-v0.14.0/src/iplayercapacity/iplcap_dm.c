/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**********************************************************
* Include files
**********************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_function.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_hierarchy.h>
#include <amxd/amxd_action.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ip_diagnostics_priv.h"
#include "ip_diagnostics.h"
#include "priv_iplcap.h"
#include "iplcap.h"

#define ME "ipd-iplcap"

/**********************************************************
* Macro definitions
**********************************************************/

/**********************************************************
* Type definitions
**********************************************************/

/**********************************************************
* Variable declarations
**********************************************************/
/**
 * @brief Scheduler state for a running IPLayerCapacity test.
 */
static ipd_iplcap_scheduler_t scheduler = {.fd_stdout = 0,
    .fd_stderr = 0,
    .pid = 0,
    .call_id = 0,
    .prev_test = false};

/**********************************************************
* Functions
**********************************************************/
void ipd_iplcap_check(int fd, void* priv) {
    ipd_iplcap_sched_check(fd, priv, &scheduler);
}

amxd_status_t _IPLayerCapacity(UNUSED amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret) {
    amxd_status_t ret_status;
    amxd_func_arg_t* arg = NULL;

    // Validate that all provided arguments exist in function definition
    amxc_var_for_each(value, args) {
        const char* param_name = amxc_var_key(value);
        arg = amxd_function_get_arg(func, param_name);
        if(arg == NULL) {
            return amxd_status_invalid_arg;
        }
    }

    // add IPLayerCapacityAuthCode object to args
    amxd_object_t* iplcap_object = ipd_get_iplcap_object();
    if(iplcap_object != NULL) {
        amxd_object_t* auth_obj = amxd_object_get_child(iplcap_object, IPLCAP_RET_KEY_AUTH_CODE_OBJECT);
        if(auth_obj != NULL) {
            amxc_var_t auth_var;
            amxc_var_init(&auth_var);
            amxc_var_set_type(&auth_var, AMXC_VAR_ID_HTABLE);
            ipd_obj_data_to_var(auth_obj, NULL, &auth_var);

            amxc_var_t* auth_dst = amxc_var_get_key(args, IPLCAP_RET_KEY_AUTH_CODE_OBJECT, AMXC_VAR_FLAG_DEFAULT);
            if(auth_dst == NULL) {
                auth_dst = amxc_var_add_key(amxc_htable_t, args, IPLCAP_RET_KEY_AUTH_CODE_OBJECT, NULL);
            }
            amxc_var_copy(auth_dst, &auth_var);
            amxc_var_clean(&auth_var);
        }
    }

    ipd_iplcap_clean_result_from_dm(ipd_get_iplcap_object());
    ret_status = ipd_iplcap_start(ipd_iplcap_check, &scheduler, args, ret);
    if(ret_status == amxd_status_deferred) {
        amxd_function_defer(func, &(scheduler.call_id), ret, NULL, NULL);
    }
    return ret_status;
}

void _ipd_iplcap_writable_dm_changed(UNUSED const char* const event_name,
                                     const amxc_var_t* const event_data,
                                     UNUSED void* const priv) {
    amxd_object_t* ipd_iplcap_object = amxd_dm_signal_get_object(ipd_get_dm(), event_data);

    when_null(ipd_iplcap_object, exit);

    // Skip if this is a DiagnosticsState change itself
    when_not_null(GETP_ARG(event_data, "parameters.DiagnosticsState.to"), exit);

    // Get current DiagnosticsState value
    const char* current_state = GET_CHAR(amxd_object_get_param_value(ipd_iplcap_object, IPLCAP_RET_KEY_DST), NULL);

    if((current_state != NULL) && (strcmp(current_state, IPLCAP_STATUS_REQUESTED) == 0)) {
        ipd_iplcap_stop(&scheduler);
        // set DiagnosticsState to None
        amxd_object_set_value(cstring_t, ipd_iplcap_object, IPLCAP_RET_KEY_DST, IPLCAP_STATUS_NONE);
    }

exit:
    return;
}

void _ipd_iplcap_check_dst(UNUSED const char* const event_name,
                           const amxc_var_t* const event_data,
                           UNUSED void* const priv) {
    amxd_status_t ret_status = amxd_status_ok;
    amxc_var_t args;
    amxc_var_t ret;
    amxd_object_t* ipd_iplcap_object = NULL;
    const cstring_t dst = GETP_CHAR(event_data, "parameters.DiagnosticsState.to");

    amxc_var_init(&args);
    amxc_var_init(&ret);

    // get IPDiagnostics.IPLayerCapacityMetrics. object from datamodel
    ipd_iplcap_object = ipd_get_iplcap_object();
    when_null_trace(ipd_iplcap_object, exit, ERROR, "Failed to fetch object IPDiagnostics.IPLayerCapacityMetrics. from datamodel.");
    ipd_obj_data_to_var(ipd_iplcap_object, NULL, &args);

    if(strcmp(dst, IPLCAP_STATUS_CANCELED) == 0) {
        ipd_iplcap_stop(&scheduler);
    } else if(strcmp(dst, IPLCAP_STATUS_REQUESTED) == 0) {
        ipd_iplcap_clean_result_from_dm(ipd_iplcap_object);
        ipd_filter_ret(&args, false, IPLCAP);
        ret_status = ipd_iplcap_start(ipd_iplcap_check, &scheduler, &args, &ret);
        when_false_trace(ret_status == amxd_status_deferred, exit, ERROR, "Could not launch the iplcap test with %d error code", ret_status);
    }

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
    return;
}

amxd_status_t _write_iplcapstate_params(amxd_object_t* object,
                                        amxd_param_t* param,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        amxc_var_t* const retval,
                                        void* priv) {
    amxd_status_t rv = amxd_status_unknown_error;
    const char* state = GETP_CHAR(args, "parameters.DiagnosticsState");
    bool set_read_only = GET_BOOL(args, "set_read_only");

    when_true_status(reason != action_object_write, exit, rv = amxd_status_function_not_implemented);

    if(set_read_only || (state == NULL)) {
        rv = amxd_action_object_write(object, param, reason, args, retval, priv);
    } else {
        when_false_status(strcmp(state, IPLCAP_STATUS_REQUESTED) == 0 || strcmp(state, IPLCAP_STATUS_CANCELED) == 0, exit, rv = amxd_status_read_only);
        rv = amxd_action_object_write(object, param, reason, args, retval, priv);
    }
exit:
    return rv;
}
