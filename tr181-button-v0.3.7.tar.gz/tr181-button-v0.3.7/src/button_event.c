/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "button.h"
#include "dm_button.h"

static void button_emit_event(button_event_t* event_info, int64_t interval) {
    amxc_var_t event_data;
    amxc_var_t button_params;
    amxc_var_t button_event_params;
    amxc_var_t actions_reference;
    amxd_object_t* event_instance = button_get_object(event_info->obj_path);
    amxd_object_t* button_instance = amxd_object_get_parent(amxd_object_get_parent(event_instance));
    amxd_object_t* action_instance = NULL;

    amxc_var_init(&event_data);
    amxc_var_init(&button_params);
    amxc_var_init(&button_event_params);
    amxc_var_init(&actions_reference);

    when_null(event_instance, exit);
    when_null(button_instance, exit);
    when_null(event_info, exit);

    amxd_object_get_params(button_instance, &button_params, amxd_dm_access_protected);
    amxd_object_get_params(event_instance, &button_event_params, amxd_dm_access_protected);

    amxc_var_set_type(&event_data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &event_data, "Event", GET_CHAR(&button_event_params, "Name"));
    amxc_var_add_key(cstring_t, &event_data, "Button", GET_CHAR(&button_params, "Name"));
    amxc_var_add_key(uint32_t, &event_data, "Interval", interval);

    SAH_TRACEZ_INFO(ME, "Button [%s] emit event [%s]", GET_CHAR(&button_params, "Name"), GET_CHAR(&button_event_params, "Name"));
    amxd_object_send_signal(event_instance, "ButtonEvent", &event_data, false);

    amxc_var_set(csv_string_t, &actions_reference, GET_CHAR(&button_event_params, "ActionsReference"));
    amxc_var_cast(&actions_reference, AMXC_VAR_ID_LIST);
    amxc_var_for_each(action, &actions_reference) {
        action_instance = button_get_object(GET_CHAR(action, NULL));
        button_action_trigger(action_instance);
    }

exit:
    amxc_var_clean(&event_data);
    amxc_var_clean(&button_params);
    amxc_var_clean(&button_event_params);
    amxc_var_clean(&actions_reference);
    return;
}

void button_event_trigger(button_event_t* event_info, button_status_t status, amxc_ts_t ts) {
    int64_t interval = 0;

    when_null(event_info, exit);
    if(status == BUTTON_PUSHED) {
        if(event_info->type == BUTTON_EVENT_TYPE_PRESSED) {
            button_emit_event(event_info, 0);
        } else if(event_info->type == BUTTON_EVENT_TYPE_RELEASED) {
            event_info->ts_pushed = ts;
        } else if(event_info->type == BUTTON_EVENT_TYPE_TIMEOUT) {
            if(amxp_timer_get_state(event_info->timer) == amxp_timer_running) {
                amxp_timer_stop(event_info->timer);
            }
            amxp_timer_start(event_info->timer, event_info->timeout);
        }
    } else if(status == BUTTON_RELEASED) {
        if(event_info->type == BUTTON_EVENT_TYPE_RELEASED) {
            interval = (ts.sec * 1000 + ts.nsec / 1000000) - (event_info->ts_pushed.sec * 1000 + event_info->ts_pushed.nsec / 1000000);
            if((interval >= event_info->min) && (interval <= event_info->max)) {
                button_emit_event(event_info, interval);
            }
        } else if(event_info->type == BUTTON_EVENT_TYPE_TIMEOUT) {
            if(amxp_timer_get_state(event_info->timer) == amxp_timer_running) {
                amxp_timer_stop(event_info->timer);
            }
        }
    }

exit:
    return;
}

void button_event_clean(amxc_llist_it_t* it) {
    button_event_t* event_info = NULL;

    if(it != NULL) {
        event_info = amxc_container_of(it, button_event_t, ll_it);
        amxc_llist_it_take(it);
        amxp_timer_delete(&event_info->timer);
        free(event_info->obj_path);
        free(event_info);
        event_info = NULL;
    }
}

void button_event_timeout_trigger(amxp_timer_t* timer, void* priv) {
    button_event_t* event_info = (button_event_t*) priv;

    when_null(event_info, exit);
    button_emit_event(event_info, event_info->timeout);
    amxp_timer_stop(timer); // The timer should be executed only once

exit:
    return;
}

void button_event_init(button_event_t* event_info, amxd_object_t* event_instance) {
    amxc_var_t params;
    amxc_var_init(&params);

    when_null(event_info, exit);
    when_null(event_instance, exit);

    event_info->index = atoi(amxd_object_get_name(event_instance, AMXD_OBJECT_INDEXED));
    amxd_object_get_params(event_instance, &params, amxd_dm_access_protected);
    event_info->enabled = GET_BOOL(&params, "Enable");
    event_info->min = GET_UINT32(&params, "Min");
    event_info->max = GET_INT32(&params, "Max");
    event_info->timeout = GET_UINT32(&params, "Timeout");
    if(strcmp("Pressed", GET_CHAR(&params, "Type")) == 0) {
        event_info->type = BUTTON_EVENT_TYPE_PRESSED;
    } else if(strcmp("Released", GET_CHAR(&params, "Type")) == 0) {
        event_info->type = BUTTON_EVENT_TYPE_RELEASED;
    } else if(strcmp("Timeout", GET_CHAR(&params, "Type")) == 0) {
        event_info->type = BUTTON_EVENT_TYPE_TIMEOUT;
    }
    event_info->obj_path = amxd_object_get_path(event_instance, AMXD_OBJECT_INDEXED);
    event_instance->priv = event_info;
    when_failed(amxp_timer_new(&(event_info->timer), button_event_timeout_trigger, event_info), exit);

exit:
    amxc_var_clean(&params);
}
