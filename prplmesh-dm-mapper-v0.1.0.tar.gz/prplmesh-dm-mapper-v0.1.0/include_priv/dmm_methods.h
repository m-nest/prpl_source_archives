/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_methods.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief Header file describes public methods (RPC) of the DataModel Mapper functionality.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#if !defined(__DMM_METHODS_H__)
#define __DMM_METHODS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "dmm.h"

/**
 * @brief RPC call that forwards the request and processes the reply with path translation.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done_transl_path callback for
 * translating paths within the returned data (e.g., for _get_supported, _describe functions).
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_transl_path(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret);

/**
 * @brief RPC call that forwards the request and processes the reply with data translation.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done_transl_data callback for
 * translating data within the returned result (e.g., for _get, _set functions).
 * Optionally, RPC uses synchronous RPC call if args.depth == 0
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_transl_path_optional_sync(amxd_object_t* object,
                                                amxd_function_t* func,
                                                amxc_var_t* args,
                                                amxc_var_t* ret);

/**
 * @brief RPC call that forwards the request and processes the reply with data translation.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done_transl_data callback for
 * translating data within the returned result (e.g., for _get, _set functions).
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_transl_data(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret);

/**
 * @brief RPC call that forwards the request and processes the reply with translation
 * for multiple data elements.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done_transl_data_multiple callback.
 * Suitable for functions requiring multiple data translations in the response.
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_transl_data_multiple(amxd_object_t* object,
                                           amxd_function_t* func,
                                           amxc_var_t* args,
                                           amxc_var_t* ret);

/**
 * @brief General RPC call that forwards the request using the standard completion callback.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done callback.
 * Suitable for most standard commands.
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc(amxd_object_t* object,
                      amxd_function_t* func,
                      amxc_var_t* args,
                      amxc_var_t* ret);

/**
 * @brief RPC call specifically designed for handling list responses.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_list_done callback.
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_list(amxd_object_t* object,
                           amxd_function_t* func,
                           amxc_var_t* args,
                           amxc_var_t* ret);

/**
 * @brief Creates a supported path template from an indexed path
 *
 * Replaces indices in an instance path with placeholders
 * (e.g., would turn "Object.1.Param" into "Object.{i}.Param")
 *
 * @param[in] indexed_path Path containing instance indices
 * @return Pointer to a new string with the path template. The caller must free the memory
 */
char* dmm_build_supported_path(const char* indexed_path);

/**
 * @brief RPC call for the delete operation (_del) with list path translation.
 *
 * Uses dmm_rpc_impl and sets the dmm_rpc_done_transl_list callback.
 * This is needed for correct path translation in the response after a delete operation.
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t.
 * @param args amxc_var_t containing arguments.
 * @param ret amxc_var_t where the result will be written.
 * @return amxd_status_t Execution status (amxd_status_deferred or immediate status).
 */
amxd_status_t dmm_rpc_del(amxd_object_t* object,
                          amxd_function_t* func,
                          amxc_var_t* args,
                          amxc_var_t* ret);

/**
 * @brief Public function implementing the AMX Data Model `_subscribe` functionality.
 *
 * This is the entry point for subscribing to events on objects managed by the DMM.
 * 1. Determines the full path for the subscription (object + relative path).
 * 2. Gets the real (backend) path (`pobj`).
 * 3. If a direct real path is found, it calls `dmm_subscription` directly.
 * 4. If no direct real path is found (e.g., subscribing to a multi-instance
 * object that hasn't been instantiated yet), it initiates a hierarchy walk
 * using `amxd_object_hierarchy_walk` with `dmm_check_tree` to find all currently
 * mapped descendants that need subscription.
 *
 * @param object The amxd_object_t for which the subscription is called.
 * @param func Unused.
 * @param args amxc_var_t containing subscription arguments (e.g., "rel_path").
 * @param ret Unused.
 * @return amxd_status_t Returns amxd_status_ok on success, or an error status.
 */
amxd_status_t dmm_subscribe(amxd_object_t* object,
                            amxd_function_t* func,
                            amxc_var_t* args,
                            amxc_var_t* ret);

/**
 * @brief Public function implementing the AMX Data Model `_unsubscribe` functionality.
 *
 * This is the entry point for unsubscribing from events.
 * 1. Determines the full path for the unsubscription.
 * 2. Finds the bus context associated with the fixed part of the real path.
 * 3. Iterates through the local list of subscriptions (`subscriptions`).
 * 4. If a matching subscription is found:
 * a. Decrements the reference count of the associated `map_info_t`.
 * b. If the reference count drops to zero, calls `dmm_remove_subscription`
 * to remove the subscription from the bus and the local list.
 *
 * @param object The amxd_object_t for which the unsubscription is called.
 * @param func Unused.
 * @param args amxc_var_t containing unsubscription arguments (e.g., "rel_path").
 * @param ret Unused.
 * @return amxd_status_t Returns amxd_status_ok on success, or an error status.
 */
amxd_status_t dmm_unsubscribe(amxd_object_t* object,
                              amxd_function_t* func,
                              amxc_var_t* args,
                              amxc_var_t* ret);

/**
 * @brief Removes all active and pending subscriptions.
 *
 * This function cleans up all resources related to subscriptions when the DMM shuts down.
 * 1. Cleans the `subscriptions` list using `dmm_remove_subscription` for cleanup.
 * 2. Cleans the `pending_waits` list using `dmm_remove_pending` to free deferred arguments.
 */
void dmm_remove_subscriptions(void);


/**
 * @brief Strictly replaces the "{i}" placeholders in a path template with numerical indices from another string.
 *
 * This function performs a **strict** substitution: it attempts to match the entire input string
 * `str_i` against the pattern template `str_ph`. Whenever "{i}" is found in the pattern, it
 * expects a **consecutive sequence of digits** (an instance index) in the input string at the
 * corresponding position. The extracted numerical index replaces the "{i}" in `str_ph`.
 * All other characters in `str_ph` must match the corresponding characters in `str_i` exactly.
 * `str_i` may have more tokens than `str_ph` if they are not placeholders.
 *
 * @param[in,out] str_ph The path pattern string containing "{i}" placeholders. This buffer is modified in place.
 * @param[in] ph_buf_size The size of the `str_ph` buffer.
 * @param[in] str_i The concrete path string containing instance indices (e.g., "Object.1.SubObject.3.Param").
 * @return Pointer to the modified `str_ph` buffer on successful replacement and match (the resulting concrete path), or NULL if:
 * - The strings do not match (e.g., a character mismatch or if `str_i` is not fully consumed).
 * - A non-digit character is found where "{i}" expects an index in `str_i`.
 * - The substitution would overflow the `str_ph` buffer.
 *
 * @note This function is useful for verifying if a concrete indexed path (`str_i`) matches a specific
 * path template (`str_ph`) and simultaneously substituting the indices into the template.
 */
char* dmm_indexes_replace_strict(char* str_ph, size_t ph_buf_size, const char* str_i);

/**
 * @brief Substitute "{i}" placeholders in `str_ph` with numeric tokens from `str_i`.
 *
 * This function performs token-by-token processing of two strings separated by '.'.
 * The token at the same position in `str_i` replaces "{i}" in `str_ph`. Other tokens
 * in `str_ph` are kept unchanged, and no comparison with `str_i` is performed.
 *
 * Rules:
 * - Tokens are split using '.'.
 * - If a token in `str_ph` equals "{i}", the corresponding token in `str_i` must be numeric.
 * - Tokens in `str_ph` that are not "{i}" remain unchanged.
 * - Both strings must have the same number of tokens.
 * - Replacement is done in-place into `str_ph`, using an internal temporary buffer.
 * - No memory allocation is performed.
 *
 * @param[in,out] str_ph       Input/output string containing placeholders "{i}".
 * @param[in]     ph_buf_size  Size of the buffer pointed to by `str_ph`.
 * @param[in]     str_i        Input string containing real numeric values.
 *
 * @return char*
 * @retval str_ph on success (with substitutions applied)
 * @retval NULL   on error, such as:
 *                 - insufficient number of tokens in str_i
 *                 - placeholder token without numeric content
 *                 - result does not fit in str_ph buffer
 *                 - token count mismatch
 */
char* dmm_indexes_replace(char* str_ph, size_t ph_buf_size, const char* str_i);


/**
 * @brief Finds and returns the deepest mapped subpath of an object.
 *
 * This function iterates through the components of the input path to find
 * the deepest existing object in the data model that matches the prefix.
 *
 * Convenient for checking whether the mapper is servicing this object at all
 * and whether modifications need to be applied to it.
 *
 * @param[in] in_path amxc_var_t variable containing the object path string (GET_CHAR(in_path, NULL)).
 * @return Pointer to a new string with the path of the found object, or NULL if only the root is found.
 * The caller is responsible for freeing the returned string.
 */
char* dmm_get_mapped_subpath(amxc_var_t* in_path);

/**
 * @brief Checks if a return variable (ret) is a Data Model response for the specified object.
 *
 * Verifies the presence of mandatory DM-specific fields (is_multi_instance, supported_commands,
 * supported_events, supported_params) for the entity given by entity_path within the ret variable.
 *
 * @param[in] entity_path String path to the entity (object).
 * @param[in] ret amxc_var_t variable containing the response to check.
 * @return true if the response contains all necessary DM fields for the entity, false otherwise.
 */
bool dmm_is_ret_dm_resp(const char* entity_path, amxc_var_t* ret);

/**
 * @brief Finds an entity (object, parameter, command, or event) by path in a DM response and
 * potentially "takes" it from the response structure.
 *
 * This function searches for the entity specified by entity_path within the DM response structure.
 * If found, it can either store the pointer in entity_taken_var, or "take" it from the parent
 * variable (if do_take == true), effectively removing it from the response.
 *
 * @param[in] entity_path Full path to the entity to find.
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 * @param[out] entity_taken_var Pointer to a variable to store the pointer to the found entity. Can be NULL.
 * @param[in] do_take If true, the entity is "taken" (removed and possibly cleaned/transferred) from ret.
 * @return 0 on successful finding/taking of the entity, -1 on error or if the entity is not found.
 */
int dmm_take_entity_by_path_in_dm_resp(const char* entity_path, amxc_var_t* ret, amxc_var_t** entity_taken_var, bool do_take);

/**
 * @brief Finds and "takes" an entity by path from a ret.
 *
 * Similar to dmm_take_entity_by_path_in_dm_resp, but uses standard key search (GETP_ARG)
 * for non-DM response structures, which typically have a simpler structure (object path -> parameter/value).
 *
 * @param[in] entity_path Full path to the entity (object.parameter or object only).
 * @param[in,out] ret amxc_var_t variable containing the data.
 * @param[out] entity_taken_var Pointer to a variable to store the pointer to the found entity. Can be NULL.
 * @param[in] do_take If true, the entity is "taken" from ret.
 * @return 0 on successful finding/taking of the entity, -1 otherwise.
 */
int dmm_take_entity_by_path(const char* entity_path, amxc_var_t* ret, amxc_var_t** entity_taken_var, bool do_take);

/**
 * @brief Removes entities from a DM response that match a given path template.
 *
 * Iterates over the objects in ret. If the object path or the object+parameter path
 * matches the given template, the corresponding entity is removed (take + clean) from ret.
 *
 * @param[in] template Path template (e.g., "Object.{i}.Param" or "Object.{i}.").
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 */
void dmm_remove_entity_by_template(const char* template, amxc_var_t* ret);

/**
 * @brief Processes the hiding of entities within the data model response.
 *
 * Iterates over the global list of hidden entities (`hide_po_list`). For each entity,
 * it determines the response type (`dmm_is_ret_dm_resp`) and calls the corresponding
 * function to remove the entity: `dmm_take_entity_by_path_in_dm_resp` or `dmm_remove_entity_by_template`.
 *
 * @param[in,out] minfo amxc_var_t variable containing the DM response from which to remove hidden entities.
 * @return 0 on success, -1 on error.
 * @note Requires the existence of a global variable `hide_po_list`.
 */
int dmm_hide_proc(map_info_t* minfo);

/**
 * @brief Executes the move/rename operation for entities in a non-DM response based on a path template.
 *
 * Iterates over the objects in `ret`. If the object path matches `orig_template`,
 * the new path `rn_path_sub_i` is calculated with index substitution, and the corresponding
 * rename function is called based on the operation type (`DMM_RN_PARAM`, `DMM_RN_OBJ`, etc.)
 * determined by `dmm_move_get_type`.
 *
 * @param[in] orig_template Original path template (e.g., "Object.{i}.Param").
 * @param[in] rn_template New path template.
 * @param[in,out] ret amxc_var_t variable containing the data.
 * @return 0 on success, -1 on error.
 * @note Only handles DMM_RN_PARAM, DMM_RN_OBJ, DMM_RN_OBJ_RN_PARAM types.
 */
int dmm_move_entity_by_path(const char* orig_template, const char* rn_template, amxc_var_t* ret);

/**
 * @brief Executes the move/rename operation for entities within a DM response.
 *
 * Determines the operation type (`mv_rn_type`) and calls the corresponding DM-specific
 * rename function (`dmm_rn_param_dm_resp`, `dmm_rn_obj`, `dmm_rn_obj_rn_param_dm_resp`).
 *
 * @param[in] orig_path Original path of the entity.
 * @param[in] rn_path New path of the entity.
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 * @return 0 on success, -1 on error or incompatible operation type.
 */
int dmm_move_entity_by_path_in_dm_resp(const char* orig_path, const char* rn_path, amxc_var_t* ret);

/**
 * @brief Processes the renaming of entities within the data model response.
 *
 * Iterates over the global rename table (`rename_po`). For each rename entry,
 * it determines the DM response type (`dmm_is_ret_dm_resp`) and calls the corresponding
 * move/rename function (`dmm_move_entity_by_path_in_dm_resp` or `dmm_move_entity_by_path`).
 *
 * @param[in,out] minfo amxc_var_t variable containing the DM response to be modified.
 * @return 0 on success, -1 on error.
 * @note Requires the existence of a global variable `rename_po`.
 */
int dmm_rename_proc(map_info_t* minfo);

/**
 * @brief Processes the revert rename operation in a request.
 *
 * @param[in,out] args amxc_var_t variable containing the request to be modified.
 * @param[in] object amxd_object_t object associated with the request.
 * @param[out] backward_node backward node for the nonterminal part.
 * @return amxd_status_t status code.
 */
amxd_status_t dmm_revert_rename_proc(amxc_var_t* args, const amxd_object_t* object, const TreeNode** backward_node);

#ifdef __cplusplus
}
#endif

#endif // __DMM_METHODS_H__
