/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "deprecated/nat_pormapping.h"
#include "deprecated/fw_interfacesetting.h"
#include "interfacesetting/dm_interfacesetting.h"
#include "firewall.h"
#include "firewall_utilities.h"
#include "init_cleanup.h"
#include <amxc/amxc_macros.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxs/amxs.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#define ME "Firewall"
typedef struct {
    amxs_sync_ctx_t* sync;
} deprecated_ifsetting_t;

amxd_status_t _on_write_deprecated_portmap_origin(amxd_object_t* object,
                                                  amxd_param_t* param,
                                                  amxd_action_t reason,
                                                  const amxc_var_t* const args,
                                                  amxc_var_t* const retval,
                                                  void* priv) {
    amxc_var_t* deprecated_values = (amxc_var_t*) priv;
    amxd_status_t status = amxd_status_unknown_error;
    const char* convert_to = NULL;

    when_null(deprecated_values, exit);

    convert_to = GET_CHAR(deprecated_values, GET_CHAR(args, NULL));
    if(convert_to != NULL) {
        amxc_var_set(cstring_t, (amxc_var_t*) args, convert_to);
    }

    status = amxd_action_param_write(object, param, reason, args, retval, priv);

exit:
    return status;
}


amxd_status_t _on_destroy_deprecated_ifsetting(amxd_object_t* object,
                                               UNUSED amxd_param_t* param,
                                               amxd_action_t reason,
                                               UNUSED const amxc_var_t* const args,
                                               UNUSED amxc_var_t* const retval,
                                               UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    deprecated_ifsetting_t* ifsetting = NULL;

    when_null_trace(object, exit, ERROR, "Object is NULL");
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);

    when_null_status(object->priv, exit, status = amxd_status_ok);
    ifsetting = (deprecated_ifsetting_t*) object->priv;

    if(ifsetting->sync != NULL) {
        amxs_sync_ctx_delete(&ifsetting->sync);
    }
    FREE(object->priv);

    status = amxd_status_ok;
exit:
    return status;
}

static void deprecated_ifsetting_init(amxd_object_t* ifsetting_obj_a) {
    const char* alias = NULL;
    deprecated_ifsetting_t* ifsetting = NULL;
    amxd_object_t* ifsetting_obj_b = NULL;
    char* path_obj_a = NULL;
    char* path_obj_b = NULL;
    bool added = false;

    when_null(ifsetting_obj_a, exit);
    when_not_null_trace(ifsetting_obj_a->priv, exit, ERROR, "Already has priv data");

    alias = object_da_string(ifsetting_obj_a, "Alias");
    when_str_empty_trace(alias, exit, ERROR, "Missing Alias");

    ifsetting_obj_b = amxd_object_findf(fw_ifsetting_template(), ".%s.", alias);

    if(ifsetting_obj_b != NULL) {
        // if it exists I assume syncing is not needed because it is loaded from persistant ODL and it has the updated values
        SAH_TRACEZ_INFO(ME, "Not syncing because Firewall.InterfaceSetting.[Alias=='%s'] already exists", alias);
        goto exit;
    } else {
        amxd_trans_t trans;
        int rv = amxd_status_unknown_error;

        // doing the calloc first because, in case it fails, I don't have to remove the added Firewall.InterfaceSetting.
        ifsetting = (deprecated_ifsetting_t*) calloc(1, sizeof(deprecated_ifsetting_t));
        when_null(ifsetting, exit);
        ifsetting_obj_a->priv = ifsetting;

        amxd_trans_init(&trans);
        amxd_trans_select_object(&trans, fw_ifsetting_template());
        amxd_trans_add_inst(&trans, 0, alias);
        amxd_trans_set_value(cstring_t, &trans, "Interface", object_da_string(ifsetting_obj_a, "Interface"));

        rv = amxd_trans_apply(&trans, fw_get_dm());
        amxd_trans_clean(&trans);

        when_failed_trace(rv, error, ERROR, "Failed to sync deprecated InterfaceSetting with alias '%s'", alias);

        added = true;

        ifsetting_obj_b = amxd_object_findf(fw_ifsetting_template(), ".%s.", alias);
        when_null_trace(ifsetting_obj_b, error, ERROR, "Failed to sync deprecated InterfaceSetting with alias '%s'", alias);
    }

    path_obj_a = amxd_object_get_path(ifsetting_obj_a, AMXD_OBJECT_INDEXED);
    path_obj_b = amxd_object_get_path(ifsetting_obj_b, AMXD_OBJECT_INDEXED);

    ifsetting->sync = amxo_parser_new_sync_ctx("A2B", path_obj_a, path_obj_b);
    FREE(path_obj_a);
    FREE(path_obj_b);

    when_null_trace(ifsetting->sync, error, ERROR, "Failed to sync deprecated InterfaceSetting with alias '%s'", alias);

    when_failed_trace(amxs_sync_ctx_start_sync(ifsetting->sync), error, ERROR, "Failed to sync deprecated InterfaceSetting with alias '%s'", alias);

exit:
    return;
error:
    if(ifsetting != NULL) {
        if(ifsetting->sync != NULL) {
            amxs_sync_ctx_delete(&ifsetting->sync);
        }
        free(ifsetting);
    }
    ifsetting_obj_a->priv = NULL;
    if(added) {
        amxd_trans_t trans;
        int rv = amxd_status_unknown_error;
        amxd_trans_init(&trans);
        amxd_trans_select_object(&trans, fw_ifsetting_template());
        amxd_trans_del_inst(&trans, 0, alias);
        rv = amxd_trans_apply(&trans, fw_get_dm());
        amxd_trans_clean(&trans);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to sync deprecated InterfaceSetting with alias '%s'", alias);
        }
    }
}

void _on_added_deprecated_ifsetting(UNUSED const char* const sig_name,
                                    const amxc_var_t* const event_data,
                                    UNUSED void* const priv) {
    amxd_object_t* ifsetting_templ = amxd_dm_signal_get_object(fw_get_dm(), event_data);
    amxd_object_t* ifsetting_obj = amxd_object_get_instance(ifsetting_templ, NULL, GET_UINT32(event_data, "index"));
    when_null(ifsetting_obj, exit);
    deprecated_ifsetting_init(ifsetting_obj);
exit:
    return;
}

void deprecated_ifsetting_init_all(void) {
    amxd_object_for_each(instance, it, amxd_dm_findf(fw_get_dm(), "Firewall.%sInterfaceSetting.", fw_get_vendor_prefix())) {
        amxd_object_t* ifsetting_obj = amxc_container_of(it, amxd_object_t, it);
        deprecated_ifsetting_init(ifsetting_obj);
    }
}

amxs_status_t _translate_param(const amxs_sync_entry_t* entry,
                               amxs_sync_direction_t direction,
                               const amxc_var_t* input,
                               amxc_var_t* output,
                               UNUSED void* priv) {
    amxs_status_t status = amxs_status_unknown_error;
    amxc_var_t* params = GET_ARG(input, "parameters");
    amxc_var_t* output_params = NULL;
    const char* path = GET_CHAR(input, "path");
    const char* notification = GET_CHAR(input, "notification");
    const char* entry_name = amxs_sync_entry_get_name(entry, direction);
    char* opposite_path = NULL;

    when_null(params, exit);
    when_str_empty(path, exit);
    when_str_empty(entry_name, exit);
    when_str_empty(notification, exit);

    opposite_path = amxs_sync_entry_get_opposite_parent_path(entry, direction, path);
    when_str_empty(opposite_path, exit);

    amxc_var_set_type(output, AMXC_VAR_ID_HTABLE);
    output_params = amxc_var_add_key(amxc_htable_t, output, "parameters", NULL);
    amxc_var_add_key(cstring_t, output, "path", opposite_path);

    amxc_var_for_each(param, params) {
        if(strcmp(amxc_var_key(param), entry_name) == 0) {
            const char* value = NULL;
            amxc_var_t* new_param = NULL;

            if((strcmp(notification, "sync:init-param") == 0) ||
               (strcmp(notification, "dm:object-added") == 0)) {
                value = GET_CHAR(param, NULL);
            } else {
                value = GET_CHAR(param, "to");
            }
            when_null_trace(value, exit, ERROR, "Failed to convert param '%s' to string", entry_name); // for now only support the 2 string type parameters

            if(strcmp(entry_name, "AcceptICMPEchoRequest") == 0) {
                bool enable = false;

                new_param = amxc_var_add_new_key(output_params, "IPv4AcceptICMPEchoRequest");
                enable = ((strcmp(value, "allow_ipv4") == 0) || (strcmp(value, "allow_both") == 0));
                amxc_var_set(bool, new_param, enable);

                new_param = amxc_var_add_new_key(output_params, "IPv6AcceptICMPEchoRequest");
                enable = ((strcmp(value, "allow_ipv6") == 0) || (strcmp(value, "allow_both") == 0));
                amxc_var_set(bool, new_param, enable);
            } else if(strcmp(entry_name, "SpoofingProtection") == 0) {
                bool enable = false;

                new_param = amxc_var_add_new_key(output_params, "IPv4SpoofingProtection");
                enable = ((strcmp(value, "ipv4") == 0) || (strcmp(value, "both") == 0));
                amxc_var_set(bool, new_param, enable);

                new_param = amxc_var_add_new_key(output_params, "IPv6SpoofingProtection");
                enable = ((strcmp(value, "ipv6") == 0) || (strcmp(value, "both") == 0));
                amxc_var_set(bool, new_param, enable);
            } else if(strcmp(entry_name, "IsolateInterface") == 0) {
                amxc_string_t iface;

                // We want to let the IsolateInterface reference the Firewall.InterfaceSetting and not the deprecated Firewall.X_InterfaceSetting.
                amxc_string_init(&iface, 0);
                amxc_string_set(&iface, value);
                amxc_string_replace(&iface, fw_get_vendor_prefix(), "", UINT32_MAX);
                new_param = amxc_var_add_new_key(output_params, amxs_sync_entry_get_opposite_name(entry, direction));
                amxc_var_set(cstring_t, new_param, amxc_string_get(&iface, 0));
                amxc_string_clean(&iface);
            } else {
                SAH_TRACEZ_ERROR(ME, "Unknown parameter to translate: '%s'", entry_name);
                goto exit;
            }
        }
    }

    status = amxs_status_ok;

exit:
    free(opposite_path);
    return status;
}
