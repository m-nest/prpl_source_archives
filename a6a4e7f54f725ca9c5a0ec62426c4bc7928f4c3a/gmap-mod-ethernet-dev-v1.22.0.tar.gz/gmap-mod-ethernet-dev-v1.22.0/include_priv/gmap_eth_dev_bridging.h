/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_ETH_DEV_BRIDGING_H__)
#define __GMAP_ETH_DEV_BRIDGING_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file Observes Bridging.Bridge.* to discover its ports and MAC addresses
 */


#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <stdint.h>
#include <stdbool.h>

#include "gmap_eth_dev_bridge.h"


/**
 * @defgroup bridging
 *
 * @{
 */

/**
 * @defgroup bridging_discovery
 *
 * `Bridging.Bridge.` is not available or fully supported by gmap-mod-ethernet-dev
 * on every system. These functions allow discovering whether bridging may be
 * used or whether gmap-mod-ethernet-dev should fall back to the BridgeTable
 * entries in NetDev.
 *
 * @{
 */

/** Result of the `Bridging.` discovery process. */
typedef enum {
    /**
     * The discovery process was not started yet, is in progress or was canceled
     * before a proper result could be obtained.
     * @see gmap_eth_dev_bridging_start_discovery
     */
    BRIDGING_DISCOVERY_UNKNOWN,
    /**
     * A supported context for `Bridging.Bridge.` was found on this system and
     * may be retrieved with @ref gmap_eth_dev_bridging_ctx.
     */
    BRIDGING_DISCOVERY_SUPPORTED,
    /**
     * The system either doesn't contain the `Bridging.Bridge.` data model,
     * it is unsupported or there was an error during discovery.
     */
    BRIDGING_DISCOVERY_NOT_SUPPORTED,
} gmap_eth_dev_bridging_discovery_result_t;

typedef void (* gmap_eth_dev_bridging_discovery_cb)(gmap_eth_dev_bridging_discovery_result_t result);

/**
 * Starts the `Bridging.Bridge.` discovery process.
 *
 * If there is already a discovery process ongoing, a call to this function will
 * not interrupt or delay that process nor start a second one.
 *
 * If a previous discovery process has finished already, the given callback is
 * executed immediately with its result.
 *
 * If starting the discovery process fails, the callback is executed immediately
 * with @ref BRIDGING_DISCOVERY_NOT_SUPPORTED and non-zero is returned.
 *
 * Otherwise, if the discovery process is not canceled before @param timeout_ms
 * milliseconds have passed, the callback will be called from the event loop with
 * either @ref BRIDGING_DISCOVERY_SUPPORTED or @ref BRIDGING_DISCOVERY_NOT_SUPPORTED.
 *
 * @param cb Callback function to be executed when the discovery process has finished.
 * @param timeout_ms Time in milliseconds after which the discovery process will
 *                   automatically fail.
 * @return 0 on success, non-0 otherwise.
 */
int PRIVATE gmap_eth_dev_bridging_start_discovery(gmap_eth_dev_bridging_discovery_cb cb,
                                                  uint32_t timeout_ms);

/** Cancels any ongoing discovery process. The callback of a canceled discovery is *not* called. */
void PRIVATE gmap_eth_dev_bridging_cancel_discovery(void);

/** Cancels any ongoing discovery process and clears any previous result. */
void PRIVATE gmap_eth_dev_bridging_reset_discovery(void);

/** @return the result of the last finished discovery process, or @ref BRIDGING_DISCOVERY_UNKNOWN. */
gmap_eth_dev_bridging_discovery_result_t PRIVATE gmap_eth_dev_bridging_discovered(void);
/**
 * @return the valid and supported `Bridging.Bridge.` bus context, or
 *         `NULL` if unsupported or unknown.
 */
amxb_bus_ctx_t* PRIVATE gmap_eth_dev_bridging_ctx(void);

/** @} */ // end of group bridging_discovery

/**
 * @defgroup bridging_listener
 *
 * This module listens to events from the `Bridging.Bridge.` data model and
 * translates them into callbacks for when ports are discovered and mac addresses
 * are added to or removed from that port's mac table.
 *
 * The module is organized as a singleton.
 *
 * @{
 */
int PRIVATE gmap_eth_dev_bridging_init(void);
void PRIVATE gmap_eth_dev_bridging_clean(void);

/**
 * Callback data for @ref gmap_eth_dev_bridging_port_cb.
 *
 * If the information must be retained after the callback function returns, a
 * deep copy must be made. None of the memory pointed to by any of the pointers
 * in this struct is guaranteed to remain available and valid.
 */
typedef struct gmap_eth_dev_bridging_port_data {
    /** NetDev name of the bridge instance. */
    const char* bridge;
    /** NetDev index of the bridge instance. */
    uint32_t bridge_index;

    /** NetDev name of the port instance. */
    const char* port;
    /** NetDev index of the port instance. */
    uint32_t port_index;
} gmap_eth_dev_bridging_port_data_t;

typedef void (* gmap_eth_dev_bridging_port_cb)(const gmap_eth_dev_bridging_port_data_t* data,
                                               bool added,
                                               void* priv);

typedef struct gmap_eth_dev_bridging_port_subscription gmap_eth_dev_bridging_port_subscription_t;

void PRIVATE gmap_eth_dev_bridging_subscribe_port(gmap_eth_dev_bridging_port_subscription_t** subscription,
                                                  const char* bridge_netdev_name,
                                                  gmap_eth_dev_bridging_port_cb cb,
                                                  void* priv);

void PRIVATE gmap_eth_dev_bridging_unsubscribe_port(gmap_eth_dev_bridging_port_subscription_t** subscription);

typedef void (* gmap_eth_dev_bridging_addr_cb)(const char* mac_address,
                                               bool added,
                                               void* const priv);

typedef struct gmap_eth_dev_bridging_mac_subscription gmap_eth_dev_bridging_mac_subscription_t;

void PRIVATE gmap_eth_dev_bridging_subscribe_mac(gmap_eth_dev_bridging_mac_subscription_t** subscription,
                                                 const char* bridge_netdev_name,
                                                 const char* port_netdev_name,
                                                 gmap_eth_dev_bridging_addr_cb cb,
                                                 void* priv);

void PRIVATE gmap_eth_dev_bridging_unsubscribe_mac(gmap_eth_dev_bridging_mac_subscription_t** subscription);

/**
 * Returns a table with mac addresses for the given port.
 *
 * The returned table contains items of [mac address] -> [uint32_t variant port index].
 *
 * @internal
 * The returned port indices are always the same as the port parameter. The
 * interface is chosen to be compatible with gmap_eth_dev_bridgetable_macs_for_port.
 * @endinternal
 *
 * @note The returned table must be deleted with
 * @code{.c}
 * amxc_htable_delete(&macs_for_port, variant_htable_it_free);
 * @endcode
 *
 * @param port_netdev_index The NetDev index of the port.
 * @return a newly allocated htable with (mac -> port index) entries,
 * @retval `NULL` on error or if the table would have been empty.
 */
amxc_htable_t* PRIVATE gmap_eth_dev_bridging_macs_for_port(uint32_t port_netdev_index);

/** @} */ // end of group bridging_listener

/**
 * @defgroup bridging_linking
 *
 * Links the information gotten by @ref bridging_listener back to gmap.
 *
 * @{
 */

typedef struct gmap_eth_dev_bridging_linker gmap_eth_dev_bridging_linker_t;

void PRIVATE gmap_eth_dev_bridging_linker_new(gmap_eth_dev_bridging_linker_t** bridging_linker,
                                              const gmap_eth_dev_bridge_t* bridge);
void PRIVATE gmap_eth_dev_bridging_linker_delete(gmap_eth_dev_bridging_linker_t** bridging_linker);

/** @} */ // end of group bridging_linking
/** @} */ // end of group bridging

#ifdef __cplusplus
}
#endif

#endif