/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, hzave made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "tr181-cpu.h"
#include "cpu_dm.h"
#include "cpu_dm_utils.h"
#include "cpu_utils.h"

#define ME "cpu-dm-actions"

/**
   @ingroup  CPU Plugin
   @defgroup cpu_dm_dvfs_actions
 */

/**
   @ingroup  cpu_dm_dvfs_actions
   Checks if a value is in the list of supported values.

   This helper function validates that a proposed value (typically a governor
   name) exists in the list of supported values read from sysfs. It converts
   the supported values to a list and compares each element.

   Why needed: The kernel provides a list of available governors like
   "performance powersave ondemand". We need to ensure users only set
   values that the system actually supports.

   @param supported_values List of supported values (will be modified)
   @param value The value to check
   @return true if value is in the supported list, false otherwise
 */
static bool cpu_is_valid_scaling_governor(amxc_var_t* supported_values, const amxc_var_t* value) {
    bool retval = false;
    int result = 0;

    // Convert CSV string to list for easier iteration
    amxc_var_cast(supported_values, AMXC_VAR_ID_CSV_STRING);
    amxc_var_cast(supported_values, AMXC_VAR_ID_LIST);

    amxc_var_for_each(supported_value, supported_values) {
        if(amxc_var_compare(supported_value, value, &result) != 0) {
            continue;
        }
        if(result == 0) {
            retval = true;
            break;
        }
    }

    return retval;
}

/**
   @ingroup  cpu_dm_dvfs_actions
   Action handler for reading DVFS parameters directly from sysfs.

   This read handler fetches the current value from the system rather than
   returning the stored data model value. This ensures the data model always
   reflects the actual system state, even if something outside our application
   modified the sysfs files.

   Why read from sysfs: The system state is the source of truth. Other tools
   or kernel events could change CPU settings, and we want to report accurate
   current values. If sysfs read fails, we fall back to the stored value.

   @param object The DVFS object being read
   @param param The parameter being read
   @param reason The action reason (must be action_param_read)
   @param args Additional arguments
   @param retval Output: the parameter value
   @param priv Private data: the sysfs filename to read
   @return Status code
 */
amxd_status_t _cpu_read_value(amxd_object_t* object,
                              UNUSED amxd_param_t* param,
                              amxd_action_t reason,
                              UNUSED const amxc_var_t* args,
                              amxc_var_t* retval,
                              void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    const char* cpu_name = NULL;
    amxc_var_t* filename = (amxc_var_t*) priv;

    when_true_status(reason != action_param_read, exit, status = amxd_status_function_not_implemented);
    when_null_trace(object, exit, ERROR, "Object is NULL");

    cpu_name = cpu_dm_dvfs_get_cpu_name(object);

    // Empty cpu_name means we're reading the template, not an instance
    if((cpu_name != NULL) && (cpu_name[0] != 0)) {
        // Try to read current value from sysfs
        if(cpu_read_value(cpu_name, GET_CHAR(filename, NULL), retval) == 0) {
            amxc_var_cast(retval, amxd_param_get_type(param));
        } else {
            // Fall back to stored value if sysfs read fails
            amxd_action_param_read(object, param, action_param_read, args, retval, priv);
        }
    } else {
        // For template, return stored default value
        amxd_action_param_read(object, param, action_param_read, args, retval, priv);
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
   @ingroup  cpu_dm_dvfs_actions
   Action handler for reading DVFS parameters with Enable check.

   This is similar to _cpu_read_value, but it checks the Enable parameter first.
   It behaves differently for public vs. protected access:

   - Public access + Enable=false: Returns stored value (doesn't read from sysfs)
   - Public access + Enable=true: Reads from sysfs
   - Protected access (internal): Always reads from sysfs

   Why the Enable check: When DVFS is disabled, we don't want to show the
   current system values (which might be defaults or set by other tools).
   Instead, we show the configured values that will be applied when enabled.
   This gives users a consistent view of their configuration.

   @param object The DVFS object being read
   @param param The parameter being read
   @param reason The action reason (must be action_param_read)
   @param args Additional arguments (including access level)
   @param retval Output: the parameter value
   @param priv Private data: the sysfs filename to read
   @return Status code
 */
amxd_status_t _cpu_read_value_checked(amxd_object_t* object,
                                      amxd_param_t* param,
                                      amxd_action_t reason,
                                      const amxc_var_t* args,
                                      amxc_var_t* retval,
                                      void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    const char* cpu_name = NULL;
    amxd_dm_access_t access = amxd_dm_access_public;
    amxc_var_t* filename = (amxc_var_t*) priv;

    when_true_status(reason != action_param_read, exit, status = amxd_status_function_not_implemented);
    when_null_trace(object, exit, ERROR, "Object is NULL");

    cpu_name = cpu_dm_dvfs_get_cpu_name(object);

    if((cpu_name != NULL) && (cpu_name[0] != 0)) {
        access = (amxd_dm_access_t) GET_UINT32(args, "access");

        if(access == amxd_dm_access_public) {
            if(cpu_read_value(cpu_name, GET_CHAR(filename, NULL), retval) == 0) {
                amxc_var_cast(retval, amxd_param_get_type(param));
            } else {
                amxd_action_param_read(object, param, action_param_read, args, retval, priv);
            }
        } else {
            // For enabled or protected access, always read current stored value
            amxd_action_param_read(object, param, action_param_read, args, retval, priv);
        }
    } else {
        amxd_action_param_read(object, param, action_param_read, args, retval, priv);
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
   @ingroup  cpu_dm_dvfs_actions
   Action handler for writing DVFS parameters to sysfs.

   This write handler stores the value in the data model and, if DVFS is
   enabled, immediately writes it to sysfs to make it take effect.

   Why check Enable: When DVFS is disabled, we store the user's configuration
   but don't apply it to the system. This allows users to configure all
   settings before enabling. When they enable DVFS, all configured values
   are applied at once.

   Why store even when disabled: Users need to be able to configure frequency
   limits and governor before enabling DVFS. The settings are persistent and
   will be applied when enabled.

   @param object The DVFS object being written
   @param param The parameter being written
   @param reason The action reason (must be action_param_write)
   @param args Input: the new value to write
   @param retval Output (unused)
   @param priv Private data: the sysfs filename to write
   @return Status code
 */
amxd_status_t _cpu_write_value(amxd_object_t* object,
                               amxd_param_t* param,
                               amxd_action_t reason,
                               amxc_var_t* const args,
                               amxc_var_t* const retval,
                               void* priv) {

    amxd_status_t status = amxd_status_unknown_error;
    int rv = -1;
    amxd_param_t* enable_param = NULL;
    const char* cpu_name = NULL;
    amxc_var_t* filename = (amxc_var_t*) priv;

    when_true_status(reason != action_param_write, exit, status = amxd_status_function_not_implemented);
    when_null_trace(object, exit, ERROR, "Object is NULL");

    cpu_name = cpu_dm_dvfs_get_cpu_name(object);
    when_str_empty(cpu_name, exit);
    enable_param = amxd_object_get_param_def(object, "Enable");

    if(GET_BOOL(&enable_param->value, NULL)) {
        // DVFS is enabled - push the new value to sysfs immediately
        rv = cpu_write_value(cpu_name, GET_CHAR(filename, NULL), args);
        when_failed_trace(rv, exit, ERROR, "Failed to write to the scaling_min_freq file.");
    }

    // Always store the value in the data model (even if DVFS is disabled)
    status = amxd_action_param_write(object, param, reason, args, retval, priv);

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
   @ingroup  cpu_dm_dvfs_actions
   Validation handler for frequency parameters.

   This validator ensures that frequency values are within acceptable ranges:
   1. ScalingMinFrequency ≤ ScalingMaxFrequency
   2. MinFrequency ≤ ScalingMinFrequency ≤ MaxFrequency
   3. MinFrequency ≤ ScalingMaxFrequency ≤ MaxFrequency

   Why these checks: The kernel enforces these constraints, so we validate
   them before attempting to write to sysfs. This provides clear error
   messages to users rather than cryptic kernel errors.

   MinFrequency and MaxFrequency are hardware limits that cannot be exceeded.
   ScalingMinFrequency and ScalingMaxFrequency define the operating range
   within those limits.

   @param object The DVFS object being validated
   @param param The parameter being validated (unused)
   @param reason The action reason (must be action_object_validate)
   @param args Additional arguments (unused)
   @param retval Output (unused)
   @param priv Private data (unused)
   @return amxd_status_ok if valid, amxd_status_invalid_value otherwise
 */
amxd_status_t _check_frequencies_are_valid(amxd_object_t* object,
                                           UNUSED amxd_param_t* param,
                                           amxd_action_t reason,
                                           UNUSED const amxc_var_t* const args,
                                           UNUSED amxc_var_t* const retval,
                                           UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    uint64_t scaling_max_frequency = 0;
    uint64_t scaling_min_frequency = 0;
    uint64_t min_frequency = 0;
    uint64_t max_frequency = 0;
    const char* cpu_name = NULL;

    when_true_status(reason != action_object_validate, exit, status = amxd_status_function_not_implemented);
    when_null_trace(object, exit, ERROR, "Object is NULL");

    scaling_max_frequency = amxd_object_get_value(uint64_t, object, "ScalingMaxFrequency", NULL);
    scaling_min_frequency = amxd_object_get_value(uint64_t, object, "ScalingMinFrequency", NULL);
    min_frequency = amxd_object_get_value(uint64_t, object, "MinFrequency", NULL);
    max_frequency = amxd_object_get_value(uint64_t, object, "MaxFrequency", NULL);

    // Validate scaling range is consistent
    when_false_status(scaling_max_frequency >= scaling_min_frequency, exit, status = amxd_status_invalid_value);

    // Validate scaling min is within hardware limits
    when_false_status(min_frequency <= scaling_min_frequency && scaling_min_frequency <= max_frequency, exit, status = amxd_status_invalid_value);

    // Validate scaling max is within hardware limits
    when_false_status(min_frequency <= scaling_max_frequency && scaling_max_frequency <= max_frequency, exit, status = amxd_status_invalid_value);

    cpu_name = cpu_dm_dvfs_get_cpu_name(object);
    when_str_empty_status(cpu_name, exit, status = amxd_status_ok);

    status = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
   @ingroup  cpu_dm_dvfs_actions
   Validation handler for governor and frequency values.

   This validator checks if a proposed value is in the list of supported values
   read from sysfs. For example, it verifies that a governor name like "performance"
   is in the scaling_available_governors list.

   Why validate against sysfs: The available governors and frequencies depend on
   the kernel configuration and hardware. We can't hardcode the valid values -
   we must read them from the system and validate against that list.

   Special case: If the sysfs file doesn't exist or returns no values, we skip
   validation. This handles CPUs that don't provide an available frequencies list.

   @param object The DVFS object being validated
   @param param The parameter being validated (unused)
   @param reason The action reason (must be action_param_validate)
   @param args The proposed new value
   @param retval Output (unused)
   @param priv Private data: the sysfs filename containing valid values
   @return amxd_status_ok if valid, amxd_status_invalid_value otherwise
 */
amxd_status_t _check_value_is_supported(amxd_object_t* object,
                                        UNUSED amxd_param_t* param,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        UNUSED amxc_var_t* const retval,
                                        UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    int rv = -1;
    const char* cpu_name = NULL;
    amxc_var_t* filename = (amxc_var_t*) priv;
    amxc_var_t supported_values;

    amxc_var_init(&supported_values);

    when_true_status(reason != action_param_validate, exit, status = amxd_status_function_not_implemented);
    when_null_trace(object, exit, ERROR, "Object is NULL");

    cpu_name = cpu_dm_dvfs_get_cpu_name(object);
    when_str_empty_status(cpu_name, exit, status = amxd_status_ok);

    // Read the list of supported values from sysfs
    rv = cpu_read_value(cpu_name, GET_CHAR(filename, NULL), &supported_values);
    when_failed_trace(rv, exit, ERROR, "Failed to read cpu file.");

    // If no supported values available, skip validation
    when_true_status(amxc_var_is_null(&supported_values), exit, status = amxd_status_ok);

    // Check if proposed value is in the supported list
    if(!cpu_is_valid_scaling_governor(&supported_values, args)) {
        status = amxd_status_invalid_value;
    } else {
        status = amxd_status_ok;
    }

exit:
    amxc_var_clean(&supported_values);
    SAH_TRACEZ_OUT(ME);
    return status;
}
