/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__PPP_H__)
#define __PPP_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>

#include <amxb/amxb.h>

#include <amxo/amxo.h>
#include <amxo/amxo_save.h>

#include <amxm/amxm.h>

#include <netmodel/client.h>

// Name of parameters in the datamodel
#define PPP_CTRL                "Controller"
#define PPP_ENCRYPTION          "EncryptionProtocol"
#define PPP_AUTHENTICATION      "AuthenticationProtocol"
#define PPP_STATUS              "Status"
#define PPP_CONNECTIONSTATUS    "ConnectionStatus"
#define PPP_LASTCONNECTIONERROR "LastConnectionError"
#define PPP_LOCAL_INTF_ID       "LocalInterfaceIdentifier"
#define PPP_REMOTE_INTF_ID      "RemoteInterfaceIdentifier"
#define PPP_PPPOE_SESSION_ID    "SessionID"
#define PPP_CURRENT_MRU_SIZE    "CurrentMRUSize"

// Name of the module namespace that you want to use to execute the functions
#define MOD_PPP_CTRL "ppp-ctrl"

// Core mod name
#define MOD_CORE "mod-ppp"

// Dummy module name, used when no controller could be loaded
#define DUMMY_MOD_NAME "mod-dummy"

typedef struct _ppp_app {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    bool mod_found;
} ppp_app_t;

typedef struct _ppp_info {
    amxd_object_t* intf_obj;                               // Pointer to PPP.Interface.{i}.
    netmodel_query_t* q_name;                              // The netmodel query for resolving the ll intf name.
    netmodel_query_t* q_ip_flag;                           // The netmodel query for monitoring the ipv4/ipv6 flag on ppp interface.
    char* ll_intf_name;                                    // Netdev name of the lowerlayers interface.
    amxp_timer_t* enable_timer;                            // Timer used when enabling a connection.
    amxp_timer_t* disable_timer;                           // Timer used when disabling a connection.
    bool use_timers;                                       // Should enable_timer and disable_timer be used?
    amxb_subscription_t* netdev_status_subscription;       // Netdev status subscription.
    amxb_subscription_t* netdev_link_added_subscription;   // Netdev link added subscription.
    amxb_subscription_t* netdev_link_removed_subscription; // Netdev link removed subscription
    uint32_t last_change;                                  // Time definition for the total uptime of the interface
} ppp_info_t;

amxd_dm_t* PRIVATE ppp_get_dm(void);
amxo_parser_t* PRIVATE ppp_get_parser(void);

int cleanup_fds(void);
int count_fds(amxc_var_t* ret);

int _ppp_main(int reason,
              amxd_dm_t* dm,
              amxo_parser_t* parser);

#ifdef __cplusplus
}
#endif

#endif // __PPP_H__
