/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__NETDEV_NETLINK_H__)
#define __NETDEV_NETLINK_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <linux/rtnetlink.h>

#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>

#include "netdev.h"

typedef struct {
    unsigned int buflen;
    unsigned short hdrlen;
    struct nlmsghdr* nlmsg;
    char buf[0];
} rtnlmsg_t;

typedef struct _rtnlhandler {
    unsigned short type;                       // RTM_message type which are handled by this handler
    unsigned short hdrlen;                     // length of RTM_message of this type
    int (* handle)(rtnlmsg_t* msg);            // actual handler function
    void (* print)(FILE* f, rtnlmsg_t* msg);   // print function for logging
} rtnlhandler_t;

bool rtnlmsg_store(rtnlmsg_t* msg);
rtnlmsg_t* rtnlmsg_load(struct nlmsghdr* nlmsg);

int rtnl_open(void);
void rtnl_close(int nlfd);

int rtnl_register_handler(rtnlhandler_t* handler);
void rtnl_unregister_handlers(void);

bool rtnl_send(int fd, rtnlmsg_t* msg);
bool rtnl_read(int fd, rtnlmsg_t* msg, bool blocking);

void rtnl_trace(bool enable);

rtnlmsg_t* rtnlmsg_instance(void);
void rtnlmsg_initialize(rtnlmsg_t* msg, unsigned short type, unsigned short hdrlen, unsigned short flags);
unsigned short rtnlmsg_type(rtnlmsg_t* msg);
int rtnlmsg_buflen(rtnlmsg_t* msg);
struct nlmsghdr* rtnlmsg_nlhdr(rtnlmsg_t* msg);
void* rtnlmsg_hdr(rtnlmsg_t* msg);
struct rtattr* rtnlmsg_attr(rtnlmsg_t* msg, unsigned short type);
struct rtattr* rtnlmsg_attrFirst(rtnlmsg_t* msg);
unsigned int rtnlmsg_attrLen(rtnlmsg_t* msg);
void rtnlmsg_addAttr(rtnlmsg_t* msg, unsigned short type, unsigned short len, const void* data);
void get_rtnl_read_stats(amxc_var_t* const retval);

amxd_status_t _netlink_msgs_read(amxd_object_t* intf,
                                 amxd_param_t* param, amxd_action_t reason,
                                 const amxc_var_t* const args,
                                 amxc_var_t* const retval, void* priv);

#ifdef __cplusplus
}
#endif

#endif // __NETDEV_NETLINK_H__
