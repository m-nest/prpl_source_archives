/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <amxc/amxc_macros.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "ipd_dns.h"

#define ME "ipd-dns"

static dns_query_t dns_query = {0}; // Used to keep track of things related to Hostname's dns lookup

static void ipd_resolve_stop(void) {
    if(dns_query.socket_fd > 0) {
        amxo_connection_remove(ipd_get_parser(), dns_query.socket_fd);
        dns_query.socket_fd = 0;
    }
    if(dns_query.channel != NULL) {
        ares_destroy(dns_query.channel);
        dns_query.channel = NULL;
    }
    memset(&dns_query, 0, sizeof(dns_query));
}

static void ipd_deferred_resolve_stop(UNUSED const amxc_var_t* data, UNUSED void* priv) {
    ipd_resolve_stop();
}

static void addrinfo_callback(void* arg, int status, UNUSED int timeouts, struct ares_addrinfo* res) {
    ipping_start_struct_t* data = (ipping_start_struct_t*) arg;
    amxc_var_t* status_var = NULL;
    int retval = -1;
    const char* resolved_ip = NULL;
    const char* protocol_version = NULL;
    amxc_var_t* resolved_host_ip = NULL;
    char ip_buf[INET6_ADDRSTRLEN];
    bool dns_lookup = true;

    amxc_var_new(&status_var);
    amxc_var_set(cstring_t, status_var, IPPING_STATUS_ERR_HOST_NAME);

    when_null_trace(data, exit_null_data, ERROR, "Data is NULL");
    when_null_trace(data->mod_args, exit, ERROR, "mod_args is NULL");
    when_null_trace(data->mod_ret, exit, ERROR, "mod_ret is NULL");

    if(status != ARES_SUCCESS) {
        SAH_TRACEZ_INFO(ME, "DNS lookup failed: %s", ares_strerror(status));
        amxc_var_set(cstring_t, GET_ARG(data->mod_args, IPPING_RET_KEY_DST), IPPING_STATUS_ERR_HOST_NAME);
        amxc_var_move(data->mod_ret, data->mod_args);
        amxc_var_set_pathf(data->mod_ret, status_var, DEFAULT_SET_PATH_FLAGS, IPPING_RET_KEY_PST);
        dns_lookup = false;
        goto exit;
    }
    protocol_version = GET_CHAR(data->mod_args, "ProtocolVersion");
    if((status == ARES_SUCCESS) && res) {
        for(struct ares_addrinfo_node* node = res->nodes; node; node = node->ai_next) {
            if((node->ai_family == AF_INET)) {
                if(strcmp(protocol_version, "Any") == 0) {
                    resolved_ip = inet_ntop(AF_INET, &((struct sockaddr_in*) node->ai_addr)->sin_addr, ip_buf, sizeof(ip_buf));
                    break;
                } else if(strcmp(protocol_version, "IPv4") == 0) {
                    resolved_ip = inet_ntop(AF_INET, &((struct sockaddr_in*) node->ai_addr)->sin_addr, ip_buf, sizeof(ip_buf));
                }
            } else if((node->ai_family == AF_INET6)) {
                if((strcmp(protocol_version, "IPv6") == 0) || (strcmp(protocol_version, "Any") == 0)) {
                    resolved_ip = inet_ntop(AF_INET6, &((struct sockaddr_in6*) node->ai_addr)->sin6_addr, ip_buf, sizeof(ip_buf));
                    break;
                }
            }
        }
    }
    resolved_host_ip = amxc_var_get_key(data->mod_args, "ResolvedHostIP", AMXC_VAR_FLAG_DEFAULT);
    amxc_var_set(cstring_t, resolved_host_ip, (resolved_ip ? resolved_ip : ""));
    retval = data->start_function(data->sch, data->check_function, data->mod_args, data->mod_ret);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Could not launch the test properly, error: %s", GET_CHAR(data->mod_ret, IPPING_RET_KEY_PST));
    }

exit:
    ipd_ipping_save_result_to_dm(data->mod_ret, data->ipd_results);
    if(GET_BOOL(data->mod_ret, "ConnectionAdded") == false) {
        ipd_ipping_save_status_to_dm(data->mod_ret, data->ipd_results);
    }
    if(!dns_lookup) {
        ipd_filter_ret(data->mod_ret, true, IPPING);
        amxd_function_deferred_done(data->sch->call_id, amxd_status_ok, NULL, data->mod_ret);
    }
    amxc_var_delete(&data->mod_args);
    amxc_var_delete(&data->mod_ret);

exit_null_data:
    amxc_var_delete(&status_var);

    ares_freeaddrinfo(res);

    // Free DNS query asynchronously
    amxp_sigmngr_deferred_call(NULL, ipd_deferred_resolve_stop, NULL, NULL);
}

static void handle_ares_event_cb(int fd, void* priv) {
    ares_channel channel = (ares_channel) priv;
    ares_process_fd(channel, fd, ARES_SOCKET_BAD);
}

static void ares_sock_cb(void* data, ares_socket_t socket_fd, int readable, UNUSED int writable) {
    amxo_parser_t* parser = ipd_get_parser();
    dns_query_t* query = (dns_query_t*) data;

    SAH_TRACEZ_INFO(ME, "ares_init_options cb function with fd: %d", socket_fd);
    if((readable > 0) && (amxo_connection_get(parser, socket_fd) == NULL)) {
        SAH_TRACEZ_INFO(ME, "Add fd %d to amxrt event loop", socket_fd);
        amxo_connection_add(parser, socket_fd, handle_ares_event_cb, NULL, AMXO_CUSTOM, query->channel);
        query->socket_fd = socket_fd;
    }
}

int resolve_hostname(ipping_start_struct_t* ipping_start) {
    int retval = -1;
    const char* hostname = GET_CHAR(ipping_start->mod_args, "Host");
    const char* protocol_version = GET_CHAR(ipping_start->mod_args, "ProtocolVersion");

    when_str_empty_trace(hostname, exit, ERROR, "Hostname is empty.");
    when_str_empty_trace(protocol_version, exit, ERROR, "ProtocolVersion is empty.");

    amxp_sigmngr_remove_deferred_call(NULL, ipd_deferred_resolve_stop, NULL);
    ipd_resolve_stop();

    dns_query.optmask = ARES_OPT_SOCK_STATE_CB | ARES_OPT_TIMEOUTMS | ARES_OPT_TRIES;
    dns_query.options.sock_state_cb = ares_sock_cb;
    dns_query.options.sock_state_cb_data = &dns_query;
    dns_query.options.tries = 1;
    dns_query.options.timeout = 300 * 1000; // 5 minutes

    retval = ares_init_options(&dns_query.channel, &dns_query.options, dns_query.optmask);
    if(retval != ARES_SUCCESS) {
        SAH_TRACEZ_ERROR(ME, "Failed to create c-ares channel: %s", ares_strerror(retval));
        goto exit;
    }

    struct ares_addrinfo_hints hints = {0};
    hints.ai_flags = ARES_AI_CANONNAME;

    if(strcmp(protocol_version, "IPv4") == 0) {
        hints.ai_family = AF_INET;
    } else if(strcmp(protocol_version, "IPv6") == 0) {
        hints.ai_family = AF_INET6;
    } else {
        hints.ai_family = AF_UNSPEC;
    }

    ares_getaddrinfo(dns_query.channel, hostname, NULL, &hints, addrinfo_callback, (void*) ipping_start);

exit:
    return retval;
}

int ipd_dns_lib_init(void) {
    int retval = ares_library_init(ARES_LIB_INIT_ALL);
    if(retval != ARES_SUCCESS) {
        SAH_TRACEZ_ERROR(ME, "Failed to initialize c-ares library: %s\n", ares_strerror(retval));
    }

    return retval;
}

void ipd_dns_lib_clean(void) {
    ares_library_cleanup();
}
