/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __SFPMGR_H__
#define __SFPMGR_H__

/* System headers */
#include <stdbool.h>
#include <stdint.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h> /* amxd_object_t */
#include <amxp/amxp_timer.h> /* amxp_timer_t */

/* Own headers */
#include "sfpmgr_common.h"    /* sfp_cage_t */
#include "sfpmgr_ethtoolif.h" /* sfp_ethtool_t */
#include "sfpmgr_trace.h"
#include "sfp_type.h"

/* Define the name of the module to be used when the controllers fail to load */
#define DEFAULT_MOD_SFP_TYPE_NAME "mod-sfp-type"

/* Object paths in data model */
#define SFPS_PATH                    "SFPs."
#define SFP_CAGE_PATH                "SFPs.SFPCage.%d."
#define SFP_XCVR_PATH                "SFPs.Mgmt.SFF8472.%d.Transceiver."
#define SFP_XCVR_THRESHOLDS_PATH     "SFPs.Mgmt.SFF8472.%d.Transceiver.Thresholds."
#define SFP_XCVR_WARNINGS_PATH       "SFPs.Mgmt.SFF8472.%d.Transceiver.Warnings."
#define SFP_XCVR_ALARMS_PATH         "SFPs.Mgmt.SFF8472.%d.Transceiver.Alarms."
#define SFP_XCVR_STATUS_PATH         "SFPs.Mgmt.SFF8472.%d.Transceiver.Status."

/*
 * Details on the SFP inserted in the cage
 */
typedef struct {
    int sfp_cage_id;                                    /* number of the cage inserted */
    bool rx_los;                                        /* rs los condition */
    bool sfp_tx_en;                                     /* is Tx Enabled by provisioning? */
    amxc_var_t key_value_pair;                          /* hash value of SFP MSA info */
} sfp_info_t;

/* init and periodic updates */
int sfpmgr_object_init (amxd_object_t* cage_object, amxd_object_t* sfp_object);
int sfpmgr_object_update (amxd_object_t* cage_object, amxd_object_t* sfp_object);
int discover_cages(void);
int get_max_cage(void);
void set_max_cage(size_t maxcage);
int discovery_stop(void);

/* transfer of info from hash to ethtool structure */
int sfpmgr_update_warning_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param);
int sfpmgr_update_alarm_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param);
int sfpmgr_update_status_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param);
int sfpmgr_update_threshold_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param);
void update_dmc_sff8472_params (sfp_ethtool_t* sfp_ethtool_param);
int sfpmgr_update_base_ext_structure (amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param);
int sfpmgr_update_dynamic_params(amxd_object_t* cage_object, amxd_object_t* sfp_object, sfp_ethtool_t* sfp_param);
int sfpmgr_update_static_params(amxd_object_t* cage_object, amxd_object_t* sfp_object, sfp_ethtool_t* sfp_param);
int populate_sfp_info(amxd_object_t* cage_object, amxd_object_t* sfp_object);
int sfpmgr_sfp_inserted(uint32_t cage_index, sfp_types_e sfp_type);
int sfpmgr_sfp_removed(uint32_t cage_index);
int sfpmgr_sfp_rxlos(uint32_t cage_index);
int sfpmgr_sfp_rxlos_cleared(uint32_t cage_index);
int sfpmgr_cage_info_update(sfp_cage_t* sfp_cage_info);
void free_cage(void);

/* diag routines */
void sfpmgr_poll_sfp (amxp_timer_t* timer, void* priv);

/* get sfp info for the particular cage index */
sfp_cage_t* get_sfp_cage_info (int32_t cage_index);
sfp_info_t* get_sfp_cage_info_trans (int32_t cage_index);


#endif // __SFPMGR_H__
