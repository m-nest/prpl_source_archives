/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "power_mgmt.h"

/* Related header */
#include <string.h> /* strcmp() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h>
#include <amxc/amxc_string.h>

/* Own headers */
#include "dm_info.h"           /* object_id_t */
#include "mod_xpon_trace.h"
#include "southbound_if.h"     /* sbi_change_power_mode() */
#include "xpon_mgr_pon_stat.h" /* xpon_mngr_call_pon_stat_function() */

static amxb_bus_ctx_t* s_bus_ctx = NULL;

/**
 * Set bus context to access xpon_onu.{i} instances.
 *
 * @param[in] bus_ctx: bus context
 */
void pwr_set_bus_ctx(amxb_bus_ctx_t* bus_ctx) {
    s_bus_ctx = bus_ctx;
}

/**
 * Return true if @a power_state is a valid BBF power state value.
 *
 * @param[in] power_state: string representing a power state, e.g. "On"
 *
 * @return true if @a power_state is a valid BBF power state value, else false
 */
static bool is_valid_power_state(const char* power_state) {
    return ((strcmp(power_state, "On") == 0) ||
            (strcmp(power_state, "Off") == 0) ||
            (strcmp(power_state, "LowPower") == 0));
}

/**
 * Change the power state of an ONU.
 *
 * @param[in] args: see below
 *
 * The value for @a args must be an htable with 4 key-value pairs:
 * - path (cstring_t): path to ONU for which ChangePowerMode() is called,
 *   e.g. "XPON.ONU.1".
 * - call_id (uint32_t): unique ID to identify this change_power_mode()
 *   invocation
 * - power_state (cstring_t): requested power state ("On", "Off", or "LowPower")
 * - timeout_ms (uint32_t): timeout in milliseconds within which tr181-xpon
 *   expects a reply via set_change_power_mode_result() (see
 *   handle_change_power_mode_result()).
 *
 * The function calls sbi_change_power_mode() to forward the request to an ONU
 * HAL agent.
 *
 * @return 0 on success, else -1
 */
int change_power_mode(UNUSED const char* function_name,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    int rc = -1;
    bool rv;
    amxc_string_t prpl_path;
    amxc_string_init(&prpl_path, 0);
    when_null_trace(s_bus_ctx, exit, ERROR, "No bus context");

    when_null(args, exit);
    when_false_trace(amxc_var_type_of(args) == AMXC_VAR_ID_HTABLE, exit, ERROR,
                     "args is not an htable");

    const char* const path = GET_CHAR(args, "path");
    when_null_trace(path, exit, ERROR, "Failed to extract path");
    const object_id_t oid = dm_get_object_id(path);
    when_false_trace(oid_onu == oid, exit, ERROR,
                     "change_power_mode() is called with path='%s' != ONU",
                     path);

    const uint32_t call_id = GET_UINT32(args, "call_id");
    const char* const power_state = GET_CHAR(args, "power_state");
    when_null_trace(power_state, exit, ERROR, "Failed to extract power_state");
    const bool power_state_ok = is_valid_power_state(power_state);
    when_false_trace(power_state_ok, exit, ERROR, "Invalid power state: '%s'",
                     power_state);

    const uint32_t timeout_ms = GET_UINT32(args, "timeout_ms");

    SAH_TRACEZ_INFO(ME, "path='%s' call_id=%u power_state='%s' timeout_ms=%u",
                    path, call_id, power_state, timeout_ms);

    rv = dm_convert_bbf_path_to_prpl_path(path, &prpl_path);
    when_false_trace(rv, exit, ERROR, "path='%s': failed to convert to prpl path", path);

    rv = sbi_change_power_mode(s_bus_ctx, &prpl_path, call_id, power_state, timeout_ms);
    when_false_trace(rv, exit, ERROR, "path='%s': failed to set power mode to %s",
                     path, power_state);

    rc = 0;

exit:
    amxc_string_clean(&prpl_path);
    return rc;
}

#define CPMR_NOTIF_NR_OF_ATTRIBUTES 2
/* Attributes of change_power_mode_result notification */
static const char* CPMR_NOTIF_ATTRIBUTES[CPMR_NOTIF_NR_OF_ATTRIBUTES] = {
    "call_id", "result"
};

/**
 * Forward the incoming "change_power_mode_result" notification to tr181-xpon.
 *
 * @param[in] onu_index: identifies the ONU. E.g. 1 for XPON.ONU.1.
 * @param[in] data: htable with attributes of the notification
 *
 * @a data must include 2 key-value pairs:
 * - call_id (uint32_t): ID to identify the change_power_mode() invocation for
 *   which this notification has a reply
 * - result (uint32_t): result of the change_power_mode() call: 0 indicates
 *   success; a value different from 0 indicates an error.
 */
void handle_change_power_mode_result(uint32_t onu_index, const amxc_var_t* const data) {
    amxc_var_t args;
    amxc_var_init(&args);

    when_null_trace(data, exit, ERROR, "data is NULL");

    const amxc_htable_t* const htable = amxc_var_constcast(amxc_htable_t, data);
    when_null_trace(htable, exit, ERROR, "data is not an htable");

    int i;
    bool has_key;
    for(i = 0; i < CPMR_NOTIF_NR_OF_ATTRIBUTES; ++i) {
        has_key = amxc_htable_contains(htable, CPMR_NOTIF_ATTRIBUTES[i]);
        when_false_trace(has_key, exit, ERROR, "data does not contain key '%s'",
                         CPMR_NOTIF_ATTRIBUTES[i]);
    }
    const uint32_t call_id = GET_UINT32(data, "call_id");
    const uint32_t result = GET_UINT32(data, "result");

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    const amxc_var_t* var = NULL;
    var = amxc_var_add_key(uint32_t, &args, "index", onu_index);
    when_null_trace(var, exit, ERROR, "XPON.ONU.%u: failed to add 'index' to args", onu_index);
    var = amxc_var_add_key(uint32_t, &args, "call_id", call_id);
    when_null_trace(var, exit, ERROR, "XPON.ONU.%u: failed to add 'call_id' to args", onu_index);
    var = amxc_var_add_key(uint32_t, &args, "result", result);
    when_null_trace(var, exit, ERROR, "XPON.ONU.%u: failed to add 'result' to args", onu_index);

    xpon_mngr_call_pon_stat_function("set_change_power_mode_result", &args);

exit:
    amxc_var_clean(&args);
    return;
}

