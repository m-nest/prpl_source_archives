/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__CTHULHU_CONFIG_H__)
#define __CTHULHU_CONFIG_H__

#ifdef __cplusplus
extern "C"
{
#endif


#ifndef __AMXC_STRING_H__
#error "include <amxc/amxc_string.h> before <cthulhu/cthulhu_config.h>"
#endif
#ifndef __AMXC_LLIST_H__
#error "include <amxc/amxc_llist.h> before <cthulhu/cthulhu_config.h>"
#endif
#ifndef __AMXC_HTABLE_H__
#error "include <amxc/amxc_htable.h> before <cthulhu/cthulhu_config.h>"
#endif


typedef struct _cthulhu_config {
    char* id;
    char* rootfs;
    char* bundle_name;
    char* bundle_version;
    char* sandbox;
    char* cgroup_dir;
    bool bundle_provided;
    // provided by the manifest
    char* user;
    amxc_llist_t exposed_ports;
    amxc_llist_t env;
    amxc_llist_t entry_point;
    amxc_llist_t cmd;
    amxc_llist_t volumes;
    char* working_dir;
    char* created;
    char* author;
    char* architecture;
    char* os;
    amxc_htable_t labels;
    char* stop_signal;

} cthulhu_config_t;

/**
 * @struct cthulhu_prestartup_config_t
 * @brief Configuration structure for Cthulhu pre-startup operations.
 *
 * This structure holds pointers to variables used for various pre-startup
 * actions such as creating sandboxes, containers, upgrading, and removing images.
 */
typedef struct _cthulhu_prestartup_config {
    amxc_var_t* sb_create;      /**< Pointer to variable for sandbox creation. */
    amxc_var_t* ctr_create;     /**< Pointer to variable for container creation. */
    amxc_var_t* ctr_upgrade;    /**< Pointer to variable for container upgrade. */
    amxc_var_t* ctr_remove;     /**< Pointer to variable for container removal. */
    amxc_var_t* image_remove;   /**< Pointer to variable for image removal. */
} cthulhu_prestartup_config_t;

int cthulhu_config_new(cthulhu_config_t** cfg);
void cthulhu_config_delete(cthulhu_config_t** cfg);

int cthulhu_config_init(cthulhu_config_t* const cfg);
void cthulhu_config_clean(cthulhu_config_t* const cfg);
void cthulhu_config_reset(cthulhu_config_t* const cfg);



#ifdef __cplusplus
}
#endif

#endif // __CTHULHU_CONFIG_H__


