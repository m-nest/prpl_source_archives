/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wsn_common.h"
#include "wsn_socket.h"
#include "wsn_session.h"
#include "wsn_main.h"

#define ME "wsnsockets"

int vendorfd = -1;

extern amxc_llist_t socketInfo;
extern amxc_llist_t headerInfo;

wsn_headerInfo_t* wsn_findMacAddressInList(swl_macBin_t macaddress) {
    amxc_llist_for_each(it, &headerInfo) {
        wsn_headerInfo_t* info = amxc_container_of(it, wsn_headerInfo_t, it);
        if(swl_typeMacBin_equalsRef(&macaddress, &info->tx_sta_mac)) {
            SAH_TRACEZ_INFO(ME, "Macaddress found in list");
            return info;
        }
    }
    SAH_TRACEZ_WARNING(ME, "Macaddress not found in list");
    return NULL;
}

static void parser(int fd, void* priv) {
    SAH_TRACEZ_WARNING(ME, "Called callback");

    wsn_header_t* header = calloc(1, sizeof(wsn_header_t));
    if(!header) {
        SAH_TRACEZ_ERROR(ME, "calloc failed");
        return;
    }

    int total_length = TOTAL_LEN + 1;
    char buffer[TOTAL_LEN + 1] = { 0 };
    ssize_t bytes_read;

    bytes_read = read(vendorfd, buffer + HEADER_LEN, DATA_BLOCK_SIZE);
    if(bytes_read == -1) {
        SAH_TRACEZ_ERROR(ME, "Not able to read data from socket.");
    } else {
        buffer[bytes_read + HEADER_LEN] = '\0';
        SAH_TRACEZ_INFO(ME, "Read %zd bytes from vendor socket", bytes_read);

        swl_macBin_t macAddr;
        memcpy(macAddr.bMac, buffer + HEADER_LEN, SWL_MAC_BIN_LEN);

        SAH_TRACEZ_INFO(ME, "MAC Address from buffer = %s ", swl_typeMacBin_toBuf32Ref(&macAddr).buf);

        wsn_headerInfo_t* data = wsn_findMacAddressInList(macAddr);

        if(data == NULL) {
            SAH_TRACEZ_INFO(ME, "MACAddress read from buffer is not present in Exchanges");
            free(header);
            return;
        } else {
            SAH_TRACEZ_INFO(ME, "MACAddress is the same. Updating header");
        }
        header->version = HEADER_VERSION;
        header->header_len = HEADER_LEN;
        strncpy(header->datatype, data->datatype, sizeof(header->datatype) - 1);
        header->datatype[sizeof(header->datatype) - 1] = '\0';
        struct timespec tv;
        clock_gettime(CLOCK_MONOTONIC, &tv);
        header->timestamp = tv.tv_sec;
        header->exchange_id = data->exchange_id;
        header->tx_sta_mac = data->tx_sta_mac;
        header->rx_sta_mac = data->rx_sta_mac;
        header->datalen = bytes_read;

        SAH_TRACEZ_INFO(ME, "Final header data version is %u ", header->version);
        SAH_TRACEZ_INFO(ME, "Final header data header_len is %u ", header->header_len);
        SAH_TRACEZ_INFO(ME, "Final header data datatypes is %s ", header->datatype);
        SAH_TRACEZ_INFO(ME, "Final header data exchange_id is %u ", header->exchange_id);
        SAH_TRACEZ_INFO(ME, "Final header data tx_sta_mac is %s ", swl_typeMacBin_toBuf32Ref(&header->tx_sta_mac).buf);
        SAH_TRACEZ_INFO(ME, "Final header data rx_sta_mac is %s ", swl_typeMacBin_toBuf32Ref(&header->rx_sta_mac).buf);
        SAH_TRACEZ_INFO(ME, "Final header data dat_len is %u ", header->datalen);

        amxc_llist_it_t* it = amxc_llist_get_first(&socketInfo);
        wsn_socket_t* sock = amxc_container_of(it, wsn_socket_t, it);
        SAH_TRACEZ_INFO(ME, "Socket fd is %d for session %u", sock->sockfd, sock->session_id);

        SAH_TRACEZ_INFO(ME, "Prepend header");
        memcpy(buffer, header, HEADER_LEN);

        struct sockaddr_un clientAddr;
        socklen_t addrLen = sizeof(clientAddr);
        if(sock->clientfd == -1) {
            sock->clientfd = accept(sock->sockfd, (struct sockaddr*) &clientAddr, &addrLen);
            if(sock->clientfd == -1) {
                if((errno == EWOULDBLOCK) || (errno == EAGAIN)) {
                    SAH_TRACEZ_INFO(ME, "No remote peer connected");
                } else {
                    SAH_TRACEZ_ERROR(ME, "Accept failed: error:%d:%s", errno, strerror(errno));
                }
                free(header);
                return;
            }
            SAH_TRACEZ_INFO(ME, "New remote peer connected, fd %d", sock->clientfd);
        }

        fd_set read_fds;
        struct timeval timeout;
        FD_ZERO(&read_fds);
        FD_SET(sock->clientfd, &read_fds);

        timeout.tv_sec = 0;
        timeout.tv_usec = 5000;

        int clientReady = select(sock->clientfd + 1, &read_fds, NULL, NULL, &timeout);
        if(clientReady < 0) {
            SAH_TRACEZ_ERROR(ME, "Select failed: error:%d:%s", errno, strerror(errno));
            free(header);
            return;
        } else if(clientReady == 0) {
            // send data to remote peer
            SAH_TRACEZ_INFO(ME, "Send stats to connected remote peer, fd %d", sock->clientfd);
            send(sock->clientfd, buffer, sizeof(buffer), 0);
        } else {
            // check if remote peer already connected
            char buf[1024];
            int bytes_received = recv(sock->clientfd, buf, sizeof(buf), 0);
            if(bytes_received <= 0) {
                if((bytes_received == 0) || (errno == ECONNRESET) || (errno == ECONNABORTED)) {
                    SAH_TRACEZ_INFO(ME, "Remote peer disconnected, fd %d", sock->clientfd);
                } else {
                    SAH_TRACEZ_ERROR(ME, "Recv data from peer failed: error:%d:%s", errno, strerror(errno));
                }
                close(sock->clientfd);
                sock->clientfd = -1;
            }
        }

    }
    free(header);
    return;
}


wsn_vendorSocketInfo_t* verify_socket_status(char* radiopath) {

    SAH_TRACEZ_IN(ME);
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has("WiFi.");
    if(bus_ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "Could not find object WiFi.");
    }

    wsn_vendorSocketInfo_t* vendorsocketInfo = calloc(1, sizeof(wsn_vendorSocketInfo_t));
    ASSERT_NOT_NULL(vendorsocketInfo, NULL, ME, "NULL");

    // function arguments
    amxc_var_t functionArgs;
    amxc_var_init(&functionArgs);
    amxc_var_set_type(&functionArgs, AMXC_VAR_ID_HTABLE);

    // return values
    amxc_var_t retvar;
    amxc_var_init(&retvar);
    amxc_var_set_type(&retvar, AMXC_VAR_ID_HTABLE);

    amxc_string_t path;
    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "%sVendor.", radiopath);

    if(amxb_call(bus_ctx, amxc_string_get(&path, 0), "getCsiSocketStatus", &functionArgs, &retvar, 3) == amxd_status_ok) {
        amxc_var_t* result = GET_ARG(&retvar, "0");
        vendorsocketInfo->socketPath = GET_CHAR(result, "SocketPath");
        vendorsocketInfo->active = GET_BOOL(result, "Active");
        SAH_TRACEZ_WARNING(ME, "socketPath: %s", vendorsocketInfo->socketPath ? : "<empty/null>");
    } else {
        SAH_TRACEZ_WARNING(ME, "Warning on calling getCsiSocket, not able to get status");
        free(vendorsocketInfo);
        amxc_string_clean(&path);
        amxc_var_clean(&functionArgs);
        amxc_var_clean(&retvar);
        return NULL;
    }

    amxc_string_clean(&path);
    amxc_var_clean(&functionArgs);
    amxc_var_clean(&retvar);
    SAH_TRACEZ_OUT(ME);
    return vendorsocketInfo;
}

void wsn_addVendorSocketWatcher() {

    int status = -1;

    wsn_vendorSocketInfo_t* sockInfo;
    sockInfo = verify_socket_status("WiFi.Radio.2.");

    if(sockInfo == NULL) {
        SAH_TRACEZ_WARNING(ME, "Unable to query getCsiSocket");
        goto exit;
    }

    if(!sockInfo->active) {
        SAH_TRACEZ_WARNING(ME, "Verification of socket turned out to be false, not going to connect.");
        goto exit;
    }

    if((vendorfd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
        SAH_TRACEZ_ERROR(ME, "Error creating socket file descriptor");
        return;
    }

    struct sockaddr_un csiAddr;
    csiAddr.sun_family = AF_UNIX;     //UNIX socket
    strcpy(csiAddr.sun_path, sockInfo->socketPath);

    // Connect to socket
    if(connect(vendorfd, (struct  sockaddr*) &csiAddr, sizeof(csiAddr)) == -1) {
        SAH_TRACEZ_ERROR(ME, "Error: connecting to socket.\n");
        close(vendorfd);
        goto exit;
    }

    if(amxo_connection_add(wifisensing_get_parser(), vendorfd, parser, "readCtrl", AMXO_CUSTOM, NULL) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to added watcher");
        close(vendorfd);
    } else {
        SAH_TRACEZ_INFO(ME, "Added watcher successfully");
    }

exit:
    free(sockInfo);
    return;
}

void wsn_removeVendorSocketWatcher() {

    SAH_TRACEZ_INFO(ME, "Removing watcher");
    if(amxo_connection_remove(wifisensing_get_parser(), vendorfd) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to remove watcher");
    } else {
        SAH_TRACEZ_INFO(ME, "Removed watcher successfully");
    }

    close(vendorfd);
    vendorfd = -1;
    return;
}
