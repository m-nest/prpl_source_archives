/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "test_helpers.h"

int CtrlPointAddDevice(void* DescDoc, const char* location, int expires);

extern const char* Type[SERVICE_COUNT];
extern int IPVersionSupported[SERVICE_COUNT];

/* Wrapers */
char* __wrap_Util_GetFirstDocumentItem(void* doc, const char* tag);
int __wrap_Util_FindAndParseService(void* descDoc,
                                    const char* location,
                                    const char* srvType,
                                    char** serviceId,
                                    char** eventURL,
                                    char** controlURL);
int __wrap_UpnpSubscribe(int handle, const char* eurl, int* timeout, Upnp_SID sid);


char* __wrap_Util_GetFirstDocumentItem(UNUSED void* doc, const char* tag) {
    check_expected_ptr(tag);
    const char* value = mock_ptr_type(const char*);
    return value ? strdup(value) : NULL;
}

int __wrap_Util_FindAndParseService(UNUSED void* descDoc,
                                    UNUSED const char* location,
                                    UNUSED const char* srvType,
                                    char** serviceId,
                                    char** eventURL,
                                    char** controlURL) {
    int found = mock_type(int);
    const char* sid = mock_ptr_type(const char*);
    const char* eurl = mock_ptr_type(const char*);
    const char* curl = mock_ptr_type(const char*);
    if(found) {
        *serviceId = sid  ? strdup(sid)  : NULL;
        *eventURL = eurl ? strdup(eurl) : NULL;
        *controlURL = curl ? strdup(curl) : NULL;
    }
    return found;
}

int __wrap_UpnpSubscribe(UNUSED int handle, const char* eurl, UNUSED int* timeout, Upnp_SID sid) {
    check_expected_ptr(eurl);
    const char* sid_in = mock_ptr_type(const char*);
    int rc = mock_type(int);
    if(sid_in && sid) {
        snprintf(sid, MAX_VAL_LEN, "%s", sid_in);
    } else if(sid) {
        sid[0] = '\0';
    }
    return rc;
}

/* Setup */
static int setup(void** state) {
    (void) state;
    memset(&IGD, 0, sizeof(IGD));
    for(int i = 0; i < SERVICE_COUNT; i++) {
        IGD.Service[i].ID[0] = '\0';
        IGD.Service[i].Type[0] = '\0';
        IGD.Service[i].ControlURL[0] = '\0';
        IGD.Service[i].EventURL[0] = '\0';
        IGD.Service[i].SID[0] = '\0';
    }
    return 0;
}

static void program_doc_items(const char* udn,
                              const char* devType) {
    expect_string(__wrap_Util_GetFirstDocumentItem, tag, "UDN");
    will_return(__wrap_Util_GetFirstDocumentItem, udn);
    expect_string(__wrap_Util_GetFirstDocumentItem, tag, "deviceType");
    will_return(__wrap_Util_GetFirstDocumentItem, devType);
}

/* Test */
static void test_devtype_mismatch_returns_0(UNUSED void** state) {
    const char* location = "http://host/d.xml";
    program_doc_items("uuid:AAA", "urn:not-our-device:1");

    int ret = CtrlPointAddDevice(NULL, location, 1234);
    assert_int_equal(ret, 0);
    assert_int_equal(IGD.Updated, 0);
}

static void test_udn_already_present_sets_timeout_and_returns_1(UNUSED void** state) {
    const char* location = "http://host/d.xml";

    IGD.Updated = 1;
    snprintf(IGD.UDN, sizeof(IGD.UDN), "%s", "uuid:EXIST");

    program_doc_items("uuid:EXIST", "urn:schemas-upnp-org:device:InternetGatewayDevice:2");

    int ret = CtrlPointAddDevice(NULL, location, 777);
    assert_int_equal(ret, 1);
    assert_int_equal(IGD.Updated, 1);
}

static void test_new_device_parses_and_subscribes_and_fills_fields(UNUSED void** state) {
    const char* location = "http://host/d.xml";

    IGD.Updated = 0;
    IGD.UDN[0] = '\0';

    program_doc_items("uuid:NEW", "urn:schemas-upnp-org:device:InternetGatewayDevice:2");


    gUserIpMode = IPVersionSupported[0];

    will_return(__wrap_Util_FindAndParseService, 1);
    will_return(__wrap_Util_FindAndParseService, "svc:wanip");
    will_return(__wrap_Util_FindAndParseService, "http://host/event0");
    will_return(__wrap_Util_FindAndParseService, "http://host/ctrl0");
    will_return(__wrap_Util_FindAndParseService, 0);
    will_return(__wrap_Util_FindAndParseService, NULL);
    will_return(__wrap_Util_FindAndParseService, NULL);
    will_return(__wrap_Util_FindAndParseService, NULL);

    expect_string(__wrap_UpnpSubscribe, eurl, "http://host/event0");
    will_return(__wrap_UpnpSubscribe, "uuid:SID0");
    will_return(__wrap_UpnpSubscribe, UPNP_E_SUCCESS);

    int ret = CtrlPointAddDevice(NULL, location, 2000);
    assert_int_equal(ret, 0);

    assert_int_equal(IGD.Updated, 1);
    assert_string_equal(IGD.UDN, "uuid:NEW");

    assert_string_equal(IGD.Service[0].ID, "svc:wanip");
    assert_string_equal(IGD.Service[0].EventURL, "http://host/event0");
    assert_string_equal(IGD.Service[0].ControlURL, "http://host/ctrl0");
    assert_string_equal(IGD.Service[0].SID, "uuid:SID0");
}

const struct CMUnitTest g_add_device_tests[] = {
    cmocka_unit_test_setup(test_devtype_mismatch_returns_0, setup),
    cmocka_unit_test_setup(test_udn_already_present_sets_timeout_and_returns_1, setup),
    cmocka_unit_test_setup(test_new_device_parses_and_subscribes_and_fills_fields, setup),
};
const size_t g_add_device_tests_count =
    sizeof(g_add_device_tests) / sizeof(g_add_device_tests[0]);
