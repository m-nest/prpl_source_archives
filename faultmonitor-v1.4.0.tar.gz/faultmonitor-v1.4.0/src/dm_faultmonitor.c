/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <dlfcn.h>
#include <libgen.h>

#include <yajl/yajl_gen.h>

#include <amxc/amxc.h>
#include <amxj/amxj_variant.h>

#include "faultmonitor.h"

#define ME DEFAULT_TRACE_ZONE_NAME

typedef struct {
    amxc_var_t* args;
    int id;
} tar_data_cb_t;

typedef struct {
    char* file_path;
    char* transfer_url;
} ftx_data_cb_t;

int remove_r(const char* path) {
    int retval = 1;
    struct dirent* file_info = NULL;
    char* file_path = NULL;
    DIR* dir = NULL;
    size_t path_len = 0;

    when_null(path, exit);

    dir = opendir(path);
    when_null(dir, exit);

    path_len = strlen(path);
    file_info = readdir(dir);
    retval = 0;
    while(file_info != NULL && !retval) {
        if((strcmp(file_info->d_name, ".") == 0) || (strcmp(file_info->d_name, "..") == 0)) {
            file_info = readdir(dir);
            continue;
        }
        file_path = calloc(path_len + strlen(file_info->d_name) + 2, sizeof(char));
        when_null_trace(file_path, error, ERROR, "memory allocation failure");

        sprintf(file_path, "%s/%s", path, file_info->d_name);
        if(file_info->d_type == DT_DIR) {
            retval = remove_r(file_path);
        } else {
            retval = remove(file_path);
        }
        free(file_path);
        file_info = readdir(dir);
    }
    closedir(dir);
    if(retval == 0) {
        retval = rmdir(path);
    } else {
        SAH_TRACEZ_ERROR(ME, "Failed to remove folder %s", path);
    }

exit:
    return retval;

error:
    return 1;

}

static amxd_status_t rm_fault_instances(amxd_object_t* root_object) {
    amxd_object_t* faults = amxd_object_get_child(root_object, "ProcessFault");
    amxd_object_t* fault = NULL;
    amxd_trans_t transaction;
    amxd_status_t retval = amxd_status_unknown_error;

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, faults);
    amxd_object_iterate(instance, it_fault, faults) {
        fault = amxc_container_of(it_fault, amxd_object_t, it);
        amxd_trans_del_inst(&transaction, amxd_object_get_index(fault), NULL);
    }
    retval = amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);
    return retval;
}

amxd_status_t _RemoveAllProcessFaults(amxd_object_t* root_object,
                                      UNUSED amxd_function_t* func,
                                      UNUSED amxc_var_t* args,
                                      UNUSED amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_unknown_error;
    const char* path_dumps = GET_CHAR(amxd_object_get_param_value(root_object, "StoragePath"), NULL);

    when_null_trace(path_dumps, exit, ERROR, "Failed to retrieve path of the core dumps directory");
    retval = rm_fault_instances(root_object);
    when_failed_trace(retval, exit, ERROR, "Failed to remove Fault instances from datamodel");
    if(!remove_r(path_dumps)) {
        retval = amxd_status_ok;
    }
exit:
    return retval;
}

amxd_status_t _Remove(amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_trans_t transaction;
    amxd_object_t* parent_object = NULL;
    amxd_status_t retval = amxd_status_unknown_error;

    retval = amxd_trans_init(&transaction);
    when_failed(retval, exit);

    parent_object = amxd_object_get_parent(object);
    when_null_trace(parent_object, exit, ERROR, "Failed to get parent object");

    retval = amxd_trans_select_object(&transaction, parent_object);
    when_failed(retval, exit);

    amxd_trans_del_inst(&transaction, amxd_object_get_index(object), NULL);
    retval = amxd_trans_apply(&transaction, get_dm());

exit:
    amxd_trans_clean(&transaction);
    return retval;
}

static void send_transfer_complete_event(ftx_request_t* req, char* url) {
    amxc_var_t* ret = NULL;
    amxc_var_t* event_params = NULL;
    amxc_ts_t* ts_start = NULL;
    amxc_ts_t* ts_end = NULL;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("LocalAgent.");
    ftx_error_code_t error_code;
    char* error_reason = NULL;

    if(req != NULL) {
        error_code = ftx_request_get_error_code(req);
        ts_start = ftx_request_get_start_time(req);
        ts_end = ftx_request_get_end_time(req);
        if(ftx_request_get_error_reason(req) != NULL) {
            error_reason = strdup(ftx_request_get_error_reason(req));
        }

        if(ftx_request_get_error_code(req) != ftx_error_code_no_error) {
            SAH_TRACEZ_ERROR(ME, "error code: (%u) reason: %s", error_code, ftx_request_get_error_reason(req));
        } else {
            char time_start_str[64] = {0};
            char time_end_str[64] = {0};

            amxc_ts_format(ts_start, time_start_str, sizeof(time_start_str));
            amxc_ts_format(ts_end, time_end_str, sizeof(time_end_str));

            SAH_TRACEZ_INFO(ME, "file size: %u", ftx_request_get_file_size(req));
            SAH_TRACEZ_INFO(ME, "Upload Time Start : %s", time_start_str);
            SAH_TRACEZ_INFO(ME, "Upload Time End   : %s", time_end_str);
        }
    } else {
        error_code = 7003;
        ts_start = 0;
        ts_end = 0;
        error_reason = strdup("Failed to upload ProcessFault");
    }

    amxc_var_new(&event_params);
    amxc_var_set_type(event_params, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, event_params, "TransferType", "Upload");
    amxc_var_add_key(uint32_t, event_params, "FaultCode", error_code);
    amxc_var_add_key(cstring_t, event_params, "FaultString", error_reason);
    amxc_var_add_key(amxc_ts_t, event_params, "StartTime", ts_start);
    amxc_var_add_key(amxc_ts_t, event_params, "CompleteTime", ts_end);
    amxc_var_add_key(cstring_t, event_params, "TransferURL", url);

    if(amxb_call(ctx, "LocalAgent.", "SendTransferComplete", event_params, ret, 5) != AMXB_STATUS_OK) {
        SAH_TRACEZ_WARNING(ME, "Transfer complete event could not be sent");
    }

    amxc_var_delete(&event_params);
    free(error_reason);
}

static void ftx_data_cb_cleanup(ftx_data_cb_t* ftx_data_cb) {
    if(ftx_data_cb != NULL) {
        free(ftx_data_cb->transfer_url);
        free(ftx_data_cb->file_path);
        free(ftx_data_cb);
    }
}

bool upload_cb(ftx_request_t* req, void* userdata) {
    ftx_data_cb_t* ftx_data_cb = (ftx_data_cb_t*) userdata;

    send_transfer_complete_event(req, ftx_data_cb->transfer_url);

    ftx_request_delete(&req);
    ftx_data_cb_cleanup(ftx_data_cb);

    return true;
}

static void tar_cb(UNUSED const char* const event_name,
                   UNUSED const amxc_var_t* const data,
                   void* const priv) {
    SAH_TRACEZ_IN(ME);
    tar_data_cb_t* tar_data_cb = (tar_data_cb_t*) priv;
    ftx_data_cb_t* ftx_data_cb = NULL;
    amxd_status_t status = amxd_status_unknown_error;
    ftx_request_t* request = NULL;
    amxc_string_t absolute_path_str;
    char* file_path = NULL;
    char* file_name = NULL;
    char* transfer_url = NULL;
    const char* url = GET_CHAR(tar_data_cb->args, "URL");
    const char* username = GET_CHAR(tar_data_cb->args, "Username");
    const char* password = GET_CHAR(tar_data_cb->args, "Password");

    amxc_string_init(&absolute_path_str, 0);

    ftx_data_cb = malloc(sizeof(ftx_data_cb_t));
    when_null_trace(ftx_data_cb, exit, ERROR, "Failed to allocate ftx_data_cb");
    ftx_data_cb->transfer_url = NULL;
    ftx_data_cb->file_path = NULL;

    when_null_trace(url, exit, ERROR, "URL is null");
    when_null_trace(username, exit, ERROR, "Username is null");
    when_null_trace(password, exit, ERROR, "Password is null");

    when_false_trace((strlen(url) < 2048), exit, ERROR, "URL MaximumSize is 2048");
    when_false_trace((strlen(username) < 256), exit, ERROR, "Username MaximumSize is 256");
    when_false_trace((strlen(password) < 256), exit, ERROR, "Password MaximumSize is 256");

    transfer_url = strdup(url);
    ftx_data_cb->transfer_url = transfer_url;
    amxc_string_setf(&absolute_path_str, "/tmp/ProcessFault.%d.tar.gz", tar_data_cb->id);

    file_path = amxc_string_take_buffer(&absolute_path_str);
    when_str_empty_trace(file_path, exit, ERROR, "There is no file path in the Name parameter");
    ftx_data_cb->file_path = file_path;
    file_name = basename(file_path);

    when_failed_trace(ftx_request_new(&request, ftx_request_type_upload, upload_cb), exit, ERROR, "Could not allocate memory.");
    when_failed_trace(ftx_request_set_url(request, url), exit, ERROR, "URL does not set.");
    when_failed_trace(ftx_request_set_credentials(request, ftx_authentication_any, username, password), exit, ERROR, "Credentials Error.");
    when_failed_trace(ftx_request_set_target_file(request, file_path), exit, ERROR, "There is no such file.");
    when_failed_trace(ftx_request_set_max_transfer_time(request, 600), exit, ERROR, "Could not allocate memory.");
    when_failed_trace(ftx_request_set_data(request, (void*) ftx_data_cb), exit, ERROR, "Could not set userdata.");
    when_failed_trace(ftx_request_set_upload_method(request, ftx_upload_method_post), exit, ERROR, "Could not set HTTP method.");
    when_failed_trace(ftx_request_set_http_multipart_form_data(request, "file", file_name, "application/octet-stream"), exit, ERROR, "Could not set HTTP multipart.");

    if(strncmp(url, "https://", 8) == 0) {
        int rc = -1;
        const char* ca_cert = GET_CHAR(amxd_object_get_param_value(get_root_object(), "CACertificate"), NULL);
        when_str_empty_trace(ca_cert, exit, ERROR, "CA Certificate is not defined");

        rc = ftx_request_set_ca_certificates(request, ca_cert, NULL);
        when_failed_trace(rc, exit, ERROR, "Could not set CA Certificate");
    }

    when_failed_trace(ftx_request_send(request), exit, ERROR, "The send request failed.");

    status = amxd_status_ok;

exit:
    if(status != amxd_status_ok) {
        send_transfer_complete_event(NULL, transfer_url);
        ftx_data_cb_cleanup(ftx_data_cb);
        ftx_request_delete(&request);
    }

    amxc_var_clean(tar_data_cb->args);
    amxc_var_delete(&tar_data_cb->args);
    free(tar_data_cb);

    amxc_string_clean(&absolute_path_str);

    SAH_TRACEZ_OUT(ME);
}

static void cmd_array_it_free(amxc_array_it_t* it) {
    free(it->data);
}

amxd_status_t _Upload(amxd_object_t* root_object,
                      UNUSED amxd_function_t* func,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    int ret_val = -1;
    amxd_status_t status = amxd_status_unknown_error;
    amxc_array_t cmd;
    amxp_subproc_t* subproc = NULL;
    amxc_string_t absolute_path_str;
    tar_data_cb_t* tar_data_cb = NULL;

    amxc_string_init(&absolute_path_str, 0);
    amxc_string_setf(&absolute_path_str, "/tmp/ProcessFault.%d.tar.gz", amxd_object_get_index(root_object));

    amxc_array_init(&cmd, 4);
    amxc_array_append_data(&cmd, strdup("tar"));
    amxc_array_append_data(&cmd, strdup("-czf"));
    amxc_array_append_data(&cmd, amxc_string_take_buffer(&absolute_path_str));
    amxc_array_append_data(&cmd, strdup(GET_CHAR(amxd_object_get_param_value(root_object, "FaultLocation"), NULL)));

    tar_data_cb = malloc(sizeof(tar_data_cb_t));
    tar_data_cb->id = amxd_object_get_index(root_object);
    amxc_var_new(&tar_data_cb->args);
    amxc_var_copy(tar_data_cb->args, args);

    ret_val = amxp_subproc_new(&subproc);
    when_failed_trace(ret_val, exit, ERROR, "Failed to initialize the subprocess.");

    ret_val = amxp_subproc_astart(subproc, &cmd);
    when_failed_trace(ret_val, exit, ERROR, "Failed to tar processfault data.");

    ret_val = amxp_slot_connect(amxp_subproc_get_sigmngr(subproc), "stop", NULL, tar_cb, tar_data_cb);
    when_failed_trace(ret_val, exit, ERROR, "Failed to register slot for stop signal");

    status = amxd_status_ok;

exit:
    amxc_array_clean(&cmd, cmd_array_it_free);
    amxc_string_clean(&absolute_path_str);

    if(status != amxd_status_ok) {
        send_transfer_complete_event(NULL, (char*) GET_CHAR(args, "URL"));
    }

    SAH_TRACEZ_OUT(ME);
    return status;
}

static void remove_oldest_instance(amxd_object_t* fault_obj, uint32_t nb_instance_to_delete) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, fault_obj);

    amxd_object_iterate(instance, it_fault, fault_obj) {
        amxd_object_t* fault = NULL;

        fault = amxc_container_of(it_fault, amxd_object_t, it);
        amxd_trans_del_inst(&trans, amxd_object_get_index(fault), NULL);

        nb_instance_to_delete--;

        if(nb_instance_to_delete == 0) {
            break;
        }
    }

    amxd_trans_apply(&trans, get_dm());
    amxd_trans_clean(&trans);
}

static void param_increment(const char* path) {
    amxd_param_t* param = NULL;
    amxc_var_t value;
    amxd_object_t* root_object = get_object("ProcessFaults.");
    uint32_t ivalue = 0;

    amxc_var_init(&value);

    param = amxd_object_get_param_def(root_object, path);
    when_null_trace(param, exit, ERROR, "Failed to get %s", path);

    amxd_param_get_value(param, &value);
    when_failed_trace(amxd_param_get_value(param, &value), exit, ERROR, "Failed to get %s value", path);
    ivalue = amxc_var_dyncast(uint32_t, &value) + 1;

    amxc_var_set(uint32_t, &value, ivalue);
    amxd_param_set_value(param, &value);

exit:
    amxc_var_clean(&value);
    return;
}

void _faults_max_inst_changed(UNUSED const char* const sig_name,
                              UNUSED const amxc_var_t* const data,
                              UNUSED void* const priv) {
    amxd_object_t* root_obj = get_root_object();
    uint32_t max_process_fault_entries = 0;
    uint32_t process_fault_number_of_entries = 0;

    max_process_fault_entries = amxd_object_get_value(uint32_t, root_obj, "MaxProcessFaultEntries", NULL);
    process_fault_number_of_entries = amxd_object_get_value(uint32_t, root_obj, "ProcessFaultNumberOfEntries", NULL);

    if(process_fault_number_of_entries > max_process_fault_entries) {
        uint32_t del_count = process_fault_number_of_entries - max_process_fault_entries;
        amxd_object_t* process_fault_instances = amxd_object_get_child(root_obj, "ProcessFault");
        remove_oldest_instance(process_fault_instances, del_count);
    }

    return;
}

amxd_status_t _faults_add_inst(amxd_object_t* const object,
                               amxd_param_t* const p,
                               amxd_action_t reason,
                               const amxc_var_t* const args,
                               amxc_var_t* const retval,
                               UNUSED void* priv) {

    amxd_status_t status = amxd_status_unknown_error;
    amxd_action_fn_t rotate_max_inst_func = (amxd_action_fn_t) AMXO_FUNC(dlsym(RTLD_DEFAULT, "_rotate_max_instances"));
    amxd_object_t* root_obj = get_root_object();
    amxc_var_t max;
    amxc_var_t* params = NULL;
    amxc_var_t* fault_location_var = NULL;
    bool rotate_enabled = amxd_object_get_value(bool, root_obj, "RotateProcessFaultEntries", NULL);
    uint32_t rotate_max_inst = amxd_object_get_value(uint32_t, root_obj, "MaxProcessFaultEntries", NULL);
    const char* fault_location = NULL;

    param_increment("LastUpgradeCount");
    param_increment("CurrentBootCount");

    params = amxc_var_get_key(args, "parameters", AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(params, exit, ERROR, "No parameters object found");
    fault_location_var = amxc_var_get_key(params, "FaultLocation", AMXC_VAR_FLAG_DEFAULT);
    when_null_trace(fault_location_var, exit, ERROR, "No FaultLocation object found");
    fault_location = GET_CHAR(fault_location_var, NULL);
    when_str_empty_status(fault_location, exit, status = amxd_status_invalid_value);

    amxc_var_init(&max);
    amxc_var_set(uint32_t, &max, rotate_max_inst);

    if((rotate_max_inst_func != NULL) && rotate_enabled) {
        status = rotate_max_inst_func(object, p, reason, args, retval, &max);
    } else {
        status = amxd_action_object_add_inst(object, p, reason, args, retval, &max);
    }
    amxc_var_clean(&max);

exit:
    return status;
}

void _faults_inst_removed(UNUSED const char* const sig_name,
                          UNUSED const amxc_var_t* const data,
                          UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t* params = NULL;
    params = amxc_var_get_key(data, "parameters", AMXC_VAR_FLAG_DEFAULT);

    if(params != NULL) {
        const char* path_dumps = NULL;
        path_dumps = GET_CHAR(amxc_var_get_key(params, "FaultLocation", AMXC_VAR_FLAG_DEFAULT), NULL);
        remove_r(path_dumps);
    }

    SAH_TRACEZ_OUT(ME);
    return;
}

static int get_dump_config(const char* path, amxc_var_t** config) {
    int retval = 1;
    int fd = -1;
    variant_json_t* reader = NULL;

    when_true_trace(amxj_reader_new(&reader) != 0, exit, ERROR, "Failed to create json file reader");

    fd = open(path, O_RDONLY);
    when_true_trace(fd == -1, exit, ERROR, "File open failed");

    when_true_trace(amxj_read(reader, fd) < 0, exit, ERROR, "File open failed");

    *config = amxj_reader_result(reader);
    retval = 0;

exit:
    amxj_reader_delete(&reader);
    close(fd);
    return retval;
}

static amxd_status_t create_dump_instance(amxc_var_t* config) {
    amxd_trans_t trans;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* fault = get_object("ProcessFaults.ProcessFault");

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, fault);
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_cstring_t(&trans, "ProcessID", GET_CHAR(amxc_var_get_key(config, "ProcessID", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "ProcessName", GET_CHAR(amxc_var_get_key(config, "ProcessName", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "Arguments", GET_CHAR(amxc_var_get_key(config, "Arguments", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "FaultLocation", GET_CHAR(amxc_var_get_key(config, "FaultLocation", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "TimeStamp", GET_CHAR(amxc_var_get_key(config, "TimeStamp", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "FirmwareVersion", GET_CHAR(amxc_var_get_key(config, "FirmwareVersion", AMXC_VAR_FLAG_DEFAULT), NULL));
    amxd_trans_set_cstring_t(&trans, "Reason", GET_CHAR(amxc_var_get_key(config, "Reason", AMXC_VAR_FLAG_DEFAULT), NULL));

    status = amxd_trans_apply(&trans, get_dm());

    amxd_trans_clean(&trans);

    return status;
}

static int sync_FS_DM(amxd_object_t* root_object) {
    int retval = 1;
    int n, i;
    struct dirent** namelist;
    size_t path_len = 0;
    char* path_fault_location = NULL;
    char* path = NULL;

    const char* storage_path = GET_CHAR(amxd_object_get_param_value(root_object, "StoragePath"), NULL);
    when_null_trace(storage_path, exit, ERROR, "StoragePath is NULL");
    path_fault_location = strdup(storage_path);
    when_str_empty_trace(path_fault_location, exit, ERROR, "memory allocation failure");

    path = calloc(strlen(path_fault_location) + strlen("/dump") + 1, sizeof(char));
    when_null_trace(path, exit, ERROR, "memory allocation failure");

    sprintf(path, "%s%s", path_fault_location, "/dump");

    path_len = strlen(path);

    n = scandir(path, &namelist, NULL, versionsort);
    when_true(n == -1, exit);

    for(i = 0; i < n; i++) {
        amxc_var_t* config = NULL;

        if((strcmp(namelist[i]->d_name, ".") != 0) && (strcmp(namelist[i]->d_name, "..") != 0)) {
            char* file_path = NULL;
            amxd_status_t status = amxd_status_unknown_error;

            file_path = calloc(path_len + strlen(namelist[i]->d_name) + 2 + strlen("/config.json"), sizeof(char));
            if(file_path != NULL) {
                sprintf(file_path, "%s/%s/config.json", path, namelist[i]->d_name);

                get_dump_config(file_path, &config);

                status = create_dump_instance(config);
                if(status != amxd_status_ok) {
                    remove_r(GET_CHAR(amxc_var_get_key(config, "FaultLocation", AMXC_VAR_FLAG_DEFAULT), NULL));
                }

                amxc_var_delete(&config);

                free(file_path);
            }
        }
        free(namelist[i]);
    }

    free(namelist);
    retval = 0;

exit:
    free(path_fault_location);
    free(path);
    return retval;
}

void _faults_start(UNUSED const char* const sig_name,
                   UNUSED const amxc_var_t* const data,
                   UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);

    amxd_param_t* param = NULL;
    amxc_var_t value;
    amxd_object_t* root_object = get_object("ProcessFaults.");
    uint32_t ivalue = 0;

    amxc_var_init(&value);

    // Assign PreviousBootCount with the CurrentBootCount value
    // Reset CurrentBootCount
    param = amxd_object_get_param_def(root_object, "CurrentBootCount");
    when_null_trace(param, exit, ERROR, "Failed to get CurrentBootCount");
    when_failed_trace(amxd_param_get_value(param, &value), exit, ERROR, "Failed to get CurrentBootCount value");
    ivalue = amxc_var_dyncast(uint32_t, &value);

    amxc_var_set(uint32_t, &value, 0);
    amxd_param_set_value(param, &value);

    param = amxd_object_get_param_def(root_object, "PreviousBootCount");
    when_null_trace(param, exit, ERROR, "Failed to get PreviousBootCount");
    amxc_var_set(uint32_t, &value, ivalue);
    amxd_param_set_value(param, &value);

    // Sync FS to DM
    sync_FS_DM(root_object);

exit:
    amxc_var_clean(&value);

    SAH_TRACEZ_OUT(ME);
    return;
}
