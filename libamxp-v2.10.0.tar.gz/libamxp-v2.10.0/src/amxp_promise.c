/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdarg.h>

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp_promise.h>

typedef struct _promise_chain {
    amxc_llist_it_t it;
    amxp_promise_chain_fn_t next;
} amxp_promise_chain_item_t;

static amxp_promise_t* amxp_promise_chain_next(amxp_promise_t* chained, const amxc_var_t* input);

static void amxp_promise_remove(amxc_llist_it_t* it) {
    amxp_promise_t* promise = amxc_container_of(it, amxp_promise_t, it);
    amxp_promise_delete(&promise);
}

static void amxp_promise_remove_chain(amxc_llist_it_t* it) {
    amxp_promise_chain_item_t* next = amxc_container_of(it, amxp_promise_chain_item_t, it);
    free(next);
}

static void amxp_promise_call_cb(amxp_promise_t* promise) {
    amxp_promise_cb_fn_t fn = NULL;
    switch(promise->state) {
    case amxp_promise_state_fulfilled:
        fn = promise->fulfilled;
        // the function should only be called once, reset the function pointers
        promise->fulfilled = NULL;
        promise->rejected = NULL;
        if(fn != NULL) {
            fn(promise, promise->watch_priv);
        }
        break;
    case amxp_promise_state_rejected:
        fn = promise->rejected;
        // the function should only be called once, reset the function pointers
        promise->fulfilled = NULL;
        promise->rejected = NULL;
        if(fn != NULL) {
            fn(promise, promise->watch_priv);
        }
        break;
    default:
        // the only other state a promise can be in is amxp_promise_pending
        // no need to call a callback while it is still in pending state
        break;
    }
}

static int amxp_promise_fulfill_impl(amxp_promise_t* promise, const amxc_var_t* data) {
    int retval = -1;

    // when the promise is already fulfilled, do nothing and leave
    when_true_status(amxp_promise_is_fulfilled(promise), exit, retval = AMXP_PROMISE_STATUS_FULFILLED);
    // when the promise is rejected, do nothing and leave with error
    when_true_status(amxp_promise_is_rejected(promise), exit, retval = AMXP_PROMISE_STATUS_REJECTED);

    promise->state = amxp_promise_state_fulfilled;
    promise->status = 0;
    if(data != NULL) {
        amxc_var_copy(promise->future, data);
    }

    // when fulfilled the promise can not be canceled anymore
    // when fulfilled the promise can not be waited on anymore.
    // Calling amxp_promise_wait will always succeed on a settled promise
    // For this reason the callback functions canceled and wait and the provider_priv
    // can be reset to NULL
    promise->canceled = NULL;
    promise->wait = NULL;
    promise->provider_priv = NULL;
    // if a reject timer was started stop and delete it
    amxp_timer_delete(&promise->reject_timer);

    // call the correct callback
    amxp_promise_call_cb(promise);

    retval = AMXP_PROMISE_STATUS_OK;

exit:
    return retval;

}

static int amxp_promise_reject_impl(amxp_promise_t* promise, int status) {
    int retval = -1;

    // when the promise is already rejected, do nothing and leave
    when_true_status(amxp_promise_is_rejected(promise), exit, retval = AMXP_PROMISE_STATUS_REJECTED);
    // when the promise is fulfilled, do nothing and leave with error
    when_true_status(amxp_promise_is_fulfilled(promise), exit, retval = AMXP_PROMISE_STATUS_FULFILLED);

    promise->state = amxp_promise_state_rejected;
    promise->status = status == 0? AMXP_PROMISE_STATUS_REJECTED:status;

    // when rejected the promise can not be canceled anymore
    // when rejected the promise can not be waited on anymore.
    // Calling amxp_promise_wait will always succeed on a settled promise
    // For this reason the callback functions canceled and wait and the provider_priv
    // can be reset to NULL
    promise->canceled = NULL;
    promise->wait = NULL;
    promise->provider_priv = NULL;
    // if a reject timer was started stop and delete it
    amxp_timer_delete(&promise->reject_timer);

    // call the correct callback
    amxp_promise_call_cb(promise);

    retval = AMXP_PROMISE_STATUS_OK;

exit:
    return retval;
}

static int amxp_promise_wait_current(amxp_promise_t* chained, uint32_t timeout, UNUSED void* priv) {
    int retval = 0;

    retval = amxp_promise_wait(chained->info.chained.current, timeout);
    while(retval == AMXP_PROMISE_STATUS_OK) {
        // the current promise is settled now.
        // the chained promise is updated.
        // if the chained promise is settled
        // the loop can be stopped
        if(amxp_promise_is_settled(chained)) {
            break;
        }

        retval = amxp_promise_wait(chained->info.chained.current, timeout);
    }

    return retval;
}

static int amxp_promise_wait_all(amxp_promise_t* aggregated, uint32_t timeout, UNUSED void* priv) {
    int retval = 0;

    amxc_llist_for_each(it, &aggregated->watches) {
        amxp_promise_t* promise = amxc_container_of(it, amxp_promise_t, it);
        if(amxp_promise_is_settled(promise)) {
            continue;
        }
        retval = amxp_promise_wait(promise, timeout);
        if(retval != 0) {
            // the wait failed, stop here.
            // it is up to the caller to do the correct handling
            // using the returned error.
            break;
        }
        // the sub-promise is settled now.
        // the aggregated promise is updated.
        // if the aggregated promise is settled
        // the loop can be stopped
        if(amxp_promise_is_settled(aggregated)) {
            break;
        }
    }

    return retval;
}

static void amxp_promise_cancel_all(amxp_promise_t* aggregated, UNUSED void* const priv) {
    amxp_promise_cb_fn_t cancel = NULL;
    void* provider_priv = NULL;
    amxc_llist_for_each(it, &aggregated->watches) {
        amxp_promise_t* promise = amxc_container_of(it, amxp_promise_t, it);
        if(amxp_promise_is_settled(promise)) {
            continue;
        }
        // if not settled yet, set the promise to rejected
        // status reason code: AMXP_PROMISE_STATUS_CANCELED

        // do not call amxp_promise_reject on the aggregated here.
        // that would cause that amxp_promise_update is being called
        // and could lead to that this function is called again
        // which is causing unwanted recursion.
        promise->state = amxp_promise_state_rejected;
        promise->status = AMXP_PROMISE_STATUS_CANCELED;
        // the sub-promise is rejected so remove the promise provider
        // callback functions, they can not be called anymore as the
        // promise is settled anyway
        cancel = promise->canceled;
        provider_priv = promise->provider_priv;
        promise->canceled = NULL;
        promise->wait = NULL;
        promise->provider_priv = NULL;
        // when the promise is not yet settled the cancel callback must be set
        // if it is NULL someone messed with the promise structure manually
        // to protect against "strange" crashes, let's check the pointer
        if(cancel != NULL) {
            promise->flags |= AMXP_PROMISE_FLAG_CANCELING;
            cancel(promise, provider_priv);
            promise->flags &= ~AMXP_PROMISE_FLAG_CANCELING;
        }
    }
}

// This function is used as a callback function.
// it is used for the aggregate type "all"
// It is set on all sub-promises of a aggregated "all" promise.
// Each time a sub-promises settles this function is called.
// When all sub-promises are fulfilled or at least one sub-promise
// is rejected the aggregated promise is settled as well.
// When a sub-promise is rejected, all other pending sub-promises are canceled
// and therefore will be rejected as well, the aggregated promise settles with rejected.
static void amxp_promise_update_all(amxp_promise_t* promise, void* const priv) {
    amxp_promise_t* aggregated = (amxp_promise_t*) priv;
    // if the sub-promise is rejected copy the status into the aggregated
    if(amxp_promise_is_rejected(promise)) {
        // cancel all reaggregateding sub-promises
        amxp_promise_cancel_all(aggregated, NULL);
        // reject the aggregated promise
        // take the status of the failed promise
        amxp_promise_reject_impl(aggregated, promise->status);
    } else {
        // decrease number of pending watched promises
        aggregated->info.watch_count--;
        // if count reaches 0 all promises are settled
        if(aggregated->info.watch_count == 0) {
            // make sure the aggregated promise is fulfilled.
            // when creating the aggregated promise, all futures
            // of the sub-promises were added into the future of the
            // aggregated promise, so no need to pass it in again
            amxp_promise_fulfill_impl(aggregated, NULL);
        }
    }
}

// This function is used as a callback function.
// it is used for the aggregate type "all settled"
// It is set on all sub-promises of an aggregated "all settled" promise.
// Each time a sub-promise settles this function is called.
// When all sub-promises are settled (that is they are either fulfilled or rejected)
// the aggregated promise is settled as well.
// The aggregated promise will never be rejected.
static void amxp_promise_update_all_settled(UNUSED amxp_promise_t* promise, void* const priv) {
    amxp_promise_t* aggregated = (amxp_promise_t*) priv;

    // decrease number of pending watched promises
    aggregated->info.watch_count--;
    // if count reaches 0 all promises are settled
    if(aggregated->info.watch_count == 0) {
        // make sure the aggregated promise is fulfilled.
        // when creating the aggregated promise, all futures
        // of the sub-promises were added into the future of the
        // aggregated promise, so no need to pass it in again
        amxp_promise_fulfill_impl(aggregated, NULL);
    }
}

// This function is used as a callback function.
// it is used for the aggregate type "any"
// It is set on all sub-promises of an aggregated "any" promise.
// Each time a sub-promise settles this function is called.
// When all sub-promises are rejected, the aggregated promise is rejected as well.
// If at least one sub-promise fulfills, the aggregated promise fulfills as well and
// all pending sub-promises will be canceled and therefore set in the rejected state
static void amxp_promise_update_any(amxp_promise_t* promise, void* const priv) {
    amxp_promise_t* aggregated = (amxp_promise_t*) priv;
    // if the sub-promise is fulfilled copy the data to the aggregated promise
    if(amxp_promise_is_fulfilled(promise)) {
        // cancel all pending sub-promises
        amxp_promise_cancel_all(aggregated, NULL);
        // fulfilled the aggregated promise
        amxp_promise_fulfill_impl(aggregated, promise->future);
    } else {
        if(aggregated->status == 0) {
            // take the status of the first failed promise
            aggregated->status = promise->status;
        }
        // decrease number of pending watched promises
        aggregated->info.watch_count--;
        // if count reaches 0 all promises are rejected
        if(aggregated->info.watch_count == 0) {
            // make sure the aggregated promise is rejected.
            amxp_promise_reject_impl(aggregated, aggregated->status);
        }
    }
}

// This function is used as a callback function.
// it is used for the aggregate type "race"
// It is set on all sub-promises of a aggregated "race" promise.
// When a sub-promises settles this function is called.
// The first sub-promise that settles will define the outcome of the
// aggregated promise.
// All remaining pending sub-promises will be canceled.
static void amxp_promise_update_race(amxp_promise_t* promise, void* const priv) {
    amxp_promise_t* aggregated = (amxp_promise_t*) priv;
    // if the sub-promise is fulfilled copy the data to the aggregated promise
    if(amxp_promise_is_fulfilled(promise)) {
        // cancel all pending sub-promises
        amxp_promise_cancel_all(aggregated, NULL);
        // fulfilled the aggregated promise
        amxp_promise_fulfill_impl(aggregated, promise->future);
    } else {
        // cancel all pending sub-promises
        amxp_promise_cancel_all(aggregated, NULL);
        // make sure the aggregated promise is rejected.
        // take the status of the rejected sub-promise
        amxp_promise_reject_impl(aggregated, promise->status);
    }
}

// This function is used as a callback function.
// it is used for chained promises
// Each time the current promise is settled, this function is called
// It takes the next promise in the chain and continues the chain
// if the current promise is rejected the chained promise will be rejected
// as well.
// If the current promise is fulfilled the chained promise will continue
// and can result in the chained promise being settled.
static void amxp_promise_chain_continue(amxp_promise_t* promise, void* const priv) {
    amxp_promise_t* chained = (amxp_promise_t*) priv;
    if(amxp_promise_is_rejected(promise)) {
        // stop the chain and reject the chained promise
        amxc_llist_clean(&chained->watches, amxp_promise_remove_chain);
        amxp_promise_reject_impl(chained, promise->status);
        chained->info.chained.current = NULL;
    } else {
        // continue the chain
        amxp_promise_t* next = amxp_promise_chain_next(chained, promise->future);
        when_null(next, exit);
        chained->info.chained.current = next;
    }

exit:
    // delete the current promise
    amxp_promise_delete(&promise);
    return;
}

static void amxp_promise_chain_cancel(amxp_promise_t* chained, void* const priv) {
    // cancel and delete the current promise
    // remove the callback functions as the current promise will be deleted anyway
    // no need to try and continue the chain,

    amxp_promise_when(chained->info.chained.current, amxp_promise_state_settled, NULL, NULL);
    // delete the current promise
    amxp_promise_delete(&chained->info.chained.current);
    if(chained->info.chained.final != NULL) {
        // call the final.
        // this allows the future of the chained promise to be set
        // because of cancellation, don't provide the current. it will be canceled as well.
        chained->info.chained.final(chained, NULL, chained->future, priv);
    }

    // stop the chain
    amxc_llist_clean(&chained->watches, amxp_promise_remove_chain);
}

static amxp_promise_cb_fn_t amxp_promise_get_aggregate_updater(amxp_promise_aggregate_type_t type) {
    amxp_promise_cb_fn_t fn = NULL;
    // the default case of the switch is dropped as all possible
    // cases are used.
    // if an invalid value is used as type by programming error
    // this function will return a NULL pointer
    switch(type) {
    case amxp_promise_aggregate_all:
        fn = amxp_promise_update_all;
        break;
    case amxp_promise_aggregate_all_settled:
        fn = amxp_promise_update_all_settled;
        break;
    case amxp_promise_aggregate_any:
        fn = amxp_promise_update_any;
        break;
    case amxp_promise_aggregate_race:
        fn = amxp_promise_update_race;
        break;
    }

    return fn;
}

static void amxp_promise_reject_timeout(UNUSED amxp_timer_t* timer, void* priv) {
    amxp_promise_t* promise = (amxp_promise_t*) priv;
    amxp_promise_cb_fn_t cancel = promise->canceled;
    void* provider_priv = promise->provider_priv;

    amxp_promise_reject_impl(promise, AMXP_PROMISE_STATUS_TIMEOUT);
    if(cancel != NULL) {
        promise->flags |= AMXP_PROMISE_FLAG_CANCELING;
        cancel(promise, provider_priv);
        promise->flags &= ~AMXP_PROMISE_FLAG_CANCELING;
    }
}

static bool amxp_promise_add(amxp_promise_t* aggregated,
                             amxp_promise_t* sub,
                             amxp_promise_aggregate_type_t type,
                             uint32_t* total,
                             uint32_t* fulfilled,
                             uint32_t* rejected) {
    bool waitable = true;
    amxp_promise_cb_fn_t fn = amxp_promise_get_aggregate_updater(type);

    // add the promise to the list
    amxc_llist_append(&aggregated->watches, &sub->it);
    (*total)++;

    // the default case of the switch is dropped as all possible cases are used.
    switch(type) {
    case amxp_promise_aggregate_all:
        // add sub promise future to list of futures of the aggregated promise
        amxc_var_set_index(aggregated->future, -1, sub->future, AMXC_VAR_FLAG_DEFAULT);
        break;
    case amxp_promise_aggregate_all_settled:
        // add sub promise future to list of futures of the aggregated promise
        amxc_var_set_index(aggregated->future, -1, sub->future, AMXC_VAR_FLAG_DEFAULT);
        break;
    case amxp_promise_aggregate_any:
        if(amxp_promise_is_pending(aggregated)) {
            // The future will be set when the first promise fulfills
            amxc_var_set_type(aggregated->future, AMXC_VAR_ID_NULL);
        }
        break;
    case amxp_promise_aggregate_race:
        if(amxp_promise_is_pending(aggregated)) {
            // The future will be set when the first promise fulfills
            amxc_var_set_type(aggregated->future, AMXC_VAR_ID_NULL);
        }
        break;
    }

    // only set the callback function on pending promises
    if(amxp_promise_is_pending(sub)) {
        // set the correct updater callback function depending on the aggregation type
        amxp_promise_when(sub, amxp_promise_state_settled, fn, aggregated);
        // and increase the count of pending sub-promises
        aggregated->info.watch_count++;
        if(!amxp_promise_is_waitable(sub)) {
            waitable = false;
        }
    } else if(amxp_promise_is_rejected(sub)) {
        // depending on the aggregation type the state needs to be updated
        (*rejected)++;
        // amxp_promise_aggregate_all -> reject
        // amxp_promise_aggregate_race -> reject
        if(aggregated->state == amxp_promise_state_pending) {
            if((type == amxp_promise_aggregate_all) ||
               (type == amxp_promise_aggregate_race)) {
                amxp_promise_reject_impl(aggregated, sub->status);
            }
        }
        // the following types will possibly cause an update of the aggregated state later
        // see @ref amxp_promise_update_aggregated
        //   amxp_promise_aggregate_all_settled -> fulfill when all are settled
        //   amxp_promise_aggregate_any -> reject when all are rejected
    } else {
        // only possible state when hitting this branch is amxp_promise_state_fulfilled
        // depending on the aggregation type the state needs to be updated
        (*fulfilled)++;
        // amxp_promise_aggregate_any -> fulfill
        // amxp_promise_aggregate_race -> fulfill
        if(aggregated->state == amxp_promise_state_pending) {
            if((type == amxp_promise_aggregate_any) ||
               (type == amxp_promise_aggregate_race)) {
                amxp_promise_fulfill_impl(aggregated, sub->future);
            }
        }
        // the following types will possible cause an update of the aggregated state later
        // see @ref amxp_promise_update_aggregated
        //   amxp_promise_aggregate_all -> fulfill when all are fulfilled
        //   amxp_promise_aggregate_all_settled -> fulfill when all are settled
    }

    return waitable;
}

static void amxp_promise_update_aggregated(amxp_promise_t* aggregated,
                                           bool waitable,
                                           amxp_promise_aggregate_type_t type,
                                           uint32_t total,
                                           uint32_t fulfilled,
                                           uint32_t rejected) {
    if(amxp_promise_is_pending(aggregated)) {
        // The aggregated promise is still in pending state
        // Check the counters and type:
        switch(type) {
        case amxp_promise_aggregate_all_settled:
            if(total == (fulfilled + rejected)) {
                // all sub-promises are settled.
                // update the state of the aggregated promise accordingly
                amxp_promise_fulfill_impl(aggregated, NULL);
            }
            break;
        case amxp_promise_aggregate_any:
            if(total == rejected) {
                amxc_llist_it_t* it = amxc_llist_get_first(&aggregated->watches);
                amxp_promise_t* first = amxc_container_of(it, amxp_promise_t, it);
                // all sub-promises are rejected
                // update the state of the aggregated promise accordingly
                amxp_promise_reject_impl(aggregated, first->status);

            }
            break;
        case amxp_promise_aggregate_all:
            if(total == fulfilled) {
                // all sub-promises are fulfilled
                // update the state of the aggregated promise accordingly
                amxp_promise_fulfill_impl(aggregated, NULL);
            }
            break;
        case amxp_promise_aggregate_race:
            // nothing to do here, the first promise that settles
            // will define the outcome.
            break;
        }
    }

    if(amxp_promise_is_settled(aggregated)) {
        if(total != (fulfilled + rejected)) {
            // there are still some pending sub-promises.
            // as the aggregated promise is settled, just cancel all pending sub-promises
            amxp_promise_cancel_all(aggregated, NULL);
        }
    } else {
        // if all sub-promises are waitable, and the aggregated promise is still in pending
        // state (not all sub-promises are settled), then the aggregated promise is waitable
        // as well.
        if(waitable) {
            aggregated->wait = amxp_promise_wait_all;
        }
    }
}

static amxp_promise_t* amxp_promise_get_next(amxp_promise_t* chained, amxp_promise_t* current, const amxc_var_t* input) {
    amxc_llist_it_t* next_it = amxc_llist_take_first(&chained->watches);
    amxp_promise_chain_item_t* next_item = NULL;
    amxp_promise_t* next_promise = NULL;

    // no more next item in the chain
    // fulfill the chained promise
    // the future of the chained promise is either set during the different steps
    // or when still a NULL variant, take the current input as the final future
    if(next_it == NULL) {
        // check if a final function is available
        if(chained->info.chained.final != NULL) {
            // and call it, this allows the future of the chained promise to be set
            chained->info.chained.final(chained, current, chained->future, chained->provider_priv);
        }
        chained->info.chained.current = NULL;
        if(amxc_var_is_null(chained->future)) {
            amxp_promise_fulfill_impl(chained, input);
        } else {
            amxp_promise_fulfill_impl(chained, NULL);
        }
        goto exit;
    }
    next_item = amxc_container_of(next_it, amxp_promise_chain_item_t, it);

    next_promise = next_item->next(chained, chained->info.chained.current, chained->future, chained->provider_priv);
    // the next item doesn't return a promise
    // this is allowed to stop the chain
    if((next_promise == NULL) || (next_promise == chained)) {
        next_promise = NULL;
        chained->info.chained.current = NULL;
        amxc_llist_clean(&chained->watches, amxp_promise_remove_chain);
        amxp_promise_reject_impl(chained, AMXP_PROMISE_STATUS_ABORT);
    }

exit:
    free(next_item);
    return next_promise;
}

static amxp_promise_t* amxp_promise_chain_next(amxp_promise_t* chained, const amxc_var_t* input) {
    amxp_promise_t* next = amxp_promise_get_next(chained, chained->info.chained.current, input);
    when_null(next, exit);

    while(next != NULL && amxp_promise_is_fulfilled(next)) {
        // if the next promise is already fulfilled, keep going until
        // a pending or rejected promise is found or
        // no more items are available.
        amxp_promise_t* current = next;
        input = current->future;
        next = amxp_promise_get_next(chained, current, input);
        amxp_promise_delete(&current);
        when_null(next, exit);
    }

    // if the chained is settled, just leave all done
    when_true(amxp_promise_is_settled(chained), exit);

    // if the next promise is already rejected, reject the chained
    if(amxp_promise_is_rejected(next)) {
        // the next promise is rejected, reject the chained promise
        amxc_llist_clean(&chained->watches, amxp_promise_remove_chain);
        // call final if available?
        if(chained->info.chained.final != NULL) {
            chained->info.chained.final(chained, next, chained->future, chained->provider_priv);
        }
        amxp_promise_reject_impl(chained, next->status);
        amxp_promise_delete(&next);
    } else {
        // otherwise set the continue callback, when it is settled it will be called
        amxp_promise_when(next, amxp_promise_state_settled, amxp_promise_chain_continue, chained);
    }

exit:
    return next;
}

int amxp_promise_new(amxp_promise_t** promise,
                     amxp_promise_cb_fn_t cancelfn,
                     amxp_promise_wait_cb_fn_t waitfn,
                     void* provider_priv) {
    int retval = -1;

    when_null(promise, exit);
    when_null(cancelfn, exit);

    *promise = (amxp_promise_t*) calloc(1, sizeof(amxp_promise_t));
    when_null(*promise, exit);
    retval = amxc_var_new(&(*promise)->future);
    when_failed(retval, exit);
    retval = 0;

    (*promise)->canceled = cancelfn;
    (*promise)->wait = waitfn;
    (*promise)->provider_priv = provider_priv;

exit:
    if((retval != 0) && (promise != NULL)) {
        free(*promise);
        *promise = NULL;

    }
    return retval;
}

// creates a new aggregated promise from a list of promises
// the aggregation type will define when the aggregated promise will be rejected or fulfilled.
// read the documentation of the @ref amxp_promise_aggregate_type_t for more info.
// the aggregated promise takes owner ship of the sub-promises.
// for pending sub-promises a callback will be set (potentially overwriting already set callbacks)
int amxp_promise_new_aggregate_list(amxp_promise_t** aggregated,
                                    amxp_promise_aggregate_type_t aggregate_type,
                                    amxc_llist_t* promise_list) {
    int retval = -1;
    bool waitable = true;
    // count the number of promises added to the aggregated promise
    // these numbers are used to select the initial state of the
    // aggregated promise
    uint32_t total = 0;
    uint32_t rejected = 0;
    uint32_t fulfilled = 0;

    when_null(aggregated, exit);
    when_true(amxc_llist_is_empty(promise_list), exit);

    when_failed(amxp_promise_new(aggregated, amxp_promise_cancel_all, NULL, NULL), exit);
    // start with the assumption that all sub promises are pending
    // so the aggregated promise is pending as well (default when creating a promise)
    // while looping over the sub-promises that needs to be watched
    // the state gets updated according the state of the sub-promises

    amxc_var_set_type((*aggregated)->future, AMXC_VAR_ID_LIST);
    retval = 0;
    amxc_llist_for_each(it, promise_list) {
        amxp_promise_t* promise = amxc_container_of(it, amxp_promise_t, it);
        waitable &= amxp_promise_add((*aggregated), promise, aggregate_type, &total, &fulfilled, &rejected);
        retval++;
    }

    amxp_promise_update_aggregated((*aggregated), waitable, aggregate_type, total, fulfilled, rejected);

exit:
    return retval;
}

// creates a new aggregated promise from an array of promises
// the aggregation type will define when the aggregated promise will be rejected or fulfilled.
// read the documentation of the @ref amxp_promise_aggregate_type_t for more info.
// the aggregated promise takes owner ship of the sub-promises.
// for pending sub-promises a callback will be set (potentially overwriting already set callbacks)
int amxp_promise_new_aggregate_array(amxp_promise_t** aggregated,
                                     amxp_promise_aggregate_type_t aggregate_type,
                                     uint32_t count,
                                     amxp_promise_t* promises[]) {
    int retval = -1;
    bool waitable = true;
    // count the number of promises added to the aggregated promise
    // these numbers are used to select the initial state of the
    // aggregated promise
    uint32_t total = 0;
    uint32_t rejected = 0;
    uint32_t fulfilled = 0;

    when_null(aggregated, exit);
    when_true(count == 0, exit);
    when_null(promises, exit);

    when_failed(amxp_promise_new(aggregated, amxp_promise_cancel_all, NULL, NULL), exit);
    // start with the assumption that all sub promises are pending
    // so the aggregated promise is pending as well (default when creating a promise)
    // while looping over the sub-promises that needs to be watched
    // the state gets updated according the state of the sub-promises

    amxc_var_set_type((*aggregated)->future, AMXC_VAR_ID_LIST);
    retval = 0;
    for(uint32_t index = 0; index < count; index++) {
        amxp_promise_t* promise = promises[index];
        if(promise == NULL) {
            continue;
        }
        waitable &= amxp_promise_add((*aggregated), promise, aggregate_type, &total, &fulfilled, &rejected);
        promises[index] = NULL;
        retval++;
    }

    if(amxc_llist_is_empty(&(*aggregated)->watches)) {
        // fail if no steps are added
        amxp_promise_delete(aggregated);
        retval = -1;
    } else {
        amxp_promise_update_aggregated((*aggregated), waitable, aggregate_type, total, fulfilled, rejected);
    }

exit:
    return retval;
}

// creates a new aggregated promise from an array of promises
// the aggregation type will define when the aggregated promise will be rejected or fulfilled.
// read the documentation of the @ref amxp_promise_aggregate_type_t for more info.
// the aggregated promise takes ownership of the sub-promises.
// for pending sub-promises a callback will be set (potentially overwriting already set callbacks)
int amxp_promise_new_aggregate(amxp_promise_t** aggregated,
                               amxp_promise_aggregate_type_t aggregate_type,
                               ...) {
    int retval = -1;
    bool waitable = true;
    va_list args;
    amxp_promise_t* promise = NULL;
    // count the number of promises added to the aggregated promise
    // these numbers are used to select the initial state of the
    // aggregated promise
    uint32_t total = 0;
    uint32_t rejected = 0;
    uint32_t fulfilled = 0;

    when_null(aggregated, exit);

    when_failed(amxp_promise_new(aggregated, amxp_promise_cancel_all, NULL, NULL), exit);
    // start with the assumption that all sub promises are pending
    // so the aggregated promise is pending as well (default when creating a promise)
    // while looping over the sub-promises that needs to be watched
    // the state gets updated according the state of the sub-promises

    amxc_var_set_type((*aggregated)->future, AMXC_VAR_ID_LIST);

    retval = 0;
    va_start(args, aggregate_type);
    promise = va_arg(args, amxp_promise_t*);
    while(promise != NULL) {
        waitable &= amxp_promise_add((*aggregated), promise, aggregate_type, &total, &fulfilled, &rejected);
        retval++;
        promise = va_arg(args, amxp_promise_t*);
    }
    va_end(args);

    if(amxc_llist_is_empty(&(*aggregated)->watches)) {
        // fail if no steps are added
        amxp_promise_delete(aggregated);
        retval = -1;
    } else {
        amxp_promise_update_aggregated((*aggregated), waitable, aggregate_type, total, fulfilled, rejected);
    }

exit:
    return retval;
}

int amxp_promise_new_chained(amxp_promise_t** chained, amxp_promise_final_fn_t final, void* provider_priv, ...) {
    int retval = -1;
    va_list args;
    amxp_promise_chain_fn_t next = NULL;
    amxp_promise_chain_item_t* item = NULL;

    when_null(chained, exit);

    // create the chained promise.
    // if all steps in the chain are waitable, the chained promise is waitable.
    // it is not possible in advance to know if all steps will be waitable.
    // The function @ref amxp_promise_is_waitable will always return true on a chained promise.
    // but @ref amxp_promise_wait can return not supported if a non-waitable step is encountered.
    when_failed(amxp_promise_new(chained, amxp_promise_chain_cancel, amxp_promise_wait_current, provider_priv), exit);

    retval = 0;
    va_start(args, provider_priv);
    next = va_arg(args, amxp_promise_chain_fn_t);
    while(next != NULL) {
        item = (amxp_promise_chain_item_t*) calloc(1, sizeof(amxp_promise_chain_item_t));
        when_null_status(item, final, retval = -1); // exception, jump to final
        item->next = next;
        amxc_llist_append(&(*chained)->watches, &item->it);
        retval++;
        next = va_arg(args, amxp_promise_chain_fn_t);
    }

final:
    va_end(args);
    if(retval <= 0) {
        amxp_promise_delete(chained);
        retval = -1;
    } else {
        // set the final function if provided, this will be called after the final sub-promise
        // has settled, this allows to update the chained promise future.
        // this function may be NULL
        (*chained)->info.chained.final = final;
        // start the chain, no input for the first item in the chain
        (*chained)->info.chained.current = amxp_promise_chain_next(*chained, NULL);
    }

exit:
    return retval;
}

int amxp_promise_new_chained_array(amxp_promise_t** chained, amxp_promise_final_fn_t final, void* provider_priv, uint32_t count, amxp_promise_chain_fn_t promises[]) {
    int retval = -1;

    when_null(chained, exit);
    when_null(promises, exit);
    when_true(count == 0, exit);

    // create the chained promise.
    // if all steps in the chain are waitable, the chained promise is waitable.
    // it is not possible in advance to know if all steps will be waitable.
    // The function @ref amxp_promise_is_waitable will always return true on a chained promise.
    // but @ref amxp_promise_wait can return not supported if a non-waitable step is encountered.
    when_failed(amxp_promise_new(chained, amxp_promise_chain_cancel, amxp_promise_wait_current, provider_priv), exit);

    retval = 0;
    for(uint32_t index = 0; index < count; index++) {
        amxp_promise_chain_fn_t next = promises[index];
        amxp_promise_chain_item_t* item = NULL;
        if(next == NULL) {
            continue;
        }
        item = (amxp_promise_chain_item_t*) calloc(1, sizeof(amxp_promise_chain_item_t));
        when_null_status(item, exit, retval = -1);
        item->next = next;
        amxc_llist_append(&(*chained)->watches, &item->it);
        retval++;
    }

    if(amxc_llist_is_empty(&(*chained)->watches)) {
        // fail if no steps are added
        amxp_promise_delete(chained);
        retval = -1;
    } else {
        // set the final function if provided, this will be called after the final sub-promise
        // has settled, this allows that the chained promise future can be updated.
        // this function may be NULL
        (*chained)->info.chained.final = final;
        // start the chain, no input for the first item in the chain
        (*chained)->info.chained.current = amxp_promise_chain_next(*chained, NULL);
    }

exit:
    return retval;
}

void amxp_promise_delete(amxp_promise_t** promise) {
    when_null(promise, exit);
    when_null(*promise, exit);
    (*promise)->flags |= AMXP_PROMISE_FLAG_DELETE;
    when_true(((*promise)->flags & (AMXP_PROMISE_FLAG_CANCELING | AMXP_PROMISE_FLAG_WAITING)) != 0, exit);

    if(!amxp_promise_is_settled(*promise)) {
        amxp_promise_cb_fn_t cancel_fn = (*promise)->canceled;
        void* provider_priv = (*promise)->provider_priv;
        // if the promise is still in pending state, make sure it gets rejected
        amxp_promise_reject_impl((*promise), AMXP_PROMISE_STATUS_CANCELED);
        // a pending promise must have a cancel callback
        if(cancel_fn != NULL) {
            (*promise)->flags |= AMXP_PROMISE_FLAG_CANCELING;
            cancel_fn(*promise, provider_priv);
            (*promise)->flags &= ~AMXP_PROMISE_FLAG_CANCELING;
        }
    }

    // make sure the promise is removed from the list.
    amxc_llist_it_take(&(*promise)->it);
    // remove all promises owned by this one
    amxc_llist_clean(&(*promise)->watches, amxp_promise_remove);
    // if future is doesn't have a parent, remove it.
    if(amxc_var_get_parent((*promise)->future) == NULL) {
        amxc_var_delete(&(*promise)->future);
    }
    // delete and stop the timer
    amxp_timer_delete(&(*promise)->reject_timer);
    free(*promise);
    *promise = NULL;

exit:
    return;
}

int amxp_promise_fulfill(amxp_promise_t* promise, const amxc_var_t* data) {
    int retval = -1;

    when_null(promise, exit);
    // if it is a chained promise, it is not allowed to just fulfill the promise
    // the chain will get settled automatically
    when_true_status(promise->canceled == amxp_promise_chain_cancel, exit, retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // if it is a aggregated promise, it is not allowed to just fulfill the promise
    // the aggregated will get settled automatically
    when_true_status(promise->canceled == amxp_promise_cancel_all, exit, retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    retval = amxp_promise_fulfill_impl(promise, data);

exit:
    return retval;

}

int amxp_promise_reject(amxp_promise_t* promise, int status) {
    int retval = -1;

    when_null(promise, exit);

    // if it is a chained promise, it is not allowed to just reject the promise
    // the chain will get settled automatically
    when_true_status(promise->canceled == amxp_promise_chain_cancel, exit, retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // if it is a aggregated promise, it is not allowed to just reject the promise
    // the aggregated will get settled automatically
    when_true_status(promise->canceled == amxp_promise_cancel_all, exit, retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    retval = amxp_promise_reject_impl(promise, status);

exit:
    return retval;
}

int amxp_promise_reject_after(amxp_promise_t* promise, uint32_t time_ms) {
    int retval = -1;

    when_null(promise, exit);
    // when the promise is already settled, do not start the timer
    // just leave.
    when_true_status(amxp_promise_is_settled(promise), exit, retval = 0);

    // if no timer is running, create a timer
    if(promise->reject_timer == NULL) {
        retval = amxp_timer_new(&promise->reject_timer, amxp_promise_reject_timeout, promise);
        when_failed(retval, exit);
    }
    // start the timer if it is a newly created timer
    // or reset the timer to the new time-out value for an existing timer
    retval = amxp_timer_start(promise->reject_timer, time_ms);
    when_failed(retval, exit);

exit:
    return retval;
}

// When callback functions are set on a settled promise, they will be called immediately.
int amxp_promise_when(amxp_promise_t* promise,
                      amxp_promise_state_t state,
                      amxp_promise_cb_fn_t fn,
                      void* watcher_priv) {
    int retval = -1;

    when_null(promise, exit);

    switch(state) {
    case amxp_promise_state_fulfilled:
        promise->fulfilled = fn;
        promise->watch_priv = watcher_priv;
        retval = AMXP_PROMISE_STATUS_OK;
        break;
    case amxp_promise_state_rejected:
        promise->rejected = fn;
        promise->watch_priv = watcher_priv;
        retval = AMXP_PROMISE_STATUS_OK;
        break;
    case amxp_promise_state_settled:
        promise->fulfilled = fn;
        promise->rejected = fn;
        promise->watch_priv = watcher_priv;
        retval = AMXP_PROMISE_STATUS_OK;
        break;
    default:
    case amxp_promise_state_pending:
        // it is not possible to set callback functions on pending state
        retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED;
        break;
    }

    // if the promise is already settled, make sure that
    // the correct callback function is called.
    if(retval == AMXP_PROMISE_STATUS_OK) {
        amxp_promise_call_cb(promise);
    }

exit:
    return retval;
}

int amxp_promise_wait(amxp_promise_t* promise, uint32_t timeout) {
    int retval = -1;

    when_null(promise, exit);
    // if the promise is not pending anymore, just leave
    // the wait didn't fail regardless of the status of the promise
    when_true_status(amxp_promise_is_settled(promise), exit, retval = 0);
    // if the promise is not waitable (no wait function available),
    // leave and indicate that the wait has failed
    when_null_status(promise->wait, exit, retval = AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // if a timeout timer is running, stop and delete it.
    // switching to synchronous mode anyway, use the timeout provided to this function.
    amxp_timer_delete(&promise->reject_timer);

    // set the wait flag - will block deletion of the promise until the wait function returns
    promise->flags |= AMXP_PROMISE_FLAG_WAITING;
    // call the wait function
    // Wait functions should not be implemented using a busy-waiting method.
    // Typically used in a wait function are one of these blocking system calls:
    // select, poll, epoll
    // The following call will block until the promise is settled or a
    // timeout occurs.
    retval = promise->wait(promise, timeout, promise->provider_priv);
    // unset the wait flag - promise can be deleted again
    promise->flags &= ~AMXP_PROMISE_FLAG_WAITING;
    // the provided wait function must settle the promise
    // in case the wait function didn't do its job correctly,
    // fulfill the promise (no data) when retval = 0
    // reject the promise when retval != 0
    if(amxp_promise_is_pending(promise)) {
        // This should not happen, but in case the wait function didn't do its job correctly
        // settle the promise here
        if(retval == 0) {
            amxp_promise_fulfill(promise, NULL);
        } else {
            amxp_promise_reject(promise, retval);
        }
    }
    // If the promise is deleted during the wait due to it has been settled
    // then it must be deleted here
    if(promise->flags & AMXP_PROMISE_FLAG_DELETE) {
        amxp_promise_delete(&promise);
    }

exit:
    return retval;
}

bool amxp_promise_is_rejected(const amxp_promise_t* promise) {
    bool retval = false;
    when_null(promise, exit);

    retval = (promise->state == amxp_promise_state_rejected);

exit:
    return retval;
}

bool amxp_promise_is_fulfilled(const amxp_promise_t* promise) {
    bool retval = false;
    when_null(promise, exit);

    retval = (promise->state == amxp_promise_state_fulfilled);

exit:
    return retval;
}

bool amxp_promise_is_settled(const amxp_promise_t* promise) {
    bool retval = false;
    when_null(promise, exit);

    retval = (promise->state != amxp_promise_state_pending);

exit:
    return retval;

}

bool amxp_promise_is_pending(const amxp_promise_t* promise) {
    bool retval = false;
    when_null(promise, exit);

    retval = (promise->state == amxp_promise_state_pending);

exit:
    return retval;
}

bool amxp_promise_is_waitable(const amxp_promise_t* promise) {
    bool retval = false;
    when_null(promise, exit);

    // A promise is considered waitable if:
    // - it has a wait function set by the promise provider
    // - or it is already settled
    retval = (promise->wait != NULL || amxp_promise_is_settled(promise));

exit:
    return retval;
}

int32_t amxp_promise_get_status(const amxp_promise_t* promise) {
    return promise == NULL? -1:promise->status;
}

const amxc_var_t* amxp_promise_get_future(const amxp_promise_t* promise) {
    return promise == NULL? NULL:promise->future;
}

amxc_var_t* amxp_promise_take_future(amxp_promise_t* promise) {
    amxc_var_t* f = NULL;

    when_null(promise, exit);
    // the future can only be taken when it is settled.
    when_false(amxp_promise_is_settled(promise), exit);

    f = promise->future;
    promise->future = NULL;

exit:
    return f;
}