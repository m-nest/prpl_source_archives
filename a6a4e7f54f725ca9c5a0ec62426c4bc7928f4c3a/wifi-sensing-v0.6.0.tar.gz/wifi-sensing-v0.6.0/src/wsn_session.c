/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wsn_common.h"
#include "wsn_session.h"
#include "wsn_exchange.h"
#include "wsn_main.h"

#define ME "sensing"

amxc_llist_t socketInfo;

static char* s_buildSocketPath(uint32_t sessionid) {
    char* socketpath = calloc(1, DATA_SOCKET_PATH_MAX_LEN);
    snprintf(socketpath, DATA_SOCKET_PATH_MAX_LEN, "/var/run/wifisensing/session-%d.sock", sessionid);
    return socketpath;
}

/*
 * Session instance addition action handler
 */
amxd_status_t _wsn_Sensing_createSession_oaf(amxd_object_t* object,
                                             amxd_param_t* param,
                                             amxd_action_t reason,
                                             const amxc_var_t* const args,
                                             amxc_var_t* const retval,
                                             void* priv) {

    SAH_TRACEZ_IN(ME);

    amxd_status_t status = amxd_action_object_add_inst(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "Session instance creation failed with error: %d", status);

    wsn_session_t* newsession = calloc(1, sizeof(wsn_session_t));
    ASSERT_NOT_NULL(newsession, amxd_status_out_of_mem, ME, "NULL");

    uint32_t instIndex = GET_UINT32(retval, "index");
    SAH_TRACEZ_INFO(ME, "index is %u", instIndex);

    newsession->sessionid = instIndex;

    SAH_TRACEZ_INFO(ME, "Adding new Session");
    newsession->object = object;
    object->priv = newsession;

    SAH_TRACEZ_OUT(ME);
    return status;
}

static void s_addSessionInst_oaf(void* priv _UNUSED, amxd_object_t* object, const amxc_var_t* const initialParamValues _UNUSED) {
    SAH_TRACEZ_IN(ME);

    uint32_t index = amxd_object_get_index(object);
    SAH_TRACEZ_INFO(ME, "Instance index is %u", index);

    ASSERT_TRUE(swl_typeUInt32_commitObjectParam(object, "SessionID", index), , ME, "Failed to set SessionID");

    char* socketpath = s_buildSocketPath(index);
    SAH_TRACEZ_INFO(ME, "DataSocketPath is %s", socketpath);
    ASSERT_TRUE(swl_typeCharPtr_commitObjectParam(object, "DataSocketPath", socketpath), , ME, "Failed to set DataSocketPath");
    free(socketpath);
    SAH_TRACEZ_OUT(ME);
}

SWLA_DM_HDLRS(sSessionDmHdlrs,
              ARR(),
              .instAddedCb = s_addSessionInst_oaf, );

void _wsn_session_setConf_ocf(const char* const sig_name,
                              const amxc_var_t* const data,
                              void* const priv) {
    swla_dm_procObjEvtOfLocalDm(&sSessionDmHdlrs, sig_name, data, priv);
}

int s_setSocketNonBlocking(int sockfd) {
    int flags = fcntl(sockfd, F_GETFL, 0);
    if(flags == -1) {
        SAH_TRACEZ_ERROR(ME, "Get sockfd flags failed: error:%d:%s", errno, strerror(errno));
        return -1;
    }
    if(fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1) {
        SAH_TRACEZ_ERROR(ME, "Set non-blocking flag failed: error:%d:%s", errno, strerror(errno));
        return -1;
    }
    return 0;
}


/**
 * @brief _CreateSession
 *
 * Create a sensing session
 *
 * @param args argument list
 *     - ApplicationName : Application identifier
 * @param retval variant that must contain the return value
 * @return
 *     - function execution state
 */
amxd_status_t _CreateSession(amxd_object_t* obj,
                             amxd_function_t* func _UNUSED,
                             amxc_var_t* args,
                             amxc_var_t* retval) {
    SAH_TRACEZ_IN(ME);

    const char* app = GET_CHAR(args, "ApplicationName");

    amxd_trans_t trans;
    amxd_object_t* templateObj = amxd_object_findf(obj, "Session");
    ASSERT_NOT_NULL(templateObj, amxd_status_unknown_error, ME, "Session object not found");

    SAH_TRACEZ_INFO(ME, "Create new Session with Application Name %s", app);
    ASSERT_TRANSACTION_INIT(templateObj, &trans, amxd_status_unknown_error, ME, "trans init failure");
    amxd_trans_add_inst(&trans, 0, NULL);

    SAH_TRACEZ_INFO(ME, "Updating Session object with provided arguments");
    const char* validArgs = "ApplicationName";
    amxc_var_for_each(newValue, args) {
        const char* pname = amxc_var_key(newValue);
        //skip arguments not matching instance's parameter names
        //to avoid transaction applying issue
        if(!swl_strlst_contains(validArgs, ",", pname)) {
            SAH_TRACEZ_INFO(ME, "skip unknown argument %s", pname);
            continue;
        }
        //we assume known args and obj params types are matching
        amxd_trans_set_param(&trans, pname, newValue);
    }
    ASSERT_TRANSACTION_LOCAL_DM_END(&trans, amxd_status_unknown_error, ME, "trans apply failure");
    amxd_object_t* instObj = NULL;
    amxc_llist_it_t* it = amxc_llist_get_last(&templateObj->instances);
    if(it != NULL) {
        instObj = amxc_container_of(it, amxd_object_t, it);
    }
    uint32_t index = amxd_object_get_index(instObj);

    //Returning newly created SessionID and DataSocketPath
    amxc_var_set_type(retval, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, retval, "SessionID", index);
    char* socketpath = s_buildSocketPath(index);
    SAH_TRACEZ_INFO(ME, "DataSocketPath is %s", socketpath);
    amxc_var_add_key(cstring_t, retval, "DataSocketPath", socketpath);

    //Create socket

    wsn_socket_t* newsocket = calloc(1, sizeof(wsn_socket_t));
    ASSERT_NOT_NULL(newsocket, amxd_status_out_of_mem, ME, "NULL");

    newsocket->session_id = index;
    newsocket->sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if(newsocket->sockfd < 0) {
        SAH_TRACEZ_ERROR(ME, "Error creating socket file descriptor");
        free(newsocket);
        return amxd_status_unknown_error;
    }

    struct sockaddr_un socket_addr;
    SAH_TRACEZ_INFO(ME, "Socket file descriptor is %d", newsocket->sockfd);
    SAH_TRACEZ_INFO(ME, "Socket path is %s", socketpath);
    memset(&socket_addr, 0, sizeof(struct sockaddr_un));
    socket_addr.sun_family = AF_UNIX;
    strncpy(socket_addr.sun_path, socketpath, sizeof(socket_addr.sun_path) - 1);
    SAH_TRACEZ_INFO(ME, "Attempting to bind to socket path");
    if(bind(newsocket->sockfd, (struct sockaddr*) &socket_addr, sizeof(struct sockaddr_un)) == -1) {
        SAH_TRACEZ_ERROR(ME, "Socket bind failed");
        goto error;
    }

    if(listen(newsocket->sockfd, 1) < 0) {
        SAH_TRACEZ_ERROR(ME, "Listen connection failed");
        goto error;
    }

    // Set server to non-bocking mode
    if(s_setSocketNonBlocking(newsocket->sockfd) == -1) {
        SAH_TRACEZ_ERROR(ME, "Setting socket to non-blocking failed");
        goto error;
    }

    SAH_TRACEZ_INFO(ME, "Unix Socket created and bound to %s", socketpath);

    newsocket->clientfd = -1;
    SAH_TRACEZ_INFO(ME, "Adding session id and fd to a list");
    amxc_llist_it_init(&newsocket->it);
    amxc_llist_append(&socketInfo, &newsocket->it);


    free(socketpath);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;

error:
    close(newsocket->sockfd);
    unlink(socketpath);
    free(newsocket);
    return amxd_status_unknown_error;
}

/*
 * Session instance deletion action handler
 */
amxd_status_t _wsn_Sensing_deleteSession_odf(amxd_object_t* object,
                                             amxd_param_t* param _UNUSED,
                                             amxd_action_t reason _UNUSED,
                                             const amxc_var_t* const args _UNUSED,
                                             amxc_var_t* const retval _UNUSED,
                                             void* priv _UNUSED) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t status = amxd_action_object_destroy(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "Fail to destroy obj instance st:%d", status);
    ASSERTS_EQUALS(amxd_object_get_type(object), amxd_object_instance, status, ME, "obj is not instance");

    wsn_session_t* session = (wsn_session_t*) object->priv;
    object->priv = NULL;
    ASSERTS_NOT_NULL(session, amxd_status_ok, ME, "No internal ctx");

    free(session);

    SAH_TRACEZ_OUT(ME);
    return status;
}

int wsn_closeSessionSocket(uint32_t sessionid) {
    amxc_llist_for_each(it, &socketInfo) {
        wsn_socket_t* sock = amxc_container_of(it, wsn_socket_t, it);
        if(sock->session_id == sessionid) {
            SAH_TRACEZ_INFO(ME, "Session id found in list");
            SAH_TRACEZ_INFO(ME, "Socket fd is %d for session %u", sock->sockfd, sock->session_id);
            close(sock->sockfd);
            if(sock->clientfd > 0) {
                SAH_TRACEZ_INFO(ME, "Socket fd for remote client is %d", sock->clientfd);
                close(sock->clientfd);
            }
            amxc_llist_it_take(&sock->it);
            free(sock);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief _DeleteSession
 *
 * Delete the sensing session
 *
 * @return
 *     - function execution state
 */
amxd_status_t _DeleteSession(amxd_object_t* obj,
                             amxd_function_t* func _UNUSED,
                             amxc_var_t* args _UNUSED,
                             amxc_var_t* retval _UNUSED) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t params;
    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    swla_object_paramsToMap(&params, obj);
    char* socketpath = GET_CHAR(&params, "DataSocketPath");
    uint32_t sessionid = GET_UINT32(&params, "SessionID");
    SAH_TRACEZ_INFO(ME, "Socket path is %s", socketpath);
    SAH_TRACEZ_INFO(ME, "Session id is %u", sessionid);

    SAH_TRACEZ_INFO(ME, "Searching for sessionid in list by calling wsn_getFdOfSessionSocket");
    if(wsn_closeSessionSocket(sessionid)) {
        SAH_TRACEZ_INFO(ME, "Socket was closed successfully");
    } else {
        SAH_TRACEZ_INFO(ME, "Socket not found in list");
    }

    unlink(socketpath);
    free(socketpath);

    amxd_status_t status = swl_object_delInstWithTransOnLocalDm(obj);
    if(status == amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Session instance deleted successfully");
    }

    SAH_TRACEZ_OUT(ME);
    return status;
}
