#ifndef __FILTER_DM_H__
#define __FILTER_DM_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>

/**
 * @brief Handles enable/disable of usb filter.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_filter_enable_changed(const char* const sig_name,
                                const amxc_var_t* const data,
                                void* const priv);

/**
 * @brief Handles a new usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_added(const char* const sig_name,
                       const amxc_var_t* const data,
                       void* const priv);

/**
 * @brief Handles a change to an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_changed(const char* const sig_name,
                         const amxc_var_t* const data,
                         void* const priv);

/**
 * @brief Handles the removal of an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_removed(const char* const sig_name,
                         const amxc_var_t* const data,
                         void* const priv);

/**
 * @brief Handles a new interface to an existing usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_added(const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv);

/**
 * @brief Handles a change to an existing usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_changed(const char* const sig_name,
                                   const amxc_var_t* const data,
                                   void* const priv);

/**
 * @brief Handles the removal of an existing usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_device_interface_removed(const char* const sig_name,
                                   const amxc_var_t* const data,
                                   void* const priv);

/**
 * @brief Handles a new allowed usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_added(const char* const sig_name,
                               const amxc_var_t* const data,
                               void* const priv);

/**
 * @brief Handles a change to an existing allowed usb interface.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_changed(const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv);

/**
 * @brief Handles the removal of an existing allowed usb device.
 *
 * @param sig_name The signal name.
 * @param data The data associated with the signal.
 * @param priv Private data.
 */
void _usb_allowed_device_removed(const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv);

#ifdef __cplusplus
}
#endif

#endif // __FILTER_DM_H__
