/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#ifndef __TEST_LAN_API_H__
#define __TEST_LAN_API_H__

int test_setup(void** state);
int test_teardown(void** state);

// call parameters context tests
void test_SetIPv4Config_no_pool(void** state);
void test_SetIPv4Config_no_ip(void** state);

// Input parameter validation tests
void test_SetIPv4Config_invalid_ip_address(void** state);
void test_SetIPv4Config_invalid_subnet_mask(void** state);
void test_SetIPv4Config_invalid_min_address(void** state);
void test_SetIPv4Config_invalid_max_address(void** state);
void test_SetIPv4Config_not_allowed_IANA_subnet(void** state);

// Network range tests
void test_SetIPv4Config_min_address_not_in_subnet(void** state);
void test_SetIPv4Config_max_address_not_in_subnet(void** state);
void test_SetIPv4Config_min_greater_than_max(void** state);
void test_SetIPv4Config_ip_in_range(void** state);

// Reserved address tests
void test_SetIPv4Config_ip_in_reserved(void** state);
void test_SetIPv4Config_min_in_reserved(void** state);
void test_SetIPv4Config_max_in_reserved(void** state);

// Special address tests
void test_SetIPv4Config_ip_is_subnet_address(void** state);
void test_SetIPv4Config_min_is_subnet_address(void** state);
void test_SetIPv4Config_max_is_broadcast_address(void** state);
void test_SetIPv4Config_allowed_IANA_subnet_10(void** state);
void test_SetIPv4Config_allowed_IANA_subnet_172(void** state);

void test_private_ipv4_config(void** state);
void test_alternative_ipv4_config(void** state);
void test_ipv4_config_ext(void** state);
void test_ipv6_config(void** state);
void test_lower_layer_config(void** state);
void test_domain_search_list(void** state);
void test_domain_name(void** state);

#endif // __TEST_LAN_API_H__
