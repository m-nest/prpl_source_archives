/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* System headers */
#include <ctype.h>  /* isalnum() */
#include <string.h> /* strncmp() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h> /* when_null() */
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>  /* amxd_object_t */

/* Own headers */
#include "sfpmgr.h"           /* sfp_info_t */
#include "sfpmgr_ethtoolif.h" /* sfp_ethtool_t */

static void convert_toupper(char* dest, const char* src, size_t dest_size) {
    int j = 0;
    for(int i = 0; src[i] != '\0' && j < (int) (dest_size - 1); i++) {
        if(isalnum(src[i])) {
            dest[j++] = toupper(src[i]);
        }
    }
    dest[j] = '\0';
}

/**
 * @brief Updates the warning structure for the SFP transceiver.
 *
 * @param[in] sfp_object Pointer to the SFP object containing key-value pairs.
 * @param[in,out] sfp_ethtool_param Pointer to the structure to store parsed warning parameters.
 *
 * @return Returns `SFPMGR_SUCCESS` on success.
 */
int sfpmgr_update_warning_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param) {
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    SAH_TRACEZ_INFO(ME, "updating SFP warning structure");

    when_null(sfp_info, exit);
    when_false_trace(amxc_var_type_of(&(sfp_info->key_value_pair)) == AMXC_VAR_ID_HTABLE, exit, ERROR, "Wrong variant type");

    amxc_var_for_each(item, &(sfp_info->key_value_pair)) {
        const char* const key = amxc_var_key(item);
        const char* const value = GET_CHAR(item, NULL);

        if(strncmp(key, LASER_BIAS_CURRENT_HIGH_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_hightxbias = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_BIAS_CURRENT_LOW_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_lowtxbias = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_OUTPUT_POWER_HIGH_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_hightxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_OUTPUT_POWER_LOW_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_lowtxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_TEMPERATURE_HIGH_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_hightemp = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_TEMPERATURE_LOW_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_lowtemp = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_VOLTAGE_HIGH_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_highvolt = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_VOLTAGE_LOW_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_lowvolt = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_RX_POWER_HIGH_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_highrxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_RX_POWER_LOW_WARNING, strlen(key)) == 0) {
            sfp_ethtool_param->warn_lowrxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        }
    }

exit:
    return SFPMGR_SUCCESS;
}


/**
 * @brief Updates the alarm structure based on the SFP object's key-value pairs.
 *
 * @param[in] sfp_object Pointer to the SFP object with key-value pairs.
 * @param[in,out] sfp_ethtool_param Pointer to the structure to update with alarm parameters.
 *
 * @return Returns `SFPMGR_SUCCESS` on success.
 */
int sfpmgr_update_alarm_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param) {
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;

    SAH_TRACEZ_INFO(ME, "updating SFP alarm structure");

    when_null(sfp_info, exit);
    when_false_trace(amxc_var_type_of(&(sfp_info->key_value_pair)) == AMXC_VAR_ID_HTABLE, exit, ERROR, "Wrong variant type");

    amxc_var_for_each(item, &(sfp_info->key_value_pair)) {
        const char* const key = amxc_var_key(item);
        const char* const value = GET_CHAR(item, NULL);

        if(strncmp(key, LASER_BIAS_CURRENT_HIGH_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_hightxbias = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_BIAS_CURRENT_LOW_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_lowtxbias = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_OUTPUT_POWER_HIGH_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_hightxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_OUTPUT_POWER_LOW_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_lowtxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_TEMPERATURE_HIGH_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_hightemp = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_TEMPERATURE_LOW_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_lowtemp = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_VOLTAGE_HIGH_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_highvolt = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, MODULE_VOLTAGE_LOW_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_lowvolt = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_RX_POWER_HIGH_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_highrxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        } else if(strncmp(key, LASER_RX_POWER_LOW_ALARM, strlen(key)) == 0) {
            sfp_ethtool_param->alarm_lowrxpower = (strncmp(value, "On", sizeof("On")) == 0) ? true : false;
        }
    }

exit:
    return SFPMGR_SUCCESS;
}


/**
 * @brief Updates the status structure with SFP parameters from the SFP object.
 *
 * @param[in] sfp_object Pointer to the SFP object with key-value pairs.
 * @param[in,out] sfp_ethtool_param Pointer to the structure to update with SFP status parameters.
 *
 * @return Returns `SFPMGR_SUCCESS` on success.
 */
int sfpmgr_update_status_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param) {
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;

    SAH_TRACEZ_INFO(ME, "updating SFP status structure");

    when_null(sfp_info, exit);
    when_false_trace(amxc_var_type_of(&(sfp_info->key_value_pair)) == AMXC_VAR_ID_HTABLE, exit, ERROR, "Wrong variant type");

    amxc_var_for_each(item, &(sfp_info->key_value_pair)) {
        const char* const key = amxc_var_key(item);
        const char* const value = GET_CHAR(item, NULL);

        if(strncmp(key, LASER_BIAS_CURRENT, strlen(key)) == 0) {
            float bias = 0;
            sscanf(value, "%f", &bias);
            sfp_ethtool_param->bias = (uint16_t) bias;
        } else if(strncmp(key, LASER_OUTPUT_POWER, strlen(key)) == 0) {
            float txpower = 0;
            if(sscanf(value, "%*f %*s / %f %*s", &txpower) != 1) {
                SAH_TRACEZ_ERROR(ME, "sscanf failed for '%s'", value);
            } else {
                sfp_ethtool_param->tx_power = txpower * 10; /* converted txpower in .1 db */
            }
        } else if(strncmp(key, RECEIVER_SIGNAL_AVG_OPTICAL_POWER, strlen(key)) == 0) {
            float rxpower = 0;
            if(sscanf(value, "%*f %*s / %f %*s", &rxpower) != 1) {
                SAH_TRACEZ_ERROR(ME, "sscanf failed for '%s'", value);
            } else {
                sfp_ethtool_param->rx_power = rxpower * 10; /* converted rxpower in .1 db */
            }
        } else if(strncmp(key, MODULE_TEMPERATURE, strlen(key)) == 0) {
            float temperature = 0;
            sscanf(value, "%f", &temperature);
            sfp_ethtool_param->temperature = (int16_t) temperature; /* Celsius */
        } else if(strncmp(key, MODULE_VOLTAGE, strlen(key)) == 0) {
            float volt = 0;
            sscanf(value, "%f", &volt);
            sfp_ethtool_param->volt = (uint16_t) volt; /* mv */
        }
    }

exit:
    return SFPMGR_SUCCESS;
}

/**
 * @brief Updates the threshold structure with SFP parameter thresholds.
 *
 * @param[in] sfp_object Pointer to the SFP object with threshold data.
 * @param[in,out] sfp_ethtool_param Pointer to the structure to update with threshold values.
 *
 * @return Returns `SFPMGR_SUCCESS` on success.
 */
int sfpmgr_update_threshold_structure(amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param) {
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;

    SAH_TRACEZ_INFO(ME, "updating SFP threshold structure");

    when_null(sfp_info, exit);
    when_false_trace(amxc_var_type_of(&(sfp_info->key_value_pair)) == AMXC_VAR_ID_HTABLE, exit, ERROR, "Wrong variant type");

    amxc_var_for_each(item, &(sfp_info->key_value_pair)) {
        const char* const key = amxc_var_key(item);
        const char* const value = GET_CHAR(item, NULL);
        double threshold_power = 0;

        if(strstr(key, MODULE_TEMP_HIGH_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hd", &sfp_ethtool_param->temp_high_alarm);
        } else if(strstr(key, MODULE_TEMP_LOW_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hd", &sfp_ethtool_param->temp_low_alarm);
        } else if(strstr(key, MODULE_TEMP_HIGH_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hd", &sfp_ethtool_param->temp_high_warning);
        } else if(strstr(key, MODULE_TEMP_LOW_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hd", &sfp_ethtool_param->temp_low_warning);
        } else if(strstr(key, MODULE_VOLT_HIGH_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->volt_high_alarm);
        } else if(strstr(key, MODULE_VOLT_LOW_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->volt_low_alarm);
        } else if(strstr(key, MODULE_VOLT_HIGH_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->volt_high_warning);
        } else if(strstr(key, MODULE_VOLT_LOW_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->volt_low_warning);
        } else if(strstr(key, LASER_BIAS_HIGH_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->bias_high_alarm);
            sfp_ethtool_param->bias_high_alarm *= 10;
        } else if(strstr(key, LASER_BIAS_LOW_ALARM_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->bias_low_alarm);
            sfp_ethtool_param->bias_low_alarm *= 10;
        } else if(strstr(key, LASER_BIAS_HIGH_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->bias_high_warning);
            sfp_ethtool_param->bias_high_warning *= 10;
        } else if(strstr(key, LASER_BIAS_LOW_WARNING_THRESHOLD) != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->bias_low_warning);
            sfp_ethtool_param->bias_low_warning *= 10;
            /* converted threshold_power in .1db hence mutiplying by 10 for below params*/
        } else if(strstr(key, LASER_POWER_HIGH_ALARM_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->tx_power_high_alarm = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_POWER_LOW_ALARM_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->tx_power_low_alarm = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_POWER_HIGH_WARNING_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->tx_power_high_warning = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_POWER_LOW_WARNING_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->tx_power_low_warning = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_RX_POWER_HIGH_ALARM_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->rx_power_high_alarm = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_RX_POWER_LOW_ALARM_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->rx_power_low_alarm = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_RX_POWER_HIGH_WARNING_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->rx_power_high_warning = (int16_t) (threshold_power * 10);
            }
        } else if(strstr(key, LASER_RX_POWER_LOW_WARNING_THRESHOLD) != NULL) {
            if(sscanf(value, "%*f %*s / %lf %*s", &threshold_power) == 1) {
                sfp_ethtool_param->rx_power_low_warning = (int16_t) (threshold_power * 10);
            }
        }
    }

exit:
    return SFPMGR_SUCCESS;
}

/**
 * @brief Updates the SFP parameters based on the DMC SFF-8472 standard.
 *
 * @param[in,out] sfp_ethtool_param Pointer to the structure to update with SFP parameters.
 *
 * @return void This function does not return a value.
 */
void update_dmc_sff8472_params (sfp_ethtool_t* sfp_ethtool_param) {
    if(sfp_ethtool_param == NULL) {
        SAH_TRACEZ_ERROR(ME, "Invalid sfp_param");
        return;
    }

    SAH_TRACEZ_INFO(ME, "updating DMC 8472 Params");

    sfp_ethtool_param->optcooltrans = (SFF_8472_A0_BYTE_64_COOLED_TRANS & sfp_ethtool_param->options[0]) ? true : false;
    sfp_ethtool_param->optlinearrcvr = (SFF_8472_A0_BYTE_64_LINEAR_RCVR & sfp_ethtool_param->options[0]) ? true : false;
    sfp_ethtool_param->optpwrlvl = (SFF_8472_A0_BYTE_64_POWER_LVL_1 & sfp_ethtool_param->options[0]) ? true : false;
    if(sfp_ethtool_param->optpwrlvl == POWER_LEVEL_0) {
        sfp_ethtool_param->optpwrlvl = POWER_LEVEL_1;         /* if value is 0 it indicates power level 1 */
    } else if(sfp_ethtool_param->optpwrlvl == POWER_LEVEL_1) {
        sfp_ethtool_param->optpwrlvl = POWER_LEVEL_2;         /* if value is 1 it indicates power level 2 */
    } else {
        sfp_ethtool_param->optpwrlvl = POWER_LEVEL_0;
    }
    sfp_ethtool_param->optlos = (SFF_8472_A0_BYTE_65_LOS & sfp_ethtool_param->options[1]) ? true : false;
    sfp_ethtool_param->optinvlos = (SFF_8472_A0_BYTE_65_INVERTED_LOS & sfp_ethtool_param->options[1]) ? true : false;
    sfp_ethtool_param->opttxfault = (SFF_8472_A0_BYTE_65_TX_FAULT & sfp_ethtool_param->options[1]) ? true : false;
    sfp_ethtool_param->opttxdisable = (SFF_8472_A0_BYTE_65_TX_DISABLE & sfp_ethtool_param->options[1]) ? true : false;
    sfp_ethtool_param->optrateselect = (SFF_8472_A0_BYTE_65_RATE_SELECT & sfp_ethtool_param->options[1]) ? true : false;
    sfp_ethtool_param->dmctypeImplemented = (SFF_8472_A0_BYTE_92_IMPL & sfp_ethtool_param->diag_type) ? true : false;
    sfp_ethtool_param->dmctypeInternalcal = (SFF_8472_A0_BYTE_92_INTERNAL & sfp_ethtool_param->diag_type) ? true : false;
    sfp_ethtool_param->dmctypeExternalcal = (SFF_8472_A0_BYTE_92_EXTERNAL & sfp_ethtool_param->diag_type) ? true : false;
    sfp_ethtool_param->dmctypeRxAvgPwr = (SFF_8472_A0_BYTE_92_RXAVGPWR & sfp_ethtool_param->diag_type) ? true : false;
    sfp_ethtool_param->eocalarmsImplemented = (SFF_8472_A0_BYTE_93_ALARM & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->eocsofttxDisable = (SFF_8472_A0_BYTE_93_SOFT_TX_DISABLE & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->eocsofttxFault = (SFF_8472_A0_BYTE_93_SOFT_TX_FAULT & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->eocsoftrxLOS = (SFF_8472_A0_BYTE_93_SOFT_RX_LOS & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->eocsoftrateSelect = (SFF_8472_A0_BYTE_93_SOFT_RATE_SELECT & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->sff8079appSelect = (SFF_8472_A0_BYTE_93_SFF_8079 & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->sff8431softrateSelect = (SFF_8472_A0_BYTE_93_SFF_8431 & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->txdisableState = (SFF_8472_A2_BYTE_110_TX_DISABLE & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->rs1State = (SFF_8472_A2_BYTE_110_RS1_STATE & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->rateselectState = (SFF_8472_A2_BYTE_110_RATE_SELECT & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->txfaultState = (SFF_8472_A2_BYTE_110_TX_FAULT & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->rxlosState = (SFF_8472_A2_BYTE_110_RX_LOS & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->datareadybarState = (SFF_8472_A2_BYTE_110_DATA_READY & sfp_ethtool_param->option) ? true : false;
    sfp_ethtool_param->softtxdisableSelect = (SFF_8472_A0_BYTE_93_SOFT_TX_DISABLE & sfp_ethtool_param->en_options) ? true : false;
    sfp_ethtool_param->softrateselectSelect = (SFF_8472_A0_BYTE_93_SOFT_RATE_SELECT & sfp_ethtool_param->en_options) ? true : false;
}

/**
 * @brief Updates SFP base and extended parameters in the `sfp_ethtool_t` structure.
 *
 * @param[in] sfp_object Pointer to the `amxd_object_t` structure containing SFP data.
 * @param[in,out] sfp_ethtool_param Pointer to the structure to be updated with SFP parameters.
 *
 *  @return `SFPMGR_SUCCESS` on success, `SFPMGR_INVALID` on error
 */
int sfpmgr_update_base_ext_structure (amxd_object_t* sfp_object, sfp_ethtool_t* sfp_ethtool_param) {
    int rv = SFPMGR_INVALID;
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    uint32_t val_u32 = 0;
    int rc;

    when_null(sfp_info, exit);

    when_false_trace(amxc_var_type_of(&(sfp_info->key_value_pair)) == AMXC_VAR_ID_HTABLE, exit, ERROR, "Wrong variant type");

    amxc_var_for_each(item, &(sfp_info->key_value_pair)) {
        const char* const key = amxc_var_key(item);
        const char* const value = GET_CHAR(item, NULL);

        if(strstr(key, "Identifier") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->id);
        } else if(strstr(key, "Extended identifier") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->ext_id);
        } else if(strstr(key, "Connector") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->connector);
        } else if(strstr(key, "Transceiver codes") != NULL) {
            uint8_t codes[9] = {0};
            sscanf(value, "%hhx %hhx %hhx %hhx %hhx %hhx %hhx %hhx %hhx",
                   &codes[0], &codes[1], &codes[2], &codes[3],
                   &codes[4], &codes[5], &codes[6], &codes[7], &codes[8]);
            snprintf(sfp_ethtool_param->transceiver, sizeof(sfp_ethtool_param->transceiver),
                     "%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                     codes[0], codes[1], codes[2], codes[3],
                     codes[4], codes[5], codes[6], codes[7], codes[8]);
        } else if(strstr(key, "Encoding") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->encoding);
        } else if(strstr(key, "BR, Nominal") != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->br_nominal);
            sfp_ethtool_param->br_nominal = sfp_ethtool_param->br_nominal / 100;
        } else if(strstr(key, "Rate identifier") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->rate_id);
        } else if(strstr(key, "Length (SMF,km)") != NULL) {
            sscanf(value, "%hhu", &sfp_ethtool_param->len_SMF_km);
        } else if(strstr(key, "Length (SMF)") != NULL) {
            if(strstr(value, "km")) {
                SAH_TRACEZ_WARNING(ME, "Length (SMF) is in km while m is expected");
            } else {
                rc = sscanf(value, "%u", &val_u32);
                if(rc == 1) {
                    /* len_SMF_100m is in units of 100 m (SFF-8472 6.2) */
                    val_u32 = val_u32 / 100;
                    if(val_u32 < 256) {
                        sfp_ethtool_param->len_SMF_100m = val_u32;
                    }
                }
            }
        } else if(strstr(key, "Length (50um)") != NULL) {
            rc = sscanf(value, "%u", &val_u32);
            if(rc == 1) {
                /* len_50um_10m is in units of 10 m (SFF-8472 6.3) */
                val_u32 = val_u32 / 10;
                if(val_u32 < 256) {
                    sfp_ethtool_param->len_50um_10m = val_u32;
                }
            }
        } else if(strstr(key, "Length (62.5um)") != NULL) {
            rc = sscanf(value, "%u", &val_u32);
            if(rc == 1) {
                /* len_62dot5um_10m is in units of 10 m (SFF-8472 6.4) */
                val_u32 = val_u32 / 10;
                if(val_u32 < 256) {
                    sfp_ethtool_param->len_62dot5um_10m = val_u32;
                }
            }
        } else if(strstr(key, "Length (OM3)") != NULL) {
            rc = sscanf(value, "%u", &val_u32);
            if(rc == 1) {
                /* len_OM3_10m is in units of 10 m (SFF-8472 6.6) */
                val_u32 = val_u32 / 10;
                if(val_u32 < 256) {
                    sfp_ethtool_param->len_OM3_10m = val_u32;
                }
            }
        } else if(strstr(key, "Vendor name") != NULL) {
            snprintf(sfp_ethtool_param->vendor_name, sizeof(sfp_ethtool_param->vendor_name), "%s", value);
        } else if(strstr(key, "Vendor OUI") != NULL) {
            char temp_vendor_oui[sizeof(sfp_ethtool_param->vendor_oui)] = { 0 };
            convert_toupper(temp_vendor_oui, value, sizeof(temp_vendor_oui));
            strncpy(sfp_ethtool_param->vendor_oui, temp_vendor_oui, sizeof(sfp_ethtool_param->vendor_oui));
        } else if(strstr(key, "Vendor PN") != NULL) {
            snprintf(sfp_ethtool_param->vendor_pn, sizeof(sfp_ethtool_param->vendor_pn), "%s", value);
        } else if(strstr(key, "Vendor rev") != NULL) {
            snprintf(sfp_ethtool_param->vendor_rev, sizeof(sfp_ethtool_param->vendor_rev), "%s", value);
        } else if(strstr(key, "BR margin, max") != NULL) {
            sscanf(value, "%hhu", &sfp_ethtool_param->br_max);
        } else if(strstr(key, "BR margin, min") != NULL) {
            sscanf(value, "%hhu", &sfp_ethtool_param->br_min);
        } else if(strstr(key, "Vendor SN") != NULL) {
            snprintf(sfp_ethtool_param->vendor_sn, sizeof(sfp_ethtool_param->vendor_sn), "%s", value);
        } else if(strstr(key, "Date code") != NULL) {
            snprintf(sfp_ethtool_param->date_code, sizeof(sfp_ethtool_param->date_code), "%s", value);
        } else if(strstr(key, "Option values") != NULL) {
            sscanf(value, "%hhx %hhx", &sfp_ethtool_param->options[0], &sfp_ethtool_param->options[1]);
        } else if(strstr(key, "Laser wavelength") != NULL) {
            sscanf(value, "%hu", &sfp_ethtool_param->wavelength);
        } else if(strstr(key, "Diagnostic Monitoring Type") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->diag_type);
        } else if(strstr(key, "Enhanced Options") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->en_options);
        } else if(strstr(key, "SFF-8472 Compliance") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->sff_vercompliance);
        } else if(strstr(key, "Optional Status/Control Bits") != NULL) {
            sscanf(value, "%hhx", &sfp_ethtool_param->option);
        }
    }
    rv = SFPMGR_SUCCESS;
exit:
    return rv;
}
