#include "filter.h"
#include "helpers.h"
#include "device_list.h"
#include "mod_usb_filter.h"

#include <amxc/amxc_macros.h>
#include <amxd/amxd_transaction.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <errno.h>
#include <string.h>

#define USB_SYSFS_DEVICES_PATH "/sys/bus/usb/devices"
#define USB_SYSFS_AUTH_FILENAME "authorized"

static bool allow_all_devices = false;

/**
 * @brief Set internal state for allowing all devices or not
 *
 * @param allow boolean with new state
 */
void set_allow_all_devices(bool allow) {
    SAH_TRACEZ_INFO(ME, "Setting AllowAllDevices to %d", allow);
    allow_all_devices = allow;
}

static void change_authorized_file(usb_device_t* device) {
    FILE* fp = NULL;
    amxc_string_t filepath_str;
    const char* path = NULL;
    int value = -1;

    amxc_string_init(&filepath_str, 0);

    when_null(device, exit);
    when_false(device->type == DEVICE, exit);
    when_str_empty_trace(device->sysfs_id, exit, ERROR, "Invalid SysFsId value");

    value = auth_state_to_int(device->authorized);
    when_true(value < 0, exit);

    amxc_string_setf(&filepath_str, USB_SYSFS_DEVICES_PATH "/%s/" USB_SYSFS_AUTH_FILENAME, device->sysfs_id);
    path = amxc_string_get(&filepath_str, 0);

    fp = fopen(path, "w");
    SAH_TRACEZ_INFO(ME, "Writing %d to %s", value, path);
    when_null_trace(fp, exit, ERROR, "Could not open %s for writing. Error: %d (%s)", path, errno, strerror(errno));
    fprintf(fp, "%d", value);
    fclose(fp);

exit:
    amxc_string_clean(&filepath_str);
}

static void update_device_status(usb_device_t* device) {
    amxd_trans_t trans;
    int rv = -1;
    int value = -1;

    amxd_trans_init(&trans);

    when_null(device, exit);
    when_false(device->type == DEVICE, exit);
    when_null(device->object, exit);

    value = auth_state_to_int(device->authorized);
    when_true(value < 0, exit);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, device->object);
    amxd_trans_set_value(bool, &trans, "IsAllowed", value);
    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Failed changing IsAllowed rv=%d", rv);

exit:
    amxd_trans_clean(&trans);
}

static void update_authorization(usb_device_t* device, auth_state_t authorized) {
    if(device->authorized != authorized) {
        device->authorized = authorized;
        change_authorized_file(device);
        update_device_status(device);
    }
}

// Check if given Device is allowed or not based on AllowedDevice specified by private data
static auth_state_t evaluate_device_based_on_allowed_list(device_type_t t, usb_device_list_entry_t* entry, void* priv) {
    auth_state_t authorized = BLOCKED;
    usb_device_t* allowed_device = NULL;
    usb_device_t* device = entry->device;

    when_false_trace(t == DEVICE, exit, ERROR, "not checking a correct device");
    allowed_device = (usb_device_t*) priv;
    when_null_trace(allowed_device, exit, ERROR, "allowed device NULL");
    SAH_TRACEZ_ERROR(ME, "Evalulate on list dev=%s allowed_dev=%s", entry->identifier, allowed_device->vendor_id);

    when_true_status(allow_all_devices, finish_validation, authorized = ALLOWED);
    when_false(allowed_device->enable, finish_validation);
    when_false(is_valid_hex_number(allowed_device->device_class, device->device_class), finish_validation);
    when_false(is_valid_hex_number(allowed_device->device_subclass, device->device_subclass), finish_validation);
    when_false(is_valid_hex_number(allowed_device->device_protocol, device->device_protocol), finish_validation);
    when_false(is_valid_hex_number(allowed_device->product_id, device->product_id), finish_validation);
    when_false(is_valid_hex_number(allowed_device->vendor_id, device->vendor_id), finish_validation);
    amxc_llist_for_each(it_allowed, allowed_device->interface_list) {
        usb_interface_list_entry_t* allowed_interface = amxc_container_of(it_allowed, usb_interface_list_entry_t, it);
        amxc_llist_for_each(it_device, device->interface_list) {
            usb_interface_list_entry_t* interface = amxc_container_of(it_device, usb_interface_list_entry_t, it);
            when_false(is_valid_interface(&allowed_interface->interface, &interface->interface), finish_validation);
        }
    }

    // All values are valid, allow device
    authorized = ALLOWED;

finish_validation:
    SAH_TRACEZ_ERROR(ME, "Evalulate on list dev=%s auth=%d", entry->identifier, authorized);

exit:
    return authorized;
}

static int evaluate_device_based_on_allow_boolean(device_type_t t, usb_device_list_entry_t* entry, UNUSED void* priv) {
    int rv = -1;

    when_false(t == DEVICE, exit);
    when_null(entry, exit);

    update_authorization(entry->device, allow_all_devices ? ALLOWED : BLOCKED);

exit:
    return rv;
}

// Called for all AllowedDevice instances.
// Loops over
//  - Specific Device when passed as private data
//  - All Device instances otherwise
// and allows or blocks accordingly
static int authorize_device(device_type_t t, usb_device_list_entry_t* device_entry, void* priv) {
    int rv = -1;
    auth_state_t authorized = BLOCKED;

    when_false(t == DEVICE, exit);
    when_null(device_entry, exit);

    if(usb_device_list_size(ALLOWED_DEVICE) == 0) {
        // Whitelist is empty, device should be set based on allow_all_devices boolean
        evaluate_device_based_on_allow_boolean(t, device_entry, priv);
    } else {
        // We have one or more whitelisted devices, validate device according to this list.
        amxc_llist_for_each(it, get_list(ALLOWED_DEVICE)) {
            usb_device_list_entry_t* allowed_device_entry = amxc_container_of(it, usb_device_list_entry_t, it);
            authorized = evaluate_device_based_on_allowed_list(DEVICE, device_entry, (void*) allowed_device_entry->device);
            if(authorized == ALLOWED) {
                break;
            }
        }
        update_authorization(device_entry->device, authorized);
    }

exit:
    return rv;
}

/**
 * @brief Update the usb devices allowed parameter after a change in the filters.
 */
void allow_devices_after_allowed_change(void) {
    usb_device_list_foreach(DEVICE, authorize_device, NULL);
}

/**
 * @brief Update the usb devices allowed paramter after a change in the device itself or one of their interfaces.
 *
 * @param entry Internal device structure.
 */
void allow_changed_device(usb_device_list_entry_t* entry) {
    when_null(entry, exit);
    when_false(entry->device->type == DEVICE, exit);
    // Only a valid Device needs to be allowed/blocked

    authorize_device(entry->device->type, entry, NULL);

exit:
    return;
}