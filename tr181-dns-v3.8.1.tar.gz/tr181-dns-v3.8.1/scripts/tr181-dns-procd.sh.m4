#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-dns"
PROG="/usr/bin/tr181-dns"
datamodel_root="DNS"
PROG_OPTIONS=""

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

#preservice_hook() {
#    logger -s "pre-service hook ${name}"
#}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    #preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

debuginfo() {
    process_debug_info ${datamodel_root}
    if [ -f /etc/unbound/unbound.conf ]; then
        printf "\ncat /etc/unbound/unbound.conf\n"
        cat /etc/unbound/unbound.conf
    fi
    for f in /etc/hosts /tmp/hosts/*; do
        printf "\ncat %s\n" "$f"
        cat "$f"
    done
}
