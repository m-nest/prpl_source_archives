/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <dirent.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>

#include "test_oopsmonitor.h"
#include "oopsmonitor_priv.h"

static const char* odl_defs = "test.odl";

static void add_instance(char* name) {
    dmesg_info_t dmesg_info = {0};
    amxd_object_t* root_object = NULL;
    amxd_trans_t trans;
    char* process_name = "Proc A";
    char* lr_name = "LR B";
    char* reason = "Reason C";

    dmesg_info.reason = reason;
    dmesg_info.process = process_name;
    dmesg_info.lastinstr = lr_name;
    dmesg_info.time.tm_year = 120;
    dmesg_info.time.tm_mon = 1;
    dmesg_info.time.tm_mday = 5;

    root_object = get_object("KernelFaults.");
    assert_non_null(root_object);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, root_object);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    assert_int_equal(0, oops_add_instance(&trans, &dmesg_info, name));
    assert_int_equal(amxd_trans_apply(&trans, get_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

static void mkmockdir(const char* path) {
    struct stat st = {0};

    if(stat(path, &st) == -1) {
        mkdir(path, 0755);
    }
}

static void rmmockdir(const char* path) {
    struct stat st = {0};

    if(stat(path, &st) == 0) {
        remove(path);
    }
}

static int count_files(const char* dir_path) {
    DIR* dir_ptr = NULL;
    struct dirent* direntp;
    int count = 0;

    dir_ptr = opendir(dir_path);
    assert_non_null(dir_ptr);
    direntp = readdir(dir_ptr);
    while(direntp != NULL) {
        if((strcmp(direntp->d_name, ".") != 0) &&
           (strcmp(direntp->d_name, "..") != 0)) {
            count++;
        }

        direntp = readdir(dir_ptr);
    }
    closedir(dir_ptr);
    return count;
}

int test_setup(void** state) {
    amxd_object_t* root_obj = NULL;

    amxut_bus_setup(state);

    root_obj = amxd_dm_get_root(amxut_bus_dm());
    assert_non_null(root_obj);

    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "oops_instance_removed", AMXO_FUNC(_oops_instance_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "oops_app_start", AMXO_FUNC(_oops_app_start)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "Upload", AMXO_FUNC(_Upload)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "Remove", AMXO_FUNC(_Remove)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "RemoveAllKernelFaults", AMXO_FUNC(_RemoveAllKernelFaults)), 0);
    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), odl_defs, root_obj), 0);
    mkmockdir("mock_ext/");
    amxut_bus_handle_events();

    assert_int_equal(_oopsmonitor_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxp_sigmngr_emit_signal(&(amxut_bus_dm()->sigmngr), "app:start", NULL);
    amxut_bus_handle_events();

    assert_non_null(get_object("KernelFaults."));

    return 0;
}

int test_teardown(void** state) {
    amxd_object_t* root_obj = get_root_object();
    assert_non_null(root_obj);

    _RemoveAllKernelFaults(root_obj, NULL, NULL, NULL);
    amxut_bus_handle_events();

    assert_int_equal(_oopsmonitor_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxo_resolver_import_close_all();
    amxut_bus_handle_events();
    amxut_bus_teardown(state);
    rmmockdir("mock_oopses/");
    rmmockdir("mock_ext/");
    return 0;
}

void test_instance_deleted(UNUSED void** state) {
    amxd_object_t* root_object = get_root_object();
    amxd_trans_t trans;

    assert_int_equal(amxd_trans_init(&trans), 0);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 0);

    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-42", false);
    add_instance("dmesg-ramoops-42");

    assert_int_equal(count_files("mock_oopses/"), 1);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 1);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, root_object);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, ".KernelFault");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, get_dm()), 0);
    amxut_bus_handle_events();

    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 0);
    assert_int_equal(count_files("mock_oopses/"), 0);
    amxd_trans_clean(&trans);
}

void test_remove_all_oops(UNUSED void** state) {
    amxd_object_t* root_object = get_root_object();

    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-0", false);
    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-1", false);

    add_instance("dmesg-ramoops-0");
    add_instance("dmesg-ramoops-1");

    assert_int_equal(count_files("mock_oopses/"), 2);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 2);
    _RemoveAllKernelFaults(root_object, NULL, NULL, NULL);
    amxut_bus_handle_events();

    assert_int_equal(count_files("mock_oopses/"), 0);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 0);
}

void test_remove_oops(UNUSED void** state) {
    const amxc_llist_it_t* it = NULL;
    amxd_object_t* root_object = get_root_object();
    amxd_object_t* oops_object = NULL;
    amxd_object_t* root_instance_object = NULL;

    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-0", false);
    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-1", false);

    add_instance("dmesg-ramoops-0");
    add_instance("dmesg-ramoops-1");

    assert_int_equal(count_files("mock_oopses/"), 2);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 2);

    root_instance_object = get_object("KernelFaults.KernelFault.");
    assert_non_null(root_instance_object);
    it = amxd_object_first_instance(root_instance_object);
    assert_non_null(it);
    oops_object = amxc_llist_it_get_data(it, amxd_object_t, it);
    assert_non_null(oops_object);
    _Remove(oops_object, NULL, NULL, NULL);
    amxut_bus_handle_events();

    assert_int_equal(count_files("mock_oopses/"), 1);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 1);
}

void test_parse_file(UNUSED void** state) {
    dmesg_info_t dmesg_info = {0};
    copy("../mocks/mock_dmesg", "mock_oopses/dmesg-ramoops-0", false);
    assert_int_equal(0, dmesg_parse_file("mock_oopses/dmesg-ramoops-0", &dmesg_info));
    assert_int_equal(strcmp(dmesg_info.reason, "Reason is kernel NULL pointer dereference\n"), 0);
    assert_int_equal(strcmp(dmesg_info.process, "MOCKPROCESS"), 0);
    assert_int_equal(strcmp(dmesg_info.lastinstr, "mock_LR.part.11+0x42/0x42\n"), 0);
    free(dmesg_info.reason);
    free(dmesg_info.process);
    free(dmesg_info.lastinstr);
}

void test_add_instance(UNUSED void** state) {
    dmesg_info_t dmesg_info = {0};
    amxd_object_t* root_object = NULL;
    amxd_object_t* root_instance_object = NULL;
    amxd_object_t* oops_instance = NULL;
    amxd_trans_t trans;
    amxc_ts_t* time_ts = NULL;
    const amxc_llist_it_t* it = NULL;
    struct tm tm_instance;
    char* process_name = "Proc A";
    char* lr_name = "LR B";
    char* reason = "Reason C";

    dmesg_info.reason = reason;
    dmesg_info.process = process_name;
    dmesg_info.lastinstr = lr_name;
    dmesg_info.time.tm_year = 120;
    dmesg_info.time.tm_mon = 1;
    dmesg_info.time.tm_mday = 5;

    root_object = get_object("KernelFaults.");
    assert_non_null(root_object);
    assert_int_equal(0, amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL));

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, root_object);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    assert_int_equal(0, oops_add_instance(&trans, &dmesg_info, "dmesg-ramoops-0"));
    assert_int_equal(amxd_trans_apply(&trans, get_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    root_instance_object = get_object("KernelFaults.KernelFault.");
    it = amxd_object_first_instance(root_instance_object);
    assert_non_null(it);
    oops_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
    assert_non_null(oops_instance);
    assert_int_equal(strcmp(process_name, GET_CHAR(amxd_object_get_param_value(oops_instance, "ProcessName"), NULL)), 0);
    assert_int_equal(strcmp(lr_name, GET_CHAR(amxd_object_get_param_value(oops_instance, "LastInstruction"), NULL)), 0);
    assert_int_equal(strcmp(reason, GET_CHAR(amxd_object_get_param_value(oops_instance, "Reason"), NULL)), 0);
    assert_int_equal(strcmp("dmesg-ramoops-0", GET_CHAR(amxd_object_get_param_value(oops_instance, "FaultLocation"), NULL)), 0);
    time_ts = amxd_object_get_value(amxc_ts_t, oops_instance, "TimeStamp", NULL);
    assert_non_null(time_ts);
    assert_true(amxc_ts_is_valid(time_ts));
    assert_int_equal(0, amxc_ts_to_tm_utc(time_ts, &tm_instance));
    assert_int_equal(120, tm_instance.tm_year);
    assert_int_equal(1, tm_instance.tm_mon);
    assert_int_equal(5, tm_instance.tm_mday);
    free(time_ts);
}

void test_upload(UNUSED void** state) {
    amxc_var_t* params = NULL;
    amxc_var_t* ret = NULL;
    amxd_object_t* oops_instance = NULL;

    add_instance("dmesg-ramoops-0");

    oops_instance = get_object("KernelFaults.KernelFault.1.");
    assert_non_null(oops_instance);

    amxc_var_new(&params);
    amxc_var_new(&ret);
    amxc_var_set_type(params, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, params, "URL", "http://192.168.1.3:8080");
    amxc_var_add_key(cstring_t, params, "Username", "user");
    amxc_var_add_key(cstring_t, params, "Password", "secret");

    expect_string(__wrap_ftx_request_set_target_file, file_path, "/data/oops/dmesg-ramoops-0");
    expect_string(__wrap_ftx_request_set_http_multipart_form_data, part_filename, "dmesg-ramoops-0");
    expect_string(__wrap_amxb_call, object, "LocalAgent.");
    expect_string(__wrap_amxb_call, method, "SendTransferComplete");
    amxd_object_invoke_function(oops_instance, "Upload", params, ret);

    amxc_var_delete(&ret);
    amxc_var_delete(&params);
}

void test_scan_dir(UNUSED void** state) {
    amxd_object_t* root_object = get_root_object();
    copy("../mocks/mock_dmesg", "mock_ext/dmesg-ramoops-12", false);
    copy("../mocks/mock_dmesg", "mock_ext/dmesg-ramoops-13", false);

    assert_int_equal(count_files("mock_oopses/"), 0);
    assert_int_equal(count_files("mock_ext/"), 2);
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 0);
    scan_oops_dir("mock_ext/");
    amxut_bus_handle_events();
    assert_int_equal(amxd_object_get_value(uint32_t, root_object, "KernelFaultNumberOfEntries", NULL), 2);
    assert_int_equal(count_files("mock_oopses/"), 2);
    assert_int_equal(count_files("mock_ext/"), 0);
    _RemoveAllKernelFaults(root_object, NULL, NULL, NULL);
    amxut_bus_handle_events();
}