/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <amxc/amxc_macros.h>

#include "mock_amxb_uci.h"

// internal variable
static amxb_state_t amxb_obj;

// Function
// helper
static int resolve_method(const char* method) {
    if(strcmp(method, "add") == 0) {
        return ADD_CMD;
    }
    if(strcmp(method, "set") == 0) {
        return SET_CMD;
    }
    if(strcmp(method, "commit") == 0) {
        return COMMIT_CMD;
    }
    if(strcmp(method, "delete") == 0) {
        return DELETE_CMD;
    }
    return NB_CMD;
}

static void store_args(UNUSED amxc_var_t* args) {
    if(amxb_obj.args != NULL) {
        amxc_var_delete(&amxb_obj.args);
    }
    amxb_obj.args = amxc_var_get_key(args, "values", AMXC_VAR_FLAG_COPY);
}

// wrapper
int __wrap_amxb_call(UNUSED amxb_bus_ctx_t* const bus_ctx,
                     UNUSED const char* object,
                     const char* method,
                     amxc_var_t* args,
                     UNUSED amxc_var_t* ret,
                     UNUSED int timeout) {
    int retval = 1;
    int cmd = NB_CMD;

    assert_string_equal(amxb_obj.object, object);
    assert_non_null(method);

    cmd = resolve_method(method);

    when_false(cmd != NB_CMD, exit);
    when_false(amxb_obj.accept_cmd[cmd], exit);

    switch(cmd) {
    case SET_CMD:
        store_args(args);
        break;
    case ADD_CMD:
        store_args(args);
        break;
    case COMMIT_CMD:
        break;
    case DELETE_CMD:
        break;
    default:
        goto exit;
    }
    retval = 0;
exit:
    return retval;
}

amxb_bus_ctx_t* __wrap_amxb_be_who_has(char* component) {
    assert_non_null(component);
    memcpy(amxb_obj.object, component, BUFFER_SIZE);
    return &amxb_obj.bus;
}

// mock specifique
void mock_amxb_init(void) {
    for(int i = 0; i < NB_CMD; i++) {
        amxb_obj.accept_cmd[i] = true;
    }
    amxb_obj.object[0] = '\0';
    amxb_obj.config_type[0] = '\0';
    return;
}

void mock_amxb_clean(void) {
    for(int i = 0; i < NB_CMD; i++) {
        amxb_obj.accept_cmd[i] = false;
    }
    if(amxb_obj.args != NULL) {
        amxc_var_delete(&amxb_obj.args);
    }
    amxb_obj.object[0] = '\0';
    amxb_obj.config_type[0] = '\0';
    return;
}

void mock_amxb_set_config(char* config) {
    memcpy(amxb_obj.config_type, config, BUFFER_SIZE);
    return;
}

void mock_amxb_set_cmd(int cmd, bool accepted) {
    amxb_obj.accept_cmd[cmd] = accepted;
    return;
}

amxc_var_t* mock_amxb_get_subsection(char* subsection) {
    return GET_ARG(amxb_obj.args, subsection);
}