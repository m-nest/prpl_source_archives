%config {
    %global privileges = {
        user = "USER_ID", group = "GROUP_ID", capabilities = ["CAP_NET_BIND_SERVICE", "CAP_NET_RAW"]
    };
}