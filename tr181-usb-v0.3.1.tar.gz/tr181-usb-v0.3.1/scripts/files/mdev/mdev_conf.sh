null    root:root 0666  @chmod 666 $MDEV
usbdev[0-9.]+ root:root 660 */usr/bin/event2usb
sd[a-z]+ root:root 660 */usr/bin/event2usb
(usb)?/?(lp[0-9]+) root:root 660 =usb%2 */usr/bin/event2usb
ttyUSB[0-9]* root:root 660 */usr/bin/event2usb
# add USB BUS (HOST) 
SUBSYSTEM=usb;DEVTYPE=usb_device;ACTION=add;BUSNUM=.*;.* root:root 660 */usr/bin/event2usb
null root:root 666
