/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdarg.h>
#include <setjmp.h>
#include <stddef.h>
#include <cmocka.h>

#include <amxc/amxc_macros.h>

#include "../common_routing_dhcp/common_routing_dhcp.h"
#include "test_module.h"
#include "mod-routing-dhcp.h"

static uint16_t hash(const char* str) {
    uint16_t hash = 5381;
    int c;

    while((c = *str++)) {
        hash = ((hash << 5) + hash) ^ c; /* hash * 33 ^ c */
    }

    return hash;
}

void test_can_load_module(UNUSED void** state) {
    assert_int_equal(_mod_routing_dhcp_main(0, get_test_dm(), get_test_parser()), 0);
    assert_int_equal(_mod_routing_dhcp_main(1, get_test_dm(), get_test_parser()), 0);
    return;
}

void test_add_forwarding(UNUSED void** state) {
    amxo_parser_t* parser = get_test_parser();
    amxd_dm_t* dm = get_test_dm();
    amxd_object_t* root_obj = amxd_dm_get_root(dm);
    amxd_object_t* test_obj = NULL;
    amxc_var_t data_event;
    amxc_var_t* work_var = NULL;

    assert_int_equal(_mod_routing_dhcp_main(AMXO_START, dm, parser), 0);

    test_obj = amxd_object_findf(root_obj, "DHCPv4Client.Client.dummy-1.");
    assert_non_null(test_obj);
    handle_events();

    amxc_var_init(&data_event);
    amxc_var_set_type(&data_event, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data_event, "name", "dummy-1");
    amxc_var_add_key(cstring_t, &data_event, "path", "DHCPv4Client.Client.");
    amxc_var_add_key(cstring_t, &data_event, "notification", "dm:instance-added");
    work_var = amxc_var_add_key(amxc_htable_t, &data_event, "parameters", NULL);
    amxc_var_add_key(cstring_t, work_var, "Interface", "Device.IP.Interface.2.");
    amxc_var_add_key(cstring_t, work_var, "IPAddress", "192.168.1.1");

    amxp_sigmngr_add_signal(&dm->sigmngr, "test-signal");
    amxp_slot_connect(&dm->sigmngr, "test-signal", NULL, mod_routing_possible_router_added, NULL);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "test-signal", &data_event);
    handle_events();

    test_obj = amxd_object_findf(root_obj, "Routing.Router.main.IPv4Forwarding.cpe-dhcp-%d-%d.", hash("10.10.10.10"), hash("192.168.1.1"));
    assert_non_null(test_obj);

    assert_int_equal(_mod_routing_dhcp_main(AMXO_STOP, dm, parser), 0);
    handle_events();

    test_obj = amxd_object_findf(root_obj, "Routing.Router.main.IPv4Forwarding.cpe-dhcp-%d-%d.", hash("10.10.10.10"), hash("192.168.1.1"));
    assert_false(test_obj = NULL);

    amxc_var_clean(&data_event);
}

void test_update_forwarding(UNUSED void** state) {
    amxo_parser_t* parser = get_test_parser();
    amxd_dm_t* dm = get_test_dm();
    amxd_object_t* root_obj = amxd_dm_get_root(dm);
    amxd_object_t* test_obj = NULL;
    char* val = NULL;
    amxd_trans_t trans;
    amxc_var_t data_event;
    amxc_var_t* work_var = NULL;

    assert_int_equal(_mod_routing_dhcp_main(AMXO_START, dm, parser), 0);

    test_obj = amxd_object_findf(root_obj, "DHCPv4Client.Client.dummy-1.");
    assert_non_null(test_obj);
    handle_events();

    val = amxd_object_get_value(cstring_t, test_obj, "Interface", NULL);
    assert_string_equal(val, "Device.IP.Interface.2.");
    free(val);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, test_obj);
    amxd_trans_set_value(cstring_t, &trans, "Interface", "Device.IP.Interface.3.");
    amxd_trans_apply(&trans, dm);
    handle_events();

    val = amxd_object_get_value(cstring_t, test_obj, "Interface", NULL);
    assert_string_equal(val, "Device.IP.Interface.3.");
    free(val);

    amxc_var_init(&data_event);
    amxc_var_set_type(&data_event, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data_event, "name", "dummy-1");
    amxc_var_add_key(cstring_t, &data_event, "path", "DHCPv4Client.Client.");
    amxc_var_add_key(cstring_t, &data_event, "notification", "dm:instance-added");
    work_var = amxc_var_add_key(amxc_htable_t, &data_event, "parameters", NULL);
    amxc_var_add_key(cstring_t, work_var, "Interface", "Device.IP.Interface.2.");
    amxc_var_add_key(cstring_t, work_var, "IPAddress", "192.168.1.1");

    amxp_sigmngr_add_signal(&dm->sigmngr, "test-signal-1");
    amxp_slot_connect(&dm->sigmngr, "test-signal-1", NULL, mod_routing_possible_router_added, NULL);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "test-signal-1", &data_event);
    handle_events();

    amxc_var_clean(&data_event);
    amxc_var_init(&data_event);
    amxc_var_set_type(&data_event, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data_event, "path", "DHCPv4Client.Client.1.");
    amxc_var_add_key(cstring_t, &data_event, "notification", "dm:object-changed");
    work_var = amxc_var_add_key(amxc_htable_t, &data_event, "parameters", NULL);
    work_var = amxc_var_add_key(amxc_htable_t, work_var, "Interface", NULL);
    amxc_var_add_key(cstring_t, work_var, "from", "Device.IP.Interface.2.");
    amxc_var_add_key(cstring_t, work_var, "to", "Device.IP.Interface.3.");

    amxp_sigmngr_add_signal(&dm->sigmngr, "test-signal-2");
    amxp_slot_connect(&dm->sigmngr, "test-signal-2", NULL, mod_routing_possible_router_changed, NULL);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "test-signal-2", &data_event);
    handle_events();

    test_obj = amxd_object_findf(root_obj, "Routing.Router.main.IPv4Forwarding.cpe-dhcp-%d-%d.", hash("10.10.10.10"), hash("192.168.1.1"));
    assert_non_null(test_obj);

    val = amxd_object_get_value(cstring_t, test_obj, "Interface", NULL);
    assert_string_equal(val, "Device.IP.Interface.3.");
    free(val);

    assert_int_equal(_mod_routing_dhcp_main(AMXO_STOP, dm, parser), 0);
    handle_events();

    amxd_trans_clean(&trans);
    amxc_var_clean(&data_event);
}

void test_delete_forwarding(UNUSED void** state) {
    amxo_parser_t* parser = get_test_parser();
    amxd_dm_t* dm = get_test_dm();
    amxd_object_t* root_obj = amxd_dm_get_root(dm);
    amxd_object_t* test_obj = NULL;
    amxd_trans_t trans;
    amxc_var_t data_event;
    amxc_var_t* work_var = NULL;

    assert_int_equal(_mod_routing_dhcp_main(AMXO_START, dm, parser), 0);
    handle_events();

    test_obj = amxd_object_findf(root_obj, "DHCPv4Client.Client.dummy-1.");
    assert_non_null(test_obj);

    amxc_var_init(&data_event);
    amxc_var_set_type(&data_event, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data_event, "name", "dummy-1");
    amxc_var_add_key(cstring_t, &data_event, "path", "DHCPv4Client.Client.");
    amxc_var_add_key(cstring_t, &data_event, "notification", "dm:instance-added");
    work_var = amxc_var_add_key(amxc_htable_t, &data_event, "parameters", NULL);
    amxc_var_add_key(cstring_t, work_var, "Interface", "Device.IP.Interface.2.");
    amxc_var_add_key(cstring_t, work_var, "IPAddress", "192.168.1.1");

    amxp_sigmngr_add_signal(&dm->sigmngr, "test-signal-1");
    amxp_slot_connect(&dm->sigmngr, "test-signal-1", NULL, mod_routing_possible_router_added, NULL);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "test-signal-1", &data_event);
    handle_events();



    test_obj = amxd_object_findf(root_obj, "Routing.Router.main.IPv4Forwarding.cpe-dhcp-%d-%d.", hash("10.10.10.10"), hash("192.168.1.1"));
    assert_non_null(test_obj);

    test_obj = amxd_object_findf(root_obj, "DHCPv4Client.Client.dummy-1.");
    assert_non_null(test_obj);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, amxd_object_get_parent(test_obj));
    amxd_trans_del_inst(&trans, amxd_object_get_index(test_obj), NULL);
    amxd_trans_apply(&trans, dm);
    handle_events();

    amxc_var_clean(&data_event);
    amxc_var_init(&data_event);
    amxc_var_set_type(&data_event, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data_event, "name", "dummy-1");

    amxp_sigmngr_add_signal(&dm->sigmngr, "test-signal-2");
    amxp_slot_connect(&dm->sigmngr, "test-signal-2", NULL, mod_routing_possible_router_removed, NULL);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "test-signal-2", &data_event);
    handle_events();

    test_obj = amxd_object_findf(root_obj, "DHCPv4Client.Client.dummy-1.");
    assert_false(test_obj != NULL);

    test_obj = amxd_object_findf(root_obj, "Routing.Router.main.IPv4Forwarding.cpe-dhcp-%d-%d.", hash("10.10.10.10"), hash("192.168.1.1"));
    assert_false(test_obj != NULL);

    assert_int_equal(_mod_routing_dhcp_main(AMXO_STOP, dm, parser), 0);
    handle_events();

    amxd_trans_clean(&trans);
    amxc_var_clean(&data_event);
}
