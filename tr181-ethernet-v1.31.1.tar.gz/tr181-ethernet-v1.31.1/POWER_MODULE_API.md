# Ethernet Power Management Module API

This document describes the API that must be implemented by power management modules for the `tr181-ethernet` service.

## Overview

Power management modules are dynamically loaded shared libraries that provide platform-specific implementations for controlling the power state of an Ethernet interface.

Power controller modules are loaded by `tr181-ethernet` from the directory configured by `ethernet-manager.mod-dir`. The default value is `/usr/lib/amx/${name}/modules`, which resolves to `/usr/lib/amx/tr181-ethernet/modules` for this component.

To make an external power controller selectable, install the shared library in that directory and add its module name (without the `.so` extension) to `Ethernet.SupportedPWRControllers`. The controller can then be selected using `Ethernet.PowerController` or `Ethernet.Interface.{i}.PowerController`.

## Module Structure

A power management module must:

1. Register itself with the AMXM module name `pwr-ctrl`
2. Implement the required command functions
3. Use AMXM constructor and destructor macros for initialization and cleanup

### Module Registration

```c
#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>

#define MOD_PWR_CTRL "pwr-ctrl"

static int pwr_capabilities_get(const char* function_name,
                                amxc_var_t* args,
                                amxc_var_t* ret);
static int pwr_status_get(const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret);
static int pwr_mode_set(const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret);

static AMXM_CONSTRUCTOR module_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_PWR_CTRL);
    amxm_module_add_function(mod, "pwr-capabilities-get", pwr_capabilities_get);
    amxm_module_add_function(mod, "pwr-status-get", pwr_status_get);
    amxm_module_add_function(mod, "pwr-mode-set", pwr_mode_set);

    return 0;
}

static AMXM_DESTRUCTOR module_stop(void) {
    return 0;
}
```

**Constant:**

- `MOD_PWR_CTRL` = `"pwr-ctrl"` - The AMXM module name that must be used for registration

## Command Functions

### 1. `pwr-mode-set` (Required)

Starts a power transition for a Ethernet Interface.

**Function Signature:**

```c
int pwr_mode_set(const char* function_name, amxc_var_t* args, amxc_var_t* ret);
```

**Parameters:**

- `function_name`: The name of the function being called (typically unused)
- `args`: Input arguments as a variant hashtable containing:
  - `intf_name` (string, required): Ethernet interface name
  - `power_mode` (string, required): The desired power state. Supported values are typically:
    - `On` - Interface powered on and operational
    - `Off` - Interface powered off, using no power
    - `LowPower` - Interface in low-power mode (optional, platform-dependent)
- `ret`: Output result as a variant hashtable

**Return Value:**

- `0` when the power transition was successfully started
- Non-zero when input validation fails or the platform operation could not be started

**Output (`ret` parameter):**

The function should populate `ret` as a hashtable. The implementation commonly returns:

- `power_status` (string): The requested or current power state

**Important Behavior:**

`ChangePowerMode()` is asynchronous at the data-model level. A successful `pwr-mode-set` call only means the transition has been started. After the hardware operation completes, the module must notify `tr181-ethernet` by calling the internal `pwr-async-done` (see [Asynchronous Completion](#asynchronous-completion)).

### 2. `pwr-capabilities-get` (Required)

Returns the power capabilities supported by the hardware platform for a given interface.

**Function Signature:**

```c
int pwr_capabilities_get(const char* function_name, amxc_var_t* args, amxc_var_t* ret);
```

**Parameters:**

- `function_name`: The name of the function being called (typically unused)
- `args`: Input arguments as a variant hashtable containing:
  - `intf_name` (string, required): Ethernet interface name
- `ret`: Output result as a variant hashtable

**Return Value:**

- `0` on success
- Non-zero on failure

**Output (`ret` parameter):**

- `power_capabilities` (CSV string): Comma-separated list of supported power states, for example `On,Off,LowPower`

### 3. `pwr-status-get` (Required)

Returns the current power state of the Ethernet interface.

**Function Signature:**

```c
int pwr_status_get(const char* function_name, amxc_var_t* args, amxc_var_t* ret);
```

**Parameters:**

- `function_name`: The name of the function being called (typically unused)
- `args`: Input arguments as a variant hashtable containing:
  - `intf_name` (string, required): Ethernet interface name
- `ret`: Output result as a variant hashtable

**Return Value:**

- `0` on success
- Non-zero on failure

**Output (`ret` parameter):**

- `power_status` (string): Current power state, typically `On`, `Off`, or `LowPower`

## Asynchronous Completion

The `Device.Ethernet.Interface.{i}.ChangePowerMode()` RPC is implemented as a deferred call in `tr181-ethernet`.

The sequence is:

1. `ChangePowerMode(PowerState)` is called on the data model
2. `tr181-ethernet` invokes `pwr-mode-set` on the selected controller
3. The controller starts the platform-specific hardware operation
4. When the hardware operation completes, the controller must call `pwr-async-done`
5. `tr181-ethernet` updates `PowerStatus` and completes the deferred RPC

To notify the manager that the transition is complete, call:

```c
amxc_var_t ret;
amxc_var_t args;

amxc_var_init(&ret);
amxc_var_init(&args);
amxm_execute_function(NULL, MOD_PWR_CTRL, "pwr-async-done", &args, &ret);
amxc_var_clean(&ret);
amxc_var_clean(&args);
```

**ASCII Flow (Successful Path):**

```text
Client / Management App
        |
        | ChangePowerMode("LowPower")
        v
tr181-ethernet
[_ChangePowerMode()]
        |
        |-- create deferred call (call_id)
        |-- store target state
        |-- start timeout timer
        |-- call selected controller: pwr-mode-set(...)
        v
Power Controller Module
[pwr-mode-set()]
        |
        |-- start platform-specific hardware operation
        |-- return 0 immediately
        v
tr181-ethernet
        |
        |-- RPC remains deferred
        |
        |   ... hardware work continues in background ...
        |
        <----------------------------------------+
        |                                        |
        | pwr-async-done                         |
        |                                        |
Power Controller Module                          |
[timer / interrupt / worker callback] ----------+
        |
        v
tr181-ethernet
[ethernet_async_change_power_mode_status_set_done()]
        |
        |-- set PowerStatus = requested state
        |-- complete deferred RPC
        |-- clear async state and stop waiting
        v
Client receives final completion
```

**ASCII Flow (Timeout / Failure to Complete):**

```text
Client / Management App
        |
        | ChangePowerMode("Off")
        v
tr181-ethernet
        |
        |-- create deferred call
        |-- start timeout timer
        |-- call pwr-mode-set(...)
        v
Power Controller Module
        |
        |-- starts badly OR never calls pwr-async-done
        v
tr181-ethernet
        |
        |   ... waiting ...
        |
        |-- timeout timer expires
        |-- remove deferred call
        |-- clear async state
        v
Request is canceled / fails
```

In short: `pwr-mode-set` starts the work now, and `pwr-async-done` tells `tr181-ethernet` later that the work has finished.

**Important Notes:**

- `pwr-async-done` is registered by `tr181-ethernet`, not by the external module
- If `pwr-async-done` is never called, the deferred RPC times out
- `PowerStatus` is updated by `tr181-ethernet` after the completion callback is received

## Integration with `tr181-ethernet`

The power module integrates with the `tr181-ethernet` data model as follows:

1. **Module loading**: `tr181-ethernet` loads controllers listed in `Ethernet.SupportedPWRControllers`
2. **Controller selection**: The active controller is chosen from `Ethernet.PowerController` or `Ethernet.Interface.{i}.PowerController`
3. **Capability sync**: `tr181-ethernet` calls `pwr-capabilities-get` and updates `PowerCapability`
4. **Status sync**: `tr181-ethernet` calls `pwr-status-get` and updates `PowerStatus`
5. **Power transition**: `ChangePowerMode(PowerState)` triggers `pwr-mode-set`
6. **Completion**: The module calls `pwr-async-done`, then `tr181-ethernet` finalizes the deferred request

## Data Model Parameters

The power module interacts with these Ethernet interface parameters:

- `PowerCapability` (read-only): Comma-separated list of supported power states
- `PowerStatus` (read-only): Current power state of the interface
- `PowerState` (protected, persistent): Target state stored in the data model
- `ChangePowerMode(PowerState)` (async RPC): Starts a power transition

The module is selected through:

- `Ethernet.SupportedPWRControllers`: Allowed power controller names
- `Ethernet.PowerController`: Default power controller
- `Ethernet.Interface.{i}.PowerController`: Per-interface power controller override

## Creating a Module in a Separate Repository

Use the in-tree `mod-pwr-dummy` implementation as a starting template.

Suggested minimal layout:

```text
my-ethernet-pwr-module/
├── include_priv/
│   └── mod_ethernet_pwr_myboard.h
├── src/
│   ├── mod_ethernet_pwr_myboard.c
│   └── makefile
└── README.md
```

Typical integration steps:

1. Implement module registration and all required command handlers
2. Build a shared library named `<module-name>.so`
3. Install it in `/usr/lib/amx/tr181-ethernet/modules` (or your configured `tr181-ethernet.mod-dir`)
4. Ensure `<module-name>` is listed in `Ethernet.SupportedPWRControllers`
5. Select it with `Ethernet.PowerController` or `Ethernet.Interface.{i}.PowerController`
6. Validate `ChangePowerMode()` end-to-end, including `pwr-async-done` callback flow

**Minimal Example:**

```c
#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>

#define MOD_PWR_CTRL "pwr-ctrl"

static int pwr_mode_set(UNUSED const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret) {
    const char* intf_name = GET_CHAR(args, "intf_name");
    const char* power_mode = GET_CHAR(args, "power_mode");

    if((intf_name == NULL) || (*intf_name == '\0') ||
       (power_mode == NULL) || (*power_mode == '\0')) {
        return -1;
    }

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "power_status", power_mode);

    /* Start platform-specific work here, then call pwr-async-done. */
    return 0;
}

static int pwr_capabilities_get(UNUSED const char* function_name,
                                amxc_var_t* args,
                                amxc_var_t* ret) {
    const char* intf_name = GET_CHAR(args, "intf_name");

    if((intf_name == NULL) || (*intf_name == '\0')) {
        return -1;
    }

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(csv_string_t, ret, "power_capabilities", "On,Off,LowPower");
    return 0;
}

static int pwr_status_get(UNUSED const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret) {
    const char* intf_name = GET_CHAR(args, "intf_name");

    if((intf_name == NULL) || (*intf_name == '\0')) {
        return -1;
    }

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "power_status", "On");
    return 0;
}

AMXM_CONSTRUCTOR module_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_PWR_CTRL);
    amxm_module_add_function(mod, "pwr-capabilities-get", pwr_capabilities_get);
    amxm_module_add_function(mod, "pwr-status-get", pwr_status_get);
    amxm_module_add_function(mod, "pwr-mode-set", pwr_mode_set);

    return 0;
}

AMXM_DESTRUCTOR module_stop(void) {
    return 0;
}
```

**Build:**

```bash
gcc -shared -fPIC -o mod-pwr-custom.so mod-pwr-custom.c -lamxc -lamxm
```

**Install:**

```bash
cp mod-pwr-custom.so /usr/lib/amx/tr181-ethernet/modules/
```

After installation, add `mod-pwr-custom` to `Ethernet.SupportedPWRControllers` and select it through `PowerController`.

## Reference Implementation

An in-tree reference implementation is available in `mod-pwr-dummy`.

It demonstrates:

- Registration under the `pwr-ctrl` AMXM module name
- `pwr-capabilities-get`, `pwr-status-get`, and `pwr-mode-set`
- An asynchronous completion path using `pwr-async-done`
- The expected `power_capabilities` and `power_status` return keys
