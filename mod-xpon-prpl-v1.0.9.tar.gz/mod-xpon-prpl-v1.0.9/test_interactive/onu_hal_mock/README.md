# ONU HAL mock

Mock for a ONU HAL agent.

Relevant links:
- [prpl XPON Manager](https://prplfoundationcloud.atlassian.net/wiki/spaces/PRPLWRT/pages/17596853/XPON+Manager)
