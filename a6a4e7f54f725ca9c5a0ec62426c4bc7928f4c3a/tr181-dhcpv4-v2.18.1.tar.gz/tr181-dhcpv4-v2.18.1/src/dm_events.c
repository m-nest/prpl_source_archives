/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_object_event.h>

#include "dhcp.h"
#include "dm_events.h"
#include "pools.h"
#include "pool_info.h"
#include "firewall_utility.h"

#define ME "events"

/**
 * @brief
 * Updates the status of a DHCPv4 pool based on the server's enabled state.
 * Enables or disables the pool, opens firewall ports if necessary, and
 * manages pool bindings.
 *
 * @param parent UNUSED parent object
 * @param pool The DHCPv4 pool object to update
 * @param priv Pointer to a boolean indicating whether the DHCPv4 server is enabled
 *
 * @return 0
 */
static int pool_status_update(UNUSED amxd_object_t* parent,
                              amxd_object_t* pool,
                              void* priv) {
    bool server_enabled = *(bool*) priv;
    pool_info_t* info = NULL;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(pool, exit, ERROR, "Invalid pool argument");
    when_null_trace(pool->priv, exit, ERROR, "Cannot get private data from pool object");
    info = (pool_info_t*) pool->priv;

    if(server_enabled) {
        bool pool_enabled = amxd_object_get_value(bool, pool, "Enable", NULL);
        if(pool_enabled) {
            SAH_TRACE_INFO("Enabling pool: %s", amxd_object_get_name(pool, AMXD_OBJECT_NAMED));
            firewall_open_dhcp_port(info);
            info->flags.bit.fw_up = 1;
            pool_info_enable(pool);
        }
    } else {
        SAH_TRACE_INFO("Disabling pool: %s", amxd_object_get_name(pool, AMXD_OBJECT_NAMED));
        pools_remove_bindings(pool);
        pool_info_disable(pool);
    }
exit:
    amxd_trans_clean(&trans);
    return 0;
}

/**
 * @brief
 * Updates the status of all DHCPv4 pools to match the current state of the server.
 * Iterates through all pools and calls pool_status_update() for each one.
 *
 * @param server_enabled Boolean indicating whether the DHCPv4 server is enabled
 */
static void pools_update_all_status(bool server_enabled) {
    amxd_object_t* pools = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.");
    when_null_trace(pools, exit, ERROR, "DHCPv4Server.Pool object not found");
    SAH_TRACEZ_INFO(ME, "DHCPv4Server is '%s', updating all DHCPv4 pools to match server state",
                    server_enabled ? "Enabled" : "Disabled");
    amxd_object_for_all(pools, ".*", pool_status_update, &server_enabled);

exit:
    return;
}

/**
 * @brief
 * Starts or stops the DHCPv4 service.
 * Called when the TR181 DHCPv4.Server.Enable data model parameter has changed.
 *
 * @param event_name event name
 * @param event_data event data
 * @param priv private data associated with event subscription
 */
void _server_enable(UNUSED const char* const event_name,
                    const amxc_var_t* const event_data,
                    UNUSED void* const priv) {
    bool enable = false;
    amxc_var_t data;
    amxd_object_t* dhcpv4_obj = amxd_dm_findf(dhcp_get_dm(), "%s", DHCP_SERVER);
    int r = 1;

    amxc_var_init(&data);

    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");
    when_null_trace(dhcpv4_obj, exit, ERROR, "Cannot find DHCPv4Server object");
    SAH_TRACEZ_INFO(ME, "DHCPv4 server enable flag has changed in TR-181 data model");

    enable = GETP_BOOL(event_data, "parameters.Enable.to");
    SAH_TRACEZ_INFO(ME, "Handling DHCPv4.Server.Enable=%d...", enable ? 1 : 0);

    // add signal to the end of the queue to start back-end after the defaults
    if(enable) {
        amxd_object_get_params(dhcpv4_obj, &data, amxd_dm_access_protected);
        amxd_object_emit_signal(amxd_dm_get_root(dhcp_get_dm()), "dhcpv4-server-start-back-end", &data);
    } else {
        char* controller = NULL;
        amxc_var_t ret;
        pools_update_all_status(false);
        controller = amxd_object_get_value(cstring_t, dhcpv4_obj, "Controller", NULL);
        when_null_trace(controller, exit, ERROR, "Cannot get controller from server.");

        amxc_var_init(&ret);

        r = amxm_execute_function(controller,
                                  controller,
                                  "stop-back-end",
                                  &data,
                                  &ret);

        free(controller);
        amxc_var_clean(&ret);
        when_failed_trace(r, exit, ERROR, "Cannot stop dhcpv4 server back-end : %d", r);
    }

exit:
    amxc_var_clean(&data);
    return;
}

void _server_config_changed(UNUSED const char* const event_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    amxc_var_t* tmp = NULL;
    int r = 1;
    char* controller = NULL;
    amxc_var_t ret;
    amxc_var_t data;
    amxd_object_t* dhcpv4_obj = amxd_dm_findf(dhcp_get_dm(), "%s", DHCP_SERVER);
    bool enable = amxd_object_get_value(bool, dhcpv4_obj, "Enable", NULL);

    amxc_var_init(&ret);
    amxc_var_init(&data);

    when_null_trace(dhcpv4_obj, exit, ERROR, "Cannot find DHCPv4Server object");

    controller = amxd_object_get_value(cstring_t, dhcpv4_obj, "Controller", NULL);
    when_null_trace(controller, exit, ERROR, "Cannot get controller from server.");

    if(enable) {
        r = amxm_execute_function(controller,
                                  controller,
                                  "stop-back-end",
                                  &data,
                                  &ret);

        when_failed_trace(r, exit, ERROR, "Cannot stop dhcpv4 server back-end : %d", r);

        amxd_object_get_params(dhcpv4_obj, &data, amxd_dm_access_protected);
        if((tmp = GETP_ARG(event_data, "parameters.IgnoreIDS")) != NULL) {
            amxc_var_set_key(&data, "IgnoreIDS", GET_ARG(tmp, "to"), AMXC_VAR_FLAG_DEFAULT);
        }
        if((tmp = GETP_ARG(event_data, "parameters.DDNSUpdate")) != NULL) {
            amxc_var_set_key(&data, "DDNSUpdate", GET_ARG(tmp, "to"), AMXC_VAR_FLAG_DEFAULT);
        }
        if((tmp = GETP_ARG(event_data, "parameters.EnableFQDN")) != NULL) {
            amxc_var_set_key(&data, "EnableFQDN", GET_ARG(tmp, "to"), AMXC_VAR_FLAG_DEFAULT);
        }

        r = amxm_execute_function(controller,
                                  controller,
                                  "start-back-end",
                                  &data,
                                  &ret);

        when_failed_trace(r, exit, ERROR, "Cannot start dhcpv4 server back-end : %d", r);
    }
exit:
    free(controller);
    amxc_var_clean(&ret);
    amxc_var_clean(&data);
    return;
}

/**
 * @brief
 * Function handler to start the back-end
 *
 * Checks whether the server is enabled. If disabled, marks all pools
 * as "Disabled" and skips starting the backend.
 *
 * @param event_name event name
 * @param event_data data of the event
 * @param priv NULL
 */
void _server_back_end_start(UNUSED const char* const event_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    int r = 1;
    char* controller = NULL;
    amxc_var_t ret;
    amxc_var_t data;
    bool server_enabled = false;
    amxd_object_t* dhcpv4_obj = amxd_dm_findf(dhcp_get_dm(), "%s", DHCP_SERVER);

    amxc_var_init(&ret);
    amxc_var_init(&data);
    amxc_var_copy(&data, event_data);

    when_null_trace(dhcpv4_obj, exit, ERROR, "Cannot find DHCPv4.Server object");

    server_enabled = amxd_object_get_value(bool, dhcpv4_obj, "Enable", NULL);

    if(server_enabled) {
        controller = amxd_object_get_value(cstring_t, dhcpv4_obj, "Controller", NULL);
        when_null_trace(controller, exit, ERROR, "Cannot get controller from pool.");
        r = amxm_execute_function(controller,
                                  controller,
                                  "start-back-end",
                                  &data,
                                  &ret);
        when_failed_trace(r, exit, ERROR, "Cannot start dhcpv4 server back-end");
    } else {
        SAH_TRACEZ_WARNING(ME, "DHCPv4Server is disabled, backend will not start");
    }
    pools_update_all_status(server_enabled);

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    free(controller);
    return;
}
