/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <amxc/amxc.h>

#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <string.h>

#include <amxb/amxb_types.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_macros.h>
#include <linux/netlink.h>
#include <unistd.h>
#include <stdio.h>

#include "mock.h"

gmap_query_t* __wrap_gmap_query_open_ext(const char* expression, UNUSED const char* name, gmap_query_cb_t fn, void* user_data) {
    gmap_query_t* retval = NULL;
    __wrap_gmap_query_open_ext_2(&retval, expression, name, 0, fn, user_data);
    return retval;
}

bool __wrap_gmap_query_open_ext_2(gmap_query_t** query,
                                  const char* expression,
                                  UNUSED const char* name,
                                  UNUSED gmap_query_flags_t flags,
                                  gmap_query_cb_t fn,
                                  void* user_data) {
    gmap_query_t* retval = (gmap_query_t*) mock();
    assert_non_null(query);
    check_expected(expression);
    if(retval != NULL) {
        retval->fn = fn;
        retval->data = user_data;
    }
    *query = retval;
    return retval != NULL;
}

static void _gmap_query_get_recursive_template(amxd_object_t* object,
                                               amxc_var_t* parameters);

static void _gmap_query_get_recursive_object(amxd_object_t* object,
                                             amxc_var_t* parameters);

static void _gmap_query_get_recursive_template(amxd_object_t* object,
                                               amxc_var_t* parameters) {
    amxc_var_t* template_var = amxc_var_add_key(amxc_llist_t, parameters,
                                                amxd_object_get_name(object, AMXD_OBJECT_NAMED),
                                                NULL);

    amxd_object_for_each(instance, it, object) {
        amxd_object_t* child_obj = amxc_container_of(it, amxd_object_t, it);
        amxc_var_t* child_params = amxc_var_add(amxc_htable_t, template_var, NULL);
        _gmap_query_get_recursive_object(child_obj, child_params);
    }
}

static void _gmap_query_get_recursive_object(amxd_object_t* object,
                                             amxc_var_t* parameters) {
    uint32_t index = amxd_object_get_index(object);

    /* include details*/
    amxd_object_get_params(object, parameters, amxd_dm_access_protected);
    amxc_var_add_key(cstring_t, parameters, "Id", amxc_var_constcast(cstring_t, amxc_var_get_key(parameters, "Key", 0)));

    if(index != 0) {
        amxc_var_add_key(uint32_t, parameters, "Index", index);
    }

    amxd_object_for_each(child, it, object) {
        amxd_object_t* child_obj = amxc_container_of(it, amxd_object_t, it);
        //if template add list otherwise add htable
        if(child_obj->type == amxd_object_template) {
            _gmap_query_get_recursive_template(child_obj, parameters);
        } else {
            const char* child_name = amxd_object_get_name(child_obj, AMXD_OBJECT_NAMED);
            amxc_var_t* childparams = amxc_var_add_key(amxc_htable_t, parameters, child_name, NULL);
            _gmap_query_get_recursive_object(child_obj, childparams);
        }
    }
}

void gmap_query_exec_callback(gmap_query_t* query,
                              const char* key,
                              gmap_query_action_t action) {
    amxc_var_t data;
    amxd_object_t* device = NULL;

    assert_non_null(query);
    assert_non_null(query->fn);
    assert_non_null(key);
    assert_string_not_equal(key, "");

    device = amxd_dm_findf(amxut_bus_dm(), "Devices.Device.%s.", key);
    assert_non_null(device);

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    _gmap_query_get_recursive_object(device, &data);

    query->fn(query, key, &data, action);

    amxc_var_clean(&data);
}

void __wrap_gmap_query_close(gmap_query_t* query) {
    check_expected(query);
}

int __wrap_system(const char* __command) {
    check_expected(__command);
    printf("System CALL: %s \n", __command);
    return mock();
}

int __wrap_amxc_ts_now(amxc_ts_t* tsp) {
    tsp->sec = 0;
    tsp->nsec = 0;
    tsp->offset = 0;
    return 0;
}

bool __wrap_gmap_device_clearTag(const char* key, const char* tags, const char* expression, gmap_traverse_mode_t mode) {
    check_expected(key);
    check_expected(tags);
    check_expected(expression);
    check_expected(mode);
    return true;
}

bool __wrap_gmap_device_setTag(const char* key, const char* tags, const char* expression, gmap_traverse_mode_t mode) {
    check_expected(key);
    check_expected(tags);
    check_expected(expression);
    check_expected(mode);
    return true;
}

char* __wrap_gmap_devices_findByMac(const char* mac) {
    check_expected(mac);
    return (char*) mock();
}

void __wrap_gmap_devices_destroyDevice(const char* key) {
    check_expected(key);
}

void mock_gmap_make_alternative(const char* master,
                                const char* alternative) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    amxd_trans_select_pathf(&trans, "Devices.Device.%s.Alternative.", master);
    amxd_trans_add_inst(&trans, 0, alternative);
    amxd_trans_select_pathf(&trans, "Devices.Device.%s.", alternative);
    amxd_trans_set_value(cstring_t, &trans, "Master", master);

    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));

    amxd_trans_clean(&trans);
}

void mock_gmap_remove_alternative(const char* master,
                                  const char* alternative) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    amxd_trans_select_pathf(&trans, "Devices.Device.%s.Alternative.", master);
    amxd_trans_del_inst(&trans, 0, alternative);
    amxd_trans_select_pathf(&trans, "Devices.Device.%s.", alternative);
    amxd_trans_set_value(cstring_t, &trans, "Master", "");

    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));

    amxd_trans_clean(&trans);
}

void mock_gmap_set_active(const char* key,
                          bool active) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    amxd_trans_select_pathf(&trans, "Devices.Device.%s.", key);
    amxd_trans_set_value(bool, &trans, "Active", active);

    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));

    amxd_trans_clean(&trans);
}

bool __wrap_is_ntp_time_synchronized(void) {
    return (bool) mock();
}