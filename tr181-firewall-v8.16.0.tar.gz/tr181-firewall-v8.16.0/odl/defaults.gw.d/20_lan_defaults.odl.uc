{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
%populate {
    object Firewall {
        object Policy {
            instance add(Alias=WAN2LAN_low) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2LAN_medium) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2LAN_high) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='High_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=WAN2LAN_Custom) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=IPV6_WAN2LAN_low) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2LAN_medium) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2LAN_high) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='IPV6_High_Out']";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WAN2LAN_Custom) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 6;
            }
{% if (has_failover): %}
            instance add(Alias=WANCELLULAR2LAN_low) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2LAN_medium) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2LAN_high) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='High_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=WANCELLULAR2LAN_Custom) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 4;
            }
            instance add(Alias=IPV6_WANCELLULAR2LAN_low) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Low']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2LAN_medium) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='IPV6_Medium']";
                parameter ReverseTargetChain = "Accept";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2LAN_high) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='High']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='IPV6_High_Out']";
                parameter IPVersion = 6;
            }
            instance add(Alias=IPV6_WANCELLULAR2LAN_Custom) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lan}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Custom_In']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='Custom_Out']";
                parameter IPVersion = 6;
            }
{% endif; %}
        }
        object InterfaceSetting {
            instance add(Alias=lan) {
                parameter Interface = "${ip_intf_lan}";
                parameter IPv4AcceptICMPEchoRequest = true;
                parameter IPv6AcceptICMPEchoRequest = true;
                parameter IsolateInterface = "Firewall.InterfaceSetting.[Alias=='guest']";
                parameter IPv4AcceptUDPTraceroute = true;
                parameter IPv6AcceptUDPTraceroute = true;
                parameter StealthMode = false;
            }
        }
        object Service {
            instance add(Alias=igmp-lan) {
                parameter Protocol = "2";
                parameter Interface = "${ip_intf_lan}";
                parameter IPVersion = 4;
                parameter Enable = 1;
                parameter Persistent = 1;
            }
        }
        object DMZ {
            instance add(1, Alias=wanDMZ) {
                parameter Interface = "${logical_intf_wan}";
                parameter Origin = "User";
                parameter Description = "Default instance for the UI.";
                parameter Enable = false;
                parameter DestIP = "";
            }
        }
    }
}
