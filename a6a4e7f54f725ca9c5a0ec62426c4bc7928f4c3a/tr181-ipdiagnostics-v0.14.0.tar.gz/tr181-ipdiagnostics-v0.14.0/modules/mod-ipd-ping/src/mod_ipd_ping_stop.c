/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_types.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_ipd_common.h"
#include "mod_ipd_ping.h"
#include "mod_ipd_ping_common.h"
#include "mod_ipd_ping_status.h"
#include "ip_diagnostics.h"
#include "ipping.h"

// module trace zone
#define ME "mod-p-stop"

/**
 * @brief
 *
 * @param function_name Unused parameter
 * @param params Input parameters for the test to stop
 * @param ret return params of the stopped test
 * @return int
 */
int mod_ipping_test_stop(UNUSED const char* function_name,
                         amxc_var_t* params,
                         amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    ipping_test_status_t status;
    amxp_subproc_t* proc_ipping = NULL;
    amxc_var_t* var = NULL;
    const int pid = GETP_INT32(params, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_PID);

    proc_ipping = amxp_subproc_find(pid);
    amxc_var_move(ret, params);
    status = ipping_test_error_canceled;

    //Kill the process
    amxp_subproc_kill(proc_ipping, SIGTERM);
    amxp_subproc_wait(proc_ipping, MOD_IPD_SUBPROC_WAIT);
    ipping_kill_ipping_test(pid);

    ipping_delete_result_file();
    amxp_subproc_delete(&proc_ipping);

    // Replace the status in the output variant
    var = GET_ARG(ret, IPPING_RET_KEY_PST);
    amxc_var_set(cstring_t, var, (cstring_t) str_ipping_test_status[status]);

    // Clear proc state
    var = GETP_ARG(ret, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_PID);
    amxc_var_set(int32_t, var, 0);
    var = GETP_ARG(ret, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_FD_STDOUT);
    amxc_var_set(int32_t, var, 0);
    var = GETP_ARG(ret, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_FD_STDERR);
    amxc_var_set(int32_t, var, 0);

    SAH_TRACEZ_OUT(ME);
    return 0;
}
