/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "dummy_pon_ctrl.h"

/* System headers */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h> /* UNUSED */
#include <amxm/amxm.h>        /* amxm_callback_t */

/* Own headers */
#include "mod_xpon_dummy_trace.h"
#include "xpon_macros.h" /* ARRAY_SIZE() */

static const char* const MOD_PON_CTRL = "pon_ctrl";

static amxm_module_t* s_pon_ctrl_module = NULL;


static int dummy_set_max_nr_of_onus(UNUSED const char* function_name,
                                    amxc_var_t* args,
                                    UNUSED amxc_var_t* ret) {
    int rc = -1; /* error */
    when_null_trace(args, exit, ERROR, "args is NULL");
    const uint32_t max_nr_of_onus = amxc_var_constcast(uint32_t, args);
    when_true_trace(0 == max_nr_of_onus, exit, ERROR, "max_nr_of_onus is 0");
    rc = 0; /* success */
exit:
    return rc;
}

#define CPM_NR_OF_KEYS_REQUIRED 4
static const char* CPM_KEYS_REQUIRED[CPM_NR_OF_KEYS_REQUIRED] = {
    "path", "call_id", "power_state", "timeout_ms"
};

int dummy_change_power_mode(UNUSED const char* function_name,
                            amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {

    int rc = -1; /* error */
    int i;
    bool has_key;

    when_null_trace(args, exit, ERROR, "args is NULL");
    when_false_trace(amxc_var_type_of(args) == AMXC_VAR_ID_HTABLE, exit, ERROR,
                     "args is not an htable");

    const amxc_htable_t* const htable = amxc_var_constcast(amxc_htable_t, args);
    when_null_trace(htable, exit, ERROR, "args is not an htable (2)");

    for(i = 0; i < CPM_NR_OF_KEYS_REQUIRED; ++i) {
        has_key = amxc_htable_contains(htable, CPM_KEYS_REQUIRED[i]);
        when_false_trace(has_key, exit, ERROR, "args does not contain key '%s'",
                         CPM_KEYS_REQUIRED[i]);
    }
    rc = 0; /* success */
exit:
    return rc;
}

typedef struct _func_info {
    const char* const name;
    amxm_callback_t cb;
} func_info_t;

static const func_info_t MOD_PON_CTRL_FUNCS[] = {
    { .name = "set_max_nr_of_onus", .cb = dummy_set_max_nr_of_onus },
    { .name = "change_power_mode", .cb = dummy_change_power_mode }
};

bool dummy_pon_ctrl_init(void) {

    bool rv = false;
    int rc;
    int i;
    amxm_shared_object_t* so = amxm_so_get_current();
    when_null_trace(so, exit, ERROR, "amxm_so_get_current() returns NULL");
    rc = amxm_module_register(&s_pon_ctrl_module, so, MOD_PON_CTRL);
    when_failed_trace(rc, exit, ERROR, "Failed to register %s namespace (rc=%d)", MOD_PON_CTRL, rc);

    const int n_functions = ARRAY_SIZE(MOD_PON_CTRL_FUNCS);
    for(i = 0; i < n_functions; ++i) {
        amxm_module_add_function(s_pon_ctrl_module, MOD_PON_CTRL_FUNCS[i].name, MOD_PON_CTRL_FUNCS[i].cb);
    }
    rv = true;
exit:
    return rv;
}

void dummy_pon_ctrl_cleanup(void) {
    amxm_module_deregister(&s_pon_ctrl_module);
}

