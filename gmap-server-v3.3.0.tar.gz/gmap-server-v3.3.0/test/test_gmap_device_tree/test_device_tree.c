/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include "test_device_tree.h"
#include "gmaps_devices.h"
#include "gmaps_dm_devices.h"
#include "../test_common/test_util.h"

#define KEY_HGW "hgw"
#define KEY_BRIDGE "bridge"
#define KEY_DEVICE_1 "device-1"
#define KEY_AP_ROOT "ap-root"
#define KEY_AP_IFACE1 "ap-iface1"
#define KEY_AP_IFACE2 "ap-iface2"
#define KEY_AP_DEVICE_2A "device-2a"
#define KEY_AP_DEVICE_2B "device-2b"

#define TEST_FILE_ROOT "test_files/"

/**
 * Creates the following small network of devices.
 * Dashed lines denote alternatives
 *
 * @verbatim
 * ┌─────┐     ┌────────┐     ┌──────────┐
 * │ hgw ├─────► bridge ├─────► device-1 │
 * └─────┘     └┬───┬───┘     └──────────┘
 *              │   │
 *              │  ┌▼────────┐    ┌───────────┐
 *              │  │ ap-root ├────► ap-iface1 │
 *              │  └────┬────┘    └───────────┘
 *              │       │
 *              │  ┌────▼──────┐  ┌───────────┐
 *              │  │ ap-iface2 ├──► device-2a │
 *              │  └────┬──────┘  └────┰──────┘
 *              │       │              ╻
 *              │  ┌────▼──────┐       ╻
 *              └──► device-2b ┝╺╺╺╺╺╺╺╹
 *                 └───────────┘
 * @endverbatim
 */
static void s_create_devices(void) {

    utils_mib_stats_data_t bridge_stats = {
        .BytesReceived = 25930,
        .BytesSent = 3552955,
        .CollectionInterval = 300,
        .InitialTimeStr = "2024-10-05T01:10:34.821301290Z",
        .LastUpdateStr = "2024-10-05T03:35:34.961735256Z",
        .Origin = "gmap-mod-conntrack-stats",
        .PacketsReceived = 74,
        .PacketsSent = 9935,
        .Status = "Success",
    };
    utils_mib_ip_ipv4_data_t bridge_ipv4[] = {
        {
            .Address = "192.168.1.1",
            .AddressSource = "self",
            .Reserved = 1,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_ipv6_data_t bridge_ipv6[] = {
        {
            .Address = "fe80::7690:bcff:fe87:f5a6",
            .AddressSource = "self",
            .Scope = "link",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t bridge_ip = {
        .IPAddress = "192.168.1.1",
        .IPAddressSource = "self",
        .ipv4_data = bridge_ipv4,
        .ipv6_data = bridge_ipv6,
    };

    utils_mib_stats_data_t dev1_stats = {
        .BytesReceived = 2382,
        .BytesSent = 233026,
        .CollectionInterval = 300,
        .InitialTimeStr = "2024-10-05T01:10:34.786432624Z",
        .LastUpdateStr = "2024-10-05T03:45:34.905133397Z",
        .Origin = "gmap-mod-conntrack-stats",
        .PacketsReceived = 18,
        .PacketsSent = 570,
        .Status = "Success",
    };
    utils_mib_ip_ipv4_data_t dev1_ipv4[] = {
        {
            .Address = "192.168.1.2",
            .AddressSource = "DHCP",
            .Reserved = 0,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_ipv6_data_t dev1_ipv6[] = {
        {
            .Address = "fe80::2048:1a98:5e91:33ca",
            .AddressSource = "static",
            .Scope = "link",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t dev1_ip = {
        .IPAddress = "192.168.1.1",
        .IPAddressSource = "self",
        .ipv4_data = dev1_ipv4,
        .ipv6_data = dev1_ipv6,
    };
    utils_mib_dhcp_data_t dev1_dhcp = {
        .ClientID = "8641641ZEVZEX",
        .DHCPOption55 = "1,2,6",
        .DHCPv4Client = "DAE57861EZAV",
    };

    utils_mib_stats_data_t aproot_stats = {
        .BytesReceived = 378005,
        .BytesSent = 1606372,
        .CollectionInterval = 300,
        .InitialTimeStr = "2024-10-05T03:53:39.865894610Z",
        .LastUpdateStr = "2024-10-05T03:53:39.865894610Z",
        .Origin = "gmap-mod-conntrack-stats",
        .PacketsReceived = 1790,
        .PacketsSent = 2700,
        .Status = "Success",
    };
    utils_mib_ip_ipv4_data_t aproot_ipv4[] = {
        {
            .Address = "192.168.1.254",
            .AddressSource = "Static",
            .Reserved = 0,
            .Scope = "global",
            .Status = "not reachable",
        },
        {
            .Address = "192.168.1.100",
            .AddressSource = "DHCP",
            .Reserved = 0,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_ipv6_data_t aproot_ipv6[] = {
        {
            .Address = "fe80::86a3:29ff:fe6b:e237",
            .AddressSource = "Static",
            .Scope = "link",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t aproot_ip = {
        .IPAddress = "192.168.1.100",
        .IPAddressSource = "DHCP",
        .ipv4_data = aproot_ipv4,
        .ipv6_data = aproot_ipv6,
    };
    utils_mib_dhcp_data_t aproot_dhcp = {
        .ClientID = "65016510ERZERRA",
        .DHCPOption55 = "1,2,6",
        .DHCPv4Client = "Device.DHCPv4.Server.Pool.1.Client.1.",
        .SerialNumber = "0001",
    };

    utils_mib_stats_data_t dev2b_stats = {
        .BytesReceived = 0,
        .BytesSent = 0,
        .CollectionInterval = 300,
        .InitialTimeStr = "0001-01-01T00:00:00Z",
        .LastUpdateStr = "0001-01-01T00:00:00Z",
        .Origin = "",
        .PacketsReceived = 0,
        .PacketsSent = 0,
        .Status = "Init",
    };
    utils_mib_ip_ipv4_data_t dev2b_ipv4[] = {
        {
            .Address = "192.168.4.65",
            .AddressSource = "Static",
            .Reserved = 0,
            .Scope = "global",
            .Status = "not reachable",
        },
        {
            .Address = "192.168.1.3",
            .AddressSource = "DHCP",
            .Reserved = 0,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_ipv6_data_t dev2b_ipv6[] = {
        {
            .Address = "fe80::de8d:8aff:feff:fb63",
            .AddressSource = "Static",
            .Scope = "link",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t dev2b_ip = {
        .IPAddress = "192.168.1.3",
        .IPAddressSource = "DHCP",
        .ipv4_data = dev2b_ipv4,
        .ipv6_data = dev2b_ipv6,
    };
    utils_mib_dhcp_data_t dev2b_dhcp = {
        .ClientID = "001",
        .DHCPOption55 = "1,2",
        .DHCPv4Client = "Device.DHCPv4.Server.Pool.4.Client.2.",
        .SerialNumber = "2144",
    };

    utils_init_device_data_t devices[] = {
        {
            .key = KEY_HGW,
            .tags = "testfunctiontree self physical hgw",
            .discovery_source = "test-self",
            .default_name = "HGW",
            .first_seen_str = "2024-12-09T11:52:00.201294387Z",
            .last_connection_str = "2024-12-09T11:52:00.201294387Z",
        },
        {
            .key = KEY_BRIDGE,
            .tags = "testfunctiontree self lan bridge ipv4 ipv6 stats",
            .discovery_source = "test-self",
            .default_name = "bridge-lan_bridge",
            .first_seen_str = "2024-12-09T12:18:14.808509773Z",
            .last_connection_str = "2024-12-09T12:19:19.699222930Z",
            .mib_stats = &bridge_stats,
            .mib_ip = &bridge_ip,
        },
        {
            .key = KEY_DEVICE_1,
            .tags = "testfunctiontree lan edev physical eth dhcp ipv4 ipv6 stats",
            .discovery_source = "eth-dev",
            .default_name = "device-1_Name",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
            .mib_stats = &dev1_stats,
            .mib_ip = &dev1_ip,
            .mib_dhcp = &dev1_dhcp,
        },
        {
            .key = KEY_AP_ROOT,
            .tags = "testfunctiontree lan edev mac physical eth dhcp ipv4 ipv6 stats ssw manageable",
            .discovery_source = "ssw",
            .default_name = "My AP",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
            .mib_stats = &aproot_stats,
            .mib_ip = &aproot_ip,
            .mib_dhcp = &aproot_dhcp,
        },
        {
            .key = KEY_AP_IFACE1,
            .tags = "testfunctiontree interface lan mac eth",
            .discovery_source = "ssw",
            .default_name = "My AP_LAN1",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
        },
        {
            .key = KEY_AP_IFACE2,
            .tags = "testfunctiontree interface lan mac eth",
            .discovery_source = "ssw",
            .default_name = "My AP_LAN2",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
        },
        {
            .key = KEY_AP_DEVICE_2A,
            .tags = "testfunctiontree lan edev mac physical ssw_sta useragent deviceid wifi",
            .discovery_source = "ssw",
            .default_name = "DC:8D:8A:FF:FB:66",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
        },
        {
            .key = KEY_AP_DEVICE_2B,
            .tags = "testfunctiontree lan mac physical wifi useragent deviceid ipv4 stats dhcp ipv6",
            .discovery_source = "ssw",
            .default_name = "DC:8D:8A:FF:FB:66",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
            .mib_stats = &dev2b_stats,
            .mib_ip = &dev2b_ip,
            .mib_dhcp = &dev2b_dhcp,
        },
        { 0 }
    };

    utils_link_data_t links[] = {
        {
            .upper_device = KEY_HGW,
            .lower_device = KEY_BRIDGE,
            .type = "default",
            .datasource = "test-self",
        },
        {
            .upper_device = KEY_BRIDGE,
            .lower_device = KEY_DEVICE_1,
            .type = "ethernet",
            .datasource = "mod-test",
        },
        {
            .upper_device = KEY_BRIDGE,
            .lower_device = KEY_DEVICE_1,
            .type = "ethernet",
            .datasource = "mod-other-test",
        },
        {
            .upper_device = KEY_BRIDGE,
            .lower_device = KEY_AP_ROOT,
            .type = "ethernet",
            .datasource = "mod-eth-dev",
        },
        {
            .upper_device = KEY_AP_ROOT,
            .lower_device = KEY_AP_IFACE1,
            .type = "default",
            .datasource = "mod-ssw",
        },
        {
            .upper_device = KEY_AP_ROOT,
            .lower_device = KEY_AP_IFACE2,
            .type = "default",
            .datasource = "mod-ssw",
        },
        {
            .upper_device = KEY_BRIDGE,
            .lower_device = KEY_AP_DEVICE_2A,
            .type = "default",
            .datasource = "mod-ssw",
        },
        {
            .upper_device = KEY_AP_IFACE2,
            .lower_device = KEY_AP_DEVICE_2A,
            .type = "default",
            .datasource = "mod-ssw",
        },
        {
            .upper_device = KEY_AP_IFACE2,
            .lower_device = KEY_AP_DEVICE_2B,
            .type = "default",
            .datasource = "mod-ssw",
        },
        { 0 }
    };

    amxc_var_t* data = test_read_json_file(TEST_FILE_ROOT "function_data.json");
    assert_non_null(data);

    util_device_create_all(devices);
    util_device_link_all(links);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_set_alternative(gmaps_get_device(KEY_AP_DEVICE_2A),
                                                  gmaps_get_device(KEY_AP_DEVICE_2B))
                     );

    util_call_set_function(KEY_DEVICE_1, NULL, "testfunc1", NULL);
    util_call_set_function(KEY_AP_DEVICE_2A, NULL, "testfunc2", data);
    util_call_set_function(KEY_AP_DEVICE_2B, "Stats", "testfunc3", NULL);
    util_call_set_function(KEY_DEVICE_1, "IPv4Address.1", "testfunc4", NULL);
    util_call_add_action(KEY_DEVICE_1, "testfunc1", "action_1");
    util_call_add_action(KEY_AP_DEVICE_2A, "testfunc2", "action_2");
    /* Note: functions defined on subobject cannot be set as actions. */

    amxc_var_delete(&data);
}

void test_device_tree_get_no_flags(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, 0));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_no_details(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_NO_DETAILS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-details_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_no_actions(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-actions_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-actions_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_NO_ACTIONS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-actions_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_with_topology(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_INCLUDE_TOPOLOGY));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_no-flags_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_with_alternatives(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_INCLUDE_ALTERNATIVES));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-alternatives_" KEY_AP_DEVICE_2B ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_with_links(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_INCLUDE_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-links_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}

void test_device_tree_get_with_full_links(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);
    s_create_devices();

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_HGW, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_HGW ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_BRIDGE, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_BRIDGE ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_DEVICE_1, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_DEVICE_1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_ROOT, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_AP_ROOT ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE1, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_AP_IFACE1 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_IFACE2, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_AP_IFACE2 ".json");

    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2A, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_AP_DEVICE_2A ".json");

    /* device 2a and device 2b are alternatives. By default, the data from the master device is taken. */
    amxc_var_clean(&data);
    assert_int_equal(gmap_status_ok,
                     gmaps_device_get(KEY_AP_DEVICE_2B, &data, GMAP_INCLUDE_FULL_LINKS));
    assert_variant_equal_from_file(&data, TEST_FILE_ROOT "test_with-full-links_" KEY_AP_DEVICE_2A ".json");

    amxc_var_clean(&data);
}