{%
import * as fs from 'fs';

let cpus_sysfs_path = "/sys/devices/system/cpu/";

function file_read(path) {
        let data = fs.readfile(path);
        if (data == null)
                return null;

        return trim(data);
}

function read_cpufreq_param(cpu_name, filename) {
        let freq = file_read(sprintf("%s/%s/cpufreq/%s", cpus_sysfs_path, cpu_name, filename));
        return freq;
}

%}
%populate {
    object CPUs.CPU {
{% for (let cpu_name in fs.lsdir(cpus_sysfs_path)) : -%}
{% if (match(cpu_name, regexp("^cpu[0-9]+$")) != null):%}
        instance add(Alias="cpe-{{ cpu_name }}")  {
            object DVFS {
                parameter ScalingMaxFrequency = {{ int(read_cpufreq_param(cpu_name, "scaling_max_freq") || 0) }};
                parameter ScalingMinFrequency = {{ int(read_cpufreq_param(cpu_name, "scaling_min_freq") || 0) }};
                parameter ScalingGovernor = {{ read_cpufreq_param(cpu_name, "scaling_governor") || "performance" }};
            }
        }
{% endif %}
{% endfor -%}
    }
}
