/*******************************************************************************
 *
 * Copyright (c) 2000-2003 Intel Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * - Neither name of Intel Corporation nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/
/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <tr069-connectionrequest.h>
#include <amxmisc.h>
#include <sys/socket.h>
#include <pthread.h>

/**
 * Callback function for KeepAlive thread
 */
typedef void (* refresh_func_t)(void);

/**
 * Default UPnP protocol
 */
#define UPNP_PROTOCOL "TCP"

/**
 * Default service lease time
 */
#define DEFAULT_SERVICE_LEASE_TIME "300"
/**
 * The refresh delta for KeepAlive thread
 */
#define KEEPALIVE_REFRESH_DELTA  10

/**
 * @file main.c
 * @brief The main loop and Control Point core.
 */

/**
   Timeout to request during subscriptions
 */
#define DEFAULT_SUBSCRIPTION_TIMEOUT    1800

static pthread_mutex_t gKaMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t gCpMutex = PTHREAD_MUTEX_INITIALIZER;
static bool gKaStop = false;
static int gKaReset = 0;
static bool gKaActive = false;

static bool gMonitorStop = false;

static bool gCpActive = false;

/**
   Default interface name
 */
char* interface_name = "br-lan";

void KeepaliveSet(refresh_func_t func);
/**
 * Mutex for protecting the global device in a multi-threaded,
 * asynchronous environment. All functions should lock this mutex before
 * reading or writing the device.
 */
ithread_mutex_t gDeviceListMutex;

/**
   The handle of Control Point
 */
UpnpClient_Handle gCtrlptHandle = -1;

/** Device type for device. */
const char DeviceURN[] = "urn:schemas-upnp-org:device:InternetGatewayDevice:2";

/** Service names.*/
const char* ServiceName[] = {
    "WANIPConnection",
    "WANPPPConnection",
    "WANIPv6FirewallControl"
};
/**
   Array of supported services
 */
const char* ServiceURN[] = {
    "urn:schemas-upnp-org:service:WANIPConnection:2",
    "urn:schemas-upnp-org:service:WANPPPConnection:1",
    "urn:schemas-upnp-org:service:WANIPv6FirewallControl:1"
};

/**
   Array of protocol for supported services
 */
const ip_mode_t IPVersionSupported[] = {IP_MODE_IPV4, IP_MODE_IPV4, IP_MODE_IPV6};

/**
   Listen port of agent
 */
char gListenPort[] = "50805";
/**
   Global IPv6 address
 */
char* gIp6String = NULL;
/**
   External port for portmapping
 */
unsigned short gExternalPort = 50805;
/**
   Current IP mode
 */
ip_mode_t gUserIpMode = 0;
static int gVerbose = 0;

bool KeepaliveThreadIsActive = false;
bool MonitorThreadIsActive = false;

/**
   The first node in the global device, or NULL if empty
 */
struct DeviceInfo IGD;

int app_main(int argc, char** argv);
int CtrlPointCallbackEventHandler(
    Upnp_EventType EventType, const void* Event, void* Cookie);
void AddAnyPortMapping(void);
void AddPortMapping(void);
void GetSpecificPortMappingEntry(void);
void AddPinhole(void);
void UpdatePinhole(void);
static void* KeepaliveThread(void* arg);
int UpdateUniqueID(char* uniqueid);
int UpdateConnectionRequestURL(service_t service);
void CtrlPointRemoveDevice(const char* UDN);
int CtrlPointRefresh(void);
int CtrlPointSendAction(int service,
                        const char* actionname,
                        const char** param_name,
                        char** param_val,
                        int param_count);
int CtrlPointPrintDevice(void);
int CtrlPointAddDevice(
    IXML_Document* DescDoc, const char* location, int expires);
void StateUpdate(
    char* UDN, int Service, IXML_Document* ChangedVariables, char* State);
void CtrlPointHandleEvent(
    const char* sid, int evntkey, IXML_Document* changes);
void CtrlPointHandleSubscribeUpdate(
    const char* eventURL, const Upnp_SID sid, int timeout);
int CtrlPointStop(void);
int CtrlPointStart(char* iface);
int CtrlPointPrintUDN();
void KeepaliveStop(void);
void MonitorStart(void);
void MonitorStop(void);
void ClearAction(service_t service);
void WaitingForTreadsFinishing(void);

/**
 * @brief Update UniqueID
 *
 * @param [in] uniqueid New UniqueID value
 * @return SUCCESS if everything went well, else ERROR.
 */
int UpdateUniqueID(char* uniqueid) {
    int rc = ERROR;
    if(IGD.Updated) {
        strncpy(IGD.UniqueID,
                uniqueid,
                MAX_VAL_LEN - 1);
        rc = SUCCESS;
    }
    return rc;
}

/**
 * @brief Update ConnectionRequestURL parameter in the data model
 *
 * Parameters:
 * @param [in] service  The index of services
 * @return SUCCESS if everything went well, else ERROR.
 */
int UpdateConnectionRequestURL(service_t service) {
    char* ExternalHost = NULL;
    char buf[MAX_VAL_LEN] = {0};
    int rc = ERROR;
    char ExternalPort[MAX_PORT_LEN] = {0};
    snprintf(ExternalPort, MAX_PORT_LEN, "%hu", gExternalPort);
    if(service == SERVICE_NONE) {
        ExternalHost = UpnpGetServerIpAddress();
        snprintf(ExternalPort, MAX_PORT_LEN, "%s", gListenPort);
        rc = SUCCESS;
    } else {
        if(IGD.Updated) {
            ExternalHost = IGD.ExternalIPAddress;
            if(gUserIpMode == IP_MODE_IPV6) {
                snprintf(ExternalPort, MAX_PORT_LEN, "%s", gListenPort);
                snprintf(buf, MAX_VAL_LEN, "[%s]", gIp6String);
                ExternalHost = buf;
            }
            rc = SUCCESS;
        }
    }
    if(rc == SUCCESS) {
        if(CallAmxUpdateConnectionRequestURL(ExternalHost, ExternalPort)) {
            Util_Print("UpdateConnectionRequestURL is failed\n");
        } else {
            Util_Print("UpdateConnectionRequestURL is OK {%s:%s}\n",
                       ExternalHost, ExternalPort
                       );
            rc = SUCCESS;
        }
    }
    return rc;
}

/**
 * @brief Remove IGD device.
 *
 * @param [in] UDN The Unique Device Name for the device to remove
 * @return SUCCESS if everything went well, else ERROR.
 */
void CtrlPointRemoveDevice(const char* UDN) {
    int rc, service;

    ithread_mutex_lock(&gDeviceListMutex);
    if(strncmp(IGD.UDN, UDN, MAX_VAL_LEN) == 0) {
        if(IGD.Updated) {
            service = IGD.ActiveService;
            /*
               If we have a valid control SID, then unsubscribe
             */
            if(strncmp(IGD.Service[service].SID, "", NAME_SIZE) != 0) {
                rc = UpnpUnSubscribe(gCtrlptHandle,
                                     IGD.Service[service].SID);
                if(UPNP_E_SUCCESS == rc) {
                    Util_Print("Unsubscribed from %s "
                               "EventURL with SID=%s\n",
                               ServiceName[service],
                               IGD.Service[service].SID);
                } else {
                    Util_Print("Error unsubscribing from %s "
                               "EventURL -- %d\n",
                               ServiceName[service],
                               rc);
                }
                IGD.Updated = 0;
            }
        }
    }
    ithread_mutex_unlock(&gDeviceListMutex);
}

/**
 * @brief Clear the current global device and issue new search
 *	 requests to build it up again from scratch.
 *
 * @return SUCCESS if everything went well, else ERROR.
 */
int CtrlPointRefresh(void) {
    int rc;

    IGD.Updated = 0;
    /* Search for all devices of type device version 1,
     * waiting for up to 5 seconds for the response */
    rc = UpnpSearchAsync(gCtrlptHandle, 5, DeviceURN, NULL);
    if(UPNP_E_SUCCESS != rc) {
        Util_Print("Error sending search request%d\n", rc);

        return ERROR;
    }

    return SUCCESS;
}

/**
 * @brief Send an Action request to the specified service of a device.
 *
 * @param [in] service The service
 * @param [in] actionname The name of the action.
 * @param [in] param_name An array of parameter names
 * @param [in] param_val The corresponding parameter values
 * @param [in] param_count The number of parameters
 * @return SUCCESS if everything went well, else ERROR.
 */
int CtrlPointSendAction(int service,
                        const char* actionname,
                        const char** param_name,
                        char** param_val,
                        int param_count) {
    IXML_Document* actionNode = NULL;
    int rc = SUCCESS;
    int param;

    ithread_mutex_lock(&gDeviceListMutex);

    if(IGD.Updated) {
        if(0 == param_count) {
            actionNode = UpnpMakeAction(
                actionname, ServiceURN[service], 0, NULL);
        } else {
            for(param = 0; param < param_count; param++) {
                if(UpnpAddToAction(&actionNode,
                                   actionname,
                                   ServiceURN[service],
                                   param_name[param],
                                   param_val[param]) !=
                   UPNP_E_SUCCESS) {
                    Util_Print(
                        "ERROR: CtrlPointSendAction: "
                        "Trying to add action param\n");
                }
            }
        }

        rc = UpnpSendActionAsync(gCtrlptHandle,
                                 IGD.Service[service].ControlURL,
                                 ServiceURN[service],
                                 NULL,
                                 actionNode,
                                 CtrlPointCallbackEventHandler,
                                 (void*) NULL);

        if(rc != UPNP_E_SUCCESS) {
            Util_Print(
                "Error in UpnpSendActionAsync -- %d\n", rc);
            rc = ERROR;
        }
    }

    ithread_mutex_unlock(&gDeviceListMutex);

    if(actionNode) {
        ixmlDocument_free(actionNode);
    }

    return rc;
}

/**
 * @brief Print the universal device names for the global device
 *
 * @return SUCCESS
 */
int CtrlPointPrintUDN() {
    ithread_mutex_lock(&gDeviceListMutex);

    if(IGD.Updated) {
        Util_Print("CtrlPointPrintUDN:\n");
        Util_Print(" -- %s\n", IGD.UDN);
        Util_Print("\n");
    }
    ithread_mutex_unlock(&gDeviceListMutex);

    return SUCCESS;
}

/**
 * @brief Print the identifiers and state table for the global device
 *
 * @return SUCCESS
 */
int CtrlPointPrintDevice(void) {
    int service;
    char spacer[15];

    if(!IGD.Updated) {
        return SUCCESS;
    }
    ithread_mutex_lock(&gDeviceListMutex);

    Util_Print("CtrlPointPrintDevice:\n");

    Util_Print("  Device \n"
               "    |                  \n"
               "    +- UDN        = %s\n",
               IGD.UDN);
    service = IGD.ActiveService;
    if(service < SERVICE_COUNT - 1) {
        sprintf(spacer, "    |    ");
    } else {
        sprintf(spacer, "         ");
    }
    Util_Print("    |                  \n"
               "    +- %s Service\n"
               "%s+- ID       = %s\n"
               "%s+- Type     = %s\n"
               "%s+- EventURL        = %s\n"
               "%s+- ControlURL      = %s\n"
               "%s+- SID             = %s\n"
               "%s+- ServiceStateTable\n",
               ServiceName[service],
               spacer,
               IGD.Service[service].ID,
               spacer,
               IGD.Service[service].Type,
               spacer,
               IGD.Service[service].EventURL,
               spacer,
               IGD.Service[service].ControlURL,
               spacer,
               IGD.Service[service].SID,
               spacer);
    {
        Util_Print("%s     +- %-10s = %s\n",
                   spacer,
                   "ExternalIPAddress",
                   IGD.ExternalIPAddress);
    }

    Util_Print("\n");
    ithread_mutex_unlock(&gDeviceListMutex);

    return SUCCESS;
}

/**
 * @brief If the device have not been connected yet,
 *       add it.  Otherwise, parse device information and
 *       update its advertisement expiration timeout.
 *
 * @param [in] DescDoc The description document for the device
 * @param [in] location The location of the description document URL
 * @param [in] expires The expiration time for this advertisement
 * @return
 */
int CtrlPointAddDevice(
    IXML_Document* DescDoc, const char* location, int expires) {
    char* deviceType = NULL;
    char* UDN = NULL;
    char* serviceId = NULL;
    char* eventURL = NULL;
    char* controlURL = NULL;
    Upnp_SID eventSID;
    int TimeOut = DEFAULT_SUBSCRIPTION_TIMEOUT;
    int ret = 1;
    int found = 0;
    int service;
    (void) expires;

    ithread_mutex_lock(&gDeviceListMutex);

    /* Read key elements from description document */
    UDN = Util_GetFirstDocumentItem(DescDoc, "UDN");
    deviceType = Util_GetFirstDocumentItem(DescDoc, "deviceType");

    if(strcmp(deviceType, DeviceURN) == 0) {

        /* Check if this device is already updated */
        if(IGD.Updated) {
            if(strncmp(IGD.UDN, UDN, MAX_VAL_LEN) == 0) {
                found = 1;
            }
        }

        if(found) {
            /* The device is already there, so just update  */
        } else {
            for(service = 0; service < SERVICE_COUNT;
                service++) {
                if((gUserIpMode == IPVersionSupported[service]) &&
                   Util_FindAndParseService(DescDoc,
                                            location,
                                            ServiceURN[service],
                                            &serviceId,
                                            &eventURL,
                                            &controlURL)) {
                    Util_Print("Subscribing to "
                               "EventURL %s...\n",
                               eventURL);
                    ret = UpnpSubscribe(gCtrlptHandle,
                                        eventURL,
                                        &TimeOut,
                                        eventSID);
                    if(ret == UPNP_E_SUCCESS) {
                        Util_Print(
                            "Subscribed to "
                            "EventURL with "
                            "SID=%s\n",
                            eventSID);
                        IGD.ActiveService = service;
                    } else {
                        Util_Print(
                            "Error Subscribing to "
                            "EventURL -- %d\n",
                            ret);
                        strncpy(eventSID, "", 1);
                    }
                }
            }
            /* Fill data to new device */
            strncpy(IGD.UDN, UDN, MAX_VAL_LEN - 1);
            service = IGD.ActiveService;
            strncpy(IGD.Service[service].ID,
                    serviceId,
                    MAX_VAL_LEN - 1);
            strncpy(IGD.Service[service].Type,
                    ServiceURN[service],
                    MAX_VAL_LEN - 1);
            strncpy(IGD.Service[service].ControlURL,
                    controlURL,
                    MAX_VAL_LEN - 1);
            strncpy(IGD.Service[service].EventURL,
                    eventURL,
                    MAX_VAL_LEN - 1);
            strncpy(IGD.Service[service].SID,
                    eventSID,
                    MAX_VAL_LEN - 1);
            memset(IGD.ExternalIPAddress, 0, MAX_VAL_LEN);
            memset(IGD.UniqueID, 0, MAX_VAL_LEN);
            IGD.Updated = 1;
        }
    }

    ithread_mutex_unlock(&gDeviceListMutex);

    if(deviceType) {
        free(deviceType);
    }
    if(UDN) {
        free(UDN);
    }
    if(serviceId) {
        free(serviceId);
    }
    if(controlURL) {
        free(controlURL);
    }
    if(eventURL) {
        free(eventURL);
    }

    return found;
}

/**
 * @brief Get ExternalIPAdress value from XML update
 *
 * @param [in] UDN The Unique Device Name
 * @param [in] Service The index of services
 * @param [in] ChangedVariables The Dom document with answer request
 * @param [out] State The output string
 */
void StateUpdate(
    char* UDN, int Service, IXML_Document* ChangedVariables, char* State) {
    IXML_NodeList* properties;
    IXML_NodeList* variables;
    IXML_Element* property;
    IXML_Element* variable;
    long unsigned int length;
    long unsigned int length1;
    long unsigned int i;
    char* tmpstate = NULL;
    (void) UDN;

    Util_Print("State Update (service %d):\n", Service);
    /* Find all of the e:property tags in the document */
    properties = ixmlDocument_getElementsByTagName(
        ChangedVariables, "e:property");
    if(properties) {
        length = ixmlNodeList_length(properties);
        for(i = 0; i < length; i++) {
            /* Loop through each property change found */
            property = (IXML_Element*) ixmlNodeList_item(
                properties, i);
            {
                variables = ixmlElement_getElementsByTagName(
                    property, "ExternalIPAddress");
                /* If a match is found, extract
                 * the value, and update the state table */
                if(variables) {
                    length1 =
                        ixmlNodeList_length(variables);
                    if(length1) {
                        variable = (IXML_Element*)
                            ixmlNodeList_item(
                            variables, 0);
                        tmpstate =
                            Util_GetElementValue(
                                variable);
                        if(tmpstate) {
                            strncpy(State,
                                    tmpstate,
                                    MAX_VAL_LEN - 1);
                            Util_Print(
                                " Variable "
                                "Name: %s New "
                                "Value:'%s'\n",
                                "ExternalIPAddress",
                                tmpstate);
                        }
                        if(tmpstate) {
                            free(tmpstate);
                        }
                        tmpstate = NULL;
                    }
                    ixmlNodeList_free(variables);
                    variables = NULL;
                }
            }
        }
        ixmlNodeList_free(properties);
    }
    return;
}

/**
 * @brief Handle a UPnP event that was received.  Process the event and update
 *        the appropriate service state table.
 *
 * @param [in] sid The subscription id for the event
 * @param [in] evntkey The eventkey number for the event
 * @param [in] changes The DOM document representing the changes
 */
void CtrlPointHandleEvent(
    const char* sid, int evntkey, IXML_Document* changes) {
    int service;
    bool active;
    const refresh_func_t funcs[SERVICE_COUNT] = {
        AddAnyPortMapping,
        GetSpecificPortMappingEntry,
        AddPinhole
    };

    ithread_mutex_lock(&gDeviceListMutex);

    if(IGD.Updated) {
        service = IGD.ActiveService;
        if(strncmp(IGD.Service[service].SID,
                   sid,
                   NAME_SIZE) == 0) {
            Util_Print(
                "Received %s Event: %d for SID %s\n",
                ServiceName[service],
                evntkey,
                sid);
            StateUpdate(IGD.UDN,
                        service,
                        changes,
                        IGD.ExternalIPAddress);
            IGD.ActiveService = service;
            ithread_mutex_unlock(&gDeviceListMutex);
            ithread_mutex_lock(&gCpMutex);
            active = gCpActive;
            ithread_mutex_unlock(&gCpMutex);
            if(active) {
                funcs[service]();
                if(service == SERVICE_WANIPCONNECTION) {
                    KeepaliveSet(AddAnyPortMapping);
                }
            }
            ithread_mutex_lock(&gDeviceListMutex);
        }
    }

    ithread_mutex_unlock(&gDeviceListMutex);
}

/**
 * @brief Handle a UPnP subscription update that was received.  Find the
 *       service the update belongs to, and update its subscription
 *       timeout.
 *
 * @param [in] eventURL The event URL for the subscription
 * @param [in] sid The subscription id for the subscription
 * @param [in] timeout The new timeout for the subscription
 */
void CtrlPointHandleSubscribeUpdate(
    const char* eventURL, const Upnp_SID sid, int timeout) {
    int service;
    (void) timeout;

    ithread_mutex_lock(&gDeviceListMutex);

    if(IGD.Updated) {
        service = IGD.ActiveService;
        if(strncmp(IGD.Service[service]
                   .EventURL,
                   eventURL,
                   NAME_SIZE) == 0) {
            Util_Print("Received %s Event Renewal "
                       "for eventURL %s\n",
                       ServiceName[service],
                       eventURL);
            strncpy(IGD.Service[service]
                    .SID,
                    sid,
                    NAME_SIZE - 1);
        }
    }

    ithread_mutex_unlock(&gDeviceListMutex);

    return;
}

/**
 * @brief The callback handler registered with the SDK while registering
 *       the control point.  Detects the type of callback, and passes the
 *       request on to the appropriate function.
 *
 * @param [in] EventType The type of callback event
 * @param [in] Event Data structure containing event data
 * @param [in] Cookie Optional data specified during callback registration
 */
int CtrlPointCallbackEventHandler(
    Upnp_EventType EventType, const void* Event, void* Cookie) {
    int errCode = 0;
    (void) Cookie;

    if(gVerbose) {
        Util_PrintEvent(EventType, Event);
    }
    switch(EventType) {
    /* SSDP Stuff */
    case UPNP_DISCOVERY_ADVERTISEMENT_ALIVE:
    case UPNP_DISCOVERY_SEARCH_RESULT: {
        const UpnpDiscovery* d_event = (UpnpDiscovery*) Event;
        IXML_Document* DescDoc = NULL;
        const char* location = NULL;
        const struct sockaddr_storage* destAddr = NULL;
        int errCode = UpnpDiscovery_get_ErrCode(d_event);

        if(errCode != UPNP_E_SUCCESS) {
            Util_Print(
                "Error in Discovery Callback -- %d\n", errCode);
            break;
        }

        /* If BootID is changed on IGD
         * we need to do re-registration
         * (CtrlPointRemoveDevice/CtrlPointAddDevice) */
        ithread_mutex_lock(&gDeviceListMutex);
        if(strlen(IGD.BootID) && (strcmp(IGD.BootID, UpnpString_get_String(
                                             UpnpDiscovery_get_BootID(d_event))) != 0)) {
            const char* deviceid = UpnpDiscovery_get_DeviceID_cstr(d_event);
            Util_Print("Remove '%s'\n", deviceid);
            ithread_mutex_unlock(&gDeviceListMutex);
            CtrlPointRemoveDevice(deviceid);
            ithread_mutex_lock(&gDeviceListMutex);
            UpdateConnectionRequestURL(SERVICE_NONE);
        }
        ithread_mutex_unlock(&gDeviceListMutex);

        if(UpnpDiscovery_get_ServiceType_cstr(d_event)) {
            const char* servicetype = UpnpDiscovery_get_ServiceType_cstr(d_event);
            int service;
            int isfound = 0;
            for(service = 0; service < SERVICE_COUNT; service++) {
                if((gUserIpMode == IPVersionSupported[service]) &&
                   !strcmp(servicetype, ServiceURN[service])) {
                    isfound = 1;
                    break;
                }
            }
            if(!isfound) {
                break;
            }
        }

        location = UpnpDiscovery_get_Location_cstr(d_event);
        destAddr = UpnpDiscovery_get_DestAddr(d_event);
        if(destAddr) {
            char* ServerIP = NULL;
            if(gUserIpMode == IP_MODE_IPV6) {
                if(destAddr->ss_family != (sa_family_t) AF_INET6) {
                    break;
                }
                ServerIP = GetAmxAgentServerAddressIp6();
            } else {
                if(destAddr->ss_family != (sa_family_t) AF_INET) {
                    break;
                }
                ServerIP = GetAmxAgentServerAddressIp4();
            }
            if(ServerIP && !strstr(location, ServerIP)) {
                break;
            }
        }

        errCode = UpnpDownloadXmlDoc(location, &DescDoc);
        if(errCode != UPNP_E_SUCCESS) {
            Util_Print("Error obtaining device description "
                       "from %s -- error = %d\n",
                       location,
                       errCode);
        } else {
            if(0 == CtrlPointAddDevice(DescDoc,
                                       location,
                                       UpnpDiscovery_get_Expires(d_event))) {
                ithread_mutex_lock(&gDeviceListMutex);
                if(IGD.Updated) {
                    strncpy(IGD.BootID,
                            UpnpDiscovery_get_BootID_cstr(d_event),
                            MAX_VAL_LEN - 1);
                    Util_Print("Detect BootID '%s' (%ld)\n", IGD.BootID,
                               UpnpDiscovery_get_BootID_Length(d_event));
                }
                ithread_mutex_unlock(&gDeviceListMutex);
                CtrlPointPrintUDN();
            }
        }
        if(DescDoc) {
            ixmlDocument_free(DescDoc);
        }
        break;
    }
    case UPNP_DISCOVERY_ADVERTISEMENT_BYEBYE: {
        UpnpDiscovery* d_event = (UpnpDiscovery*) Event;
        int errCode = UpnpDiscovery_get_ErrCode(d_event);
        const char* deviceId = UpnpString_get_String(
            UpnpDiscovery_get_DeviceID(d_event));

        if(errCode != UPNP_E_SUCCESS) {
            Util_Print(
                "Error in Discovery ByeBye Callback -- %d\n",
                errCode);
        }
        Util_Print("Received ByeBye for Device: %s\n", deviceId);
        CtrlPointRemoveDevice(deviceId);
        Util_Print("After byebye:\n");
        CtrlPointPrintUDN();
        break;
    }
    /* SOAP Stuff */
    case UPNP_CONTROL_ACTION_COMPLETE: {
        bool active;
        UpnpActionComplete* a_event = (UpnpActionComplete*) Event;
        int errCode = UpnpActionComplete_get_ErrCode(a_event);
        int service = IGD.ActiveService;
        ithread_mutex_lock(&gCpMutex);
        active = gCpActive;
        ithread_mutex_unlock(&gCpMutex);
        if(!active) {
            break;
        }
        if(errCode != UPNP_E_SUCCESS) {
            if(errCode == 714) {
                if(SERVICE_WANPPPCONNECTION == service) {
                    AddPortMapping();
                    KeepaliveSet(AddPortMapping);
                }
            } else {
                Util_Print(
                    "Error in  Action Complete Callback -- %d\n",
                    errCode);
            }
        } else {
            IXML_Document* actionResult =
                UpnpActionComplete_get_ActionResult(a_event);
            if(actionResult && (service >= 0) && (service < SERVICE_COUNT)) {
                if(SERVICE_WANIPCONNECTION == service) {
                    IXML_NodeList* NewReservedPort =
                        ixmlDocument_getElementsByTagName(actionResult,
                                                          "NewReservedPort");
                    if(NewReservedPort) {
                        IXML_Element* port =
                            (IXML_Element*) ixmlNodeList_item(NewReservedPort, 0);
                        char* localExternalPort = Util_GetElementValue(port);
                        if(localExternalPort) {
                            gExternalPort = atoi(localExternalPort);
                            UpdateConnectionRequestURL(service);
                            free(localExternalPort);
                        }
                        ixmlNodeList_free(NewReservedPort);
                    }
                }
                if(SERVICE_WANPPPCONNECTION == service) {
                    IXML_NodeList* NewInternalClient =
                        ixmlDocument_getElementsByTagName(actionResult,
                                                          "NewInternalClient");
                    if(NewInternalClient) {
                        IXML_Element* client =
                            (IXML_Element*) ixmlNodeList_item(NewInternalClient, 0);
                        char* localclient = Util_GetElementValue(client);
                        if(localclient) {
                            if(strcmp(localclient,
                                      (char*) UpnpGetServerIpAddress()) == 0) {
                                IXML_NodeList* NewInternalPort =
                                    ixmlDocument_getElementsByTagName(actionResult,
                                                                      "NewInternalPort");
                                if(NewInternalPort) {
                                    IXML_Element* port =
                                        (IXML_Element*) ixmlNodeList_item(
                                            NewInternalPort, 0);
                                    char* localNewInternalPort =
                                        Util_GetElementValue(port);
                                    if(localNewInternalPort) {
                                        if(atoi(localNewInternalPort) ==
                                           gExternalPort) {
                                            UpdateConnectionRequestURL(service);
                                            AddPortMapping();
                                            KeepaliveSet(AddPortMapping);
                                        } else {
                                            gExternalPort++;
                                            if(gExternalPort == 65535) {
                                                gExternalPort = 1024;
                                            }
                                            GetSpecificPortMappingEntry();
                                        }
                                        free(localNewInternalPort);
                                    }
                                    ixmlNodeList_free(NewInternalPort);
                                }
                            } else {
                                gExternalPort++;
                                if(gExternalPort == 65535) {
                                    gExternalPort = 1024;
                                }
                                GetSpecificPortMappingEntry();
                            }
                            free(localclient);
                        }
                        ixmlNodeList_free(NewInternalClient);
                    }
                }
                if(SERVICE_WANIPV6FIREWALLCONTROL == service) {
                    IXML_NodeList* UniqueID =
                        ixmlDocument_getElementsByTagName(actionResult, "UniqueID");
                    if(UniqueID) {
                        IXML_Element* id =
                            (IXML_Element*) ixmlNodeList_item(UniqueID, 0);
                        char* localExternalID = Util_GetElementValue(id);
                        if(localExternalID) {
                            UpdateConnectionRequestURL(service);
                            UpdateUniqueID(localExternalID);
                            UpdatePinhole();
                            KeepaliveSet(UpdatePinhole);
                            free(localExternalID);
                        }
                        ixmlNodeList_free(UniqueID);
                    }
                }
            }
        }
        break;
    }
    /* GENA Stuff */
    case UPNP_EVENT_RECEIVED: {
        UpnpEvent* e_event = (UpnpEvent*) Event;
        CtrlPointHandleEvent(UpnpEvent_get_SID_cstr(e_event),
                             UpnpEvent_get_EventKey(e_event),
                             UpnpEvent_get_ChangedVariables(e_event));
        break;
    }
    case UPNP_EVENT_SUBSCRIBE_COMPLETE:
    case UPNP_EVENT_UNSUBSCRIBE_COMPLETE:
    case UPNP_EVENT_RENEWAL_COMPLETE: {
        UpnpEventSubscribe* es_event = (UpnpEventSubscribe*) Event;

        errCode = UpnpEventSubscribe_get_ErrCode(es_event);
        if(errCode != UPNP_E_SUCCESS) {
            Util_Print(
                "Error in Event Subscribe Callback -- %d\n",
                errCode);
        } else {
            CtrlPointHandleSubscribeUpdate(
                UpnpString_get_String(
                    UpnpEventSubscribe_get_PublisherUrl(
                        es_event)),
                UpnpString_get_String(
                    UpnpEventSubscribe_get_SID(es_event)),
                UpnpEventSubscribe_get_TimeOut(es_event));
        }
        break;
    }
    case UPNP_EVENT_AUTORENEWAL_FAILED:
    case UPNP_EVENT_SUBSCRIPTION_EXPIRED: {
        UpnpEventSubscribe* es_event = (UpnpEventSubscribe*) Event;
        int TimeOut = DEFAULT_SUBSCRIPTION_TIMEOUT;
        Upnp_SID newSID;

        errCode = UpnpSubscribe(gCtrlptHandle,
                                UpnpString_get_String(
                                    UpnpEventSubscribe_get_PublisherUrl(es_event)),
                                &TimeOut,
                                newSID);
        if(errCode == UPNP_E_SUCCESS) {
            Util_Print(
                "Subscribed to EventURL with SID=%s\n", newSID);
            CtrlPointHandleSubscribeUpdate(
                UpnpString_get_String(
                    UpnpEventSubscribe_get_PublisherUrl(
                        es_event)),
                newSID,
                TimeOut);
        } else {
            Util_Print(
                "Error Subscribing to EventURL -- %d\n",
                errCode);
        }
        break;
    }
    /* ignore these cases, since this is not a device */
    case UPNP_EVENT_SUBSCRIPTION_REQUEST:
    case UPNP_CONTROL_GET_VAR_REQUEST:
    case UPNP_CONTROL_ACTION_REQUEST:
    case UPNP_CONTROL_GET_VAR_COMPLETE:
    case UPNP_DISCOVERY_SEARCH_TIMEOUT:
        break;
    }

    return 0;
}

/**
 * @brief Call this function to initialize the UPnP library and start the
 *        Control Point. This function provides a
 *        callback handler to process any UPnP events that are received.
 *
 * @param [in] iface The name of interface
 * @return SUCCESS if everything went well, else ERROR.
 */
int CtrlPointStart(char* iface) {
    int rc;
    unsigned short port = 0;

    ithread_mutex_init(&gDeviceListMutex, 0);

    memset(&IGD, 0, sizeof(struct DeviceInfo));

    Util_Print("Initializing UPnP Sdk with\n"
               "\tinterface = %s port = %u\n",
               iface ? iface : "{NULL}",
               port);

    rc = UpnpInit2(iface, port);
    if(rc != UPNP_E_SUCCESS) {
        Util_Print("UpnpInit2() Error: %d\n", rc);
        UpnpFinish();
        return ERROR;
    }

    Util_Print("UPnP Initialized\n"
               "\tipv4 address = %s port = %u\n"
               "\tipv6 address = %s port = %u\n"
               "\tipv6ulagua address = %s port = %u\n",
               UpnpGetServerIpAddress(), UpnpGetServerPort(),
               UpnpGetServerIp6Address(), UpnpGetServerPort6(),
               UpnpGetServerUlaGuaIp6Address(), UpnpGetServerUlaGuaPort6());
    if(gUserIpMode == IP_MODE_IPV6) {
        gIp6String = UpnpGetServerUlaGuaIp6Address();
    }

    CreateUpnpFirewallRules(
        UpnpGetServerPort(),
        UpnpGetServerPort(),
        UpnpGetServerUlaGuaPort6(),
        gUserIpMode);

    Util_Print("Registering Control Point\n");
    rc = UpnpRegisterClient(CtrlPointCallbackEventHandler,
                            &gCtrlptHandle,
                            &gCtrlptHandle);
    if(rc != UPNP_E_SUCCESS) {
        Util_Print("Error registering CP: %d\n", rc);
        UpnpFinish();

        return ERROR;
    }

    Util_Print("Control Point Registered\n");

    CtrlPointRefresh();

    return SUCCESS;
}

/**
 * @brief Call this function to uninitialize the UPnP library and stop the
 *        Control Point.
 *
 * @return SUCCESS
 */
int CtrlPointStop(void) {
    UpnpUnRegisterClient(gCtrlptHandle);
    UpnpFinish();
    DeleteUpnpFirewallRule(gUserIpMode);

    return SUCCESS;
}

/**
 * @brief Prepare and send AddAnyPortMapping action
 */
void AddAnyPortMapping(void) {
    const char* names[6] = {
        "NewRemoteHost",
        "NewExternalPort",
        "NewProtocol",
        "NewInternalPort",
        "NewInternalClient",
        "NewLeaseDuration"
    };

    char* values[6];
    char ExternalPort[MAX_PORT_LEN] = {0};
    char* acs_ip = GetAmxAgentAcsIp();
    snprintf(ExternalPort, MAX_PORT_LEN, "%hu", gExternalPort);
    int ret = UPNP_E_SUCCESS;
    Util_Print("Send AddAnyPortMapping action\n");
    values[0] = acs_ip;
    values[1] = ExternalPort;
    values[2] = UPNP_PROTOCOL;
    values[3] = gListenPort;
    values[4] = GetAmxAgentIp4();
    values[5] = DEFAULT_SERVICE_LEASE_TIME;

    ret = CtrlPointSendAction(SERVICE_WANIPCONNECTION, "AddAnyPortMapping", names, values, 6);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute AddAnyPortMapping %d\n", ret);
    }
}

/**
 * @brief Prepare and send AddPortMapping action
 */
void AddPortMapping(void) {
    const char* names[6] = {
        "NewRemoteHost",
        "NewExternalPort",
        "NewProtocol",
        "NewInternalPort",
        "NewInternalClient",
        "NewLeaseDuration"
    };

    char* values[6];
    char* acs_ip = GetAmxAgentAcsIp();
    char ExternalPort[MAX_PORT_LEN] = {0};
    snprintf(ExternalPort, MAX_PORT_LEN, "%hu", gExternalPort);
    int ret = UPNP_E_SUCCESS;
    Util_Print("Send AddPortMapping action\n");
    values[0] = acs_ip;
    values[1] = ExternalPort;
    values[2] = UPNP_PROTOCOL;
    values[3] = gListenPort;
    values[4] = GetAmxAgentIp4();
    values[5] = DEFAULT_SERVICE_LEASE_TIME;

    ret = CtrlPointSendAction(SERVICE_WANPPPCONNECTION, "AddPortMapping", names, values, 6);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute AddPortMapping %d\n", ret);
    }
}

/**
 * @brief Prepare and send GetSpecificPortMappingEntry action
 */
void GetSpecificPortMappingEntry(void) {
    const char* names[3] = {
        "NewRemoteHost",
        "NewExternalPort",
        "NewProtocol"
    };

    char* values[3];
    char* acs_ip = GetAmxAgentAcsIp();
    char ExternalPort[MAX_PORT_LEN] = {0};
    snprintf(ExternalPort, MAX_PORT_LEN, "%hu", gExternalPort);
    int ret = UPNP_E_SUCCESS;
    Util_Print("Send GetSpecificPortMappingEntry action\n");
    values[0] = acs_ip;
    values[1] = ExternalPort;
    values[2] = UPNP_PROTOCOL;

    ret = CtrlPointSendAction(SERVICE_WANPPPCONNECTION, "GetSpecificPortMappingEntry", names,
                              values, 3);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute GetSpecificPortMappingEntry %d\n", ret);
    }
}

/**
 * @brief Prepare and send AddPinhole action
 */
void AddPinhole(void) {
    const char* names[6] = {
        "RemoteHost",
        "Protocol",
        "InternalPort",
        "InternalClient",
        "LeaseTime",
        "RemotePort"
    };

    char* values[6];
    char* acs_ip = GetAmxAgentAcsIp();
    int ret = UPNP_E_SUCCESS;
    Util_Print("Send AddPinhole action\n");
    values[0] = acs_ip;
    values[1] = "6";
    values[2] = gListenPort;
    values[3] = gIp6String;
    values[4] = DEFAULT_SERVICE_LEASE_TIME;
    values[5] = "0";

    ret = CtrlPointSendAction(SERVICE_WANIPV6FIREWALLCONTROL, "AddPinhole", names, values, 6);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute AddPinhole %d\n", ret);
    }
}

/**
 * @brief Prepare and send UpdatePinhole action
 */
void UpdatePinhole(void) {
    const char* names[2] = {
        "UniqueID",
        "NewLeaseTime"
    };

    char* values[2];
    int ret = UPNP_E_SUCCESS;
    Util_Print("Send UpdatePinhole action\n");
    values[0] = IGD.UniqueID;
    values[1] = DEFAULT_SERVICE_LEASE_TIME;

    ret = CtrlPointSendAction(SERVICE_WANIPV6FIREWALLCONTROL, "UpdatePinhole", names, values, 2);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute UpdatePinhole %d\n", ret);
    }
}

/**
 * @brief Clear action
 */
void ClearAction(service_t service) {
    const char* names[SERVICE_COUNT][3] = {
        {"NewStartPort", "NewEndPort", "NewProtocol"},
        {"NewStartPort", "NewEndPort", "NewProtocol"},
        {"UniqueID", "", ""}
    };
    char* values[3];
    char* action = NULL;
    int param_count = 0;
    int ret = UPNP_E_SUCCESS;
    char ExternalPort[MAX_PORT_LEN] = {0};
    switch(service) {
    case SERVICE_WANIPCONNECTION:
    case SERVICE_WANPPPCONNECTION:
        action = "DeletePortMappingRange";
        snprintf(ExternalPort, MAX_PORT_LEN, "%hu", gExternalPort);
        values[0] = ExternalPort;
        values[1] = ExternalPort;
        values[2] = UPNP_PROTOCOL;
        param_count = 3;
        break;
    case SERVICE_WANIPV6FIREWALLCONTROL:
        action = "DeletePinhole";
        values[0] = IGD.UniqueID;
        param_count = 1;
        break;
    case SERVICE_NONE:
        return;
    }
    Util_Print("Send %s action\n", action);

    ret = CtrlPointSendAction(service, action, names[service], values, param_count);
    if(ret != UPNP_E_SUCCESS) {
        Util_Print("Error execute %d %s\n", ret, action);
    }
}

/**
 * @brief Calculate timeout from lease time
 * @return timeout in sec
 */
static int KaSleepSec(void) {
    int sec = atoi(DEFAULT_SERVICE_LEASE_TIME) - KEEPALIVE_REFRESH_DELTA;
    return (sec < 1) ? 1 : sec;
}

/**
 * @brief Keepalive thread to run active actions periodically
 */
static void* KeepaliveThread(void* arg) {
    refresh_func_t func = *(refresh_func_t*) arg;
    pthread_mutex_lock(&gKaMutex);
    gKaActive = true;

    Util_Print("[Keepalive] Thread started\n");

    while(!gKaStop) {
        int target = KaSleepSec();
        int counter = 0;
        gKaReset = 0;
        KeepaliveThreadIsActive = true;
        Util_Print("[Keepalive] Started, interval=%d sec\n", target);

        while(!gKaStop && counter < target) {
            pthread_mutex_unlock(&gKaMutex);
            sleep(1);
            pthread_mutex_lock(&gKaMutex);
            if(gKaReset) {
                gKaReset = 0;
                target = KaSleepSec();
                counter = 0;
                Util_Print("[Keepalive] Timer reset\n");
            } else {
                counter++;
            }
        }

        if(gKaStop) {
            break;
        }

        pthread_mutex_unlock(&gKaMutex);
        Util_Print("[Keepalive] Executing keepalive function\n");
        func();
        pthread_mutex_lock(&gKaMutex);
    }

    gKaActive = false;
    pthread_mutex_unlock(&gKaMutex);
    Util_Print("[Keepalive] Thread stopped\n");
    KeepaliveThreadIsActive = false;
    return NULL;
}

/**
 * @brief Set keepalive callback function and start thread
 *
 * @param [in] func The callback function
 */
void KeepaliveSet(refresh_func_t func) {
    static pthread_t ka_tid;
    static refresh_func_t ka_func = NULL;
    static bool ka_thread_started = false;

    if(func == NULL) {
        ka_func = NULL;
        ka_thread_started = false;
        return;
    } else if(ka_func && (ka_func != func)) {
        KeepaliveStop();
        return;
    }

    pthread_mutex_lock(&gKaMutex);

    ka_func = func;
    gKaReset = 1;
    Util_Print("[Keepalive] Reset\n");

    if(!ka_thread_started) {
        gKaStop = false;
        if(pthread_create(&ka_tid, NULL, KeepaliveThread, &ka_func) == 0) {
            pthread_detach(ka_tid);
            ka_thread_started = true;
            Util_Print("[Keepalive] Background thread created\n");
        } else {
            Util_Print("[Keepalive] ERROR: Failed to create thread\n");
        }
    }
    pthread_mutex_unlock(&gKaMutex);
}

/**
 * @brief Stop keepalive thread
 */
void KeepaliveStop(void) {
    KeepaliveSet(NULL);
    pthread_mutex_lock(&gKaMutex);
    gKaStop = true;
    Util_Print("[Keepalive] Stop requested\n");
    Util_Print("[Keepalive] Waiting to stop thread \n");
    while(gKaActive) {
        pthread_mutex_unlock(&gKaMutex);
        sleep(1);
        pthread_mutex_lock(&gKaMutex);
    }
    Util_Print("[Keepalive] The thread was stopped \n");
    pthread_mutex_unlock(&gKaMutex);
}

/**
 * @brief Monitor thread to detect changing of ACSIP and ConnRequestPort
 */
static void* MonitorThread(void* arg) {
    (void) arg;
    static char acs_ip[INET6_ADDRSTRLEN] = {0};
    char* p_acs_ip = NULL;
    int rc;
    static unsigned short agent_port = 0;
    CPState_t state = CP_STOPPED;
    CPState_t last_state = CP_STOPPED;
    Util_Print("[Monitor] Started\n");
    while(!gMonitorStop) {
        MonitorThreadIsActive = true;
        p_acs_ip = GetAmxAgentAcsIp();
        if(p_acs_ip) {
            last_state = state;
            switch(state) {
            case CP_STOPPED: {
                if(GetAmxAgentAcsStatsSessions()) {
                    strncpy(acs_ip, p_acs_ip, INET6_ADDRSTRLEN);
                    agent_port = GetAmxAgentPort();
                    if(agent_port) {
                        snprintf(gListenPort, sizeof(gListenPort), "%hu", agent_port);
                    }
                    if(strchr(acs_ip, ':')) {
                        gUserIpMode = IP_MODE_IPV6;
                    } else if(strchr(acs_ip, '.')) {
                        gUserIpMode = IP_MODE_IPV4;
                    }
                    Util_Print("Work mode IPv%d\n", gUserIpMode == IP_MODE_IPV6 ? 6 : 4);
                    rc = CtrlPointStart(interface_name);
                    if(rc != SUCCESS) {
                        Util_Print("Error starting control point\n");
                    } else {
                        state = CP_RUNNING;
                        Util_Print("Init done, starting control point\n");
                        ithread_mutex_lock(&gCpMutex);
                        gCpActive = true;
                        ithread_mutex_unlock(&gCpMutex);
                    }
                }
            }
            break;
            case CP_RUNNING: {
                if((strlen(acs_ip) &&
                    (strncmp(acs_ip, p_acs_ip, INET6_ADDRSTRLEN) != 0)) ||
                   (agent_port != GetAmxAgentPort())
                   ) {
                    state = CP_SHOULD_STOP;
                }
            }
            break;
            case CP_SHOULD_STOP: {
                memset(acs_ip, 0, INET6_ADDRSTRLEN);
                Util_Print("Detected ACSIP change\n");
                ithread_mutex_lock(&gCpMutex);
                gCpActive = false;
                ithread_mutex_unlock(&gCpMutex);
                ClearAction(IGD.ActiveService);
                KeepaliveStop();
                rc = CtrlPointStop();
                if(rc != SUCCESS) {
                    Util_Print("Error stopping control point\n");
                }
                Util_Print("Control point stopped\n");
                state = CP_STOPPED;
                agent_port = 0;
            }
            break;
            }
        }

        if(last_state == state) {
            sleep(5);
        }
    }
    Util_Print("[Monitor] Stopped\n");
    MonitorThreadIsActive = false;
    return NULL;
}

/**
 * @brief Start monitor thread
 */
void MonitorStart(void) {
    pthread_t m_tid;
    gMonitorStop = false;
    Util_Print("[Monitor] Starting\n");
    if(pthread_create(&m_tid, NULL, MonitorThread, NULL) == 0) {
        pthread_detach(m_tid);
        Util_Print("[Monitor] Background thread created\n");
    } else {
        Util_Print("[Monitor] ERROR: Failed to create thread\n");
    }
}

/**
 * @brief Waiting for threads finishing before app exit
 */
void WaitingForThreadsFinishing(void) {
    while(MonitorThreadIsActive || KeepaliveThreadIsActive) {
        sleep(1);
    }
}

/**
 * @brief Stop monitor thread
 */
void MonitorStop(void) {
    gMonitorStop = true;
    Util_Print("[Monitor] Stop requested\n");
}

/**
 * @brief Internal main loop
 *
 * @param [in] argc The count of arguments
 * @param [in] argv The array of arguments
 * @return SUCCESS if everything went well, else ERROR.
 */
int app_main(int argc, char** argv) {
    int i = 0;
    int sig;
    sigset_t sigs_to_catch;

    Util_Initialize(linux_print);

    /* Parse options */
    for(i = 1; i < argc; i++) {
        if(strcmp(argv[i], "-v") == 0) {
            gVerbose = 1;
        } else if(strcmp(argv[i], "-i") == 0) {
            interface_name = argv[++i];
        } else if(strcmp(argv[i], "-help") == 0) {
            Util_Print(
                "Usage: %s -i interface -help (this message)\n",
                argv[0]);
            Util_Print("\tinterface:     interface address "
                       "of the control point\n"
                       "\t\te.g.: eth0\n");
            return 1;
        }
    }

    if(InitAmx()) {
        Util_Print("Error on init AMX\n");
    } else {
        MonitorStart();
    }

    /* Catch Ctrl-C and properly shutdown */
    sigemptyset(&sigs_to_catch);
    sigaddset(&sigs_to_catch, SIGINT);
    sigaddset(&sigs_to_catch, SIGTERM);
    sigwait(&sigs_to_catch, &sig);
    Util_Print("Shutting down on signal %d...\n", sig);
    MonitorStop();
    KeepaliveStop();
    Util_Finish();
    WaitingForThreadsFinishing();

    return 0;
}

#ifndef UNIT_TEST
/**
 * @brief Main loop
 *
 * @param [in] argc The count of arguments
 * @param [in] argv The array of arguments
 * @return SUCCESS if everything went well, else ERROR.
 */
int main(int argc, char** argv) {
    return app_main(argc, argv);
}
#endif
