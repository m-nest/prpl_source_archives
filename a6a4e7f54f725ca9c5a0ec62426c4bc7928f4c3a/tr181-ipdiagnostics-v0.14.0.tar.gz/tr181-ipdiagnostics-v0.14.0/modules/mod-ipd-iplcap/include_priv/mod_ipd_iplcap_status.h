/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__MOD_IPD_IPLCAP_STATUS_H__)
#define __MOD_IPD_IPLCAP_STATUS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "iplcap.h"

/**
 * @brief IP Layer Capacity test status strings
 *
 * Array of string representations for all possible IP Layer Capacity
 * test status codes. This array provides human-readable status messages
 * corresponding to the numeric status codes defined in the iplcap
 * status enumeration.
 *
 * The array is indexed by the iplcap_test_status_t enumeration values
 * and provides the string representation for each status code.
 */
static const cstring_t str_iplcap_test_status[iplcap_test_num_of_status] = {
    IPLCAP_STATUS_NONE,           /**< No test running */
    IPLCAP_STATUS_COMPLETE,       /**< Test completed successfully */
    IPLCAP_STATUS_REQUESTED,      /**< Test requested but not started */
    IPLCAP_STATUS_CANCELED,       /**< Test was canceled */
    IPLCAP_STATUS_ERROR,          /**< General test error */
    IPLCAP_STATUS_ERR_HOST_NAME,  /**< Host name resolution error */
    IPLCAP_STATUS_ERR_ROUTE,      /**< Routing error */
    IPLCAP_STATUS_ERR_INIT_CONN,  /**< Connection initialization error */
    IPLCAP_STATUS_ERR_NO_RESP,    /**< No response from target */
    IPLCAP_STATUS_ERR_PWD_REQ,    /**< Password required error */
    IPLCAP_STATUS_ERR_LOGIN,      /**< Login authentication error */
    IPLCAP_STATUS_ERR_REJECTED,   /**< Connection rejected error */
    IPLCAP_STATUS_ERR_SIZE,       /**< Size parameter error */
    IPLCAP_STATUS_ERR_TIMEOUT,    /**< Test timeout error */
    IPLCAP_STATUS_ERR_INTERNAL,   /**< Internal system error */
    IPLCAP_STATUS_ERR_OTHER,      /**< Other unspecified error */
    IPLCAP_STATUS_NOT_COMPLETE    /**< Test not yet complete */
};

#ifdef __cplusplus
}
#endif

#endif // __MOD_IPD_IPLCAP_STATUS_H__