/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2026 Inango
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <setjmp.h>
#include <cmocka.h>
#include <stdio.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>

#include <amxut/amxut_util.h>

#include "amxb_usp.h"
#include "amxb_usp_la.h"
#include "test_amxb_usp_la_create_subs.h"

static amxb_usp_t* usp_ctx = NULL;
static amxd_dm_t* dm = NULL;
static amxd_dm_t* la_dm = NULL;

static amxd_object_t* tmp_obj = NULL;

static amxd_status_t buzz_describe(UNUSED amxd_object_t* object,
                                   UNUSED amxd_function_t* func,
                                   amxc_var_t* args,
                                   amxc_var_t* ret) {
    function_called();

    const char* rel_path = GET_CHAR(args, "rel_path");
    const char* rel_path_expected = mock_ptr_type(const char*);
    assert_string_equal(rel_path, rel_path_expected);

    const amxc_var_t* ret_result = mock_ptr_type(amxc_var_t*);
    amxc_var_copy(ret, ret_result);

    return mock_type(amxd_status_t);
}

// Static.              // static
//        Foo.          // static
//            Bar.      // static
//
// Dynamic.             // dynamic
static void init_dm(void) {
    assert_int_equal(amxd_dm_new(&dm), amxd_status_ok);
    amxd_object_t* root = amxd_dm_get_root(dm);
    root->priv = usp_ctx;

    {
        amxd_object_t* static_obj = NULL;

        assert_int_equal(amxd_object_new(&static_obj, amxd_object_singleton, "Static"), amxd_status_ok);
        assert_int_equal(amxd_dm_add_root_object(dm, static_obj), amxd_status_ok);

        amxd_object_t* foo = NULL;
        assert_int_equal(amxd_object_new(&foo, amxd_object_singleton, "Foo"), amxd_status_ok);
        assert_int_equal(amxd_object_add_object(static_obj, foo), amxd_status_ok);

        amxd_object_t* bar = NULL;
        assert_int_equal(amxd_object_new(&bar, amxd_object_template, "Bar"), amxd_status_ok);
        assert_int_equal(amxd_object_add_object(foo, bar), amxd_status_ok);
    }

    {
        amxd_object_t* dynamic_obj = NULL;

        assert_int_equal(amxd_object_new(&dynamic_obj, amxd_object_singleton, "Dynamic"), amxd_status_ok);
        assert_int_equal(amxd_dm_add_root_object(dm, dynamic_obj), amxd_status_ok);
        amxd_object_change_function(dynamic_obj, "_describe", buzz_describe);

    }
}

static void init_la_dm(void) {
    assert_int_equal(amxd_dm_new(&la_dm), amxd_status_ok);
    amxd_object_t* root = amxd_dm_get_root(la_dm);
    root->priv = usp_ctx;

    amxd_object_t* device = NULL;

    assert_int_equal(amxd_object_new(&device, amxd_object_singleton, "Device"), amxd_status_ok);
    assert_int_equal(amxd_dm_add_root_object(la_dm, device), amxd_status_ok);

    amxd_object_t* la = NULL;
    assert_int_equal(amxd_object_new(&la, amxd_object_singleton, "LocalAgent"), amxd_status_ok);
    assert_int_equal(amxd_object_add_object(device, la), amxd_status_ok);

    amxd_object_t* subscription = NULL;
    assert_int_equal(amxd_object_new(&subscription, amxd_object_template, "Subscription"), amxd_status_ok);
    assert_int_equal(amxd_object_add_object(la, subscription), amxd_status_ok);

    amxd_object_t* controller = NULL;
    assert_int_equal(amxd_object_new(&controller, amxd_object_template, "Controller"), amxd_status_ok);
    assert_int_equal(amxd_object_add_object(la, controller), amxd_status_ok);

    amxd_param_t* eid = NULL;
    assert_int_equal(amxd_param_new(&eid, "EndpointID", AMXC_VAR_ID_CSTRING), amxd_status_ok);
    assert_int_equal(amxd_object_add_param(controller, eid), amxd_status_ok);

    amxd_object_t* instance = NULL;
    assert_int_equal(amxd_object_new_instance(&instance, controller, "usp", 0, NULL), amxd_status_ok);

    amxd_object_set_value(cstring_t, instance, "EndpointID", "usp");
}

int test_setup(UNUSED void** state) {

    usp_ctx = calloc(sizeof(amxb_usp_t), 1);
    usp_ctx->eid = "usp";

    init_dm();
    init_la_dm();

    usp_ctx->dm = dm;
    usp_ctx->la_dm = la_dm;

    amxd_object_new(&tmp_obj, amxd_object_singleton, "TmpObj");

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxd_dm_delete(&la_dm);
    amxd_dm_delete(&dm);
    free(usp_ctx);

    return 0;
}

amxd_status_t __wrap_amxd_action_object_add_inst(UNUSED amxd_object_t* const object,
                                                 UNUSED amxd_param_t* const param,
                                                 UNUSED amxd_action_t reason,
                                                 UNUSED const amxc_var_t* const args,
                                                 UNUSED amxc_var_t* const retval,
                                                 UNUSED void* priv) {
    return amxd_status_ok;
}

amxd_object_t* __wrap_amxd_object_get_instance(UNUSED const amxd_object_t* object,
                                               UNUSED const char* name,
                                               UNUSED uint32_t index) {
    return tmp_obj;
}

static amxc_var_t* create_event_subcription(const char* path) {
    amxc_var_t* args = NULL;
    amxc_var_new(&args);
    amxc_var_set_type(args, AMXC_VAR_ID_HTABLE);
    {
        amxc_var_t* params = amxc_var_add_new_key(args, "parameters");
        amxc_var_set_type(params, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, params, "NotifType", "Event");
        amxc_var_add_key(cstring_t, params, "ReferenceList", path);
    }

    return args;
}

void test_create_subscription_static_dm(UNUSED void** state) {
    {
        amxc_var_t* args = create_event_subcription("Static.Foo.");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_ok);
        amxc_var_delete(&args);
    }
    {
        amxc_var_t* args = create_event_subcription("Static.Foo.Bar.");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_ok);
        amxc_var_delete(&args);
    }
    {
        amxc_var_t* args = create_event_subcription("Static.Foo.Bar.Buzz.");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_invalid_value);
        amxc_var_delete(&args);
    }
}

static amxc_var_t* build_describe_response() {
    amxc_var_t* ret = NULL;
    amxc_var_new(&ret);
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(int32_t, ret, "type_id", amxd_object_singleton);

    return ret;
}

void test_create_subscription_dynamic_dm(UNUSED void** state) {
    {
        expect_function_call(buzz_describe);
        will_return(buzz_describe, "Foo.");
        amxc_var_t* ret = build_describe_response();
        will_return(buzz_describe, ret);
        will_return(buzz_describe, amxd_status_ok);

        amxc_var_t* args = create_event_subcription("Dynamic.Foo.");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_ok);

        amxc_var_delete(&args);
        amxc_var_delete(&ret);
    }
    {
        expect_function_call(buzz_describe);
        will_return(buzz_describe, "Foo.Bar.");
        amxc_var_t* ret = build_describe_response();
        will_return(buzz_describe, ret);
        will_return(buzz_describe, amxd_status_ok);

        amxc_var_t* args = create_event_subcription("Dynamic.Foo.Bar.");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_ok);

        amxc_var_delete(&args);
        amxc_var_delete(&ret);
    }
    {
        expect_function_call(buzz_describe);
        will_return(buzz_describe, "Foo.Bar.");
        will_return(buzz_describe, NULL);
        will_return(buzz_describe, amxd_status_object_not_found);

        amxc_var_t* args = create_event_subcription("Dynamic.Foo.Bar.Buzz");
        assert_int_equal(amxb_usp_la_subs_add_inst(amxd_dm_findf(la_dm, "Device.LocalAgent.Subscription"), NULL, action_object_add_inst, args, NULL, NULL), amxd_status_invalid_value);

        amxc_var_delete(&args);
    }

}
