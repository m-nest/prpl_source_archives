{# find out if wan interface type is cellular #}{% let has_cellular_wan = (BDfn.getInterfaceIndex("wan", "cellular") != "-1"); %}
%populate {
{% if (BDfn.getUpstreamInterfaceIndex() != "-1"): %}
    object IP.Interface.wan {
        parameter Enable = true;
        parameter IPv4Enable = true;
        parameter IPv6Enable = true;
        parameter ULAEnable = false;
        parameter UCISectionNameIPv4 = "";
        parameter UCISectionNameIPv6 = "";
        parameter MaxMTUSize = 1500;
        parameter Type = "Normal";
        parameter Loopback = false;
        parameter LowerLayers = "Device.Ethernet.Link.2";
        parameter UpLink = true;
    }

    object IP.Interface.wan.IPv4Address {
        instance add("primary") {
            parameter Enable = true;
{% if (has_cellular_wan): %}
            parameter AddressingType = "3GPP-NAS";
{% else; %}
            parameter AddressingType = "DHCP";
{% endif; %}
        }
    }

    object IP.Interface.wan.IPv6Prefix {
        instance add ("GUA_IAPD") {
            parameter Enable = true;
            parameter Origin = "PrefixDelegation";
            parameter StaticType = "Inapplicable";
        }

        instance add ("GUA_RA") {
            parameter Enable = true;
            parameter Origin = "RouterAdvertisement";
            parameter StaticType = "Inapplicable";
        }

        instance add ("DHCP_IAPD") {
            parameter Enable = true;
            parameter Origin = "Child";
            parameter Prefix = "";
            parameter Autonomous = true;
            parameter ParentPrefix = "${ip_intf_wan}IPv6Prefix.1";
            parameter StaticType = "Inapplicable";
            parameter ChildPrefixBits = "0:0:0:FFFF::/64";
        }

        instance add ("GUA_STATIC") {
            parameter Enable = true;
            parameter Origin = "Static";
            parameter StaticType = "Static";
            parameter Autonomous = true;
            parameter OnLink = true;
        }

{% if (has_cellular_wan): %}
        instance add ("GUA_3GPP_NAS") {
            parameter Enable = true;
            parameter Origin = "3GPP-NAS";
            parameter StaticType = "Inapplicable";
        }
{% endif; %}
    }

    object IP.Interface.wan.IPv6Address {
        instance add ("GUA_RA") {
            parameter Enable = true;
            parameter Origin = "AutoConfigured";
            parameter Prefix = "${ip_intf_wan}IPv6Prefix.2";
        }

        instance add("DHCP") {
            parameter Enable = true;
            parameter Origin = "DHCPv6";
            parameter InterfaceIDType = "None";
        }

        instance add("DHCP_IAPD") {
            parameter Enable = true;
            parameter IPAddress = "";
            parameter Prefix = "${ip_intf_wan}IPv6Prefix.3";
            parameter Origin = "AutoConfigured";
        }

        instance add("GUA_STATIC") {
            parameter Enable = true;
            parameter IPAddress = "";
            parameter Prefix = "${ip_intf_wan}IPv6Prefix.4";
            parameter Origin = "Static";
        }

{% if (has_cellular_wan): %}
        instance add("GUA_3GPP_NAS") {
            parameter Enable = true;
            parameter IPAddress = "";
            parameter Prefix = "${ip_intf_wan}IPv6Prefix.5";
            parameter Origin = "3GPP-NAS";
        }
{% endif; %}
    }
{% endif; %}
}
