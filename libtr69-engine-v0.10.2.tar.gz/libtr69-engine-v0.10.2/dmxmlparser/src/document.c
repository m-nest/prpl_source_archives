/*
 * ----------------------------------------------------------------------------
 *                                 Apache License
 *                           Version 2.0, January 2004
 *                        http://www.apache.org/licenses/
 *
 *   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
 *
 *   1. Definitions.
 *
 *      "License" shall mean the terms and conditions for use, reproduction,
 *      and distribution as defined by Sections 1 through 9 of this document.
 *
 *      "Licensor" shall mean the copyright owner or entity authorized by
 *      the copyright owner that is granting the License.
 *
 *      "Legal Entity" shall mean the union of the acting entity and all
 *      other entities that control, are controlled by, or are under common
 *      control with that entity. For the purposes of this definition,
 *      "control" means (i) the power, direct or indirect, to cause the
 *      direction or management of such entity, whether by contract or
 *      otherwise, or (ii) ownership of fifty percent (50%) or more of the
 *      outstanding shares, or (iii) beneficial ownership of such entity.
 *
 *      "You" (or "Your") shall mean an individual or Legal Entity
 *      exercising permissions granted by this License.
 *
 *      "Source" form shall mean the preferred form for making modifications,
 *      including but not limited to software source code, documentation
 *      source, and configuration files.
 *
 *      "Object" form shall mean any form resulting from mechanical
 *      transformation or translation of a Source form, including but
 *      not limited to compiled object code, generated documentation,
 *      and conversions to other media types.
 *
 *      "Work" shall mean the work of authorship, whether in Source or
 *      Object form, made available under the License, as indicated by a
 *      copyright notice that is included in or attached to the work
 *      (an example is provided in the Appendix below).
 *
 *      "Derivative Works" shall mean any work, whether in Source or Object
 *      form, that is based on (or derived from) the Work and for which the
 *      editorial revisions, annotations, elaborations, or other modifications
 *      represent, as a whole, an original work of authorship. For the purposes
 *      of this License, Derivative Works shall not include works that remain
 *      separable from, or merely link (or bind by name) to the interfaces of,
 *      the Work and Derivative Works thereof.
 *
 *      "Contribution" shall mean any work of authorship, including
 *      the original version of the Work and any modifications or additions
 *      to that Work or Derivative Works thereof, that is intentionally
 *      submitted to Licensor for inclusion in the Work by the copyright owner
 *      or by an individual or Legal Entity authorized to submit on behalf of
 *      the copyright owner. For the purposes of this definition, "submitted"
 *      means any form of electronic, verbal, or written communication sent
 *      to the Licensor or its representatives, including but not limited to
 *      communication on electronic mailing lists, source code control systems,
 *      and issue tracking systems that are managed by, or on behalf of, the
 *      Licensor for the purpose of discussing and improving the Work, but
 *      excluding communication that is conspicuously marked or otherwise
 *      designated in writing by the copyright owner as "Not a Contribution."
 *
 *      "Contributor" shall mean Licensor and any individual or Legal Entity
 *      on behalf of whom a Contribution has been received by Licensor and
 *      subsequently incorporated within the Work.
 *
 *   2. Grant of Copyright License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      copyright license to reproduce, prepare Derivative Works of,
 *      publicly display, publicly perform, sublicense, and distribute the
 *      Work and such Derivative Works in Source or Object form.
 *
 *   3. Grant of Patent License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      (except as stated in this section) patent license to make, have made,
 *      use, offer to sell, sell, import, and otherwise transfer the Work,
 *      where such license applies only to those patent claims licensable
 *      by such Contributor that are necessarily infringed by their
 *      Contribution(s) alone or by combination of their Contribution(s)
 *      with the Work to which such Contribution(s) was submitted. If You
 *      institute patent litigation against any entity (including a
 *      cross-claim or counterclaim in a lawsuit) alleging that the Work
 *      or a Contribution incorporated within the Work constitutes direct
 *      or contributory patent infringement, then any patent licenses
 *      granted to You under this License for that Work shall terminate
 *      as of the date such litigation is filed.
 *
 *   4. Redistribution. You may reproduce and distribute copies of the
 *      Work or Derivative Works thereof in any medium, with or without
 *      modifications, and in Source or Object form, provided that You
 *      meet the following conditions:
 *
 *      (a) You must give any other recipients of the Work or
 *          Derivative Works a copy of this License; and
 *
 *      (b) You must cause any modified files to carry prominent notices
 *          stating that You changed the files; and
 *
 *      (c) You must retain, in the Source form of any Derivative Works
 *          that You distribute, all copyright, patent, trademark, and
 *          attribution notices from the Source form of the Work,
 *          excluding those notices that do not pertain to any part of
 *          the Derivative Works; and
 *
 *      (d) If the Work includes a "NOTICE" text file as part of its
 *          distribution, then any Derivative Works that You distribute must
 *          include a readable copy of the attribution notices contained
 *          within such NOTICE file, excluding those notices that do not
 *          pertain to any part of the Derivative Works, in at least one
 *          of the following places: within a NOTICE text file distributed
 *          as part of the Derivative Works; within the Source form or
 *          documentation, if provided along with the Derivative Works; or,
 *          within a display generated by the Derivative Works, if and
 *          wherever such third-party notices normally appear. The contents
 *          of the NOTICE file are for informational purposes only and
 *          do not modify the License. You may add Your own attribution
 *          notices within Derivative Works that You distribute, alongside
 *          or as an addendum to the NOTICE text from the Work, provided
 *          that such additional attribution notices cannot be construed
 *          as modifying the License.
 *
 *      You may add Your own copyright statement to Your modifications and
 *      may provide additional or different license terms and conditions
 *      for use, reproduction, or distribution of Your modifications, or
 *      for any such Derivative Works as a whole, provided Your use,
 *      reproduction, and distribution of the Work otherwise complies with
 *      the conditions stated in this License.
 *
 *   5. Submission of Contributions. Unless You explicitly state otherwise,
 *      any Contribution intentionally submitted for inclusion in the Work
 *      by You to the Licensor shall be under the terms and conditions of
 *      this License, without any additional terms or conditions.
 *      Notwithstanding the above, nothing herein shall supersede or modify
 *      the terms of any separate license agreement you may have executed
 *      with Licensor regarding such Contributions.
 *
 *   6. Trademarks. This License does not grant permission to use the trade
 *      names, trademarks, service marks, or product names of the Licensor,
 *      except as required for reasonable and customary use in describing the
 *      origin of the Work and reproducing the content of the NOTICE file.
 *
 *   7. Disclaimer of Warranty. Unless required by applicable law or
 *      agreed to in writing, Licensor provides the Work (and each
 *      Contributor provides its Contributions) on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *      implied, including, without limitation, any warranties or conditions
 *      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
 *      PARTICULAR PURPOSE. You are solely responsible for determining the
 *      appropriateness of using or redistributing the Work and assume any
 *      risks associated with Your exercise of permissions under this License.
 *
 *   8. Limitation of Liability. In no event and under no legal theory,
 *      whether in tort (including negligence), contract, or otherwise,
 *      unless required by applicable law (such as deliberate and grossly
 *      negligent acts) or agreed to in writing, shall any Contributor be
 *      liable to You for damages, including any direct, indirect, special,
 *      incidental, or consequential damages of any character arising as a
 *      result of this License or out of the use or inability to use the
 *      Work (including but not limited to damages for loss of goodwill,
 *      work stoppage, computer failure or malfunction, or any and all
 *      other commercial damages or losses), even if such Contributor
 *      has been advised of the possibility of such damages.
 *
 *   9. Accepting Warranty or Additional Liability. While redistributing
 *      the Work or Derivative Works thereof, You may choose to offer,
 *      and charge a fee for, acceptance of support, warranty, indemnity,
 *      or other liability obligations and/or rights consistent with this
 *      License. However, in accepting such obligations, You may act only
 *      on Your own behalf and on Your sole responsibility, not on behalf
 *      of any other Contributor, and only if You agree to indemnify,
 *      defend, and hold each Contributor harmless for any liability
 *      incurred by, or claims asserted against, such Contributor by reason
 *      of your accepting any such warranty or additional liability.
 *
 *   END OF TERMS AND CONDITIONS
 *
 *   APPENDIX: How to apply the Apache License to your work.
 *
 *      To apply the Apache License to your work, attach the following
 *      boilerplate notice, with the fields enclosed by brackets "[]"
 *      replaced with your own identifying information. (Don't include
 *      the brackets!)  The text should be enclosed in the appropriate
 *      comment syntax for the file format. We also recommend that a
 *      file or class name and description of purpose be included on the
 *      same "printed page" as the copyright notice for easier
 *      identification within third-party archives.
 *
 *   Copyright [2025] [SoftAtHome]
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 * ---------------------------------------------------------------------------
 */
///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2000-2003 Intel Corporation
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation
// and/or other materials provided with the distribution.
// * Neither name of Intel Corporation nor the names of its contributors
// may be used to endorse or promote products derived from this software
// without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>

#include <dmxmlparser/ixmlparser.h>

/*================================================================
 *   ixmlDocument_init
 *       It initialize the document structure.
 *       External function.
 *
 *=================================================================*/
void
ixmlDocument_init(IN IXML_Document* doc) {
    memset(doc, 0, sizeof( IXML_Document ));
}

/*================================================================
 *   ixmlDocument_free
 *       It frees the whole document tree.
 *       External function.
 *
 *=================================================================*/
void
ixmlDocument_free(IN IXML_Document* doc) {
    if(doc != NULL) {
        ixmlNode_free(( IXML_Node* ) doc);
    }

}

/*================================================================
 *   ixmlDocument_setOwnerDocument
 *
 *       When this function is called first time, nodeptr is the root
 *       of the subtree, so it is not necessay to do two steps
 *       recursion.
 *
 *       Internal function called by ixmlDocument_importNode
 *
 *=================================================================*/
void
ixmlDocument_setOwnerDocument(IN IXML_Document* doc,
                              IN IXML_Node* nodeptr) {
    if(nodeptr != NULL) {
        nodeptr->ownerDocument = doc;
        ixmlDocument_setOwnerDocument(doc,
                                      ixmlNode_getFirstChild(nodeptr));
        ixmlDocument_setOwnerDocument(doc,
                                      ixmlNode_getNextSibling
                                      (nodeptr));
    }
}

/*================================================================
 *   ixmlDocument_importNode
 *       Imports a node from another document to this document. The
 *       returned node has no parent; (parentNode is null). The source
 *       node is not altered or removed from the original document;
 *       this method creates a new copy of the source node.

 *       For all nodes, importing a node creates a node object owned
 *       by the importing document, with attribute values identical to
 *       the source node's nodeName and nodeType, plus the attributes
 *       related to namespaces (prefix, localName, and namespaceURI).
 *       As in the cloneNode operation on a node, the source node is
 *       not altered.
 *
 *       External function.
 *
 *=================================================================*/
int
ixmlDocument_importNode(IN IXML_Document* doc,
                        IN IXML_Node* importNode,
                        IN BOOL deep,
                        OUT IXML_Node** rtNode) {
    unsigned short nodeType;
    IXML_Node* newNode;

    *rtNode = NULL;

    if(( doc == NULL ) || ( importNode == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    nodeType = ixmlNode_getNodeType(importNode);
    if(nodeType == eDOCUMENT_NODE) {
        return IXML_NOT_SUPPORTED_ERR;
    }

    newNode = ixmlNode_cloneNode(importNode, deep);
    if(newNode == NULL) {
        return IXML_FAILED;
    }

    ixmlDocument_setOwnerDocument(doc, newNode);
    *rtNode = newNode;

    return IXML_SUCCESS;
}

/*================================================================
 *   ixmlDocument_createElementEx
 *       Creates an element of the type specified.
 *       External function.
 *   Parameters:
 *       doc:        pointer to document
 *       tagName:    The name of the element, it is case-sensitive.
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INVALID_PARAMETER:     if either doc or tagName is NULL
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createElementEx(IN IXML_Document* doc,
                             IN const DOMString tagName,
                             OUT IXML_Element** rtElement) {

    int errCode = IXML_SUCCESS;
    IXML_Element* newElement = NULL;

    if(( doc == NULL ) || ( tagName == NULL )) {
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    newElement = ( IXML_Element* ) malloc(sizeof( IXML_Element ));
    if(newElement == NULL) {
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    ixmlElement_init(newElement);
    newElement->tagName = strdup(tagName);
    if(newElement->tagName == NULL) {
        ixmlElement_free(newElement);
        newElement = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }
    // set the node fields
    newElement->n.nodeType = eELEMENT_NODE;
    newElement->n.nodeName = strdup(tagName);
    if(newElement->n.nodeName == NULL) {
        ixmlElement_free(newElement);
        newElement = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    newElement->n.ownerDocument = doc;

ErrorHandler:
    *rtElement = newElement;
    return errCode;

}

/*================================================================
 *   ixmlDocument_createElement
 *       Creates an element of the type specified.
 *       External function.
 *   Parameters:
 *       doc:        pointer to document
 *       tagName:    The name of the element, it is case-sensitive.
 *   Return Value:
 *       A new element object with the nodeName set to tagName, and
 *       localName, prefix and namespaceURI set to null.
 *
 *=================================================================*/
IXML_Element*
ixmlDocument_createElement(IN IXML_Document* doc,
                           IN const DOMString tagName) {
    IXML_Element* newElement = NULL;

    ixmlDocument_createElementEx(doc, tagName, &newElement);
    return newElement;

}

/*================================================================
 *   ixmlDocument_createDocumentEx
 *       Creates an document object
 *       Internal function.
 *   Parameters:
 *       rtDoc:  the document created or NULL on failure
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createDocumentEx(OUT IXML_Document** rtDoc) {
    IXML_Document* doc;
    int errCode = IXML_SUCCESS;

    doc = NULL;
    doc = ( IXML_Document* ) malloc(sizeof( IXML_Document ));
    if(doc == NULL) {
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    ixmlDocument_init(doc);

    doc->n.nodeName = strdup(DOCUMENTNODENAME);
    if(doc->n.nodeName == NULL) {
        ixmlDocument_free(doc);
        doc = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    doc->n.nodeType = eDOCUMENT_NODE;
    doc->n.ownerDocument = doc;

ErrorHandler:
    *rtDoc = doc;
    return errCode;
}

/*================================================================
 *   ixmlDocument_createDocument
 *       Creates an document object
 *       Internal function.
 *   Parameters:
 *       none
 *   Return Value:
 *       A new document object with the nodeName set to "#document".
 *
 *=================================================================*/
IXML_Document*
ixmlDocument_createDocument(  ) {
    IXML_Document* doc = NULL;

    ixmlDocument_createDocumentEx(&doc);

    return doc;

}

/*================================================================
 *   ixmlDocument_createTextNodeEx
 *       Creates an text node.
 *       External function.
 *   Parameters:
 *       data: text data for the text node. It is stored in nodeValue field.
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INVALID_PARAMETER:     if either doc or data is NULL
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createTextNodeEx(IN IXML_Document* doc,
                              IN const char* data,
                              OUT IXML_Node** textNode) {
    IXML_Node* returnNode;
    int rc = IXML_SUCCESS;

    returnNode = NULL;
    if(( doc == NULL ) || ( data == NULL )) {
        rc = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    returnNode = ( IXML_Node* ) malloc(sizeof( IXML_Node ));
    if(returnNode == NULL) {
        rc = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }
    // initialize the node
    ixmlNode_init(returnNode);

    returnNode->nodeName = strdup(TEXTNODENAME);
    if(returnNode->nodeName == NULL) {
        ixmlNode_free(returnNode);
        returnNode = NULL;
        rc = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }
    // add in node value
    if(data != NULL) {
        returnNode->nodeValue = strdup(data);
        if(returnNode->nodeValue == NULL) {
            ixmlNode_free(returnNode);
            returnNode = NULL;
            rc = IXML_INSUFFICIENT_MEMORY;
            goto ErrorHandler;
        }
    }

    returnNode->nodeType = eTEXT_NODE;
    returnNode->ownerDocument = doc;

ErrorHandler:
    *textNode = returnNode;
    return rc;

}

/*================================================================
 *   ixmlDocument_createTextNode
 *       Creates an text node.
 *       External function.
 *   Parameters:
 *       data: text data for the text node. It is stored in nodeValue field.
 *   Return Value:
 *       The new text node.
 *
 *=================================================================*/
IXML_Node*
ixmlDocument_createTextNode(IN IXML_Document* doc,
                            IN const char* data) {
    IXML_Node* returnNode = NULL;

    ixmlDocument_createTextNodeEx(doc, data, &returnNode);

    return returnNode;
}

/*================================================================
*   ixmlDocument_createAttributeEx
*       Creates an attribute of the given name.
*       External function.
*   Parameters:
*       name: The name of the Attribute node.
*   Return Value:
*       IXML_SUCCESS
*       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
*
   ================================================================*/
int
ixmlDocument_createAttributeEx(IN IXML_Document* doc,
                               IN const char* name,
                               OUT IXML_Attr** rtAttr) {
    IXML_Attr* attrNode = NULL;
    int errCode = IXML_SUCCESS;

    attrNode = ( IXML_Attr* ) malloc(sizeof( IXML_Attr ));
    if(attrNode == NULL) {
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    if(( doc == NULL ) || ( name == NULL )) {
        ixmlAttr_free(attrNode);
        attrNode = NULL;
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    ixmlAttr_init(attrNode);

    attrNode->n.nodeType = eATTRIBUTE_NODE;

    // set the node fields
    attrNode->n.nodeName = strdup(name);
    if(attrNode->n.nodeName == NULL) {
        ixmlAttr_free(attrNode);
        attrNode = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    attrNode->n.ownerDocument = doc;

ErrorHandler:
    *rtAttr = attrNode;
    return errCode;

}

/*================================================================
*   ixmlDocument_createAttribute
*       Creates an attribute of the given name.
*       External function.
*   Parameters:
*       name: The name of the Attribute node.
*   Return Value:
*       A new attr object with the nodeName attribute set to the
*       given name, and the localName, prefix and namespaceURI set to NULL.
*       The value of the attribute is the empty string.
*
   ================================================================*/
IXML_Attr*
ixmlDocument_createAttribute(IN IXML_Document* doc,
                             IN const char* name) {
    IXML_Attr* attrNode = NULL;

    ixmlDocument_createAttributeEx(doc, name, &attrNode);
    return attrNode;

}

/*================================================================
 *   ixmlDocument_createAttributeNSEx
 *       Creates an attrbute of the given name and namespace URI
 *       External function.
 *   Parameters:
 *       namespaceURI: the namespace fo the attribute to create
 *       qualifiedName: qualifiedName of the attribute to instantiate
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INVALID_PARAMETER:     if either doc,namespaceURI or qualifiedName is NULL
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createAttributeNSEx(IN IXML_Document* doc,
                                 IN const DOMString namespaceURI,
                                 IN const DOMString qualifiedName,
                                 OUT IXML_Attr** rtAttr) {
    IXML_Attr* attrNode = NULL;
    int errCode = IXML_SUCCESS;

    if(( doc == NULL ) || ( namespaceURI == NULL )
       || ( qualifiedName == NULL )) {
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    errCode =
        ixmlDocument_createAttributeEx(doc, qualifiedName, &attrNode);
    if(errCode != IXML_SUCCESS) {
        goto ErrorHandler;
    }
    // set the namespaceURI field
    attrNode->n.namespaceURI = strdup(namespaceURI);
    if(attrNode->n.namespaceURI == NULL) {
        ixmlAttr_free(attrNode);
        attrNode = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }
    // set the localName and prefix
    errCode =
        ixmlNode_setNodeName(( IXML_Node* ) attrNode, qualifiedName);
    if(errCode != IXML_SUCCESS) {
        ixmlAttr_free(attrNode);
        attrNode = NULL;
        goto ErrorHandler;
    }

ErrorHandler:
    *rtAttr = attrNode;
    return errCode;

}

/*================================================================
 *   ixmlDocument_createAttributeNS
 *       Creates an attrbute of the given name and namespace URI
 *       External function.
 *   Parameters:
 *       namespaceURI: the namespace fo the attribute to create
 *       qualifiedName: qualifiedName of the attribute to instantiate
 *   Return Value:
 *       Creates an attribute node with the given namespaceURI and
 *       qualifiedName. The prefix and localname are extracted from
 *       the qualifiedName. The node value is empty.
 *
 *=================================================================*/
IXML_Attr*
ixmlDocument_createAttributeNS(IN IXML_Document* doc,
                               IN const DOMString namespaceURI,
                               IN const DOMString qualifiedName) {
    IXML_Attr* attrNode = NULL;

    ixmlDocument_createAttributeNSEx(doc, namespaceURI, qualifiedName,
                                     &attrNode);
    return attrNode;
}

/*================================================================
 *   ixmlDocument_createCDATASectionEx
 *       Creates an CDATASection node whose value is the specified string
 *       External function.
 *   Parameters:
 *       data: the data for the CDATASection contents.
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INVALID_PARAMETER:     if either doc or data is NULL
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createCDATASectionEx(IN IXML_Document* doc,
                                  IN const DOMString data,
                                  OUT IXML_CDATASection** rtCD) {
    int errCode = IXML_SUCCESS;
    IXML_CDATASection* cDSectionNode = NULL;

    if(( doc == NULL ) || ( data == NULL )) {
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    cDSectionNode =
        ( IXML_CDATASection* ) malloc(sizeof( IXML_CDATASection ));
    if(cDSectionNode == NULL) {
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    ixmlCDATASection_init(cDSectionNode);

    cDSectionNode->n.nodeType = eCDATA_SECTION_NODE;
    cDSectionNode->n.nodeName = strdup(CDATANODENAME);
    if(cDSectionNode->n.nodeName == NULL) {
        ixmlCDATASection_free(cDSectionNode);
        cDSectionNode = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    cDSectionNode->n.nodeValue = strdup(data);
    if(cDSectionNode->n.nodeValue == NULL) {
        ixmlCDATASection_free(cDSectionNode);
        cDSectionNode = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    cDSectionNode->n.ownerDocument = doc;

ErrorHandler:
    *rtCD = cDSectionNode;
    return errCode;

}

/*================================================================
 *   ixmlDocument_createCDATASection
 *       Creates an CDATASection node whose value is the specified string
 *       External function.
 *   Parameters:
 *       data: the data for the CDATASection contents.
 *   Return Value:
 *       The new CDATASection object.
 *
 *=================================================================*/
IXML_CDATASection*
ixmlDocument_createCDATASection(IN IXML_Document* doc,
                                IN const DOMString data) {

    IXML_CDATASection* cDSectionNode = NULL;

    ixmlDocument_createCDATASectionEx(doc, data, &cDSectionNode);
    return cDSectionNode;
}

/*================================================================
 *   ixmlDocument_createElementNSEx
 *       Creates an element of the given qualified name and namespace URI.
 *       External function.
 *   Parameters:
 *       namespaceURI: the namespace URI of the element to create.
 *       qualifiedName: the qualified name of the element to instantiate.
 *   Return Value:
 *   Return Value:
 *       IXML_SUCCESS
 *       IXML_INVALID_PARAMETER:     if either doc,namespaceURI or qualifiedName is NULL
 *       IXML_INSUFFICIENT_MEMORY:   if not enough memory to finish this operations.
 *
 *=================================================================*/
int
ixmlDocument_createElementNSEx(IN IXML_Document* doc,
                               IN const DOMString namespaceURI,
                               IN const DOMString qualifiedName,
                               OUT IXML_Element** rtElement) {

    IXML_Element* newElement = NULL;
    int errCode = IXML_SUCCESS;

    if(( doc == NULL ) || ( namespaceURI == NULL )
       || ( qualifiedName == NULL )) {
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    errCode =
        ixmlDocument_createElementEx(doc, qualifiedName, &newElement);
    if(errCode != IXML_SUCCESS) {
        goto ErrorHandler;
    }
    // set the namespaceURI field
    newElement->n.namespaceURI = strdup(namespaceURI);
    if(newElement->n.namespaceURI == NULL) {
        ixmlElement_free(newElement);
        newElement = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }
    // set the localName and prefix
    errCode =
        ixmlNode_setNodeName(( IXML_Node* ) newElement, qualifiedName);
    if(errCode != IXML_SUCCESS) {
        ixmlElement_free(newElement);
        newElement = NULL;
        errCode = IXML_INSUFFICIENT_MEMORY;
        goto ErrorHandler;
    }

    newElement->n.nodeValue = NULL;

ErrorHandler:
    *rtElement = newElement;
    return errCode;

}

/*================================================================
 *   ixmlDocument_createElementNS
 *       Creates an element of the given qualified name and namespace URI.
 *       External function.
 *   Parameters:
 *       namespaceURI: the namespace URI of the element to create.
 *       qualifiedName: the qualified name of the element to instantiate.
 *   Return Value:
 *       The new element object with tagName qualifiedName, prefix and
 *       localName extraced from qualfiedName, nodeName of qualfiedName,
 *	    namespaceURI of namespaceURI.
 *
 *=================================================================*/
IXML_Element*
ixmlDocument_createElementNS(IN IXML_Document* doc,
                             IN const DOMString namespaceURI,
                             IN const DOMString qualifiedName) {
    IXML_Element* newElement = NULL;

    ixmlDocument_createElementNSEx(doc, namespaceURI, qualifiedName,
                                   &newElement);
    return newElement;
}

/*================================================================
 *   ixmlDocument_getElementsByTagName
 *       Returns a nodeList of all the Elements with a given tag name
 *       in the order in which they are encountered in a preorder traversal
 *       of the document tree.
 *       External function.
 *   Parameters:
 *       tagName: the name of the tag to match on. The special value "*"
 *                matches all tags.
 *   Return Value:
 *       A new nodeList object containing all the matched Elements.
 *
 *=================================================================*/
IXML_NodeList*
ixmlDocument_getElementsByTagName(IN IXML_Document* doc,
                                  IN const char* tagName) {
    IXML_NodeList* returnNodeList = NULL;

    if(( doc == NULL ) || ( tagName == NULL )) {
        return NULL;
    }

    ixmlNode_getElementsByTagName(( IXML_Node* ) doc, tagName,
                                  &returnNodeList);
    return returnNodeList;
}

/*================================================================
 *   ixmlDocument_getElementsByTagNameNS
 *       Returns a nodeList of all the Elements with a given local name and
 *       namespace URI in the order in which they are encountered in a
 *       preorder traversal of the document tree.
 *       External function.
 *   Parameters:
 *       namespaceURI: the namespace of the elements to match on. The special
 *               value "*" matches all namespaces.
 *       localName: the local name of the elements to match on. The special
 *               value "*" matches all local names.
 *   Return Value:
 *       A new nodeList object containing all the matched Elements.
 *
 *=================================================================*/
IXML_NodeList*
ixmlDocument_getElementsByTagNameNS(IN IXML_Document* doc,
                                    IN const DOMString namespaceURI,
                                    IN const DOMString localName) {
    IXML_NodeList* returnNodeList = NULL;

    if(( doc == NULL ) || ( namespaceURI == NULL )
       || ( localName == NULL )) {
        return NULL;
    }

    ixmlNode_getElementsByTagNameNS(( IXML_Node* ) doc, namespaceURI,
                                    localName, &returnNodeList);
    return returnNodeList;
}

/*================================================================
 *   ixmlDocument_getElementById
 *       Returns the element whose ID is given by tagName. If no such
 *       element exists, returns null.
 *       External function.
 *   Parameter:
 *       tagName: the tag name for an element.
 *   Return Values:
 *       The matching element.
 *
 *=================================================================*/
IXML_Element*
ixmlDocument_getElementById(IN IXML_Document* doc,
                            IN const DOMString tagName) {
    IXML_Element* rtElement = NULL;
    IXML_Node* nodeptr = ( IXML_Node* ) doc;
    const char* name;

    if(( nodeptr == NULL ) || ( tagName == NULL )) {
        return rtElement;
    }

    if(ixmlNode_getNodeType(nodeptr) == eELEMENT_NODE) {
        name = ixmlNode_getNodeName(nodeptr);
        if(name == NULL) {
            return rtElement;
        }

        if(strcmp(tagName, name) == 0) {
            rtElement = ( IXML_Element* ) nodeptr;
            return rtElement;
        } else {
            rtElement = ixmlDocument_getElementById(( IXML_Document* )
                                                    ixmlNode_getFirstChild
                                                    (nodeptr),
                                                    tagName);
            if(rtElement == NULL) {
                rtElement = ixmlDocument_getElementById(( IXML_Document
                                                          * )
                                                        ixmlNode_getNextSibling
                                                        (nodeptr),
                                                        tagName);
            }
        }
    } else {
        rtElement = ixmlDocument_getElementById(( IXML_Document* )
                                                ixmlNode_getFirstChild
                                                (nodeptr), tagName);
        if(rtElement == NULL) {
            rtElement = ixmlDocument_getElementById(( IXML_Document* )
                                                    ixmlNode_getNextSibling
                                                    (nodeptr),
                                                    tagName);
        }
    }

    return rtElement;
}
