#!/bin/sh
rm /tmp/oops.tar
