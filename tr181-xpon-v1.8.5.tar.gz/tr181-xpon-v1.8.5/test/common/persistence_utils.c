/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _GNU_SOURCE
/* Related header */
#include "persistence_utils.h"

/* System headers */
#include <ftw.h>    /* nftw() */
#include <stdio.h>  /* remove() */
#include <unistd.h> /* access() */

/* Other libraries' headers */

/* Own headers */
#include "test_constants.h" /* STORAGE_DIR */
#include "xpon_trace.h"

#undef ME
#define ME "runtest"


static int unlink_cb(const char* fpath, const struct stat* sb, int typeflag, struct FTW* ftwbuf) {
    (void) sb;
    (void) typeflag;

    /* Do not remove the top-level folder */
    if(ftwbuf->level == 0) {
        return 0;
    }

    SAH_TRACEZ_DEBUG(ME, "Removing %s", fpath);
    return remove(fpath);
}

/**
 * Remove all files in STORAGE_DIR.
 */
void remove_persistent_files(void) {
    bool exists = (access(STORAGE_DIR, F_OK) == 0);
    when_false_trace(exists, exit, ERROR, "%s does not exist", STORAGE_DIR);

    bool permissions_ok = (access(STORAGE_DIR, R_OK | W_OK | X_OK) == 0);
    when_false_trace(permissions_ok, exit, ERROR, "%s does not have expected permissions",
                     STORAGE_DIR);

    const int rc = nftw(STORAGE_DIR, unlink_cb, 64, FTW_DEPTH | FTW_PHYS);
    when_failed_trace(rc, exit, ERROR, "Failed to remove contents of %s", STORAGE_DIR);

exit:
    return;
}

