
#include <string.h>

#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "device_list.h"
#include "helpers.h"
#include "mod_usb_filter.h"

static amxc_llist_t* usb_device_list = NULL;
static amxc_llist_t* allowed_usb_device_list = NULL;


/**
 * @brief Get list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @return Pointer to device structure list.
 */
amxc_llist_t* get_list(device_type_t type) {
    amxc_llist_t* list = NULL;

    if(type == DEVICE) {
        list = usb_device_list;
    } else if(type == ALLOWED_DEVICE) {
        list = allowed_usb_device_list;
    }

    return list;
}

/**
 * @brief Get amount of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @return Size of device list.
 */
size_t usb_device_list_size(device_type_t type) {
    return amxc_llist_size(get_list(type));
}

/**
 * @brief Initialize list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 */
void usb_device_list_init(device_type_t type) {
    amxc_llist_t* list = get_list(type);

    if(list == NULL) {
        if(type == DEVICE) {
            amxc_llist_new(&usb_device_list);
        } else if(type == ALLOWED_DEVICE) {
            amxc_llist_new(&allowed_usb_device_list);
        }
    }
}

/**
 * @brief Cleanup list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 */
void usb_device_list_clean(device_type_t type) {
    amxc_llist_t* list = get_list(type);
    when_false_trace(amxc_llist_size(list) == 0, exit, ERROR, "USB Device list should be emptied before cleaning it up.");

    if(type == DEVICE) {
        amxc_llist_delete(&usb_device_list, NULL);
        usb_device_list = NULL;
    } else if(type == ALLOWED_DEVICE) {
        amxc_llist_delete(&allowed_usb_device_list, NULL);
        allowed_usb_device_list = NULL;
    }

exit:
    return;
}

static void usb_device_list_delete_item(amxc_llist_it_t* it) {
    usb_device_list_entry_t* entry = amxc_container_of(it, usb_device_list_entry_t, it);
    when_null(it, exit);
    amxc_llist_it_take(it);

    SAFE_DELETE(entry->identifier);
    usb_device_clean(entry->device);
    SAFE_DELETE(entry->device);
    SAFE_DELETE(entry);

exit:
    return;
}

/**
 * @brief Find internal device structure based on identifier.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param identifier SysfsId (for Device) or Alias (for AllowedDevice).
 * @return Pointer to device structure.
 */
usb_device_list_entry_t* usb_device_list_find(device_type_t type, const char* identifier) {
    usb_device_list_entry_t* ret_ptr = NULL;

    when_str_empty(identifier, exit);
    amxc_llist_for_each(it, get_list(type)) {
        usb_device_list_entry_t* entry = amxc_container_of(it, usb_device_list_entry_t, it);
        if(strcmp(identifier, entry->identifier) == 0) {
            ret_ptr = entry;
            break;
        }
    }

exit:
    return ret_ptr;
}

/**
 * @brief Call function for each entry in the device structure list.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param cb Function to be called.
 * @param priv Private data that is passed to the callback function.
 */
void usb_device_list_foreach(device_type_t type, usb_device_action_cb_t cb, void* priv) {
    amxc_llist_for_each(it, get_list(type)) {
        usb_device_list_entry_t* entry = amxc_container_of(it, usb_device_list_entry_t, it);
        cb(type, entry, priv);
    }
}

/**
 * @brief Remove internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param identifier SysfsId (for Device) or Alias (for AllowedDevice).
 * @return 0 on succes, -1 otherwise.
 */
int usb_device_list_delete(device_type_t type, const char* identifier) {
    int retval = -1;

    when_str_empty(identifier, exit);
    amxc_llist_for_each(it, get_list(type)) {
        usb_device_list_entry_t* entry = amxc_container_of(it, usb_device_list_entry_t, it);
        if(strcmp(identifier, entry->identifier) == 0) {
            usb_device_list_delete_item(it);
            retval = 0;
            break;
        }
    }

exit:
    return retval;
}

/**
 * @brief Add an internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param template_object Template object of the Device Object.
 * @param args Hashtable containing device settings.
 * @return Pointer to device structure.
 */
usb_device_list_entry_t* usb_device_list_add(device_type_t type, amxd_object_t* template_object, amxc_var_t* args) {
    amxc_llist_t* list = get_list(type);
    usb_device_list_entry_t* entry = NULL;
    const char* identifier = NULL;

    when_true_trace(amxc_var_is_null(args), exit, ERROR, "The given args parameter is invalid");
    identifier = (type == DEVICE) ? GET_CHAR(args, "SysfsId") : GET_CHAR(args, "Alias");
    when_null_trace(identifier, exit, ERROR, "bad input %s value", type == DEVICE ? "SysfsId" : "Alias");

    when_false_trace(usb_device_list_find(type, identifier) == NULL, exit, ERROR, "there is already a USB Device struct in the list");

    entry = (usb_device_list_entry_t*) calloc(1, sizeof(usb_device_list_entry_t));
    when_null_trace(entry, exit, ERROR, "Failed to execute calloc");

    entry->identifier = strdup(identifier);
    entry->device = create_usb_device(type, template_object, args);

    amxc_llist_append(list, &(entry->it));

exit:
    return entry;
}

/**
 * @brief Get list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 * @return Size of interface list.
 */
size_t usb_interface_list_size(usb_device_t* device) {
    return amxc_llist_size(device->interface_list);
}

/**
 * @brief Initialize list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_interface_list_init(usb_device_t* device) {
    if(device->interface_list == NULL) {
        amxc_llist_new(&device->interface_list);
    }
}

/**
 * @brief Remove an interface from the list of interfaces for an internal device structure.
 *
 * @param it iterator of the interface list item that needs to be removed.
 */
void usb_interface_list_delete_item(amxc_llist_it_t* it) {
    usb_interface_list_entry_t* entry = amxc_container_of(it, usb_interface_list_entry_t, it);
    when_null(it, exit);
    amxc_llist_it_take(it);

    usb_device_interface_clean(&entry->interface);
    SAFE_DELETE(entry);

exit:
    return;
}

/**
 * @brief Cleanup the list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_interface_list_clean(usb_device_t* device) {
    amxc_llist_for_each(it, device->interface_list) {
        usb_interface_list_delete_item(it);
    }

    when_false_trace(usb_interface_list_size(device) == 0, exit, ERROR, "USB Interface list should be emptied before cleaning it up.");

    amxc_llist_delete(&device->interface_list, NULL);

exit:
    return;
}

/**
 * @brief Remove an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return 0 on succes, -1 otherwise.
 */
int usb_interface_list_delete(usb_device_t* device, usb_device_interface_t* interface) {
    return usb_interface_list_delete_by_values(device,
                                               interface->interface_class,
                                               interface->interface_subclass,
                                               interface->interface_protocol);
}

/**
 * @brief Remove an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface_class Interface Class.
 * @param interface_subclass Interface SubClass.
 * @param interface_protocol Interface Protocol.
 * @return 0 on succes, -1 otherwise.
 */
int usb_interface_list_delete_by_values(usb_device_t* device,
                                        const char* interface_class,
                                        const char* interface_subclass,
                                        const char* interface_protocol) {
    int retval = -1;

    when_null(device, exit);
    when_null(interface_class, exit);
    when_null(interface_protocol, exit);
    when_null(interface_subclass, exit);

    amxc_llist_for_each(it, device->interface_list) {
        usb_interface_list_entry_t* entry = amxc_container_of(it, usb_interface_list_entry_t, it);
        if(((strcmp(entry->interface.interface_class, interface_class) == 0) &&
            (strcmp(entry->interface.interface_protocol, interface_protocol) == 0) &&
            (strcmp(entry->interface.interface_subclass, interface_subclass) == 0))) {
            usb_interface_list_delete_item(it);
            retval = 0;
            break;
        }
    }

exit:
    return retval;
}

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_find(usb_device_t* device, usb_device_interface_t* interface) {
    return usb_interface_list_find_by_values(device,
                                             interface->interface_class,
                                             interface->interface_subclass,
                                             interface->interface_protocol);
}

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface_class Interface Class.
 * @param interface_subclass Interface SubClass.
 * @param interface_protocol Interface Protocol.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_find_by_values(usb_device_t* device,
                                                              const char* interface_class,
                                                              const char* interface_subclass,
                                                              const char* interface_protocol) {
    usb_interface_list_entry_t* ret_ptr = NULL;

    when_null(device, exit);
    when_null(interface_class, exit);
    when_null(interface_protocol, exit);
    when_null(interface_subclass, exit);

    amxc_llist_for_each(it, device->interface_list) {
        usb_interface_list_entry_t* entry = amxc_container_of(it, usb_interface_list_entry_t, it);
        if(((strcmp(entry->interface.interface_class, interface_class) == 0) &&
            (strcmp(entry->interface.interface_protocol, interface_protocol) == 0) &&
            (strcmp(entry->interface.interface_subclass, interface_subclass) == 0))) {
            ret_ptr = entry;
            break;
        }
    }

exit:
    return ret_ptr;
}

/**
 * @brief Add an interface to an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_add(usb_device_t* device, usb_device_interface_t* interface) {
    usb_interface_list_entry_t* entry = NULL;
    when_null(device, exit);
    when_false_trace(usb_interface_list_find(device, interface) == NULL, exit, ERROR, "there is already a USB Interface struct in the list");

    entry = (usb_interface_list_entry_t*) calloc(1, sizeof(usb_interface_list_entry_t));
    when_null_trace(entry, exit, ERROR, "Failed to execute calloc");

    entry->interface.interface_class = strdup(interface->interface_class);
    entry->interface.interface_subclass = strdup(interface->interface_subclass);
    entry->interface.interface_protocol = strdup(interface->interface_protocol);
    amxc_llist_append(device->interface_list, &(entry->it));

exit:
    return entry;
}

/**
 * @brief Add an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param parameters Hashtable containing interface parameters.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_add_by_parameters(usb_device_t* device, const amxc_var_t* const parameters) {
    usb_interface_list_entry_t* entry = NULL;
    char* intf_class = NULL;
    char* intf_subclass = NULL;
    char* intf_protocol = NULL;

    when_true_trace(amxc_var_is_null(parameters), exit, ERROR, "The given parameters parameter is invalid");

    intf_class = set_hex_value(GET_CHAR(parameters, "InterfaceClass"));
    intf_subclass = set_hex_value(GET_CHAR(parameters, "InterfaceSubClass"));
    intf_protocol = set_hex_value(GET_CHAR(parameters, "InterfaceProtocol"));
    when_false_trace(usb_interface_list_find_by_values(device, intf_class, intf_subclass, intf_protocol) == NULL, exit, ERROR, "there is already a USB Interface struct in the list");

    entry = (usb_interface_list_entry_t*) calloc(1, sizeof(usb_interface_list_entry_t));
    if(entry == NULL) {
        SAFE_DELETE(intf_class);
        SAFE_DELETE(intf_subclass);
        SAFE_DELETE(intf_protocol);
        SAH_TRACEZ_ERROR(ME, "Failed to execute calloc");
        goto exit;
    }

    entry->interface.interface_class = intf_class;
    entry->interface.interface_subclass = intf_subclass;
    entry->interface.interface_protocol = intf_protocol;
    amxc_llist_append(device->interface_list, &(entry->it));

exit:
    return entry;
}
