#ifndef __FILTER_H__
#define __FILTER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "device_list.h"

/**
 * @brief Set internal state for allowing all devices or not
 *
 * @param allow boolean with new state
 */
void set_allow_all_devices(bool allow);

/**
 * @brief Update the usb devices allowed parameter after a change in the filters.
 */
void allow_devices_after_allowed_change(void);

/**
 * @brief Update the usb devices allowed paramter after a change in the device itself or one of their interfaces.
 *
 * @param entry Internal device structure.
 */
void allow_changed_device(usb_device_list_entry_t* entry);

#ifdef __cplusplus
}
#endif

#endif // __FILTER_H__
