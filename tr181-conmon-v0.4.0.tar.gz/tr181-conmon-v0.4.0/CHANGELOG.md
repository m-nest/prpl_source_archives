# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release master_v0.6.3 - 2025-06-18(06:26:13 +0000)

### Other

- Issue: HOP-10147 - Write readme for internal conmon

## Release master_v0.6.2 - 2025-05-23(14:27:45 +0000)

### Other

- Issue: HOP-8335 - [neighbordisco] problem in backoff time for NS messages
- Issue: HOP-8338 - [neighbordisco] problem in retry algo when failure

## Release master_v0.6.1 - 2025-05-22(10:50:31 +0000)

### Other

- Issue: HOP-9344 - [tr181-conmon] empty Type should not be allowed

## Release master_v0.6.0 - 2025-03-31(09:47:47 +0000)

### Other

- Issue: HOP-9259 [Plugin][tr181-device] Jenkins tests are failing with prefix changes done

## Release master_v0.5.1 - 2025-03-27(11:42:14 +0000)

### Other

- Issue: HOP-9224 [INTERNAL] [Plugin][tr181-conmon] Jenkins tests are failing with prefix changes done

## Release master_v0.5.0 - 2025-03-21(09:20:46 +0000)

### Other

- Issue: HOP-8989 [INTERNAL] [Plugin][tr181-conmon] Replace prefix X_PRPL-COM by X_PRLPWARE-COM within global variable call

## Release master_v0.4.6 - 2024-10-04(15:02:54 +0000)

### Other

- Issue: HOP-6587 [Security][AppArmor] Apparmor must be available on PRPL builds
- Issue: HOP-7568 [TR181 ConMon] Wrong cast used on data in netmodel queries

## Release master_v0.4.6 - 2024-09-10(07:22:38 +0000)

### Other

- Issue: HOP-6587 [Security][AppArmor] Apparmor must be available on PRPL builds

## Release master_v0.4.5 - 2024-07-29(06:09:04 +0000)

### Other

- Issue: HOP-4680 - [amx] Failing to restart processes with init scripts

## Release master_v0.4.4 - 2024-07-08(07:10:08 +0000)

## Release master_v0.4.3 - 2024-06-21(08:44:20 +0000)

### Other

- Issue: HOP-6586 amx plugin should not run as root user

## Release master_v0.4.2 - 2024-05-24(12:35:33 +0000)

### Other

- Issue: HOP-6658 Sevice mapping vendor prefix

## Release master_v0.4.1 - 2024-04-10(10:04:31 +0000)

### Changes

- Issue: HOP-6338 Make amxb timeouts configurable

## Release master_v0.4.0 - 2024-02-05(16:22:45 +0000)

### New

- Issue: HOP-5396 Add tr181-device proxy odl files to components

## Release master_v0.3.0 - 2024-01-17(09:34:23 +0000)

### New

- Issue: HOP-5396 Add tr181-device proxy odl files to components

## Release master_v0.2.1 - 2023-10-13(14:12:02 +0000)

### Changes

- Issue: HOP-4560  All applications using sahtrace logs should use default log levels

## Release master_v0.2.0 - 2023-10-04(08:17:01 +0000)

### New

- Issue: HOP-3900  [amx][conmon] ConMon must support arp(ipv4) and icmpv6(ipv6)

## Release master_v0.1.0 - 2023-07-24(15:43:52 +0000)

### New

- Issue: HOP-2639 [amx][conmon] ConMon must be available as a prpl plugin

