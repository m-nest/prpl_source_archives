/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <stdio.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_sahtrace.h>
#include <amxut/amxut_verify.h>

#include <amxrt/amxrt.h>

#include <debug/sahtrace.h>

#include "dmm.h"
#include "dmm_trie.h"
#include "dmm_trie_translator.h"

#include "trie_translator.h"

#include <fcntl.h>
#include <yajl/yajl_parse.h>
#include <yajl/yajl_gen.h>
#include <amxj/amxj_variant.h>

// Uncomment for debug output
// #define PRINT_DEBUG_TEST_OUTPUT

static amxc_var_t* read_json_from_file(const char* filename) {
    variant_json_t* reader = NULL;
    amxc_var_t* data = NULL;

    amxj_reader_new(&reader);

    int fd = open(filename, O_RDONLY);
    assert_int_not_equal(fd, -1);

    int read = amxj_read(reader, fd);
    assert_int_not_equal(read, -1);

    amxj_reader_state_t reader_state;
    while((reader_state = amxj_reader_get_state(reader)) == amxj_reader_parsing) {
        read = amxj_read(reader, fd);
        assert_int_not_equal(read, -1);
    }
    data = amxj_reader_result(reader);

    amxj_reader_delete(&reader);
    close(fd);

    assert_non_null(data);

    return data;
}

void check_response_translator(const char* json_config, int(translator_f)(amxc_var_t*)) {
    amxc_var_t* json_config_parsed = read_json_from_file(json_config);

    amxc_var_t* hide_mapping = GET_ARG(json_config_parsed, "hide");
    assert_non_null(hide_mapping);

    amxc_var_t* rename_mapping = GET_ARG(json_config_parsed, "rename");
    assert_non_null(rename_mapping);

#ifdef PRINT_DEBUG_TEST_OUTPUT
    printf("Hide:\n");
    amxc_var_dump_stream(hide_mapping, stdout);
    printf("Rename:\n");
    amxc_var_dump_stream(rename_mapping, stdout);
#endif

    amxc_var_t* config = amxrt_get_config();
    assert_non_null(config);
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_HIDE, hide_mapping, AMXC_VAR_FLAG_DEFAULT), 0);
    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_RENAME, rename_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    assert_int_equal(init_tree(), 0);
    assert_int_equal(parse_mapping(), 0);

#ifdef PRINT_DEBUG_TEST_OUTPUT
    print_trees();
#endif

    amxc_var_t* translations = GET_ARG(json_config_parsed, "translations");
    assert_non_null(translations);

    amxc_var_for_each(translation, translations) {
        const amxc_var_t* original = GET_ARG(translation, "original");
        assert_non_null(original);

        amxc_var_t* expected = GET_ARG(translation, "expected");
        assert_non_null(expected);

        amxc_var_t original_copy;
        amxc_var_init(&original_copy);
        amxc_var_copy(&original_copy, original);

        assert_int_equal(translator_f(&original_copy), 0);

        assert_true(amxut_verify_variant_equal_check((LargestIntegralType) & original_copy, (LargestIntegralType) expected));

        amxc_var_clean(&original_copy);
    }

    amxc_var_set_type(config, AMXC_VAR_ID_NULL);
    amxc_var_delete(&json_config_parsed);

    clean_tree();
}

int test_setup(void** state) {
    amxut_sahtrace_setup(state);
    sahTraceSetLevel(TRACE_LEVEL_CALLSTACK);

    return 0;
}

int test_teardown(void** state) {
    amxut_sahtrace_teardown(state);

    return 0;
}

void test_can_translate_get_supported_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_supported/no_mapping.json", translate_get_supported_response);
}

void test_can_translate_get_supported_object(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_supported/object.json", translate_get_supported_response);
}

void test_can_translate_get_supported_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_supported/table.json", translate_get_supported_response);
}

void test_can_translate_get_supported_terminals(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_supported/terminals.json", translate_get_supported_response);
}


void test_can_translate_get_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get/no_mapping.json", translate_get_response);
}

void test_can_translate_get_object(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get/object.json", translate_get_response);
}

void test_can_translate_get_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get/table.json", translate_get_response);
}

void test_can_translate_set_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/set/no_mapping.json", translate_set_response);
}

void test_can_translate_set_object(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/set/object.json", translate_set_response);
}

void test_can_translate_set_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/set/table.json", translate_set_response);
}

void test_can_translate_add_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/add/no_mapping.json", translate_add_response);
}

void test_can_translate_add_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/add/table.json", translate_add_response);
}

void test_can_translate_del_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/del/no_mapping.json", translate_del_response);
}

void test_can_translate_del_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/del/table.json", translate_del_response);
}

void test_can_translate_get_instances_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_instances/no_mapping.json", translate_get_instances_response);
}

void test_can_translate_get_instances_object(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/get_instances/object.json", translate_get_instances_response);
}

void test_can_translate_event_no_mapping(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/event/no_mapping.json", translate_event_response);
}
void test_can_translate_event_object(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/event/object.json", translate_event_response);
}

void test_can_translate_event_table(UNUSED void** state) {
    check_response_translator(TESTDATA_FOLDER "/event/table.json", translate_event_response);
}

int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_can_translate_get_supported_no_mapping),
        cmocka_unit_test(test_can_translate_get_supported_object),
        cmocka_unit_test(test_can_translate_get_supported_table),
        cmocka_unit_test(test_can_translate_get_supported_terminals),
        cmocka_unit_test(test_can_translate_get_no_mapping),
        cmocka_unit_test(test_can_translate_get_object),
        cmocka_unit_test(test_can_translate_get_table),
        cmocka_unit_test(test_can_translate_set_no_mapping),
        cmocka_unit_test(test_can_translate_set_object),
        cmocka_unit_test(test_can_translate_set_table),
        cmocka_unit_test(test_can_translate_add_no_mapping),
        cmocka_unit_test(test_can_translate_add_table),
        cmocka_unit_test(test_can_translate_del_no_mapping),
        cmocka_unit_test(test_can_translate_del_table),
        cmocka_unit_test(test_can_translate_get_instances_no_mapping),
        cmocka_unit_test(test_can_translate_get_instances_object),
        cmocka_unit_test(test_can_translate_event_no_mapping),
        cmocka_unit_test(test_can_translate_event_object),
        cmocka_unit_test(test_can_translate_event_table),
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
