/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>

#include "bulkdata.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_parameter.h"
#include "bulkdata_profile_acl.h"
#include "bulkdata_utils.h"

#define ME "parameter"

const cstring_t types[] = { "NULL", "string", "short", "short", "int", "long", "unsignedShort", "unsignedShort", "unsignedInt", "unsignedLong",
    "float", "double", "boolean", "N/A", "N/A", "N/A", "string", "string", "string", "string", ""};

amxd_object_t* bulkdata_get_parameter_object(amxd_object_t* profile) {
    cstring_t path = amxd_object_get_path(profile, AMXD_OBJECT_NAMED);
    amxd_object_t* obj = amxd_dm_findf(bulkdata_get_dm(), "%s.Parameter.", path);
    free(path);
    return obj;
}

const cstring_t bulkdata_parameter_get_name(amxd_object_t* parameter) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(parameter, "Name"));
}

const cstring_t bulkdata_parameter_get_reference(amxd_object_t* parameter) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(parameter, "Reference"));
}

static bool bulkdata_parameter_refrence_is_wildcard(const char* reference) {
    bool ret = false;
    amxd_path_t ref_path;

    when_null_trace(reference, exit, ERROR, "Reference is NULL");
    amxd_path_init(&ref_path, reference);

    ret = (amxd_path_get_type(&ref_path) == amxd_path_search);

exit:
    amxd_path_clean(&ref_path);
    return ret;
}

static void bulkdata_replace_with_name(const char* name, const char* reference, amxc_string_t* key) {
    if(!reference || !name) {
        return;
    }

    bool is_wildcard = (bulkdata_get_parameter_wild_card_supported() && (strchr(reference, '*') != NULL));

    if(!is_wildcard) {
        amxc_string_replace(key, reference, name, 1);
        /* Add a '.' if the reference is an object */
        if(reference[strlen(reference) - 1] == '.') {
            amxc_string_insert_at(key, strlen(name), ".", 1);
        }
    } else {
        const char* key_path = amxc_string_get(key, 0);
        char* cpy = strdup(reference);
        if(!cpy) {
            return;
        }
        char new_name[512];
        strcpy(new_name, name);
        char* new_name_ptr = &new_name[strlen(new_name)];
        char* tok = strtok(cpy, "*");
        do {
            key_path += strlen(tok);
            *new_name_ptr++ = '.';
            while(*key_path != '.' && *key_path != '\0') {
                *new_name_ptr++ = *key_path;
                key_path++;
            }
        } while((tok = strtok(NULL, "*")));

        if(reference[strlen(reference) - 1] == '.') {
            *new_name_ptr = '\0';
        } else {
            /* Remove extra '.' and format final key */
            *(new_name_ptr - 1) = '\0';
        }

        amxc_string_setf(key, "%s%s", new_name, key_path);

        free(cpy);
    }
}

static void bulkdata_retrieve_parameter_json(amxd_object_t* parameter, amxc_var_t* json) {
    const cstring_t name = NULL;
    const cstring_t reference = NULL;
    amxc_var_t ref_values;
    amxd_path_t reference_obj_path;
    int ret = -1;

    amxc_var_init(&ref_values);

    when_null_trace(parameter, exit, ERROR, "Parameter is NULL");
    SAH_TRACEZ_INFO(ME, "Start listening parameter %s", amxd_object_get_name(parameter, AMXD_OBJECT_NAMED));

    name = bulkdata_parameter_get_name(parameter);
    reference = bulkdata_parameter_get_reference(parameter);
    when_null_trace(reference, exit, ERROR, "Reference is NULL");
    // get the reference object path
    amxd_path_init(&reference_obj_path, reference);

    when_failed_trace(bulkdata_profile_acl_check_permission(parameter), exit, ERROR, "ACL check failed for %s", reference);

    /* Get value */
    /* Set depth to 0 if reference is a parameter, -1 is it's an object */
    bool ref_is_object = (reference[strlen(reference) - 1] == '.');
    ret = amxb_get(amxb_be_who_has_ex(amxd_path_get(&reference_obj_path, AMXD_OBJECT_TERMINATE), true), reference, ref_is_object ? INT32_MAX : 0, &ref_values, 3);
    when_failed_trace(ret, exit, ERROR, "Unable to get value for %s", reference);

    amxc_var_for_each(ref_value, amxc_var_get_first(&ref_values)) {
        const char* key = amxc_var_key(ref_value);
        SAH_TRACEZ_INFO(ME, "key = %s", key);
        amxc_var_for_each(ref_param, ref_value) {
            amxc_string_t key_param_str;
            amxc_string_init(&key_param_str, 0);
            amxc_string_setf(&key_param_str, "%s%s", key, amxc_var_key(ref_param));

            /* Replace reference by name */
            if(name && *name) {
                bulkdata_replace_with_name(name, reference, &key_param_str);
            }

            /* Extract key + value and add it in the report */
            const cstring_t key_param = amxc_string_get(&key_param_str, 0);
            cstring_t value = amxc_var_dyncast(cstring_t, ref_param);
            SAH_TRACEZ_INFO(ME, "%s = %s", key_param, value);
            amxc_var_add_key(cstring_t, json, key_param, value);

            /* Cleanup */
            amxc_string_clean(&key_param_str);
            free(value);
        }
    }

exit:
    /* Cleanup */
    amxd_path_clean(&reference_obj_path);
    amxc_var_clean(&ref_values);
}

static cstring_t bulkdata_replace_search_expr(const char* name, const char* reference, const char* path_from_get_resp, bool ref_is_object) {
    const char* param = NULL;
    amxd_path_t ref_path;
    amxd_path_t get_path;
    amxc_string_t result;
    uint32_t offset = 0;
    uint32_t depth = 0;
    cstring_t result_str = NULL;

    amxd_path_init(&ref_path, reference);
    amxd_path_init(&get_path, path_from_get_resp);
    amxc_string_init(&result, 0);
    amxc_string_setf(&result, "%s.", name);

    when_null(reference, exit);
    when_null(path_from_get_resp, exit);
    when_str_empty(name, exit);

    // Check if path is search expression
    when_false(amxd_path_get_type(&ref_path) == amxd_path_search, exit);

    // Skip index 0, because this is never a search expression
    depth = amxd_path_get_depth(&ref_path);
    for(uint32_t i = 1; i < (depth + 1); i++) {
        char* sub_path = amxd_path_get_at(&ref_path, i);
        if(sub_path == NULL) {
            continue;
        }

        if((sub_path[0] == '*') || (sub_path[0] == '[')) {
            char* index = amxd_path_get_at(&get_path, i - offset);

            amxc_string_appendf(&result, "%s", index);
            // When a wildcard is found, the dot that follows is seen as a separate path element
            offset++;
            free(index);
        }
        free(sub_path);
    }

    param = amxd_path_get_param(&get_path);
    if((true == ref_is_object) && (param != NULL)) {
        amxc_string_appendf(&result, "%s", param);
    }

    amxc_string_trimr(&result, bulkdata_utils_is_dot);
    result_str = strdup(amxc_string_get(&result, 0));

exit:
    amxc_string_clean(&result);
    amxd_path_clean(&ref_path);
    amxd_path_clean(&get_path);
    return result_str;
}

static cstring_t bulkdata_format_name_for_object(const char* name, const char* path_from_get_resp, bool ref_is_object) {
    cstring_t result_str = NULL;
    amxc_string_t result;
    amxd_path_t get_path;

    amxc_string_init(&result, 0);
    amxc_string_setf(&result, "%s.", (name != NULL) ? name : "");
    amxd_path_init(&get_path, path_from_get_resp);

    when_false(ref_is_object, exit);
    when_str_empty(name, exit);
    when_null(path_from_get_resp, exit);

    amxc_string_appendf(&result, "%s", amxd_path_get_param(&get_path));
    result_str = strdup(amxc_string_get(&result, 0));

exit:
    amxc_string_clean(&result);
    amxd_path_clean(&get_path);
    return result_str;
}

static cstring_t bulkdata_generate_report_reference_name(const char* name, const char* reference, const char* path_from_get_resp, bool ref_is_object) {
    cstring_t result_str = NULL;

    // Reference is wildcard
    result_str = bulkdata_replace_search_expr(name, reference, path_from_get_resp, ref_is_object);
    when_true((result_str != NULL), exit);

    // Reference points to an object
    result_str = bulkdata_format_name_for_object(name, path_from_get_resp, ref_is_object);
    when_true((result_str != NULL), exit);

    // else
    if((bulkdata_parameter_refrence_is_wildcard(reference)) || (NULL == name)) {
        result_str = strdup(path_from_get_resp);
    } else {
        result_str = strdup(name);
    }

exit:
    return result_str;
}

static void bulkdata_retrieve_parameter_csv(amxd_object_t* parameter, amxc_var_t* csv) {
    const cstring_t name = NULL;
    const cstring_t reference = NULL;
    amxc_var_t ref_values;
    amxd_path_t reference_obj_path;
    int ret = -1;

    amxc_var_init(&ref_values);

    when_null_trace(parameter, exit, ERROR, "Parameter is NULL");
    SAH_TRACEZ_INFO(ME, "Start listening parameter %s", amxd_object_get_name(parameter, AMXD_OBJECT_NAMED));
    name = bulkdata_parameter_get_name(parameter);
    reference = bulkdata_parameter_get_reference(parameter);
    when_null(reference, exit);
    // get the reference object path
    amxd_path_init(&reference_obj_path, reference);

    when_failed_trace(bulkdata_profile_acl_check_permission(parameter), exit, ERROR, "ACL check failed for %s", reference);

    /* Set depth to 0 if reference is a parameter, -1 is it's an object */
    bool ref_is_object = (reference[strlen(reference) - 1] == '.');
    ret = amxb_get(amxb_be_who_has_ex(amxd_path_get(&reference_obj_path, AMXD_OBJECT_TERMINATE), true), reference, ref_is_object ? INT32_MAX : 0, &ref_values, 3);
    when_failed_trace(ret, exit, ERROR, "Unable to get value for %s", reference);

    amxc_var_for_each(ref_value, amxc_var_get_first(&ref_values)) {
        const char* key = amxc_var_key(ref_value);
        SAH_TRACEZ_INFO(ME, "Fetch data for key = %s", key);
        amxc_var_for_each(ref_param, ref_value) {
            amxc_var_t* entry = NULL;
            const cstring_t key_param = NULL;
            cstring_t value = NULL;
            const cstring_t type = NULL;
            cstring_t formatted_name = NULL;
            amxc_string_t key_param_str;

            amxc_string_init(&key_param_str, 0);
            amxc_string_setf(&key_param_str, "%s%s", key, amxc_var_key(ref_param));

            /* Replace reference by name */
            formatted_name = bulkdata_generate_report_reference_name(name, reference, amxc_string_get(&key_param_str, 0), ref_is_object);

            /* Extract key + value and add it in the report */
            key_param = amxc_string_get(&key_param_str, 0);
            value = amxc_var_dyncast(cstring_t, ref_param);
            type = types[amxc_var_type_of(ref_param)];
            SAH_TRACEZ_NOTICE(ME, "\tentry %s : %s = %s | %s", amxc_string_get(&key_param_str, 0), formatted_name, value, type);

            entry = amxc_var_add_key(amxc_htable_t, csv, key_param, NULL);
            amxc_var_add_key(cstring_t, entry, "value", value);
            amxc_var_add_key(cstring_t, entry, "type", type);
            amxc_var_add_key(cstring_t, entry, "paramName", formatted_name);

            /* Cleanup */
            amxc_string_clean(&key_param_str);
            free(value);
            free(formatted_name);
        }
    }

exit:
    /* Cleanup */
    amxd_path_clean(&reference_obj_path);
    amxc_var_clean(&ref_values);
}

static int bulkdata_retrieve_parameters_in_json_callback(UNUSED amxd_object_t* parameters,
                                                         amxd_object_t* parameter,
                                                         void* priv) {
    amxc_var_t* json = priv;
    bulkdata_retrieve_parameter_json(parameter, json);
    return 0;
}

static int bulkdata_retrieve_parameters_in_csv_callback(UNUSED amxd_object_t* parameters,
                                                        amxd_object_t* parameter,
                                                        void* priv) {
    amxc_var_t* csv = priv;
    bulkdata_retrieve_parameter_csv(parameter, csv);
    return 0;
}

amxc_var_t* bulkdata_retrieve_parameters(amxd_object_t* profile, profile_encoding encoding) {
    SAH_TRACEZ_INFO(ME, "Start listening parameters");
    amxd_object_t* parameters = bulkdata_get_parameter_object(profile);
    /* Stop collection if there's no Parameter instance */
    if(!amxd_object_get_instance_count(parameters)) {
        SAH_TRACEZ_INFO(ME, "No parameter instance");
        return NULL;
    }
    amxc_var_t* data;
    amxc_var_new(&data);
    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);

    if(PROFILE_ENCODING_JSON == encoding) {
        amxd_object_for_all(parameters, "*.", bulkdata_retrieve_parameters_in_json_callback, data);
    } else if(PROFILE_ENCODING_CSV == encoding) {
        amxd_object_for_all(parameters, "*.", bulkdata_retrieve_parameters_in_csv_callback, data);
    }
    return data;
}
