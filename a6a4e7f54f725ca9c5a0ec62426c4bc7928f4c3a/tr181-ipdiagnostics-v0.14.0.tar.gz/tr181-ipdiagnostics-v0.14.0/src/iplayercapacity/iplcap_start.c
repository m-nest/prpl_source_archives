/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <amxc/amxc_lqueue.h>
#include <amxp/amxp_signal.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ip_diagnostics_priv.h"
#include "ip_diagnostics.h"
#include "iplcap.h"
#include "priv_iplcap.h"
#include "config.h"

#define ME "ipd-iplcap-start"

/**
 * @brief Context passed to a deferred completion check.
 *
 * @details Holds the callback and parameters needed to invoke the
 *          final check from the amxp event loop.
 */
typedef struct {
    void (* check_fn)(int, void*);   /**< @brief Completion callback to invoke. */
    int fd;                          /**< @brief File descriptor associated with the test (or 0/negative if none). */
    void* user;                      /**< @brief Optional user data passed to the callback. */
} iplcap_deferred_check_t;

/**
 * @brief Deferred function that triggers the final completion check.
 *
 * @details Called by the amxp signal manager. Invokes the stored
 *          completion callback and releases the allocated context.
 *
 * @param[in] data Unused deferred data.
 * @param[in] priv Opaque pointer to an iplcap_deferred_check_t context.
 */
static void ipd_iplcap_deferred_check(const amxc_var_t* const data, void* const priv) {
    (void) data;
    iplcap_deferred_check_t* ctx = (iplcap_deferred_check_t*) priv;
    if((ctx != NULL) && (ctx->check_fn != NULL)) {
        ctx->check_fn(ctx->fd, ctx->user);
    }
    if(ctx != NULL) {
        free(ctx);
    }
}

/**
 * @brief Start the IPLayerCapacity test and connect process monitoring.
 *
 * @details Launches the module-side start RPC, wires the provided check
 *          callback to the process output when the test is ongoing, or
 *          schedules a deferred final check when the test already finished.
 *
 * @param[in]  sch            Scheduler state for the running test.
 * @param[in]  check_function Callback invoked when output/status is available.
 * @param[in]  mod_args       Input arguments for the module RPC.
 * @param[out] mod_ret        Output arguments populated by the module RPC.
 *
 * @return 0 on success, -1 on failure.
 */
static int ipd_iplcap_mod_start(ipd_iplcap_scheduler_t* sch,
                                void (* check_function)(int, void*),
                                amxc_var_t* mod_args,
                                amxc_var_t* mod_ret) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* ipd_iplcap_object = NULL;
    amxc_var_t* fd_var = NULL;
    amxc_var_t* fd_err_var = NULL;
    amxc_var_t* pid_var = NULL;
    amxc_var_t* status_var = NULL;
    const cstring_t status_str = NULL;
    int rv = -1;
    int32_t fd = -1;
    int32_t fd_err = -1;
    int32_t pid = -1;

    amxc_var_new(&status_var);
    amxc_var_set(cstring_t, status_var, IPLCAP_STATUS_ERR_OTHER);

    ipd_iplcap_object = ipd_get_iplcap_object();

    //First check if a iplcap test is already running
    //Fetch the fd from the datamodel
    fd = ipd_tool_get_dm_fd(IPLCAP);

    if(fd > 0) {
        sch->prev_test = true;
        check_function(fd, NULL);
        if(sch->fd_stdout > 0) {
            ipd_iplcap_stop(sch);
        }
        sch->prev_test = false;
    }

    rv = ipd_execute_ctrl_function_cb(ipd_iplcap_object, IPD_IPLCAP_TEST_START, mod_args, mod_ret);
    fd_var = GETP_ARG(mod_ret, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_FD_STDOUT);
    fd_err_var = GETP_ARG(mod_ret, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_FD_STDERR);
    pid_var = GETP_ARG(mod_ret, IPLCAP_RET_KEY_PROC "."IPLCAP_RET_KEY_PROC_PID);

    if((rv != 0) || (fd_var == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Failed to execute function %s. Return value: %d", IPD_IPLCAP_TEST_START, rv);
        amxc_var_set_pathf(mod_ret, status_var, DEFAULT_SET_PATH_FLAGS, IPLCAP_RET_KEY_DST);
        goto exit;
    }

    fd = GET_INT32(fd_var, NULL);
    fd_err = GET_INT32(fd_err_var, NULL);
    pid = GET_INT32(pid_var, NULL);

    if(fd <= 0) {
        SAH_TRACEZ_ERROR(ME, "Invalid file descriptor returned: %d", fd);
        amxc_var_set_pathf(mod_ret, status_var, DEFAULT_SET_PATH_FLAGS, IPLCAP_RET_KEY_DST);
        goto exit;
    }

#ifndef IP_DIAGNOSTICS_UNIT_TEST
    amxc_var_move(mod_args, mod_ret);
    ipd_execute_ctrl_function_cb(ipd_iplcap_object, IPD_IPLCAP_TEST_CHECK, mod_args, mod_ret);
#endif

    status_str = GET_CHAR(mod_ret, IPLCAP_RET_KEY_DST);

    if(!str_empty(status_str) && (strcmp(status_str, IPLCAP_STATUS_NOT_COMPLETE) == 0)) {
        sch->fd_stderr = fd_err;
        sch->fd_stdout = fd;
        sch->pid = pid;
        amxo_connection_add(ipd_get_parser(), fd, check_function, NULL, AMXO_CUSTOM, NULL);
        amxc_var_add_key(bool, mod_ret, "ConnectionAdded", true);
    } else {
        SAH_TRACEZ_INFO(ME, "Scheduling final deferred check for immediate update");
        iplcap_deferred_check_t* ctx = calloc(1, sizeof(*ctx));
        if(ctx != NULL) {
            ctx->check_fn = check_function;
            ctx->fd = fd; // handler should be able to handle no-fd if needed
            ctx->user = NULL;
            amxp_sigmngr_deferred_call(NULL, ipd_iplcap_deferred_check, NULL, ctx);
        }
        amxc_var_add_key(bool, mod_ret, "ConnectionAdded", false);
    }
    rv = 0;
exit:
    amxc_var_delete(&status_var);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Validate parameters against function and object definitions.
 *
 * @details Applies default values where defined and executes registered
 *          validation callbacks on the current object and its children.
 *
 * @param[in]     object  Current data model object.
 * @param[in]     func    Function definition providing argument metadata.
 * @param[in,out] params  Parameters to validate and complete with defaults.
 *
 * @return amxd_status_ok on success, error code otherwise.
 */
static amxd_status_t ipd_iplcap_validate_params(amxd_object_t* object, amxd_function_t* func, amxc_var_t* params) {
    amxd_status_t stat = amxd_status_ok;
    amxd_param_t* param_def = NULL;
    const char* param_name = NULL;
    amxc_var_t* retval = NULL;

    amxc_var_new(&retval);

    when_null_trace(object, exit, ERROR, "Object is NULL");
    when_null_trace(func, exit, ERROR, "Function is NULL");
    when_null_trace(params, exit, ERROR, "Params is NULL");

    // First validate parameters of current object
    amxc_llist_for_each(it, &(object->parameters)) {
        param_def = amxc_llist_it_get_data(it, amxd_param_t, it);
        param_name = amxd_param_get_name(param_def);

        // Check if parameter is in the function's input parameters
        amxd_func_arg_t* arg = amxd_function_get_arg(func, param_name);
        if(arg == NULL) {
            continue;
        }

        amxc_var_t* value = amxc_var_get_key(params, param_name, AMXC_VAR_FLAG_DEFAULT);

        // If parameter is not provided and has a default value, set it
        if((value == NULL) && !amxc_var_is_null(&param_def->value)) {
            // Create a new variant for the parameter value
            amxc_var_t* new_value = NULL;
            amxc_var_new(&new_value);

            // Copy the default value to the new variant
            stat = amxc_var_copy(new_value, &param_def->value);
            when_failed_trace(stat, exit, ERROR, "Failed to copy default value for parameter %s", param_name);
            amxc_var_set_key(params, param_name, new_value, AMXC_VAR_FLAG_DEFAULT);
            value = amxc_var_get_key(params, param_name, AMXC_VAR_FLAG_DEFAULT);
        }

        // Validate the parameter using its registered validation callbacks
        amxc_llist_for_each(cb_it, &(param_def->cb_fns)) {
            amxd_dm_cb_t* cb_fn = amxc_llist_it_get_data(cb_it, amxd_dm_cb_t, it);
            if((cb_fn->reason != action_param_validate) ||
               (cb_fn->fn == NULL) ||
               (!cb_fn->enable)) {
                continue;
            }
            stat = cb_fn->fn(object, param_def, action_param_validate, value, retval, cb_fn->priv);
            when_failed_trace(stat, exit, ERROR, "Validation failed for parameter %s with status: %d", param_name, stat);
        }
    }

    // Then recursively validate parameters of child objects
    amxd_object_for_each(child, it, object) {
        amxd_object_t* child_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        const char* object_name = amxd_object_get_name(child_obj, AMXD_OBJECT_NAMED);

        // Check if the object is read-only
        if(amxd_object_is_attr_set(child_obj, amxd_oattr_read_only)) {
            // For read-only objects, set the object value to 0
            amxc_var_t* aux_val = GET_ARG(params, object_name);
            if(aux_val != NULL) {
                stat = amxc_var_set(uint32_t, aux_val, 0);
                when_failed_trace(stat, exit, ERROR, "Failed to set default value for read-only object %s", object_name);
            }
        } else if(amxd_object_is_attr_set(child_obj, amxd_oattr_protected)) {
            continue;
        } else {
            // For non-read-only (writeable) objects, validate their parameters recursively
            stat = ipd_iplcap_validate_params(child_obj, func, params);
            when_failed_trace(stat, exit, ERROR, "Failed to validate parameters for child object %s", object_name);
        }
    }

    stat = amxd_status_ok;

exit:
    amxc_var_delete(&retval);
    return stat;
}

/**
 * @brief Validate IPLayerCapacity parameters using the data model.
 *
 * @param[in,out] params Parameters to validate.
 *
 * @return amxd_status_ok when parameters are valid, error code otherwise.
 */
static amxd_status_t ipd_iplcap_validate(amxc_var_t* params) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t stat = amxd_status_unknown_error;
    amxd_object_t* ipd_object = NULL;
    amxd_function_t* func = NULL;

    // Get the IPLayerCapacityMetrics object
    ipd_object = ipd_get_iplcap_object();
    when_null_trace(ipd_object, exit, ERROR, "Failed to fetch IPLayerCapacityMetrics object");

    // Get the function definition
    func = amxd_object_get_function(ipd_get_root_object(), "IPLayerCapacity");
    if(func == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to get IPLayerCapacity function definition");
        stat = amxd_status_function_not_found;
        goto exit;
    }
    // Start recursive validation
    stat = ipd_iplcap_validate_params(ipd_object, func, params);

exit:
    SAH_TRACEZ_OUT(ME);
    return stat;
}

amxd_status_t ipd_iplcap_start(void (* check_function)(int, void*),
                               ipd_iplcap_scheduler_t* sch,
                               amxc_var_t* args,
                               amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    const cstring_t key_result = IPD_IPLCAP_CONFIG;
    amxd_status_t ret_status = amxd_status_unknown_error;
    amxd_object_t* ipd_object = NULL;
    amxd_object_t* ipd_results = NULL;
    amxc_var_t* mod_args = NULL;
    amxc_var_t* mod_ret = NULL;
    int ret_val = -1;

    amxc_var_new(&mod_args);
    amxc_var_set_type(mod_args, AMXC_VAR_ID_HTABLE);
    amxc_var_new(&mod_ret);
    amxc_var_set_type(mod_ret, AMXC_VAR_ID_HTABLE);

    ret_status = amxd_status_object_not_found;
    ipd_object = ipd_get_root_object();
    ipd_results = amxd_object_findf(ipd_object, "%s.", key_result);
    when_null_trace(ipd_results, exit, ERROR, "Failed to fetch object IPDiagnostics.%s. from datamodel.", key_result);

    amxc_var_move(mod_args, args);
    ret_status = amxd_status_invalid_arg;
    ret_status = ipd_iplcap_validate(mod_args);
    when_failed_trace(ret_status, exit, ERROR, "Validation failed, error: %d", ret_status);

    //Start test on the module
    ret_status = amxd_status_deferred;
    ret_val = ipd_iplcap_mod_start(sch, check_function, mod_args, mod_ret);

    if(ret_val != amxd_status_ok) {
        ret_status = amxd_status_unknown_error;
        SAH_TRACEZ_ERROR(ME, "Could not launch the test properly, error: %s", GET_CHAR(mod_ret, IPLCAP_RET_KEY_DST));
    }

    ipd_iplcap_save_result_to_dm(mod_ret, ipd_results);
    if(GET_BOOL(mod_ret, "ConnectionAdded") == false) {
        ipd_iplcap_save_status_to_dm(mod_ret, ipd_results);
    }
exit:
    amxc_var_move(ret, mod_ret);
    ipd_filter_ret(ret, true, IPLCAP);
    amxc_var_delete(&mod_args);
    amxc_var_delete(&mod_ret);
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}
