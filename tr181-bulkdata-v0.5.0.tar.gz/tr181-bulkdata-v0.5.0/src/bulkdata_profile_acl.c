/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>
#include "bulkdata.h"
#include "bulkdata_utils.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_parameter.h"
#include "bulkdata_profile_json_encoding.h"
#include "bulkdata_profile_csv_encoding.h"
#include "bulkdata_profile_mqtt.h"
#include "bulkdata_profile_http.h"
#include "bulkdata_profile_acl.h"

#define ME "acl"

static cstring_t bulkdata_profile_acl_get_controller_id(const cstring_t controller) {
    amxc_var_t ret;
    cstring_t from_id = NULL;
    amxd_status_t status = amxd_status_unknown_error;
    const cstring_t endpoint_id = NULL;
    amxc_string_t* dotted_controller = NULL;

    amxc_var_init(&ret);

    when_null_trace(controller, exit, ERROR, "Controller is NULL");
    when_str_empty_trace(controller, exit, ERROR, "Controller is empty");

    dotted_controller = bulkdata_utils_add_dot(controller);
    when_null_trace(dotted_controller, exit, ERROR, "Controller is NULL");

    // Extract the controller ID from the controller string
    status = amxb_get(amxb_be_who_has_ex(amxc_string_get(dotted_controller, 0), true), amxc_string_get(dotted_controller, 0), 0, &ret, 0);
    when_failed_trace(status, exit, ERROR, "Failed to get controller ID");
    endpoint_id = GETP_CHAR(&ret, "0.0.EndpointID");
    when_null_trace(endpoint_id, exit, ERROR, "Endpoint ID is NULL");
    when_str_empty_trace(endpoint_id, exit, ERROR, "Endpoint ID is empty");
    // Allocate memory for the from_id string
    from_id = strdup(endpoint_id);
    when_null_trace(from_id, exit, ERROR, "Failed to allocate memory for from_id");

exit:
    amxc_string_delete(&dotted_controller);
    amxc_var_clean(&ret);
    return from_id;
}

static char* bulkdata_profile_acl_role_from_eid(const char* eid) {
    char* role = NULL;
    const char* assigned = NULL;
    const char* name = NULL;
    int retval = -1;
    amxc_string_t path;
    amxc_string_t* dotted_role = NULL;
    amxc_var_t ret;

    amxc_var_init(&ret);
    amxc_string_init(&path, 0);

    amxc_string_setf(&path, "Device.LocalAgent.Controller.[EndpointID=='%s'].", eid);
    retval = amxb_get(amxb_be_who_has_ex("Device.LocalAgent.", true), amxc_string_get(&path, 0), 0, &ret, 5);

    when_failed(retval, exit);

    assigned = GETP_CHAR(&ret, "0.0.AssignedRole");
    when_str_empty(assigned, exit);

    dotted_role = bulkdata_utils_add_dot(assigned);

    retval = amxb_get(amxb_be_who_has(amxc_string_get(dotted_role, 0)), amxc_string_get(dotted_role, 0), 0, &ret, 5);
    when_failed(retval, exit);

    name = GETP_CHAR(&ret, "0.0.Name");
    when_str_empty(name, exit);

    role = strdup(name);

exit:
    amxc_string_delete(&dotted_role);
    amxc_var_clean(&ret);
    amxc_string_clean(&path);
    return role;
}

static amxc_string_t* bulkdata_profile_acl_get_acl_file(const char* eid) {
    int retval = -1;
    amxo_parser_t* parser = bulkdata_get_parser();
    const char* acl_dir = NULL;
    char* role = NULL;
    amxc_string_t* merged_file = NULL;

    amxc_string_new(&merged_file, 0);

    when_null(parser, exit);
    acl_dir = GET_CHAR(&parser->config, "acl_dir");

    when_str_empty(eid, exit);
    when_str_empty(acl_dir, exit);

    role = bulkdata_profile_acl_role_from_eid(eid);
    when_str_empty(role, exit);

    amxc_string_setf(merged_file, "%s/merged/%s.json", acl_dir, role);

    retval = 0;
exit:
    if(retval != 0) {
        amxc_string_delete(&merged_file);
        merged_file = NULL;
    }
    free(role);
    return merged_file;
}

static bool bulkdata_profile_acl_is_enbabled(void) {
    bool res = false;
    amxo_parser_t* parser = NULL;

    parser = bulkdata_get_parser();
    when_null_trace(parser, exit, ERROR, "Parser is NULL");

    res = GET_BOOL(&parser->config, "acl_check_enabled");
exit:
    return res;
}

amxd_status_t bulkdata_profile_acl_check_permission(amxd_object_t* parameter) {
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* params_obj = NULL;
    amxd_object_t* profile_obj = NULL;
    const cstring_t controller = NULL;
    cstring_t from_id = NULL;
    amxc_string_t* acl_file = NULL;
    const cstring_t reference;
    amxc_var_t* ret = NULL;

    amxc_var_new(&ret);
    when_false_status(bulkdata_profile_acl_is_enbabled(), exit, status = amxd_status_ok);
    when_null_trace(parameter, exit, ERROR, "Profile is NULL");

    reference = bulkdata_parameter_get_reference(parameter);
    when_null_trace(reference, exit, ERROR, "Reference is NULL");
    SAH_TRACEZ_INFO(ME, "Checking ACL for Reference: %s", reference);

    params_obj = amxd_object_get_parent(parameter);
    when_null_trace(params_obj, exit, ERROR, "Parameter object is NULL");
    profile_obj = amxd_object_get_parent(params_obj);
    when_null_trace(profile_obj, exit, ERROR, "Profile object is NULL");

    controller = bulkdata_profile_get_controller(profile_obj);
    when_null_trace(controller, exit, ERROR, "Controller is NULL");
    //  When controller is empty, it will be ignored and no ACL checking will be done
    when_str_empty_status(controller, exit, status = amxd_status_ok);

    // Check if the controller has permission to access the parameter
    from_id = bulkdata_profile_acl_get_controller_id(controller);
    when_null_trace(from_id, exit, ERROR, "Controller ID is NULL");

    acl_file = bulkdata_profile_acl_get_acl_file(from_id);
    when_null_trace(acl_file, exit, ERROR, "ACL file is NULL");

    SAH_TRACEZ_INFO(ME, "Checking ACL for Reference: %s | acl file %s | controller %s | eid %s", reference, amxc_string_get(acl_file, 0), controller, from_id);
    status = amxa_get(amxb_be_who_has(reference), reference, amxc_string_get(acl_file, 0), 0, ret, 0);

exit:
    amxc_string_delete(&acl_file);
    amxc_var_delete(&ret);
    free(from_id);
    return status;
}
