/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __amxb_wrapper_h__
#define __amxb_wrapper_h__

#include <amxc/amxc_variant.h> /* required by amxb.h */
#include <amxc/amxc_lqueue.h>  /* required by amxb.h */
#include <amxp/amxp_signal.h>  /* required by amxb.h */
#include <amxp/amxp_slot.h>    /* required by amxb.h */
#include <amxd/amxd_types.h>   /* required by amxb.h */
#include <amxb/amxb_types.h>   /* amxb_bus_ctx_t */

amxb_bus_ctx_t* amxb_wrap_be_who_has(const char* object_path);

int amxb_wrap_call(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   const char* method,
                   amxc_var_t* args,
                   amxc_var_t* ret,
                   int timeout);

int amxb_wrap_list(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   uint32_t flags,
                   amxb_be_cb_fn_t fn,
                   void* priv);

int amxb_wrap_subscribe(amxb_bus_ctx_t* const ctx,
                        const char* object,
                        const char* expression,
                        amxp_slot_fn_t slot_cb,
                        void* priv);

int amxb_wrap_unsubscribe(amxb_bus_ctx_t* const ctx,
                          const char* object,
                          amxp_slot_fn_t slot_cb,
                          void* priv);

#endif
