/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include "test_common.h"
#include "test_wrap.h"

struct _netmodel_query {
    bool fake_definition;
};


/* brg info req,
   all frame lengths: 46
 */

static uint8_t test_brg_info_req[] = {0x01, 0x20, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

static uint8_t test_cm_nw_stats_req[] = {0x01, 0x48, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

static uint8_t test_vs_nw_info_req[] = {0x01, 0x38, 0xA0, 0x00, 0x00, 0x00, 0xB0, 0x52, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

static uint8_t test_cm_hfid_req[] = {0x01, 0x40, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};
static uint8_t test_atherow_sw_ver_req[] = {0x00, 0x00, 0xA0, 0x00, 0xB0, 0x52, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

/* br info cnf
   from: F4:06:8D:11:A5:E9
   frame size 46 */
static uint8_t test_brg_info_cnf[] = {0x01, 0x21, 0x60, 0x00, 0x00, 0x01, 0x01, 0x04, 0xF4, 0x06, 0x8D,
    0x11, 0xA5, 0xE7, 0xF4, 0x06, 0x8D, 0x11, 0xA5, 0xE8, 0x00, 0x24,
    0x9B, 0x19, 0x6B, 0x02, 0x02, 0x10, 0x18, 0x01, 0x14, 0x01, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

/*  cm_nw_stats_cnf
    from F4:06:8D:11:A5:E9
    frame size 46 */
static uint8_t test_cm_nw_stats_cnf[] = {0x01, 0x49, 0x60, 0x00, 0x00, 0x01, 0xF4, 0x06, 0x8D, 0x96, 0x1F,
    0xD7, 0x7C, 0x7D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00};

/*  vs_nw_info_cnf
    from F4:06:8D:11:A5:E9
    frame size 70 */

static uint8_t test_vs_nw_info_cnf[] = {0x01, 0x39, 0xA0, 0x00, 0x00, 0x00, 0xB0, 0x52, 0x00, 0x00, 0x3A,
    0x00, 0x00, 0x01, 0xB6, 0x44, 0x93, 0x15, 0x27, 0x8D, 0x04, 0x00,
    0x00, 0x07, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0xF4, 0x06, 0x8D,
    0x11, 0xA5, 0xE9, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xF4, 0x06, 0x8D, 0x96, 0x1F, 0xD7, 0x02, 0x00, 0x00,
    0x00, 0xF4, 0x06, 0x8D, 0x96, 0x1F, 0xD5, 0x7C, 0x01, 0x00, 0x00,
    0x7D, 0x01, 0x00, 0x00};

/* cm_hfid_cnf
   from F4:06:8D:11:A5:E9
   framesize: 70
 */

static uint8_t test_cm_hfid_cnf[] = {0x01, 0x41, 0x60, 0x00, 0x00, 0x00, 0x4F, 0x72, 0x61, 0x6E, 0x67,
    0x65, 0x20, 0x57, 0x69, 0x2D, 0x46, 0x69, 0x20, 0x45, 0x78, 0x74,
    0x65, 0x6E, 0x64, 0x65, 0x72, 0x20, 0x35, 0x30, 0x30, 0x20, 0x4D,
    0x62, 0x69, 0x74, 0x73, 0x2F, 0x73, 0x20, 0x5B, 0x4D, 0x54, 0x32,
    0x36, 0x31, 0x36, 0x3B, 0x58, 0x5D, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00};

/*
    atheros_sw_ver_cnf
    from F4:06:8D:11:A5:E9
    framesize: 150
 */

static uint8_t test_atherow_sw_ver_cnf[] = {0x00, 0x01, 0xA0, 0x00, 0xB0, 0x52, 0x00, 0x04, 0x2A, 0x49, 0x4E,
    0x54, 0x37, 0x34, 0x30, 0x30, 0x2D, 0x4D, 0x41, 0x43, 0x2D, 0x35,
    0x2D, 0x33, 0x2D,
    0x35, 0x33, 0x31, 0x37, 0x2D, 0x30, 0x33, 0x2D, 0x31, 0x35, 0x35,
    0x37, 0x2D, 0x32, 0x30, 0x31, 0x34, 0x30, 0x31, 0x32, 0x39, 0x2D,
    0x43, 0x53, 0x2D,
    0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00};

static void convert_frame(uint8_t* hdr, ssize_t frame_size) {

    int i = 0;
    char* hex = calloc(1, 3 * frame_size + 1);
    for(i = 0; i < frame_size; i++) {
        snprintf(&hex[3 * i], 4, "%2.2X ", hdr[i]);
    }
    printf("frame: %s frame_size: %ld\n", hex, frame_size);
    free(hex);
}

static bool compare_array(uint8_t* message1, uint8_t* message2, ssize_t message_size) {
    bool res = true;
    int i = 0;
    for(i = 0; i < message_size; i++) {
        if(message1[i] != message2[i]) {
            printf("error at index: %d\n", i);
            return false;
        }
    }
    return res;
}

bool __wrap_netmodel_initialize(void) {
    return true;
}
void __wrap_netmodel_cleanup(void) {

}

void __wrap_netmodel_closeQuery(UNUSED netmodel_query_t* const netmodel_query) {
    free(netmodel_query);
}
netmodel_query_t* __wrap_netmodel_openQuery_isUp(UNUSED const char* intf,
                                                 UNUSED const char* subscriber,
                                                 UNUSED const char* flag,
                                                 UNUSED const char* traverse,
                                                 UNUSED netmodel_callback_t handler,
                                                 UNUSED void* userdata) {
    netmodel_query_t* query = (netmodel_query_t*) calloc(1, sizeof(netmodel_query_t));
    return query;
}

amxc_var_t* __wrap_netmodel_getFirstParameter(UNUSED const char* intf,
                                              UNUSED const char* name,
                                              UNUSED const char* flag,
                                              UNUSED const char* traverse) {
    amxc_var_t* interface_var = NULL;
    amxc_var_new(&interface_var);
    amxc_var_set_type(interface_var, AMXC_VAR_ID_CSTRING);
    amxc_var_set(cstring_t, interface_var, "br-lan");
    return interface_var;
}

homeplug_socket_t* __wrap_homeplug_socket_new(UNUSED const char* dev_name) {
    homeplug_socket_t* sock = (homeplug_socket_t*) calloc(1, sizeof(homeplug_socket_t));
    return sock;
}

void __wrap_homeplug_socket_delete(UNUSED homeplug_socket_t* sock) {
    free(sock);
}

bool __wrap_homeplug_socket_send_request(UNUSED homeplug_socket_t* sock, UNUSED const uint8_t addr[8], UNUSED uint8_t* message, UNUSED size_t message_size) {
    uint32_t counter = get_send_request_counter();
    printf("__wrap_homeplug_socket_send_request\n");
    function_called();
    printf("current counter value: %d\n", get_send_request_counter());
    convert_frame(message, message_size);
    switch(counter) {
    case 0: {
        printf("send br_info_req\n");
        assert_int_equal(message_size, 46);
        assert_true(compare_array(message, test_brg_info_req, message_size));
        break;
    }
    case 1: {
        printf("send cm_nw_stats_req\n");
        assert_int_equal(message_size, 46);
        assert_true(compare_array(message, test_cm_nw_stats_req, message_size));
        break;
    }
    case 2: {
        printf("send test_vs_nw_info_req\n");
        assert_int_equal(message_size, 46);
        assert_true(compare_array(message, test_vs_nw_info_req, message_size));
        break;
    }
    case 3: {
        printf("test_cm_hfid_req\n");
        assert_int_equal(message_size, 46);
        assert_true(compare_array(message, test_cm_hfid_req, message_size));
        break;
    }
    case 4: {
        printf("test_atherow_sw_ver_req\n");
        assert_int_equal(message_size, 46);
        assert_true(compare_array(message, test_atherow_sw_ver_req, message_size));
        break;
    }
    default: {
        printf("unexpected request number\n ");
        assert_true(false);
    }
    }
    increment_send_request_counter();
    return true;
}


void __wrap_homeplug_socket_read_socket_cb(UNUSED int socket_fd, UNUSED void* priv) {
    printf("__wrap_homeplug_socket_read_socket_cb\n");
    homeplug_socket_t* sock = (homeplug_socket_t*) priv;
    /* socket_fd is missused to indicate which homeplug av frame (or other protocol frame)  need to be send back
       1. BRG_INFO_CNF
       ...
     */
    uint8_t* frame = NULL;
    size_t framelength = 0;
    uint8_t sll_addr[8] = {244, 6, 141, 150, 31, 215, 0, 0}; /* 30:30:30:30:30:31*/

    switch(socket_fd) {
    case 1: {
        frame = (uint8_t*) &test_brg_info_cnf[0];
        framelength = 46;
        break;
    }
    case 2: {
        frame = (uint8_t*) &test_cm_nw_stats_cnf[0];
        framelength = 46;
        break;

    }
    case 3: {
        frame = (uint8_t*) &test_vs_nw_info_cnf[0];
        framelength = 70;
        break;
    }
    case 4: {
        frame = (uint8_t*) &test_cm_hfid_cnf[0];
        framelength = 70;
        break;
    }
    case 5: {
        frame = (uint8_t*) &test_atherow_sw_ver_cnf[0];
        framelength = 150;
        break;
    }
    default: {
        break;
    }
    }
    homeplug_av_protocol_handle_rcvd_msg(sock, frame, framelength, sll_addr);
}

