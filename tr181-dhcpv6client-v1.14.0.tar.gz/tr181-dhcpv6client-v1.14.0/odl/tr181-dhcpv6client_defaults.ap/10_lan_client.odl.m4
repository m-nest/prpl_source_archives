%populate {
    object DHCPv6Client {
        object 'Client' {
            instance add('lan') {
                parameter 'Enable' = true;
                parameter 'Interface' = "${ip_intf_lan}";
                parameter 'RequestAddresses' = true;
                parameter 'RequestPrefixes' = false;
                parameter "RequestedOptions" = "17,23,31,32,64,65";

                object 'SentOption' {
m4_ifdef(`CONFIG_SAH_AMX_TR181_DHCPV6CLIENT_SENTOPTION_17', `
                    instance add("sent-option-17") {
                        parameter "Enable" = true;
                        parameter "Tag" = 17; // vendor-specific information option
                        parameter "Alias" = "sent-option-17";
                        parameter "Value" = "CONFIG_SAH_AMX_TR181_DHCPV6CLIENT_SENTOPTION_17";
                    }
')
                    instance add("sent-option-16") {
                        parameter "Enable" = true;
                        parameter "Tag" = 16; // vendor-class option
                        parameter "Alias" = "sent-option-16";
                        parameter "Value" = "${vendor_class_dslforum_org_usp}";
                    }
                }
            }
        }
    }
}
