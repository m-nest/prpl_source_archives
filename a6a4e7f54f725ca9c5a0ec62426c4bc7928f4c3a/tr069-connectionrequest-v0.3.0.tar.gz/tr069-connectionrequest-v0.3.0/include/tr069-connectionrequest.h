/**************************************************************************
*
* Copyright (c) 2000-2003 Intel Corporation
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* - Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
* - Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
* - Neither name of Intel Corporation nor the names of its contributors
* may be used to endorse or promote products derived from this software
* without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
* PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************/
/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef TR069_CONNECTIONREQUEST
#define TR069_CONNECTIONREQUEST

#ifdef __cplusplus
extern "C" {
#endif

#include <util.h>

#include <upnp.h>
#include <UpnpString.h>
#include <upnptools.h>

#include <signal.h>
#include <stdarg.h>
#include <stdio.h>

/**
 * Maximum length of IP string
 */
#define MAX_PORT_LEN    6
/**
 * Maximum length of value string
 */
#define MAX_VAL_LEN     256
/**
 * Count of supported service
 */
#define SERVICE_COUNT   3
/**
 * Success state
 */
#define SUCCESS     0
/**
 * Error state
 */
#define ERROR       (-1)
/**
 * Warning state
 */
#define WARNING     1

/**
 * @file tr069-connectionrequest.h
 * @brief The UPnP Control Point for update TR-069 ConnectionRequestURL.
 */

/**
 * @enum service_t
 * Enumeration of service type
 */
typedef enum {
    SERVICE_WANIPCONNECTION = 0,    /**< WanIPConnection service */
    SERVICE_WANPPPCONNECTION,       /**< WanPPPConnection service */
    SERVICE_WANIPV6FIREWALLCONTROL, /**< WanIPv6FirewallControl service */
    SERVICE_NONE                    /**< No service */
} service_t;

/**
 * @enum CPState_t
 * Enumeration of control point state
 */
typedef enum {
    CP_STOPPED = 0, /**< Stopped state */
    CP_RUNNING,     /**< Running state */
    CP_SHOULD_STOP  /**< Should stop state */
} CPState_t;

/**
 * @struct ServiceInfo
 * Description of service
 */
struct ServiceInfo {
    /**
     * ID of service
     */
    char ID[NAME_SIZE];
    /**
     * Type of service
     */
    char Type[NAME_SIZE];
    /**
     * URL for event
     */
    char EventURL[NAME_SIZE];
    /**
     * URL for control
     */
    char ControlURL[NAME_SIZE];
    /**
     * Event service ID
     */
    char SID[NAME_SIZE];
};

/**
 * @struct DeviceInfo
 * Description of internet gateway device (IGD)
 */
struct DeviceInfo {
    /**
     * Unique Device Number
     */
    char UDN[MAX_VAL_LEN];
    /**
     * Array of services
     */
    struct ServiceInfo Service[SERVICE_COUNT];
    /**
     * The flag to indicate if data about IGD is relevant
     */
    int Updated;
    /**
     * Currently active service on IGD
     */
    service_t ActiveService;
    /**
     * IGD Boot ID
     */
    char BootID[MAX_VAL_LEN];
    /**
     * External IP Address of IGD
     */
    char ExternalIPAddress[MAX_VAL_LEN];
    /**
     * Unique ID of IPv6 service
     */
    char UniqueID[MAX_VAL_LEN];
};

int app_main(int argc, char** argv);

#ifdef __cplusplus
};
#endif

#endif /* UPNP_CTRLPT_H */
