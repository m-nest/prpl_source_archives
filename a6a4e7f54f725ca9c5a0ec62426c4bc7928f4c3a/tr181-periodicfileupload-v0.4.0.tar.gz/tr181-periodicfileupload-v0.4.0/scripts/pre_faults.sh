#!/bin/sh
tar cf /tmp/faults.tar `ba-cli -l ProcessFaults.StoragePath?` 2>/dev/null
echo -n "/tmp/faults.tar"