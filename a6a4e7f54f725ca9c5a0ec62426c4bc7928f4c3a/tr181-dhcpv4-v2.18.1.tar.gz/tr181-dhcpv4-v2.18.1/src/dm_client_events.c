/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "dm_client_events.h"
#include "pools.h"
#include "dns_utility.h"

#define ME "client_events"

/**
 * @brief
 * Sets the TR181 DHCPv4.Server.Pool.{i}.Client.{i}.Active flag to false when the client is not using any IP addresses.
 * Called when a TR181 DHCPv4.Server.Pool.{i}.Client.{i}.IPv4AddressNumberOfEntries data model parameter is changed.
 *
 * @param event_name event name
 * @param event_data event data
 * @param priv private data associated with event subscription
 */
void _client_check_if_active(UNUSED const char* const event_name,
                             const amxc_var_t* const event_data,
                             UNUSED void* const priv) {
    uint32_t from = 0;
    uint32_t to = 0;
    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");
    SAH_TRACEZ_INFO(ME, "DHCPv4 server pool client number of IP addresses has changed in TR-181 data model");

    from = GETP_UINT32(event_data, "parameters.IPv4AddressNumberOfEntries.from");
    to = GETP_UINT32(event_data, "parameters.IPv4AddressNumberOfEntries.to");
    if((from == 1) && (to == 0)) {
        const char* object = GETP_CHAR(event_data, "object");
        int rc = 0;
        when_null_trace(object, exit, ERROR, "No object in event_data");
        SAH_TRACEZ_INFO(ME, "Setting '%s' to false in TR-181 data model because DHCPv4 client is not leasing any IP addresses", object);
        rc = pools_set_client_active(object, false);
        when_failed_trace(rc, exit, ERROR, "Problem setting DHCPv4 server pool client '%s' inactive", object);
        dhcp_trigger_maintenance();
    }
exit:
    return;
}

void _client_active_changed(UNUSED const char* const event_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv) {
    amxd_object_t* client = amxd_dm_signal_get_object(dhcp_get_dm(), data);
    amxd_object_t* option_12 = amxd_object_findf(client, ".Option.[Tag == 12].");
    when_null(option_12, exit);
    dns_set_host(option_12, DNS_HOST_ARG_CLIENT);
exit:
    return;
}
