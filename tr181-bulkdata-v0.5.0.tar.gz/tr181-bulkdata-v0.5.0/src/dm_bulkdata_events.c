/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "bulkdata.h"
#include "bulkdata_events.h"
#include "bulkdata_profile.h"
#include <debug/user_trace.h>

#define ME "events"

void _bulkdata_enable_changed(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    bulkdata_status_e status;

    USER_TRACE_INFO(TRACE_CAT_SYSTEM, "The Data collection process changes from \"%d\" to \"%d\"",
                    GETP_BOOL(data, "parameters.Enable.from"),
                    GETP_BOOL(data, "parameters.Enable.to"));

    if(GETP_BOOL(data, "parameters.Enable.to")) {
        bulkdata_start_collection_profiles();
        status = BULKDATA_ENABLED;
    } else {
        bulkdata_stop_collection_profiles();
        status = BULKDATA_DISABLED;
    }

    bulkdata_set_status(status);

    return;
}

void _bulkdata_profile_time_reference_changed(UNUSED const char* const sig_name,
                                              const amxc_var_t* const data,
                                              UNUSED void* const priv) {

    if(bulkdata_get_enable() == false) {
        SAH_TRACEZ_INFO(ME, "BulkData is disabled, no need to start collection");
        return;
    }

    SAH_TRACEZ_INFO(ME, "TimeReference changed from \"%" PRIu64 "\" to \"%" PRIu64 "\"",
                    amxc_var_constcast(amxc_ts_t, GETP_ARG(data, "parameters.TimeReference.from"))->sec,
                    amxc_var_constcast(amxc_ts_t, GETP_ARG(data, "parameters.TimeReference.to"))->sec);

    amxd_dm_t* dm = bulkdata_get_dm();
    amxd_object_t* profile = amxd_dm_signal_get_object(dm, data);
    bulkdata_update_timer(profile);
}

void _bulkdata_profile_reporting_interval_changed(UNUSED const char* const sig_name,
                                                  const amxc_var_t* const data,
                                                  UNUSED void* const priv) {

    if(bulkdata_get_enable() == false) {
        SAH_TRACEZ_INFO(ME, "BulkData is disabled, no need to start collection");
        return;
    }

    SAH_TRACEZ_INFO(ME, "ReportingInterval changed from \"%d\" to \"%d\"",
                    GETP_UINT32(data, "parameters.ReportingInterval.from"),
                    GETP_UINT32(data, "parameters.ReportingInterval.to"));

    amxd_dm_t* dm = bulkdata_get_dm();
    amxd_object_t* profile = amxd_dm_signal_get_object(dm, data);
    bulkdata_update_timer(profile);
}

void _bulkdata_profile_enable_changed(UNUSED const char* const sig_name,
                                      const amxc_var_t* const data,
                                      UNUSED void* const priv) {
    amxd_dm_t* dm = bulkdata_get_dm();
    amxd_object_t* profile = amxd_dm_signal_get_object(dm, data);

    SAH_TRACEZ_INFO(ME, "Enable changed from \"%d\" to \"%d\"",
                    GETP_BOOL(data, "parameters.Enable.from"),
                    GETP_BOOL(data, "parameters.Enable.to"));
    if(bulkdata_get_enable() == false) {
        SAH_TRACEZ_INFO(ME, "BulkData is disabled, no need to start/stop the profile");
        return;
    }

    if(GETP_BOOL(data, "parameters.Enable.to") == false) {
        bulkdata_stop_profile(profile);
    } else {
        bulkdata_start_profile(profile);
    }
}

void _bulkdata_profile_added(UNUSED const char* const sig_name,
                             const amxc_var_t* const data,
                             UNUSED void* const priv) {

    amxd_dm_t* dm = bulkdata_get_dm();
    amxd_object_t* profile = amxd_dm_signal_get_object(dm, data);

    SAH_TRACEZ_INFO(ME, "Profile %s added", amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
    if(bulkdata_get_enable() == false) {
        SAH_TRACEZ_INFO(ME, "BulkData is disabled, no need to start/stop the profile");
        return;
    }

    profile = amxd_object_get_instance(profile, NULL, GET_UINT32(data, "index"));
    bulkdata_start_profile(profile);
}
