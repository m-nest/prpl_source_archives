﻿# **Ethernet**
<https://prplfoundationcloud.atlassian.net/issues/?jql=project%20in%20(%22Low-Level%20API%22)%20and%20labels%20in%20(%22ethernet%22)%20ORDER%20BY%20type%20ASC,%20created%20DESC> 
## **Tasks**
- Check with prplOS team if the tr181-ethernet service can accommodate the netdev/physical port name requirements. [Wouter Cloetens](https://prplfoundationcloud.atlassian.net/wiki/people/636531781cc605b1fd18d04d?ref=confluence) to check with HLAPI/prplOS [David Cluytens](https://prplfoundationcloud.atlassian.net/wiki/people/6374fa968fd2d2d5f12c5861?ref=confluence) [Olaf Wachendorf](https://prplfoundationcloud.atlassian.net/wiki/people/636bc697847c699ac651c61e?ref=confluence) [Evgueni Tzvetanov](https://prplfoundationcloud.atlassian.net/wiki/people/5eb99a1d0590bb0b7b4f5a63?ref=confluence) → part of 2024 SoW
- Investigate best implementation of setting the netdev interface name at boot (udev/script/requirement on Ethernet driver). → [Mahipati Deshpande](https://prplfoundationcloud.atlassian.net/wiki/people/636a365b11c69c74184510fd?ref=confluence) looking into doing it in the device driver.
- Provide concrete code examples to map the content of a DeviceTree alias parameter to a netdev interface name. [Wouter Cloetens](https://prplfoundationcloud.atlassian.net/wiki/people/636531781cc605b1fd18d04d?ref=confluence) to check with HLAPI/prplOS [David Cluytens](https://prplfoundationcloud.atlassian.net/wiki/people/6374fa968fd2d2d5f12c5861?ref=confluence) [Olaf Wachendorf](https://prplfoundationcloud.atlassian.net/wiki/people/636bc697847c699ac651c61e?ref=confluence) [Evgueni Tzvetanov](https://prplfoundationcloud.atlassian.net/wiki/people/5eb99a1d0590bb0b7b4f5a63?ref=confluence) → not a HL-API issue
- Add ethtool, and MAC stats, to the requirements. [PPW-198](https://prplfoundationcloud.atlassian.net/browse/PPW-198) - Stats are always zero for Unicast/Multicast/Broadcast Backlog 
## **High Level Description**
![](image/Ethernet_naming_mech.png) 
### **Netdev Interface Name**
An Ethernet (or similar layer 2 network interface) should have a consistent netdev interface name. This should be set at boot time, configurable by a system integrator, and consistent across driver updates.

- Different hardware revisions or alternatives should have the same interface names for the same physical ports, regardless of software versions.
- This could be modelled in the Device.Ethernet.Interface.{i}.*Name* data model parameter.
### **Physical Port Identification**
It must be possible for the system integrator to configure the end user exposed name of a network port, e.g. “blue”, “LAN1”, “ETH3”, “WAN”.

- Different hardware revisions or alternatives should be able to present the name of a port through a user interface and/or remote management system, so that any user configuration applies to whatever underlying netdev interface name the port has. This could be modelled in the Device.Ethernet.Interface.{i}.*Alias* data model parameter.
## **Status**
Physical port names agreed with WNC and Gemtek for 2024 reference platforms.

Freedom implementation in progress.
## **Detailed Description**
### **Netdev Interface Name**
The netdev interface name must be configurable through the label parameter in DeviceTree.

See the Turris Omnia DeviceTree configuration for an example:

<https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/arch/arm/boot/dts/marvell/armada-385-turris-omnia.dts#n215>

```

/\* WAN port \*/

&eth2 {

...
label = "wan";

};

...

    /\* Switch MV88E6176 at address 0x10 \*/

    ethernet-switch@10 {

            ...

            ethernet-ports {

            ...

			ethernet-port@0 {

                ...

				label = "lan0";

			};
```
###
### **Physical Port Identification**
The physical port interface name must be configurable through the aliases parameter in DeviceTree.

The name is limited to the following characters: [0-9][a-z]- per <https://devicetree-specification.readthedocs.io/en/latest/chapter3-devicenodes.html#aliases-node>

The alias must point to an Ethernet MAC (or switch port) object that contains a device\_type parameter with content network.

Aliases starting with the string ethernet must be ignored, due to U-Boot behaviour.

U-Boot uses the “ethernet<n>” (Linux) DeviceTree alias for MAC address assignment.

<https://github.com/u-boot/u-boot/blob/master/boot/fdt_support.c#L646> 
The Ethernet MAC with “ethernet0" gets assigned a MAC address with “eth0addr” and so forth.

U-boot uses “ethernet<n>” aliases to assign MAC addresses from “eth<n>addr” env vars.

Note that this is not the right solution for a gateway; should be all ports bridged with the same MAC address

The alias label-mac-device must be ignored. It is used to identify which network device receives the primary MAC address.

<https://www.spinics.net/lists/devicetree-spec/msg00858.html>
### **Metrics**
A number of netdev metrics can be queried through the netdev netlink interface.

These do not differentiate between broadcast and multicast, though, for example. The ethtool interface (ioctl and [netlink](https://docs.kernel.org/networking/ethtool-netlink.html) interfaces exist) exposes NIC metrics.

<https://docs.kernel.org/networking/ethtool-netlink.html> 
STATS\_GET, set ETHTOOL\_STATS\_ETH\_MAC in ETHTOOL\_A\_STATS\_GROUPS.
ethtool\_eth\_mac\_stats structure: <https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/include/linux/ethtool.h?id=ffc253263a1375a65fa6c9f62a893e9767fbebfa#n316>

```

		u64 MulticastFramesXmittedOK;

		u64 BroadcastFramesXmittedOK;

		[...]

		u64 MulticastFramesReceivedOK;

		u64 BroadcastFramesReceivedOK;
```
## **Implementation**
### **Physical Port Lookup in tr181-ethernet Manager**
Example shell script:
```

#!/bin/sh

find /sys/firmware/devicetree/base/aliases/ -type f -exec echo {} \; | while read a

do

        alias=`basename $a`

        p=`cat $a`

        if device\_type=`cat /sys/firmware/devicetree/base/$p/device\_type` 2>/dev/null

        then

                if [ $device\_type = "network" ]

                then

                        label=`cat /sys/firmware/devicetree/base/$p/label`

                        echo "$alias: $label"

                else

                        echo "$alias is not a network device"

                fi

        else

                echo "$alias is not a device"

        fi

done
```

### **Netdev Interface Name**
The “label” DeviceTree parameter must be read by the device driver and used as the interface name.
### **prplMesh**
An Airties EasyMesh+ extension includes port identification, but the Ethernet ports as integers. An algorithm to translate the port names to integers, taking into account all possible scenario, must be worked out. [Wouter Cloetens](https://prplfoundationcloud.atlassian.net/wiki/people/636531781cc605b1fd18d04d?ref=confluence) [Bora Sahin](https://prplfoundationcloud.atlassian.net/wiki/people/63a4d000f3e7004f77fc1bd1?ref=confluence) [Bilal Hatipoglu](https://prplfoundationcloud.atlassian.net/wiki/people/5cd276aa4eeaaa0dd0b0065e?ref=confluence)
### **OpenWrt**
<https://gitlab.com/prpl-foundation/prplos/prplos/-/blob/mainline-3.2/target/linux/mvebu/cortexa9/base-files/etc/board.d/02_network?ref_type=heads>

OpenWrt configures the WAN interface and LAN Ethernet bridge ports with a device-specific boot script, which configures defaults in UCI.

No change to this system is needed, provided that the netdev names of the network interfaces are configured correctly early enough during boot.

It does not have the ability to explicitly inform the packet accelerator if an Ethernet interface is used for WAN or LAN. [Hardware Offload](file:///C:/wiki/spaces/LLAPI/pages/16384403/Hardware+Offload)
### **prplOS**
OpenWrt’s system is limited to Ethernet ports and a single bridge.

The tr181-ethernet component sets up all bridges based on the [networklayout.json](https://gitlab.com/prpl-foundation/prplos/feeds/feed-prpl/-/blob/mainline-3.2/prpl-configuration/files/wnc-freedom/etc/networklayout.json?ref_type=heads) configuration file. The prplMesh Wireless Hardware Manager identifies the WLAN radios from this file as well, and add VAPs to the appropriate bridges.
## **Certification**
## **References**
- <https://gitlab.com/prpl-foundation/components/core/plugins/tr181-ethernet/-/blob/main/odl/ethernet-manager_interface.odl>
