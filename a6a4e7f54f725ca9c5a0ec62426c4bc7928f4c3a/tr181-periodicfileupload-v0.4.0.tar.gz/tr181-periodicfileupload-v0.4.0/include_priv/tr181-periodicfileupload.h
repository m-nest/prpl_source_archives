/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __TR181_PERIODICFILEUPLOAD_H__
#define __TR181_PERIODICFILEUPLOAD_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>

/**
 * @file
 * @brief
 * tr181-periodicfileupload plugin header file
 */

#define PFU_ROOT_DM_PATH "PeriodicFileTransfer."

/**
 * @brief Plugin main entry point
 *
 * Handles plugin lifecycle events (start/stop). Initializes the periodic
 * file upload functionality on start and cleans up resources on stop.
 *
 * @param[in] reason Entry reason (AMXO_START or AMXO_STOP)
 * @param[in] dm Data model instance
 * @param[in] parser ODL parser instance
 *
 * @return Always returns 0
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
 * @brief Application start event handler
 *
 * Toggles the plugin state based on the current PeriodicFileTransfer.Enable setting
 * when the application starts.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data (unused)
 * @param[in] priv Private data (unused)
 */
void _app_start(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Gets the data model instance
 *
 * Returns a pointer to the data model used by the periodic file upload plugin.
 *
 * @return Pointer to the data model instance, or NULL if not initialized
 */
amxd_dm_t* periodic_fupload_get_dm(void);

/**
 * @brief Gets the ODL parser instance
 *
 * Returns a pointer to the ODL parser used by the periodic file upload plugin.
 *
 * @return Pointer to the parser instance, or NULL if not initialized
 */
amxo_parser_t* periodic_fupload_get_parser(void);

/**
 * @brief Gets the PeriodicFileTransfer root object from the data model
 *
 * Returns a pointer to the root PeriodicFileTransfer object used by the
 * periodic file upload functionality.
 *
 * @return Pointer to the PeriodicFileTransfer root object, or NULL if not initialized
 */
amxd_object_t* periodic_fupload_get_root_object(void);

/**
 * @brief Checks if the periodic file upload feature is enabled
 *
 * Returns the current state of the PeriodicFileTransfer.Enable parameter from
 * the data model root object.
 *
 * @return true if periodic file upload is enabled, false otherwise
 *
 * @note Returns false if data model or root object is not initialized
 */
bool periodic_fupload_enabled(void);

/**
 * @brief Event handler for new Transfer instance creation
 *
 * Registers a new file transfer when a Transfer instance is added to the
 * data model. Only processes enabled transfers when the plugin is active.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data containing the new Transfer instance information
 * @param[in] priv Private data (unused)
 *
 * @note Triggered by dm:instance-added events on PeriodicFileTransfer.Transfer
 * @note Only registers transfer if plugin is enabled and instance Enable is true
 */
void _dm_transfer_added(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Event handler for Transfer object parameter changes
 *
 * Handles Transfer object modifications by re-registering the transfer
 * or deregistering it when disabled.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data containing the Transfer object changed informations
 * @param[in] priv Private data (unused)
 *
 * @note Triggered by dm:object-changed events on Transfer parameters (except Status)
 * @note Deregisters transfer when Enable changes from true to false
 * @note Re-registers transfer when Enable is true or other parameters change
 */
void _dm_transfer_changed(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Event handler for Transfer status completion (Success/Error)
 *
 * Resets the Transfer object status to "Idle" when a transfer completes
 * with either "Success" or "Error" status. Uses a transaction to modify
 * the read-only Status parameter.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data containing the Transfer object information
 * @param[in] priv Private data (unused)
 *
 * @note Triggered by dm:object-changed events on Transfer Status parameter
 * @note Only processes "Success" or "Error" status transitions
 */
void _dm_transfer_status_done(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Action handler for Transfer object destruction
 *
 * Deregisters a file transfer when its corresponding Transfer object is destroyed.
 * Cleans up the periodic file upload registration.
 *
 * @param[in] object Transfer object being destroyed
 * @param[in] param Parameter (unused)
 * @param[in] reason Action reason (must be action_object_destroy)
 * @param[in] args Action arguments (unused)
 * @param[out] retval Return value container (cleaned on success)
 * @param[in] priv Private data (unused)
 *
 * @return amxd_status_ok on success, amxd_status_function_not_implemented if reason is not destroy
 *
 * @note Triggered by destroy action on PeriodicFileTransfer.Transfer objects
 */
amxd_status_t _dm_transfer_destroyed(amxd_object_t* object, amxd_param_t* param, amxd_action_t reason,
                                     const amxc_var_t* const args, amxc_var_t* const retval, void* priv);

/**
 * @brief Event handler for PeriodicFileTransfer Enable parameter changes
 *
 * Toggles the entire file transfer plugin when the global PeriodicFileTransfer.Enable
 * parameter is modified. Enables or disables all file transfer functionality.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data containing the Enable parameter value
 * @param[in] priv Private data (unused)
 *
 * @return Always returns 0
 *
 * @note Triggered by dm:object-changed events on PeriodicFileTransfer.Enable
 */
int _dm_filetransfer_enable(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Event handler for vendor-specific ForceTransfer parameter
 *
 * Triggers an immediate file transfer when the vendor-specific ForceTransfer
 * parameter is set to true. Automatically resets the parameter to false and
 * initiates a one-time transfer with zero interval if the transfer status is "Idle".
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Event data containing the Transfer object information
 * @param[in] priv Private data (unused)
 *
 * @note Triggered when ${global_vendor_prefix_}ForceTransfer changes to 1
 * @note Only processes transfers with "Idle" status to prevent conflicts
 * @note Restores original UploadInterval and restarts transfer on error
 */
void _dm_transfer_forcetransfer(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
 * @brief Forces an immediate file transfer execution
 *
 * Stops the current periodic transfer, sets interval to 0 to trigger immediate
 * execution, and restarts the transfer. Uses deferred execution pattern.
 *
 * @param[in] transfer Transfer object instance (must be in "Idle" status)
 * @param[in] func Function object for deferred execution
 * @param[in] args Function arguments (unused)
 * @param[out] ret Return value container for deferred result
 *
 * @return amxd_status_deferred on success, amxd_status_unknown_error on failure
 *
 * @note This is the entrypoint for the TR-369 ForceTransfer function
 * @note Fails if transfer is already being forced or not in "Idle" status
 * @note Retry mechanism is ignored for forced transfer
 * @warning Allocates call_id in transfer->priv, freed elsewhere
 */
amxd_status_t _ForceTransfer(amxd_object_t* transfer, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Registers and configures a periodic file transfer
 *
 * Configures a periodic file transfer by retrieving parameters from the instance
 * and associated FileTypeConfig object. Sets up file path, upload interval,
 * pre/post-processing scripts, and starts the transfer.
 *
 * @param[in] instance Object instance containing transfer parameters:
 *                     Type, ProfileReference, TimeReference, UploadInterval
 *
 * @note Returns early with error log if FileTypeConfig is not found
 * @warning Allocates and frees time_reference memory internally
 */
void register_transfer(amxd_object_t* instance);

#ifdef __cplusplus
}
#endif

#endif // __TR181_PERIODICFILEUPLOAD_H__