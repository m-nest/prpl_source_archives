#!/bin/sh
rm /tmp/faults.tar
