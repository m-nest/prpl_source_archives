#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-firewall"
PROG="/usr/bin/tr181-firewall"
datamodel_root="Firewall"
PROG_OPTIONS=""


FW_DEFAULTS=/etc/amx/tr181-firewall/iptables.d/firewall.defaults
FW6_DEFAULTS=/etc/amx/tr181-firewall/iptables.d/firewall_ipv6.defaults

firewall_load_defaults() {
    iptables-restore < ${FW_DEFAULTS}
    ip6tables-restore < ${FW6_DEFAULTS}
    if [ -d /etc/amx/tr181-firewall/rules4 ]; then
        for f in /etc/amx/tr181-firewall/rules4/* ; do
            iptables-restore -n < $f
        done
    fi
    if [ -d /etc/amx/tr181-firewall/rules6 ]; then
        for f in /etc/amx/tr181-firewall/rules6/* ; do
            ip6tables-restore -n < $f
        done
    fi
}

firewall_clear() {
    iptables -P INPUT ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -F
    iptables -X
    iptables -t nat -F
    iptables -t nat -X

    ip6tables -P INPUT ACCEPT
    ip6tables -P FORWARD ACCEPT
    ip6tables -F
    ip6tables -X
}

#Guideline- this function has the instructions to execute
#before starting this service
#End
preservice_hook() {
    logger -s "pre-service hook ${name}"
    firewall_load_defaults
}

#Guideline- this function has the instructions to execute
#after stopping this service
#End
postservice_hook() {
    logger -s "post-service hook ${name}"
    firewall_clear
}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
    echo "1" > /proc/sys/net/ipv4/ip_forward
    echo "1" > /proc/sys/net/ipv6/conf/all/forwarding
}

stop_service() {
    deregister_service ${name}
    postservice_hook
}

debuginfo() {
    process_debug_info ${datamodel_root}
    process_debug_info "NAT"
}
