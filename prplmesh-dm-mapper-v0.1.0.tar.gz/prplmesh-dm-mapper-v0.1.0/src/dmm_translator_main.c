/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_translator_main.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contain implementation for DataModel Mapper transaltion requests
 *        with External DM Path to the proper Internal DM Path
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#include <stdlib.h>
#include <string.h>

#include "dmm.h"
#include "dmm_methods.h"
#include "dmm_connect_mngr.h"

#include <amxb/amxb_register.h>

#define ME "dmm"          /*!< Prefix for SAH logger method */

static prpl_dmm_t mapper; /*!< State of the DM Mapper */
extern const amxc_llist_t* hide_po_list;
extern amxc_var_t* rename_po;

/**
 * @brief
 *
 * @param c Character ASCII code as integer value
 * @return Function returns 1 if character is dot. Otherwise 0.
 */
static int isdot(int c) {
    return (c == '.') ? 1 : 0;
}

/**
 * @brief Logs the contents of an AMX container variant (`amxc_var_t`).
 *
 * This function logs the entire structure and content of the provided variant
 * using the configured tracing mechanism.
 *
 * To avoid log message mixing that occurs when **amxc_var_log()** splits
 * output by newlines into the system log, this function implements a workaround:
 * 1. The variant's contents are dumped to a memory stream using **open_memstream()**
 * and **amxc_var_dump_stream()**.
 * 2. The entire resulting string buffer is then logged as a single tracing message
 * using **SAH_TRACEZ_INFO**.
 * 3. The memory buffer is subsequently freed.
 *
 * The function gracefully handles **NULL** or **AMXC_VAR_ID_NULL** variants by
 * immediately returning.
 *
 * @param[in] var A constant pointer to the `amxc_var_t` structure to be logged.
 */
void SAH_TRACEZ_LOG_VARIANT(const amxc_var_t* var) {
    when_null(var, exit);
    when_true(amxc_var_type_of(var) == AMXC_VAR_ID_NULL, exit);

    // amxc_var_log writing to syslog splits by newlines,
    // so it gets mixed with other log messages
    // Instead, dump to memory and log as a single message
    char* buffer = NULL;
    size_t buffer_len = 0;
    FILE* stream = open_memstream(&buffer, &buffer_len);
    amxc_var_dump_stream(var, stream);
    fclose(stream);
    SAH_TRACEZ_INFO(ME, "%s", buffer);
    free(buffer);

exit:
    return;
}

/**
 * @brief Logs all currently configured data model mapping paths.
 *
 * This utility function retrieves the list of paths stored in the global
 * `mapper.mapping_paths` array and logs them sequentially using the
 * tracing mechanism (**SAH_TRACEZ_INFO**).
 *
 * The paths are logged in reverse order of their indexing (from `size` down to 1),
 * along with their index number.
 *
 * @return The total number of mapping paths currently stored in the mapper.
 */
size_t dmm_print_mapping_paths() {
    size_t size = amxc_array_size(mapper.mapping_paths);
    SAH_TRACEZ_INFO(ME, "Mapped paths:");
    for(size_t i = size; i > 0; i--) {
        const char* p = (const char*) amxc_array_get_data_at(mapper.mapping_paths, i - 1);
        SAH_TRACEZ_INFO(ME, "[%d] [%s]", i, p);
    }
    return size;
}

/**
 * @brief Adds an object path to the local Data Model (DM) hierarchy.
 *
 * This function parses a full path and creates the necessary intermediate and
 * final singleton objects in the local Data Model if they don't exist yet.
 * For each existing or newly created object part, it links the object to the
 * DMM's map base by appending its `derived_from` list to `mapper.map_base->derived_objects`.
 * This ensures that the object hierarchy is tracked by the DMM.
 *
 * @param dm Pointer to the local AMX Data Model.
 * @param path The full path of the object to be added (e.g., "Mgt.Objects.1.Param").
 * @return int Returns 0 on success, or -1 on failure.
 */
static int dmm_add_object(amxd_dm_t* dm, const char* path) {
    int retval = -1;
    amxc_string_t obj_path;
    amxc_llist_t parts;
    amxd_object_t* object = amxd_dm_get_root(dm);

    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Add object, full path [%s]", path);

    amxc_llist_init(&parts);
    amxc_string_init(&obj_path, 0);
    amxc_string_setf(&obj_path, "%s", path);
    amxc_string_trimr(&obj_path, isdot);
    amxc_string_split_to_llist(&obj_path, &parts, '.');

    amxc_llist_for_each(it, &parts) {
        amxc_string_t* obj_name = amxc_string_from_llist_it(it);
        amxd_object_t* obj = amxd_object_get(object, amxc_string_get(obj_name, 0));
        SAH_TRACEZ_INFO(ME, "Processing the part - obj_name: [%s], found next obj pointer in tree [%p].",
                        amxc_string_get(obj_name, 0), obj);
        if(obj != NULL) {
            SAH_TRACEZ_INFO(ME, "Object [%s] exist in subtree, derived append to map_base.", amxd_object_get_name(obj, AMXD_OBJECT_NAMED));
            amxc_llist_append(&mapper.map_base->derived_objects, &obj->derived_from);
            object = obj;
            continue;
        }
        if((amxd_object_get_type(object) == amxd_object_root) && (obj == NULL)) {
            SAH_TRACEZ_INFO(ME, "Exit from part processing, (object) == amxd_object_root && (obj == NULL)");
            goto exit;
        }
        SAH_TRACEZ_INFO(ME, "Create new object for [%s].", amxc_string_get(obj_name, 0));
        amxd_object_new(&obj, amxd_object_singleton, amxc_string_get(obj_name, 0));
        when_null(obj, exit);
        SAH_TRACEZ_INFO(ME, "Object [%s], derived append to map_base.", amxc_string_get(obj_name, 0));
        amxc_llist_append(&mapper.map_base->derived_objects, &obj->derived_from);
        SAH_TRACEZ_INFO(ME, "Defines the parent for new object.");
        amxd_object_add_object(object, obj);
        object = obj;
    }

    retval = 0;

exit:
    amxc_llist_clean(&parts, amxc_string_list_it_free);
    amxc_string_clean(&obj_path);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
 * @brief Recursively removes an object and its empty ancestors from the Data Model.
 *
 * This function cleans up objects in the local DM that are no longer needed
 * (i.e., not mapped and having no children, parameters, or derived objects).
 * It starts at `map_obj` and walks up the hierarchy:
 * 1. Checks if the object has any resources (objects, parameters, derived objects, or is mapped itself).
 * 2. If it is empty and not the root's direct child, it sends a "dm:object-removed" signal,
 * frees the object, and moves to the parent to check it as well.
 *
 * @param dm Pointer to the local AMX Data Model.
 * @param map_obj The amxd_object_t to start the removal process from.
 */
static void dmm_remove_object(amxd_dm_t* dm, amxd_object_t* map_obj) {
    while(map_obj != NULL) {
        if(!amxc_llist_is_empty(&map_obj->objects)) {
            break;
        }
        if(!amxc_llist_is_empty(&map_obj->parameters)) {
            break;
        }
        if(!amxc_llist_is_empty(&map_obj->derived_objects)) {
            break;
        }
        if(dmm_is_mapped(map_obj, NULL)) {
            break;
        }

        amxd_object_t* parent = amxd_object_get_parent(map_obj);
        if(parent == amxd_dm_get_root(dm)) {
            break;
        }

        amxd_object_send_signal(map_obj, "dm:object-removed", NULL, false);
        amxd_object_free(&map_obj);
        map_obj = parent;
    }
}

/**
 * @brief Updates the local Data Model based on a mapping path.
 *
 * This function is responsible for synchronizing the local DM with the DMM configuration.
 * 1. It checks if the object corresponding to the path already exists in the DM.
 * 2. If it exists, it links the object and all its ancestors (up to the root's children)
 * to the DMM's map base by appending their `derived_from` lists. This ensures they are
 * protected from removal and tracked.
 * 3. If the object does not exist, it calls `dmm_add_object` to create the object hierarchy.
 *
 * @param dm Pointer to the local AMX Data Model.
 * @param path amxc_var_t containing the mapping path (key) and possibly the real path (value).
 * @return int Returns 0 on success, or -1 on failure.
 */
static int dmm_update_dm(amxd_dm_t* dm, amxc_var_t* path) {
    int retval = -1;
    amxd_object_t* map_obj = NULL;
    amxd_object_t* parent = NULL;

    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Update DM, path [%s]", amxc_var_key(path));

    map_obj = amxd_dm_findf(dm, "%s", amxc_var_key(path));
    if(map_obj != NULL) {
        {
            char* path = amxd_object_get_path(map_obj, AMXD_OBJECT_TERMINATE);
            SAH_TRACEZ_INFO(ME, "Map obj found, map_obj: [%s] map_obj_path: [%s], derived append to map_base\n",
                            amxd_object_get_name(map_obj, AMXD_OBJECT_NAMED),
                            path);
            free(path);
        }
        amxc_llist_append(&mapper.map_base->derived_objects, &map_obj->derived_from);
        parent = amxd_object_get_parent(map_obj);

        while(parent != NULL && amxd_object_get_type(parent) != amxd_object_root) {
            {
                char* path = amxd_object_get_path(parent, AMXD_OBJECT_TERMINATE);
                SAH_TRACEZ_INFO(ME, "Parent found: [%s] parent_path: [%s]\n",
                                amxd_object_get_name(parent, AMXD_OBJECT_NAMED),
                                path);
                free(path);
            }
            if(parent->derived_from.llist != &mapper.map_base->derived_objects) {
                SAH_TRACEZ_INFO(ME, "Derived append to map_base from parent.");
                amxc_llist_append(&mapper.map_base->derived_objects, &parent->derived_from);
            }
            parent = amxd_object_get_parent(parent);
        }
        retval = 0;
    } else {
        SAH_TRACEZ_INFO(ME, "Mapped object not found, add new object.");
        retval = dmm_add_object(dm, amxc_var_key(path));
    }

    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
 * @brief Async callback function invoked when a real (backend) object is verified as available.
 *
 * This function is called after an asynchronous `_get` call to the backend succeeds,
 * confirming the object's existence.
 * 1. It moves the mapping path from the `DMM_OBJECTS_PENDING` list to the active `DMM_OBJECTS` list.
 * 2. Rebuilds the sorted list of mapping paths (`mapper.mapping_paths`).
 * 3. Calls `dmm_update_dm` to create or link the corresponding object hierarchy in the local DM.
 *
 * @param bus_ctx Unused. The bus context.
 * @param req The completed amxb_request_t structure.
 * @param status Unused. The request status.
 * @param priv Pointer to the `amxc_var_t` containing the real path and mapping path.
 */
static void dmm_real_object_available(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                      amxb_request_t* req,
                                      UNUSED int status,
                                      void* priv) {
    amxc_var_t* config_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS);
    amxc_var_t* real_path = (amxc_var_t*) priv;
    const char* path = amxc_var_key(real_path);
    amxc_var_t* mapping_path = amxc_var_add_key(cstring_t, config_po, GET_CHAR(real_path, NULL), path);
    const amxc_htable_t* map_objs = NULL;

    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Object [%s] verified - response received", path);

    // Do not delete real_path from DMM_OBJECTS_PENDING
    // We need DMM_OBJECTS_PENDING reverse mapping for unregistering and reconnecting
    // amxc_var_delete(&real_path);

    map_objs = amxc_var_constcast(amxc_htable_t, config_po);
    amxc_array_delete(&mapper.mapping_paths, NULL);
    mapper.mapping_paths = amxc_htable_get_sorted_keys(map_objs);

    dmm_update_dm(mapper.dm, mapping_path);

    amxb_close_request(&req);

    dmm_print_mapping_paths();

    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Initiates verification of a real (backend) object's availability.
 *
 * This function is called to check if an object listed in the DMM configuration
 * is actually present on the bus. It initiates an asynchronous RPC call (`_get`)
 * with depth 0 to the backend object's path.
 * The callback `dmm_real_object_available` will handle the result.
 *
 * @param path The real path of the object to verify (on the backend bus).
 */
void dmm_real_object_verify(const char* path) {
    SAH_TRACEZ_IN(ME);
    amxb_bus_ctx_t* bus_ctx = dmm_get_connection(path);
    amxc_var_t* pending_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS_PENDING);
    amxc_var_t* real_path = GET_ARG(pending_po, path);
    amxc_var_t args;

    if(bus_ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to verify [%s] - no context found", path);
        return;
    }
    SAH_TRACEZ_INFO(ME, "Wait on path: [%s], real_path: [%s]  done", path, GET_CHAR(real_path, NULL));
    SAH_TRACEZ_INFO(ME, "bus_ctx [%p] - %s", (void*) bus_ctx, bus_ctx->bus_fn->name);

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(uint32_t, &args, "depth", 0);
    if(amxb_async_call(bus_ctx, path, "_get", &args, dmm_real_object_available, real_path) == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to verify [%s] - object not added", path);
    }

    amxc_var_clean(&args);

    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Initializes the DMM translator component.
 *
 * Sets up the internal DMM state (`mapper` structure) using the provided DM and parser.
 * It ensures necessary configuration tables (`DMM_OBJECTS_CONFIG`, `DMM_OBJECTS_PENDING`,
 * `DMM_OBJECTS`, `DMM_OBJECTS_RENAME`) exist and populates the active objects list.
 * It iterates through the configured objects: if a real path is defined, the object
 * is moved to `DMM_OBJECTS_PENDING` for verification; otherwise, `dmm_update_dm` is called
 * immediately. Finally, it builds the sorted array of mapping paths.
 *
 * @param dm Pointer to the local AMX Data Model.
 * @param parser Pointer to the AMX Open parser containing DMM configuration.
 * @return int Returns 0 on success, or -1 on failure.
 */
int dmm_translator_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = -1;
    amxc_var_t* config_po = GET_ARG(&parser->config, DMM_OBJECTS_CONFIG);
    amxc_var_t* pending_po = GET_ARG(&parser->config, DMM_OBJECTS_PENDING);
    amxc_var_t* active_po = GET_ARG(&parser->config, DMM_OBJECTS);
    rename_po = GET_ARG(&parser->config, DMM_OBJECTS_RENAME);
    const amxc_htable_t* map_objs = NULL;
    hide_po_list = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser->config, DMM_OBJECTS_HIDE));

    SAH_TRACEZ_IN(ME);
    mapper.dm = dm;
    mapper.parser = parser;

    if(config_po == NULL) {
        config_po = amxc_var_add_key(amxc_htable_t, &parser->config, DMM_OBJECTS_CONFIG, NULL);
    }
    if(pending_po == NULL) {
        pending_po = amxc_var_add_key(amxc_htable_t, &parser->config, DMM_OBJECTS_PENDING, NULL);
    }
    if(active_po == NULL) {
        active_po = amxc_var_add_key(amxc_htable_t, &parser->config, DMM_OBJECTS, NULL);
    }
    amxc_var_copy(active_po, config_po);

    if(rename_po == NULL) {
        rename_po = amxc_var_add_key(amxc_htable_t, &parser->config, DMM_OBJECTS_RENAME, NULL);
    }

    dmm_object_create();

    when_false(amxc_var_type_of(active_po) == AMXC_VAR_ID_HTABLE, exit);
    amxb_be_cache_set_size(amxc_htable_size(amxc_var_constcast(amxc_htable_t, active_po)));

    amxc_var_for_each(path, active_po) {
        const char* real_path = GET_CHAR(path, NULL);
        if((real_path != NULL) && (*real_path != 0)) {
            amxc_var_add_key(cstring_t, pending_po, real_path, amxc_var_key(path));
            amxc_var_delete(&path);
        } else {
            retval = dmm_update_dm(dm, path);
            when_failed(retval, exit);
        }
    }

    map_objs = amxc_var_constcast(amxc_htable_t, active_po);
    mapper.mapping_paths = amxc_htable_get_sorted_keys(map_objs);

    retval = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

int dmm_translator_cleanup(UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser) {
    dmm_remove_subscriptions();

    mapper.dm = NULL;
    mapper.parser = NULL;
    amxc_array_delete(&mapper.mapping_paths, NULL);

    dmm_object_delete();

    return 0;
}

const char* dmm_get_real_path(amxd_path_t* path) {
    size_t size = amxc_array_size(mapper.mapping_paths);
    const char* real_path = NULL;
    const char* mapping_path = NULL;
    const char* param = amxd_path_get_param(path);
    const amxc_var_t* config_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS);
    amxc_string_t new_path;
    uint32_t depth = amxd_path_get_depth(path);

    amxc_string_init(&new_path, 0);

    for(size_t i = size; i > 0; i--) {
        const char* p = (const char*) amxc_array_get_data_at(mapper.mapping_paths, i - 1);
        size_t len = strlen(p);
        if(strncmp(p, amxd_path_get(path, AMXD_OBJECT_TERMINATE), len) == 0) {
            real_path = GET_CHAR(config_po, p);
            if((real_path == NULL) ||
               ((*real_path == 0) && (depth > 1))) {
                continue;
            }
            mapping_path = p;
            if(param != NULL) {
                amxc_string_setf(&new_path, "%s%s", amxd_path_get(path, AMXD_OBJECT_TERMINATE), amxd_path_get_param(path));
            } else {
                amxc_string_setf(&new_path, "%s", amxd_path_get(path, AMXD_OBJECT_TERMINATE));
            }
            amxc_string_replace(&new_path, p, real_path, 1);
            amxd_path_setf(path, false, "%s", amxc_string_get(&new_path, 0));
            break;
        }
    }

    amxc_string_clean(&new_path);
    return mapping_path;
}

const char* dmm_get_translate_path(const char* map_obj) {
    const amxc_var_t* config_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS);

    return GET_CHAR(config_po, map_obj);
}

bool dmm_is_mapped(amxd_object_t* object, const char* rel_path) {
    amxc_string_t path;
    char* obj_path = amxd_object_get_path(object, AMXD_OBJECT_TERMINATE | AMXD_OBJECT_INDEXED);
    const char* real_path = NULL;

    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "%s%s", obj_path, rel_path == NULL? "":rel_path);
    real_path = dmm_get_translate_path(amxc_string_get(&path, 0));
    free(obj_path);
    amxc_string_clean(&path);

    return (real_path != NULL && real_path[0] != 0);
}

char* dmm_strip_mapped(const char* mapped,
                       const char* real_obj) {
    amxd_path_t real_path;
    amxd_path_t mapped_path;
    uint32_t mapped_depth = 0;
    char* stripped = NULL;
    amxc_var_t* post_translate_objects = GET_ARG(&mapper.parser->config, DMM_OBJECTS_POST_TRANSLATE_CONFIG);
    const char* post_translate_mapped = GET_CHAR(post_translate_objects, mapped);

    if(post_translate_mapped && ((real_obj == NULL) || (strstr(real_obj, post_translate_mapped) == real_obj))) {
        mapped = post_translate_mapped;
    }

    amxd_path_init(&mapped_path, mapped);
    amxd_path_init(&real_path, real_obj);

    mapped_depth = amxd_path_get_depth(&mapped_path);

    for(uint32_t i = 0; i < mapped_depth; i++) {
        char* path_part = amxd_path_get_first(&real_path, true);
        free(path_part);
    }

    stripped = strdup(amxd_path_get(&real_path, AMXD_OBJECT_TERMINATE));

    amxd_path_clean(&real_path);
    amxd_path_clean(&mapped_path);

    return stripped;
}

int dmm_unregister(const char* mapping_path) {
    int retval = -1;
    amxc_var_t* config_po = NULL;
    const amxc_htable_t* map_objs = NULL;
    amxc_var_t* info = NULL;
    amxd_object_t* map_obj = NULL;

    when_null(mapper.parser, exit);
    config_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS);
    info = amxc_var_get_key(config_po, mapping_path, AMXC_VAR_FLAG_DEFAULT);

    retval = 0;
    when_null(info, exit);

    amxc_var_delete(&info);

    map_objs = amxc_var_constcast(amxc_htable_t, config_po);
    amxc_array_delete(&mapper.mapping_paths, NULL);
    mapper.mapping_paths = amxc_htable_get_sorted_keys(map_objs);

    map_obj = amxd_dm_findf(mapper.dm, "%s", mapping_path);
    when_null(map_obj, exit);

    dmm_remove_object(mapper.dm, map_obj);

exit:
    return retval;
}

int dmm_unregister_by_real_path(const char* real_path) {
    const amxc_var_t* config_po = GET_ARG(&mapper.parser->config, DMM_OBJECTS_PENDING);
    const amxc_var_t* mapping_path = GET_ARG(config_po, real_path);

    SAH_TRACE_INFO("path=%s mapping_path=%s", real_path, GET_CHAR(mapping_path, NULL));
    return dmm_unregister(GET_CHAR(mapping_path, NULL));
}

amxd_dm_t* dmm_get_dm(void) {
    return mapper.dm;
}

prpl_dmm_t* dmm_get_info(void) {
    return &mapper;
}
