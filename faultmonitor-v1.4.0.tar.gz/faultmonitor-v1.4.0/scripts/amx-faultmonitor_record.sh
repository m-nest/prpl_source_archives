#! /bin/sh

# Monitor and store core dumps of crashing processes

# Immediately compress the coredump from stdin into a temporary file.
# This must be the first action to prevent the pipe buffer from overflowing, which would cause a truncated coredump.
TMP_CORE_GZ_FILE="/tmp/coredump.$$.tmp.gz"
gzip -c > "$TMP_CORE_GZ_FILE"

# Default configuration
ODL_FILE=/etc/amx/amx-faultmonitor/amx-faultmonitor.odl
ODL_DEFAULT_DIR=/etc/amx/amx-faultmonitor/defaults.d/
ODL_PERSISTENT_DIR=/etc/config/amx-faultmonitor/
ODL_PERSISTENT_FILE=/etc/config/amx-faultmonitor/amx-faultmonitor.odl
MANAGE_FAULT_AT_SHUTDOWN=false
MANAGE_FAULT_AT_EARLY_BOOT=false
PROCESS_FAULT_BOOT=/tmp/.amx-faultmonitor.boot
CORE_BASE_DIR=/ext/faults
MIN_FREE_SPACE=3000
MAX_CORE_DUMPS=20
LOCK_DIR=/tmp/faultmonitor.lock
MAX_LOG_ENTRIES=100
STORE_CORE_DUMP_FS=true
STORE_CORE_DUMP_DM=true
AMXD_ERROR_CODE=0
PROCESS_FAULT_IS_RUNNING=false

get_config() {
    if [ -f "$ODL_PERSISTENT_FILE" ]; then
        ODL_CONFIG_DIR=$ODL_PERSISTENT_DIR
    else
        ODL_CONFIG_DIR=$ODL_DEFAULT_DIR
    fi

    if [ -f "$ODL_FILE" ]; then
        CORE_BASE_DIR="$(amxo-cg -s -Gjson-dm -i $ODL_CONFIG_DIR $ODL_FILE | jsonfilter -e '@["ProcessFaults."].StoragePath')"
        MAX_CORE_DUMPS="$(amxo-cg -s -Gjson-dm -i $ODL_CONFIG_DIR $ODL_FILE | jsonfilter -e '@["ProcessFaults."].MaxProcessFaultEntries')"
        MIN_FREE_SPACE="$(amxo-cg -s -Gjson-dm -i $ODL_CONFIG_DIR $ODL_FILE | jsonfilter -e '@["ProcessFaults."].MinFreeSpace')"
        MANAGE_FAULT_AT_SHUTDOWN="$(amxo-cg -s -Gjson-cfg -i $ODL_DEFAULT_DIR $ODL_FILE | jsonfilter -e '@.manage_fault_at_shutdown')"
        MANAGE_FAULT_AT_EARLY_BOOT="$(amxo-cg -s -Gjson-cfg -i $ODL_DEFAULT_DIR $ODL_FILE | jsonfilter -e '@.manage_fault_at_early_boot')"
        STORE_CORE_DUMP_FS="$(amxo-cg -s -Gjson-cfg -i $ODL_DEFAULT_DIR $ODL_FILE | jsonfilter -e '@.store_core_dump')"
    fi
}

get_process_name_from_ps() {
    ps -p "$PID" -o comm=
}

get_process_name_from_comm() {
  if [ -e "/proc/$PID/comm" ]; then
    cat /proc/$PID/comm
  else
    echo ""
  fi
}

get_process_name_from_cmdline() {
  if [ -e "/proc/$PID/cmdline" ]; then
    tr '\0' '\n' < /proc/$PID/cmdline | head -n 1
  else
    echo ""
  fi
}

get_arguments_from_ps() {
    ps -p "$PID" -o args= | awk '{$1=""; sub(/^[ \t]+/, ""); print}'
}

get_arguments_from_cmdline() {
    if [ -e "/proc/$PID/cmdline" ]; then
        # Read all arguments, excluding the first (process name)
        tr '\0' '\n' < /proc/$PID/cmdline | tail -n +2 | tr '\n' ' '
    else
        echo ""
    fi
}

# Basic characteristics of the fault
PID=$1
SIGNAL=$2
TIME=$(date -u -d @$3 '+%Y-%m-%dT%H:%M:%SZ')
PROCESS_NAME=$5

# If core pattern didn't return a process name, fallback to ps
if [ -z "$PROCESS_NAME" ]; then
    PROCESS_NAME=$(get_process_name_from_ps)
fi

# If ps didn't return a process name, fallback to /proc/comm
if [ -z "$PROCESS_NAME" ]; then
    PROCESS_NAME=$(get_process_name_from_comm)
fi

# If comm didn't return a process name, fallback to /proc/cmdline
if [ -z "$PROCESS_NAME" ]; then
    PROCESS_NAME=$(get_process_name_from_cmdline)
fi

# Try to get process args with ps
ARGUMENTS=$(get_arguments_from_ps)

# If ps didn't return a process args, fallback to /proc/cmdline
if [ -z "$ARGUMENTS" ]; then
    ARGUMENTS=$(get_arguments_from_cmdline)
fi

if [ ! -z "$4" ]; then
    PID=$4
fi

# Retreive software version
SOFTWARE_VERSION=$(awk -F '=' '/SOFTWAREVERSION=/ {gsub(/"/, "", $2); print $2}' /etc/environment)

get_config

# Do not handle crash dumps if it occurs before process fault start
# and manage_fault_at_early_boot config is false
if [ ! -e "$PROCESS_FAULT_BOOT" ] && [ $MANAGE_FAULT_AT_EARLY_BOOT = "false" ]; then
    exit 0
fi

if [ -z "$CORE_BASE_DIR" ]; then
    exit 0
fi

# Compute the crash id and store the count of crashes
mkdir -p $CORE_BASE_DIR
while ! mkdir $LOCK_DIR 2> /dev/null; do
  # poor mans busy waiting mutex
  sleep 0
done
COUNT_FILE=$CORE_BASE_DIR/count
CRASH_ID=0
if [ -e $COUNT_FILE ]; then
  CRASH_ID=$(cat $COUNT_FILE)
fi
COUNT=$(expr $CRASH_ID + 1)

# Compute local core dump path and check limits
# note: those checks are racy
CORE_DUMP_PATH=$CORE_BASE_DIR/dump/$CRASH_ID/
FREE_SPACE=$(\df -k $CORE_BASE_DIR | tail -n 1 | awk "{ print \$4 }")
if [ $FREE_SPACE -lt $MIN_FREE_SPACE ]; then
    STORE_CORE_DUMP_DM=false
    STORE_CORE_DUMP_FS=false
fi
if [ $MAX_CORE_DUMPS -eq 0 ]; then
    STORE_CORE_DUMP_DM=false
    STORE_CORE_DUMP_FS=false
fi

# Check if amx-faultmonitor process is running
if pgrep -x -f '/usr/bin/amx-faultmonitor' > /dev/null; then
    PROCESS_FAULT_IS_RUNNING=true
else
    PROCESS_FAULT_IS_RUNNING=false
fi

# Store details
if [ $STORE_CORE_DUMP_DM = "true" ] && [ $PROCESS_FAULT_IS_RUNNING = "true" ]; then
    RET=$(ubus call ProcessFaults.ProcessFault _add "\
    {\"parameters\":\
        {\"Reason\": $SIGNAL,\
        \"ProcessName\": \"$PROCESS_NAME\",\
        \"Arguments\": \"$ARGUMENTS\",\
        \"FaultLocation\": \"$CORE_DUMP_PATH\",\
        \"ProcessID\": \"$PID\",\
        \"TimeStamp\": \"$TIME\",\
        \"FirmwareVersion\": \"$SOFTWARE_VERSION\"}}")

    # Extract the amxd-error-code
    AMXD_ERROR_CODE=$(echo "$RET" | sed -n 's/.*"amxd-error-code": \([0-9]*\).*/\1/p')
else
    AMXD_ERROR_CODE=0
fi

# Do not handle crash dumps if it occurs after process fault stop
# and manage_fault_at_shutdown config is false
if [ $PROCESS_FAULT_IS_RUNNING = "false" ] && [ $MANAGE_FAULT_AT_SHUTDOWN = "false" ] && [ -e "$PROCESS_FAULT_BOOT" ]; then
    rmdir $LOCK_DIR
    exit 0
fi

# Store counter/crash id
echo $COUNT > $COUNT_FILE
rmdir $LOCK_DIR

# Store in log
FAULTS_LOG=$CORE_BASE_DIR/log
LOG_ENTRIES=0
if [ -f $FAULTS_LOG ]; then
    LOG_ENTRIES=$(wc -l $FAULTS_LOG |awk '{print $1}')
    if [ $LOG_ENTRIES -ge $MAX_LOG_ENTRIES ]; then
    # remove the oldest entries
    sed -i "1d" $FAULTS_LOG
    fi
fi

echo "$CRASH_ID $PID $SIGNAL $TIME $PROCESS_NAME $ARGUMENTS" >> $FAULTS_LOG

# Copy core dump only if it is successfully add to the DM or that the ProcessFaults DM isn't accessible
if [ "$AMXD_ERROR_CODE" -eq 0 ] && [ $STORE_CORE_DUMP_DM = "true" ]; then
    mkdir -p $CORE_DUMP_PATH
    json=$(echo -e "{\n\t"\
    "\"Reason\": \"$SIGNAL\",\n\t"\
    "\"ProcessName\": \"$PROCESS_NAME\",\n\t"\
    "\"Arguments\": \"$ARGUMENTS\",\n\t"\
    "\"FaultLocation\": \"$CORE_DUMP_PATH\",\n\t"\
    "\"ProcessID\": \"$PID\",\n\t"\
    "\"TimeStamp\": \"$TIME\",\n\t"\
    "\"FirmwareVersion\": \"$SOFTWARE_VERSION\"\n}")

    echo "$json" > $CORE_DUMP_PATH/config.json

    if [ $STORE_CORE_DUMP_FS = "true" ]; then
        for i in wchan maps smaps fdinfo "stat*"; do
        echo cp -r /proc/$PID/$i $CORE_DUMP_PATH
        cp -r /proc/$PID/$i $CORE_DUMP_PATH
        done
        ls -l /proc/$PID/fd/ > $CORE_DUMP_PATH/fd-listing.txt
        mv "$TMP_CORE_GZ_FILE" "$CORE_DUMP_PATH/core.gz"
    fi
fi

rm -f "$TMP_CORE_GZ_FILE"