/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wsn_common.h"
#include "wsn_utils.h"

#define ME "sensing"

char* wsn_util_getPathFieldAtIndex(const char* srcPath, size_t index) {
    char* res = NULL;
    size_t maxNFields = swl_str_countChar(srcPath, '.') + 1;
    ASSERT_TRUE(index < maxNFields, NULL, ME, "out of bound");
    char* fields[maxNFields];
    memset(fields, 0, sizeof(fields));
    size_t nFields = swl_typeCharPtr_arrayFromCharSep(fields, maxNFields, srcPath, ".");
    if((index < nFields) && (fields[index] != NULL)) {
        swl_str_copyMalloc(&res, fields[index]);
    }
    swl_typeCharPtr_arrayCleanup(fields, nFields);
    return res;
}

/**
 * @brief wsn_util_getApInstanceOfAssociatedStation
 *
 * Determines the accesspoint to which sta is associated
 *
 * @param macaddress contains the macaddress of the sta
 * @param onlyActive bool indicating whether looking for only active, or any matching associatedDevice entry
 * @return
 *     - accesspoint instance for the given sta. Returns 0 if sta is not associated
 */
int wsn_util_getApInstanceOfAssociatedStation(const char* macaddress, bool onlyActive) {
    SAH_TRACEZ_IN(ME);

    amxd_path_t dm_path;
    amxc_var_t retvar;
    amxd_path_init(&dm_path, NULL);
    amxc_var_init(&retvar);
    int rv = -1;
    int ap = 0;

    swl_macChar_t strMac = g_swl_macChar_null;
    swl_typeMacChar_fromChar(&strMac, macaddress);
    ASSERT_TRUE(swl_mac_charIsValidStaMac(&strMac), 0, ME, "invalid sta mac %s", macaddress);

    SAH_TRACEZ_INFO(ME, "Getting wifi context");
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");

    amxd_path_init(&dm_path, NULL);
    if(onlyActive) {
        amxd_path_setf(&dm_path, true, "WiFi.AccessPoint.*.AssociatedDevice.[MACAddress == '%s' && Active == '1'].", strMac.cMac);
    } else {
        amxd_path_setf(&dm_path, true, "WiFi.AccessPoint.*.AssociatedDevice.[MACAddress == '%s'].", strMac.cMac);
    }
    rv = amxb_resolve(ctx, &dm_path, &retvar);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get object");
    }

    const char* result = NULL;
    result = GETI_CHAR(&retvar, 0);

    if(!swl_str_isEmpty(result)) {

        char* apObjIdStr = wsn_util_getPathFieldAtIndex(result, 2);

        SAH_TRACEZ_INFO(ME, "Accesspoint instance of MACAddress %s is %s", strMac.cMac, apObjIdStr);

        if(apObjIdStr != NULL) {
            ap = atoi(apObjIdStr);
            free(apObjIdStr);
        }
    }
    SAH_TRACEZ_INFO(ME, "Result is %d", ap);
    amxd_path_clean(&dm_path);
    amxc_var_clean(&retvar);
    return ap;
}

/**
 * @brief wsn_util_getRadioPathOfAssociatedStation
 *
 * Determines the radio to which sta is associated
 *
 * @param macaddress contains the macaddress of the sta
 * @param onlyActive bool indicating whether looking for only active, or any matching associatedDevice entry
 * @return
 *     - radio path for the given sta. Returns NULL if sta is not associated (to be freed by the called)
 */
char* wsn_util_getRadioPathOfAssociatedStation(const char* macaddress, bool onlyActive) {
    SAH_TRACEZ_IN(ME);

    amxc_string_t path;
    amxd_path_t dm_path;
    amxc_var_t retvar;
    amxc_var_init(&retvar);
    int rv = -1;
    char* radio = NULL;
    int apInstance = 0;

    apInstance = wsn_util_getApInstanceOfAssociatedStation(macaddress, onlyActive);
    if(!apInstance) {
        SAH_TRACEZ_ERROR(ME, "Macaddress not found in associated devices");
        return NULL;
    }

    SAH_TRACEZ_INFO(ME, "Getting wifi context");
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");

    amxc_string_init(&path, 0);

    amxc_string_setf(&path, "WiFi.AccessPoint.%d.RadioReference", apInstance);

    rv = amxb_get(ctx, amxc_string_get(&path, 0), 0, &retvar, 0);

    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get object");
    }

    amxd_path_init(&dm_path, NULL);
    amxd_path_setf(&dm_path, true, "%s", GETP_CHAR(&retvar, "0.0.RadioReference"));

    rv = amxb_resolve(ctx, &dm_path, &retvar);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get object");
    }

    radio = strdup(GETI_CHAR(&retvar, 0));
    if(!radio) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", GETI_CHAR(&retvar, 0));
        return NULL;
    }
    SAH_TRACEZ_INFO(ME, "RadioReference from amxb_get 0.0.RadioReference is %s", radio);

    amxc_string_clean(&path);

    amxd_path_clean(&dm_path);
    amxc_var_clean(&retvar);

    SAH_TRACEZ_OUT(ME);
    return radio;
}
