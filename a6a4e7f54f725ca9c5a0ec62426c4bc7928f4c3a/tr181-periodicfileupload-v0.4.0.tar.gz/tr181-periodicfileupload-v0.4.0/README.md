# TR-181 Periodic File Upload Plugin

A TR-181 compliant periodic file upload plugin developed for the PRPL Foundation.

## Description

This plugin implements periodic file upload functionality according to TR-181 specifications. It enables automatic upload of files (logs, process dumps, kernel faults) to remote servers at configurable intervals.

## Features

### Core Functionality
- **Periodic Upload** : Automatic file upload at configurable intervals
- **Multi-Protocol Support** : HTTP and HTTPS protocols
- **File Type Support** : ProcessFaults, KernelFaults
- **Profile Management** : Flexible configuration via transfer profiles
- **Pre/Post Processing** : Script execution before and after upload
- **Authentication** : HTTP Basic and Digest Authentication support
- **TLS Security** : Client certificates and CA bundle validation
- **Compression** : GZIP, Compress, Deflate support
- **Automatic Retry** : Configurable retry mechanism
- **Statistics** : Success/failure counters

### TR-181 Compliance
- Complete implementation of `Device.PeriodicFileTransfer` data model
- Support for `Profile`, `Transfer`, and `FileTypeConfig` objects
- TR-369 compliant `ForceTransfer()` function
- TR-069 compliant `X_PRPLWARE_COM_ForceTransfer` parameter
- Transfer state management according to specifications

## Architecture

### Main Components

#### TR-181 Plugin (`tr181-periodicfileupload`)
- Main plugin entry point
- Data model lifecycle and event management
- AMX framework interface

#### Library (`libperiodicfileupload`)
- Low-level API for periodic transfer management
- Timer and scheduling management
- File transfer library interface

### Data Model

```
Device.PeriodicFileTransfer.
|-- Enable                              # Global enable/disable
|-- ProtocolsSupported                  # "HTTP,HTTPS"
|-- TypesSupported                      # "ProcessFaults,KernelFaults"
|-- HTTPCompressionsSupported           # "None,GZIP,Compress,Deflate"
|-- HTTPMethodsSupported                # "POST,PUT"
|-- Profile.{i}.                        # Transfer profiles
|   |-- Protocol
|   |-- HTTP.
|   |   |-- URL
|   |   |-- Username/Password
|   |   |-- Certicate                   # Client certificate reference
|   |   |-- CABundle                    # CA bundle reference
|   |   |-- IPVersion
|   |   |-- Method (POST/PUT)
|   |   |-- Compression
|   |   |-- RetryEnable
|   |   |-- RetryMinimumWaitInterval
|   |   |-- RetryIntervalMultiplier
|   |   |-- RequestHeaderParameter.{i}.
|   |   +-- RequestURIParameter.{i}.
|-- Transfer.{i}.                       # Transfer instances
|   |-- Enable
|   |-- Type                            # Reference to Device.PeriodicFileTransfer.FileTypeConfig.{i}.
|   |-- ProfileReference                # Reference to Device.PeriodicFileTransfer.Profile.{i}.
|   |-- UploadInterval
|   |-- TimeReference                   # Reference to calculate every interval
|   |-- Status                          # "Idle,Creating,Uploading,Success,Retrying,Error"
|   |-- ForceTransfer()                 # Force transfer function
|   |-- X_PRPLWARE_COM_ForceTransfer    # Force transfer triggering parameter
|   +-- Stats.
+-- FileTypeConfig.{i}.                 # File type configuration
    |-- FileTypeReference
    |-- FilePath
    |-- PreHookScript
    +-- PostHookScript
```

## Installation

### Prerequisites
- AMX framework (amxc, amxp, amxd, amxo)
- File transfer library
- Compatible C compiler
- ODL storage support
- Security certificate management system

### Build
```bash
# Clone the repository
git clone https://gitlab.com/prpl-foundation/components/core/plugins/tr181-periodicfileupload.git
cd tr181-periodicfileupload

# Build
make
```

### Deployment
```bash
# Install the plugin
make install

# Plugin will be available for AMX runtime
```

## Configuration

### Plugin Configuration

The plugin uses ODL-based configuration with the following key settings:

```odl
%config {
    scripts-directory = "/usr/bin/periodicfileupload/"; // Location of the hook script for the FileConfigType object

    trace-zones = {
        "periodic-upload" = "${default_trace_zone_level}",
        "libperiodicup" = "${default_trace_zone_level}"
    };
}
```

### Basic Configuration Example

```bash
# Enable the service
ba-cli "Device.PeriodicFileTransfer.Enable=true"

# Create a profile
ba-cli "Device.PeriodicFileTransfer.Profile.1.Protocol=HTTP"
ba-cli "Device.PeriodicFileTransfer.Profile.1.HTTP.URL=http://server.example.com/upload"
ba-cli "Device.PeriodicFileTransfer.Profile.1.HTTP.Method=POST"

# Create a transfer
ba-cli "Device.PeriodicFileTransfer.Transfer.+.Enable=true"
ba-cli "Device.PeriodicFileTransfer.Transfer.1.Type=ProcessFaults"
ba-cli "Device.PeriodicFileTransfer.Transfer.1.ProfileReference=Device.PeriodicFileTransfer.Profile.1"
ba-cli "Device.PeriodicFileTransfer.Transfer.1.UploadInterval=3600"
ba-cli "Device.PeriodicFileTransfer.Transfer.1.TimeReference=1970-01-01T00:00:00Z"
```

### Advanced Configuration with Scripts

```bash
# Configuration with pre/post processing
ba-cli "Device.PeriodicFileTransfer.FileTypeConfig.+.FileTypeReference=ProcessFaults"
ba-cli "Device.PeriodicFileTransfer.FileTypeConfig.1.FilePath=/tmp/process_faults.tar.gz"
ba-cli "Device.PeriodicFileTransfer.FileTypeConfig.1.PreHookScript=/usr/bin/periodicfileupload/generate_fault_archive.sh"
ba-cli "Device.PeriodicFileTransfer.FileTypeConfig.1.PostHookScript=/usr/bin/periodicfileupload/cleanup_fault_archive.sh"
```

## API Reference

### Plugin API (tr181-periodicfileupload.h)

#### TR-369 Functions

##### ForceTransfer()
```
Device.PeriodicFileTransfer.Transfer.{i}.ForceTransfer() → {data: string}
```

Forces an immediate file transfer execution for the specified Transfer instance.

**Parameters:**
- None

**Returns:**
- `data: string` : Result of the forced transfer after execution

**Example:**
```bash
ba-cli "Device.PeriodicFileTransfer.Transfer.1.ForceTransfer()"
```

#### Event-Driven Operations

The plugin operates through an event-driven architecture based on data model changes:

##### Application Startup
**Trigger:** `app:start` event
**Handler:** `_app_start()`
**Behavior:** Initializes plugin state based on current PeriodicFileTransfer.Enable setting

##### Global Enable/Disable
**Trigger:** `dm:object-changed` event on `PeriodicFileTransfer.Enable`
**Handler:** `_dm_filetransfer_enable()`
**Filter:** `path == "PeriodicFileTransfer." && contains("parameters.Enable")`
**Behavior:** Toggles entire file transfer functionality when global Enable parameter changes

##### Transfer Instance Management
**Trigger:** `dm:instance-added` event on Transfer table
**Handler:** `_dm_transfer_added()`
**Filter:** `path matches "^PeriodicFileTransfer\.Transfer\.$"`
**Behavior:** Registers new file transfer when Transfer instance is created (only if enabled)

##### Transfer Configuration Changes
**Trigger:** `dm:object-changed` event on Transfer parameters (excluding Status)
**Handler:** `_dm_transfer_changed()`
**Filter:** `path matches "^PeriodicFileTransfer\.Transfer\.[0-9]+\.$" && !contains("parameters.Status")`
**Behavior:**
- Re-registers transfer when parameters change
- Deregisters transfer when Enable changes from true to false

##### Transfer Status Completion
**Trigger:** `dm:object-changed` event on Transfer Status parameter
**Handler:** `_dm_transfer_status_done()`
**Filter:** `path matches "^PeriodicFileTransfer\.Transfer\.[0-9]+\.$" && (parameters.Status.to == "Success" || parameters.Status.to == "Error")`
**Behavior:** Resets Transfer Status from "Success" or "Error" back to "Idle"

##### Transfer Instance Destruction
**Trigger:** `action_object_destroy` on Transfer object
**Handler:** `_dm_transfer_destroyed()`
**Behavior:** Deregisters file transfer and cleans up resources when Transfer instance is deleted

### Library API (libperiodicfileupload.h)

#### Context Management
```c
// Initialization
int periodicfileupload_init(amxo_parser_t* parser);
void periodicfileupload_deinit(void);

// File registration
int periodicfileupload_register_file(const char* id, const char* internal_path,
                                     const char* profile_path);
void periodicfileupload_deregister_file(const char* id);
```

#### Transfer Control
```c
// Configuration
int periodicfileupload_set_interval(const char* id, uint32_t interval, amxc_ts_t* time_ref);

// Control
int periodicfileupload_start(const char* id);
int periodicfileupload_stop(const char* id);
```

#### Callback Management
```c
// Transfer status callback
void periodicfileupload_set_transfer_cb(const char* id, periodicfileupload_transfer_cb_t callback, void* priv);

// Pre/post processing callbacks
void periodicfileupload_preupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv);
void periodicfileupload_postupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv);

// Helper callback for script execution
periodicfileupload_cb_status_t periodicfileupload_exec_script_cb(const char* id, void* priv);
```

#### Callback Types
```c
// Transfer status callback - called when transfer state changes
typedef void (*periodicfileupload_transfer_cb_t)(const amxc_var_t* const status, void* const priv);

// Transfer state enumeration
typedef enum periodicfileupload_state_e {
    pfu_state_idle = 0,
    pfu_state_creating,
    pfu_state_uploading,
    pfu_state_success,
    pfu_state_retrying,
    pfu_state_error,
} periodicfileupload_state_t;

// Pre/post processing callback return status
typedef enum periodicfileupload_cb_status_e {
    PFU_CB_ERROR = -1,    // Error occurred
    PFU_CB_OK,            // Success
    PFU_CB_DELAY,         // Delay upload
} periodicfileupload_cb_status_t;

// Pre/post processing callback
typedef periodicfileupload_cb_status_t (*periodicfileupload_cb_t)(const char* id, void* priv);
```


## Transfer States and Flow

### Possible States
- **Idle** : Waiting for next transfer
- **Creating** : File generation (pre-processing script)
- **Uploading** : Transfer in progress
- **Success** : Transfer completed successfully
- **Error** : Transfer failed

### Transfer Flow
```
Idle → Uploading → Success → Idle
Idle → Uploading → Error → Idle
Idle → Uploading → Retrying → Success → Idle
Idle → Creating → Error → Idle
Idle → Creating → Uploading → Success → Idle
Idle → Creating → Uploading → Error → Idle
Idle → Creating → Uploading → Retrying → Success → Idle
```

## Usage Examples

### Force Transfer
```bash
# Force immediate transfer
ba-cli "Device.PeriodicFileTransfer.Transfer.1.ForceTransfer()"
```

### Monitoring
```bash
# Check transfer status
ba-cli "Device.PeriodicFileTransfer.Transfer.1.Status?"

# Check statistics
ba-cli "Device.PeriodicFileTransfer.Transfer.1.Stats.?"
ba-cli "Device.PeriodicFileTransfer.Stats.?"

# Monitor next transfer date
ba-cli "Device.PeriodicFileTransfer.Transfer.1.NextTransferDate?"
```

### Configuration Management
```bash
# List all profiles
ba-cli "Device.PeriodicFileTransfer.Profile.?"

# Check profile configuration
ba-cli "Device.PeriodicFileTransfer.Profile.1.?"

# List all transfers
ba-cli "Device.PeriodicFileTransfer.Transfer.?"

# Check file type configurations
ba-cli "Device.PeriodicFileTransfer.FileTypeConfig.?"
```

### Script Examples

#### Pre-upload Script (`/usr/bin/periodicfileupload/generate_fault_archive.sh`)
```bash
#!/bin/bash
# Generate process fault archive
tar -czf /tmp/process_faults.tar.gz /var/log/faults/
```

#### Post-upload Script (`/usr/bin/periodicfileupload/cleanup_fault_archive.sh`)
```bash
#!/bin/bash
# Cleanup after upload
rm -f /tmp/process_faults.tar.gz
exit 0
```

#### Pre-upload Script (`/usr/bin/periodicfileupload/generate_fault_archive_with_name.sh`)
```bash
#!/bin/bash
# Generate process fault archive
tar -czf /tmp/process_faults.tar.gz /var/log/faults/
echo -n "/tmp/process_faults.tar.gz"
```
## Security Configuration

### TLS/HTTPS with Client Certificates

The plugin supports mutual TLS authentication using client certificates and CA bundle validation:

```bash
# Configure HTTPS profile with mutual authentication
ba-cli "Device.PeriodicFileTransfer.Profile.2.Protocol=HTTP"
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.URL=https://secure.example.com/upload"
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.Username=device123"
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.Password=secretpass"
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.Method=PUT"
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.Compression=GZIP"

# Configure client certificate for mutual authentication
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.Certicate=Device.Security.Certificate.1"

# Configure CA bundle for server certificate validation
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.CABundle=Device.Security.CABundle.1"

# Configure IP version preference
ba-cli "Device.PeriodicFileTransfer.Profile.2.HTTP.IPVersion=4"
```

### Certificate Management

The plugin integrates with the Device.Security certificate management system:

#### Client Certificate Configuration
- **Purpose** : Mutual authentication with remote server
- **Reference** : Must point to `Device.Security.Certificate.{i}`
- **Usage** : Client presents certificate to server for authentication
- **Requirements** : Certificate must match client's private key

#### CA Bundle Configuration
- **Purpose** : Server certificate validation
- **Reference** : Must point to `Device.Security.CABundle.{i}`
- **Usage** : Validates server certificate against trusted CAs
- **Support** : Multiple CA certificates for different issuers

## Troubleshooting

### Logging and Debugging

The plugin supports comprehensive logging through configurable trace zones:

- periodic-upload: Main plugin operations
- libperiodicup: Library-level operations

## Security

### Authentication
- HTTP Basic Authentication (RFC 7617)
- HTTP Digest Authentication (RFC 7616)
- Certificate-based authentication for HTTPS

### File Access
- Configurable script directory restrictions
- File path validation

### Network Security
- HTTPS support with certificate validation
- Configurable CA bundle support
- IP version selection (IPv4/IPv6)

## Configuration Examples

### Retry Configuration
```bash
# Configure retry behavior
ba-cli "Device.PeriodicFileTransfer.Profile.1.HTTP.RetryEnable=true"
ba-cli "Device.PeriodicFileTransfer.Profile.1.HTTP.RetryMinimumWaitInterval=10"
ba-cli "Device.PeriodicFileTransfer.Profile.1.HTTP.RetryIntervalMultiplier=2000"
```
