/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include "processmonitor.h"
#include "dm_processmonitor.h"

/**
 * @brief Retrieves and updates the process monitoring params during validating the PM tests.
 *
 * This function queries the process monitoring enabled flag and updates the associated data models accordingly
 * If disabed, it updates the process respawn/fail datamodels defaults to -1.
 * If enabled, it updates the process respawn/fail datamodel defaults to 0 (if not set) or retains current values
 * Additionally it will query and update the Process respawn params - Threshold, Retry & Timeout from service ubus call on PM test
 *
 * @param[in] test pointer to the current PM test.
 * @param[in] trans pointer to the AMXD Transaction for the current test
 *
 */

void pm_update_process_monitoring_params(test_t* test, amxd_trans_t* trans) {
    int32_t process_fail_num = 0;
    int32_t process_respawn_num = 0;

    when_null(test, exit);

    //if process monitor flag is disabled, Process FailNum/RespawnNum always defaults to -1
    if(!test->process_monitor_enabled) {
        process_fail_num = -1;
        process_respawn_num = -1;
    } else if(test->reconfigured) {
        //if PM Test subject changed, Reset Process FailNum/RespawnNum to 0 regardless of current value
        process_fail_num = 0;
        process_respawn_num = 0;
    } else {
        //with PM Test validate, Reset Process FailNum/RespawnNum to 0 if not set or else retain current value
        process_fail_num = amxd_object_get_value(int32_t, test->object, "NumProcessFail", NULL);
        process_respawn_num = amxd_object_get_value(int32_t, test->object, "NumProcessRespawn", NULL);

        process_fail_num = (process_fail_num != -1)? process_fail_num:0;
        process_respawn_num = (process_respawn_num != -1)? process_respawn_num:0;
    }

    amxd_trans_set_value(int32_t, trans, "NumProcessFail", process_fail_num);
    amxd_trans_set_value(int32_t, trans, "NumProcessRespawn", process_respawn_num);

    //Finally call to update respawn params accordingly with PM Test validate/subject change based on process monitor flag
    pm_test_update_process_respawn_params(test);

exit:
    return;
}

/**
 * @brief   Callback invoked when a 'service.stop' ubus notify event received.
 *
 * @details This function handles the 'service.stop' event for the PM Test .
 *          It's triggered during process lifecycle management when its instance is stopped manually.
 *          It marks the PM Test -  Fail Reason as 'Process Stopped' to indicate its stopped state
 *          And sets the test interval & call update_current_test_interval() to update current test interval of PM Test
 *          to 0 with same on halting its monitoring with deliberate shutdown
 *
 * @param   test   pointer to the PM Test for which 'service.stop' event received from ubus.
 * @param   trans  pointer to the AMXD Transaction associated with the PM Test
 *
 */
static void pm_handle_process_service_stop_event(test_t* test, amxd_trans_t* trans) {

    SAH_TRACEZ_INFO(ME, "For service.stop event, Mark Fail Reason as 'Process Stopped' & set test->current_test_interval to 0 for halting its Amx monitoring");

    //setting test_interval to 0 to halt its monitoring from Amx with deliberate shutdown
    test->test_interval = 0;
    update_current_test_interval(test);
    amxd_trans_set_value(uint32_t, trans, "CurrentTestInterval", test->current_test_interval);

    //setting fail reason as Process stopped with 'service.stop' event
    test->test_halted = true;
    amxd_trans_set_value(cstring_t, trans, "LastFailReason", PM_TEST_FAIL_REASON_TEST_PROCESS_STOPPED);

}

/**
 * @brief   Callback invoked when a 'instance.fail' ubus notify event received.
 *
 * @details This function handles the 'instance.fail' event for the PM Test .
 *          It's triggered during process lifecycle management when its instance is killed/crashed exhausting its respawn threhold.
 *          It marks the PM Test -  Fail Reason as 'Process Failed' to indicate its failed state, call pm_handle_result -> pm_update_test_ko to mark service health as Bad, Increment its failNum & Execute failAction when it breaches its MaxFailNum , Finally increment 'ProcessFail' for recording the fail statistics from process/service UBUS events .
 *
 * @param   test   pointer to the PM Test for which 'instance.fail' event received from ubus.
 * @param   trans  pointer to the AMXD Transaction associated with the PM Test
 *
 */
static void pm_handle_process_instance_fail_event(test_t* test, amxd_trans_t* trans) {

    SAH_TRACEZ_INFO(ME, "For instance.fail event, Mark the Fail Reason as 'Process Failed' and Mark result as fail, call pm_handle_result->pm_update_test_status_ko");

    amxd_trans_set_value(cstring_t, trans, "LastFailReason", PM_TEST_FAIL_REASON_TEST_PROCESS_FAILED);
    amxd_trans_set_value(int32_t, trans, "NumProcessFail", amxd_object_get_value(int32_t, test->object, "NumProcessFail", NULL) + 1);

    SAH_TRACEZ_NOTICE(ME, "Process test '%s' seems to be NOK", test->name);

    amxp_timer_start(test->timer_async_check, PM_PROCESS_ASYNC_TIMEOUT);
}

/**
 * @brief   Callback invoked when a 'instance.stop' ubus notify event received.
 *
 * @details This function handles the 'instance.stop' event for the PM Test .
 *          It's triggered during process lifecycle management when its instance is killed/crashed with failure within its respawn threshold.
 *          It marks the PM Test -  Fail Reason as 'Process Stopped' to indicate its stopped state before respawning, call pm_handle_result -> pm_update_test_ko to mark service health as Bad, Increment its failNum & Execute failAction when it breaches its MaxFailNum
 *
 * @param   test   pointer to the PM Test for which 'instance.stop' event received from ubus.
 * @param   trans  pointer to the AMXD Transaction associated with the PM Test
 *
 */
static void pm_handle_process_instance_stop_event(test_t* test, amxd_trans_t* trans) {
    SAH_TRACEZ_INFO(ME, "For instance.stop event, Mark result as fail and call pm_handle_result->pm_update_test_status_ko, Mark Fail Reason as Process Instance Stopped");

    amxd_trans_set_value(cstring_t, trans, "LastFailReason", PM_TEST_FAIL_REASON_TEST_PROCESS_INSTANCE_STOPPED);

    SAH_TRACEZ_NOTICE(ME, "Process test '%s' seems to be NOK", test->name);

    amxp_timer_start(test->timer_async_check, PM_PROCESS_ASYNC_TIMEOUT);
}

/**
 * @brief   Callback invoked when a 'service.start' ubus notify event received.
 *
 * @details This function handles the 'service.start' event for the PM Test .
 *          It's triggered during process lifecycle management when its service is started from its init script
 *          Resetting ProcessRespawn to 0, indicating a clean service start that disregards any previous respawn history.
 *          And will set back the current test interval to test_interval to enable its monitoring back on Amx if its disabled before.
 *
 * @param   test   pointer to the PM Test for which 'service.start' event received from ubus.
 * @param   trans  pointer to the AMXD Transaction associated with the PM Test
 *
 */
static void pm_handle_process_service_start_event(test_t* test, amxd_trans_t* trans) {

    SAH_TRACEZ_INFO(ME, "Service start detected — Resetting ProcessRespawn to 0, indicating a clean service start");
    amxd_trans_set_value(int32_t, trans, "NumProcessRespawn", 0);

    test->test_halted = false;
    test->test_interval = amxd_object_get_value(uint32_t, test->object, "TestInterval", NULL);

    // if the service intended to start manually, would have test interval not set by default. Once they started, setting their test interval with default monitoring interval (Plugin:60s, Process:30s , Custom/Other: 120s) on enable their monitoring with Amx process monitor
    if(test->test_interval <= 0) {

        switch(test->type) {
        case PM_TEST_TYPE_PLUGIN:
            test->test_interval = DEF_AMX_TEST_MONITORING_INTERVAL;
            break;
        case PM_TEST_TYPE_PROCESS:
            test->test_interval = DEF_AMX_TEST_MONITORING_INTERVAL / 2;
            break;
        default:
            test->test_interval = DEF_AMX_TEST_MONITORING_INTERVAL * 2;
            break;
        }

        amxd_trans_set_value(uint32_t, trans, "TestInterval", test->test_interval);
    }

    //setting current_test_interval back to test_interval to continue its monitoring from Amx after starting back
    update_current_test_interval(test);
    amxd_trans_set_value(uint32_t, trans, "CurrentTestInterval", test->current_test_interval);
    test->initialized = false;
}


/**
 * @brief   Callback invoked when a 'instance.respawn' ubus notify event received.
 *
 * @details This function handles the 'instance.respawn' event for the PM Test .
 *          It's triggered during process lifecycle management when its service is respawned after its being killed/crashed by init process
 *          Increment ProcessRespawn DataModel to record the 'instance.respawn' statistics for the current PM Test.
 *
 * @param   test   pointer to the PM Test for which 'instance.respawn' event received from ubus.
 * @param   trans  pointer to the AMXD Transaction associated with the PM Test
 */
static void pm_handle_process_instance_respawn_event(test_t* test, amxd_trans_t* trans) {

    SAH_TRACEZ_INFO(ME, "Instance respawn detected — Incrementing ProcessRespawn for recording the respawn statistics from process/service UBUS events");
    amxd_trans_set_value(int32_t, trans, "NumProcessRespawn", amxd_object_get_value(int32_t, test->object, "NumProcessRespawn", NULL) + 1);
}

/**
 * @brief   Determines and invokes the appropriate callback for service/process UBUS events received for the PM Test.
 *
 * @details This function validates incoming UBUS events related to the PM Test and triggers the corresponding
 *          callback based on the event method. It ensures that updates are handled correctly as part of
 *          process lifecycle management.
 *
 * @param   event    char pointer indicating the type of process/service UBUS event received.
 * @param   test     pointer to the PM Test associated with the received UBUS event.
 * @param   trans    pointer to the AMXD Transaction associated with the PM Test
 *
 */
static void pm_handle_process_event(test_t* test, const char* event, amxd_trans_t* trans) {

    if((strcmp(event, "instance.start") != 0) || (strcmp(test->last_event, "instance.respawn") != 0)) {
        strncpy(test->last_event, event, sizeof(test->last_event) - 1);
        test->last_event[sizeof(test->last_event) - 1] = '\0';
    }

    if(!strcmp(event, "service.start")) {
        pm_handle_process_service_start_event(test, trans);
    } else if(!strcmp(event, "instance.start")) {
        pm_test_update_process_respawn_params(test);
    } else if(!strcmp(event, "instance.respawn")) {
        pm_handle_process_instance_respawn_event(test, trans);
    } else if(!strcmp(event, "instance.stop")) {
        pm_handle_process_instance_stop_event(test, trans);
    } else if(!strcmp(event, "instance.fail")) {
        pm_handle_process_instance_fail_event(test, trans);
    } else {
        pm_handle_process_service_stop_event(test, trans);
    }

    return;
}

/**
 * @brief   Common Unified handler for AMXD transactions triggered by process events.
 *
 * @details This function initiates AMXD transaction, sets attributes, triggers event handling via pm_handle_process_event, and commits changes to AMXRT Data Model
 *
 * @param   method   Pointer to the method indicating the type of process/service UBUS event received.
 * @param   test     Pointer to the PM Test associated with the received UBUS event.
 */
void pm_apply_process_event_update(test_t* test, const char* method) {
    amxd_trans_t transaction;
    amxd_status_t status = amxd_status_ok;

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, test->object);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);

    when_null_trace(test, exit, WARNING, "Test is NULL");

    pm_handle_process_event(test, method, &transaction);

    status = amxd_trans_apply(&transaction, get_dm());

    when_false_trace(status == amxd_status_ok, exit, ERROR, "Failed to map '%s' event to AMX DataModel for service: %s (error: %d)", method, test->name, status);

    SAH_TRACEZ_INFO(ME, "'%s' event mapped to AMX ProcessMonitor DataModel successfully for service: %s", method, test->name);

exit:
    amxd_trans_clean(&transaction);
    return;
}
