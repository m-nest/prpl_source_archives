/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "test_generate_unbound_conf.h"
#include "mock.h"
#include "mock_dm.h"
#include "modunbound.h"

#define outfile "/tmp/hashes"
#define hash_store "hash_db/"

static bool with_unbound_checkconf = false;

int test_setup(void** state) {
    amxd_object_t* root = NULL;
    FILE* fp = NULL;
    char buf[64] = {0};

    amxut_bus_setup(state);

    root = amxd_dm_get_root(amxut_bus_dm());
    assert_non_null(root);

    mock_dm_init(amxut_bus_dm(), amxut_bus_parser(), root);

    amxut_bus_handle_events();

    fp = popen("unbound-checkconf -h", "r");
    assert_non_null(fp);
    while(fgets(buf, sizeof(buf) - 1, fp) != NULL) {
        if(strstr(buf, "Usage:	unbound-checkconf") != NULL) {
            with_unbound_checkconf = true;
            break;
        }
    }

    pclose(fp);

    return 0;
}

int test_teardown(void** state) {
    amxm_close_all();
    amxut_bus_teardown(state);
    return 0;
}

static bool compare_hashes(const char* saved_hashes) {
    FILE* fp1 = NULL;
    FILE* fp2 = NULL;
    char buf1[1000];
    char buf2[1000];
    bool equal = false;

    fp1 = fopen(saved_hashes, "r");
    fp2 = fopen(outfile, "r");

    assert_non_null(fp1);
    assert_non_null(fp2);

    while(1) {
        char* c1 = fgets(buf1, sizeof(buf1) - 1, fp1);
        char* c2 = fgets(buf2, sizeof(buf2) - 1, fp2);

        if((c1 == NULL) && (c2 == NULL)) {
            break;
        }

        if((c1 == NULL) || (c2 == NULL) || (strcmp(buf1, buf2) != 0)) {
            print_error("%s != %s", buf1, buf2);
            goto exit;
        }
    }

    equal = true;

exit:
    fclose(fp1);
    fclose(fp2);
    return equal;
}

static void statistics(void) {
    FILE* fp = NULL;
    fp = popen("sort " outfile " | uniq | wc -l", "r");
    if(fp != NULL) {
        int unique_hashes = 0;
        if(fscanf(fp, "%d", &unique_hashes) == 1) {
            print_message("generated %d unique unbound.conf files\n", unique_hashes);
        }
    }
    pclose(fp);
}

static bool valid_unbound_conf(const char* interface) {
    amxc_string_t system_cmd;
    FILE* fp = NULL;
    bool ok = false;
    char buf[1000] = {0};

    amxc_string_init(&system_cmd, 0);
    amxc_string_setf(&system_cmd, "unbound-checkconf " DNS_UNBOUND_CONFIG_FILE, interface);

    fp = popen(amxc_string_get(&system_cmd, 0), "r");
    if(fp != NULL) {
        while(fgets(buf, sizeof(buf) - 1, fp) != NULL) {
            if(strstr(buf, "unbound-checkconf: no errors in ") != NULL) {
                ok = true;
                break;
            }
        }
    }

    pclose(fp);
    amxc_string_clean(&system_cmd);
    return ok;
}

/**
 * This test will in a loop call random fuctions of the mod-dns-unbound amxm API.
 * It will do some minimal checking where possible on expected result (rv == 0 or -1).
 * After each call a hash of the generated unbound.conf (CFLAG -DDNS_UNBOUND_CONFIG_FILE=/tmp/etc/unbound/unbound.config) is appended to outfile="/tmp/hashes"
 * and if unbound-checkconf is installed then it is used to make sure the generated unbound.conf is valid.
 *
 * When the loop is done some statistics are printed: number of unique hashes in outfile
 * and the outfile is compared to a previously stored file of hashes (./hash_db/set1).
 * The 2 files should be equal unless the (order of) function pointers in set1[] changed or the input changed or the generation of unbound.conf has changed.
 * In the latter case if this is not expected it is likely a regression and the root cause of the change has to be found.
 *
 * If the ./hash_db/set1 should be updated then simply run the tests, they will fail on the compare, then simply "cp /tmp/hashes ./hash_db/set1" and rerun the tests.
 *
 * Tricks:
 * If you want to see what hash at line 100 of ./hash_db/set1 represent use gdb to put breakpoint at the line number "ok = set1[actor](rand());" and make it conditional "cond 1 i==100" (remember the hash is at line 100 of ./hash_db/set1)
 * It is then possible to "cat /tmp/etc/unbound/unbound-<intf>.config" before and after the test.
 */
void test_generate_from_set1(UNUSED void** state) {
    amxc_string_t system_cmd;
    const char* interface[3] = {"lo", "br-lan", "br-guest"};
    int max = 500;               // for range 100 - 500 there seems to be a trend of "uniq hashes = (max / 100) * 37"

    fclose(fopen(outfile, "w")); // start from empty file

    amxc_string_init(&system_cmd, 0);

    for(int i = 0; i < max; i++) {
        int api = rand() % sizeof_set1;
        bool ok = false;

        ok = set1[api](rand());
        if(!ok) {
            print_error("test %d - iteration %d", api, i);
        }
        assert_true(ok);

        if(with_unbound_checkconf) {
            for(int j = 0; j < 3; j++) {
                bool intf_ok = false;
                intf_ok = valid_unbound_conf(interface[j]);
                if(!intf_ok) {
                    print_error("test %d - iteration %d: invalid unbound.conf", api, i);
                }
                ok |= intf_ok;
            }
            assert_true(ok);
        }

        print_message(".");
        for(int j = 0; j < 3; j++) {
            amxc_string_setf(&system_cmd, "if [ -f " DNS_UNBOUND_CONFIG_FILE " ]; then md5sum " DNS_UNBOUND_CONFIG_FILE " | awk ' { print $1 }' >> " outfile "; fi", interface[j], interface[j]);
            system(amxc_string_get(&system_cmd, 0));
        }
    }
    print_message("\n");
    statistics();
    if(!with_unbound_checkconf) {
        print_message("skipped unbound-checkconf: please install unbound to enable\n");
    }
    assert_true(compare_hashes(hash_store "set1"));
    amxc_string_clean(&system_cmd);
}