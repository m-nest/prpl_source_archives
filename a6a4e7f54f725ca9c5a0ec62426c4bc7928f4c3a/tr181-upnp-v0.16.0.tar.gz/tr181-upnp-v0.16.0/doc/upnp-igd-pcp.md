# **UPnP-IGD PCP interworking**
[Requirements](#upnp-igdpcpinterworking-requirements) 

[Introduction and High-Level Description](#upnp-igdpcpinterworking-introductionandhigh-leveldescription) 

[High-Level Description](#upnp-igdpcpinterworking-high-leveldescription)

[Use Case Definition](#upnp-igdpcpinterworking-usecasedefinition)

[References](#upnp-igdpcpinterworking-references)

[Architecture](#upnp-igdpcpinterworking-architecture)

[Implementation](#upnp-igdpcpinterworking-implementation) 

[Handling CPE reboots](#upnp-igdpcpinterworking-handlingcpereboots)

[Data Model](#upnp-igdpcpinterworking-datamodel)

[Low-Level API](#upnp-igdpcpinterworking-low-levelapi)

[API](#upnp-igdpcpinterworking-api)

[Files](#upnp-igdpcpinterworking-files)

[Firewall](#upnp-igdpcpinterworking-firewall)

[Dependants and Dependencies](#upnp-igdpcpinterworking-dependantsanddependencies) 

[Dependants](#upnp-igdpcpinterworking-dependants)

[Dependencies](#upnp-igdpcpinterworking-dependencies)

[Configuration](#upnp-igdpcpinterworking-configuration)

[Backup/Restore, Upgrade, Reset](#upnp-igdpcpinterworking-backup/restore,upgrade,reset)

[Web UI](#upnp-igdpcpinterworking-webui)

[Considerations](#upnp-igdpcpinterworking-considerations) 

[IPv6](#upnp-igdpcpinterworking-ipv6)

[Packet Acceleration](#upnp-igdpcpinterworking-packetacceleration)

[Memory Usage](#upnp-igdpcpinterworking-memoryusage)

[Boot Time](#upnp-igdpcpinterworking-boottime)

[Security](#upnp-igdpcpinterworking-security)

[Remote Management](#upnp-igdpcpinterworking-remotemanagement)

[Operational Monitoring](#upnp-igdpcpinterworking-operationalmonitoring)

[Quality](#upnp-igdpcpinterworking-quality) 

[Project Reference Configuration](#upnp-igdpcpinterworking-projectreferenceconfiguration)

[Build-time Checks](#upnp-igdpcpinterworking-build-timechecks)

[Run-time Checks](#upnp-igdpcpinterworking-run-timechecks)

[Unit Tests](#upnp-igdpcpinterworking-unittests)

[Logging and Debugging](#upnp-igdpcpinterworking-logginganddebugging)

[Functional Tests](#upnp-igdpcpinterworking-functionaltests)

[CI Tests](#upnp-igdpcpinterworking-citests)

[Certification](#upnp-igdpcpinterworking-certification)

[Design Review Documentation](#upnp-igdpcpinterworking-designreviewdocumentation)
# <a name="upnp-igdpcpinterworking-requirements"></a>**Requirements**
## <a name="upnp-igdpcpinterworking-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
This document describes the integration of Universal Plug and Play Internet Gateway Device (UPnP-IGD) with Port Control Protocol (PCP) in a router to interact with Carrier Grade NAT (CGNAT) server. The goal is to explain how these two features work together to manage network address translation (NAT) and port forwarding, enabling seamless communication between devices on a local area network (LAN) and a remote home gateway. This feature is particularly used when the router does not have a public IPv4 address, where simple NAT is not possible and still allow end-user inbound IPv4 traffic on select port. A typical use case is when DSLite is used in combination with CGNAT (Carrier Grade NAT)
### <a name="upnp-igdpcpinterworking-high-leveldescription"></a>**High-Level Description**
**UPnP-IGD**:

- UPnP-IGD is a protocol that allows devices on a LAN to automatically configure the router for seamless internet connectivity.
- It simplifies the process of setting up port forwarding rules, enabling applications to communicate through the router without manual configuration.

**PCP**:

- PCP is a protocol that allows devices to control how incoming traffic is forwarded by the router.
- It is used to manage NAT and firewall traversal, ensuring that devices behind the router can receive incoming connections.
- PCP is especially useful when the router does not have a public IPv4 address, as it helps manage communication through multiple layers of NAT.

**Integration of UPnP-IGD and PCP**:

- When a device on the LAN sends a UPnP request to the router, the router translates this request into a PCP request.
- The PCP request is then sent to the remote HGW to establish the necessary port forwarding rules.
- This integration ensures that devices on the LAN can communicate with external networks efficiently, leveraging the capabilities of both UPnP-IGD and PCP.

By combining UPnP-IGD and PCP, the router can dynamically manage port forwarding and NAT traversal, providing a seamless and automated network configuration experience for users. This is particularly beneficial in scenarios where the router does not have a public IPv4 address, ensuring reliable connectivity and communication.

**Limitations:**

- The PCP protocol allows for a suggested port to be specified in the inbound mapping request. However, if the suggested port is not available, the CGNAT (Carrier-Grade NAT) server can assign a different port.
- Due to the dynamic nature of port allocation in PCP, there is no guarantee that the requested port will always be available. This can be problematic for applications that rely on specific ports for communication.
- Only the AddAnyPortMapping() UPnP call supports scenarios where the offered port may differ from the requested port. Standard AddPortMapping() cannot handle port reassignment gracefully, and will return an error n such scenario. This will potentially lead to connectivity issues if an exact port is required by requesting application.
## <a name="upnp-igdpcpinterworking-usecasedefinition"></a>**Use Case Definition[](https://prplfoundationcloud.atlassian.net/issues/?jql=project%20in%20\(%22Product%20Steering%20Committee%20\(PSC\)%22\)%20AND%20key%20=%20%22PSCP-n%22%20ORDER%20BY%20type,%20created%20DESC)**
<https://prplfoundationcloud.atlassian.net/issues/?jql=project%20in%20(%22Product%20Steering%20Committee%20(PSC)%22)%20AND%20key%20=%20%22PSCP-n%22%20ORDER%20BY%20type,%20created%20DESC> 
## <a name="upnp-igdpcpinterworking-references"></a>**References**
- [UPnP IGD 2.0: Internet Gateway Device (IGD) Standardized DCP](<http://upnp.org/specs/gw/UPnP-gw-InternetGatewayDevice-v2-Device.pdf>)
- [RFC 6887 - Port Control Protocol (PCP)](<https://tools.ietf.org/html/rfc6887>)
- [RFC 6970 - Universal Plug and Play (UPnP) Internet Gateway Device - Port Control Protocol Interworking Function DIGD-PCP IWF)(<https://datatracker.ietf.org/doc/html/rfc6970> )
- [RFC 7291 - DHCPv6 options to enable PCP] <https://www.rfc-editor.org/rfc/rfc7291.html>
- [TR181 PCP DM definition] <https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.PCP.>
# <a name="upnp-igdpcpinterworking-architecture"></a>**Architecture**
The feature relies mostly on TR181-UPnP plugin that uses miniupnpd has a backend and on the existing TR181-PCP plugin.
# <a name="upnp-igdpcpinterworking-implementation"></a>**Implementation**
Enhancements have been made to the UPnP-IGD module to integrate with PCP. A detection mechanism has been added to check when PCP is enabled. This is achieved by performing a check using the "PCP.Client.\*.Server.[Status == "Enabled"]." data model search path.

When PCP is enabled, any UPnP addPortMapping operations are translated into requests to the PCP data model to add a corresponding InboundMapping entry. If PCP is disabled, the UPnP-IGD module will revert to its previous behavior of adding a NAT instance in the firewall.

By default, miniupnp would refuse any PortMapping operations when it detects a WAN IPv4 address in a private range, which is typically the scenario where PCP is needed. A new configuration option, pf\_allow\_reserved\_addr, has been introduced to allow this behavior when set to "yes," enabling LAN clients to perform PortMapping operations even in such cases.
## <a name="upnp-igdpcpinterworking-handlingcpereboots"></a>**Handling CPE reboots**
According to RFC 6970 §4.1, there is no state persistence on the UPnP side. This means that after a Customer Premises Equipment (CPE) reboot, applications are responsible for re-issuing their port mapping requests.

For PCP communication with CG-NAT, the PCP plugin will handle the unregistration of port mappings. In the event of an unexpected CPE reboot, the lifetime parameter specified in PCP requests ensures that port mappings are automatically cleaned up on the CG-NAT side once the lifetime expires.
## <a name="upnp-igdpcpinterworking-datamodel"></a>**Data Model**
There is no specific datamodel as the feature relies on already existing data model.

PCP maps will be exposed in the PCP Data model as inbound mappings

In the PCP.Client.{i}.Server.{i}.InboundMapping Data model, an [Origin ](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.PCP.Client.Server.InboundMapping.Origin)parameter exposes who created a given InboundMapping instance. For the UPnP IGD interworking feature it will be set to *UPnP\_IWF*.
## <a name="upnp-igdpcpinterworking-low-levelapi"></a>**Low-Level API**
N/A
## <a name="upnp-igdpcpinterworking-api"></a>**API**
A new pf\_allow\_reserved\_addr option has been implemented in miniupnpd to allow UPnP-IGD usage when CPE has a WAN IPv4 address in a private range.
## <a name="upnp-igdpcpinterworking-files"></a>**Files**
N/A
## <a name="upnp-igdpcpinterworking-firewall"></a>**Firewall**
Similar as in normal PCP Inbound mappings, the FORWARD chain in iptables must be configured to allow the incoming streams (WAN to LAN). By default WAN to LAN traffic is only allowing ESTABLISHED, RELATED traffic. For each stream a dedicated WAN to LAN FORWARD rule will be available.
## <a name="upnp-igdpcpinterworking-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="upnp-igdpcpinterworking-dependants"></a>**Dependants**
N/A
### <a name="upnp-igdpcpinterworking-dependencies"></a>**Dependencies**
This feature adds a dependency from TR181-UPnP to TR181-PCP.

Feature also depends on miniupnpd with additional patches. This can be found in this gitlab repository: <https://gitlab.com/prpl-foundation/mirrors/miniupnpd/-/tree/gen_miniupnpd_2_3_3?ref_type=heads>
## <a name="upnp-igdpcpinterworking-configuration"></a>**Configuration**
The UPnP-IGD PCP interworking feature should be automatically enabled when PCP and DSlite (or CGNAT) are enabled.

PCP is usually enabled through specific DHPv6 options as described in RFC 7291.
## <a name="upnp-igdpcpinterworking-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
UPnP Portmapping rules have a limited lifetime and are not persistent, nor back-up persistent by default.
## <a name="upnp-igdpcpinterworking-webui"></a>**Web UI**
UPnP Portmapping rules can be retrieved in the Data Model, so they cold be retrieved by UI for display. These rules cannot be modified by the UI.
# <a name="upnp-igdpcpinterworking-considerations"></a>**Considerations**
## <a name="upnp-igdpcpinterworking-ipv6"></a>**IPv6**
The UPnP-IGD PCP interworking feature is only applicable for IPv4.

It is is typically used in a DS-Lite environment, when using CGNAT.
## <a name="upnp-igdpcpinterworking-packetacceleration"></a>**Packet Acceleration**
Forwarded inbound streams are subject to hardware acceleration.
## <a name="upnp-igdpcpinterworking-memoryusage"></a>**Memory Usage**
The Memory usage is directly proportional with the number of Inbound Mappings which are configured.
## <a name="upnp-igdpcpinterworking-boottime"></a>**Boot Time**
The feature does not impact the boot time, as the rules are not persistent, all UPnP rules will be created when the HGW is active, and when requested by UPnP clients, not at boot.
## <a name="upnp-igdpcpinterworking-security"></a>**Security**
The UPnP-IGD does not require any form of authentication. While prplOS has an implementation, it is not recommended to deploy this.

This specific subfeature of IGD does not affect the LAN-facing security issues.
## <a name="upnp-igdpcpinterworking-remotemanagement"></a>**Remote Management**
N/A
## <a name="upnp-igdpcpinterworking-operationalmonitoring"></a>**Operational Monitoring**
Active inbound rules can be monitored through the PCP Data model.

<https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.PCP.Client.Server.InboundMapping.>
# <a name="upnp-igdpcpinterworking-quality"></a>**Quality**
## <a name="upnp-igdpcpinterworking-projectreferenceconfiguration"></a>**Project Reference Configuration**
The feature is disabled by default.

The feature will be enabled automatically when CGNAT is configured and at least one PCP server is activate/enabled.
## <a name="upnp-igdpcpinterworking-build-timechecks"></a>**Build-time Checks**
## <a name="upnp-igdpcpinterworking-run-timechecks"></a>**Run-time Checks**
## <a name="upnp-igdpcpinterworking-unittests"></a>**Unit Tests**
## <a name="upnp-igdpcpinterworking-logginganddebugging"></a>**Logging and Debugging**
## <a name="upnp-igdpcpinterworking-functionaltests"></a>**Functional Tests**
Test requires a CPE that is connected typically in a DSLite mode with a CGNAT or a stub.

|**Step**|**Test designation**|**Description** |**Expected result**|
| :-: | :-: | :-: | :-: |
|1|Display datamodel and setup subscription|<p>On CPE ba-cli:</p><p>Device.PCP.?</p><p>Device.UPnP.Device.?</p><p>Subscribe to track PCP datamodel updates</p><p>Device.PCP.?&</p>|<p>Datamodel should be displayed.</p><p>PCP should be enable without any rule yet. check following parameter are filled in:</p><p>Device.PCP.Client.1.Enable=1</p><p>Device.PCP.Client.1.Status="Enabled"</p><p>Device.PCP.Client.1.Server.1.Enable=1</p><p>Device.PCP.Client.1.Server.1.ServerAddressInUse="2001:470:cb55:800::13"</p><p>Device.PCP.Client.1.Server.1.Status="Enabled"</p><p>UPnP-IGD should be enabled</p><p>Device.UPnP.Device.UPnPIGD=1</p>|
|2|Request a to create port mapping using upnpc|<p>On LAN device command line:</p><p>upnpc -m eth1 -e "Testing UPnP-IGD PCP 1"  -a 192.168.1.78 6666 9999 tcp</p>|<p>upnpc should answer with success:</p><p>external 192.0.3.2:9999 TCP is redirected to internal 192.168.1.78:6666</p><p>PCP datamodel should update showing a new InboundMapping entry:</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Alias="cpe-InboundMapping-7"</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.AssignedExternalIPAddress=""</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.AssignedExternalPort=0</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.AssignedExternalPortEndRange=0</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Description="Testing UPnP-IGD PCP 1"</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Enable=1</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.ErrorCode=0</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.FilterNumberOfEntries=0</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.InternalPort=6666</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Lifetime=604800</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Origin="UPnP\_IWF"</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.ProtocolNumber=6</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.Status="Error"</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.SuggestedExternalIPAddress=""</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.SuggestedExternalPort=9999</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.SuggestedExternalPortEndRange=0</p><p>Device.PCP.Client.1.Server.1.InboundMapping.7.ThirdPartyAddress="192.168.1.78"</p>|
|3|List newly created port mapping from upnp|<p>On LAN device command line:</p><p>upnpc  -m eth1 -L</p>|<p>upnpc should list the newly created rule:</p><p>0 TCP  9999->192.168.1.78:6666  'Testing UPnP-IGD PCP 1' '' 578822</p>|
|4|Update the mapping i.e: change internal port)|<p>On LAN device command line:</p><p>upnpc -m eth1 -e "Testing UPnP-IGD PCP 1"  -a 192.168.1.78 7777 9999 tcp</p>|<p>PCP datamodel should update:</p><p>[2024-08-05T17:14:39Z] Event dm:object-changed received from Device.PCP.Client.1.Server.1.InboundMapping.7.</p><p><  dm:object-changed> Device.PCP.Client.1.Server.1.InboundMapping.7.InternalPort = 6666 -> 7777</p>|
|5|List mappings again from upnp to check change has bee reflected|<p>On LAN device command line:</p><p>upnpc  -m eth1 -L</p>|<p>upnpc should list the NAT with updated portL</p><p>1 TCP  9999->192.168.1.78:7777  'Testing UPnP-IGD PCP 1' '' 578822</p>|
|6|Delete port mapping entry from upnp|<p>On LAN device command line:</p><p>` `upnpc  -m eth1 -d  9999 tcp</p>|<p>PCP datamodel should update with InboundPortMapping entry gone:</p><p>[2024-08-05T17:28:49Z] Event dm:instance-removed received from Device.PCP.Client.1.Server.1.InboundMapping.</p><p><dm:instance-removed> Device.PCP.Client.1.Server.1.InboundMapping.7.</p><p></p><p>[2024-08-05T17:28:49Z] Event dm:object-changed received from Device.PCP.Client.1.Server.1.</p><p><  dm:object-changed> Device.PCP.Client.1.Server.1.InboundMappingNumberOfEntries = 2 -> 1</p>|
|7|List mappings to check port mapping entry is gone|<p>On LAN device command line:</p><p>upnpc  -m eth1 -L</p>|upnpc doesn’t report any redirection anymore|
|8|Disable UPnP-IGD and check no more redirection can be done|<p>On CPE ba-cli:</p><p>Device.UPnP.Device.UPnPIGD=0</p>|<p>PCP datamodel should not update</p><p>upnpc should report</p><p>No IGD UPnP Device found on the network !</p>|
## <a name="upnp-igdpcpinterworking-citests"></a>**CI Tests**
Unless CDRouter can perform such testing, it would be very difficult to achieve CI testing here.
## <a name="upnp-igdpcpinterworking-certification"></a>**Certification**
# <a name="upnp-igdpcpinterworking-designreviewdocumentation"></a>**Design Review Documentation**
