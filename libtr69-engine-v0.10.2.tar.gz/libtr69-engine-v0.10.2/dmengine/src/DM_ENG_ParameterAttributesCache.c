/*
 * ----------------------------------------------------------------------------
 *                                 Apache License
 *                           Version 2.0, January 2004
 *                        http://www.apache.org/licenses/
 *
 *   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
 *
 *   1. Definitions.
 *
 *      "License" shall mean the terms and conditions for use, reproduction,
 *      and distribution as defined by Sections 1 through 9 of this document.
 *
 *      "Licensor" shall mean the copyright owner or entity authorized by
 *      the copyright owner that is granting the License.
 *
 *      "Legal Entity" shall mean the union of the acting entity and all
 *      other entities that control, are controlled by, or are under common
 *      control with that entity. For the purposes of this definition,
 *      "control" means (i) the power, direct or indirect, to cause the
 *      direction or management of such entity, whether by contract or
 *      otherwise, or (ii) ownership of fifty percent (50%) or more of the
 *      outstanding shares, or (iii) beneficial ownership of such entity.
 *
 *      "You" (or "Your") shall mean an individual or Legal Entity
 *      exercising permissions granted by this License.
 *
 *      "Source" form shall mean the preferred form for making modifications,
 *      including but not limited to software source code, documentation
 *      source, and configuration files.
 *
 *      "Object" form shall mean any form resulting from mechanical
 *      transformation or translation of a Source form, including but
 *      not limited to compiled object code, generated documentation,
 *      and conversions to other media types.
 *
 *      "Work" shall mean the work of authorship, whether in Source or
 *      Object form, made available under the License, as indicated by a
 *      copyright notice that is included in or attached to the work
 *      (an example is provided in the Appendix below).
 *
 *      "Derivative Works" shall mean any work, whether in Source or Object
 *      form, that is based on (or derived from) the Work and for which the
 *      editorial revisions, annotations, elaborations, or other modifications
 *      represent, as a whole, an original work of authorship. For the purposes
 *      of this License, Derivative Works shall not include works that remain
 *      separable from, or merely link (or bind by name) to the interfaces of,
 *      the Work and Derivative Works thereof.
 *
 *      "Contribution" shall mean any work of authorship, including
 *      the original version of the Work and any modifications or additions
 *      to that Work or Derivative Works thereof, that is intentionally
 *      submitted to Licensor for inclusion in the Work by the copyright owner
 *      or by an individual or Legal Entity authorized to submit on behalf of
 *      the copyright owner. For the purposes of this definition, "submitted"
 *      means any form of electronic, verbal, or written communication sent
 *      to the Licensor or its representatives, including but not limited to
 *      communication on electronic mailing lists, source code control systems,
 *      and issue tracking systems that are managed by, or on behalf of, the
 *      Licensor for the purpose of discussing and improving the Work, but
 *      excluding communication that is conspicuously marked or otherwise
 *      designated in writing by the copyright owner as "Not a Contribution."
 *
 *      "Contributor" shall mean Licensor and any individual or Legal Entity
 *      on behalf of whom a Contribution has been received by Licensor and
 *      subsequently incorporated within the Work.
 *
 *   2. Grant of Copyright License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      copyright license to reproduce, prepare Derivative Works of,
 *      publicly display, publicly perform, sublicense, and distribute the
 *      Work and such Derivative Works in Source or Object form.
 *
 *   3. Grant of Patent License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      (except as stated in this section) patent license to make, have made,
 *      use, offer to sell, sell, import, and otherwise transfer the Work,
 *      where such license applies only to those patent claims licensable
 *      by such Contributor that are necessarily infringed by their
 *      Contribution(s) alone or by combination of their Contribution(s)
 *      with the Work to which such Contribution(s) was submitted. If You
 *      institute patent litigation against any entity (including a
 *      cross-claim or counterclaim in a lawsuit) alleging that the Work
 *      or a Contribution incorporated within the Work constitutes direct
 *      or contributory patent infringement, then any patent licenses
 *      granted to You under this License for that Work shall terminate
 *      as of the date such litigation is filed.
 *
 *   4. Redistribution. You may reproduce and distribute copies of the
 *      Work or Derivative Works thereof in any medium, with or without
 *      modifications, and in Source or Object form, provided that You
 *      meet the following conditions:
 *
 *      (a) You must give any other recipients of the Work or
 *          Derivative Works a copy of this License; and
 *
 *      (b) You must cause any modified files to carry prominent notices
 *          stating that You changed the files; and
 *
 *      (c) You must retain, in the Source form of any Derivative Works
 *          that You distribute, all copyright, patent, trademark, and
 *          attribution notices from the Source form of the Work,
 *          excluding those notices that do not pertain to any part of
 *          the Derivative Works; and
 *
 *      (d) If the Work includes a "NOTICE" text file as part of its
 *          distribution, then any Derivative Works that You distribute must
 *          include a readable copy of the attribution notices contained
 *          within such NOTICE file, excluding those notices that do not
 *          pertain to any part of the Derivative Works, in at least one
 *          of the following places: within a NOTICE text file distributed
 *          as part of the Derivative Works; within the Source form or
 *          documentation, if provided along with the Derivative Works; or,
 *          within a display generated by the Derivative Works, if and
 *          wherever such third-party notices normally appear. The contents
 *          of the NOTICE file are for informational purposes only and
 *          do not modify the License. You may add Your own attribution
 *          notices within Derivative Works that You distribute, alongside
 *          or as an addendum to the NOTICE text from the Work, provided
 *          that such additional attribution notices cannot be construed
 *          as modifying the License.
 *
 *      You may add Your own copyright statement to Your modifications and
 *      may provide additional or different license terms and conditions
 *      for use, reproduction, or distribution of Your modifications, or
 *      for any such Derivative Works as a whole, provided Your use,
 *      reproduction, and distribution of the Work otherwise complies with
 *      the conditions stated in this License.
 *
 *   5. Submission of Contributions. Unless You explicitly state otherwise,
 *      any Contribution intentionally submitted for inclusion in the Work
 *      by You to the Licensor shall be under the terms and conditions of
 *      this License, without any additional terms or conditions.
 *      Notwithstanding the above, nothing herein shall supersede or modify
 *      the terms of any separate license agreement you may have executed
 *      with Licensor regarding such Contributions.
 *
 *   6. Trademarks. This License does not grant permission to use the trade
 *      names, trademarks, service marks, or product names of the Licensor,
 *      except as required for reasonable and customary use in describing the
 *      origin of the Work and reproducing the content of the NOTICE file.
 *
 *   7. Disclaimer of Warranty. Unless required by applicable law or
 *      agreed to in writing, Licensor provides the Work (and each
 *      Contributor provides its Contributions) on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *      implied, including, without limitation, any warranties or conditions
 *      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
 *      PARTICULAR PURPOSE. You are solely responsible for determining the
 *      appropriateness of using or redistributing the Work and assume any
 *      risks associated with Your exercise of permissions under this License.
 *
 *   8. Limitation of Liability. In no event and under no legal theory,
 *      whether in tort (including negligence), contract, or otherwise,
 *      unless required by applicable law (such as deliberate and grossly
 *      negligent acts) or agreed to in writing, shall any Contributor be
 *      liable to You for damages, including any direct, indirect, special,
 *      incidental, or consequential damages of any character arising as a
 *      result of this License or out of the use or inability to use the
 *      Work (including but not limited to damages for loss of goodwill,
 *      work stoppage, computer failure or malfunction, or any and all
 *      other commercial damages or losses), even if such Contributor
 *      has been advised of the possibility of such damages.
 *
 *   9. Accepting Warranty or Additional Liability. While redistributing
 *      the Work or Derivative Works thereof, You may choose to offer,
 *      and charge a fee for, acceptance of support, warranty, indemnity,
 *      or other liability obligations and/or rights consistent with this
 *      License. However, in accepting such obligations, You may act only
 *      on Your own behalf and on Your sole responsibility, not on behalf
 *      of any other Contributor, and only if You agree to indemnify,
 *      defend, and hold each Contributor harmless for any liability
 *      incurred by, or claims asserted against, such Contributor by reason
 *      of your accepting any such warranty or additional liability.
 *
 *   END OF TERMS AND CONDITIONS
 *
 *   APPENDIX: How to apply the Apache License to your work.
 *
 *      To apply the Apache License to your work, attach the following
 *      boilerplate notice, with the fields enclosed by brackets "[]"
 *      replaced with your own identifying information. (Don't include
 *      the brackets!)  The text should be enclosed in the appropriate
 *      comment syntax for the file format. We also recommend that a
 *      file or class name and description of purpose be included on the
 *      same "printed page" as the copyright notice for easier
 *      identification within third-party archives.
 *
 *   Copyright [2025] [SoftAtHome]
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 * ---------------------------------------------------------------------------
 */

#include <dmengine/DM_ENG_ParameterAttributesCache.h>
#include <dmengine/DM_ENG_ParameterAttributesStruct.h>
#include <dmengine/DM_ENG_Common.h>
#include <dmengine/DM_ENG_Device.h>
#include <string.h>

#include <debug/sahtrace.h>
/*
 * TODO:
 * The cache is currently implemented as a sorted linked list. This is not optimal for performance,
 * and should be changed to a more efficient (hash?) in the future
 */

static DM_ENG_ParameterAttributesStruct* acache = NULL;
extern device_adapter_t* device_adapter;

static void DM_ENG_locateParameterAttributesCacheEllement(const char* name, DM_ENG_ParameterAttributesStruct** cur, DM_ENG_ParameterAttributesStruct** prev) {
    *cur = acache;
    *prev = NULL;

    while(*cur) {
        if((*cur)->parameterName && name && ( strcmp((*cur)->parameterName, name) >= 0)) {
            break;
        }
        *prev = *cur;
        *cur = (*cur)->next;
    }

}

int DM_ENG_RemoveAttributesCacheEllement(const char* name, bool allowRemoveForcedParameter) {
    SAH_TRACEZ_INFO("DM_ENGINE", "Removing parameter attribute %s (allowRemoveForcedParameter=%d)", name, allowRemoveForcedParameter);

    if(( acache == NULL) || ( name == NULL)) {
        return -1;
    }
    DM_ENG_ParameterAttributesStruct* cur = NULL;
    DM_ENG_ParameterAttributesStruct* prev = NULL;

    DM_ENG_locateParameterAttributesCacheEllement(name, &cur, &prev);

    if(( cur != NULL) && ( strcmp(cur->parameterName, name) == 0)) {
        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter found, removing it");
        if(( cur->notification == DM_ENG_NotificationMode_FORCED) && ( allowRemoveForcedParameter == false)) {
            return -1;
        }
        //remove from list
        if(cur == acache) {
            acache = cur->next;
        } else {
            prev->next = cur->next;
        }
        cur->next = NULL;

        //remove the subscription
        if(( cur->notificationID != 0) && device_adapter->DM_ENG_Device_RemoveNotification) {
            device_adapter->DM_ENG_Device_RemoveNotification(cur->parameterName, cur->notificationID);
        }

        //remove the item
        DM_ENG_deleteParameterAttributesStruct(cur);
    } else {
        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter not found");
        return -1;
    }

    return 0;
}

int DM_ENG_AddParameterAttributesCacheEllement(const char* name, DM_ENG_NotificationMode notificationMode, char* accessList[]) {
    int notificationID = 0;
    char* value = NULL;

    SAH_TRACEZ_INFO("DM_ENGINE", "Adding parameter attribute %s, mode %d", name, notificationMode);

    if(name == NULL) {
        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter name = NULL, not adding the value to the attributes cache");
        return -1;
    }

    //for passive notifications we need to load the cachedValue
    //for active notification we need to load the cachedvalue
    if(( notificationMode == DM_ENG_NotificationMode_PASSIVE) || ( notificationMode == DM_ENG_NotificationMode_ACTIVE)) {
        DM_ENG_ParameterValueStruct** pResult = NULL;
        char* paramArray[2];
        paramArray[0] = name;
        paramArray[1] = NULL;
        // get the new value of the parameter
        if(DM_ENG_GetParameterValues(DM_ENG_EntityType_SYSTEM, (char**) paramArray, &pResult) == 0) {
            if(pResult) {
                value = (pResult[0]->value) ? strdup(pResult[0]->value) : NULL;
                DM_ENG_deleteAllParameterValueStruct(pResult);
                free(pResult);
            }
        } else {
            SAH_TRACEZ_ERROR("DM_ENGINE", "Could not get parameter value for parameter %s, not adding it to the cache", name);
            return -1;
        }
    }

    if(acache == NULL) {
        acache = DM_ENG_newParameterAttributesStruct(name, notificationMode, accessList);
        acache->notificationID = 0;
        if(device_adapter->DM_ENG_Device_AddNotification) {
            device_adapter->DM_ENG_Device_AddNotification(name, &notificationID, notificationMode);
        }
        if(( notificationMode == DM_ENG_NotificationMode_ACTIVE) || ( notificationMode == DM_ENG_NotificationMode_FORCED)) {
            acache->notificationID = notificationID;
        }
        if(accessList != NULL) {
            if(device_adapter->DM_ENG_Device_SetAccessRights) {
                device_adapter->DM_ENG_Device_SetAccessRights(name, accessList);
            }
        }
        acache->cachedValue = value;
        return 0;
    }
    DM_ENG_ParameterAttributesStruct* cur = NULL;
    DM_ENG_ParameterAttributesStruct* prev = NULL;

    DM_ENG_locateParameterAttributesCacheEllement(name, &cur, &prev);

    if(( cur != NULL) && ( strcmp(cur->parameterName, name) == 0)) {
        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter found, updating it");
        // we found the element, update it

        if(cur->notification != DM_ENG_NotificationMode_UNDEFINED) {  //if undefined, we leave the current notification mode as is
            if(cur->notification != DM_ENG_NotificationMode_FORCED) { // we only modify non-forced notifications
                // subscribe only to active notifications
                if(device_adapter->DM_ENG_Device_AddNotification) {
                    device_adapter->DM_ENG_Device_AddNotification(name, &notificationID, notificationMode);
                }
                if(( cur->notification == DM_ENG_NotificationMode_ACTIVE) && ( notificationMode != DM_ENG_NotificationMode_ACTIVE)) {
                    cur->notificationID = 0;
                }
                if(( cur->notification != DM_ENG_NotificationMode_ACTIVE) && ( notificationMode == DM_ENG_NotificationMode_ACTIVE)) {
                    cur->notificationID = notificationID;
                }
                cur->notification = notificationMode;
            }
        }
        if(accessList != NULL) {
            if(cur->accessList != NULL) {
                DM_ENG_deleteTabString(cur->accessList);
            }
            cur->accessList = DM_ENG_copyTabString(accessList);
        }
        if(( notificationMode == DM_ENG_NotificationMode_ACTIVE) && ( value != NULL) && ( *value == 0)) {
            free(cur->cachedValue);
            cur->cachedValue = strdup("NULL");
            free(value);
        } else {
            free(cur->cachedValue);
            cur->cachedValue = value;
        }
    } else {
        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter not found, adding it to list");
        // location where to insert the element is reached
        DM_ENG_ParameterAttributesStruct* pas = DM_ENG_newParameterAttributesStruct(name, notificationMode, accessList);
        if(prev == NULL) {
            acache = pas;
        } else {
            prev->next = pas;
        }
        pas->next = cur;

        if(device_adapter->DM_ENG_Device_AddNotification) {
            device_adapter->DM_ENG_Device_AddNotification(name, &notificationID, notificationMode);
        }
        if(( notificationMode == DM_ENG_NotificationMode_ACTIVE) || ( notificationMode == DM_ENG_NotificationMode_FORCED)) {
            pas->notificationID = notificationID;
        }
        if(accessList != NULL) {
            if(device_adapter->DM_ENG_Device_SetAccessRights) {
                device_adapter->DM_ENG_Device_SetAccessRights(name, accessList);
            }
        }
        if(( notificationMode == DM_ENG_NotificationMode_ACTIVE) && ( value != NULL) && ( *value == 0)) {
            pas->cachedValue = strdup("NULL");
            free(value);
        } else {
            pas->cachedValue = value;
        }
    }

    return 0;
}

int DM_ENG_GetParameterAttributesCacheEllement(const char* name, DM_ENG_NotificationMode* notificationMode, char** accessList[]) {
    DM_ENG_ParameterAttributesStruct* cur = NULL;
    DM_ENG_ParameterAttributesStruct* prev = NULL;

    if(name == NULL) {
        *notificationMode = DM_ENG_NotificationMode_OFF;
        *accessList = NULL;
        return 0;
    }

    DM_ENG_locateParameterAttributesCacheEllement(name, &cur, &prev);
    if(( cur != NULL) && ( strcmp(cur->parameterName, name) == 0)) {
        // element found
        *notificationMode = cur->notification;
        *accessList = cur->accessList;
    } else {
        // element not found, return defaults
        *notificationMode = DM_ENG_NotificationMode_OFF;
        *accessList = NULL;
    }
    return 0;
}

char* DM_ENG_GetParameterAttributesCacheEllementPath(int id) {
    DM_ENG_ParameterAttributesStruct* cur = acache;

    while(cur) {
        if(cur->notificationID == id) {
            return strdup(cur->parameterName);
        }
        cur = cur->next;
    }

    return NULL;
}

int DM_ENG_VerifyParameterAttributesCache() {
    if(device_adapter->DM_ENG_Device_GetParameterNames) {
        DM_ENG_ParameterAttributesStruct* cache = acache;
        DM_ENG_ParameterAttributesStruct* prev = NULL;
        DM_ENG_ParameterInfoStruct* infoList = NULL;
        while(cache) {
            if(device_adapter->DM_ENG_Device_GetParameterNames(cache->parameterName, false, &infoList) != 0) {
                // there is something wrong with this parameter, remove it from list
                if(prev == NULL) {
                    acache = cache->next;
                    DM_ENG_deleteParameterAttributesStruct(cache);
                    cache = acache;
                } else {
                    prev->next = cache->next;
                    DM_ENG_deleteParameterAttributesStruct(cache);
                    cache = prev->next;
                }

            } else {
                prev = cache;
                cache = cache->next;
            }
            DM_ENG_deleteAllParameterInfoStruct(&infoList);
        }
    }

    return 0;
}

int DM_ENG_SyncParameterAttributesCache() {
    DM_ENG_ParameterAttributesStruct* cache = acache;
    while(cache) {
        DM_ENG_ParameterValueStruct** pResult = NULL;
        char* paramArray[2];
        paramArray[0] = cache->parameterName;
        paramArray[1] = NULL;
        // get the new value of the parameter
        if((DM_ENG_GetParameterValues(DM_ENG_EntityType_SYSTEM, (char**) paramArray, &pResult) == 0) && (pResult != NULL)) {
            free(cache->cachedValue);
            cache->cachedValue = strdup(pResult[0]->value);
            DM_ENG_deleteAllParameterValueStruct(pResult);
            free(pResult);
        } else {
            SAH_TRACEZ_ERROR("DM_ENGINE", "Could not get parameter value for parameter %s, not adding it to the cache", cache->parameterName);
        }
        cache = cache->next;
    }

    return 0;
}


/*
 * Add a cached value
 */
void DM_ENG_AddCachedValueToParameterAttributesCache(const char* paramName, const char* paramValue) {
    DM_ENG_ParameterAttributesStruct* cache = acache;
    while(cache) {
        if(( cache->parameterName != NULL) && ( paramName != NULL) && ( strcmp(cache->parameterName, paramName) == 0)) {
            // we found the parameter
            SAH_TRACEZ_INFO("DM_ENGINE", "** Updating cached value for parameter %s (%s -> %s)", paramName, cache->cachedValue, paramValue);
            free(cache->cachedValue);
            if(paramValue) {
                cache->cachedValue = strdup(paramValue);
            } else {
                cache->cachedValue = NULL;
            }
            return;
        }
        cache = cache->next;
    }
    // if we get here, there are no attributes for this parameter
}


/*
 * Check if the attributes cache contains a cached parameter value that is equal to the one
 * we're getting from a notification. In case we find the parameter, we clear the value of the
 * attributescache.
 *
 * @return true if the value was in the cache (e.g. this value was set by the ACS)
 *         false if the value was not in the cache (e.g. this value was not set by the ACS)
 */
bool DM_ENG_ValueWasCachedInParameterAttributesCache(const char* paramName, const char* paramValue) {
    DM_ENG_ParameterAttributesStruct* cache = acache;
    while(cache) {
        if(( cache->parameterName != NULL) && ( paramName != NULL) && ( strcmp(cache->parameterName, paramName) == 0)) {
            // we found the parameter
            SAH_TRACEZ_INFO("DM_ENGINE", "Parameter %s found in cache, comparing cached value %s with %s", paramName, cache->cachedValue, paramValue);
            if(( cache->cachedValue != NULL) && ( paramValue != NULL) && ( strcmp(cache->cachedValue, paramValue) == 0)) {
                return true;
            } else if(( cache->cachedValue != NULL) && ( strcmp(cache->cachedValue, "NULL") == 0) && ( paramValue != NULL) && ( *paramValue == 0)) {
                return true; //cache->cacheValue=="NULL" && paramValue==""
            } else if(( cache->notification == DM_ENG_NotificationMode_ACTIVE) && ( paramValue != NULL) && ( cache->cachedValue != NULL) && ( *paramValue == 0)) {
                free(cache->cachedValue);
                cache->cachedValue = strdup("NULL");
                return false;
            } else if(( cache->notification == DM_ENG_NotificationMode_ACTIVE) && ( paramValue != NULL) && ( cache->cachedValue != NULL) && ( *paramValue != 0)) {
                free(cache->cachedValue);
                cache->cachedValue = strdup(paramValue);
                return false;
            } else {
                free(cache->cachedValue);
                cache->cachedValue = NULL;
                return false;
            }
        }
        cache = cache->next;
    }
    // if we get here, there are no attributes for this parameter
    return false;
}



DM_ENG_ParameterValueStruct* DM_ENG_ParameterAttributesCacheGetChangedPassiveParams() {
    DM_ENG_ParameterValueStruct* pvs = NULL;
    DM_ENG_ParameterAttributesStruct* cache = acache;
    while(cache) {
        // only test the passive notifications
        if(cache->notification == DM_ENG_NotificationMode_PASSIVE) {
            SAH_TRACEZ_INFO("DM_ENGINE", "Passive notification %s found", cache->parameterName);
            DM_ENG_ParameterValueStruct** pResult = NULL;
            char* paramArray[2];
            paramArray[0] = cache->parameterName;
            paramArray[1] = NULL;
            // get the new value of the parameter
            if(DM_ENG_GetParameterValues(DM_ENG_EntityType_SYSTEM, (char**) paramArray, &pResult) == 0) {
                if(pResult) {
                    SAH_TRACEZ_INFO("DM_ENGINE", "old value = %s, new value = %s", cache->cachedValue, pResult[0]->value);
                    // check if the parameter has changed
                    if(pResult[0]->value && cache->cachedValue && ( strcmp(pResult[0]->value, cache->cachedValue) == 0)) {
                        //  if unchanged: do nothing
                        SAH_TRACEZ_INFO("DM_ENGINE", "No change, do nothing");
                        DM_ENG_deleteAllParameterValueStruct(pResult);
                    } else {
                        //  if changed: add to pvs, update cached values
                        SAH_TRACEZ_INFO("DM_ENGINE", "Parameter changed, add it to the result list and update the cache");
                        DM_ENG_addParameterValueStruct(&pvs, pResult[0]);
                        free(cache->cachedValue);
                        cache->cachedValue = strdup(pResult[0]->value);
                    }
                    free(pResult);
                }
            } else {
                SAH_TRACEZ_ERROR("DM_ENGINE", "Could not get parameter value for parameter %s, removing it from the cache", cache->parameterName);
                //todo: remove parameter from cache
            }
        }
        cache = cache->next;
    }
    return pvs;
}

DM_ENG_ParameterValueStruct* DM_ENG_ParameterAttributesCacheGetChangedActiveParams() {
    DM_ENG_ParameterValueStruct* pvs = NULL;
    DM_ENG_ParameterAttributesStruct* cache = acache;
    while(cache) {
        // only test the active notifications
        if(cache->notification == DM_ENG_NotificationMode_ACTIVE) {
            SAH_TRACEZ_INFO("DM_ENGINE", " notification %s found", cache->parameterName);
            DM_ENG_ParameterValueStruct** pResult = NULL;
            char* paramArray[2];
            paramArray[0] = cache->parameterName;
            paramArray[1] = NULL;
            // get the new value of the parameter
            if((DM_ENG_GetParameterValues(DM_ENG_EntityType_SYSTEM, (char**) paramArray, &pResult) == 0) && (pResult != NULL) && pResult[0]->value) {
                SAH_TRACEZ_INFO("DM_ENGINE", " old value = %s, new value = %s", cache->cachedValue, pResult[0]->value);
                // check if the parameter has changed
                if(cache->cachedValue && (strcmp(pResult[0]->value, cache->cachedValue) == 0)) {
                    //  if unchanged: do nothing
                    SAH_TRACEZ_INFO("DM_ENGINE", " No change, do nothing");
                    DM_ENG_deleteAllParameterValueStruct(pResult);
                } else if((*pResult[0]->value == 0) && cache->cachedValue && (strcmp(cache->cachedValue, "NULL") == 0)) {
                    //  NULL parameter unchanged: do nothing
                    SAH_TRACEZ_WARNING("DM_ENGINE", " NULL parameter unchanged, do nothing");
                    DM_ENG_deleteAllParameterValueStruct(pResult);
                } else {//  if changed: add to pvs if old value is not null, update cached values
                    if((cache->cachedValue == NULL) && pResult[0] && (strlen(pResult[0]->value) == 0)) {
                        SAH_TRACEZ_INFO("DM_ENGINE", " Parameter changed the value is empty , update the cache not add it to the result list");
                        cache->cachedValue = strdup("NULL");
                    } else if((cache->cachedValue == NULL) && pResult[0] && (strlen(pResult[0]->value) != 0)) {
                        cache->cachedValue = strdup(pResult[0]->value);
                        SAH_TRACEZ_INFO("DM_ENGINE", " Parameter changed the value is not empty , update the cache not add it to the result list %s ", cache->cachedValue);
                    } else {
                        SAH_TRACEZ_INFO("DM_ENGINE", " Parameter  changed update cache, add it to the result list and update the cache %s ", cache->cachedValue);
                        DM_ENG_addParameterValueStruct(&pvs, pResult[0]);
                        free(cache->cachedValue);
                        cache->cachedValue = strdup(pResult[0]->value);
                    }
                }

                free(pResult);
                pResult = NULL;
            } else {
                SAH_TRACEZ_ERROR("DM_ENGINE", " Could not get parameter value for parameter %s, removing it from the cache", cache->parameterName);
            }
        }
        cache = cache->next;
    }
    return pvs;
}


DM_ENG_ParameterValueStruct* DM_ENG_ParameterAttributesCacheGetForcedParams(bool updateCache, bool* parameterChanged) {
    DM_ENG_ParameterValueStruct* pvs = NULL;
    DM_ENG_ParameterAttributesStruct* cache = acache;
    if(parameterChanged) {
        *parameterChanged = false;
    }
    while(cache) {
        // only test the forced notifications
        if(cache->notification == DM_ENG_NotificationMode_FORCED) {
            SAH_TRACEZ_INFO("DM_ENGINE", "Forced notification %s found", cache->parameterName);
            DM_ENG_ParameterValueStruct** pResult = NULL;
            char* paramArray[2];
            paramArray[0] = cache->parameterName;
            paramArray[1] = NULL;

            // get the value of the parameter
            if((DM_ENG_GetParameterValues(DM_ENG_EntityType_SYSTEM, (char**) paramArray, &pResult) == 0) && (pResult != NULL)) {
                // add to pvs
                SAH_TRACEZ_INFO("DM_ENGINE", "add it to the result forced list");
                DM_ENG_addParameterValueStruct(&pvs, pResult[0]);
                if(updateCache) {
                    if(!(pResult[0]->value && cache->cachedValue && ( strcmp(pResult[0]->value, cache->cachedValue) == 0))) {
                        //parameter changed : indicate this and update cache
                        if(parameterChanged) {
                            SAH_TRACEZ_INFO("DM_ENGINE", " ** Adding event value changed for %s (%s)", pResult[0]->parameterName, pResult[0]->value);
                            *parameterChanged = true;
                        }
                        free(cache->cachedValue);
                        cache->cachedValue = (pResult[0]->value) ? strdup(pResult[0]->value) : NULL;
                    }
                }

                free(pResult);
                pResult = NULL;
            } else {
                SAH_TRACEZ_ERROR("DM_ENGINE", "Could not get parameter value for parameter %s, removing it from the cache", cache->parameterName);
                //todo: remove parameter from cache
            }
        }
        cache = cache->next;
    }
    return pvs;
}




int DM_ENG_InitializeParameterAttributesCache(DM_ENG_ParameterAttributesStruct** acacheArray) {
    int size = DM_ENG_tablen((void**) acacheArray);
    int i = 0;
    for(i = 0; i < size; i++) {
        DM_ENG_AddParameterAttributesCacheEllement(acacheArray[i]->parameterName, acacheArray[i]->notification, acacheArray[i]->accessList);
        DM_ENG_AddCachedValueToParameterAttributesCache(acacheArray[i]->parameterName, acacheArray[i]->cachedValue);
    }
    return 0;
}

int DM_ENG_CleanupParameterAttributesCache() {
    DM_ENG_ParameterAttributesStruct* cache = acache;
    DM_ENG_ParameterAttributesStruct* prev;
    while(cache) {
        prev = cache;
        cache = cache->next;
        DM_ENG_deleteParameterAttributesStruct(prev);
    }
    acache = NULL;

    return 0;
}


/*
 * Display the parameter Cache
 */
void DM_ENG_DisplayParameterAttributesCache() {
    DM_ENG_ParameterAttributesStruct* cache = acache;
    SAH_TRACEZ_INFO("DM_ENGINE", "----------------");
    SAH_TRACEZ_INFO("DM_ENGINE", "attribute cache:");
    SAH_TRACEZ_INFO("DM_ENGINE", "----------------");
    SAH_TRACEZ_INFO("DM_ENGINE", "path - notification - accesslist - subscriptionID");
    while(cache) {
        SAH_TRACEZ_INFO("DM_ENGINE", "%s - %s(%d) - %s - %d", cache->parameterName, DM_ENG_NotificationModeString(cache->notification),
                        cache->notification, cache->accessList ? cache->accessList[0] : "NULL", cache->notificationID);
        cache = cache->next;
    }

}

const char* DM_ENG_NotificationModeString(DM_ENG_NotificationMode mode) {
    switch(mode) {
    case DM_ENG_NotificationMode_OFF:       return "Off";
    case DM_ENG_NotificationMode_PASSIVE:   return "Passive";
    case DM_ENG_NotificationMode_ACTIVE:    return "Active";
    case DM_ENG_NotificationMode_FORCED:    return "Forced";
    case DM_ENG_NotificationMode_UNDEFINED: return "Undefined";
    default: break;
    }
    return "Error";
}

DM_ENG_NotificationMode DM_ENG_StringNotificationMode(const char* mode) {

    if(strcmp(mode, "Off") == 0) {
        return DM_ENG_NotificationMode_OFF;
    } else if(strcmp(mode, "Passive") == 0) {
        return DM_ENG_NotificationMode_PASSIVE;
    } else if(strcmp(mode, "Active") == 0) {
        return DM_ENG_NotificationMode_ACTIVE;
    } else {
        return DM_ENG_NotificationMode_UNDEFINED;
    }
}

void DM_ENG_CacheDict_Build(amxc_htable_t* dict) {
    DM_ENG_ParameterAttributesStruct* pas = acache;
    amxc_htable_init(dict, 0);
    while(pas) {
        if((pas->parameterName != NULL) && (strcmp(pas->parameterName, "") != 0)) {
            cache_dict_entry_t* entry = (cache_dict_entry_t*) calloc(1, sizeof(cache_dict_entry_t));
            entry->pas = pas;
            amxc_htable_insert(dict, pas->parameterName, &entry->hit);
        }
        pas = pas->next;
    }
}

static void cache_dict_entry_free(UNUSED const char* key, amxc_htable_it_t* it) {
    cache_dict_entry_t* entry = amxc_htable_it_get_data(it, cache_dict_entry_t, hit);
    free(entry);
}

void DM_ENG_CacheDict_Destroy(amxc_htable_t* dict) {
    amxc_htable_clean(dict, cache_dict_entry_free);
}

int DM_ENG_CacheDict_GetInfo(amxc_htable_t* dict, const char* name, DM_ENG_NotificationMode* notificationMode, char** accessList[]) {
    int retval = -1;
    amxc_htable_it_t* it = NULL;
    cache_dict_entry_t* entry = NULL;
    *notificationMode = DM_ENG_NotificationMode_OFF;
    *accessList = NULL;

    if((dict == NULL) || (name == NULL) || ((strcmp(name, "") == 0))) {
        SAH_TRACEZ_WARNING("DM_ENGINE", "Invalid arg(s)");
        goto stop;
    }
    if((amxc_htable_is_empty(dict) == true)) {
        SAH_TRACEZ_INFO("DM_ENGINE", "Cache dict is empty");
        goto stop;
    }
    it = amxc_htable_get(dict, name);
    if(it == NULL) {
        SAH_TRACEZ_INFO("DM_ENGINE", "Iterator not found [%s]", name);
        goto stop;
    }
    entry = amxc_htable_it_get_data(it, cache_dict_entry_t, hit);
    if(entry == NULL) {
        // unexpected error.
        SAH_TRACEZ_ERROR("DM_ENGINE", "Entry not valid [%s]", name);
        goto stop;
    }
    if(entry->pas == NULL) {
        // unexpected error.
        SAH_TRACEZ_ERROR("DM_ENGINE", "Invalid PAS within the entry [%s]", name);
        goto stop;
    }
    *notificationMode = entry->pas->notification;
    *accessList = entry->pas->accessList;
    retval = 0;
stop:
    return retval;
}
