/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>          /* amxd_dm_findf() */
#include <amxd/amxd_types.h>       /* amxd_object_t */
#include <amxd/amxd_transaction.h> /* amxd_trans_t */

/* Own headers */
#include "sfpmgr.h"
#include "sfpmgr_main.h"  /* sfp_get_dm() */
#include "sfpmgr_utils.h" /* setStringParam() */
#include "sfp_type.h"

/**
 * @brief Updates the static parameters of an SFP transceiver object.
 *
 * @param[in] cage_object The SFPCage object to update.
 * @param[in] sfp_object The SFP object to update.
 * @param[in] sfp_param  The structure containing the new parameter values.
 *
 * @return Returns `amxd_status_ok` on success, or an error code on failure.
 */
int sfpmgr_update_static_params(amxd_object_t* cage_object, amxd_object_t* sfp_object, sfp_ethtool_t* sfp_param) {
    amxd_status_t retval = amxd_status_ok;
    char buf[32];
    amxd_trans_t static_transaction;
    when_null(sfp_param, exit);
    amxd_trans_init(&static_transaction);

    /* Fetch sfpmgr DM */
    amxd_dm_t* dm = sfp_get_dm();
    if(dm == NULL) {
        SAH_TRACEZ_ERROR(ME, "dm failed ");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }

    sfp_cage_t* sfp_cage = (sfp_cage_t*) cage_object->priv;
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;

    /* SFP type is required for various other components to discover the
     * presence and removal */
    const char* const sfp_type_cstr = sfp_type_to_cstring(sfp_cage->sfp_type);
    SAH_TRACEZ_INFO(ME, "SFPType %s", sfp_type_cstr);

    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    retval = amxd_status_ok;

    amxd_trans_select_object(&static_transaction, cage_object);
    retval |= setBoolParam(&static_transaction, "SFPPresent", sfp_cage->state != SFP_STATE_REMOVED);
    retval |= setStringParam(&static_transaction, "SFPType", sfp_type_cstr);
    retval |= setUint32Param(&static_transaction, "SFF8024Identifier", sfp_param->id);

    amxd_trans_select_object(&static_transaction, sfp_object);
    snprintf(buf, sizeof(buf), "%02x", sfp_param->connector);
    retval |= setStringParam(&static_transaction, "Connector", buf);
    retval |= setStringParam(&static_transaction, "Transceiver", sfp_param->transceiver);
    retval |= setUint32Param(&static_transaction, "Encoding", sfp_param->encoding);
    retval |= setint32Param(&static_transaction, "BRNominal", sfp_param->br_nominal);
    snprintf(buf, sizeof(buf), "%02x", sfp_param->rate_id);
    retval |= setStringParam(&static_transaction, "RateIdentifier", buf);
    retval |= setStringParam(&static_transaction, "VendorName", sfp_param->vendor_name);
    retval |= setStringParam(&static_transaction, "VendorOUI", sfp_param->vendor_oui);
    retval |= setStringParam(&static_transaction, "VendorPN", sfp_param->vendor_pn);
    retval |= setStringParam(&static_transaction, "VendorRev", sfp_param->vendor_rev);
    retval |= setUint32Param(&static_transaction, "BRMax", sfp_param->br_max);
    retval |= setUint32Param(&static_transaction, "BRMin", sfp_param->br_min);
    retval |= setStringParam(&static_transaction, "VendorSN", sfp_param->vendor_sn);
    retval |= setStringParam(&static_transaction, "DateCode", sfp_param->date_code);
    retval |= setUint32Param(&static_transaction, "LengthSMFkm", sfp_param->len_SMF_km);
    retval |= setUint32Param(&static_transaction, "LengthSMF", sfp_param->len_SMF_100m);
    retval |= setUint32Param(&static_transaction, "LengthOM2", sfp_param->len_50um_10m);
    retval |= setUint32Param(&static_transaction, "LengthOM1", sfp_param->len_62dot5um_10m);
    retval |= setUint32Param(&static_transaction, "LengthOM3", sfp_param->len_OM3_10m);
    retval |= setUint32Param(&static_transaction, "Wavelength", sfp_param->wavelength);
    snprintf(buf, sizeof(buf), "%02x", sfp_param->sff_vercompliance);
    retval |= setStringParam(&static_transaction, "VerCompliance", buf);
    retval |= setBoolParam(&static_transaction, "OptCooledTrans", sfp_param->optcooltrans);
    retval |= setBoolParam(&static_transaction, "OptPowerlvl", sfp_param->optpwrlvl);
    retval |= setBoolParam(&static_transaction, "OptLinearRcvr", sfp_param->optlinearrcvr);
    retval |= setBoolParam(&static_transaction, "OptRateSelect", sfp_param->optrateselect);
    retval |= setBoolParam(&static_transaction, "OptTxDisable", sfp_param->opttxdisable);
    retval |= setBoolParam(&static_transaction, "OptTxFault", sfp_param->opttxfault);
    retval |= setBoolParam(&static_transaction, "OptInvertedLOS", sfp_param->optinvlos);
    retval |= setBoolParam(&static_transaction, "OptLOS", sfp_param->optlos);
    retval |= setBoolParam(&static_transaction, "DMCtypeImplemented", sfp_param->dmctypeImplemented);
    retval |= setBoolParam(&static_transaction, "DMCtypeInternalCal", sfp_param->dmctypeInternalcal);
    retval |= setBoolParam(&static_transaction, "DMCtypeExternalCal", sfp_param->dmctypeExternalcal);
    retval |= setBoolParam(&static_transaction, "DMCtypeRxAvgPwr", sfp_param->dmctypeRxAvgPwr);
    retval |= setBoolParam(&static_transaction, "EOCalarmsImplemented", sfp_param->eocalarmsImplemented);
    retval |= setBoolParam(&static_transaction, "EOCSoftTxDisable", sfp_param->eocsofttxDisable);
    retval |= setBoolParam(&static_transaction, "EOCSoftTxFault", sfp_param->eocsofttxFault);
    retval |= setBoolParam(&static_transaction, "EOCSoftRxLOS", sfp_param->eocsoftrxLOS);
    retval |= setBoolParam(&static_transaction, "EOCSoftRateSelect", sfp_param->eocsoftrateSelect);
    retval |= setBoolParam(&static_transaction, "SFF8079AppSelect", sfp_param->sff8079appSelect);
    retval |= setBoolParam(&static_transaction, "SFF8431SoftRateSelect", sfp_param->sff8431softrateSelect);
    retval |= setBoolParam(&static_transaction, "EMCSPowerLvlOp", false);
    retval |= setBoolParam(&static_transaction, "EMCSPowerLvlSelect", false);

    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "SFP object update failed");
    }
    /* Save the changes */
    retval = amxd_trans_apply(&static_transaction, dm);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "failed:%s:%d:ret:%d", __func__, __LINE__, retval);
    } else {
        SAH_TRACEZ_INFO(ME, "success: %s:%d", __func__, __LINE__);
    }

    amxd_trans_clean(&static_transaction);
    amxd_trans_init(&static_transaction);
    amxd_object_t* threshold_obj = amxd_dm_findf(dm, SFP_XCVR_THRESHOLDS_PATH, sfp_info->sfp_cage_id);

    if(threshold_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Thresholds object failed");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }
    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    retval = amxd_status_ok;

    amxd_trans_select_object(&static_transaction, threshold_obj);
    retval |= setint32Param(&static_transaction, "HighTempAlarm", sfp_param->temp_high_alarm);
    retval |= setint32Param(&static_transaction, "HighTempWarning", sfp_param->temp_high_warning);
    retval |= setint32Param(&static_transaction, "LowTempWarning", sfp_param->temp_low_warning);
    retval |= setint32Param(&static_transaction, "LowTempAlarm", sfp_param->temp_low_alarm);
    retval |= setUint32Param(&static_transaction, "HighVccAlarm", sfp_param->volt_high_alarm);
    retval |= setUint32Param(&static_transaction, "HighVccWarning", sfp_param->volt_high_warning);
    retval |= setUint32Param(&static_transaction, "LowVccWarning", sfp_param->volt_low_warning);
    retval |= setUint32Param(&static_transaction, "LowVccAlarm", sfp_param->volt_low_alarm);
    retval |= setUint32Param(&static_transaction, "HighTxBiasAlarm", sfp_param->bias_high_alarm);
    retval |= setUint32Param(&static_transaction, "HighTxBiasWarning", sfp_param->bias_high_warning);
    retval |= setUint32Param(&static_transaction, "LowTxBiasWarning", sfp_param->bias_low_warning);
    retval |= setUint32Param(&static_transaction, "LowTxBiasAlarm", sfp_param->bias_low_alarm);
    retval |= setint32Param(&static_transaction, "HighTxPowerAlarm", sfp_param->tx_power_high_alarm);
    retval |= setint32Param(&static_transaction, "HighTxPowerWarning", sfp_param->tx_power_high_warning);
    retval |= setint32Param(&static_transaction, "LowTxPowerWarning", sfp_param->tx_power_low_warning);
    retval |= setint32Param(&static_transaction, "LowTxPowerAlarm", sfp_param->tx_power_low_alarm);
    retval |= setint32Param(&static_transaction, "HighRxPowerAlarm", sfp_param->rx_power_high_alarm);
    retval |= setint32Param(&static_transaction, "HighRxPowerWarning", sfp_param->rx_power_high_warning);
    retval |= setint32Param(&static_transaction, "LowRxPowerWarning", sfp_param->rx_power_low_warning);
    retval |= setint32Param(&static_transaction, "LowRxPowerAlarm", sfp_param->rx_power_low_alarm);

    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Thresholds object update failed");
    }

    retval = amxd_trans_apply(&static_transaction, dm);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "failed:%s:%d:ret:%d", __func__, __LINE__, retval);
    } else {
        SAH_TRACEZ_INFO(ME, "sucess: %s:%d", __func__, __LINE__);
    }
    amxd_trans_clean(&static_transaction);

exit:
    return retval;
}


/**
 * @brief Updates the dynamic parameters, alarms, status, and warnings of an SFP transceiver.
 *
 * @param[in] cage_object The SFPCage object to update.
 * @param[in] sfp_object The SFP object to update.
 * @param[in] sfp_param  The structure containing updated parameters and thresholds.
 *
 * @return Returns `amxd_status_ok` on success, or an error code on failure.
 */
int sfpmgr_update_dynamic_params(UNUSED amxd_object_t* cage_object, amxd_object_t* sfp_object, sfp_ethtool_t* sfp_param) {
    amxd_status_t retval = amxd_status_ok;
    amxd_trans_t static_transaction;

    when_null(sfp_param, exit);
    amxd_trans_init(&static_transaction);

    /* Fetch sfpmgr DM */
    amxd_dm_t* dm = sfp_get_dm();
    if(dm == NULL) {
        SAH_TRACEZ_ERROR(ME, "dm failed ");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }
    SAH_TRACEZ_INFO(ME, "Updating dynamic params of SFP");
    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    amxd_object_t* status_obj = amxd_dm_findf(dm, SFP_XCVR_STATUS_PATH, sfp_info->sfp_cage_id);

    SAH_TRACEZ_INFO(ME, "sfp_info->sfp_cage_id is {%d}", sfp_info->sfp_cage_id);
    if(status_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Status object failed ");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }
    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    retval = amxd_status_ok;
    amxd_trans_select_object(&static_transaction, status_obj);
    /* status updated */
    retval |= setint32Param(&static_transaction, "Temperature", sfp_param->temperature);
    retval |= setUint16Param(&static_transaction, "Vcc", sfp_param->volt);
    retval |= setUint16Param(&static_transaction, "TxBias", sfp_param->bias);
    retval |= setint32Param(&static_transaction, "TxPower", sfp_param->tx_power);
    retval |= setint32Param(&static_transaction, "RxPower", sfp_param->rx_power);
    retval |= setBoolParam(&static_transaction, "TxDisableState", sfp_param->txdisableState);
    retval |= setBoolParam(&static_transaction, "SoftTxDisableSelect", sfp_param->softtxdisableSelect);
    retval |= setBoolParam(&static_transaction, "RS1State", sfp_param->rs1State);
    retval |= setBoolParam(&static_transaction, "RateSelectState", sfp_param->rateselectState);
    retval |= setBoolParam(&static_transaction, "SoftRateSelectSelect", sfp_param->sff8431softrateSelect);
    retval |= setBoolParam(&static_transaction, "TXFaultState", sfp_param->txfaultState);
    retval |= setBoolParam(&static_transaction, "RxLOSState", sfp_param->rxlosState);
    retval |= setBoolParam(&static_transaction, "DataReadyBarState", sfp_param->datareadybarState);

    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Status object update failed");
    }

    retval = amxd_trans_apply(&static_transaction, dm);

    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "failed:%s:%d:ret:%d", __func__, __LINE__, retval);
    } else {
        SAH_TRACEZ_INFO(ME, "sucess: %s:%d", __func__, __LINE__);
    }
    amxd_trans_clean(&static_transaction);
    amxd_trans_init(&static_transaction);
    amxd_object_t* alarm_obj = amxd_dm_findf(dm, SFP_XCVR_ALARMS_PATH, sfp_info->sfp_cage_id);

    if(alarm_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Alarms object failed");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }
    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    retval = amxd_status_ok;
    amxd_trans_select_object(&static_transaction, alarm_obj);
    /* alarms  updated */
    retval |= setBoolParam(&static_transaction, "TemperatureHigh", sfp_param->alarm_hightemp);
    retval |= setBoolParam(&static_transaction, "TemperatureLow", sfp_param->alarm_lowtemp);
    retval |= setBoolParam(&static_transaction, "VccHigh", sfp_param->warn_highvolt);
    retval |= setBoolParam(&static_transaction, "VccLow", sfp_param->alarm_lowvolt);
    retval |= setBoolParam(&static_transaction, "TxBiasHigh", sfp_param->alarm_hightxbias);
    retval |= setBoolParam(&static_transaction, "TxBiasLow", sfp_param->alarm_lowtxbias);
    retval |= setBoolParam(&static_transaction, "TxPowerHigh", sfp_param->alarm_hightxpower);
    retval |= setBoolParam(&static_transaction, "TxPowerLow", sfp_param->alarm_lowtxpower);
    retval |= setBoolParam(&static_transaction, "RxPowerHigh", sfp_param->alarm_highrxpower);
    retval |= setBoolParam(&static_transaction, "RxPowerLow", sfp_param->alarm_lowrxpower);

    retval = amxd_trans_apply(&static_transaction, dm);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "failed:%s:%d:ret:%d", __func__, __LINE__, retval);
    } else {
        SAH_TRACEZ_INFO(ME, "sucess: %s:%d", __func__, __LINE__);
    }

    amxd_trans_clean(&static_transaction);
    amxd_trans_init(&static_transaction);
    amxd_object_t* warning_obj = amxd_dm_findf(dm, SFP_XCVR_WARNINGS_PATH, sfp_info->sfp_cage_id);

    if(warning_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Warning object failed");
        amxd_trans_clean(&static_transaction);
        return amxd_status_invalid_value;
    }
    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    retval = amxd_status_ok;
    /* warning object updated */
    amxd_trans_select_object(&static_transaction, warning_obj);

    /* alarms and warnings updated */
    retval |= setBoolParam(&static_transaction, "TemperatureHigh", sfp_param->warn_hightemp);
    retval |= setBoolParam(&static_transaction, "TemperatureLow", sfp_param->warn_lowtemp);
    retval |= setBoolParam(&static_transaction, "VccHigh", sfp_param->warn_highvolt);
    retval |= setBoolParam(&static_transaction, "VccLow", sfp_param->warn_lowvolt);
    retval |= setBoolParam(&static_transaction, "TxBiasHigh", sfp_param->warn_hightxbias);
    retval |= setBoolParam(&static_transaction, "TxBiasLow", sfp_param->warn_lowtxbias);
    retval |= setBoolParam(&static_transaction, "TxPowerHigh", sfp_param->warn_hightxpower);
    retval |= setBoolParam(&static_transaction, "TxPowerLow", sfp_param->warn_lowtxpower);
    retval |= setBoolParam(&static_transaction, "RxPowerHigh", sfp_param->warn_highrxpower);
    retval |= setBoolParam(&static_transaction, "RxPowerLow", sfp_param->warn_lowrxpower);
    /* save it to the object */
    retval = amxd_trans_apply(&static_transaction, dm);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "failed:%s:%d:ret:%d", __func__, __LINE__, retval);
    } else {
        SAH_TRACEZ_INFO(ME, "sucess: %s:%d", __func__, __LINE__);
    }
    SAH_TRACEZ_INFO(ME, "sfp updated for dynamic params for cage %d", sfp_info->sfp_cage_id);
    amxd_trans_clean(&static_transaction);

exit:
    return retval;
}

/**
 * @brief Retrieves information about an SFP cage.
 *
 * @param[in] cage_index The index of the SFP cage to retrieve.
 *
 * @return Returns a pointer to the `sfp_cage_t` structure, or `NULL` if not found.
 */
sfp_cage_t* get_sfp_cage_info (int32_t cage_index) {
    int rc;
    char sfp_path[128];
    rc = snprintf(sfp_path, 128, SFP_CAGE_PATH, cage_index);
    when_true_trace(rc < 0 || rc >= 128, exit, ERROR, "snprintf() failed rc=%d", rc);
    amxd_object_t* sfp_cage_object = amxd_dm_findf(sfp_get_dm(), sfp_path, cage_index);
    when_null(sfp_cage_object, exit);
    sfp_cage_t* sfp_cage_info = (sfp_cage_t*) sfp_cage_object->priv;
    when_null(sfp_cage_info, exit);
    return sfp_cage_info;

exit:
    SAH_TRACEZ_ERROR(ME, "sfp_cage_info not found for cage %d", cage_index);
    return NULL;
}


sfp_info_t* get_sfp_cage_info_trans(int32_t cage_index) {
    int rc;
    char sfp_path[128];
    rc = snprintf(sfp_path, 128, SFP_XCVR_PATH, cage_index);
    when_true_trace(rc < 0 || rc >= 128, exit, ERROR, "snprintf() failed rc=%d", rc);
    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), sfp_path, cage_index);
    when_null(sfp_object, exit);
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);
    return sfp_info;

exit:
    /**
     * Do not log an error. The Transceiver object does not have any private data
     * if tr181-sfp is started and immediately stopped. This is tested by the unit
     * tests in test/test-tr181_sfp_01_start_stop.
     */
    SAH_TRACEZ_INFO(ME, "sfp_info not found for cage %d", cage_index);
    return NULL;
}

