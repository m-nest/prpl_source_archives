/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>

#include "bulkdata.h"
#include "bulkdata_profile_encoding.h"
#include "bulkdata_profile_csv_encoding.h"

#define ME "csv_encoding"
#define CSV_ENCODING_PARAM_PER_ROW      "ParameterPerRow"
#define CSV_ENCODING_PARAM_PER_COLUMN   "ParameterPerColumn"

typedef struct {
    const cstring_t entity;
    char replacement;
} HtmlEntity;

// List of common HTML named entities
static const HtmlEntity html_entities[] = {
    {"quot", '\"'}, {"amp", '&'}, {"lt", '<'}, {"gt", '>'}, {"apos", '\''}, {"nbsp", ' '}
};

#define NUM_ENTITIES (sizeof(html_entities) / sizeof(html_entities[0]))

static void bulkdata_decode_html_entities(const cstring_t input, cstring_t output) {
    when_null(input, exit);
    when_null(output, exit);

    while(*input) {
        if(*input == '&') {
            const cstring_t start = input + 1;

            if(*start == '#') {
                int ascii_code = 0;
                if((start[1] == 'x') || (start[1] == 'X')) {
                    ascii_code = strtol(start + 2, (cstring_t*) &input, 16);
                } else {
                    ascii_code = strtol(start + 1, (cstring_t*) &input, 10);
                }

                if(*input == ';') {
                    input++;
                }
                *output++ = (char) ascii_code;
                continue;
            }

            const cstring_t semi = strchr(start, ';');
            if(semi) {
                int length = semi - start;
                for(uint32_t i = 0; i < NUM_ENTITIES; i++) {
                    if((strncmp(html_entities[i].entity, start, length) == 0) && (html_entities[i].entity[length] == '\0')) {
                        *output++ = html_entities[i].replacement;
                        input = semi + 1;
                        goto next_char;
                    }
                }
            }
        }
        *output++ = *input++;

next_char:;
    }
    *output = '\0';

exit:
    return;
}

amxd_object_t* bulkdata_get_csv_encoding_object(amxd_object_t* profile) {
    cstring_t path = amxd_object_get_path(profile, AMXD_OBJECT_NAMED);
    amxd_object_t* obj = amxd_dm_findf(bulkdata_get_dm(), "%s.CSVEncoding.", path);
    free(path);
    return obj;
}

const cstring_t bulkdata_csv_encoding_get_field_separator(amxd_object_t* csv_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(csv_encoding, "FieldSeparator"));
}

const cstring_t bulkdata_csv_encoding_get_row_separator(amxd_object_t* csv_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(csv_encoding, "RowSeparator"));
}

const cstring_t bulkdata_csv_encoding_get_escape_character(amxd_object_t* csv_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(csv_encoding, "EscapeCharacter"));
}

const cstring_t bulkdata_csv_encoding_get_report_format(amxd_object_t* csv_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(csv_encoding, "ReportFormat"));
}

const cstring_t bulkdata_csv_encoding_get_row_timestamp(amxd_object_t* csv_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(csv_encoding, "RowTimestamp"));
}

static void bulkdata_escape_string(amxc_string_t* str, cstring_t escape_character) {
    amxc_string_t replacement;
    amxc_string_init(&replacement, 0);

    amxc_string_setf(&replacement, "%s\"", escape_character);
    amxc_string_replace(str, "\"", amxc_string_get(&replacement, 0), UINT32_MAX);

    amxc_string_clean(&replacement);
}

static void bulkdata_convert_to_ParameterPerRow_data(amxc_var_t* data, amxc_var_t* converted_data,
                                                     const cstring_t collection_time,
                                                     const cstring_t fields_separator,
                                                     const cstring_t rows_separator,
                                                     const cstring_t escape_character) {
    amxc_string_t record;
    amxc_string_t value_str;
    cstring_t decoded_row_seperator = calloc(40, sizeof(char));
    cstring_t decoded_escape = calloc(40, sizeof(char));

    bulkdata_decode_html_entities(rows_separator, decoded_row_seperator);
    bulkdata_decode_html_entities(escape_character, decoded_escape);

    amxc_string_init(&value_str, 0);
    amxc_string_init(&record, 0);
    amxc_string_setf(&record, "ReportTimestamp%sParameterName%sParameterValue%sParameterType%s", fields_separator, fields_separator, fields_separator, decoded_row_seperator);

    amxc_var_for_each(entry, data) {
        const char* key = amxc_var_key(entry);
        const char* value = GET_CHAR(entry, "value");
        const char* type = GET_CHAR(entry, "type");
        const char* name = GET_CHAR(entry, "paramName");
        const char* name_in_csv_record = NULL;
        SAH_TRACEZ_NOTICE(ME, "key '%s' | name '%s'| value '%s' | type '%s'", key, name, value, type);

        // If 'BulkData.Profile.i.Parameter.j.Name' is empty ==> take the full path that is set in Reference
        if((name == NULL) || (name[0] == '\0')) {
            name_in_csv_record = key;
        } else {
            name_in_csv_record = name;
        }

        amxc_string_setf(&value_str, "%s", value);
        bulkdata_escape_string(&value_str, decoded_escape);

        amxc_string_appendf(&record, "%s%s%s%s%s%s%s%s",
                            collection_time, fields_separator,
                            name_in_csv_record, fields_separator,
                            amxc_string_get(&value_str, 0), fields_separator,
                            type, decoded_row_seperator);
    }
    amxc_var_add(cstring_t, converted_data, amxc_string_get(&record, 0));

    amxc_string_clean(&record);
    amxc_string_clean(&value_str);
    free(decoded_row_seperator);
    free(decoded_escape);
}

static void bulkdata_convert_to_ParameterPerColumn_data(amxc_var_t* data, amxc_var_t* converted_data,
                                                        const cstring_t collection_time,
                                                        const cstring_t fields_separator,
                                                        const cstring_t rows_separator,
                                                        const cstring_t escape_character) {
    amxc_string_t record;
    amxc_string_t header;
    amxc_string_t value_str;
    cstring_t decoded_row_seperator = calloc(40, sizeof(char));
    cstring_t decoded_escape = calloc(40, sizeof(char));

    bulkdata_decode_html_entities(rows_separator, decoded_row_seperator);
    bulkdata_decode_html_entities(escape_character, decoded_escape);

    amxc_string_init(&value_str, 0);
    amxc_string_init(&record, 0);
    amxc_string_init(&header, 0);

    amxc_string_setf(&header, "%s", "ReportTimestamp");
    amxc_string_setf(&record, "%s", collection_time);

    amxc_var_for_each(entry, data) {
        const char* key = amxc_var_key(entry);
        const char* value = GET_CHAR(entry, "value");
        const char* name = GET_CHAR(entry, "paramName");
        amxc_string_setf(&value_str, "%s", value);
        bulkdata_escape_string(&value_str, decoded_escape);

        // If 'BulkData.Profile.i.Parameter.j.Name' is empty ==> take the full path that is set in Reference
        if((name == NULL) || (name[0] == '\0')) {
            amxc_string_appendf(&header, "%s%s", fields_separator, key);
        } else {
            amxc_string_appendf(&header, "%s%s", fields_separator, name);
        }
        amxc_string_appendf(&record, "%s%s", fields_separator, amxc_string_get(&value_str, 0));
    }

    amxc_string_appendf(&header, "%s", decoded_row_seperator);
    amxc_string_appendf(&record, "%s", decoded_row_seperator);
    amxc_string_appendf(&header, "%s", amxc_string_get(&record, 0));
    amxc_var_add(cstring_t, converted_data, amxc_string_get(&header, 0));

    amxc_string_clean(&record);
    amxc_string_clean(&header);
    amxc_string_clean(&value_str);
    free(decoded_row_seperator);
    free(decoded_escape);
}


static void bulkdata_generate_collection_time(amxd_object_t* json_encoding, cstring_t collection_time) {
    const cstring_t report_timestamp = NULL;
    cstring_t report_collection_time = NULL;
    amxc_ts_t* timestamp = NULL;
    when_null(collection_time, exit);

    report_timestamp = bulkdata_csv_encoding_get_row_timestamp(json_encoding);
    when_true_trace((report_timestamp == NULL) || (strcmp(report_timestamp, "None") == 0), exit, ERROR, "Don't send CollectionTime");

    timestamp = bulkdata_utc_timestamp(report_timestamp);
    when_null_trace(timestamp, exit, ERROR, "Could not retrieve UTC timestamp.");
    report_collection_time = bulkdata_format_time(report_timestamp, timestamp);
    when_null(report_collection_time, exit);
    memcpy(collection_time, report_collection_time, strlen(report_collection_time));

exit:
    free(report_collection_time);
    free(timestamp);
}

amxc_var_t* bulkdata_csv_format_data(amxd_object_t* profile, amxc_var_t* data) {
    amxd_object_t* csv_encoding;
    const cstring_t fields_separator = NULL;
    const cstring_t rows_separator = NULL;
    const cstring_t escape_character = NULL;
    char* report_format = NULL;
    cstring_t collection_time = calloc(40, sizeof(char));

    amxc_var_t converted_data;
    amxc_var_t* csv = NULL;

    amxc_var_init(&converted_data);
    amxc_var_set_type(&converted_data, AMXC_VAR_ID_LIST);
    amxc_var_new(&csv);

    csv_encoding = bulkdata_get_csv_encoding_object(profile);
    when_null(csv_encoding, exit);
    fields_separator = bulkdata_csv_encoding_get_field_separator(csv_encoding);
    rows_separator = bulkdata_csv_encoding_get_row_separator(csv_encoding);
    escape_character = bulkdata_csv_encoding_get_escape_character(csv_encoding);

    /* Add CollectionTime */
    bulkdata_generate_collection_time(csv_encoding, collection_time);
    /* Manage csv formating */
    report_format = amxd_object_get_value(cstring_t, csv_encoding, "ReportFormat", NULL);
    if(strcmp(report_format, CSV_ENCODING_PARAM_PER_ROW) == 0) {
        bulkdata_convert_to_ParameterPerRow_data(data, &converted_data, collection_time, fields_separator, rows_separator, escape_character);
        amxc_var_move(csv, &converted_data);
    } else if(strcmp(report_format, CSV_ENCODING_PARAM_PER_COLUMN) == 0) {
        bulkdata_convert_to_ParameterPerColumn_data(data, &converted_data, collection_time, fields_separator, rows_separator, escape_character);
        amxc_var_move(csv, &converted_data);
    } else {
        /* Do a copy to returned a variant that can be delete later */
        amxc_var_move(csv, data);
    }

exit:
    amxc_var_clean(&converted_data);
    free(report_format);
    free(collection_time);
    return csv;
}
