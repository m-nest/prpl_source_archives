/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_path.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "conmon_queries.h"
#include "conmon_soc_utils.h"
#include "conmon_utils.h"

#define BUS_TIMEOUT 5

static char* resolve_path(char* path) {
    amxd_path_t full_path;
    amxb_bus_ctx_t* ctx = NULL;
    amxc_var_t ret;
    int res = -1;
    const char* resolved_path = NULL;
    char* returned_path = NULL;
    char* fixed_path = NULL;

    amxd_path_init(&full_path, 0);
    amxc_var_init(&ret);

    when_str_empty(path, exit);
    amxd_path_setf(&full_path, true, "%s", path);

    if(!amxd_path_is_search_path(&full_path)) {
        returned_path = strdup(amxd_path_get(&full_path, AMXD_OBJECT_TERMINATE));
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Resolving search path '%s'", path);
    fixed_path = amxd_path_get_fixed_part(&full_path, false);
    ctx = amxb_be_who_has(fixed_path);
    when_null_trace(ctx, exit, ERROR, "No bus context was found for '%s'", fixed_path);

    res = amxb_get(ctx, amxd_path_get(&full_path, AMXD_OBJECT_TERMINATE), 0, &ret, BUS_TIMEOUT);
    when_failed_trace(res, exit, WARNING, "Failed(%d) to lookup search path: %s", res, path);

    resolved_path = amxc_var_key(GETP_ARG(&ret, "0.0"));
    when_str_empty_trace(resolved_path, exit, WARNING, "No results for '%s'", path);

    SAH_TRACEZ_INFO(ME, "Resolved '%s' to '%s'", path, resolved_path);
    returned_path = strdup(resolved_path);
exit:
    free(fixed_path);
    amxd_path_clean(&full_path);
    amxc_var_clean(&ret);
    return returned_path;
}

static void conmon_interface_disable(conmon_info_t* conmon) {
    amxc_var_t mod_data;
    amxc_var_init(&mod_data);

    amxp_timer_delete(&conmon->resolve_timer);

    mod_conmon_build_basic_data_struct(conmon, &mod_data, false);
    mod_conmon_execute_function(MOD_CONMON_UPDATE_STOP_FUNCTION, &mod_data);

    cleanup_netdev_queries(conmon);
    cleanup_nm_interface_queries(conmon);
    conmon_set_status(conmon, STATUS_DISABLED);

    amxc_var_clean(&mod_data);
}

static void conmon_interface_enable_queries(conmon_info_t* conmon, const char* resolved_path) {
    amxd_object_t* conmon_object = NULL;
    const char* type = NULL;
    uint32_t ip_version = 0;
    amxc_string_t buffer;
    amxc_var_t mod_data;

    amxc_string_init(&buffer, 0);
    amxc_var_init(&mod_data);

    conmon_object = conmon->entry;
    when_null_trace(conmon_object, exit, ERROR, "Private data for entry is NULL");

    type = GET_CHAR(amxd_object_get_param_value(conmon_object, "Type"), NULL);
    when_false_trace((is_ipv4(type) || is_ipv6(type)), exit, ERROR, "Skipping entry since neither ARP or ND is configured");
    ip_version = (is_ipv4(type) ? 4 : 6);

    amxc_string_setf(&buffer, "netdev && ipv%d", ip_version);
    conmon->wan_intf = netmodel_openQuery_luckyIntf(resolved_path, PLUGIN_NAME, amxc_string_get(&buffer, 0), netmodel_traverse_down, wanintf_changed, (void*) conmon);
    verify_open_query(conmon->wan_intf, "wan_intf");

    amxc_string_setf(&buffer, "ipv%d-up", ip_version);
    conmon->wan_isup = netmodel_openQuery_isUp(resolved_path, PLUGIN_NAME, amxc_string_get(&buffer, 0), netmodel_traverse_down, isup_changed, (void*) conmon);
    verify_open_query(conmon->wan_isup, "wan_isup");
    conmon->ll_interface_path_changed = netmodel_openQuery_getFirstParameter(resolved_path, PLUGIN_NAME, "InterfacePath", "ip", netmodel_traverse_down, ll_interface_path_changed, (void*) conmon);
    verify_open_query(conmon->ll_interface_path_changed, "ll_interface_path_changed");

    if(ip_version == 4) {
        conmon->wan_defaultroute = netmodel_openQuery_getDHCPOption(resolved_path, PLUGIN_NAME, "req", 3, netmodel_traverse_down, wan_defaultroute_changed, (void*) conmon);
        verify_open_query(conmon->wan_defaultroute, "wan_defaultroute");
        conmon->wan_physdowntimeout = netmodel_openQuery_getFirstParameter(resolved_path, PLUGIN_NAME, "ResetOnPhysDownTimeout", NULL, netmodel_traverse_down, physdowntimeout_changed, (void*) conmon);
        verify_open_query(conmon->wan_physdowntimeout, "wan_physdowntimeout");
        conmon->local_ip = netmodel_openQuery_getFirstParameter(resolved_path, PLUGIN_NAME, "IPAddress", "ipv4", netmodel_traverse_down, local_ip_changed, (void*) conmon);
        verify_open_query(conmon->local_ip, "local_ip");
        conmon->dhcp_isup = netmodel_openQuery_hasFlag(resolved_path, PLUGIN_NAME, "dhcpv4-up && dhcpv4-bound", "", netmodel_traverse_down, dhcp_changed, (void*) conmon);
        verify_open_query(conmon->dhcp_isup, "dhcp_isup");
    } else {     // ip_version == 6
        // No timeout for IPv6 directly call netdev subscriptions
        create_netdev_subscription(conmon, "dm:instance-added", &conmon->netdev_link_added_subscription, netdev_new_link_added_cb);
        create_netdev_subscription(conmon, "dm:instance-removed", &conmon->netdev_link_removed_subscription, netdev_link_removed_cb);

        conmon->wan_defaultroute = netmodel_openQuery_getFirstParameter(resolved_path, PLUGIN_NAME, "IPv6Router.SourceRouter", "ipv6", netmodel_traverse_down, wan6_defaultroute_changed, (void*) conmon);
        verify_open_query(conmon->wan_defaultroute, "wan_defaultroute");
        conmon->local_ip = netmodel_openQuery_luckyAddrAddress(resolved_path, PLUGIN_NAME, "ipv6 && @gua", netmodel_traverse_down, local_ip_changed, (void*) conmon);
        verify_open_query(conmon->local_ip, "local_ip");
        conmon->dhcp_isup = netmodel_openQuery_hasFlag(resolved_path, PLUGIN_NAME, "dhcpv6-up", "", netmodel_traverse_down, dhcp_changed, (void*) conmon);
        verify_open_query(conmon->dhcp_isup, "dhcp_isup");
    }

    mod_conmon_build_basic_data_struct(conmon, &mod_data, true);
    mod_conmon_execute_function(MOD_CONMON_UPDATE_CONFIG_FUNCTION, &mod_data);
exit:
    amxc_var_clean(&mod_data);
    amxc_string_clean(&buffer);
}

static void check_if_interface_is_resolvable(UNUSED amxp_timer_t* timer, void* priv) {
    conmon_info_t* conmon = (conmon_info_t*) priv;
    char* resolved_path = NULL;

    resolved_path = resolve_path(conmon->logical_path);
    when_str_empty(resolved_path, exit);

    amxp_timer_delete(&conmon->resolve_timer);
    conmon_interface_enable_queries(conmon, resolved_path);
exit:
    free(resolved_path);
}

static void conmon_interface_enable(conmon_info_t* conmon) {
    amxd_object_t* conmon_object = NULL;
    const char* type = NULL;
    char* resolved_path = NULL;

    conmon_object = conmon->entry;
    when_null_trace(conmon_object, exit, ERROR, "Private data for entry is NULL");

    type = GET_CHAR(amxd_object_get_param_value(conmon_object, "Type"), NULL);
    when_false_trace((is_ipv4(type) || is_ipv6(type)), exit, ERROR, "Skipping entry since neither ARP or ND is configured");

    resolved_path = resolve_path(conmon->logical_path);
    if(!str_empty(resolved_path)) {
        amxp_timer_delete(&conmon->resolve_timer);
        conmon_interface_enable_queries(conmon, resolved_path);
        goto exit;
    }

    if(conmon->resolve_timer == NULL) {
        amxp_timer_new(&conmon->resolve_timer, check_if_interface_is_resolvable, conmon);
        amxp_timer_set_interval(conmon->resolve_timer, RESOLVE_RETRY_INTERVAL);
    }
    amxp_timer_start(conmon->resolve_timer, RESOLVE_RETRY_INTERVAL);
    conmon_set_status(conmon, STATUS_ERROR);
exit:
    free(resolved_path);
}

void set_intf_info(conmon_info_t* conmon) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* conmon_object = NULL;

    when_null(conmon, exit);
    conmon_object = conmon->entry;
    when_null_trace(conmon_object, exit, ERROR, "Private data for entry is NULL");

    if(amxd_object_get_value(bool, conmon_object, "Enable", NULL)) {
        conmon_interface_enable(conmon);
    } else {
        conmon_interface_disable(conmon);
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

amxd_status_t conmon_info_new(conmon_info_t** conmon) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t rv = amxd_status_invalid_function_argument;

    when_null_trace(conmon, exit, ERROR, "conmon can not be null, invalid argument");

    *conmon = (conmon_info_t*) calloc(1, sizeof(conmon_info_t));
    when_null_status(*conmon, exit, rv = amxd_status_out_of_mem);

    rv = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

amxd_status_t conmon_info_clean(conmon_info_t** conmon) {
    SAH_TRACEZ_IN(ME);

    if((conmon == NULL) || (*conmon == NULL)) {
        goto exit;
    }
    cleanup_nm_interface_queries(*conmon);
    cleanup_netdev_queries(*conmon);

    amxp_timer_delete(&(*conmon)->resolve_timer);

    free((*conmon)->logical_path);
    (*conmon)->logical_path = NULL;
    free((*conmon)->alias);
    (*conmon)->alias = NULL;
    free((*conmon)->interface_name);
    (*conmon)->interface_name = NULL;

    free(*conmon);
    *conmon = NULL;

exit:
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

static amxd_object_t* find_conmon_obj_by_alias(const char* alias) {
    SAH_TRACEZ_IN(ME);

    amxd_object_t* instance = NULL;
    amxd_object_t* template_obj = amxd_dm_findf(conmon_get_dm(), "ConMon.Entry.");

    when_null_trace(template_obj, exit, ERROR, "Could not find ConMon.Entry. template object");

    amxd_object_for_each(instance, it, template_obj) {
        amxd_object_t* inst = amxc_container_of(it, amxd_object_t, it);

        const char* name = amxd_object_get_name(inst, AMXD_OBJECT_NAMED);
        if(strcmp(alias, name) == 0) {
            instance = inst;
            break;
        }
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return instance;
}

static int conmon_update_stats(amxd_object_t* obj,
                               amxc_var_t* args,
                               amxd_trans_t* trans) {
    SAH_TRACEZ_IN(ME);

    int rv = -1;
    const char* alias = GET_CHAR(args, "alias");
    amxd_object_t* stats_obj = NULL;
    stats_obj = amxd_object_findf(obj, "Stats.");
    (void) alias; // use variable when traces are disabled
    when_null_trace(stats_obj, exit, ERROR, "Stats object for alias %s not found", alias);

    amxd_trans_select_object(trans, stats_obj);
    if(amxc_var_get_key(args, "arpns_total_fail", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxd_trans_set_param(trans, "ARPNSTotalFail", GET_ARG(args, "arpns_total_fail"));
    }
    if(amxc_var_get_key(args, "total_dhcp_restarts", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxd_trans_set_param(trans, "TotalDHCPRestarts", GET_ARG(args, "total_dhcp_restarts"));
    }
    if(amxc_var_get_key(args, "arpns_errors_sent", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxd_trans_set_param(trans, "ARPNSErrorsSent", GET_ARG(args, "arpns_errors_sent"));
    }

    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

int conmon_set_status(conmon_info_t* entry, const char* status) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t args;
    amxc_var_t ret;
    int rc = -1;

    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    when_null(entry, exit);
    when_null(status, exit);

    amxc_var_add_key(cstring_t, &args, "alias", entry->alias);
    amxc_var_add_key(cstring_t, &args, "Status", status);

    rc = conmon_update_dm(NULL, &args, &ret);
    when_failed_trace(rc, exit, ERROR, "[%s] Failed to set Status %s", entry->alias, status);

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&args);

    SAH_TRACEZ_OUT(ME);
    return rc;
}

const char* conmon_get_status(conmon_info_t* entry, bool dhcp_up) {
    SAH_TRACEZ_IN(ME);

    amxd_object_t* conmon_object = NULL;
    const char* status = NULL;
    bool entry_enabled = false;

    when_null(entry, exit);

    conmon_object = entry->entry;
    when_null_trace(conmon_object, exit, ERROR, "Private data for entry is NULL");
    entry_enabled = amxd_object_get_value(bool, conmon_object, "Enable", NULL);

    if(entry_enabled) {
        status = dhcp_up ? STATUS_ENABLED : STATUS_ERROR;
    } else {
        status = STATUS_DISABLED;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

int conmon_update_dm(UNUSED const char* function_name,
                     amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    int rv = -1;
    amxd_object_t* obj = NULL;
    amxd_trans_t trans;
    amxd_status_t trans_result = amxd_status_unknown_error;
    const char* alias = GET_CHAR(args, "alias");

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    when_str_empty_trace(alias, exit, ERROR, "alias is empty");

    obj = find_conmon_obj_by_alias(alias);
    when_null_trace(obj, exit, ERROR, "Could not find ConMon object for alias %s", alias);

    amxd_trans_select_object(&trans, obj);
    if(amxc_var_get_key(args, "Status", AMXC_VAR_FLAG_DEFAULT) != NULL) {
        amxd_trans_set_param(&trans, "Status", GET_ARG(args, "Status"));
    }

    rv = conmon_update_stats(obj, args, &trans);
    when_failed_trace(rv, exit, ERROR, "Failed to update Stats for alias %s", alias);

    trans_result = amxd_trans_apply(&trans, conmon_get_dm());
    when_failed_trace(trans_result, exit, ERROR, "Failed to update dm for ConMon Entry for alias %s (%s)", alias, amxd_status_string(trans_result));

    rv = 0;

exit:
    amxd_trans_clean(&trans);

    SAH_TRACEZ_OUT(ME);
    return rv;
}
