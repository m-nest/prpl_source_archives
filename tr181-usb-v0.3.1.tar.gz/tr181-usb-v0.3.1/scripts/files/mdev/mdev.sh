#!/bin/sh /etc/rc.common
# Copyright (C) 2025 Sagemcom

START=10

boot() {
	# MDEV loading...
    echo > /dev/mdev.seq
    sysctl -w kernel.hotplug=/sbin/mdev
    /sbin/mdev -s
}
