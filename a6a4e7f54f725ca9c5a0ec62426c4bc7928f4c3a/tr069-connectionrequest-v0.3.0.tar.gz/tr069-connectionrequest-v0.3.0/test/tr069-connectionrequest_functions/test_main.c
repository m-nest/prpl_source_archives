/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include "test_helpers.h"

/* Suites exposed by feature files */

extern const struct CMUnitTest g_remove_device_tests[];
extern const size_t g_remove_device_tests_count;

extern const struct CMUnitTest g_add_device_tests[];
extern const size_t g_add_device_tests_count;

extern const struct CMUnitTest g_state_update_tests[];
extern const size_t g_state_update_tests_count;

extern const struct CMUnitTest g_update_connreq_tests[];
extern const size_t g_update_connreq_tests_count;

extern const struct CMUnitTest g_add_any_port_mapping_tests[];
extern const size_t g_add_any_port_mapping_count;

extern const struct CMUnitTest g_add_port_mapping_tests[];
extern const size_t g_add_port_mapping_count;

extern const struct CMUnitTest g_get_specific_port_mapping_entry_tests[];
extern const size_t g_get_specific_port_mapping_entry_count;

extern const struct CMUnitTest g_add_pinhole_tests[];
extern const size_t g_add_pinhole_count;

extern const struct CMUnitTest g_update_pinhole_tests[];
extern const size_t g_update_pinhole_count;

int main(void) {
    int rc = 0;

    rc |= _cmocka_run_group_tests("CtrlPointRemoveDevice",
                                  g_remove_device_tests,
                                  g_remove_device_tests_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("CtrlPointAddDevice",
                                  g_add_device_tests, g_add_device_tests_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("StateUpdate",
                                  g_state_update_tests, g_state_update_tests_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("updateConnectionRequestURL",
                                  g_update_connreq_tests,
                                  g_update_connreq_tests_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("AddAnyPortMapping",
                                  g_add_any_port_mapping_tests,
                                  g_add_any_port_mapping_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("AddPortMapping",
                                  g_add_port_mapping_tests,
                                  g_add_port_mapping_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("GetSpecificPortMappingEntry",
                                  g_get_specific_port_mapping_entry_tests,
                                  g_get_specific_port_mapping_entry_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("AddPinhole",
                                  g_add_pinhole_tests,
                                  g_add_pinhole_count,
                                  global_setup, global_teardown);
    rc |= _cmocka_run_group_tests("UpdatePinhole",
                                  g_update_pinhole_tests,
                                  g_update_pinhole_count,
                                  global_setup, global_teardown);

    return rc;
}
