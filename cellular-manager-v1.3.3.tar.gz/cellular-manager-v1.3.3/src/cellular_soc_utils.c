/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "cellular_priv.h"
#include "cellular_actions.h"
#include "cellular_utils.h"

#include "cellular_soc_utils.h"

#define ME "utils"

/**
 * Definition for the Cellular interface read-only parameters
 */
static const char* CellIfParams[] = {
    "InternalName",
    "Status",
    "IMEI",
    "SupportedAccessTechnologies",
    "PreferredAccessTechnology",
    "CurrentAccessTechnology",
    "AvailableNetworks",
    "NetworkRequested",
    "NetworkInUse",
    "RSSI",
    "RSRP",
    "RSRQ",
    "UpstreamMaxBitRate",
    "DownstreamMaxBitRate",
    NULL
};

/**
 * Definition for the USIM read-only parameters
 */
static const char* USIMParams[] = {
    "InternalName",
    "Status",
    "IMSI",
    "ICCID",
    "MSISDN",
    NULL
};

/**
 * Definition for the Bearer read-only parameters
 */
static const char* BearerParams[] = {
    "InternalName",
    "DNSServers",
    NULL
};

/**
 * Definition for the Bearer IPv4 read-only parameters
 */
static const char* BearerIPv4Params[] = {
    "Method",
    "Address",
    "GatewayIPAddress",
    "SubnetMask",
    "MTU",
    NULL
};

/**
 * Definition for the Bearer IPv6 read-only parameters
 */
static const char* BearerIPv6Params[] = {
    "Method",
    "Address",
    "NextHop",
    "Prefix",
    "MTU",
    NULL
};

static const char* get_cellular_ctrl(void) {
    amxd_dm_t* dm = cellular_get_dm();
    amxd_object_t* cellular_obj = amxd_dm_findf(dm, "Cellular");
    const amxc_var_t* cellular_ctrl = amxd_object_get_param_value(cellular_obj, "CellularController");

    const char* cellular_ctrl_name = NULL;

    if(cellular_mods_are_loaded()) {
        cellular_ctrl_name = GET_CHAR(cellular_ctrl, NULL);
    } else {
        cellular_ctrl_name = DUMMY_CELLULAR_MOD_NAME;
    }

    return cellular_ctrl_name;
}

static amxd_object_t* find_accesspoint_obj(uint32_t iface_idx) {
    amxd_dm_t* dm = cellular_get_dm();
    amxd_object_t* obj = amxd_dm_findf(dm, "Cellular.AccessPoint.[Enable && Interface==\"Device.Cellular.Interface.%u.\"].", iface_idx);

    return obj;
}

int mod_cellular_execute_function(amxd_object_t* cellular_obj, const char* function, amxc_var_t* data, amxc_var_t* ret) {
    const char* cellular_ctrl = NULL;
    int rv = -1;

    when_str_empty(function, exit);
    when_null_trace(cellular_obj, exit, ERROR, "can not execute %s, no object given", function);

    cellular_ctrl = get_cellular_ctrl();
    SAH_TRACEZ_INFO(ME, "%s -> call implementation (controller = '%s')", function, cellular_ctrl);
    rv = amxm_execute_function(cellular_ctrl, MOD_CELLULAR_CTRL, function, data, ret);
    when_failed_trace(rv, exit, ERROR, "amxm_execute_function failed");

exit:
    return rv;
}

static void cellular_info_fill_trans(amxd_object_t* cell_obj, amxd_trans_t* trans,
                                     const char* params[], const amxc_var_t* cell_entry) {
    amxd_param_t* param = NULL;
    uint32_t type = 0;
    int status = 0;
    amxc_var_t conv_var;

    amxc_var_init(&conv_var);
    amxd_trans_select_object(trans, cell_obj);
    for(int i = 0; params[i] != NULL; i++) {
        param = amxd_object_get_param_def(cell_obj, params[i]);
        when_null_trace(param, exit, ERROR, "invalid parameter %s", params[i]);
        type = amxc_var_type_of(&param->value);
        status = amxc_var_convert(&conv_var, GET_ARG(cell_entry, params[i]), type);
        when_failed_trace(status, exit, ERROR, "failed to convert parameter %s value", params[i]);
        status = amxd_trans_set_param(trans, params[i], &conv_var);
        when_failed_trace(status, exit, ERROR, "failed to set parameter %s", params[i]);
    }

exit:
    amxc_var_clean(&conv_var);
    return;
}

static const amxc_var_t* get_object_prefixed_param(amxd_object_t* obj, const cstring_t name) {
    const amxc_var_t* result = NULL;
    amxc_string_t prefixed_name;

    when_null(obj, exit);
    when_str_empty(name, exit);

    amxc_string_init(&prefixed_name, 0);
    amxc_string_setf(&prefixed_name, "%s%s", GET_CHAR(cellular_get_config(), "global_vendor_prefix_"), name);

    result = amxd_object_get_param_value(obj, amxc_string_get(&prefixed_name, 0));

exit:
    amxc_string_clean(&prefixed_name);
    return result;
}

amxd_object_t* cell_iface_info_push(amxd_object_t* object, amxd_param_t* const param, const amxc_var_t* const new_value) {
    amxc_var_t data;
    amxc_var_t ret;
    cell_iface_t* cell_iface = NULL;

    when_null_trace(object, exit, ERROR, "object is NULL");
    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");
    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");

    cell_iface = (cell_iface_t*) object->priv;
    when_null_trace(cell_iface, exit, INFO, "cell_iface is still NULL");
    when_null_trace(param, exit, ERROR, "Passed param argument is NULL");
    when_null_trace(new_value, exit, ERROR, "Passed new_value argument is NULL");

    SAH_TRACEZ_INFO(ME, "%s, Setting %s", amxd_object_get_name(object, AMXD_OBJECT_NAMED), param->name);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", amxd_object_get_path(object, AMXD_OBJECT_INDEXED));

    if(!strcmp(param->name, "Enable")) {
        amxd_dm_t* dm = cellular_get_dm();
        amxd_object_t* cell_obj = amxd_dm_findf(dm, "Cellular");
        when_null_trace(cell_obj, exit, ERROR, "Cellular not found");
        const amxc_var_t* roaming = amxd_object_get_param_value(cell_obj, "RoamingEnabled");
        amxd_object_t* ap_obj = find_accesspoint_obj(amxd_object_get_index(object));
        when_null_trace(ap_obj, exit, ERROR, "AccessPoint not found");
        const amxc_var_t* apn = amxd_object_get_param_value(ap_obj, "APN");
        const amxc_var_t* user = amxd_object_get_param_value(ap_obj, "Username");
        const amxc_var_t* pass = amxd_object_get_param_value(ap_obj, "Password");
        const amxc_var_t* proxy = amxd_object_get_param_value(ap_obj, "Proxy");
        const amxc_var_t* port = amxd_object_get_param_value(ap_obj, "ProxyPort");
        const amxc_var_t* iptype = get_object_prefixed_param(ap_obj, "IPType");
        SAH_TRACEZ_INFO(ME, "Passing APN %s roaming:%s user:%s pass:%s proxy:%s:%u iptype:%s",
                        amxc_var_constcast(cstring_t, apn),
                        (amxc_var_dyncast(bool, roaming) ? "true" : "false"),
                        amxc_var_constcast(cstring_t, user), amxc_var_constcast(cstring_t, pass),
                        amxc_var_constcast(cstring_t, proxy), amxc_var_dyncast(uint32_t, port),
                        amxc_var_constcast(cstring_t, iptype));

        amxc_var_add_key(bool, &data, "Enable", amxc_var_dyncast(bool, new_value));
        amxc_var_add_key(cstring_t, &data, "APN", amxc_var_constcast(cstring_t, apn));
        amxc_var_add_key(bool, &data, "RoamingEnabled", amxc_var_dyncast(bool, roaming));
        amxc_var_add_key(cstring_t, &data, "UserName", amxc_var_constcast(cstring_t, user));
        amxc_var_add_key(cstring_t, &data, "Password", amxc_var_constcast(cstring_t, pass));
        amxc_var_add_key(cstring_t, &data, "Proxy", amxc_var_constcast(cstring_t, proxy));
        amxc_var_add_key(uint32_t, &data, "ProxyPort", amxc_var_dyncast(uint32_t, port));
        amxc_var_add_key(cstring_t, &data, "IPType", amxc_var_constcast(cstring_t, iptype));
    } else if(strstr(param->name, "SignalQualityPollingRate") != NULL) {
        amxc_var_add_key(uint32_t, &data, "SignalQualityPollingRate", amxc_var_dyncast(uint32_t, new_value));
    } else if(!strcmp(param->name, "PreferredAccessTechnology")) {
        amxc_var_add_key(cstring_t, &data, "PreferredAccessTechnology", amxc_var_constcast(cstring_t, new_value));
    } else if(!strcmp(param->name, "NetworkRequested")) {
        amxc_var_add_key(cstring_t, &data, "NetworkRequested", amxc_var_constcast(cstring_t, new_value));
    }

    when_failed_trace(mod_cellular_execute_function(object, "set-cell-iface-info", &data, &ret),
                      exit, ERROR, "set-cell-iface-info failed");
exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return object;
}

int mod_cellular_set_interface_params(amxd_object_t* cellular_obj) {
    int rv = -1;
    amxd_param_t* param = NULL;

    when_null_trace(cellular_obj, exit, ERROR, "no object given");

    amxc_llist_for_each(it, (&cellular_obj->parameters)) {
        param = amxc_llist_it_get_data(it, amxd_param_t, it);
        if((strstr(param->name, "SignalQualityPollingRate") != NULL) ||
           !strcmp(param->name, "PreferredAccessTechnology") ||
           !strcmp(param->name, "NetworkRequested")) {
            cell_iface_info_push(cellular_obj, param, &param->value);
        }
    }

    rv = 0;

exit:
    return rv;
}

int set_cell_iface_enabled(cell_iface_t* cell_iface, bool enable) {
    int rv = -1;
    amxc_var_t data;
    amxc_var_t ret;

    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");
    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");

    when_null_trace(cell_iface, exit, ERROR, "Passed cell_iface info is NULL");
    when_null_trace(cell_iface->object, exit, ERROR, "cell_iface object is NULL");

    SAH_TRACEZ_INFO(ME, "%s, Setting %s", amxd_object_get_name(cell_iface->object, AMXD_OBJECT_NAMED), enable ? "enabled" : "disabled");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));
    amxc_var_add_key(bool, &data, "Enable", enable);

    amxd_dm_t* dm = cellular_get_dm();
    amxd_object_t* cell_obj = amxd_dm_findf(dm, "Cellular");
    when_null_trace(cell_obj, exit, ERROR, "Cellular not found");
    const amxc_var_t* roaming = amxd_object_get_param_value(cell_obj, "RoamingEnabled");
    amxd_object_t* ap_obj = find_accesspoint_obj(amxd_object_get_index(cell_iface->object));
    when_null_trace(ap_obj, exit, ERROR, "AccessPoint not found");
    const amxc_var_t* apn = amxd_object_get_param_value(ap_obj, "APN");
    const amxc_var_t* user = amxd_object_get_param_value(ap_obj, "Username");
    const amxc_var_t* pass = amxd_object_get_param_value(ap_obj, "Password");
    const amxc_var_t* proxy = amxd_object_get_param_value(ap_obj, "Proxy");
    const amxc_var_t* port = amxd_object_get_param_value(ap_obj, "ProxyPort");
    const amxc_var_t* iptype = get_object_prefixed_param(ap_obj, "IPType");
    SAH_TRACEZ_INFO(ME, "Passing APN %s roaming:%s user:%s pass:%s proxy:%s:%u iptype:%s",
                    amxc_var_constcast(cstring_t, apn),
                    (amxc_var_dyncast(bool, roaming) ? "true" : "false"),
                    amxc_var_constcast(cstring_t, user), amxc_var_constcast(cstring_t, pass),
                    amxc_var_constcast(cstring_t, proxy), amxc_var_dyncast(uint32_t, port),
                    amxc_var_constcast(cstring_t, iptype));

    amxc_var_add_key(cstring_t, &data, "APN", amxc_var_constcast(cstring_t, apn));
    amxc_var_add_key(bool, &data, "RoamingEnabled", amxc_var_dyncast(bool, roaming));
    amxc_var_add_key(cstring_t, &data, "UserName", amxc_var_constcast(cstring_t, user));
    amxc_var_add_key(cstring_t, &data, "Password", amxc_var_constcast(cstring_t, pass));
    amxc_var_add_key(cstring_t, &data, "Proxy", amxc_var_constcast(cstring_t, proxy));
    amxc_var_add_key(uint32_t, &data, "ProxyPort", amxc_var_dyncast(uint32_t, port));
    amxc_var_add_key(cstring_t, &data, "IPType", amxc_var_constcast(cstring_t, iptype));

    when_failed_trace(mod_cellular_execute_function(cell_iface->object, "set-cell-iface-info", &data, &ret),
                      exit, ERROR, "set-cell-iface-info failed");

    rv = 0;

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return rv;
}

int set_cell_iface_usim(cell_iface_t* cell_iface, const char* pincheck, const char* pin) {
    int rv = -1;
    amxc_var_t data;
    amxc_var_t ret;

    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");
    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");

    when_null_trace(cell_iface, exit, ERROR, "Passed cell_iface info is NULL");
    when_null_trace(cell_iface->object, exit, ERROR, "cell_iface object is NULL");

    SAH_TRACEZ_INFO(ME, "%s.USIM, Setting PINCheck=%s PIN=%s",
                    amxd_object_get_name(cell_iface->object, AMXD_OBJECT_NAMED),
                    pincheck ? pincheck : "(unchanged)",
                    pin ? pin : "(unchanged)");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));
    amxc_var_add_key(cstring_t, &data, "PIN", pin);
    amxc_var_add_key(cstring_t, &data, "PINCheck", pincheck);

    when_failed_trace(mod_cellular_execute_function(cell_iface->object, "set-cell-usim-info", &data, &ret),
                      exit, ERROR, "set-cell-usim-info failed");

    rv = 0;

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return rv;
}

void cell_iface_fill_trans(cell_iface_t* cell_iface, amxd_trans_t* trans) {
    amxc_var_t data;
    amxc_var_t ret;
    amxd_dm_t* dm = cellular_get_dm();
    amxd_object_t* usim_object;
    amxd_object_t* bearer_object;
    amxd_object_t* bearer_ipv4_object;
    amxd_object_t* bearer_ipv6_object;

    amxc_var_init(&ret);
    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");
    when_null_trace(cell_iface, exit, INFO, "cell_iface is NULL");
    when_null_trace(cell_iface->object, exit, ERROR, "Object is NULL");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));

    when_failed_trace(mod_cellular_execute_function(cell_iface->object, "retrieve-cell-iface-info", &data, &ret),
                      exit, ERROR, "retrieve-cell-iface-info failed");
    cellular_info_fill_trans(cell_iface->object, trans, CellIfParams, &ret);
    amxc_var_clean(&ret);

    usim_object = amxd_dm_findf(dm, "%s.USIM", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));
    when_null_trace(usim_object, exit, ERROR, "USIM object not found");
    when_failed_trace(mod_cellular_execute_function(cell_iface->object, "retrieve-cell-usim-info", &data, &ret),
                      exit, ERROR, "retrieve-cell-usim-info failed");
    cellular_info_fill_trans(usim_object, trans, USIMParams, &ret);
    amxc_var_clean(&ret);

    bearer_object = amxd_dm_findf(dm, "%s.Bearer", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));
    when_null_trace(bearer_object, exit, ERROR, "Bearer object not found");
    when_failed_trace(mod_cellular_execute_function(cell_iface->object, "retrieve-cell-bearer-info", &data, &ret),
                      exit, ERROR, "retrieve-cell-bearer-info failed");
    cellular_info_fill_trans(bearer_object, trans, BearerParams, &ret);

    bearer_ipv4_object = amxd_object_get_child(bearer_object, "IPv4");
    if(bearer_ipv4_object && GET_ARG(&ret, "IPv4")) {
        cellular_info_fill_trans(bearer_ipv4_object, trans, BearerIPv4Params, GET_ARG(&ret, "IPv4"));
    }

    bearer_ipv6_object = amxd_object_get_child(bearer_object, "IPv6");
    if(bearer_ipv6_object && GET_ARG(&ret, "IPv6")) {
        cellular_info_fill_trans(bearer_ipv6_object, trans, BearerIPv6Params, GET_ARG(&ret, "IPv6"));
    }
    amxc_var_clean(&ret);

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
}

