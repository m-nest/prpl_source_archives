# tr181-button

[TOC]

# Introduction

This is an Ambiorix plug-in for a Pushbutton Manager.

# Building, installing and testing

## Docker container

You could install all tools needed for testing and developing on your local
machine, or use a pre-configured environment. Such an environment is already
prepared for you as a docker container.

Refer to the [Ambiorix tutorials](https://gitlab.com/prpl-foundation/components/ambiorix/tutorials/getting-started) for the steps to launch the Ambiorix Docker container.

## Building

### Prerequisites

`tr181-button` depends on the following libraries:

- libamxb
- libamxc
- libamxd
- libamxm
- libamxo
- libamxp
- libamxj
- libsahtrace

### Build tr181-button

1. Clone the git repository

    To be able to build it, you need the source code. So open the desired target directory and clone this plug-in in it.

    ```bash
    mkdir ~/workspace/core/plugins
    cd ~/workspace/core/plugins/
    git clone git@gitlab.com:prpl-foundation/components/core/plugins/tr181-button.git
    ```

2. Build it

    When using the internal gitlab, you must define an environment variable `VERSION_PREFIX` before building.

    ```bash
    export VERSION_PREFIX="master_"
    ```

    After the variable is set, you can build the plug-in.

    ```bash
    cd ~/workspace/core/plugins/tr181-button
    make
    ```

## Installing

You can use the install target in the makefile to install the plug-in

```bash
cd ~/workspace/core/plugins/tr181-button
sudo -E make install
```

## Testing

### Prerequisites

No extra components are needed for testing `tr181-button`.

### Run tests

You can run the tests by executing the following command:

```bash
cd ~/workspace/core/plugins/tr181-button/test
make
```

Or this command if you also want the coverage tests to run:

```bash
cd ~/workspace/core/plugins/tr181-button/test
make run coverage
```

You can combine both commands:

```bash
cd ~/workspace/core/plugins/tr181-button
make test
```

### Coverage reports

The coverage target will generate coverage reports using
[gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and
[gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each c-file is printed in your console after the tests are run.
A HTML version of the coverage reports is also generated. These reports are
available in the output directory of the compiler used.  For example, when using
native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML
coverage reports can be found at
`~/workspace/core/plugins/tr181-button/output/x86_64-linux-gnu/coverage/report.`