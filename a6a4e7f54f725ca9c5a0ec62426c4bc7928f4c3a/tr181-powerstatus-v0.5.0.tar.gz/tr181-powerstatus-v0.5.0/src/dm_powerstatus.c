/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_transaction.h>

#include "tr181-powerstatus.h"
#include "dm_powerstatus.h"
#include "powersensor_info.h"

#define ME "dm-powerstatus"

static void dm_powersensor_update_status(amxd_object_t* obj, bool failure) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);

    when_null_trace(obj, exit, ERROR, "PowerSensor instance is NULL");

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, obj);

    if(amxd_object_get_value(bool, obj, "Enable", NULL)) {
        amxd_trans_set_value(cstring_t, &trans, "Status", failure ? "Error" :"Enabled");
        SAH_TRACE_INFO("PowerSensor[%s] change Status(%s)", amxd_object_get_name(obj, AMXD_OBJECT_NAMED), failure ? "Error" :"Enabled");
    } else {
        amxd_trans_set_value(cstring_t, &trans, "Status", "Disabled");
        SAH_TRACE_INFO("PowerSensor[%s] change Status(Disabled)", amxd_object_get_name(obj, AMXD_OBJECT_NAMED));
    }
    amxd_trans_apply(&trans, powerstatus_get_dm());

exit:
    amxd_trans_clean(&trans);
}

void _powersensor_changed(UNUSED const char* const sig_name,
                          const amxc_var_t* const event_data,
                          UNUSED void* const priv) {
    amxd_object_t* sensor = amxd_dm_signal_get_object(powerstatus_get_dm(), event_data);
    powersensor_info_t* info = NULL;
    bool error = true;

    when_null_trace(sensor, exit, ERROR, "Cannot retreive PowerSensor instance");
    info = (powersensor_info_t*) sensor->priv;
    when_null_trace(info, exit, ERROR, "Sensor info priv is NULL");
    when_failed_trace(powersensor_timer_update(info), exit, ERROR, "Cannot update polling timer");

    error = false;
exit:
    dm_powersensor_update_status(sensor, error);
    return;
}

void _powersensor_added(UNUSED const char* const sig_name,
                        const amxc_var_t* const event_data,
                        UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(powerstatus_get_dm(), event_data);
    amxd_object_t* sensor = amxd_object_get_instance(obj, NULL, GET_UINT32(event_data, "index"));
    powersensor_info_t* info = NULL;
    bool error = true;

    when_null_trace(sensor, exit, ERROR, "Cannot retreive PowerSensor instance");
    powersensor_info_create(sensor);
    info = (powersensor_info_t*) sensor->priv;
    when_null_trace(info, exit, ERROR, "Sensor info priv has not been allocated");
    when_failed_trace(powersensor_timer_update(info), exit, ERROR, "Cannot update polling timer");

    error = false;
exit:
    dm_powersensor_update_status(sensor, error);
    return;
}

amxd_status_t _powersensor_destroy(amxd_object_t* object,
                                   UNUSED amxd_param_t* param,
                                   amxd_action_t reason,
                                   UNUSED const amxc_var_t* const args,
                                   UNUSED amxc_var_t* const retval,
                                   UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    powersensor_info_t* info = NULL;

    when_false_trace(reason == action_object_destroy, exit, NOTICE, "Wrong reason, expected action_object_destroy(%d) got %d", action_object_destroy, reason);

    when_null_trace(object, exit, ERROR, "PowerSensor object is NULL");
    info = (powersensor_info_t*) object->priv;
    when_null_trace(info, exit, ERROR, "Sensor info priv has not been allocated");

    powersensor_info_clear(info);
    status = amxd_status_ok;
exit:
    return status;
}

void dm_powersensor_update_readings(amxd_object_t* obj, uint32_t power) {
    amxd_trans_t trans;
    amxc_ts_t time;
    bool reading_valid = false;

    amxd_trans_init(&trans);

    when_null_trace(obj, exit, ERROR, "PowerSensor object is NULL");

    reading_valid = power > 0;
    when_false_trace(reading_valid, exit, ERROR, "Power value is not valid");

    amxc_ts_now(&time);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, obj);
    amxd_trans_set_value(amxc_ts_t, &trans, "LastUpdate", &time);
    amxd_trans_set_value(int32_t, &trans, "Power", power);
    amxd_trans_apply(&trans, powerstatus_get_dm());

exit:
    dm_powersensor_update_status(obj, !reading_valid);
    amxd_trans_clean(&trans);
    return;
}