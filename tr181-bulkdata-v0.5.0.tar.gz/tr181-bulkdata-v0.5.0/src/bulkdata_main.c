/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "bulkdata.h"
#include "bulkdata_profile.h"
#include <filetransfer/filetransfer.h>

#define ME "bulkdata"

static bulkdata_app_t bulkdata;

static void bulkdata_synchronized_done(UNUSED const char* const sig_name,
                                       UNUSED const amxc_var_t* const data,
                                       UNUSED void* const priv) {
    const char* time_obj = "Time.";
    amxb_bus_ctx_t* ctx = amxb_be_who_has(time_obj);

    SAH_TRACEZ_INFO(ME, "Time sync done");
    bulkdata.synchronized = true;
    amxb_unsubscribe(ctx, time_obj, bulkdata_synchronized_done, NULL);

    if(bulkdata_get_enable()) {
        bulkdata_start_collection_profiles();
    }
}

static void bulkdata_setup_time_sync(void) {
    const char* status = NULL;
    const char* time_obj = "Time.";
    amxb_bus_ctx_t* ctx = amxb_be_who_has(time_obj);
    amxc_var_t ret;

    amxc_var_init(&ret);

    // It is possible that Status is already Synchronized, so use subscribe + get
    // Do subscribe before get, because otherwise you can theoretically miss the Status change
    amxb_subscribe(ctx, time_obj, "parameters.Status.to == 'Synchronized'",
                   bulkdata_synchronized_done, NULL);
    amxb_get(ctx, time_obj, 0, &ret, 5);

    status = GETP_CHAR(&ret, "0.0.Status");
    if((status != NULL) && (strcmp(status, "Synchronized") == 0)) {
        bulkdata.synchronized = true;
        amxb_unsubscribe(ctx, time_obj, bulkdata_synchronized_done, NULL);
    }

    amxc_var_clean(&ret);
}

static void bulkdata_filetransfer_event_cb(int fd, UNUSED void* priv) {
    ftx_fd_event_handler(fd);
}

static int bulkdata_filetransfer_fdset_cb(int fd, bool add) {
    int retval = -1;
    if(add) {
        retval = amxo_connection_add(bulkdata_get_parser(), fd, bulkdata_filetransfer_event_cb, NULL, AMXO_LISTEN, NULL);
    } else {
        retval = amxo_connection_remove(bulkdata_get_parser(), fd);
    }
    SAH_TRACEZ_INFO(ME, "%s connection fd %d %s", add ? "add" : "remove", fd, (retval == 0) ? "success" : "failure");
    return retval;
}

static int bulkdata_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    bool needs_time_sync = false;

    SAH_TRACEZ_INFO(ME, "TR181-BulkData start");
    bulkdata.dm = dm;
    bulkdata.parser = parser;

    if(parser != NULL) {
        needs_time_sync = GET_BOOL(&parser->config, "needs-time-sync");
    }
    if(needs_time_sync) {
        SAH_TRACEZ_INFO(ME, "Time sync needed");
        bulkdata_setup_time_sync();
    } else {
        SAH_TRACEZ_INFO(ME, "Time sync not needed");
        bulkdata.synchronized = true;
    }

    ftx_init(bulkdata_filetransfer_fdset_cb);

    return 0;
}

static int bulkdata_clean(void) {
    SAH_TRACEZ_INFO(ME, "TR181-BulkData stop");

    bulkdata.dm = NULL;
    bulkdata.parser = NULL;
    if(!bulkdata.synchronized) {
        const char* time_obj = "Time.";
        amxb_bus_ctx_t* ctx = amxb_be_who_has(time_obj);
        amxb_unsubscribe(ctx, time_obj, bulkdata_synchronized_done, NULL);
    }
    bulkdata.synchronized = false;
    ftx_clean();

    return 0;
}

amxd_dm_t* bulkdata_get_dm(void) {
    return bulkdata.dm;
}

amxo_parser_t* bulkdata_get_parser(void) {
    return bulkdata.parser;
}

bool bulkdata_get_sync(void) {
    return bulkdata.synchronized;
}

amxd_object_t* bulkdata_get_root_object(void) {
    const char* prefix = amxc_var_constcast(cstring_t, amxo_parser_get_config(bulkdata.parser, "prefix_"));
    amxc_string_t object_name;
    amxd_object_t* root_object = NULL;

    amxc_string_init(&object_name, 0);
    amxc_string_setf(&object_name, "%s", ROOT_OBJECT_NAME);

    if((prefix != NULL) && (*prefix != 0)) {
        amxc_string_prependf(&object_name, "%s", prefix);
    }
    root_object = amxd_dm_findf(bulkdata_get_dm(), "%s", amxc_string_get(&object_name, 0));
    amxc_string_clean(&object_name);
    return root_object;
}

bool bulkdata_get_enable(void) {
    return amxd_object_get_value(bool, bulkdata_get_root_object(), "Enable", NULL);
}

bool bulkdata_get_parameter_wild_card_supported(void) {
    return amxd_object_get_value(bool, bulkdata_get_root_object(), "ParameterWildCardSupported", NULL);
}

static amxd_trans_t* bulkdata_init_transaction(const char* obj_path) {
    amxd_trans_t* transaction;
    amxd_dm_t* dm = bulkdata_get_dm();
    amxd_object_t* bulkdata_obj = amxd_dm_findf(dm, "%s", obj_path);
    amxd_trans_new(&transaction);
    amxd_trans_set_attr(transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(transaction, bulkdata_obj);
    return transaction;
}

void bulkdata_set_status(bulkdata_status_e status) {
    const char* status_string = NULL;
    amxd_object_t* root = bulkdata_get_root_object();
    const char* object_name = amxd_object_get_name(root, AMXD_OBJECT_NAMED);
    amxd_trans_t* transaction = NULL;

    when_null(root, exit);
    when_str_empty(object_name, exit);

    switch(status) {
    case BULKDATA_DISABLED:
        status_string = "Disabled";
        break;
    case BULKDATA_ENABLED:
        status_string = "Enabled";
        break;
    case BULKDATA_ERROR:
        status_string = "Error";
        break;
    }

    transaction = bulkdata_init_transaction(object_name);
    amxd_trans_set_value(cstring_t, transaction, "Status", status_string);
    amxd_trans_apply(transaction, bulkdata_get_dm());

exit:
    amxd_trans_delete(&transaction);
}

int _bulkdata_main(int reason,
                   amxd_dm_t* dm,
                   amxo_parser_t* parser) {
    int rv = -1;
    SAH_TRACEZ_INFO(ME, "entry point %s, reason: %d", __func__, reason);

    switch(reason) {
    case AMXO_START:     // START
        rv = bulkdata_init(dm, parser);
        break;
    case AMXO_STOP:     // STOP
        rv = bulkdata_clean();
        break;
    }

    return rv;
}
