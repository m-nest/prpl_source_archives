MACHINE = $(shell $(CC) -dumpmachine)

SRCDIR = $(realpath ../../src)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR = $(realpath ../../include ../../include_priv ../include)
COMMON_SRC_DIR = ../common

HEADERS = $(wildcard $(INCDIR)/$(TARGET)/*.h)
SOURCES = $(wildcard $(SRCDIR)/*.c) $(wildcard $(COMMON_SRC_DIR)/*.c)

WRAP_FUNC=-Wl,--wrap=
MOCK_WRAP=  

CFLAGS += -Werror -Wall -Wextra -Wno-attributes\
          --std=gnu99 -g3 -Wmissing-declarations \
		  $(addprefix -I ,$(INCDIR)) -I$(OBJDIR)/.. -I../mocks -I../common \
		  -fkeep-inline-functions -fkeep-static-functions -Wno-format-nonliteral \
		  $(shell pkg-config --cflags cmocka) -pthread -DUNIT_TEST

LDFLAGS += -fkeep-inline-functions -fkeep-static-functions \
		   $(shell pkg-config --libs cmocka) \
		   -lamxc -lamxj -lamxp -lamxd -lamxo -lamxb -lamxa -lamxut \
		   -ldl -lpthread -lsahtrace -limtp -lfiletransfer

LDFLAGS += -g $(addprefix $(WRAP_FUNC),$(MOCK_WRAP))
LDFLAGS += -ldl $(shell pkg-config --libs zlib)
