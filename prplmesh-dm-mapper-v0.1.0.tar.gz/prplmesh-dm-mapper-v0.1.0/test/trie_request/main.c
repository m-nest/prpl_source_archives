/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_util.h>

#include <amxrt/amxrt.h>

#include "dmm.h"
#include "dmm_trie.h"
#include "dmm_trie_translator.h"

#define TEST_COMMON_FOLDER "../test/common"


static int setup(UNUSED void** state) {
    amxc_var_t* config = amxrt_get_config();
    assert_non_null(config);
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);

    amxc_var_t* hide_mapping = amxut_util_read_json_from_file(TEST_COMMON_FOLDER "/mapping/hide.json");
    assert_non_null(hide_mapping);
    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_HIDE, hide_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    amxc_var_t* rename_mapping = amxut_util_read_json_from_file(TEST_COMMON_FOLDER "/mapping/rename.json");
    assert_non_null(rename_mapping);
    assert_int_equal(amxc_var_set_key(config, DMM_OBJECTS_RENAME, rename_mapping, AMXC_VAR_FLAG_DEFAULT), 0);

    assert_int_equal(init_tree(), 0);
    assert_int_equal(parse_mapping(), 0);

    return 0;
}

static int teardown(UNUSED void** state) {
    clean_tree();
    amxc_var_clean(amxrt_get_config());

    return 0;
}

static void translate_only_root(UNUSED void** state) {
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.");
    assert_null(res.fwd_node);

    clean_translate_req_result(&res);
}

static void translate_simple_path_no_rename(UNUSED void** state) {
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Not.Re.Named.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Not.Re.Named.");
    assert_null(res.fwd_node);

    clean_translate_req_result(&res);
}

static void translate_simple_path_with_rename(UNUSED void** state) {
    // Single rename
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Baz.");
    assert_non_null(res.fwd_node);
    assert_non_null(amxc_htable_get(&res.fwd_node->nonterminals, "Nested"));

    clean_translate_req_result(&res);

    // Two renames
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.Object1.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Baz.Object.");
    assert_non_null(res.fwd_node);

    clean_translate_req_result(&res);

    // No rename in the middle
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.Nested.Object1.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Baz.Nested.Object.");
    assert_non_null(res.fwd_node);

    clean_translate_req_result(&res);

    // No rename for the last part, the node shall be NULL
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.Nested.Object1.Subobject.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Baz.Nested.Object.Subobject.");
    assert_null(res.fwd_node);

    clean_translate_req_result(&res);
}

static void reject_invalid_paths(UNUSED void** state) {
    // hidden name
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Hidden.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // hidden name, but is more nested
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz.Object.Nested.Hidden.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // original name
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // original name, but nested is renamed
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz.Object1.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // original name, which is more nested
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.Object.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // original name, but is even more nested
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz1.Nested.Object.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    // original name, with non-renamed object
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Baz.Nested.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);
}

void translate_table_no_expression(UNUSED void** state) {
    // Table only
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    // With inst
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.1.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.1.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.alias.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.alias.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.*.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.*.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    // Subobject, renamed
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.1.Object1.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.1.Object.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.alias.Object1.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.alias.Object.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.*.Object1.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.*.Object.");
    assert_non_null(res.fwd_node);
    clean_translate_req_result(&res);

    // Subobject, not renamed
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.1.Not.Re.Named.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.1.Not.Re.Named.");
    assert_null(res.fwd_node);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.alias.Not.Re.Named.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.alias.Not.Re.Named.");
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.*.Not.Re.Named.");
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Table.*.Not.Re.Named.");
    assert_null(res.fwd_node);
    clean_translate_req_result(&res);

    // Original name --- invalid
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.1.Object.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.alias.Object.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);

    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Table1.*.Object.");
    assert_int_equal(res.status, amxd_status_object_not_found);
    clean_translate_req_result(&res);
}

void can_rename_or_check_hidden_parameter(UNUSED void** state) {
    // Check that we'll be able to rename parameters
    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Quux.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Quux.");
    assert_non_null(res.fwd_node);
    assert_non_null(res.bwd_node);
    assert_non_null(amxc_htable_get(&res.fwd_node->terminals, "Parameter1"));
    assert_non_null(amxc_htable_get(&res.bwd_node->terminals, "Parameter"));
    assert_non_null(amxc_htable_get(&res.bwd_node->terminals, "Hidden"));

    clean_translate_req_result(&res);

    // Same, but with table
    res = translate_nonterminal_request_path(&forward_tree, &backward_tree, "WiFiMapped.Quux.*.Object.");

    assert_int_equal(res.status, amxd_status_ok);
    assert_string_equal(amxc_string_get(&res.translated, 0), "WiFiMapped.Quux.*.Object.");
    assert_non_null(res.fwd_node);
    assert_non_null(res.bwd_node);
    assert_non_null(amxc_htable_get(&res.fwd_node->terminals, "Parameter1"));
    assert_non_null(amxc_htable_get(&res.bwd_node->terminals, "Parameter"));
    assert_non_null(amxc_htable_get(&res.bwd_node->terminals, "Hidden"));

    clean_translate_req_result(&res);
}

void translate_table_with_expression(UNUSED void** state) {
    TranslateReqResult res;
#define TRANSLATE_CHECK_STRING(path, expected) do { \
        res = translate_nonterminal_request_path(&forward_tree, &backward_tree, path); \
        assert_string_equal(amxc_string_get(&res.translated, 0), expected); \
        clean_translate_req_result(&res); \
} while (0)

    // no renamings inside/after the expression
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"value\"].", "WiFiMapped.Table.[Param==\"value\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"value\"].Not.Re.Named.", "WiFiMapped.Table.[Param==\"value\"].Not.Re.Named.");
    // rename past the expression
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"value\"].Object1.", "WiFiMapped.Table.[Param==\"value\"].Object.");
    // rename inside the expression
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Object1.Param==\"value\"].", "WiFiMapped.Table.[Object.Param==\"value\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Object1.Param==\"value\"].Not.Re.Named.", "WiFiMapped.Table.[Object.Param==\"value\"].Not.Re.Named.");
    // rename inside and past the expression
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Object1.Param==\"value\"].Object1.", "WiFiMapped.Table.[Object.Param==\"value\"].Object.");
    // translate reffollow as-is
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Ref+.Param == \"value\"].", "WiFiMapped.Table.[Ref+.Param == \"value\"].");

    // multiple exprcomps
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Param1==\"value\" && Param2==42].",
        "WiFiMapped.Table.[Param1==\"value\" && Param2==42]."
        );
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Object1.Param1==\"value\" && Object1.Param2==42].",
        "WiFiMapped.Table.[Object.Param1==\"value\" && Object.Param2==42]."
        );

    // strings with fancy stuff
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==''].", "WiFiMapped.Table.[Param==''].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"\"].", "WiFiMapped.Table.[Param==\"\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param=='\"'].", "WiFiMapped.Table.[Param=='\"'].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param=='\\''].", "WiFiMapped.Table.[Param=='\\''].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"\\\"\"].", "WiFiMapped.Table.[Param==\"\\\"\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"va]lue\"].", "WiFiMapped.Table.[Param==\"va]lue\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"value]\"].", "WiFiMapped.Table.[Param==\"value]\"].");
    TRANSLATE_CHECK_STRING("WiFiMapped.Table1.[Param==\"va&&lue]\"].", "WiFiMapped.Table.[Param==\"va&&lue]\"].");
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Param1==\"va&&lue\" && Param2==42].",
        "WiFiMapped.Table.[Param1==\"va&&lue\" && Param2==42]."
        );
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Param1==-42 && Param2=='va&&lue'].",
        "WiFiMapped.Table.[Param1==-42 && Param2=='va&&lue']."
        );
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Param1==\"va\\\"lue]\" && Param2=='va\"lue'].",
        "WiFiMapped.Table.[Param1==\"va\\\"lue]\" && Param2=='va\"lue']."
        );
    TRANSLATE_CHECK_STRING(
        "WiFiMapped.Table1.[Param == unquoted].",
        "WiFiMapped.Table.[Param == unquoted]."
        );

#undef TRANSLATE_CHECK_STRING

    // catch hidden/original names
#define TRANSLATE_CHECK_ERROR(path, error) do { \
        res = translate_nonterminal_request_path(&forward_tree, &backward_tree, path); \
        assert_int_equal(res.status, error); \
        clean_translate_req_result(&res); \
} while (0)

    TRANSLATE_CHECK_ERROR("WiFiMapped.Table1.[Object.Param==\"value\"].", amxd_status_object_not_found);
    TRANSLATE_CHECK_ERROR("WiFiMapped.Table1.[Object1.Param==\"value\"].Object.", amxd_status_object_not_found);
    TRANSLATE_CHECK_ERROR("WiFiMapped.Quux.[Parameter!=0].", amxd_status_parameter_not_found);
    TRANSLATE_CHECK_ERROR("WiFiMapped.Quux.[Object.Parameter!=0].", amxd_status_parameter_not_found);
    TRANSLATE_CHECK_ERROR("WiFiMapped.Quux.[Hidden!=0].", amxd_status_parameter_not_found);
    TRANSLATE_CHECK_ERROR("WiFiMapped.Quux.[HiddenObject.Parameter!=0].", amxd_status_object_not_found);

#undef TRANSLATE_CHECK_ERROR
}

int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(translate_only_root),
        cmocka_unit_test(translate_simple_path_no_rename),
        cmocka_unit_test(translate_simple_path_with_rename),
        cmocka_unit_test(reject_invalid_paths),
        cmocka_unit_test(translate_table_no_expression),
        cmocka_unit_test(can_rename_or_check_hidden_parameter),
        cmocka_unit_test(translate_table_with_expression),
    };

    return cmocka_run_group_tests(tests, setup, teardown);
}
