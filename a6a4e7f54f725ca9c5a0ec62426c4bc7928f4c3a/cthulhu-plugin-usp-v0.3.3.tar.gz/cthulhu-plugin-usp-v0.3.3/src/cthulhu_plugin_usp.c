/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE 1 // to make strdup work

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>
#include <amxc/amxc_macros.h>
#include <amxb/amxb_be_intf.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_helpers.h>
#include <cthulhu/cthulhu_error.h>
#include <lcm/lcm_assert.h>
#include <debug/sahtrace.h>
#include <libocispec/image_spec_schema_image_manifest_schema.h>
#include <lcm/amxc_data.h>
#include <uuid/uuid.h>
#include <lcm/lcm_remote_object.h>

#include "cthulhu_plugin_usp.h"

#define ME "plugin_usp"

#define LOCALAGENT "LocalAgent"
#define LOCALAGENT_DM TR_DEVICE "." LOCALAGENT "."
#define LOCALAGENT_CONTROLLER "Controller"
#define LOCALAGENT_CONTROLLER_DM TR_DEVICE "." LOCALAGENT "." LOCALAGENT_CONTROLLER "."
#define LOCALAGENT_MTP "MTP"
#define LOCALAGENT_UDS "UDS"
#define LOCALAGENT_UDSREF "UnixDomainSocketRef"
#define LOCALAGENT_MTP_FILTER "[Protocol==\"UDS\"]"
#define LOCALAGENT_MTP_UDS_FILTER_DM TR_DEVICE "." LOCALAGENT "." LOCALAGENT_MTP "." LOCALAGENT_MTP_FILTER "." LOCALAGENT_UDS "." LOCALAGENT_UDSREF
#define USPCONFIG "USPConfig"
#define USPCONFIG_ENABLEPROTECTEDACCESS "EnableProtectedAccess"
#define USPCONFIG_DEFAULTCONTROLLERTRUSTROLE "DefaultControllerTrustRole"
#define GET_TIMEOUT 10

#define ENVVAR_ENDPOINTID "USP_ENDPOINT_ID"
#define ENDPOINTID_FORMAT "uuid::%s"

#define CONTROLLER_TRUST "ControllerTrust"
#define ROLE "Role"
#define ROLE_DM TR_DEVICE "." LOCALAGENT "." CONTROLLER_TRUST "." ROLE "."
#define MTP "MTP"
#define MTP_DM TR_DEVICE "." LOCALAGENT "." MTP "."
#define ROLE_NAME "Name"
#define ROLE_PATH_LEN ( sizeof(ROLE_DM) + sizeof("9999") + 1 )
#define ROLE_NAME_LEN ( 256 + 1 )

#define ALIAS_SIZE 512
#define CONTROLLER_ALIAS_FMT "controller-%s"
#define CONTROLLER_MTP_FMT LOCALAGENT_CONTROLLER_DM "[Alias==\"%s\"]." LOCALAGENT_MTP
#define CONTROLLER_INSTANCE_FMT LOCALAGENT_CONTROLLER_DM "[Alias==\""CONTROLLER_ALIAS_FMT "\"]."


#define ENDPOINTID_SIZE 1024
#define MTP_PATH_SIZE 1024
#define UUIDV4_SIZE 37 // 36 characters for UUIDv4 + null terminator

#define BROKER_CONTROLLER_PATH_ON_HOST "/var/run/usp/broker_controller_path"
#define BROKER_CONTROLLER_PATH_IN_CTR "/run/usp/broker_controller_path"
#define BROKER_AGENT_PATH_IN_CTR "/run/usp/broker_agent_path"

#define AMXB_WAIT_DONE "wait:done"
#define AMXB_APP_START "app:start"
#define AMXB_APP_STOP "app:stop"
#define AMXB_NOTIF_PATH "path"
#define AMXB_NOTIF_INDEX "index"

typedef struct usp_role_entry {
    amxc_llist_it_t it;
    uint32_t index;
    char role_path[ROLE_PATH_LEN];
    char role_name[ROLE_NAME_LEN];
} usp_role_entry_t;

static amxm_shared_object_t* so = NULL;
static amxm_module_t* mod = NULL;

static amxd_dm_t* dm = NULL;
static amxb_bus_ctx_t* amxb_bus_ctx_la = NULL;
static amxc_llist_t cached_usp_role_list;
bool invalid_ctx = false;

static int usp_localagent_controllertrust_probe(void);
static void usp_localagent_unsubscribe(bool all);
static amxb_bus_ctx_t* get_localagent_busctx(void);

static inline int remove_slot(const char* sig_name, amxp_slot_fn_t fn) {
    return amxp_slot_disconnect(NULL, sig_name, fn);
}

static inline int add_slot(const char* const signal_name,
                           const char* const expression,
                           amxp_slot_fn_t fn,
                           void* const priv) {
    return amxp_slot_connect(NULL, signal_name, expression, fn, priv);
}

static void set_localagent_busctx(amxb_bus_ctx_t* ctx) {
    amxb_bus_ctx_la = ctx;
}

static void connection_deleted_callback(UNUSED const char* const sig_name,
                                        UNUSED const amxc_var_t* const data,
                                        UNUSED void* priv) {
    if(amxc_var_type_of(data) != AMXC_VAR_ID_FD) {
        return;
    }

    amxb_bus_ctx_t* ctx = get_localagent_busctx();
    if(ctx && (amxb_get_fd(ctx) == amxc_var_dyncast(fd_t, data))) {
        SAH_TRACEZ_WARNING(ME, "Connection to bus implementnig %s lost (ctx = %p)", LOCALAGENT_DM, ctx);
        invalid_ctx = true;
        set_localagent_busctx(NULL);
    }
}

static amxb_bus_ctx_t* get_localagent_busctx(void) {
    amxb_bus_ctx_t* ret = amxb_bus_ctx_la;
    if((ret == NULL) && (invalid_ctx == false)) {
        ret = amxb_be_who_has_ex(LOCALAGENT_DM, true);
        set_localagent_busctx(ret);
        amxp_slot_connect(NULL, "connection-deleted", NULL, connection_deleted_callback, NULL);
    }
    return ret;
}

static inline amxd_object_t* usp_sb_get(const char* const sb_id) {
    return amxd_dm_findf(dm, CTHULHU_DM_SANDBOX_INSTANCES ".[" CTHULHU_SANDBOX_ID "==\"%s\"].", sb_id);
}

/**
 * @brief Get all sandboxes from the datamodel
 *
 * @return amxd_object_t amxd pointer to sandbox instances
 */
static inline amxd_object_t* usp_sbs_get(void) {
    return amxd_dm_findf(dm, CTHULHU_DM_SANDBOX_INSTANCES ".");
}

static inline amxd_object_t* usp_ctr_get(const char* const ctr_id) {
    return amxd_dm_findf(dm, CTHULHU_DM_CONTAINER_INSTANCES ".[" CTHULHU_CONTAINER_ID "==\"%s\"].", ctr_id);
}

static inline amxd_object_t* usp_ctrs_get(void) {
    return amxd_dm_findf(dm, CTHULHU_DM_CONTAINER_INSTANCES ".");
}

static amxd_object_t* usp_sb_get_from_ctr(amxd_object_t* ctr) {
    amxd_object_t* sb_obj = NULL;
    char* sb_id = NULL;

    ASSERT_NOT_NULL(ctr, goto exit);

    sb_id = amxd_object_get_cstring_t(ctr, CTHULHU_CONTAINER_SANDBOX, NULL);
    ASSERT_STR_NOT_EMPTY(sb_id, goto exit);

    sb_obj = usp_sb_get(sb_id);
    ASSERT_NOT_NULL(sb_obj, goto exit);

exit:
    free(sb_id);
    return sb_obj;
}

static inline int initialize_cached_role_list(void) {
    return amxc_llist_init(&cached_usp_role_list);
}

static inline void free_role_entry(usp_role_entry_t* role) {
    free(role);
}

static void delete_role_entry(amxc_llist_it_t* it) {
    usp_role_entry_t* role = amxc_container_of(it, usp_role_entry_t, it);
    free_role_entry(role);
}

static inline void clean_cached_role_list(void) {
    amxc_llist_clean(&cached_usp_role_list, delete_role_entry);
}

static inline usp_role_entry_t* find_usp_role_entry_by_name(const char* usp_role_name) {
    usp_role_entry_t* ret = NULL;
    ASSERT_NOT_NULL_NL(usp_role_name, goto exit);

    amxc_llist_for_each(it, (&cached_usp_role_list)) {
        ret = amxc_llist_it_get_data(it, usp_role_entry_t, it);
        if(strncmp(ret->role_name, usp_role_name, ROLE_NAME_LEN) == 0) {
            break;
        }
        ret = NULL;
    }

exit:
    return ret;
}

/**
 * @brief Find a role entry in the cached list by index
 *
 * @return usp_role_entry_t reference to the entry with the index
 */
static inline usp_role_entry_t* find_usp_role_entry_by_index(uint32_t index) {
    usp_role_entry_t* ret = NULL;

    amxc_llist_for_each(it, (&cached_usp_role_list)) {
        ret = amxc_llist_it_get_data(it, usp_role_entry_t, it);
        if(ret->index == index) {
            break;
        }
        ret = NULL;
    }

    return ret;
}

static inline usp_role_entry_t* find_usp_role_entry_by_path(const char* usp_role_path) {
    usp_role_entry_t* ret = NULL;
    ASSERT_NOT_NULL_NL(usp_role_path, goto exit);

    amxc_llist_for_each(it, (&cached_usp_role_list)) {
        ret = amxc_llist_it_get_data(it, usp_role_entry_t, it);
        if(strncmp(ret->role_path, usp_role_path, ROLE_PATH_LEN) == 0) {
            break;
        }
        ret = NULL;
    }

exit:
    return ret;
}

/**
 * @brief Remove a role path from all sandboxes in the datamodel
 * The role name is also a parameter in the cthulhu sandbox
 * datamodel and will be removed as well
 * @param role_entry reference to the removed role
 */
static void remove_path_from_available_roles_in_all_sbs(usp_role_entry_t* role_entry) {
    amxd_object_t* sbs = NULL;

    ASSERT_NOT_NULL(role_entry, return );
    ASSERT_STR_NOT_EMPTY(role_entry->role_name, return );
    ASSERT_STR_NOT_EMPTY(role_entry->role_path, return );

    sbs = usp_sbs_get();
    ASSERT_NOT_NULL(sbs, return );
    amxd_object_for_each(instance, it, sbs) {
        amxc_var_t params_sb;
        amxc_var_t* availablerolesnamelist = NULL;
        amxc_var_t* availableroleslist = NULL;
        bool modified = false;
        amxd_object_t* sb_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_init(&params_sb);
        amxd_object_get_params(sb_instance, &params_sb, amxd_dm_access_public);

        if(!STRING_EMPTY(GET_CHAR(&params_sb, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES))) {
            availablerolesnamelist = GET_ARG(&params_sb, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES);
            amxc_var_cast(availablerolesnamelist, AMXC_VAR_ID_LIST);
            amxc_var_for_each(entry, availablerolesnamelist) {
                const char* available_role_name = amxc_var_constcast(cstring_t, entry);
                ASSERT_STR_NOT_EMPTY(available_role_name, continue);
                if(strncmp(role_entry->role_name, available_role_name, ROLE_NAME_LEN) == 0) {
                    amxc_var_delete(&entry);
                    modified = true;
                }
            }
        }

        if(!STRING_EMPTY(GET_CHAR(&params_sb, CTHULHU_SANDBOX_AVAILABLE_ROLES))) {
            availableroleslist = GET_ARG(&params_sb, CTHULHU_SANDBOX_AVAILABLE_ROLES);
            amxc_var_cast(availableroleslist, AMXC_VAR_ID_LIST);
            amxc_var_for_each(entry, availableroleslist) {
                const char* available_role_path = amxc_var_constcast(cstring_t, entry);
                ASSERT_STR_NOT_EMPTY(available_role_path, continue);
                if(strncmp(role_entry->role_path, available_role_path, ROLE_PATH_LEN) == 0) {
                    amxc_var_delete(&entry);
                    modified = true;
                }
            }
        }

        if(modified) {
            amxd_status_t status;
            amxd_trans_t trans;
            amxd_trans_init(&trans);
            amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
            amxd_trans_select_object(&trans, sb_instance);

            amxc_var_cast(availablerolesnamelist, AMXC_VAR_ID_CSV_STRING);
            amxc_var_cast(availableroleslist, AMXC_VAR_ID_CSV_STRING);

            amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES, amxc_var_constcast(cstring_t, availablerolesnamelist));
            amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES, amxc_var_constcast(cstring_t, availableroleslist));

            status = amxd_trans_apply(&trans, dm);
            if(status != amxd_status_ok) {
                SAH_TRACEZ_ERROR(ME,
                                 "Transaction failed. Could not remove (%s:%s) from " CTHULHU_SANDBOX_AVAILABLE_ROLES " & " CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES " not Updated in Sandbox (%s). Status: %d",
                                 role_entry->role_name, role_entry->role_path, GET_CHAR(&params_sb, CTHULHU_SANDBOX_ID), status);
            }
            amxd_trans_clean(&trans);
        }

        amxc_var_delete(&availablerolesnamelist);
        amxc_var_delete(&availableroleslist);
        amxc_var_clean(&params_sb);
    }

    return;
}

static int find_path_in_available_roles(const char* role_path, amxc_var_t* available_roles) {
    int ret = -1;

    ASSERT_NOT_NULL(available_roles, goto exit);
    ASSERT_NOT_NULL(role_path, goto exit);

    ret = 0;
    amxc_var_for_each(available_role_entry, available_roles) {
        const char* role_path_entry = amxc_var_constcast(cstring_t, available_role_entry);
        if(STRING_EMPTY(role_path_entry)) {
            continue;
        }

        if(strncmp(role_path_entry, role_path, ROLE_PATH_LEN) == 0) {
            ret = 1;
            break;
        }
    }

exit:
    return ret;
}

static int usp_convert_rolenames_to_paths(amxc_string_t* output, amxc_var_t* roles, amxc_var_t* available_roles) {
    int ret = -1;

    ASSERT_NOT_NULL(output, goto exit);
    ASSERT_NOT_NULL(roles, goto exit);

    ret = 0;

    amxc_var_for_each(roleentry, roles) {
        const char* role_name_entry = amxc_var_constcast(cstring_t, roleentry);
        if(role_name_entry == NULL) {
            continue;
        }

        usp_role_entry_t* entry_in_list = find_usp_role_entry_by_name(role_name_entry);
        if(entry_in_list == NULL) {
            SAH_TRACEZ_ERROR(ME, "Cannot find role '%s' in the cached list to resolve to a path", role_name_entry);
            continue;
        }

        if(available_roles) {
            if(find_path_in_available_roles(entry_in_list->role_path, available_roles) == 0) {
                SAH_TRACEZ_WARNING(ME, "Cannot find role '%s' (%s) in available roles of the sb", role_name_entry, entry_in_list->role_path);
                continue;
            }
        }

        if(!amxc_string_is_empty(output)) {
            amxc_string_append(output, ",", 1);
        }
        amxc_string_appendf(output, "%s", entry_in_list->role_path);
        ret++;
    }

exit:
    return ret;
}

static int usp_localagent_controller_rm(const char* ctr_id) {
    int ret = -1;
    char controller[MTP_PATH_SIZE] = {0};
    amxc_var_t retvar;

    amxb_bus_ctx_t* bus_ctx_la = get_localagent_busctx();
    ASSERT_NOT_NULL(bus_ctx_la, return ret, "Cannot get ctx on " LOCALAGENT_CONTROLLER_DM);

    if(snprintf(controller, sizeof(controller), CONTROLLER_INSTANCE_FMT, ctr_id) < 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot generate correct controller instance");
        goto exit;
    }

    amxc_var_init(&retvar);
    ret = amxb_get(bus_ctx_la, controller, 0, &retvar, GET_TIMEOUT);
    CHECK_NOT_EQUAL_LOG(INFO, ret, amxd_status_ok, goto exit, "No assigned controller to CTR [%s].", ctr_id);

    SAH_TRACEZ_INFO(ME, "Removing controller %s", controller);

    amxc_var_clean(&retvar);
    amxc_var_init(&retvar);

    ret = amxb_del(bus_ctx_la, controller, 0, NULL, &retvar, 18);
    ASSERT_EQUAL(ret, amxd_status_ok, goto exit, "Cannot remove controller %s", controller);


exit:
    amxc_var_clean(&retvar);
    return ret;
}

static int usp_uds_share(cthulhu_ctr_start_data_t* start_data, const char* ctr_id) {
    int ret = -1;
    amxc_var_t values;
    amxc_var_t retvar;
    amxc_var_t mtp_info;
    amxc_string_t uri;
    const char* endpointid = NULL;
    char controller[MTP_PATH_SIZE] = {0};

    amxc_var_init(&values);
    amxc_var_init(&retvar);
    amxc_var_init(&mtp_info);
    amxc_string_init(&uri, 0);

    amxb_bus_ctx_t* bus_ctx_la = get_localagent_busctx();
    ASSERT_NOT_NULL(bus_ctx_la, return ret, "Cannot get ctx on " LOCALAGENT_CONTROLLER_DM);

    ret = amxb_get(bus_ctx_la, LOCALAGENT_MTP_UDS_FILTER_DM, 0, &mtp_info, GET_TIMEOUT);
    if(ret != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "Cannot add instance to " LOCALAGENT_MTP_UDS_FILTER_DM);
        goto exit;
    }

    const char* socket_ref = GETP_CHAR(&mtp_info, "0.0.UnixDomainSocketRef");
    if((socket_ref == NULL) || (*socket_ref == 0)) {
        SAH_TRACEZ_ERROR(ME, "UnixDomainSocketRef is empty");
        goto exit;
    }

    amxc_string_setf(&uri, "%s.Path", socket_ref);
    ret = amxb_get(bus_ctx_la, amxc_string_get(&uri, 0), 0, &mtp_info, 5);
    if(ret != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to get %s", amxc_string_get(&uri, 0));
        goto exit;
    }

    const char* socket_path = GETP_CHAR(&mtp_info, "0.0.Path");
    if((socket_path == NULL) || (*socket_path == 0)) {
        SAH_TRACEZ_ERROR(ME, "UnixDomainSocket Path is empty");
        goto exit;
    }

    ret = cthulhu_issocket(socket_path);
    if(!ret) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: UDS MTP socket not found [%s]", ctr_id, socket_path);
        goto exit;
    }

    SAH_TRACEZ_NOTICE(ME, "Trying to add UDP MTP sockets: %s and " BROKER_CONTROLLER_PATH_ON_HOST " to the mount table", socket_path);

    // Mount destination is hardcoded as it is required on a specific path in container side. To be improved.
    ret = cthulhu_ctr_start_data_add_mount_data(start_data, socket_path, BROKER_AGENT_PATH_IN_CTR, NULL, NULL);
    if(ret < 0) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: Could not configure socket mount", ctr_id);
        goto exit;
    }

    // The UDS implementation depends on two sockets, one for the broker and another for the controller.
    // The datamodel only models the agent socket (retrieved above) due to a limitation imposed by BBF.
    // We are explicitly setting the controller socket here.
    ret = cthulhu_ctr_start_data_add_mount_data(start_data, BROKER_CONTROLLER_PATH_ON_HOST, BROKER_CONTROLLER_PATH_IN_CTR, NULL, NULL);
    if(ret < 0) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: Could not configure socket mount", ctr_id);
        goto exit;
    }

    ASSERT_TRUE(snprintf(controller, sizeof(controller), CONTROLLER_INSTANCE_FMT, ctr_id) > 0, goto exit,
                "Cannot generate correct controller instance");

    ret = amxb_get(bus_ctx_la, controller, 0, &retvar, GET_TIMEOUT);
    ASSERT_EQUAL(ret, amxd_status_ok, goto exit, "No assigned controller to CTR [%s]. Cannot pass it to container", ctr_id);

    // Read the EndpointID that was previously configured
    endpointid = GETP_CHAR(&retvar, "0.0.EndpointID");
    ASSERT_STR_NOT_EMPTY(endpointid, goto exit, "EndpointID is empty for CTR [%s]! Cannot be configured", ctr_id);
    // Share the EndpointID that must be used by the container as EnvVar
    ASSERT_SUCCESS(cthulhu_ctr_start_data_add_envvar_data(start_data, ENVVAR_ENDPOINTID, endpointid),
                   goto exit, "Failed to set container USP EndpointID");

exit:
    amxc_string_clean(&uri);
    amxc_var_clean(&mtp_info);
    amxc_var_clean(&retvar);
    amxc_var_clean(&values);

    return ret;
}

static int usp_localagent_add_mtp(amxb_bus_ctx_t* amxb_bus_ctx, const char* alias, const char* ctr_id) {
    int ret = -1;
    amxc_var_t values;
    amxc_var_t retvar;
    char path[MTP_PATH_SIZE] = {0};

    if(snprintf(path, sizeof(path), CONTROLLER_MTP_FMT, alias) < 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot generate MTP path for %s", alias);
        return ret;
    }
    amxc_var_init(&values);
    amxc_var_init(&retvar);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, "Enable", true);
    amxc_var_add_key(cstring_t, &values, "Protocol", "UDS");

    ret = amxb_add(amxb_bus_ctx, path, 0, "mtp-uds", &values, &retvar, 0);
    if(ret != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "Cannot add instance to %s for %s", path, ctr_id);
    }

    amxc_var_clean(&retvar);
    amxc_var_clean(&values);

    return ret;
}

static int usp_localagent_controller_add(const char* ctr_id, amxc_var_t* requiredroles, amxc_var_t* optionalroles) {
    int ret = -1;
    amxc_var_t values;
    amxc_var_t retvar;
    amxc_var_t params_sb_dm;
    amxc_var_t* available_roles = NULL;
    amxd_trans_t trans;
    amxd_status_t status;

    char alias[ALIAS_SIZE] = {};
    char endpointid[ENDPOINTID_SIZE] = {};
    amxc_string_t assigned_roles;
    char uuid_str[UUIDV4_SIZE] = {0};
    uuid_t uuid;

    amxb_bus_ctx_t* bus_ctx_la = get_localagent_busctx();
    if(bus_ctx_la == NULL) {
        SAH_TRACEZ_ERROR(ME, "Cannot get ctx on " LOCALAGENT_CONTROLLER_DM);
        goto exit;
    }

    amxd_object_t* ctr_obj = usp_ctr_get(ctr_id);
    amxd_object_t* sb_obj = usp_sb_get_from_ctr(ctr_obj);
    if(sb_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Cannot get container sandbox to match available_roles, assuming none are allowed");
        goto exit;
    }

    amxc_string_init(&assigned_roles, 256);
    amxc_var_init(&values);
    amxc_var_init(&retvar);
    amxc_var_init(&params_sb_dm);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, ctr_obj);

    if(snprintf(alias, sizeof(alias), CONTROLLER_ALIAS_FMT, ctr_id) < 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot generate correct alias");
        goto exitclean;
    }

    amxd_object_get_params(sb_obj, &params_sb_dm, amxd_dm_access_public);
    available_roles = GET_ARG(&params_sb_dm, CTHULHU_SANDBOX_AVAILABLE_ROLES);
    if(available_roles) {
        amxc_var_cast(available_roles, AMXC_VAR_ID_LIST);
        // validated should have flagged an error on the available roles,
        // so we assume they are correct for required
        usp_convert_rolenames_to_paths(&assigned_roles, requiredroles, NULL);
        // optional roles can be filtered by available roles, so we'll do just that
        usp_convert_rolenames_to_paths(&assigned_roles, optionalroles, available_roles);
    } else {
        SAH_TRACEZ_WARNING(ME, "No " CTHULHU_SANDBOX_AVAILABLE_ROLES " so assuming none are allowed");
    }

    amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_ASSIGNED_ROLES, amxc_string_get(&assigned_roles, 0));
    status = amxd_trans_apply(&trans, dm);
    amxd_trans_clean(&trans);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed. " CTHULHU_CONTAINER_ASSIGNED_ROLES " not added to DM. Status: %d", status);
    }

    if(amxc_string_is_empty(&assigned_roles)) {
        SAH_TRACEZ_ERROR(ME, "No assigned roles apparently so not creating the controller");
        goto exitclean;
    }

    amxc_var_add_key(csv_string_t, &values, "AssignedRole", amxc_string_get(&assigned_roles, 0));
    amxc_var_add_key(cstring_t, &values, "Alias", alias);
    amxc_var_add_key(bool, &values, "Enable", true);

    // Generate a random UUID (UUID4) to use as part of the EndpointID
    uuid_generate_random(uuid);
    uuid_unparse(uuid, uuid_str);
    ASSERT_TRUE(snprintf(endpointid, sizeof(endpointid), ENDPOINTID_FORMAT, uuid_str) > 0,
                goto exitclean, "Failed to generate container USP EndpointID");
    amxc_var_add_key(cstring_t, &values, "EndpointID", endpointid);

    SAH_TRACEZ_NOTICE(ME, "Trying to add controller '%s' ( for ctr: '%s' ) to '" LOCALAGENT_CONTROLLER_DM "'", alias, ctr_id);
    ret = amxb_add(bus_ctx_la, LOCALAGENT_CONTROLLER_DM, 0, alias, &values, &retvar, 0);
    if(ret) {
        SAH_TRACEZ_ERROR(ME, "Cannot add instance to " LOCALAGENT_CONTROLLER_DM " for %s", ctr_id);
        goto exitclean;
    }

    ret = usp_localagent_add_mtp(bus_ctx_la, alias, ctr_id);

exitclean:
    amxc_string_clean(&assigned_roles);
    amxc_var_clean(&retvar);
    amxc_var_clean(&values);
    amxc_var_clean(&params_sb_dm);
exit:
    return ret;
}

static int usp_sb_create(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = -1;
    amxd_trans_t trans;
    amxd_status_t status;

    const char* sb_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_SB_ID);
    ASSERT_NOT_NULL(sb_id, goto exit);

    amxd_object_t* sb_obj = usp_sb_get(sb_id);
    ASSERT_NOT_NULL(sb_obj, goto exit);

    amxc_var_t* var_data = GET_ARG(args, CTHULHU_PLUGIN_ARG_CREATE_DATA);
    if(var_data == NULL) {
        SAH_TRACEZ_INFO(ME, "CTHULHU_PLUGIN_ARG_CREATE_DATA is not supplied, assuming this is for the private sandbox creation, so ignoring the error");
        res = 0;
        goto exit;
    }

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, sb_obj);

    amxc_var_t* varavailableroles = GET_ARG(var_data, CTHULHU_SANDBOX_AVAILABLE_ROLES);
    if(varavailableroles) {
        const char* charavailableroles = amxc_var_constcast(cstring_t, varavailableroles);
        amxc_string_t available_roles;
        amxc_var_t copiedvaravailableroles;

        amxc_string_init(&available_roles, 256);
        amxc_var_init(&copiedvaravailableroles);


        amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES, charavailableroles);

        amxc_var_copy(&copiedvaravailableroles, varavailableroles);
        amxc_var_cast(&copiedvaravailableroles, AMXC_VAR_ID_LIST);
        usp_convert_rolenames_to_paths(&available_roles, &copiedvaravailableroles, NULL);

        amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES, amxc_string_get(&available_roles, 0));

        amxc_string_clean(&available_roles);
        amxc_var_clean(&copiedvaravailableroles);
    } else {
        SAH_TRACEZ_WARNING(ME, "No " CTHULHU_SANDBOX_AVAILABLE_ROLES " supplied, setting empty list");
        amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES, "");
        amxd_trans_set_csv_string_t(&trans, CTHULHU_SANDBOX_AVAILABLE_ROLES, "");
    }

    status = amxd_trans_apply(&trans, dm);
    amxd_trans_clean(&trans);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed. " CTHULHU_SANDBOX_AVAILABLE_ROLES " & " CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES " not added to DM. Status: %d", status);
        goto exit;
    }

    res = 0;

exit:
    amxc_var_set(int32_t, ret, res);
    return res;
}

static int usp_ctr_create(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int res = -1;
    amxd_trans_t trans;
    amxd_status_t status = amxd_status_unknown_error;
    const char* required = NULL;
    const char* optional = NULL;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    amxc_var_t* var_data = NULL;

    var_data = GET_ARG(args, CTHULHU_PLUGIN_ARG_CREATE_DATA);
    ASSERT_NOT_NULL(var_data, goto exit);

    required = GET_CHAR(var_data, CTHULHU_CONTAINER_REQUIRED_ROLES);
    optional = GET_CHAR(var_data, CTHULHU_CONTAINER_OPTIONAL_ROLES);

    // Required/Optional not defined. No change to previous config.
    if((required == NULL) && (optional == NULL)) {
        res = 0;
        amxc_var_set(int32_t, ret, res);
        return res;
    }

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_NOT_NULL(ctr_id, goto exit);

    ctr_obj = usp_ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit);


    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, ctr_obj);

    if(required != NULL) {
        amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_REQUIRED_ROLES, required);
    }
    if(optional != NULL) {
        amxd_trans_set_csv_string_t(&trans, CTHULHU_CONTAINER_OPTIONAL_ROLES, optional);
    }

    status = amxd_trans_apply(&trans, dm);
    amxd_trans_clean(&trans);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed. " CTHULHU_CONTAINER_REQUIRED_ROLES " & " CTHULHU_CONTAINER_OPTIONAL_ROLES " not added to DM. Status: %d", status);
        goto exit;
    }

    res = 0;
exit:
    amxc_var_set(int32_t, ret, res);
    return res;
}

static int usp_ctr_postcreate(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int rc = -1;
    amxc_var_t paramsdm;
    amxd_object_t* ctr_obj = NULL;
    amxc_var_t* requiredroles = NULL;
    amxc_var_t* optionalroles = NULL;

    const char* ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    amxc_var_init(&paramsdm);

    ctr_obj = usp_ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit);

    amxd_object_get_params(ctr_obj, &paramsdm, amxd_dm_access_public);

    requiredroles = GET_ARG(&paramsdm, CTHULHU_CONTAINER_REQUIRED_ROLES);
    optionalroles = GET_ARG(&paramsdm, CTHULHU_CONTAINER_OPTIONAL_ROLES);

    if(STRING_EMPTY(amxc_var_constcast(cstring_t, requiredroles)) && STRING_EMPTY(amxc_var_constcast(cstring_t, optionalroles))) {
        SAH_TRACEZ_INFO(ME, "No " CTHULHU_CONTAINER_REQUIRED_ROLES " and " CTHULHU_CONTAINER_REQUIRED_ROLES " requested!");
        rc = 0;
    } else {
        amxc_var_cast(requiredroles, AMXC_VAR_ID_LIST);
        amxc_var_cast(optionalroles, AMXC_VAR_ID_LIST);
        rc = usp_localagent_controller_add(ctr_id, requiredroles, optionalroles);
    }

exit:
    amxc_var_clean(&paramsdm);
    amxc_var_set(int32_t, ret, rc);
    return rc;
}

static int usp_ctr_postremove(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int rc = -1;

    const char* ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_NOT_NULL(ctr_id, goto exit, "CTR ID missing, USP controller cannot be removed");
    rc = usp_localagent_controller_rm(ctr_id);

exit:
    amxc_var_set(int32_t, ret, rc);
    return rc;
}

static int usp_ctr_prestart(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int rc = -1;
    cthulhu_ctr_start_data_t* start_data = NULL;
    amxd_object_t* ctr_obj = NULL;
    char* assigned_roles_char = NULL;

    const char* ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ctr_obj = usp_ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit);

    amxc_var_t* var_start_data = GET_ARG(args, CTHULHU_PLUGIN_ARG_START_DATA);
    if(!(var_start_data && var_start_data->data.data)) {
        SAH_TRACEZ_ERROR(ME, "Failed to get " CTHULHU_PLUGIN_ARG_START_DATA " for %s", ctr_id);
        goto exit;
    }

    start_data = (cthulhu_ctr_start_data_t*) var_start_data->data.data;

    assigned_roles_char = amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_ASSIGNED_ROLES, NULL);
    if(STRING_EMPTY(assigned_roles_char)) {
        SAH_TRACEZ_INFO(ME, "No " CTHULHU_CONTAINER_ASSIGNED_ROLES " for ctr '%s',so not sharing the socket", ctr_id);
        rc = 0;
    } else {
        rc = usp_uds_share(start_data, ctr_id);
    }

    free(assigned_roles_char);
exit:
    amxc_var_set(int32_t, ret, rc);
    return rc;
}

static inline void usp_validate_error_on_role(const char* role_name, int rc, amxc_var_t* ret) {
    if(rc > 0) {
        amxc_var_t* reason_var = GET_ARG(ret, CTHULHU_NOTIF_REASON);
        amxc_string_t* reason = amxc_var_take(amxc_string_t, reason_var);
        if(reason != NULL) {
            amxc_string_setf(reason, "%s, '%s'", amxc_string_get(reason, 0), role_name);
            amxc_var_set(cstring_t, reason_var, amxc_string_get(reason, 0));
            amxc_string_delete(&reason);
        } else {
            SAH_TRACEZ_ERROR(ME, "Cannot get reason to append to");
        }
    } else {
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(int32_t, ret, CTHULHU_NOTIF_ERROR_TYPE, tr181_fault_unavailable_role);
        amxc_string_t reason;
        amxc_string_init(&reason, 0);
        amxc_string_setf(&reason, "Role not found in '" ROLE_DM "' or in the '" CTHULHU_SANDBOX_AVAILABLE_ROLES "': '%s'", role_name);
        amxc_var_add_key(cstring_t, ret, CTHULHU_NOTIF_REASON, amxc_string_get(&reason, 0));
        amxc_string_clean(&reason);
    }
}

static inline void usp_validate_sb_error_on_role(const char* role_name, int rc, amxc_var_t* ret) {
    if(rc > 0) {
        amxc_var_t* reason_var = GET_ARG(ret, CTHULHU_NOTIF_REASON);
        amxc_string_t* reason = amxc_var_take(amxc_string_t, reason_var);
        if(reason != NULL) {
            amxc_string_setf(reason, "%s, '%s'", amxc_string_get(reason, 0), role_name);
            amxc_var_set(cstring_t, reason_var, amxc_string_get(reason, 0));
            amxc_string_delete(&reason);
        } else {
            SAH_TRACEZ_ERROR(ME, "Cannot get reason to append to");
        }
    } else {
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(int32_t, ret, CTHULHU_NOTIF_ERROR_TYPE, tr181_fault_unavailable_role);
        amxc_string_t reason;
        amxc_string_init(&reason, 0);
        amxc_string_setf(&reason, "Role not found in '" ROLE_DM "': '%s'", role_name);
        amxc_var_add_key(cstring_t, ret, CTHULHU_NOTIF_REASON, amxc_string_get(&reason, 0));
        amxc_string_clean(&reason);
    }
}

static inline void usp_validate_sb_error_on_ctr_role_missing(const char* role_name, const char* ctr_id, int rc, amxc_var_t* ret) {
    if(rc > 0) {
        amxc_var_t* reason_var = GET_ARG(ret, CTHULHU_NOTIF_REASON);
        amxc_string_t* reason = amxc_var_take(amxc_string_t, reason_var);
        if(reason != NULL) {
            amxc_string_setf(reason, "%s, '%s' from ctr '%s'", amxc_string_get(reason, 0), role_name, ctr_id);
            amxc_var_set(cstring_t, reason_var, amxc_string_get(reason, 0));
            amxc_string_delete(&reason);
        } else {
            SAH_TRACEZ_ERROR(ME, "Cannot get reason to append to");
        }
    } else {
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(int32_t, ret, CTHULHU_NOTIF_ERROR_TYPE, tr181_fault_unavailable_role);
        amxc_string_t reason;
        amxc_string_init(&reason, 0);
        amxc_string_setf(&reason, "Role missing in '" CTHULHU_SANDBOX_AVAILABLE_ROLES "': '%s' from ctr '%s'", role_name, ctr_id);
        amxc_var_add_key(cstring_t, ret, CTHULHU_NOTIF_REASON, amxc_string_get(&reason, 0));
        amxc_string_clean(&reason);
    }
}

static int usp_sb_validate(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int rc = -1;
    amxd_object_t* ctrs = NULL;
    const char* available_roles_arg = "";
    amxc_var_t* available_roles = NULL;
    amxc_var_t copiedavailableroles;
    amxc_var_init(&copiedavailableroles);

    const char* sb_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_SB_ID);
    if(sb_id == NULL) {
        sb_id = GET_CHAR(args, CTHULHU_SANDBOX_ID);
    }
    ASSERT_NOT_NULL(sb_id, goto exit);

    rc = 0;
    available_roles = GET_ARG(args, CTHULHU_SANDBOX_AVAILABLE_ROLES);
    if(available_roles) {
        available_roles_arg = GET_CHAR(args, CTHULHU_SANDBOX_AVAILABLE_ROLES);
        // only do validation if there are available roles passed
        amxc_var_copy(&copiedavailableroles, available_roles);
        amxc_var_cast(&copiedavailableroles, AMXC_VAR_ID_LIST);

        amxc_var_for_each(roleentry, (&copiedavailableroles)) {
            const char* role_name_entry = amxc_var_constcast(cstring_t, roleentry);
            if(STRING_EMPTY(role_name_entry)) {
                continue;
            }

            usp_role_entry_t* entry_in_list = find_usp_role_entry_by_name(role_name_entry);
            if(entry_in_list == NULL) {
                SAH_TRACEZ_ERROR(ME, "Cannot find '%s' in the cached role list", role_name_entry);
                // We don't issue an error just yet, but the code is in place to return it properly
                usp_validate_sb_error_on_role(role_name_entry, rc, ret);
                rc++;
            }
        }

        if(rc) {
            SAH_TRACEZ_ERROR(ME, "Couldnt match (%d) roles with the cached role list for proposed " CTHULHU_SANDBOX_AVAILABLE_ROLES " '%s'", \
                             rc, available_roles_arg);
            goto exit;
        }
    } else {
        // Even if its empty just make it a list
        amxc_var_cast(&copiedavailableroles, AMXC_VAR_ID_LIST);
    }

    ctrs = usp_ctrs_get();
    if(ctrs) {
        amxd_object_for_each(instance, it, ctrs) {
            const char* instance_ctr_id = NULL;
            const char* ctr_sandbox = NULL;
            amxc_var_t params_ctr;
            amxd_object_t* ctr_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
            amxc_var_init(&params_ctr);
            amxd_object_get_params(ctr_instance, &params_ctr, amxd_dm_access_public);
            instance_ctr_id = GET_CHAR(&params_ctr, CTHULHU_CONTAINER_ID);
            ctr_sandbox = GET_CHAR(&params_ctr, CTHULHU_CONTAINER_SANDBOX);
            if(STRING_EMPTY(ctr_sandbox) || (strcmp(ctr_sandbox, sb_id) != 0)) {
                continue;
            }
            if(!STRING_EMPTY(GET_CHAR(&params_ctr, CTHULHU_CONTAINER_REQUIRED_ROLES))) {
                amxc_var_t* requiredroles = GET_ARG(&params_ctr, CTHULHU_CONTAINER_REQUIRED_ROLES);
                amxc_var_cast(requiredroles, AMXC_VAR_ID_LIST);
                amxc_var_for_each(requiredrole, requiredroles) {
                    const char* required_role_name_entry = amxc_var_constcast(cstring_t, requiredrole);
                    int retval;
                    if(STRING_EMPTY(required_role_name_entry)) {
                        continue;
                    }
                    retval = find_path_in_available_roles(required_role_name_entry, &copiedavailableroles);
                    if(retval == 0) {
                        SAH_TRACEZ_ERROR(ME, "Cannot find the required role '%s' (ctr '%s') in the proposed " CTHULHU_SANDBOX_AVAILABLE_ROLES, \
                                         required_role_name_entry, instance_ctr_id);
                        usp_validate_sb_error_on_ctr_role_missing(required_role_name_entry, instance_ctr_id, rc, ret);
                        rc++;
                    } else if(retval < 0) {
                        SAH_TRACEZ_ERROR(ME, "Cannot find the required role due to an error");
                        rc = -1;
                        break;
                    }
                }
            }
            amxc_var_clean(&params_ctr);
        }

        if(rc) {
            SAH_TRACEZ_ERROR(ME, "Cannot match (%d) requiredroles from currently installed containers with " CTHULHU_SANDBOX_AVAILABLE_ROLES " '%s'", \
                             rc, available_roles_arg);
        }
    }

exit:
    amxc_var_clean(&copiedavailableroles);
    return rc;
}

static void slot_localagent_up(UNUSED const char* const sig_name,
                               UNUSED const amxc_var_t* const data,
                               UNUSED void* priv) {
    int retval = usp_localagent_controllertrust_probe();
    if(retval != 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot probe " LOCALAGENT_DM);
        return;
    }
    remove_slot(AMXB_WAIT_DONE, slot_localagent_up);
    return;
}

static inline void wait_and_connect_localagent(void) {
    add_slot(AMXB_WAIT_DONE, NULL, slot_localagent_up, NULL);
    amxb_wait_for_object(LOCALAGENT_DM);
}

static int usp_ctr_validate(UNUSED const char* function_name, amxc_var_t* args, amxc_var_t* ret) {
    int rc = 0;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    amxd_object_t* sb_obj = NULL;
    amxc_var_t* requiredroles = NULL;
    amxc_var_t* available_roles = NULL;
    amxc_var_t params_sb_dm;

    const char* sb_id = GET_CHAR(args, CTHULHU_CONTAINER_SANDBOX);
    if(sb_id) {
        // Install path
        sb_obj = usp_sb_get(sb_id);
    } else {
        // Update path
        ctr_id = GET_CHAR(args, CTHULHU_CONTAINER_ID);
        if(ctr_id) {
            ctr_obj = usp_ctr_get(ctr_id);
            sb_obj = usp_sb_get_from_ctr(ctr_obj);
        } else {
            SAH_TRACEZ_ERROR(ME, "Couldnt get " CTHULHU_CONTAINER_ID);
        }
    }
    ASSERT_NOT_NULL(sb_obj, goto exit);

    amxc_var_init(&params_sb_dm);
    amxd_object_get_params(sb_obj, &params_sb_dm, amxd_dm_access_public);
    available_roles = GET_ARG(&params_sb_dm, CTHULHU_SANDBOX_AVAILABLE_ROLES);

    if(available_roles) {
        amxc_var_cast(available_roles, AMXC_VAR_ID_LIST);
    } else {
        SAH_TRACEZ_ERROR(ME, "Cannot get " CTHULHU_SANDBOX_AVAILABLE_ROLES " from sandbox");
    }

    requiredroles = GET_ARG(args, CTHULHU_CONTAINER_REQUIRED_ROLES);
    if(requiredroles) {
        SAH_TRACEZ_INFO(ME, "Found " CTHULHU_CONTAINER_REQUIRED_ROLES ", starting validation");
        amxc_var_t copiedrequiredroles;
        amxc_var_init(&copiedrequiredroles);
        amxc_var_copy(&copiedrequiredroles, requiredroles);
        amxc_var_cast(&copiedrequiredroles, AMXC_VAR_ID_LIST);

        amxc_var_for_each(roleentry, (&copiedrequiredroles)) {
            const char* role_name_entry = amxc_var_constcast(cstring_t, roleentry);
            if(STRING_EMPTY(role_name_entry)) {
                SAH_TRACEZ_INFO(ME, "Skip empty role");
                continue;
            }
            usp_role_entry_t* entry_in_list = find_usp_role_entry_by_name(role_name_entry);
            if(entry_in_list == NULL) {
                SAH_TRACEZ_ERROR(ME, "Cannot find '%s' in the cached role list", role_name_entry);
                usp_validate_error_on_role(role_name_entry, rc, ret);
                rc = 1;
            } else {
                if(find_path_in_available_roles(entry_in_list->role_path, available_roles) == 0) {
                    // Passing the role path here instead so it can debugged that its not allowed in the available
                    SAH_TRACEZ_ERROR(ME, "Cannot find '%s' (%s) in the available role list", entry_in_list->role_path, role_name_entry);
                    usp_validate_error_on_role(role_name_entry, rc, ret);
                    rc = 1;
                }
            }
        }

        amxc_var_clean(&copiedrequiredroles);
    }

    amxc_var_clean(&params_sb_dm);
exit:
    return rc;
}

static int register_function(const char* const func_name, amxm_callback_t cb) {
    int res = -1;
    if(amxm_module_add_function(mod, func_name, cb) < 0) {
        SAH_TRACEZ_ERROR(ME, "Could not add function [%s]", func_name);
        goto exit;
    }
    res = 0;
exit:
    return res;
}

static void localagent_controllertrust_dm_removed(UNUSED const char* const sig_name,
                                                  const amxc_var_t* const data,
                                                  UNUSED void* const priv) {
    usp_role_entry_t* roleentry = NULL;
    const char* path = GET_CHAR(data, AMXB_NOTIF_PATH);
    amxc_var_t* var_index = GET_ARG(data, AMXB_NOTIF_INDEX);
    uint32_t index = UINT32_MAX;

    if(strncmp(path, ROLE_DM, (sizeof(ROLE_DM) - 1)) != 0) {
        // Ignore notification from sub-object
        SAH_TRACEZ_INFO(ME, "Subscription returned notification on child: %s", path);
        return;
    }

    ASSERT_NOT_NULL(path, return , "Notification missing object path");
    ASSERT_NOT_NULL(var_index, return , "Notification missing object index");

    index = amxc_var_dyncast(uint32_t, var_index);

    roleentry = find_usp_role_entry_by_index(index);
    ASSERT_NOT_NULL(roleentry, return ,
                    "Cannot find usp role entry path '%s' with index '%u', assuming we don't have to remove it from the list", path, index);

    amxc_llist_it_take(&(roleentry->it));
    SAH_TRACEZ_NOTICE(ME, "Removed [%u] '%s' (%s) from the cached list", roleentry->index, roleentry->role_path, roleentry->role_name);

    remove_path_from_available_roles_in_all_sbs(roleentry);
    free_role_entry(roleentry);
    return;
}

static void localagent_app_stopped(UNUSED const char* const sig_name,
                                   UNUSED const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    SAH_TRACEZ_ERROR(ME, LOCALAGENT_DM " app stopped, trying to recover when it gets back up");
    usp_localagent_unsubscribe(false);
    set_localagent_busctx(NULL);
    clean_cached_role_list();
    wait_and_connect_localagent();
}

static void localagent_app_started(UNUSED const char* const sig_name,
                                   UNUSED const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    SAH_TRACEZ_NOTICE(ME, LOCALAGENT_DM " app started, resyncing again");

    usp_localagent_unsubscribe(false);
    set_localagent_busctx(NULL);

    if(usp_localagent_controllertrust_probe() != 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot probe " LOCALAGENT_DM ". Will wait until " LOCALAGENT_DM " is up!");
        wait_and_connect_localagent();
        return;
    }

    // To avoid resycing again if that is the case
    remove_slot(AMXB_WAIT_DONE, slot_localagent_up);
}

static void localagent_controllertrust_dm_added(UNUSED const char* const sig_name,
                                                const amxc_var_t* const data,
                                                UNUSED void* const priv) {
    usp_role_entry_t* newroleentry = NULL;
    const char* path = GET_CHAR(data, "path");
    amxc_var_t* parameters = GET_ARG(data, "parameters");
    const char* role_name = GET_CHAR(parameters, "Name");
    amxc_var_t* var_index = GET_ARG(data, AMXB_NOTIF_INDEX);
    uint32_t index = UINT32_MAX;

    if(strncmp(path, ROLE_DM, (sizeof(ROLE_DM) - 1)) != 0) {
        SAH_TRACEZ_INFO(ME, "Subscription returned notification on child: %s", path);
        return;
    }

    ASSERT_NOT_NULL(path, return , "Notification missing path");
    ASSERT_NOT_NULL(role_name, return , "Notification missing (role) Name");
    ASSERT_NOT_NULL(var_index, return , "Notification missing object index");

    index = amxc_var_dyncast(uint32_t, var_index);

    newroleentry = calloc(1, sizeof(struct usp_role_entry));
    ASSERT_NOT_NULL(newroleentry, return , "Cannot calloc the role entry");

    snprintf(newroleentry->role_path, ROLE_PATH_LEN, "%s%d.", path, index);
    strncpy(newroleentry->role_name, role_name, (ROLE_NAME_LEN - 1));
    newroleentry->index = index;

    amxc_llist_append(&cached_usp_role_list, &(newroleentry->it));
    SAH_TRACEZ_NOTICE(ME, "Added '%s' (%s) [%u] to the cached list", newroleentry->role_path, newroleentry->role_name, newroleentry->index);
    return;
}

static void usp_localagent_unsubscribe(bool all) {
    amxb_bus_ctx_t* bus_ctx_la = get_localagent_busctx();
    if(bus_ctx_la) {
        amxb_unsubscribe(bus_ctx_la, ROLE_DM, localagent_controllertrust_dm_added, NULL);
        amxb_unsubscribe(bus_ctx_la, ROLE_DM, localagent_controllertrust_dm_removed, NULL);
        if(all) {
            amxb_unsubscribe(bus_ctx_la, ROLE_DM, localagent_app_stopped, NULL);
            amxb_unsubscribe(bus_ctx_la, ROLE_DM, localagent_app_started, NULL);
        }
    }
}

static int usp_localagent_controllertrust_probe(void) {
    int ret = -1;
    amxc_var_t roles;

    amxb_bus_ctx_t* bus_ctx_la = get_localagent_busctx();
    if(bus_ctx_la == NULL) {
        SAH_TRACEZ_ERROR(ME, LOCALAGENT_DM " not up yet!!!");
        return ret;
    }

    amxc_var_init(&roles);

    ret = amxb_get(bus_ctx_la, ROLE_DM, 0, &roles, GET_TIMEOUT);
    if(ret != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Couldnt get " ROLE_DM "* !!");
        goto subscribe;
    }

    amxc_var_t* roles_list = amxc_var_get_first(&roles);
    if(roles_list == NULL) {
        SAH_TRACEZ_ERROR(ME, "Variant returned is not a list");
        goto subscribe;
    }

    clean_cached_role_list();
    initialize_cached_role_list();

    amxc_var_for_each(role, roles_list) {
        const char* rolepath = amxc_var_key(role);
        const char* rolename = GET_CHAR(role, ROLE_NAME);
        uint32_t index = UINT32_MAX;
        usp_role_entry_t* newroleentry = NULL;

        ASSERT_NOT_NULL(rolepath, continue, "Key (rolepath) is missing");
        ASSERT_NOT_NULL(rolename, continue, ROLE_NAME " is missing");

        if(get_index_from_path((rolepath + sizeof(ROLE_DM) - 1), &index, true) == false) {
            SAH_TRACEZ_ERROR(ME, "Cannot get index from '%s'", (rolepath + sizeof(ROLE_DM) - 1));
            continue;
        }

        newroleentry = calloc(1, sizeof(struct usp_role_entry));
        ASSERT_NOT_NULL(newroleentry, continue, "Cannot calloc the role entry");

        strncpy(newroleentry->role_path, rolepath, (ROLE_PATH_LEN - 1));
        strncpy(newroleentry->role_name, rolename, (ROLE_NAME_LEN - 1));
        newroleentry->index = index;

        amxc_llist_append(&cached_usp_role_list, &(newroleentry->it));
        SAH_TRACEZ_NOTICE(ME, "Added '%s' (%s) [%u] to the cached list", newroleentry->role_path, newroleentry->role_name, newroleentry->index);
    }

subscribe:

    ASSERT_EQUAL(amxb_subscribe(bus_ctx_la, ROLE_DM, "notification == 'dm:instance-added'", localagent_controllertrust_dm_added, NULL),
                 AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to added instances on %s", ROLE_DM);

    ASSERT_EQUAL(amxb_subscribe(bus_ctx_la, ROLE_DM, "notification == 'dm:instance-removed'", localagent_controllertrust_dm_removed, NULL),
                 AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to removed instances on %s", ROLE_DM);

    ASSERT_EQUAL(amxb_subscribe_ex(bus_ctx_la, LOCALAGENT_DM, 0, AMXB_BE_EVENT_TYPE_EVENT, "notification == '" AMXB_APP_STOP "'",
                                   localagent_app_stopped, NULL), AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to stopping of the " LOCALAGENT_DM);

    ASSERT_EQUAL(amxb_subscribe_ex(bus_ctx_la, LOCALAGENT_DM, 0, AMXB_BE_EVENT_TYPE_EVENT, "notification == '" AMXB_APP_START "'",
                                   localagent_app_started, NULL), AMXB_STATUS_OK, NO_INSTRUCTION, "Could not subscribe to stopping of the " LOCALAGENT_DM);

    amxc_var_clean(&roles);
    return ret;
}

static int usp_plugin_init(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_NOTICE(ME, "Initializing cthulhu-plugin-usp");

    dm = (amxd_dm_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_DATAMODEL);

    initialize_cached_role_list();
    if(usp_localagent_controllertrust_probe()) {
        SAH_TRACEZ_ERROR(ME, "Will wait until " LOCALAGENT_DM " is up!");
        wait_and_connect_localagent();
    }

    return 0;
}

AMXM_CONSTRUCTOR module_init(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu Plugin USP constructor");
    int ret = -1;

    so = amxm_so_get_current();
    if(so == NULL) {
        SAH_TRACEZ_ERROR(ME, "Could not get shared object\n");
        goto exit;
    }

    if(amxm_module_register(&mod, so, CTHULHU_PLUGIN)) {
        SAH_TRACEZ_ERROR(ME, "Could not register module " CTHULHU_PLUGIN);
        goto exit;
    }

    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_CREATE, usp_sb_create), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_MODIFY, usp_sb_create), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_SB_VALIDATE, usp_sb_validate), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_VALIDATE, usp_ctr_validate), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_PRESTART, usp_ctr_prestart), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_POSTCREATE, usp_ctr_postcreate), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_POSTREMOVE, usp_ctr_postremove), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_CREATE, usp_ctr_create), goto exit);

    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_INIT, usp_plugin_init), goto exit);

    ret = 0;
exit:
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu Plugin USP constructor");
    return ret;
}

AMXM_DESTRUCTOR module_exit(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu Plugin USP destructor");
    remove_slot(AMXB_WAIT_DONE, slot_localagent_up);
    usp_localagent_unsubscribe(true);
    clean_cached_role_list();
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu Plugin USP destructor");
    return 0;
}
