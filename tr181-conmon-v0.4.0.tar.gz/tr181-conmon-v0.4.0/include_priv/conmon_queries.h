/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__CONMON_QUERIES_H__)
#define __CONMON_QUERIES_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "conmon.h"

/**
   @file
   @brief
   Helpers for netmodel queries
 */

/**
   @ingroup conmon
   @defgroup conmon_queries ConMon netmodel queries helper

   Functions used by conmon plugins to get information from NetModel
 */

typedef void (* netdev_callback_t)(const char* const sig_name, const amxc_var_t* const data, void* const priv);

/**
   @ingroup conmon_queries
   @brief
   Wrapper function to be ccreate a subscription on NetDev.Link.

   @param entry conmon_info_t structur pointer corresponding to a ConMON.Entry.i object
   @param notification The bus event on which the subscription call back need to be trigger
   @param netdev_subscription The subscription returned by the amxb_subscription_new call
   @param cb The callback function for to be called when the subscription trigger
 */
void create_netdev_subscription(conmon_info_t* entry, const char* notification, amxb_subscription_t** netdev_subscription, netdev_callback_t cb);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling the addition of a new NetDev.Link.i

   @param sig_name The signal send on the bus, not used in this function
   @param data The send on the bus by the bus event, not used in this function
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to a NetDev.Link. addition
 */
void netdev_new_link_added_cb(const char* const sig_name,
                              const amxc_var_t* const data,
                              void* const priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling the removal of a new NetDev.Link.i

   @param sig_name The signal send on the bus, not used in this function
   @param data The send on the bus by the bus event, not used in this function
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to a NetDev.Link. removal
 */
void netdev_link_removed_cb(const char* const sig_name,
                            const amxc_var_t* const data,
                            void* const priv);

/**
   @ingroup conmon_queries
   @brief
   Function to update the internal state of a ConMon.Entry.i object when the physical link change

   @param up True if the physical link linked with the ConMon.Entry.i is up
   @param entry The conmon_info_t pointer corresponding to a ConMon.Entry.i object where the physical link changed
 */
void physicalisup_changed(bool up, conmon_info_t* entry);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the parameter of the connected wan interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The wan linux interface name
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the wan interface
 */
void wanintf_changed(const char* sig_name,
                     const amxc_var_t* data,
                     void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the up status of an interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The up status of the linux interface
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the status of the interface
 */
void isup_changed(const char* sig_name,
                  const amxc_var_t* data,
                  void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the default route of the wan interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The list of the default route of the wan interface
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change in the default routes of the wan interface
 */
void wan_defaultroute_changed(const char* sig_name,
                              const amxc_var_t* data,
                              void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the default route of the wan ipv6 interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The list of the default route of the wan ipv6 interface
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change in the default routes of the wan ipv6 interface
 */
void wan6_defaultroute_changed(const char* sig_name,
                               const amxc_var_t* data,
                               void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the down timeout of the interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The timout value
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change in the timeout of the interface
 */
void physdowntimeout_changed(const char* sig_name,
                             const amxc_var_t* data,
                             void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the interface ip

   @param sig_name The signal send on the bus, not used in this function
   @param data The ip address on the interface
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change in the ip of the interface
 */
void local_ip_changed(const char* sig_name,
                      const amxc_var_t* data,
                      void* priv);

/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the status of the dhcp connection on an interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The dhcp up status
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change of the dhcp connectin status on an interface
 */
void dhcp_changed(const char* sig_name,
                  const amxc_var_t* data,
                  void* priv);


/**
   @ingroup conmon_queries
   @brief
   Callback function handeling a change in the status of the low level interface path of the interface

   @param sig_name The signal send on the bus, not used in this function
   @param data The low level interface path
   @param priv The conmon_info_t pointer corresponding to a ConMon.Entry.i object that previously subscribed to the change of the dhcp connectin status on an interface
 */
void ll_interface_path_changed(const char* sig_name,
                               const amxc_var_t* data,
                               void* priv);

/**
   @ingroup conmon_queries
   @brief
   Function to clean all netmodel queries open for a conmon_info_t structure

   @param conmon The conmon_info_t structure's pointer where the nemodel queries need to be cleaned
 */
void cleanup_nm_interface_queries(conmon_info_t* conmon);

/**
   @ingroup conmon_queries
   @brief
   Function to clean all netdev queries open for a conmon_info_t structure

   @param conmon The conmon_info_t structure's pointer where the nnetdev queries need to be cleaned
 */
void cleanup_netdev_queries(conmon_info_t* conmon);

/**
   @ingroup conmon_queries
   @brief
   Function to verify if a netmodel query was already open

   @param query The netmodel query to verify
   @param description A humane readable name of the query to test
 */
void verify_open_query(netmodel_query_t* query, const char* description);

#ifdef __cplusplus
}
#endif

#endif // __CONMON_QUERIES_H__
