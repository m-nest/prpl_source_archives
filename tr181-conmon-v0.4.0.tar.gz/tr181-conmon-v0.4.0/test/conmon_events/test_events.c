/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>

#include "../common/common_functions.h"

#include "conmon.h"
#include "conmon_utils.h"
#include "test_events.h"

static void cleanup_entry(const char* name) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_priv, true);

    amxd_trans_select_pathf(&trans, "ConMon.Entry");
    amxd_trans_del_inst(&trans, 0, name);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxut_bus_handle_events();

    amxd_trans_clean(&trans);
}

int test_setup(void** state) {
    amxut_bus_setup(state);

    resolver_add_all_functions();

    test_setup_parse_odl(DUMMY_TEST_ODL);
    test_setup_parse_odl(INTERFACE_ODL);
    test_setup_parse_odl(NETDEV_ODL);
    test_setup_parse_odl(LOGICAL_ODL);
    test_setup_parse_odl(LOGICAL_POPULATE_ODL);

    assert_int_equal(_conmon_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_handle_events();
    return 0;
}

int test_teardown(void** state) {
    cleanup_entry("wan");
    assert_int_equal(_conmon_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);

    return 0;
}

void test_add_entry(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_priv, true);

    amxd_trans_select_pathf(&trans, "ConMon.Entry");
    amxd_trans_add_inst(&trans, 0, "test_entry");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    amxd_trans_set_value(cstring_t, &trans, "Interface", "Device.Logical.Interface.2.");
    amxd_trans_set_value(cstring_t, &trans, "Type", "ND");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxut_bus_handle_events();

    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Disabled");

    amxd_trans_clean(&trans);
}

void test_change_entry(UNUSED void** state) {
    amxc_var_t data;
    amxc_var_t ret;

    amxc_var_init(&data);
    amxc_var_init(&ret);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(bool, &data, "Enable", true);
    assert_int_equal(amxb_set(amxut_bus_ctx(), "ConMon.Entry.test_entry.", &data, &ret, 5), 0);
    amxut_bus_handle_events();

    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Enabled");

    amxc_var_clean(&ret);
    amxc_var_clean(&data);
}

void test_simulate_failure(UNUSED void** state) {
    amxc_var_t data;
    amxc_var_t ret;
    amxd_object_t* obj = NULL;
    char* status_result = NULL;
    amxc_string_t test_path;
    const char* interface_name = "wan";
    const char* status = "Error";
    uint32_t arpns_total_fail = 5;
    uint32_t total_dhcp_restarts = 1;
    uint32_t arpns_errors_sent = 2;


    amxc_var_init(&data);
    amxc_var_init(&ret);
    amxc_string_init(&test_path, 0);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, "alias", interface_name);
    amxc_var_add_key(cstring_t, &data, "Status", status);
    amxc_var_add_key(uint32_t, &data, "arpns_total_fail", arpns_total_fail);
    amxc_var_add_key(uint32_t, &data, "total_dhcp_restarts", total_dhcp_restarts);
    amxc_var_add_key(uint32_t, &data, "arpns_errors_sent", arpns_errors_sent);

    assert_int_equal(conmon_update_dm(NULL, &data, NULL), 0);
    amxut_bus_handle_events();

    amxc_string_setf(&test_path, "ConMon.Entry.%s", interface_name);

    obj = amxd_dm_findf(amxut_bus_dm(), amxc_string_get(&test_path, 0));
    status_result = amxd_object_get_value(cstring_t, obj, "Status", NULL);
    assert_string_equal(status_result, status);

    amxc_string_append(&test_path, ".Stats", 6);
    obj = amxd_dm_findf(amxut_bus_dm(), amxc_string_get(&test_path, 0));
    assert_int_equal(amxd_object_get_value(uint32_t, obj, "ARPNSErrorsSent", NULL), arpns_errors_sent);
    assert_int_equal(amxd_object_get_value(uint32_t, obj, "ARPNSTotalFail", NULL), arpns_total_fail);
    assert_int_equal(amxd_object_get_value(uint32_t, obj, "TotalDHCPRestarts", NULL), total_dhcp_restarts);

    amxc_string_clean(&test_path);
    free(status_result);
    amxc_var_clean(&data);
}

void test_temporary_link_loss(UNUSED void** state) {
    amxd_trans_t trans;
    const char* interface_name = "eth0";

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_priv, true);

    amxd_trans_select_pathf(&trans, "NetDev.Link.");
    amxd_trans_del_inst(&trans, 0, interface_name);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxut_bus_handle_events();

    amxd_trans_clean(&trans);
}

void test_link_loss_fixed(UNUSED void** state) {
    amxd_trans_t trans2;
    const char* interface_name = "eth0";

    amxd_trans_init(&trans2);
    amxd_trans_set_attr(&trans2, amxd_tattr_change_priv, true);

    amxd_trans_select_pathf(&trans2, "NetDev.Link.");
    amxd_trans_add_inst(&trans2, 0, interface_name);
    assert_int_equal(amxd_trans_apply(&trans2, amxut_bus_dm()), amxd_status_ok);
    amxut_bus_handle_events();

    amxd_trans_clean(&trans2);
}

void test_remove_entry(UNUSED void** state) {
    cleanup_entry("test_entry");
}
