# tr069-connectionrequest

[TOC]

# Introduction

`tr069-connectionrequest` is a lightweight software module designed to run on a **prplOS-based network Extender**.  
Its primary role is to enable **TR-069 Auto Configuration Server (ACS)** connectivity to the Extender’s **TR-181 data model**, even when the Extender is deployed behind a **Gateway (GW)**.

## Key Functions

The module accomplishes this by:

- Opening and maintaining the **UPnP Internet Gateway Device (IGD)** control port on the Gateway.  
- Establishing a **port mapping** that forwards incoming TR-069 *Connection Request* traffic from the ACS server through the Gateway to the Extender.  
- Allowing the ACS server to **initiate management sessions** with the Extender’s TR model as if it were directly accessible.  

## Overview

In effect, `tr069-connectionrequest` provides the **bridge between the ACS and the Extender** in NATed environments, ensuring that the ACS can trigger TR-069 sessions reliably without manual configuration of the Gateway.

This module integrates into the broader **prplOS management framework** and cooperates with the **miniupnpd** component to provide seamless remote management of Extended devices.

```text
+-----------------------+                         
|  Auto Configuration   | session (ACS <-> Extender) via mapping 
|  Server (ACS)         |---------<--------------------->-----+
+-----------+-----------+                                     |
            ^                                                 |
            |                                                 |
            |                                                 |
            |                                                 v
+-----------+-----------+          UPnP IGD: AddPortMapping   +-----------------------+
|   Gateway (GW)        |<------------------------------------|     Extender          |
| - miniupnpd           |          Mapping                    |tr069-connectionrequest|
| - NAT / Firewall      |------------------------------------>|   module              |
| - Public/Upstream IP  |                                     |                       |
+-----------+-----------+                                     +---------+-------------+
            ^                                                           |
            |                                                           |
            +----------------------- ConnReq URL -----------------------+
                                   http://[EXT_IP or EXT_v6]:ext_port/token
```

# Building

The `tr069-connectionrequest` module is not distributed as a standalone package.  
It is integrated into the **prplOS build system** and included by default in the **Extender full image profile**.

## Dependencies

<code>tr069-connectionrequest</code> depends on the following libraries:

- libamxb
- libamxc
- libamxd
- libamxm
- libamxp
- libupnp-prpl
- libixml

