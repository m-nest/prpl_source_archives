/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include <string.h>
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_bridging.h"
#include "gmap_eth_dev_bridge_priv.h"
#include <amxo/amxo.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_timer.h>

#include "../common/test-setup.h"
#include "../common/test-util.h"
#include "../common/mock_gmap.h"
#include "test_bridging.h"
#include "mock_bridging.h"
#include <arpa/inet.h>

#define NETDEV_MAC "60:50:40:30:20:10"
#define GMAP_QUERY_EXPRESSION "self interface && (eth || wifi || moca) && .NetDevIndex != 0 && .PhysAddress ^= \"" NETDEV_MAC "\""

#define ND_BR_LAN "br-lan"
#define ND_IDX_BR_LAN 19
#define ND_ETH0_1 "eth0_1"
#define ND_IDX_ETH0_1 12

/**
 * Mock discoping wrapper structure. All calls to gmap_eth_dev_discoping_*
 * should be wrapped.
 */
struct gmap_eth_dev_discoping {
    /* empty structs are a gcc extension. */
    char empty;
};

void __wrap_gmap_eth_dev_discoping_verify_all_ips(gmap_eth_dev_discoping_t* discoping,
                                                  const char* dev_mac,
                                                  const char* key,
                                                  uint32_t protocol_family);

void __wrap_gmap_eth_dev_discoping_verify_all_ips(gmap_eth_dev_discoping_t* discoping,
                                                  const char* dev_mac,
                                                  const char* key,
                                                  uint32_t protocol_family) {
    check_expected(discoping);
    check_expected(dev_mac);
    check_expected(key);
    check_expected(protocol_family);
}

static void s_expect_discoping_verify_all_ips(const gmap_eth_dev_bridge_t* bridge,
                                              const char* dev_mac,
                                              const char* dev_key) {
    assert_non_null(bridge);
    expect_value(__wrap_gmap_eth_dev_discoping_verify_all_ips, discoping, bridge->discoping);
    expect_string(__wrap_gmap_eth_dev_discoping_verify_all_ips, dev_mac, dev_mac);
    expect_string(__wrap_gmap_eth_dev_discoping_verify_all_ips, key, dev_key);
    expect_value(__wrap_gmap_eth_dev_discoping_verify_all_ips, protocol_family, bridge->proto_family);
}

void __wrap_gmap_eth_dev_linker_link(gmap_eth_dev_linker_t* linker,
                                     const amxc_var_t* port_fields_cached,
                                     uint32_t port_netdev_idx,
                                     const char* dev_key);

void __wrap_gmap_eth_dev_linker_link(gmap_eth_dev_linker_t* linker,
                                     UNUSED const amxc_var_t* port_fields_cached,
                                     uint32_t port_netdev_idx,
                                     const char* dev_key) {
    assert_non_null(linker);
    check_expected(port_netdev_idx);
    check_expected(dev_key);
}

static void s_expect_linker_link(uint32_t port_netdev_idx,
                                 const char* dev_key) {
    expect_value(__wrap_gmap_eth_dev_linker_link, port_netdev_idx, port_netdev_idx);
    expect_string(__wrap_gmap_eth_dev_linker_link, dev_key, dev_key);
}

void __wrap_gmap_eth_dev_linker_make_inactive(gmap_eth_dev_linker_t* linker,
                                              uint32_t port_netdev_idx,
                                              const char* dev_key);

void __wrap_gmap_eth_dev_linker_make_inactive(gmap_eth_dev_linker_t* linker,
                                              uint32_t port_netdev_idx,
                                              const char* dev_key) {
    assert_non_null(linker);
    check_expected(port_netdev_idx);
    check_expected(dev_key);
}

static void s_expect_linker_make_inactive(uint32_t port_netdev_idx,
                                          const char* dev_key) {
    expect_value(__wrap_gmap_eth_dev_linker_make_inactive, port_netdev_idx, port_netdev_idx);
    expect_string(__wrap_gmap_eth_dev_linker_make_inactive, dev_key, dev_key);
}


int test_setup_bridging_linking(UNUSED void** state) {
    int result = amxut_bus_setup(state);
    when_false(result == 0, exit);

    bridging_setup_netdev();
    bridging_setup_mock();
    bridging_setup_discovered();

    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    assert_success(gmap_eth_dev_bridging_init());

exit:
    return result;
}

int test_teardown_bridging_linking(UNUSED void** state) {
    gmap_eth_dev_bridging_clean();
    bridging_teardown_discovered();
    bridging_teardown_mock();

    return amxut_bus_teardown(state);
}


void test_gmap_eth_dev_bridging_linker__bad_init(UNUSED void** state) {
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = NULL,
    };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    gmap_eth_dev_bridging_linker_new(NULL, NULL);
    gmap_eth_dev_bridging_linker_new(&linker, NULL);
    assert_null(linker);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_null(linker);

    gmap_eth_dev_bridging_linker_delete(NULL);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__init(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // THEN initializing the linker will work
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__init_initial_fetch(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // AND a filled bridge table
    bridging_mock_add_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // THEN expect all structures to be set up
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);

    // AND expect the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = false,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), true);
    s_expect_linker_link(ND_IDX_ETH0_1, "id1");

    // WHEN creating the bridging linker
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__new_mac(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // EXPECT all structures to be set up
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);
    amxut_bus_handle_events();

    // WHEN a device becomes available
    bridging_mock_add_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = false,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), true);
    s_expect_linker_link(ND_IDX_ETH0_1, "id1");
    amxut_bus_handle_events();

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__new_mac_device_exists(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // EXPECT all structures to be set up
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);
    amxut_bus_handle_events();

    // WHEN a device becomes available
    bridging_mock_add_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be linked and checked
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = true,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), true);
    s_expect_linker_link(ND_IDX_ETH0_1, "id1");
    s_expect_discoping_verify_all_ips(&bridge, "11:22:33:44:55:01", "id1");
    amxut_bus_handle_events();

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__removed_mac(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // EXPECT all structures to be set up
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);
    amxut_bus_handle_events();

    // WHEN a device becomes available
    bridging_mock_add_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = false,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), true);
    s_expect_linker_link(ND_IDX_ETH0_1, "id1");
    amxut_bus_handle_events();

    // WHEN the device becomes unavailable
    bridging_mock_remove_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = NULL,
        .will_return_already_exists = false,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), false);
    // Nothing to make inactive: the device didn't exist yet
    // s_expect_linker_make_inactive(ND_IDX_ETH0_1, "id1");
    amxut_bus_handle_events();

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}

void test_gmap_eth_dev_bridging_linker__removed_mac_device_exists(UNUSED void** state) {
    // GIVEN a bridge with valid (mocked) discoping structure,
    gmap_eth_dev_discoping_t discoping = { 0 };
    gmap_eth_dev_bridge_t bridge = {
        .netdev = ND_BR_LAN,
        .netdev_index = ND_IDX_BR_LAN,
        .address = "192.168.1.1",
        .mac = NETDEV_MAC,
        .proto_family = AF_INET,
        .discoping = &discoping,
    };
    gmap_query_t query = { 0 };
    gmap_eth_dev_bridging_linker_t* linker = NULL;

    // EXPECT all structures to be set up
    expect_string(__wrap_gmap_query_open_ext_2, expression, GMAP_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    gmap_eth_dev_bridging_linker_new(&linker, &bridge);
    assert_non_null(linker);
    amxut_bus_handle_events();

    // WHEN a device becomes available
    bridging_mock_add_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = false,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), true);
    s_expect_linker_link(ND_IDX_ETH0_1, "id1");
    amxut_bus_handle_events();

    // WHEN the device becomes unavailable
    bridging_mock_remove_mac(ND_BR_LAN, ND_ETH0_1, "11:22:33:44:55:01");

    // EXPECT the device to be created in gmap
    mock_gmap_expect_createIfActive("11:22:33:44:55:01", (&(mock_gmap_devices_create_mockdata_t) {
        .will_return_key = "id1",
        .will_return_already_exists = true,
        .will_return_success = true,
        .expected_tags = "lan edev mac physical",
    }), false);
    s_expect_linker_make_inactive(ND_IDX_ETH0_1, "id1");
    amxut_bus_handle_events();

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    gmap_eth_dev_bridging_linker_delete(&linker);
    assert_null(linker);
}
