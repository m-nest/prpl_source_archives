/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_bridgeport.h"

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include "gmap_eth_dev_bridgeport.h"
#include <string.h>
#include <sys/socket.h>
#include <stdio.h>
#include <amxc/amxc.h> // needed for <amxp/amxp.h>
#include <amxp/amxp.h> // needed for <amxd/amxd_object.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <malloc.h>

#include "../common/test-setup.h"
#include "../common/test-util.h"


int test_gmap_eth_dev_bridgeport_setup(UNUSED void** state) {
    int result = test_setup_without_component_init(state);
    if(result == 0) {
        amxut_dm_load_odl("netdev-dm.odl");
        amxut_bus_handle_events();
    }
    return result;
}

int test_gmap_eth_dev_bridgeport_teardown(UNUSED void** state) {
    return test_teardown_without_component_cleanup(state);
}

static uint32_t s_create_port(const char* kind, uint32_t master) {
    amxc_var_t params;
    amxc_var_t ret;
    amxd_status_t status;
    uint32_t index = 0;

    amxc_var_init(&params);
    amxc_var_init(&ret);

    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &params, "Kind", kind);
    amxc_var_add_key(uint32_t, &params, "Master", master);

    status = amxb_add(amxut_bus_ctx(), "NetDev.Link.", 0, NULL, &params, &ret, 5);
    assert_int_equal(status, amxd_status_ok);

    index = GET_UINT32(GETI_ARG(&ret, 0), "index");
    assert_int_not_equal(index, 0);

    amxc_var_clean(&ret);
    amxc_var_clean(&params);

    return index;
}

static void s_mod_port(uint32_t index, const char* kind, uint32_t master) {
    amxd_trans_t trans;
    amxd_status_t status;

    amxd_trans_init(&trans);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "NetDev.Link.%d.", index);
    amxd_trans_set_value(cstring_t, &trans, "Kind", kind);
    amxd_trans_set_value(uint32_t, &trans, "Master", master);

    status = amxd_trans_apply(&trans, amxut_bus_dm());
    assert_int_equal(status, amxd_status_ok);

    amxd_trans_clean(&trans);
}

static void s_del_port(uint32_t index) {
    amxb_del(amxut_bus_ctx(), "NetDev.Link.", index, NULL, NULL, 5);
}

static void s_port_cb_t(gmap_eth_dev_bridgeport_t* port,
                        const char* path,
                        uint32_t master,
                        bool matching,
                        void* const priv) {
    check_expected(port);
    check_expected(path);
    check_expected(master);
    check_expected(matching);
    check_expected(priv);
}

void test_gmap_eth_dev_bridgeport_added_matching(UNUSED void** state) {
    gmap_eth_dev_bridgeport_t* port = NULL;

    // GIVEN a netdev bridge_port reader
    gmap_eth_dev_bridgeport_new(&port, amxut_bus_ctx());
    assert_non_null(port);

    // WHEN subscribed for a specific port
    gmap_eth_dev_bridgeport_subscribe(port, 1, s_port_cb_t, (void*) (uintptr_t) 1);

    // AND that port is added
    s_create_port("bridge_port", 1);

    // THEN the callback is called
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    // WHEN another port is added
    s_create_port("bridge_port", 2);

    // THEN the callback is not called
    amxut_bus_handle_events();

    gmap_eth_dev_bridgeport_delete(&port);
    assert_null(port);
}

void test_gmap_eth_dev_bridgeport_removed_matching(UNUSED void** state) {
    gmap_eth_dev_bridgeport_t* port = NULL;
    uint32_t index = 0;

    // GIVEN a netdev bridge_port reader
    gmap_eth_dev_bridgeport_new(&port, amxut_bus_ctx());
    assert_non_null(port);

    // WHEN subscribed for a specific port
    gmap_eth_dev_bridgeport_subscribe(port, 1, s_port_cb_t, (void*) (uintptr_t) 1);

    // AND that port is added
    index = s_create_port("bridge_port", 1);

    // THEN the callback is called
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    // WHEN that port is removed
    s_del_port(index);

    // THEN the callback is called
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, false);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    gmap_eth_dev_bridgeport_delete(&port);
    assert_null(port);
}

void test_gmap_eth_dev_bridgeport_changed_matching(UNUSED void** state) {
    gmap_eth_dev_bridgeport_t* port = NULL;
    uint32_t index = 0;

    // GIVEN a netdev bridge_port reader
    gmap_eth_dev_bridgeport_new(&port, amxut_bus_ctx());
    assert_non_null(port);

    // WHEN subscribed for two specific ports
    gmap_eth_dev_bridgeport_subscribe(port, 1, s_port_cb_t, (void*) (uintptr_t) 1);
    gmap_eth_dev_bridgeport_subscribe(port, 2, s_port_cb_t, (void*) (uintptr_t) 2);

    // AND a non-matching port is added
    index = s_create_port("other-kind", 1);
    assert_int_not_equal(index, 0);

    // THEN the callback is not called
    amxut_bus_handle_events();

    //WHEN the port is changed
    s_mod_port(index, "bridge_port", 1);

    // THEN the callback is called
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);
    amxut_bus_handle_events();

    //WHEN the port is changed again
    s_mod_port(index, "bridge_port", 2);

    // THEN both callbacks are called
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, false);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);

    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 2);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 2);
    amxut_bus_handle_events();

    gmap_eth_dev_bridgeport_delete(&port);
    assert_null(port);
}

void test_gmap_eth_dev_bridgeport_initial_matching(UNUSED void** state) {
    gmap_eth_dev_bridgeport_t* port = NULL;

    // GIVEN a existing port
    s_create_port("bridge_port", 1);
    amxut_bus_handle_events();

    // WHEN the port listener is created
    gmap_eth_dev_bridgeport_new(&port, amxut_bus_ctx());
    assert_non_null(port);

    // AND another port is added
    s_create_port("bridge_port", 2);
    amxut_bus_handle_events();

    // THEN callbacks are called when their subscriptions are added
    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.1.");
    expect_value(s_port_cb_t, master, 1);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 1);
    gmap_eth_dev_bridgeport_subscribe(port, 1, s_port_cb_t, (void*) (uintptr_t) 1);

    expect_value(s_port_cb_t, port, port);
    expect_string(s_port_cb_t, path, "NetDev.Link.2.");
    expect_value(s_port_cb_t, master, 2);
    expect_value(s_port_cb_t, matching, true);
    expect_value(s_port_cb_t, priv, (void*) (uintptr_t) 2);
    gmap_eth_dev_bridgeport_subscribe(port, 2, s_port_cb_t, (void*) (uintptr_t) 2);


    gmap_eth_dev_bridgeport_delete(&port);
    assert_null(port);
}
