/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __ROUTING_TABLE_H__
#define __ROUTING_TABLE_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file
 * @brief Routing table management for the TR-181 Routing plugin.
 *
 * This file provides functions to validate, add, and delete Linux routing table entries
 * used by the TR-181 Routing plugin.
 */

/**
 * @defgroup routing_table Routing Table Management
 * @ingroup tr181-routing
 * @brief Functions to manage routing table entries for the TR-181 Routing plugin.
 * @{
 */

/**
 * @brief Checks if a routing table entry is valid.
 *
 * Validates if the specified routing table entry exists and matches the given name.
 *
 * @param table_id The ID of the routing table.
 * @param table_name The name of the routing table.
 * @return true if the entry is valid, false otherwise.
 */
bool is_valid_rt_table_entry(int table_id, const char* table_name);

/**
 * @brief Adds or updates a routing table entry.
 *
 * Sets or updates the routing table entry with the specified ID and name.
 *
 * @param table_id The ID of the routing table.
 * @param table_name The name to assign to the routing table.
 * @return 0 on success, or a negative value on failure.
 */
int set_rt_table_entry(int table_id, const char* table_name);

/**
 * @brief Deletes a routing table entry.
 *
 * Removes the routing table entry with the specified ID.
 *
 * @param table_id The ID of the routing table to delete.
 * @return 0 on success, or a negative value on failure.
 */
int del_rt_table_entry(int table_id);

/** @} */ // end of routing_table group

#ifdef __cplusplus
}
#endif

#endif // __ROUTING_TABLE_H__

