#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_usb_filter.h"
#include "device_list.h"
#include "filter.h"

static amxd_dm_t* data_model;

/**
 * @brief Get the dm object
 *
 * @return dm object
 */
amxd_dm_t* get_dm(void) {
    return data_model;
}

static int remove_entry(device_type_t t, usb_device_list_entry_t* entry, UNUSED void* priv) {
    int rv = -1;

    when_null(entry, exit);
    rv = usb_device_list_delete(t, entry->identifier);
    entry = NULL; // freed in usb_device_list_delete

exit:
    return rv;
}

/**
 * @brief Main entry point for the module.
 *
 * @param reason The reason for the call.
 * @param dm The data model.
 * @param parser The parser.
 * @return int The status of the operation.
 */
int _filter_main(int reason,
                 amxd_dm_t* dm,
                 UNUSED amxo_parser_t* parser) {
    int retval = 0;
    switch(reason) {
    case 0:
        data_model = dm;
        usb_device_list_init(DEVICE);
        usb_device_list_init(ALLOWED_DEVICE);
        break;
    case 1:
        usb_device_list_foreach(DEVICE, remove_entry, NULL);
        usb_device_list_foreach(ALLOWED_DEVICE, remove_entry, NULL);
        usb_device_list_clean(DEVICE);
        usb_device_list_clean(ALLOWED_DEVICE);
        break;
    }

    return retval;
}

/**
 * @brief Handles the app:start event
 *
 * @param sig_name The signal name.
 * @param data The data associated with the event.
 * @param priv Private data.
 */
void _filter_app_start(UNUSED const char* const sig_name,
                       UNUSED const amxc_var_t* const data,
                       UNUSED void* const priv) {
    amxd_object_t* usb_hosts_obj = NULL;

    usb_hosts_obj = amxd_dm_findf(get_dm(), "USB.USBHosts");
    when_null_trace(usb_hosts_obj, exit, ERROR, "Could not find USB.USBHosts object");

    set_allow_all_devices(GET_BOOL(amxd_object_get_param_value(usb_hosts_obj, "AllowAllDevices"), NULL));

exit:
    return;
}