/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_helpers.h>
#include <cthulhu/cthulhu_config.h>
#include <amxd/amxd_object_event.h>
#include <lcm/lcm_dump_rpc.h>

#include <lcm/lcm_assert.h>
#include <lcm/amxc_data.h>
#include <debug/sahtrace.h>

#include "cthulhu_lpm_defines.h"
#include "ctr_policy.h"
#include "utils.h"
#include "cthulhu_lpm.h"

#define ME "lpm"

/**
 * @brief Pointer to the data model instance.
 */
static amxd_dm_t* dm = NULL;
/**
 * @brief Pointer to the shared object instance.
 */
static amxm_shared_object_t* so = NULL;
/**
 * @brief Pointer to the module instance.
 */
static amxm_module_t* mod = NULL;

static cthulhu_prestartup_config_t* prestartup_config = NULL;

/**
 * @brief Gets the data model instance.
 * @return Pointer to the data model instance.
 */
amxd_dm_t* get_dm(void) {
    return dm;
}

/**
 * @brief Registers Cthulhu custom function for LocalManagement service
 *
 * @param path Path of the function to register the function to it.
 * @param fn_name Name of the function as exposed in the data model.
 * @param function Pointer to the function to use as custom function.
 * @return amxd_status_ok on success, a different value on failure.
 */
static amxd_status_t register_pcm_functions(const char* path, const char* fn_name, amxd_object_fn_t function) {
    amxd_status_t rc = amxd_status_unknown_error;
    amxd_function_t* fn = NULL;
    amxd_object_t* object = NULL;

    ASSERT_NOT_NULL(function, goto exit);

    SAH_TRACEZ_INFO(ME, "Registering function functions (%s:%s)", path, fn_name);
    object = amxd_dm_findf(dm, "%s", path);
    ASSERT_NOT_NULL(object, goto exit);

    ASSERT_SUCCESS(amxd_function_new(&fn,
                                     fn_name,
                                     AMXC_VAR_ID_NULL,
                                     function), goto error);

    ASSERT_SUCCESS(amxd_function_new_arg(fn, CTHULHU_NOTIF_COMMAND_ID, AMXC_VAR_ID_CSTRING, NULL),
                   goto error);
    ASSERT_SUCCESS(amxd_function_arg_is_attr_set(fn, CTHULHU_NOTIF_COMMAND_ID, amxd_aattr_in),
                   goto error);

    rc = amxd_object_add_function(object, fn);
    ASSERT_SUCCESS(rc, goto error);

exit:
    return rc;

error:
    amxd_function_delete(&fn);
    return rc;
}

/**
 * @brief Implement the LocalManagement custom system info.
 *
 * This function constructs a notification message containing the command ID (if available)
 * and the system name, then triggers a signal to notify the caller.
 *
 * @param obj Pointer to the `amxd_object_t` representing the object context.
 * @param func Pointer to the `amxd_function_t` (unused in this function).
 * @param args Pointer to the `amxc_var_t` containing arguments, including the command ID.
 * @param ret Pointer to the `amxc_var_t` for return value (unused in this function).
 * @return `amxd_status_ok` indicating successful execution.
 */
static amxd_status_t lm_info(amxd_object_t* obj,
                             UNUSED amxd_function_t* func,
                             amxc_var_t* args,
                             UNUSED amxc_var_t* ret) {
    lcm_dump_rpc(obj, func, args, NULL);
    const char* command_id = GET_CHAR(args, CTHULHU_NOTIF_COMMAND_ID);
    amxc_var_t argument;

    amxc_var_init(&argument);
    amxc_var_set_type(&argument, AMXC_VAR_ID_HTABLE);

    if(!STRING_EMPTY(command_id)) {
        amxc_var_add_key(cstring_t, &argument, CTHULHU_NOTIF_COMMAND_ID, command_id);
    }
    amxc_var_add_key(cstring_t, &argument, "SystemName", "LocalPolicyManager");
    amxd_object_trigger_signal(amxd_dm_findf(dm, CTHULHU), CTHULHU_NOTIF_LOCALMANAGEMENT_INFO, &argument);

    amxc_var_clean(&argument);
    return amxd_status_ok;
}

/**
 * @brief Implement the LocalManagement custom action list.
 *
 * This function constructs a notification message containing the command ID (if available)
 * and the list of actions, then triggers a signal to notify to the caller.
 *
 * @param obj Pointer to the `amxd_object_t` representing the object context.
 * @param func Pointer to the `amxd_function_t` (unused in this function).
 * @param args Pointer to the `amxc_var_t` containing arguments, including the command ID.
 * @param ret Pointer to the `amxc_var_t` for return value (unused in this function).
 * @return `amxd_status_ok` indicating successful execution.
 */
static amxd_status_t action_ls(amxd_object_t* obj,
                               UNUSED amxd_function_t* func,
                               amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {
    lcm_dump_rpc(obj, func, args, NULL);
    const char* command_id = GET_CHAR(args, CTHULHU_NOTIF_COMMAND_ID);
    send_trigger(NULL, command_id, CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_LIST);
    return amxd_status_ok;
}

/**
 * @brief Initializes the Cthulhu Lpm plugin.
 *
 * Retrieve and save the datamodel pointer for potential future use
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for initialization.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_lpm_init(UNUSED const char* function_name,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    dm = (amxd_dm_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_DATAMODEL);
    prestartup_config = (cthulhu_prestartup_config_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_PRESTART_CONFIG);

    ASSERT_NOT_NULL(dm, return -1);
    ASSERT_NOT_NULL(prestartup_config, return -1);

    register_pcm_functions(CTHULHU_DM_LOCALMANAGEMENT, CTHULHU_CMD_LM_INFO, lm_info);
    register_pcm_functions(CTHULHU_DM_LOCALMANAGEMENT_ACTION, CTHULHU_CMD_LM_ACTION_LS, action_ls);

    return 0;
}

/**
 * @brief prestart hook callback.
 *
 * The LPM callback for the prestart hook,
 * will update the container lists create, remove and update,
 * according the the container update policy
 * The policy will only be applied when cthulhu is started up after upgrade (or after hard reset),
 * but not after each subsequent reboot or restart of the cthulhu services.
 * So only when the ExecutedAfterUpgrade flag is set 0, the main function of this plugin will be executed,
 * and that flag is set to 1 after execution, so it won't be executed again until the next upgrade.
 *
 * @param function_name Name of the function to be used
 * @param args Arguments for lpm_ctr_prestart.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_plugin_odl_loaded(UNUSED const char* function_name,
                              UNUSED amxc_var_t* args,
                              UNUSED amxc_var_t* ret) {

    int res = -1;
    bool executed_after_upgrade = false;
    amxd_object_t* pluginobj = amxd_dm_findf(dm, LPMC);

    ASSERT_NOT_NULL(prestartup_config, goto exit, "prestartup_config not initialized");
    ASSERT_NOT_NULL(dm, goto exit, "dm not initialized");
    ASSERT_NOT_NULL(pluginobj, goto exit, "pluginobj not initialized");

    executed_after_upgrade = amxd_object_get_value(bool, pluginobj, EXECUTEDAFTERUPGRADE, NULL);

    if(!executed_after_upgrade) {
        amxd_trans_t trans;

        ASSERT_SUCCESS(load_policyfile(), goto exit);
        ASSERT_SUCCESS(update_ctr_list(
                           prestartup_config->ctr_create,
                           prestartup_config->ctr_upgrade,
                           prestartup_config->ctr_remove,
                           prestartup_config->image_remove
                           ), goto exit);

        amxd_trans_init(&trans);
        amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
        amxd_trans_select_object(&trans, pluginobj);
        amxd_trans_set_value(bool, &trans, EXECUTEDAFTERUPGRADE, true);
        amxd_status_t status = amxd_trans_apply(&trans, dm);
        amxd_trans_clean(&trans);
        ASSERT_SUCCESS(status, goto exit, "Failed to set %s parameter to true [%d]", EXECUTEDAFTERUPGRADE, status);
    }

    res = 0;
exit:
    return res;
}

int cthulhu_plugin_ctr_postcreate(UNUSED const char* function_name,
                                  amxc_var_t* args,
                                  UNUSED amxc_var_t* ret) {
    const char* ctrid = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    char* uuid = NULL;
    amxd_object_t* obj = amxd_dm_findf(dm, "%s.[%s == \"%s\"]", CTHULHU_DM_CONTAINER_INSTANCES, CTHULHU_CONTAINER_ID, ctrid);
    ASSERT_NOT_NULL(obj, return 0, "Failed to get container object [%s]", ctrid);
    uuid = amxd_object_get_value(cstring_t, obj, CTHULHU_CONTAINER_LINKED_UUID, NULL);
    ASSERT_STR_NOT_EMPTY(uuid, return 0, "Failed to get LinkedUUID [%s]", ctrid);
    change_action_status(dm, uuid, "Success");
    free(uuid);
    return 0;
}

static int register_function(const char* const func_name, amxm_callback_t cb) {
    ASSERT_SUCCESS(amxm_module_add_function(mod, func_name, cb), return -1, "Could not add function [%s]", func_name);
    return 0;
}

AMXM_CONSTRUCTOR module_init(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu lpm constructor");
    int ret = 1;

    so = amxm_so_get_current();
    ASSERT_NOT_NULL(so, goto exit, "Could not get shared object");
    ASSERT_SUCCESS(amxm_module_register(&mod, so, CTHULHU_PLUGIN), goto exit, "Could not register module %s", CTHULHU_PLUGIN);

    /* Init hook */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_INIT, cthulhu_lpm_init), goto exit);

    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_ODL_LOADED, cthulhu_plugin_odl_loaded), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_POSTCREATE, cthulhu_plugin_ctr_postcreate), goto exit);

    ret = 0;
exit:
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu lpm constructor");
    return ret;
}

AMXM_DESTRUCTOR module_exit(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu lpm destructor");
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu lpm destructor");
    return 0;
}
