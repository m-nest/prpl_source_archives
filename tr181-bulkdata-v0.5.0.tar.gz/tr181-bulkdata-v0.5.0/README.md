# tr181-bulkdata

[[_TOC_]]

## Introduction

This is a TR-181 compatible bulkdata collection plug-in developed in Ambiorix.

## Building, installing, running and testing

### Docker container

You could install all tools needed for testing and developing on your local machine, but it is easier to just use a pre-configured environment. Such an environment is already prepared for you as a docker container.

Refer to the [Ambiorix getting-started guide](https://gitlab.com/prpl-foundation/components/ambiorix/tutorials/getting-started) to see how your environment can be set up.

### Building

#### Prerequisites

- [libamxc](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxc)
- [libamxj](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxj)
- [libamxp](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxp)
- [libamxd](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxd)
- [libamxb](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxb)
- [libamxo](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxo)
- [libimtp](https://gitlab.com/soft.at.home/usp/libraries/libimtp)
- [libsahtrace](https://gitlab.com/soft.at.home/network/libsahtrace)

#### Building tr181-bulkdata

1. Clone the git repository

    To be able to build it, you need the source code. So open the desired target directory and clone the application.

    ```bash
    mkdir ~/workspace/amx/plugins
    cd ~/workspace/amx/plugins
    git clone git@gitlab.com:https://gitlab.softathome.com/ext_prpl/components/tr181-bulkdata.git
    ``` 

1. Install dependencies

    Although the container will contain all tools needed for building, it does not contain the libraries needed for building the `tr181-bulkdata`. To be able to build the `tr181-bulkdata` you need `libamxc`, `libamxp`, `libamxj`, `libamxd`, `libamxb`, `libamxo`, `libimpt` and `libsahtrace`. These libraries can be installed in the container by executing the following commands. 

    ```bash
    sudo apt update
    sudo apt install libamxc libamxp libamxj libamxd libamxb libamxo libimtp sah-lib-sahtrace-dev
    ```

1. Build it

    ```bash
    cd ~/workspace/amx/plugins/tr181-bulkdata
    make
    ```

### Installing

#### Using make target install

You can use the install target in the makefile to install the plugin

```bash
cd ~/workspace/amx/plugins/tr181-bulkdata
sudo -E make install
```

#### Using package

From within the container you can create packages.

```bash
cd ~/workspace/amx/plugins/tr181-bulkdata
make package
```

The packages generated are:

```
~/workspace/amx/plugins/tr181-bulkdata/tr181-bulkdata-<VERSION>.tar.gz
~/workspace/amx/plugins/tr181-bulkdata/tr181-bulkdata-<VERSION>.deb
```

You can copy these packages and extract/install them.

For ubuntu or debian distributions use dpkg:

```bash
sudo dpkg -i ~/workspace/amx/plugins/tr181-bulkdata/tr181-bulkdata-<VERSION>.deb
```

### Running

#### Run time prerequisites

- [amxrt](https://gitlab.com/prpl-foundation/components/ambiorix/plugins/amxrt)
- [mod-dmext](https://gitlab.com/prpl-foundation/components/core/modules/mod_dmext)
- [mod-amxb-usp](https://gitlab.com/prpl-foundation/components/ambiorix/modules/amxb_backends/amxb_usp)
- [tr181-mqtt](https://gitlab.com/prpl-foundation/components/core/plugins/tr181-mqtt) (when using the MQTT profile)
- [mod-sahtrace](https://gitlab.com/prpl-foundation/components/core/modules/mod_sahtrace) (optional)

This plugin runs with `amxrt` like most ambiorix plugins. It also uses `mod-dmext` to check the validity of a few data model parameters. To publish messages with the MQTT protocol, it uses the `USP backend` to communicate with `tr181-mqtt` client. For logging it loads the `sahtrace` module at run time if it is available. When it is not available, it will not be loaded.

These tools can be installed from debian packages.

```bash
sudo apt install amxrt mod-dmext mod-amxb-usp tr181-mqtt mod-sahtrace
```

#### Running tr181-bulkdata

During installation of tr181-bulkdata a symbolic link is created to amxrt:

```text
/usr/bin/tr181-bulkdata -> /usr/bin/amxrt
```

This allows you to run the plugin using the `tr181-bulkdata` command. `amxrt` will find the relevant odl files in `/etc/amx/tr181-bulkdata`.

If you want to use MQTT as the communication protocol to publish bulkdata reports, make sure that `tr181-mqtt` is running first. You can use the following commands to run both plugins daemonized

```bash
tr181-mqtt -D
tr181-bulkdata -D
```

You may need to run them with sudo privileges depending on your setup.

### Testing

#### Run tests

1. Install dependencies

    No extra dependencies are needed for testing the `tr181-bulkdata`.

1. Run tests

    You can run the tests by executing the following command.
    
    ```bash
    cd ~/workspace/amx/plugins/tr181-bulkdata/test
    make
    ```
    
    Or this command if you also want the coverage tests to run:
    
    ```bash
    cd ~/workspace/amx/plugins/tr181-bulkdata/test
    make run coverage
    ```
    
    Or from the root directory of this repository,
    
    ```bash
    cd ~/workspace/amx/plugins/tr181-bulkdata
    make test
    ```
    
    This last will run the unit-tests and generate the test coverage reports in one go.

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each file (*.c file) is printed in your console after the tests are run.
A HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used.
Example: using native gcc
When the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/workspace/amx/plugins/tr181-bulkdata/output/x86_64-linux-gnu/coverage/report.`

You can easily access the reports in your browser.
In the container start a python3 http server in background.

```bash
cd ~/workspace/
python3 -m http.server 8080 &
```

Use the following url to access the reports `http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-bulkdata/output/<MACHINE>/coverage/report`
You can find the ip address of your container by using the `ip` command in the container.

Example:

```bash
USER@<CID>:~/amx/plugins/tr181-bulkdata$ ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
173: eth0@if174: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether 02:42:ac:11:00:07 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet 172.17.0.7/16 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 2001:db8:1::242:ac11:7/64 scope global nodad 
       valid_lft forever preferred_lft forever
    inet6 fe80::42:acff:fe11:7/64 scope link 
       valid_lft forever preferred_lft forever
```

In this case the IP address of the container is `172.17.0.7`.
So the uri you should use is: `http://172.17.0.7:8080/amx/plugins/tr181-bulkdata/output/x86_64-linux-gnu/coverage/report/`


## Example of profiles
In this section, we will provide some example of `http` and `mqtt` profiles.

### Bulkdata Configuration
**1. Time synchronization**
Check the prameter `needs-time-sync` located on the configuration section of the module.
if the value is `True` then to start the bulkdata correctely:
- We must start the `Time` plugin.
- Make sure that the time is synchronized.

Please note if, you want to check the configuration parameters of the plugin please use the option `-d` when starting it.
Example:
```
sudo tr181-bulkdata -d
INFO -- Load - Failed to load /etc/config/tr181-bulkdata//odl or directory is empty
INFO -- Load - Try to load default from tr181-bulkdata_defaults/

Configuration:
{
    auto-connect = true,
    auto-detect = true,
    auto-resolver-order = [
        "import",
        "*"
    ],
    needs-time-sync = false,
    ...
}
```

**2. Enable the Bulkdata plugin**
Enable the bulkdata plugin
```
BulkData.Enable=1
```

### HTTP Profile
### HTTP Profile to send JSON report
**1. Add the http profile**
```
BulkData.Profile.+{Alias="http-json", EncodingType="JSON", Name="http-json", Protocol="HTTP", Enable="false", ReportingInterval = 30}
```
In this case, according to parameter `ReportingInterval`, this profile will be triggered each 30 seconds.

***The documentation of the DM parameters is available in this link: [Device.BulkData.Profile.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.BulkData.Profile.)***

****2. Update the http object****
```
BulkData.Profile.http-json.HTTP.URL="https://postman-echo.com/post/"
BulkData.Profile.http-json.HTTP.Method="POST"
BulkData.Profile.http-json.HTTP.UseDateHeader=1
```

**3. Update the JSON object**
```
BulkData.Profile.http-json.JSONEncoding.ReportFormat="ObjectHierarchy"
BulkData.Profile.http-json.JSONEncoding.ReportTimestamp="Unix-Epoch"
```

**4. Add parameter to be sent in the report**
```
BulkData.Profile.http-json.Parameter.+{Name="Contacts", Reference="Phonebook.Contact."}
```

**5. Example of traces of sent report**

After configuring the profile, enable it
```
BulkData.Profile.http-json.Enable="true"
```

**5.1. Traces**
```
Mar 23 15:18:08 0914faeadcbe ba-cli: > BulkData.Profile.http-json.Enable="true"
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: profile - [i]Start profile http-json - (bulkdata_start_profile@bulkdata_profile.c:357)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
Mar 23 15:18:08 0914faeadcbe ba-cli: > BulkData.Profile.http-json.Enable="true"
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-json - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-json - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:08 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:09 0914faeadcbe tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http-json' - (response_cb@bulkdata_profile_http.c:205)
Mar 23 15:18:09 0914faeadcbe tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http-json' - (response_cb@bulkdata_profile_http.c:205)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-json - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-json - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 2 - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:124)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:138)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:142)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:166)
Mar 23 15:18:38 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_json@bulkdata_profile_parameter.c:152)
Mar 23 15:18:39 0914faeadcbe tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http-json' - (response_cb@bulkdata_profile_http.c:205)
```

**5.2. Sent report**
```
{
  "args": {},
  "data": "",
  "files": {},
  "form": {
    "{\"Report\":[{\"Contacts\":{\"1\":{\"LastName\":\"Bond\",\"FirstName\":\"James\"}},\"CollectionTime\":\"1742743118947\"}]}": ""
  },
  "headers": {
    "host": "postman-echo.com",
    "x-request-start": "t1742743119.701",
    "connection": "close",
    "content-length": "104",
    "x-forwarded-proto": "https",
    "x-forwarded-port": "443",
    "x-amzn-trace-id": "Root=1-67e0264f-4eebab9512f52ba34113dd96",
    "accept": "*/*",
    "date": "Sun, 23 Mar 2025 15:18:38 GMT",
    "bbf-report-format": "ObjectHierarchy",
    "content-type": "application/x-www-form-urlencoded"
  },
  "json": {
    "{\"Report\":[{\"Contacts\":{\"1\":{\"LastName\":\"Bond\",\"FirstName\":\"James\"}},\"CollectionTime\":\"1742743118947\"}]}": ""
  },
  "url": "https://postman-echo.com/post/"
}
```

### HTTP Profile to send CSV report
**1. Add the http profile**
```
BulkData.Profile.+{Alias="http-csv", EncodingType="CSV", Name="http-csv", Protocol="HTTP", Enable="false", ReportingInterval = 10}
```

**2. Update the http object**
```
BulkData.Profile.http-csv.HTTP.URL="https://postman-echo.com/post/"
BulkData.Profile.http-csv.HTTP.Method="POST"
BulkData.Profile.http-csv.HTTP.UseDateHeader=1
```

**3. Update the CSV object**
```
BulkData.Profile.http-csv.CSVEncoding.EscapeCharacter="&quot"
BulkData.Profile.http-csv.CSVEncoding.FieldSeparator=","
BulkData.Profile.http-csv.CSVEncoding.ReportFormat="ParameterPerRow"
BulkData.Profile.http-csv.CSVEncoding.RowSeparator="&#13;&#10;"
BulkData.Profile.http-csv.CSVEncoding.RowTimestamp="Unix-Epoch"
```

**4. Add parameter to be sent in the report**
```
BulkData.Profile.http-csv.Parameter.+{Name="Contacts", Reference="Phonebook.Contact."}
```

**5. Example of traces of sent report**

After configuring the profile, enable it
```
BulkData.Profile.http-csv.Enable="true"
```

**5.1. Traces**
```
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Start profile http-csv - (bulkdata_start_profile@bulkdata_profile.c:357)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: events  - [i]Enable changed from "0" to "1" - (_bulkdata_profile_enable_changed@dm_bulkdata_events.c:126)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Start profile http-csv - (bulkdata_start_profile@bulkdata_profile.c:357)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Undefined time, return 0 - (bulkdata_compute_timeout@bulkdata_profile.c:315)
Mar 23 15:37:34 0914faeadcbe ba-cli: > BulkData.Profile.http-csv.Enable="true"
Mar 23 15:37:34 0914faeadcbe ba-cli: > BulkData.Profile.http-csv.Enable="true"
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-csv - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:181)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:196)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:200)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: profile - [i]Collect profile http-csv - (bulkdata_profile_collect@bulkdata_profile.c:284)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameters - (bulkdata_retrieve_parameters@bulkdata_profile_parameter.c:263)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Start listening parameter 1 - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:181)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]root_object = Phonebook - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:196)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Bus ctx is not null - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:200)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond | string - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James | string - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact.1. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.LastName = Bond | string - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]Contacts.1.FirstName = James | string - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:227)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: paramet - [i]key = Phonebook.Contact. - (bulkdata_retrieve_parameter_csv@bulkdata_profile_parameter.c:208)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: csv_enc - [i]#011#011 Contacts.1.FirstName  | James  | string - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: csv_enc - [i]#011#011 Contacts.1.LastName  | Bond  | string - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: csv_enc - [i]#011#011 Contacts.1.FirstName  | James  | string - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
Mar 23 15:37:34 0914faeadcbe tr181-bulkdata: csv_enc - [i]#011#011 Contacts.1.LastName  | Bond  | string - (bulkdata_convert_to_ParameterPerRow_data@bulkdata_profile_csv_encoding.c:190)
Mar 23 15:37:35 0914faeadcbe tr181-bulkdata: http    - [i]http request sent successfully for profile 'BulkData.Profile.http-csv' - (response_cb@bulkdata_profile_http.c:205)
```

**5.2. Sent report**
```
{
  "args": {},
  "data": "",
  "files": {},
  "form": {
    "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n,1742744254675,Contacts.1.FirstName,James,string\r\n,1742744254675,Contacts.1.LastName,Bond,string\r\n": ""
  },
  "headers": {
    "host": "postman-echo.com",
    "x-request-start": "t1742744255.424",
    "connection": "close",
    "content-length": "158",
    "x-forwarded-proto": "https",
    "x-forwarded-port": "443",
    "x-amzn-trace-id": "Root=1-67e02abf-34fc93ac152ab10e1e72b1b4",
    "accept": "*/*",
    "date": "Sun, 23 Mar 2025 15:37:34 GMT",
    "bbf-report-format": "ParameterPerRow",
    "content-type": "application/x-www-form-urlencoded"
  },
  "json": {
    "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n,1742744254675,Contacts.1.FirstName,James,string\r\n,1742744254675,Contacts.1.LastName,Bond,string\r\n": ""
  },
  "url": "https://postman-echo.com/post/"
}
```
### MQTT Profile
**1. Add the mqtt profile**
```
BulkData.Profile.+{Alias="mqtt-json", EncodingType="JSON", Name="mqtt-json", Protocol="USPEventNotif", Enable="false", ReportingInterval = 10}
```

**2. Update the JSON object**
```
BulkData.Profile.mqtt-json.JSONEncoding.ReportFormat="ObjectHierarchy"
BulkData.Profile.mqtt-json.JSONEncoding.ReportTimestamp="Unix-Epoch"
```

**3. Add parameter to be sent in the report**
```
BulkData.Profile.mqtt-json.Parameter.+{Name="Contacts", Reference="Phonebook.Contact."}
```

**4. Example of traces of sent report**

After configuring the profile, enable it
```
BulkData.Profile.mqtt-json.Enable="true"
```

**5. Sent report**
```
[2025-03-23T17:09:12Z] Event Push! received from BulkData.Profile.7.
{
    data = {
        Data = "{"Report":[{"CollectionTime":"1742749752459","Contacts":{"1":{"LastName":"Bond","FirstName":"James"}}}]}"
    },
    eobject = "BulkData.Profile.[mqtt-json].",
    notification = "Push!",
    object = "BulkData.Profile.mqtt-json.",
    path = "BulkData.Profile.7."
}
```
