Kernel Fault Monitor
============

# Requirements

## Introduction and High-Level Description

Monitoring the stability and reliability of a Linux-based system is crucial for effective system administration and development. Two key components of this monitoring are the observation of kernel-level errors, known as "oopses," and the tracking of process faults within applications. These practices are essential for diagnosing and addressing issues that may compromise system integrity.

Understanding and monitoring kernel-level "oopses" help identify critical errors and bugs within the Linux kernel, which can lead to system instability. Capturing detailed error messages, analyzing root causes, and utilizing debugging tools are vital for effective resolution. An "oops" in the Linux kernel signifies a critical error that the kernel cannot recover from. When this occurs, the kernel generates an "oops message," which provides information about the error, the system state at the time, and a stack trace of function calls leading to the error.

A significant challenge is that kernel errors often result in system reboots, making it difficult to retrieve relevant information. To address this, the solution leverages the standard kernel ramoops feature, enabling the retrieval of kernel logs prior to the fault and reboot, thereby facilitating better analysis and troubleshooting.


## References

* linux ramoops: [https://www.kernel.org/doc/html/v5.1/admin-guide/ramoops.html](https://www.kernel.org/doc/html/v5.1/admin-guide/ramoops.html)  
* linux pstore: [https://www.kernel.org/doc/Documentation/ABI/testing/pstore](https://www.kernel.org/doc/Documentation/ABI/testing/pstore)  
* TR181 BBF datamodel `Device.DeviceInfo.KernelFaults.`: [https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.KernelFaults.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.KernelFaults.)  
* oopsmonitor implementation in gitlab: [https://gitlab.com/prpl-foundation/components/core/plugins/oopsmonitor](https://gitlab.com/prpl-foundation/components/core/plugins/oopsmonitor)

# Architecture

![oopsMonitor architecture](image/oopsmonitorArchitecture.png)

# Implementation

The implementation of this solution is designed as a standard Ambiorix plugin, leveraging the kernel's ramoops and platform store features. Upon startup, the plugin scans the pstore path to retrieve any kernel logs from the previous boot. If any kernel logs are found, they are moved to the designated plugin storage path for further analysis.  
Additionally, the data model is updated accordingly to reflect the newly retrieved logs, ensuring that all relevant information is readily accessible for troubleshooting and monitoring purposes.  
To manage storage effectively, a `MaxKernelFaultEntries` parameter is included in the data model, capping the number of fault entries stored and preventing excessive data accumulation.  
As ramoops logs are retrieved on startup, it is expected that `panic_on_oops` kernel feature is enabled for oops to be retrieved and exposed in the datamodel.

In the event that the pstore is not mounted by the system, the initialization script of the component will automatically handle this situation. The script checks for the presence of the pstore mount and, if necessary, performs the required steps to mount it.

Ramoops is an oops/panic logger that writes its logs to RAM before the system crashes. It works by logging oopses and panics in a circular buffer. Ramoops needs a system with persistent RAM so that the content of that area can survive after a restart.

## Data Model

Plugin is using standard datamodel defined here :[https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.KernelFaults.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.KernelFaults.)

## Low-Level API

KernelFault feature is relying on standard kernel ramoops feature.

## Files

Plugin default configuration is done through odl in `/etc/amx/oopsmonitor/` path.

Collected logs are stored in a path defined by `ramoops_path` configuration in the main odl.


## Dependants and Dependencies

### Dependants

none.

### Dependencies

KernelFault depends on the following libraries:

* **libsahtrace** is used for debugging traces  
* **mod-dmext** is used for the regexp function in the odl file  
* **libfiletransfer** is used for the transfer of the fault

FaultMonitor is an Ambiorix application and as such it has the following dependencies on Ambiorix libraries:

* **libamxb**  
* **libamxc**  
* **libamxd**  
* **libamxo**  
* **libamxp**  
* **libamxm**

It also depends on ramoops feature being enabled at kernel/system level:

* kernel configuration must be set : `CONFIG_PSTORE_RAM=y` (implies also `CONFIG_PSTORE=y`)  
* a `ramoops` reserved-memory region must be defined in kernel device-tree so dmesg information can be stored over reboots.  
* the reserved-memory region needs to persist over reboot (not being erased by early stage bootloaders)

## Configuration

### component configuration

`ramoops_path` parameter, defined in main odl `oopsmonitor.odl`, is used to specify where information collected from ramoops pstore must be kept.

### kernel sysctl configuration

As Kernel fault merely retrieve information logged on oops and panic, it is important that proper kernel configuration is enabled to allow investigation. Note that it is leaved up to each specific integrator to assess if options would be suitable for a production environment.

Hereafter is a list of recommended default kernel configuration:

* `CONFIG_PANIC_ON_OOPS=y`: force a panic reboot when a oops occur  
* `sysctl.kernel.panic_on_rcu_stall=1`: allow to reboot when a RCU stall occurs

Additional debug information can help further debug but might pose security risks in production

* `DEBUG_BUGVERBOSE=y`: make BUG() panics output the file name and line number of the BUG call as well as the EIP and oops trace.  
* `CONFIG_RANDOMIZE_BASE=n`: disable kernel ASLR to make base address identification easier. unsecure option as it allow easier exploits.

One may want to look at the panic section of [https://www.kernel.org/doc/Documentation/admin-guide/sysctl/kernel.rst](https://www.kernel.org/doc/Documentation/admin-guide/sysctl/kernel.rst) to further fine tune what cause panic and which information are displayed.

## Backup/Restore, Upgrade, Reset

Logs retrieved from pstore are kept in path defined by `ramoops_path` over reboot. They are used to repopulate datamodel on each startup of the process.

Those logs are not upgrade persistent as the information is considered relevant only for the currently running firmware version.

Writeable parameters are also reboot persistent.

# Considerations


## Security

Kernel logs may contain privacy-sensitive and security-sensitive, information. The privacy-sensitive aspects may be subject to legal and regulatory rules, in addition to internal rules within the Operator.

## Remote Management

`Upload()` TR181 command can be used to upload a specific kernel log information to a remote http server.


## Unit Tests

Unit tests are implemented here: [https://gitlab.com/prpl-foundation/components/core/plugins/oopsmonitor/-/tree/main/test?ref\_type=heads](https://gitlab.com/prpl-foundation/components/core/plugins/oopsmonitor/-/tree/main/test?ref_type=heads)

## Logging and Debugging

Plugin provides only a single tracezone `oopsmonitor` for debugging purpose.

## Functional Tests

| Test step | Tested feature | Test commands and output |
| :---- | :---- | :---- |
| 1 | Oops instance should be added after kernel oops: check datamodel prior to test trigger a kernel crash (use /proc/sysrq-trigger) after CPE reboot check a new fault entry is populated | `root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=0 KernelFaults.LastUpgradeCount=0 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=0 KernelFaults.StoragePath="/data/oops" root@prplOS:/# ls -l /data/oopsls: /data/oops: No such file or directory # cause kernel oops with "echo c > /proc/sysrq-trigger" ( board will reboot ) root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=1 KernelFaults.LastUpgradeCount=1 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=1 KernelFaults.StoragePath="/data/oops" KernelFaults.KernelFault.1. KernelFaults.KernelFault.1.Alias="cpe-KernelFault-1" KernelFaults.KernelFault.1.FaultLocation="dmesg-ramoops-0" KernelFaults.KernelFault.1.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.1.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.1.ProcessName="ash" KernelFaults.KernelFault.1.Reason="SysRq triggered crash" KernelFaults.KernelFault.1.TimeStamp="2024-09-30T18:51:09Z" root@prplOS:/# dateMon Sep 30 18:55:00 UTC 2024root@prplOS:/# ls /data/oops/dmesg-ramoops-0` |
| 2 | No new oops instances aren't added if limit is reached | `root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=5 KernelFaults.LastUpgradeCount=5 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=1 KernelFaults.StoragePath="/data/oops" KernelFaults.KernelFault.1. KernelFaults.KernelFault.1.Alias="cpe-KernelFault-1" KernelFaults.KernelFault.1.FaultLocation="dmesg-ramoops-0" KernelFaults.KernelFault.1.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.1.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.1.ProcessName="ash" KernelFaults.KernelFault.1.Reason="SysRq triggered crash" KernelFaults.KernelFault.1.TimeStamp="2024-09-30T18:51:09Z" KernelFaults.KernelFault.2. KernelFaults.KernelFault.2.Alias="cpe-KernelFault-2" KernelFaults.KernelFault.2.FaultLocation="dmesg-ramoops-1" KernelFaults.KernelFault.2.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.2.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.2.ProcessName="ash" KernelFaults.KernelFault.2.Reason="SysRq triggered crash" KernelFaults.KernelFault.2.TimeStamp="2024-09-30T18:56:17Z" KernelFaults.KernelFault.3. KernelFaults.KernelFault.3.Alias="cpe-KernelFault-3" KernelFaults.KernelFault.3.FaultLocation="dmesg-ramoops-2" KernelFaults.KernelFault.3.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.3.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.3.ProcessName="ash" KernelFaults.KernelFault.3.Reason="SysRq triggered crash" KernelFaults.KernelFault.3.TimeStamp="2024-09-30T19:02:02Z" KernelFaults.KernelFault.4. KernelFaults.KernelFault.4.Alias="cpe-KernelFault-4" KernelFaults.KernelFault.4.FaultLocation="dmesg-ramoops-3" KernelFaults.KernelFault.4.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.4.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.4.ProcessName="ash" KernelFaults.KernelFault.4.Reason="SysRq triggered crash" KernelFaults.KernelFault.4.TimeStamp="2024-09-30T19:02:47Z" KernelFaults.KernelFault.5. KernelFaults.KernelFault.5.Alias="cpe-KernelFault-5" KernelFaults.KernelFault.5.FaultLocation="dmesg-ramoops-4" KernelFaults.KernelFault.5.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.5.LastInstruction="0x0082ee40\n" KernelFaults.KernelFault.5.ProcessName="ash" KernelFaults.KernelFault.5.Reason="SysRq triggered crash" KernelFaults.KernelFault.5.TimeStamp="2024-09-30T19:06:57Z" root@prplOS:/# ls /data/oops/dmesg-ramoops-0  dmesg-ramoops-2  dmesg-ramoops-4dmesg-ramoops-1  dmesg-ramoops-3` \# causing another kernel oops with "echo c \> /proc/sysrq-trigger" `root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=5 KernelFaults.LastUpgradeCount=6 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=1 KernelFaults.StoragePath="/data/oops" KernelFaults.KernelFault.1. KernelFaults.KernelFault.1.Alias="cpe-KernelFault-1" KernelFaults.KernelFault.1.FaultLocation="dmesg-ramoops-0" KernelFaults.KernelFault.1.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.1.LastInstruction="Unknown" KernelFaults.KernelFault.1.ProcessName="Unknown" KernelFaults.KernelFault.1.Reason="Unknown" KernelFaults.KernelFault.1.TimeStamp="2024-09-30T18:51:09Z" KernelFaults.KernelFault.2. KernelFaults.KernelFault.2.Alias="cpe-KernelFault-2" KernelFaults.KernelFault.2.FaultLocation="dmesg-ramoops-1" KernelFaults.KernelFault.2.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.2.LastInstruction="Unknown" KernelFaults.KernelFault.2.ProcessName="Unknown" KernelFaults.KernelFault.2.Reason="Unknown" KernelFaults.KernelFault.2.TimeStamp="2024-09-30T18:56:17Z" KernelFaults.KernelFault.3. KernelFaults.KernelFault.3.Alias="cpe-KernelFault-3" KernelFaults.KernelFault.3.FaultLocation="dmesg-ramoops-2" KernelFaults.KernelFault.3.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.3.LastInstruction="Unknown" KernelFaults.KernelFault.3.ProcessName="Unknown" KernelFaults.KernelFault.3.Reason="Unknown" KernelFaults.KernelFault.3.TimeStamp="2024-09-30T19:02:02Z" KernelFaults.KernelFault.4. KernelFaults.KernelFault.4.Alias="cpe-KernelFault-4" KernelFaults.KernelFault.4.FaultLocation="dmesg-ramoops-3" KernelFaults.KernelFault.4.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.4.LastInstruction="Unknown" KernelFaults.KernelFault.4.ProcessName="Unknown" KernelFaults.KernelFault.4.Reason="Unknown" KernelFaults.KernelFault.4.TimeStamp="2024-09-30T19:02:47Z" KernelFaults.KernelFault.5. KernelFaults.KernelFault.5.Alias="cpe-KernelFault-5" KernelFaults.KernelFault.5.FaultLocation="dmesg-ramoops-4" KernelFaults.KernelFault.5.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.5.LastInstruction="Unknown" KernelFaults.KernelFault.5.ProcessName="Unknown" KernelFaults.KernelFault.5.Reason="Unknown" KernelFaults.KernelFault.5.TimeStamp="2024-09-30T19:06:57Z" root@prplOS:/# ls /data/oops/dmesg-ramoops-0  dmesg-ramoops-2  dmesg-ramoops-4dmesg-ramoops-1  dmesg-ramoops-3` |
| 3 | RemoveOopses call removes all instances and ramoops files stored | `root@prplOS:/# ls /data/oops/dmesg-ramoops-0  dmesg-ramoops-2  dmesg-ramoops-4dmesg-ramoops-1  dmesg-ramoops-3root@prplOS:/# ubus-cli Copyright (c) 2020 - 2023 SoftAtHomeamxcli version : 0.2.25 !amx silent true                    _  ___  ____  _ __  _ __ _ __ | |/ _ \/ ___| | '_ \| '__| '_ \| | | | \___ \ | |_) | |  | |_) | | |_| |___) | | .__/|_|  | .__/|_|\___/|____/ |_|        |_| based on OpenWrt ----------------------------------------------------- ubus - cli ----------------------------------------------------- root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=5 KernelFaults.LastUpgradeCount=6 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=1 KernelFaults.StoragePath="/data/oops" KernelFaults.KernelFault.1. KernelFaults.KernelFault.1.Alias="cpe-KernelFault-1" KernelFaults.KernelFault.1.FaultLocation="dmesg-ramoops-0" KernelFaults.KernelFault.1.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.1.LastInstruction="Unknown" KernelFaults.KernelFault.1.ProcessName="Unknown" KernelFaults.KernelFault.1.Reason="Unknown" KernelFaults.KernelFault.1.TimeStamp="2024-09-30T18:51:09Z" KernelFaults.KernelFault.2. KernelFaults.KernelFault.2.Alias="cpe-KernelFault-2" KernelFaults.KernelFault.2.FaultLocation="dmesg-ramoops-1" KernelFaults.KernelFault.2.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.2.LastInstruction="Unknown" KernelFaults.KernelFault.2.ProcessName="Unknown" KernelFaults.KernelFault.2.Reason="Unknown" KernelFaults.KernelFault.2.TimeStamp="2024-09-30T18:56:17Z" KernelFaults.KernelFault.3. KernelFaults.KernelFault.3.Alias="cpe-KernelFault-3" KernelFaults.KernelFault.3.FaultLocation="dmesg-ramoops-2" KernelFaults.KernelFault.3.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.3.LastInstruction="Unknown" KernelFaults.KernelFault.3.ProcessName="Unknown" KernelFaults.KernelFault.3.Reason="Unknown" KernelFaults.KernelFault.3.TimeStamp="2024-09-30T19:02:02Z" KernelFaults.KernelFault.4. KernelFaults.KernelFault.4.Alias="cpe-KernelFault-4" KernelFaults.KernelFault.4.FaultLocation="dmesg-ramoops-3" KernelFaults.KernelFault.4.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.4.LastInstruction="Unknown" KernelFaults.KernelFault.4.ProcessName="Unknown" KernelFaults.KernelFault.4.Reason="Unknown" KernelFaults.KernelFault.4.TimeStamp="2024-09-30T19:02:47Z" KernelFaults.KernelFault.5. KernelFaults.KernelFault.5.Alias="cpe-KernelFault-5" KernelFaults.KernelFault.5.FaultLocation="dmesg-ramoops-4" KernelFaults.KernelFault.5.FirmwareVersion="0.10.74998" KernelFaults.KernelFault.5.LastInstruction="Unknown" KernelFaults.KernelFault.5.ProcessName="Unknown" KernelFaults.KernelFault.5.Reason="Unknown" KernelFaults.KernelFault.5.TimeStamp="2024-09-30T19:06:57Z" root - ubus: - [ubus-cli] (0)  > KernelFaults.RemoveAllKernelFaults() KernelFaults.RemoveAllKernelFaults() returned [     "" ] root - ubus: - [ubus-cli] (0)  > KernelFaults.? KernelFaults. KernelFaults.KernelFaultNumberOfEntries=0 KernelFaults.LastUpgradeCount=6 KernelFaults.MaxKernelFaultEntries=5 KernelFaults.MinFreeSpace=3000 KernelFaults.PreviousBootCount=1 KernelFaults.StoragePath="/data/oops" ubus: - [ubus-cli] (0)  > exit> !amx exit ubus: - [ubus-cli] (0)  > root@prplOS:/# ls /data/oops/root@prplOS:/#`  |


   
