/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "flash_health.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "dm_flash_health.h"

#define ME "usage"

/**
 * @brief Retrieves eMMC usage parameters from the flash health object.
 *
 * This function handles read access to various eMMC-related parameters such as
 * LifeTimeA, LifeTimeB, their hexadecimal representations, and Pre-EOL information.
 *
 * @param[in] object     The AMXD object representing the eMMC device.
 * @param[in] param      The parameter being accessed.
 * @param[in] reason     The reason for the action (only supports read).
 * @param[in] args       Unused arguments.
 * @param[out] retval    The variable to store the result.
 * @param[in] priv       Unused private data.
 *
 * @return amxd_status_t Returns the status of the operation:
 *                       - amxd_status_ok on success
 *                       - amxd_status_function_not_implemented if not a read
 *                       - amxd_status_unknown_error on failure
 */
amxd_status_t _emmc_usage(UNUSED amxd_object_t* object,
                          amxd_param_t* param,
                          amxd_action_t reason,
                          UNUSED const amxc_var_t* const args,
                          amxc_var_t* const retval,
                          UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    const char* param_name;
    amxd_object_t* flash_device = NULL;
    flash_health_t* fh = NULL;

    when_null(param, exit);
    when_null(object, exit);

    flash_device = amxd_object_get_parent(object);
    when_null(flash_device->priv, exit);
    fh = (flash_health_t*) flash_device->priv;
    when_null(fh, exit);

    if(reason != action_param_read) {
        status = amxd_status_function_not_implemented;
        goto exit;
    }
    param_name = amxd_param_get_name(param);
    if(!strcmp(param_name, DM_LIFETIMEA)) {
        amxc_var_set(cstring_t, retval, fh->lifeTimeA);
    } else if(!strcmp(param_name, DM_LIFETIMEB)) {
        amxc_var_set(cstring_t, retval, fh->lifeTimeB);
    } else if(!strcmp(param_name, DM_LIFETIMEAHEX)) {
        amxc_var_set(uint32_t, retval, fh->lifeTimeAHex);
    } else if(!strcmp(param_name, DM_LIFETIMEBHEX)) {
        amxc_var_set(uint32_t, retval, fh->lifeTimeBHex);
    } else if(!strcmp(param_name, DM_PREEOLINFO)) {
        amxc_var_set(cstring_t, retval, fh->emmcPreEolInfo);
    } else {
        SAH_TRACEZ_ERROR(ME, "No Key set");
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
 * @brief Retrieves NAND usage statistics from the flash health object.
 *
 * This function handles read access to NAND-related parameters such as
 * TotalGoodBlocks and TotalBadBlocks.
 *
 * @param[in] object     The AMXD object representing the NAND device.
 * @param[in] param      The parameter being accessed.
 * @param[in] reason     The reason for the action (only supports read).
 * @param[in] args       Unused arguments.
 * @param[out] retval    The variable to store the result.
 * @param[in] priv       Unused private data.
 *
 * @return amxd_status_t Returns the status of the operation:
 *                       - amxd_status_ok on success
 *                       - amxd_status_function_not_implemented if not a read
 *                       - amxd_status_unknown_error on failure
 */
amxd_status_t _nand_usage(UNUSED amxd_object_t* object,
                          amxd_param_t* param,
                          amxd_action_t reason,
                          UNUSED const amxc_var_t* const args,
                          amxc_var_t* const retval,
                          UNUSED void* priv) {

    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    const char* param_name;
    amxd_object_t* flash_device = NULL;
    flash_health_t* fh = NULL;

    when_null(param, exit);
    when_null(object, exit);

    flash_device = amxd_object_get_parent(object);
    when_null(flash_device->priv, exit);
    fh = (flash_health_t*) flash_device->priv;
    when_null(fh, exit);

    if(reason != action_param_read) {
        status = amxd_status_function_not_implemented;
        goto exit;
    }
    param_name = amxd_param_get_name(param);

    if(!strcmp(param_name, "TotalGoodBlocks")) {
        amxc_var_set(uint32_t, retval, fh->totalGoodBlocks);
    } else if(!strcmp(param_name, "TotalBadBlocks")) {
        amxc_var_set(uint32_t, retval, fh->totalBadBlocks);
    } else {
        SAH_TRACEZ_ERROR(ME, "No Key set");
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return status;

}
