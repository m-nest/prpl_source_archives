/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__TR181_TEMPERATURE_H__)
#define __TR181_TEMPERATURE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <regex.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <sys/stat.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_dir.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>

#define str_empty(txt) ((txt == NULL) || (*txt == 0))

#define TEMPSTATUS_TR181_PATH "TemperatureStatus."
#define TEMPSENSOR_TR181_PATH TEMPSTATUS_TR181_PATH "TemperatureSensor"

#define TEMPSENSOR_ST_DISABLED "Disabled"
#define TEMPSENSOR_ST_ENABLED "Enabled"
#define TEMPSENSOR_ST_ERROR "Error"

#define TEMP_VAL "temp"
#define HWMON_TEMP_VAL "temp[0-9]+_input"
#define HWMON_STR_VAL "hwmon[0-9]+/temp[0-9]+_input"

typedef struct {
    char* name;
    char* hwmon_name;
    char* hwmon_complete_sensor_path;
    bool hwmon_dev;
    bool enabled;
    bool err;

    amxp_timer_t* polling_timer;
    uint32_t polling_interval;
    uint32_t def_polling_interval;
    int32_t scaling_parameter;      // Unsigned content but signed type as it has to be multiplied to signed values too.
    uint32_t polling_retry_count;   // number of polling retry attempts, before going to error state

    int32_t value;
    amxc_ts_t last_update;
    amxc_ts_t reset_time;

    int32_t min_value;
    amxc_ts_t min_time;

    int32_t max_value;
    amxc_ts_t max_time;

    int32_t low_alarm_value;
    amxc_ts_t low_alarm_time;
    bool low_alarm_set;

    int32_t high_alarm_value;
    amxc_ts_t high_alarm_time;
    bool high_alarm_set;

    bool alarm_enabled;    /* sensor is part of the thermal mitigation */
    bool high_alarm_state; /* whether the sensor is currently in alarm-on state or not */
    bool low_alarm_state;  /* whether the sensor is currently in alarm-on state or not */
    int32_t high_hysteresis;
    int32_t low_hysteresis;
} tempsensor_info_t;

// Misc functions
amxd_dm_t* get_dm(void);
amxo_parser_t* get_parser(void);
const char* get_prefix(void);
amxc_var_t* get_config(void);
amxd_object_t* get_object(const char* path);
char* get_unknown_time(void);
int32_t get_bad_temp(void);
int32_t get_retry(void);
int tempsensor_init_all(void);
int tempsensor_init(amxd_object_t* tempsensor_instance);
amxd_status_t tempsensor_info_clean(tempsensor_info_t** tempsensor_info);
// Device functions
bool tempsensor_device_exists(tempsensor_info_t* tempsensor_info);
int32_t probe_tempsensor(tempsensor_info_t* tempsensor_info);
// Update function
void update_temp_dm_n_struct(amxp_timer_t* timer, void* priv);
uint32_t get_hysteresis(void);
uint32_t get_overheated_sensors(void);
uint32_t get_underheated_sensors(void);
void set_overheated_sensors(uint32_t s);
void set_underheated_sensors(uint32_t s);
void tempsensor_handle_alarms(tempsensor_info_t* info);
void tempsensor_high_alarm_reset(tempsensor_info_t* info);
void tempsensor_low_alarm_reset(tempsensor_info_t* info);
void hwmon_path_to_name(tempsensor_info_t* tempsensor_info, const char* path);

#ifdef __cplusplus
}
#endif

#endif // __TR181_TEMPERATURE_H__
