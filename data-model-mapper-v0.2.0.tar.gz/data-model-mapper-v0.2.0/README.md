# Data Model Mapper

## Introduction
The Data Model Mapper is a service, which allows to map and call USP (TR-369) commands via ACS (TR-069).

## Commands mapping

### General structure
In general, the structure for any new command is:
```
%config {
    %global proxy-object = {
        "'<root_object_name_for_new_commands_set>.'" = "<path_to exists_object>."
    };
}

%define {
	object <root_object_name_for_new_commands_set> {
		object <comand_name_1> {
			/* all necessary parameters and objects for new command */
		}

		object <comand_name_2> {
			/* all necessary parameters and objects for new command */
		}
		...
	}
}
```

Details about command structure is described in Command structure part.

The mapping should be based on present `odl` files in prplOS, because implemented command parameters can have differences from the USP standard.

The examples of the mapping can be found in the `odl` directory of this project.

### Command structure
Each command must be present in the data-model-mapper `odl` file as a separate object and has the following structure:
```
object <command_name> {
    %private %read-only string CmdPath = <path_to_org_command>;
    /* string CmdPath = <path_to_org_command> for multi-instance commands */
    %private %read-only string CmdName = <name_of_org_command>;

    on event "dm:object-changed" call process_command filter 'parameters.State.to == "Requested"';
	
    string State {
        default "None";
        on action validate call check_enum ["None", "Requested", "Complete", "Error"];
    }

    %read-only string ErrorMessage;

    %read-only string ErrorCode;

    // not requered
    object Input {
        /* list of the input arguments */
    }

    // not requered
    object Output {
        /* list of the input arguments */
    }
}
```

The object name may be any string.

The parameter `CmdPath` is mandatory and should contain the path to the mapping command, for example:
```
%private %read-only string CmdPath = "Device.SoftwareModules";
```

The parameter `CmdName` is mandatory and should contain the name of the mapping command, for example:
```
%private %read-only string CmdName = "InstallDU";
```

Attributes `%private` and `%read-only` are strongly recommended (excluding multi-instance commands, see Multi-instance commands features part), because they protect these service parameters from accidental overwriting, excluding multi-instance commands mapping.

The keyword `on event` must be present to processing command via `State` parameter, and there are two option to do it:
1. as in example: `on event "dm:object-changed" call process_command filter 'parameters.State.to == "Requested"';`. In this case it's necessary to add this keyword to each mapped command, as in example above;
2. In the end of the `odl` file:
```
%populate {
    on event "dm:object-changed" call process_command
        filter 'path matches "<root_object_name_for_new_commands_set>\." &&
            parameters.State.to == "Requested"';
}
```
In this case it is enough to add `on event` once in the end of the file.

The `State` parameter is mandatory. This parameter is a trigger to processing mapped command, and has the following logic of the using. By default, after the `data-model-mapper` module started, this parameter has a value `None`. To start command execution, the value `Requested` must be written. Writing any other value won't have any effect. After completing the command execution, the `State` parameter will have either `Complete`, if the command is completed successfully, or `Error`, if the command is completed with error. Details of the error will be present in the `ErrorMessage` and `ErrorCode` parameters.

The parameters `ErrorMessage` and `ErrorCode` should be present to provide more details about errors during command execution. The attribute `%read-only` is recommended to protect these parameters from accidental overwriting. These parameters are empty by default and contain some values only if some error is happened.

The object `Input` is required, if a mapped command has input parameters, and should contain as minimum all mandatory parameters for the command. Each parameter of this object can have any `odl` supported type, including objects and objects template, and must have the same name as it presents in the original command.
Example of the `Input` object from `InstallDU` mapping:
```
object Input {
	...
    int32 AllocatedCPUPercent = -1;

    bool AutoStart;

    string Signature;
    ...
    object HostObject[] {
        %private %read-only string target_type = "list";

        string Source;
        ...
    }

    object NetworkConfig {
        %private %read-only string target_type = "list";

        string AccessInterfaces;
    }
    ...
}
```
In case when input parameter is an object or an object template, it is necessary to add service parameter `target_type`. This parameter should contain the type of this parameter. Supported values are `list` and `htable`. It is strongly recommended to add attributes `%private` and `%read-only` to hide this parameter from ACS and protect them from accidental overwriting. The correct type can be taken from original `odl` file with command description.

The `Output` object is optional, if a mapped command has output parameters, and should contain all output parameters. Parameter names must have the same names as it presents in the original command.

### Multi-instance command
The good example of the multi-instance command can be `SoftwareModules.DeploymentUnit.{i}.Uninstall()`. For this type of the command, it is necessary to add the `CmdPath` parameter without attributes `%private` and `%read-only`. This parameter must be visible and writable to have possibility to set the exact number of the `DeploymentUnit`, because count of the `DeploymentUnit` change dynamically during work.

### Mapping existing objects to new object
There is a possibility to add and dynamically update exists objects and parameters from other components to the newly created for data-model-mapper.
To do this, it is needed to add the following in the start of the `odl` file:
```
%config {
    %global proxy-object = {
        "'<root_object_name_for_new_commands_set>.'" = "<path_to exists_object>."
    };
}
```
Example for SoftwareModules (from file odl/software-modules/software-modules-mapping_definition.odl):
```
%config {
    %global proxy-object = {
        "'X_PRPLWARE-COM_SoftwareModules.'" = "SoftwareModules."
    };
}

%define {
    object 'X_PRPLWARE-COM_SoftwareModules' {
        object AddExecEnvCmd {
        ...
        }
    }
}
```
As a result, all objects from the `SoftwareModules` will be present in the `X_PRPLWARE-COM_SoftwareModules`.

### Paths for ODL with mapping
There are two places to add additional `odl` files with commads mapping.
The first one is designed to add files when building the firmware: the odl directory in the project sources. New `odl` files can be added there:
- with any name in the root of the `odl` directory: `odl/<new_odl_file_name>.odl`;
- with any name in any sub-directory with one level of nesting: `odl/<new_or_exist_dir>/<new_odl_file_name>.odl`;
The subdirectories with more than one level of nesting isn't supported.

The second one is designed to add files in runtime. To activate this feature, it is necessary to remove comments in the odl/data-model-mapper.odl file from sections:
```
...
// This variable should be defined to point to a directory
// where dynamic mapping to be placed.
// runtime_odl_dir = "";
...
// If runtime_odl_dir is defined, this include directive must be uncommented.
// #include "${runtime_odl_dir}";
...
```

and specify the directory path in the `runtime_odl_dir` parameter and re-start the `data-model-mapper`.

### Notifications
To configure notification on ACS it is necessary to make subscription for value change of Device.X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.State parameter.

### Provide data model to USP agent
To provide the data model from data-model mapper for USP agent it is necessary to add the following keywords in `%config` section:
```
%config {
	%global usp.translate = {
         "'<root_object_name_for_new_commands_set>.'" = "Device.<root_object_name_for_new_commands_set>."
    };

    %global usp.registrations = [
        "Device.<root_object_name_for_new_commands_set>."
    ];

	%global usp.register-retry = true;

    %global usp.connect-retry = true;
}
```

Example for `X_PRPLWARE-COM_SoftwareModules` object:
```
%config {
    %global proxy-object = {
        "'X_PRPLWARE-COM_SoftwareModules.'" = "SoftwareModules."
    };

    %global usp.translate = {
         "'X_PRPLWARE-COM_SoftwareModules.'" = "Device.X_PRPLWARE-COM_SoftwareModules."
    };

    %global usp.registrations = [
        "Device.X_PRPLWARE-COM_SoftwareModules."
    ];

	%global usp.register-retry = true;

    %global usp.connect-retry = true;
}
```

### Examples of work with data-model-mapper
All examples of work with data-model-mapper will be made based on commands for Software Modules using the ubus utility as an interface.

#### InstallDU
1. Set all mandatory parameters:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.Input _set '{"parameters":{"URL":"docker://some-url", "UUID":"0fed4ee6-b25f-5b4a-ba21-c3f182c4ba39", "Username":"username", "Password":"password", "ExecutionEnvRef":"generic"}}'
```

**If you are adding a multi-instance object**, such as `HostObject`, you need to add each instance using:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.Input.HostObject _add
```
Then, set its values using the following command:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.Input.HostObject.1 _set '{"parameters":{"Source":"/tmp/test_file_1","Destination":"/tmp/test_file_1","Options": "type=mount,bind,rw"}}
```
2. Command execution request:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd _set '{"parameters":{"State":"Requested"}}'
```
3. Results of the successful command:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd _get
{
       "X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.": {
               "ErrorMessage": "",
               "State": "Complete",
               "ErrorCode": ""
       }
}
```
4. Results of the failed command:
```
ubus call X_PRPLWARE-COM_SoftwareModules.InstallDUCmd _get
{
       "X_PRPLWARE-COM_SoftwareModules.InstallDUCmd.": {
               "ErrorMessage": "Pull image [docker://some-url] failed [Curl download content error [URL rejected: Error] URL [https://server-address:port/v2/some-url/manifests/latest]]",
               "State": "Error",
               "ErrorCode": "7002"
       }
}
```

#### DeploymentUnit.{i}.Uninstall
1. Set all mandatory parameters:
```
ubus call X_PRPLWARE-COM_SoftwareModules.DeploymentUnitUninstallCmd _set '{"parameters": { "CmdPath": "Device.SoftwareModules.DeploymentUnit.1" }}'
```
2. Command execution request:
```
ubus call X_PRPLWARE-COM_SoftwareModules.DeploymentUnitUninstallCmd _set '{"parameters": { "State": "Requested" }}'
```
3. Results of the successful command:
```
ubus call X_PRPLWARE-COM_SoftwareModules.DeploymentUnit_UninstallCmd _get
{
       "X_PRPLWARE-COM_SoftwareModules.DeploymentUnitUninstallCmd.": {
               "ErrorMessage": "",
               "State": "Complete",
               "CmdPath": "Device.SoftwareModules.DeploymentUnit.1",
               "ErrorCode": ""
       }
}
```
4. Results of the failed command:
```
ubus call X_PRPLWARE-COM_SoftwareModules.DeploymentUnitUninstallCmd _get
{
       "X_PRPLWARE-COM_SoftwareModules.DeploymentUnitUninstallCmd.": {
               "ErrorMessage": "object not found",
               "State": "Error",
               "CmdPath": "Device.SoftwareModules.DeploymentUnit.2",
               "ErrorCode": "2"
       }
}
```
