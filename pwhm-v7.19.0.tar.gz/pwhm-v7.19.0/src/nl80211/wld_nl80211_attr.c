/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
/*
 * This file implements nl80211 set of utilities to build basic and nested attributes
 */

#include "wld_nl80211_attr.h"
#include "wld_nl80211_api.h"
#include "wld_nl80211_parser.h"

#include "swl/swl_common.h"
#include "swl/swl_assert.h"
#include "swla/swla_mac.h"

#define ME "nlAttr"


void wld_nl80211_initNlAttrList(wld_nl80211_nlAttrList_t* pAttrList) {
    swl_unLiList_init(pAttrList, sizeof(wld_nl80211_nlAttr_t));
}

void wld_nl80211_initNlAttr(wld_nl80211_nlAttr_t* pAttr) {
    ASSERTS_NOT_NULL(pAttr, , ME, "NULL");
    pAttr->type = NL80211_ATTR_UNSPEC;
    pAttr->nested = false;
    memset(&pAttr->data, 0, sizeof(pAttr->data));
    wld_nl80211_initNlAttrList(&pAttr->data.attribs);
}

void wld_nl80211_cleanNlAttr(wld_nl80211_nlAttr_t* pAttr) {
    ASSERTS_NOT_NULL(pAttr, , ME, "NULL");
    if(pAttr->nested) {
        wld_nl80211_cleanNlAttrList(&pAttr->data.attribs);
    } else {
        wld_nl80211_initNlAttr(pAttr);
    }
}

void wld_nl80211_cleanNlAttrList(wld_nl80211_nlAttrList_t* pAttrList) {
    ASSERTW_NOT_NULL(pAttrList, , ME, "NULL");
    wld_nl80211_nlAttr_t* pAttr = NULL;
    uint32_t nAttr = swl_unLiList_size(pAttrList);
    for(int32_t i = nAttr - 1; i >= 0; i--) {
        pAttr = (wld_nl80211_nlAttr_t*) swl_unLiList_get(pAttrList, i);
        wld_nl80211_cleanNlAttr(pAttr);
        swl_unLiList_remove(pAttrList, i);
    }
    wld_nl80211_initNlAttrList(pAttrList);
}
