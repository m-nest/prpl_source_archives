# TR-181 UPnP Discovery
## Introduction
This is an Ambiorix plug-in for TR-181 UPnP Discovery.
## Architecture
The design of the plugin is similar to other plugins up to a certain point. The main difference is because of the fact that libupnp is multithreaded.

 1. **Handling multi-threaded libupnp**
To avoid dealing with excessive race conditions the system of signal/slot implemented by the lib_amxp is used. With a small tweak performed for this purpose, the signal/slot pipe is since lib_amxp=master_v1.1.0 thread safe.

After registering the plugin as a upnp client to search for all devices and services with "ssdp:all", the libupnp start threads doing some upnp stuff (handling SSDP). The callback passed by the plugin will be called from outside of the main thread (where amxrt eventloop runs) so only a few checks without side effect will be performed in it.

Depending on the type of SSDP event, the callback will emit an signal (amxp) passing the event data to the slot.

In the main thread, the signal pipe will be consumed by amxrt when needed and the data-model changed as requested.

 2. **Data-model/Object logic**
For Discovery, most (if not all) of the data will come from the libupnp to separate the data management from the object logic.

The data-management (filling the data-model with the correct value), is handled by the slot functions triggered by libupnp callback using lib_amxp stack.

The logic will be performed using amxd data-model event callback.

The Data model (LastUpdate parameter) is updated each time a SSDL Alive message is received. This can pose a certain stress on the service. 
The Data model is also immediately updated when we receive an SSDP ByeBye message.

## Features
 1. **Automatic Device Detection**
   - Seamlessly discovers UPnP-enabled devices within the local network.
   - Supports dynamic detection of new devices and removal of disconnected ones.

 2. **Service Information Retrieval**
   - Retrieves detailed service descriptions and capabilities of discovered devices.
   - Supports browsing and querying UPnP device and service data.

 3. **Dynamic Configuration**
   - Automatically updates TR-181 data model parameters based on discovered devices.
   - Facilitates real-time network configuration and management.

 4. **Interoperability & Compatibility**
   - Ensures compatibility with a wide range of UPnP devices.
   - Simplifies integration with existing network infrastructure.

 5. **Network Resource Optimization**
   - Enables efficient device management and resource allocation.
   - Reduces manual configuration efforts.

 6. **Security & Access Control**
   - Supports secure discovery and interaction with UPnP devices.
   - Ensures only authorized devices are managed.

## Use cases
 1. **Automatic Device Discovery and Management**
- Quickly identify all UPnP devices on the local network.
- Automatically add new devices to the network configuration.
- Remove or disable disconnected or offline devices.
- Maintain an up-to-date list of devices for efficient management.

 2. **Dynamic Network Service Configuration**
- Retrieve service descriptions to automatically configure network parameters.
- Update TR-181 configuration based on detected device capabilities.
- Facilitate seamless integration of new devices into the network without manual intervention.

 3. **Enhanced Security and Access Control**
- Restrict interactions to authorized devices only.
- Monitor connected devices in real-time to detect suspicious activity.
- Manage access rights based on device types or roles within the network.

 4. **Network Resource Optimization**
- Identify devices consuming significant bandwidth or resources.
- Prioritize or limit access for certain devices to improve overall performance.
- Automate resource management based on device discovery.

 5. **Support for Maintenance and Troubleshooting**
- Quickly gather detailed information about devices for diagnostics.
- Verify device compatibility with network services.
- Enable remote updates or configuration of UPnP devices.

## Building
### Prerequisites
- [libamxc](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxc)
- [libamxp](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxp)
- [libamxj](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxj)
- [libamxd](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxd)
- [libamxb](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxb)
- [libamxo](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxo)
- [libamxm](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxm)
- [libamxrt](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxrt)
- [libsahtrace](https://gitlab.com/soft.at.home/network/libsahtrace)
- [libnetmodel](https://gitlab.com/prpl-foundation/components/core/libraries/libnetmodel)
- [mod-fw-amx](https://gitlab.com/prpl-foundation/components/core/modules/mod-fw-amx)
- [libipat](https://gitlab.com/prpl-foundation/components/core/libraries/libipat)
- [libtr181-hosts](https://gitlab.com/prpl-foundation/components/core/libraries/lib_tr181-hosts)
- [curl]

You can install these libraries from source or using their debian packages. To install them from source, refer to their corresponding repositories for more information.
To install them using debian packages, you can run
```bash
sudo apt update
sudo apt install sah-lib-sahtrace-dev libamxc libamxp libamxj libamxd libamxb libamxo libamxm libamxmrt libnetmodel mod-fw-amx libipat libtr181-hosts libcurl4-gnutls-dev
```

### Build and install TR-181 UPnP Discovery
1. Clone the git repository
    To be able to build it, you need the source code. So open the desired target directory and clone this plug-in in it.
    ```bash
    mkdir ~/workspace/amx/plugins
    cd ~/workspace/amx/plugins
    git clone git@gitlab.com:prpl-foundation/components/core/plugins/tr181-upnpdiscovery.git
    ```
1. Build it
    When using the internal gitlab, you must define an environment variable `VERSION_PREFIX` before building.
    ```bash
    export VERSION_PREFIX="master_"
    ```
    After the variable is set, you can build the plug-in.
    ```bash
    cd ~/workspace/amx/plugins/tr181-upnpdiscovery
    make
    ```
1. Install it
    You can use the install target in the makefile to install the plug-in
    ```bash
    cd ~/workspace/amx/plugins/tr181-upnpdiscovery
    sudo -E make install
    ```
### Running the plug-in
During installation a symbolic link is created to amxrt:
```text
/usr/bin/tr181-upnpdiscovery -> /usr/bin/amxrt
```
This allows you to run the Routing manager using the `tr181-upnpdiscovery` command. `amxrt` will find the relevant odl files in `/etc/amx/tr181-upnpdiscovery`.