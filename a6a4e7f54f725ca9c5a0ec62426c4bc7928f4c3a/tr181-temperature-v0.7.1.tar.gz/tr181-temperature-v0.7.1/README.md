# tr181-temperature


# Introduction

`tr181-temperature` implements the TR-181 Device.DeviceInfo. data model. The data model is based on TR-181 v2.17  
and the specification can be found on the [BroadBandForum](https://www.broadband-forum.org/)'s website. The data 
model is supported by protocolslike [CWMP](https://cwmp-data-models.broadband-forum.org/) or
[USP](https://usp-data-models.broadband-forum.org/).

TR-181 Device.DeviceInfo.TemperatureStatus. allows the monitoring of device temperature through the use of 
temperature sensor objects, such as Device.DeviceInfo.TemperatureStatus.TemperatureSensor.{i}. 
See: https://usp-data-models.broadband-forum.org/tr-181-2-12-0-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus.

## Use Case Definition

TR181-Tempeature pugin provides the following features: 

- **Temperature Reporting and Logging**
  - Implementation of a TR-181 v2.17 `Device.DeviceInfo.TemperatureStatus` datamodel.
  - Provide an Enable switch for individual sensors.
  - Expose current temperature and names of sensors.
  - Provide minimum and maximum recorded values along with timestamps.
  - Configuration of polling interval for temperature readings.
  - Configure of low and high alarm threshold values.
  - Expose initial timestamps when alarm values were triggered.
  - Reset command to clear alarm timestamps.

- **LL-API Interface**
  - Read sensor values from standard Linux thermal zones as described in the [Linux Thermal Sysfs API](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt).
  - Option to configure the path of the sysfs device driver from configuration settings.

- **Safety Mechanisms**
  - Handle a graceful shutdown of the router when temperature exceeds defined thresholds.

## References

* TR-181  TemperatureStatus datamodel: [https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.TemperatureStatus.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus.)
* Linux kernel thermal sysfs API: [https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt)
 


# Architecture

TR181-Temperature is a standard ambiorix application connected to the bus and exposing datamodel. It is polling sys fs periodically

![TR181-Temperature Architecture diagram](image/TemperatureArchitecture.png)


#### **Temperature polling**

The tr181-temperature plugin must periodically poll the temperature values of the configured sensors. This polling interval must be configurable by the user and can be modified on the go. 

If no polling interval is set, a default value will be used as polling interval. This value must be internal to the plugin and hidden form the user.

#### **Temperature statistics**

The tr181-temperature plugin must provide multiple temperature statistics data to the user. 

A maximum temperature value can be set by the user and will let the plugin record the moment in time where the value is reached. This will be readable by the user as a time stamp.

The maximum effective reached temperature will also be stored in the datamodel and be readable by the user.

A minimum temperature value can be set by the user and will let the plugin record the moment in time where the value is reached. This will be readable by the user as a time stamp.

The minimum effective reached temperature will also be stored in the datamodel and be readable by the user.

#### **Reset of the temperature sensor's statistics**

The temperature sensor's statistics can be reset to defaults values. When reset, the upper and lower temperature limits will be set to \-274 degrees Celsius, disabling them.

The stored upper and lower temperature time stamp will be removed and the sensor will be set to a disabled state. The user will have to manually enable the sensor via the datamodel.

#### **Source of the temperature readings**

The parameter "Name" is used to store the path to the temperature file in sysfs.

# Implementation
 
## Data Model

Datamodel is implemented according to TR181: [https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html\#D.Device:2.Device.DeviceInfo.TemperatureStatus.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus.)

TR-181 Device.DeviceInfo.TemperatureStatus. contains a multi instance object :

| Object                                                                | Implemented in tr181-temperature |
| ----------------------------------------------------------------------| -------------------------------- |
| Device.DeviceInfo.TemperatureStatus.TemperatureSensorNumberOfEntries  | **Yes**                          |
| Device.DeviceInfo.TemperatureStatus.TemperatureSensor.{i}.            | **Yes**                          |


## Low-Level API

TR181-Temperature relies relies on linux kernel thermal zones as defined in [https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt](https://www.kernel.org/doc/Documentation/thermal/sysfs-api.txt)

## API

## Files

All files used by the component are in `/amx/tr181-temperature/.`

Component polls regularly `/sys/class/thermal/thermal_zone*` to fetch temperature data.



## Dependants and Dependencies

### Dependants

Weak dependancy from [reboot-service](https://gitlab.com/prpl-foundation/components/core/plugins/reboot-service) plugin that subscribe to HighAlarm events to handle reboot. see Reboot-Service documentaiton for more details.

### Dependencies

TR181-Temperature is dependent on ambiorix framework:

* lib\_amxc  
* lib\_amxd  
* lib\_amxp  
* lib\_amxo  
* lib\_sahtrace

TR181-Temperature also depends on following modules to build an initial configuration retrieving system available sensors in sysfs:

* odl-generator:  
* ucode-mod-fs : used

## Configuration

Main configuration file is in `/etc/amx/tr181-temperature/tr181-temperature.odl`

By default, on firstboot, initial instances are created by looking for all `thermal_zone` files in `/sys/class/thermal/`. This is implemented through `/etc/amx/tr181-temperature/defaults.d/tr181-temperature_defaults.odl.uc` processed by odl-generator.

This can be easily overridden by providing a default `/etc/amx/tr181-temperature/defaults.d/tr181-temperature_defaults.odl` file.

Note that, in case of and SDK upstep, any change in the list of thermal zones or their names, there is no guarantee that the data model still behaves correctly. A factory reset might be needed to correct it. It is important for the System Integrator to verify this on SDK upsteps.

## Backup/Restore, Upgrade, Reset

TR181-Temperature doesn’t have any persistent parameter as temperature data is considered to be relevant only for a given boot.
LowAlarmValue, HighAlarmValue, PollingInterval should be persistent.


# Considerations

## Security

The plugin executes with the tr181\_app user and drops all the capabilities except:

* CAP\_DAC\_OVERRIDE: To allow read access to temperature

## Remote Management

Few parameters are writeable to set thresholds and pollingInterval. A Reset() command is also available. Refer to TR-181 datamodel.

# Building, installing and testing

## Docker container

You could install all tools needed for testing and developing on your local
machine, or use a pre-configured environment. Such an environment is already
prepared for you as a docker container.

1. Install Docker

    Docker must be installed on your system. Here are some links that could
    help you:

    - [Get Docker Engine - Community for
      Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for
      Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for
      Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for
      CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)
      <br /><br />

    Make sure you user id is added to the docker group:

        sudo usermod -aG docker $USER
    <br />

2. Fetch the container image

    To get access to the pre-configured environment, pull the image and launch
    a container.

    Pull the image:

        docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    Before launching the container, you should create a directory which will be
    shared between your local machine and the container.

        mkdir -p ~/amx/temperature/applications/

    Launch the container:

        docker run -ti -d \
            --name oss-dbg \
            --restart=always \
            --cap-add=SYS_PTRACE \
            --cap-add=CAP_NET_RAW \
            --cap-add=CAP_NET_ADMIN \
            --sysctl net.ipv6.conf.all.disable_ipv6=1 \
            -e "USER=$USER" \
            -e "UID=$(id -u)" \
            -e "GID=$(id -g)" \
            -v ~/amx:/home/$USER/amx \
            registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    The `-v` option bind mounts the local directory for the amx project in
    the container, at the exact same place.
    The `-e` options create environment variables in the container. These
    variables are used to create a user name with exactly the same user id and
    group id in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

        docker exec -ti --user $USER oss-dbg /bin/bash

## Building

### Prerequisites

<code>tr181-temperature</code> depends on the following libraries:

- libamxc
- libamxo
- libamxp
- libamxd
- libsahtrace
- mod-dmext

These libraries and additional packages can be installed in the container:

    sudo apt-get update
    sudo apt-get install libamxc libamxo libamxp libamxd amxo-cg \
    amxo-xml-to amxrt mod-dmext mod-amxb-ubus mod-ba-cli mod-dm-cli \
    mod-sahtrace sah-lib-sahtrace-dev 

### Build tr181-temperature

1. Clone the git repository

    To be able to build it, you need the source code. So open the directory
    just created for the ambiorix project and clone this library in it (on your
    local machine).

        cd ~/amx/temperature/applications/
        git clone git@gitlab.com:prpl-foundation/components/core/plugins/tr181-temperature.git

2. Build it

    When using the internal gitlab, you must define an environment variable
    `VERSION_PREFIX` before building in your docker container.

        export VERSION_PREFIX="master_"

    After the variable is set, you can build the package.

        cd ~/amx/temperature/applications/tr181-temperature
        make

## Installing

### Using make target install

You can install your own compiled version easily in the container by running
the install target.

    cd ~/amx/temperature/applications/tr181-temperature
    sudo -E make install

### Using package

From within the container you can create packages.

    cd ~/amx/temperature/applications/tr181-temperature
    make package

The packages generated are:

    ~/amx/temperature/applications/tr181-temperature/tr181-temperature-<VERSION>.tar.gz
    ~/amx/temperature/applications/tr181-temperature/tr181-temperature-<VERSION>.deb

You can copy these packages and extract/install them.

For Ubuntu or Debian distributions use dpkg:

    sudo dpkg -i ~/amx/temperature/applications/tr181-temperature/tr181-temperature-<VERSION>.deb

## Testing

### Prerequisites

No extra components are needed for testing `tr181-temperature`.

### Run tests

You can run the tests by executing the following command:

    cd ~/amx/temperature/applications/tr181-temperature/test
    make

Or this command if you also want the coverage tests to run:

    cd ~/amx/temperature/applications/tr181-temperature/test
    make run coverage

You can combine both commands:

    cd ~/amx/temperature/applications/tr181-temperature
    make test

### Coverage reports

The coverage target will generate coverage reports using
[gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and
[gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each c-file is printed in your console after the tests are run.
A HTML version of the coverage reports is also generated. These reports are
available in the output directory of the compiler used.  For example, when using
native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML
coverage reports can be found at
`~/amx/temperature/applications/tr181-temperature/output/x86_64-linux-gnu/coverage/report.`

You can easily access the reports in your browser. In the container start a
python3 http server in background.

    cd ~/amx/
    python3 -m http.server 8080 &

Use the following url to access the reports:

    http://<IP ADDRESS OF YOUR CONTAINER>:8080/temperature/applications/tr181-temperature/output/<MACHINE>/coverage/report

You can find the ip address of your container by using the `ip -br a` command
in the container.

Example:

    USER@<CID>:~/amx/temperature/applications/tr181-temperature$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16


In this case the ip address of the container is `172.17.0.3`.  So the url you
should use is:
`http://172.17.0.3:8080/temperature/applications/tr181-temperature/output/x86_64-linux-gnu/coverage/report/`

## Documentation

### Prerequisites

To generate the documentation, [Doxygen](https://www.doxygen.nl) is required
and already available in the container. In case you want to install this on
your local machine:

    sudo apt-get install doxygen

### Paths

The documentation is split in two parts, starting from the repository path:

    cd ~/amx/temperature/applications/tr181-temperature

Here, you can find:

- README.md: this file is used on Gitlab and is the main page for the Doxygen documentation.
- docs directory: contains the Doxygen settings, code examples and additional pages used in Doxygen.

The code itself is documented in the approriate header and source files.

### Generate documentation

You can generate the documentation by executing the following command:

    cd ~/amx/temperature/applications/tr181-temperature
    make doc

The full documentation is available in the `output` directory. You can easily
access the documentation in your browser. As described in the coverage reports
section, you can start a http server in the container.

    cd ~/amx/
    python3 -m http.server 8080 &

Note that there are two different kinds of documentation:
- Doxygen documentation, describing the internals of the TR-181 temperature Manager.
- ODL documentation, describing the TR-181 Device.temperature data model.

Use the following urls to access the reports:

- Doxygen documentation:

        http://<IP ADDRESS OF YOUR CONTAINER>:8080/temperature/applications/tr181-temperature/output/doc/doxy-html/index.html

- TR-181 data model documentation:

        http://<IP ADDRESS OF YOUR CONTAINER>:8080/temperature/applications/tr181-temperature/output/html/index.html


You can find the ip address of your container by using the `ip -br a` command
in the container.

Example:

    USER@<CID>:~/amx/temperature/applications/tr181-temperature$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16


In this case the ip address of the container is `172.17.0.3`.  So the url you
should use is
`http://172.17.0.3:8080/temperature/applications/tr181-temperature/output/doc/doxy-html/index.html`
or
`http://172.17.0.3:8080/temperature/applications/tr181-temperature/output/html/index.html`

# What's next?

Consult the full documentation for a complete description of the architecture,
the module API, example configurations, etc.
