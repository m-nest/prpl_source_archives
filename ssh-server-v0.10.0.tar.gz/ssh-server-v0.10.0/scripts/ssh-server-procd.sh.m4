#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="ssh_server"
PROG="/usr/bin/ssh_server"
datamodel_root="SSH"
PROG_OPTIONS=""


prepare(){
    if [ ! -d /etc/config/ssh_server ]; then
        mkdir -p /etc/config/ssh_server/odl
    fi
    $(. /etc/init.d/dropbear 2>/dev/null && hk_generate_as_needed)
    if [ -d /etc/dropbear ] && ls /etc/dropbear/*_key >/dev/null 2>&1; then
        for file in /etc/dropbear/*_key; do
            dest="/etc/config/ssh_server/$(basename "$file")"
            if [ ! -f "$dest" ]; then
                mv "$file" "$dest"
            else
                rm "$file"
            fi
        done
    fi
}

#Guideline- this function has the instructions to execute
#before starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    prepare
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook()
}
