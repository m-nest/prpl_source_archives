/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _SFPMGR_ETHTOOLIF_H_
#define _SFPMGR_ETHTOOLIF_H_

#include <stdbool.h>
#include <stdint.h>

#define SFF_8472_A0_BYTE_64_LINEAR_RCVR         0x01
#define SFF_8472_A0_BYTE_64_POWER_LVL_1         0x02
#define SFF_8472_A0_BYTE_64_COOLED_TRANS        0x04

#define SFF_8472_A0_BYTE_65_LOS                 0x02
#define SFF_8472_A0_BYTE_65_INVERTED_LOS        0x04
#define SFF_8472_A0_BYTE_65_TX_FAULT            0x08
#define SFF_8472_A0_BYTE_65_TX_DISABLE          0x10
#define SFF_8472_A0_BYTE_65_RATE_SELECT         0x20

#define SFF_8472_A0_BYTE_92_LEGACY              0x80
#define SFF_8472_A0_BYTE_92_IMPL                0x40
#define SFF_8472_A0_BYTE_92_INTERNAL            0x20
#define SFF_8472_A0_BYTE_92_EXTERNAL            0x10
#define SFF_8472_A0_BYTE_92_RXAVGPWR            0x08

#define SFF_8472_A0_BYTE_93_ALARM               0x80
#define SFF_8472_A0_BYTE_93_SOFT_TX_DISABLE     0x40
#define SFF_8472_A0_BYTE_93_SOFT_TX_FAULT       0x20
#define SFF_8472_A0_BYTE_93_SOFT_RX_LOS         0x10
#define SFF_8472_A0_BYTE_93_SOFT_RATE_SELECT    0x08
#define SFF_8472_A0_BYTE_93_SFF_8079            0x04
#define SFF_8472_A0_BYTE_93_SFF_8431            0x02

#define SFF_8472_A2_BYTE_110_DATA_READY         0x01
#define SFF_8472_A2_BYTE_110_RX_LOS             0x02
#define SFF_8472_A2_BYTE_110_TX_FAULT           0x04
#define SFF_8472_A2_BYTE_110_RATE_SELECT        0x10
#define SFF_8472_A2_BYTE_110_RS1_STATE          0x20
#define SFF_8472_A2_BYTE_110_TX_DISABLE         0x80

#define POWER_LEVEL_0 0
#define POWER_LEVEL_1 1
#define POWER_LEVEL_2 2

#define LASER_BIAS_CURRENT                      "Laser bias current"
#define LASER_OUTPUT_POWER                      "Laser output power"
#define RECEIVER_SIGNAL_AVG_OPTICAL_POWER       "Receiver signal average optical power"
#define MODULE_TEMPERATURE                      "Module temperature"
#define MODULE_VOLTAGE                          "Module voltage"
#define LASER_BIAS_CURRENT_HIGH_WARNING         "Laser bias current high warning"
#define LASER_BIAS_CURRENT_LOW_WARNING          "Laser bias current low warning"
#define LASER_OUTPUT_POWER_HIGH_WARNING         "Laser output power high warning"
#define LASER_OUTPUT_POWER_LOW_WARNING          "Laser output power low warning"
#define MODULE_TEMPERATURE_HIGH_WARNING         "Module temperature high warning"
#define MODULE_TEMPERATURE_LOW_WARNING          "Module temperature low warning"
#define MODULE_VOLTAGE_HIGH_WARNING             "Module voltage high warning"
#define MODULE_VOLTAGE_LOW_WARNING              "Module voltage low warning"
#define LASER_RX_POWER_HIGH_WARNING             "Laser rx power high warning"
#define LASER_RX_POWER_LOW_WARNING              "Laser rx power low warning"
#define LASER_BIAS_CURRENT_HIGH_ALARM           "Laser bias current high alarm"
#define LASER_BIAS_CURRENT_LOW_ALARM            "Laser bias current low alarm"
#define LASER_OUTPUT_POWER_HIGH_ALARM           "Laser output power high alarm"
#define LASER_OUTPUT_POWER_LOW_ALARM            "Laser output power low alarm"
#define MODULE_TEMPERATURE_HIGH_ALARM           "Module temperature high alarm"
#define MODULE_TEMPERATURE_LOW_ALARM            "Module temperature low alarm"
#define MODULE_VOLTAGE_HIGH_ALARM               "Module voltage high alarm"
#define MODULE_VOLTAGE_LOW_ALARM                "Module voltage low alarm"
#define LASER_RX_POWER_HIGH_ALARM               "Laser rx power high alarm"
#define LASER_RX_POWER_LOW_ALARM                "Laser rx power low alarm"
#define MODULE_TEMP_HIGH_ALARM_THRESHOLD        "Module temperature high alarm threshold"
#define MODULE_TEMP_LOW_ALARM_THRESHOLD         "Module temperature low alarm threshold"
#define MODULE_TEMP_HIGH_WARNING_THRESHOLD      "Module temperature high warning threshold"
#define MODULE_TEMP_LOW_WARNING_THRESHOLD       "Module temperature low warning threshold"
#define MODULE_VOLT_HIGH_ALARM_THRESHOLD        "Module voltage high alarm threshold"
#define MODULE_VOLT_LOW_ALARM_THRESHOLD         "Module voltage low alarm threshold"
#define MODULE_VOLT_HIGH_WARNING_THRESHOLD      "Module voltage high warning threshold"
#define MODULE_VOLT_LOW_WARNING_THRESHOLD       "Module voltage low warning threshold"
#define LASER_BIAS_HIGH_ALARM_THRESHOLD         "Laser bias current high alarm threshold"
#define LASER_BIAS_LOW_ALARM_THRESHOLD          "Laser bias current low alarm threshold"
#define LASER_BIAS_HIGH_WARNING_THRESHOLD       "Laser bias current high warning threshold"
#define LASER_BIAS_LOW_WARNING_THRESHOLD        "Laser bias current low warning threshold"
#define LASER_POWER_HIGH_ALARM_THRESHOLD        "Laser output power high alarm threshold"
#define LASER_POWER_LOW_ALARM_THRESHOLD         "Laser output power low alarm threshold"
#define LASER_POWER_HIGH_WARNING_THRESHOLD      "Laser output power high warning threshold"
#define LASER_POWER_LOW_WARNING_THRESHOLD       "Laser output power low warning threshold"
#define LASER_RX_POWER_HIGH_ALARM_THRESHOLD     "Laser rx power high alarm threshold"
#define LASER_RX_POWER_LOW_ALARM_THRESHOLD      "Laser rx power low alarm threshold"
#define LASER_RX_POWER_HIGH_WARNING_THRESHOLD   "Laser rx power high warning threshold"
#define LASER_RX_POWER_LOW_WARNING_THRESHOLD    "Laser rx power low warning threshold"

#define TRANSCEIVER_LEN 18
#define VENDOR_NAME_LEN 16
#define VENDOR_OUI_LEN 6
#define VENDOR_PN_LEN 16
#define VENDOR_REV_LEN 4
#define VENDOR_SN_LEN 16
#define DATE_CODE_LEN 8

typedef struct sfp_ethtool_st {
    uint8_t id;                            /* addr 0 */
    uint8_t ext_id;                        /* addr 1 */
    uint8_t connector;                     /* addr 2 */
    char transceiver[TRANSCEIVER_LEN + 1]; /* addr 3 - 10 and addr 36 */
    uint8_t encoding;                      /* addr 11 */
    uint16_t br_nominal;                   /* addr 12 */
    uint8_t rate_id;                       /* addr 13 */
    uint8_t len_SMF_km;                    /* addr 14 */
    uint8_t len_SMF_100m;                  /* addr 15 */
    uint8_t len_50um_10m;                  /* addr 16 */
    uint8_t len_62dot5um_10m;              /* addr 17 */
#if 0
    uint8_t len_OM4_10m;                   /* addr 18: does not occur in BBF DM */
#endif
    uint8_t len_OM3_10m;                   /* addr 19 */
    char vendor_name[VENDOR_NAME_LEN + 1]; /* addr 20 - 35 */
    char vendor_oui[VENDOR_OUI_LEN + 1];   /* addr 37 - 39 */
    char vendor_rev[VENDOR_REV_LEN + 1];
    char vendor_pn[VENDOR_PN_LEN + 1];     /* addr 40 - 55 */
    uint16_t wavelength;                   /* addr 60 - 61 */
    uint8_t cc_base;                       /* addr 63 */
    uint8_t options[2];                    /* addr 64 - 65 */
    uint8_t br_max;                        /* addr 66 */
    uint8_t br_min;                        /* addr 67 */
    char vendor_sn[VENDOR_SN_LEN + 1];     /* addr 68 - 83 */
    char date_code[DATE_CODE_LEN + 1];     /* addr 84 - 91 */
    uint8_t diag_type;                     /* addr 92 */
    uint8_t en_options;                    /* addr 93 */
    uint8_t sff_vercompliance;             /* addr 94 */
    uint8_t cc_ext;                        /* addr 95 */
    int16_t temp_high_alarm;
    int16_t temp_low_alarm;
    int16_t temp_high_warning;
    int16_t temp_low_warning;
    uint16_t volt_high_alarm;
    uint16_t volt_low_alarm;
    uint16_t volt_high_warning;
    uint16_t volt_low_warning;
    uint16_t bias_high_alarm;
    uint16_t bias_low_alarm;
    uint16_t bias_high_warning;
    uint16_t bias_low_warning;
    int16_t tx_power_high_alarm;
    int16_t tx_power_low_alarm;
    int16_t tx_power_high_warning;
    int16_t tx_power_low_warning;
    int16_t rx_power_high_alarm;
    int16_t rx_power_low_alarm;
    int16_t rx_power_high_warning;
    int16_t rx_power_low_warning;
    int16_t temperature;        /* addr 96-97 */
    uint16_t volt;              /* addr 98-99 */
    uint16_t bias;              /* addr 100-101 */
    int16_t tx_power;           /* addr 102-103 */
    int16_t rx_power;           /* addr 104-105 */
    uint8_t option;             /* addr 110 */
    bool optcooltrans;
    bool optlinearrcvr;
    bool optpwrlvl;
    bool optlos;
    bool optinvlos;
    bool opttxfault;
    bool opttxdisable;
    bool optrateselect;
    bool warn_hightemp;
    bool warn_lowtemp;
    bool warn_highvolt;
    bool warn_lowvolt;
    bool warn_hightxbias;
    bool warn_lowtxbias;
    bool warn_hightxpower;
    bool warn_lowtxpower;
    bool warn_highrxpower;
    bool warn_lowrxpower;
    bool alarm_hightemp;
    bool alarm_lowtemp;
    bool alarm_highvolt;
    bool alarm_lowvolt;
    bool alarm_hightxbias;
    bool alarm_lowtxbias;
    bool alarm_hightxpower;
    bool alarm_lowtxpower;
    bool alarm_highrxpower;
    bool alarm_lowrxpower;
    bool dmctypeImplemented;
    bool dmctypeInternalcal;
    bool dmctypeExternalcal;
    bool dmctypeRxAvgPwr;
    bool eocalarmsImplemented;
    bool eocsofttxDisable;
    bool eocsofttxFault;
    bool eocsoftrxLOS;
    bool eocsoftrateSelect;
    bool sff8079appSelect;
    bool sff8431softrateSelect;
    bool txdisableState;
    bool rs1State;
    bool rateselectState;
    bool txfaultState;
    bool rxlosState;
    bool datareadybarState;
    bool softtxdisableSelect;
    bool softrateselectSelect;
} sfp_ethtool_t;


#endif //_SFPMGR_ETHTOOLIF_H_
