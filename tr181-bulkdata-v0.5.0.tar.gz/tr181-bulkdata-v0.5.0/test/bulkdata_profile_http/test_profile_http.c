/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>

#include <imtp/imtp_connection.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_http.h"

#include "mock.h"
#include "test_common.h"
#include "test_profile_http.h"

int test_http_profile_setup(UNUSED void** state) {
    const char* odl_bulkdata = "../common/tr181-bulkdata_test_http_profiles.odl";
    const char* odl_device = "../common/test_device.odl";
    const char* odl_mqtt = "../common/tr181-mqtt.odl";
    const char* odl_deviceInfo = "../common/tr181-deviceInfo.odl";
    static const char* la_definition = "../common/tr181-localagent_definition.odl";
    static const char* la_defaults = "../common/tr181-localagent_mtp_enabled.odl";
    amxo_parser_t* parser = NULL;

    test_setup(NULL);
    capture_sigalrm();

    parser = test_get_parser();
    assert_int_equal(amxo_parser_parse_file(parser, odl_bulkdata, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_device, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_mqtt, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_deviceInfo, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, la_definition, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, la_defaults, amxd_dm_get_root(mock_get_dm())), 0);
    amxc_var_add_key(bool, &parser->config, "acl_check_enabled", true);
    amxc_var_add_key(cstring_t, &parser->config, "acl_dir", "/cfg/etc/acl");
    return 0;
}

int test_http_profile_teardown(UNUSED void** state) {
    go_to_future_ms(10000);
    test_teardown(NULL);
    return 0;
}

static void dump_path(const char* path, int depth) {
    amxc_var_t ret;
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has(path);
    amxc_var_init(&ret);
    printf("will dump values for '%s' with depth '%d'\n", path, depth);
    fflush(stdout);
    assert_int_equal(amxb_get(bus_ctx, path, depth, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);
    handle_events();


    amxc_var_clean(&ret);
}

static void add_profile_http(const char* alias, uint32_t interval) {
    amxb_bus_ctx_t* bus_ctx = test_get_bus_ctx();
    amxc_var_t values;
    amxc_var_t ret;
    amxc_string_t path;
    int res = -1;

    amxc_var_init(&values);
    amxc_var_init(&ret);
    amxc_string_init(&path, 0);

    printf("1-amxb_get for 'BulkData.Profile.'\n");
    fflush(stdout);
    assert_int_equal(amxb_get(bus_ctx, "BulkData.Profile.", 0, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);
    printf("1-amxb_get for 'Device.Time.'\n");
    fflush(stdout);
    assert_int_equal(amxb_get(bus_ctx, "Device.Time.", 1, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);
    printf("1-amxb_get for 'MQTT.Client.1.'\n");
    fflush(stdout);
    assert_int_equal(amxb_get(bus_ctx, "MQTT.Client.1.", 1, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);


    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, "Enable", true);
    amxc_var_add_key(uint32_t, &values, "ReportingInterval", interval);
    amxc_var_add_key(cstring_t, &values, "Alias", alias);
    amxc_var_add_key(cstring_t, &values, "Protocol", "HTTP");

    amxc_string_setf(&path, "%sProfile.", ROOT_OBJECT_NAME);
    assert_int_equal(amxb_add(bus_ctx, amxc_string_get(&path, 0), 0, NULL, &values, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "Method", "POST");
    amxc_var_add_key(cstring_t, &values, "URL", "https://postman-echo.com/post/");
    amxc_var_add_key(bool, &values, "UseDateHeader", true);

    amxc_string_appendf(&path, "%s.HTTP.", alias);
    res = amxb_set(bus_ctx, amxc_string_get(&path, 0), &values, &ret, 3);
    printf("amxb_set return '%s' when setting '%s'\n", amxd_status_string(res), amxc_string_get(&path, 0));
    fflush(stdout);
    amxc_var_dump(&ret, STDOUT_FILENO);
    assert_int_equal(res, 0);

    printf("2-amxb_get for 'BulkData.Profile.'\n");
    fflush(stdout);
    assert_int_equal(amxb_get(bus_ctx, "BulkData.Profile.", 0, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    amxc_string_clean(&path);
    amxc_var_clean(&ret);
    amxc_var_clean(&values);
}

void test_can_add_profile_http(UNUSED void** state) {
    amxd_object_t* object = NULL;
    const char* alias = "http-profile-1";

    set_bulkdata_enable(true);
    add_profile_http(alias, 15);
    handle_events();

    object = amxd_dm_findf(mock_get_dm(), "%sProfile.%s.HTTP.", ROOT_OBJECT_NAME, alias);
    assert_non_null(object);
    set_bulkdata_profile_enable("BulkData.Profile.http-profile-1.", false);
    handle_events();
}

void test_can_send_report_via_http_post_json(UNUSED void** state) {
    const char* profile = "BulkData.Profile.HTTP_POST_JSON_ObjectHierarchy.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    dump_path(profile, -1);
    go_to_future_ms(5000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
    dump_path(profile, -1);
}

void test_can_send_report_via_http_put_json(UNUSED void** state) {
    // HTTP_PUT
    const char* profile = "BulkData.Profile.HTTP_POST_JSON_ObjectHierarchy.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    go_to_future_ms(15000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}

void test_can_send_report_via_http_put_with_certif(UNUSED void** state) {
    // HTTP_PUT_Cert_JSON_ObjectHierarchy
    const char* profile = "BulkData.Profile.HTTP_PUT_Cert_JSON_ObjectHierarchy.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    go_to_future_ms(12000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}

void test_can_send_report_via_http_post_with_certif(UNUSED void** state) {
    // HTTP_POST_Cert_JSON_ObjectHierarchy
    const char* profile = "BulkData.Profile.HTTP_POST_Cert_JSON_ObjectHierarchy.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    go_to_future_ms(12000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}

void test_can_send_report_via_http_post_csv_ParameterPerRow(UNUSED void** state) {
    // HTTP_POST_CSV_ParameterPerRow
    const char* profile = "BulkData.Profile.HTTP_POST_CSV_ParameterPerRow.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    go_to_future_ms(12000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}

void test_can_send_report_via_http_post_csv_ParameterPerColumn(UNUSED void** state) {
    // HTTP_POST_CSV_ParameterPerColumn
    const char* profile = "BulkData.Profile.HTTP_POST_CSV_ParameterPerColumn.";
    set_bulkdata_profile_enable(profile, true);
    handle_events();
    go_to_future_ms(12000);

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}

void test_can_send_report_via_http_retry(UNUSED void** state) {
    const char* profile = "BulkData.Profile.HTTP_CSV_Retry.";
    set_bulkdata_profile_enable(profile, true);
    go_to_future_ms(10000);
    handle_events();
    go_to_future_ms(20000);
    handle_events();
    go_to_future_ms(40000);
    handle_events();

    go_to_future_ms(40000);
    handle_events();

    set_bulkdata_profile_enable(profile, false);
    handle_events();
}
