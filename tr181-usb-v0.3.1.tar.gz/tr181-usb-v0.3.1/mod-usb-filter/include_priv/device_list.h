#ifndef __USB_DEVICE_LIST_H__
#define __USB_DEVICE_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "device.h"

typedef struct usb_device_list_entry {
    char* identifier; // SysfsId for Device / Alias for AllowedDevice
    usb_device_t* device;

    amxc_llist_it_t it;
} usb_device_list_entry_t;

typedef int (* usb_device_action_cb_t) (device_type_t t, usb_device_list_entry_t* entry, void* priv);

/**
 * @brief Get list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @return Pointer to device structure list.
 */
amxc_llist_t* get_list(device_type_t type);

/**
 * @brief Get amount of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @return Size of device list.
 */
size_t usb_device_list_size(device_type_t type);

/**
 * @brief Initialize list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 */
void usb_device_list_init(device_type_t type);

/**
 * @brief Cleanup list of internal device structures.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 */
void usb_device_list_clean(device_type_t type);

/**
 * @brief Remove internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param identifier SysfsId (for Device) or Alias (for AllowedDevice).
 * @return 0 on succes, -1 otherwise.
 */
int usb_device_list_delete(device_type_t type, const char* identifier);

/**
 * @brief Find internal device structure based on identifier.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param identifier SysfsId (for Device) or Alias (for AllowedDevice).
 * @return Pointer to device structure.
 */
usb_device_list_entry_t* usb_device_list_find(device_type_t type, const char* identifier);

/**
 * @brief Add an internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param template_object Template object of the Device Object.
 * @param args Hashtable containing device settings.
 * @return Pointer to device structure.
 */
usb_device_list_entry_t* usb_device_list_add(device_type_t type, amxd_object_t* template_object, amxc_var_t* args);

/**
 * @brief Call function for each entry in the device structure list.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param cb Function to be called.
 * @param priv Private data that is passed to the callback function.
 */
void usb_device_list_foreach(device_type_t type, usb_device_action_cb_t cb, void* priv);

typedef struct usb_interface_list_entry {
    usb_device_interface_t interface;
    amxc_llist_it_t it;
} usb_interface_list_entry_t;

typedef int (* usb_interface_action_cb_t) (usb_device_t* device, usb_interface_list_entry_t* entry);

/**
 * @brief Get list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 */
size_t usb_interface_list_size(usb_device_t* device);

/**
 * @brief Initialize list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_interface_list_init(usb_device_t* device);

/**
 * @brief Remove an interface from the list of interfaces for an internal device structure.
 *
 * @param it iterator of the interface list item that needs to be removed.
 */
void usb_interface_list_delete_item(amxc_llist_it_t* it);

/**
 * @brief Cleanup the list of interfaces for an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_interface_list_clean(usb_device_t* device);

/**
 * @brief Remove an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return 0 on succes, -1 otherwise.
 */
int usb_interface_list_delete(usb_device_t* device, usb_device_interface_t* interface);

/**
 * @brief Remove an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface_class Interface Class.
 * @param interface_subclass Interface SubClass.
 * @param interface_protocol Interface Protocol.
 * @return 0 on succes, -1 otherwise.
 */
int usb_interface_list_delete_by_values(usb_device_t* device,
                                        const char* interface_class,
                                        const char* interface_subclass,
                                        const char* interface_protocol);

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_find(usb_device_t* device, usb_device_interface_t* interface);

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface_class Interface Class.
 * @param interface_subclass Interface SubClass.
 * @param interface_protocol Interface Protocol.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_find_by_values(usb_device_t* device,
                                                              const char* interface_class,
                                                              const char* interface_protocol,
                                                              const char* interface_subclass);

/**
 * @brief Add an interface to an internal device structure.
 *
 * @param device Internal device structure.
 * @param interface Internal interface structure.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_add(usb_device_t* device, usb_device_interface_t* interface);

/**
 * @brief Add an interface from an internal device structure.
 *
 * @param device Internal device structure.
 * @param parameters Hashtable containing interface parameters.
 * @return Pointer to interface structure.
 */
usb_interface_list_entry_t* usb_interface_list_add_by_parameters(usb_device_t* device, const amxc_var_t* const args);

#ifdef __cplusplus
}
#endif

#endif // __USB_DEVICE_LIST_H__
