/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxmisc.h>
#include <string.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>
#include <amxm/amxm.h>
#include <arpa/inet.h>
#include <ithread.h>
#include <amxmisc.h>

/**
 * Maximum length of UBus sock url string
 */
#define UBUS_SOCK_URL_MAX_LEN (1024)
/**
 * Maximum length of UBus backend url string
 */
#define UBUS_BE_URL_MAX_LEN (1024)
/**
 * Self tag
 */
#define ME "AMXMISC"
/**
 * Firewall ID tag for IPv4
 */
#define FIREWALL_UPNP_ID "tr069_connectionrequest"
/**
 * Firewall ID tag for IPv6
 */
#define FIREWALL_UPNP_ID_6 "tr069_connectionrequest6"
/**
 * Firewall ID tag for IPv6 global
 */
#define FIREWALL_UPNP_ID_6_GLOBAL "tr069_connectionrequest6_global"
/**
 * Firewall IPv4 version
 */
#define FIREWALL_UPNP_IP_4 4
/**
 * Firewall IPv6 version
 */
#define FIREWALL_UPNP_IP_6 6
/**
 * Firewall TCP protocol
 */
#define FIREWALL_UPNP_TCP "6"
/**
 * Firewall UDP protocol
 */
#define FIREWALL_UPNP_UDP "17"
/**
 * Firewall ID tag for IPv4 SSDP
 */
#define FIREWALL_UPNP_SSDP_ID "tr069_connectionrequest_ssdp"
/**
 * Firewall ID tag for IPv6 SSDP
 */
#define FIREWALL_UPNP_SSDP_ID_6 "tr069_connectionrequest_ssdp6"
/**
 * Firewall SSDP port
 */
#define FIREWALL_UPNP_SSDP_PORT 1900
/**
 * The library of Firewall Controller
 */
#define FIREWALL_CONTROLLER  "/usr/lib/amx/modules/mod-fw-amx.so"

/**
 * @file amxmisc.c
 * @brief The module for access to Ambiorix.
 */


static amxb_bus_ctx_t* gBusCtx = NULL;
/**
 * The url to UBus socket
 */
char ubus_sock_url[UBUS_SOCK_URL_MAX_LEN] = "ubus:/var/run/ubus.sock";
/**
 * The url to UBus alternative socket
 */
char ubus_sock_url_tmp[UBUS_SOCK_URL_MAX_LEN] = "ubus:/tmp/run/ubus/ubus.sock";
/**
 * The url to UBus backend library
 */
char ubus_backend_url[UBUS_BE_URL_MAX_LEN] = "/usr/bin/mods/amxb/mod-amxb-ubus.so";
static amxm_shared_object_t* fw_module = NULL;
static int gAmxInited = 0;
/**
 * The Ambiorix mutex
 */
ithread_mutex_t AmxMutext;

/**
 * @brief Load firewall controller library.
 */
static void LoadFwController(void) {
    if(amxm_so_open(&fw_module, "fw", FIREWALL_CONTROLLER)) {
        printf("ERROR: Couldn't open fw controller (%s)", FIREWALL_CONTROLLER);
    }
    return;
}

int InitAmx(void) {
    int r = -1;
    if(gBusCtx != NULL) {
        r = 0;
    } else {
        r = amxb_be_load(ubus_backend_url);
        if(r == 0) {
            r = amxb_connect(&gBusCtx, ubus_sock_url);
            if(r) {
                r = amxb_connect(&gBusCtx, ubus_sock_url_tmp);
                if(r) {
                    goto exit;
                }
            }
            LoadFwController();
            ithread_mutex_init(&AmxMutext, 0);
            gAmxInited = 1;
        }
    }
exit:
    return r;
}

void ShutdownAmx(void) {
    gAmxInited = 0;
    ithread_mutex_destroy(&AmxMutext);
    if(fw_module) {
        amxm_so_close(&fw_module);
    }
    amxb_disconnect(gBusCtx);
    gBusCtx = NULL;
    return;
}

/**
 * @brief Get specific data model parameter value from Ambiorix.
 *
 * @param [in] name The path of object
 * @param [in out] ret The object with result
 * @return 0 if FAIL
 * @return 1 if SUCCESS
 */
static int GetDataModelParam(const char* name, amxc_var_t* ret) {
    int res = 0;
    ithread_mutex_lock(&AmxMutext);
    when_failed(amxb_get(gBusCtx, name, 0, ret, 0), exit);
    if(amxc_var_type_of(ret) != AMXC_VAR_ID_NULL) {
        res = 1;
    }
exit:
    ithread_mutex_unlock(&AmxMutext);
    return res;
}

unsigned short GetAmxAgentPort(void) {
    unsigned short port = 0;
    amxc_var_t ret;
    if(!gAmxInited) {
        return 0;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("ManagementServer.ConnRequest.", &ret)) {
        port = GETP_UINT32(&ret, "0.0.ConnRequestPort");
    }
    amxc_var_clean(&ret);
    return port;
}

char* GetAmxAgentAcsIp(void) {
    static char acs_ip[INET6_ADDRSTRLEN] = {0};
    char* out = NULL;
    amxc_var_t ret;
    if(!gAmxInited) {
        return NULL;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("ManagementServer.State.", &ret)) {
        const char* pacs_ip = NULL;
        pacs_ip = GETP_CHAR(&ret, "0.0.ACSIP");
        if(pacs_ip && strlen(pacs_ip)) {
            strncpy(&acs_ip[0], pacs_ip, INET6_ADDRSTRLEN - 1);
            out = &acs_ip[0];
        }
    }
    amxc_var_clean(&ret);
    return out;
}

uint32_t GetAmxAgentAcsStatsSessions(void) {
    uint32_t out = 0;
    amxc_var_t ret;
    if(!gAmxInited) {
        return 0;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("ManagementServer.Stats.", &ret)) {
        out = GETP_UINT32(&ret, "0.0.SessionsSinceReboot");
    }
    amxc_var_clean(&ret);
    return out;
}

char* GetAmxAgentIp4(void) {
    static char ip4[INET_ADDRSTRLEN] = {0};
    char* out = NULL;
    amxc_var_t ret;
    if(!gAmxInited) {
        return NULL;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("IP.Interface.[Alias == 'lan'].IPv4Address.[Enable == 1].",
                         &ret)) {
        const char* ip = GETP_CHAR(&ret, "0.0.IPAddress");
        if(ip) {
            strncpy(&ip4[0], ip, INET_ADDRSTRLEN - 1);
            out = &ip4[0];
        }
    }
    amxc_var_clean(&ret);
    return out;
}

char* GetAmxAgentIp6(void) {
    static char ip6[INET6_ADDRSTRLEN] = {0};
    char* out = NULL;
    amxc_var_t ret;
    if(!gAmxInited) {
        return NULL;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("IP.Interface.[Alias == 'lan'].IPv6Address.[Alias != 'LLA' "
                         "&& Enable == 1 && IPAddress != '' && IPAddressStatus == 'Preferred'].",
                         &ret)) {
        const char* ip = GETP_CHAR(&ret, "0.0.IPAddress");
        if(ip) {
            strncpy(&ip6[0], ip, INET6_ADDRSTRLEN - 1);
            out = &ip6[0];
        }
    }
    amxc_var_clean(&ret);
    return out;
}

int GetAmxAgentIsSetIp6(void) {
    int res = 0;
    if(GetAmxAgentIp6()) {
        res = 1;
    }
    return res;
}

int GetAmxAgentIsSetIp4(void) {
    int res = 0;
    if(GetAmxAgentIp4()) {
        res = 1;
    }
    return res;
}

char* GetAmxAgentServerAddressIp6(void) {
    static char address[INET6_ADDRSTRLEN] = {0};
    char* ptr = NULL;
    amxc_var_t ret;
    if(!gAmxInited) {
        return NULL;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("Routing.Router.[Alias=='main'].IPv6Forwarding.[Enable==1 && DestIPPrefix != ''].", &ret)) {
        amxc_var_for_each(entry, GETP_ARG(&ret, "0.")) {
            const char* ServerAddr = GETP_CHAR(entry, "DestIPPrefix");
            /* Skip link-local addresses */
            if((ServerAddr[0] == 'f') || (ServerAddr[0] == ':')) {
                continue;
            }
            if(ServerAddr) {
                strncpy(&address[0], ServerAddr, INET6_ADDRSTRLEN - 1);
                ptr = strchr(address, '/');
                if(ptr) {
                    *ptr = '\0';
                }
                amxc_var_clean(&ret);
                return address;
            }
        }
    }
    amxc_var_clean(&ret);
    return NULL;
}

char* GetAmxAgentServerAddressIp4(void) {
    static char address[INET_ADDRSTRLEN] = {0};
    amxc_var_t ret;
    if(!gAmxInited) {
        return NULL;
    }
    amxc_var_init(&ret);
    if(GetDataModelParam("Routing.Router.[Alias=='main'].IPv4Forwarding.[Enable==1 && "
                         "GatewayIPAddress!='']", &ret)) {
        const char* adr = GETP_CHAR(&ret, "0.0.GatewayIPAddress");
        if(adr) {
            strncpy(&address[0], adr, INET_ADDRSTRLEN - 1);
            amxc_var_clean(&ret);
            return address;
        }
    }
    amxc_var_clean(&ret);
    return NULL;
}

/**
 * @brief Create Firewall rule.
 *
 * @param [in] name The name of ID
 * @param [in] proto The protocol TCP/UDP.
 * @param [in] port The port
 * @param [in] ip_ver The IP version
 */
static void CreateUpnpFirewallRule(const char* name, const char* proto,
                                   uint32_t port, int ip_ver) {
    amxc_var_t mgmt_server;
    const char* interface;

    amxc_var_t ret;
    amxc_var_t args;

    when_false(GetDataModelParam("ManagementServer.", &mgmt_server), exit);
    interface = GETP_CHAR(&mgmt_server, "0.Interface");

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "id", name);
    amxc_var_add_key(cstring_t, &args, "protocol", proto);
    amxc_var_add_key(cstring_t, &args, "interface", interface);
    amxc_var_add_key(uint32_t, &args, "destination_port", port);
    amxc_var_add_key(uint32_t, &args, "ipversion", ip_ver);
    amxc_var_add_key(bool, &args, "enable", true);
    amxm_execute_function("fw", "fw", "set_service", &args, &ret);
exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
    amxc_var_clean(&mgmt_server);
}

/**
 * @brief Destroy Firewall rule.
 *
 * @param [in] name The name of ID
 */
static void DestroyUpnpFirewallRule(const char* id) {
    amxc_var_t ret;
    amxc_var_t args;

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "id", id);
    amxm_execute_function("fw", "fw", "delete_service", &args, &ret);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void CreateUpnpFirewallRules(
    unsigned short portv4,
    unsigned short portv6,
    unsigned short portv6global,
    ip_mode_t isIPv6) {
    if(isIPv6) {
        CreateUpnpFirewallRule(FIREWALL_UPNP_ID_6, FIREWALL_UPNP_TCP, portv6,
                               FIREWALL_UPNP_IP_6);
        CreateUpnpFirewallRule(FIREWALL_UPNP_ID_6_GLOBAL, FIREWALL_UPNP_TCP,
                               portv6global, FIREWALL_UPNP_IP_6);
        CreateUpnpFirewallRule(FIREWALL_UPNP_SSDP_ID_6, FIREWALL_UPNP_UDP,
                               FIREWALL_UPNP_SSDP_PORT, FIREWALL_UPNP_IP_6);
    } else {
        CreateUpnpFirewallRule(FIREWALL_UPNP_ID, FIREWALL_UPNP_TCP, portv4,
                               FIREWALL_UPNP_IP_4);
        CreateUpnpFirewallRule(FIREWALL_UPNP_SSDP_ID, FIREWALL_UPNP_UDP,
                               FIREWALL_UPNP_SSDP_PORT, FIREWALL_UPNP_IP_4);
    }
}

void DeleteUpnpFirewallRule(ip_mode_t isIPv6) {
    if(isIPv6) {
        DestroyUpnpFirewallRule(FIREWALL_UPNP_ID_6);
        DestroyUpnpFirewallRule(FIREWALL_UPNP_ID_6_GLOBAL);
        DestroyUpnpFirewallRule(FIREWALL_UPNP_SSDP_ID_6);
    } else {
        DestroyUpnpFirewallRule(FIREWALL_UPNP_ID);
        DestroyUpnpFirewallRule(FIREWALL_UPNP_SSDP_ID);
    }
}

int CallAmxUpdateConnectionRequestURL(const char* host, const char* port) {
    int res = 1;
    amxc_var_t ret;
    amxc_var_t arg;
    if(!gAmxInited) {
        return 1;
    }
    ithread_mutex_lock(&AmxMutext);
    amxc_var_init(&ret);
    amxc_var_init(&arg);
    amxc_var_set_type(&arg, AMXC_VAR_ID_HTABLE);
    when_null(amxc_var_add_key(cstring_t, &arg, "host", host), exit);
    when_null(amxc_var_add_key(cstring_t, &arg, "port", port), exit);
    when_null(amxc_var_add_key(bool, &arg, "update", true), exit);
    when_failed(amxb_call(gBusCtx, "ManagementServer",
                          "updateConnectionRequestURL", &arg, &ret, 1), exit);
    res = 0;
exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&arg);
    ithread_mutex_unlock(&AmxMutext);
    return res;
}
