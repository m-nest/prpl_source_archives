/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bsd/string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/version.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>
#include <amxb/amxb.h>

#define ME "HOTPLUG"

#define AMXB_BACKEND_DEFAULT    "/usr/bin/mods/amxb/mod-amxb-ubus.so"
#define AMXB_URI_DEFAULT        "ubus:/var/run/ubus/ubus.sock"

/*
 * Host controller devices are named usb1, usb2, etc...
 */
#define HCD_PREFIX "usb"

/*
 * Physdevpath E-sata device
 */
#define ESATA_DEV "ahci"

/*
 * Maximum number of attempts to open a /dev/sdx disk device
 * On some device (especially Android smartphone), we notice that /dev/sda is created
 * but opening this file fails with error ENOMEDIUM
 * Retrying during 10 to 20 seconds generally solves the issue
 */
#define OPEN_DISK_MAX_ATTEMPTS 30

/*
 * Time (in seconds) between two attempts.
 */
#define OPEN_DISK_ATTEMPTS_INTERVAL 2

/*
 * Actions
 */
#define ACTION_ADD 0
#define ACTION_REMOVE 1
#define ACTION_BIND 2
#define ACTION_UNBIND 3
#define ACTION_UNKNOWN 4

/*
 * Global variables, often passed from one callback to another. Having them
 * all in the global scope eases referencing them.
 */
static char dev_type[64];
static char dev_name[64];
static char disk_name[16];
static char sysfs_name[64];
static char printer_name[64];
static char bus_num[16];
static char usb_version[16];
static char usb_type[16];
extern char** environ;

bool usb_call(const char* function, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handle error by logging the message and exiting the program.
 *
 * @param msg Error message to log.
 */
static void __attribute__((noreturn)) handle_error(const char* msg) {
    SAH_TRACEZ_INFO(ME, "error: %s", msg);
    exit(1);
}

/**
 * @brief Print the environment variables.
 */
static void print_env(void) {
    SAH_TRACEZ_INFO(ME, ">>> USB EVENT");
    if(environ) {
        char** s = environ;

        for(; *s; s++) {
            SAH_TRACEZ_INFO(ME, "%s", *s);
        }
    }
}

static void set_sysfs_name(void) {
    char* env_var, * ptr, * ptr2, * sysfs;

    env_var = getenv("PHYSDEVPATH");

    if((env_var == NULL) || (strstr(env_var, "devices") == NULL)) {
        env_var = getenv("DEVPATH");

        if(env_var == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH missing");
        }
    }

    sysfs = strdup(env_var);
    if(sysfs == NULL) {
        handle_error("Strdup of env_var failed");
    }

    ptr = strstr(sysfs, HCD_PREFIX);
    if(ptr == NULL) {
        handle_error("environment corrupted: PHYSDEVPATH error");
    }

    ptr2 = strchr(ptr, '/');

    if(ptr2 == NULL) {
        handle_error("environment corrupted: PHYSDEVPATH error");
    }

    ptr2++;
    ptr = strchr(ptr2, ':');

    if(ptr == NULL) {
        handle_error("environment corrupted: PHYSDEVPATH error");
    }

    *ptr = '\0';

    ptr = strrchr(ptr2, '/');

    ptr++;

    if(strlen(ptr) >= sizeof(sysfs_name)) {
        handle_error("Sysfs name too large");
    }

    strlcpy(sysfs_name, ptr, sizeof(sysfs_name));

    free(sysfs);
}

/**
 * @brief Set device message based on the action.
 *
 * @param action Action to be performed (add or remove).
 * @return 0 on success, 1 on failure.
 */
static unsigned int set_dev_msg(int action) {
    char* ptr, * env_var, * path;
    unsigned int ret = 0;

    print_env();

    if((action != ACTION_ADD) && (action != ACTION_REMOVE)) {
        handle_error("unsupported action");
    }

    env_var = getenv("PHYSDEVPATH");

    if(env_var != NULL) {
        path = strdup(env_var);

        if(path == NULL) {
            handle_error("unable to allocate memory");
        }
    } else {
        env_var = getenv("DEVPATH");

        if(env_var == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH missing");
        }

        path = strdup(env_var);

        if(path == NULL) {
            handle_error("unable to allocate memory");
        }

        /* Some kernels add a trailing /usb_device/usbdevX.X. */
        ptr = strstr(path, "/usb_device/usbdev");

        if(ptr == NULL) {
            handle_error("DEVPATH has no /usb_device/usbdevX.X part");
        }

        *ptr = '\0';
    }

    ptr = strrchr(path, '/');

    if(ptr == NULL) {
        handle_error("environment corrupted: PHYSDEVPATH isn't a path");
    }

    ptr++;

    if(*ptr == '\0') {
        handle_error("environment corrupted: PHYSDEVPATH ends with '/'");
    }

    if(strlen(ptr) >= sizeof(dev_name)) {
        handle_error("device name too large");
    }

    if(strncmp(ptr, HCD_PREFIX, sizeof(HCD_PREFIX) - 1) == 0) {
        SAH_TRACEZ_NOTICE(ME, "Notice: ignoring host controller %s\n", ptr);
        ret = 1;
    }

    strlcpy(dev_name, ptr, sizeof(dev_name));
    strlcpy(dev_type, "dev", sizeof(dev_type));
    free(path);

    return ret;
}

/**
 * @brief Set disk message based on the action.
 *
 * @param action Action to be performed (add or remove).
 * @return 0 on success, 1 on failure.
 */
static unsigned int set_disk_msg(int action) {
    char* env_var, * ptr, * ptr2, * sysfs;
    unsigned int ret = 0;

    print_env();

    if((action != ACTION_ADD) && (action != ACTION_REMOVE)) {
        handle_error("unsupported action");
    }

    env_var = getenv("DEVTYPE");
    if(env_var == NULL) {
        handle_error("Environment corrupted : DEVTYPE missing");
    }

    if(strncmp(env_var, "disk", strlen("disk") + 1) != 0) {
        SAH_TRACEZ_ERROR(ME, "notice : handle disks only");
        ret = 1;
    }

    env_var = getenv("PHYSDEVPATH");

    if(env_var == NULL) {
        env_var = getenv("DEVPATH");

        if(env_var == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH missing");
        }
    }

    sysfs = strdup(env_var);
    if(sysfs == NULL) {
        handle_error("Strdup of env_var failed");
    }

    if((ptr = strstr(sysfs, HCD_PREFIX)) != NULL) {
        ptr2 = strchr(ptr, '/');

        if(ptr2 == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH error");
        }

        ptr2++;
        ptr = strchr(ptr2, ':');

        if(ptr == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH error");
        }

        *ptr = '\0';

        ptr = strrchr(ptr2, '/');

        ptr++;

        if(strlen(ptr) >= sizeof(sysfs_name)) {
            handle_error("Sysfs name too large");
        }

        strlcpy(sysfs_name, ptr, sizeof(sysfs_name));
    } else if((ptr = strstr(sysfs, ESATA_DEV)) != NULL) {
        /* PATH in the form : PHYSDEVPATH=/devices/platform/ahci/host0/target0:0:0/0:0:0:0 */
        /* At the block end, ptr2 should point to "0:0:0:0" */
        ptr2 = strrchr(ptr, '/');

        if(ptr2 == NULL) {
            handle_error("environment corrupted: PHYSDEVPATH error");
        }

        ptr2++;

        if(strlen(ptr2) >= sizeof(sysfs_name)) {
            handle_error("Sysfs name too large");
        }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 4, 0)
        /* case seen in kernel 3.4 */
        /* DEVPATH=/devices/platform/strict-ahci.0/ata1/host0/target0:0:0/0:0:0:0/block/sdb */
        if(ptr2[0] == 's') {
            char* start;
            start = strstr(ptr, "target");
            if(start) {
                start = strchr(start, '/');
                if(start) {
                    ptr2 = start + 1;
                    ptr = strchr(ptr2, '/');
                    *ptr = 0;
                }
            }
        }
#endif

        strlcpy(sysfs_name, ptr2, sizeof(sysfs_name));
    } else {
        SAH_TRACEZ_ERROR(ME, "Sysfs name does not contain \"usb\" nor \"ahci\"");
    }
    free(sysfs);

    env_var = getenv("DEVNAME");
    if(env_var == NULL) {
        handle_error("Environment corrupted: DEVNAME missing");
    }

    if(strlen(env_var) >= sizeof(disk_name)) {
        handle_error("Disk name too large");
    }

    strlcpy(disk_name, env_var, sizeof(disk_name));
    strlcpy(dev_type, "disk", sizeof(dev_type));

    return ret;
}

/**
 * @brief Set bus message based on the action.
 *
 * @param action Action to be performed (add or remove).
 * @return 0 on success, 1 on failure.
 */
static unsigned int set_bus_msg(int action) {
    char* env_var, * ptr;
    unsigned int ret = 0;

    print_env();

    env_var = getenv("DEVTYPE");
    if(env_var == NULL) {
        handle_error("Environment corrupted : DEVTYPE missing");
    }

    if(strncmp(env_var, "usb_device", strlen("usb_device") + 1) != 0) {
        handle_error("notice : handle usb_device only");
    }

    env_var = getenv("DEVICENAME");

    if(action == ACTION_BIND) {
        if(env_var == NULL) {
            handle_error("Environment corrupted : DEVICENAME missing");
        }

        strlcpy(dev_name, env_var, sizeof(dev_name));
        strlcpy(sysfs_name, env_var, sizeof(sysfs_name));
        strlcpy(dev_type, "dev", sizeof(dev_type));
        return 0;
    } else if(action == ACTION_UNBIND) {
        if(env_var == NULL) {
            set_sysfs_name();
        } else {
            strlcpy(sysfs_name, env_var, sizeof(sysfs_name));
        }
        strlcpy(dev_type, "usb_device", sizeof(dev_type));
        return 0;
    } else if(action == ACTION_REMOVE) {
        if(env_var == NULL) {
            handle_error("Environment corrupted : DEVICENAME missing");
        }
        strlcpy(sysfs_name, env_var, sizeof(sysfs_name));
        strlcpy(dev_type, "usb_device", sizeof(dev_type));
        return 0;
    } else if(action != ACTION_ADD) {
        handle_error("unsupported action");
    }

    env_var = getenv("BUSNUM");
    if(env_var == NULL) {
        handle_error("Environment corrupted: BUSNUM missing");
    }
    if(strlen(env_var) >= sizeof(dev_name)) {
        handle_error("bunnum too large");
    }
    ptr = env_var;
    while(ptr[0] == '0') {
        ptr++;
    }
    strlcpy(bus_num, ptr, sizeof(bus_num));

    env_var = getenv("OF_COMPATIBLE_0");

    if(env_var == NULL) {
        // Try with DEVPATH
        env_var = getenv("DEVPATH");
    }

    if(env_var == NULL) {
        handle_error("unknow bus type");
    }
    if(strstr(env_var, "ohci")) {
        strlcpy(usb_type, "OHCI", sizeof(usb_type));
    } else if(strstr(env_var, "uhci")) {
        strlcpy(usb_type, "UHCI", sizeof(usb_type));
    } else if(strstr(env_var, "ehci")) {
        strlcpy(usb_type, "EHCI", sizeof(usb_type));
    } else if(strstr(env_var, "xhci")) {
        strlcpy(usb_type, "xHCI", sizeof(usb_type));
    } else {
        handle_error("unknow bus speed");
    }
    {
        FILE* fp;
        char file_usb_version[128];
        char tmp[16];
        size_t read_size = 0;
        env_var = getenv("DEVPATH");
        snprintf(file_usb_version, sizeof(file_usb_version), "/sys%s/version", env_var);
        fp = fopen(file_usb_version, "r");
        if(fp == NULL) {
            exit(EXIT_FAILURE);
        }
        read_size = fread(tmp, 1, 16, fp);
        if(!read_size) {
            exit(EXIT_FAILURE);
        }
        fclose(fp);
        tmp[ read_size - 1 ] = '\0';
        ptr = tmp;
        while(ptr[0] == ' ') {
            ptr++;
        }
        strlcpy(usb_version, ptr, sizeof(usb_version));
    }
    strlcpy(dev_type, "bus", sizeof(dev_type));
    return ret;
}

/**
 * @brief Set tty device message based on the action.
 *
 * @param action Action to be performed (add or remove).
 * @return 0 on success, 1 on failure.
 */
static unsigned int set_tty_device_msg(int action) {
    char* env_var;
    unsigned int ret = 0;

    print_env();

    if((action != ACTION_ADD) && (action != ACTION_REMOVE)) {
        handle_error("unsupported action");
    }

    set_sysfs_name();

    env_var = getenv("DEVNAME");
    if(env_var == NULL) {
        handle_error("Environment corrupted: DEVNAME missing");
    }

    if(strlen(env_var) >= sizeof(dev_name)) {
        handle_error("Printer name too large");
    }

    strlcpy(dev_name, env_var, sizeof(dev_name));
    strlcpy(dev_type, "tty", sizeof(dev_type));

    return ret;
}

/**
 * @brief Set printer message based on the action.
 *
 * @param action Action to be performed (add or remove).
 * @return 0 on success, 1 on failure.
 */
static unsigned int set_printer_msg(int action) {
    char* env_var;
    unsigned int ret = 0;

    print_env();

    if((action != ACTION_ADD) && (action != ACTION_REMOVE)) {
        handle_error("unsupported action");
    }

    set_sysfs_name();

    env_var = getenv("DEVNAME");
    if(env_var == NULL) {
        handle_error("Environment corrupted: DEVNAME missing");
    }

    if(strlen(env_var) >= sizeof(printer_name)) {
        handle_error("Printer name too large");
    }

    strlcpy(printer_name, env_var, sizeof(printer_name));
    strlcpy(dev_type, "printer", sizeof(dev_type));

    return ret;
}

/**
 * @brief Get the action to be performed from the environment variables.
 *
 * @return Action to be performed (add, remove, or unknown).
 */
static int get_action(void) {
    char* action;
    int ret = ACTION_UNKNOWN;

    action = getenv("ACTION");
    if(action == NULL) {
        handle_error("Environment corrupted: ACTION missing");
    }


    if(strncmp(action, "add", strlen("add") + 1) == 0) {
        ret = ACTION_ADD;
    } else if(strncmp(action, "remove", strlen("remove") + 1) == 0) {
        ret = ACTION_REMOVE;
    } else if(strncmp(action, "bind", strlen("bind") + 1) == 0) {
        ret = ACTION_BIND;
    } else if(strncmp(action, "unbind", strlen("unbind") + 1) == 0) {
        ret = ACTION_UNBIND;
    } else {
        SAH_TRACEZ_ERROR(ME, "Unknown action %s", action);
    }

    return ret;
}

/**
 * @brief Wait until the USB disk is ready.
 *
 * @param devName Name of the device.
 * @return 1 on success, -1 on failure.
 */
static int waitUntilUsbDiskIsReady(const char* devName) {
    int retry = OPEN_DISK_MAX_ATTEMPTS;
    char fullDevName[64];

    if(snprintf(fullDevName, sizeof(fullDevName), "/dev/%s", devName) >= (int) sizeof(fullDevName)) {
        SAH_TRACEZ_ERROR(ME, "devName %s too long", devName);
        return -1;
    }

    while(retry) {
        int fd;
        fd = open(fullDevName, O_RDONLY);
        if(fd < 0) {
            SAH_TRACEZ_ERROR(ME, "cannot open %s - errno=%d (%s)", devName, errno, strerror(errno));
            switch(errno) {
            case ENOMEDIUM:                         // no medium
                sleep(OPEN_DISK_ATTEMPTS_INTERVAL); // wait before retry
                retry--;
                break;
            case EINTR:         // interrupted
                break;          // retry immediatly
            default:
                return -1;
            }
        } else {
            close(fd);
            SAH_TRACEZ_INFO(ME, "open %s succeed after %d tries", devName, 30 - retry + 1);
            return 1;
        }
    }

    // all attempts have failed
    SAH_TRACEZ_ERROR(ME, "cannot open %s", devName);
    return -1;
}

/**
 * @brief Call the USB function with the given arguments.
 *
 * @param function Name of the function to call.
 * @param args Arguments to pass to the function.
 * @param ret Return value from the function.
 * @return True on success, false on failure.
 */
bool usb_call(const char* function, amxc_var_t* args, amxc_var_t* ret) {

    int rv = -1;
    amxb_bus_ctx_t* bus = NULL;
    amxb_be_load(AMXB_BACKEND_DEFAULT);
    amxb_connect(&bus, AMXB_URI_DEFAULT);
    if(bus == NULL) {
        handle_error("No bus for 'Device.USB.'");
    }

    rv = amxb_call(bus, "USB.", function, args, ret, 5);
    if(rv > 1) {
        SAH_TRACEZ_ERROR(ME, "error: amxb_call(%s, ...) failed: %d", function, rv);
        goto exit;
    }
    rv = AMXB_STATUS_OK;

exit:
    return rv == AMXB_STATUS_OK;
}

/**
 * @brief Main function for handling USB events.
 *
 * @param argc Argument count.
 * @param argv Argument values.
 * @return 0 on success, non-zero on failure.
 */
int main(UNUSED int argc, UNUSED char* argv[]) {
    unsigned int error;
    int action;
    char* env_var;
    env_var = getenv("HOTPLUG_TYPE");

    /* Configure TRACE */
    sahTraceOpen(ME, TRACE_TYPE_SYSLOG);
    sahTraceSetLevel(200);
    sahTraceAddZone(200, ME);

    if(env_var == NULL) {
        handle_error("must be called by HOTPLUG");
    }

    action = get_action();
    if(action == ACTION_UNKNOWN) {
        handle_error("Action not handled --> ignore ...");
    }

    if(((strncmp(env_var, "usblp", strlen("usblp") + 1) == 0) || (strncmp(env_var, "usb/lp", strlen("usb/lp") + 1) == 0))) {
        error = set_printer_msg(action);
    } else {
        env_var = getenv("SUBSYSTEM");
        if(env_var == NULL) {
            handle_error("invalid subsystem");
        } else if(strncmp(env_var, "usb_device", strlen("usb_device") + 1) == 0) {
            error = set_dev_msg(action);
        } else if(strncmp(env_var, "block", strlen("block") + 1) == 0) {
            error = set_disk_msg(action);
        } else if(strncmp(env_var, "usb", strlen("usb") + 1) == 0) {
            error = set_bus_msg(action);
        } else if(strncmp(env_var, "tty", strlen("tty") + 1) == 0) {
            error = set_tty_device_msg(action);
        } else {
            handle_error("unsupported subsystem");
        }
    }

    if(error) {
        return 0;
    }

    // patch to solve an issue with some Android smartphone with an external SDCARD
    // kernel creates a /dev/sda file and then calls this executable
    // but the /dev/sda file cannot be opened --> errno = ENOMEDIUM
    // waiting 10 to 20 seconds generally solves this issue
    if((strncmp(dev_type, "disk", strlen("disk") + 1) == 0) && (action == ACTION_ADD)) {
        int ready;
        SAH_TRACEZ_INFO(ME, "NOTIFY_ADD_USB_DISK : %s - %s", sysfs_name, disk_name);
        ready = waitUntilUsbDiskIsReady(disk_name);
        if(ready <= 0) {
            handle_error("Failed to open /dev device");
        }
    }

    amxc_var_t dev_args;
    amxc_var_t dev_ret;
    amxc_var_init(&dev_ret);
    amxc_var_init(&dev_args);
    amxc_var_set_type(&dev_args, AMXC_VAR_ID_HTABLE);

    if(strncmp(dev_type, "dev", strlen("dev") + 1) == 0) {
        amxc_var_add_key(cstring_t, &dev_args, "type", dev_type);
        amxc_var_add_key(cstring_t, &dev_args, "sysfs", sysfs_name);
        amxc_var_add_key(cstring_t, &dev_args, "name", dev_name);
        if((action == ACTION_ADD) || (action == ACTION_BIND)) {
            when_false(usb_call("addDev", &dev_args, &dev_ret), error);
        }
        if(action == ACTION_REMOVE) {
            when_false(usb_call("delDev", &dev_args, &dev_ret), error);
        }

    } else if(strncmp(dev_type, "disk", strlen("disk") + 1) == 0) {
        amxc_var_add_key(cstring_t, &dev_args, "type", dev_type);
        amxc_var_add_key(cstring_t, &dev_args, "sysfs", sysfs_name);
        amxc_var_add_key(cstring_t, &dev_args, "name", disk_name);
        if(action == ACTION_ADD) {
            when_false(usb_call("addDev", &dev_args, &dev_ret), error);
        }
        if(action == ACTION_REMOVE) {
            when_false(usb_call("delDev", &dev_args, &dev_ret), error);
        }

    } else if(strncmp(dev_type, "printer", strlen("printer") + 1) == 0) {
        amxc_var_add_key(cstring_t, &dev_args, "type", dev_type);
        amxc_var_add_key(cstring_t, &dev_args, "sysfs", sysfs_name);
        amxc_var_add_key(cstring_t, &dev_args, "name", printer_name);
        if(action == ACTION_ADD) {
            when_false(usb_call("addDev", &dev_args, &dev_ret), error);
        }
        if(action == ACTION_REMOVE) {
            when_false(usb_call("delDev", &dev_args, &dev_ret), error);
        }

    } else if(strncmp(dev_type, "tty", strlen("tty") + 1) == 0) {
        amxc_var_add_key(cstring_t, &dev_args, "type", dev_type);
        amxc_var_add_key(cstring_t, &dev_args, "sysfs", sysfs_name);
        amxc_var_add_key(cstring_t, &dev_args, "name", dev_name);
        if(action == ACTION_ADD) {
            when_false(usb_call("addDev", &dev_args, &dev_ret), error);
        }
        if(action == ACTION_REMOVE) {
            when_false(usb_call("delDev", &dev_args, &dev_ret), error);
        }
    } else if(strncmp(dev_type, "usb_device", strlen("usb_device") + 1) == 0) {
        amxc_var_add_key(cstring_t, &dev_args, "type", dev_type);
        amxc_var_add_key(cstring_t, &dev_args, "sysfs", sysfs_name);
        amxc_var_add_key(cstring_t, &dev_args, "name", dev_name);
        if(action == ACTION_REMOVE) {
            when_false(usb_call("delDev", &dev_args, &dev_ret), error);
        }
        if(action == ACTION_UNBIND) {
            when_false(usb_call("unbindDev", &dev_args, &dev_ret), error);
        }

    } else if((strncmp(dev_type, "bus", strlen("bus") + 1) == 0) && (action == ACTION_ADD)) {
        amxc_var_add_key(cstring_t, &dev_args, "busnum", bus_num);
        amxc_var_add_key(cstring_t, &dev_args, "usbversion", usb_version);
        amxc_var_add_key(cstring_t, &dev_args, "usbtype", usb_type);
        when_false(usb_call("addBus", &dev_args, &dev_ret), error);

    } else {
        handle_error("unsupported device");
    }
    goto exit;
error:
    handle_error("Failed to send notification");
exit:
    amxc_var_clean(&dev_ret);
    amxc_var_clean(&dev_args);
    return 0;
}
