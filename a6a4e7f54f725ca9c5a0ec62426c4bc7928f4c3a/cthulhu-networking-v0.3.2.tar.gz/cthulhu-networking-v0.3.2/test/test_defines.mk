MACHINE = $(shell $(CC) -dumpmachine)
SHELL = /bin/bash

SRCDIR = $(realpath ../../src)
COMMON_SRCDIR = $(realpath ../common/)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR = $(realpath ../../include ../../include_priv)
INCDIR += $(realpath ../common_includes)

HEADERS = $(wildcard $(INCDIR)/$(TARGET)/*.h)
SOURCES = $(wildcard $(SRCDIR)/*.c)
SOURCES += $(wildcard $(COMMON_SRCDIR)/*.c)

CFLAGS += -Werror -Wall -Wextra -Wno-attributes \
          --std=gnu99 -g3 -Wmissing-declarations \
          $(addprefix -I ,$(INCDIR)) \
          -fprofile-arcs -ftest-coverage \
          -fkeep-inline-functions -fkeep-static-functions \
          $(shell pkg-config --cflags cmocka)
LDFLAGS += -fprofile-arcs -ftest-coverage \
           -fkeep-inline-functions -fkeep-static-functions \
           $(shell pkg-config --libs cmocka) -lamxc \
           -lamxj -lamxp -lamxd -lamxm -lamxo -lamxb -lsahtrace -llcm -lcthulhu

CFLAGS += -DSAHTRACES_LEVEL=500 -DSAHTRACES_ENABLED

TEST_SRCDIR = $(shell pwd)


