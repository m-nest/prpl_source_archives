%populate {
    object Cellular.Interface {
{% let cellular_count = 0 %}
{% for (let Interface in BD.Interfaces): if (Interface.Type == "cellular"): %}
        instance add (Alias = "CELLULAR{{cellular_count}}", Name = "{{Interface.Name}}") {
            parameter Enable = "true";
            object USIM {
                parameter 'PIN' = "";
                parameter 'PINCheck' = "Off";
            }
            object Bearer {
            }
        }
{% cellular_count++ %}
{% endif; endfor; %}
    }

    object Cellular.AccessPoint {
{% cellular_count = 0 %}
{% for (let Interface in BD.Interfaces): if (Interface.Type == "cellular"): %}
        instance add (Alias = "AP{{cellular_count}}") {
            parameter Enable = "true";
            parameter Interface = "Device.Cellular.Interface.{{cellular_count + 1}}.";
        }
{% cellular_count++ %}
{% endif; endfor; %}
    }
} 
