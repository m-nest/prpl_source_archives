/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"

#define ME "device"

// Device information variables
static char device_class[4];
static char device_subclass[4];
static char device_protocol[4];
static char usb_version[6];
static char product_class[128];
static char serial_number[128];
static char manufacturer[128];
static char rate[10];
static uint32_t device_number;
static uint32_t device_version;
static uint32_t product_id;
static uint32_t vendor_id;
static uint32_t max_children;
static uint32_t configuration_value;
static uint32_t num_interfaces;
static bool is_suspended;
static bool is_self_powered;

/**
 * @brief Deletes a device object.
 *
 * @param host The host object.
 * @param device The device object.
 * @return int The status of the operation.
 */
int device_delete_object(amxd_object_t* host, amxd_object_t* device) {
    if((host == NULL) || (device == NULL)) {
        return -1;                                 // Add null check
    }
    amxd_trans_t trans;
    int rv = 0;
    int index;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.%d.Device.", amxd_object_get_index(host));
    index = amxd_object_get_index(device);
    amxd_trans_del_inst(&trans, index, NULL);

    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

exit:
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief Creates a device object.
 *
 * @param host The host object.
 * @param connected_port The connected port object.
 * @param name The device name.
 * @param id The device ID.
 * @param error The error code.
 * @return amxd_object_t* The device object.
 */
amxd_object_t* device_create_object(amxd_object_t* host, amxd_object_t* connected_port, const char* name, const char* id, int* error) {
    if((host == NULL) || (connected_port == NULL) || (name == NULL) || (id == NULL)) {
        return NULL;                                                                       // Add null check
    }
    int rv = 0;
    amxd_trans_t trans;
    amxc_string_t search;
    amxc_string_t dev_name;
    amxd_object_t* device = NULL;

    amxc_string_init(&search, 0);
    amxc_string_init(&dev_name, 0);
    amxd_trans_init(&trans);
    SAH_TRACEZ_NOTICE(ME, "Create Host.%d.Device %s (on Port %d)...", amxd_object_get_index(host), id, amxd_object_get_index(connected_port));
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.%d.Device.", amxd_object_get_index(host));
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "SysfsId", id);
    amxc_string_setf(&dev_name, "/dev/%s", name);
    amxd_trans_set_value(cstring_t, &trans, "SysDevName", amxc_string_get(&dev_name, 0));

    device_set_info(&trans, id, connected_port, error);

    // Create configurations
    if((configuration_value > 0) && (num_interfaces > 0)) {
        char configuration_id[MAX_ID_SIZE];
        snprintf(configuration_id, sizeof(configuration_id), "%u", configuration_value);
        rv = configuration_create_object(&trans, id, configuration_id, num_interfaces);
    }

    rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

    amxc_string_setf(&search, "USB.USBHosts.Host.%d.Device.[SysfsId=='%s']", amxd_object_get_index(host), id);
    device = amxd_dm_findf(get_dm(), "%s", amxc_string_get(&search, 0));
    when_null_trace(device, exit, ERROR, "Problem amxd_dm_findf ");

exit:
    *error = rv;
    amxd_trans_clean(&trans);
    amxc_string_clean(&search);
    amxc_string_clean(&dev_name);
    return device;
}

/**
 * @brief Fill the transaction with its system information.
 *
 * @param trans Transaction pointer.
 * @param sysfs_id The filesystem device id.
 * @param connected_port Port to which the device is connected.
 * @param error A returned error code.
 * @return True on success, false on failure.
 */
int device_set_info(amxd_trans_t* trans, const char* sysfs_id, amxd_object_t* connected_port, int* error) {
    if((connected_port == NULL) || (trans == NULL)) {
        return -1;                                                           // Add null check
    }
    int rv = 0;
    strlcpy(device_class, "00", sizeof(device_class));
    strlcpy(device_subclass, "00", sizeof(device_subclass));
    strlcpy(device_protocol, "00", sizeof(device_protocol));
    strlcpy(usb_version, "1.0", sizeof(usb_version));
    strlcpy(product_class, "", sizeof(product_class));
    strlcpy(serial_number, "", sizeof(serial_number));
    strlcpy(manufacturer, "", sizeof(manufacturer));
    strlcpy(rate, "Low", sizeof(rate));
    device_number = 0;
    device_version = 0;
    product_id = 0;
    vendor_id = 0;
    max_children = 0;
    configuration_value = 0;
    num_interfaces = 0;
    is_suspended = false;
    is_self_powered = false;
    bool sysfs_fail = true;

    if(sysfs_id == NULL) {
        *error |= 1;
        return *error;
    }
    // Get device info from sysfs
    device_get_sysfs_info(sysfs_id, error);

    for(int i = 0; i < SYSFS_GET_MAX_RETRIES; i++) {
        if((num_interfaces < INTERFACE_NUMBER_MAX) && (configuration_value < CONFIGURATION_NUMBER_MAX)) {
            sysfs_fail = false;
            break;
        } else {
            device_get_sysfs_info(sysfs_id, error);
        }
    }
    if(sysfs_fail) {
        *error |= 1;
        return *error;
    }

    char* port_path = amxd_object_get_path(connected_port, AMXD_OBJECT_INDEXED);
    if(port_path == NULL) {
        *error |= 1;
        return *error;
    }
    amxc_string_t usb_port;
    amxc_string_init(&usb_port, 0);
    amxc_string_setf(&usb_port, "Device.%s.", port_path);
    amxd_trans_set_value(uint32_t, trans, "Port", amxd_object_get_index(connected_port));
    amxd_trans_set_value(cstring_t, trans, "USBPort", amxc_string_get(&usb_port, 0));
    amxd_trans_set_value(cstring_t, trans, "DeviceClass", device_class);
    amxd_trans_set_value(cstring_t, trans, "Parent", "");
    amxd_trans_set_value(cstring_t, trans, "DeviceSubClass", device_subclass);
    amxd_trans_set_value(cstring_t, trans, "DeviceProtocol", device_protocol);
    amxd_trans_set_value(cstring_t, trans, "Manufacturer", manufacturer);
    amxd_trans_set_value(cstring_t, trans, "ProductClass", product_class);
    amxd_trans_set_value(cstring_t, trans, "SerialNumber", serial_number);
    amxd_trans_set_value(cstring_t, trans, "USBVersion", usb_version);
    amxd_trans_set_value(uint32_t, trans, "DeviceNumber", device_number);
    amxd_trans_set_value(uint32_t, trans, "DeviceVersion", device_version);
    amxd_trans_set_value(uint32_t, trans, "ProductID", product_id);
    amxd_trans_set_value(uint32_t, trans, "VendorID", vendor_id);
    amxd_trans_set_value(bool, trans, "IsSuspended", is_suspended);
    amxd_trans_set_value(bool, trans, "IsSelfPowered", is_self_powered);
    amxd_trans_set_value(uint32_t, trans, "MaxChildren", max_children);
    amxd_trans_set_value(cstring_t, trans, "Rate", rate);
    free(port_path);
    amxc_string_clean(&usb_port);

    *error |= rv;
    return *error;
}

/**
 * @brief Gets device information from sysfs.
 *
 * @param sysfs_id The device ID.
 * @param error The error code.
 * @return int The status of the operation.
 */
int device_get_sysfs_info(const char* sysfs_id, int* error) {
    if(sysfs_id == NULL) {
        return -1;                   // Add null check
    }
    SAH_TRACEZ_NOTICE(ME, "Get device %s information from sysfs", sysfs_id);
    struct sysfs_device* device = NULL;
    struct dlist* attrlist;

    // Find the device
    device = sysfs_open_device("usb", sysfs_id);

    // Get device info list
    attrlist = sysfs_get_device_attributes(device);

    // Navigate the list
    if(attrlist != NULL) {
        struct sysfs_attribute* attr;
        dlist_for_each_data(attrlist, attr, struct sysfs_attribute) {
            char tmp[128];
            if(strncmp(attr->name, "busnum", sizeof("busnum") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                device_number = strtoul((const char*) tmp, (char**) NULL, 10);
            } else if(strncmp(attr->name, "version", sizeof("version") - 1) == 0) {
                strlcpy(usb_version, trim_str(attr->value), sizeof(usb_version));
            } else if(strncmp(attr->name, "bDeviceClass", sizeof("bDeviceClass") - 1) == 0) {
                strlcpy(device_class, trim_str(attr->value), sizeof(device_class));
            } else if(strncmp(attr->name, "bDeviceSubClass", sizeof("bDeviceSubClass") - 1) == 0) {
                strlcpy(device_subclass, trim_str(attr->value), sizeof(device_subclass));
            } else if(strncmp(attr->name, "bcdDevice", sizeof("bcdDevice") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                device_version = strtoul((const char*) tmp, (char**) NULL, 10);
            } else if(strncmp(attr->name, "bDeviceProtocol", sizeof("bDeviceProtocol") - 1) == 0) {
                strlcpy(device_protocol, trim_str(attr->value), sizeof(device_protocol));
            } else if(strncmp(attr->name, "idProduct", sizeof("idProduct") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                product_id = strtoul((const char*) tmp, (char**) NULL, 16);
            } else if(strncmp(attr->name, "idVendor", sizeof("idVendor") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                vendor_id = strtoul((const char*) tmp, (char**) NULL, 16);
            } else if(strncmp(attr->name, "manufacturer", sizeof("manufacturer") - 1) == 0) {
                strlcpy(manufacturer, trim_str(attr->value), sizeof(manufacturer));
            } else if(strncmp(attr->name, "product", sizeof("product") - 1) == 0) {
                strlcpy(product_class, trim_str(attr->value), sizeof(product_class));
            } else if(strncmp(attr->name, "serial", sizeof("serial") - 1) == 0) {
                strlcpy(serial_number, trim_str(attr->value), sizeof(serial_number));
            } else if(strncmp(attr->name, "speed", sizeof("speed") - 1) == 0) {
                if(strncmp(attr->value, USB_SPEED_LOW_STR, sizeof(USB_SPEED_LOW_STR) - 1) == 0) {
                    strlcpy(rate, "Low", sizeof(rate));
                } else if(strncmp(attr->value, USB_SPEED_FULL_STR, sizeof(USB_SPEED_FULL_STR) - 1) == 0) {
                    strlcpy(rate, "Full", sizeof(rate));
                } else if(strncmp(attr->value, USB_SPEED_HIGH_STR, sizeof(USB_SPEED_HIGH_STR) - 1) == 0) {
                    strlcpy(rate, "High", sizeof(rate));
                } else if(strncmp(attr->value, USB_SPEED_SUPER_STR, sizeof(USB_SPEED_SUPER_STR) - 1) == 0) {
                    strlcpy(rate, "Super", sizeof(rate));
                } else {
                    SAH_TRACEZ_ERROR(ME, "Unknown USB rate: %s", attr->value);
                }
            } else if(strncmp(attr->name, "maxchild", sizeof("maxchild") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                max_children = strtoul((const char*) tmp, (char**) NULL, 10);
            } else if(strncmp(attr->name, "bMaxPower", sizeof("bMaxPower") - 1) == 0) {
                is_self_powered = (strncmp(attr->value, "0\n", sizeof("0\n") - 1) == 0);
            } else if(strncmp(attr->name, "bConfigurationValue", sizeof("bConfigurationValue") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                configuration_value = strtol((const char*) tmp, (char**) NULL, 10);
            } else if(strncmp(attr->name, "bNumInterfaces", sizeof("bNumInterfaces") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp));
                num_interfaces = strtol((const char*) tmp, (char**) NULL, 10);
            }
        }
    } else {
        *error |= 1;
    }
    sysfs_close_device(device);
    *error |= 0;
    return *error;
}
