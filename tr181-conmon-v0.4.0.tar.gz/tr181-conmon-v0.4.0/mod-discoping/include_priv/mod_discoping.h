/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__MOD_DISCOPING_H__)
#define __MOD_DISCOPING_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>

#include <discoping/arp_socket.h>
#include <discoping/ndp_socket.h>

// module names
#define MOD_CONMON_CTRL "conmon-ctrl"

// Core mod name
#define MOD_CORE "mod-conmon"

#define ME "mod-discoping"

#define str_empty(x) ((x == NULL) || (*x == 0))

/**
   @file
   @brief
   Main mod_discoping header file
 */

/**
   @defgroup mod_discoping

   Functions relatives to the start and shutdown of the mod_descoping module
 */

/**
   @ingroup mod_discoping
   @brief
   Enum containing the state of the conmon entry
 */
typedef enum _conmon_state {
    DISABLED,           /**< entry disabled */
    LINK_DOWN,          /**< wan link down */
    WAN_DOWN,           /**< wan down */
    INIT,               /**< start routine */
    REINIT,             /**< retries failed, dhcp will be restarted */
    MAINLOOP,           /**< mainloop routine */
    RETRY,              /**< retrying */
} conmon_state;

/**
   @ingroup mod_discoping
   @brief
   Main structure containing the state variable of a conmon entry object.
 */
typedef struct active_discoping {
    arp_socket_t* arp_socket;     /**< ARP socket */
    char* alias;                  /**< Alias of the active discoping */
    char* interface_name;         /**< Netdev name of the interface. */
    char* logical_path;           /**< Logical interface path */
    char* ll_interface_path;      /**< Lower link interface path */
    uint32_t ip_version;          /**< IP protocol version */
    char* local_ip;               /**< Local IP */
    char* local_mac;              /**< Mac of the interface */
    char* wan_ip;                 /**< DHCP option 3 IP Routers value */
    uint32_t main_interval;       /**< main check interval */
    uint32_t fail_interval;       /**< fail retry interval */
    uint32_t retries_max;         /**< Maximum number of retry */
    uint32_t retry_interval;      /**< Retry interval */

    uint32_t arpns_total_fail;    /**< Number of ARPPing fails */
    uint32_t total_dhcp_restarts; /**< Number of dhcp restart */
    uint32_t arpns_errors_sent;   /**< Numbers of ARP errors */

    // state tracking
    conmon_state state;           /**< current state as specified by conmon_state */
    uint32_t retry_current;       /**< how many times we are already retrying */
    bool link_up;                 /**< Is physical wan link up */
    bool wan_up;                  /**< Is logical wan link up */
    bool response_received;       /**< Did we receive a response */
    amxp_timer_t* main_timer;     /**< Main loop timer */
    amxp_timer_t* response_timer; /**< Timer to get a response */
    amxp_timer_t* deadline_timer; /**< Timer to stop the test */
    bool isdeferring;             /**< Is a defer call already made. */

    ndp_socket_t* ndp_socket;     /**< Neighbor discovery socket */

    amxc_llist_it_t it;           /**< Iterator */
} active_discoping_t;

/**
   @ingroup mod_discoping
   @brief
   Internal function to get the parser structure pointer used by the mod-discoping module.

   @return
   The mod-discoping module parser
 */
amxo_parser_t* get_parser(void);

/**
   @ingroup mod_discoping
   @brief
   Internal function to get or add a discoping item corresponding to an ConMon.Entry.i

   @param args Variant containing :
   - ip_version : The ip version of the ConMon.Entry.i object
   - alias : The Alias of the ConMon.Entry.i object
   - interface_name : The linux interface name corresponding to the Interface set in the the ConMon.Entry.i object
   - local_mac : The MAC address of the interface link to the ConMon.Entry.i object
   - logical_path : The interface of the ConMon.Entry.i object
   - retries_max : The number of retry the ConMon.Entry.i object
   - retry_interval : The response timout of the ConMon.Entry.i object
   - main_interval :  The interval for the main retry loop of the ConMon.Entry.i object
   - fail_interval : The interval for the fail retry loop of the ConMon.Entry.i object
   - arpns_errors_sent [optional] : Number of arp error send by the ConMon.Entry.i object
   - arpns_total_fail [optional] : Number of arp fail done by the ConMon.Entry.i object
   - total_dhcp_restarts [optional] : Number of dhcp DORA cycle done by the ConMon.Entry.i object

   @return
   The active_descoping_t structure's pointer related to the ConMon.Entry.i given in the args
 */
PRIVATE active_discoping_t* find_or_add_discoping_item(amxc_var_t* args);

/**
   @ingroup mod_discoping
   @brief
   Internal function to update a discoping item corresponding to an ConMon.Entry.i

   @param function_name The function name called, unused in this function
   @param args Variant containing :
   - ip_version : The ip version of the ConMon.Entry.i object
   - alias : The Alias of the ConMon.Entry.i object
   - interface_name : The linux interface name corresponding to the Interface set in the the ConMon.Entry.i object
   - local_mac : The MAC address of the interface link to the ConMon.Entry.i object
   - logical_path : The interface of the ConMon.Entry.i object
   - retries_max : The number of retry the ConMon.Entry.i object
   - retry_interval : The response timout of the ConMon.Entry.i object
   - main_interval :  The interval for the main retry loop of the ConMon.Entry.i object
   - fail_interval : The interval for the fail retry loop of the ConMon.Entry.i object
   - arpns_errors_sent [optional] : Number of arp error send by the ConMon.Entry.i object
   - arpns_total_fail [optional] : Number of arp fail done by the ConMon.Entry.i object
   - total_dhcp_restarts [optional] : Number of dhcp DORA cycle done by the ConMon.Entry.i object
   @param ret Extra return argument, not used in this function

   @return 0 on success, -1 elsewhere
 */
PRIVATE int update_config(const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret);

/**
   @ingroup mod_discoping
   @brief
   Internal function to remove a discoping item corresponding to an ConMon.Entry.i

   @param function_name The function name called, unused in this function
   @param args Variant containing :
   - ip_version : The ip version of the ConMon.Entry.i object
   - alias : The Alias of the ConMon.Entry.i object
   - interface_name : The linux interface name corresponding to the Interface set in the the ConMon.Entry.i object
   - local_mac : The MAC address of the interface link to the ConMon.Entry.i object
   - logical_path : The interface of the ConMon.Entry.i object
   - retries_max : The number of retry the ConMon.Entry.i object
   - retry_interval : The response timout of the ConMon.Entry.i object
   - main_interval :  The interval for the main retry loop of the ConMon.Entry.i object
   - fail_interval : The interval for the fail retry loop of the ConMon.Entry.i object
   - arpns_errors_sent [optional] : Number of arp error send by the ConMon.Entry.i object
   - arpns_total_fail [optional] : Number of arp fail done by the ConMon.Entry.i object
   - total_dhcp_restarts [optional] : Number of dhcp DORA cycle done by the ConMon.Entry.i object
   @param ret Extra return argument, not used in this function

   @return 0 on success, -1 elsewhere
 */
PRIVATE int stop(const char* function_name,
                 amxc_var_t* args,
                 amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __MOD_DISCOPING_H__
