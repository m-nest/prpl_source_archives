/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_tr181_sfp.h"

/* System headers */
#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <cmocka.h>

#include <signal.h>
#include <assert.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h> /* amxd_dm_findf() */
#include <amxd/amxd_object.h>

/* Own headers */
#include "sfpmgr.h"        /* sfpmgr_sfp_inserted() */
#include "sfpmgr_common.h" /* sfp_cage_t */
#include "sfpmgr_main.h"   /* sfp_get_dm() */
#include "json_utils.h"    /* read_json_from_file() */
#include "sfp_type.h"      /* SFP_GPON */
#include "sfp_ethdata.h"   /* retrieve_sfp_data() */

enum sfp_identifier {
    SFP_ID_SFP_WITH_SFF8472_MGMT_IF = 3
};

void sigalrm_handler(UNUSED int signum);

void sigalrm_handler(UNUSED int signum) {
    printf("SIGALRM received\n");
}

void test_sfpmgr_sfp_cage_info_update(UNUSED void** state) {
    signal(SIGALRM, sigalrm_handler);
    assert_int_equal(sfpmgr_sfp_inserted(/*cage_index=*/ 1, SFP_UNSUPPORTED), amxd_status_ok);

    sfp_cage_t* sfp_cage_info = get_sfp_cage_info(1);
    assert_non_null(sfp_cage_info);
    assert_int_equal(sfpmgr_cage_info_update(sfp_cage_info), 0);
}

void test_verify_gpon(UNUSED void** state) {
    test_sfp_insert(SFP_GPON);
    validate_sfp_info(SFP_GPON);
    test_sfp_rxlos();
    test_sfp_rxlos_clear();
    test_sfp_remove();
    validate_sfp_removal(SFP_GPON);

}

void test_verify_electrical_ethernet(UNUSED void** state) {
    test_sfp_insert(SFP_ELECTRICAL_ETHERNET);
    validate_sfp_info(SFP_ELECTRICAL_ETHERNET);
    test_sfp_rxlos();
    test_sfp_rxlos_clear();
    test_sfp_remove();
    validate_sfp_removal(SFP_ELECTRICAL_ETHERNET);
}

void test_verify_optical_ethernet(UNUSED void** state) {
    test_sfp_insert(SFP_OPTICAL_ETHERNET);
    validate_sfp_info(SFP_OPTICAL_ETHERNET);
    test_sfp_rxlos();
    test_sfp_rxlos_clear();
    test_sfp_remove();
    validate_sfp_removal(SFP_OPTICAL_ETHERNET);
}

void test_verify_XGSPON(UNUSED void** state) {
    test_sfp_insert(SFP_XGSPON);
    validate_sfp_info(SFP_XGSPON);
    test_sfp_rxlos();
    test_sfp_rxlos_clear();
    test_sfp_remove();
    validate_sfp_removal(SFP_XGSPON);
}

void test_sfp_insert(int sfptype) {
    signal(SIGALRM, sigalrm_handler);
    assert_int_equal(sfpmgr_sfp_inserted(1, sfptype), amxd_status_ok);

    sfp_cage_t* sfp_cage_info = get_sfp_cage_info(1);
    assert_non_null(sfp_cage_info);

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_object);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    assert_non_null(sfp_info);

    bool rxLosStatus;
    int cageState;
    rxLosStatus = sfp_info->rx_los;
    cageState = sfp_cage_info->state;
    assert(rxLosStatus == true);
    assert(cageState == 1);
}

void validate_sfp_info(int sfp_type) {

    int rc;
    bool rv;
    amxd_object_t* cage_object = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, 1);
    assert_non_null(cage_object);
    sfp_cage_t* sfp_cage_info = (sfp_cage_t*) cage_object->priv;
    assert_non_null(sfp_cage_info);

    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_object);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    assert_non_null(sfp_info);

    amxc_var_init(&sfp_info->key_value_pair);
    amxc_var_set_type(&sfp_info->key_value_pair, AMXC_VAR_ID_HTABLE);

    const char* const sfp_type_cstr = sfp_type_to_cstring(sfp_cage_info->sfp_type);
    const char* const sfp_type_expected_cstr = sfp_type_to_cstring(sfp_type);
    assert_string_equal(sfp_type_cstr, sfp_type_expected_cstr);

    sfp_ethtool_t* sfp_param = calloc(1, sizeof(sfp_ethtool_t));
    char file_path[PATH_SIZE];
    amxc_string_t file_path_str;
    amxc_string_init(&file_path_str, 0);

    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_ethtool_data.txt",
             sfp_type_cstr, sfp_type_cstr);
    amxc_string_setf(&file_path_str, "%s", file_path);
    amxc_string_replace(&file_path_str, " ", "_", 2);
    const char* const file_path_cstr = amxc_string_get(&file_path_str, 0);
    char command[1024];
    rc = snprintf(command, 1024, "cat %s", file_path_cstr);
    assert_true(rc > 0 && rc < 1024);
    rv = retrieve_sfp_data(command, &sfp_info->key_value_pair);
    assert_true(rv);

    assert_int_equal(sfpmgr_update_base_ext_structure(sfp_object, sfp_param), 0);

    update_dmc_sff8472_params(sfp_param);
    assert_int_equal(sfpmgr_update_threshold_structure(sfp_object, sfp_param), 0);
    assert_int_equal(sfpmgr_update_alarm_structure(sfp_object, sfp_param), 0);
    assert_int_equal(sfpmgr_update_warning_structure(sfp_object, sfp_param), 0);
    assert_int_equal(sfpmgr_update_status_structure(sfp_object, sfp_param), 0);
    assert_int_equal(sfpmgr_update_static_params(cage_object, sfp_object, sfp_param), 0);
    assert_int_equal(sfpmgr_update_dynamic_params(cage_object, sfp_object, sfp_param), 0);

    validate_sfp(sfp_type_cstr);
    amxc_var_clean(&sfp_info->key_value_pair);
    free(sfp_param);
    amxc_string_clean(&file_path_str);
}

void test_sfp_rxlos(UNUSED void** state) {
    signal(SIGALRM, sigalrm_handler);
    assert_int_equal(sfpmgr_sfp_rxlos(/*cage_index=*/ 1), 0);

    sfp_cage_t* sfp_cage_info = get_sfp_cage_info(1);
    assert_non_null(sfp_cage_info);
    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_object);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    assert_non_null(sfp_info);

    bool rxLosStatus;
    int cageState;
    rxLosStatus = sfp_info->rx_los;
    cageState = sfp_cage_info->state;
    assert(rxLosStatus == true);
    assert(cageState == 1);
}

void test_sfp_rxlos_clear(UNUSED void** state) {
    signal(SIGALRM, sigalrm_handler);
    assert_int_equal(sfpmgr_sfp_rxlos_cleared(/*cage_index=*/ 1), 0);

    sfp_cage_t* sfp_cage_info = get_sfp_cage_info(1);
    assert_non_null(sfp_cage_info);
    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_object);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    assert_non_null(sfp_info);

    bool rxLosStatus;
    int cageState;
    rxLosStatus = sfp_info->rx_los;
    cageState = sfp_cage_info->state;
    assert(rxLosStatus == false);
    assert(cageState == 2);
}

void test_sfp_remove(UNUSED void** state) {
    signal(SIGALRM, sigalrm_handler);
    assert_int_equal(sfpmgr_sfp_removed(/*cage_index=*/ 1), 0);

    sfp_cage_t* sfp_cage_info = get_sfp_cage_info(1);
    assert_non_null(sfp_cage_info);
    amxd_object_t* sfp_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_object);

    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    assert_non_null(sfp_info);

    bool rxLosStatus;
    int cageState;
    rxLosStatus = sfp_info->rx_los;
    cageState = sfp_cage_info->state;
    assert(rxLosStatus == true);
    assert(cageState == 0);
}

/**
 * Call read_json_from_file() on `fname` after changing spaces to underscores.
 */
static amxc_var_t* read_json_from_file_wrapper(const char* fname) {
    amxc_string_t path;
    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "%s", fname);
    amxc_string_replace(&path, " ", "_", 2);
    const char* const path_cstr = amxc_string_get(&path, 0);
    amxc_var_t* const result = read_json_from_file(path_cstr);
    amxc_string_clean(&path);
    return result;
}

void validate_sfp(const char* sfp_type) {

    amxc_var_t dm_params;
    amxc_var_init(&dm_params);
    amxc_var_t* expected_data = NULL;
    char file_path[PATH_SIZE];
    int rv = 0;
    int result = 0;
    const amxc_var_t* value = NULL;

    amxd_object_t* cage = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, 1);
    assert_non_null(cage);

    value = amxd_object_get_param_value(cage, "SFF8024Identifier");
    assert_non_null(value);
    assert_int_equal(GET_UINT32(value, NULL), SFP_ID_SFP_WITH_SFF8472_MGMT_IF);

    amxd_object_t* sfp_trans_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_trans_object);

    amxd_object_get_params(sfp_trans_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_transceiver.json",
             sfp_type, sfp_type);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_threshold_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_THRESHOLDS_PATH, 1);
    assert_non_null(sfp_threshold_object);

    amxd_object_get_params(sfp_threshold_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_threshold.json",
             sfp_type, sfp_type);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_warn_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_WARNINGS_PATH, 1);
    assert_non_null(sfp_warn_object);

    amxd_object_get_params(sfp_warn_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_warning.json",
             sfp_type, sfp_type);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_alarm_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_ALARMS_PATH, 1);
    assert_non_null(sfp_alarm_object);

    amxd_object_get_params(sfp_alarm_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_alarm.json",
             sfp_type, sfp_type);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* cage_status_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_STATUS_PATH, 1);
    assert_non_null(cage_status_object);

    amxd_object_get_params(cage_status_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_status.json",
             sfp_type, sfp_type);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);
}

void validate_sfp_removal(int sfp_type) {

    amxc_var_t dm_params;
    amxc_var_init(&dm_params);
    amxc_var_t* expected_data = NULL;
    char file_path[PATH_SIZE];
    int rv = 0;
    int result = 0;

    const char* const sfp_type_cstr = sfp_type_to_cstring(sfp_type);

    amxd_object_t* sfp_trans_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_PATH, 1);
    assert_non_null(sfp_trans_object);

    amxd_object_get_params(sfp_trans_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_removal_transceiver.json",
             sfp_type_cstr, sfp_type_cstr);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_threshold_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_THRESHOLDS_PATH, 1);
    assert_non_null(sfp_threshold_object);

    amxd_object_get_params(sfp_threshold_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_removal_threshold.json",
             sfp_type_cstr, sfp_type_cstr);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_warn_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_WARNINGS_PATH, 1);
    assert_non_null(sfp_warn_object);

    amxd_object_get_params(sfp_warn_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_removal_warning.json",
             sfp_type_cstr, sfp_type_cstr);
    expected_data = read_json_from_file_wrapper(file_path);
    amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* sfp_alarm_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_ALARMS_PATH, 1);
    assert_non_null(sfp_alarm_object);

    amxd_object_get_params(sfp_alarm_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_removal_alarm.json",
             sfp_type_cstr, sfp_type_cstr);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

    amxd_object_t* cage_status_object = amxd_dm_findf(sfp_get_dm(), SFP_XCVR_STATUS_PATH, 1);
    assert_non_null(cage_status_object);

    amxd_object_get_params(cage_status_object, &dm_params, amxd_dm_access_public);
    amxc_var_dump(&dm_params, STDOUT_FILENO);
    snprintf(file_path, sizeof(file_path), "../test_data/%s_test_data/%s_dm_removal_status.json",
             sfp_type_cstr, sfp_type_cstr);
    expected_data = read_json_from_file_wrapper(file_path);
    rv = amxc_var_compare(&dm_params, expected_data, &result);
    assert_int_equal(rv, 0);
    assert_int_equal(result, 0);
    clean_data(expected_data);
    amxc_var_clean(&dm_params);

}
