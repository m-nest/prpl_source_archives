# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.7.0 - 2025-12-08(15:30:12 +0000)

### Other

- - [tr181-temperature] Add High and Low Alarm Events to Device.DeviceInfo.TemperatureStatus

## Release v0.6.0 - 2025-06-11(06:29:45 +0000)

### Other

- - [tr181-temperature] improve usability

## Release v0.5.3 - 2025-05-23(14:58:44 +0000)

### Other

- [Plugin shutdown] Plugins Accessing Already-Stopped Dependencies

## Release v0.5.2 - 2025-04-29(12:43:07 +0000)

### Other

- [Import] [tr181-temperature] Missing runtime dependency on ucode-mod-fs

## Release v0.5.1 - 2025-04-22(13:06:34 +0000)

### Other

- - [tr181-temperatur] WiFi TemperatureStatus.TemperatureSensor.*.Status="Error"

## Release v0.5.0 - 2025-03-21(09:19:46 +0000)

### Other

- adapt synt to prpl-foundation
- [Plugin][tr181-temperature] Replace prefix X_PRPL-COM by X_PRLPWARE-COM within global variable call

## Release v0.4.11 - 2024-12-18(08:39:00 +0000)

### Other

- [Overheating] Enable alams and configure thresholds

## Release v0.4.10 - 2024-10-14(14:25:14 +0000)

### Other

- populate TemperatureStatus

## Release v0.4.9 - 2024-10-01(16:23:30 +0000)

## Release v0.4.8 - 2024-09-10(07:21:53 +0000)

### Other

- [Security][AppArmor] Apparmor must be available on PRPL builds

## Release v0.4.7 - 2024-08-27(12:10:06 +0000)

### Other

- Temperature Sensor support can't handle hwmon

## Release v0.4.6 - 2024-07-29(13:24:38 +0000)

## Release v0.4.5 - 2024-07-29(06:07:14 +0000)

### Other

- - [amx] Failing to restart processes with init scripts

## Release v0.4.4 - 2024-07-24(06:43:33 +0000)

### Other

- [tr181-temperature] Temperature alarms not working as it should.

## Release v0.4.3 - 2024-07-22(13:58:24 +0000)

### Other

- [tr181-temperature] Temperature sensor is disabled after reset
- [tr181-temperature] - Endless loop when thermal zone cannot be read

## Release v0.4.2 - 2024-07-16(10:36:59 +0000)

### Fixes

- [tr181-temperature] High CPU usage for sysbus process

## Release v0.4.1 - 2024-07-08(06:57:26 +0000)

## Release v0.4.0 - 2024-06-29(07:40:50 +0000)

### New

- Set correct reboot reason in case of overheating

## Release v0.3.5 - 2024-06-25(08:14:46 +0000)

### Other

- amx plugin should not run as root user

## Release v0.3.4 - 2024-05-07(08:46:06 +0000)

### Fixes

- - Initialization failed on generic config (without defaults odl defined in the configs)

## Release v0.3.3 - 2024-04-24(15:34:50 +0000)

### Fixes

- - move defaults odl to examples directory

## Release v0.3.2 - 2024-04-10(07:12:14 +0000)

### Changes

- Make amxb timeouts configurable

## Release v0.3.1 - 2024-03-29(12:54:35 +0000)

### Fixes

- [tr181-temperature]Configure Wifi temperature

## Release v0.3.0 - 2024-03-29(11:38:27 +0000)

### New

- [temperature]Some thermal entry don't have the same unit.

## Release v0.2.1 - 2024-03-26(16:20:56 +0000)

## Release v0.2.0 - 2024-03-23(13:09:35 +0000)

### New

- Add tr181-device proxy odl files to components

## Release v0.1.0 - 2024-02-29(09:52:53 +0000)

### New

- [LED] Support for Device.­Device­Info.­Temperature­Status.­Temperature­Sensor.­{i}. Data Model parameters.

