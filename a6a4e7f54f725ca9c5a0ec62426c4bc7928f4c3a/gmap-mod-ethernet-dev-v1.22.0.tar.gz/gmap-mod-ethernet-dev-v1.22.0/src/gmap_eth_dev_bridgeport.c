/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file Please read documentation in `gmap_eth_dev_bridge_port.h`.
 */

#include "gmap_eth_dev_bridgeport.h"
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_includes.h"
#include "gmap_eth_dev_util.h"
#include <amxb/amxb_subscribe.h>
#include <amxd/amxd_object_event.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxb/amxb.h>
#include <amxd/amxd_path.h>
#include <string.h>
#include <stdlib.h>


#define GMAP_BRIDGE_PORT_PATH "NetDev.Link."
#define GMAP_BRIDGE_PORT_KIND "bridge_port"

struct gmap_eth_dev_bridgeport {
    amxb_subscription_t* subscription_port_instance;
    amxb_subscription_t* subscription_port_modified;
    amxc_llist_t ports;
    amxc_llist_t subscriptions;
};


typedef struct s_port_entry {
    amxc_llist_it_t it;
    char* path;
    uint32_t master;
    bool isport;
} s_port_entry_t;

typedef struct s_subscription {
    amxc_llist_it_t it;
    uint32_t master;
    gmap_eth_dev_bridgeport_cb_t cb;
    void* priv;
} s_subscription_t;


// port_entry implementation
////////////////////////////////////////////////////////////////////////////////

static bool s_port_entry_new(s_port_entry_t** out,
                             const char* path,
                             uint32_t master,
                             const char* kind) {
    bool success = false;
    s_port_entry_t* entry = NULL;

    when_null_trace(out, exit, ERROR, "Null");
    *out = NULL;
    when_str_empty_trace(path, exit, ERROR, "Null or empty string");
    when_str_empty_trace(kind, exit, ERROR, "Null or empty string");
    entry = malloc(sizeof(s_port_entry_t));

    when_null_trace(entry, exit, ERROR, "Out of memory");
    amxc_llist_it_init(&entry->it);
    entry->path = strdup(path);

    when_null_trace(entry->path, exit, ERROR, "Out of memory");

    entry->master = master;
    entry->isport = strcmp(kind, GMAP_BRIDGE_PORT_KIND) == 0;

    success = true;
    *out = entry;

exit:
    if(!success && (entry != NULL)) {
        free(entry->path);
        free(entry);
    }
    return success;
}

static void s_port_entry_delete(amxc_llist_it_t* it) {
    s_port_entry_t* entry = NULL;

    when_null(it, exit);
    entry = amxc_llist_it_get_data(it, s_port_entry_t, it);

    free(entry->path);
    free(entry);
exit:
    return;
}

static s_port_entry_t* s_get_port(gmap_eth_dev_bridgeport_t* port,
                                  const char* path) {
    s_port_entry_t* entry = NULL;

    when_null_trace(port, exit, ERROR, "Null");
    when_str_empty_trace(path, exit, ERROR, "Null or empty string");

    amxc_llist_for_each(it, &port->ports) {
        s_port_entry_t* item = amxc_llist_it_get_data(it, s_port_entry_t, it);
        if(strcmp(item->path, path) == 0) {
            entry = item;
            break;
        }
    }

exit:
    return entry;
}


// port_subscription implementation
////////////////////////////////////////////////////////////////////////////////

static bool s_port_subscription_new(s_subscription_t** out,
                                    uint32_t master,
                                    gmap_eth_dev_bridgeport_cb_t cb,
                                    void* priv) {
    bool success = false;
    s_subscription_t* entry = NULL;

    when_null_trace(out, exit, ERROR, "Null");
    *out = NULL;
    when_str_empty_trace(cb, exit, ERROR, "Null or empty string");

    entry = malloc(sizeof(s_subscription_t));
    when_null_trace(entry, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&entry->it);
    entry->master = master;
    entry->cb = cb;
    entry->priv = priv;

    success = true;
    *out = entry;

exit:
    if(!success && (entry != NULL)) {
        free(entry);
    }
    return success;
}

static void s_port_subscription_delete(amxc_llist_it_t* it) {
    s_subscription_t* entry = NULL;

    when_null(it, exit);
    entry = amxc_llist_it_get_data(it, s_subscription_t, it);

    free(entry);
exit:
    return;
}

static s_subscription_t* s_get_subscription(gmap_eth_dev_bridgeport_t* port,
                                            uint32_t master,
                                            gmap_eth_dev_bridgeport_cb_t cb,
                                            void* priv) {
    s_subscription_t* entry = NULL;

    when_null_trace(port, exit, ERROR, "Null");
    when_null_trace(cb, exit, ERROR, "Null");

    amxc_llist_for_each(it, &port->subscriptions) {
        s_subscription_t* item = amxc_llist_it_get_data(it, s_subscription_t, it);
        if((item->cb == cb) && (item->master == master) && (item->priv == priv)) {
            entry = item;
            break;
        }
    }

exit:
    return entry;
}


// port event implementation
////////////////////////////////////////////////////////////////////////////////

static void s_port_set_master(gmap_eth_dev_bridgeport_t* port,
                              s_port_entry_t* entry,
                              uint32_t master,
                              bool isport) {
    when_true(entry->master == master && entry->isport == isport, exit);

    /* notify stopped matching. */
    if(entry->isport) {
        amxc_llist_for_each(it, &port->subscriptions) {
            s_subscription_t* subscription = amxc_llist_it_get_data(it, s_subscription_t, it);
            if(entry->master == subscription->master) {
                subscription->cb(port, entry->path, entry->master, false, subscription->priv);
            }
        }
    }

    /* modify entry */
    entry->master = master;
    entry->isport = isport;

    /* notify started matching. */
    if(isport) {
        amxc_llist_for_each(it, &port->subscriptions) {
            s_subscription_t* subscription = amxc_llist_it_get_data(it, s_subscription_t, it);
            if(master == subscription->master) {
                subscription->cb(port, entry->path, master, true, subscription->priv);
            }
        }
    }

    SAH_TRACEZ_INFO(ME, "port master or kind changed '%s'", entry->path);

exit:
    return;
}

static void s_instance_cb(const char* const sig_name UNUSED,
                          const amxc_var_t* const notification_data,
                          void* const priv) {
    gmap_eth_dev_bridgeport_t* port = (gmap_eth_dev_bridgeport_t*) priv;
    const char* notification = NULL;
    const char* path_root = NULL;
    const char* path = NULL;
    uint32_t index;
    s_port_entry_t* entry = NULL;
    amxc_string_t full_path;

    amxc_string_init(&full_path, 0);

    when_null_trace(notification_data, exit, ERROR, "NULL");
    when_null_trace(port, exit, ERROR, "NULL");

    notification = GET_CHAR(notification_data, "notification");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty string");

    path_root = GET_CHAR(notification_data, "path");
    when_str_empty_trace(path_root, exit, ERROR, "NULL/empty string");
    /* Check if some sub-instance was created/deleted. */
    when_false(strcmp(path_root, GMAP_BRIDGE_PORT_PATH) == 0, exit);

    index = GET_UINT32(notification_data, "index");
    when_true_trace(index == 0, exit, ERROR, "0 index");

    when_failed_trace(amxc_string_setf(&full_path, GMAP_BRIDGE_PORT_PATH "%d.", index),
                      exit, ERROR, "Failed to build port instance path.");
    path = amxc_string_get(&full_path, 0);

    if(strcmp(notification, "dm:instance-removed") == 0) {
        // A port was removed, clean it up
        entry = s_get_port(port, path);
        when_null(entry, exit);

        if(entry->isport) {
            amxc_llist_for_each(it, &port->subscriptions) {
                s_subscription_t* subscription = amxc_llist_it_get_data(it, s_subscription_t, it);
                if(entry->master == subscription->master) {
                    subscription->cb(port, path, entry->master, false, subscription->priv);
                }
            }
        }

        amxc_llist_it_clean(&entry->it, s_port_entry_delete);
        entry = NULL;

        SAH_TRACEZ_INFO(ME, "Stopped tracking port '%s'", path);
    } else if(strcmp(notification, "dm:instance-added") == 0) {
        // A port was created, add it if we don't know it yet.
        uint32_t master = GET_UINT32(GET_ARG(notification_data, "parameters"), "Master");
        const char* kind = GET_CHAR(GET_ARG(notification_data, "parameters"), "Kind");
        when_str_empty_trace(kind, exit, ERROR, "NULL/empty string");

        entry = s_get_port(port, path);
        if(entry != NULL) {
            SAH_TRACEZ_WARNING(ME, "New instance '%s' created, but the path is already known", path);
            s_port_set_master(port, entry, master, strcmp(kind, GMAP_BRIDGE_PORT_KIND) == 0);
        } else {
            when_false_trace(s_port_entry_new(&entry, path, master, kind), exit,
                             ERROR, "Failed to create new port entry");
            amxc_llist_append(&port->ports, &entry->it);

            if(entry->isport) {
                amxc_llist_for_each(it, &port->subscriptions) {
                    s_subscription_t* subscription = amxc_llist_it_get_data(it, s_subscription_t, it);
                    if(master == subscription->master) {
                        subscription->cb(port, path, master, true, subscription->priv);
                    }
                }
            }

            SAH_TRACEZ_INFO(ME, "Tracking new port '%s'", path);
        }
    }

exit:
    amxc_string_clean(&full_path);
    return;
}

static void s_mod_cb(const char* const sig_name UNUSED,
                     const amxc_var_t* const notification_data,
                     void* const priv) {
    gmap_eth_dev_bridgeport_t* port = (gmap_eth_dev_bridgeport_t*) priv;
    const size_t prefix_len = strlen(GMAP_BRIDGE_PORT_PATH);
    const amxc_var_t* params = NULL;
    const amxc_var_t* param_kind = NULL;
    const amxc_var_t* param_master = NULL;
    const char* notification = NULL;
    const char* path = NULL;
    const char* needle = NULL;
    uint32_t master = 0;
    const char* kind = NULL;
    bool isport = false;
    s_port_entry_t* entry = NULL;

    when_null_trace(notification_data, exit, ERROR, "NULL");
    when_null_trace(port, exit, ERROR, "NULL");

    notification = GET_CHAR(notification_data, "notification");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty string");
    when_true(strcmp(notification, "dm:object-changed") != 0, exit);

    path = GET_CHAR(notification_data, "path");
    when_str_empty_trace(path, exit, ERROR, "NULL/empty string");
    when_true(strncmp(path, GMAP_BRIDGE_PORT_PATH, prefix_len) != 0, exit);
    needle = strchr(path + prefix_len, '.');
    /* Expect an index after the known fixed prefix. */
    when_null(needle, exit);
    /* Expect no other path parts after the index. */
    when_false(*(needle + 1) == '\0', exit);

    entry = s_get_port(port, path);
    when_null_trace(entry, exit, ERROR, "Unknown port '%s' changed interface", path);

    params = GET_ARG(notification_data, "parameters");
    param_kind = GET_ARG(params, "Kind");
    if(param_kind != NULL) {
        kind = GET_CHAR(param_kind, "to");
        when_str_empty_trace(kind, exit, ERROR, "NULL/empty string");
        isport = strcmp(kind, GMAP_BRIDGE_PORT_KIND) == 0;
    } else {
        isport = entry->isport;
    }

    param_master = GET_ARG(params, "Master");
    if(param_master != NULL) {
        master = GET_UINT32(param_master, "to");
    } else {
        master = entry->master;
    }

    s_port_set_master(port, entry, master, isport);

exit:
    return;
}

static void s_subscribe(gmap_eth_dev_bridgeport_t* port, amxb_bus_ctx_t* ctx) {
    when_failed_trace(amxb_subscription_new(&port->subscription_port_instance,
                                            ctx,
                                            GMAP_BRIDGE_PORT_PATH,
                                            "notification == 'dm:instance-added' || notification == 'dm:instance-removed'",
                                            s_instance_cb,
                                            port),
                      exit, ERROR, "Failed to subscribe to port instance creation/destruction");

    when_failed_trace(amxb_subscription_new(&port->subscription_port_modified,
                                            ctx,
                                            GMAP_BRIDGE_PORT_PATH,
                                            "notification == 'dm:object-changed'",
                                            s_mod_cb,
                                            port),
                      exit, ERROR, "Failed to subscribe to port instance modification");
exit:
    return;
}

static void s_init_fetch(gmap_eth_dev_bridgeport_t* port, amxb_bus_ctx_t* ctx) {
    int status = -1;
    amxc_var_t var;

    amxc_var_init(&var);
    when_null_trace(port, exit, ERROR, "Null");

    status = amxb_get(ctx,
                      GMAP_BRIDGE_PORT_PATH "*.", 0,
                      &var, GMAP_ETH_DEV_BUS_TIMEOUT_SEC);
    when_failed_trace(status, exit, ERROR, "Failed to fetch " GMAP_BRIDGE_PORT_PATH " port interfaces: %d", status);

    /* Return variant has the form [{ "path" = {Master = 0, Kind = "", }, }] */
    amxc_var_for_each(entry, amxc_var_get_first(&var)) {
        const char* path = amxc_var_key(entry);
        uint32_t master = GET_UINT32(entry, "Master");
        const char* kind = GET_CHAR(entry, "Kind");
        s_port_entry_t* port_entry = NULL;

        when_str_empty(path, next);
        when_str_empty(kind, next);

        when_false(s_port_entry_new(&port_entry, path, master, kind), next);
        when_null(port_entry, next);

        amxc_llist_append(&port->ports, &port_entry->it);
        SAH_TRACEZ_INFO(ME, "Found "GMAP_BRIDGE_PORT_PATH " port instance '%s' for master '%d'", path, master);

next:
        continue;
    }

exit:
    amxc_var_clean(&var);
}


// port api implementation
////////////////////////////////////////////////////////////////////////////////

void gmap_eth_dev_bridgeport_new(gmap_eth_dev_bridgeport_t** port, amxb_bus_ctx_t* ctx) {
    when_null_trace(port, exit, ERROR, "NULL argument");

    *port = malloc(sizeof(gmap_eth_dev_bridgeport_t));
    when_null_trace(*port, exit, ERROR, "Out of Memory");

    (*port)->subscription_port_instance = NULL;
    (*port)->subscription_port_modified = NULL;
    amxc_llist_init(&(*port)->ports);
    amxc_llist_init(&(*port)->subscriptions);

    s_subscribe(*port, ctx);
    s_init_fetch(*port, ctx);

exit:
    return;
}

void gmap_eth_dev_bridgeport_delete(gmap_eth_dev_bridgeport_t** port) {
    if((port == NULL) || (*port == NULL)) {
        return;
    }

    amxb_subscription_delete(&(*port)->subscription_port_modified);
    amxb_subscription_delete(&(*port)->subscription_port_instance);
    amxc_llist_clean(&(*port)->ports, s_port_entry_delete);
    amxc_llist_clean(&(*port)->subscriptions, s_port_subscription_delete);

    free(*port);
    *port = NULL;
}


bool gmap_eth_dev_bridgeport_subscribe(gmap_eth_dev_bridgeport_t* port,
                                       uint32_t master,
                                       gmap_eth_dev_bridgeport_cb_t cb,
                                       void* priv) {
    bool success = false;
    s_subscription_t* subscription = NULL;

    when_null_trace(port, exit, ERROR, "Null");
    when_null_trace(cb, exit, ERROR, "Null");

    subscription = s_get_subscription(port, master, cb, priv);
    when_not_null_trace(subscription, exit, ERROR, "Duplicate subscription for master %d and callback %p", master, cb);

    when_false(s_port_subscription_new(&subscription, master, cb, priv), exit);

    amxc_llist_append(&port->subscriptions, &subscription->it);

    amxc_llist_for_each(it, &port->ports) {
        const s_port_entry_t* entry = amxc_llist_it_get_data(it, s_port_entry_t, it);
        if(entry->isport && (entry->master == master)) {
            cb(port, entry->path, master, true, subscription->priv);
        }
    }

exit:
    return success;
}

void gmap_eth_dev_bridgeport_unsubscribe(gmap_eth_dev_bridgeport_t* port,
                                         uint32_t master,
                                         gmap_eth_dev_bridgeport_cb_t cb,
                                         void* priv) {
    s_subscription_t* subscription = NULL;

    when_null_trace(port, exit, ERROR, "Null");
    when_null_trace(cb, exit, ERROR, "Null");

    subscription = s_get_subscription(port, master, cb, priv);
    when_null(subscription, exit);

    amxc_llist_it_clean(&subscription->it, s_port_subscription_delete);

exit:
    return;
}
