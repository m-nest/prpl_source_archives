MACHINE = $(shell $(CC) -dumpmachine)

SRCDIR = $(realpath ../../src)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR = $(realpath ../../include_priv)

SOURCES_MODULE = $(wildcard $(SRCDIR)/*.c)
OBJECTS_MODULE = $(addprefix $(OBJDIR)/,$(notdir $(SOURCES_MODULE:.c=.o)))
MODULE = ../$(MOT_DIR)/module.so

COMMON_TEST_SOURCES = $(wildcard $(COMMON_TEST_SRC_DIR)/*.c)
SOURCES_RUN_TEST = 

CFLAGS += -Werror -Wall -Wextra -Wno-attributes\
		  --std=gnu99 -fPIC -g3 \
		  $(addprefix -I ,$(INCDIR)) -I$(OBJDIR)/.. \
		  -fkeep-inline-functions -fkeep-static-functions \
		   -Wno-format-nonliteral \
		  $(shell pkg-config --cflags cmocka) \
		  -DSAHTRACES_ENABLED -DSAHTRACES_LEVEL=500

LDFLAGS += -fkeep-inline-functions -fkeep-static-functions \
		   $(shell pkg-config --libs cmocka) \
		   -lamxb -lamxd -lamxm -lamxp -lamxc -lsahtrace

