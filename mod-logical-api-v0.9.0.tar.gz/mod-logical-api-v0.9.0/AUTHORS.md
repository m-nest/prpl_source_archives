Authors
=======

This is the list of mod-logical-api authors for copyright purposes.

Groups
------

 * SoftAtHome
 * Orange

Individuals
-----------
