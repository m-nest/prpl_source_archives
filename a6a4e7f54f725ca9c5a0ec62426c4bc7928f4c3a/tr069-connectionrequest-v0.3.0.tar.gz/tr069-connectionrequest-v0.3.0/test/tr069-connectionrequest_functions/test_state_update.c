/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "test_helpers.h"

void StateUpdate(char* UDN, int Service, IXML_Document* ChangedVariables, char* State);

/* Wrappers */

/* Helpers */
static IXML_Document* make_event_with_ip(const char* ip) {
    char xml[256];
    snprintf(xml, sizeof(xml),
             "<e:propertyset xmlns:e=\"urn:schemas-upnp-org:event-1-0\">"
             "<e:property><ExternalIPAddress>%s</ExternalIPAddress></e:property>"
             "</e:propertyset>", ip);
    IXML_Document* doc = ixmlParseBuffer(xml);
    assert_non_null(doc);
    return doc;
}

static IXML_Document* make_event_without_ip(void) {
    const char* xml =
        "<e:propertyset xmlns:e=\"urn:schemas-upnp-org:event-1-0\">"
        "<e:property><SomeOtherField>value</SomeOtherField></e:property>"
        "</e:propertyset>";
    IXML_Document* doc = ixmlParseBuffer(xml);
    assert_non_null(doc);
    return doc;
}

/* Setup */
static int setup(UNUSED void** s) {
    g_ixml_free_passthrough = 1;
    return 0;
}
static int teardown(UNUSED void** s) {
    g_ixml_free_passthrough = 0;
    return 0;
}

/* Tests */
static void test_StateUpdate_parses_external_ip(UNUSED void** state) {
    memset(&IGD, 0, sizeof(IGD));
    strncpy(IGD.UDN, "uuid:dev-1", sizeof(IGD.UDN) - 1);

    IXML_Document* doc = make_event_with_ip("203.0.113.7");

    memset(IGD.ExternalIPAddress, 0, sizeof(IGD.ExternalIPAddress));
    StateUpdate(IGD.UDN, SERVICE_WANIPCONNECTION, doc, IGD.ExternalIPAddress);

    assert_string_equal(IGD.ExternalIPAddress, "203.0.113.7");
    ixmlDocument_free(doc);
}

static void test_StateUpdate_handles_missing_field(UNUSED void** state) {
    memset(&IGD, 0, sizeof(IGD));
    strncpy(IGD.UDN, "uuid:dev-2", sizeof(IGD.UDN) - 1);

    IXML_Document* doc = make_event_without_ip();

    memset(IGD.ExternalIPAddress, 0, sizeof(IGD.ExternalIPAddress));
    strncpy(IGD.ExternalIPAddress, "unchanged", sizeof(IGD.ExternalIPAddress) - 1);

    StateUpdate(IGD.UDN, SERVICE_WANIPCONNECTION, doc, IGD.ExternalIPAddress);

    assert_string_equal(IGD.ExternalIPAddress, "unchanged");

    ixmlDocument_free(doc);
}

const struct CMUnitTest g_state_update_tests[] = {
    cmocka_unit_test_setup_teardown(test_StateUpdate_parses_external_ip, setup, teardown),
    cmocka_unit_test_setup_teardown(test_StateUpdate_handles_missing_field, setup, teardown),
};
const size_t g_state_update_tests_count =
    sizeof(g_state_update_tests) / sizeof(g_state_update_tests[0]);
