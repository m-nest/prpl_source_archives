/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__LOGICAL_API_GETTERS_H__)
#define __LOGICAL_API_GETTERS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxb/amxb.h>
#include <amxd/amxd_types.h>
#include <ipat/ipat.h>

char* get_dhcpv4_pool(const char* ip_intf);
char* get_dhcpv6_pool(const char* ip_intf);
char* get_ra_pool(const char* ip_intf);

int get_ip_params(const char* intf, uint32_t index, amxc_var_t* ret);
int get_private_ipv4_params(const char* intf, amxc_var_t* ret);
int get_public_ipv4_params(const char* intf, amxc_var_t* ret);
int get_ipv6_params(const char* intf, amxc_var_t* ret);
int get_dhcpv4_params(const char* dhcp_pool, amxc_var_t* ret);
int get_dhcpv6_params(const char* dhcp_pool, amxc_var_t* ret);
int get_device_macaddr(const char* device, amxc_var_t* ret);
int get_ra_params(const char* intf, amxc_var_t* ret);
int get_remote_gateway(const char* ip_intf, amxc_var_t* ret);

amxc_var_t* collect_ip_params(amxc_var_t* args);
int collect_ip_params_list(amxc_var_t* args, amxc_var_t** ret);
amxc_var_t* collect_dhcpv4_params(amxc_var_t* args);
int collect_dhcpv4_pool_params(amxc_var_t* args, amxc_var_t** ret);
amxc_var_t* collect_dhcpv6_params(amxc_var_t* args, const char* ip_intf);
amxc_var_t* collect_ra_params(amxc_var_t* args, const char* ip_intf);
int get_remote_v6_gateway(amxc_var_t* ret);

/**
   @brief
   Retrieve an argument from arguments list, based on its key
   Check that the value is an IP V4 value

   @param params[in] arguments list
   @param attr_key[in] argument key
   @param ip_addr[out] retrieved ip address in text format.
                       NULL if the value cannot be retrieved.

   @return
   true if the value has been retrieved and has a correct ipv4 format (or is null).
   false if the value has not a correct ipv4 format.
 */
bool get_ipv4_address_by_key(amxc_var_t* params, const char* attr_key, char** ip_addr);

/**
   @brief
   Retrieves DHCPv4Server object

   @param dhcp_object[in] path to the dhcp object
   @param dhcp_object_dm[out] variant that will contain the dhcp object attributes

   @return
   - true if the value has successfully been retrieved.
   - false if failed to retrieve the value.
 */
bool get_dhcpv4_var(const char* dhcp_object, amxc_var_t* dhcp_object_dm);

/**
   @brief
   Search for the associated DHCPv4Server.Pool
   Then retrieves DHCPv4Server.Pool.{i}.ReservedAddresses value

   @param pool_alias[in] DHCP pool alias
   @param reserved_addresses_list[out] variant that will contain the list of reserved addresses

   @return
   - true if the value has successfully been retrieved.
   - false if failed to retrieve the value.
 */
bool get_dhcpv4_pool_reserved_addresses(const char* pool_alias, amxc_var_t* reserved_addresses_list);

/**
   @brief
   Compute the subnet address and broadcast address of a subnet
   The subnet is defined by ip_address/subnet_mask ex: 192.168.1.1/255.255.255.0

   @param ip_address[in] IP address used to define the subnet
   @param subnet_mask[in] subnet mask used to define the subnet
   @param subnet_address[out] subnet address
   @param broadcast_address[out] broadcast_address address

 */
void get_subnet_reserved_addresses(const char* ip_address, const char* subnet_mask,
                                   ipat_t* subnet_address, ipat_t* broadcast_address);

/**
   @brief
   If a value of a dhcp attribute is null try to fallback on the value of the same attribute
   of the existing dhcp pool

   @param dhcp_pool_path[in] dhcp pool path where to find the fallback value
   @param attr_name[in] name of the attribute to process
   @param attr_value[in/out] value of the attribute that will be changed if null

 */
void retrieve_dhcp_fallback_value(const char* dhcp_pool_path, const char* attr_name, char** attr_value);

#ifdef __cplusplus
}
#endif

#endif // __LOGICAL_API_GETTERS_H__
