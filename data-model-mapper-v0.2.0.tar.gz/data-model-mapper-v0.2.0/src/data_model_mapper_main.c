/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include "data_model_mapper.h"

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ME "data-model-mapper"

static data_model_mapper_app_t app;

static void registration_verify(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                amxb_request_t* req,
                                int status,
                                void* priv) {
    const char* proxy_name = (const char*) priv;

    if(status != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to register a mapping for '%s', error is %d", proxy_name, status);
    } else {
        SAH_TRACEZ_INFO(ME, "Success to register a mapping for '%s'", proxy_name);
    }

    amxb_close_request(&req);
}

static void find_and_register_proxy_objects(void) {
    amxc_var_t* proxy_setting = NULL;
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has("ProxyManager");

    if(bus_ctx == NULL) {
        SAH_TRACEZ_WARNING(ME, "ProxyManager is not found on the bus, unable to register the object");
        return;
    }

    proxy_setting = amxo_parser_get_config(data_model_mapper_get_parser(), "proxy-object");
    if(proxy_setting == NULL) {
        SAH_TRACEZ_INFO(ME, "proxy-object is NULL");
    } else if(amxc_var_type_of(proxy_setting) == AMXC_VAR_ID_HTABLE) {
        const amxc_htable_t* htable = amxc_var_constcast(amxc_htable_t, proxy_setting);

        if(amxc_htable_size(htable) == 0) {
            SAH_TRACEZ_INFO(ME, "Empty proxy-object table");
        }

        amxc_htable_for_each(it, htable) {
            const char* key = amxc_htable_it_get_key(it);
            amxb_request_t* req = NULL;
            amxc_var_t values;
            char proxy_name[256];

            snprintf(proxy_name, sizeof(proxy_name), "Device.%s", key);

            amxc_var_init(&values);
            amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
            amxc_var_add_key(cstring_t, &values, "proxy", proxy_name);
            amxc_var_add_key(cstring_t, &values, "real", key);

            req = amxb_async_call(bus_ctx, "ProxyManager", "register", &values, registration_verify, (void*) key);
            if(req == NULL) {
                SAH_TRACEZ_WARNING(ME, "Bad amxb_async_call, request is NULL");
            }
            amxc_var_clean(&values);
        }
    } else {
        SAH_TRACEZ_INFO(ME, "Bad proxy-object format");
    }
}

amxd_dm_t* data_model_mapper_get_dm(void) {
    return app.dm;
}

amxo_parser_t* data_model_mapper_get_parser(void) {
    return app.parser;
}

int _data_model_mapper_main(int reason,
                            amxd_dm_t* dm,
                            amxo_parser_t* parser) {
    switch(reason) {
    case 0:     // START
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*      data-model-mapper started     *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");

        app.dm = dm;
        app.parser = parser;

        find_and_register_proxy_objects();

        break;
    case 1:     // STOP
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*      data-model-mapper stopped     *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        app.dm = NULL;
        app.parser = NULL;
        break;
    }

    return 0;
}
