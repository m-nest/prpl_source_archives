/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>

#include "dm_dhcpv6client.h"
#include "dm_client.h"
#include "dm_server.h"
#include "firewall.h"

int dm_client_action(UNUSED const char* function_name,
                     amxc_var_t* args,
                     amxc_var_t* ret) {
    int retval = -1;
    amxd_object_t* client = dm_get_client(args);
    uint32_t action = GET_UINT32(args, "Action");

    when_null(client, exit);

    switch(action) {
    case DHCPV6_ACTION_STARTED:
        dm_client_status(client, dhcpv6c_status_error_misconfigure);
        break;
    case DHCPV6_ACTION_STOPPED:
        dm_client_init(client);
        break;
    default:
        break;
    }

    dm_client_dhcp_status(client, action);
    retval = 0;
exit:
    amxc_var_set(int32_t, ret, retval);
    return retval;
}

amxd_status_t _Renew(amxd_object_t* object,
                     UNUSED amxd_function_t* func,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    client_info_t* info = (client_info_t*) object->priv;
    amxd_status_t status = amxd_status_unknown_error;

    when_null_trace(info, exit, ERROR, "No internal data found for the client");

    status = dm_dhcpv6c_renew_client(info);
    when_failed_trace(status, exit, ERROR, "Failed to renew client");
exit:
    return status;
}

amxd_status_t _Release(amxd_object_t* object,
                       UNUSED amxd_function_t* func,
                       UNUSED amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    client_info_t* info = (client_info_t*) object->priv;
    amxd_status_t status = amxd_status_unknown_error;

    when_null_trace(info, exit, ERROR, "No internal data found for the client");

    status = dm_dhcpv6c_release_client(info);
    when_failed_trace(status, exit, ERROR, "Failed to release client");
    dm_client_status(object, info->flags.bit.enable ? dhcpv6c_status_error_misconfigure : dhcpv6c_status_disabled);
exit:
    return status;
}

