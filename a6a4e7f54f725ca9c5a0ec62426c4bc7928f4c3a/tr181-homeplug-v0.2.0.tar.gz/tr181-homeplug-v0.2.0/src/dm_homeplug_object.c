/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdio.h>

#include "dm_homeplug.h"
#include "homeplug.h"

int dm_homeplug_update_status(amxd_object_t* homeplug_obj, const char* status) {
    amxd_trans_t transaction;
    int retval = 0;

    when_null_trace(homeplug_obj, exit, ERROR, "homeplug_obj is NULL pointer");
    when_str_empty_trace(status, exit, ERROR, "empty status message");

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, homeplug_obj);

    amxd_trans_set_value(cstring_t, &transaction, "Status", status);

    retval = amxd_trans_apply(&transaction, homeplug_get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to update status");
    }

    amxd_trans_clean(&transaction);
exit:

    return retval;
}

bool dm_interface_add_or_update_device(amxd_object_t* homeplug_interface_obj_x,
                                       const uint8_t* device_mac,
                                       amxc_var_t* device_params) {
    bool result = false;
    amxd_trans_t trans;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* device_obj = NULL;
    amxd_object_t* device_obj_x = NULL;
    const char* param_key = NULL;

    SAH_TRACEZ_INFO(ME, "add_or_update_interface_device_instance");
    when_str_empty_trace((const char*) device_mac, exit, ERROR, "empty device mac address");
    when_null_trace(homeplug_interface_obj_x, exit, ERROR, " interface object instance is NULL");
    when_null_trace(device_params, exit, ERROR, "device params is NULL");
    SAH_TRACEZ_INFO(ME, "device instance to add %s", device_mac);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    device_obj = amxd_object_findf(homeplug_interface_obj_x, "AssociatedDevice.");
    when_null_trace(device_obj, exit, ERROR, "Can not find AssiciatedDevice in datamodel");
    device_obj_x = amxd_object_findf(device_obj, "%s.", (const char*) device_mac);
    amxd_trans_select_object(&trans, device_obj);

    if(!device_obj_x) {
        amxd_trans_add_inst(&trans, 0, (const char*) device_mac);
    } else {
        amxd_trans_select_object(&trans, device_obj_x);
    }
    amxc_var_for_each(device_param, device_params) {
        param_key = amxc_var_key(device_param);
        SAH_TRACEZ_INFO(ME, "param key: %s", param_key);
        amxd_trans_set_param(&trans, param_key, device_param);
    }
    status = amxd_trans_apply(&trans, homeplug_get_dm());
    when_failed_trace(status, exit, ERROR, "Apply transaction failed, status: %d", status);
exit:
    amxd_trans_clean(&trans);
    result = (status == amxd_status_ok) ? true : false;
    return result;
}

bool dm_device_update_associated_devices(amxd_object_t* homeplug_interface_obj_x,
                                         const uint8_t* device_mac,
                                         amxc_var_t* associated_devices) {
    bool result = false;
    amxd_trans_t trans;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* associated_device_obj = NULL;
    when_str_empty_trace((const char*) device_mac, exit, ERROR, "empty device mac address");
    when_null_trace(homeplug_interface_obj_x, exit, ERROR, " interface object instance is NULL");
    when_null_trace(associated_devices, exit, ERROR, " associated devices is NULL");
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    SAH_TRACEZ_INFO(ME, "update_associated devices");
    associated_device_obj = amxd_object_findf(homeplug_interface_obj_x, "AssociatedDevice.");
    when_null_trace(associated_device_obj, exit, ERROR, "Can not find Associated Device in datamodel");

    amxc_var_for_each(associated_device, associated_devices) {
        const char* var_key = amxc_var_key(associated_device);
        amxd_object_t* associated_device_obj_x = amxd_object_findf(associated_device_obj, "%s.", var_key);
        when_null_trace(associated_device_obj_x, exit, ERROR, "Can not find Associated Device with key %s in datamodel", var_key);
        amxd_trans_select_object(&trans, associated_device_obj_x);

        amxc_var_for_each(device_param, associated_device) {
            const char* param_key = amxc_var_key(device_param);
            SAH_TRACEZ_INFO(ME, "param key: %s", param_key);
            amxd_trans_set_param(&trans, param_key, device_param);
        }
    }
    status = amxd_trans_apply(&trans, homeplug_get_dm());
    when_failed_trace(status, exit, ERROR, "Apply transaction failed, status: %d", status);
exit:
    amxd_trans_clean(&trans);
    result = (status == amxd_status_ok) ? true : false;
    return result;
}

/**
   @brief Removes a device instance from a HomePlug interface.

   This function deletes a device object instance identified by @p device_key
   from the provided HomePlug interface object.

   @param device_obj Pointer to device object.
   @param device_key Key identifying the device instance to remove.

   @return @c true if the device instance was successfully removed; @c false otherwise.
 */
static bool dm_interface_remove_device(amxd_object_t* device_obj,
                                       const char* device_key) {
    bool result = false;
    amxd_trans_t trans;
    amxd_status_t status = amxd_status_unknown_error;

    SAH_TRACEZ_INFO(ME, "interface_remove_device");

    when_str_empty_trace((const char*) device_key, exit, ERROR, "empty device key");
    when_null_trace(device_obj, exit, ERROR, "device obj is NULL");

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    amxd_trans_select_object(&trans, device_obj);
    amxd_trans_del_inst(&trans, 0, device_key);

    status = amxd_trans_apply(&trans, homeplug_get_dm());
    when_failed_trace(status, exit, ERROR, "Apply transaction failed, status: %d", status);
exit:
    amxd_trans_clean(&trans);
    result = (status == amxd_status_ok) ? true : false;
    return result;
}

bool dm_interface_cleanup_inactive_devices(amxd_object_t* homeplug_interface_obj_x,
                                           amxc_llist_t* active_devices) {

    amxc_string_t* actives_str = NULL;
    amxd_object_t* device_obj = NULL;

    SAH_TRACEZ_INFO(ME, "dm interface cleanup inactive devices");

    when_null_trace(homeplug_interface_obj_x, exit, ERROR, "interface obj instance is NULL");
    when_null_trace(active_devices, exit, ERROR, "acives devices list is NULL");

    amxc_string_new(&actives_str, 0);
    amxc_string_join_llist(actives_str,
                           active_devices,
                           ' ');

    device_obj = amxd_object_findf(homeplug_interface_obj_x, "AssociatedDevice.");
    when_null_trace(device_obj, exit, ERROR, "Can not find AssociatedDevice. object");

    amxd_object_for_each(instance, it, device_obj) {
        amxd_object_t* device_obj_x = amxc_container_of(it, amxd_object_t, it);
        const char* device_key = amxd_object_get_name(device_obj_x, AMXD_OBJECT_NAMED);
        when_str_empty_trace(device_key, exit, ERROR, "empty device key");
        if(amxc_string_search(actives_str, device_key, 0) == -1) {
            SAH_TRACEZ_INFO(ME, "remove inactive device: %s", device_key);
            dm_interface_remove_device(device_obj, device_key);
        }
    }
exit:
    amxc_string_delete(&actives_str);
    return true;
}
