/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#if !defined(__LOGICAL_API_VALIDATE_H__)
#define __LOGICAL_API_VALIDATE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

#include <amxc/amxc.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>

/**
   @brief
   Checks that IP params and DHCP pool params are consistent so that
   the service will work for that IP Interface.

   @param ip_params[in] IP interface parameters
   @param dhcpv4_params[in] DHCP pool parameters
   @param curr_dhcpv4_pool[in] path to the DHCP pool currently associated to the interface
   @param new_pool_alias[in] alias of the DHCP pool
   @param need_ip_update[in] IP interface parameters need to be updated
   @param need_dhcp_update[in] IP interface parameters need to be updated
   @param ip_intf[in] path to the IP interface
   @param ip_index[in] index of IP interface parameters
   @param dhcp_pool_to_update[out] path to the DHCP pool to update,
                                   NULL if the pool has to be created

   @return
   - true if params are consistent
   - false if params are NOT consistent
 */
bool is_valid_config(amxc_var_t* ip_params, amxc_var_t* dhcpv4_params,
                     const char* curr_dhcpv4_pool, const char* new_pool_alias,
                     bool need_ip_update, bool need_dhcp_update,
                     const char* ip_intf, uint32_t ip_index, char** dhcp_pool_to_update);

#ifdef __cplusplus
}
#endif

#endif // __LOGICAL_API_VALIDATE_H__