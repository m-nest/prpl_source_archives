/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "flash_health.h"
#include "dm_flash_health.h"
#define ME "events"


/**
 * @brief Retrieves the flash_health_t structure from signal event data.
 *
 * This function extracts the flash device's health information from the
 * event data received via a signal. It navigates through the data model
 * to locate the parent object and its associated private data.
 *
 * @param event_data Pointer to the signal event data.
 * @return Pointer to flash_health_t if successful, NULL otherwise.
 */
flash_health_t* get_flash_info_from_signal_data (const amxc_var_t* const event_data) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* flash_health_mon = amxd_dm_signal_get_object(fh_get_dm(), event_data);
    amxd_object_t* flash_device = NULL;
    flash_health_t* fh = NULL;

    when_null(flash_health_mon, exit);
    flash_device = amxd_object_get_parent(flash_health_mon);
    when_null(flash_device->priv, exit);
    fh = (flash_health_t*) flash_device->priv;
    when_null(fh, exit);
    return fh;

exit:
    SAH_TRACEZ_OUT(ME);
    return NULL;

}

/**
 * @brief Updates the flash monitoring status based on the received signal.
 *
 * Enables or disables flash monitoring depending on the value of "parameters.Enabled.to"
 * in the signal data.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data Pointer to the signal data (amxc_var_t).
 * @param[in] priv Unused private data pointer.
 */
void _update_flash_monitoring (UNUSED const char* const sig_name,
                               const amxc_var_t* const event_data,
                               UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    flash_health_t* fh = get_flash_info_from_signal_data(event_data);
    when_null(fh, exit);
    fh->enabled = GETP_BOOL(event_data, "parameters.Enabled.to");
    SAH_TRACEZ_INFO(ME, "Health status enable  %d", fh->enabled);
    if(fh->enabled) {
        enable_flash_monitoring(fh);
    } else {
        disable_flash_monitoring(fh);
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Updates the eMMC LifeTimeA threshold based on the received signal.
 *
 * Currently not implemented.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data Pointer to the signal data (amxc_var_t).
 * @param[in] priv Unused private data pointer.
 */
void _update_emmc_lifetimea_thresholds (UNUSED const char* const sig_name,
                                        UNUSED const amxc_var_t* const event_data,
                                        UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Current lifetimeA threshold is changed");
    flash_health_t* fh = get_flash_info_from_signal_data(event_data);
    when_null(fh, exit);
    fh->lifeTimeAThreshold = GETP_UINT32(event_data, "parameters.LifeTimeAThreshold.to");

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Updates the eMMC LifeTimeB threshold based on the received signal.
 *
 * Currently not implemented.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data Pointer to the signal data (amxc_var_t).
 * @param[in] priv Unused private data pointer.
 */

void _update_emmc_lifetimeb_thresholds (UNUSED const char* const sig_name,
                                        UNUSED const amxc_var_t* const event_data,
                                        UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Current lifetimeB threshold is changed");
    flash_health_t* fh = get_flash_info_from_signal_data(event_data);
    when_null(fh, exit);
    fh->lifeTimeBThreshold = GETP_UINT32(event_data, "parameters.LifeTimeBThreshold.to");
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Updates the eMMC PreEOL threshold based on the received signal.
 *
 * Currently not implemented.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data Pointer to the signal data (amxc_var_t).
 * @param[in] priv Unused private data pointer.
 */
void _update_emmc_preeol_thresholds (UNUSED const char* const sig_name,
                                     UNUSED const amxc_var_t* const event_data,
                                     UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Current PreEol Threshold is changed");
    flash_health_t* fh = get_flash_info_from_signal_data(event_data);
    when_null(fh, exit);
    fh->preEolThreshold = GETP_UINT32(event_data, "parameters.PreEolThreshold.to");
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Updates the NAND bad blocks threshold based on the received signal.
 *
 * Sets the bad blocks threshold for NAND flash health monitoring using the value
 * from "parameters.BadBlocksThreshold.to" in the signal data.
 *
 * @param[in] sig_name Name of the received signal (unused).
 * @param[in] data Pointer to the signal data (amxc_var_t).
 * @param[in] priv Unused private data pointer.
 */
void _update_nand_thresholds (UNUSED const char* const sig_name,
                              const amxc_var_t* const event_data,
                              UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    flash_health_t* fh = get_flash_info_from_signal_data(event_data);
    when_null(fh, exit);

    disable_flash_monitoring(fh);
    fh->badBlocksThreshold = GETP_UINT32(event_data, "parameters.BadBlocksThreshold.to");
    SAH_TRACEZ_INFO(ME, "Bad Blocks Threshold set to:%d", fh->badBlocksThreshold);
    enable_flash_monitoring(fh);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}
