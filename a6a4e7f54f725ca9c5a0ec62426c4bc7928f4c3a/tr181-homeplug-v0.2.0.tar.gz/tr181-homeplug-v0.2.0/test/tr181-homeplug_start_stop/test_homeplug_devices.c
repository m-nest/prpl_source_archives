/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include "homeplug.h"
#include "dm_homeplug.h"
#include "../common/test_common.h"
#include "test_homeplug_devices.h"

void test_start_device_discovery(UNUSED void** state) {

    amxd_object_t* interface_obj_6 = NULL;
    homeplug_interface_t* interface = NULL;
    amxd_object_t* device_obj_6_1 = NULL;
    amxc_var_t up;

    reset_send_request_counter();

    interface_obj_6 = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.");
    assert_non_null(interface_obj_6);

    amxc_var_init(&up);
    amxc_var_set_type(&up, AMXC_VAR_ID_BOOL);
    amxc_var_set(bool, &up, true);

    interface = (homeplug_interface_t*) interface_obj_6->priv;
    assert_non_null(interface);

    expect_function_call(__wrap_homeplug_socket_send_request);
    expect_function_call(__wrap_homeplug_socket_send_request);
    expect_function_call(__wrap_homeplug_socket_send_request);
    expect_function_call(__wrap_homeplug_socket_send_request);
    expect_function_call(__wrap_homeplug_socket_send_request);

    homeplug_interface_up_cb(NULL, &up, interface);

    read_sigalrm();
    amxp_timers_calculate();
    amxp_timers_check();
    handle_events();

    amxc_var_clean(&up);

    homeplug_socket_read_socket_cb(1, interface->sock);
    homeplug_socket_read_socket_cb(2, interface->sock);
    homeplug_socket_read_socket_cb(3, interface->sock);
    homeplug_socket_read_socket_cb(4, interface->sock);
    homeplug_socket_read_socket_cb(5, interface->sock);

    device_obj_6_1 = amxd_object_findf(interface_obj_6, "AssociatedDevice.1.");
    assert_non_null(device_obj_6_1);

    assert_str_attr_equal(device_obj_6_1, "EndStationMACs", "F4:06:8D:11:A5:E7, F4:06:8D:11:A5:E8, 00:24:9B:19:6B:02, 02:10:18:01:14:01");
    assert_str_attr_equal(device_obj_6_1, "Manufacturer", "Orange Wi-Fi Extender 500 Mbits/s [MT2616;X]");
    assert_str_attr_equal(device_obj_6_1, "FirmwareVersion", "INT7400-MAC-5-3-5317-03-1557-20140129-CS-D");
    assert_str_attr_equal(device_obj_6_1, "MACAddress", "F4:06:8D:96:1F:D7");

    assert_int_equal(amxd_object_get_value(uint16_t, device_obj_6_1, "RxPhyRate", NULL), 381);
    assert_int_equal(amxd_object_get_value(uint16_t, device_obj_6_1, "TxPhyRate", NULL), 380);

}

void test_stop_device_discovery(UNUSED void** state) {

    amxd_object_t* device_obj_6_x = NULL;
    amxd_object_t* device_obj_6 = NULL;
    amxd_object_t* assoc_device_obj = NULL;
    amxd_trans_t transaction;
    amxd_status_t status;
    amxd_object_t* interface_obj_6 = NULL;
    homeplug_interface_t* interface = NULL;

    reset_send_request_counter();

    // brg info request is expected to be sent 2 times, 1 after each timer callback call
    expect_function_call(__wrap_homeplug_socket_send_request);
    expect_function_call(__wrap_homeplug_socket_send_request);

    interface_obj_6 = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.");
    assert_non_null(interface_obj_6);


    assoc_device_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.AssociatedDevice.");
    assert_non_null(assoc_device_obj);

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, assoc_device_obj);
    amxd_trans_add_inst(&transaction, 0, "device_00_00_00_00_00_02");
    status = amxd_trans_apply(&transaction, get_dm());
    printf("status: %d\n", status);
    amxd_trans_clean(&transaction);

    handle_events();

    amxd_object_for_each(instance, it, assoc_device_obj) {
        amxd_object_t* assoc_device_obj_x = amxc_container_of(it, amxd_object_t, it);
        const char* device_key = amxd_object_get_name(assoc_device_obj_x, AMXD_OBJECT_NAMED);
        printf("assoc_device key: %s\n", device_key);
    }

    interface = (homeplug_interface_t*) interface_obj_6->priv;
    assert_non_null(interface);

    homeplug_socket_read_socket_cb(3, interface->sock);


    read_sigalrm();
    amxp_timers_calculate();
    amxp_timers_check();
    handle_events();
    reset_send_request_counter();

    /* after first timeout, active list is not yet emptied, so device_obj_6_x still present */

    device_obj_6_x = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.AssociatedDevice.1.");
    assert_non_null(device_obj_6_x);

    read_sigalrm();
    amxp_timers_calculate();
    amxp_timers_check();
    handle_events();

    reset_send_request_counter();

    /* after second timeout, check device object not anymore present  */

    device_obj_6 = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.AssociatedDevice.");
    assert_non_null(device_obj_6);

    device_obj_6_x = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.AssociatedDevice.1.");
    assert_null(device_obj_6_x);
}
