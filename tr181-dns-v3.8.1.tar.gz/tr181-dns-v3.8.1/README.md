[TOC]

# tr181-dns

The DNS manager with tr181 data model. It is made modular with the Ambiorix libamxm library.

## module configuration

>>>
Most of the module configurations are applied only at start of this plugin. Keep in mind the reboot persistency file located at `/etc/config/tr181-dns/odl/tr181-dns.odl`.
>>>

### Prefix for non standardized tr181 data model objects/parameters
Public non standardized objects and parameters must have a vendor prefix. This prefix is configurable in ODL:
```
%config {
    prefix_ = "X_<COMPANY>-COM_";
}
```
A global prefix is available for the whole board with the variable global_vendor_prefix_ .

All other non standardized objects and parameters will have ODL attribute `%protected`. They will be hidden and can be viewed with ubus-cli like this:
```
ubus-cli
> protected
> DNS.?
```

### DNS Controller

By default `mod-dns-uci` is used. [README](mod-dns-uci/README.md)<br>
<br>
The DNS controller is configurable in ODL:
```
%config {
    modules.dns-directory = "/usr/lib/amx/tr181-dns/modules";
    //modules.dns-options = {};
}

%populate {
    DNS.SupportedDNSControllers = "mod-dns-uci";
    DNS.DNSController = "mod-dns-uci";
}
```

### Failover Controller

A failover controller is optional. The DNS controller needs to be able to detect and report server failures. The failover controller can be configured in ODL:

```
%config {
    modules.dns-directory = "/usr/lib/amx/tr181-dns/modules";
    modules.failover-controller = "mod-dns-failover";
    //modules.failover-options = {};
}
```

Parameter `DNS.Relay.Forwarding.i.Tag` can give the failover algorithm extra information about the server.<br>
<br>
Parameter `DNS.Relay.Forwarding.i.State` can be used by the failover algorithm to report what it is doing with the server. E.g. Used, Error, Standby.

### Firewall controller

The plugin uses `mod-fw-amx` to open and close DNS ports.

```
%config {
    modules.fw-directory = "/usr/lib/amx/modules";
}

%populate {
    DNS.SupportedFWControllers = "mod-fw-amx";
    DNS.FWController = "mod-fw-amx";
}
```

## Memory footprint (PPW-1174)

### Per-interface process model

With `mod-dns-unbound`, there is one `unbound` process per interface.  
This means memory usage scales approximately linearly with the number of active interfaces.

### Defaults used for cache sizing

`DNS.Relay.Config` defaults:

- `CacheSize = 4000` (KB)
- `CacheMinTTL = 0`
- `CacheMaxTTL = 86400`

`mod-dns-unbound` generates per-interface `unbound` config with:

- `module-config: "iterator"`
- `rrset-cache-size: CacheSize`
- `msg-cache-size: CacheSize`
- `key-cache-size: CacheSize`
- `neg-cache-size: CacheSize`
- `infra-cache-numhosts: 100`

### How unbound uses memory

Per process, memory is mainly consumed by:

- Base process/runtime memory: executable text, shared libraries, stacks, allocator metadata, event loop structures.
- DNS response caches:
  - `msg-cache`: cached full DNS response messages.
  - `rrset-cache`: cached RRsets used to build answers.
- TCP waiting buffer:
  - `stream-wait-size`: memory budget for waiting TCP streams.
- Infrastructure cache:
  - server RTT/capability/health metadata (`infra-cache-numhosts` controls the size budget).
- Validator-only caches:
  - `key-cache` and `neg-cache` are effectively used when validator is active with trust anchors.

### Estimated memory per interface (default settings)

For the current generated configuration (`module-config: "iterator"`), an expected cache-related budget is:

```
msg-cache        = 4000k  = 4,096,000 B
rrset-cache      = 4000k  = 4,096,000 B
stream-wait-size = 4 MiB  = 4,194,304 B
infra-cache      = 100 * (sizeof(infra_key)+sizeof(infra_data))
                 = 100 * 296 B
                 = 29,600 B
------------------------------------------------
total            = 12,415,904 B ≈ 11.84 MiB
```

If validator is enabled with trust anchors, add:

```
key-cache + neg-cache = 4000k + 4000k = 8,192,000 B ≈ 7.81 MiB
```

So the same per-interface budget becomes approximately:

```
11.84 MiB + 7.81 MiB = 19.65 MiB
```

### Verified startup measurement

Measured with 4 simultaneously started instances (same host, patched unbound 1.24.1, default cache sizing):

- RSS per process: `9820 KB`, `9820 KB`, `10064 KB`, `9668 KB`
- Average RSS: `9843 KB` (`~9.6 MiB`) per process
- Total RSS for 4 instances: `39372 KB` (`~38.5 MiB`)

This is the best case scenario, during startup.

### How memory grows with more DNS records

Use the following model per interface:

```
RSS(interface) ≈ baseline_process + dynamic_cache + local_record_data
```

- `baseline_process` is the startup footprint observed around `9.6 MiB` per process with default settings.
- `dynamic_cache` grows as cacheable DNS answers are learned and is bounded by configured cache budgets.
- `local_record_data` is memory used by configured host and local-data entries and grows with the number of configured records.

Maximum memory with current defaults is bounded by cache budgets, then increased by local record data:

```
Iterator mode cache budget      ≈ 11.84 MiB per interface
Validator enabled cache budget  ≈ 19.65 MiB per interface
Total worst case per interface  ≈ cache budget + local_record_data + runtime overhead
```

For a fixed configuration you can calculate a concrete hard cap estimate.
The cache part has a strict cap from the configured cache sizes.
The local record part has a strict cap only if you also fix the number of local data entries.

Concrete worst case assumption for this document:

- One interface
- 250 connected devices
- 250 `local-data` entries
- Cache configured with `CacheSize = 4000k`
- Iterator mode

Measured values used for this estimate in this environment:

- Runtime baseline with no cache and no local data: `9796 KB`
- Additional memory for `250 local-data` entries: `96 KB`
- Cache budget cap in iterator mode: `12125 KB`

Worst case estimate for this assumption:

```
Worst case RSS per interface
= baseline + cache_cap + local_data_250
= 9796 KB + 12125 KB + 96 KB
= 22017 KB
= 21.50 MiB
```

So for the assumed scenario the precise worst case estimate is `22017 KB` per interface.

Worst case total for 4 instances (`br-lan`, `br-guest`, `lcm`, `lo`) with the same assumption:

```
Total worst case for 4 instances
= 4 * 22017 KB
= 88068 KB
= 86.00 MiB
```

Wrost case scenario with tuned cache sizes in `DNS.Relay.Config.{i}`:

- `br-lan` keeps `CacheSize = 4000k`
- `br-guest` uses `CacheSize = 2000k`
- `lcm` uses `CacheSize = 1000k`
- `lo` uses `CacheSize = 500k`
- `250 local-data` entries per interface
- Iterator mode
- Same measured baseline and local data delta

Per interface maximum estimate with this tuning:

```
br-lan   = 9796 KB + 12125 KB + 96 KB = 22017 KB
br-guest = 9796 KB + 8125 KB  + 96 KB = 18017 KB
lcm      = 9796 KB + 6125 KB  + 96 KB = 16017 KB
lo       = 9796 KB + 5125 KB  + 96 KB = 15017 KB
```

Maximum combined usage by unbound instances in this worst case scenario with tuning:

```
Total maximum for 4 instances
= 22017 KB + 18017 KB + 16017 KB + 15017 KB
= 71068 KB
= 69.40 MiB
```

Practical use cases:

- Home gateway with repeated lookups to a small set of domains  
  Cache warms quickly, memory rises from startup, then stays near a steady level.
- Gateway under stress with many unique domains  
  `msg-cache` and `rrset-cache` fill toward configured limits, then evictions keep cache memory near the budget ceiling.
- Deployment with large static host list  
  Memory includes cache usage plus host and local-data structures, growth is near linear with added records.

Effect of TTL configuration:

- Higher `CacheMaxTTL` keeps entries longer and increases steady-state occupancy.
- Non-zero `CacheMinTTL` can force longer retention and can also increase occupancy.

Per device impact with multiple interfaces:

```
Total RSS(device) ≈ Σ RSS(interface_i)
```

Since one unbound process is used per interface, cache and local record memory is not shared across interfaces.

## compile + install
```
# compile
make

# install
sudo make install
```

## (unit)tests
```
# run tests
make test
```

```mermaid
flowchart TB
    classDef todo fill:#FF6347
    classDef implemented fill:#7FFF00

    Start -.-> Client
    Client -.-> Relay
    Relay -.-> Hosts
    Hosts -.-> Config
    Config -.-> End

    subgraph Client[" "]
    direction LR
    A1[add/change/remove DNS.Client. instances]:::todo
    end

    subgraph Relay[" "]
    direction TB
    B1[Type Static] --> B11[Add DNS.Relay. instance]:::implemented
    B11 --> B12["Change DNS.Relay.{i}.Enable"]:::implemented
    B12 --> B13["Change DNS.Relay.{i}.DNSServer"]:::implemented
    B13 --> B14[Remove DNS.Relay. instance]:::implemented

    B2[Type DHCPv4] --1--> B21[Add DNS.Relay. instance]:::implemented
    B21 --2--> B21
    B21 --3--> B22[Change DNS.Relay.Enable]:::implemented
    B22 --4--> B21
    B21 --5--> B23[Remove DNS.Relay.3.]:::implemented
    B23 --> B24[Change DNS.Relay.1.Interface]:::implemented
    B24 --> B25["Change (netmodel) netdevname"]:::implemented
    B25 --> B26["Change (netmodel) dhcp option"]:::implemented

    B3[Type IPCP] --1--> B31[Add DNS.Relay. instance]:::implemented
    B31 --2 and 3--> B31
    B31 --4--> B32[Remove DNS.Relay.3.]:::implemented
    B32 --> B33["Change (netmodel) dnsservers"]:::implemented

    B4[Type RouterAdvertisement] --> B41[Add DNS.Relay. instance]:::implemented
    end

    subgraph Hosts[" "]
    direction TB
    C1[Firewall is open]:::implemented --> C2[Add DNS.Host. instance]:::implemented
    C2 --1--> C3["Add DNS.Host.{i}.IPAddress. instance"]:::implemented
    C3 --2--> C4["Change DNS.Host.{i}.Enable"]:::implemented
    C4 --> C5["Change DNS.Host.{i}.Name"]:::implemented
    C5 --> C6["Change DNS.Host.{i}.Interface"]:::implemented
    C6 --3--> C3
    C3 --4--> C7["Change DNS.Host.{i}.IPAddress.2.IPaddress"]:::implemented
    C7 --> C8["Remove DNS.Host.{i}.IPAddress.2. instance"]:::implemented
    C8 --> C9["Remove DNS.Host.{i}. instance"]:::implemented
    C9 --> C10["Add 2 DNS.Host.{i}. instances with same Interface"]:::implemented
    C10 --> C11[Firewall is closed]:::implemented
    end

    subgraph Config[" "]
    direction TB
    D1[Add DNS.Config. instance]:::implemented --> D2["Change DNS.Config.{i}.Interface"]:::implemented
    D2 --> D3["Change DNS.Config.{i}.CacheSize"]:::implemented
    D3 --> D4["Change DNS.Config.{i}.CacheTTLMax"]:::implemented
    D4 --> D5["Change DNS.Config.{i}.CacheTTLMin"]:::implemented
    D5 --> D6["Call DNS.Config.{i}.FlushCache()"]:::implemented
    D6 --> D7["Remove DNS.Config.{i}. instance"]:::implemented
    end
```
