/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdlib.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "conmon.h"
#include "conmon_soc_utils.h"

static bool get_local_mac(conmon_info_t* entry, char** local_mac) {
    SAH_TRACEZ_IN(ME);
    bool rv = false;

    when_null_trace(entry, exit, ERROR, "entry NULL");
    when_null_trace(entry->logical_path, exit, ERROR, "Logical interface is NULL");

    if(local_mac) {
        const char* mac_address_s = NULL;
        amxb_bus_ctx_t* ctx = NULL;
        amxc_string_t tmp_str;
        amxc_var_t data;

        ctx = amxb_be_who_has("NetDev.Link.");

        amxc_var_init(&data);
        amxc_string_init(&tmp_str, 0);

        amxc_string_setf(&tmp_str, "NetDev.Link.[Name==\"%s\"].LLAddress", entry->interface_name);
        amxb_get(ctx, amxc_string_get(&tmp_str, 0), 0, &data, 1);
        mac_address_s = GETP_CHAR(&data, "0.0.LLAddress");
        if(str_empty(mac_address_s) == false) {
            *local_mac = strdup(mac_address_s);
        }

        amxc_var_clean(&data);
        amxc_string_clean(&tmp_str);
    }
    SAH_TRACEZ_INFO(ME, "[%s] local_mac %s", entry->alias, local_mac? *local_mac:0);
    rv = true;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

void mod_conmon_build_basic_data_struct(conmon_info_t* conmon, amxc_var_t* data, bool set_stats) {
    SAH_TRACEZ_IN(ME);

    uint32_t ip_version = 0;
    amxc_var_t main_params;
    amxc_var_t stats_params;
    char* local_mac = NULL;
    const char* type = NULL;
    amxd_object_t* stats_object = NULL;

    amxc_var_init(&main_params);
    amxc_var_init(&stats_params);
    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);

    when_null_trace(conmon, exit, ERROR, "data struct is NULL");

    amxd_object_get_params(conmon->entry, &main_params, amxd_dm_access_protected);
    type = GET_CHAR(&main_params, "Type");

    if(is_ipv4(type)) {
        ip_version = 4;
    } else if(is_ipv6(type)) {
        ip_version = 6;
    }

    get_local_mac(conmon, &local_mac);

    amxc_var_add_key(uint32_t, data, "ip_version", ip_version);
    amxc_var_add_key(cstring_t, data, "alias", GET_CHAR(&main_params, "Alias"));
    amxc_var_add_key(cstring_t, data, "interface_name", str_empty(conmon->interface_name) ? "" : conmon->interface_name);
    amxc_var_add_key(cstring_t, data, "local_mac", str_empty(local_mac) ? "" : local_mac);
    amxc_var_add_key(cstring_t, data, "logical_path", GET_CHAR(&main_params, "Interface"));
    amxc_var_add_key(uint32_t, data, "retries_max", GET_UINT32(&main_params, "NumberOfRetries"));
    amxc_var_add_key(uint32_t, data, "retry_interval", GET_UINT32(&main_params, "ResponseTimeout") * 1000); // Seconds to ms
    amxc_var_add_key(uint32_t, data, "main_interval", GET_UINT32(&main_params, "MainInterval") * 1000);     // Seconds to ms
    amxc_var_add_key(uint32_t, data, "fail_interval", GET_UINT32(&main_params, "FailInterval") * 1000);     // Seconds to ms

    if(set_stats) {
        stats_object = amxd_object_get_child(conmon->entry, "Stats");
        when_null_trace(stats_object, exit, ERROR, "stats data object is NULL");
        amxd_object_get_params(stats_object, &stats_params, amxd_dm_access_protected);

        amxc_var_add_key(uint32_t, data, "arpns_errors_sent", GET_UINT32(&stats_params, "ARPNSErrorsSent"));
        amxc_var_add_key(uint32_t, data, "arpns_total_fail", GET_UINT32(&stats_params, "ARPNSTotalFail"));
        amxc_var_add_key(uint32_t, data, "total_dhcp_restarts", GET_UINT32(&stats_params, "TotalDHCPRestarts"));
    }

exit:
    free(local_mac);
    amxc_var_clean(&stats_params);
    amxc_var_clean(&main_params);

    SAH_TRACEZ_OUT(ME);
}

int mod_conmon_execute_function(const char* function, amxc_var_t* data) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t ret;
    int rv = -1;

    amxc_var_init(&ret);

    when_str_empty(function, exit);
    when_true(amxc_var_is_null(data), exit);

    rv = amxm_execute_function("mod-discoping", MOD_CONMON_CTRL, function, data, &ret);
    when_failed_trace(rv, exit, ERROR, "function %s failed", function);

exit:
    amxc_var_clean(&ret);

    SAH_TRACEZ_OUT(ME);
    return rv;
}
