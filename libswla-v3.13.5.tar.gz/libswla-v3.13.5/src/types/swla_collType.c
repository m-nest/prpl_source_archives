/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "swl/swl_common.h"
#include "swla/swla_type.h"
#include "swl/types/swl_collType.h"
#include "swl/types/swl_collTypes.h"

#define ME "swl_col"

static bool s_toVariant_cb(swl_type_t* type _UNUSED, amxc_var_t* tgt, const swl_typeData_t* srcData) {
    ASSERTS_NOT_NULL(tgt, false, ME, "NULL");
    swl_collType_t* colType = (swl_collType_t*) type;

    swl_collTypeFun_t* typeFun = swl_type_getExtFun(type, SWL_TYPE_COL_FUN_UID);
    ASSERT_NOT_NULL(typeFun, false, ME, "NO FUN");

    if(colType->toStrVar) {
        return swl_type_toVariantString(type, tgt, srcData);
    }

    if(amxc_var_type_of(tgt) != AMXC_VAR_ID_LIST) {
        amxc_var_init(tgt);
        amxc_var_set_type(tgt, AMXC_VAR_ID_LIST);
    }

    swl_type_t* elType = colType->elementType;

    swl_collType_forEachRef(colType, myIt, swl_typeEl_t, data, srcData) {
        amxc_var_t* myVar = amxc_var_add_new(tgt);
        swl_type_toVariant(elType, myVar, SWL_TYPE_EL_TO_DATA(elType, data));
    }

    return true;
}

static bool s_fromVariant_cb(swl_type_t* type, swl_typeEl_t* tgtData, const amxc_var_t* var) {
    swl_collType_t* colType = (swl_collType_t*) type;
    swl_collTypeFun_t* typeFun = swl_type_getExtFun(type, SWL_TYPE_COL_FUN_UID);
    ASSERT_NOT_NULL(typeFun, false, ME, "NO FUN");

    if(colType->toStrVar) {
        return swl_type_fromVariantString(type, tgtData, var);
    }

    swl_type_t* elType = colType->elementType;
    ASSERT_EQUALS(amxc_var_type_of(var), AMXC_VAR_ID_LIST, false, "ME", "Invalid var type");

    amxc_var_for_each(it, var) {

        swl_typeEl_t* el = typeFun->alloc(&colType->type, tgtData);
        ASSERT_NOT_NULL(el, false, ME, "ALLOC FAIL");

        ASSERT_TRUE(swl_type_fromVariant(elType, el, it), false, ME, "CONV FAIL");
    }

    return true;
}

SWL_CONSTRUCTOR static void s_collection_var_init(void) {
    for(size_t i = 0; i < SWL_COLL_TYPES_NUMBER; i++) {
        gSwl_collTypes_funList[i]->toVariant = (swl_type_toVariant_cb) s_toVariant_cb;
        gSwl_collTypes_funList[i]->fromVariant = (swl_type_fromVariant_cb) s_fromVariant_cb;
    }
}
