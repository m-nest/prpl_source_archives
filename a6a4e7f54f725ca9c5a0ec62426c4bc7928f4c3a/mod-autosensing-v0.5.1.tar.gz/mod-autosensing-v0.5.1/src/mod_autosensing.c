/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxm/amxm.h>

#include "mod_autosensing.h"

#define str_empty(txt) ((txt == NULL) || (*txt == 0))

static int autosensing_stop(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

typedef enum  {
    mode_unknown = 0,
    mode_available = 1,
    mode_unavailable = 2,
} mode_availability_t;

typedef struct {
    amxc_var_t* modes;
    amxc_var_t* current_mode;
    amxc_var_t* next_mode;
    amxp_timer_t* timer;
    uint32_t timeout;
    bool continuous;
    bool in_progress;
} auto_sensing_t;

static auto_sensing_t auto_sensing = {
    .modes = NULL,
    .next_mode = NULL,
    .current_mode = NULL,
    .timer = NULL,
    .timeout = 10000,
    .continuous = false,
    .in_progress = false
};

// Custom compare function to sort WANModes based on SensingPriority
static int cmp(amxc_llist_it_t* it1, amxc_llist_it_t* it2) {
    amxc_var_t* one = amxc_container_of(it1, amxc_var_t, lit);
    amxc_var_t* two = amxc_container_of(it2, amxc_var_t, lit);
    uint32_t priority_one = GET_UINT32(one, "SensingPriority");
    uint32_t priority_two = GET_UINT32(two, "SensingPriority");

    if(priority_one == priority_two) {
        return 0;
    } else if(priority_one < priority_two) {
        return -1;
    } else {
        return 1;
    }
}

// Create a list of WANModes that can be sensed.
// It can either start from an empty list or update an existing list with new data
static int populates_modes(const amxc_var_t* const input_modes) {
    int rv = -1;
    amxc_llist_t* sortlist = NULL;
    amxc_var_t* temp = NULL;

    if(auto_sensing.modes == NULL) {
        // First start of module
        amxc_var_for_each(new_mode, input_modes) {
            amxc_var_add_key(bool, new_mode, "Valid", GET_BOOL(new_mode, "EnableSensing"));
            amxc_var_add_key(uint32_t, new_mode, "Availability", mode_unknown);
        }
        sortlist = amxc_var_dyncast(amxc_llist_t, input_modes);
    } else {
        // Sync new and old modes

        // Invalidate all old modes.
        // When a match is found in the list of new modes it is set to valid again.
        amxc_var_for_each(old_mode, auto_sensing.modes) {
            temp = GET_ARG(old_mode, "Valid");
            amxc_var_set(bool, temp, false);
        }

        // Go over the list of new modes and search for matching modes with the old list
        amxc_var_for_each(new_mode, input_modes) {
            const char* alias_new_mode = GET_CHAR(new_mode, "Alias");
            bool found = false;

            if(GET_BOOL(new_mode, "EnableSensing") == false) {
                continue;
            }
            amxc_var_for_each(old_mode, auto_sensing.modes) {
                const char* alias_old_mode = GET_CHAR(old_mode, "Alias");
                if(strcmp(alias_new_mode, alias_old_mode) == 0) {
                    found = true;
                    if(strcmp(GET_CHAR(new_mode, "PhysicalReference"), GET_CHAR(old_mode, "PhysicalReference")) != 0) {
                        temp = GET_ARG(old_mode, "PhysicalReference");
                        amxc_var_set(cstring_t, temp, GET_CHAR(new_mode, "PhysicalReference"));
                        // Availability is based on the PhysicalReference so reset this value.
                        temp = GET_ARG(old_mode, "Availability");
                        amxc_var_set(uint32_t, temp, mode_unknown);
                    }
                    if(GET_UINT32(new_mode, "SensingPriority") != GET_UINT32(old_mode, "SensingPriority")) {
                        temp = GET_ARG(old_mode, "SensingPriority");
                        amxc_var_set(uint32_t, temp, GET_UINT32(new_mode, "SensingPriority"));
                    }
                    temp = GET_ARG(old_mode, "Valid");
                    amxc_var_set(bool, temp, true);
                    break;
                }
            }
            if(!found) {
                // New mode not present yet in old list
                amxc_var_add_key(uint32_t, new_mode, "Availability", mode_unknown);
                amxc_var_add_key(bool, new_mode, "Valid", true);
                amxc_var_add(amxc_htable_t, auto_sensing.modes, amxc_var_constcast(amxc_htable_t, new_mode));
            }
        }

        sortlist = amxc_var_dyncast(amxc_llist_t, auto_sensing.modes);
    }

    rv = amxc_llist_sort(sortlist, cmp);
    when_failed_trace(rv, exit, ERROR, "Could not sort sortlist");

    amxc_var_delete(&auto_sensing.modes);
    amxc_var_new(&auto_sensing.modes);
    amxc_var_set_type(auto_sensing.modes, AMXC_VAR_ID_LIST);
    amxc_llist_iterate(it, sortlist) {
        amxc_var_t* mode = amxc_container_of(it, amxc_var_t, lit);
        // Only add valid modes, all invalid modes are old modes that are not matched with the new modes (no longer needed)
        if(GET_BOOL(mode, "Valid")) {
            amxc_var_add(amxc_htable_t, auto_sensing.modes, amxc_var_constcast(amxc_htable_t, mode));
        }
    }
    amxc_llist_delete(&sortlist, variant_list_it_free);

    rv = 0;

exit:
    return rv;
}

// Get next WANMode that is not unavailable
static void get_next_mode(void) {
    do {
        if(auto_sensing.next_mode == NULL) {
            auto_sensing.next_mode = GETI_ARG(auto_sensing.modes, 0);
        } else {
            auto_sensing.next_mode = amxc_var_get_next(auto_sensing.next_mode);
        }
    } while(auto_sensing.next_mode != NULL && GET_UINT32(auto_sensing.next_mode, "Availability") == mode_unavailable);
}

static int set_wan_mode(void) {
    int rv = -1;
    amxc_var_t ret;

    amxc_var_init(&ret);
    rv = amxm_execute_function("self", MOD_DM_MNGR, "set-mode", auto_sensing.next_mode, &ret);
    when_failed_trace(rv, exit, ERROR, "Failed to call set-mode for mode '%s', returned '%d'", GET_CHAR(auto_sensing.next_mode, "Alias"), rv);

    auto_sensing.current_mode = auto_sensing.next_mode;

exit:
    amxc_var_clean(&ret);
    return rv;
}

static void auto_sensing_timer_cb(UNUSED amxp_timer_t* const timer, UNUSED void* data) {
    int rv = -1;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    when_false_trace(auto_sensing.in_progress, exit, WARNING, "Autosensing no longer in progress");

    rv = amxm_execute_function("self", MOD_DM_MNGR, "isup-sensing-stop", &args, &ret);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to stop sensing, '%d'", rv);
    }

    SAH_TRACEZ_INFO(ME, "Verifying next wanmode");
    if(auto_sensing.next_mode == NULL) {
        SAH_TRACEZ_INFO(ME, "All modes where sensed, no mode was active");
        if(auto_sensing.continuous == true) {
            SAH_TRACEZ_INFO(ME, "Selecting the first wan-mode again");
            get_next_mode();
        } else {
            SAH_TRACEZ_INFO(ME, "Stopping sensing");
            auto_sensing.in_progress = false;
            goto exit;
        }
    }

    amxp_timer_start(timer, auto_sensing.timeout);
    rv = set_wan_mode();
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to call set-mode function, '%d'", rv);
        autosensing_stop(NULL, &args, &ret);
        goto exit;
    }
    get_next_mode();

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

// Start the autosensing progress
static void start_sensing(amxc_var_t* args) {
    amxc_var_t ret;
    const char* current_wanmode = GET_CHAR(args, "WANMode");

    amxc_var_init(&ret);

    auto_sensing.next_mode = NULL;
    auto_sensing.in_progress = true;

    amxp_timer_stop(auto_sensing.timer); // Make sure the timer is not running

    // Timer should be started before calling the set mode.
    // If this mode is already set and valid, sensing will be stopped immediately
    // the timer will then be started after sensing is stopped
    amxp_timer_start(auto_sensing.timer, auto_sensing.timeout);

    // Select the next wan mode
    get_next_mode();
    if((GET_BOOL(args, "sense_current_mode") == false) && (auto_sensing.next_mode != NULL) &&
       (!str_empty(current_wanmode) && !str_empty(GET_CHAR(auto_sensing.next_mode, "Alias")) &&
        (strcmp(GET_CHAR(args, "WANMode"), GET_CHAR(auto_sensing.next_mode, "Alias")) == 0))) {
        SAH_TRACEZ_INFO(ME, "Skipping current WANMode %s", GET_CHAR(args, "WANMode"));
        get_next_mode();
    }
    // Make sure there are no queries on the current mode
    amxm_execute_function("self", MOD_DM_MNGR, "isup-sensing-stop", args, &ret);

    SAH_TRACEZ_INFO(ME, "Selecting first mode");
    when_failed(set_wan_mode(), exit);
    get_next_mode();

exit:
    amxc_var_clean(&ret);
}

static int autosensing_start(UNUSED const char* function_name,
                             amxc_var_t* args,
                             UNUSED amxc_var_t* ret) {
    int rv = -1;
    const char* policy = GET_CHAR(args, "SensingPolicy");

    SAH_TRACEZ_INFO(ME, "Starting auto-sensing");
    when_false_trace(!auto_sensing.in_progress, exit, WARNING, "Sensing already in progress, not restarting");

    rv = populates_modes(GET_ARG(args, "modes"));
    when_failed_trace(rv, exit, ERROR, "Failed to copy modes to be sensed");

    auto_sensing.timeout = GET_UINT32(args, "SensingTimeout") * 1000;
    auto_sensing.continuous = (policy != NULL) && (strcmp(policy, "Continuous") == 0);

    start_sensing(args);

exit:
    return rv;
}

static int autosensing_stop(UNUSED const char* function_name,
                            UNUSED amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    int rv = amxp_timer_stop(auto_sensing.timer);

    SAH_TRACEZ_INFO(ME, "Stopping auto-sensing");

    auto_sensing.in_progress = false;
    when_failed_trace(rv, exit, ERROR, "Failed to stop timer");

exit:
    return rv;
}

// Called when a physical interface comes up or loses its connection.
// This can lead to restart sensing when a higher priority interface comes up.
static int autosensing_intf_change(UNUSED const char* function_name,
                                   amxc_var_t* args,
                                   UNUSED amxc_var_t* ret) {
    int rv = -1;
    bool up = GET_BOOL(args, "up");
    const char* physical_reference = GET_CHAR(args, "physical_ref");
    amxc_var_t* mode = NULL;
    bool restart_needed = false;

    when_str_empty_trace(physical_reference, exit, ERROR, "Empty physical ref parameter");

    mode = GETI_ARG(auto_sensing.modes, 0);
    while(mode != NULL) {
        if(strcmp(GET_CHAR(mode, "PhysicalReference"), physical_reference) == 0) {
            amxc_var_t* temp = GET_ARG(mode, "Availability");
            mode_availability_t new_status = up? mode_available : mode_unavailable;
            if(GET_UINT32(temp, NULL) != (uint32_t) new_status) {
                if(GET_BOOL(args, "restart") && up && (GET_UINT32(mode, "SensingPriority") < GET_UINT32(auto_sensing.current_mode, "SensingPriority"))) {
                    restart_needed = true;
                }
            }
        }
        mode = amxc_var_get_next(mode);
    }

    if(restart_needed) {
        amxc_var_t data;
        amxc_var_init(&data);
        SAH_TRACEZ_INFO(ME, "Stopping auto-sensing because of higher priority interface comes up");
        start_sensing(&data);
        amxc_var_clean(&data);
    }

    rv = 0;

exit:
    return rv;
}

static AMXM_CONSTRUCTOR mod_autosensing_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_AUTOSENSING_CTRL);

    amxm_module_add_function(mod, "autosensing-start", autosensing_start);
    amxm_module_add_function(mod, "autosensing-stop", autosensing_stop);
    amxm_module_add_function(mod, "autosensing-physical-intf-change", autosensing_intf_change);

    amxp_timer_new(&auto_sensing.timer, auto_sensing_timer_cb, NULL);

    return 0;
}

static AMXM_DESTRUCTOR mod_autosensing_stop(void) {
    auto_sensing.in_progress = false;
    auto_sensing.current_mode = NULL;
    auto_sensing.next_mode = NULL;
    amxp_timer_delete(&auto_sensing.timer);
    amxc_var_delete(&auto_sensing.modes);
    return 0;
}
