#!/bin/sh

. /usr/lib/amx/scripts/amx_init_functions.sh

name="tr181-dynamicdns"
datamodel_root="DynamicDNS"

/bin/ash /usr/lib/amx/scripts/ddns-scripts-patch.sh $name $1
. /lib/functions/network.sh

case $1 in
    boot)
        process_boot ${name} -D
        ;;
    start)
        process_start ${name} -D
        ;;
    stop)
        process_stop ${name}
        ;;
    shutdown)
        process_shutdown ${name}
        ;;
    restart)
        $0 stop
        $0 start
        ;;
    debuginfo)
        process_debug_info ${datamodel_root}
        ;;
    *)
        echo "Usage : $0 [start|boot|stop|shutdown|debuginfo|restart]"
        ;;
esac
