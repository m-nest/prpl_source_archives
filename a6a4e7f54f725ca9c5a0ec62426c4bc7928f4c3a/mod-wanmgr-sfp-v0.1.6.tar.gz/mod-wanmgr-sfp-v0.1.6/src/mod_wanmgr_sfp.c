/**
 * @file mod_wanmgr_sfp.c
 *
 * @brief This file contains implementation of mod wanmgr sfp functionalities.
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_wanmgr_sfp.h"

static amxm_module_t* mod = NULL;

/**
 * @brief  amxb_bus_get_ctx_sfpmgr
 *
 * @detail This function returns the bus context used by the Device.SFPs. component.
 *
 * @return amxb_bus_ctx_t*, Pointer to the bus context, or NULL if not found.
 */
amxb_bus_ctx_t* amxb_bus_get_ctx_sfpmgr(void) {
    return amxb_be_who_has("SFPs.");
}

/**
 * @brief       get_sfp_present_status
 *
 * @detail      Get to know if spf present in SFPCage.1 from tr181-sfp
 *
 * @param[out]   sfp_present, contains the information of SFPPresent.
 *
 * @retval      rv, Returns 0 on success or -1 on failure.
 */
static int get_sfp_present_status(bool* sfp_present) {
    int rv = amxd_status_unknown_error;
    int rc = 0;
    const char* key = NULL;

    amxc_var_t sfpmgr_ret;
    amxc_var_init(&sfpmgr_ret);
    amxc_var_t* sfp_args;
    amxc_var_t* sfp_info;

    when_null_trace(sfp_present, exit, ERROR, "SFPPresent address is NULL");

    amxb_bus_ctx_t* sfpmgr_ctx = amxb_bus_get_ctx_sfpmgr();
    when_null_trace(sfpmgr_ctx, exit, ERROR, "Failed to get bus context of sfpmgr");

    // Get the SFP interface from tr181-sfp
    rc = amxb_get(sfpmgr_ctx, TR181_SFPCAGE_PATH, 0, &sfpmgr_ret, TIMEOUT_20);

    if(rc != 0) {
        // Exit the program - failed with MAX_RETRIES.
        when_failed_trace(rc, exit, ERROR, "Failed get " TR181_SFPCAGE_PATH ", exit error: %d", rc);
    }

    // Get the first element from the AMX result.
    sfp_info = amxc_var_get_first(&sfpmgr_ret);
    when_null_trace(sfp_info, exit, ERROR, "The first element returned as empty");

    // Iterate to get the key - Device.SFPs.SFPCage.1.
    amxc_var_for_each(sfp_key, sfp_info) {
        key = amxc_var_key(sfp_key);
        if(!string_is_empty(key)) {
            break;
        }
    }
    sfp_args = GET_ARG(sfp_info, key);
    when_null_trace(sfp_args, exit, ERROR, "Fail to retrieve any SFP data");

    *sfp_present = GETP_BOOL(sfp_args, "SFPPresent");
    rv = amxd_status_ok;

exit:
    amxc_var_clean(&sfpmgr_ret);
    return rv;
}

/**
 * @brief       get_interface_name
 *
 * @detail      Get interface name from tr181-sfpmgr
 *
 * @param[in]   sfp_info, contains the information of SFPType.
 *
 * @retval      rv, Returns 0 on success or -1 on failure.
 */
static int get_interface_name(amxc_var_t* sfp_info) {
    int rv = amxd_status_unknown_error;
    int rc = 0;

    const char* sfp_ifname = NULL;
    const char* key = NULL;

    amxc_var_t sfpmgr_ret;
    amxc_var_init(&sfpmgr_ret);
    amxc_var_t* index_val;
    amxc_var_t* sfp_args;

    when_null_trace(sfp_info, exit, ERROR, "Failed to get SFPType");

    amxb_bus_ctx_t* sfpmgr_ctx = amxb_bus_get_ctx_sfpmgr();
    when_null_trace(sfpmgr_ctx, exit, ERROR, "Failed to get bus context of sfpmgr");

    // Get the SFP interface from tr181-sfpmgr.
    rc = amxb_get(sfpmgr_ctx, TR181_SFPCAGE_PATH, 0, &sfpmgr_ret, TIMEOUT_20);

    if(rc != 0) {
        // Exit the program - failed with MAX_RETRIES.
        when_failed_trace(rc, exit, ERROR, "Failed get " TR181_SFPCAGE_PATH ", exit error: %d", rc);
    }

    // Get the first element from the AMX result.
    index_val = amxc_var_get_first(&sfpmgr_ret);
    when_null_trace(sfp_info, exit, ERROR, "The first element returned as empty");

    // Iterate to get the key - Device.SFPs.SFPCage.1.
    amxc_var_for_each(sfp_key, index_val) {
        key = amxc_var_key(sfp_key);
        if(!string_is_empty(key)) {
            break;
        }
    }
    sfp_args = GET_ARG(index_val, key);
    sfp_ifname = GETP_CHAR(sfp_args, "Name");
    when_null_trace(sfp_ifname, exit, ERROR, "GETP_CHAR returned Name as NULL");

    amxc_var_add_key(cstring_t, sfp_info, "Name", sfp_ifname);
    rv = amxd_status_ok;

exit:
    amxc_var_clean(&sfpmgr_ret);
    return rv;
}

/**
 * @brief      read_sfp_type
 *
 * @detail     This function reads the SFPType and interface name from sfpmgr.
 *
 * @param[out] ret, contains the information of SFPType and ifname.
 *
 * @retval     rv, Returns 0 on success or -1 on failure.
 */
static int read_sfp_type(UNUSED const char* function_name,
                         UNUSED amxc_var_t* args,
                         amxc_var_t* ret) {
    int rv = amxd_status_unknown_error;
    int rc = 0;
    int retry_count = 0;
    int max_retries = MAX_RETRIES;
    const char* key = NULL;
    const char* sfp_type = NULL;
    const char* sfp_ifname = NULL;
    bool sfp_present = true;
    amxc_var_t* sfp_info = NULL;
    amxc_var_t* sfp_args = NULL;
    amxb_bus_ctx_t* sfpmgr_ctx = NULL;

    amxc_var_t sfp_get_info;
    amxc_var_init(&sfp_get_info);

    when_null_trace(ret, exit, ERROR, "The argument ret passed as NULL.");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    sfpmgr_ctx = amxb_bus_get_ctx_sfpmgr();
    when_null_trace(sfpmgr_ctx, exit, ERROR, "Failed to get bus context of sfpmgr");

    while(retry_count <= max_retries) {
        // Retrieve the SFPType from tr181-sfpmgr.
        rc = amxb_get(sfpmgr_ctx, TR181_SFPCAGE_PATH, 0, &sfp_get_info, TIMEOUT_20);
        if(rc == 0) {
            // amxb_get is successful, breaking out of the loop.
            break;
        }
        SAH_TRACEZ_INFO(ME, "amxb_get(%s) failed on attempt %d: %d", TR181_SFPCAGE_PATH, retry_count + 1, rc);
        // Increment the retry count
        retry_count++;
        if(retry_count <= max_retries) {
            // sleep or some other delay function to wait before retrying.
            // Sleep for 1 second, adjust as needed
            sleep(1);
        }
    }

    when_failed_trace(rc, exit, ERROR, "amxb_get(%s) failed after max retries(%d)", TR181_SFPCAGE_PATH, max_retries);

    // Get the first element from the AMX result.
    sfp_info = amxc_var_get_first(&sfp_get_info);
    when_null_trace(sfp_info, exit, ERROR, "The first element returned as empty");

    // Iterate to get the key - Device.SFPs.SFPCage.1.
    amxc_var_for_each(sfp_key, sfp_info) {
        key = amxc_var_key(sfp_key);
        if(!string_is_empty(key)) {
            break;
        }
    }
    when_null_trace(key, exit, ERROR, "The SFPCage key is null");
    when_str_empty_trace(key, exit, ERROR, "The SFPCage key is empty");

    sfp_args = GET_ARG(sfp_info, key);
    when_null_trace(sfp_args, exit, ERROR, "sfp args is NULL");

    // Only if SFPPresent is no 'false', Copy the retrieved SFP type.
    sfp_present = GET_BOOL(sfp_args, "SFPPresent");
    if(sfp_present != false) {
        sfp_type = GET_CHAR(sfp_args, "SFPType");
        when_null_trace(sfp_type, exit, ERROR, "GET_CHAR returned SFPType as NULL");
    } else {
        sfp_type = "Unsupported";
    }
    sfp_ifname = GET_CHAR(sfp_args, "Name");
    when_null_trace(sfp_ifname, exit, ERROR, "GET_CHAR returned ifname from tr181-sfpmgr as NULL");

    // Fill the ambiorix variant with SFPType, Name, SFPPresent.
    amxc_var_add_key(bool, ret, "SFPPresent", sfp_present);
    amxc_var_add_key(cstring_t, ret, "SFPType", sfp_type);
    amxc_var_add_key(cstring_t, ret, "Name", sfp_ifname);

    rv = amxd_status_ok;
exit:
    amxc_var_clean(&sfp_get_info);
    return rv;
}

/**
 * @brief       mod_wanmgr_sfp_update_sfptype
 *
 * @detail      Updates interface name and SFPType to wan-manager.
 *
 * @param[in]   sfp_info, contains the information of SFPType.
 * @param[out]  ret, variant structure for the return values from the function.
 *
 * @retval      rv, Returns 0 on success or -1 on failure.
 */

static int mod_wanmgr_sfp_update_sfptype(amxc_var_t* sfp_info, amxc_var_t* ret) {
    int rv = amxd_status_unknown_error;

    when_null_trace(sfp_info, exit, ERROR, "Failed to get SFP Info");
    when_null_trace(ret, exit, ERROR, "The output argument ret passed as NULL.");

    rv = get_interface_name(sfp_info);
    when_failed_trace(rv, exit, ERROR, "Failed to call get_interface_name function, '%d'", rv);

    // Updating the WANManager with SFP informations.
    rv = amxm_execute_function("self", MOD_DM_MNGR, "update-sfp-type", sfp_info, ret);
    when_failed_trace(rv, exit, ERROR, "Failed to update sfp details, '%d'", rv);

exit:
    return rv;
}

/**
 * @brief      get_sfp_type
 *
 * @detail     This function gets the SFPType from sfpmgr using an ambiorix API
 *
 * @param[out] sfp_info, contains the information of SFPType.
 * @param[out] ret, variant structure for the return values from the function.
 *
 * @retval     rv, Returns 0 on success or -1 on failure.
 */
static int get_sfp_type(UNUSED const char* function_name,
                        amxc_var_t* sfp_info,
                        amxc_var_t* ret) {
    int rv = amxd_status_unknown_error;
    int rc = 0;
    const char* sfptype = NULL;
    amxc_var_t* result = NULL;
    amxc_var_new(&result);

    when_null_trace(sfp_info, exit, ERROR, "The output argument sfp_info passed as NULL.");
    when_null_trace(ret, exit, ERROR, "The output argument ret passed as NULL.");

    amxc_var_set_type(sfp_info, AMXC_VAR_ID_HTABLE);

    // Reading the SFP Type
    rc = read_sfp_type(NULL, NULL, result);
    when_failed_trace(rc, exit, ERROR, "Failed to get the SFP type information '%d'", rc);

    // Copy the retrieved SFPType type.
    sfptype = GETP_CHAR(result, "SFPType");
    when_null_trace(sfptype, exit, ERROR, "GETP_CHAR returned SFPType as NULL");

    // Fill the ambiorix variant with SFP type.
    amxc_var_add_key(cstring_t, sfp_info, "SFPType", sfptype);

    rc = mod_wanmgr_sfp_update_sfptype(sfp_info, ret);
    when_failed_trace(rc, exit, ERROR, "Failed to call mod_wanmgr_sfp_update_sfptype function, '%d'", rc);

    rv = amxd_status_ok;
exit:
    amxc_var_delete(&result);
    return rv;
}

/**
 * @brief     sfp_type_changed
 *
 * @details   callback function to SFPType change event
 *
 * @param[in] data, contains notification name and info relevant for that notification.
 *
 * @return    void
 */
static void sfp_type_changed(UNUSED const char* const sig_name,
                             const amxc_var_t* const data,
                             UNUSED void* const priv) {
    int rv = amxd_status_unknown_error;
    int rc = 0;
    const char* old_sfp_state = NULL;
    const char* new_sfp_state = NULL;
    bool sfp_present = false;

    amxc_var_t sfp_info;
    amxc_var_init(&sfp_info);
    amxc_var_set_type(&sfp_info, AMXC_VAR_ID_HTABLE);

    amxc_var_t ret;
    amxc_var_init(&ret);

    when_null_trace(data, exit, ERROR, "The Input argument data is NULL");

    // 'SFPType' applicable only after 'SFPPresent' is 'true'
    rc = get_sfp_present_status(&sfp_present);
    when_failed_trace(rc, exit, ERROR, "Failed to get the SFPPresent status");

    old_sfp_state = GETP_CHAR(data, "parameters.SFPType.from");
    new_sfp_state = GETP_CHAR(data, "parameters.SFPType.to");
    when_null_trace(old_sfp_state, exit, ERROR, "SFPType old state is NULL");
    when_null_trace(new_sfp_state, exit, ERROR, "SFPType new state is NULL");

    if((sfp_present != true) || (strncmp(new_sfp_state, "Unsupported", MAX_LENGTH) == 0)) {
        SAH_TRACEZ_INFO(ME, "No SFP detected");
        goto exit;
    } else if(old_sfp_state != new_sfp_state) {
        // Fill the ambiorix variant with the SFP type.
        amxc_var_add_key(cstring_t, &sfp_info, "SFPType", new_sfp_state);
        rv = mod_wanmgr_sfp_update_sfptype(&sfp_info, &ret);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to call mod_wanmgr_sfp_update_sfptype function, '%d'", rv);
        }
    } else {
        SAH_TRACEZ_INFO(ME, "No change in SFPType detected");
        goto exit;
    }
exit:
    amxc_var_clean(&sfp_info);
    amxc_var_clean(&ret);
    return;
}

/**
 * @brief     detect_sfp_type_change
 *
 * @details   Function to subscribe Device.SFPs.SFPCage.1.SFPType. object
 *
 * @param[in] void
 *
 * @retval    rv, Returns 0 on success or -1 on failure.
 */
static int detect_sfp_type_change(UNUSED const char* function_name,
                                  UNUSED amxc_var_t* args,
                                  UNUSED amxc_var_t* ret) {
    int rv = amxd_status_unknown_error;
    amxb_bus_ctx_t* sfpmgr_ctx = amxb_bus_get_ctx_sfpmgr();
    when_null_trace(sfpmgr_ctx, exit, ERROR, "Failed to get bus context of sfpmgr transceiver");

    //subscribe to Device.SFPs.SFPCage.1. to handle SFPType param change.
    rv = amxb_subscribe(sfpmgr_ctx, TR181_SFPCAGE_PATH,
                        "notification in ['dm:object-changed'] && contains('parameters.SFPType')",
                        sfp_type_changed, NULL);

    if(rv != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "Failed to subscribe " TR181_SFPCAGE_PATH " [%d]", rv);
        return rv;
    } else {
        SAH_TRACEZ_INFO(ME, "Successfully subscribed to " TR181_SFPCAGE_PATH);
        rv = 0;
    }
exit:
    return rv;
}

/**
 * @brief Start and register functions for the mod-wanmgr-sfp module.
 *
 * @return AMXM_CONSTRUCTOR always return 0.
 */
static AMXM_CONSTRUCTOR mod_wanmgr_sfp_up(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    when_null_trace(so, exit, ERROR, "Could not get shared object");
    SAH_TRACEZ_INFO(ME, "mod-wanmgr-sfp started");

    // Registering module namespace and adding functions.
    if(amxm_module_register(&mod, so, MOD_WANMGR_SFP)) {
        SAH_TRACEZ_ERROR(ME, "Could not register module" MOD_WANMGR_SFP);
        goto exit;
    }

    amxm_module_add_function(mod, "sfp-type-change", detect_sfp_type_change);
    amxm_module_add_function(mod, "get-sfp-type", get_sfp_type);
    amxm_module_add_function(mod, "read-sfp-type", read_sfp_type);
exit:
    return 0;
}

/**
 * @brief Stop and clean the mod-wanmgr-sfp module.
 *
 * @return AMXM_DESTRUCTOR always return 0.
 */
static AMXM_DESTRUCTOR mod_wanmgr_sfp_down(void) {
    SAH_TRACEZ_INFO(ME, "Exiting mod-wanmgr-sfp destructor");

    return 0;
}
