/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_cellular-dummy.h"

#define ME "dummy"

static amxc_llist_t* dummy_cell_ifaces = NULL;

static int init_dummy_cell_iface(dummy_cell_iface_t* cell_iface, const char* obj_path, const char* netdev_name) {
    int rv = -1;

    SAH_TRACEZ_INFO(ME, "initializing dummy cell iface for object %s", obj_path);
    when_null_trace(cell_iface, exit, ERROR, "interface can not be null, invalid argument");
    when_str_empty(obj_path, exit);
    when_str_empty(netdev_name, exit);

    strncpy(cell_iface->object_path, obj_path, sizeof(cell_iface->object_path) - 1);
    if(!strcmp("Cellular.Interface.1", obj_path)) {
        cell_iface->enable = true;
        strcpy(cell_iface->status, "Up");
        strcpy(cell_iface->name, "Modem/0");
        strcpy(cell_iface->imei, "863781016084494");
        strcpy(cell_iface->supported_access_tech, "GPRS,EDGE,UMTS,LTE");
        strcpy(cell_iface->preferred_access_tech, "LTE");
        strcpy(cell_iface->current_access_tech, "LTE");
        strcpy(cell_iface->available_networks, "Orange,Raspberry,Peach");
        strcpy(cell_iface->network_requested, "Orange");
        strcpy(cell_iface->network_in_use, "Orange");
        cell_iface->signal_quality_polling_rate = 30;
        cell_iface->rssi = -30;
        cell_iface->rsrp = -50;
        cell_iface->rsrq = -5;
        cell_iface->upstream_max_bitrate = 50000;
        cell_iface->downstream_max_bitrate = 100000;
        strcpy(cell_iface->usim.name, "SIM/0");
        strcpy(cell_iface->usim.status, "Valid");
        strcpy(cell_iface->usim.imsi, "206102300806160");
        strcpy(cell_iface->usim.iccid, "89320299220208006010");
        strcpy(cell_iface->usim.msisdn, "206102300806160");
        strcpy(cell_iface->usim.pin_check, "Reboot");
        strcpy(cell_iface->usim.pin, "1234");
        strcpy(cell_iface->bearer.name, "Bearer/0");
        strcpy(cell_iface->bearer.dns_servers, "10.0.0.2,2001:4860:4860::8888");
        strcpy(cell_iface->bearer.ipv4.method, "Static");
        strcpy(cell_iface->bearer.ipv4.addr, "10.0.0.10");
        strcpy(cell_iface->bearer.ipv4.prefix, "255.255.255.128");
        strcpy(cell_iface->bearer.ipv4.gateway, "10.0.0.11");
        cell_iface->bearer.ipv4.mtu = 1500;
        strcpy(cell_iface->bearer.ipv6.method, "Static");
        strcpy(cell_iface->bearer.ipv6.addr, "2001:db8:cafe:1:754e:73c3:176c:ff47");
        strcpy(cell_iface->bearer.ipv6.prefix, "2001:db8:cafe:1::/64");
        strcpy(cell_iface->bearer.ipv6.gateway, "2001:db8:cafe:1:c47b:a1d:6d44:6bbd");
        cell_iface->bearer.ipv6.mtu = 1400;
    } else if(!strcmp("Cellular.Interface.2", obj_path)) {
        cell_iface->enable = true;
        strcpy(cell_iface->status, "Up");
        strcpy(cell_iface->name, "Modem/1");
        strcpy(cell_iface->imei, "863781016084495");
        strcpy(cell_iface->supported_access_tech, "GPRS,EDGE,UMTS,LTE");
        strcpy(cell_iface->preferred_access_tech, "Auto");
        strcpy(cell_iface->current_access_tech, "UMTS");
        strcpy(cell_iface->available_networks, "Orange,Blueberry,Apple");
        strcpy(cell_iface->network_requested, "Blueberry");
        strcpy(cell_iface->network_in_use, "Blueberry");
        cell_iface->signal_quality_polling_rate = 60;
        cell_iface->rssi = -60;
        cell_iface->rsrp = -140;
        cell_iface->rsrq = -5;
        cell_iface->upstream_max_bitrate = 128;
        cell_iface->downstream_max_bitrate = 384;
        strcpy(cell_iface->usim.name, "SIM/1");
        strcpy(cell_iface->usim.status, "Available");
        strcpy(cell_iface->usim.imsi, "206102300806161");
        strcpy(cell_iface->usim.iccid, "89320299220208006011");
        strcpy(cell_iface->usim.msisdn, "206102300806161");
        strcpy(cell_iface->usim.pin_check, "OnNetworkAccess");
        strcpy(cell_iface->usim.pin, "4321");
        strcpy(cell_iface->bearer.name, "Bearer/1");
        strcpy(cell_iface->bearer.dns_servers, "10.0.0.2,2001:4860:4860::8844");
        strcpy(cell_iface->bearer.ipv4.method, "Static");
        strcpy(cell_iface->bearer.ipv4.addr, "10.0.0.20");
        strcpy(cell_iface->bearer.ipv4.prefix, "255.255.255.128");
        strcpy(cell_iface->bearer.ipv4.gateway, "10.0.0.22");
        cell_iface->bearer.ipv4.mtu = 1500;
        strcpy(cell_iface->bearer.ipv6.method, "Static");
        strcpy(cell_iface->bearer.ipv6.addr, "2001:db8:cafe:1:754e:73c3:176c:ffab");
        strcpy(cell_iface->bearer.ipv6.prefix, "2001:db8:cafe:1::/64");
        strcpy(cell_iface->bearer.ipv6.gateway, "2001:db8:cafe:1:c47b:a1d:6d44:6bbd");
        cell_iface->bearer.ipv6.mtu = 1400;
    } else {
        SAH_TRACEZ_ERROR(ME, "Unable to initialize cell interface %s", obj_path);
        goto exit;
    }
    strcpy(cell_iface->netdev_name, netdev_name);

    rv = 0;

exit:
    return rv;
}

int dummy_iface_create(UNUSED const char* function_name,
                       amxc_var_t* args,
                       amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    const char* name = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");

    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_str_empty_trace(obj_path, exit, ERROR, "Passed object path is empty");
    name = GET_CHAR(args, "Name");
    when_str_empty_trace(name, exit, ERROR, "Passed name is empty");

    SAH_TRACEZ_INFO(ME, "creating dummy cell iface info for object %s netdev name %s", obj_path, name);

    dummy_cell_iface_t* cell_iface = calloc(1, sizeof(dummy_cell_iface_t));
    when_null_trace(cell_iface, exit, ERROR, "Unable to allocate memory");

    retval = init_dummy_cell_iface(cell_iface, obj_path, name);
    when_failed_trace(retval, clean, ERROR, "Failed to initialize dummy cell interface %s", obj_path);

    amxc_llist_append(dummy_cell_ifaces, &cell_iface->it);

    SAH_TRACEZ_NOTICE(ME, "Allocated dummy cell iface for %s", obj_path);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->name);

    retval = 0;

clean:
    if(retval != 0) {
        free(cell_iface);
    }
exit:
    return retval;
}

static void dummy_iface_delete(amxc_llist_it_t* it) {
    dummy_cell_iface_t* cell_iface = amxc_container_of(it, dummy_cell_iface_t, it);
    SAH_TRACEZ_NOTICE(ME, "Deallocating dummy cell iface for %s", cell_iface->object_path);
    free(cell_iface);
}

static dummy_cell_iface_t* find_dummy_cell_iface_by_object_path(const char* object_path) {
    dummy_cell_iface_t* cell_iface;

    amxc_llist_for_each(it, dummy_cell_ifaces) {
        cell_iface = amxc_container_of(it, dummy_cell_iface_t, it);
        if(!strcmp(cell_iface->object_path, object_path)) {
            return cell_iface;
        }
    }
    return NULL;
}

int dummy_iface_destroy(UNUSED const char* function_name,
                        amxc_var_t* args,
                        UNUSED amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");

    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");
    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    SAH_TRACEZ_INFO(ME, "Destroy dummy cell iface %s", obj_path);

    dummy_cell_iface_t* cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    amxc_llist_it_clean(&cell_iface->it, dummy_iface_delete);

    retval = 0;

exit:
    return retval;
}

int dummy_iface_destroy_all(UNUSED const char* function_name,
                            UNUSED amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_NOTICE(ME, "Destroy all dummy cell interfaces");
    amxc_llist_delete(&dummy_cell_ifaces, dummy_iface_delete);

    return 0;
}

int dummy_iface_set(UNUSED const char* function_name,
                    amxc_var_t* args,
                    UNUSED amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    dummy_cell_iface_t* cell_iface = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");
    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "Setting for interface %s", cell_iface->object_path);

    if(GET_ARG(args, "Enable")) {
        cell_iface->enable = GET_BOOL(args, "Enable");
        if(cell_iface->enable) {
            strcpy(cell_iface->status, "Up");
        } else {
            strcpy(cell_iface->status, "Down");
        }
        SAH_TRACEZ_INFO(ME, "Set enable=%d", cell_iface->enable);
    } else if(GET_ARG(args, "SignalQualityPollingRate")) {
        cell_iface->signal_quality_polling_rate = GET_UINT32(args, "SignalQualityPollingRate");
        SAH_TRACEZ_INFO(ME, "Set signal_quality_polling_rate=%u", cell_iface->signal_quality_polling_rate);
    } else if(GET_ARG(args, "PreferredAccessTechnology")) {
        strncpy(cell_iface->preferred_access_tech, GET_CHAR(args, "PreferredAccessTechnology"), 127);
        SAH_TRACEZ_INFO(ME, "Set preferred_access_tech=%s", cell_iface->preferred_access_tech);
    } else if(GET_ARG(args, "NetworkRequested")) {
        strncpy(cell_iface->network_requested, GET_CHAR(args, "NetworkRequested"), 64);
        SAH_TRACEZ_INFO(ME, "Set network_requested=%s", cell_iface->network_requested);
    }

    retval = 0;

exit:
    return retval;
}

int dummy_iface_retrieve(UNUSED const char* function_name,
                         amxc_var_t* args,
                         amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    dummy_cell_iface_t* cell_iface = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");

    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "get data for %s", cell_iface->object_path);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, ret, "Enable", cell_iface->enable);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->name);
    amxc_var_add_key(cstring_t, ret, "Name", cell_iface->netdev_name);
    amxc_var_add_key(cstring_t, ret, "Status", cell_iface->status);
    amxc_var_add_key(cstring_t, ret, "IMEI", cell_iface->imei);
    amxc_var_add_key(cstring_t, ret, "SupportedAccessTechnologies", cell_iface->supported_access_tech);
    amxc_var_add_key(cstring_t, ret, "PreferredAccessTechnology", cell_iface->preferred_access_tech);
    amxc_var_add_key(cstring_t, ret, "CurrentAccessTechnology", cell_iface->current_access_tech);
    amxc_var_add_key(cstring_t, ret, "AvailableNetworks", cell_iface->available_networks);
    amxc_var_add_key(cstring_t, ret, "NetworkRequested", cell_iface->network_requested);
    amxc_var_add_key(cstring_t, ret, "NetworkInUse", cell_iface->network_in_use);
    amxc_var_add_key(int32_t, ret, "RSSI", cell_iface->rssi);
    amxc_var_add_key(int32_t, ret, "RSRP", cell_iface->rsrp);
    amxc_var_add_key(int32_t, ret, "RSRQ", cell_iface->rsrq);
    amxc_var_add_key(uint32_t, ret, "UpstreamMaxBitRate", cell_iface->upstream_max_bitrate);
    amxc_var_add_key(uint32_t, ret, "DownstreamMaxBitRate", cell_iface->downstream_max_bitrate);

    retval = 0;

exit:
    return retval;
}

int dummy_usim_set(UNUSED const char* function_name,
                   amxc_var_t* args,
                   UNUSED amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    dummy_cell_iface_t* cell_iface = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "Setting for USIM %s", cell_iface->usim.name);

    if(GET_ARG(args, "PINCheck")) {
        strncpy(cell_iface->usim.pin_check, GET_CHAR(args, "PINCheck"), 15);
        SAH_TRACEZ_INFO(ME, "Set pin_check=%s", cell_iface->usim.pin_check);
    }
    if(GET_ARG(args, "PIN")) {
        strncpy(cell_iface->usim.pin, GET_CHAR(args, "PIN"), 4);
        SAH_TRACEZ_INFO(ME, "Set pin=%s", cell_iface->usim.pin);
    }

    retval = 0;

exit:
    return retval;
}

int dummy_usim_retrieve(UNUSED const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    dummy_cell_iface_t* cell_iface = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "get data for %s", cell_iface->usim.name);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->usim.name);
    amxc_var_add_key(cstring_t, ret, "Status", cell_iface->usim.status);
    amxc_var_add_key(cstring_t, ret, "IMSI", cell_iface->usim.imsi);
    amxc_var_add_key(cstring_t, ret, "ICCID", cell_iface->usim.iccid);
    amxc_var_add_key(cstring_t, ret, "MSISDN", cell_iface->usim.msisdn);
    amxc_var_add_key(cstring_t, ret, "PINCheck", cell_iface->usim.pin_check);
    amxc_var_add_key(cstring_t, ret, "PIN", cell_iface->usim.pin);

    retval = 0;

exit:
    return retval;
}

int dummy_bearer_retrieve(UNUSED const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    dummy_cell_iface_t* cell_iface = NULL;
    amxc_var_t* ipv4_addr = NULL;
    amxc_var_t* ipv6_addr = NULL;

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_dummy_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "Dummy interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "get data for %s", cell_iface->bearer.name);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->bearer.name);
    amxc_var_add_key(cstring_t, ret, "DNSServers", cell_iface->bearer.dns_servers);
    ipv4_addr = amxc_var_add_new_key(ret, "IPv4");
    amxc_var_set_type(ipv4_addr, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ipv4_addr, "Method", cell_iface->bearer.ipv4.method);
    amxc_var_add_key(cstring_t, ipv4_addr, "Address", cell_iface->bearer.ipv4.addr);
    amxc_var_add_key(cstring_t, ipv4_addr, "GatewayIPAddress", cell_iface->bearer.ipv4.gateway);
    amxc_var_add_key(cstring_t, ipv4_addr, "SubnetMask", cell_iface->bearer.ipv4.prefix);
    amxc_var_add_key(uint32_t, ipv4_addr, "MTU", cell_iface->bearer.ipv4.mtu);

    ipv6_addr = amxc_var_add_new_key(ret, "IPv6");
    amxc_var_set_type(ipv6_addr, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ipv6_addr, "Method", cell_iface->bearer.ipv6.method);
    amxc_var_add_key(cstring_t, ipv6_addr, "Address", cell_iface->bearer.ipv6.addr);
    amxc_var_add_key(cstring_t, ipv6_addr, "NextHop", cell_iface->bearer.ipv6.gateway);
    amxc_var_add_key(cstring_t, ipv6_addr, "Prefix", cell_iface->bearer.ipv6.prefix);
    amxc_var_add_key(uint32_t, ipv6_addr, "MTU", cell_iface->bearer.ipv6.mtu);

    retval = 0;

exit:
    return retval;
}

static AMXM_CONSTRUCTOR dummy_module_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxc_llist_new(&dummy_cell_ifaces);

    amxm_module_register(&mod, so, MOD_CELLULAR_CTRL);
    amxm_module_add_function(mod, "create-cell-iface", dummy_iface_create);
    amxm_module_add_function(mod, "destroy-cell-iface", dummy_iface_destroy);
    amxm_module_add_function(mod, "destroy-all-cell-ifaces", dummy_iface_destroy_all);
    amxm_module_add_function(mod, "set-cell-iface-info", dummy_iface_set);
    amxm_module_add_function(mod, "retrieve-cell-iface-info", dummy_iface_retrieve);
    amxm_module_add_function(mod, "set-cell-usim-info", dummy_usim_set);
    amxm_module_add_function(mod, "retrieve-cell-usim-info", dummy_usim_retrieve);
    amxm_module_add_function(mod, "retrieve-cell-bearer-info", dummy_bearer_retrieve);

    SAH_TRACEZ_NOTICE(ME, "Module loaded");

    return 0;
}

static AMXM_DESTRUCTOR dummy_module_stop(void) {

    SAH_TRACEZ_NOTICE(ME, "Module stopped");

    amxc_llist_delete(&dummy_cell_ifaces, dummy_iface_delete);
    return 0;
}
