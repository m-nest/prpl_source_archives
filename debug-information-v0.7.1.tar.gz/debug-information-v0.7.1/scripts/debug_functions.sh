show_cmd()
{
  echo "-------- $@"
  eval "$@"
  echo ""
}

show_title()
{
    echo "######## $1"
}
