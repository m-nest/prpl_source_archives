/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "flash_health.h"
#include "nand_health.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ME "nand"
/**
 * @brief Retrieves NAND block parameters and updates the flash health structure.
 *
 * This function reads the NAND block table for the device specified in the
 * flash_health_t structure and updates the total good and bad blocks.
 *
 * @param fh Pointer to the flash_health_t structure.
 * @return true if parameters were successfully retrieved, false otherwise.
 */
static bool fh_get_nand_params (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);

    if(!fh) {
        return false;
    }

    const char* base_name = strrchr(fh->path, '/');
    if(!base_name || (strncmp(base_name + 1, "mtd", 3) != 0)) {
        SAH_TRACEZ_ERROR(ME, "Invalid MTD device path: %s", fh->path);
        return false;
    }

    char mtd_name[32];
    char bad_blocks_path[128];
    char erasesize_path[128];
    char size_path[128];

    strncpy(mtd_name, base_name + 1, sizeof(mtd_name) - 1);
    mtd_name[sizeof(mtd_name) - 1] = '\0';

    snprintf(bad_blocks_path, sizeof(bad_blocks_path), "/sys/class/mtd/%s/bad_blocks", mtd_name);
    snprintf(erasesize_path, sizeof(erasesize_path), "/sys/class/mtd/%s/erasesize", mtd_name);
    snprintf(size_path, sizeof(size_path), "/sys/class/mtd/%s/size", mtd_name);

    FILE* fp_bad = fopen(bad_blocks_path, "r");
    FILE* fp_erase = fopen(erasesize_path, "r");
    FILE* fp_size = fopen(size_path, "r");

    unsigned int erasesize = 0;
    unsigned int size = 0;

    if(!fp_bad || !fp_erase || !fp_size) {
        perror("Error accessing sysfs files");
        if(fp_bad) {
            fclose(fp_bad);
        }
        if(fp_erase) {
            fclose(fp_erase);
        }
        if(fp_size) {
            fclose(fp_size);
        }
        return false;
    }

    if((fscanf(fp_bad, "%u", &(fh->totalBadBlocks)) != 1) ||
       (fscanf(fp_erase, "%u", &erasesize) != 1) ||
       (fscanf(fp_size, "%u", &size) != 1)) {
        SAH_TRACEZ_ERROR(ME, "Failed to read values from sysfs");
        fclose(fp_bad);
        fclose(fp_erase);
        return false;
    }

    fh->totalGoodBlocks = (size / erasesize) - fh->totalBadBlocks;

    fclose(fp_bad);
    fclose(fp_erase);

    SAH_TRACEZ_OUT(ME);
    return true;
}

/**
 * @brief Checks the health of the NAND device and updates its status.
 *
 * This function calculates the percentage of bad blocks and sets the health
 * status to critical or normal based on the configured threshold.
 *
 * @param fh Pointer to the flash_health_t structure.
 */
void fh_nand_check (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    uint32_t bb = 0;
    uint32_t gb = 0;
    uint32_t bbpercent = 0;
    bool rv = fh_get_nand_params(fh);
    if(fh == NULL) {
        return;
    }
    if(rv == true) {
        bb = fh->totalBadBlocks;
        gb = fh->totalGoodBlocks;
        bbpercent = (100 * bb) / (bb + gb);

        if(bbpercent >= fh->badBlocksThreshold) {
            set_health_status(fh, HEALTH_STATUS_CRITICAL);
        } else {
            set_health_status(fh, HEALTH_STATUS_NORMAL);
        }
    }

    SAH_TRACEZ_OUT(ME);
    return;
}
