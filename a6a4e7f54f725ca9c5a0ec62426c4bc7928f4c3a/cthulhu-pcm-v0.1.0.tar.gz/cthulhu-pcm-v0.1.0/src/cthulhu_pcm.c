/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_helpers.h>
#include <cthulhu/cthulhu_config.h>

#include <lcm/lcm_assert.h>
#include <lcm/amxc_data.h>
#include <debug/sahtrace.h>

#include "cthulhu_pcm.h"
#define ME "pcm"

#define PCM_EXPORT_FN "CustomPcmExport"
#define PCM_IMPORT_FN "CustomPcmImport"

/**
 * @brief Pointer to the data model instance.
 */
static amxd_dm_t* dm = NULL;
/**
 * @brief Pointer to the shared object instance.
 */
static amxm_shared_object_t* so = NULL;
/**
 * @brief Pointer to the module instance.
 */
static amxm_module_t* mod = NULL;

/**
 * @brief Pointer to save prestartup_config.
 */
static cthulhu_prestartup_config_t* prestartup_config = NULL;

/**
 * @brief Pointer to cthulhu_plugin_exec.
 */
static cthulhu_plugin_exec_fn cthulhu_plugin_exec = NULL;

/**
 * @brief Gets the data model instance.
 * @return Pointer to the data model instance.
 */
static amxd_dm_t* get_dm(void) {
    return dm;
}

/**
 * @brief Gets the prestartup_config pointer.
 * @return Pointer to saved prestartup_config.
 */
cthulhu_prestartup_config_t* get_prestartup_config(void) {
    return prestartup_config;
}

/**
 * @brief Sets the prestartup_config pointer.
 * @return Pointer to saved prestartup_config.
 */
void set_prestartup_config(cthulhu_prestartup_config_t* config) {
    prestartup_config = config;
}

/**
 * @brief Copies specified arguments from a source variable to a destination variable.
 *
 * Iterates over a list of argument descriptors and copies the corresponding values
 * from the source variable to the destination variable using the provided parameter
 * names and paths.
 *
 * @param dest       Pointer to the destination amxc_var_t variable where arguments will be copied.
 * @param src        Pointer to the source amxc_var_t variable from which arguments are read.
 * @param rpc_args   Array of cthulhu_restore_data_t structures describing the arguments to copy.
 * @param args_count Number of elements in the rpc_args array.
 */
void cthulhu_copy_args(amxc_var_t* dest, const amxc_var_t* src,
                       const cthulhu_restore_data_t* rpc_args, size_t args_count) {
    const cthulhu_restore_data_t* param = NULL;
    for(size_t i = 0; i < args_count; i++) {
        param = &rpc_args[i];
        amxc_var_t* var = GETP_ARG(src, param->path);
        if(!var) {
            continue;
        }
        amxc_var_set_key(dest, param->parameter, var, AMXC_VAR_FLAG_COPY);
    }
}

/**
 * @brief Registers PCM import and export functions to the Cthulhu object in the data model.
 *
 * This function creates and registers the custom "import" and "export" function which will
 * be used by the Persistent Configuration Manager (PCM).
 */
static amxd_status_t register_pcm_functions(amxd_object_fn_t export_fn, amxd_object_fn_t import_fn) {
    amxd_status_t rc = amxd_status_unknown_error;
    amxd_function_t* import = NULL;
    amxd_function_t* export = NULL;
    amxc_var_t def_val;

    ASSERT_NOT_NULL(export_fn, goto exit);
    ASSERT_NOT_NULL(import_fn, goto exit);

    SAH_TRACEZ_INFO(ME, "Registering export/import functions");
    amxd_object_t* cthulhu = amxd_dm_findf(dm, CTHULHU);
    ASSERT_NOT_NULL(cthulhu, goto exit);

    ASSERT_SUCCESS(amxd_function_new(&import,
                                     PCM_IMPORT_FN,
                                     AMXC_VAR_ID_NULL,
                                     import_fn), goto error);

    ASSERT_SUCCESS(amxd_function_set_attr(import, amxd_fattr_protected, true), goto error);
    ASSERT_SUCCESS(amxd_function_new_arg(import, "data", AMXC_VAR_ID_HTABLE, NULL), goto error);
    ASSERT_SUCCESS(amxd_function_arg_is_attr_set(import, "data", amxd_aattr_in), goto error);
    ASSERT_SUCCESS(amxd_function_arg_is_attr_set(import, "data", amxd_aattr_mandatory), goto error);

    rc = amxd_object_add_function(cthulhu, import);
    ASSERT_SUCCESS(rc, goto error);

    ASSERT_SUCCESS(amxd_function_new(&export,
                                     PCM_EXPORT_FN,
                                     AMXC_VAR_ID_NULL,
                                     export_fn), goto error);

    amxc_var_init(&def_val);

    ASSERT_SUCCESS(amxd_function_set_attr(export, amxd_fattr_protected, true), goto error);

    amxc_var_set(bool, &def_val, false);
    ASSERT_SUCCESS(amxd_function_new_arg(export, "usersetting", AMXC_VAR_ID_BOOL, &def_val), goto error);
    amxd_function_arg_set_attr(export, "usersetting", amxd_aattr_in, true);

    amxc_var_set(bool, &def_val, true);
    ASSERT_SUCCESS(amxd_function_new_arg(export, "changed", AMXC_VAR_ID_BOOL, &def_val), goto error);
    amxd_function_arg_set_attr(export, "changed", amxd_aattr_in, true);

    ASSERT_SUCCESS(amxd_function_new_arg(export, "data", AMXC_VAR_ID_HTABLE, NULL), goto error);
    amxd_function_arg_set_attr(export, "data", amxd_aattr_out, true);

    rc = amxd_object_add_function(cthulhu, export);
    ASSERT_SUCCESS(rc, goto error);

    SAH_TRACEZ_INFO(ME, "Registered success");

exit:
    return rc;

error:
    amxd_function_delete(&import);
    amxd_function_delete(&export);
    return rc;
}

/**
 * @brief Executes a specific command/hook on the plugins that are registering the
 *        specified command/hook.
 *
 * @param method The hook name to be executed.
 * @param in_data variable that contains the input config to be passed to the hook.
 * @param out_data variable that contains the output config to be filled in by the hook.
 * @return None
 */
static void cthulhu_pcm_plugin_exec(const char* method, const amxc_var_t* in_data, amxc_var_t* out_data) {
    ASSERT_NOT_NULL(cthulhu_plugin_exec, return );
    amxc_var_t plugin_var;
    amxc_var_init(&plugin_var);
    amxc_var_set_type(&plugin_var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&plugin_var, CTHULHU_PLUGIN_ARG_IMPORT_DATA, (amxc_var_t*) in_data);
    amxc_var_add_new_key_data(&plugin_var, CTHULHU_PLUGIN_ARG_OUT_DATA, (amxc_var_t*) out_data);
    ASSERT_SUCCESS(cthulhu_plugin_exec(method, &plugin_var, NULL), NO_INSTRUCTION, "Execution of %s failed", method);

    amxc_var_clean(&plugin_var);
}

/**
 * @brief Prepares the argument values for Sandbox.restore() RPC based on the
 * imported data from PCM
 *
 * @param dest_sb variable that contains the arguments for Sandbox.restore() RPC
 * @param src_sb variable that contains the imported data from PCM
 * @return None
 */
void cthulhu_sb_restore_fill(amxc_var_t* dest_sb, const amxc_var_t* src_sb) {
    const cthulhu_restore_data_t rpc_args[] = {
        {CTHULHU_SANDBOX_ID, CTHULHU_SANDBOX_ID, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_PARENT, CTHULHU_SANDBOX_PARENT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_ENABLE, CTHULHU_SANDBOX_ENABLE, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_VERSION, CTHULHU_SANDBOX_VERSION, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_VENDOR, CTHULHU_SANDBOX_VENDOR, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_CPU, CTHULHU_SANDBOX_CPU, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_MEMORY, CTHULHU_SANDBOX_MEMORY, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_DISKSPACE, CTHULHU_SANDBOX_DISKSPACE, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_AVAILABLE_ROLES, CTHULHU_SANDBOX_AVAILABLE_ROLES_NAMES, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_APPLICATIONDATA, CTHULHU_SANDBOX_APPLICATIONDATA, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_DEVICES, CTHULHU_SANDBOX_DEVICES, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_CREATED, CTHULHU_SANDBOX_CREATED, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_DESCRIPTION, CTHULHU_SANDBOX_DESCRIPTION, AMXC_VAR_FLAG_COPY},
        {CTHULHU_SANDBOX_RESTART_REASON, CTHULHU_SANDBOX_RESTART_REASON, AMXC_VAR_FLAG_COPY},
    };
    size_t args_count = sizeof(rpc_args) / sizeof((rpc_args)[0]);
    cthulhu_copy_args(dest_sb, src_sb, rpc_args, args_count);

    // Fill the other parameters that are owned by Cthulhu plugins
    cthulhu_pcm_plugin_exec(CTHULHU_PLUGIN_SB_IMPORT, src_sb, dest_sb);
}

/**
 * @brief Prepares the argument values for Container.restore() RPC based on the
 * imported data from PCM
 *
 * @param dest_ctr variable that contains the arguments for Container.restore() RPC
 * @param src_Ctr variable that contains the imported data from PCM
 * @param sandboxes a list of sandboxes, necessary for resolving ApplicationData
 * @return None
 */
void cthulhu_ctr_restore_fill(amxc_var_t* dest_ctr, const amxc_var_t* src_ctr,
                              const amxc_var_t* sandboxes) {
    const cthulhu_restore_data_t rpc_args[] = {
        {CTHULHU_CONTAINER_ID, CTHULHU_CONTAINER_ID, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_LINKED_UUID, CTHULHU_CONTAINER_LINKED_UUID, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_BUNDLE, CTHULHU_CONTAINER_BUNDLE, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_BUNDLEVERSION, CTHULHU_CONTAINER_BUNDLEVERSION, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_DISKLOCATION, CTHULHU_CONTAINER_DISKLOCATION, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_SANDBOX, CTHULHU_CONTAINER_SANDBOX, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_AUTOSTART, CTHULHU_CONTAINER_AUTOSTART, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_MODULEVERSION, CTHULHU_CONTAINER_MODULEVERSION, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_REQUIRED_ROLES, CTHULHU_CONTAINER_REQUIRED_ROLES, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_OPTIONAL_ROLES, CTHULHU_CONTAINER_OPTIONAL_ROLES, AMXC_VAR_FLAG_COPY},
        // Resources
        {CTHULHU_CONTAINER_RESOURCES_CPU, CTHULHU_CONTAINER_RESOURCES "." CTHULHU_CONTAINER_RESOURCES_CPU, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_RESOURCES_MEMORY, CTHULHU_CONTAINER_RESOURCES "." CTHULHU_CONTAINER_RESOURCES_MEMORY, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_RESOURCES_DISKSPACE, CTHULHU_CONTAINER_RESOURCES "." CTHULHU_CONTAINER_RESOURCES_DISKSPACE, AMXC_VAR_FLAG_COPY},
        // Optional parameters
        {CTHULHU_CONTAINER_CREATED, CTHULHU_CONTAINER_CREATED, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_LASTREQSTATEACTIVE, CTHULHU_CONTAINER_LASTREQSTATEACTIVE, AMXC_VAR_FLAG_COPY},
        {CTHULHU_CONTAINER_UPDATED, CTHULHU_CONTAINER_UPDATED, AMXC_VAR_FLAG_COPY},
    };
    size_t args_count = sizeof(rpc_args) / sizeof((rpc_args)[0]);
    cthulhu_copy_args(dest_ctr, src_ctr, rpc_args, args_count);

    // ApplicationData - check if any was created by this container
    amxc_var_t* dst_appdata = amxc_var_add_key(amxc_llist_t, dest_ctr, CTHULHU_CONTAINER_APPLICATIONDATA, NULL);
    amxc_var_for_each(it, sandboxes) {
        amxc_var_t* sandbox = amxc_var_get_first(it);
        if(strcmp(GET_CHAR(sandbox, CTHULHU_SANDBOX_ID), GET_CHAR(src_ctr, CTHULHU_CONTAINER_SANDBOX))) {
            continue; // different sandbox, skip it
        }
        amxc_var_t* appdatas = GET_ARG(sandbox, CTHULHU_CONTAINER_APPLICATIONDATA);
        amxc_var_for_each(it2, appdatas) {
            amxc_var_t* appdata = amxc_var_get_first(it2);
            if(strcmp(
                   GET_CHAR(appdata, CTHULHU_SANDBOX_APPLICATIONDATA_APPLICATIONUUID),
                   GET_CHAR(src_ctr, CTHULHU_CONTAINER_ID)) == 0) {
                amxc_var_t* uuid = amxc_var_take_key(appdata, CTHULHU_SANDBOX_APPLICATIONDATA_APPLICATIONUUID);
                amxc_var_delete(&uuid);
                amxc_var_add(amxc_htable_t, dst_appdata, amxc_var_constcast(amxc_htable_t, appdata));
            }
        }
    }

    // Environment variables
    const amxc_var_t* src_envvars = GET_ARG(src_ctr, CTHULHU_CONTAINER_ENVIRONMENTVARIABLES);
    if(src_envvars) {
        amxc_var_t* dst_envvars = amxc_var_add_key(amxc_llist_t, dest_ctr, CTHULHU_CONTAINER_ENVIRONMENTVARIABLES, NULL);
        amxc_var_for_each(it, src_envvars) {
            amxc_var_t* envvar = amxc_var_get_first(it);
            amxc_var_add(amxc_htable_t, dst_envvars, amxc_var_constcast(amxc_htable_t, envvar));
        }
    }

    // HostObject
    const amxc_var_t* src_hostobjects = GET_ARG(src_ctr, CTHULHU_CONTAINER_HOSTOBJECT);
    if(src_hostobjects) {
        amxc_var_t* dst_hostobjects = amxc_var_add_key(amxc_llist_t, dest_ctr, CTHULHU_CONTAINER_HOSTOBJECT, NULL);
        amxc_var_for_each(it, src_hostobjects) {
            amxc_var_t* hostobj = amxc_var_get_first(it);
            amxc_var_add(amxc_htable_t, dst_hostobjects, amxc_var_constcast(amxc_htable_t, hostobj));
        }
    }

    // Unprivileged
    const amxc_var_t* unpriv = GET_ARG(src_ctr, CTHULHU_CONTAINER_UNPRIVILEGED);
    if(unpriv == NULL) {
        amxc_var_add_key(bool, dest_ctr, CTHULHU_CONTAINER_UNPRIVILEGED_PRIVILEGED, true);
    } else {
        amxc_var_add_key(bool, dest_ctr, CTHULHU_CONTAINER_UNPRIVILEGED_PRIVILEGED, false);
        uint32_t uids = GET_UINT32(unpriv, CTHULHU_CONTAINER_UNPRIVILEGED_NUMREQUIREDUIDS);
        amxc_var_add_key(uint32_t, dest_ctr, CTHULHU_CONTAINER_UNPRIVILEGED_NUMREQUIREDUIDS, uids);
    }

    // AutoRestart
    const cthulhu_restore_data_t autorestart_args[] = {
        {CTHULHU_DM_CTR_AR_ENABLE, CTHULHU_DM_CTR_AR_ENABLE, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_RETRYCOUNT, CTHULHU_DM_CTR_AR_RETRYCOUNT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_MAX_RETRYCOUNT, CTHULHU_DM_CTR_AR_MAX_RETRYCOUNT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_MIN_INT, CTHULHU_DM_CTR_AR_MIN_INT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_MAX_INT, CTHULHU_DM_CTR_AR_MAX_INT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_RETRY_INT, CTHULHU_DM_CTR_AR_RETRY_INT, AMXC_VAR_FLAG_COPY},
        {CTHULHU_DM_CTR_AR_RESET, CTHULHU_DM_CTR_AR_RESET, AMXC_VAR_FLAG_COPY},
    };
    args_count = sizeof(autorestart_args) / sizeof((autorestart_args)[0]);
    const amxc_var_t* src_autorestart = GET_ARG(src_ctr, CTHULHU_CONTAINER_AUTORESTART);
    if(src_autorestart) {
        amxc_var_t* dst_autorestart = amxc_var_add_key(amxc_htable_t, dest_ctr,
                                                       CTHULHU_CONTAINER_AUTORESTART, NULL);
        cthulhu_copy_args(dst_autorestart, src_ctr, autorestart_args, args_count);
    }

    // Fill the other parameters that are owned by Cthulhu plugins
    // (e.g. cthulhu-networking with NetworkConfig)
    cthulhu_pcm_plugin_exec(CTHULHU_PLUGIN_CTR_IMPORT, src_ctr, dest_ctr);
}

/**
 * @brief Custom export function.
 *
 * This function provides a wrapper around the generic pcm_svc export functionality.
 *
 * @param object Pointer to the object implementing the function.
 * @param func   Pointer to the function.
 * @param args   Variant containing the input arguments.
 * @param ret    Variant to store the return value.
 * @return amxd_status_t Returns amxd_status_ok on success, or an appropriate error code on failure.
 */
amxd_status_t custom_pcm_export(UNUSED amxd_object_t* object,
                                UNUSED amxd_function_t* func,
                                amxc_var_t* args,
                                UNUSED amxc_var_t* ret) {

    amxc_var_t* fn_rv = NULL;
    amxd_dm_t* datamodel = get_dm();

    ASSERT_NOT_NULL(datamodel, return amxd_status_unknown_error);
    amxd_object_t* cthulhu_obj = amxd_dm_findf(datamodel, CTHULHU_DM ".");

    amxc_var_new(&fn_rv);
    amxd_status_t retval = amxd_object_invoke_function(cthulhu_obj, "PcmExport", args, fn_rv);
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to invoke datamodel export: (%d) %s", retval, amxd_status_string(retval));
    }
    amxc_var_delete(&fn_rv);

    return amxd_status_ok;
}

/**
 * @brief Custom import function.
 *
 * It prepares the necessary arguments based on the imported data from PCM in
 * order to recreate later the containers, sandboxes and modify the default
 * sandboxes configuration.
 * In the case of default sandboxes, it also overwrites the sandboxes' values
 * with imported values from PCM.
 * Basically, it reuses the `cthulhu_prestartup_config_t` with extra list
 * (sb_mobify) to modify the default sandboxes (already present in data model)
 * with resource constraints.
 *
 * @param object Pointer to the object implementing the function.
 * @param func   Pointer to the function.
 * @param args   Variant containing the input arguments.
 * @param ret    Variant to store the return value.
 * @return amxd_status_t Returns amxd_status_ok on success, or an appropriate error code on failure.
 */
amxd_status_t custom_pcm_import(UNUSED amxd_object_t* object,
                                UNUSED amxd_function_t* func,
                                amxc_var_t* args,
                                UNUSED amxc_var_t* ret) {

    const amxc_var_t* pcm_data = NULL;
    const amxc_var_t* sandboxes = NULL;
    const amxc_var_t* ctrs = NULL;
    amxd_object_t* sb_obj = NULL;
    amxd_status_t status = amxd_status_unknown_error;
    cthulhu_prestartup_config_t* config = get_prestartup_config();

    pcm_data = GET_ARG(args, "data");
    ASSERT_NOT_NULL(pcm_data, goto exit, "'data' parameter not found");

    sandboxes = GETP_ARG(pcm_data, "set.hgwconfig." CTHULHU_DM_SANDBOX_INSTANCES);
    ASSERT_NOT_NULL(sandboxes, goto exit, "Failed to get sandboxes data model from imported configuration");

    // Remove all the default sandboxes: both the present ones in PCM and the absent ones
    sb_obj = amxd_dm_findf(get_dm(), CTHULHU_DM_SANDBOX_INSTANCES);
    amxd_object_for_each(instance, it, sb_obj) {
        amxd_object_t* instance = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxd_object_free(&instance);
    }

    amxc_var_for_each(it, sandboxes) {
        amxc_var_t* sb_inst = NULL;
        amxc_var_t* inst = NULL;
        const amxc_var_t* sandbox_var = amxc_var_get_first(it);

        bool private = GET_BOOL(sandbox_var, CTHULHU_SANDBOX_CREATEDBYCONTAINER);
        if(private) {
            continue;
        }

        amxc_var_new(&sb_inst);
        amxc_var_set_type(sb_inst, AMXC_VAR_ID_HTABLE);

        // Assemble the necessary arguments to create sandbox from scratch
        cthulhu_sb_restore_fill(sb_inst, sandbox_var);
        amxc_var_add_key(bool, sb_inst, CTHULHU_SB_RESTORE_FLAG, true);

        inst = amxc_var_add(amxc_llist_t, config->sb_create, NULL);
        amxc_var_move(inst, sb_inst);

        amxc_var_delete(&sb_inst);
    }


    ctrs = GETP_ARG(pcm_data, "set.hgwconfig." CTHULHU_DM_CONTAINER_INSTANCES);
    ASSERT_NOT_NULL(ctrs, goto exit, "Failed to get containers data model from imported configuration");

    amxc_var_for_each(it, ctrs) {
        amxc_var_t* ctr_inst = NULL;
        amxc_var_t* inst = NULL;

        const amxc_var_t* ctr_var = amxc_var_get_first(it);

        amxc_var_new(&ctr_inst);
        amxc_var_set_type(ctr_inst, AMXC_VAR_ID_HTABLE);

        // Assemble the necessary arguments to create container from scratch
        cthulhu_ctr_restore_fill(ctr_inst, ctr_var, sandboxes);
        amxc_var_add_key(bool, ctr_inst, CTHULHU_CTR_RESTORE_FLAG, true);

        inst = amxc_var_add(amxc_llist_t, config->ctr_create, NULL);
        amxc_var_move(inst, ctr_inst);

        amxc_var_delete(&ctr_inst);
    }

    SAH_TRACEZ_INFO(ME, "Upgrade-persistent configuration is imported");

    status = 0;
exit:
    return status;
}

/**
 * @brief Initializes the Cthulhu Pcm plugin.
 *
 * Retrieve and save the datamodel pointer for potential future use
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for initialization.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_pcm_init(UNUSED const char* function_name,
                     amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    int rc = -1;
    cthulhu_prestartup_config_t* config = NULL;

    dm = (amxd_dm_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_DATAMODEL);
    config = (cthulhu_prestartup_config_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_PRESTART_CONFIG);
    set_prestartup_config(config);
    cthulhu_plugin_exec = (cthulhu_plugin_exec_fn) GET_DATA(args, CTHULHU_PLUGIN_ARG_PLUGIN_EXEC_FN);

    ASSERT_NOT_NULL(dm, goto exit);
    ASSERT_NOT_NULL(get_prestartup_config(), goto exit);

    ASSERT_SUCCESS(register_pcm_functions(custom_pcm_export, custom_pcm_import), goto exit);

    rc = 0;
exit:
    return rc;
}

static int register_function(const char* const func_name, amxm_callback_t cb) {
    ASSERT_SUCCESS(amxm_module_add_function(mod, func_name, cb), return -1, "Could not add function [%s]", func_name);
    return 0;
}

AMXM_CONSTRUCTOR module_init(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu pcm constructor");
    int ret = 1;

    so = amxm_so_get_current();
    ASSERT_NOT_NULL(so, goto exit, "Could not get shared object");
    ASSERT_SUCCESS(amxm_module_register(&mod, so, CTHULHU_PLUGIN), goto exit, "Could not register module %s", CTHULHU_PLUGIN);

    /* Init hook */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_INIT, cthulhu_pcm_init), goto exit);

    ret = 0;
exit:
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu pcm constructor");
    return ret;
}

AMXM_DESTRUCTOR module_exit(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu pcm destructor");
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu pcm destructor");
    return 0;
}
