/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <ctype.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_ipd_iplcap.h"
#include "mod_ipd_iplcap_common.h"
#include "mod_ipd_iplcap_status.h"
#include "mod_ipd_common.h"
#include "ip_diagnostics_priv.h"
#include "ip_diagnostics.h"
#include "iplcap.h"

// module trace zone
#define ME "mod-iplcap-start"
/**
 * @brief Free an amxc_array_it_t.
 *
 * @details Frees the data pointer stored in the amxc_array_it_t.
 *
 * @param[in] it Pointer to the amxc_array_it_t to free.
 */
static void iplcap_script_array_it_free(amxc_array_it_t* it) {
    free(it->data);
}

/**
 * @brief Retrieve object data from the bus given a full object path.
 *
 * @details Resolves the responsible backend context and performs a GET
 *          on the provided object path, storing the result in the
 *          supplied variant.
 *
 * @param[in]  object_path Fully-qualified object path to query.
 * @param[out] data        Variant receiving the returned key/values.
 *
 * @return 0 on success, -1 on failure.
 */
static int get_object_data(const char* object_path, amxc_var_t* data) {
    amxb_bus_ctx_t* ctx = NULL;
    int ret = -1;

    when_str_empty_trace(object_path, exit, ERROR, "Object name is not provided");
    when_null_trace(data, exit, ERROR, "Data has not initialized");

    ctx = amxb_be_who_has(object_path);
    when_null_trace(ctx, exit, ERROR, "Could not find the context of the %s", object_path);

    ret = amxb_get(ctx, object_path, 0, data, 1);
    when_failed_trace(ret, exit, ERROR, "Failed to get data from %s", object_path);

exit:
    return ret;

}

/**
 * @brief Extract the numeric suffix from an AuthenticationAlias.
 *
 * @details Validates that the alias matches the expected
 *          "cpe-IPLayerCapacityAuthCode-<N>" format and returns a
 *          pointer to the numeric substring.
 *
 * @param[in] alias Authentication alias string to parse.
 *
 * @return Pointer to the numeric substring on success, NULL on error.
 */
static const char* extract_numeric_part(const char* alias) {
    // Check if alias follows the format "cpe-IPLayerCapacityAuthCode-1"
    if(strncmp(alias, CPE_PREFIX, strlen(CPE_PREFIX)) != 0) {
        SAH_TRACEZ_ERROR(ME, "Invalid alias format: %s. Must follow format 'cpe-IPLayerCapacityAuthCode-X'", alias);
        return NULL;
    }

    // Extract the numeric part after the last hyphen
    const char* numeric_part = alias + strlen(CPE_PREFIX);

    // Validate that the remaining part is not empty and is numeric
    if(*numeric_part == '\0') {
        SAH_TRACEZ_ERROR(ME, "Invalid alias format: %s. Numeric part cannot be empty", alias);
        return NULL;
    }

    for(const char* p = numeric_part; *p != '\0'; p++) {
        if(!isdigit(*p)) {
            SAH_TRACEZ_ERROR(ME, "Invalid alias format: %s. Numeric part must contain only digits", alias);
            return NULL;
        }
    }

    return numeric_part;
}

int iplcap_create_command(amxc_var_t* params, amxc_string_t* cmd) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    uint32_t param_int = 0;
    amxc_string_t param_string;
    amxc_var_t* command = NULL;
    amxc_llist_t list;
    char auth_code_key_str[100];

    const char* interface_name = NULL;
    amxc_var_t interface_data;
    char interface_name_path[256];
    amxc_var_init(&interface_data);

    amxc_string_init(&param_string, 0);
    amxc_llist_init(&list);

    when_null_trace(params, exit, ERROR, "Input parameter is NULL.");
    when_null_trace(cmd, exit, ERROR, "Command string is not initialised.");

    amxc_string_clean(cmd);
    amxc_string_init(cmd, 0);

    // Add base command
    amxc_string_setf(&param_string, "udpst");
    amxc_string_appendf(cmd, "udpst ");

    // -u|-d        Test Upstream OR Downstream as client
    amxc_string_setf(&param_string, "%s", GET_CHAR(params, IPLCAP_RET_KEY_ROLE));
    when_str_empty_trace(amxc_string_get(&param_string, 0), exit, ERROR, "No test type specified");
    if(strcmp(amxc_string_get(&param_string, 0), "Sender") == 0) {
        amxc_string_setf(&param_string, "-u");
        amxc_string_appendf(cmd, "-u ");
    } else if(strcmp(amxc_string_get(&param_string, 0), "Receiver") == 0) {
        amxc_string_setf(&param_string, "-d");
        amxc_string_appendf(cmd, "-d ");
    } else {
        SAH_TRACEZ_ERROR(ME, "No valid test type has been specified");
        goto exit;
    }

    // Protocol version
    amxc_string_setf(&param_string, "%s", GET_CHAR(params, IPLCAP_RET_KEY_PRTCLV));
    when_str_empty_trace(amxc_string_get(&param_string, 0), exit, ERROR, "Invalid protocol version");
    if(strcmp(amxc_string_get(&param_string, 0), "IPv4") == 0) {
        amxc_string_setf(&param_string, "-4");
        amxc_string_appendf(cmd, "-4 ");
    } else if(strcmp(amxc_string_get(&param_string, 0), "IPv6") == 0) {
        amxc_string_setf(&param_string, "-6");
        amxc_string_appendf(cmd, "-6 ");
    }

    // Flow count
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_FLOW_COUNT);
    if(param_int > 0) {
        amxc_string_setf(&param_string, "-C");
        amxc_string_appendf(cmd, "-C ");

        param_int = GET_UINT32(params, IPLCAP_RET_KEY_MAX_FLOWS);
        if(param_int > 0) {
            amxc_string_setf(&param_string, "%u-%u", GET_UINT32(params, IPLCAP_RET_KEY_FLOW_COUNT), param_int);
            amxc_string_appendf(cmd, "%u-%u ", GET_UINT32(params, IPLCAP_RET_KEY_FLOW_COUNT), param_int);
        } else {
            amxc_string_setf(&param_string, "%u", GET_UINT32(params, IPLCAP_RET_KEY_FLOW_COUNT));
            amxc_string_appendf(cmd, "%u ", GET_UINT32(params, IPLCAP_RET_KEY_FLOW_COUNT));
        }
    }

    // -f Add JSON output format
    amxc_string_setf(&param_string, "-f");
    amxc_string_appendf(cmd, "-f ");
    amxc_string_setf(&param_string, "json");
    amxc_string_appendf(cmd, "json ");

    // -j Jumbo frames
    if(!GET_BOOL(params, IPLCAP_RET_KEY_JUMBO_FRAMES)) {
        amxc_string_setf(&param_string, "-j");
        amxc_string_appendf(cmd, "-j ");
    }

    // -T Traditional MTU 1500
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_MTU);
    if(param_int == IPLCAP_DEFAULT_MTU) {
        amxc_string_setf(&param_string, "-T");
        amxc_string_appendf(cmd, "-T ");
    }

    // -X randomize
    if(!str_empty(GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT))) {
        if(strcmp(GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT), "zeroes") == 0) {
            SAH_TRACEZ_WARNING(ME, "zeroes is supported as default");
        } else if(strcmp(GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT), "ones") == 0) {
            SAH_TRACEZ_WARNING(ME, "ones is not supported yet");
        } else if(strcmp(GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT), "alternates0and1") == 0) {
            SAH_TRACEZ_WARNING(ME, "alternates0and1 is not supported yet");
        } else if(strcmp(GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT), "random") == 0) {
            amxc_string_setf(&param_string, "-X");
            amxc_string_appendf(cmd, "-X ");
        } else {
            SAH_TRACEZ_ERROR(ME, "Invalid UDP payload content: %s", GET_CHAR(params, IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT));
            goto exit;
        }
    }

    // -B Max bandwidth (mbps)
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_MAX_BANDWIDTH);
    if((param_int > IPLCAP_MIN_MAX_BANDWIDTH) && (param_int <= IPLCAP_MAX_MAX_BANDWIDTH)) {
        amxc_string_setf(&param_string, "-B");
        amxc_string_appendf(cmd, "-B ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -i Number of first mode test sub-intervals
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_NUM_FIRST_MODE);
    if((param_int >= 1) && (param_int <= IPLCAP_MAX_NUM_FIRST_MODE)) {
        amxc_string_setf(&param_string, "-i");
        amxc_string_appendf(cmd, "-i ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -o One-way delay option
    if(GET_BOOL(params, IPLCAP_RET_KEY_IPDV_ENABLE)) {
        amxc_string_setf(&param_string, "-o");
        amxc_string_appendf(cmd, "-o ");
    }

    // -R Out-of-order/duplicate option
    if(!GET_BOOL(params, IPLCAP_RET_KEY_REORD_DUP_IGNORE)) {
        amxc_string_setf(&param_string, "-R");
        amxc_string_appendf(cmd, "-R ");
    }

    // -a, -y, -K Authentication
    if(GET_BOOL(params, IPLCAP_RET_KEY_AUTH_ENABLED)) {
        const char* auth_code = GET_CHAR(params, IPLCAP_RET_KEY_AUTH_CODE);
        const char* auth_alias = GET_CHAR(params, IPLCAP_RET_KEY_AUTH_ALIAS);
        const char* auth_key_file = GET_CHAR(params, IPLCAP_RET_KEY_AUTH_KEY_FILE);

        // Check if at least one authentication parameter is provided
        if(str_empty(auth_code) && str_empty(auth_alias) && str_empty(auth_key_file)) {
            SAH_TRACEZ_ERROR(ME, "Authentication enabled but no authentication parameters provided");
            goto exit;
        }

        // Case 1: Only AuthenticationCode is provided
        if(!str_empty(auth_code) && str_empty(auth_alias) && str_empty(auth_key_file)) {
            amxc_string_setf(&param_string, "-a");
            amxc_string_appendf(cmd, "-a ");

            amxc_string_setf(&param_string, "%s", auth_code);
            amxc_string_appendf(cmd, "%s ", auth_code);
        }
        // Case 2: Both AuthenticationCode and AuthenticationAlias are provided
        else if(!str_empty(auth_code) && !str_empty(auth_alias) && str_empty(auth_key_file)) {
            amxc_string_setf(&param_string, "-a");
            amxc_string_appendf(cmd, "-a ");

            amxc_string_setf(&param_string, "%s", auth_code);
            amxc_string_appendf(cmd, "%s ", auth_code);

            // Extract numeric part from alias (must follow format "cpe-IPLayerCapacityAuthCode-1")
            const char* numeric_part = extract_numeric_part(auth_alias);
            when_null_trace(numeric_part, exit, ERROR, "Invalid alias format: %s. Must follow format 'cpe-IPLayerCapacityAuthCode-X'", auth_alias);

            amxc_string_setf(&param_string, "-y");
            amxc_string_appendf(cmd, "-y ");

            amxc_string_setf(&param_string, "%s", numeric_part);
            amxc_string_appendf(cmd, "%s ", numeric_part);
        } else if(str_empty(auth_code) && !str_empty(auth_alias) && str_empty(auth_key_file)) {
            // Case 3: Only AuthenticationAlias is provided
            // Validate alias format
            const char* numeric_part = extract_numeric_part(auth_alias);
            when_null_trace(numeric_part, exit, ERROR, "Invalid alias format: %s. Must follow format 'cpe-IPLayerCapacityAuthCode-X'", auth_alias);

            // Get the authentication key from the IPLayerCapacityAuthCode table
            snprintf(auth_code_key_str, sizeof(auth_code_key_str), "IPLayerCapacityAuthCode.%s.AuthenticationKey", numeric_part);
            const char* auth_code_key = GETP_CHAR(params, auth_code_key_str);
            when_str_empty_trace(auth_code_key, exit, ERROR, "Authentication key not found for alias: %s", auth_alias);

            // Use the authentication key from the table
            amxc_string_setf(&param_string, "-a");
            amxc_string_appendf(cmd, "-a ");

            amxc_string_setf(&param_string, "%s", auth_code_key);
            amxc_string_appendf(cmd, "%s ", auth_code_key);

            amxc_string_setf(&param_string, "-y");
            amxc_string_appendf(cmd, "-y ");

            amxc_string_setf(&param_string, "%s", numeric_part);
            amxc_string_appendf(cmd, "%s ", numeric_part);
        }
        // Case 4: Both AuthenticationAlias and AuthenticationKeyFileLocation are provided
        else if(str_empty(auth_code) && !str_empty(auth_alias) && !str_empty(auth_key_file)) {
            // Validate alias format
            const char* numeric_part = extract_numeric_part(auth_alias);
            when_null_trace(numeric_part, exit, ERROR, "Invalid alias format: %s. Must follow format 'cpe-IPLayerCapacityAuthCode-X'", auth_alias);

            amxc_string_setf(&param_string, "-y");
            amxc_string_appendf(cmd, "-y ");

            amxc_string_setf(&param_string, "%s", numeric_part);
            amxc_string_appendf(cmd, "%s ", numeric_part);

            amxc_string_setf(&param_string, "-K");
            amxc_string_appendf(cmd, "-K ");

            amxc_string_setf(&param_string, "%s", auth_key_file);
            amxc_string_appendf(cmd, "%s ", auth_key_file);
        }
        // Case 5: Only AuthenticationKeyFileLocation is provided
        else if(str_empty(auth_code) && str_empty(auth_alias) && !str_empty(auth_key_file)) {
            amxc_string_setf(&param_string, "-K");
            amxc_string_appendf(cmd, "-K ");

            amxc_string_setf(&param_string, "%s", auth_key_file);
            amxc_string_appendf(cmd, "%s ", auth_key_file);
        }
        // Case 6: All three parameters are provided
        else if(!str_empty(auth_code) && !str_empty(auth_alias) && !str_empty(auth_key_file)) {
            // Validate alias format
            const char* numeric_part = extract_numeric_part(auth_alias);
            when_null_trace(numeric_part, exit, ERROR, "Invalid alias format: %s. Must follow format 'cpe-IPLayerCapacityAuthCode-X'", auth_alias);

            // When all three are provided, use AuthenticationCode and AuthenticationAlias
            amxc_string_setf(&param_string, "-a");
            amxc_string_appendf(cmd, "-a ");

            amxc_string_setf(&param_string, "%s", auth_code);
            amxc_string_appendf(cmd, "%s ", auth_code);

            amxc_string_setf(&param_string, "-y");
            amxc_string_appendf(cmd, "-y ");

            amxc_string_setf(&param_string, "%s", numeric_part);
            amxc_string_appendf(cmd, "%s ", numeric_part);
        } else {
            SAH_TRACEZ_ERROR(ME, "Invalid combination of authentication parameters");
            goto exit;
        }
    }

    // -m DSCP, value can be 0
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_DSCP);
    if(param_int <= IPLCAP_MAX_DSCP) {
        amxc_string_setf(&param_string, "-m");
        amxc_string_appendf(cmd, "-m ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -I [@]index  Index of sending rate (see '-S') [Default @0 = <Auto>]
    // StartSendingRateIndex overrides StartSendingRate
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_START_RATE_INDEX);
    if(param_int <= IPLCAP_MAX_START_RATE_INDEX) {
        amxc_string_setf(&param_string, "-I");
        amxc_string_appendf(cmd, "-I ");

        amxc_string_setf(&param_string, "@%u", param_int);
        amxc_string_appendf(cmd, "@%u ", param_int);
    }

    // -t Test interval
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_SUB_INTERVAL) * GET_UINT32(params, IPLCAP_RET_KEY_NUM_SUB_INTERVALS) / 1000;
    if(param_int > 0) {
        amxc_string_setf(&param_string, "-t");
        amxc_string_appendf(cmd, "-t ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -P period    Sub-interval period in seconds [Default 1]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_SUB_INTERVAL);
    if((param_int >= IPLCAP_MIN_SUB_INTERVAL) && (param_int <= IPLCAP_MAX_SUB_INTERVAL)) {
        amxc_string_setf(&param_string, "-P");
        amxc_string_appendf(cmd, "-P ");

        amxc_string_setf(&param_string, "%u", param_int / 1000);
        amxc_string_appendf(cmd, "%u ", param_int / 1000);
    }

    // -A algo      Rate adjustment algorithm (B - C) [Default B]
    if(!str_empty(GET_CHAR(params, IPLCAP_RET_KEY_RATE_ADJ_ALGO))) {
        amxc_string_setf(&param_string, "-A");
        amxc_string_appendf(cmd, "-A ");

        amxc_string_setf(&param_string, "%s", GET_CHAR(params, IPLCAP_RET_KEY_RATE_ADJ_ALGO));
        amxc_string_appendf(cmd, "%s ", GET_CHAR(params, IPLCAP_RET_KEY_RATE_ADJ_ALGO));
    }

    //  -L delvar    Low delay variation threshold in ms [Default 30]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_LOWER_THRESH);
    if((param_int >= IPLCAP_MIN_LOWER_THRESH) &&
       (param_int <= IPLCAP_MAX_LOWER_THRESH) &&
       (param_int < GET_UINT32(params, IPLCAP_RET_KEY_UPPER_THRESH))) {
        amxc_string_setf(&param_string, "-L");
        amxc_string_appendf(cmd, "-L ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    //  -U delvar    High delay variation threshold in ms [Default 100]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_UPPER_THRESH);
    if((param_int >= IPLCAP_MIN_UPPER_THRESH) &&
       (param_int <= IPLCAP_MAX_UPPER_THRESH) &&
       (param_int > GET_UINT32(params, IPLCAP_RET_KEY_LOWER_THRESH))) {
        amxc_string_setf(&param_string, "-U");
        amxc_string_appendf(cmd, "-U ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    //  -F interval  Status feedback/trial interval in ms [Default 50]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_FEEDBACK_INTERVAL);
    if((param_int >= IPLCAP_MIN_FEEDBACK_INTERVAL) && (param_int <= IPLCAP_MAX_FEEDBACK_INTERVAL)) {
        amxc_string_setf(&param_string, "-F");
        amxc_string_appendf(cmd, "-F ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    //  -c thresh    Congestion slow adjustment threshold [Default 3]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_SLOW_ADJ_THRESH);
    if(param_int >= IPLCAP_MIN_SLOW_ADJ_THRESH) {
        amxc_string_setf(&param_string, "-c");
        amxc_string_appendf(cmd, "-c ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    //  -h delta     High-speed (row adjustment) delta [Default 10]
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_HIGH_SPEED_DELTA);
    if(param_int >= IPLCAP_MIN_HIGH_SPEED_DELTA) {
        amxc_string_setf(&param_string, "-h");
        amxc_string_appendf(cmd, "-h ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -q seqerr    Sequence error threshold [Default 10], value can be 0
    param_int = GET_UINT32(params, IPLCAP_RET_KEY_SEQ_ERR_THRESH);
    if(param_int <= IPLCAP_MAX_SEQ_ERR_THRESH) {
        amxc_string_setf(&param_string, "-q");
        amxc_string_appendf(cmd, "-q ");

        amxc_string_setf(&param_string, "%u", param_int);
        amxc_string_appendf(cmd, "%u ", param_int);
    }

    // -E intf      Show local interface traffic rate (ex. eth0)
    // Handle Interface parameter: Path Name of a table row (e.g., Device.IP.Interface.1)
    const char* interface_path = GET_CHAR(params, IPLCAP_RET_KEY_INTF);
    if(!str_empty(interface_path)) {
        // Create the path to the Name parameter: {Interface}.Name
        snprintf(interface_name_path, sizeof(interface_name_path), "%s.Name", interface_path);

        // Get interface name
        when_failed_trace(get_object_data(interface_name_path, &interface_data), exit, ERROR, "Failed to get interface name for path: %s", interface_name_path);
        interface_name = GETP_CHAR(&interface_data, "0.0.Name");
        when_str_empty_trace(interface_name, exit, ERROR, "Failed to get interface name for path: %s", interface_name_path);
    }

    // Add -E parameter if we have a valid interface name
    if(!str_empty(interface_name)) {
        amxc_string_setf(&param_string, "-E");
        amxc_string_appendf(cmd, "-E ");

        amxc_string_setf(&param_string, "%s", interface_name);
        amxc_string_appendf(cmd, "%s ", interface_name);

        //  -M           Use local interface rate to determine maximum
        // Only valid when Interface is set successfully
        if(GET_BOOL(params, IPLCAP_RET_KEY_LOCAL_RATE)) {
            amxc_string_setf(&param_string, "-M");
            amxc_string_appendf(cmd, "-M ");
        }
    }

    // Server list and port
    amxc_string_setf(&param_string, "%s", GET_CHAR(params, IPLCAP_RET_KEY_SERVER_LIST));
    when_str_empty_trace(amxc_string_get(&param_string, 0), exit, ERROR, "No server list specified");

    // Set, split, and loop through servers
    amxc_string_split_to_llist(&param_string, &list, ',');
    amxc_llist_for_each(it, &list) {
        amxc_string_setf(&param_string, "%s", amxc_string_get(amxc_string_from_llist_it(it), 0));
        amxc_string_appendf(cmd, "%s", amxc_string_get(amxc_string_from_llist_it(it), 0));
        amxc_llist_it_t* next_it = amxc_llist_it_get_next(it);
        if(next_it != NULL) {
            const char* next_str = amxc_string_get(amxc_string_from_llist_it(next_it), 0);
            // handle case ipv6 address with port
            if((next_str == NULL) || (next_str[0] != ':')) {
                amxc_string_appendf(cmd, " ");
            }
        }
    }

    command = amxc_var_get_key(params, IPLCAP_RET_KEY_CMD, AMXC_VAR_FLAG_DEFAULT);
    amxc_var_set(cstring_t, command, amxc_string_get(cmd, 0));
    rv = amxd_status_ok;

exit:
    amxc_var_clean(&interface_data);
    amxc_string_clean(&param_string);
    amxc_llist_clean(&list, amxc_string_list_it_free);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

int mod_iplcap_test_start(UNUSED const char* function_name,
                          amxc_var_t* params,
                          amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    iplcap_test_status_t status = 0;
    amxc_var_t* proc_htable = NULL;
    amxc_var_t* pid_var = NULL;
    amxc_var_t* fd_stdout_var = NULL;
    amxc_var_t* fd_stderr_var = NULL;
    amxp_subproc_t* proc_iplcap = NULL;
    int rv = -1;
    int32_t pid = -1;
    int32_t fd_stdout = -1;
    int32_t fd_stderr = -1;
    amxc_array_t sh_script;
    amxc_string_t cmd;
    amxc_var_t* var = NULL;

    amxc_string_init(&cmd, 0);
    amxc_var_new(&var);
    amxc_array_init(&sh_script, 1);

    rv = iplcap_create_command(params, &cmd);
    when_failed_trace(rv, exit, ERROR, "Could not create the command, missing parameters");

    amxc_var_move(ret, params);

    rv = iplcap_create_sh_script(ret, &cmd, &sh_script);
    when_failed_trace(rv, exit, ERROR, "Failed to create the shell script.");

    rv = amxp_subproc_new(&proc_iplcap);
    when_failed_trace(rv, exit, ERROR, "Failed to initialize the subprocess.");

    fd_stdout = amxp_subproc_open_fd(proc_iplcap, STDOUT_FILENO);
    fd_stderr = amxp_subproc_open_fd(proc_iplcap, STDERR_FILENO);
    if((fd_stdout == -1) || (fd_stderr == -1)) {
        SAH_TRACEZ_ERROR(ME, "Failed to open file descriptor. stdout: %d, stderr: %d", fd_stdout, fd_stderr);
        goto exit;
    }

    // proc_htable
    proc_htable = amxc_var_get_key(ret, IPLCAP_RET_KEY_PROC, AMXC_VAR_FLAG_DEFAULT);
    if(proc_htable == NULL) {
        proc_htable = amxc_var_add_key(amxc_htable_t, ret, IPLCAP_RET_KEY_PROC, NULL);
    }

    // fd_stdout_var
    fd_stdout_var = amxc_var_get_key(proc_htable, IPLCAP_RET_KEY_PROC_FD_STDOUT, AMXC_VAR_FLAG_DEFAULT);
    if(fd_stdout_var == NULL) {
        fd_stdout_var = amxc_var_add_key(int32_t, proc_htable, IPLCAP_RET_KEY_PROC_FD_STDOUT, 0);
    }
    amxc_var_set(int32_t, fd_stdout_var, fd_stdout);

    // fd_stderr_var
    fd_stderr_var = amxc_var_get_key(proc_htable, IPLCAP_RET_KEY_PROC_FD_STDERR, AMXC_VAR_FLAG_DEFAULT);
    if(fd_stderr_var == NULL) {
        fd_stderr_var = amxc_var_add_key(int32_t, proc_htable, IPLCAP_RET_KEY_PROC_FD_STDERR, 0);
    }
    amxc_var_set(int32_t, fd_stderr_var, fd_stderr);

#ifndef IP_DIAGNOSTICS_UNIT_TEST
    rv = amxp_subproc_astart(proc_iplcap, &sh_script);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start iplcap process with error: %d", rv);
        amxp_subproc_delete(&proc_iplcap);
        goto exit;
    }
#else
    amxp_subproc_delete(&proc_iplcap);
#endif

    pid = amxp_subproc_get_pid(proc_iplcap);

    // pid_var
    pid_var = amxc_var_get_key(proc_htable, IPLCAP_RET_KEY_PROC_PID, AMXC_VAR_FLAG_DEFAULT);
    if(pid_var == NULL) {
        pid_var = amxc_var_add_key(int32_t, proc_htable, IPLCAP_RET_KEY_PROC_PID, 0);
    }
    amxc_var_set(int32_t, pid_var, pid);

    status = iplcap_test_not_complete;

exit:
    amxc_array_clean(&sh_script, iplcap_script_array_it_free);
    amxc_string_clean(&cmd);

    if(status == iplcap_test_not_complete) {
        amxc_var_set(cstring_t, var, (cstring_t) str_iplcap_test_status[status]);
        amxc_var_set_pathf(ret, var, DEFAULT_SET_PATH_FLAGS, IPLCAP_RET_KEY_DST);
    }

    amxc_var_delete(&var);
    SAH_TRACEZ_OUT(ME);
    return status == iplcap_test_not_complete ? 0:1;
}
