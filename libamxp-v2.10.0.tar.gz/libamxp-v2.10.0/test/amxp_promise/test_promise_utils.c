/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_promise.h"

void read_sigalrm(void) {
    sigset_t mask;
    int sfd;
    struct signalfd_siginfo fdsi;
    ssize_t s;

    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);

    sigprocmask(SIG_BLOCK, &mask, NULL);

    sfd = signalfd(-1, &mask, 0);
    s = read(sfd, &fdsi, sizeof(struct signalfd_siginfo));
    assert_int_equal(s, sizeof(struct signalfd_siginfo));
    if(fdsi.ssi_signo == SIGALRM) {
        printf("Got SIGALRM\n");
    } else {
        printf("Read unexpected signal\n");
    }

    amxp_timers_calculate();
    amxp_timers_check();
}

void settle_callback_rejects(amxp_promise_t* promise, UNUSED void* const consumer_priv) {
    // misbehaving settle callback that rejects the promise
    uint32_t status = amxp_promise_get_status(promise);
    amxp_promise_state_t state = promise->state;
    function_called();
    check_expected_ptr(promise);
    check_expected(status);
    check_expected(state);
    // the reject must fail and returns the state of the promise
    assert_int_equal(amxp_promise_reject(promise, 666), AMXP_PROMISE_STATUS_FULFILLED);
}

void settle_callback_fulfills(amxp_promise_t* promise, UNUSED void* const consumer_priv) {
    // misbehaving settle (reject or fulfill) callback that rejects the promise
    uint32_t status = amxp_promise_get_status(promise);
    amxp_promise_state_t state = promise->state;
    function_called();
    check_expected_ptr(promise);
    check_expected(status);
    check_expected(state);
    // the reject must fail and returns the state of the promise
    assert_int_equal(amxp_promise_fulfill(promise, NULL), AMXP_PROMISE_STATUS_REJECTED);
}

void settle_callback_deletes(amxp_promise_t* promise, UNUSED void* const consumer_priv) {
    // misbehaving settle callback that rejects the promise
    uint32_t status = amxp_promise_get_status(promise);
    amxp_promise_state_t state = promise->state;
    function_called();
    check_expected_ptr(promise);
    check_expected(status);
    check_expected(state);
    // it is allowed to delete the promise in a settle callback (reject or fulfill)
    amxp_promise_delete(&promise);
}

void rejected_callback(amxp_promise_t* promise, UNUSED void* const consumer_priv) {
    uint32_t status = amxp_promise_get_status(promise);
    function_called();
    check_expected_ptr(promise);
    check_expected(status);
}

void fulfilled_callback(amxp_promise_t* promise, UNUSED void* const consumer_priv) {
    uint32_t status = amxp_promise_get_status(promise);
    function_called();
    check_expected_ptr(promise);
    check_expected(status);
}

void cancel_callback(amxp_promise_t* promise, void* const provider_priv) {
    uint32_t status = amxp_promise_get_status(promise);
    assert_true(amxp_promise_is_rejected(promise));
    function_called();
    check_expected(status);
    check_expected_ptr(promise);
    check_expected_ptr(provider_priv);
}

void cancel_callback_no_check(amxp_promise_t* promise, UNUSED void* const provider_priv) {
    uint32_t status = amxp_promise_get_status(promise);
    assert_true(amxp_promise_is_rejected(promise));
    function_called();
    check_expected(status);
}

void cancel_callback_fulfills(amxp_promise_t* promise, UNUSED void* const provider_priv) {
    function_called();
    assert_int_equal(amxp_promise_fulfill(promise, NULL), AMXP_PROMISE_STATUS_REJECTED);
}

void cancel_callback_deletes(amxp_promise_t* promise, UNUSED void* const provider_priv) {
    function_called();
    amxp_promise_delete(&promise);
}

int wait_fulfill(amxp_promise_t* promise, UNUSED uint32_t timeout, UNUSED void* const provider_priv) {
    assert_int_equal(amxp_promise_fulfill(promise, NULL), AMXP_PROMISE_STATUS_OK);
    printf("=> function called -> wait_fulfill\n");
    function_called();
    printf("=> check expected provider_prv\n");
    check_expected_ptr(provider_priv);
    fflush(stdout);
    return 0;
}

int wait_reject(amxp_promise_t* promise, UNUSED uint32_t timeout, UNUSED void* const provider_priv) {
    assert_int_equal(amxp_promise_reject(promise, 11), AMXP_PROMISE_STATUS_OK);
    check_expected_ptr(provider_priv);
    function_called();
    return 0;
}

int wait_fail(UNUSED amxp_promise_t* promise, UNUSED uint32_t timeout, UNUSED void* const provider_priv) {
    // a correctly behaving wait function should settle the promise when the "wait" is done
    // it is acceptable that when the wait fails, the promise stays in pending state.
    // the promise implementation will reject the promise with the return value provided.
    check_expected_ptr(provider_priv);
    function_called();
    return 1001;
}

int wait_success_not_resolving(UNUSED amxp_promise_t* promise, UNUSED uint32_t timeout, void* const provider_priv) {
    // a correctly behaving wait function should settle the promise when the "wait" is done
    // when the return value is 0 of the wait function, and the promise is not settled
    // the promise implementation will fulfill it (with no data).
    check_expected_ptr(provider_priv);
    function_called();
    return 0;
}