/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "conmon_utils.h"
#include "conmon_queries.h"
#include "conmon_soc_utils.h"

void create_netdev_subscription(conmon_info_t* entry, const char* notification, amxb_subscription_t** netdev_subscription, netdev_callback_t cb) {
    SAH_TRACEZ_IN(ME);

    amxc_string_t expr;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("NetDev.Link.");

    amxc_string_init(&expr, 0);

    when_str_empty_trace(entry->interface_name, exit, ERROR, "conmon name is empty: no netdev interface name given");
    when_null_trace(ctx, exit, WARNING, "ctx not known, no subscription created");

    amxc_string_setf(&expr, "notification == '%s' && path == 'NetDev.Link.' && parameters.Alias == '%s'", notification, entry->interface_name);
    amxb_subscription_new(netdev_subscription, ctx, "NetDev.Link.", amxc_string_get(&expr, 0), cb, entry);
    when_null_trace(*netdev_subscription, exit, WARNING, "failed to create subscription");

exit:
    amxc_string_clean(&expr);
    SAH_TRACEZ_OUT(ME);
}

void netdev_new_link_added_cb(UNUSED const char* const sig_name,
                              UNUSED const amxc_var_t* const data,
                              void* const priv) {
    SAH_TRACEZ_IN(ME);

    conmon_info_t* entry = (conmon_info_t*) priv;
    physicalisup_changed(true, entry);

    SAH_TRACEZ_OUT(ME);
}

void netdev_link_removed_cb(UNUSED const char* const sig_name,
                            UNUSED const amxc_var_t* const data,
                            void* const priv) {
    SAH_TRACEZ_IN(ME);

    conmon_info_t* entry = (conmon_info_t*) priv;
    physicalisup_changed(false, entry);

    SAH_TRACEZ_OUT(ME);
}

static void execute_update_config_string(const amxc_var_t* data, void* priv, const char* key) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t mod_data;
    conmon_info_t* entry = (conmon_info_t*) priv;
    const char* value = NULL;

    amxc_var_init(&mod_data);

    when_null(entry, exit);
    when_null(data, exit);

    value = amxc_var_constcast(cstring_t, data);
    SAH_TRACEZ_INFO(ME, "[%s] Received new %s value '%s'", entry->alias, key, value ? value :"");

    mod_conmon_build_basic_data_struct(entry, &mod_data, false);
    amxc_var_add_key(cstring_t, &mod_data, key, value ? value : "");
    mod_conmon_execute_function(MOD_CONMON_UPDATE_CONFIG_FUNCTION, &mod_data);

exit:
    amxc_var_clean(&mod_data);
    SAH_TRACEZ_OUT(ME);
}

static void execute_update_config_bool(bool data, void* priv, const char* key) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t mod_data;
    conmon_info_t* entry = (conmon_info_t*) priv;

    amxc_var_init(&mod_data);

    when_null(entry, exit);

    SAH_TRACEZ_INFO(ME, "[%s] Received new %s value '%s'", entry->alias, key, data ? "TRUE" : "FALSE");

    mod_conmon_build_basic_data_struct(entry, &mod_data, false);
    amxc_var_add_key(bool, &mod_data, key, data);
    mod_conmon_execute_function(MOD_CONMON_UPDATE_CONFIG_FUNCTION, &mod_data);

exit:
    amxc_var_clean(&mod_data);
    SAH_TRACEZ_OUT(ME);
}

void physicalisup_changed(bool up, conmon_info_t* entry) {
    SAH_TRACEZ_IN(ME);
    execute_update_config_bool(up, (void*) entry, "physup_changed");
    SAH_TRACEZ_OUT(ME);
}


void wanintf_changed(UNUSED const char* sig_name,
                     const amxc_var_t* data,
                     void* priv) {
    SAH_TRACEZ_IN(ME);

    conmon_info_t* entry = (conmon_info_t*) priv;
    const char* intf_name = NULL;
    const char* netdev_name = NULL;
    amxc_var_t* dev_name = NULL;
    amxc_var_t mod_data;
    amxc_var_init(&mod_data);

    when_null(data, exit);
    when_null(entry, exit);

    intf_name = amxc_var_constcast(cstring_t, data);
    when_null(intf_name, exit);
    SAH_TRACEZ_INFO(ME, "[%s] intf_name %s -> %s", entry->alias, entry->interface_name, intf_name);

    free(entry->interface_name);
    entry->interface_name = NULL;

    dev_name = netmodel_getFirstParameter(intf_name, "NetDevName", 0, netmodel_traverse_down);
    netdev_name = amxc_var_constcast(cstring_t, dev_name);

    if((netdev_name != NULL) && (intf_name[0] != '\0')) {
        entry->interface_name = strdup(netdev_name);
    } else {
        entry->interface_name = strdup(intf_name);
    }

    mod_conmon_build_basic_data_struct(entry, &mod_data, false);
    mod_conmon_execute_function(MOD_CONMON_UPDATE_CONFIG_FUNCTION, &mod_data);

exit:
    amxc_var_clean(&mod_data);
    amxc_var_delete(&dev_name);
    SAH_TRACEZ_OUT(ME);
}

void isup_changed(UNUSED const char* sig_name,
                  const amxc_var_t* data,
                  void* priv) {
    SAH_TRACEZ_IN(ME);
    when_null(data, exit);
    execute_update_config_bool(GET_BOOL(data, NULL), priv, "up_changed");
exit:
    SAH_TRACEZ_OUT(ME);
}

void wan_defaultroute_changed(UNUSED const char* sig_name,
                              const amxc_var_t* data,
                              void* priv) {
    SAH_TRACEZ_IN(ME);

    const amxc_llist_t* data_list;

    when_null(data, exit);

    data_list = amxc_var_constcast(amxc_llist_t, data);
    when_null(data_list, exit);

    when_false(amxc_llist_size(data_list) == 1, exit);
    execute_update_config_string(amxc_var_from_llist_it(amxc_llist_get_first(data_list)), priv, "wan_ip");

exit:
    SAH_TRACEZ_OUT(ME);
}

void wan6_defaultroute_changed(UNUSED const char* sig_name,
                               const amxc_var_t* data,
                               void* priv) {
    SAH_TRACEZ_IN(ME);
    execute_update_config_string(data, priv, "wan_ip");
    SAH_TRACEZ_OUT(ME);
}

void local_ip_changed(UNUSED const char* sig_name,
                      const amxc_var_t* data,
                      void* priv) {
    SAH_TRACEZ_IN(ME);
    execute_update_config_string(data, priv, "local_ip");
    SAH_TRACEZ_OUT(ME);
}

void ll_interface_path_changed(UNUSED const char* sig_name,
                               const amxc_var_t* data,
                               void* priv) {
    SAH_TRACEZ_IN(ME);
    execute_update_config_string(data, priv, "ll_interface_path");
    SAH_TRACEZ_OUT(ME);
}

void dhcp_changed(UNUSED const char* sig_name,
                  const amxc_var_t* data,
                  void* priv) {
    SAH_TRACEZ_IN(ME);
    conmon_info_t* entry = (conmon_info_t*) priv;
    bool dhcp_up = false;
    const char* new_status = NULL;

    when_null(data, exit);
    when_null(entry, exit);

    dhcp_up = GET_BOOL(data, NULL);

    new_status = conmon_get_status(entry, dhcp_up);
    conmon_set_status(entry, new_status);

    execute_update_config_bool(dhcp_up, priv, "dhcpup_changed");
exit:
    SAH_TRACEZ_OUT(ME);
}

void physdowntimeout_changed(UNUSED const char* sig_name,
                             const amxc_var_t* data,
                             void* priv) {
    SAH_TRACEZ_IN(ME);

    conmon_info_t* entry = (conmon_info_t*) priv;
    int32_t timeout = 0;

    when_null(data, exit);
    when_null(entry, exit);
    timeout = amxc_var_constcast(int32_t, data);

    SAH_TRACEZ_INFO(ME, "[%s] Received new Physical Down Timeout value %d for interface %s", entry->alias, timeout, entry->interface_name);

    if(timeout != 0) {
        if(entry->netdev_link_added_subscription == NULL) {
            create_netdev_subscription(entry, "dm:instance-added", &entry->netdev_link_added_subscription, netdev_new_link_added_cb);
        }
        if(entry->netdev_link_removed_subscription == NULL) {
            create_netdev_subscription(entry, "dm:instance-removed", &entry->netdev_link_removed_subscription, netdev_link_removed_cb);
        }
    } else {
        cleanup_netdev_queries(entry);
    }

exit:
    SAH_TRACEZ_OUT(ME);
}

static void cleanup_query(netmodel_query_t** query) {
    SAH_TRACEZ_IN(ME);

    if((query != NULL) && (*query != NULL)) {
        netmodel_closeQuery(*query);
        *query = NULL;
    }

    SAH_TRACEZ_OUT(ME);
}

void cleanup_nm_interface_queries(conmon_info_t* conmon) {
    SAH_TRACEZ_IN(ME);

    cleanup_query(&conmon->wan_intf);
    cleanup_query(&conmon->wan_isup);
    cleanup_query(&conmon->wan_defaultroute);
    cleanup_query(&conmon->wan_physdowntimeout);
    cleanup_query(&conmon->local_ip);
    cleanup_query(&conmon->ll_interface_path_changed);
    cleanup_query(&conmon->dhcp_isup);

    SAH_TRACEZ_OUT(ME);
}

void cleanup_netdev_queries(conmon_info_t* conmon) {
    SAH_TRACEZ_IN(ME);

    if(conmon->netdev_link_added_subscription != NULL) {
        amxb_subscription_delete(&(conmon->netdev_link_added_subscription));
    }
    if(conmon->netdev_link_removed_subscription != NULL) {
        amxb_subscription_delete(&(conmon->netdev_link_removed_subscription));
    }

    SAH_TRACEZ_OUT(ME);
}

void verify_open_query(netmodel_query_t* query, const char* description) {
    SAH_TRACEZ_IN(ME);

    if(query == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to add %s query to NetModel", description);
    }
    (void) description; // use variable when tracing is disabled

    SAH_TRACEZ_OUT(ME);
}
