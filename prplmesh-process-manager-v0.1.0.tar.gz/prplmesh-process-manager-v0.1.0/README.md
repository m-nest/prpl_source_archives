# prplmesh-process-manager
PrplMesh process manager allows to manage the state of the prplMesh components.
For each component it exposes subobject under own model:
* `X_PRPLWARE-COM_ProcessManager.`
  * `PWHM.` for pwhm
  * `Sensing.` for wifi-sensing
  * `PrplMesh.` for prplMesh

The PrplMesh additionally contains parameters to configure the management and certification mode.

For each service the following parameters control the state of the service:
* `Enable`: enable or disable the component
* `Status` status of the service can be one of:
  * `Idle`: this component is in an Idle state and not running
  * `Starting`: component is in the process of Starting and SHOULD transition to the Active state
  * `Active`: component is currently running
  * `Stopping`:  component is in the process of Stopping and SHOULD transition to the Idle state
* `FaultCode` error status, can be one of `NoFault, FailureOnStop, FailureOnStart`


The state of the prplMesh itself can be managed using `X_PRPLWARE-COM_ProcessManager.PrplMesh.` object , the following additional parameters are supported:
* `CertificationMode`: specifies whether or not certification mode is enabled. This is internal parameter for using only by prplMesh. It is exposed to ba-cli, and *not* frontends.
* `ManagementMode`: sets the management mode of prplMesh component. Can be one of:
  * Multi-AP-Controller-and-Agent
  * Multi-AP-Controller
  * Multi-AP-Agent
  * Not-Multi-AP (The management mode disables EasyMesh feature, prplMesh operates as IEEE 1905.1 transport bridge)
  * Non-Prpl-Controller-and-Agent (This mode is for local prplMesh Agent running with non-prplMesh Controller on the same device)

**Note:** Changing ManagementMode mod causes the prpl-mesh to restart.

The process manager is available under TR-069 and TR-369 interface using prplmesh-dm-mapper.

