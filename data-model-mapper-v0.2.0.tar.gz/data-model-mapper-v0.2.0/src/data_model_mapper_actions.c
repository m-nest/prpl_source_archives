/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "data_model_mapper.h"
#include <amxb/amxb_be_intf.h>

#define ME "data-model-mapper"

#define OUTPUT_MAX_DEPTH 4
#define ERROR_CODE_LEN_MAX 16

typedef struct _parse_output_data {
    amxd_object_t* output;
    const amxc_var_t* response_htable;
} parse_output_data_t;

static const char* prepare_error_msg(int error_code) {
    const char* error_message = amxd_status_string(error_code);

    if(error_message == NULL) {
        return "Unknown error";
    }
    return error_message;
}

static void set_error_code_and_msg(const char* error_code, const char* error_message, amxd_object_t* object) {
    amxd_object_set_value(cstring_t, object, "ErrorMessage", error_message);
    amxd_object_set_value(cstring_t, object, "ErrorCode", error_code);
}

static amxd_status_t set_trans_state(const char* cmd_status, amxd_object_t* object) {
    amxd_trans_t trans;
    amxd_status_t status_trans = amxd_trans_init(&trans);

    if(status_trans != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to create transaction, error code = %d", status_trans);
        goto out;
    }

    status_trans = amxd_trans_set_attr(&trans, amxd_tattr_change_pub, true);
    if(status_trans != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to set attrs, error code = %d", status_trans);
        goto error;
    }

    status_trans = amxd_trans_select_object(&trans, object);
    if(status_trans != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to select object for transaction, error code = %d", status_trans);
        goto error;
    }

    status_trans = amxd_trans_set_cstring_t(&trans, "State", cmd_status);
    if(status_trans != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to set transaction parameter 'State' to '%s', error code = %d", cmd_status, status_trans);
        goto error;
    }

    status_trans = amxd_trans_apply(&trans, amxd_object_get_dm(object));
    if(status_trans != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to apply transaction, error code = %d", status_trans);
        goto error;
    }
    amxd_trans_clean(&trans);
    return status_trans;
error:
    amxd_trans_clean(&trans);
out:
    //Set value without notification
    amxd_object_set_value(cstring_t, object, "State", cmd_status);
    return status_trans;
}

static void remove_all_instances(amxd_object_t* template_obj) {
    SAH_TRACEZ_INFO(ME, "Removing instances for '%s'.", template_obj->name);
    amxd_object_for_each(instance, it, template_obj) {
        amxd_object_t* inst = amxc_container_of(it, amxd_object_t, it);
        amxd_object_free(&inst);
    }
}

static void parse_output_object_singleton(amxd_object_t* obj, const char* obj_path, amxd_param_t* param,
                                          const amxc_var_t* response) {
    amxc_var_t* val = NULL;
    amxd_status_t status;
    SAH_TRACEZ_INFO(ME, "Searching the following path: '%s%s'", obj_path, param->name);

    val = amxc_var_get_pathf(response, AMXC_VAR_FLAG_DEFAULT, "%s%s", obj_path, param->name);

    if(val) {
        SAH_TRACEZ_INFO(ME, "Found value in response.");
        status = amxd_object_set_param(obj, param->name, val);
        if(status != amxd_status_ok) {
            SAH_TRACEZ_WARNING(ME, "Output parameter '%s%s' couldn't be set, error: %d", obj_path, param->name, status);
        }
    } else {
        SAH_TRACEZ_WARNING(ME, "Output parameter '%s%s' was not found in response.", obj_path, param->name);
    }
}

static void parse_output_object_template(amxd_object_t* obj, const char* obj_path, amxd_param_t* param,
                                         const amxc_var_t* response) {
    int index = 0;
    amxc_var_t* val = NULL, * table = NULL;
    amxd_status_t status;
    amxd_object_t* inst_obj = NULL;

    SAH_TRACEZ_INFO(ME, "Searching the following table path: '%s'", obj_path);
    table = amxc_var_get_pathf(response, AMXC_VAR_FLAG_DEFAULT, "%s", obj_path);

    if(table && (amxc_var_type_of(table) == AMXC_VAR_ID_LIST)) {
        SAH_TRACEZ_INFO(ME, "Found table in response.");
        amxc_var_for_each(instance, table) {
            index++;
            val = amxc_var_get_key(instance, param->name, AMXC_VAR_FLAG_DEFAULT);
            if(val) {
                SAH_TRACEZ_INFO(ME, "Parsing instance parameter '%s%d.%s'", obj_path, index, param->name);
                inst_obj = amxd_object_get_instance(obj, NULL, index);
                if(!inst_obj) {
                    status = amxd_object_add_instance(&inst_obj, obj, NULL, index, NULL);
                    if(status != amxd_status_ok) {
                        SAH_TRACEZ_ERROR(ME, "New instance of '%s' at index %d could not be created.", obj_path, index);
                        continue;
                    }
                }
                status = amxd_object_set_param(inst_obj, param->name, val);
                if(status != amxd_status_ok) {
                    SAH_TRACEZ_WARNING(ME, "Output parameter '%s%d.%s' couldn't be set, error: %d", obj_path, index, param->name, status);
                }
            } else {
                SAH_TRACEZ_WARNING(ME, "Output parameter '%s%s' was not found in response.", obj_path, param->name);
            }
        }
    } else {
        SAH_TRACEZ_WARNING(ME, "Output table '%s' was not found in response.", obj_path);
    }
}

static void parse_output_object_cb(amxd_object_t* const obj, UNUSED int32_t depth, void* priv) {
    parse_output_data_t* priv_data = (parse_output_data_t*) priv;
    char* obj_path = amxd_object_get_rel_path(obj, priv_data->output, AMXD_OBJECT_INDEXED | AMXD_OBJECT_TERMINATE);
    if(obj_path == NULL) {
        obj_path = calloc(1, 1);
    }

    SAH_TRACEZ_INFO(ME, "Object path: '%s'", obj_path);

    if(obj->type == amxd_object_template) {
        remove_all_instances(obj);
    }

    amxd_object_for_each(parameter, it, obj) {
        amxd_param_t* param = amxc_container_of(it, amxd_param_t, it);
        SAH_TRACEZ_INFO(ME, "Param name: '%s'", param->name);
        if(obj->type == amxd_object_singleton) {
            parse_output_object_singleton(obj, obj_path, param, priv_data->response_htable);
        } else if(obj->type == amxd_object_template) {
            parse_output_object_template(obj, obj_path, param, priv_data->response_htable);
        }
    }

    free(obj_path);
}

static const amxc_var_t* get_result_htable(amxb_request_t* req) {
    const amxc_var_t* result_htable = NULL;
    const amxc_llist_t* result_list = NULL;

    result_list = amxc_var_constcast(amxc_llist_t, req->result);
    if(result_list == NULL) {
        return result_htable;
    }

    result_htable = amxc_var_from_llist_it(amxc_llist_get_last(result_list));
    return result_htable;
}

static void write_callback(UNUSED const amxb_bus_ctx_t* bus_ctx,
                           amxb_request_t* req,
                           int status,
                           void* priv) {
    parse_output_data_t priv_data;
    const char* cmd_status = NULL;
    amxd_object_t* object = (amxd_object_t*) priv;
    const amxc_var_t* result_htable = NULL;

    SAH_TRACEZ_INFO(ME, "Async write_callback started status is %d", status);

    result_htable = get_result_htable(req);

    if(status == 0) {
        amxd_object_t* output = amxd_object_get_child(object, "Output");
        cmd_status = "Complete";
        if(output == NULL) {
            SAH_TRACEZ_INFO(ME, "Output object in '%s' not found", object->name);
        } else {
            if(result_htable == NULL) {
                SAH_TRACEZ_WARNING(ME, "Result htable is NULL");
            } else {
                priv_data.response_htable = result_htable;
                priv_data.output = output;
                amxd_object_hierarchy_walk(output, amxd_direction_down, NULL, parse_output_object_cb, OUTPUT_MAX_DEPTH, &priv_data);
            }
        }
    } else {
        const char* error_msg = NULL;
        char* error_code = NULL;
        const amxc_htable_t* err_htable = amxc_var_constcast(amxc_htable_t, result_htable);
        amxc_htable_it_t* it_code = amxc_htable_get(err_htable, "err_code");
        amxc_htable_it_t* it_msg = amxc_htable_get(err_htable, "err_msg");

        cmd_status = "Error";

        if(it_code != NULL) {
            const amxc_var_t* err_code_var = amxc_htable_it_get_data(it_code, amxc_var_t, hit);
            error_code = amxc_var_dyncast(cstring_t, err_code_var);
            if(error_code != NULL) {
                SAH_TRACEZ_INFO(ME, "err_code_var is %s", error_code);
            }
        }

        if(error_code != NULL) {
            if(it_msg != NULL) {
                const amxc_var_t* err_msg_var = amxc_htable_it_get_data(it_msg, amxc_var_t, hit);
                error_msg = amxc_var_constcast(cstring_t, err_msg_var);
            } else {
                error_msg = "unknown error";
            }
        } else {
            // When the err_code is not found in response, the msg is updated to the standard message corresponding to the status
            error_code = malloc(ERROR_CODE_LEN_MAX);
            snprintf(error_code, ERROR_CODE_LEN_MAX, "%d", status);
            error_msg = prepare_error_msg(status);
        }

        set_error_code_and_msg(error_code, error_msg, object);
        free(error_code);
    }

    set_trans_state(cmd_status, object);

    amxb_close_request(&req);
}

static void parse_obj_params(amxd_object_t* obj, amxc_var_t* values) {
    amxd_object_for_each(parameter, it, obj) {
        amxd_param_t* param = amxc_container_of(it, amxd_param_t, it);

        if(!amxd_param_is_attr_set(param, amxd_pattr_private)) {
            amxc_var_t* subvar = amxc_var_add_new_key(values, param->name);
            char* param_value = amxc_var_dyncast(cstring_t, &param->value);
            if(param_value != NULL) {
                SAH_TRACEZ_INFO(ME, "Param name: '%s', Param value: '%s'", param->name, param_value);
                free(param_value);
            }
            if(subvar) {
                amxc_var_set_type(subvar, amxc_var_type_of(&param->value));
                amxc_var_add_value(subvar, &param->value);
            } else {
                SAH_TRACEZ_WARNING(ME, "New key '%s' not added", param->name);
            }
        }
    }
}

static char* prepare_path_for_search_bus(const char* cmd_path) {
    amxc_string_t input_string;
    amxc_llist_t result_list;
    amxc_llist_t parse_list;
    amxc_string_split_status_t status;
    char* result = NULL;

    amxc_string_init(&input_string, 0);
    amxc_string_set(&input_string, cmd_path);

    amxc_llist_init(&parse_list);
    amxc_llist_init(&result_list);

    status = amxc_string_split_to_llist(&input_string, &parse_list, '.');
    if(status != AMXC_STRING_SPLIT_OK) {
        return NULL;
    }

    amxc_llist_it_t* it1 = amxc_llist_get_at(&parse_list, 0);
    amxc_llist_it_t* it2 = amxc_llist_get_at(&parse_list, 1);
    if(it1 == NULL) {
        goto clean;
    }

    amxc_llist_append(&result_list, it1);

    if(it2 != NULL) {
        amxc_llist_append(&result_list, it2);
    }

    amxc_string_clean(&input_string);
    if(amxc_string_join_llist(&input_string, &result_list, '.') != 0) {
        goto clean;
    }
    result = amxc_string_dup(&input_string, 0, AMXC_STRING_MAX);

clean:
    amxc_llist_clean(&parse_list, NULL);
    amxc_llist_clean(&result_list, NULL);
    amxc_string_clean(&input_string);

    return result;
}

void _process_command(UNUSED const char* const sig_name,
                      const amxc_var_t* const data,
                      UNUSED void* const priv) {
    amxd_object_t* object = NULL, * input = NULL;
    amxb_bus_ctx_t* bus_ctx = NULL;
    amxc_var_t values;
    const char* cmd_status = NULL;
    char* cmd_path = NULL, * cmd_name = NULL, * search_path = NULL;
    amxb_request_t* req = NULL;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    object = amxd_dm_signal_get_object(data_model_mapper_get_dm(), data);
    if(object == NULL) {
        SAH_TRACEZ(TRACE_LEVEL_FATAL_ERROR, ME, "Object is NULL");
        return;
    }

    input = amxd_object_get_child(object, "Input");
    if(input == NULL) {
        SAH_TRACEZ_INFO(ME, "Input object in '%s' not found", object->name);
    }

    SAH_TRACEZ_NOTICE(ME, "Start command event handler, root object name: '%s'", object->name);

    cmd_path = amxd_object_get_value(cstring_t, object, "CmdPath", NULL);
    if(cmd_path == NULL) {
        SAH_TRACEZ_ERROR(ME, "Object '%s' has no mandatory parameter CmdPath", object->name);
        set_error_code_and_msg("1", "Parameter CmdPath not found", object);
        goto error;
    }

    cmd_name = amxd_object_get_value(cstring_t, object, "CmdName", NULL);
    if(cmd_name == NULL) {
        SAH_TRACEZ_ERROR(ME, "Object '%s' has no mandatory parameter CmdName", object->name);
        set_error_code_and_msg("1", "Parameter CmdName not found", object);
        goto error;
    }

    search_path = prepare_path_for_search_bus(cmd_path);
    if(search_path == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to parse CmdPath '%s' ", cmd_path);
        set_error_code_and_msg("1", "Failed to parse CmdPath", object);
        goto error;
    }

    SAH_TRACEZ_INFO(ME, "search_path is '%s', cmd_path is '%s'", search_path, cmd_path);

    bus_ctx = amxb_be_who_has_ex(search_path, true);
    if(bus_ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "Can't find '%s' on a system bus!", search_path);
        set_error_code_and_msg("1", "Init bus_ctx error", object);
        goto error;
    }
    SAH_TRACEZ_INFO(ME, "Selected bus name is '%s'", bus_ctx->bus_fn->name);

    set_error_code_and_msg("", "", object);

    /* parse 1-st layer parameters */
    parse_obj_params(input, &values);

    /* parse all sub-objects and their parameters */
    amxd_object_for_each(child, sobj_it, input) {
        amxd_object_t* sub_object = amxc_container_of(sobj_it, amxd_object_t, it);
        const cstring_t target_type = amxc_var_constcast(cstring_t, amxd_object_get_param_value(sub_object, "target_type"));
        amxc_var_t* record;

        if(target_type == NULL) {
            SAH_TRACEZ_WARNING(ME, "target_type for object '%s' is NULL, skip parsing", sub_object->name);
            continue;
        } else if(strcmp(target_type, "list") == 0) {
            record = amxc_var_add_key(amxc_llist_t, &values, sub_object->name, NULL);
        } else if(strcmp(target_type, "htable") == 0) {
            record = &values;
        } else {
            SAH_TRACEZ_WARNING(ME, "Unsuported target_type '%s' for object '%s', skip parsing", target_type, sub_object->name);
            continue;
        }

        if(sub_object->type == amxd_object_template) {
            amxd_object_for_each(instance, ins_it, sub_object) {
                amxd_object_t* instance = amxc_container_of(ins_it, amxd_object_t, it);
                amxc_var_t* param_table = amxc_var_add(amxc_htable_t, record, NULL);

                parse_obj_params(instance, param_table);
            }
        } else if(sub_object->type == amxd_object_singleton) {
            amxc_var_t* param_table = amxc_var_add(amxc_htable_t, record, NULL);

            parse_obj_params(sub_object, param_table);
        }
    }

    req = amxb_async_call(bus_ctx, cmd_path, cmd_name, &values, write_callback, object);
    if(req == NULL) {
        SAH_TRACEZ_ERROR(ME, "Bad amxb_async_call, request is NULL");
        goto error;
    }

    SAH_TRACEZ_NOTICE(ME, "Command event handler completed, root  object name: '%s'", object->name);
    goto cleanup;

error:
    cmd_status = "Error";
    set_trans_state(cmd_status, object);

cleanup:
    amxc_var_clean(&values);
    free(cmd_path);
    free(cmd_name);
    free(search_path);
}
