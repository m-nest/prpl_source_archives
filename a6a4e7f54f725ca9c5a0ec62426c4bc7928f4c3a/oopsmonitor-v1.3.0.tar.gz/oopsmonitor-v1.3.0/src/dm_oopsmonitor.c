/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "oopsmonitor_priv.h"

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include <filetransfer/filetransfer.h>

#include <errno.h>
#include <libgen.h>
#include <string.h>
#include <sys/stat.h>

#define ME DEFAULT_TRACE_ZONE_NAME

static amxd_status_t rm_oops_instances(amxd_object_t* root_object) {
    amxd_object_t* oopses = NULL;
    amxd_object_t* oops = NULL;
    amxd_trans_t transaction;
    amxd_status_t retval = amxd_status_unknown_error;

    when_null(root_object, exit);
    oopses = amxd_object_get_child(root_object, "KernelFault");
    when_null(oopses, exit);
    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, oopses);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_object_iterate(instance, it_oops, oopses) {
        oops = amxc_container_of(it_oops, amxd_object_t, it);
        amxd_trans_del_inst(&transaction, amxd_object_get_index(oops), NULL);
    }
    retval = amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);
exit:
    return retval;
}

amxd_status_t _RemoveAllKernelFaults(amxd_object_t* root_object,
                                     UNUSED amxd_function_t* func,
                                     UNUSED amxc_var_t* args,
                                     UNUSED amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_unknown_error;
    const char* store_path = NULL;
    when_null(root_object, exit);

    store_path = GET_CHAR(amxd_object_get_param_value(root_object, "StoragePath"), NULL);
    when_null_trace(store_path, exit, ERROR, "Failed to retrieve path of the stored oopses directory");

    retval = rm_oops_instances(root_object);
    when_failed_trace(retval, exit, ERROR, "Failed to remove Oops instances from datamodel");

exit:
    return retval;
}

amxd_status_t _Remove(amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_trans_t transaction;
    amxd_object_t* parent_object = NULL;
    amxd_status_t retval = amxd_status_unknown_error;

    retval = amxd_trans_init(&transaction);
    when_failed(retval, exit);

    parent_object = amxd_object_get_parent(object);
    when_null(parent_object, exit);

    retval = amxd_trans_select_object(&transaction, parent_object);
    when_failed(retval, exit);

    retval = amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    when_failed(retval, exit);

    amxd_trans_del_inst(&transaction, amxd_object_get_index(object), NULL);
    retval = amxd_trans_apply(&transaction, get_dm());

exit:
    amxd_trans_clean(&transaction);
    return retval;
}

bool upload_cb(ftx_request_t* req, void* userdata) {
    char* transfer_url = (char*) userdata;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("LocalAgent.");
    amxc_ts_t* ts_start = NULL;
    amxc_ts_t* ts_end = NULL;
    ftx_error_code_t error_code;
    amxc_var_t* ret = NULL;
    amxc_var_t* event_params = NULL;

    error_code = ftx_request_get_error_code(req);
    ts_start = ftx_request_get_start_time(req);
    ts_end = ftx_request_get_end_time(req);

    amxc_var_new(&event_params);
    amxc_var_set_type(event_params, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, event_params, "TransferType", "Upload");
    amxc_var_add_key(uint32_t, event_params, "FaultCode", error_code);
    amxc_var_add_key(cstring_t, event_params, "FaultString", ftx_request_get_error_reason(req));
    amxc_var_add_key(amxc_ts_t, event_params, "StartTime", ts_start);
    amxc_var_add_key(amxc_ts_t, event_params, "CompleteTime", ts_end);
    amxc_var_add_key(cstring_t, event_params, "TransferURL", transfer_url);

    if(error_code != ftx_error_code_no_error) {
        SAH_TRACEZ_ERROR(ME, "error code: (%u) reason: %s", error_code, ftx_request_get_error_reason(req));
    } else {
        char time_start_str[64] = {0};
        char time_end_str[64] = {0};

        amxc_ts_format(ts_start, time_start_str, sizeof(time_start_str));
        amxc_ts_format(ts_end, time_end_str, sizeof(time_end_str));

        SAH_TRACEZ_INFO(ME, "file size: %u", ftx_request_get_file_size(req));
        SAH_TRACEZ_INFO(ME, "Upload Time Start : %s", time_start_str);
        SAH_TRACEZ_INFO(ME, "Upload Time End   : %s", time_end_str);
    }

    if(amxb_call(ctx, "LocalAgent.", "SendTransferComplete", event_params, ret, 5) != AMXB_STATUS_OK) {
        SAH_TRACEZ_WARNING(ME, "Transfer complete event could not be sent");
    }

    ftx_request_delete(&req);
    amxc_var_delete(&event_params);
    free(transfer_url);
    return true;
}

amxd_status_t _Upload(amxd_object_t* object,
                      UNUSED amxd_function_t* func,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxd_status_t status = amxd_status_unknown_error;
    ftx_request_t* request = NULL;
    amxc_string_t absolute_path_str;
    char* file_path = NULL;
    char* file_name = NULL;
    char* transfer_url = NULL;
    const char* url = GET_CHAR(args, "URL");
    const char* username = GET_CHAR(args, "Username");
    const char* password = GET_CHAR(args, "Password");
    const char* dir_path = GET_CHAR(amxd_object_get_param_value(get_root_object(), "StoragePath"), NULL);

    amxc_string_init(&absolute_path_str, 0);

    when_false_trace((strlen(url) < 2048), exit, ERROR, "URL MaximumSize is 2048");
    when_false_trace((strlen(username) < 256), exit, ERROR, "Username MaximumSize is 256");
    when_false_trace((strlen(password) < 256), exit, ERROR, "Password MaximumSize is 256");

    transfer_url = strdup(url);
    amxc_string_setf(&absolute_path_str, "%s/%s", dir_path, GET_CHAR(amxd_object_get_param_value(object, "FaultLocation"), NULL));
    file_path = amxc_string_take_buffer(&absolute_path_str);
    when_str_empty_trace(file_path, exit, ERROR, "There is no file path in the Name parameter");
    file_name = basename(file_path);

    when_failed_trace(ftx_request_new(&request, ftx_request_type_upload, upload_cb), exit, ERROR, "Could not allocate memory.");
    when_failed_trace(ftx_request_set_url(request, url), exit, ERROR, "URL does not set.");
    when_failed_trace(ftx_request_set_credentials(request, ftx_authentication_any, username, password), exit, ERROR, "Credentials Error.");
    when_failed_trace(ftx_request_set_target_file(request, file_path), exit, ERROR, "There is no such file.");
    when_failed_trace(ftx_request_set_max_transfer_time(request, 600), exit, ERROR, "Could not allocate memory.");
    when_failed_trace(ftx_request_set_data(request, (void*) transfer_url), exit, ERROR, "Could not set userdata.");
    when_failed_trace(ftx_request_set_upload_method(request, ftx_upload_method_post), exit, ERROR, "Could not set HTTP method.");
    when_failed_trace(ftx_request_set_http_multipart_form_data(request, "file", file_name, "application/octet-stream"), exit, ERROR, "Could not set HTTP multipart.");

    if(strstr(url, "https://") != NULL) {
        int rc = -1;
        const char* ca_cert = GET_CHAR(amxd_object_get_param_value(get_root_object(), "CACertificate"), NULL);
        when_str_empty_trace(ca_cert, exit, ERROR, "CA Certificate is not defined");

        rc = ftx_request_set_ca_certificates(request, ca_cert, NULL);
        when_failed_trace(rc, exit, ERROR, "Could not set CA Certificate");
    }

    when_failed_trace(ftx_request_send(request), exit, ERROR, "The send request failed.");

    status = amxd_status_ok;

exit:
    if(status != amxd_status_ok) {
        free(transfer_url);
        ftx_request_delete(&request);
    }

    free(file_path);
    amxc_string_clean(&absolute_path_str);
    return status;
}

static int mkpath(char* dir, mode_t mode) {
    struct stat sb;

    if(!dir) {
        errno = EINVAL;
        return 1;
    }

    if(!stat(dir, &sb)) {
        return 0;
    }

    mkpath(dirname(strdupa(dir)), mode);

    return mkdir(dir, mode);
}

static bool create_store_dir(void) {
    bool retval = false;
    struct stat sb = {0};
    const char* dir_path = GET_CHAR(amxd_object_get_param_value(get_root_object(), "StoragePath"), NULL);

    when_null_trace(dir_path, exit, ERROR, "Can't create directory because StorePath is empty");
    if(stat(dir_path, &sb) != 0) {
        when_false_trace(mkpath((char*) dir_path, 0755) == 0, exit, ERROR, "Failed to create directory: %s", strerror(errno));
    } else {
        when_true_trace(S_ISDIR(sb.st_mode) == 0, exit, ERROR, "Failed StorePath is not a directory");
    }
    retval = true;
exit:
    return retval;
}

void _oops_app_start(UNUSED const char* const sig_name,
                     UNUSED const amxc_var_t* const data,
                     UNUSED void* const priv) {
    const char* path_s = NULL;
    struct stat sb = {0};
    amxc_var_t* oops_path = amxo_parser_get_config(get_parser(), "ramoops_path");

    when_null_trace(oops_path, exit, ERROR,
                    "Failed to retrieve oops directory path");
    when_false(create_store_dir(), exit);
    path_s = amxc_var_constcast(cstring_t, oops_path);
    if((path_s != NULL) && (stat(path_s, &sb) == 0) && S_ISDIR(sb.st_mode)) {
        scan_oops_dir(path_s);
    }
exit:
    return;
}

void _oops_instance_removed(UNUSED const char* const event_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    const char* file_name = NULL;
    char* file_path = NULL;
    amxc_var_t* params = GET_ARG(event_data, "parameters");
    const char* store_path = GET_CHAR(amxd_object_get_param_value(get_root_object(), "StoragePath"), NULL);
    int rv = 0;

    when_null(store_path, exit);
    when_null(params, exit);

    file_name = GET_CHAR(params, "FaultLocation");
    when_null(file_name, exit);

    rv = asprintf(&file_path, "%s/%s", store_path, file_name);
    when_true(rv == -1, exit);
    when_true_trace(remove(file_path) != 0, exit, ERROR, "Failed to remove file %s", file_path);

exit:
    free(file_path);
    return;
}