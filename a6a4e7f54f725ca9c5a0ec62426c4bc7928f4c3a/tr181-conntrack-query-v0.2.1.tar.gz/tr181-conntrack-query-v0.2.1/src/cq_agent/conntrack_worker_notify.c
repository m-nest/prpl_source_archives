/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <libnetfilter_conntrack/libnetfilter_conntrack.h>
#include <sys/un.h>
#include <fcntl.h>
#include "conntrackingquery_common.h"

static int start_notify_events();

static int sock = -1;
static char* filter_event = NULL;

/**
 * @struct filter_cfg
 * @brief Holds filtering configuration for network packets.
 *
 * This structure defines the filtering parameters used to match
 * network packets based on IPv6/IPv4 addresses, protocol, and ports.
 */
struct filter_cfg {
    struct in6_addr src_ipv6;   /**< Source IPv6 address. */
    struct in6_addr dst_ipv6;   /**< Destination IPv6 address. */
    uint8_t proto;              /**< Protocol number (e.g., TCP = 6, UDP = 17). */
    uint32_t src_ip;            /**< Source IPv4 address (in network byte order). */
    uint32_t dst_ip;            /**< Destination IPv4 address (in network byte order). */
    uint16_t src_port;          /**< Source port number. */
    uint16_t dst_port;          /**< Destination port number. */
};

static struct filter_cfg cfg;

/**
 * @brief Sets Nonblocking mode on the socket
 *
 * This functions sets Nonblocking mode on the opened socket
 *
 * @param socket socket descriptor
 *
 * @return bool returns the true or false status
 */
static bool set_nonblock(int socket) {
    int flags = fcntl(socket, F_GETFL, 0);
    int ret = -1;
    bool rc = false;

    ret = fcntl(socket, F_SETFL, flags | O_NONBLOCK);
    if(ret == -1) {
        fprintf(stderr, "Failed to set socket non blocking: (%d) - %s", errno, strerror(errno));
        goto exit;
    }
    rc = true;

exit:
    return rc;
}

/**
 * @brief Opens a UNIX socket
 *
 * This functions opens a UNIX socket and passes the callback function sock_event_handler
 * for handling the data
 *
 * @param query the query object which was got from the data model
 *
 * @return int returns 0 on success -1 on failure
 */
int unix_socket_init(void) {
    bool close_socket = false;

    sock = socket(AF_UNIX, SOCK_DGRAM, 0);
    if(sock < 0) {
        fprintf(stderr, "Failed to open socket: (%d) - %s", errno, strerror(errno));
        return sock;
    }

    if(set_nonblock(sock) == false) {
        close_socket = true;
        goto exit;
    }

exit:
    if(close_socket) {
        close(sock);
        sock = -1;
    }

    return sock;
}


/**
 * @brief: converts the ip6 addresss given in dotted decimal format to network format
 * This function converts the ip6 addresss given in dotted decimal format to network format
 *
 * @param ip	Pointer to const char which is ip address in dotted decimal format
 * @param addr	structure to define IPv6 address
 *
 * @return int	returns 0 for valid address , -1 for invalid address
 */

static int ip_str_to_in6(const char* ip, struct in6_addr* addr) {
    if(strcmp(ip, "::") == 0) {
        memset(addr, 0, sizeof(struct in6_addr));
        return 0;
    }
    if(inet_pton(AF_INET6, ip, addr) != 1) {
        fprintf(stderr, "invalid IPv6: %s\n", ip);
        return -1;
    }
    return 0;
}


/**
 * @brief: converts the ip4 addresss given in dotted decimal format to network format
 * This function converts the ip6 addresss given in dotted decimal format to network format
 *
 * @param ip    Pointer to const char which is ip address in dotted decimal format
 * @param addr  structure to define IPv4 address
 *
 * @return int  returns 0 for valid address , -1 for invalid address
 */
static uint32_t ip_str_to_u32(const char* ip) {
    struct in_addr a;
    if(ip != NULL) {
        //Valid ip address
    }
    if(strcmp(ip, "0.0.0.0") == 0) {
        return 0;
    }
    if(inet_aton(ip, &a) == 0) {
        fprintf(stderr, "invalid IPv4: %s\n", ip);
        exit(EXIT_FAILURE);
    }
    return ntohl(a.s_addr);
}


/**
 * @brief parse the protocol in string format to the appropriate protocol numbers
 * The function parses the protoco  in string format to the appropriate protocol numbers
 *
 * @param proto Pointer to const char which is protocol in string format
 * @return unit8_t Returns appropriate protocol numbers
 */

static uint8_t parse_proto(const char* proto) {
    if(!proto) {
        return 0;
    }
    if(strcasecmp(proto, "tcp") == 0) {
        return IPPROTO_TCP;
    }
    if(strcasecmp(proto, "udp") == 0) {
        return IPPROTO_UDP;
    }
    if(strcasecmp(proto, "icmp") == 0) {
        return IPPROTO_ICMP;
    }
    return 0;
}


/**
 * @brief returns the conntract event state based on the type of the conntrack event
 * The function returns the conntract event state based on the type of the conntrack event
 *
 * @param type	enum type of nf_conntrack_msg_type
 * @return const char * Returns the appropriate string for the event type
 */

static const char* nfct_msg_type_to_str(enum nf_conntrack_msg_type type) {
    switch(type) {
    case NFCT_T_NEW: return "New";
    case NFCT_T_UPDATE: return "Update";
    case NFCT_T_DESTROY: return "Delete";
    default: return "UNKNOWN";
    }
}


/**
 * @brief sends the conntract event entry to the other end of the socket
 * The function sends the conntract event entry to the other end of the socket
 *
 * @param ct_entry conntract entry of type struct conntrack_entry_t
 * @return void
 */
void send_conntrack_entry_to_socket(conntrack_entry_t* ct_entry) {

    struct sockaddr_un addr;
    ct_entry->pid = getpid();
    memset(&addr, 0, sizeof(struct sockaddr_un));
    socklen_t addr_len = sizeof(struct sockaddr_un);
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TR181_CT_MGR_SOCK, sizeof(addr.sun_path) - 1);
    sendto(sock, ct_entry, sizeof(conntrack_entry_t), 0, (struct sockaddr*) &addr, addr_len);

}


/**
 * @brief Callback function to handle and parse the conntrack events
 * This is a callback function to handle and parse the conntrack events
 *
 * @param type	enum nf_conntrack_msg_type
 * @param ct	pointer to nf_conntrack
 * @param data  Unused param
 *
 * @return int returns NFCT_CB_CONTINUE
 */
static int event_cb(enum nf_conntrack_msg_type type,
                    struct nf_conntrack* ct, void* data __attribute__((unused))) {

    conntrack_entry_t entry;
    uint8_t l4proto = nfct_get_attr_u8(ct, ATTR_ORIG_L4PROTO);
    uint32_t saddr = nfct_get_attr_u32(ct, ATTR_ORIG_IPV4_SRC);
    uint32_t daddr = nfct_get_attr_u32(ct, ATTR_ORIG_IPV4_DST);
    uint16_t sport = ntohs(nfct_get_attr_u16(ct, ATTR_ORIG_PORT_SRC));
    uint16_t dport = ntohs(nfct_get_attr_u16(ct, ATTR_ORIG_PORT_DST));
    const void* saddr6 = nfct_get_attr(ct, ATTR_ORIG_IPV6_SRC);
    const void* daddr6 = nfct_get_attr(ct, ATTR_ORIG_IPV6_DST);


    if(cfg.proto && (l4proto != cfg.proto)) {
        return NFCT_CB_CONTINUE;
    }
    if(cfg.src_port && (sport != cfg.src_port)) {
        return NFCT_CB_CONTINUE;
    }
    if(cfg.dst_port && (dport != cfg.dst_port)) {
        return NFCT_CB_CONTINUE;
    }
    if((filter_event != NULL) && strcmp(filter_event, nfct_msg_type_to_str(type))) {
        return NFCT_CB_CONTINUE;
    }

    snprintf(entry.event, sizeof(entry.event), "%s", nfct_msg_type_to_str(type));

    if(saddr6 && daddr6) {
        inet_ntop(AF_INET6, saddr6, entry.src_ip, sizeof(entry.src_ip));
        inet_ntop(AF_INET6, saddr6, entry.src_ip, sizeof(entry.src_ip));
    } else {

        struct in_addr src, dst;
        src.s_addr = saddr;
        dst.s_addr = daddr;
        snprintf(entry.src_ip, sizeof(entry.src_ip), "%s", inet_ntoa(src));
        snprintf(entry.dst_ip, sizeof(entry.dst_ip), "%s", inet_ntoa(dst));
    }
    entry.src_port = sport;
    entry.dst_port = dport;
    entry.protocol = l4proto;

    send_conntrack_entry_to_socket(&entry);

    return NFCT_CB_CONTINUE;
}



/**
 * @brief conntrack notify main
 * Main conntrack notify worker function to parse the input filters and check
 * for conntrack events based on the input filters
 *
 * @param argc	number of arguments
 * @param argv	arguments
 *
 * @return int
 */

int main(int argc, char* argv[]) {

    memset(&cfg, 0, sizeof(cfg));
    cfg.proto = parse_proto("udp");

    for(int i = 1; i < argc; ++i) {
        if(strncmp(argv[i], "--proto=", 8) == 0) {
            cfg.proto = parse_proto(argv[i] + 8);
        } else if(strncmp(argv[i], "--src-ip=", 9) == 0) {
            if(strchr(argv[i] + 9, ':')) {
                ip_str_to_in6(argv[i] + 9, &cfg.src_ipv6);
            } else {
                cfg.src_ip = ip_str_to_u32(argv[i] + 9);
            }
        } else if(strncmp(argv[i], "--dst-ip=", 9) == 0) {
            if(strchr(argv[i] + 9, ':')) {
                ip_str_to_in6(argv[i] + 9, &cfg.dst_ipv6);
            } else {
                cfg.dst_ip = ip_str_to_u32(argv[i] + 9);
            }
        } else if(strncmp(argv[i], "--sport=", 8) == 0) {
            cfg.src_port = atoi(argv[i] + 8);
        } else if(strncmp(argv[i], "--dport=", 8) == 0) {
            cfg.dst_port = atoi(argv[i] + 8);
        } else if(strncmp(argv[i], "--event=", 8) == 0) {
            filter_event = argv[i] + 8;
        }
    }

    start_notify_events();
    return 0;

}

/**
 * @brief start_notify_events
 * start_notify_events function which will used libnetfilter_conntrack apis
 * to add and attach filters and parse the incoming events
 *
 * @param void
 *
 * @return int returns 0 on successs, EXIT_FAILURE on failure
 */

int start_notify_events() {

    struct nfct_handle* h;
    struct nfct_filter* filter;
    int fd;

    unix_socket_init();

    h = nfct_open(CONNTRACK, NFCT_ALL_CT_GROUPS);
    if(!h) {
        perror("nfct_open");
        return EXIT_FAILURE;
    }

    fd = nfct_fd(h);
    filter = nfct_filter_create();
    if(!filter) {
        perror("nfct_filter_create");
        nfct_close(h);
        return EXIT_FAILURE;
    }

    if(cfg.src_ip) {
        struct nfct_filter_ipv4 s4 = { .addr = cfg.src_ip, .mask = 0xFFFFFFFF };
        nfct_filter_add_attr(filter, NFCT_FILTER_SRC_IPV4, &s4);
    }
    if(cfg.dst_ip) {
        struct nfct_filter_ipv4 d4 = { .addr = cfg.dst_ip, .mask = 0xFFFFFFFF };
        nfct_filter_add_attr(filter, NFCT_FILTER_DST_IPV4, &d4);
    }


    struct in6_addr zero_addr6 = {0};

    if((memcmp(&cfg.src_ipv6, &zero_addr6, sizeof(struct in6_addr)) != 0) &&
       (memcmp(&cfg.dst_ipv6, &zero_addr6, sizeof(struct in6_addr)) != 0)) {

        struct nfct_filter_ipv6 s6;
        memcpy(s6.addr, &cfg.src_ipv6, sizeof(struct in6_addr));
        memset(s6.mask, 0xFF, sizeof(s6.mask));  // Full mask
        nfct_filter_add_attr(filter, NFCT_FILTER_SRC_IPV6, &s6);

        struct nfct_filter_ipv6 d6;
        memcpy(d6.addr, &cfg.dst_ipv6, sizeof(struct in6_addr));
        memset(d6.mask, 0xFF, sizeof(d6.mask));  // Full mask
        nfct_filter_add_attr(filter, NFCT_FILTER_DST_IPV6, &d6);

    }

    if(cfg.proto) {
        nfct_filter_add_attr_u32(filter, NFCT_FILTER_L4PROTO, cfg.proto);
    }

    if(nfct_filter_attach(fd, filter) == -1) {
        perror("nfct_filter_attach");
        nfct_filter_destroy(filter);
        nfct_close(h);
        return EXIT_FAILURE;
    }

    nfct_filter_destroy(filter);

    if(nfct_callback_register(h, NFCT_T_ALL, event_cb, NULL) == -1) {
        perror("nfct_callback_register");
        nfct_close(h);
        return EXIT_FAILURE;
    }

    nfct_catch(h);
    nfct_close(h);
    return 0;
}

