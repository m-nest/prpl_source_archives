/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__AMXS_SYNC_RESOLVE_H__)
#define __AMXS_SYNC_RESOLVE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxs/amxs_types.h>

/**
   @file
   @brief
   Ambiorix Object Path Resolving API header file
 */

/**
   @ingroup amxs_resolve
   @brief
   Creates a resolve context and starts monitoring a given object search path

   Monitors a given object search path and all object instance paths that start or stop
   matching the search path are passed to the callback function.

   @note:
   It is possible that callbacks are invoked before this function returns.
   This can happen when existing objects are matching the search path when this function is called.

   Use @ref amxs_resolve_ctx_delete to stop the monitoring and and free all allocated memory.

   @param ctx Pointer to a resolve context pointer. The address of the new allocated
              resolve context is stored in this pointer.
   @param search_path Object search path to monitor. The path must meet the following conditions:
                      - The path depth must be at least 3
                      - The path must end with a "."
                      - The search expression must be the last part of the path, and written between
                        square brackets
                      - The path must contain exactly one expression (which may contain multiple operators)
   @param cb Callback function which is invoked when an object path starts or stops
             matching the given search path.
   @param priv Pointer to user data which will be passed to the resolve callback function.

   @return
   amxs_status_ok when the resolve context is created and started succesfully, or another status
   code when an error has occured.
 */
amxs_status_t amxs_resolve_ctx_new(amxs_resolve_ctx_t** ctx,
                                   const char* search_path,
                                   amxs_resolve_fn_t cb,
                                   void* priv);

/**
   @ingroup amxs_resolve
   @brief
   Resolve context destructor function

   Stops monitoring the object search path for the given resolve context.

   @note
   The callback function will be invoked for all currently matching object paths, to indicate that they are no longer matching.

   Frees all memory allocated for the resolve context.

   @param ctx Pointer to a resolve context pointer.
 */
void amxs_resolve_ctx_delete(amxs_resolve_ctx_t** ctx);

#ifdef __cplusplus
}
#endif

#endif // __AMXS_SYNC_RESOLVE_H__

