/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "common_functions.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <signal.h>       /* sigemptyset() */
#include <sys/select.h>
#include <sys/signalfd.h> /* signalfd() */
#include <unistd.h>       /* read() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp.h> /* amxp_timers_calculate() */

/* Own headers */
#include "sfpmgr_trace.h"

#undef ME
#define ME "runtest"


/**
 * Handle amxp timers if SIGALRM occurs.
 *
 * Wait for SIGALRM with a timeout of @a timeout_s seconds. Handle amxp timers
 * if SIGALRM occurs.
 *
 * If the module under test starts a timer which should time out in less than @a
 * timeout_s seconds (because of an action done by the unit test), the unit test
 * can call this function: it waits for the SIGALRM of the timer, and then calls
 * amxp functions to handle the timer: this should call the callback function of
 * the timer.
 *
 * @return true if function received and handled SIGALRM, else false
 */
bool read_sig_alarm(unsigned timeout_s) {
    bool alarm_read = false;
    int rv = -1;
    sigset_t mask;
    int sfd;
    struct signalfd_siginfo fdsi;
    ssize_t s;
    fd_set set;
    struct timeval timeout;

    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    sfd = signalfd(-1, &mask, 0);

    FD_ZERO(&set);     /* clear the set */
    FD_SET(sfd, &set); /* add our file descriptor to the set */
    timeout.tv_sec = timeout_s;
    timeout.tv_usec = 0;

    rv = select(sfd + 1, &set, NULL, NULL, &timeout);
    if(rv == -1) {
        assert_non_null(NULL);
    } else if(rv == 0) {
        SAH_TRACEZ_INFO(ME, "No timer event occurred");
    } else {
        SAH_TRACEZ_INFO(ME, "Got SIGALRM");
        s = read(sfd, &fdsi, sizeof(struct signalfd_siginfo));
        assert_int_equal(s, sizeof(struct signalfd_siginfo));
        if(fdsi.ssi_signo == SIGALRM) {
            amxp_timers_calculate();
            amxp_timers_check();
        }
        alarm_read = true;
    }
    return alarm_read;
}

/**
 * Trigger event handlers.
 *
 * See:
 * https://gitlab.com/prpl-foundation/components/ambiorix/examples/datamodel/greeter_plugin/-/blob/v0.4.5/test/greeter_state/test_greeter_state.c?ref_type=tags#L86
 */
void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
}
