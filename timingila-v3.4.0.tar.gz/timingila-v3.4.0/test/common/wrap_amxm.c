/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxp/amxp.h>
#include <amxm/amxm.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <debug/sahtrace.h>

#include <timingila/timingila_defines.h>
#include "timingila_common.h"
#include "timingila/timingila_module.h"
#include "softwaremodules_common.h"
#include "test_setup.h"

#include "wrap_amxm.h"

#define ME "wrap"

#define UNUSED __attribute__((unused))

static int update_var_data_cstring_t(amxc_var_t* var_table, const char* key, const char* data) {
    amxc_var_t* var = amxc_var_get_key(var_table, key, AMXC_VAR_FLAG_DEFAULT);
    if(var) {
        return amxc_var_set(cstring_t, var, data);
    }
    amxc_var_add_key(cstring_t, var_table, key, data);
    return 0;
}

static int mod_install_du(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = %s, %s, %s\n", GET_CHAR(args, SM_DM_DU_URL), GET_CHAR(args, SM_DM_DU_UUID), GET_CHAR(args, SM_DM_DU_EE_REF));
    return 0;
}
static int mod_add_exec_env(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = %s, %s, %s, %s, %d, %d, %d\n",
           GET_CHAR(args, SM_DM_EE_NAME), GET_CHAR(args, SM_DM_EE_VENDOR), GET_CHAR(args, SM_DM_EE_VERSION), GET_CHAR(args, SM_DM_EE_PARENT_EE),
           GET_INT32(args, SM_DM_EE_ALLOCMEM), GET_INT32(args, SM_DM_EE_ALLOCDISKSPACE), GET_INT32(args, SM_DM_EE_ALLOCCPUPERCENT));
    return 0;
}
static int mod_update_du(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = %s, %s, %s, %s\n", GET_CHAR(args, SM_DM_DU_URL), GET_CHAR(args, SM_DM_DU_UUID), GET_CHAR(args, SM_DM_DU_USERNAME), GET_CHAR(args, SM_DM_DU_PASSWORD));
    return 0;
}

static int mod_uninstall_du(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_INFO(ME, "UNINSTALL DU");
    amxc_string_t alias;
    amxc_string_init(&alias, 0);
    amxc_var_t remove_args;
    amxc_var_init(&remove_args);
    amxc_var_set_type(&remove_args, AMXC_VAR_ID_HTABLE);

    // remove from the datamodel
    amxc_string_appendf(&alias, "cpe-%s", GET_CHAR(args, SM_DM_DU_DUID));
    amxc_var_set_key(&remove_args, SM_DM_EU_EUID, GET_ARG(args, SM_DM_DU_DUID), AMXC_VAR_FLAG_COPY);
    timingila_dm_mngr_execute(TIMINGILA_MOD_DM_MNGR_REMOVE_EU, &remove_args, ret);
    amxc_var_clean(&remove_args);

    // pretend that everything went well
    amxc_var_t* dustatechange_data = GET_ARG(args, SM_DM_EVENT_DUSTATECHANGE_DATA);

    amxc_ts_t now = {0, 0, 0};
    amxc_ts_now(&now);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &now);
    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_CURRENTSTATE, SM_DM_EVENT_DUSTATECHANGE_UNINSTALLED);
    timingila_dm_mngr_event_dustatechange(NULL, dustatechange_data, NULL);

    amxc_string_clean(&alias);
    amxc_var_clean(&remove_args);

    return 0;
}

static int mod_restart_ee(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = %s\n", GET_CHAR(args, SM_DM_EE_RESTART_REASON));
    return 0;
}

static int mod_modify_constraints_ee(UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = \n");
    return 0;
}
static int mod_delete_ee(UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = \n");
    return 0;
}
static int mod_setrequestedstate_eu(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    printf("Args = %s\n", GET_CHAR(args, SM_DM_EU_REQSTATE));
    return 0;
}
static int mod_eu_nodifynetworkconfig(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    amxc_var_dump(args, STDOUT_FILENO);
    return 0;
}

static int mod_eu_validateargs(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_INFO(ME, "VALIDATE ARGS");
    amxc_string_t alias;
    amxc_string_init(&alias, 0);
    amxc_var_t create_args;
    amxc_var_init(&create_args);
    amxc_var_set_type(&create_args, AMXC_VAR_ID_HTABLE);

    // add to the datamodel
    amxc_string_appendf(&alias, "cpe-%s", GET_CHAR(args, SM_DM_DU_DUID));
    amxc_var_add_new_key_cstring_t(&create_args, SM_DM_DU_ALIAS, amxc_string_get(&alias, 0));
    amxc_var_add_new_key_cstring_t(&create_args, SM_DM_DU_VERSION, "3.14");
    amxc_var_set_key(&create_args, SM_DM_DU_DUID, GET_ARG(args, SM_DM_DU_DUID), AMXC_VAR_FLAG_COPY);
    amxc_var_set_key(&create_args, SM_DM_DU_URL, GET_ARG(args, SM_DM_DU_URL), AMXC_VAR_FLAG_COPY);
    amxc_var_set_key(&create_args, SM_DM_DU_UUID, GET_ARG(args, SM_DM_DU_UUID), AMXC_VAR_FLAG_COPY);

    timingila_dm_mngr_execute(TIMINGILA_MOD_DM_MNGR_UPDATE_DU, &create_args, ret);
    amxc_var_clean(&create_args);
    amxc_var_set_type(&create_args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&create_args, SM_DM_EU_ALIAS, amxc_string_get(&alias, 0));
    amxc_var_set_key(&create_args, SM_DM_EU_EUID, GET_ARG(args, SM_DM_DU_DUID), AMXC_VAR_FLAG_COPY);
    timingila_dm_mngr_execute(TIMINGILA_MOD_DM_MNGR_UPDATE_EU, &create_args, ret);
    amxc_var_clean(&create_args);

    const char* eeref = GET_CHAR(args, SM_DM_DU_EE_REF);
    if(!STRING_EMPTY(eeref)) {
        amxd_object_t* ee = amxd_dm_findf(test_get_dm(), SOFTWAREMODULES_DM_EE ".[" SM_DM_EE_NAME " == '%s'].", eeref);
        if(ee) {
            amxd_object_t* du = amxd_dm_findf(test_get_dm(), SOFTWAREMODULES_DM_DU ".[" SM_DM_DU_ALIAS " == '%s'].", amxc_string_get(&alias, 0));
            if(du) {
                char* path = amxd_object_get_path(ee, AMXD_OBJECT_INDEXED);
                amxd_object_set_cstring_t(du, SM_DM_DU_EE_REF, path);
                free(path);
            }
        }
    }

    // pretend that everything went well
    amxc_var_t* dustatechange_data = GET_ARG(args, SM_DM_EVENT_DUSTATECHANGE_DATA);

    amxc_ts_t now = {0, 0, 0};
    amxc_ts_now(&now);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &now);
    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_CURRENTSTATE, SM_DM_EVENT_DUSTATECHANGE_INSTALLED);
    timingila_dm_mngr_event_dustatechange(NULL, dustatechange_data, NULL);

    amxc_string_clean(&alias);
    amxc_var_clean(&create_args);

    return 0;
}

static int mod_eu_get_corresponding_dus(amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int rc = -1;
    const char* euid = GET_CHAR(args, SM_DM_EU_EUID);
    SAH_TRACEZ_INFO(ME, "Exec " TIMINGILA_CONTAINER_EU_GET_CORRESPONDING_DUS);
    if(euid == NULL) {
        SAH_TRACEZ_ERROR(ME, "Missing " SM_DM_EU_EUID);
        goto exit;
    }

    amxc_var_set_type(ret, AMXC_VAR_ID_LIST);
    amxc_var_add(cstring_t, ret, euid);

    rc = 0;
exit:
    return rc;
}

int __wrap_amxm_so_execute_function(UNUSED amxm_shared_object_t* const so,
                                    const char* const module_name,
                                    const char* const func_name,
                                    amxc_var_t* args,
                                    amxc_var_t* ret) {
    printf("Module_name %s fname %s\n", module_name, func_name);
    if(strcmp(func_name, TIMINGILA_PACKAGER_INSTALLDU) == 0) {
        return mod_install_du(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_PACKAGER_UPDATEDU) == 0) {
        return mod_update_du(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_PACKAGER_UNINSTALLDU) == 0) {
        return mod_uninstall_du(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EE_RESTART) == 0) {
        return mod_restart_ee(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EE_ADD) == 0) {
        return mod_add_exec_env(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EE_DELETE) == 0) {
        return mod_delete_ee(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EE_MODIFYCONSTRAINTS) == 0) {
        return mod_modify_constraints_ee(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EU_SETREQUESTEDSTATE) == 0) {
        return mod_setrequestedstate_eu(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EU_MODIFYNETWORKCONFIG) == 0) {
        return mod_eu_nodifynetworkconfig(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EU_VALIDATEINSTALLARGS) == 0) {
        return mod_eu_validateargs(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EU_VALIDATEUPDATEARGS) == 0) {
        return mod_eu_validateargs(args, ret);
    }
    if(strcmp(func_name, TIMINGILA_CONTAINER_EU_GET_CORRESPONDING_DUS) == 0) {
        return mod_eu_get_corresponding_dus(args, ret);
    }

    int rv = (int) mock();

    return rv;
}
