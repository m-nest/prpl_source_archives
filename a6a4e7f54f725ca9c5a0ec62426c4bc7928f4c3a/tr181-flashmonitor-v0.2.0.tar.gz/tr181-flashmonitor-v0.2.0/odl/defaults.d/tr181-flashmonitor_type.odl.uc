{% import * as fs from 'fs'; %}
%populate {
    object Hardware.FlashDevice {
        {% for (let dev in fs.lsdir("/sys/class/block/")) : -%}
            {% let type_path = "/sys/class/block/" + dev + "/device/type"; %}
            {% let name_path = "/sys/class/block/" + dev + "/device/name"; %}
            {% let version = "Unknown"; %}
            {% let name = "Unknown"; %}
            {% if (fs.access(type_path, "f")): %}
                {% let fh = fs.open(type_path, "r"); %}
                {% let content = fh.read(5); %}
                {% fh.close(); %}
                {% if (content != null): %}
                    {% if (match(dev, regexp("mmcblk[0-9]+")) != null && match(content, regexp("MMC")) != null): %}
                        {% if (fs.access(name_path, "f")): %}
                            {% let name_fh = fs.open(name_path, "r"); %}
                            {% let name_raw = name_fh.read(128); %}
                            {% name_fh.close(); %}
                            {% if (name_raw != null): %}
                                {% let newline_match = match(name_raw, regexp("[^\r\n]+")); %}
                                {% if (newline_match != null): %}
                                {% name = newline_match[0]; %}
                                {% endif %}
                            {% endif %}
                        {% endif %}
                        {% let rev_path = "/sys/class/block/" + dev + "/device/rev"; %}
                        {% if (fs.access(rev_path, "f")): %}
                            {% let rev_fh = fs.open(rev_path, "r"); %}
                            {% let rev_raw = rev_fh.read(10); %}
                            {% rev_fh.close(); %}
                            {% let rev_match = match(rev_raw, regexp("0x[0-9a-fA-F]+")); %}
                            {% let rev = rev_match[0]; %}
                            {% if (rev == "0x05" || rev == "0x5"): %}
                                {% version = "v4.41"; %}
                            {% elif (rev == "0x06" || rev == "0x6"): %}
                                {% version = "v4.5"; %}
                            {% elif (rev == "0x07" || rev == "0x7"): %}
                                {% version = "v5.0"; %}
                            {% elif (rev == "0x08" || rev == "0x8"): %}
                                {% version = "v5.1"; %}
                            {% endif %}
                        {% endif %}
                        instance add(Alias="cpe-{{ dev }}") {
                            parameter FlashType = "eMMC";
                            parameter Name = "{{ name }}";
                            parameter Path = "/dev/{{ dev }}";
                            parameter Version = "{{ version }}";
                        }
                    {% endif %}
                {% endif %}
            {% endif %}
        {% endfor %}
        {% for (let mtd in fs.lsdir("/sys/class/mtd/")) : -%}
            {% let mtd_type_path = "/sys/class/mtd/" + mtd + "/type"; %}
            {% let mtd_name_path = "/sys/class/mtd/" + mtd + "/name"; %}
            {% let name = "Unknown"; %}
            {% if (match(mtd, regexp("mtd[0-9]+")) != null && fs.access(mtd_type_path, "f")): %}
                {% let fh = fs.open(mtd_type_path, "r"); %}
                {% let content = fh.read(10); %}
                {% fh.close(); %}
                {% if (match(content, regexp("nand")) != null): %}
                    {% if (fs.access(mtd_name_path, "f")): %}
                        {% let name_fh = fs.open(mtd_name_path, "r"); %}
                        {% let name_raw = name_fh.read(128); %}
                        {% name_fh.close(); %}
                        {% if (name_raw != null): %}
                            {% let newline_match = match(name_raw, regexp("[^\r\n]+")); %}
                            {% if (newline_match != null): %}
                                {% name = newline_match[0]; %}
                            {% endif %}
                        {% endif %}
                    {% endif %}
                    instance add(Alias="cpe-{{ mtd }}") {
                        parameter FlashType = "NAND";
                        parameter Name = "{{ name }}";
                        parameter Path = "/dev/{{ mtd }}";
                    }
                {% endif %}
            {% endif %}
        {% endfor %}
    }
}
