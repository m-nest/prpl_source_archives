/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <yajl/yajl_gen.h>
#include <yajl/yajl_parse.h>

#include <debug/sahtrace.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxj/amxj_variant.h>

#include <lcm/lcm_assert.h>

#include "cthulhu_lpm_defines.h"
#include "utils.h"

#define ME "lpm"

amxd_status_t is_valid_version_string(const char* version) {
    unsigned major1 = 0, minor1 = 0, patch1 = 0;
    amxd_status_t status = amxd_status_unknown_error;
    ASSERT_NOT_NULL(version, goto exit);

    if(sscanf(version, "%u.%u.%u", &major1, &minor1, &patch1) == 3) {
        status = amxd_status_ok;
    }

exit:
    return status;
}

int compare_version_string(const char* version1, const char* version2) {
    unsigned major1 = 0, minor1 = 0, patch1 = 0;
    unsigned major2 = 0, minor2 = 0, patch2 = 0;
    sscanf(version1, "%u.%u.%u", &major1, &minor1, &patch1);
    sscanf(version2, "%u.%u.%u", &major2, &minor2, &patch2);
    if(major1 < major2) {
        return -1;
    }
    if(major1 > major2) {
        return 1;
    }

    if(minor1 < minor2) {
        return -1;
    }
    if(minor1 > minor2) {
        return 1;
    }

    if(patch1 < patch2) {
        return -1;
    }
    if(patch1 > patch2) {
        return 1;
    }

    return 0;
}

void print_variant_as_trace(const char* prefix, amxc_var_t* var) {
    amxc_var_t var_copy;
    amxc_var_init(&var_copy);
    amxc_var_convert(&var_copy, var, AMXC_VAR_ID_JSON);
    const char* cstr = amxc_var_constcast(jstring_t, &var_copy);
    SAH_TRACEZ_INFO(ME, "%s: %s", prefix, cstr);
    amxc_var_clean(&var_copy);
}

static void add_trigger_object(amxd_object_t* log, amxc_var_t* varlist) {
    char* action = amxd_object_get_value(cstring_t, log, LM_ACTION, NULL);
    amxc_var_t* new = NULL;
    if(action && !strcmp(action, "Ignore")) {
        // Filter "Ignore" entries.
        // "Ignore" is not a valid value in tr181, because it does not reflect a new state.
        // But we keep "Ignore" Actions in the local Action table, because it shows a container was correctly restored.
        goto exit;
    }
    new = amxc_var_add(amxc_htable_t, varlist, NULL);
    amxc_var_set_type(new, AMXC_VAR_ID_HTABLE);
    amxd_object_get_params(log, new, amxd_dm_access_public);
exit:
    free(action);
}

void send_trigger(amxd_object_t* obj, const char* command_id, const char* notification_type) {
    amxc_var_t varlm;
    amxc_var_t varlist;
    amxc_var_t top;

    amxc_var_init(&varlm);
    amxc_var_set_type(&varlm, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&varlist);
    amxc_var_set_type(&varlist, AMXC_VAR_ID_LIST);
    amxc_var_init(&top);
    amxc_var_set_type(&top, AMXC_VAR_ID_HTABLE);

    if(obj) {
        // retrieve the supplied logged action from the datamodel
        amxd_object_get_params(obj, &varlm, amxd_dm_access_public);
    } else {
        // in case no log object is supplied,
        // retrieve all logged actions from the datamodel
        amxd_object_t* logs = amxd_dm_findf(get_dm(), LPM_ACTION);
        amxd_object_for_each(instance, it, logs) {
            amxd_object_t* log = amxc_llist_it_get_data(it, amxd_object_t, it);
            add_trigger_object(log, &varlist);
        }
        amxc_var_add_key(amxc_llist_t, &varlm, LM_ACTION, amxc_var_constcast(amxc_llist_t, &varlist));
    }

    if(!STRING_EMPTY(command_id)) {
        amxc_var_add_key(cstring_t, &top, CTHULHU_NOTIF_COMMAND_ID, command_id);
    }
    amxc_var_add_key(amxc_htable_t, &top, CTHULHU_NOTIF_DM_OBJ_FULL, amxc_var_constcast(amxc_htable_t, &varlm));

    SAH_TRACEZ_INFO(ME, "Sending trigger [%s]", notification_type);
    print_variant_as_trace("trigger: ", &top);
    amxd_object_trigger_signal(amxd_dm_findf(get_dm(), CTHULHU), notification_type, &top);

    amxc_var_clean(&varlm);
    amxc_var_clean(&varlist);
    amxc_var_clean(&top);
}

void add_action_entry_to_dm(amxd_dm_t* dm, policylog_t* log, const char* id) {
    amxd_trans_t trans;
    amxc_ts_t now;
    const char* errorinfo = amxc_string_get(&log->error_info, 0);
    amxc_string_t alias;
    amxc_string_init(&alias, 0);
    amxc_string_setf(&alias, "cpe-%s", id);
    const char* actionstatus = NULL;
    amxd_status_t status = amxd_status_unknown_error;

    if(errorinfo && *errorinfo) {
        actionstatus = ACTION_STATUS_VALIDATIONERROR;
    } else {
        if(log && log->policy_action && !strcmp(log->policy_action, ACTION_STATUS_UNINSTALL)) {
            // in case of Uninstall, we won't get a callback later, so status is Success immediately
            actionstatus = ACTION_STATUS_SUCCESS;
        } else {
            actionstatus = ACTION_STATUS_INPROGRESS;
        }
    }

    amxc_ts_now(&now);
    amxd_object_t* templobj = amxd_dm_findf(get_dm(), LPM_ACTION);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, templobj);
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_amxc_ts_t(&trans, LA_DATE, &now);
    amxd_trans_set_value(cstring_t, &trans, LA_ALIAS, amxc_string_get(&alias, 0));
    amxd_trans_set_value(cstring_t, &trans, LA_UUID, id);
    amxd_trans_set_value(cstring_t, &trans, LA_EVENT, log->policy_event);
    amxd_trans_set_value(cstring_t, &trans, LA_ACTION, log->policy_action);
    amxd_trans_set_value(cstring_t, &trans, LA_POLICYSCOPE, log->policy_scope);
    amxd_trans_set_value(cstring_t, &trans, LA_PREVIOUSMODULEVERSION, (log->old_version ? log->old_version : "<none>"));
    amxd_trans_set_value(cstring_t, &trans, LA_CURRENTMODULEVERSION, (log->new_version ? log->new_version : "<none>"));
    amxd_trans_set_value(cstring_t, &trans, LA_EXECENVNAME, (log->execenv ? log->execenv : "<none>"));
    amxd_trans_set_value(cstring_t, &trans, LA_FAULTMESSAGE, (errorinfo ? errorinfo : ""));
    amxd_trans_set_value(cstring_t, &trans, LA_STATUS, actionstatus);
    status = amxd_trans_apply(&trans, dm);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Could not append local policy manager log [%d]", status);
        SAH_TRACEZ_ERROR(ME, "  -> data [%s] [%s] [%s] [%s] [%s] [%s]", id, log->policy_event, log->policy_action, log->policy_scope, log->old_version, log->new_version);
        SAH_TRACEZ_ERROR(ME, "  -> data [%s]", errorinfo);
    } else {
        send_trigger(amxd_dm_findf(dm, LPM_ACTION ".[" LA_ALIAS " == \"%s\"]", amxc_string_get(&alias, 0)),
                     NULL,
                     CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_UPDATED);
    }
    amxd_trans_clean(&trans);
    amxc_string_clean(&log->error_info);
    amxc_string_clean(&alias);
}

void change_action_status(amxd_dm_t* dm, const char* id, const char* new_status) {
    amxd_trans_t trans;
    amxc_ts_t now;
    amxc_string_t log_inst_path;
    amxc_string_init(&log_inst_path, 0);
    amxc_string_setf(&log_inst_path, "%s.[%s == \"%s\"]", LPM_ACTION, LA_UUID, id);

    amxc_ts_now(&now);
    amxd_object_t* obj = amxd_dm_findf(dm, "%s", amxc_string_get(&log_inst_path, 0));
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, obj);
    amxd_trans_set_amxc_ts_t(&trans, "Date", &now);
    amxd_trans_set_value(cstring_t, &trans, LA_STATUS, new_status);
    amxd_status_t status = amxd_trans_apply(&trans, dm);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Could not update local policy manager action status [%d] [%s]", status, amxc_string_get(&log_inst_path, 0));
    } else {
        send_trigger(obj, NULL, CTHULHU_NOTIF_LOCALMANAGEMENT_ACTION_UPDATED);
    }
    amxd_trans_clean(&trans);
    amxc_string_clean(&log_inst_path);
}

void add_log_error_info(policylog_t* log, const char* info, ...) {
    va_list args;
    va_start(args, info);
    const char* currinfo = amxc_string_get(&log->error_info, 0);
    if(currinfo && *currinfo) {
        amxc_string_append(&log->error_info, "\n", 1);
    }
    amxc_string_vappendf(&log->error_info, info, args);
    SAH_TRACEZ_WARNING(ME, "%s", amxc_string_get(&log->error_info, 0));
    va_end(args);
}

void add_new_sublist(amxc_var_t* list, const char* sublist) {
    amxc_var_t slist;
    amxc_var_init(&slist);
    amxc_var_set_type(&slist, AMXC_VAR_ID_LIST);
    amxc_var_add_key(amxc_llist_t, list, sublist, amxc_var_constcast(amxc_llist_t, &slist));
}

