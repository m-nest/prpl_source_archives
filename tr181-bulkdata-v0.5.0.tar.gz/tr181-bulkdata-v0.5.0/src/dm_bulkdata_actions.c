/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <syslog.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_mqtt.h"

#include <amxd/amxd_action.h>

#define ME "actions"

static amxc_var_t* amxd_resolve_param_ref(amxd_object_t* obj,
                                          amxc_var_t* ref) {
    amxd_object_t* ref_object = NULL;
    amxd_param_t* ref_param = NULL;
    amxc_var_t* ref_value = NULL;
    amxd_dm_t* dm = amxd_object_get_dm(obj);
    char* full_ref = amxc_var_dyncast(cstring_t, ref);
    if(!full_ref) {
        return NULL;
    }
    int ref_len = strlen(full_ref);
    char* object = full_ref;
    char* param = NULL;

    for(int i = ref_len; i >= 0; i--) {
        if(full_ref[i] == '.') {
            full_ref[i] = 0;
            param = full_ref + i + 1;
            break;
        }
    }

    if(!param || !*param) {
        goto exit;
    }

    if(object[0] == 0) {
        ref_object = obj;
    } else {
        if(object[0] == '.') {
            ref_object = amxd_object_findf(obj, "%s", object);
        } else {
            ref_object = amxd_dm_findf(dm, "%s", object);
        }
    }
    ref_param = amxd_object_get_param_def(ref_object, param);
    if(!ref_param) {
        goto exit;
    }
    ref_value = &ref_param->value;

exit:
    free(full_ref);
    return ref_value;
}


amxd_status_t _check_is_none_or_in(amxd_object_t* object,
                                   amxd_param_t* param,
                                   amxd_action_t reason,
                                   const amxc_var_t* const args,
                                   amxc_var_t* const retval,
                                   void* priv) {
    amxd_status_t rv = amxd_status_unknown_error;

    rv = amxd_action_param_check_is_in(object, param, reason, args, retval, priv);

    if(rv != amxd_status_ok) {
        char* input = amxc_var_dyncast(cstring_t, args);
        if((input != NULL) && (!strcmp(input, "None"))) {
            rv = amxd_status_ok;
        }
        free(input);
    }

    return rv;
}

amxd_status_t _check_reference_is_valid(amxd_object_t* object,
                                        amxd_param_t* param UNUSED,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        amxc_var_t* const retval UNUSED,
                                        void* priv) {
    const cstring_t input_path = amxc_var_constcast(cstring_t, args);
    amxc_var_t* wildcard = (amxc_var_t*) priv;
    bool wildcard_enabled = false;

    if(reason != action_param_validate) {
        return amxd_status_function_not_implemented;
    }

    if(wildcard != NULL) {
        if(amxc_var_type_of(wildcard) == AMXC_VAR_ID_CSTRING) {
            amxc_var_t* ref_value = amxd_resolve_param_ref(object, wildcard);
            wildcard = ref_value == NULL ? wildcard : ref_value;
        }
        wildcard_enabled = amxc_var_dyncast(bool, wildcard);
    }

    if(input_path == NULL) {
        SAH_TRACEZ_ERROR(ME, "input_path is NULL");
        return amxd_status_invalid_value;
    }

    if(!wildcard_enabled && (strchr(input_path, '*') != NULL)) {
        SAH_TRACEZ_WARNING(ME, "Wildcard is not supported and Reference contains a wildcard");
        return amxd_status_invalid_value;
    }

    return 0;
}

amxd_status_t _bulkdata_profile_cleanup(amxd_object_t* object,
                                        UNUSED amxd_param_t* param,
                                        UNUSED amxd_action_t reason,
                                        UNUSED const amxc_var_t* const args,
                                        UNUSED amxc_var_t* const retval,
                                        UNUSED void* priv) {
    SAH_TRACEZ_INFO(ME, "Profile %s cleanup", amxd_object_get_name(object, AMXD_OBJECT_NAMED));
    bulkdata_stop_profile(object);
    return 0;
}

amxd_status_t _bulkdata_profile_mqtt_cleanup(amxd_object_t* object,
                                             UNUSED amxd_param_t* param,
                                             UNUSED amxd_action_t reason,
                                             UNUSED const amxc_var_t* const args,
                                             UNUSED amxc_var_t* const retval,
                                             UNUSED void* priv) {
    SAH_TRACEZ_INFO(ME, "Profile MQTT cleanup");
    bulkdata_profile_mqtt_clean(object);
    return 0;
}
