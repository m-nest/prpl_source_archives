/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* System headers */
#include <net/if.h> /* struct ifreq */
#include <string.h> /* strcmp() */
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/sysinfo.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>           /* when_null() */
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxd/amxd_object.h>           /* AMXD_OBJECT_INDEXED */
#include <amxd/amxd_object_hierarchy.h> /* amxd_object_get_path() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param_value() */
#include <amxd/amxd_transaction.h>

/* Own headers */
#include "sfpmgr_common.h"    /* sfp_cage_t */
#include "sfpmgr_ethtoolif.h" /* sfp_ethtool_t */
#include "sfpmgr_main.h"      /* sfp_get_dm() */
#include "sfpmgr_utils.h"     /* setStringParam() */
#include "optical_if.h"

static const char* const OPTICAL_INTERFACE = "Optical.Interface";
static const char* const NOT_PRESENT = "NotPresent";

/**
 * @brief Retrieves the system's uptime.
 *
 * This function fetches the system uptime using the `sysinfo` function,
 * which is part of the standard library for gathering system statistics.
 * It returns the uptime in seconds.
 *
 * @return Returns the system uptime in seconds if successful, or
 * 0 if the `sysinfo` call fails.
 */
static int get_system_uptime(void) {
    uint32_t uptime = 0;
    struct sysinfo info;

    if(sysinfo(&info) != 0) {
        SAH_TRACEZ_ERROR(ME, "sysinfo failed");
        goto exit;
    }
    uptime = info.uptime;
exit:
    return uptime;
}

/**
 * @brief Gets the optical interface status.
 *
 * @param cage_info A pointer to the `sfp_cage_t` structure containing the cage info.
 * @param if_instance A pointer to the `amxd_object_t` structure containing Optical.Interface object.
 *
 * @return Interface status
 */
static const cstring_t get_interface_status(const sfp_cage_t* cage_info,
                                            const amxd_object_t* if_instance) {
    /**
     * For all SFPs the default value of Status is NotPresent. For all SFPs for
     * which Device.Optical is not applicable, the Status should always be
     * NotPresent.
     */
    const cstring_t status = NOT_PRESENT;
    const amxc_var_t* enable_var = NULL;
    bool enable = false;

    when_null(cage_info, exit);
    when_null(if_instance, exit);

    if(sfp_type_is_optical(cage_info->sfp_type)) {
        switch(cage_info->state) {
        default:
        case SFP_STATE_REMOVED:
            status = NOT_PRESENT;
            break;
        case SFP_STATE_RX_LOS:
            status = "Down";
            break;
        case SFP_STATE_RX_LOS_CLEARED:
            enable_var = amxd_object_get_param_value(if_instance, "Enable");
            enable = amxc_var_constcast(bool, enable_var);
            status = enable ? "Up" : "Down";
            break;
        }
    }

exit:
    return status;
}

/**
 * @brief Populates the optical interface instance data in a transaction.
 *
 * @details Sets various parameters for an optical interface, namely LowerLayers,
 * Upstream and Status, in the provided transaction for later application to the
 * device model.
 *
 * @param cage_info A pointer to the `sfp_cage_t` structure containing the cage info.
 * @param if_instance A pointer to the `amxd_object_t` structure containing Optical.Interface object.
 * @param transaction A pointer to the `amxd_trans_t` structure representing the transaction.
 */
static void optical_if_populate_instance_data(const sfp_cage_t* cage_info,
                                              amxd_object_t* if_instance,
                                              amxd_trans_t* transaction) {
    setStringParam(transaction, "LowerLayers", OPTICAL_IF_LOWER_LAYER);
    setStringParam(transaction, "Status", get_interface_status(cage_info, if_instance));
}

/**
 * @brief Updates the optical interface instance in the system.
 *
 * @details Retrieves and updates the optical interface object with data from
 * the specified cage information, and applies the changes to the device model.
 * It also updates the transmission enabled status based on the cage data.
 *
 * @param cage_info A pointer to the `sfp_cage_t` structure holding the cage info.
 *
 * @return Returns `amxd_status_ok` on success, or `SFPMGR_INVALID` on failure.
 */
int optical_if_update_interface_instance(sfp_cage_t* cage_info) {
    const uint32_t index = cage_info->cage_id; /* alias */
    const char* intf_format = "Optical.Interface.%d.";
    int rv = SFPMGR_INVALID;
    optical_info_t* info = NULL;

    amxd_object_t* optical_if_object = amxd_dm_findf(sfp_get_dm(), intf_format, index);
    amxd_trans_t static_transaction;
    amxd_trans_init(&static_transaction);

    when_null_trace(optical_if_object, exit, ERROR, "Couldnt retrieve Optical.Interface.%d", index);

    if(optical_if_object->priv == NULL) {
        info = (optical_info_t*) calloc(1, sizeof(optical_info_t));
        when_null_trace(info, exit, ERROR, "Couldnt allocate optical info");
        optical_if_object->priv = info;
    } else {
        info = (optical_info_t*) optical_if_object->priv;
    }

    info->last_change = get_system_uptime();
    info->cage_info = cage_info;          /* back reference to cage information */

    amxd_trans_set_attr(&static_transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&static_transaction, optical_if_object);

    optical_if_populate_instance_data(cage_info, optical_if_object, &static_transaction);

    /* Save the changes */
    when_failed_trace(amxd_trans_apply(&static_transaction, sfp_get_dm()), exit, ERROR, "Interface object update failed");
    rv = SFPMGR_SUCCESS;

exit:
    // Clean up transaction resources
    amxd_trans_clean(&static_transaction);

    return rv;
}

/**
 * @brief Handles changes in the optical interface enable state.
 *
 * @details This function manages the enable state change of the optical interface.
 * - On enabling, it updates the hardware TX and checks the link status.
 * - On disabling, it updates the DM status and brings down the network interface.
 *
 * @param data Data associated with the signal, containing parameters like "Enable" and "index".
 *
 * @return None
 */
void _optical_interface_enable_changed(UNUSED const char* const sig_name,
                                       const amxc_var_t* const data,
                                       UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(sfp_get_dm(), data);
    sfp_cage_t* cage_info = NULL;
    optical_info_t* optical_info = NULL;
    bool enable;
    int rv = SFPMGR_INVALID;

    if(data == NULL) {
        SAH_TRACEZ_ERROR(ME, "data is NULL");
        return;
    }
    if(obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "optical if obj is NULL");
        return;
    }
    enable = GETP_BOOL(data, "parameters.Enable.to");

    optical_info = (optical_info_t*) obj->priv;
    when_null(optical_info, exit);

    cage_info = (sfp_cage_t*) optical_info->cage_info;
    when_null(cage_info, exit);

    SAH_TRACEZ_INFO(ME, "%s.%d: enable=%d", OPTICAL_INTERFACE, cage_info->cage_id, enable);

    const bool is_optical = sfp_type_is_optical(cage_info->sfp_type);
    when_false_trace(is_optical, exit, INFO, "%s.%d: not applicable",
                     OPTICAL_INTERFACE, cage_info->cage_id);

    if(enable == false) {
        rv = set_if_state(cage_info->ifName, 0);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to set intf down :%s, rv:%d", cage_info->ifName, rv);
        }
    } else {
        rv = set_if_state(cage_info->ifName, 1);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to set intf up :%s, rv:%d", cage_info->ifName, rv);
        }
    }

    /* Update link status */
    optical_interface_link_status(cage_info);

exit:
    return;
}

/**
 * @brief Updates the link status of the optical interface based on the SFP state.
 *
 * @param cage_info Pointer to the `sfp_cage_t` structure containing optical
 * interface and hardware state information.
 *
 * @return int Returns `SFPMGR_SUCCESS` on success, or `SFPMGR_INVALID` on failure.
 */
int optical_interface_link_status (sfp_cage_t* cage_info) {
    amxd_object_t* if_instance = amxd_dm_findf(sfp_get_dm(),
                                               "Optical.Interface.%d", cage_info->cage_id);
    when_null_trace(if_instance, exit, ERROR, "Optical.Interface instance not found");

    optical_info_t* optical_info = (optical_info_t*) if_instance->priv;
    when_null_trace(optical_info, exit, ERROR, "Optical.Interface without optical info");

    const cstring_t const status = get_interface_status(cage_info, if_instance);

    const amxc_var_t* const status_old = amxd_object_get_param_value(if_instance, "Status");
    when_null_trace(status_old, exit, ERROR, "%s.%d: failed to get Status",
                    OPTICAL_INTERFACE, cage_info->cage_id);
    const cstring_t const status_old_cstr = GET_CHAR(status_old, NULL);
    when_null_trace(status_old_cstr, exit, ERROR, "Failed to extract C string");

    const bool status_changed = (strcmp(status, status_old_cstr) != 0);
    when_false(status_changed, exit);

    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, if_instance);
    amxd_trans_set_value(cstring_t, &trans, "Status", status);
    amxd_trans_apply(&trans, sfp_get_dm());
    optical_info->last_change = get_system_uptime();
    amxd_trans_clean(&trans);

exit:
    return SFPMGR_SUCCESS;
}

/**
 * @brief Handles the read operation for the LastChange parameter of an optical interface.
 *
 * @param object Pointer to the `amxd_object_t` representing the optical interface.
 * @param reason The action reason, should be `action_param_read`.
 * @param retval Pointer to `amxc_var_t` to store the result (time since last change).
 *
 * @return amxd_status_t Returns `amxd_status_ok` on success, or an error code on failure.
 */
amxd_status_t _lastchange_on_read(amxd_object_t* const object,
                                  UNUSED amxd_param_t* const param,
                                  amxd_action_t reason,
                                  UNUSED const amxc_var_t* const args,
                                  amxc_var_t* const retval,
                                  UNUSED void* priv) {
    amxd_status_t rv = amxd_status_unknown_error;
    optical_info_t* optical_info = NULL;
    uint32_t since_change = 0;
    uint32_t uptime = 0;
    char* path = NULL;

    SAH_TRACEZ_IN(ME);
    if(reason != action_param_read) {
        SAH_TRACEZ_ERROR(ME, "wrong reason, expected action_param_read(%d) got %d", action_param_read, reason);
        rv = amxd_status_invalid_action;
        goto exit;
    }

    /* Check if retval is NULL */
    if(retval == NULL) {
        SAH_TRACEZ_ERROR(ME, "retval is NULL");
        rv = amxd_status_invalid_value;
        goto exit;
    }

    /* retval needs to be set, in case of error lastchange will be 0 */
    amxc_var_set_uint32_t(retval, 0);

    /* Check if the object is NULL */
    if(object == NULL) {
        SAH_TRACEZ_ERROR(ME, "optical object cannot be null");
        rv = amxd_status_invalid_value;
        goto exit;
    }

    path = amxd_object_get_path(object, AMXD_OBJECT_INDEXED);
    /**
     * This function is called when the object with the LastChange parameter is
     * is being created. Then 'object->priv' is still NULL. Therefore do not log
     * an error if 'object->priv' is NULL.
     */
    if(object->priv == NULL) {
        SAH_TRACEZ_ERROR(ME, "object %s has no private data", path);
        rv = amxd_status_invalid_value;
        goto exit;
    }

    optical_info = (optical_info_t*) object->priv;

    uptime = get_system_uptime();
    if(uptime < optical_info->last_change) {
        SAH_TRACEZ_ERROR(ME, "UpTime is smaller than last change");
        rv = amxd_status_invalid_value;
        goto exit;
    }
    since_change = uptime - optical_info->last_change;
    if(amxc_var_set_uint32_t(retval, since_change) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to set lastchange");
        goto exit;
    }
    rv = amxd_status_ok;

exit:
    if(path) {
        free(path);
    }
    return rv;
}

/**
 * @brief Updates the optical signal levels (transmit and receive) for an optical interface.
 *
 * @param sfp_ethtool Pointer to the `sfp_ethtool_t` structure containing the signal power values.
 *
 * @return int Returns 0 on success, or -1 if the operation fails.
 */
int optical_interface_update_signal_level_params(int cage_id, sfp_ethtool_t* sfp_ethtool) {
    amxd_trans_t trans;
    amxd_object_t* if_instance = NULL;
    amxd_status_t dm_status;
    int rv = -1, tx_power = 0, rx_power = 0;

    when_null_trace(sfp_ethtool, exit, ERROR, "sfp_ethtool is NULL");

    tx_power = sfp_ethtool->tx_power * 100;
    rx_power = sfp_ethtool->rx_power * 100;

    // Initialize the transaction
    amxd_trans_init(&trans);

    // Find the device instance object using the cage ID
    if_instance = amxd_dm_findf(sfp_get_dm(), "Optical.Interface.%d", cage_id);
    when_null_trace(if_instance, exit, ERROR, "Failed to find device instance for cage ID %d", cage_id);

    // Set the transaction attributes
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, if_instance);

    setint32Param(&trans, "TransmitOpticalLevel", tx_power);
    setint32Param(&trans, "OpticalSignalLevel", rx_power);

    // Apply the transaction
    dm_status = amxd_trans_apply(&trans, sfp_get_dm());
    if(dm_status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply DM transaction, status=%d", dm_status);
        rv = -1;
        goto exit;
    }

    //successfull execution
    rv = 0;

exit:
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief Set the state of a network interface.
 *
 * This function sets the state of the specified network interface to either up or down.
 *
 * @param if_name The name of the network interface.
 * @param up A flag indicating whether to bring the interface up (1) or down (0).
 * @return 0 on success, -1 on failure.
 */
int set_if_state(const char* if_name, int up) {
    int fd = -1;
    struct ifreq ifr;
    int rv = -1;

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    when_true_trace(fd < 0, exit, ERROR, "Unable to change state of %s, failed to open socket", if_name);

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, if_name, IFNAMSIZ - 1);

    when_true_trace(ioctl(fd, SIOCGIFFLAGS, &ifr) < 0, exit, ERROR, "Failed to get flags for interface %s", if_name);

    if(up) {
        ifr.ifr_flags |= IFF_UP;  // Set the IFF_UP flag to bring the interface up
    } else {
        ifr.ifr_flags &= ~IFF_UP; // Clear the IFF_UP flag to bring the interface down
    }

    when_true_trace(ioctl(fd, SIOCSIFFLAGS, &ifr) < 0, exit, ERROR, "Failed to set interface %s %s", if_name, up ? "up" : "down");
    rv = 0;
    SAH_TRACEZ_INFO(ME, "Set interface %s %d", if_name, up);

exit:
    if(fd >= 0) {
        close(fd);
    }
    return rv;
}

optical_info_t* get_sfp_cage_info_optical(int32_t cage_index) {
    int rc;
    char sfp_path[128];
    const char* intf_format = "Optical.Interface.%d.";
    rc = snprintf(sfp_path, 128, intf_format, cage_index);
    when_true_trace(rc < 0 || rc >= 128, exit, ERROR, "snprintf() failed rc=%d", rc);
    amxd_object_t* optical_if_object = amxd_dm_findf(sfp_get_dm(), sfp_path, cage_index);
    when_null(optical_if_object, exit);
    optical_info_t* optical_info = (optical_info_t*) optical_if_object->priv;
    when_null(optical_info, exit);
    return optical_info;

exit:
    SAH_TRACEZ_ERROR(ME, "optical_info not found for cage %d", cage_index);
    return NULL;
}

