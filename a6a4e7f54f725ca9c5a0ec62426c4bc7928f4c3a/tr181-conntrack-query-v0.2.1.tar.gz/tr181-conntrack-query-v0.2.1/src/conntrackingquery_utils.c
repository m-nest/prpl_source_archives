/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "conntrackingquery.h"
#include <signal.h>
#include <netdb.h>

#define OBJECT_NAME(OBJECT) amxd_object_get_name(OBJECT, AMXD_OBJECT_NAMED)

static amxc_llist_t query_llist;
static bool query_init = false;

/**
 * @brief Creates and initializes a new query object.
 *
 * Allocates memory for a query, initializes its fields, links it to the given
 * data model object, and adds it to the global query list.
 *
 * @param object  Pointer to the data model object associated with the query.
 * @return Pointer to the newly created query object, or NULL on failure.
 */

query_t* query_create(amxd_object_t* object) {
    query_t* query = NULL;

    when_null(object, exit);

    query = calloc(1, sizeof(query_t));
    when_null(query, exit);

    if(!query_init) {
        amxc_llist_init(&query_llist);
        query_init = true;
    }

    amxc_string_init(&query->src_ip, 64);
    amxc_string_init(&query->dst_ip, 64);
    amxc_string_init(&(query->name), 64);
    amxc_string_init(&(query->protocol), 64);
    amxc_string_init(&(query->src_port), 64);
    amxc_string_init(&(query->dst_port), 64);
    amxc_string_init(&(query->event), 64);

    query->object = object;
    amxc_llist_append(&query_llist, &query->it);

    object->priv = query;

exit:
    return query;
}

/**
 * @brief Deletes a query object and frees its associated resources.
 *
 * Removes the query from the global list, cleans up its IP strings and timer,
 * and frees the allocated memory.
 *
 * @param query  Pointer to the query object to be deleted.
 */

void query_delete(query_t* query) {

    amxc_llist_it_take(&query->it);

    amxc_string_clean(&query->src_ip);
    amxc_string_clean(&query->dst_ip);
    amxc_string_clean(&(query->name));
    amxc_string_clean(&(query->protocol));
    amxc_string_clean(&(query->src_port));
    amxc_string_clean(&(query->dst_port));
    amxc_string_clean(&(query->event));
    free(query);
    query = NULL;
}

/**
 * @brief Finds a query object by its associated instance name.
 *
 * Searches the global query list for a query whose associated object's name
 * matches the given name.
 *
 * @param name  Name of the query instance to search for.
 * @return Pointer to the matching query object, or NULL if not found.
 */

query_t* query_find_by_name(const char* name) {
    query_t* query = NULL;

    when_null(name, exit);

    amxc_llist_for_each(it, &query_llist) {
        query = amxc_llist_it_get_data(it, query_t, it);
        if(strcmp(name, OBJECT_NAME(query->object)) == 0) {
            return query;
        }
    }

exit:
    return NULL;
}

/**
 * @brief Finds a query object by its associated process ID.
 *
 * Searches the global query list for a query whose process ID matches
 * the given PID.
 *
 * @param pid  Process ID to search for.
 * @return Pointer to the matching query object, or NULL if not found.
 */

query_t* query_find_by_pid(pid_t pid) {
    query_t* query = NULL;
    amxc_llist_for_each(it, &query_llist) {
        query = amxc_llist_it_get_data(it, query_t, it);
        when_null(query, exit);
        if(query->process && (pid == query->process->pid)) {
            return query;
        }
    }

exit:
    return NULL;
}


/**
 * @brief Finds a query object by its index.
 *
 * Searches the global query list for a query whose index matches
 * the given value.
 *
 * @param index  Index value to search for.
 * @return Pointer to the matching query object, or NULL if not found.
 */

query_t* query_find_by_index(const uint32_t index) {
    query_t* query = NULL;
    amxc_llist_for_each(it, &query_llist) {
        query = amxc_llist_it_get_data(it, query_t, it);
        if(query->index == index) {
            return query;
        }
    }
    return NULL;
}

/**
 * @brief Sets the source or destination IP address for a query.
 *
 * Updates the query's IP address field based on the provided value.
 * If the address is empty or a default value like "0.0.0.0" or "::/0",
 * the field is reset.
 *
 * @param query       Pointer to the query object.
 * @param ip_address  IP address to set.
 * @param source      If true, sets the source IP; otherwise, sets the destination IP.
 * @return true if the address was processed successfully, false otherwise.
 */
bool query_set_address(query_t* query, const char* ip_address, bool source) {
    bool retval = false;
    amxc_string_t* address = NULL;

    when_null(query, exit);

    if(source) {
        address = &query->src_ip;
    } else {
        address = &query->dst_ip;
    }

    if((ip_address == NULL) || (ip_address[0] == '\0')) {
        amxc_string_reset(address);
        retval = true;
        goto exit;
    }

    if((strcmp(ip_address, "0.0.0.0") != 0) && (strcmp(ip_address, "::/0") != 0)) {
        amxc_string_set(address, ip_address);
    } else {
        amxc_string_reset(address);
    }

    retval = true;

exit:
    return retval;
}

/**
 * @brief Sets the protocol value for a query.
 *
 * Updates the query's protocol field with the provided string.
 *
 * @param query     Pointer to the query object.
 * @param protocol  Protocol string to set.
 * @return true if the protocol was set successfully, false otherwise.
 */
bool query_set_protocol(query_t* query, const char* protocol) {

    bool retval = false;
    when_null(query, exit);

    if((protocol == NULL) || (protocol[0] == '\0')) {
        amxc_string_reset(&query->protocol);
    } else {
        amxc_string_set(&query->protocol, protocol);
    }
    retval = true;

exit:
    return retval;
}

/**
 * @brief Validates a port string as a numeric value within valid port range.
 *
 * This API validates that a port string is either empty (allowed, means no filtering)
 * or a valid numeric port in range 0-65535. This is a dedicated validation API
 * that can be called from ODL validators or internal functions.
 *
 * @param port_str  Port value as a string (can be NULL or empty).
 * @return true if the port string is valid (empty or 0-65535), false otherwise.
 */
bool validate_port_range(const char* port_str) {
    char* end_ptr = NULL;
    long port_val;

    if((port_str == NULL) || (port_str[0] == '\0')) {
        return true;  /* Empty is valid */
    }

    /* Use strtol for proper numeric validation */
    errno = 0;
    port_val = strtol(port_str, &end_ptr, 10);

    /* Check for conversion errors */
    if(errno != 0) {
        return false;  /* Conversion error (overflow/underflow) */
    }

    /* Check if entire string was consumed (no trailing garbage) */
    if(*end_ptr != '\0') {
        return false;  /* Non-numeric characters found */
    }

    /* Validate port range (0-65535) */
    if((port_val < 0) || (port_val > 65535)) {
        return false;  /* Out of valid port range */
    }

    return true;
}

/**
 * @brief Sets the source or destination port for a query.
 *
 * Updates the query's port field based on the provided string.
 * Uses validate_port_range() to ensure strict validation.
 * If the port is empty or invalid, the field is reset.
 *
 * @param query     Pointer to the query object.
 * @param port_str  Port value as a string.
 * @param source    If true, sets the source port; otherwise, sets the destination port.
 * @return true if the port was processed successfully, false otherwise.
 */
bool query_set_port(query_t* query, const char* port_str, bool source) {

    bool retval = false;
    amxc_string_t* port = NULL;

    when_null(query, exit);

    if(source) {
        port = &query->src_port;
    } else {
        port = &query->dst_port;
    }

    if((port_str == NULL) || (port_str[0] == '\0')) {
        amxc_string_reset(port);
        retval = true;
        goto exit;
    }

    /* Validate port using dedicated API */
    if(validate_port_range(port_str)) {
        amxc_string_set(port, port_str);
        retval = true;
    } else {
        amxc_string_reset(port);
        SAH_TRACEZ_INFO(ME, "Invalid port value: %s (must be 0-65535 or empty)", port_str);
    }

exit:
    return retval;

}

/**
 * @brief Sets the event filter value for a query.
 *
 * Updates the query's event filter field with the provided string.
 *
 * @param query     Pointer to the query object.
 * @param prot  Protocol string to set.
 * @return true if the protocol was set successfully, false otherwise.
 */
bool query_set_event_filter(query_t* query, const char* event_filter) {

    bool retval = false;
    when_null(query, exit);

    if((event_filter == NULL) || (event_filter[0] == '\0')) {
        amxc_string_reset(&query->event);
    } else {
        amxc_string_set(&query->event, event_filter);
    }
    retval = true;

exit:
    return retval;
}

/**
 * @brief Cleans up a query object associated with a data model instance.
 *
 * Stops any running worker associated with the query, deletes the query,
 * and clears the instance's private data.
 *
 * @param templ     Template object (unused).
 * @param instance  Instance object whose query is to be cleaned up.
 * @param priv      Private data (unused).
 * @return Always returns 1.
 */

int query_cleanup(UNUSED amxd_object_t* templ, amxd_object_t* instance, UNUSED void* priv) {
    query_t* query = NULL;

    when_null(instance, exit);

    query = (query_t*) instance->priv;
    when_null(query, exit);
    stop_notify_query_worker(query);

    query_delete(query);
    instance->priv = NULL;

exit:
    return 1;
}


/**
 * @brief Retrieves the string value of a parameter from a data model object.
 *
 * Gets the value of the specified parameter from the given object and returns it
 * as a constant string.
 *
 * @param object  Pointer to the data model object.
 * @param name    Name of the parameter to retrieve.
 * @return The parameter value as a string, or NULL if not found.
 */

const char* object_da_string(amxd_object_t* const object, const char* name) {
    const char* res = NULL;
    const amxc_var_t* var = NULL;

    when_null(object, out);
    when_str_empty(name, out);

    var = amxd_object_get_param_value(object, name);
    when_not_null(var, assign);
    goto out;
assign:
    res = amxc_var_constcast(cstring_t, var);
out:
    return res;
}

