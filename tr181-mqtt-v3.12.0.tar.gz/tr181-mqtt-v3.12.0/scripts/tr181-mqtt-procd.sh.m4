#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-mqtt"
PROG="/usr/bin/tr181-mqtt"
datamodel_root="MQTT"
PROG_OPTIONS=""

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

#preservice_hook() {
#    logger -s "pre-service hook ${name}"
#}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    #preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

fail() {
    /etc/init.d/uspagent stop
    /etc/init.d/tr181-localagent stop
    /etc/init.d/tr181-mqtt start
    /etc/init.d/tr181-localagent start
    /etc/init.d/uspagent start
}

extra_command fail "Failing ${name} service"
