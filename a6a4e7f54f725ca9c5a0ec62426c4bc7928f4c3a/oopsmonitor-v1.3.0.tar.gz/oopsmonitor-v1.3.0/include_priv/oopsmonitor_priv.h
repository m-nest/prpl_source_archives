/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__OOPSMONITOR_PRIV_H__)
#define __OOPSMONITOR_PRIV_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define _GNU_SOURCE

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>

#include <filetransfer/filetransfer.h>

#define DEFAULT_TRACE_ZONE_NAME "oopsmonitor"
#define MAX_FILE_NAME 256

typedef struct dmesg_info {
    struct tm time;
    char* process;
    char* reason;
    char* lastinstr;
} dmesg_info_t;

amxd_dm_t* get_dm(void);
amxo_parser_t* get_parser(void);
amxd_object_t* get_object(const char* path);
amxd_object_t* get_root_object(void);
int copy(const char* spath, const char* dpath, bool del_source);
int oops_add_instance(amxd_trans_t* trans, dmesg_info_t* dmesg_info, const char* file_name);
int dmesg_parse_file(const char* file_path, dmesg_info_t* dmesg_info);
int scan_oops_dir(const char* path);
//entry point function
int _oopsmonitor_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);
amxd_status_t _RemoveAllKernelFaults(amxd_object_t* root_object,
                                     amxd_function_t* func,
                                     amxc_var_t* args,
                                     amxc_var_t* ret);
amxd_status_t _Remove(amxd_object_t* object,
                      amxd_function_t* func,
                      amxc_var_t* args,
                      amxc_var_t* ret);
amxd_status_t _Upload(amxd_object_t* object,
                      amxd_function_t* func,
                      amxc_var_t* args,
                      amxc_var_t* ret);
void _oops_app_start(const char* const sig_name,
                     const amxc_var_t* const data,
                     void* const priv);
void _oops_instance_removed(const char* const event_name,
                            const amxc_var_t* const event_data,
                            void* const priv);

bool upload_cb(ftx_request_t* req, void* userdata);

#ifdef __cplusplus
}
#endif

#endif // __OOPSMONITOR_PRIV_H__