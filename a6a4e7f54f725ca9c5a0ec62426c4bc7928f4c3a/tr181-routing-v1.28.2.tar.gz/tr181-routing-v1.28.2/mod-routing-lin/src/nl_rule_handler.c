/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <net/if.h>
#include <netlink/netlink.h>
#include <netlink/route/rule.h>
#include <netlink/route/addr.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include "mod_routing_lin.h"
#define ME "mod-routing"

static int rule_set_iif(struct rtnl_rule* rule, const char* iif) {
    int rv = 0;
    if(!str_empty(iif)) {
        rv = rtnl_rule_set_iif(rule, iif);
    }
    return rv;
}

static int rule_set_oif(struct rtnl_rule* rule, const char* oif) {
    int rv = 0;
    if(!str_empty(oif)) {
        rv = rtnl_rule_set_oif(rule, oif);
    }
    return rv;
}

static int rule_set_proto(struct rtnl_rule* rule, int32_t proto) {
    int rv = -1;
    when_true_status(proto < 0, exit, rv = 0);
    when_true_trace(proto > UINT8_MAX, exit, ERROR, "IP protocol is %d but netlink only knows protocols up to 255", proto);
    rtnl_rule_set_ipproto(rule, proto);
    rv = 0;
exit:
    return rv;
}

static void rule_set_prio(struct rtnl_rule* rule, int32_t priority) {
    when_true(priority < 0, exit);
    rtnl_rule_set_prio(rule, priority);
exit:
    return;
}

static void rule_set_table(struct rtnl_rule* rule, uint32_t table) {
    when_true(table == 0, exit);
    rtnl_rule_set_table(rule, table);
exit:
    return;
}

static int rule_set_source_port_range(struct rtnl_rule* rule, const amxc_var_t* data) {
    int rv = 0;
    int32_t source_port = GET_INT32(data, "SourcePort");
    int32_t source_port_max = GET_INT32(data, "SourcePortRangeMax");

    when_true(source_port < 0, exit);

    if(source_port_max > 0) {
        rv = rtnl_rule_set_sport_range(rule, source_port, source_port_max);
    } else {
        rv = rtnl_rule_set_sport(rule, source_port);
    }
exit:
    return rv;
}

static int rule_set_dest_port_range(struct rtnl_rule* rule, const amxc_var_t* data) {
    int rv = 0;
    int32_t dest_port = GET_INT32(data, "DestPort");
    int32_t dest_port_max = GET_INT32(data, "DestPortRangeMax");

    when_true(dest_port < 0, exit);

    if(dest_port_max > 0) {
        rv = rtnl_rule_set_dport_range(rule, dest_port, dest_port_max);
    } else {
        rv = rtnl_rule_set_dport(rule, dest_port);
    }
exit:
    return rv;
}

static void rule_set_forwarding_policy(struct rtnl_rule* rule, const amxc_var_t* data) {
    int32_t mark = GET_INT32(data, "ForwardingPolicy");
    uint32_t mask = GET_UINT32(data, "FwMask");

    when_true(mark <= 0, exit);

    rtnl_rule_set_mark(rule, mark);
    rtnl_rule_set_mask(rule, mask);

exit:
    return;
}

static void rule_set_ip_version(struct rtnl_rule* rule, int32_t ip_version) {
    if(rtnl_rule_get_family(rule) != AF_UNSPEC) {
        // IP version was set already
        return;
    }

    if(ip_version == 6) {
        rtnl_rule_set_family(rule, AF_INET6);
    } else {
        // If no version is specified, default to AF_INET as a version is required.
        rtnl_rule_set_family(rule, AF_INET);
    }
}

static int rule_set_src_prefix(struct rtnl_rule* rule, const char* prefix) {
    int rv = 0;
    if(!str_empty(prefix)) {
        struct nl_addr* dest = NULL;
        if(nl_addr_parse(prefix, AF_UNSPEC, &dest) < 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse prefix %s", prefix);
            rv = -1;
            goto exit;
        } else {
            rv = rtnl_rule_set_src(rule, dest);
            when_failed_trace(rv, exit, ERROR, "Failed to set %s as source prefix for rule", prefix);
        }
    }
exit:
    return rv;
}

static int rule_set_dst_prefix(struct rtnl_rule* rule, const char* prefix) {
    int rv = 0;
    if(!str_empty(prefix)) {
        struct nl_addr* dest = NULL;
        if(nl_addr_parse(prefix, AF_UNSPEC, &dest) < 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse prefix %s", prefix);
            rv = -1;
            goto exit;
        } else {
            rv = rtnl_rule_set_dst(rule, dest);
            when_failed_trace(rv, exit, ERROR, "Failed to set %s as destination prefix for rule", prefix);
        }
    }
exit:
    return rv;
}

static void free_rule(struct rtnl_rule* rule) {
    struct nl_addr* addr = NULL;
    when_null(rule, exit);

    addr = rtnl_rule_get_dst(rule);
    if(addr != NULL) {
        nl_addr_put(addr);
    }
    addr = rtnl_rule_get_src(rule);
    if(addr != NULL) {
        nl_addr_put(addr);
    }
    rtnl_rule_put(rule);
exit:
    return;
}

static int nl_rule_action(const amxc_var_t* data, unsigned short action_type) {
    struct nl_sock* sock = NULL;
    struct rtnl_rule* rule = NULL;
    int rv = -1;

    sock = init_netlink_socket();
    when_null_trace(sock, exit, ERROR, "Failed to initialize netlink socket");

    rule = rtnl_rule_alloc();
    when_null_trace(rule, exit, ERROR, "Failed to allocate rule object");

    when_failed_trace(rule_set_iif(rule, GET_CHAR(data, "iif")), exit, ERROR, "Failed to set iif");
    when_failed_trace(rule_set_oif(rule, GET_CHAR(data, "oif")), exit, ERROR, "Failed to set oif");
    when_failed_trace(rule_set_src_prefix(rule, GET_CHAR(data, "SourceIPPrefix")), exit, ERROR, "Failed to set source prefix");
    when_failed_trace(rule_set_dst_prefix(rule, GET_CHAR(data, "DestIPPrefix")), exit, ERROR, "Failed to set destination prefix");
    when_failed_trace(rule_set_source_port_range(rule, data), exit, ERROR, "Failed to set source port range");
    when_failed_trace(rule_set_dest_port_range(rule, data), exit, ERROR, "Failed to set destination port range");
    when_failed_trace(rule_set_proto(rule, GET_INT32(data, "Protocol")), exit, ERROR, "Failed to set protocol");
    rule_set_prio(rule, GET_INT32(data, "Priority"));
    rule_set_table(rule, GET_UINT32(data, "ID"));
    rule_set_forwarding_policy(rule, data);
    rule_set_ip_version(rule, GET_INT32(data, "IPVersion"));
    rtnl_rule_set_action(rule, RTN_UNICAST);

    if(action_type == RTM_NEWRULE) {
        rv = rtnl_rule_add(sock, rule, NLM_F_CREATE);
        when_true_trace(rv < 0, exit, ERROR, "Failed to add rule with error %s", nl_geterror(rv));
    } else if(action_type == RTM_DELRULE) {
        rv = rtnl_rule_delete(sock, rule, 0);
        when_true_trace(rv < 0, exit, ERROR, "Failed to delete rule with error %s", nl_geterror(rv));
    }
    rv = 0;
exit:
    free_rule(rule);
    nl_socket_free(sock);
    return rv;
}

int nl_rule_add(const amxc_var_t* data) {
    SAH_TRACEZ_IN(ME);
    int rv = nl_rule_action(data, RTM_NEWRULE);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

int nl_rule_del(const amxc_var_t* data) {
    SAH_TRACEZ_IN(ME);
    int rv = nl_rule_action(data, RTM_DELRULE);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
