/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "tr181-dns.h"
#include "test_dns_zone.h"
#include "mock.h"

static amxd_dm_t* dm = NULL;
static amxo_parser_t* parser = NULL;

int test_setup(void** state) {
    expect_check_set_interface("br-lan", 4000, 86400, 0);
    expect_check_set_interface("br-guest", 4000, 86400, 0);
    expect_check_set_interface("lo", 4000, 86400, 0);
    expect_check_set_service("dns-1", "Device.Logical.Interface.2", "17,6", true, 0, 53);
    expect_check_set_service("dns-2", "Device.Logical.Interface.3", "17,6", true, 0, 53);
    expect_check_set_service("dns-3", "Device.IP.Interface.1", "17,6", true, 0, 53);
    expect_check_add_server(true, "eth0", "ra-1", "2a02:1802:94:4200::10");
    expect_check_add_host("prplOS2", "br-lan", "192.168.10.1", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a01,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b01");
    expect_check_add_host("PC", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    dns_unit_test_setup(state, true);
    dm = amxut_bus_dm();
    parser = amxut_bus_parser();
    amxut_bus_handle_events();
    return 0;
}

int test_teardown(void** state) {
    amxd_trans_t trans;

    print_message("teardown: remove instance 'DNS.Relay.Forwarding.dns-1.'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Relay.Forwarding.");
    amxd_trans_del_inst(&trans, 0, "ra-1");
    expect_check_remove_server("ra-1");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    print_message("teardown: remove all instances of 'DNS.Relay.Config.'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Relay.Config.");
    amxd_trans_del_inst(&trans, 0, "lan");
    amxd_trans_del_inst(&trans, 0, "guest");
    amxd_trans_del_inst(&trans, 0, "lo");
    expect_check_remove_interface("lo");
    expect_check_remove_interface("br-guest");
    expect_check_remove_interface("br-lan");
    expect_check_delete_service("dns-3");
    expect_check_delete_service("dns-2");
    expect_check_delete_service("dns-1");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    dns_unit_test_teardown(state);
    dm = NULL;
    parser = NULL;
    return 0;
}

void test_zone_add(UNUSED void** state) {
    amxd_trans_t trans;

    print_message("step: add 1 instance of 'DNS.Zone.'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.");
    amxd_trans_add_inst(&trans, 0, "zone-1");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "Name", "test.com");
    amxd_trans_set_value(cstring_t, &trans, "Interface", "Device.Logical.Interface.2.");
    print_message("expectation: 'add_host' of the dns controller is not called because there are no instances of Host\n");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    print_message("step: add 1 instance of 'DNS.Zone.zone-1.Host'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host");
    amxd_trans_add_inst(&trans, 0, "host-1");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "Name", "stark,hue");
    amxd_trans_set_value(cstring_t, &trans, "Host", "Device.Hosts.Host.5.");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    print_message("expectation: 'add_host' of the dns controller is called because there are instances of Host\n");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "192.168.10.15", "");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15", "");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    amxut_bus_handle_events();
}

void test_zone_change_hostname(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host.host-1");
    amxd_trans_set_value(cstring_t, &trans, "Name", "hue");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("stark", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_remove_host("stark", "br-lan");
    expect_check_remove_host("hue", "br-lan");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15", "");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    amxut_bus_handle_events();
}

void test_zone_add_host_not_active(UNUSED void** state) {
    amxd_trans_t trans;

    print_message("step: add 1 instance of 'DNS.Zone.zone-1.Host'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host");
    amxd_trans_add_inst(&trans, 0, "host-2");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "Name", "lannister,baggins");
    amxd_trans_set_value(cstring_t, &trans, "Host", "Device.Hosts.Host.4.");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    print_message("expectation: 'add_host' of the dns controller is not called because Hosts.Host.4.Active=0\n");
    amxut_bus_handle_events();
}

void test_zone_add_existing_host(UNUSED void** state) {
    amxd_trans_t trans;

    print_message("step: add 1 disabled instance of 'DNS.Zone.zone-1.Host'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host");
    amxd_trans_add_inst(&trans, 0, "host-3");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    amxd_trans_set_value(cstring_t, &trans, "Name", "skywalker,PC,holmes");
    amxd_trans_set_value(cstring_t, &trans, "Host", "Device.Hosts.Host.2.");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    print_message("expectation: 'add_host' of the dns controller is not called because the Enable=0\n");
    amxut_bus_handle_events();

    print_message("step: Enable 'DNS.Zone.zone-1.Host.host-3'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host.host-3.");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    print_message("expectation: 'add_host' of the dns controller is called\n");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    amxut_bus_handle_events();
}

void test_zone_change_domain(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.");
    amxd_trans_set_value(cstring_t, &trans, "Name", "brick.com");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    //remove all hosts
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_remove_host("hue", "br-lan");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("skywalker", "br-lan");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "test.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "test.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("holmes", "br-lan");

    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15", "");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    amxut_bus_handle_events();
}

void test_zone_activate_host_from_hosts(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Hosts.Host.disabled.");
    amxd_trans_set_value(bool, &trans, "Active", true);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    amxut_bus_handle_events();
}

void test_zone_disable_host(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host.host-2.");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("lannister", "br-lan");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("baggins", "br-lan");
    amxut_bus_handle_events();

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host.host-2.");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    amxut_bus_handle_events();
}

void test_zone_disable_enable(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    //remove all hosts
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_remove_host("hue", "br-lan");
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("lannister", "br-lan");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("baggins", "br-lan");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("skywalker", "br-lan");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("holmes", "br-lan");
    amxut_bus_handle_events();

    //Enable again
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15", "");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.15,192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "192.168.10.14", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    amxut_bus_handle_events();
}

void test_zone_remove_existing_host_ipaddr(UNUSED void** state) {
    amxd_trans_t trans;

    print_message("step: remove 'DNS.Host.PC.IPAddress.address-2.'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Host.PC.IPAddress.");
    amxd_trans_del_inst(&trans, 0, "cpe-IPAddress-2");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

void test_zone_remove_ipaddr_from_hosts(UNUSED void** state) {
    amxd_trans_t trans;

    print_message("step: remove 'Hosts.Host.PC.IPv6Address.'\n");
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Hosts.Host.PC.IPv6Address.");
    amxd_trans_del_inst(&trans, 1, NULL);

    //remove all hosts
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("skywalker", "br-lan");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("holmes", "br-lan");

    //add all hosts
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12, c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.11,192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");

    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

void test_zone_delete_host_from_hosts(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Hosts.Host.");
    amxd_trans_del_inst(&trans, 0, "disabled");

    expect_check_add_host_local_domain("lannister", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("lannister", "br-lan");
    expect_check_add_host_local_domain("baggins", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a14");
    expect_check_remove_host("baggins", "br-lan");

    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

void test_zone_delete_host(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.zone-1.Host.");
    amxd_trans_del_inst(&trans, 0, "host-1");

    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "192.168.10.16", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a15,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_add_host_local_domain("hue", "brick.com", "br-lan", "", "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a16");
    expect_check_remove_host("hue", "br-lan");

    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

void test_zone_delete_zone(UNUSED void** state) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "DNS.Zone.");
    amxd_trans_del_inst(&trans, 0, "zone-1");

    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("skywalker", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("skywalker", "br-lan");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "brick.com", "br-lan", "192.168.10.11",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("PC", "", "br-lan", "192.168.10.11", "");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "192.168.10.12",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b11,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3a12,c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_add_host_local_domain("holmes", "brick.com", "br-lan", "",
                                       "c9e7:6457:7f5c:a79e:65ea:fd4d:8b2a:3b12");
    expect_check_remove_host("holmes", "br-lan");

    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}