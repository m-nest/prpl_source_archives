# Homeplug plugin
[[_TOC_]]

## compile and install

```
make
sudo make install
```

## run test

```
make test
```

## run plugin inside a Ambiorix Docker container

Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

### compile/install build dependencies: (make + sudo make install)

 * libsahtrace
 * libnetmodel
 * libamxb
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp

### runtime dependencies

 * umdns

### activate tr181-homeplug plugin
```
/etc/init.d/tr181-homeplug start
```

## Architecture
Support of HomePlug AV1.1
HomePlug Discovery is activated on a per interface basis. By default, the HomePlug feature will be active on the br-lan bridge.
All discovered devices are asked for associated device(s) information and related statistics.
Discovered devices are removed from the data model when not present anymore.
AssociatedDevice information is constantly updated.

## TR-181 HomePlug plugin
The HomePlug service is implemented as an Ambiorix micro service. It exposes a data model (Device.)HomePlug.
This service must be mapped under Device.HomePlug. using the Device proxy manager.
A default configuration needs to be provided, so HomePlug devices are detected by default on the LAN interface.
Guest Interface HomePlug detection is out-of-scope.
HomePlug devices must be automatically detected, updated and removed. (current implementation does not support reboot and upgrade persistence)

The HomePlug service is implemented is as a Ambiorix plugin, exposing a Device.HomePlug data model.
The plugin opens a socket on each configured LAN Interface and listens for packets with EtherType = “0x88e1”.
The plugin will listen for the packets and based on the input the data model is constructed.
The data model is kept up to date with the information in the packets.

