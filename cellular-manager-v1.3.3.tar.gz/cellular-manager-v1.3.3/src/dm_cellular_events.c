/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "cellular_priv.h"
#include "cellular_events.h"
#include "cellular_utils.h"
#include "cellular_soc_utils.h"

#define ME "events"

void _cell_iface_added(UNUSED const char* const sig_name,
                       const amxc_var_t* const data,
                       UNUSED void* const priv) {
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxd_dm_t* dm = cellular_get_dm();
    cell_iface_t* cell_iface = NULL;
    amxd_object_t* interface_templ_obj = amxd_dm_signal_get_object(dm, data);
    amxd_object_t* interface_obj = NULL;
    char* obj_path;
    const char* netdev_ifname = GETP_CHAR(data, "parameters.Name");
    bool enable = GETP_BOOL(data, "parameters.Enable");
    int ret = -1;

    when_str_empty_trace(netdev_ifname, exit, ERROR, "Empty Name");
    when_null_trace(interface_templ_obj, exit, ERROR, "Could not get template object");
    interface_obj = amxd_object_get_instance(interface_templ_obj, NULL, GET_UINT32(data, "index"));
    when_null_trace(interface_obj, exit, ERROR, "Could not get the added instance");
    obj_path = amxd_object_get_path(interface_obj, AMXD_OBJECT_INDEXED);

    when_not_null(interface_obj->priv, exit);

    SAH_TRACEZ_INFO(ME, "Adding cell interface %s for netdev %s", obj_path, netdev_ifname);

    rv = cell_iface_new(&cell_iface, interface_obj, netdev_ifname);
    when_failed_trace(rv, exit, ERROR, "Could not create cell interface");

    interface_obj->priv = cell_iface;

    netdev_link_added_subscription_new(cell_iface);
    netdev_link_state_subscription_new(cell_iface);

    mod_cellular_set_interface_params(interface_obj);

    ret = cell_iface_set_enabled(cell_iface, enable);
    when_failed_trace(ret, exit, ERROR, "Failed to %s cell interface %s: %d",
                      enable ? "enable" : "disable", obj_path, ret);

    cell_iface_update_dm(cell_iface);

exit:
    return;
}

void _cell_iface_enable_changed(UNUSED const char* const sig_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    int ret = -1;
    amxd_object_t* obj = amxd_dm_signal_get_object(cellular_get_dm(), data);
    char* obj_path;
    cell_iface_t* cell_iface = NULL;
    bool enable = GETP_BOOL(data, "parameters.Enable.to");

    when_null_trace(obj, exit, ERROR, "Could not get object");
    obj_path = amxd_object_get_path(obj, AMXD_OBJECT_INDEXED);
    cell_iface = (cell_iface_t*) obj->priv;
    when_null_trace(cell_iface, exit, ERROR, "Object private data is null");
    SAH_TRACEZ_INFO(ME, "Cell interface %s changed to %s", obj_path, enable ? "enabled" : "disabled");
    ret = cell_iface_set_enabled(cell_iface, enable);
    when_failed_trace(ret, exit, ERROR, "Failed to %s cell interface %s: %d",
                      enable ? "enable" : "disable", obj_path, ret);

    cell_iface_update_dm(cell_iface);

exit:
    return;
}

void _cell_iface_usim_info_changed(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    int ret = -1;
    amxd_object_t* usim_obj = amxd_dm_signal_get_object(cellular_get_dm(), data);
    amxd_object_t* obj = amxd_object_get_parent(usim_obj);
    char* obj_path;
    cell_iface_t* cell_iface = NULL;
    const char* pincheck = GETP_CHAR(data, "parameters.PINCheck.to");
    const char* pin = GETP_CHAR(data, "parameters.PIN.to");

    when_null_trace(obj, exit, ERROR, "Could not get object");
    obj_path = amxd_object_get_path(obj, AMXD_OBJECT_INDEXED);
    cell_iface = (cell_iface_t*) obj->priv;
    when_null_trace(cell_iface, exit, ERROR, "Object private data is null");
    SAH_TRACEZ_INFO(ME, "Cell interface %s USIM PIN setup changed", obj_path);
    ret = set_cell_iface_usim(cell_iface, pincheck, pin);
    when_failed_trace(ret, exit, ERROR, "Failed to setup USIM PIN on cell interface %s: %d",
                      obj_path, ret);

exit:
    return;
}

void _cell_ap_added(UNUSED const char* const sig_name,
                    const amxc_var_t* const data,
                    UNUSED void* const priv) {
    amxd_dm_t* dm = cellular_get_dm();
    amxd_object_t* ap_templ_obj = amxd_dm_signal_get_object(dm, data);
    amxd_object_t* ap_obj = NULL;
    const char* ap_name = GETP_CHAR(data, "parameters.APN");
    const char* ap_user = GETP_CHAR(data, "parameters.Username");
    const char* ap_pass = GETP_CHAR(data, "parameters.Password");
    const char* ap_proxy = GETP_CHAR(data, "parameters.Proxy");
    uint32_t proxy_port = GETP_UINT32(data, "parameters.ProxyPort");
//    bool enable = GETP_BOOL(data, "parameters.Enable");

    when_null_trace(ap_templ_obj, exit, ERROR, "Could not get template object");
    ap_obj = amxd_object_get_instance(ap_templ_obj, NULL, GET_UINT32(data, "index"));
    when_null_trace(ap_obj, exit, ERROR, "Could not get the added instance");

    SAH_TRACEZ_INFO(ME, "Adding AccessPoint name:%s user:%s pass:%s proxy:%s:%u",
                    ap_name != NULL ? ap_name : "", ap_user != NULL ? ap_user : "",
                    ap_pass != NULL ? ap_pass : "", ap_proxy != NULL ? ap_proxy : "", proxy_port);

    SAH_TRACEZ_NOTICE(ME, "%s added", ap_name != NULL ? ap_name : "");

//    ret = cell_ap_set_enabled(cell_ap, enable);
//    when_failed_trace(ret, exit, ERROR, "Failed to %s cell AccessPoint %s: %d",
//                      enable ? "enable" : "disable", cell_ap->name_ap, ret);

exit:
    return;
}

void _cell_ap_enable_changed(UNUSED const char* const sig_name,
                             const amxc_var_t* const data,
                             UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(cellular_get_dm(), data);
    bool enable = GETP_BOOL(data, "parameters.Enable.to");

    when_null_trace(obj, exit, ERROR, "Could not get object");

    SAH_TRACEZ_INFO(ME, "Cell ap changed to %s", enable ? "enabled" : "disabled");
//    ret = cell_ap_set_enabled(cell_ap, enable);
//    when_failed_trace(ret, exit, ERROR, "Failed to %s cell ap %s: %d",
//                      enable ? "enable" : "disable", cell_ap->name_ap, ret);

exit:
    return;
}

void _print_event(UNUSED const char* const event_name,
                  const amxc_var_t* const event_data,
                  UNUSED void* const priv) {
    if(sahTraceZoneLevel(sahTraceGetZone(ME)) >= TRACE_LEVEL_INFO) {
        SAH_TRACEZ_INFO(ME, "received event: %s", event_name);
        amxc_var_log(event_data);
    }
}
