/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "amxb_wrapper.h"

/* System headers */
#include <string.h> /* strcmp() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* UNUSED */
#include <amxb/amxb.h>        /* amxb_call() */

/* Own headers */
#include "mod_xpon_trace.h"

#ifndef UNIT_TEST

/**
 * Wrapper around amxb_be_who_has().
 */
amxb_bus_ctx_t* amxb_wrap_be_who_has(const char* object_path) {
    return amxb_be_who_has(object_path);
}

/**
 * Wrapper around amxb_call().
 */
int amxb_wrap_call(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   const char* method,
                   amxc_var_t* args,
                   amxc_var_t* ret,
                   int timeout) {
    return amxb_call(bus_ctx, object, method, args, ret, timeout);
}

/**
 * Wrapper around amxb_list().
 */
int amxb_wrap_list(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   uint32_t flags,
                   amxb_be_cb_fn_t fn,
                   void* priv) {
    return amxb_list(bus_ctx, object, flags, fn, priv);
}

/**
 * Wrapper around amxb_subscribe().
 */
int amxb_wrap_subscribe(amxb_bus_ctx_t* const ctx,
                        const char* object,
                        const char* expression,
                        amxp_slot_fn_t slot_cb,
                        void* priv) {
    return amxb_subscribe(ctx, object, expression, slot_cb, priv);
}

/**
 * Wrapper around amxb_unsubscribe().
 */
int amxb_wrap_unsubscribe(amxb_bus_ctx_t* const ctx,
                          const char* object,
                          amxp_slot_fn_t slot_cb,
                          void* priv) {
    return amxb_unsubscribe(ctx, object, slot_cb, priv);
}

#else

/* Dummy bus context for unit tests */
static amxb_bus_ctx_t s_amxb_bus_ctx;

/**
 * Wrapper around amxb_be_who_has().
 */
amxb_bus_ctx_t* amxb_wrap_be_who_has(UNUSED const char* object_path) {
    return &s_amxb_bus_ctx;
}

/**
 * Wrapper around amxb_call().
 */
int amxb_wrap_call(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   const char* method,
                   UNUSED amxc_var_t* args,
                   amxc_var_t* ret,
                   UNUSED int timeout) {
    int rc = -1;
    when_false_trace(bus_ctx == &s_amxb_bus_ctx, exit, ERROR,
                     "bus_ctx is not as expected");

#define GET_METHOD "get"
#define XPON_ONU_ONE "xpon_onu.1."
#define XPON_ETHERNET_UNI_ONE "xpon_onu.1.ethernet_uni.1."

    SAH_TRACEZ_DEBUG(ME, "object='%s'", object);
    if(strncmp(method, GET_METHOD, strlen(GET_METHOD)) == 0) {
        if(strcmp(object, XPON_ONU_ONE) == 0) {
            amxc_var_set_type(ret, AMXC_VAR_ID_LIST);
            amxc_var_t* htable = amxc_var_add(amxc_htable_t, ret, NULL);
            when_null_trace(htable, exit, ERROR, "Failed to add htable");
            amxc_var_add_key(cstring_t, htable, "name", "ONU_ONE");
            amxc_var_add_key(uint8_t, htable, "enable", 1);
            amxc_var_add_key(cstring_t, htable, "version", "v1.2.3");
            amxc_var_add_key(cstring_t, htable, "equipment_id", "MyEquipment");
            amxc_var_add_key(cstring_t, htable, "power_capability", "On,Off,LowPower");
            amxc_var_add_key(cstring_t, htable, "power_status", "On");
        } else if(strcmp(object, XPON_ETHERNET_UNI_ONE) == 0) {
            amxc_var_set_type(ret, AMXC_VAR_ID_LIST);
            amxc_var_t* htable = amxc_var_add(amxc_htable_t, ret, NULL);
            when_null_trace(htable, exit, ERROR, "Failed to add htable");
            amxc_var_add_key(cstring_t, htable, "name", "MyEthernetUNI");
            amxc_var_add_key(cstring_t, htable, "status", "Up");
            amxc_var_add_key(cstring_t, htable, "ani_list", "xpon_onu.1.ani.1");
        }
    }
    rc = 0;
exit:
    return rc;
}

typedef struct _instances_info {
    const char* path;
    const size_t path_len;
    amxc_string_t* const indexes;
} instances_info_t;

/**
 * Wrapper around amxb_list().
 */
int amxb_wrap_list(amxb_bus_ctx_t* const bus_ctx,
                   const char* object,
                   uint32_t flags,
                   UNUSED amxb_be_cb_fn_t fn,
                   void* priv) {
    int rc = -1;
    when_false_trace(bus_ctx == &s_amxb_bus_ctx, exit, ERROR,
                     "bus_ctx is not as expected");
    when_null_trace(object, exit, ERROR, "object is NULL");
    when_false_trace(AMXB_FLAG_INSTANCES == flags, exit, ERROR,
                     "flags=0x%x != AMXB_FLAG_INSTANCES=0x%x",
                     flags, AMXB_FLAG_INSTANCES);
    when_null_trace(priv, exit, ERROR, "priv is NULL");
    instances_info_t* info = (instances_info_t*) priv;
    when_null_trace(info->indexes, exit, ERROR, "info->indexes is NULL");

    if(strcmp(object, "xpon_onu.1.software_image.") == 0) {
        amxc_string_set(info->indexes, "1,2");
    }
    rc = 0;
exit:
    return rc;
}

/**
 * Wrapper around amxb_subscribe().
 */
int amxb_wrap_subscribe(UNUSED amxb_bus_ctx_t* const ctx,
                        UNUSED const char* object,
                        UNUSED const char* expression,
                        UNUSED amxp_slot_fn_t slot_cb,
                        UNUSED void* priv) {
    return 0;
}

/**
 * Wrapper around amxb_unsubscribe().
 */
int amxb_wrap_unsubscribe(UNUSED amxb_bus_ctx_t* const ctx,
                          UNUSED const char* object,
                          UNUSED amxp_slot_fn_t slot_cb,
                          UNUSED void* priv) {
    return 0;
}

#endif
