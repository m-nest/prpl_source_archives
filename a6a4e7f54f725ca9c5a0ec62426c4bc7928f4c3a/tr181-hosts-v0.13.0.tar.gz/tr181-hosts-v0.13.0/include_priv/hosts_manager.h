/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <amxc/amxc_llist.h>

#if !defined(__TR_HOSTS_MANAGER_H__)
#define __TR_HOSTS_MANAGER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_action.h>
#include <amxo/amxo.h>
#include <amxp/amxp_slot.h>
#include <amxb/amxb.h>
#include <debug/sahtrace.h>

int _hosts_manager_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

PRIVATE
amxd_dm_t* hosts_manager_get_dm(void);

PRIVATE
amxc_var_t* hosts_manager_get_config(void);

PRIVATE
amxo_parser_t* hosts_manager_get_parser(void);

// event handlers
void _hosts_active_changed(const cstring_t const event_name,
                           const amxc_var_t* const event_data,
                           void* const priv);

void _hosts_protected_changed(const cstring_t const event_name,
                              const amxc_var_t* const event_data,
                              void* const priv);

void _hosts_added(const cstring_t const event_name,
                  const amxc_var_t* const event_data,
                  void* const priv);


void _hosts_removed(const cstring_t const event_name,
                    const amxc_var_t* const event_data,
                    void* const priv);

/**
   @defgroup hosts_manager
 */

/**
   @ingroup hosts_manager
   @brief Event handler for IP information updates.

   Triggered when an IP-related object changes in the data model. This
   function resolves the corresponding host object and updates its
   primary IP address information.

   @param event_name Name of the triggering event (e.g. @c dm:object-changed).
   @param event_data Event payload containing the IP address object reference.
   @param priv       Private data (unused).

   @note
   - For @c dm:object-changed events, the IP object instance is received and
     the host object is obtained by moving two levels up.
   - For other IP events, the host object is one level up.
 */
void _ip_info_updated(const cstring_t const event_name,
                      const amxc_var_t* const event_data,
                      void* const priv);

amxd_status_t _RemoveInactiveDevices(amxd_object_t* object, amxd_function_t* func,
                                     amxc_var_t* args, amxc_var_t* ret);

/**
   @ingroup hosts_manager
   @brief Removes inactive hosts through the AMXD function interface.

   This function is intended to be invoked as an AMXD function handler.
   It removes inactive hosts based on the optional @c MinimumInactiveTime
   argument and returns the number of removed hosts in the result.

   @param object Unused.
   @param func   Unused.
   @param args   Input arguments. May contain the key @c MinimumInactiveTime
                 (in seconds), which defines the minimum inactivity period
                 before a host is removed. If not provided, all inactive hosts
                 are removed.
   @param ret    Output result. On completion, contains a hashtable with:
                 - @c NumberOfRemovedHosts : the number of hosts removed.

   @return
   - @c amxd_status_ok if the operation completed successfully,
   - an error status if removal failed.

   @note Requires time synchronization if a non-zero inactivity threshold
         is specified.
 */
amxd_status_t _RemoveInactiveHosts(amxd_object_t* object,
                                   amxd_function_t* func, amxc_var_t* args,
                                   amxc_var_t* ret);

/**
   @ingroup hosts_manager
   @brief Event handler for changes to the CleanupHostsThreshold parameter.

   This function is triggered when the @c CleanupHostsThreshold parameter
   changes. If the threshold is non-negative, it enforces the limit by
   removing excess inactive hosts. A threshold of @c -1 means that no
   cleanup is performed.

   @param event_name Name of the event (unused).
   @param event_data Event payload. Must contain the updated value at
                     @c parameters.CleanupHostsThreshold.to.
   @param priv       Private data (unused).
 */
void _hosts_CleanUpHostsThreshold_changed(const cstring_t const event_name,
                                          const amxc_var_t* const event_data,
                                          void* const priv);

/**
   @ingroup hosts_manager
   @brief Sets the debounce interval for WAN statistics reads.

   Configures how frequently WAN statistics can be read, by applying
   a debounce interval. If the given value is below the minimum allowed
   threshold (@c HOSTS_WANSTATS_READ_MIN_DEBOUNCE_S), the minimum is used
   instead.

   @param seconds Desired debounce interval in seconds. Values lower than
                  the minimum threshold are automatically adjusted upwards.
 */
void hosts_manager_set_stats_debounce_seconds(uint32_t seconds);

/**
   @ingroup hosts_manager
   @brief Retrieves WAN/host statistics with debounce control.

   Returns the current statistics for the given @p object. If the cached
   statistics are still valid within the configured debounce interval,
   the cached values are returned. Otherwise, new statistics are read
   and stored before being returned.

   @param object The object for which statistics are requested.
   @param[out] out Pointer to receive the statistics data. Must not be NULL.
                   On success, points to a valid @c amxc_var_t structure containing
                   the statistics.

   @return
   - @c amxd_status_ok if statistics were successfully retrieved,
   - @c amxd_status_invalid_value if cached data is invalid,
   - @c amxd_status_unknown_error on failure.

   @note The returned pointer @p out refers to internal storage. It must not
         be modified or freed by the caller.
 */
amxd_status_t hosts_manager_get_stats(amxd_object_t* object, const amxc_var_t** out);

amxd_status_t _dm_read_stats(amxd_object_t* const object, amxd_param_t* param,
                             amxd_action_t reason, const amxc_var_t* const args,
                             amxc_var_t* const retval, void* priv);

/**
   @ingroup hosts_manager
   @brief Cleanup handler for destroyed WAN statistics objects.

   This function is called when a WAN statistics object is being destroyed.
   It frees any associated statistics data and clears the object's private
   data pointer.

   @param object The WAN statistics object being destroyed. Must not be NULL.
   @param param  Unused.
   @param reason Unused.
   @param args   Unused.
   @param retval Unused.
   @param priv   Unused.

   @return Always returns @c amxd_status_ok.
 */
amxd_status_t _on_wanstats_destroyed(amxd_object_t* const object,
                                     amxd_param_t* const param,
                                     amxd_action_t reason,
                                     const amxc_var_t* const args,
                                     amxc_var_t* const retval,
                                     void* priv);

/**
   @ingroup hosts_manager
   @brief Imports reboot-persistent host data.

   This function handles the import of persistent host configuration and
   state data. It first verifies and patches the input data using
   @c hosts_sync_import, then delegates to the backend PCM import
   function to complete the process.

   @param object Unused.
   @param func   Unused.
   @param args   Input arguments. Must contain the key @c "data" with the
                 persistent host data to import.
   @param ret    Output arguments, filled by the backend PCM import call.

   @return
   - @c amxd_status_ok if the import completed successfully,
   - @c amxd_status_unknown_error or other error codes if import failed.

   @note The @p args->data parameter is required; the function will fail
         if it is missing or NULL.
 */
amxd_status_t _Import(amxd_object_t* object,
                      amxd_function_t* func,
                      amxc_var_t* args,
                      amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __TR_HOSTS_MANAGER_H__
