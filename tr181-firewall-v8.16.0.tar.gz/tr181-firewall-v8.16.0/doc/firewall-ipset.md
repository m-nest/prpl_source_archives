﻿# **TR-181 Firewall: IPSet extension**
[Requirements](#tr-181firewall:ipsetextension-requirements) 

[Introduction and High-Level Description](#tr-181firewall:ipsetextension-introductionandhigh-leveldescription)

[Use Case Definition](#tr-181firewall:ipsetextension-usecasedefinition)

[References](#tr-181firewall:ipsetextension-references)

[Architecture](#tr-181firewall:ipsetextension-architecture)

[Implementation](#tr-181firewall:ipsetextension-implementation) 

[Firewall.Set.{i}](#tr-181firewall:ipsetextension-firewall.set.{i}) 

[Rule](#tr-181firewall:ipsetextension-rule)

[Exclude](#tr-181firewall:ipsetextension-exclude)

[Firewall.Chain.{i}.Rule.{i}](#tr-181firewall:ipsetextension-firewall.chain.{i}.rule.{i})

[Data Model](#tr-181firewall:ipsetextension-datamodel)

[Low-Level API](#tr-181firewall:ipsetextension-low-levelapi)

[API](#tr-181firewall:ipsetextension-api)

[Files](#tr-181firewall:ipsetextension-files)

[Firewall](#tr-181firewall:ipsetextension-firewall)

[Dependants and Dependencies](#tr-181firewall:ipsetextension-dependantsanddependencies) 

[Dependants](#tr-181firewall:ipsetextension-dependants)

[Dependencies](#tr-181firewall:ipsetextension-dependencies)

[Configuration](#tr-181firewall:ipsetextension-configuration)

[Backup/Restore, Upgrade, Reset](#tr-181firewall:ipsetextension-backup/restore,upgrade,reset)

[Web UI](#tr-181firewall:ipsetextension-webui)

[Considerations](#tr-181firewall:ipsetextension-considerations) 

[IPv6](#tr-181firewall:ipsetextension-ipv6)

[Packet Acceleration](#tr-181firewall:ipsetextension-packetacceleration)

[Memory Usage](#tr-181firewall:ipsetextension-memoryusage)

[Boot Time](#tr-181firewall:ipsetextension-boottime)

[Security](#tr-181firewall:ipsetextension-security)

[Remote Management](#tr-181firewall:ipsetextension-remotemanagement)

[Operational Monitoring](#tr-181firewall:ipsetextension-operationalmonitoring)

[Quality](#tr-181firewall:ipsetextension-quality) 

[Project Reference Configuration](#tr-181firewall:ipsetextension-projectreferenceconfiguration)

[Build-time Checks](#tr-181firewall:ipsetextension-build-timechecks)

[Run-time Checks](#tr-181firewall:ipsetextension-run-timechecks)

[Unit Tests](#tr-181firewall:ipsetextension-unittests)

[Logging and Debugging](#tr-181firewall:ipsetextension-logginganddebugging)

[Functional Tests](#tr-181firewall:ipsetextension-functionaltests)

[CI Tests](#tr-181firewall:ipsetextension-citests)

[Certification](#tr-181firewall:ipsetextension-certification)

[Design Review Documentation](#tr-181firewall:ipsetextension-designreviewdocumentation)
# <a name="tr-181firewall:ipsetextension-requirements"></a>**Requirements**
## <a name="tr-181firewall:ipsetextension-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
- A **Firewall.Set.** object should be used to store a large amount of entries from one (and only one) of the following type :
  - IP address and subnet
  - MAC address
  - Port
  - IP/MAC address to then be used to match the source or destination of a Firewall.Chain.{i}.Rule
- User created rules (**Firewall.Chain.{i}.Rule**) should be able to use the **Firewall.Set.** created to match the source or destination field.
- A **Firewall.Set.** object should be be able to be updated dynamically with new entries (add and remove).
- Firewall.Chain.{i}.Rule.{i}.[Source|Dest]MatchSet[Include|Exclude] refers to a configured set.
## <a name="tr-181firewall:ipsetextension-usecasedefinition"></a>**Use Case Definition[](https://prplfoundationcloud.atlassian.net/issues/?jql=key%20%3D%20%22HAPM-75%22%20ORDER%20BY%20type%2C%20created%20DESC)**
<https://prplfoundationcloud.atlassian.net/issues/?jql=key%20%3D%20%22HAPM-75%22%20ORDER%20BY%20type%2C%20created%20DESC> 
## <a name="tr-181firewall:ipsetextension-references"></a>**References**
[Device.Firewall.Set.](https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.Firewall.Set.)
# <a name="tr-181firewall:ipsetextension-architecture"></a>**Architecture**
![image](image/arch.png) 

The diagram shows the architecture of the IPSet extension for the firewall.

Notes :

- libipset is used to create and populate the ipset in the kernel from the Firewall.Set. datamodel.
- libfwrules & libfwinterfaces are used to create the rules in iptables
- The rules uses a reference to the ipset created.
# <a name="tr-181firewall:ipsetextension-implementation"></a>**Implementation**
The ipset extension is part of the firewall manager (tr181-firewall) plugin.
## <a name="tr-181firewall:ipsetextension-firewall.set.{i}"></a>**Firewall.Set.{i}**
For each enabled **Firewall.Set.{i}** instance, an ipset set is created using the Alias, Type and IPVersion parameters.

Updating/Disabling a **Firewall.Set.{i}**. is not allowed if it is currently used by an enabled **Firewall.Chain.{i}.Rule.{i}**

If **Firewall.Set.{i}**. Type/IPVersion parameters are updated, all the child **Rule** instances are removed.

If **Firewall.Set.{i}**. is disabled, the mapped ipset set is deleted.
### <a name="tr-181firewall:ipsetextension-rule"></a>**Rule**
When a new **Firewall.Set.{i}**.**Rule.{i}** instance is created, the IPs/MACs/Ports are added to the set.

If a **Firewall.Set.{i}**.**Rule.{i}** instance is deleted or updated, the ipset is emptied and repopulated based on the content of the remaining **Firewall.Set.{i}**.**Rule** instances.
### <a name="tr-181firewall:ipsetextension-exclude"></a>**Exclude**
**Firewall.Set.{i}**.**Rule.{i}**.**Exclude** is only applicable for IPv4/IPv6 set.

If **Firewall.Set.{i}.Rule.{i}.Exclude** is true, the IP entries will be added with the *nomatch* flag (see <https://ipset.netfilter.org/ipset.man.html> )
## <a name="tr-181firewall:ipsetextension-firewall.chain.{i}.rule.{i}"></a>**Firewall.Chain.{i}.Rule.{i}**
A reference to a SET object can be used in the parameters : SourceMatchSet/SourceMatchSetExclude and DestMatchSet/DestMatchSetExclude.

To have a correctly configured rule, the following conditions should be met :

- **Firewall.Set.{i}** should be enabled
- **Firewall.Chain.{i}.Rule.{i}.IPVersion** and **Firewall.Set.{i}.IPVersion** should match

SourceIP is ignored if SourceMatchSet or SourceMatchSetExclude is set.

DestIP is ignored if DestMatchSet or DestMatchSetExclude is set. 
## <a name="tr-181firewall:ipsetextension-datamodel"></a>**Data Model**
|**Name**|**Type**|**W/P/V**|**Description**|**Legal Values/Default**|**Action on Add/Delete/Modify**|**Version**|
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
|**Firewall**|**Object**|**RP**|**Defines Firewall. TR-181 data model 2.16**|**–**||**8.8.6**|
|**Firewall.Chain.{i}**|**Object**|**RWP**|**Firewall Chain table. Each entry contains an ordered list of Rule objects which can themselves reference other Chain instances. A hierarchy of rules can therefore be created.**|**–**||**1.0**|
|**Firewall.Chain.{i}.Rule.{i}**|**Object**|**RWP**|**Firewall Rule table. Each entry defines a Firewall packet selection rule. The Target parameter defines the action to perform for traffic matching this rule: the packet can be dropped, accepted, rejected or passed to another Chain.**|**–**||**1.0**|
|DestMatchSet|string|RWP|Destination Match Set, Matches packets if their destination is found in the designated Set. reference. An empty string indicates this criterion is not used for matching.|**default**:|–|2\.18|
|DestMatchSetExclude|string|RWP|Destination Exclude Match Set, Matches packets if their destination is not found in the designated Set. reference. An empty string indicates this criterion is not used for matching.|**default**:|–|2\.18|
|SourceMatchSet|string|RWP|Source Match Set, Matches packets if their source is found in the designated Set. reference. An empty string indicates this criterion is not used for matching.|**default**:|–|2\.18|
|SourceMatchSetExclude|string|RWP|Source Exclude Match Set, Matches packets if their source is not found in the designated Set. reference. An empty string indicates this criterion is not used for matching.|**default**:|–|2\.18|
|**Firewall.Set.{i}**|**Object**|**RWP**|**Firewall Set object that is used for configuring sets of IP, MAC addresses and/or port numbers which can then be used in conjunction with the firewall. It provides a more efficient way to manage large collections of addresses and ports compared to traditional methods of listing them individually within firewall rules.**|**–**||**2.18**|
|Alias|string|RWP|A non-volatile unique key used to reference this instance.|**default**:|–|2\.18|
|Enable|bool|RWP|Enables or disables the Set instance.|**default**: false|–|2\.18|
|Origin|string|RWP|Indicates the Origin of the Set instance. Enumeration of: - User (Used for indicating that the set rule was created by the end-user. For example through the web-ui) - System (Used for indicating that the set rule was created by the system itself) - Controller (Used for indicating that the set rule was created by a controller)|**default**: Controller|–|2\.18|
|Name|string|RWP|Human-readable name associated with this Set entry.|**default**:|–|2\.18|
|Type|string|RWP|Describes the intention of the Rule entries and what it contains. Enumeration of: - IPAddresses (The Rule set entry describes only a list of IPaddresses) - Ports (The Rule set entry describes only a list of ports) - MACAddresses (The Rule set entry describes only a list of MAC addresses)|**default**: IPAddresses|–|2\.18|
|IPVersion|uint32|RWP|IP Protocol Version as specified in [IANA-ipversionnumbers](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IANA-ipversionnumbers&linkCreation=true&fromPageId=590780429). For example: - 4 (IPv4) - 6 (IPv6)|**default**: 6|–|2\.18|
|RuleNumberOfEntries|uint32|R||**Instance counter for**:|–|8\.8.6|
|**Firewall.Set.{i}.Rule.{i}**|**Object**|**RWP**|**Firewall Rule object that is used for configuring the set lists.**|**–**||**2.18**|
|Alias|string|RWP|A non-volatile unique key used to reference this instance.|**default**:|–|2\.18|
|Exclude|bool|RWP|Specifies if this rule entry should match or not match the configured criteria.|**default**: false|–|2\.18|
|IPAddressList|csv\_string|RWP|Comma-separated list of IP Addresses. Source IPv4 or IPv6 address or subnet mask. The IP version of the IP address MUST correspond to the IP version set in IPVersion. Can not be used in combination with MACAddressList or PortList.|**default**:|–|2\.18|
|MACAddressList|csv\_string|RWP|Specifies the MACAddress that can be used by the *Rule* entry. Can not be used in combination with *IPAddressList* or *PortList*.|**default**:|–|2\.18|
|PortList|csv\_string|RWP|Comma-separated list of strings. Specifies the Port number or a port range that can be used by the Rule entry. A single port can be configured as e.g. ‘80’. A port range can be configured as ‘8000-80010’. Can not be used in combination with MACAddressList or IPAddressList.|**default**:|–|2\.18|
## <a name="tr-181firewall:ipsetextension-low-levelapi"></a>**Low-Level API**
## <a name="tr-181firewall:ipsetextension-api"></a>**API**
## <a name="tr-181firewall:ipsetextension-files"></a>**Files**
This feature is an integral part of TR181-firewall plugin.
## <a name="tr-181firewall:ipsetextension-firewall"></a>**Firewall**
## <a name="tr-181firewall:ipsetextension-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="tr-181firewall:ipsetextension-dependants"></a>**Dependants**
N/A
### <a name="tr-181firewall:ipsetextension-dependencies"></a>**Dependencies**
- ibfwrules→ keeps the chains/rules in process memory
- libip(6)tc, libfwinterface → interact with iptables (and netfilter)
- libipset → creates/deletes IPSET set
- iptable with ipset support enabled
- Ambiorix framework libs and tools
## <a name="tr-181firewall:ipsetextension-configuration"></a>**Configuration**
This feature is intended to be configured through HL-API. **Firewall.Set.{i].** instances can be created/updated/deleted to manage the sets.

**Firewall.Chain.Rule.{i}.** instances parameters **SourceMatchSet**/**SourceMatchSetExclude** and **DestMatchSet**/**DestMatchSetExclude** can be set to a reference of a **Firewall.Set.{i}** instance.

**Additional Considerations:**

- Before enabling a **Firewall.Chain.Rule.{i}.** , the **Firewall.Set.{i}.** used must be enabled
- If a **Firewall.Set.{i}.** instance** is referenced by at least one enabled **Firewall.Chain.Rule.{i}.,** then the Set can not be disabled, modified or deleted.
- When using **Firewall.Set.{i}.** to match the source or destination, logging is not supported.
## <a name="tr-181firewall:ipsetextension-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
**Firewall.Set.** instances are reboot persistent.
## <a name="tr-181firewall:ipsetextension-webui"></a>**Web UI**
Direct access to this datamodel from WebUI is not recommended as bad rule configuration could imped HGW operation. It is advisable that users interacts with higher level service restricting IPSet changes to intended scope.
# <a name="tr-181firewall:ipsetextension-considerations"></a>**Considerations**
## <a name="tr-181firewall:ipsetextension-ipv6"></a>**IPv6**
Supported.
## <a name="tr-181firewall:ipsetextension-packetacceleration"></a>**Packet Acceleration**
## <a name="tr-181firewall:ipsetextension-memoryusage"></a>**Memory Usage**
## <a name="tr-181firewall:ipsetextension-boottime"></a>**Boot Time**
## <a name="tr-181firewall:ipsetextension-security"></a>**Security**
## <a name="tr-181firewall:ipsetextension-remotemanagement"></a>**Remote Management**
## <a name="tr-181firewall:ipsetextension-operationalmonitoring"></a>**Operational Monitoring**
# <a name="tr-181firewall:ipsetextension-quality"></a>**Quality**
## <a name="tr-181firewall:ipsetextension-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="tr-181firewall:ipsetextension-build-timechecks"></a>**Build-time Checks**
## <a name="tr-181firewall:ipsetextension-run-timechecks"></a>**Run-time Checks**
## <a name="tr-181firewall:ipsetextension-unittests"></a>**Unit Tests**
Added in tr181-firewall unit test <https://gitlab.com/prpl-foundation/components/core/plugins/tr181-firewall/-/tree/main/test?ref_type=heads>
## <a name="tr-181firewall:ipsetextension-logginganddebugging"></a>**Logging and Debugging**
Log messages with trace zone "*ipset*" on tr181-firewall
## <a name="tr-181firewall:ipsetextension-functionaltests"></a>**Functional Tests**
|**Step**|**Test designation**|**Description** |**Expected result**|
| :-: | :-: | :-: | :-: |
|1|Create new SETs|<p>Create 4 new Sets objects:</p><p>- 1 of type IPAddresses restricted to IPv4</p><p>- 1 of type IPAddresses</p><p>- 1 of type MACAddresses</p><p>- 1 of type Ports</p>|<p>in ba-cli , create new Set objects :</p><p>> Firewall.Set.+{Enable=1, Type="IPAddresses", IPVersion=4}</p><p>Firewall.Set.1.</p><p>Firewall.Set.1.Alias="cpe-Set-1"</p><p>> Firewall.Set.+{Enable=1, Type="IPAddresses"}</p><p>Firewall.Set.2.</p><p>Firewall.Set.2.Alias="cpe-Set-2"</p><p>> Firewall.Set.+{Enable=1, Type="MACAddresses"}</p><p>Firewall.Set.3.</p><p>Firewall.Set.3.Alias="cpe-Set-3"</p><p>> Firewall.Set.+{Enable=1, Type="Ports"}</p><p>Firewall.Set.4.</p><p>Firewall.Set.4.Alias="cpe-Set-4"</p><p>on console check ipset list :</p><p>root@prplOS:~# ipset list<br>Name: cpe-Set-1<br>Type: hash:net<br>Revision: 6<br>Header: family inet6 hashsize 1024 maxelem 65536<br>Size in memory: 1232<br>References: 1<br>Number of entries: 0<br>Members:</p><p>Name: cpe-Set-2<br>Type: hash:net<br>Revision: 6<br>Header: family inet hashsize 1024 maxelem 65536<br>Size in memory: 448<br>References: 0<br>Number of entries: 0<br>Members:</p><p>Name: cpe-Set-3<br>Type: hash:mac<br>Revision: 0<br>Header: hashsize 1024 maxelem 65536<br>Size in memory: 192<br>References: 0<br>Number of entries: 0<br>Members:</p><p>Name: cpe-Set-4<br>Type: bitmap:port<br>Revision: 3<br>Header: range 0-65535<br>Size in memory: 8264<br>References: 0<br>Number of entries: 0<br>Members:</p>|
|2|Add new IP address to IPv4 SET| |<p>Create new Set and Rule objects :</p><p>> Firewall.Set.+{Enable=1, Type="IPAddresses",  IPVersion=4}</p><p>Firewall.Set.1.</p><p>Firewall.Set.1.Alias="cpe-Set-1"</p><p>> Firewall.Set.1.Rule.+{IPAddressList="192.168.6,192.168.1.8"}  </p><p>Firewall.Set.1.Rule.1.</p><p>Firewall.Set.1.Rule.1.Alias="cpe-Rule-1"</p><p>> Firewall.Set.1.Rule.+{IPAddressList="10.10.10.10"}  </p><p>Firewall.Set.1.Rule.2.</p><p>Firewall.Set.1.Rule.2.Alias="cpe-Rule-2"</p><p>Check ipset list :</p><p>root@prplOS:~# ipset list cpe-Set-1</p><p>Name: cpe-Set-5</p><p>Type: hash:net</p><p>Revision: 6</p><p>Header: family inet hashsize 1024 maxelem 65536</p><p>Size in memory: 576</p><p>References: 0</p><p>Number of entries: 2</p><p>Members:</p><p>192\.168.0.6</p><p>192\.168.1.8</p><p>10\.10.10.10</p>|
|3| |Use SET in a firewall rule|<p>Create new Set object :</p><p>> Firewall.Set.+{Enable=1, Type="IPAddresses",  IPVersion=4}</p><p>Firewall.Set.1.</p><p>Firewall.Set.1.Alias="cpe-Set-1"</p><p>Use the Set path in the firewall Rule **SourceMatchSet** parameter :</p><p>> Firewall.Chain.1.Rule.1.SourceMatchSet="Firewall.Set.1."</p><p>Firewall.Chain.1.Rule.1.</p><p>Firewall.Chain.1.Rule.1.SourceMatchSet="Firewall.Set.1."</p><p>Rule Status should be **Enabled**</p><p>> Firewall.Chain.1.Rule.1.Status?</p><p>Firewall.Chain.1.Rule.1.Status="Enabled"</p><p>The created iptables rule should have the **match-set cpe-Set-1 src** matching option</p><p>root@prplOS:~# iptables -L FORWARD\_L\_Low</p><p>Chain FORWARD\_L\_Low (3 references)</p><p>target     prot opt source               destination         </p><p>ACCEPT     all  --  anywhere             anywhere             **match-set cpe-Set-1 src**</p>|
|4| |Use not enabled SET in a firewall rule|<p>Create new disabled Set object :</p><p>> Firewall.Set.+{Enable=0, Type="IPAddresses",  IPVersion=4}</p><p>Firewall.Set.1.</p><p>Firewall.Set.1.Alias="cpe-Set-1"</p><p>> Firewall.Chain.1.Rule.1.SourceMatchSet="Firewall.Set.1."</p><p>Firewall.Chain.1.Rule.1.</p><p>Firewall.Chain.1.Rule.1.SourceMatchSet="Firewall.Set.1."</p><p>Rule Status should be **Error\_Misconfigured**</p><p>` `> Firewall.Chain.4.Rule.1.Status?</p><p>Firewall.Chain.4.Rule.1.Status="Error\_Misconfigured"</p><p> </p>|
| | |Use Exclude SET parameter|<p>Create new Set object :</p><p>> Firewall.Set.+{Enable=1, Type="IPAddresses",  IPVersion=4}</p><p>Firewall.Set.1.</p><p>Firewall.Set.1.Alias="cpe-Set-1"</p><p>Use the Set path in the firewall Rule **SourceMatchSetExclude** parameter :</p><p>> Firewall.Chain.1.Rule.1.SourceMatchSetExclude="Firewall.Set.1."</p><p>Firewall.Chain.1.Rule.1.</p><p>Firewall.Chain.1.Rule.1.SourceMatchSetExclude="Firewall.Set.1."</p><p>Rule Status should be **Enabled**</p><p>> Firewall.Chain.1.Rule.1.Status?</p><p>Firewall.Chain.1.Rule.1.Status="Enabled"</p><p>The created iptables rule should have the **! match-set cpe-Set-1 src** matching option</p><p>root@prplOS:~# iptables -L FORWARD\_L\_Low</p><p>Chain FORWARD\_L\_Low (3 references)</p><p>target     prot opt source               destination         </p><p>ACCEPT     all  --  anywhere             anywhere             **! match-set cpe-Set-1 src**</p>|
## <a name="tr-181firewall:ipsetextension-citests"></a>**CI Tests**
## <a name="tr-181firewall:ipsetextension-certification"></a>**Certification**
# <a name="tr-181firewall:ipsetextension-designreviewdocumentation"></a>**Design Review Documentation**
