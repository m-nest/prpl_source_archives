/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "dm_pool_events.h"
#include "dm_pool_methods.h"
#include "pools.h"
#include "pool_info.h"

#define ME "pool_events"

/**
 * @brief
 * Adds or updates a DHCPv4 server pool in the UCI files.
 * Called when a TR181 DHCPv4.Server.Pool data model object instance is added or changed.
 *
 * The function creates the pool's internal data structures, initializes its private
 * info, and sets the pool's enabled/disabled state based on the "Enable" parameter.
 * If the DHCPv4 server itself is disabled, the pool is added in the data model but
 * no activation occurs.
 *
 * @param event_name event name
 * @param event_data event data
 * @param priv private data associated with event subscription
 */
void _pool_added(UNUSED const char* const event_name,
                 const amxc_var_t* const event_data,
                 UNUSED void* const priv) {
    bool enable = false;
    amxd_dm_t* dm = NULL;
    amxd_object_t* templ = NULL;
    amxd_object_t* pool = NULL;
    const char* name = NULL;
    bool server_enabled = false;

    SAH_TRACEZ_INFO(ME, "In DHCPv4 server pool added.");
    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");

    name = GET_CHAR(event_data, "name");
    when_null_trace(name, exit, ERROR, "Cannot get object name.");

    dm = dhcp_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DHCPv4 data model.");
    templ = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(templ, exit, ERROR, "Cannot get template for pool object.");
    pool = amxd_object_get_instance(templ, name, 0);
    when_null_trace(pool, exit, ERROR, "Cannot get pool object.");

    pool->priv = pool_info_create(pool);
    when_null_trace(pool->priv, exit, ERROR, "Cannot create pool private info.");

    amxd_object_t* dhcpv4_obj = amxd_dm_findf(dm, "%s", DHCP_SERVER);
    when_null_trace(dhcpv4_obj, exit, ERROR, "DHCPv4Server object not found");

    server_enabled = amxd_object_get_value(bool, dhcpv4_obj, "Enable", NULL);
    when_false_trace(server_enabled, exit, WARNING,
                     "Pool successfully added, but DHCPv4 Server is disabled");

    enable = amxd_object_get_value(bool, pool, "Enable", NULL);
    enable ? pool_info_enable(pool) : pool_info_disable(pool);
exit:
    return;
}


/**
 * @brief
 * Enable all static addresses of the pool with Enable parameter set to true.
 *
 * @param pool the pool object that the static ip addresses are associated to.
 */
static void enable_pool_static_address_if_enabled_in_dm(amxd_object_t* pool) {
    amxd_object_for_each(instance, it, amxd_object_findf(pool, ".StaticAddress.")) {
        amxd_object_t* addr = amxc_container_of(it, amxd_object_t, it);
        if(amxd_object_get_value(bool, addr, "Enable", NULL)) {
            pools_enable_pool_static_address(pool, addr);
        }
    }
}

/**
 * @brief
 * Updates the state of a DHCPv4 Server.Pool
 *
 * If the pool is enabled and the DHCPv4 server is active, the pool is activated and
 * static addresses are enabled if configured.
 * If the pool is disabled and the server is active, the pool is deactivated and
 * all static addresses are disabled.
 * No changes are applied if the DHCPv4 server itself is disabled.
 *
 * @param pool the DHCPv4 Server.Pool object to update
 */
static void update_pool(amxd_object_t* pool) {
    when_null_trace(pool, exit, ERROR, "DHCPv4 pool object can't be NULL");
    amxd_dm_t* dm = NULL;
    amxd_object_t* dhcpv4_obj = NULL;
    bool server_enabled = false;

    dm = dhcp_get_dm();
    dhcpv4_obj = amxd_dm_findf(dm, "%s", DHCP_SERVER);
    when_null_trace(dhcpv4_obj, exit, ERROR, "DHCPv4Server object not found");

    server_enabled = amxd_object_get_value(bool, dhcpv4_obj, "Enable", NULL);
    when_false_trace(server_enabled, exit, WARNING, "DHCPv4Server is disabled");

    if(amxd_object_get_value(bool, pool, "Enable", NULL)) {
        pool_info_enable(pool);
        enable_pool_static_address_if_enabled_in_dm(pool);
    } else {
        pool_info_disable(pool);
        pools_disable_all_pool_static_addresses(pool);
    }

exit:
    return;
}

/**
 * @brief
 * Updates the DHCPv4 server pools whose Order Parameter will have changed.
 *
 * When a Server.Pool.{i}.Order parameter is set only that Order change will trigger an event.
 * All subsequently updated Order Parameters (incremented or compacted) won't trigger an event.
 *
 * Example:
 * A1|B2|C3|D4 (Before)
 * A1|D2|B3|C4 (After setting D Order to 2)
 *     |  ^--^-- Order changes without event (manual update)
 *     ^-- Order change with event (event_order)
 *
 * @param pools the Pool template object
 * @param event_order the Order change that got an event
 */
static void handle_pool_order_changes(amxd_object_t* pools, uint32_t min_order, uint32_t max_order) {
    when_null_trace(pools, exit, ERROR, "Pool template object is NULL");

    amxd_object_for_each(instance, it, pools) {
        amxd_object_t* pool_it_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        uint32_t order = 0;
        when_null_trace(pool_it_obj, continue_loop, ERROR, "Iterated Pool object NULL");

        order = amxd_object_get_uint32_t(pool_it_obj, "Order", NULL);
        when_false_trace(order > 0, continue_loop, ERROR, "Failed to get Pool Order Parameter");

        when_false(min_order == 0 || order >= min_order, continue_loop);
        when_false(max_order == 0 || order <= max_order, continue_loop);

        update_pool(pool_it_obj);
continue_loop:
        continue;
    }
exit:
    return;
}

/**
 * @brief
 * Handles changes to the DHCPv4 server pool "Enable" parameter.
 * Called when the TR-181 DHCPv4.Server.Pool data model object's 'Enable' parameter is modified.
 *
 * If the pool is enabled and the DHCPv4 server is active, the pool is activated and ready for IP allocation.
 * If the pool is disabled and the DHCPv4 server is active, bindings are removed and the pool is deactivated.
 * If the DHCPv4 server itself is disabled, the change is recorded in the data model but no pool actions are performed.
 *
 * @param event_name event name
 * @param event_data event data
 * @param priv private data associated with event subscription
 */
void _pool_enable_changed(UNUSED const char* const event_name,
                          const amxc_var_t* const event_data,
                          UNUSED void* const priv) {

    amxd_dm_t* dm = NULL;
    amxd_object_t* pool = NULL;
    bool server_enabled = false;

    SAH_TRACEZ_INFO(ME, "DHCPv4 server pool 'Enable' parameter updated in TR-181 data model");
    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");

    dm = dhcp_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DHCPv4 data model.");
    pool = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(pool, exit, ERROR, "Cannot get DHCPv4 pool object.");
    bool enable = 0;
    enable = GETP_BOOL(event_data, "parameters.Enable.to");

    amxd_object_t* dhcpv4_obj = amxd_dm_findf(dm, "%s", DHCP_SERVER);
    when_null_trace(dhcpv4_obj, exit, ERROR, "DHCPv4Server object not found");

    server_enabled = amxd_object_get_value(bool, dhcpv4_obj, "Enable", NULL);
    when_false_trace(server_enabled, exit, WARNING,
                     "Pool 'Enable' parameter updated in datamodel, but DHCPv4Server is disabled!");

    if(enable) {
        pool_info_enable(pool);
    } else {
        pools_remove_bindings(pool);
        pool_info_disable(pool);
    }

exit:
    return;
}

/**
 * @brief
 * Updates a DHCPv4 server pool.
 * Called when a TR181 DHCPv4.Server.Pool data model object instance is changed.
 *
 * When the "Order" parameter is changed only that Order change will trigger an event.
 * All subsequently updated Order Parameters (incrementing and compacting) won't trigger an event.
 * These will need to be triggered manually
 *
 * @param event_name event name
 * @param event_data event data
 * @param priv private data associated with event subscription
 */
void _pool_changed(UNUSED const char* const event_name,
                   const amxc_var_t* const event_data,
                   UNUSED void* const priv) {

    amxd_dm_t* dm = NULL;
    amxd_object_t* pool = NULL;
    uint32_t to_order = 0;
    uint32_t from_order = 0;
    amxc_var_t* iface = NULL;

    amxc_var_t* maxaddr_var = NULL;
    amxc_var_t* minaddr_var = NULL;
    amxc_var_t* dns_servers_var = NULL;
    amxc_var_t* ip_routers_var = NULL;
    amxc_var_t* domain_name_var = NULL;
    amxc_var_t* interface_var = NULL;
    amxc_var_t* leaseTime_var = NULL;
    amxc_var_t* subnet_mask_var = NULL;

    SAH_TRACEZ_INFO(ME, "DHCPv4 server pool has been changed in TR-181 data model");
    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");

    dm = dhcp_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DHCPv4 data model.");
    pool = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(pool, exit, ERROR, "Cannot get DHCPv4 pool object.");

    to_order = GETP_UINT32(event_data, "parameters.Order.to");
    if(to_order == 0) {
        update_pool(pool);
    } else {
        uint32_t min_order = 0;
        uint32_t max_order = 0;
        from_order = GETP_UINT32(event_data, "parameters.Order.from");

        if(from_order > to_order) {
            min_order = to_order;
            max_order = from_order;
        } else {
            min_order = from_order;
            max_order = to_order;
        }

        handle_pool_order_changes(amxd_object_get_parent(pool),
                                  min_order, max_order);
    }
    /* This may seem like an overkill but we should forget the pool's bindings
     * at this point. */

    interface_var = GETP_ARG(event_data, "parameters.Interface");
    subnet_mask_var = GETP_ARG(event_data, "parameters.SubnetMask");
    maxaddr_var = GETP_ARG(event_data, "parameters.MaxAddress");
    minaddr_var = GETP_ARG(event_data, "parameters.MinAddress");
    dns_servers_var = GETP_ARG(event_data, "parameters.DNSServers");
    ip_routers_var = GETP_ARG(event_data, "parameters.IPRouters");
    domain_name_var = GETP_ARG(event_data, "parameters.DomainName");
    leaseTime_var = GETP_ARG(event_data, "parameters.LeaseTime");

    /* Update pool->priv->intf_path if Interface changed */
    pool_info_t* info = (pool_info_t*) pool->priv;
    when_null_trace(info, exit, ERROR, "Cannot get private pool info data from pool object.");

    if(interface_var) {
        iface = GETP_ARG(interface_var, "to");
        if(iface) {
            free(info->intf_path);
            info->intf_path = amxc_var_dyncast(cstring_t, iface);
            info->flags.bit.intf_ok = 1;
        }
    }

    if(interface_var || subnet_mask_var
       || maxaddr_var || minaddr_var
       || leaseTime_var || dns_servers_var
       || ip_routers_var || domain_name_var) {

        amxc_var_t args;
        amxc_var_t ret;

        amxc_var_init(&args);
        amxc_var_init(&ret);
        pools_remove_bindings(pool);
        _cleanClientLeases(pool, NULL, &args, &ret);

        amxc_var_clean(&args);
        amxc_var_clean(&ret);
        when_failed_trace(pools_update_pool_status(pool), exit, ERROR, "Failed to update DHCPv4 pool status");
    }

exit:
    return;
}

/**
 * @brief
 * callback function when data managing the filter association criterion changes
 *
 * @param event_name name of the event
 * @param event_data change done in the vendor class data
 * @param priv Not used
 */
void _pool_filtered_changed(UNUSED const char* const event_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    amxd_object_t* pool = NULL;
    pool_info_t* info = NULL;

    pool = amxd_dm_signal_get_object(dhcp_get_dm(), event_data);
    when_null_trace(pool, exit, ERROR, "Cannot get DHCPv4 pool option object.");

    info = (pool_info_t*) pool->priv;
    when_null_trace(info, exit, ERROR, "DHCPv4 pool private data is NULL");
    SAH_TRACEZ_INFO(ME, "enable when filter changed : %d", info->flags.bit.enable);
    if(info->flags.bit.enable == 1) {
        when_failed_trace(pools_update_pool_status(pool), exit, ERROR, "Failed to update DHCPv4 pool status");
    }
exit:
    return;
}

/**
 * @brief
 * A pool has been removed from the data model. Update the orders.
 *
 * @param event_name name of the event
 * @param event_data change done in the vendor class data
 * @param priv Not used
 */
void _pool_removed(UNUSED const char* const event_name,
                   UNUSED const amxc_var_t* const event_data,
                   UNUSED void* const priv) {
    SAH_TRACE_IN();
    amxd_object_t* pools = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.");

    when_null_trace(pools, exit, ERROR, "Cannot get DHCPv4 Pool template object.");

    handle_pool_order_changes(pools, 0, 0);
exit:
    SAH_TRACE_OUT();
    return;
}

/**
 * @brief
 * DHCPv4Server.Pool.{i} callback when a static address change to update known devices if AllowDevices != "All"
 *
 * @param event_name The name of the event
 * @param event_data Data of the StaticAddress added/changed
 * @param priv not used
 */
void _pool_known_client_changed(const char* const event_name,
                                const amxc_var_t* const event_data,
                                UNUSED void* const priv) {
    amxd_object_t* event_object = NULL;
    amxd_object_t* pool = NULL;
    bool enable = false;
    char* allow = NULL;

    when_null_trace(event_name, exit, ERROR, "No event name given");
    when_null_trace(event_data, exit, ERROR, "No event data given");

    event_object = amxd_dm_signal_get_object(dhcp_get_dm(), event_data);
    when_null_trace(event_object, exit, ERROR, "Cannot retrieve event object");

    if(strcmp(event_name, "dm:object-changed") == 0) {
        pool = amxd_object_get_parent(amxd_object_get_parent(event_object));
    } else {
        pool = amxd_object_get_parent(event_object);
    }

    when_null_trace(pool, exit, ERROR, "Cannot retrieve Pool object");

    enable = amxd_object_get_value(bool, pool, "Enable", NULL);
    allow = amxd_object_get_value(cstring_t, pool, "AllowedDevices", NULL);

    when_str_empty_trace(allow, exit, ERROR, "No allow rule given");

    if(enable && (strcmp(allow, "All") != 0)) {
        pool_info_enable(pool);
    }

exit:
    free(allow);
    return;
}

/**
 * @brief
 * Construct from a list of ips, an hex string by removing the comma
 *
 * @param hex_value The return value
 * @param value The list of ips, comma separated
 */
static void construct_hex_value(amxc_string_t* hex_value, char* value) {
    char* octets = NULL;
    when_null_trace(hex_value, exit, ERROR, "The hex value is not initialized");
    when_str_empty_trace(value, exit, ERROR, "WINSServers value is empty");

    octets = strtok(value, ".,");
    while(octets != NULL) {
        int oct_val = atoi(octets);
        amxc_string_appendf(hex_value, "%s%X", (oct_val > 15) ? "" : "0", oct_val);
        octets = strtok(NULL, ".,");
    }

exit:
    return;
}

void _pool_winsserver_changed(UNUSED const char* const event_name,
                              const amxc_var_t* const event_data,
                              UNUSED void* const priv) {
    char* winsserver = NULL;
    const char* pool_str = NULL;
    amxc_string_t hex_value;
    const char* hex_value_str = NULL;
    amxd_object_t* option_obj = NULL;
    amxd_object_t* option_44 = NULL;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxc_string_init(&hex_value, 0);

    when_null_trace(event_data, exit, ERROR, "No event data provided");
    winsserver = amxc_var_dyncast(cstring_t, GETP_ARG(event_data, "parameters.0.to"));
    when_null_trace(winsserver, exit, ERROR, "Couldn't parse the WINSServers value");

    pool_str = GET_CHAR(event_data, "object");
    when_null_trace(pool_str, exit, ERROR, "No pool object provided");

    option_obj = amxd_dm_findf(dhcp_get_dm(), "%sOption.", pool_str);
    when_null_trace(option_obj, exit, ERROR, "No %sOption object found", pool_str);

    option_44 = amxd_dm_findf(dhcp_get_dm(), "%sOption.[Tag==44]", pool_str);

    if(str_empty(winsserver) && (option_44 != NULL)) {
        amxd_trans_select_object(&trans, option_obj);
        amxd_trans_del_inst(&trans, 0, amxd_object_get_name(option_44, AMXD_OBJECT_NAMED));
        when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot apply the transaction");
        goto exit;
    }

    construct_hex_value(&hex_value, winsserver);
    hex_value_str = amxc_string_get(&hex_value, 0);
    when_str_empty_trace(hex_value_str, exit, ERROR, "The value of option-44 is not constructed correctly");

    if(option_44 == NULL) {
        amxd_trans_select_object(&trans, option_obj);
        amxd_trans_add_inst(&trans, 0, "cpe-dhcp-44");
        amxd_trans_set_value(int8_t, &trans, "Tag", 44);
        amxd_trans_set_value(cstring_t, &trans, "Value", hex_value_str);
        amxd_trans_set_value(bool, &trans, "Enable", true);
    } else {
        amxd_trans_select_object(&trans, option_44);
        amxd_trans_set_value(cstring_t, &trans, "Value", hex_value_str);
    }

    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot apply the transaction");

exit:
    free(winsserver);
    amxc_string_clean(&hex_value);
    amxd_trans_clean(&trans);
    return;
}
