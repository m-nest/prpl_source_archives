﻿# **DHCP client with Enhanced DHCPv6 carrier-grade features**
[Requirements](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-requirements) 

[Introduction and High-Level Description](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-introductionandhigh-leveldescription)

[PSC Review Summary](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-pscreviewsummary)

[Use Case Definition](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-usecasedefinition)

[References](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-references)

[Architecture](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-architecture)

[Implementation](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-implementation) 

[High Level architecture](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-highlevelarchitecture)

[odhcp6c architecture.](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6carchitecture.)

[Components](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-components) 

[tr181-dhcpv6client](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-tr181-dhcpv6client)

[mod-odhcp6c](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-mod-odhcp6c)

[odhcp6c](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6c)

[Data Model](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-datamodel)

[Low-Level API](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-low-levelapi)

[API](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-api)

[Files](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-files)

[Firewall](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-firewall)

[Dependants and Dependencies](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependantsanddependencies) 

[Dependants](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependants)

[Dependencies](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependencies)

[tr181-dhcpv6client](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-tr181-dhcpv6client.1)

[mod-odhcp6c](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-mod-odhcp6c.1)

[odhcp6c](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6c.1)

[Configuration](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-configuration)

[Backup/Restore, Upgrade, Reset](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-backup/restore,upgrade,reset)

[Web UI](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-webui)

[Considerations](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-considerations) 

[IPv6](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-ipv6)

[Packet Acceleration](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-packetacceleration)

[Memory Usage](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-memoryusage)

[Boot Time](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-boottime)

[Security](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-security)

[Remote Management](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-remotemanagement)

[Operational Monitoring](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-operationalmonitoring)

[Quality](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-quality) 

[Project Reference Configuration](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-projectreferenceconfiguration)

[Build-time Checks](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-build-timechecks)

[Run-time Checks](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-run-timechecks)

[Unit Tests](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-unittests)

[Logging and Debugging](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-logginganddebugging)

[Functional Tests](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-functionaltests)

[CI Tests](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-citests)

[Certification](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-certification)

[Design Review Documentation](#dhcpclientwithenhanceddhcpv6carrier-gradefeatures-designreviewdocumentation)
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-requirements"></a>**Requirements**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
1. [PCF-1039](https://prplfoundationcloud.atlassian.net/browse/PCF-1039) DHCPv6 features: requirements missing altogether. Refined here:
   1. architecture task: selection of DHCPv6 client (code)
   1. requirement: behaviour in accordance with RFC7084. Test using CDRouter <https://support.qacafe.com/cdrouter/knowledge-base/test-setup-for-rfc-7084/> – **note**: LAN-side behaviour is linked
   1. set of *enhanced features*: configurable timers as per DEV2DM-946, authentication as per RFC3118 section 4.
   1. **action**: filter requirements from Operator specifications
1. [PCF-901](https://prplfoundationcloud.atlassian.net/browse/PCF-901): DHCPv4 code delivered, but DM is not yet in compliance with BBF DM enhancements: <https://issues.broadband-forum.org/browse/DEV2DM-946>: DHCPv4 and DHCPv6 timers → in or out of scope of this feature, which is only about DHCPv6 client?
1. Proposed additional requirements: extra metrics, which could be contributed to BBF. → [David Cluytens](https://prplfoundationcloud.atlassian.net/wiki/people/6374fa968fd2d2d5f12c5861?ref=confluence)
   1. DHCPv4 client has a hidden Stats object without parameters: <https://gitlab.com/prpl-foundation/components/core/plugins/tr181-dhcpv4client/-/blob/main/odl/dhcpv4c_definition.odl?ref_type=heads#L479>
   1. AT&T has pushed statistics reset PR’s to BBF; these should also be included.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-pscreviewsummary"></a>**PSC Review Summary**
Summary:

1. The DHCPv6 client to be used is OpenWrt's odhcp6c, which is currently used in prplOS. This guarantees that the current, very rich, OpenWrt functionality is not compromised. Modifications must be upstreamed to OpenWrt.
   1. SoftAtHome feedback: it may be necessary to create a ubus interface in odhcp6c, to provide a more dynamic interaction than the current script-based interface.
1. (WAN-side requirement) compliance with RFC7084 (Basic Requirement for IPv6 Customer Edge Routers) is required. RFC7084bis, in draft, must be reviewed. Compliance with RFC9096 (Improving the Reaction of Customer Edge Routers to IPv6 Renumbering Events) is required. CDRouter cpe\_v6 WAN-side tests must pass. The enhancements may not cause regressions in related behaviour (e.g. LAN-side address assignment).
   1. SoftAtHome feedback: Operator requirements may force the need for customisations to overrule the RFC-mandated behaviour.
1. The BBF introduced additional configurability of timing and retry algorithms in TR-181, in DEV2DM-946. This must be implemented.
1. RFC3118 section 4 (authentication token) must be implemented. Data model changes must be contributed to BBF's TR-181.
1. The ability to configure the DSCP value of the outgoing DHCPv6 packets must be added, and contributed to BBF's TR-181. prplOS' ability to map this to the appropriate upstream QoS queue, and translate to an appropriate VLAN PCP value, must be verified.
1. The following BBF DHCPv6 option 17 suboptions must be supported: TR-069 ACS discovery and TR-369 USP discovery. I valid option responses are received, the prplOS TR-069 client and/or TR-369 client must be dynamically configured accordingly.
1. It is unclear whether received NTP and upstream DNS server options are currently configured to the NTP client and DNS relay. They probably are. But if not, this must be implemented.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-usecasedefinition"></a>**Use Case Definition[](https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20\(%22PCF-1039%22%2C%22GREQ-546%22\)%20ORDER%20BY%20type%2C%20created%20DESC)**
<https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20(%22PCF-1039%22%2C%22GREQ-546%22)%20ORDER%20BY%20type%2C%20created%20DESC> 
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-references"></a>**References**
<https://datatracker.ietf.org/doc/html/rfc8415>

<https://datatracker.ietf.org/doc/html/rfc7084>

<https://datatracker.ietf.org/doc/html/rfc9096>

IANA: <https://www.iana.org/assignments/dhcpv6-parameters/dhcpv6-parameters.xhtml>

BBF DHCPv6 option 17 suboptions: <https://wiki.broadband-forum.org/display/BBF/Assigned+Names+and+Numbers#AssignedNamesandNumbers-DHCPv6Option17Sub-options>

<https://issues.broadband-forum.org/browse/DEV2DM-946>: DHCPv4 and DHCPv6 timers

<https://issues.broadband-forum.org/browse/DEV2DM-1042>: DHCP Client statistics

<https://www.rfc-editor.org/rfc/rfc3118.html> section 4: authentication token

<https://issues.broadband-forum.org/browse/DEV2DM-1043>: RFC3118 authentication

<https://wiki.broadband-forum.org/display/BBF/DHCP+Authentication+token>

<https://issues.broadband-forum.org/browse/DEV2DM-1042>: DHCP statistics

<https://issues.broadband-forum.org/browse/DEV2DM-1159>: DSCP mark, for client and server

[Carrier grade DHCPv6 client: odhcp6c impacts](file:///C:/wiki/spaces/PRPLWRT/pages/757956648/Carrier+grade+DHCPv6+client+odhcp6c+impacts)
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-architecture"></a>**Architecture**
Care must be taken to not break OpenWrt’s RFC7084 compliant implementation, with interworking between RA/SLAAC on WAN and LAN side, DHCPv6 IA\_NA/informational/PD on WAN and LAN, and NDP support.

Take renumbering scenarios into account as per RFC9096. As per [Timothy Winters](https://prplfoundationcloud.atlassian.net/wiki/people/5ee25498a7a4030ab38fa82f?ref=confluence), CDRouter status:

- We take some it into account in cpe\_v6 module but we don’t cover all the statements. We could add some tests if there is interest.
- I’m working on the 7084bis in the IETF (<https://datatracker.ietf.org/doc/draft-winters-v6ops-rfc7084bis/> ) which includes 9096. We will have full coverage there as well.

DHCPv6 client selection.

- RDK-B uses Dibbler: <https://github.com/tomaszmrugalski/dibbler>
- Default OpenWrt client: OpenWrt’s own<https://openwrt.org/docs/techref/odhcp6c>, which is controlled by <https://gitlab.com/prpl-foundation/components/core/plugins/tr181-dhcpv6client> in prplOS

Missing in tr181-dhcpv6client and odhcp6c:

- timer and retry algorithm heuristics as per newly added TR-181 DM parameters
- rfc3118 authentication and to be proposed TR-181 parameter(s) → in progress
- if additional dynamic state / metric updates are needed, it may make sense to add a ubus interface to odhcp6c
- DSCP value (and possibly VLAN PCP) to be used by the client. Missing from TR-181.
  - To be checked if VLAN egress map can be used to set the PCP value directly, and if skbprio is set accordingly for upstream queue selection.

Requested and received options.

- NTP server(s)
- DNS server(s)
- Option 17 TR-069 ACS discovery
- Option 17 TR-369 USP Controller discovery

Note: there seems to be no record of this being implemented in the DHCPv4 client; at least option 125.

Changes to upstream odhcp6c:

- Implementation of additional configurability of timing and retry algorithms in TR-181, per Device.DHCPv6.Client.Retransmission.
- Support for DHCPv6 Client statistics, e.g., received messages, transmitted messages, number of solicit messages, ...
- Support for the most relevant DHCPv6 Authentication mechanisms, and upstream the required data model changes to BBF's TR-181.
- Ability to configure the DSCP value of the outgoing DHCPv6 packets.
- ubus interface, allowing for dynamic reconfiguration without restarting the daemon, so the existing session is not affected.
- ubus interface also necessitates a rearchitecture to an event-based model, using a mainloop.

Adding dependencies undermines the ability to use it in non-OpenWrt platforms.

- The ubus interface should be a compile-time option.
- The event loop could be:
  - libubox: used in OpenWrt, but undermines the request to keep the code independent of OpenWrt
  - libevent: commonly used in open source projects, but not in OpenWrt
  - custom event loop without external dependencies: **selected**
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-implementation"></a>**Implementation**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-highlevelarchitecture"></a>**High Level architecture**
![](image/High_level_arch.png) 

The diagram shows the implementation with odhcp6c DHCPv6 client daemon :

- <https://gitlab.com/prpl-foundation/mirrors/odhcp6c>

The communication is made via UBUS events and RPC methods and is controlled by tr181-dhcpv6client in prplOS :

- <https://gitlab.com/prpl-foundation/components/core/plugins/tr181-dhcpv6client>
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6carchitecture."></a>**odhcp6c architecture.**
![](image/odhcp6c_architecture.png) 

DHCPv6 client in prplOS is composed of **tr181-dhcpv6client** exposing the datamodel and **mod-odhcp6c** managing the OpenWrt's **odhcp6c** deamon.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-components"></a>**Components**
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-tr181-dhcpv6client"></a>**tr181-dhcpv6client**
Main process of the plugin that manages the datamodel interactions and netmodel queries.

Several netmodel queries are opened when the Client datamodel is enabled to :

- Get physical interface and Linux netdev info (MAC, interface name) from the TR-181 path, Be informed of interface Status updates.
- Get router advertisement info for the interface.

A core module named **dm-dhcpv6c** is registered and the below functions are exported to be used by an external module **(mod-odhcp6c)** :

- *client*-*stopped* : Cleanup and emptied datamodel to reflect stopped client state
- *client-started* : Update datamodel status to reflect client state
- *client-misconfigured* : Update datamodel status to error-misconfigured
- *server-add* : Add server information to the datamodel
- *server-remove :* Remove server information from the datamodel
- *options-add :* Add received options info to the datamodel
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-mod-odhcp6c"></a>**mod-odhcp6c**
This module manages the odhcp6c daemon. Is is responsible for configuring, starting and stopping the DHCPv6 daemon, as well as treating new data coming via ubus.

The below functions are exported to be used by the core module **(dm-dhcpv6c) :**

- *start-dhcpv6c* : Start odhcp6c process or reconfigure the daemon via ubus based on the given configuration
- *stop-dhcpv6c :* Stop odhcp6c process
- *renew-dhcpv6c :* Force the renewing of the dhcpv6 leases by odhcp6c

After starting odhcp6c daemon, mod-odhcp6c subscribe to it on ubus (path = "*odhcp6c.{intfname}."*) to receive all new data on state change.

“DHCPV6\_STATE” events (identical to the response of a get\_state function) are received under the following format:

- *RDNSS*: An array of recursive DNS servers
- *DOMAINS*: An array of DNS search domains
- *SNTP\_IP*: An array of SNTP server IP addresses
- *SNTP\_FQDN*: An array of SNTP server FQDNs
- *SIP\_IP*: An array of SIP servers
- *SIP\_DOMAIN*: An array of SIP domains
- *OPTION\_*<*num*>: Custom option received as base-16
- *PREFIXES*: An array of prefixes currently assigned
  - Parameters key: target, length, preferred, valid, [excluded, excluded\_length]
- *ADDRESSES*: An array of addresses currently assigned
  - Parameters key: address, length, preferred, valid
- *RA\_ADDRESSES*: An array of addresses from RA-prefixes
  - Parameters key: address, length, preferred, valid
- *RA\_ROUTES*: An array list of routes from the RA
  - Parameters key: address, length, gateway, valid, metric
- *RA\_DNS*: An array of recursive DNS servers from the RA
- *RA\_DOMAINS*: An array of DNS search domains from the RA
- *RA\_HOPLIMIT*: Highest hop-limit received in RAs
- *RA\_MTU*: MTU-value received in RA
- *RA\_REACHABLE*: ND Reachability time
- *RA\_RETRANSMIT: ND Retransmit time*
- *AFTR*: The DS-Lite AFTR domain name
- *MAPE / MAPT / LW4O6:* Softwire rules for MAPE, MAPT and LW4O6

It also uses the following odhcp6c ubus methods :

- get\_statistics() : On each **DHCPv6Client.Client.1.Stats.** datamodel object read, to get the latest packet statistics.
- reset\_statistics() : Zero all statistics.
- reconfigure\_dhcp() : On every configuration change, often triggered by a datamodel interaction. A dynamic reconfiguration occurs without restarting the daemon and reseting the statistics.
- get\_state() : get current received configuration.
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6c"></a>**odhcp6c**
This daemon is a lightweight DHCPv6 client (and RA-client but, its parameters on reception of RA are not used. In prplOS, this functionality is duplicated in tr181-routing).

odhcpv6c has been re-architectured to an event-based model to implement an (optional compile-time) ubus interface.

odhcp6c's datamodel is available on ubus path : "odhcp6c.{ifname}." where {ifname} is the linux netdev interface name given as a start argument for odhcp6c process.

Communication over ubus simplifies data transfer with mod-odhcp6c by implementing methods and events like :

- get\_state() : Returns the DHCPv6 state
- get\_statistics() : Returns the packet statistics 
- reset\_statistics() : Reset packet statistics
- reconfigure\_dhcp() : Reconfigure DHCP settings

The new start argument -E has been added to disable the script mechanism and exclusively use ubus event to report DHCP state change.

Full documentation of odhcp6c methods is available in the README : [https://gitlab.com/prpl-foundation/mirrors/odhcp6c/-/blob/gen_bcd28363/README?ref_type=head](https://gitlab.com/prpl-foundation/mirrors/odhcp6c/-/blob/gen_bcd28363/README?ref_type=heads)

NOTES:

- Backward compatibility with old tr181-dhcpv6client version can be achieved with CONFIG\_ODHCP6C\_ENABLE\_UBUS=n
  - The ubus interface will be completely disabled
  - The event-loop will still be used for the DHCPv6 transmission
  - The old script mechanism will be used to get data from odhcp6c
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-datamodel"></a>**Data Model**
Default value for DSCP should be 0x30 as per [QoS](file:///C:/wiki/spaces/LLAPI/pages/16384124/QoS). This default value was accepted in the addition of the DSCPMark in DHCPv4 and DHCPv6, for server and client.

|**Name**|**Type**|**W/P/V**|**Description**|**Legal Values/Default**|**Action on Add/Delete/Modify**|**Version**|
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
|**DHCPv6Client**|**Object**|**RP**|**The Dynamic Host Configuration Protocol (DHCP) IPv6 object [RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=RFC3315&linkCreation=true&fromPageId=398960427). This entire object applies to IPv6 only. It contains the Client and Server objects.**|**–**||**V1.0**|
|ClientSupportedControllers|csv\_string|R|Only modules that are added to this comma separated list can be configured in the Controller parameter under the Client instance. The name used should be the name of the so file without the extension.|**default**: mod-odhcp6c|–|V1.0|
|SupportedFWControllers|csv\_string|R|Comma-separated list of firewall modules that can be configured.|**default**: mod-fw-amx|–|1\.0|
|update()|function|–|*void* **update**(*in string* mod\_name, *in string* fnc, *in table* data)<br>update is generic function to facilitate calling a function of the specified module.<br>**mod\_name**: Module name<br>**fnc**: name of function to call<br>**data**: specific to the calling function<br>**returns**:|–|–|1\.6.0-3-ga90fa82|
|ClientNumberOfEntries|uint32|R|The number of entries in the Client table.|**Instance counter for**:|–|V1.0|
|**DHCPv6Client.Client.{i}**|**Object**|**RWP**|**This object contains DHCPv6 client settings for an associated IP Interface indicated by Interface.**|**–**||**V1.0**|
|Enable|bool|RWP|Enables or disables the DHCP Client entry.|**default**: false|–|V1.0|
|Alias|string|RW|A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.|**default**:|–|V1.0|
|ResetOnPhysDownTimeout|int32|RWP|A DHCP client is never started before its lower layers are up. Whether and when the DHCP client should be shut down again when one of the lower layers go down can be configured by this parameter. If it is set to zero, which is the default, the DHCP client is shut down immediately after a lower layer went down. A positive value indicates a timeout in milliseconds: the DHCP client will only be shut down if a lower layer remains down for at least ResetOnPhysDownTimeout milliseconds. A negative value indicates that the DHCP client should never be shut down based on lower layer states. In any case, when the lower layers are up again, the DHCP client is always restarted if it was down.|**default**: 1000|–|V1.0|
|Interface|string|RWP|The value MUST be the Path Name of a row in the IP.Interface table. If the referenced object is deleted, the parameter value MUST be set to an empty string. The IP Interface associated with the Client entry. This will reference an IPv6-capable interface (that is attached to the IPv6 stack), otherwise the table entry will be inoperable.|**default**:|–|V1.0|
|Status|string|R|The status of this table entry. Enumeration of: - Disabled - Enabled - Error\_Misconfigured|**default**: Disabled|–|V1.0|
|DUID|string|R|The client's DHCP Unique Identifier (DUID) [Section 9/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+9%2FRFC3315&linkCreation=true&fromPageId=398960427). DUID is set by the CPE. A hexbinary encoded value.|**default**:|–|V1.0|
|RequestAddresses|bool|RWP|Enables or disables inclusion of the Identity Association (IA) for Non-Temporary Address option OPTION\_IA\_NA(3) [Section 22.4/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.4%2FRFC3315&linkCreation=true&fromPageId=398960427) in Solicit messages.|**default**: true|–|V1.0|
|RequestPrefixes|bool|RWP|Enables or disables inclusion of the Identity Association (IA) for Prefix Delegation option OPTION\_IA\_PD(25) [Section 10/RFC3633](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+10%2FRFC3633&linkCreation=true&fromPageId=398960427) in Solicit messages.|**default**: false|–|V1.0|
|RapidCommit|bool|RWP|Enables or disables inclusion of the Rapid Commit option OPTION\_RAPID\_COMMIT(14) [Section 22.14/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.14%2FRFC3315&linkCreation=true&fromPageId=398960427) in Solicit messages.|**default**: false|–|V1.0|
|SuggestedT1|int32|RWP|T1 value, in seconds, that the client SHOULD use when sending IA options, e.g. OPTION\_IA\_NA [Section 22.4/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.4%2FRFC3315&linkCreation=true&fromPageId=398960427) and OPTION\_IA\_PD [Section 10/RFC3633](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+10%2FRFC3633&linkCreation=true&fromPageId=398960427).|**default**: -1|–|V1.0|
|SuggestedT2|int32|RWP|T1 value, in seconds, that the client SHOULD use when sending IA options, e.g. OPTION\_IA\_NA [Section 22.4/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.4%2FRFC3315&linkCreation=true&fromPageId=398960427) and OPTION\_IA\_PD [Section 10/RFC3633](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+10%2FRFC3633&linkCreation=true&fromPageId=398960427).|**default**: -1|–|V1.0|
|SupportedOptions|csv\_string|R|Comma-separated list of unsigned integers. The options that the client is able to process in server responses. This list MUST include both top-level and encapsulated options, e.g. if the client is able to process OPTION\_IA\_NA (3) with an encapsulated OPTION\_IAADDR (5), the list would be expected to include both 3 and 5.|**default**: 23,31|–|V1.0|
|RequestedOptions|csv\_string|RWP|Comma-separated list of unsigned integers. An ordered list of the top-level options (i.e. not encapsulated options) that the client will explicitly request from the server.|**default**: 23,31,32,64,65|–|V1.0|
|Renew()|function|–|*void* **Renew**()<br>The DHCP client will renew its DHCP lease.<br>**returns**:|–|–|1\.6.0-3-ga90fa82|
|X\_PRPL-COM\_Release()|function|–|*void* **X\_PRPL-COM\_Release**()<br>The DHCP client shutdown and trigger a new negotiation.<br>**returns**:|–|–|1\.6.0-3-ga90fa82|
|Renew|bool|RW|The Client will renew its DHCPv6-supplied information (i.e. the Agent will do a renew or information request as needed, updating both stateful and stateless parameter values discovered by this Client instance).|**default**:|–|V1.0|
|X\_PRPL-COM\_Release|bool|RW|The DHCP client shutdown and trigger a new negotiation|**default**:|–|V1.0|
|DSCP|uint32|RWP|DSCP value used in DHCPv6 packets header.|**default**: 0|–|1\.0|
|RequestAddressesStatus|string|R|The status of the client regarding the requesting of IANA. - Disabled - Enabled|**default**: Disabled|–|V1.0|
|RequestPrefixesStatus|string|R|The status of the client regarding the requesting of IAPD. - Disabled - Enabled|**default**: Disabled|–|V1.0|
|ServerNumberOfEntries|uint32|R|The number of entries in the Server table.|**Instance counter for**:|–|V1.0|
|SentOptionNumberOfEntries|uint32|R|The number of entries in the SentOption table.|**Instance counter for**:|–|V1.0|
|ReceivedOptionNumberOfEntries|uint32|R|The number of entries in the ReceivedOption table.|**Instance counter for**:|–|V1.0|
|**DHCPv6Client.Client.{i}.Server.{i}**|**Object**|**R**|**This is a transitory table that lists the discovered DHCPv6 servers (it does not model a local DHCP server). Table entries are automatically created to correspond with these servers. However, it is a local matter to the CPE when to delete old table entries.**|**–**||**V1.0**|
|SourceAddress|string|R|[IPv6Address](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IPv6Address&linkCreation=true&fromPageId=398960427) The IP address from which the message most recently received from this server was sent.|**default**:|–|V1.0|
|DUID|string|R|The server's DHCP Unique Identifier (DUID) [Section 9/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+9%2FRFC3315&linkCreation=true&fromPageId=398960427) as received via OPTION\_SERVERID.|**default**:|–|V1.0|
|InformationRefreshTime|datetime|R|The OPTION\_INFORMATION\_REFRESH\_TIME value [RFC4242](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=RFC4242&linkCreation=true&fromPageId=398960427) that was most recently received from this server, converted to the dateTime at which the associated information will expire. If no such option has been received, the parameter value MUST be the "Unknown Time" 0001-01-01T00:00:00Z. If the information will never expire, the parameter value MUST be infinite time 9999-12-31T23:59:59Z.|**default**: 0001-01-01T00:00:00Z|–|V1.0|
|**DHCPv6Client.Client.{i}.SentOption.{i}**|**Object**|**RWP**|**The top-level options and option values (including any encapsulated options) that the client will send to the server.**|**–**||**V1.0**|
|Enable|bool|RWP|Enables or disables this SentOption table entry.|**default**: false|–|V1.0|
|Alias|string|RW|A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.|**default**:|–|V1.0|
|Tag|uint16|RWP|Option tag (code) [Section 22.1/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.1%2FRFC3315&linkCreation=true&fromPageId=398960427).|**default**:|–|V1.0|
|Value|string|RWP|A hexbinary encoded option data [Section 22.1/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.1%2FRFC3315&linkCreation=true&fromPageId=398960427).|**default**:|–|V1.0|
|**DHCPv6Client.Client.{i}.Retransmission**|**Object**|**RP**|**This object enables the configurion of the DHCPv6 retransmission behavior according to the guidelines described in [Section 7.6/RFC8415](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+7.6%2FRFC8415&linkCreation=true&fromPageId=398960427).**|**–**||**2.18**|
|SolicitMaxTimeout|uint32|RWP|Maximum solicit timeout value, expressed in seconds.|**default**: 3600|–|2\.18|
|**DHCPv6Client.Client.{i}.ReceivedOption.{i}**|**Object**|**R**|**This is a transitory table that lists all the options received from all servers. Table entries are automatically created to correspond with received options. However, it is a local matter to the CPE when to delete old table entries.**|**–**||**V1.0**|
|Tag|uint16|R|Option tag (code) [Section 22.1/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.1%2FRFC3315&linkCreation=true&fromPageId=398960427).|**default**:|–|V1.0|
|Value|string|R|A hexbinary encoded option data [Section 22.1/RFC3315](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Section+22.1%2FRFC3315&linkCreation=true&fromPageId=398960427).|**default**:|–|V1.0|
|Server|string|R|The value MUST be the Path Name of a row in the Server table. If the referenced object is deleted, the parameter value MUST be set to an empty string. This is the server that sent the option to the client. Each ReceivedOption entry MUST have an associated server.|**default**:|–|V1.0|
|LastUpdate|datetime|R|Timestamp for when this ReceivedOption last received an update|**default**:|–|1\.0|
|**DHCPv6Client.Client.{i}.Stats**|**Object**|**R**|**Provide statistics for the embedded DHCPv6 Client.**|**–**||**2.19**|
|Solicit|uint64|RV|The total number of SOLICIT messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Advertise|uint64|RV|The total number of ADVERTISE messages received by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Request|uint64|RV|The total number of REQUEST messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Confirm|uint64|RV|The total number of CONFIRM messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Renew|uint64|RV|The total number of RENEW messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Rebind|uint64|RV|The total number of REBIND messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Reply|uint64|RV|The total number of REPLY messages received by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Release|uint64|RV|The total number of RELEASE messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Decline|uint64|RV|The total number of DECLINE messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|Reconfigure|uint64|RV|The total number of RECONFIGURE messages received by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|InformationRequest|uint64|RV|The total number of INFORMATION-REQUEST messages sent by the client, as defined in RFC8415-Dynamic Host Configuration Protocol for IPv6.|**default**:|–|2\.19|
|DiscardedPackets|uint64|RV|The total number of DHCP packets discarded by the client. Packets can be discarded due to illegal message format and content, incorrect received bytes, etc.|**default**:|–|2\.19|
|TransmitFailure|uint64|RV|The total number of DHCP messages that failed to transmit.|**default**:|–|2\.19|
|**DHCPv6Client.Client.{i}.X\_PRPL-COM\_Config**|**Object**|**R**|**Timing information send to the IPV6 Client**|**–**||**1.0**|
|LastT1SentWhen|datetime|RP|Last time T1 was send|**default**: 0001-01-01T00:00:00Z|–|**1.0**|
|LastT2SentWhen|datetime|RP|Last time T2 was send|**default**: 0001-01-01T00:00:00Z|–|**1.0**|
|T1Renewed|bool|RP|T1 was renewed successfully|**default**: 0|–|**1.0**|
|T2Renewed|bool|RP|T2 was renewed successfully|**default**: 0|–|**1.0**|
|LeaseRenewedWhen|datetime|R|Last renewed lease|**default**:|–|**1.0**|
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-low-levelapi"></a>**Low-Level API**
3 different API’s are available (already detailed in the Component Section) :

- amx module API exposed by **m-dhcpv6c** module to manage the datamodel
- amx module API exposed by **mod-odhcp6c** module to manage the odhcp6c daemon
- ubus API exposed by **odhcp6c** daemon to communicate with others ubus process.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-api"></a>**API**
- TR181 HL API <https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html>
- Client Stats object is only introduced in version 2.19.0
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-files"></a>**Files**
* /usr/bin/tr181-dhcpv6client
* /usr/lib/amx/tr181-dhcpv6client/tr181-dhcpv6client.so
* /usr/lib/amx/tr181-dhcpv6client/modules/mod-odhcp6c.so
* /etc/amx/tr181-dhcpv6/defaults.d/10\_wan\_client.odl
* /etc/amx/tr181-dhcpv6client/dhcpv6c.odl
* /etc/amx/tr181-dhcpv6client/dhcpv6c\_definition.odl
* /etc/amx/tr181-dhcpv6client/tr181-dhcpv6client.odl
* /etc/init.d/tr181-dhcpv6client
* /etc/rc.d/S25tr181-dhcpv6client
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-firewall"></a>**Firewall**
A properly configured Client with a correct path in the Interface parameter will call Firewall.setService() before starting the odhcp6c component. This will make the Firewall be open for the necessary interface on UDP port 546. When disabled and after receiving a "stopped" action of the dhcpv6 component or when the interface state is down, firewall for UDP port 546 is closed.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependants"></a>**Dependants**
- WANManager.
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-dependencies"></a>**Dependencies**
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-tr181-dhcpv6client.1"></a>**tr181-dhcpv6client**
- NetModel must be used  to translate between tr181 path and physical interface name and to know when the linux netdev interface is up and running.
- Ambiorix deps
  - libamxc, libamxd, libamxm, libamxo, libamxp
- libsahtrace
- mod-dmext
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-mod-odhcp6c.1"></a>**mod-odhcp6c**
- Ambiorix deps:
  - libamxc, libamxd, libamxm, libamxo, libamxp,libamxb
- libsahtrace
- libdhcpoptions
### <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-odhcp6c.1"></a>**odhcp6c**
- libubox
- libubus
- resolv
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-configuration"></a>**Configuration**
**BOOL: SAH\_AMX\_TR181\_DHCPV6CLIENT**

- Build the TR-181 compatible DHCPv6 client manager

**BOOL: CONFIG\_ODHCP6C\_ENABLE\_UBUS**

- Build odhcp6c with ubus support, should be enabled on prplOS, disabled if you use it for standard openwrt.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
DHCPv6 configuration is only reboot persistent.

Upgrade persistent is not required for now.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-webui"></a>**Web UI**
N/A
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-considerations"></a>**Considerations**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-ipv6"></a>**IPv6**
To verify whether the implementation introduces any regressions in RFC7084 compliance, the CDRouter cpe\_v6 module tests must be run and must pass.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-packetacceleration"></a>**Packet Acceleration**
N/A
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-memoryusage"></a>**Memory Usage**
Memory usage is low.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-boottime"></a>**Boot Time**
The impact of the DHCPv6 Client startup should be minimal. The DHCPv6 process is started asynchronously and should not affect the boottime.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-security"></a>**Security**
Both the plugin as the odhcpv6c process executes with the tr181\_app user and drop all the capabilities except:

- CAP\_KILL : To kill odhcp6c process
- CAP\_NET\_BIND\_SERVICE :  To be inherited by odhcp6c and allow it to bind to a socket
- CAP\_NET\_RAW : To be inherited by odhcp6c and allow it to bind to a socket
- CAP\_DAC\_OVERRIDE : To allow odhcp6c to inherit above capabilities
- CAP\_SETFCAP : To allow odhcp6c to inherit above capabilities
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-remotemanagement"></a>**Remote Management**
The Plugin provides a TR181 Compatible Datamodel API to be used for remote configuration.
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-operationalmonitoring"></a>**Operational Monitoring**
See Data model parameters and
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-quality"></a>**Quality**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-build-timechecks"></a>**Build-time Checks**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-run-timechecks"></a>**Run-time Checks**
|Test 1|DHCPv6 Client on wan, <br>DUID|<p>command:</p><p>1. Default configuration, 1 client on wan (path IP.Interface.2.).</p><p>2. Assuming connection on wan</p><p>3. DHCPv6 Server active on wan</p><p>output:</p><p>DHCPv6.Client.1.DUID verification</p><p>- Length is 20 hexadecimal digits</p><p>- Starts with '00030001'</p>||
| :- | :- | :- | :- |
|Test 2|multi-instance object Server|<p>command:</p><p>1. WAN connected to DHCPv6 server.</p><p>2. Wait a few seconds</p><p>output:</p><p>After '2.', verify that received option 2 is equal to DUID of Server instance</p><p>- DHCPv6.Client.1.Server.1.DUID == DHCPv6.Client.1.ReceivedOption.[Tag==2&&Server=='DHCPv6.Client.1.Server.1'].Value</p>||
|Test 3|Toggle Enable|<p>command:</p><p>1. DHCPv6.Client.1.Enable=0</p><p>2. Wait a few seconds, check result</p><p>3. DHCPv6.Client.1.Enable=1</p><p>4. Wait a few seconds</p><p>output:</p><p>After '2.', verify that</p><p>- DHCPv6.Client.1.Server.1. instance is removed</p><p>- All ReceivedOption instances are also removed </p><p>- DHCPv6.Client.1.Status = "Disabled"</p><p>After '4. verify that</p><p>- existence of DHCPv6.Client.1.Server.2</p>||
|Test 4|Removal of Client instance|<p>command:</p><p>1. ubus-cli  DHCPv6.Client.1.-</p><p>output:</p><p>Should result in an error code (11)</p>||
|Test 5|Add new Client instance|<p>command:</p><p>1. ubus-cli  DHCPv6.Client.+</p><p>output:</p><p>Check DHCPv6.Client.2.Status=="Disabled"</p>||
|Test 6|Change interface name|<p>command:</p><p>1. Get Interface path for 'lo'</p><p>2. ubus-cli DHCPv6.Client.1.Interface="IP.Interface.x" where x is index for path to 'lo'</p><p>output:</p><p>Verify</p><p>- DHCPv6.Client.1.Server.2. instance is removed</p><p>- DHCPv6.Client.1.ReceivedOption.\* instances are removed </p><p>- DHCPv6Client.1.Status == "Error\_Misconfigured"</p>||
|Test 7|Removal of Client instance|<p>command:</p><p>1. ubus-cli  DHCPv6.Client.1.-</p><p>output:</p><p>DHCPv6.Client.1. removed</p>||
|Test 8|Change interface name|<p>command:</p><p>1. Assuming IP.Interface.2. points to wan</p><p>2. ubus-cli DHCPv6.Client.2.Enable=1</p><p>3. ubus-cli DHCPv6.Client.2.Interface="IP.Interface.2."</p><p>output:</p><p>Verify</p><p>- Existence of DHCPv6.Client.2.Server instance</p><p>- Existence of DHCPv6.Client.2.ReceivedOption instance</p>||
|Test 9|Timer should be launch before going to disable state|<p>command:</p><p>1. Check that the DHCPv6 Client is Enabled</p><p>DHCPv6Client.Client.</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID=""</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=5</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.ResetOnPhysDownTimeout=10000</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=1</p><p>DHCPv6Client.Client.1.Status="Enabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>2. Shut down the wan link.</p><p>output:</p><p>Verify that the DHCPv6 Client stay Enabled for *ResetOnPhysDownTimeout* then goes to the status disabled.</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID=""</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.ResetOnPhysDownTimeout=10000</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=0</p><p>DHCPv6Client.Client.1.Status="Disabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p>||
|13|When calling the release function of a client, a release message should be send over the interface link to the client|<p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=4</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=1</p><p>DHCPv6Client.Client.1.Status="Enabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>DHCPv6Client.Client.1.ReceivedOption.1.</p><p>DHCPv6Client.Client.1.ReceivedOption.1.Server="DHCPv6Client.Client.1.Server.1."</p><p>DHCPv6Client.Client.1.ReceivedOption.1.Tag=23</p><p>DHCPv6Client.Client.1.ReceivedOption.1.Value="FEC00000000000010000000000000001"</p><p>DHCPv6Client.Client.1.ReceivedOption.2.</p><p>DHCPv6Client.Client.1.ReceivedOption.2.Server="DHCPv6Client.Client.1.Server.1."</p><p>DHCPv6Client.Client.1.ReceivedOption.2.Tag=1</p><p>DHCPv6Client.Client.1.ReceivedOption.2.Value="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.ReceivedOption.3.</p><p>DHCPv6Client.Client.1.ReceivedOption.3.Server="DHCPv6Client.Client.1.Server.1."</p><p>DHCPv6Client.Client.1.ReceivedOption.3.Tag=2</p><p>DHCPv6Client.Client.1.ReceivedOption.3.Value="000100012D4BA4BCB827EBD37550"</p><p>DHCPv6Client.Client.1.ReceivedOption.4.</p><p>DHCPv6Client.Client.1.ReceivedOption.4.Server="DHCPv6Client.Client.1.Server.1."</p><p>DHCPv6Client.Client.1.ReceivedOption.4.Tag=25</p><p>DHCPv6Client.Client.1.ReceivedOption.4.Value="00000001000000B600000127001A00190000016D0000024E3820010DB800000F000000000000000000"</p><p>DHCPv6Client.Client.1.Server.1.</p><p>DHCPv6Client.Client.1.Server.1.DUID="000100012d4ba4bcb827ebd37550"</p><p>DHCPv6Client.Client.1.Server.1.InformationRefreshTime="0001-01-01T00:00:00Z"</p><p>DHCPv6Client.Client.1.Server.1.SourceAddress="fe80::2135:b895:89d7:dee"</p><p>**Call the release RPC :**</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.X\_PRPL\_COM\_Release()</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release() returned</p><p>[</p><p>`    `""</p><p>]</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=0</p><p>DHCPv6Client.Client.1.Status="Error\_Misconfigured"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>-----</p><p>and a release message should be seen on the network</p><p>-----</p><p>**Restart the dhcpv6 client :**</p><p>- ubus: - [ubus-cli] (0)</p><p><br>` `> DHCPv6Client.Client.1.Enable=0<br>DHCPv6Client.Client.1.<br>DHCPv6Client.Client.1.Enable=0</p><p>- ubus: - [ubus-cli] (0)</p><p><br>` `> DHCPv6Client.Client.1.Enable=1<br>DHCPv6Client.Client.1.<br>DHCPv6Client.Client.1.Enable=1</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=4</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=1</p><p>DHCPv6Client.Client.1.Status="Enabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>DHCPv6Client.Client.1.ReceivedOption.5.</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Tag=23</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Value="FEC00000000000010000000000000001"</p><p>DHCPv6Client.Client.1.ReceivedOption.6.</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Tag=1</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Value="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.ReceivedOption.7.</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Tag=2</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Value="000100012D4BA4BCB827EBD37550"</p><p>DHCPv6Client.Client.1.ReceivedOption.8.</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Tag=25</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Value="00000001000000B600000127001A00190000016D0000024E3820010DB800000F000000000000000000"</p><p>DHCPv6Client.Client.1.Server.2.</p><p>DHCPv6Client.Client.1.Server.2.DUID="000100012d4ba4bcb827ebd37550"</p><p>DHCPv6Client.Client.1.Server.2.InformationRefreshTime="0001-01-01T00:00:00Z"</p><p>DHCPv6Client.Client.1.Server.2.SourceAddress="fe80::2135:b895:89d7:dee"</p>| |
|14|When toggling the IPv6Enable parameter in the IP datamodel, the client should send a release message over the interface before it is bring down by the ip-manager|<p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=4</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=1</p><p>DHCPv6Client.Client.1.Status="Enabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>DHCPv6Client.Client.1.ReceivedOption.5.</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Tag=23</p><p>DHCPv6Client.Client.1.ReceivedOption.5.Value="FEC00000000000010000000000000001"</p><p>DHCPv6Client.Client.1.ReceivedOption.6.</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Tag=1</p><p>DHCPv6Client.Client.1.ReceivedOption.6.Value="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.ReceivedOption.7.</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Tag=2</p><p>DHCPv6Client.Client.1.ReceivedOption.7.Value="000100012D4BA4BCB827EBD37550"</p><p>DHCPv6Client.Client.1.ReceivedOption.8.</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Server="DHCPv6Client.Client.1.Server.2."</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Tag=25</p><p>DHCPv6Client.Client.1.ReceivedOption.8.Value="00000001000000B600000127001A00190000016D0000024E3820010DB800000F000000000000000000"</p><p>DHCPv6Client.Client.1.Server.2.</p><p>DHCPv6Client.Client.1.Server.2.DUID="000100012d4ba4bcb827ebd37550"</p><p>DHCPv6Client.Client.1.Server.2.InformationRefreshTime="0001-01-01T00:00:00Z"</p><p>DHCPv6Client.Client.1.Server.2.SourceAddress="fe80::2135:b895:89d7:dee"</p><p>**Toggle the IPV6Enable in the IP. data model :**</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> IP.IPv6Enable=0</p><p>IP.</p><p>IP.IPv6Enable=0</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=0</p><p>DHCPv6Client.Client.1.Status="Error\_Misconfigured"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>------</p><p>and a release message should be seen on the network</p><p>------</p><p>**Toggle back the IPv6Enable :**</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> IP.IPv6Enable=1</p><p>IP.</p><p>IP.IPv6Enable=1</p><p>- ubus: - [ubus-cli] (0)</p><p>` `> DHCPv6Client.Client.1.?</p><p>DHCPv6Client.Client.1.</p><p>DHCPv6Client.Client.1.Alias="wan"</p><p>DHCPv6Client.Client.1.DUID="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.Enable=1</p><p>DHCPv6Client.Client.1.Interface="Device.IP.Interface.2."</p><p>DHCPv6Client.Client.1.RapidCommit=0</p><p>DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries=4</p><p>DHCPv6Client.Client.1.Renew=0</p><p>DHCPv6Client.Client.1.RequestAddresses=0</p><p>DHCPv6Client.Client.1.RequestPrefixes=1</p><p>DHCPv6Client.Client.1.RequestedOptions="23,31,32,64,65"</p><p>DHCPv6Client.Client.1.SentOptionNumberOfEntries=0</p><p>DHCPv6Client.Client.1.ServerNumberOfEntries=1</p><p>DHCPv6Client.Client.1.Status="Enabled"</p><p>DHCPv6Client.Client.1.SuggestedT1=-1</p><p>DHCPv6Client.Client.1.SuggestedT2=-1</p><p>DHCPv6Client.Client.1.SupportedOptions="23,31"</p><p>DHCPv6Client.Client.1.X\_PRPL\_COM\_Release=0</p><p>DHCPv6Client.Client.1.ReceivedOption.10.</p><p>DHCPv6Client.Client.1.ReceivedOption.10.Server="DHCPv6Client.Client.1.Server.3."</p><p>DHCPv6Client.Client.1.ReceivedOption.10.Tag=1</p><p>DHCPv6Client.Client.1.ReceivedOption.10.Value="00030001C03C04BE3370"</p><p>DHCPv6Client.Client.1.ReceivedOption.11.</p><p>DHCPv6Client.Client.1.ReceivedOption.11.Server="DHCPv6Client.Client.1.Server.3."</p><p>DHCPv6Client.Client.1.ReceivedOption.11.Tag=2</p><p>DHCPv6Client.Client.1.ReceivedOption.11.Value="000100012D4BA4BCB827EBD37550"</p><p>DHCPv6Client.Client.1.ReceivedOption.12.</p><p>DHCPv6Client.Client.1.ReceivedOption.12.Server="DHCPv6Client.Client.1.Server.3."</p><p>DHCPv6Client.Client.1.ReceivedOption.12.Tag=25</p><p>DHCPv6Client.Client.1.ReceivedOption.12.Value="00000001000000BB0000012C001A001900000177000002583820010DB800000F000000000000000000"</p><p>DHCPv6Client.Client.1.ReceivedOption.9.</p><p>DHCPv6Client.Client.1.ReceivedOption.9.Server="DHCPv6Client.Client.1.Server.3."</p><p>DHCPv6Client.Client.1.ReceivedOption.9.Tag=23</p><p>DHCPv6Client.Client.1.ReceivedOption.9.Value="FEC00000000000010000000000000001"</p><p>DHCPv6Client.Client.1.Server.3.</p><p>DHCPv6Client.Client.1.Server.3.DUID="000100012d4ba4bcb827ebd37550"</p><p>DHCPv6Client.Client.1.Server.3.InformationRefreshTime="0001-01-01T00:00:00Z"</p><p>DHCPv6Client.Client.1.Server.3.SourceAddress="fe80::2135:b895:89d7:dee"</p>||
|Test 15|When the release function is cal;, a unicast DHCP Release message should be send to the WAN, and the client should initiate a new DORA cycle to obtain an ipv6.|<p>` `> DHCPv6Client.Client.1.X\_PRPL-COM\_Release()<br>DHCPv6Client.Client.1.X\_PRPL-COM\_Release() returned<br>[<br>`    `""<br>]</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.Status = Enabled -> Error\_Misconfigured</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.Server.<br><dm:instance-removed> DHCPv6Client.Client.1.Server.1.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ServerNumberOfEntries = 1 -> 0</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.ReceivedOption.<br><dm:instance-removed> DHCPv6Client.Client.1.ReceivedOption.1.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 5 -> 4</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.ReceivedOption.<br><dm:instance-removed> DHCPv6Client.Client.1.ReceivedOption.2.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 4 -> 3</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.ReceivedOption.<br><dm:instance-removed> DHCPv6Client.Client.1.ReceivedOption.3.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 3 -> 2</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.ReceivedOption.<br><dm:instance-removed> DHCPv6Client.Client.1.ReceivedOption.4.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 2 -> 1</p><p>[2024-08-26T06:54:47Z] Event dm:instance-removed received from DHCPv6Client.Client.1.ReceivedOption.<br><dm:instance-removed> DHCPv6Client.Client.1.ReceivedOption.5.</p><p>[2024-08-26T06:54:47Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 1 -> 0</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ServerNumberOfEntries = 0 -> 1</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.Server.<br><  dm:instance-added> DHCPv6Client.Client.1.Server.2.InformationRefreshTime = 0001-01-01T00:00:00Z<br><                   > DHCPv6Client.Client.1.Server.2.DUID = 000100012a556730ba97fc3e8bfa<br><                   > DHCPv6Client.Client.1.Server.2.SourceAddress = fe80::b897:fcff:fe3e:8bfa</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 0 -> 1</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 1 -> 2</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 2 -> 3</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 3 -> 4</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.ReceivedOptionNumberOfEntries = 4 -> 5</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.ReceivedOption.<br><  dm:instance-added> DHCPv6Client.Client.1.ReceivedOption.6.LastUpdate = 2024-08-26T06:54:58.643512087Z<br><                   > DHCPv6Client.Client.1.ReceivedOption.6.Tag = 64<br><                   > DHCPv6Client.Client.1.ReceivedOption.6.Server = DHCPv6Client.Client.1.Server.2.<br><                   > DHCPv6Client.Client.1.ReceivedOption.6.Value = 04616674720262650A736F66746174686F6D6503636F6D00</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.ReceivedOption.<br><  dm:instance-added> DHCPv6Client.Client.1.ReceivedOption.7.LastUpdate = 2024-08-26T06:54:58.643579535Z<br><                   > DHCPv6Client.Client.1.ReceivedOption.7.Tag = 1<br><                   > DHCPv6Client.Client.1.ReceivedOption.7.Server = DHCPv6Client.Client.1.Server.2.<br><                   > DHCPv6Client.Client.1.ReceivedOption.7.Value = 0003000196AE2FF9AEA8</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.ReceivedOption.<br><  dm:instance-added> DHCPv6Client.Client.1.ReceivedOption.8.LastUpdate = 2024-08-26T06:54:58.643647608Z<br><                   > DHCPv6Client.Client.1.ReceivedOption.8.Tag = 2<br><                   > DHCPv6Client.Client.1.ReceivedOption.8.Server = DHCPv6Client.Client.1.Server.2.<br><                   > DHCPv6Client.Client.1.ReceivedOption.8.Value = 000100012A556730BA97FC3E8BFA</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.ReceivedOption.<br><  dm:instance-added> DHCPv6Client.Client.1.ReceivedOption.9.LastUpdate = 2024-08-26T06:54:58.643715107Z<br><                   > DHCPv6Client.Client.1.ReceivedOption.9.Tag = 25<br><                   > DHCPv6Client.Client.1.ReceivedOption.9.Server = DHCPv6Client.Client.1.Server.2.<br><                   > DHCPv6Client.Client.1.ReceivedOption.9.Value = 000000010000046000000703001A0019000008C000000E063C2A021802009443900000000000000000</p><p>[2024-08-26T06:54:58Z] Event dm:instance-added received from DHCPv6Client.Client.1.ReceivedOption.<br><  dm:instance-added> DHCPv6Client.Client.1.ReceivedOption.10.LastUpdate = 2024-08-26T06:54:58.643784690Z<br><                   > DHCPv6Client.Client.1.ReceivedOption.10.Tag = 23<br><                   > DHCPv6Client.Client.1.ReceivedOption.10.Server = DHCPv6Client.Client.1.Server.2.<br><                   > DHCPv6Client.Client.1.ReceivedOption.10.Value = 2A021802009442000000000000000010</p><p>[2024-08-26T06:54:58Z] Event dm:object-changed received from DHCPv6Client.Client.1.<br><  dm:object-changed> DHCPv6Client.Client.1.Status = Error\_Misconfigured -> Enabled</p>||
|16|Check DSCP value in IP header packet|<p>> DHCPv6Client.Client.1.DSCP=8</p><p>With tcpdump, check that the DSCP value of the next DHCPv6 packet is 8.</p><p>DHCPv6Client.Client.1.Renew() can be used to trigger the immediate transmission of a packet.</p>||
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-unittests"></a>**Unit Tests**
Development of the plugin/modules is covered by unit testing
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-logginganddebugging"></a>**Logging and Debugging**
DHCPv6 plugins, dhcpv6s-manager and tr181-dhcpv6client, have multiple trace-zones that can be controlled individually.

|tr181-dhcpv6client|dhcpv6c|All tr181-dhcpv6client traces, except for firewall access|
| :- | :- | :- |
|tr181-dhcpv6client|m-dhcp6c|<p>Traces of DHCPv6.Client.{i}.Controller component:</p><p>- mod-odhcp6c</p>|
|dhcpv6s-manager &<br>tr181-dhcpv6client|firewall|Traces regarding opening and closing of the UDP ports used by DHCPv6 (546 & 547).<br>Both server and client use this trace zone|
|dhcpv6s-manager|main|entrypoint and init related traces|
|dhcpv6s-manager|dmmngr|Datamodel manager related traces|
|dhcpv6s-manager|odhcpd|Traces of module: mod-dhcpv6s-odhcpd|
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-functionaltests"></a>**Functional Tests**
CDRouter IPv6 client tests must be passed.

[Wouter Cloetens](https://prplfoundationcloud.atlassian.net/wiki/people/636531781cc605b1fd18d04d?ref=confluence) to check into the test cases and compare with RFC’s. Reach out to [Timothy Winters](https://prplfoundationcloud.atlassian.net/wiki/people/5ee25498a7a4030ab38fa82f?ref=confluence) to get details of the tests, and any mapping with RFC7084 etc.

[prplOS Certification test plan](file:///C:/wiki/spaces/CERT/pages/448593935/prplOS+Network+Functionality+Test+Plan), DHCPv6:

- <https://docs.google.com/document/d/136CflV6Z2BkwUiq2Gu6RVd8VhRY1KsT1d_tIkSdzRxo/edit#heading=h.jr66rb1ce498>

RFC7084

- <https://support.qacafe.com/cdrouter/knowledge-base/test-setup-for-rfc-7084/>
- <https://support.qacafe.com/cdrouter/test-summary/ipv6-test-summary#cpe-v6tcl>
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-citests"></a>**CI Tests**
## <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-certification"></a>**Certification**
# <a name="dhcpclientwithenhanceddhcpv6carrier-gradefeatures-designreviewdocumentation"></a>**Design Review Documentation**
