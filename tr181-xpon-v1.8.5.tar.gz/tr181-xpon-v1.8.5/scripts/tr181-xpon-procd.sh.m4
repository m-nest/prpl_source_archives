#!/bin/sh /etc/rc.common

# shellcheck disable=SC1091 # Do not follow sourced files
. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-xpon"
PROG="/usr/bin/tr181-xpon"
datamodel_root="XPON"
PROG_OPTIONS=""

# tr181-xpon no longer uses /etc/config/tr181-xpon for persistency. It uses
# /cfg/pcm/tr181-xpon. Remove the folder /etc/config/tr181-xpon if it exists.
persistency_migration_cleanup(){
    if [ -d /etc/config/tr181-xpon ]; then
        rm -rf /etc/config/tr181-xpon
    fi
}

#Guideline- this function has the instructions to execute before
#starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    persistency_migration_cleanup
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after starting this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook()
}

debuginfo() {
    process_debug_info ${datamodel_root}
    if [ -x /usr/lib/amx/tr181-xpon/modules/debuginfo_vendor ]; then
        /usr/lib/amx/tr181-xpon/modules/debuginfo_vendor
    fi
}
