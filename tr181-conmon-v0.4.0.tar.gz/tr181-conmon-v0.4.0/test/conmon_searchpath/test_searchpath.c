/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxm/amxm.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>

#include "../common/common_functions.h"

#include "conmon.h"
#include "conmon_utils.h"
#include "test_searcpath.h"

static void add_entry(const char* alias, const char* interface, const char* type, bool enable) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_priv, true);

    amxd_trans_select_pathf(&trans, "ConMon.Entry");
    amxd_trans_add_inst(&trans, 0, alias);
    amxd_trans_set_value(bool, &trans, "Enable", enable);
    amxd_trans_set_value(cstring_t, &trans, "Interface", interface);
    amxd_trans_set_value(cstring_t, &trans, "Type", type);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);

    amxd_trans_clean(&trans);
}

int test_setup(void** state) {
    amxut_bus_setup(state);

    resolver_add_all_functions();

    test_setup_parse_odl(DUMMY_TEST_ODL);
    test_setup_parse_odl(INTERFACE_ODL);
    test_setup_parse_odl(NETDEV_ODL);
    test_setup_parse_odl(LOGICAL_ODL);

    assert_int_equal(_conmon_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_handle_events();
    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_conmon_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_teardown(state);
    return 0;
}

void test_supports_entry_intf_searchpath(UNUSED void** state) {
    // GIVEN: the interface is already available
    test_setup_parse_odl(LOGICAL_POPULATE_ODL);
    amxut_bus_handle_events();

    // GIVEN: A ConMon.Entry. with a searchpath Interface
    add_entry("test_entry",
              "Device.Logical.Interface.[Name == \"test\"]",
              "ND",
              true);
    amxut_bus_handle_events();

    // ASSERT: that the entry is in the Enable state
    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Enabled");
}

void test_supports_entry_intf_searchpath_delayed_availability(UNUSED void** state) {
    // GIVEN: A ConMon.Entry. with a searchpath Interface
    add_entry("test_entry",
              "Device.Logical.Interface.[Name == \"test\"]",
              "ND",
              true);
    amxut_bus_handle_events();

    // ASSERT: that the entry remains in Error state
    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Error");
    amxut_timer_go_to_future_ms(RESOLVE_RETRY_INTERVAL * 2);
    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Error");

    // WHEN: the interface becomes available
    test_setup_parse_odl(LOGICAL_POPULATE_ODL);
    amxut_timer_go_to_future_ms(RESOLVE_RETRY_INTERVAL);

    // ASSERT: that the entry enters in Enable state
    amxut_dm_param_equals(cstring_t, "ConMon.Entry.test_entry.", "Status", "Enabled");
}
