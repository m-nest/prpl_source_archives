#ifndef __TEST_VALIDATE_AUTH_H__
#define __TEST_VALIDATE_AUTH_H__

#ifdef __cplusplus
extern "C"
{
#endif

int test_setup(void** state);
int test_teardown(void** state);

void test_allow_new_device(void** state);
void test_block_new_device(void** state);
void test_allow_all_devices(void** state);
void test_allow_blocked_device(void** state);
void test_block_changed_device(void** state);
void test_allow_existing_device(void** state);
void test_block_existing_device(void** state);
void test_block_existing_device_after_emptying_allowed_devices(void** state);
void test_block_device_after_disable_allowed_device(void** state);

#ifdef __cplusplus
}
#endif

#endif // __TEST_VALIDATE_AUTH_H__
