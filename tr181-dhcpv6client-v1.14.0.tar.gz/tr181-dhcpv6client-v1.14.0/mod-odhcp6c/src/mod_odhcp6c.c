/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "mod_odhcp6c.h"
#include "odhcp6c_list.h"
#include "odhcp6c_actions.h"
#include "v4v6option.h"

#define GRACEFUL_STOP_TIMEOUT 1000
#define NO_IA_PD INT32_MAX

#define DHCPV6_OPTION_VENDOR_SPECIFIC_INFO 17

/**********************************************************
* Function Prototypes
**********************************************************/

static void update_state(odhcp6c_t* odhcp6c);
static int odhcp6c_stop(odhcp6c_t* odhcp6c);
static void odhcp6c_stop_handler(const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv);
/**********************************************************
* Functions
**********************************************************/

static bool requires_hex_format(uint16_t option_tag) {
    switch(option_tag) {
    case DHCPV6_OPTION_VENDOR_SPECIFIC_INFO:
        return true;
    default:
        return false;
    }
}

static amxc_string_t* get_parsed_dhcp_option(amxc_var_t* var) {
    amxc_var_t* parsed_info = NULL;
    amxc_string_t* str = NULL;
    uint32_t length = 0;
    uint16_t tag = (uint16_t) GET_UINT32(var, "Tag");
    char* param_value = NULL;
    unsigned char* option = NULL;
    amxc_string_t* result_option = NULL;
    amxc_var_new(&parsed_info);
    amxc_string_new(&str, 0);

    option = dhcpoption_option_convert2bin(GET_CHAR(var, "Value"), &length);
    when_null_trace(option, exit, ERROR, "Failed to convert SentOption %u to binary, will be ignored", tag);

    // Convert binary buffer to string(s) (amxc_var_t)
    dhcpoption_v6parse(parsed_info, tag, length, option);
    param_value = amxc_var_dyncast(cstring_t, parsed_info);
    when_str_empty_trace(param_value, exit, ERROR, "Failed to parse SentOption %u, will be ignored", tag);
    amxc_string_new(&result_option, 0);
    amxc_string_set(result_option, param_value);

exit:
    amxc_var_delete(&parsed_info);
    amxc_string_delete(&str);
    free(option);
    free(param_value);
    return result_option;
}

static amxc_string_t* get_raw_dhcp_option(amxc_var_t* var) {
    amxc_string_t* result_option = NULL;
    const char* option_value = GET_CHAR(var, "Value");
    when_str_empty_trace(option_value, exit, ERROR, "Failed to get SentOption, will be ignored");
    amxc_string_new(&result_option, 0);
    amxc_string_set(result_option, option_value);

exit:
    return result_option;
}

static char* convert_to_odhcp6c_option(amxc_var_t* option) {
    uint16_t tag = (uint16_t) GET_UINT32(option, "Tag");
    amxc_string_t* option_data = NULL;
    char* result_option = NULL;
    if(requires_hex_format(tag)) {
        option_data = get_raw_dhcp_option(option);
    } else {
        option_data = get_parsed_dhcp_option(option);
    }

    when_null_trace(option_data, exit, ERROR, "Cannot convert DHCP option");
    amxc_string_prependf(option_data, "%u:", tag);
    result_option = amxc_string_take_buffer(option_data);
exit:
    amxc_string_delete(&option_data);
    return result_option;
}

static void odhcp6c_set_sent_options(amxc_var_t* opts,
                                     amxc_array_t* array) {
    size_t size = 0;
    when_null_trace(opts, exit, ERROR, "No SentOption defined");
    when_null_trace(array, exit, ERROR, "No array defined");

    amxc_var_for_each(var, opts) {
        size++;
    }
    amxc_array_grow(array, size);
    amxc_var_for_each(var, opts) {
        char* odhcp6c_option = convert_to_odhcp6c_option(var);
        when_null_trace(odhcp6c_option, loop_next, ERROR, "Cannot extract DHCP option");
        amxc_array_append_data(array, (void*) odhcp6c_option);
loop_next:
    }
exit:
    return;
}

static void odhcp6c_free_array_item(amxc_array_it_t* it) {
    free(it->data);
}

static int odhcp6c_start_process(odhcp6c_t* odhcp6c) {
    int retval = -1;
    uint32_t index = 0;
    size_t nr_sent_opts = 0;
    size_t nr_args = 0;
    amxc_array_t cmd;
    amxc_array_t array_opts;
    const char* ifname = NULL;
    uint32_t sol_max_rt = 0;
    const char* req_options = NULL;
    amxc_string_t sol_max_arg;
    amxc_string_t dscp_arg;

    amxc_array_init(&cmd, 0);
    amxc_string_init(&sol_max_arg, 0);
    amxc_string_init(&dscp_arg, 0);
    amxc_array_init(&array_opts, 0);

    when_null_trace(odhcp6c, exit, ERROR, "Bad odhcp input value");
    when_null_trace(odhcp6c->subproc, exit, ERROR, "Could not find the odhcp subproc");
    when_false_trace(!amxp_subproc_is_running(odhcp6c->subproc), exit, ERROR, "trying to start the subproc, but the subproc is already running");
    when_null_trace(odhcp6c->latest_args, exit, ERROR, "Could not find the odhcp latest_args parameter");
    ifname = GET_CHAR(odhcp6c->latest_args, "ifname");
    when_null_trace(ifname, exit, ERROR, "Could not find the odhcp ifname");

    odhcp6c_set_sent_options(GETP_ARG(odhcp6c->latest_args, "SentOption"), &array_opts);
    nr_sent_opts = amxc_array_size(&array_opts);

    req_options = GET_CHAR(odhcp6c->latest_args, "RequestedOptions");
    nr_args = 11 + 2 * nr_sent_opts + (str_empty(req_options) ? 0 : 2);
    amxc_array_grow(&cmd, nr_args);

    amxc_array_append_data(&cmd, (void*) "odhcp6c");
    amxc_array_append_data(&cmd, (void*) "-v");
    amxc_array_append_data(&cmd, (void*) "-f");
    amxc_array_append_data(&cmd, (void*) "-E");

    if(GET_BOOL(odhcp6c->latest_args, "RequestAddresses") == false) {
        amxc_array_append_data(&cmd, (void*) "-N");
        amxc_array_append_data(&cmd, (void*) "none");
    }
    if(GET_BOOL(odhcp6c->latest_args, "RequestPrefixes")) {
        amxc_array_append_data(&cmd, (void*) "-P0");
    }
    sol_max_rt = GET_UINT32(odhcp6c->latest_args, "SolicitMaxTimeout");
    if(sol_max_rt > 0) {
        amxc_string_setf(&sol_max_arg, "-t%u", sol_max_rt);
        amxc_array_append_data(&cmd, (void*) amxc_string_get(&sol_max_arg, 0));
    }
    amxc_string_setf(&dscp_arg, "-C%u", GET_UINT32(odhcp6c->latest_args, "dscp"));
    amxc_array_append_data(&cmd, (void*) amxc_string_get(&dscp_arg, 0));
    amxc_array_append_data(&cmd, (void*) "-R");
    if(!str_empty(req_options)) {
        amxc_array_append_data(&cmd, (void*) "-r");
        amxc_array_append_data(&cmd, (void*) req_options);
    }
    while(nr_sent_opts > 0) {
        amxc_array_append_data(&cmd, (void*) "-x");
        amxc_array_append_data(&cmd, amxc_array_get_data_at(&array_opts, index));
        index++;
        nr_sent_opts--;
    }

    /* Interface name should always be last */
    amxc_array_append_data(&cmd, (void*) ifname);
    retval = amxp_subproc_astart(odhcp6c->subproc, &cmd);
    when_false_trace(retval == 0, exit, ERROR, "Failed to start the subproc");
    SAH_TRACEZ_INFO(ME, "amxp_subproc_astart (odhcp6c %s, pid %d) ret %d", ifname, odhcp6c->subproc->pid, retval);
exit:
    amxc_string_clean(&sol_max_arg);
    amxc_string_clean(&dscp_arg);
    amxc_array_clean(&cmd, NULL);
    amxc_array_clean(&array_opts, odhcp6c_free_array_item);
    return retval;
}

static void odhcp6c_subscribe_cb(UNUSED const char* signame,
                                 const amxc_var_t* data,
                                 void* priv) {
    int retval = -1;
    const char* action = NULL;
    odhcp6c_t* odhcp6c = (odhcp6c_t*) priv;

    when_null_trace(odhcp6c, exit, ERROR, "Bad input parameter odhcp6c struct");
    when_str_empty_trace(odhcp6c->client, exit, ERROR, "Client reference is empty");
    when_null_trace(data, exit, ERROR, "Bad input parameter data");

    action = GET_CHAR(data, "notification");
    when_str_empty_trace(action, exit, ERROR, "Could not find the action name in the data");

    retval = actions_handler(odhcp6c->client, action, data);
    when_failed_trace(retval, exit, ERROR, "Failed to handle action '%s' (%d)", action, retval);
exit:
    return;
}

static void odhcp6c_wait_done_cb(UNUSED const char* const signal,
                                 UNUSED const amxc_var_t* const data,
                                 void* const priv) {
    int retval = -1;
    odhcp6c_t* odhcp6c = (odhcp6c_t*) priv;

    when_null_trace(odhcp6c, exit, ERROR, "Invalid odhcp6c private argument");
    when_null_trace(odhcp6c->path, exit, ERROR, "Empty bus path");

    odhcp6c->bus = amxb_be_who_has(odhcp6c->path);
    when_null_trace(odhcp6c->bus, exit, ERROR, "Failed to find bus context for object %s", odhcp6c->path);

    amxp_slot_disconnect_with_priv(NULL, odhcp6c_wait_done_cb, odhcp6c);

    if(odhcp6c->state == ODHCP_STARTING) {
        // Because it is not possible to subscribe to ubus object before it is available, the "started" event can be missed so it is manually called
        actions_handler(odhcp6c->client, "started", NULL);
    }

    retval = amxb_subscribe(odhcp6c->bus, odhcp6c->path, "notification != 'ra-updated'", odhcp6c_subscribe_cb, odhcp6c);
    when_failed_trace(retval, exit, ERROR, "Failed to subscribe on object %s : %d", odhcp6c->path, retval);

    if(odhcp6c->state == ODHCP_STARTING) {
        odhcp6c->state = ODHCP_STARTED;
        update_state(odhcp6c);
    }
exit:
    return;
}

static int odhcp6c_start(odhcp6c_t* odhcp6c) {
    int retval = -1;
    amxc_string_t wait_expr;
    amxc_string_t object_name;

    amxc_string_init(&object_name, 0);
    amxc_string_init(&wait_expr, 0);

    when_null_trace(odhcp6c, exit, ERROR, "Invalid odhcp6c input parameter");

    odhcp6c->state = ODHCP_STARTING;
    retval = amxp_slot_connect(amxp_subproc_get_sigmngr(odhcp6c->subproc), "stop", NULL, odhcp6c_stop_handler, (void*) odhcp6c);
    when_false_trace(retval == 0, exit, ERROR, "Failed to connect stop handler");

    amxc_string_setf(&object_name, "odhcp6c.%s.", GET_CHAR(odhcp6c->latest_args, "ifname"));
    free(odhcp6c->path);
    odhcp6c->path = amxc_string_take_buffer(&object_name);

    amxc_string_setf(&wait_expr, "^wait:%s$", odhcp6c->path);
    amxc_string_replace(&wait_expr, ".", "\\.", UINT32_MAX);
    amxp_slot_connect_filtered(NULL, amxc_string_get(&wait_expr, 0), NULL, odhcp6c_wait_done_cb, odhcp6c);
    amxb_wait_for_object(odhcp6c->path);

    retval = odhcp6c_start_process(odhcp6c);
    if(retval != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to execute odhcp6c_start_process");
        amxp_slot_disconnect(amxp_subproc_get_sigmngr(odhcp6c->subproc), "stop", odhcp6c_stop_handler);
        amxp_slot_disconnect_with_priv(NULL, odhcp6c_wait_done_cb, odhcp6c);
    }
exit:
    amxc_string_clean(&object_name);
    amxc_string_clean(&wait_expr);
    return retval;
}

static void odhcp6c_stop_handler(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 void* const priv) {
    odhcp6c_t* odhcp6c = (odhcp6c_t*) priv;
    int retval = -1;

    SAH_TRACEZ_INFO(ME, "The stop odhcp handler has been triggered");

    when_null_trace(odhcp6c, exit, ERROR, "Could not find the odhcp struct in the priv data");
    when_null_trace(odhcp6c->client, exit, ERROR, "Could not find the odhcp client reference");

    retval = amxp_slot_disconnect(amxp_subproc_get_sigmngr(odhcp6c->subproc), "stop", odhcp6c_stop_handler);
    when_false_trace(retval == 0, exit, ERROR, "Failed to disconnect stop handler");

    retval = amxb_unsubscribe(odhcp6c->bus, odhcp6c->path, odhcp6c_subscribe_cb, odhcp6c);
    when_failed_trace(retval, exit, ERROR, "Failed to unsubscribe from object %s : %d", odhcp6c->path, retval);
    odhcp6c->bus = NULL;

    if(GET_INT32(data, "ExitCode") != 0) {
        SAH_TRACEZ_ERROR(ME, "ODHCP closed with an exit error %d", GET_INT32(data, "ExitCode"));
    }
    actions_handler(odhcp6c->client, "stopped", NULL);
    odhcp6c->state = ODHCP_STOPPED;
    update_state(odhcp6c);
exit:
    return;
}

static void odhcp6c_cleanup_process_cb(odhcp6c_t* odhcp6c) {
    amxc_var_t data_var;
    amxc_var_t ret;
    int retval = -1;

    amxc_var_init(&data_var);
    amxc_var_init(&ret);

    when_null_trace(odhcp6c, exit, ERROR, "Bad odhcp input parameter");
    when_null_trace(odhcp6c->subproc, exit, ERROR, "Could not find the odhcp subproc");
    when_false(amxp_subproc_is_running(odhcp6c->subproc), exit);

    retval = amxp_slot_disconnect(amxp_subproc_get_sigmngr(odhcp6c->subproc), "stop", odhcp6c_stop_handler);
    when_false_trace(retval == 0, exit, ERROR, "Failed to disconnect stop handler");

    odhcp6c_stop(odhcp6c);
    amxc_var_clean(odhcp6c->used_args);
    amxc_var_clean(odhcp6c->latest_args);

    amxc_var_set_type(&data_var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(int32_t, &data_var, "ExitCode", 0);
    odhcp6c_stop_handler(NULL, &data_var, (void*) odhcp6c);
exit:
    amxc_var_clean(&data_var);
    amxc_var_clean(&ret);
}

static int odhcp6c_stop(odhcp6c_t* odhcp6c) {
    int retval = -1;

    when_null_trace(odhcp6c, exit, ERROR, "Bad odhcp input parameter");
    when_null_trace(odhcp6c->subproc, exit, ERROR, "Could not find the odhcp subproc");
    when_false_trace(amxp_subproc_is_running(odhcp6c->subproc), exit, ERROR, "trying to stop the subproc, but the subproc is not running");

    odhcp6c->state = ODHCP_STOPPING;

    retval = amxp_subproc_kill(odhcp6c->subproc, SIGTERM);
    when_false_trace(retval == 0, exit, ERROR, "Failed to kill the subproc with SIGTERM %s (%d)", strerror(errno), errno);
    retval = amxp_subproc_wait(odhcp6c->subproc, GRACEFUL_STOP_TIMEOUT);
    if(retval != 0) {
        SAH_TRACEZ_ERROR(ME, "dhcpv6 client (odhcp6c) is still running after %d ms, sending SIGKILL", GRACEFUL_STOP_TIMEOUT);
        retval = amxp_subproc_kill(odhcp6c->subproc, SIGKILL);
        when_false_trace(retval == 0, exit, ERROR, "Failed to kill the subproc with SIGKILL %s (%d)", strerror(errno), errno);
    }
    SAH_TRACEZ_INFO(ME, "Terminate odhcp6c[%d]", odhcp6c->subproc->pid);
exit:
    return retval;
}

static int odhcp6c_call(odhcp6c_t* odhcp6c, const char* method, amxc_var_t* args, amxc_var_t* ret) {
    int retval = -1;

    when_null_trace(odhcp6c, exit, ERROR, "odhcp6c struct is null");
    when_str_empty_trace(odhcp6c->path, exit, ERROR, "Empty bus path");
    when_false_trace(odhcp6c->state == ODHCP_STARTED, exit, ERROR, "odhcp6c for client %s is not started", odhcp6c->client);
    when_null_trace(odhcp6c->bus, exit, ERROR, "Failed to find bus context for object %s", odhcp6c->path);

    retval = amxb_call(odhcp6c->bus, odhcp6c->path, method, args, ret, 1);
    when_failed_trace(retval, exit, ERROR, "Failed to execute '%s' on object %s : %d", method, odhcp6c->path, retval);
exit:
    return retval;
}

int odhcp6c_get_stats(UNUSED const char* function_name,
                      amxc_var_t* args,
                      amxc_var_t* ret) {
    int retval = -1;
    const char* client = GET_CHAR(args, "Client");
    odhcp6c_t* odhcp6c = odhcp6c_list_find(client);
    when_null_trace(odhcp6c, exit, ERROR, "odhcp6c info for %s not found", client);
    retval = odhcp6c_call(odhcp6c, "get_statistics", NULL, ret);
exit:
    return retval;
}

int odhcp6c_renew(UNUSED const char* function_name,
                  amxc_var_t* args,
                  amxc_var_t* ret) {
    int retval = -1;
    const char* client = GET_CHAR(args, "Client");
    odhcp6c_t* odhcp6c = odhcp6c_list_find(client);
    when_null_trace(odhcp6c, exit, ERROR, "odhcp6c info for %s not found", client);
    retval = odhcp6c_call(odhcp6c, "renew", NULL, ret);
exit:
    return retval;
}

int odhcp6c_release(UNUSED const char* function_name,
                    amxc_var_t* args,
                    amxc_var_t* ret) {
    int retval = -1;
    const char* client = GET_CHAR(args, "Client");
    odhcp6c_t* odhcp6c = odhcp6c_list_find(client);
    when_null_trace(odhcp6c, exit, ERROR, "odhcp6c info for %s not found", client);
    retval = odhcp6c_call(odhcp6c, "release", NULL, ret);
exit:
    return retval;
}

static void set_retransmit_options(amxc_var_t* src, amxc_var_t* dest) {
    amxc_var_t* msg = NULL;

    when_null_trace(src, exit, ERROR, "Src argument is NULL");
    when_null_trace(src, exit, ERROR, "Dest argument is NULL");

    amxc_var_add_key(uint32_t, dest, "irt_default", GET_UINT32(src, "InformationRefreshTime"));
    amxc_var_add_key(uint32_t, dest, "irt_min", GET_UINT32(src, "MinInformationRefreshTime"));
    amxc_var_add_key(uint32_t, dest, "rand_factor", GET_UINT32(src, "TimeoutRandomize"));

    msg = amxc_var_add_new_key(dest, "msg_solicit");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "delay_max", GET_UINT32(src, "SolicitMaxDelay"));
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "SolicitInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "timeout_max", GET_UINT32(src, "SolicitMaxTimeout"));

    msg = amxc_var_add_new_key(dest, "msg_request");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "RequestInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "timeout_max", GET_UINT32(src, "RequestMaxTimeout"));
    amxc_var_add_key(uint32_t, msg, "rc_max", GET_UINT32(src, "RequestMaxRetry"));

    msg = amxc_var_add_new_key(dest, "msg_renew");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "RenewInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "timeout_max", GET_UINT32(src, "RenewMaxTimeout"));

    msg = amxc_var_add_new_key(dest, "msg_rebind");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "RebindInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "timeout_max", GET_UINT32(src, "RebindMaxTimeout"));

    msg = amxc_var_add_new_key(dest, "msg_release");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "ReleaseInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "rc_max", GET_UINT32(src, "ReleaseMaxAttempts"));

    msg = amxc_var_add_new_key(dest, "msg_decline");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "DeclineInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "rc_max", GET_UINT32(src, "DeclineMaxAttempts"));

    msg = amxc_var_add_new_key(dest, "msg_inforeq");
    amxc_var_set_type(msg, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, msg, "delay_max", GET_UINT32(src, "InformationRequestMaxDelay"));
    amxc_var_add_key(uint32_t, msg, "timeout_init", GET_UINT32(src, "InformationRequestInitialTimeout"));
    amxc_var_add_key(uint32_t, msg, "timeout_max", GET_UINT32(src, "InformationRequestMaxTimeout"));
exit:
    return;
}

static void update_args(odhcp6c_t* odhcp6c) {
    int retval = -1;
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t req_opt_csv;
    amxc_var_t* req_opt;
    amxc_var_t* send_opt;
    amxc_array_t sent_opts;
    uint32_t dscp = GET_UINT32(odhcp6c->latest_args, "dscp");
    bool request_addresses = GET_BOOL(odhcp6c->latest_args, "RequestAddresses");
    bool request_prefixes = GET_BOOL(odhcp6c->latest_args, "RequestPrefixes");
    const char* request_option = GET_CHAR(odhcp6c->latest_args, "RequestedOptions");
    const char* auth_protocol = GET_CHAR(odhcp6c->latest_args, "AuthenticationProtocol");
    const char* auth_token = GET_CHAR(odhcp6c->latest_args, "AuthenticationToken");

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_init(&req_opt_csv);
    amxc_array_init(&sent_opts, 0);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(uint32_t, &args, "dscp", dscp);
    amxc_var_add_key(cstring_t, &args, "req_addresses", request_addresses ? "try" : "none");
    amxc_var_add_key(uint32_t, &args, "req_prefixes", request_prefixes ? 0 : NO_IA_PD);
    amxc_var_add_key(cstring_t, &args, "auth_protocol", auth_protocol);
    amxc_var_add_key(cstring_t, &args, "auth_token", auth_token);
    amxc_var_add_key(bool, &args, "opt_strict", true);

    req_opt = amxc_var_add_key(amxc_llist_t, &args, "opt_requested", NULL);
    if(!str_empty(request_option)) {
        amxc_var_set(csv_string_t, &req_opt_csv, request_option);
        amxc_var_cast(&req_opt_csv, AMXC_VAR_ID_LIST);
        amxc_var_for_each(var, &req_opt_csv) {
            amxc_var_add(uint32_t, req_opt, GET_UINT32(var, NULL));
        }
    }

    odhcp6c_set_sent_options(GET_ARG(odhcp6c->latest_args, "SentOption"), &sent_opts);
    send_opt = amxc_var_add_key(amxc_llist_t, &args, "opt_send", NULL);
    for(size_t i = 0; i < amxc_array_size(&sent_opts); i++) {
        amxc_var_add(cstring_t, send_opt, amxc_array_get_data_at(&sent_opts, i));
    }

    set_retransmit_options(odhcp6c->latest_args, &args);

    retval = odhcp6c_call(odhcp6c, "reconfigure_dhcp", &args, &ret);
    when_failed_trace(retval, exit, ERROR, "Failed to reconfigure DHCP for %s with error %d", odhcp6c->path, retval);

    amxc_var_copy(odhcp6c->used_args, odhcp6c->latest_args);

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    amxc_var_clean(&req_opt_csv);
    amxc_array_clean(&sent_opts, odhcp6c_free_array_item);
}

static void update_state(odhcp6c_t* odhcp6c) {
    int cmp = -1;
    int ret = -1;

    when_null_trace(odhcp6c, exit, ERROR, "Bad odhcp6c input parameter");

    if((odhcp6c->state == ODHCP_STARTED) || (odhcp6c->state == ODHCP_STOPPED)) {
        //Check if the process is in process
        if(amxc_var_get_first(odhcp6c->latest_args) == NULL) {
            if(odhcp6c->state != ODHCP_STOPPED) {
                //Should be stopped
                odhcp6c_stop(odhcp6c);
            }
        } else {
            //Should be started
            if(odhcp6c->state == ODHCP_STOPPED) {
                amxc_var_clean(odhcp6c->used_args);
                odhcp6c_start(odhcp6c);
            } else {
                //Started, but not with the most recent arguments
                ret = amxc_var_compare(odhcp6c->used_args, odhcp6c->latest_args, &cmp);
                when_failed_trace(ret, exit, ERROR, "Failed to compare two variants");
                when_true_trace(cmp == 0, exit, INFO, "Arguments are already updated");
                if(!str_empty(GET_CHAR(odhcp6c->used_args, "ifname")) && !str_empty(GET_CHAR(odhcp6c->latest_args, "ifname")) &&
                   (strcmp(GET_CHAR(odhcp6c->latest_args, "ifname"), GET_CHAR(odhcp6c->used_args, "ifname")) != 0)) {
                    // If ifname changed, odhcp6c should be stopped to be restarted with the correct interface
                    odhcp6c_stop(odhcp6c);
                } else {
                    update_args(odhcp6c);
                }
            }
        }
    }
exit:
    return;
}

/**
   @brief
   Start a DHCPv6 client

   @param function_name function name
   @param args { Client = "DHCPv6Client.Client.1", ifname = "eth0",
                 SentOption [ {Tag = 111,  Value = "" },...],
                 RequestedOptions = "" }
   @return Always 0
 */
int odhcp6c_set_state_start(UNUSED const char* function_name,
                            amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    odhcp6c_t* odhcp6c = NULL;
    const char* client = NULL;
    int retval = -1;

    SAH_TRACEZ_INFO(ME, "Got a signal to start the odhcp process");

    when_null_trace(args, exit, ERROR, "Bad args input parameter given");
    client = GET_CHAR(args, "Client");
    when_str_empty_trace(client, exit, ERROR, "bad input value 'client'");

    odhcp6c = odhcp6c_list_find(client);
    if(odhcp6c == NULL) {
        odhcp6c = odhcp6c_list_add(args);
    }
    when_null_trace(odhcp6c, exit, ERROR, "Failed to create a odhcp6c info struct");
    amxc_var_copy(odhcp6c->latest_args, args);
    update_state(odhcp6c);
    retval = 0;
exit:
    amxc_var_set(int32_t, ret, retval);
    return 0;
}

/**
   @brief
   Stop DHCPv6 client

   @param function_name function name
   @param args { Client = "DHCPv6Client.Client.1" }
   @param ret status value, 0 if ok
   @return 0 if success
 */
int odhcp6c_set_state_stop(UNUSED const char* function_name,
                           amxc_var_t* args,
                           amxc_var_t* ret) {
    const char* client = NULL;
    odhcp6c_t* odhcp6c = NULL;
    int retval = -1;

    SAH_TRACEZ_INFO(ME, "Got a signal to stop the odhcp process");

    when_null_trace(args, exit, ERROR, "Bad args input parameter given");
    client = GET_CHAR(args, "Client");
    when_str_empty_trace(client, exit, ERROR, "Bad input value 'client'");

    odhcp6c = odhcp6c_list_find(client);
    when_null_trace(odhcp6c, exit, ERROR, "Could not find the odhcp6c struct for %s", client);
    amxc_var_clean(odhcp6c->latest_args);
    update_state(odhcp6c);
    retval = 0;
exit:
    amxc_var_set(int32_t, ret, retval);
    return 0;
}

static AMXM_CONSTRUCTOR mod_odhcp6c_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    SAH_TRACEZ_INFO(ME, "Start %s", "mod-odhcp6c");

    odhcp6c_list_init();

    amxm_module_register(&mod, so, MOD_ODHCP6C);
    amxm_module_add_function(mod, "start-dhcpv6c", odhcp6c_set_state_start);
    amxm_module_add_function(mod, "stop-dhcpv6c", odhcp6c_set_state_stop);
    amxm_module_add_function(mod, "renew-dhcpv6c", odhcp6c_renew);
    amxm_module_add_function(mod, "release-dhcpv6c", odhcp6c_release);
    amxm_module_add_function(mod, "get-statistics", odhcp6c_get_stats);

    return 0;
}

static AMXM_DESTRUCTOR mod_odhcp6c_stop(void) {
    amxp_slot_disconnect_all(odhcp6c_wait_done_cb);
    odhcp6c_list_all(odhcp6c_cleanup_process_cb);
    odhcp6c_list_delete_all();

    return 0;
}



