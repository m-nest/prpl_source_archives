#!/bin/sh

# create the hostname
MY_HOSTNAME="prplOS"

echo "export MY_HOSTNAME=\"$MY_HOSTNAME\"" >> /var/etc/environment
