/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxp/amxp.h>
#include <amxm/amxm.h>

#include <yajl/yajl_gen.h>
#include <amxj/amxj_variant.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <debug/sahtrace.h>

#include "cthulhu_pcm.h"
#include "test_import.h"

#undef ME
#define ME "test"
static cthulhu_prestartup_config_t prestartup_config;


static amxc_var_t* test_read_json_from_file(const char* fname) {
    int fd = -1;
    variant_json_t* reader = NULL;
    amxc_var_t* data = NULL;

    // create a json reader
    if(amxj_reader_new(&reader) != 0) {
        printf("Failed to create json file reader");
        goto exit;
    }

    // open the json file
    fd = open(fname, O_RDONLY);
    if(fd == -1) {
        printf("File open file %s - error 0x%8.8X\n", fname, errno);
        goto exit;
    }

    // read the json file and parse the json text
    while(amxj_read(reader, fd) > 0) {
    }

    // get the variant
    data = amxj_reader_result(reader);

    if(data == NULL) {
        printf("Invalid JSON in file %s\n", fname);
    }

    close(fd);
exit:
    amxj_reader_delete(&reader);
    return data;
}

int test_cthulhu_import_setup(UNUSED void** state) {
    LOG_ENTRY
    cthulhu_prestartup_config_t* config = &prestartup_config;

    memset(config, 0, sizeof(cthulhu_prestartup_config_t));
    set_prestartup_config(config);

    amxc_var_new(&(config->ctr_create));
    amxc_var_set_type(config->ctr_create, AMXC_VAR_ID_LIST);

    amxc_var_new(&(config->sb_create));
    amxc_var_set_type(config->sb_create, AMXC_VAR_ID_LIST);

    LOG_EXIT
    return 0;
}

int test_cthulhu_import_teardown(UNUSED void** state) {
    LOG_ENTRY

    cthulhu_prestartup_config_t* config = get_prestartup_config();
    amxc_var_delete(&(config->ctr_create));
    amxc_var_delete(&(config->sb_create));

    LOG_EXIT
    return 0;
}

static int call_import(const char* import_file) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* import_data = test_read_json_from_file(import_file);

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_set_key(&args, "data", import_data, AMXC_VAR_FLAG_COPY);

    custom_pcm_import(NULL, NULL, &args, &ret);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    amxc_var_delete(&import_data);

    return 0;
}

void test_cthulhu_import_full_unpriv_ctr(UNUSED void** state) {
    LOG_ENTRY
    const char* import_data_file = "cthulhu_Cthulhu_unpriv.json";

    assert_int_equal(call_import(import_data_file), 0);

    cthulhu_prestartup_config_t* config = get_prestartup_config();

    amxc_var_t* sb = amxc_var_get_first(config->sb_create);
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_ID), "generic");
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_PARENT), "");
    assert_int_equal(GET_UINT32(sb, CTHULHU_SANDBOX_ENABLE), 1);
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_VERSION), "testVersion");
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_VENDOR), "testVendor");
    assert_int_equal(GET_INT32(sb, CTHULHU_SANDBOX_CPU), 100);
    assert_int_equal(GET_INT32(sb, CTHULHU_SANDBOX_MEMORY), -1);
    assert_int_equal(GET_INT32(sb, CTHULHU_SANDBOX_DISKSPACE), 5120);
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_RESTART_REASON), "Increase allocated disk space");
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_CREATED), "2025-10-01T16:35:57.684276976Z");
    assert_string_equal(GET_CHAR(sb, CTHULHU_SANDBOX_DESCRIPTION), "fascinating");
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_APPLICATIONDATA ".0.1." CTHULHU_SANDBOX_APPLICATIONDATA_ACCESSPATH), "/appdata");
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_APPLICATIONDATA ".0.1." CTHULHU_SANDBOX_APPLICATIONDATA_NAME), "TestApplicationData");
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_APPLICATIONDATA ".0.1." CTHULHU_SANDBOX_APPLICATIONDATA_RETAIN), "UntilStopped");
    assert_int_equal(GETP_UINT32(sb, CTHULHU_SANDBOX_APPLICATIONDATA ".0.1." CTHULHU_SANDBOX_APPLICATIONDATA_CAPACITY), 1);
    assert_int_equal(GETP_UINT32(sb, CTHULHU_SANDBOX_APPLICATIONDATA ".0.1." CTHULHU_SANDBOX_APPLICATIONDATA_ENCRYPTED), false);
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_DEVICE), "/dev/null");
    assert_int_equal(GETP_BOOL(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_CREATE), true);
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_PERMISSION), "Allow");
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_ACCESS), "rwm");
    assert_int_equal(GETP_INT32(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_MAJOR), 1);
    assert_int_equal(GETP_INT32(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_MINOR), 3);
    assert_string_equal(GETP_CHAR(sb, CTHULHU_SANDBOX_DEVICES ".0.1." CTHULHU_SANDBOX_DEVICES_TYPE), "c");

    amxc_var_t* ctr = amxc_var_get_first(config->ctr_create);
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_ID), "bf8eaa5b-71cf-516c-969f-033686fd7572");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_LINKED_UUID), "321fbff8-7fb2-5ccf-b2a8-8eaa8c818ebc");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_BUNDLE), "alpine");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_BUNDLEVERSION), "3.14");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_SANDBOX), "generic");
    assert_int_equal(GET_UINT32(ctr, CTHULHU_CONTAINER_AUTOSTART), 1);
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_MODULEVERSION), "testVersion");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_REQUIRED_ROLES), "Full Access");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_OPTIONAL_ROLES), "Restricted Access");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_ENVIRONMENTVARIABLES ".0." CTHULHU_CONTAINER_ENVIRONMENTVARIABLES_KEY), "NEW_VAR");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_ENVIRONMENTVARIABLES ".0." CTHULHU_CONTAINER_ENVIRONMENTVARIABLES_VALUE), "Example");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_DISKLOCATION), "/lcm/rlyeh/images/prpl-foundation/lcm/samples/lcmsampleapp/lcm-sample-app-x86-64");
    assert_int_equal(GET_BOOL(ctr, CTHULHU_CONTAINER_UNPRIVILEGED_PRIVILEGED), false);
    assert_int_equal(GET_UINT32(ctr, CTHULHU_CONTAINER_UNPRIVILEGED_NUMREQUIREDUIDS), 10);
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_HOSTOBJECT ".0." CTHULHU_CONTAINER_HOSTOBJECT_SOURCE), "/var/log");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_HOSTOBJECT ".0." CTHULHU_CONTAINER_HOSTOBJECT_DESTINATION), "/tmp/log");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_HOSTOBJECT ".0." CTHULHU_CONTAINER_HOSTOBJECT_OPTIONS), "type=mount,bind,rw,create=dir");
    assert_string_equal(GET_CHAR(ctr, CTHULHU_CONTAINER_UPDATED), "1970-01-01T00:00:00Z");
    assert_int_equal(GET_INT32(ctr, CTHULHU_CONTAINER_RESOURCES_CPU), 85);
    assert_int_equal(GET_INT32(ctr, CTHULHU_CONTAINER_RESOURCES_DISKSPACE), 5123);
    assert_int_equal(GET_INT32(ctr, CTHULHU_CONTAINER_RESOURCES_MEMORY), 4096);
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_APPLICATIONDATA ".0." CTHULHU_CONTAINER_APPLICATIONDATA_ACCESSPATH), "/appdata");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_APPLICATIONDATA ".0." CTHULHU_CONTAINER_APPLICATIONDATA_NAME), "TestApplicationData");
    assert_string_equal(GETP_CHAR(ctr, CTHULHU_CONTAINER_APPLICATIONDATA ".0." CTHULHU_CONTAINER_APPLICATIONDATA_RETAIN), "UntilStopped");
    assert_int_equal(GETP_UINT32(ctr, CTHULHU_CONTAINER_APPLICATIONDATA ".0." CTHULHU_CONTAINER_APPLICATIONDATA_CAPACITY), 1);
    assert_int_equal(GETP_UINT32(ctr, CTHULHU_CONTAINER_APPLICATIONDATA ".0." CTHULHU_CONTAINER_APPLICATIONDATA_ENCRYPTED), false);

    // reset the prestartup config
    amxc_var_set_type(config->sb_create, AMXC_VAR_ID_LIST);
    amxc_var_set_type(config->ctr_create, AMXC_VAR_ID_LIST);

    LOG_EXIT
}

void test_cthulhu_import_priv_ctr(UNUSED void** state) {
    LOG_ENTRY

    const char* import_data_file = "cthulhu_Cthulhu_priv.json";

    assert_int_equal(call_import(import_data_file), 0);

    cthulhu_prestartup_config_t* config = get_prestartup_config();

    amxc_var_t* ctr = amxc_var_get_first(config->ctr_create);
    amxc_var_dump(ctr, 1);
    assert_int_equal(GET_BOOL(ctr, CTHULHU_CONTAINER_UNPRIVILEGED_PRIVILEGED), true);

    LOG_EXIT
}
