/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_dm.h>

#include "dm_powerstatus.h"
#include "tr181-powerstatus.h"
#include "powersensor_info.h"
#include "common_functions.h"
#include "test_functional.h"

#define ODL_MOCK_MAIN "../common/mock_tr181-powerstatus.odl"
#define ODL_DEFS "../../odl/tr181-powerstatus_definition.odl"
#define ODL_DEFAULTS "mock_defaults.odl"
#define SENSOR_PATH "../common/mock_power"

int test_setup(void** state) {
    amxd_dm_t* dm = NULL;
    amxo_parser_t* parser = NULL;
    amxd_object_t* root = NULL;

    amxut_bus_setup(state);

    dm = amxut_bus_dm();
    assert_non_null(dm);
    parser = amxut_bus_parser();
    assert_non_null(parser);
    root = amxd_dm_get_root(dm);
    assert_non_null(root);

    resolver_add_all_functions();

    // Load ODL files
    assert_int_equal(amxo_parser_parse_file(parser, ODL_MOCK_MAIN, root), 0); // A stripped down version of odl/tr181-powerstatus.odl
    assert_int_equal(amxo_parser_parse_file(parser, ODL_DEFS, root), 0);
    assert_int_equal(amxo_parser_parse_file(parser, ODL_DEFAULTS, root), 0);

    // Call entrypoint
    assert_int_equal(_tr181_powerstatus_main(AMXO_START, dm, parser), 0);

    amxut_bus_handle_events();

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_tr181_powerstatus_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    amxut_bus_teardown(state);

    return 0;
}

void test_powersensor_initialized(UNUSED void** state) {
    amxd_object_t* powersensor_obj = amxd_dm_findf(amxut_bus_dm(), "PowerStatus.PowerSensor.1.");
    powersensor_info_t* sensor_info = NULL;

    assert_non_null(powersensor_obj);
    assert_non_null(powersensor_obj->priv);
    sensor_info = (powersensor_info_t*) powersensor_obj->priv;

    assert_ptr_equal(sensor_info->obj, powersensor_obj);
    assert_non_null(sensor_info->polling_timer);
}

static void assert_timestamp_equal(const char* path, const char* parameter, const char* expected) {
    amxd_object_t* powersensor_obj = amxd_dm_findf(amxut_bus_dm(), path);
    char* lastupdate = amxc_var_dyncast(cstring_t, amxd_object_get_param_value(powersensor_obj, parameter));
    assert_string_equal(lastupdate, expected);
    free(lastupdate);
}

static void assert_timestamp_not_equal(const char* path, const char* parameter, const char* expected) {
    amxd_object_t* powersensor_obj = amxd_dm_findf(amxut_bus_dm(), path);
    char* lastupdate = amxc_var_dyncast(cstring_t, amxd_object_get_param_value(powersensor_obj, parameter));
    assert_string_not_equal(lastupdate, expected);
    free(lastupdate);
}

void test_powersensor_enable_toggle(UNUSED void** state) {
    // PowerSensor instance "demo" is disabled by default => Should be disabled
    amxut_dm_param_equals(bool, "PowerStatus.PowerSensor.1.", "Enable", false);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", "");
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Disabled");
    assert_timestamp_equal("PowerStatus.PowerSensor.1.", "LastUpdate", "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 0);

    // Enable it but without setting a correct filepath => Should be an error
    amxut_dm_param_set(bool, "PowerStatus.PowerSensor.1.", "Enable", true);
    amxut_timer_go_to_future_ms(1000);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", "");
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Error");
    assert_timestamp_equal("PowerStatus.PowerSensor.1.", "LastUpdate", "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 0);

    // Set the filepath to the dummy sensor file => Should be OK
    amxut_dm_param_set(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", SENSOR_PATH);
    amxut_timer_go_to_future_ms(1000);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Enabled");
    assert_timestamp_not_equal("PowerStatus.PowerSensor.1.", "LastUpdate", "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 10000);

    // Disable the instance => Should be disabled but Power and LastUpdate is saved
    amxut_dm_param_set(bool, "PowerStatus.PowerSensor.1.", "Enable", false);
    amxut_dm_param_set(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", SENSOR_PATH);
    amxut_timer_go_to_future_ms(1000);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Disabled");
    assert_timestamp_not_equal("PowerStatus.PowerSensor.1.", "LastUpdate", "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 10000);

    // Enable it again and change the path to an incorrect file => Should be Error but Power and LastUpdate is saved
    amxut_dm_param_set(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", "not/valid/path");
    amxut_dm_param_set(bool, "PowerStatus.PowerSensor.1.", "Enable", true);
    amxut_timer_go_to_future_ms(1000);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Error");
    assert_timestamp_not_equal("PowerStatus.PowerSensor.1.", "LastUpdate", "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 10000);
}

void test_powersensor_pollinginterval(UNUSED void** state) {
    amxd_object_t* powersensor_obj = amxd_dm_findf(amxut_bus_dm(), "PowerStatus.PowerSensor.1.");
    char* lastupdate_saved = NULL;
    char* lastupdate = NULL;

    amxut_dm_param_set(bool, "PowerStatus.PowerSensor.1.", "Enable", true);
    amxut_dm_param_set(cstring_t, "PowerStatus.PowerSensor.1.", "PowerPath", SENSOR_PATH);
    amxut_dm_param_set(uint32_t, "PowerStatus.PowerSensor.1.", "PollingInterval", 30);
    amxut_timer_go_to_future_ms(1000);
    amxut_dm_param_equals(cstring_t, "PowerStatus.PowerSensor.1.", "Status", "Enabled");
    lastupdate_saved = amxc_var_dyncast(cstring_t, amxd_object_get_param_value(powersensor_obj, "LastUpdate"));
    assert_string_not_equal(lastupdate_saved, "0001-01-01T00:00:00Z");
    amxut_dm_param_equals(int32_t, "PowerStatus.PowerSensor.1.", "Power", 10000);
    amxut_timer_go_to_future_ms(25000);
    lastupdate = amxc_var_dyncast(cstring_t, amxd_object_get_param_value(powersensor_obj, "LastUpdate"));
    assert_string_equal(lastupdate_saved, lastupdate);
    free(lastupdate);
    amxut_timer_go_to_future_ms(10000);
    lastupdate = amxc_var_dyncast(cstring_t, amxd_object_get_param_value(powersensor_obj, "LastUpdate"));
    assert_string_not_equal(lastupdate_saved, lastupdate);
    free(lastupdate);
    free(lastupdate_saved);
}