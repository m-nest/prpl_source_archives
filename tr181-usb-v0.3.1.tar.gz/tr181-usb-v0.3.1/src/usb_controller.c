/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"

#define ME "usbcontroller"

/**
 * @brief Trims whitespace from a string.
 *
 * @param str The string to trim.
 * @return char* The trimmed string.
 */
char* trim_str(char* str) {
    if(str == NULL) {
        return NULL;              // Add null check
    }
    char* end;
    while(isspace((unsigned char) *str)) {
        str++;
    }

    if(*str == 0) {
        return str;
    }

    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char) *end)) {
        end--;
    }

    end[1] = '\0';
    return str;
}

/**
 * @brief Gets the error message for a given error code.
 *
 * @param error The error code.
 * @return const char* The error message.
 */
const char* get_error_message(int error) {
    switch(error) {
    case ERR_HOST_NOT_FOUND:
        return "ERR_HOST_NOT_FOUND";
    case ERR_HOST_ALREADY_EXISTS:
        return "ERR_HOST_ALREADY_EXISTS";
    case ERR_DEVICE_ALREADY_EXISTS:
        return "ERR_DEVICE_ALREADY_EXISTS";
    case ERR_PORT_NOT_FOUND:
        return "ERR_PORT_NOT_FOUND";
    case ERR_PORT_ALREADY_EXISTS:
        return "ERR_PORT_ALREADY_EXISTS";
    case ERR_PORT_ALREADY_CONNECTED:
        return "ERR_PORT_ALREADY_CONNECTED";
    case 0:
        return "NO ERROR";
    default:
        return "unknown error";
    }
}

/**
 * @brief Finds a USB host by its ID.
 *
 * @param id The host ID.
 * @return amxd_object_t* The USB host object.
 */
amxd_object_t* find_host(const char* id) {
    if(id == NULL) {
        return NULL;             // Add null check
    }
    return amxd_dm_findf(get_dm(), "USB.USBHosts.Host.%s.", id);
}

/**
 * @brief Adds a USB device.
 *
 * @param device_name The device name.
 */
void add_device(const char* device_name) {
    if(device_name == NULL) {
        return;                      // Add null check
    }
    if(isdigit(device_name[0])) {
        if(find_device(device_name) == NULL) {
            size_t size;
            const char* ptr;
            char host_id[5];
            int error;
            SAH_TRACEZ_NOTICE(ME, "[Device %s] Creating device...", device_name);
            ptr = strchr(device_name, '-');
            when_false_trace(ptr != NULL, exit, ERROR, "Failed to process %s", device_name);
            size = ptr - device_name;
            when_false_trace(size < sizeof(host_id), exit, ERROR, "Failed to process %s", device_name);
            memcpy(host_id, device_name, size);
            host_id[size] = '\0';
            error = host_add_device(host_id, device_name, device_name, device_name);
            if(error > 0) {
                SAH_TRACEZ_ERROR(ME, "[Device %s] ERROR: Creating device failed: %s", device_name, get_error_message(error));
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "[Device %s] WARNING: Already created", device_name);
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "[Device %s] ERROR: Invalid device ID ('%s')", device_name, device_name);
    }
exit:
    return;
}

/**
 * @brief Deletes a USB device.
 *
 * @param device_name The device name.
 * @param check_is_authorized When true, only remove device when it is authorized.
 */
void delete_device(const char* device_name, bool check_is_authorized) {
    if(device_name == NULL) {
        return;                      // Add null check
    }
    if(isdigit(device_name[0]) && (find_device(device_name) != NULL)) {
        int error;
        SAH_TRACEZ_NOTICE(ME, "[Device %s] Removing device...", device_name);
        error = host_del_device(device_name, check_is_authorized);
        if(error != 0) {
            SAH_TRACEZ_ERROR(ME, "[Device %s] ERROR: Removing device failed: %s", device_name, get_error_message(error));
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "[Device %s] ERROR: Unknown device ID ('%s')", device_name, device_name);
    }
}

/**
 * @brief Adds a USB disk.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void add_disk(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    const char* ptr;
    char host_id[5];
    size_t size;
    int error;
    if(!isdigit(sysfs_id[0])) {
        SAH_TRACEZ_ERROR(ME, "[Disk %s (%s)] ERROR: sysfs_id corrupted", device_name, sysfs_id);
        return;
    }

    if(strchr(sysfs_id, ':') != NULL) {
        SAH_TRACEZ_NOTICE(ME, "[Disk %s (Esata)] TODO: Add support for ESata", device_name);
    } else if(find_device(sysfs_id) == NULL) {
        ptr = strchr(sysfs_id, '-');
        when_false_trace(ptr != NULL, exit, ERROR, "Failed to process %s", sysfs_id);
        size = ptr - sysfs_id;
        when_false_trace(size < sizeof(host_id), exit, ERROR, "Failed to process %s", sysfs_id);
        memcpy(host_id, sysfs_id, size);
        host_id[size] = '\0';

        SAH_TRACEZ_NOTICE(ME, "[Disk %s (USB: %s)] Creating Device...", device_name, sysfs_id);

        error = host_add_device(host_id, device_name, sysfs_id, sysfs_id);
        if(error > 0) {
            SAH_TRACEZ_ERROR(ME, "[Disk %s (USB: %s)] ERROR: Failed creating device: %s", device_name, sysfs_id, get_error_message(error));
        }
    }
exit:
    return;
}

/**
 * @brief Deletes a USB disk.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void delete_disk(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    if(isdigit(sysfs_id[0]) && (find_device(sysfs_id) != NULL)) {
        if(strchr(sysfs_id, ':') != NULL) {
            SAH_TRACEZ_NOTICE(ME, "[Disk %s (Esata)] TODO: Add support for ESata", device_name);
        } else {
            int error;
            SAH_TRACEZ_NOTICE(ME, "[Disk %s (USB: %s)] Removing Device...", device_name, sysfs_id);

            error = host_del_device(sysfs_id, true);
            if(error != 0) {
                SAH_TRACEZ_ERROR(ME, "[Disk %s (USB: %s)] ERROR: Failed removing device: %s", device_name, sysfs_id, get_error_message(error));
            }
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "[Disk %s (USB: %s)] ERROR: Unknown device ID ('%s')", device_name, sysfs_id, sysfs_id);
    }
}

/**
 * @brief Adds a USB printer.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void add_printer(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    if(!isdigit(sysfs_id[0])) {
        SAH_TRACEZ_NOTICE(ME, "[Printer %s (%s)] ERROR: sysfs_id corrupted", device_name, sysfs_id);
        return;
    }

    if(find_device(sysfs_id) == NULL) {
        const char* ptr;
        char host_id[5];
        size_t size;
        int error;
        ptr = strchr(sysfs_id, '-');
        when_false_trace(ptr != NULL, exit, ERROR, "Failed to process %s", sysfs_id);
        size = ptr - sysfs_id;
        when_false_trace(size < sizeof(host_id), exit, ERROR, "Failed to process %s", sysfs_id);
        memcpy(host_id, sysfs_id, size);
        host_id[size] = '\0';

        SAH_TRACEZ_NOTICE(ME, "[Printer %s (USB: %s)] Creating Device...", device_name, sysfs_id);

        error = host_add_device(host_id, device_name, sysfs_id, sysfs_id);
        if(error > 0) {
            SAH_TRACEZ_ERROR(ME, "[Printer %s (USB: %s)] ERROR: Failed creating device: %s", device_name, sysfs_id, get_error_message(error));
        }
    }
exit:
    return;
}

/**
 * @brief Deletes a USB printer.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void delete_printer(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    if(isdigit(sysfs_id[0]) && (find_device(sysfs_id) != NULL)) {
        int error;
        SAH_TRACEZ_NOTICE(ME, "[Printer %s (USB: %s)] Removing device...", device_name, sysfs_id);
        error = host_del_device(sysfs_id, true);
        if(error != 0) {
            SAH_TRACEZ_ERROR(ME, "[Printer %s (USB: %s)] ERROR: Removing device failed: %s", device_name, sysfs_id, get_error_message(error));
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "[Printer %s (USB: %s)] ERROR: Unknown device ID", device_name, sysfs_id);
    }
}

/**
 * @brief Adds a USB TTY device.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void add_tty(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    if(!isdigit(sysfs_id[0])) {
        SAH_TRACEZ_ERROR(ME, "[Device %s (%s)] ERROR: sysfs_id corrupted", device_name, sysfs_id);
        return;
    }
    if(find_device(sysfs_id) == NULL) {
        const char* ptr;
        char host_id[5];
        size_t size;
        int error;
        ptr = strchr(sysfs_id, '-');
        when_false_trace(ptr != NULL, exit, ERROR, "Failed to process %s", sysfs_id);
        size = ptr - sysfs_id;
        when_false_trace(size < sizeof(host_id), exit, ERROR, "Failed to process %s", sysfs_id);
        memcpy(host_id, sysfs_id, size);
        host_id[size] = '\0';

        SAH_TRACEZ_NOTICE(ME, "[Device %s (USB: %s)] Creating Device...", device_name, sysfs_id);

        error = host_add_device(host_id, device_name, sysfs_id, sysfs_id);
        if(error > 0) {
            SAH_TRACEZ_ERROR(ME, "[Device %s (USB: %s)] ERROR: Failed creating device: %s", device_name, sysfs_id, get_error_message(error));
        }
    }
exit:
    return;
}

/**
 * @brief Deletes a USB TTY device.
 *
 * @param device_name The device name.
 * @param sysfs_id The sysfs ID.
 */
void delete_tty(const char* device_name, const char* sysfs_id) {
    if((device_name == NULL) || (sysfs_id == NULL)) {
        return;                                          // Add null check
    }
    if(isdigit(sysfs_id[0]) && (find_device(sysfs_id) != NULL)) {
        int error = 0;
        SAH_TRACEZ_NOTICE(ME, "[Device %s (USB: %s)] Removing Device...", device_name, sysfs_id);

        error = host_del_device(sysfs_id, true);
        if(error != 0) {
            SAH_TRACEZ_ERROR(ME, "[Device %s (USB: %s)] ERROR: Failed removing device: %s", device_name, sysfs_id, get_error_message(error));
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "[Device %s (USB: %s)] ERROR: Unknown device ID ('%s')", device_name, sysfs_id, sysfs_id);
    }
}
