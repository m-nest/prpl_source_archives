#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="pcm-manager"
PROG="/usr/bin/pcm-manager"
datamodel_root="PersistentConfiguration"
PROG_OPTIONS=""

#Show PCM backup files content
pcm_content(){
   for file in /cfg/pcm/*.json; do
      echo "Content of PCM backup file ${file#/cfg/pcm/}:"
      cat "$file"
   done
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

#preservice_hook() {
#    logger -s "pre-service hook ${name}"
#}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    #preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

debuginfo() {
    process_debug_info ${datamodel_root}
    pcm_content
}
