/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <arpa/inet.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dm_pool_actions.h"
#include "pools.h"
#include "pool_info.h"

#define ME "pool_actions"

/**
 * @brief
 * Remove a pool from the DHCPv4.Server object.
 *
 * @param object The DHCPv4.Server object.
 * @param param NULL
 * @param reason The action identifier.
 * @param args The data of the pool to remove.
 * @param retval Variant to store the result of the action.
 * @param priv NULL
 * @return amxd_status_ok if the pool was successfully removed.
 */
amxd_status_t _pool_deleted(amxd_object_t* object,
                            amxd_param_t* param,
                            amxd_action_t reason,
                            const amxc_var_t* const args,
                            amxc_var_t* const retval,
                            void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* pool = NULL;
    int index = 0;
    const char* name = NULL;
    pool_info_t* info = NULL;

    SAH_TRACEZ_INFO(ME, "DHCPv4 server pool removed from TR-181 data model");
    when_null_trace(args, exit, ERROR, "Cannot get the data of the pool to remove.");
    when_null_trace(object, exit, ERROR, "Cannot get DHCPv4.Server object.");

    index = GET_INT32(args, "index");
    if(index == 0) {
        name = GET_CHAR(args, "name");
        when_null_trace(name, exit, ERROR, "Cannot get pool name.");
    }
    pool = amxd_object_get_instance(object, name, index);
    when_null_trace(pool, exit, ERROR, "Cannot get DHCPv4 pool object.");
    info = (pool_info_t*) pool->priv;
    when_null_trace(info, exit, ERROR, "Cannot get DHCPv4 pool private information.");
    SAH_TRACEZ_INFO(ME, "Removing DHCPv4 server pool '%s' from UCI...", info->intf_alias);
    pool_info_disable(pool);
    pools_disable_all_pool_static_addresses(pool);
    pool_info_clear((pool_info_t**) &pool->priv);
    status = amxd_action_object_destroy(object, param, reason, args, retval, priv);
exit:
    return status;
}
