/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "common_dm_functions.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

/* Other libraries' headers */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "sfp_types_and_constants.h" /* SFP_ID_UNKNOWN */

/**
 * Check that SFPs.SFPCage.1 indicates no SFP is present.
 */
void check_no_sfp_is_present(amxd_dm_t* dm) {
    amxc_var_t value;
    amxc_var_init(&value);

    amxd_object_t* const cage = amxd_dm_findf(dm, "SFPs.SFPCage.1");
    assert_non_null(cage);

    assert_int_equal(amxd_object_get_param(cage, "SFF8024Identifier", &value), amxd_status_ok);
    assert_int_equal(GET_UINT32(&value, NULL), SFP_ID_UNKNOWN);

    assert_int_equal(amxd_object_get_param(cage, "SFPPresent", &value), amxd_status_ok);
    assert_int_equal(GET_BOOL(&value, NULL), 0);

    assert_int_equal(amxd_object_get_param(cage, "SFPReference", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "Device.SFPs.Mgmt.SFF8472.1.");

    assert_int_equal(amxd_object_get_param(cage, "SFPType", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "Unsupported");

    amxc_var_clean(&value);
}

/**
 * Check that SFPs.SFPCage.1 indicates an SFP of type @a sfp_type is present.
 *
 * Check that the parameter SFF8024Identifier has value 3 (i.e. SFP with
 * SFF-8472 mgmt IF).
 */
void check_sfp_cage_parameters(amxd_dm_t* dm, const char* sfp_type) {
    amxc_var_t value;
    amxc_var_init(&value);

    amxd_object_t* const cage = amxd_dm_findf(dm, "SFPs.SFPCage.1");
    assert_non_null(cage);

    assert_int_equal(amxd_object_get_param(cage, "SFF8024Identifier", &value), amxd_status_ok);
    assert_int_equal(GET_UINT32(&value, NULL), SFP_ID_SFP_WITH_SFF8472_MGMT_IF);

    assert_int_equal(amxd_object_get_param(cage, "SFPPresent", &value), amxd_status_ok);
    assert_int_equal(GET_BOOL(&value, NULL), 1);

    assert_int_equal(amxd_object_get_param(cage, "SFPReference", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "Device.SFPs.Mgmt.SFF8472.1.");

    assert_int_equal(amxd_object_get_param(cage, "SFPType", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), sfp_type);

    amxc_var_clean(&value);
}

