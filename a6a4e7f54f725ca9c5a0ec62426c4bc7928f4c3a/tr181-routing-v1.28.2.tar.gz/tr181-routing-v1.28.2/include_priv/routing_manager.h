/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __ROUTING_MANAGER_H__
#define __ROUTING_MANAGER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>

#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>

#include <amxd/amxd_types.h>

#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include <debug/sahtrace.h>

#include "subscription_manager.h"
#include "dm_interface.h"
#include "ipv4_routes.h"
#include "ipv6_routes.h"
#include "ipvx.h"

typedef struct {
    amxc_llist_t subscription_manager;
    ipv4_routes_t ipv4_routes;
    ipv6_routes_t ipv6_routes;
} routing_manager_t;

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxm_shared_object_t* so;
} routing_manager_app_t;

typedef enum router_action {
    action_add,
    action_remove,
    action_error
} router_action_t;

#define ROUTING_ROUTER_ACTION_ADD "add-route"
#define ROUTING_ROUTER_ACTION_REMOVE "remove-route"

#define string_empty(x) ((x == NULL) || (*x == '\0'))

routing_manager_t get_routing_manager(void);
amxd_dm_t* PRIVATE routing_manager_get_dm(void);
amxo_parser_t* PRIVATE routing_manager_get_parser(void);
amxb_bus_ctx_t* PRIVATE routing_manager_get_netdev_context(void);
const cstring_t PRIVATE routing_manager_get_prefix(void);
cstring_t PRIVATE routing_manager_get_prefix_with_value(const cstring_t value);
amxd_status_t PRIVATE routing_manager_call_ctrl(amxd_object_t* route, const char* action, amxc_var_t* data);

int _routing_manager_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

amxd_status_t _route_forwarding_deleted_ipvx_route(amxd_object_t* object,
                                                   amxd_param_t* param,
                                                   amxd_action_t reason,
                                                   const amxc_var_t* const args,
                                                   amxc_var_t* const retval,
                                                   void* priv);

amxd_status_t _check_is_empty_or_in(amxd_object_t* object,
                                    amxd_param_t* param,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv);

void _routing_router_added(const char* const sig_name,
                           const amxc_var_t* const data,
                           void* const priv);

amxd_status_t _router_deleted(amxd_object_t* object,
                              amxd_param_t* param,
                              amxd_action_t reason,
                              const amxc_var_t* const args,
                              amxc_var_t* const retval,
                              void* priv);

void _routing_table_id_changed(const char* const sig_name,
                               const amxc_var_t* const data,
                               void* const priv);

void routing_manager_enable_cb(bool enable);

void _print_event(const char* const sig_name,
                  const amxc_var_t* const data,
                  void* const priv);

rmi_return_code_t routing_manager_init(void);
void routing_manager_cleanup(void);

#ifdef __cplusplus
}
#endif

#endif // __ROUTING_MANAGER_H__

