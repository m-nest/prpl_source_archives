/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "tr181-cpu.h"
#include "cpu_utils.h"
#include "cpu_dm_utils.h"
#include "cpu_dm.h"

#define ME "cpu-dm-event"

/**
   @ingroup  CPU Plugin
   @defgroup cpu_dm_event
 */

/**
   @ingroup  cpu_dm_event
   Pushes configured DVFS values to the system.

   This function writes the data model's configured DVFS parameters to the
   corresponding sysfs files, making the settings take effect. It writes:
   - ScalingGovernor to scaling_governor
   - ScalingMaxFrequency to scaling_max_freq
   - ScalingMinFrequency to scaling_min_freq

   Why these three: These are the user-controllable parameters that actually
   change CPU behavior. Other parameters like CurrentFrequency are read-only,
   and hardware limits (MinFrequency, MaxFrequency) cannot be changed.

   @param dvfs_obj The DVFS data model object containing configured values
   @param cpu_name The CPU identifier (e.g., "cpu0")
 */
static void cpu_dm_dvfs_push_values(amxd_object_t* dvfs_obj, const char* cpu_name) {
    static const char* file_params[][2] = {
        { "scaling_governor", "ScalingGovernor"},
        { "scaling_max_freq", "ScalingMaxFrequency" },
        { "scaling_min_freq", "ScalingMinFrequency" }
    };

    for(int i = 0; i < NR_DEFAULTS; i++) {
        amxd_param_t* param = amxd_object_get_param_def(dvfs_obj, file_params[i][1]);
        cpu_write_value(cpu_name, file_params[i][0], &param->value);
    }
}

/**
   @ingroup  cpu_dm_event
   Event handler called when the application starts.

   This is triggered by the "app:start" event, which fires after the data model
   has been loaded and the event loop is running. At this point it's safe to
   initialize CPU instances and interact with the system.

   Why wait for app:start: During plugin loading, the data model structure is
   being created but not fully populated. We need to wait until the application
   is fully initialized before scanning for CPUs and populating their parameters.

   @param sig_name The signal name (unused)
   @param data Signal data (unused)
   @param priv Private data (unused)
 */
void _cpu_app_start(UNUSED const char* const sig_name,
                    UNUSED const amxc_var_t* const data,
                    UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "TR181-cpu plugin : event loop started");
    cpu_dm_cpu_init();
}

/**
   @ingroup  cpu_dm_event
   Event handler called when the Enable parameter changes.

   This is triggered by data model change events when a user sets the Enable
   parameter of any DVFS object. The handler performs different actions based
   on the new Enable value and whether DVFS is supported:

   - If Supported=false: Sets Status="Unsupported" (regardless of Enable)
   - If Enable=true: Sets Status="Enabled" and pushes configured values to sysfs
   - If Enable=false: Sets Status="Disabled" and restores original system defaults

   Why push on enable: When enabling DVFS, we apply the user's configured
   settings (governor, min/max frequency) to the system.

   Why restore on disable: When disabling DVFS, we don't just leave the system
   in whatever state it was in - we restore the original settings that were
   active before we started managing this CPU.

   @param sig_name The signal name (unused)
   @param data Signal data containing the changed object and parameters
   @param priv Private data (unused)
 */
void _on_enable_changed(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* dvfs_obj = amxd_dm_signal_get_object(cpu_get_dm(), data);
    const char* cpu_name = NULL;
    amxd_param_t* supported_param = NULL;
    amxd_param_t* enable_param = NULL;

    when_null_trace(dvfs_obj, exit, ERROR, "DVFS object could not be found");
    cpu_name = cpu_dm_dvfs_get_cpu_name(dvfs_obj);
    supported_param = amxd_object_get_param_def(dvfs_obj, "Supported");
    enable_param = amxd_object_get_param_def(dvfs_obj, "Enable");

    if(!GET_BOOL(&supported_param->value, NULL)) {
        cpu_dm_dfvs_set_status(dvfs_obj, "Unsupported");
    } else {
        if(GET_BOOL(&enable_param->value, NULL)) {
            cpu_dm_dfvs_set_status(dvfs_obj, "Enabled");
            cpu_dm_dvfs_push_values(dvfs_obj, cpu_name);
        } else {
            cpu_dm_dfvs_set_status(dvfs_obj, "Disabled");
            cpu_reset_dvfs_default(cpu_name);
        }
    }

exit:
    SAH_TRACEZ_OUT(ME);
}