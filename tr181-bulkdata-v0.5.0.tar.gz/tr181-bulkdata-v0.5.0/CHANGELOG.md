# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.7.0 - 2025-03-25(12:48:10 +0000)

### Other

- - TR181 Bulkdata sending report over HTTP/HTTPS

## Release v0.6.4 - 2024-09-30(05:51:59 +0000)

### Other

- CI: Disable squashing of open source commits
- [AMX] Disable commit squashing

## Release v0.6.3 - 2024-07-29(06:09:42 +0000)

### Other

- - [amx] Failing to restart processes with init scripts

## Release v0.6.2 - 2024-04-10(10:03:51 +0000)

### Changes

- Make amxb timeouts configurable

## Release v0.6.1 - 2024-03-20(21:29:56 +0000)

### Fixes

- [ACS] [USP] [DC] change ReportFormat to ObjectHierarchy does not change the output format

## Release v0.6.0 - 2024-03-20(21:13:19 +0000)

### Other

- [Events Log][System] Miscellaneous

## Release v0.5.0 - 2024-02-05(16:23:02 +0000)

### New

- Add tr181-device proxy odl files to components

## Release v0.4.1 - 2024-01-24(09:21:24 +0000)

### Fixes

- Validate the reason a validation function is called

## Release v0.4.0 - 2024-01-17(09:34:33 +0000)

### New

- Add tr181-device proxy odl files to components

## Release v0.3.16 - 2024-01-09(15:48:58 +0000)

### Other

- Add opensource license

## Release v0.3.15 - 2023-10-13(14:11:31 +0000)

### Changes

-  All applications using sahtrace logs should use default log levels

## Release v0.3.14 - 2023-09-22(11:15:37 +0000)

### Fixes

- BulkData.Profile.{i}.Controller needs to be reboot persistent

## Release v0.3.13 - 2023-09-07(12:55:32 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release v0.3.12 - 2023-08-04(08:34:56 +0000)

### Fixes

- [ACS] Data collections resets and does not follow the initial time interval set after the RG reboots

## Release v0.3.11 - 2023-07-20(12:07:43 +0000)

### Changes

- [BulkData] Adapt bulkdata to new IMTP APIs

## Release v0.3.10 - 2023-07-05(07:14:59 +0000)

### Fixes

- Init script has no shutdown function

## Release v0.3.9 - 2023-04-20(09:49:30 +0000)

### Fixes

- Default JSON ReportFormat is NameValuePair

## Release v0.3.8 - 2023-04-20(06:55:58 +0000)

### Fixes

- [AMX] BulkData segfault when profile is deleted

## Release v0.3.7 - 2023-03-21(12:31:34 +0000)

### Fixes

- [KPN][SW2] sah_amx_tr181_bulkdata doc gen error

## Release v0.3.6 - 2023-02-28(12:17:35 +0000)

### Other

- Documentation generation is failing when extra default files are added

## Release v0.3.5 - 2023-02-22(11:53:32 +0000)

### Other

- [KPN][SW2] sah_amx_tr181_bulkdata doc gen error

## Release v0.3.4 - 2023-01-09(10:30:57 +0000)

### Other

- [KPN SW2][Security]Restrict ACL of admin user

## Release v0.3.3 - 2022-10-27(13:29:28 +0000)

### Other

- [AMX][BulkData] Extend documentation

## Release v0.3.2 - 2022-10-27(10:09:37 +0000)

### Fixes

- [AMX][BulkData] Don't disable profile in start function

## Release v0.3.1 - 2022-10-26(07:38:02 +0000)

### Fixes

- Push! event has exclamation mark

## Release v0.3.0 - 2022-10-24(07:12:26 +0000)

### New

- [amx][bulkdata] Add support for MQTT communication in Bulkdata profiles

## Release v0.2.4 - 2022-10-17(11:02:17 +0000)

### Other

- - Implement Device.BulkData.Profile.{i}.ForceCollection() and Device.BulkData.Profile.{i}.Push! event

## Release v0.2.3 - 2022-10-13(08:46:49 +0000)

### Other

- Improve plugin boot order

## Release v0.2.2 - 2022-07-14(15:07:24 +0000)

## Release v0.2.1 - 2022-03-24(10:52:15 +0000)

### Changes

- [GetDebugInformation] Add data model debuginfo in component services

## Release v0.2.0 - 2022-02-11(12:52:28 +0000)

### New

- FIG-2089 - [Standalone] Implement Ambiorix based BulkData manager

## Release v0.1.0 - 2021-12-22(10:08:53 +0000)

### New

- [Standalone] Implement Ambiorix based BulkData manager

