# netmodel-ppp

This netmodel client handles the synchronization between netmodel interfaces marked with the ppp flag and the PPP.Interface. instances.
