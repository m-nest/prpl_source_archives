/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_methods.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contain implementation for RPC's and DataModel mapper functionality like renamings and hidins.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <debug/sahtrace.h>

#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxrt/amxrt.h>

#include "dmm.h"
#include "dmm_methods.h"
#include "dmm_info.h"
#include "dmm_connect_mngr.h"
#include "dmm_trie_translator.h"

#define ME "dmm"           /*!< Prefix for SAH logger method */

#define AMXB_BUS_TIMEOUT 5 /*!< bus timeout for sync function call on the component */

/**
 * @brief Retrieves the DMM request type based on the function name suffix.
 *
 * This function takes a string suffix (e.g., "_get", "_set") and
 * maps it to the corresponding enumeration value in
 * @ref dmm_downstream_request_type.
 *
 * @note The lookup is performed using direct string comparison (strcmp).
 *
 * @param[in] func The string containing the request suffix (e.g., "_get").
 * @return @ref dmm_downstream_request_type The corresponding DMM request type enumeration value.
 * Returns @ref DMM_RQT_UNKNOWN if the suffix is not found.
 *
 * @see dmm_downstream_request_type
 */
dmm_downstream_request_type dmm_downstream_request_type_get(const char* func) {
    int retval = DMM_RQT_UNKNOWN;

    when_str_empty(func, exit);

    if(strcmp(func, "_get") == 0) {
        retval = DMM_GET;
    } else if(strcmp(func, "_set") == 0) {
        retval = DMM_SET;
    } else if(strcmp(func, "_add") == 0) {
        retval = DMM_ADD;
    } else if(strcmp(func, "_del") == 0) {
        retval = DMM_DEL;
    } else if(strcmp(func, "_list") == 0) {
        retval = DMM_LIST;
    } else if(strcmp(func, "_describe") == 0) {
        retval = DMM_DESCRIBE;
    } else if(strcmp(func, "_exec") == 0) {
        retval = DMM_EXEC;
    } else if(strcmp(func, "_get_supported") == 0) {
        retval = DMM_GET_SUPPORTED;
    } else if(strcmp(func, "_get_instances") == 0) {
        retval = DMM_GET_INSTANCES;
    } else if(strcmp(func, "_get_subscribe") == 0) {
        retval = DMM_SUBSCRIBE;
    } else if(strcmp(func, "_get_unsubscribe") == 0) {
        retval = DMM_UNSUBSCRIBE;
    }

exit:
    return retval;
}

char* dmm_indexes_replace_strict(char* str_ph, size_t ph_buf_size, const char* str_i) {
    when_null(str_ph, exit);
    when_null(str_i, exit);

    char* p = str_ph;        // current position in the pattern
    const char* s = str_i;   // current position in the input string

    while(*p && *s) {
        if(strncmp(p, "{i}", I_PLACEHOLDER_LEN) == 0) {
            const char* s_start = s;

            // Expecting a numeric index in str_i
            if(!isdigit(*s)) {
                return NULL;
            }

            // Read consecutive digits (the index from str_i)
            while(isdigit(*s)) {
                s++;
            }

            size_t number_len = s - s_start;  // length of the extracted number
            size_t tail_len = strlen(p + 3);  // number of chars after "{i}"

            // Check if buffer is large enough after substitution
            if((size_t) (p - str_ph) + number_len + tail_len >= ph_buf_size) {
                return NULL;
            }
            // Adjust the tail position if number length differs from "{i}" (3 chars)
            if(number_len != 3) {
                memmove(p + number_len, p + 3, tail_len + 1); // +1 for null-terminator
            }
            // Copy the extracted index into the pattern buffer
            memcpy(p, s_start, number_len);

            p += number_len;
        } else {
            // Characters must match exactly
            if(*p != *s) {
                return NULL;
            }

            p++;
            s++;
        }
    }

    // allow trailing tokens in str_i, unless there is {i} among them
    if((*p == '\0') && !strstr(s, "{i}")) {
        return str_ph;
    }

exit:
    return NULL;
}

char* dmm_indexes_replace(char* str_ph, size_t ph_buf_size, const char* str_i) {
    char* ret = NULL;

    when_null(str_ph, exit);
    when_null(str_i, exit);

    // Temporary buffer used to construct final output.
    char temp[MAX_PATH_LEN];
    size_t temp_pos = 0;

    // Read pointer for the template string with placeholders.
    const char* p_ph = str_ph;

    // Read pointer for the input string with numeric index values.
    const char* p_si = str_i;

    while(*p_ph) {

        // Extract the next token from str_ph (until '.' or end of string).
        const char* ph_token_start = p_ph;
        size_t ph_len = 0;
        while(p_ph[ph_len] && p_ph[ph_len] != '.') {
            ph_len++;
        }


        // Extract the next token from str_i (until '.' or end of string).
        const char* si_token_start = p_si;
        size_t si_len = 0;
        while(p_si[si_len] && p_si[si_len] != '.') {
            si_len++;
        }

        // Ensure str_i has enough tokens.
        if((si_len == 0) && (ph_len > 0)) {
            return NULL;
        }

        // If this token in str_ph is "{i}", substitute with numeric token from str_i.
        if((ph_len == 3) &&
           (ph_token_start[0] == '{') &&
           (ph_token_start[1] == 'i') &&
           (ph_token_start[2] == '}')) {
            // Validate that the token from str_i consists only of digits.
            for(size_t i = 0; i < si_len; i++) {
                if(!isdigit((unsigned char) si_token_start[i])) {
                    return NULL;
                }
            }

            // Ensure the replacement fits into the temporary buffer.
            if(temp_pos + si_len >= sizeof(temp)) {
                return NULL;
            }

            // Copy the numeric token from str_i to the output buffer.
            memcpy(&temp[temp_pos], si_token_start, si_len);
            temp_pos += si_len;
        } else {
            // Normal token: copy it as is from str_ph (no comparison to str_i).
            if(temp_pos + ph_len >= sizeof(temp)) {
                return NULL;
            }

            memcpy(&temp[temp_pos], ph_token_start, ph_len);
            temp_pos += ph_len;
        }

        // Handle the '.' separator between tokens.
        if((p_ph[ph_len] == '.') && (p_si[si_len] == '.')) {
            temp[temp_pos++] = '.';
            p_ph += ph_len + 1;
            p_si += si_len + 1;
        } else if((p_ph[ph_len] == '\0') && (p_si[si_len] == '\0')) {
            // Both strings reached end at the same time — final token.
            p_ph += ph_len;
            p_si += si_len;
            break;
        } else {
            // Mismatched number of tokens.
            return NULL;
        }
    }

    // Ensure the final result fits into the destination buffer.
    if(temp_pos >= ph_buf_size) {
        return NULL;
    }

    // NULL-terminate result and copy back over original buffer.
    temp[temp_pos] = '\0';
    memcpy(str_ph, temp, temp_pos + 1);

    ret = str_ph;

exit:
    return ret;
}

char* dmm_get_mapped_subpath(amxc_var_t* in_path) {
    amxd_path_t path;
    char* path_part = NULL;
    char* ret = NULL;
    amxd_object_t* tmp = NULL;
    amxd_object_t* object = amxd_dm_get_root(dmm_get_dm());

    amxd_path_init(&path, GET_CHAR(in_path, NULL));
    do {
        path_part = amxd_path_get_first(&path, true);
        tmp = amxd_object_findf(object, "%s", path_part);
        if(tmp != NULL) {
            object = tmp;
        } else {
            amxd_path_prepend(&path, path_part);
        }
        free(path_part);
    } while(tmp != NULL);

    amxd_path_clean(&path);

    // If some object found
    if(object != amxd_dm_get_root(dmm_get_dm())) {
        ret = amxd_object_get_path(object, AMXD_OBJECT_TERMINATE);
    }

    return ret;
}

bool dmm_is_ret_dm_resp(const char* entity_path, amxc_var_t* ret) {
    bool retval = false;
    amxd_path_t path;
    amxc_string_t search_string;

    amxd_path_init(&path, entity_path);
    amxc_string_init(&search_string, 0);

    amxc_string_setf(&search_string, "'%s'.%s", amxd_path_get(&path, AMXD_OBJECT_TERMINATE), "is_multi_instance");
    if(GETP_ARG(ret, amxc_string_get(&search_string, 0)) == NULL) {
        goto exit;
    }

    amxc_string_setf(&search_string, "'%s'.%s", amxd_path_get(&path, AMXD_OBJECT_TERMINATE), "supported_commands");
    if(GETP_ARG(ret, amxc_string_get(&search_string, 0)) == NULL) {
        goto exit;
    }

    amxc_string_setf(&search_string, "'%s'.%s", amxd_path_get(&path, AMXD_OBJECT_TERMINATE), "supported_events");
    if(GETP_ARG(ret, amxc_string_get(&search_string, 0)) == NULL) {
        goto exit;
    }

    amxc_string_setf(&search_string, "'%s'.%s", amxd_path_get(&path, AMXD_OBJECT_TERMINATE), "supported_params");
    if(GETP_ARG(ret, amxc_string_get(&search_string, 0)) == NULL) {
        goto exit;
    }

    retval = true;

exit:
    amxc_string_clean(&search_string);
    amxd_path_clean(&path);
    return(retval);
}


int dmm_take_entity_by_path_in_dm_resp(const char* entity_path, amxc_var_t* ret, amxc_var_t** entity_taken_var, bool do_take) {
    int retval = -1;
    amxd_path_t path;
    amxc_var_t* entity_var = NULL;
    const char* param = NULL;
    const char* entity_obj_path = NULL;

    when_str_empty(entity_path, exit);

    amxd_path_init(&path, entity_path);
    entity_obj_path = amxd_path_get(&path, AMXD_OBJECT_TERMINATE);
    param = amxd_path_get_param(&path);

    bool taken = false;
    amxc_var_for_each(object_var, ret) {
        const char* object_path = amxc_var_key(object_var);
        const amxc_llist_t* param_list = NULL;
        const amxc_llist_t* cmd_list = NULL;
        amxc_var_t* event_table = NULL;

        // If current object is equal to target object or is its child object
        if(strstr(object_path, entity_obj_path)) {
            // If need remove obj, not param.
            if(strstr(object_path, entity_path) && (param == NULL)) {
                // if just remove and not take
                if(do_take && (entity_taken_var == NULL)) {
                    taken = true;
                    amxc_var_take_it(object_var);
                    amxc_var_delete(&object_var);
                    continue;
                }
                entity_var = object_var;
                goto exit;
            }
            // Removing of param.
            if(param[strlen(param) - 1] == ')') {
                cmd_list = amxc_var_constcast(amxc_llist_t, GET_ARG(object_var, "supported_commands"));
                amxc_llist_iterate(it2, cmd_list) {
                    amxc_var_t* cmd_var = amxc_var_from_llist_it(it2);
                    if(strcmp(GET_CHAR(cmd_var, "command_name"), param) == 0) {
                        entity_var = cmd_var;
                        goto exit;
                    }
                }
            }

            if(param[strlen(param) - 1] == '!') {
                event_table = GET_ARG(object_var, "supported_events");
                amxc_var_for_each(event, event_table) {
                    if(strcmp(amxc_var_key(event), param) == 0) {
                        entity_var = event;
                        goto exit;
                    }
                }
            }

            param_list = amxc_var_constcast(amxc_llist_t, GET_ARG(object_var, "supported_params"));
            amxc_llist_iterate(it2, param_list) {
                amxc_var_t* param_var = amxc_var_from_llist_it(it2);
                if(strcmp(GET_CHAR(param_var, "param_name"), param) == 0) {
                    entity_var = param_var;
                    goto exit;
                }
            }
        }
    }

exit:
    if(entity_var != NULL) {
        if(do_take) {
            amxc_var_take_it(entity_var);
        }

        if(entity_taken_var != NULL) {
            *entity_taken_var = entity_var;
        } else {
            amxc_var_delete(&entity_var);
        }

        retval = 0;
    }

    if(taken) {
        retval = 0;
    }
    amxd_path_clean(&path);

    return retval;
}

int dmm_take_entity_by_path(const char* entity_path, amxc_var_t* ret, amxc_var_t** entity_taken_var, bool do_take) {
    int retval = -1;
    amxd_path_t path;
    amxc_string_t search_string;
    amxc_var_t* entity_var = NULL;
    const char* param = NULL;

    amxd_path_init(&path, entity_path);
    param = amxd_path_get_param(&path);

    amxc_string_init(&search_string, 0);

    if(param == NULL) {
        amxc_string_setf(&search_string, "'%s'", amxd_path_get(&path, AMXD_OBJECT_TERMINATE));
    } else {
        amxc_string_setf(&search_string, "'%s'.%s", amxd_path_get(&path, AMXD_OBJECT_TERMINATE), param);
    }

    entity_var = GETP_ARG(ret, amxc_string_get(&search_string, 0));

    if(entity_var != NULL) {
        if(do_take) {
            amxc_var_take_it(entity_var);
        }
        if(entity_taken_var != NULL) {
            *entity_taken_var = entity_var;
        } else {
            amxc_var_delete(&entity_var);
        }
        retval = 0;
    }

    amxc_string_clean(&search_string);

    amxd_path_clean(&path);
    return retval;
}

/**
 * @brief Constructs a supported path template from a concrete path.
 *
 * Replaces all sequences of digits in the input path with the "{i}" placeholder.
 * For example, "Device.WiFi.Radio.1" becomes "Device.WiFi.Radio.{i}".
 *
 * @param[in] indexed_path The concrete path containing numeric indices.
 *
 * @return A dynamically allocated string containing the template path, or NULL on allocation failure.
 */
char* dmm_build_supported_path(const char* indexed_path) {
    char* res = NULL;

    when_null(indexed_path, exit);

    const char* src = indexed_path;
    size_t digit_seqs = 0;

    // Count digit sequences
    // For simplicity, we don't care about path separators here
    // so we count sequence inside something like "WiFi7STARole"
    while(*src) {
        if(isdigit(*src)) {
            digit_seqs++;
            while(isdigit(*src)) {
                src++;
            }
            continue;
        }
        src++;
    }

    // I_PLACEHOLDER_LEN for each digit sequence
    res = malloc((src - indexed_path) + digit_seqs * I_PLACEHOLDER_LEN + 1);
    if(!res) {
        return NULL;
    }

    // Copy path, replacing sequences of digits with placeholder "{i}"
    // Now we shall respect path separators
    src = indexed_path;
    char* dst = res;
    while(*src) {
        // Copy separator and continue to the next element, if any
        if(*src == '.') {
            *dst++ = *src++;
            continue;
        }

        // If an element starts with a digit, it can contain only digits
        if(isdigit(*src)) {
            while(isdigit(*src)) {
                src++;
            }
            memcpy(dst, "{i}", I_PLACEHOLDER_LEN);
            dst += I_PLACEHOLDER_LEN;

            continue;
        }

        // Copy object/parameter name as is
        while(*src && *src != '.') {
            *dst++ = *src++;
        }
    }
    *dst = '\0';

exit:
    return res;
}

/**
 * @brief Appends the "{i}." suffix to a dynamically allocated string.
 *
 * This function reallocates memory for the given string buffer and appends
 * the suffix "{i}." to the end of the string. The caller must pass a pointer
 * to a char pointer so the updated pointer (after realloc) can be returned.
 *
 * @param[in,out] obj_path   Pointer to a dynamically allocated C-string.
 *                           On success, it will be updated to point to the
 *                           resized buffer.
 *
 * @return true  If memory reallocation and append succeeded.
 * @return false If input pointers are invalid or realloc fails.
 */
static bool append_index_suffix(char** obj_path) {
    const char* suffix = "{i}.";
    size_t suffix_len = strlen(suffix);

    if((obj_path == NULL) || (*obj_path == NULL)) {
        return false;
    }

    size_t old_len = strlen(*obj_path);
    size_t new_len = old_len + suffix_len;

    // Allocate more memory (+1 for null terminator)
    char* new_ptr = realloc(*obj_path, new_len + 1);
    if(new_ptr == NULL) {
        return false; // original pointer remains valid
    }

    *obj_path = new_ptr;

    // Append the suffix (including null terminator)
    memcpy(*obj_path + old_len, suffix, suffix_len + 1);

    return true;
}

/**
 * @brief Removes entities from a DM response that match a given path template.
 *
 * Iterates over the objects in ret. If the object path or the object+parameter path
 * matches the given template, the corresponding entity is removed (take + clean) from ret.
 *
 * @param[in] template Path template (e.g., "Object.{i}.Param" or "Object.{i}.").
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 */
void dmm_remove_entity_by_template(const char* template, amxc_var_t* ret) {
    amxd_path_t path;
    amxd_path_init(&path, template);
    const char* param = amxd_path_get_param(&path);

    amxc_var_for_each(var, ret) {
        const char* object_path_i = amxc_var_key(var);
        char* object_path = dmm_build_supported_path(object_path_i);

        amxc_string_t search_string;
        amxc_var_t* entity_var = NULL;

        amxc_string_init(&search_string, 0);

        if(param == NULL) {
            amxc_string_setf(&search_string, "%s", object_path);
        } else {
            amxc_string_setf(&search_string, "%s%s", object_path, param);
        }

        if(strstr(amxc_string_get(&search_string, 0), template)) {

            if(param == NULL) {
                amxc_string_setf(&search_string, "'%s'", object_path_i);
            } else {
                amxc_string_setf(&search_string, "'%s'.%s", object_path_i, param);
            }

            entity_var = GETP_ARG(ret, amxc_string_get(&search_string, 0));

            if(entity_var != NULL) {
                amxc_var_take_it(entity_var);
                amxc_var_delete(&entity_var);
            }
        }
        free(object_path);
        amxc_string_clean(&search_string);
    }

    amxd_path_clean(&path);
}

int dmm_hide_proc(map_info_t* minfo) {
    int retval = -1;

    when_null(minfo, exit);

    amxc_llist_for_each(it, hide_po_list) {
        amxc_var_t* hide_path = amxc_var_from_llist_it(it);
        char* mapped_subpath = dmm_get_mapped_subpath(hide_path);

        if(mapped_subpath == NULL) {
            continue;
        }

        switch(minfo->ds_rq_type) {
        case DMM_GET_SUPPORTED:
            dmm_take_entity_by_path_in_dm_resp(GET_CHAR(hide_path, NULL), &minfo->ret, NULL, true);
            break;

        case DMM_DESCRIBE:
        case DMM_GET:
        case DMM_SET:
        case DMM_ADD:
        case DMM_DEL:
        case DMM_LIST:
        case DMM_EXEC:
        case DMM_GET_INSTANCES:
        case DMM_SUBSCRIBE:
        case DMM_UNSUBSCRIBE:
        case DMM_RQT_UNKNOWN:
            dmm_remove_entity_by_template(GET_CHAR(hide_path, NULL), &minfo->ret);
            break;
        }

        free(mapped_subpath);
    }

    retval = 0;

exit:
    return retval;
}

/**
 * @brief Determines the type of move/rename operation based on the original (orig) and new (rn) path.
 *
 * Analyzes the paths, their depth, and the presence/match of parameters to classify the operation
 * (e.g., object rename, parameter rename, object move with parameter rename, etc.).
 *
 * @param[in] orig Original path string.
 * @param[in] rn New (renamed/moved) path string.
 * @return mv_rn_type enumeration indicating the type of move/rename operation.
 * @retval DMM_RENAME_SAME If the paths are the same.
 * @retval DMM_RN_OBJ Object rename.
 * @retval DMM_RN_PARAM Parameter rename.
 * @retval DMM_RN_OBJ_RN_PARAM Object and parameter rename.
 * @retval DMM_RN_UNKNOWN In case of an unknown or invalid operation.
 */
static mv_rn_type dmm_move_get_type(const char* orig, const char* rn) {
    mv_rn_type retval = DMM_RN_UNKNOWN;
    amxd_path_t orig_path;
    amxd_path_t rn_path;
    const char* orig_param = NULL;
    const char* rn_param = NULL;
    const char* entity_rn_obj_path = NULL;
    const char* entity_orig_obj_path = NULL;
    int orig_depth = -1;
    int rn_depth = -1;
    bool params_exist = false;
    bool params_same = false;
    bool base_path_same = false;

    // If paths same
    if(strcmp(orig, rn) == 0) {
        retval = DMM_RENAME_SAME;
        goto exit;
    }

    if(amxd_path_init(&orig_path, orig) != amxd_status_ok) {
        goto exit;
    }
    orig_param = amxd_path_get_param(&orig_path);
    entity_orig_obj_path = amxd_path_get(&orig_path, AMXD_OBJECT_TERMINATE);
    orig_depth = amxd_path_get_depth(&orig_path);

    if(amxd_path_init(&rn_path, rn) != amxd_status_ok) {
        amxd_path_clean(&rn_path);
        goto exit;
    }
    rn_param = amxd_path_get_param(&rn_path);
    entity_rn_obj_path = amxd_path_get(&rn_path, AMXD_OBJECT_TERMINATE);
    rn_depth = amxd_path_get_depth(&rn_path);

    if((entity_orig_obj_path != NULL) && (entity_rn_obj_path != NULL)) {
        if(strcmp(entity_orig_obj_path, entity_rn_obj_path) == 0) {
            base_path_same = true;
        }
    } else {
        goto exit;
    }

    if(((orig_param != NULL) && (rn_param == NULL)) ||
       ((orig_param == NULL) && (rn_param != NULL))) {
        goto exit;
    } else {
        if((orig_param != NULL) && (rn_param != NULL)) {
            params_exist = true;
            if(strcmp(orig_param, rn_param) == 0) {
                params_same = true;
            }
        }
    }

    if(orig_depth == rn_depth) {
        if(params_exist) {
            if(!params_same) {
                if(base_path_same) {
                    retval = DMM_RN_PARAM;
                } else {
                    retval = DMM_RN_OBJ_RN_PARAM;
                }
            }
        } else {
            retval = DMM_RN_OBJ;
        }
        goto exit;
    }

    // Rename with move to down level
    if(orig_depth < rn_depth) {
        if(params_exist) {
            if(params_same) {
                retval = DMM_RN_DOWN_PARAM;
            } else {
                retval = DMM_RN_DOWN_RN_PARAM;
            }
        } else {
            retval = DMM_RN_DOWN; // This is something weird, like object addion, not being processed.
        }
        goto exit;
    }

    // Rename with move to up level
    if(orig_depth > rn_depth) {
        if(params_exist) {
            if(params_same) {
                retval = DMM_MV_UP_PARAM;
            } else {
                retval = DMM_MV_UP_RN_PARAM;
            }
        } else {
            retval = DMM_MV_UP; // This is something weird, like object deletion, not being processed.
        }
        goto exit;
    }

exit:
    if(entity_orig_obj_path != NULL) {
        amxd_path_clean(&orig_path);
    }
    if(entity_rn_obj_path != NULL) {
        amxd_path_clean(&rn_path);
    }
    return retval;
}

/**
 * @brief Replaces the prefix string `str_orig` in `str_res` with the new string `str_new`.
 *
 * @param[in,out] str_res String where the replacement occurs. Must be of sufficient size (`size`).
 * @param[in] str_orig The prefix to find and replace.
 * @param[in] str_new The new string to replace the prefix with.
 * @param[in] size Maximum size of the `str_res` buffer.
 * @return 0 if the replacement was successful, -1 if `str_orig` is not a prefix of `str_res`.
 */
static int replace_prefix(char* str_res, const char* str_orig, const char* str_new, size_t size) {
    size_t len_orig = strlen(str_orig);

    if(strncmp(str_res, str_orig, len_orig) == 0) {
        char tmp[size];
        snprintf(tmp, sizeof(tmp), "%s", str_res + len_orig);
        snprintf(str_res, size, "%s%s", str_new, tmp);
        return 0;
    }
    return -1;
}

/**
 * @brief Renames an object in the DM response.
 *
 * Takes the object using `orig_path` and re-inserts it with the `new_path` into the response hash table.
 * It also updates all descendant paths starting with `orig_path` by replacing the prefix with `new_path`.
 *
 * @param[in] orig_path Original path to the object.
 * @param[in] new_path New path for the object.
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 * @return 0 on success, -1 on error.
 */
static int dmm_rn_obj(const char* orig_path, const char* new_path, amxc_var_t* ret) {
    int retval = -1;
    amxc_htable_it_t* obj = NULL;

    amxc_htable_t* obj_table = (amxc_htable_t*) amxc_var_constcast(amxc_htable_t, ret);
    obj = amxc_htable_take(obj_table, orig_path);
    if(obj != NULL) {
        retval = amxc_htable_insert(obj_table, new_path, obj);
    }

    amxc_htable_iterate(it, obj_table) {
        const char* object_path = amxc_htable_it_get_key(it);
        char buf[MAX_PATH_LEN];

        strcpy(buf, object_path);

        if(replace_prefix(buf, orig_path, new_path, strlen(buf) + 1) == 0) {
            obj = amxc_htable_take(obj_table, object_path);
            if((obj == NULL) || (amxc_htable_insert(obj_table, buf, obj) == -1)) {
                retval = -1;
                goto exit;
            }
        }
    }

    retval = 0;
exit:

    return retval;
}

/**
 * @brief Renames a parameter in a non-DM response structure.
 *
 * Finds the parameter using `orig` and renames the key in its parent variable from
 * `orig_param` to `rn_param`, while preserving the value (copying).
 * Used for standard (non-DM resp) responses where parameters are represented as keys.
 *
 * @param[in] orig Original path to the parameter.
 * @param[in] rn New path to the parameter (used only to extract the new name).
 * @param[in,out] ret amxc_var_t variable containing the data.
 * @return 0 on success, -1 on error.
 */
static int dmm_rn_param(const char* orig, const char* rn, amxc_var_t* ret) {
    int retval = -1;
    amxc_var_t* param_var = NULL;
    amxd_path_t orig_path;
    amxd_path_t rn_path;
    const char* orig_param = NULL;
    const char* rn_param = NULL;
    const char* entity_rn_obj_path = NULL;
    const char* entity_orig_obj_path = NULL;
    amxc_var_t* parent_param_var = NULL;
    amxc_var_t* taken_param_var = NULL;
    amxc_var_t* new_param_var = NULL;

    if(amxd_path_init(&orig_path, orig) != amxd_status_ok) {
        goto exit;
    }
    orig_param = amxd_path_get_param(&orig_path);
    entity_orig_obj_path = amxd_path_get(&orig_path, AMXD_OBJECT_TERMINATE);

    if(amxd_path_init(&rn_path, rn) != amxd_status_ok) {
        goto exit;
    }
    rn_param = amxd_path_get_param(&rn_path);
    entity_rn_obj_path = amxd_path_get(&rn_path, AMXD_OBJECT_TERMINATE);

    dmm_take_entity_by_path(orig, ret, &param_var, false);

    when_null(param_var, exit);

    parent_param_var = amxc_var_get_parent(param_var);
    taken_param_var = amxc_var_take_key(parent_param_var, orig_param);

    new_param_var = amxc_var_add_new_key(parent_param_var, rn_param);
    when_null(new_param_var, exit);

    if(amxc_var_copy(new_param_var, param_var) != 0) {
        goto exit;
    }

    retval = 0;

exit:
    if(entity_orig_obj_path != NULL) {
        amxd_path_clean(&orig_path);
    }
    if(entity_rn_obj_path != NULL) {
        amxd_path_clean(&rn_path);
    }
    if(taken_param_var != NULL) {
        amxc_var_delete(&taken_param_var);
    }
    return retval;
}

/**
 * @brief Renames a parameter, command, or event within a DM response.
 *
 * Finds the entity (parameter/command/event) and updates its internal name field
 * (`param_name` or `command_name`) to the new name. For events, the key in the parent
 * `supported_events` hash table is renamed.
 *
 * @param[in] orig Original path to the entity.
 * @param[in] rn New path to the entity (used to extract the new name).
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 * @return 0 on success, -1 on error.
 */
static int dmm_rn_param_dm_resp(const char* orig, const char* rn, amxc_var_t* ret) {
    int retval = -1;
    amxc_var_t* param_var = NULL;
    amxc_var_t* param_name_var = NULL;
    amxd_path_t orig_path;
    amxd_path_t rn_path;
    const char* orig_param = NULL;
    const char* rn_param = NULL;
    const char* entity_rn_obj_path = NULL;
    const char* entity_orig_obj_path = NULL;


    if(amxd_path_init(&orig_path, orig) != amxd_status_ok) {
        goto exit;
    }
    orig_param = amxd_path_get_param(&orig_path);
    entity_orig_obj_path = amxd_path_get(&orig_path, AMXD_OBJECT_TERMINATE);

    if(amxd_path_init(&rn_path, rn) != amxd_status_ok) {
        goto exit;
    }
    rn_param = amxd_path_get_param(&rn_path);
    entity_rn_obj_path = amxd_path_get(&rn_path, AMXD_OBJECT_TERMINATE);

    dmm_take_entity_by_path_in_dm_resp(orig, ret, &param_var, false);

    if(orig_param[strlen(orig_param) - 1] == ')') {
        param_name_var = amxc_var_take_key(param_var, "command_name");
        amxc_var_add_key(cstring_t, param_var, "command_name", rn_param);
        goto exit;
    }

    if(orig_param[strlen(orig_param) - 1] == '!') {
        amxc_var_t* event_table = amxc_var_get_parent(param_var);
        amxc_var_t* event_param_list = amxc_var_take_key(event_table, orig_param);
        amxc_var_add_key(amxc_llist_t, event_table, rn_param, amxc_var_constcast(amxc_llist_t, param_var));
        if(event_param_list != NULL) {
            amxc_var_clean(event_param_list);
        }
        goto exit;
    }

    param_name_var = amxc_var_take_key(param_var, "param_name");
    amxc_var_add_key(cstring_t, param_var, "param_name", rn_param);

    retval = 0;
exit:
    if(entity_orig_obj_path != NULL) {
        amxd_path_clean(&orig_path);
    }
    if(entity_rn_obj_path != NULL) {
        amxd_path_clean(&rn_path);
    }
    if(param_name_var != NULL) {
        amxc_var_delete(&param_name_var);
    }
    return retval;
}

/**
 * @brief Executes object and parameter/entity renaming within a DM response.
 *
 * First renames the parameter/command/event (`dmm_rn_param_dm_resp`),
 * and then renames the object itself (`dmm_rn_obj`).
 *
 * @param[in] orig Original full entity path (object.parameter).
 * @param[in] rn New full entity path.
 * @param[in,out] ret amxc_var_t variable containing the DM response.
 * @return 0 on success, -1 on error.
 */
static int dmm_rn_obj_rn_param_dm_resp(const char* orig, const char* rn, amxc_var_t* ret) {
    int retval = -1;
    amxd_path_t orig_path;
    amxd_path_t rn_path;
    const char* rn_obj_path = NULL;
    const char* orig_obj_path = NULL;

    if(dmm_rn_param_dm_resp(orig, rn, ret) != 0) {
        goto exit;
    }

    if(amxd_path_init(&orig_path, orig) != amxd_status_ok) {
        goto exit;
    }

    orig_obj_path = amxd_path_get(&orig_path, AMXD_OBJECT_TERMINATE);

    if(amxd_path_init(&rn_path, rn) != amxd_status_ok) {
        goto exit;
    }

    rn_obj_path = amxd_path_get(&rn_path, AMXD_OBJECT_TERMINATE);
    retval = dmm_rn_obj(orig_obj_path, rn_obj_path, ret);

exit:
    if(orig_obj_path != NULL) {
        amxd_path_clean(&orig_path);
    }
    if(rn_obj_path != NULL) {
        amxd_path_clean(&rn_path);
    }
    return retval;
}

/**
 * @brief Executes object and parameter renaming for a non-DM response structure.
 *
 * First renames the parameter (`dmm_rn_param`), and then renames the object (`dmm_rn_obj`).
 *
 * @param[in] orig Original full entity path (object.parameter).
 * @param[in] rn New full entity path.
 * @param[in,out] ret amxc_var_t variable containing the data.
 * @return 0 on success, -1 on error.
 */
static int dmm_rn_obj_rn_param(const char* orig, const char* rn, amxc_var_t* ret) {
    int retval = -1;
    amxd_path_t orig_path;
    amxd_path_t rn_path;
    const char* rn_obj_path = NULL;
    const char* orig_obj_path = NULL;

    if(dmm_rn_param(orig, rn, ret) != 0) {
        goto exit;
    }

    if(amxd_path_init(&orig_path, orig) != amxd_status_ok) {
        goto exit;
    }

    orig_obj_path = amxd_path_get(&orig_path, AMXD_OBJECT_TERMINATE);

    if(amxd_path_init(&rn_path, rn) != amxd_status_ok) {
        goto exit;
    }

    rn_obj_path = amxd_path_get(&rn_path, AMXD_OBJECT_TERMINATE);
    retval = dmm_rn_obj(orig_obj_path, rn_obj_path, ret);

exit:
    if(orig_obj_path != NULL) {
        amxd_path_clean(&orig_path);
    }
    if(rn_obj_path != NULL) {
        amxd_path_clean(&rn_path);
    }
    return retval;
}

int dmm_move_entity_by_path(const char* orig_template, const char* rn_template, amxc_var_t* ret) {
    int retval = -1;
    mv_rn_type type = dmm_move_get_type(orig_template, rn_template);

    amxd_path_t path;
    amxd_path_init(&path, orig_template);
    const char* param = amxd_path_get_param(&path);

    const amxc_htable_t* obj_table = amxc_var_constcast(amxc_htable_t, ret);
    amxc_htable_iterate(it, obj_table) {
        const char* object_path_i = amxc_htable_it_get_key(it);
        char* object_path = dmm_build_supported_path(amxc_htable_it_get_key(it));

        amxc_string_t search_string;
        amxc_string_init(&search_string, 0);

        if(param == NULL) {
            amxc_string_setf(&search_string, "%s", object_path);
        } else {
            amxc_string_setf(&search_string, "%s%s", object_path, param);
        }
        free(object_path);

        if(strcmp(amxc_string_get(&search_string, 0), orig_template) == 0) {

            char rn_path_sub_i[MAX_PATH_LEN];
            strcpy(rn_path_sub_i, rn_template);

            if(param == NULL) {
                amxc_string_setf(&search_string, "%s", object_path_i);
            } else {
                amxc_string_setf(&search_string, "%s%s", object_path_i, param);
            }

            if(dmm_indexes_replace(rn_path_sub_i, MAX_PATH_LEN, amxc_string_get(&search_string, 0)) != NULL) {
                switch(type) {
                case DMM_RN_PARAM:
                    retval = dmm_rn_param(amxc_string_get(&search_string, 0), rn_path_sub_i, ret);
                    break;

                case DMM_RN_OBJ:
                    retval = dmm_rn_obj(amxc_string_get(&search_string, 0), rn_path_sub_i, ret);
                    break;

                case DMM_RN_OBJ_RN_PARAM:
                    retval = dmm_rn_obj_rn_param(amxc_string_get(&search_string, 0), rn_path_sub_i, ret);
                    break;

                case DMM_RN_DOWN_PARAM:
                case DMM_RN_DOWN_RN_PARAM:
                case DMM_MV_UP_PARAM:
                case DMM_MV_UP_RN_PARAM:
                case DMM_RENAME_SAME:
                case DMM_RN_DOWN:
                case DMM_MV_UP:
                case DMM_RN_UNKNOWN:
                    break;
                }
            }
        }

        amxc_string_clean(&search_string);
    }

    amxd_path_clean(&path);
    return retval;
}

int dmm_move_entity_by_path_in_dm_resp(const char* orig_path, const char* rn_path, amxc_var_t* ret) {
    int retval = -1;
    mv_rn_type type = dmm_move_get_type(orig_path, rn_path);

    switch(type) {
    case DMM_RN_PARAM:
        retval = dmm_rn_param_dm_resp(orig_path, rn_path, ret);
        break;

    case DMM_RN_OBJ:
        retval = dmm_rn_obj(orig_path, rn_path, ret);
        break;

    case DMM_RN_OBJ_RN_PARAM:
        retval = dmm_rn_obj_rn_param_dm_resp(orig_path, rn_path, ret);
        break;

    case DMM_RN_DOWN_PARAM:
    case DMM_RN_DOWN_RN_PARAM:
    case DMM_MV_UP_PARAM:
    case DMM_MV_UP_RN_PARAM:
    case DMM_RENAME_SAME:
    case DMM_RN_DOWN:
    case DMM_MV_UP:
    case DMM_RN_UNKNOWN:
        goto exit;
        break;
    }

exit:

    return retval;
}

int dmm_rename_proc(map_info_t* minfo) {
    int retval = -1;

    when_null(minfo, exit);

    amxc_var_t* ret = &minfo->ret;

    const amxc_htable_t* rn_table = amxc_var_constcast(amxc_htable_t, rename_po);
    amxc_htable_iterate(it, rn_table) {
        amxc_var_t* rn_path_var = amxc_var_from_htable_it(it);
        const char* rn_path = GET_CHAR(rn_path_var, NULL);
        const char* orig_path = amxc_htable_it_get_key(it);
        char* mapped_subpath = dmm_get_mapped_subpath(rn_path_var);

        if(mapped_subpath == NULL) {
            continue;
        }

        switch(minfo->ds_rq_type) {
        case DMM_GET_SUPPORTED:
            dmm_move_entity_by_path_in_dm_resp(orig_path, rn_path, ret);
            break;

        case DMM_DESCRIBE:

        case DMM_GET:
        case DMM_SET:
        case DMM_ADD:
        case DMM_DEL:
        case DMM_LIST:
        case DMM_EXEC:
        case DMM_GET_INSTANCES:
        case DMM_SUBSCRIBE:
        case DMM_UNSUBSCRIBE:
        case DMM_RQT_UNKNOWN:
            dmm_move_entity_by_path(orig_path, rn_path, ret);
            break;
        }
        free(mapped_subpath);
    }

    retval = 0;

exit:
    return retval;
}

/**
 * @brief Checks if terminal is valid (not original name, not hidden), and renames if necessary.
 *
 * @param[in] fwd Forward tree node of the parent object.
 * @param[in] bwd Backward tree node of the parent object.
 * @param[in] terminal The terminal to check.
 * @param[in] translator translator function to use
 *
 * @return PathAction indicating the result of the revert rename operation.
 *         If action==rename, the `rename_to` field contains the new name.
 *         If action==hide, it means the terminal is invalid!
 */
static PathAction dmm_revert_rename_and_check(const TreeNode* fwd, const TreeNode* bwd, const char* terminal, dmm_translator_f translator) {
    PathAction action = translator(fwd, terminal);

    // Check if need to rename
    if(action.action == RenamePathAction) {
        // No need to check for validity
        return action;
    }

    // Check if uses original name or is hidden
    clean_path_action(&action);
    action = translator(bwd, terminal);
    if(action.action != NoActionPathAction) {
        action.action = HidePathAction; // Signals invalid
        return action;
    }

    return action;
}

/**
 * @brief Checks if terminal is valid (not original name, not hidden), and renames if necessary.
 *
 * @param[in] fwd Forward tree node of the parent object.
 * @param[in] bwd Backward tree node of the parent object.
 * @param[in] terminal The terminal to check.
 *
 * @return PathAction indicating the result of the revert rename operation.
 *         If action==rename, the `rename_to` field contains the new name.
 *         If action==hide, it means the terminal is invalid!
 */
static PathAction dmm_revert_rename_and_check_terminal(const TreeNode* fwd, const TreeNode* bwd, const char* terminal) {
    return dmm_revert_rename_and_check(fwd, bwd, terminal, translate_terminal_name);
}

/**
 * @brief Checks if terminal is valid (not original name, not hidden), and renames if necessary.
 *
 * @param[in] fwd Forward tree node of the parent object.
 * @param[in] bwd Backward tree node of the parent object.
 * @param[in] terminal The terminal to check.
 *
 * @return PathAction indicating the result of the revert rename operation.
 *         If action==rename, the `rename_to` field contains the new name.
 *         If action==hide, it means the terminal is invalid!
 */
static PathAction dmm_revert_rename_and_check_function(const TreeNode* fwd, const TreeNode* bwd, const char* terminal) {
    return dmm_revert_rename_and_check(fwd, bwd, terminal, translate_rpc_name);
}

/**
 * @brief Translate parameter map in set/add request
 *
 * @param[in,out] parameters parameters to translate
 * @param optional whether the parameters are optional
 * @param forward_node forward node of the nonterminal path
 * @param backward_node backward node of the nonterminal path
 *
 * @return amxd_status_ok if no error happened
 */
static amxd_status_t dmm_translate_set_parametes_map(amxc_var_t* parameters, bool optional, const TreeNode* forward_node, const TreeNode* backward_node) {
    amxd_status_t retval = amxd_status_ok;

    when_null(parameters, exit);

    amxc_var_for_each(param_var, parameters) {
        const char* param = amxc_var_key(param_var);
        PathAction action = dmm_revert_rename_and_check_terminal(forward_node, backward_node, param);

        if(action.action == HidePathAction) { // Invalid
            if(optional) {
                amxc_var_delete(&param_var);
                goto next_loop_iteration;
            }
            clean_path_action(&action);
            retval = amxd_status_parameter_not_found;
            goto exit;
        }

        if(action.action == RenamePathAction) { // Renamed
            const char* new_name = amxc_string_get(&action.rename_to, 0);
            amxc_var_t* new_param_var = amxc_var_add_new_key(parameters, new_name);
            when_null_status(new_param_var, exit, retval = amxd_status_out_of_mem);
            if(amxc_var_copy(new_param_var, param_var) != 0) {
                amxc_var_delete(&new_param_var);
                if(optional) {
                    goto next_loop_iteration;
                }
                retval = amxd_status_out_of_mem;
                goto exit;
            }
            amxc_var_delete(&param_var);
        }

next_loop_iteration:
        clean_path_action(&action);
    }

exit:
    return retval;
}

/**
 * @brief Translate exec's method
 *
 * @param[in,out] method RPC to call
 * @param forward_node forward node of the nonterminal path
 * @param backward_node backward node of the nonterminal path
 *
 * @return amxd_status_ok if no error happened
 */
static amxd_status_t dmm_translate_exec_method(amxc_var_t* method, const TreeNode* forward_node, const TreeNode* backward_node) {
    amxd_status_t retval = amxd_status_ok;

    when_null(method, exit);

    const char* method_cstr = amxc_var_constcast(cstring_t, method);
    when_null(method_cstr, exit);

    const char* prohibited_method[] = {"_get", "_set", "_add", "_del", "_get_supported", "_get_instances", "_describe", "_list", "_subscribe", "_exec"};
    for(int i = 0; i != sizeof(prohibited_method) / sizeof(prohibited_method[0]); ++i) {
        if(!strcmp(method_cstr, prohibited_method[i])) {
            SAH_TRACEZ_WARNING(ME, "Cannot call prohibited method '%s'", method_cstr);
            retval = amxd_status_function_not_found;
            goto exit;
        }
    }

    PathAction action = dmm_revert_rename_and_check_function(forward_node, backward_node, method_cstr);

    switch(action.action) {
    case HidePathAction:
        retval = amxd_status_function_not_found;
        break;
    case RenamePathAction:
        if(amxc_var_set(cstring_t, method, amxc_string_get(&action.rename_to, 0))) {
            retval = amxd_status_out_of_mem;
        }
        break;
    case NoActionPathAction:
        break;
    }

    clean_path_action(&action);

exit:
    return retval;
}

amxd_status_t dmm_revert_rename_proc(amxc_var_t* args, const amxd_object_t* object, const TreeNode** backward_node) {
    amxd_status_t retval = amxd_status_unknown_error;

    char* object_path = amxd_object_get_path(object, AMXD_OBJECT_TERMINATE);
    amxc_var_t* rel_path_var = GET_ARG(args, "rel_path");
    const char* rel_path = GET_CHAR(rel_path_var, NULL);

    if((object_path == NULL) || (rel_path == NULL)) { // Impossible, but just in case
        SAH_TRACEZ_ERROR(ME, "Object name or rel_path is somehow NULL");
        goto object_path_exit;
    }

    amxc_string_t path_str;
    amxc_string_init(&path_str, 0);
    // tr181-device (or dm-proxy)
    // can send us rel_path consisting of (starting with?) "."
    // so we need to skip it
    amxc_string_setf(&path_str, "%s%s", object_path, rel_path + (*rel_path == '.'));

    int len = amxc_string_text_length(&path_str);
    char* path = amxc_string_take_buffer(&path_str);

    SAH_TRACEZ_INFO(ME, "%s", path);

    // On GET, we may have the parameter directly in rel_path
    // e.g. "Root.Object.Param"
    bool termnal_in_rel_path = path[len - 1] != '.';
    char* terminal_start = path + len;
    char terminal_first_char = '\0';
    if(termnal_in_rel_path) {
        // In this case, we need to find the start of the terminal
        // and terminate the path at it (e.g. would become "Root.Object.")
        // so that we could translate the nonterminal part first
        while(terminal_start[-1] != '.') {
            terminal_start--;
        }
        SAH_TRACEZ_INFO(ME, "Terminal in rel_path: %s", terminal_start);

        terminal_first_char = *terminal_start;
        *terminal_start = '\0';
    }

    TranslateReqResult res = translate_nonterminal_request_path(&forward_tree, &backward_tree, path);
    if((retval = res.status) != amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "translate_nonterminal_request_path failed with %d", res.status);
        goto exit;
    }
    *backward_node = res.bwd_node;

    *terminal_start = terminal_first_char; // OK even when termnal_in_rel_path is false

    // Nothing to rename/check
    if(!res.fwd_node && !res.bwd_node) {
        // Restore the original terminal (if any)
        amxc_string_append(&res.translated, terminal_start, strlen(terminal_start));

        goto skip_terminal_renames;
    }

    // Check/translate the rel_path's terminal
    if(termnal_in_rel_path) {
        PathAction action = dmm_revert_rename_and_check_terminal(res.fwd_node, res.bwd_node, terminal_start);

        if(action.action == HidePathAction) { // Invalid
            clean_path_action(&action);
            retval = amxd_status_parameter_not_found;
            goto exit;
        }

        if(action.action == RenamePathAction) { // Renamed
            const char* new_name = amxc_string_get(&action.rename_to, 0);
            amxc_string_append(&res.translated, new_name, strlen(new_name));
        } else {
            // Restore the original terminal
            amxc_string_append(&res.translated, terminal_start, strlen(terminal_start));
        }

        clean_path_action(&action);
    }

    // Check/translate the parameters (in SET)
    if((retval = dmm_translate_set_parametes_map(GET_ARG(args, "parameters"), false, res.fwd_node, res.bwd_node)) != amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Failed to translate mandatory parameters in request");
        goto exit;
    }
    if(dmm_translate_set_parametes_map(GET_ARG(args, "oparameters"), true, res.fwd_node, res.bwd_node) != amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Failed to translate optional parameters in request");
    }

    if((retval = dmm_translate_exec_method(GET_ARG(args, "method"), res.fwd_node, res.bwd_node)) != amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Failed to translate _exec method in request");
        goto exit;
    }

skip_terminal_renames:
    amxc_var_set(cstring_t, rel_path_var, amxc_string_get(&res.translated, strlen(object_path)));
    retval = amxd_status_ok;

exit:
    amxc_string_clean(&path_str);
    free(path);
    clean_translate_req_result(&res);

object_path_exit:
    free(object_path);
    return retval;
}

/**
 * @brief Main procedure for processing hide and rename operations in a response.
 *
 * Calls `dmm_hide_proc` first to remove hidden entities, and then
 * `dmm_rename_proc` to apply rename/move operations to the response.
 *
 * @param[in,out] minfo Structure with mapping information, containing the response (`minfo->ret`).
 * @return 0 on success, -1 on error.
 */
static int dmm_hide_rename_proc(map_info_t* minfo) {
    int retval = -1;

    switch(minfo->ds_rq_type) {
    case DMM_GET_SUPPORTED:
        retval = translate_get_supported_response(&minfo->ret);
        break;
    case DMM_GET:
        retval = translate_get_response(&minfo->ret);
        break;
    case DMM_SET:
        retval = translate_set_response(&minfo->ret);
        break;
    case DMM_ADD:
        retval = translate_add_response(&minfo->ret);
        break;
    case DMM_DEL:
        retval = translate_del_response(&minfo->ret);
        break;
    case DMM_GET_INSTANCES:
        retval = translate_get_instances_response(&minfo->ret);
        break;
    case DMM_LIST:
        retval = translate_list_response(minfo->backward_node, &minfo->ret);
        break;
    case DMM_DESCRIBE:
        retval = translate_describe_response(&minfo->ret);
        break;
    default:
        SAH_TRACEZ_INFO(ME, "Calling OLD translate handlers");
        dmm_hide_proc(minfo);
        dmm_rename_proc(minfo);
        retval = 0;
    }

    return retval;
}

/**
 * @brief Finds an object in the data model hierarchy based on a relative path.
 *
 * Traverses the object tree starting from @p object using the components of @p rel_path.
 * Updates @p rel_path to reflect the remaining part of the path if a partial match occurs.
 *
 * @param[in]     object   The starting object.
 * @param[in,out] rel_path Variant containing the relative path string. Updated during traversal.
 *
 * @return The found object, or the last matching object in the path.
 */
static amxd_object_t* dmm_find_object(amxd_object_t* object, amxc_var_t* rel_path) {
    amxd_path_t path;
    amxc_string_t full_path;
    char* path_part = NULL;
    amxd_object_t* tmp = NULL;

    amxc_string_init(&full_path, 0);
    amxd_path_init(&path, GET_CHAR(rel_path, NULL));
    do {
        path_part = amxd_path_get_first(&path, true);
        tmp = amxd_object_findf(object, "%s", path_part);
        if(tmp != NULL) {
            object = tmp;
        } else {
            amxd_path_prepend(&path, path_part);
        }
        free(path_part);
    } while(tmp != NULL);

    amxc_string_setf(&full_path, "%s%s",
                     amxd_path_get(&path, AMXD_OBJECT_TERMINATE),
                     amxd_path_get_param(&path) == NULL? "":amxd_path_get_param(&path));
    amxc_var_set(cstring_t, rel_path, amxc_string_get(&full_path, 0));

    amxc_string_clean(&full_path);
    amxd_path_clean(&path);
    return object;
}


/**
 * @brief Translates paths in a proxy reply (key-based).
 *
 * Converts keys in the @p orig_ret variant (which are paths from the backend)
 * to mapped paths in the @p proxy_ret variant.
 *
 * @param[in]  minfo     Mapping information.
 * @param[out] proxy_ret The destination variant for the translated reply.
 * @param[in]  orig_ret  The original reply from the backend.
 */
static void dmm_reply_transl_path(map_info_t* minfo,
                                  amxc_var_t* orig_ret) {
    amxc_var_t* proxy_ret = &minfo->ret;
    amxc_var_t* orig = GETI_ARG(orig_ret, 0);
    amxc_string_t mapping_path;
    const char* real_obj = dmm_get_translate_path(minfo->map_obj);

    amxc_var_set_type(proxy_ret, amxc_var_type_of(orig));

    amxc_string_init(&mapping_path, 256);

    amxc_var_for_each(reply_item, orig) {
        const char* key = amxc_var_key(reply_item);
        const char* proxy_key = NULL;
        char* stripped = dmm_strip_mapped(real_obj, key);

        amxc_string_setf(&mapping_path, "%s%s", minfo->map_obj, stripped);
        free(stripped);

        proxy_key = amxc_string_get(&mapping_path, 0);
        amxc_var_set_key(proxy_ret, proxy_key, reply_item, AMXC_VAR_FLAG_DEFAULT);
    }

    amxc_string_clean(&mapping_path);
}

/**
 * @brief Translate data output of the prplMesh component that is stored in
 * first item in the list.
 *
 * @param minfo structure containing mapping information.
 * @param data variant that contains result of the operation on prplMesh component.
 */
static void dmm_reply_transl_data_list(map_info_t* minfo,
                                       amxc_var_t* orig_ret) {
    dmm_reply_transl_data(minfo, GETI_ARG(orig_ret, 0));
}

/**
 * @brief Translates a list of paths in a proxy reply.
 *
 * Iterates over a list of paths in @p orig_ret, strips the mapped part,
 * and adds the translated path to @p proxy_ret.
 *
 * @param[in]  minfo     Mapping information.
 * @param[out] proxy_ret The destination variant for the translated list.
 * @param[in]  orig_ret  The original reply containing a list of paths.
 */
static void dmm_reply_transl_list(map_info_t* minfo,
                                  amxc_var_t* proxy_ret,
                                  amxc_var_t* orig_ret) {
    amxc_var_t* orig = GETI_ARG(orig_ret, 0);
    amxc_string_t mapping_path;
    const char* real_obj = dmm_get_translate_path(minfo->map_obj);

    amxc_var_set_type(proxy_ret, amxc_var_type_of(orig));

    amxc_string_init(&mapping_path, 256);

    amxc_var_for_each(reply_item, orig) {
        const char* item = amxc_var_constcast(cstring_t, reply_item);
        const char* proxy_item = NULL;
        char* stripped = dmm_strip_mapped(real_obj, item);

        amxc_string_setf(&mapping_path, "%s%s", minfo->map_obj, stripped);
        free(stripped);

        proxy_item = amxc_string_get(&mapping_path, 0);
        amxc_var_add(cstring_t, proxy_ret, proxy_item);
    }

    amxc_string_clean(&mapping_path);
}

/**
 * @brief Callback for RPC completion that requires list translation.
 *
 * Handles the response of an RPC call, translates the resulting list of paths,
 * and completes the deferred function call.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_done_transl_list(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                     UNUSED amxb_request_t* request,
                                     int status,
                                     void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    dmm_reply_transl_list(minfo, &minfo->ret, request->result);

    dmm_hide_rename_proc(minfo);

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);
    SAH_TRACEZ_LOG_VARIANT(&minfo->ret);
    amxd_function_deferred_call_done(minfo->call_id, status, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Callback for RPC completion that requires path translation.
 *
 * Handles the response, translates paths (keys), performs hiding/renaming processing,
 * and completes the deferred function call.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_done_transl_path(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                     UNUSED amxb_request_t* request,
                                     int status,
                                     void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    dmm_reply_transl_path(minfo, request->result);
    dmm_hide_rename_proc(minfo);
    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);
    SAH_TRACEZ_LOG_VARIANT(&minfo->ret);
    amxd_function_deferred_call_done(minfo->call_id, status, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Callback for RPC completion that requires data translation.
 *
 * Translates the data content, processes hidden/renamed entities, merges objects,
 * and completes the deferred function call.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_done_transl_data(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                     UNUSED amxb_request_t* request,
                                     int status,
                                     void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    amxc_var_t* ret = GETI_ARG(minfo->request->result, 0);
    amxc_var_t* local_objs = GET_ARG(&minfo->ret, "objects");
    amxc_var_t* remote_objs = GET_ARG(ret, "objects");

    dmm_reply_transl_data(minfo, ret);

    dmm_hide_rename_proc(minfo);

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);
    amxc_var_for_each(obj, local_objs) {
        amxc_var_set_index(remote_objs, -1, obj, AMXC_VAR_FLAG_DEFAULT);
    }
    SAH_TRACEZ_LOG_VARIANT(ret);
    amxd_function_deferred_call_done(minfo->call_id, status, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Callback for RPC completion handling multiple data results.
 *
 * Iterates through a list of results (if applicable), translates the data,
 * and completes the deferred function call.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_done_transl_data_multiple(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                              UNUSED amxb_request_t* request,
                                              int status,
                                              void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    amxc_var_t* ret = GETI_ARG(minfo->request->result, 0);

    if(amxc_var_type_of(ret) == AMXC_VAR_ID_LIST) {
        amxc_var_for_each(entry, ret) {
            dmm_reply_transl_data(minfo, entry);
        }
    } else {
        dmm_reply_transl_data(minfo, ret);
    }

    dmm_hide_rename_proc(minfo);

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);
    SAH_TRACEZ_LOG_VARIANT(&minfo->ret);
    amxd_function_deferred_call_done(minfo->call_id, status, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Generic callback for RPC completion.
 *
 * Simply forwards the result and output arguments to the deferred function call handler.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_done(UNUSED const amxb_bus_ctx_t* bus_ctx,
                         UNUSED amxb_request_t* request,
                         int status,
                         void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    amxc_var_t* ret = GETI_ARG(minfo->request->result, 0);
    amxc_var_t* out_args = GETI_ARG(minfo->request->result, 1);

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);
    SAH_TRACEZ_LOG_VARIANT(ret);
    SAH_TRACEZ_LOG_VARIANT(out_args);
    amxd_function_deferred_call_done(minfo->call_id, status, out_args, ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Callback for List RPC completion.
 *
 * Enhances the list result with local child objects (from the proxy),
 * then calls the generic @ref dmm_rpc_done.
 *
 * @param[in] bus_ctx The bus context.
 * @param[in] request The RPC request structure.
 * @param[in] status  The status of the RPC call.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_list_done(const amxb_bus_ctx_t* bus_ctx,
                              amxb_request_t* request,
                              int status,
                              void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    amxc_var_t* objects = GETP_ARG(minfo->request->result, "0.objects");

    if(objects != NULL) {
        amxd_object_t* obj = amxd_dm_findf(dmm_get_dm(), "%s", minfo->map_obj);
        amxd_object_for_each(child, it, obj) {
            amxd_object_t* child_obj = amxc_container_of(it, amxd_object_t, it);
            amxc_var_add(cstring_t, objects, amxd_object_get_name(child_obj, 0));
        }
    }

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", status);

    amxc_var_t* orig = GETI_ARG(minfo->request->result, 0);
    amxc_var_move(&minfo->ret, orig);

    dmm_hide_rename_proc(minfo);
    SAH_TRACEZ_LOG_VARIANT(&minfo->ret);
    amxd_function_deferred_call_done(minfo->call_id, status, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Callback for cancelling an RPC request.
 *
 * cleans up the mapping info when a deferred call is cancelled.
 *
 * @param[in] call_id The ID of the call being cancelled.
 * @param[in] priv    Private data (map_info_t pointer).
 */
static void dmm_rpc_cancel(UNUSED uint64_t call_id, void* const priv) {
    map_info_t* minfo = (map_info_t*) priv;
    SAH_TRACEZ_NOTICE(ME, "Forwarded canceled - call id= %d", (uint32_t) call_id);

    dmm_delete_info(&minfo);
}

/**
 * @brief Sets the relative path in the arguments variant.
 *
 * Extracts the remaining relative path and optional parameter from the
 * path structure and updates the "rel_path" key in @p rel_path_var.
 *
 * @param[in]     path          The path structure.
 * @param[in,out] rel_path_var  The variant to update with the string representation.
 */
static void dmm_set_rel_path(amxd_path_t* path, amxc_var_t* rel_path_var) {
    amxc_string_t rel_path;
    amxc_string_init(&rel_path, 0);

    if((amxd_path_get(path, 0) != NULL) && (amxd_path_get(path, 0)[0] != 0)) {
        if(amxd_path_get_param(path) != 0) {
            amxc_string_setf(&rel_path, "%s%s", amxd_path_get(path, AMXD_OBJECT_TERMINATE), amxd_path_get_param(path));
            amxc_var_set(cstring_t, rel_path_var, amxc_string_get(&rel_path, 0));
        } else {
            amxc_var_set(cstring_t, rel_path_var, amxd_path_get(path, AMXD_OBJECT_TERMINATE));
        }
    } else {
        if(amxd_path_get_param(path) != 0) {
            amxc_var_set(cstring_t, rel_path_var, amxd_path_get_param(path));
        } else {
            amxc_var_delete(&rel_path_var);
        }
    }

    amxc_string_clean(&rel_path);
}

/**
 * @brief Forward RPC call to the prplMesh comoponent
 *
 * @param minfo minfo used for request
 * @param object object for the request
 * @param func function to call
 * @param args arguments for the function
 * @param done_fn callback when request is done
 *
 * @return amxd_status_deferred when OK
 */
static amxd_status_t dmm_rpc_forward(map_info_t* minfo,
                                     amxd_object_t* object,
                                     amxd_function_t* func,
                                     amxc_var_t* args,
                                     amxb_be_done_cb_fn_t done_fn,
                                     bool defer) {
    amxd_status_t retval = amxd_status_object_not_found;
    char* object_path = amxd_object_get_path(object, AMXD_OBJECT_TERMINATE | AMXD_OBJECT_INDEXED);
    amxc_var_t* rel_path_var = GET_ARG(args, "rel_path");
    const char* fname = amxd_function_get_name(func);
    const char* pobj = NULL;
    char* robj = NULL;
    amxb_bus_ctx_t* bus_ctx = NULL;
    amxd_path_t path;

    SAH_TRACEZ_IN(ME);
    amxd_path_init(&path, NULL);

    amxd_path_setf(&path, false, "%s%s", object_path, rel_path_var == NULL? "":GET_CHAR(rel_path_var, NULL));
    pobj = dmm_get_real_path(&path);
    when_null(pobj, exit);
    robj = amxd_path_get_fixed_part(&path, true);
    bus_ctx = dmm_get_connection(robj);
    if(rel_path_var == NULL) {
        rel_path_var = amxc_var_add_key(cstring_t, args, "rel_path", "");
    }
    dmm_set_rel_path(&path, rel_path_var);

    if(!bus_ctx) {
        retval = amxd_status_object_not_found;
        SAH_TRACEZ_ERROR(ME, "No bus ctx found for [%s]", robj);
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Forwarding request on bus ctx [%p] - %s", (void*) bus_ctx, bus_ctx->bus_fn->name);

    minfo->map_obj = pobj;

    SAH_TRACEZ_INFO(ME, "Forwarding - origin object = [%s], remote object = [%s], function = [%s]", object_path, robj, fname);

    if(defer && done_fn) {
        amxc_var_t copy_args;
        amxc_var_init(&copy_args);
        amxc_var_copy(&copy_args, args);
        SAH_TRACEZ_LOG_VARIANT(&copy_args);

        minfo->request = amxb_async_call(bus_ctx, robj, fname, &copy_args, done_fn, minfo);
        amxc_var_clean(&copy_args);
        if(minfo->request == NULL) {
            SAH_TRACEZ_ERROR(ME, "Forwarding failed - return error %d", amxd_status_object_not_found);
            retval = amxd_status_object_not_found;
            goto exit;
        }
        retval = amxd_status_deferred;
    } else {
        retval = amxb_call(bus_ctx, robj, fname, args, &minfo->ret, AMXB_BUS_TIMEOUT);
    }


exit:
    free(object_path);
    free(robj);
    amxd_path_clean(&path);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
 * @brief Verify that all requests proccessed for child nodes.
 *
 *
 * @param[in] bus_ctx unused parameter
 * @param[in] request unused parameter
 * @param[in] status resulting status for request
 * @param[in] priv additional request info like map_info_t struct
 */
static void dmm_child_request_done(UNUSED const amxb_bus_ctx_t* bus_ctx,
                                   UNUSED amxb_request_t* request,
                                   int status,
                                   void* priv) {
    map_info_t* minfo = (map_info_t*) priv;
    map_info_t* main_req = amxc_container_of(minfo->it.llist, map_info_t, child_requests);

    SAH_TRACEZ_INFO(ME, "Forwarded child request done for call id = %d", (uint32_t) main_req->call_id);

    if(main_req->ds_rq_type == DMM_DESCRIBE) {
        // Since we can have object roots "mounted" inside another object,
        // _describe sub-requests are sent to all of them.
        // Now we need to merge the results.
        dmm_reply_transl_data(minfo, GETI_ARG(request->result, 0));
        amxc_var_t* orig_ret = &minfo->ret;
        translate_describe_response(orig_ret);
        const char* main_name = GET_CHAR(&main_req->ret, "name");
        const char* name = GET_CHAR(orig_ret, "name");
        if(main_name && name && (strcmp(main_name, name) == 0)) {
            amxc_var_add_value(GET_ARG(&main_req->ret, "objects"), GET_ARG(orig_ret, "objects"));
            amxc_var_add_value(GET_ARG(&main_req->ret, "functions"), GET_ARG(orig_ret, "functions"));
            amxc_var_add_value(GET_ARG(&main_req->ret, "parameters"), GET_ARG(orig_ret, "parameters"));
            amxc_var_add_value(GET_ARG(&main_req->ret, "events"), GET_ARG(orig_ret, "events"));
        }
        dmm_hide_rename_proc(main_req);
    } else {
        dmm_reply_transl_path(minfo, request->result);
        dmm_hide_rename_proc(minfo);
        amxc_var_for_each(rv, &minfo->ret) {
            amxc_var_set_key(&main_req->ret, amxc_var_key(rv), rv, AMXC_VAR_FLAG_DEFAULT | AMXC_VAR_FLAG_UPDATE);
        }
    }
    dmm_delete_info(&minfo);

    status = (status == amxd_status_object_not_found)? amxd_status_ok:status;
    if(amxc_llist_is_empty(&main_req->child_requests)) {
        SAH_TRACEZ_INFO(ME, "All child requests done for call id= %d", (uint32_t) main_req->call_id);
        SAH_TRACEZ_INFO(ME, "Final result = %d", status);
        SAH_TRACEZ_LOG_VARIANT(&main_req->ret);
        amxd_function_deferred_call_done(main_req->call_id, status, NULL, &main_req->ret);
        dmm_delete_info(&main_req);
    }
}

/**
 * @brief hierarchy walker callback to check objects for mapping.
 *
 * called for each object in the hierarchy. if the object is mapped, it triggers
 * a forwarded rpc call (@ref dmm_rpc_forward).
 *
 * @param[in] object the current object in the hierarchy.
 * @param[in] depth  the current depth in the hierarchy.
 * @param[in] priv   private data (rpc_data_t pointer).
 */
static void dmm_check_tree(amxd_object_t* const object,
                           int32_t depth,
                           void* priv) {
    rpc_data_t* data = (rpc_data_t*) priv;
    SAH_TRACEZ_IN(ME);
    if(dmm_is_mapped(object, "")) {
        amxd_status_t retval = amxd_status_ok;
        map_info_t* minfo = NULL;
        amxc_var_t* depth_var = GET_ARG(data->args, "depth");
        char* path = amxd_object_get_path(object, AMXD_OBJECT_TERMINATE | AMXD_OBJECT_INDEXED);
        amxc_var_set(int32_t, depth_var, depth);
        dmm_new_info(&minfo, path);

        minfo->ds_rq_type = dmm_downstream_request_type_get(amxd_function_get_name(data->func));
        amxc_llist_append(&data->main->child_requests, &minfo->it);
        retval = dmm_rpc_forward(minfo, object, data->func, data->args, dmm_child_request_done, data->func != NULL);
        if(retval == amxd_status_object_not_found) {
            dmm_delete_info(&minfo);
        }
        free(path);
    }
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Retrieves the requested depth from the arguments.
 *
 * Checks for "depth" or "first_level_only" arguments to determine recursion depth.
 *
 * @param[in] args The argument variant.
 *
 * @return The depth as an integer (INT32_MAX for infinite).
 */
static int32_t dmm_get_request_depth(const amxc_var_t* const args) {
    int32_t depth = GET_INT32(args, "depth");
    if(GET_ARG(args, "first_level_only") != NULL) {
        if(GET_BOOL(args, "first_level_only")) {
            depth = 0;
        } else {
            depth = INT32_MAX;
        }
    }

    if(depth == -1) {
        depth = INT32_MAX;
    }

    return depth;
}

/**
 * @brief Timer callback for RPC timeout (reply mode).
 *
 * Triggered if the RPC takes too long. Completes the call with success (0)
 * and whatever data has been collected so far.
 *
 * @param[in] timer The timer that expired.
 * @param[in] priv  Private data (map_info_t pointer).
 */
static void dmm_rpc_timeout_reply(UNUSED amxp_timer_t* timer, void* priv) {
    map_info_t* minfo = (map_info_t*) priv;

    SAH_TRACEZ_WARNING(ME, "Wait timer expired for call id = %d, forwarding recieved data", (uint32_t) minfo->call_id);
    amxd_function_deferred_call_done(minfo->call_id, 0, NULL, &minfo->ret);

    dmm_delete_info(&minfo);
}

/**
 * @brief Timer callback for RPC timeout (fail mode).
 *
 * Triggered if the RPC takes too long. Completes the call with a timeout error.
 *
 * @param[in] timer The timer that expired.
 * @param[in] priv  Private data (map_info_t pointer).
 */
static void dmm_rpc_timeout_fail(UNUSED amxp_timer_t* timer, void* priv) {
    map_info_t* minfo = (map_info_t*) priv;

    SAH_TRACEZ_WARNING(ME, "Wait timer expired for call id = %d, fail", (uint32_t) minfo->call_id);
    amxd_function_deferred_call_done(minfo->call_id, amxd_status_timeout, NULL, NULL);

    dmm_delete_info(&minfo);
}

/**
 * @brief Starts the wait timer for an RPC call.
 *
 * Configures a timer based on the "dmm-resp-wait-time" config.
 * Uses different callbacks (reply vs fail) based on the function name.
 *
 * @param[in] func  The name of the function being called.
 * @param[in] minfo The mapping info structure.
 */
static void dmm_start_wait_timer(const char* func, map_info_t* minfo) {
    prpl_dmm_t* proxy = dmm_get_info();
    const amxc_var_t* var_wait_time = GET_ARG(&proxy->parser->config, "dmm-resp-wait-time");
    uint32_t wait_time = var_wait_time == NULL? 3:GET_UINT32(var_wait_time, NULL);

    SAH_TRACEZ_INFO(ME, "Starting wait timer for call id= %d, wait_time [%d]", (uint32_t) minfo->call_id, wait_time);
    if((strcmp(func, "_get") == 0) ||
       (strcmp(func, "_get_supported") == 0) ||
       (strcmp(func, "_get_instances") == 0)) {
        amxp_timer_new(&minfo->wait_timer, dmm_rpc_timeout_reply, minfo);
    } else {
        amxp_timer_new(&minfo->wait_timer, dmm_rpc_timeout_fail, minfo);
    }

    if(minfo->wait_timer != NULL) {
        amxp_timer_start(minfo->wait_timer, wait_time * 1000);
    }
}

/**
 * @brief Checks the object tree and initiates forwarded calls if necessary.
 *
 * Calls the base function locally, then walks the hierarchy (@ref dmm_check_tree)
 * to forward requests for mapped children.
 *
 * @param[in] object  The object context.
 * @param[in] func    The function to call.
 * @param[in] args    Arguments.
 * @param[in] ret     Return variant.
 * @param[in] done_fn Callback for completion.
 *
 * @return amxd_status_deferred if child requests are pending, or status from base call.
 */
static amxd_status_t dmm_check_object(amxd_object_t* object,
                                      amxd_function_t* func,
                                      amxc_var_t* args,
                                      amxc_var_t* ret,
                                      amxb_be_done_cb_fn_t done_fn) {
    amxd_status_t retval = amxd_status_object_not_found;
    int32_t depth = dmm_get_request_depth(args);
    map_info_t* minfo = NULL;
    rpc_data_t data;

    SAH_TRACEZ_IN(ME);
    retval = amxd_function_call_base(func, object, args, ret);
    when_failed(retval, exit);

    dmm_new_info(&minfo, NULL);
    minfo->done_fn = done_fn;
    data.main = minfo;
    data.func = func;
    data.args = args;
    minfo->ds_rq_type = dmm_downstream_request_type_get(amxd_function_get_name(func));

    amxc_var_move(&minfo->ret, ret);
    amxd_object_hierarchy_walk(object, amxd_direction_down, NULL, dmm_check_tree, depth, &data);
    if(amxc_llist_is_empty(&minfo->child_requests)) {
        amxc_var_move(ret, &minfo->ret);
        SAH_TRACEZ_LOG_VARIANT(ret);
        dmm_delete_info(&minfo);
    } else {
        amxd_function_defer(func, &minfo->call_id, ret, dmm_rpc_cancel, minfo);
        SAH_TRACEZ_INFO(ME, "Deferred call id = %d (private data = %p)", (uint32_t) minfo->call_id, (void*) minfo);
        dmm_start_wait_timer(amxd_function_get_name(func), minfo);
        retval = amxd_status_deferred;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
 * @brief Checks if the path resolves to a mapped object and forwards if so.
 *
 * Resolves the relative path. If it points to a mapped object, forwards the call.
 * Otherwise, calls the base function locally.
 *
 * @param[in] object The object context.
 * @param[in] func   The function to call.
 * @param[in] args   Arguments.
 * @param[in] ret    Return variant.
 *
 * @return Status of the operation.
 */
static amxd_status_t dmm_check_resolved(amxd_object_t* object,
                                        amxd_function_t* func,
                                        amxc_var_t* args,
                                        amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_object_not_found;
    const char* rel_path = GET_CHAR(args, "rel_path");
    amxd_path_t input_path;
    amxc_llist_t paths;

    SAH_TRACEZ_IN(ME);
    amxd_path_init(&input_path, rel_path);
    amxc_llist_init(&paths);

    SAH_TRACEZ_INFO(ME, "Resolving path = [%s]", amxd_path_get(&input_path, 0));
    amxd_object_resolve_pathf(object, &paths, "%s", amxd_path_get(&input_path, 0));
    if(!amxc_llist_is_empty(&paths)) {
        amxc_llist_for_each(it, &paths) {
            amxc_string_t* path = amxc_string_from_llist_it(it);
            amxd_object_t* obj = amxd_dm_findf(dmm_get_dm(), "%s", amxc_string_get(path, 0));
            SAH_TRACEZ_INFO(ME, "Matching object = [%s]", amxc_string_get(path, 0));
            if(dmm_is_mapped(obj, "")) {
                if((rel_path == NULL) || (*rel_path == 0)) {
                    amxd_function_call_base(func, object, args, ret);
                    SAH_TRACEZ_LOG_VARIANT(ret);
                }
                amxc_llist_clean(&paths, amxc_string_list_it_free);
                amxd_path_clean(&input_path);
                goto exit;
            }
        }
        retval = amxd_function_call_base(func, object, args, ret);
        amxc_llist_clean(&paths, amxc_string_list_it_free);
    }

    amxd_path_clean(&input_path);

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
 * @brief The main RPC call implementation for the DMM.
 *
 * This function handles an incoming RPC call (function call) from the Data Model (DM).
 * It performs the following steps:
 * 1. Checks if the object has been renamed or hidden.
 * 2. Reverts parameter renaming for correct processing.
 * 3. Tries to handle the request locally (`dmm_check_object` or `dmm_check_resolved`).
 * 4. If local handling fails, it creates and initializes a `map_info_t` structure,
 * and forwards the request to the backend (`dmm_rpc_forward`).
 * 5. If the request is forwarded, the function defers execution (`amxd_function_defer`)
 * and starts a wait timer.
 *
 * @param object Pointer to the amxd_object_t for which the function is called.
 * @param func Pointer to the amxd_function_t representing the called RPC function (e.g., _get, _set).
 * @param args amxc_var_t containing the function arguments.
 * @param ret amxc_var_t where the result will be written.
 * @param done_fn Pointer to the completion callback function to be called
 * after the backend request finishes.
 * @return amxd_status_t Returns amxd_status_deferred if the request was successfully
 * forwarded, or an immediate completion status.
 */
static amxd_status_t dmm_rpc_impl(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret,
                                  amxb_be_done_cb_fn_t done_fn,
                                  map_info_t** minfo_ret,
                                  bool defer) {
    amxd_status_t retval = amxd_status_object_not_found;
    map_info_t* minfo = NULL;
    amxc_var_t* var_rel_path = GET_ARG(args, "rel_path");
    const char* rel_path = GET_CHAR(var_rel_path, NULL);
    bool rel_path_not_empty = (rel_path != NULL) && (*rel_path != 0);
    int32_t depth = dmm_get_request_depth(args);
    const char* fname = amxd_function_get_name(func);
    bool is_describe = strcmp(fname, "_describe") == 0;

    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Recieved function call [%s] - object = [%s]:",
                    fname,
                    amxd_object_get_name(object, AMXD_OBJECT_NAMED));

    SAH_TRACEZ_LOG_VARIANT(args);

    const TreeNode* backward_node;
    retval = dmm_revert_rename_proc(args, object, &backward_node);
    if(retval != amxd_status_ok) {
        goto exit;
    }

    SAH_TRACEZ_LOG_VARIANT(args);

    var_rel_path = GET_ARG(args, "rel_path");

    if(rel_path_not_empty) {
        amxd_object_t* tmp = dmm_find_object(object, var_rel_path);
        if(tmp != NULL) {
            object = tmp;
            rel_path = GET_CHAR(var_rel_path, NULL);
        }
    } else {
        rel_path = NULL;
    }

    if(((rel_path == NULL) || (*rel_path == 0)) && ((depth > 0) || is_describe)) {
        retval = dmm_check_object(object, func, args, ret, done_fn);
    } else {
        retval = dmm_check_resolved(object, func, args, ret);
    }

    if(retval != amxd_status_object_not_found) {
        goto exit;
    }

    dmm_new_info(&minfo, NULL);
    if(minfo_ret) {
        *minfo_ret = minfo;
    }

    amxc_var_move(&minfo->ret, ret);

    minfo->ds_rq_type = dmm_downstream_request_type_get(fname);
    minfo->backward_node = backward_node;

    retval = dmm_rpc_forward(minfo, object, func, args, done_fn, defer);

    if(defer) {
        if(retval != amxd_status_deferred) {
            dmm_delete_info(&minfo);
            if(minfo_ret) {
                *minfo_ret = NULL;
            }

            goto exit;
        }
        retval = amxd_function_defer(func, &minfo->call_id, ret, dmm_rpc_cancel, minfo);
        if(retval == amxd_status_ok) {
            dmm_start_wait_timer(amxd_function_get_name(func), minfo);
            retval = amxd_status_deferred;
        }
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

typedef amxb_be_done_cb_fn_t dmm_rpc_async_done_cb_t;                     /*!< Callback for async translation of the RPC result */
typedef void (* dmm_rpc_sync_translator_t)(map_info_t*, amxc_var_t* ret); /*!< Callback for sync translation of the RPC result */

/**
 * @brief Middleware for calling dmm_rpc_impl either synchronously or
 * ascynrhonously.
 *
 * @param object object on which function call was made.
 * @param func RPC that was called (e.g., _get, _set)
 * @param args call arguments.
 * @param ret amxc variant to stor the result
 * @param done_fn async translator to use when call is asynchronous
 * @param sync_translator_fn sync translator to use when call is synchronous
 * @param defer whether the call is async or sync
 *
 * @return result of the dmm_rpc_impl.

 */
static amxd_status_t dmm_rpc_call(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret,
                                  dmm_rpc_async_done_cb_t done_fn,
                                  dmm_rpc_sync_translator_t sync_translator_fn,
                                  bool defer) {

    amxd_status_t retval = amxd_status_object_not_found;

    if(defer) {
        retval = dmm_rpc_impl(object, func, args, ret, done_fn, NULL, true);
        goto exit;
    }

    map_info_t* minfo = NULL;

    amxc_var_set_type(ret, AMXC_VAR_ID_NULL);
    retval = dmm_rpc_impl(object, func, args, ret, NULL, &minfo, false);
    when_null(minfo, exit);

    SAH_TRACEZ_INFO(ME, "Forwarded request done - call id= %d", (uint32_t) minfo->call_id);
    SAH_TRACEZ_INFO(ME, "Result = %d", retval);

    amxc_var_move(ret, &minfo->ret);

    sync_translator_fn(minfo, ret);
    dmm_hide_rename_proc(minfo);

    amxc_var_move(ret, &minfo->ret);
    dmm_delete_info(&minfo);

    SAH_TRACEZ_LOG_VARIANT(ret);

exit:
    return retval;

}

amxd_status_t dmm_rpc_transl_path(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_done_transl_path, NULL, true);

    return retval;
}

amxd_status_t dmm_rpc_transl_path_optional_sync(amxd_object_t* object,
                                                amxd_function_t* func,
                                                amxc_var_t* args,
                                                amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_object_not_found;

    if(GET_INT32(args, "depth")) {
        retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_done_transl_path, NULL, true);
    } else {
        retval = dmm_rpc_call(object, func, args, ret, NULL, dmm_reply_transl_path, false);
    }

    return retval;
}

amxd_status_t dmm_rpc_transl_data(amxd_object_t* object,
                                  amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret) {

    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, NULL, dmm_reply_transl_data_list, false);

    return retval;
}

amxd_status_t dmm_rpc_transl_data_multiple(amxd_object_t* object,
                                           amxd_function_t* func,
                                           amxc_var_t* args,
                                           amxc_var_t* ret) {

    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_done_transl_data_multiple, NULL, true);

    return retval;
}

amxd_status_t dmm_rpc(amxd_object_t* object,
                      amxd_function_t* func,
                      amxc_var_t* args,
                      amxc_var_t* ret) {

    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_done, NULL, true);

    return retval;
}

amxd_status_t dmm_rpc_list(amxd_object_t* object,
                           amxd_function_t* func,
                           amxc_var_t* args,
                           amxc_var_t* ret) {

    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_list_done, NULL, true);

    return retval;
}

amxd_status_t dmm_rpc_del(amxd_object_t* object,
                          amxd_function_t* func,
                          amxc_var_t* args,
                          amxc_var_t* ret) {

    amxd_status_t retval = amxd_status_object_not_found;

    retval = dmm_rpc_call(object, func, args, ret, dmm_rpc_done_transl_list, NULL, true);

    return retval;
}
