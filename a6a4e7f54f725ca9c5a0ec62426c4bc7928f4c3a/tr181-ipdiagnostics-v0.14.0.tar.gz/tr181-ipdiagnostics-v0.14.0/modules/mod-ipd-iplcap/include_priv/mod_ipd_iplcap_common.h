/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__MOD_IPD_IPLCAP_COMMON_H__)
#define __MOD_IPD_IPLCAP_COMMON_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include "iplcap.h"
#include "mod_ipd_common.h"

// File names
#define IPLCAP_SCRIPT_FILE "iplcap.sh"

// Min/max values
#define IPLCAP_MIN_ETH_PRIORITY         0
#define IPLCAP_MAX_ETH_PRIORITY         7
#define IPLCAP_MAX_DSCP                 63
#define IPLCAP_MIN_UDP_PAYLOAD          32
#define IPLCAP_MAX_UDP_PAYLOAD          8972
#define IPLCAP_MAX_UDP_PAYLOAD_NO_JUMBO 1472
#define IPLCAP_MIN_PORT                 49152
#define IPLCAP_MAX_PORT                 65535
#define IPLCAP_MIN_PORT_OPT             0
#define IPLCAP_MAX_PORT_OPT             49151
#define IPLCAP_MIN_PORT_OPT_VALID       1024
#define IPLCAP_MIN_PREAMBLE_DUR         0
#define IPLCAP_MAX_PREAMBLE_DUR         5
#define IPLCAP_MIN_START_RATE           500
#define IPLCAP_MAX_START_RATE           40000000
#define IPLCAP_MIN_START_RATE_INDEX     0
#define IPLCAP_MAX_START_RATE_INDEX     11108
#define IPLCAP_MIN_NUM_SUB_INTERVALS    1
#define IPLCAP_MAX_NUM_SUB_INTERVALS    100
#define IPLCAP_MAX_NUM_FIRST_MODE       100
#define IPLCAP_MIN_SUB_INTERVAL         100
#define IPLCAP_MAX_SUB_INTERVAL         6000
#define IPLCAP_MIN_FEEDBACK_INTERVAL    5
#define IPLCAP_MAX_FEEDBACK_INTERVAL    250
#define IPLCAP_MIN_TIMEOUT_NO_TRAFFIC   500
#define IPLCAP_MAX_TIMEOUT_NO_TRAFFIC   1000
#define IPLCAP_MIN_TIMEOUT_NO_STATUS    500
#define IPLCAP_MAX_TIMEOUT_NO_STATUS    1000
#define IPLCAP_MIN_TMAX                 50
#define IPLCAP_MAX_TMAX                 3000
#define IPLCAP_MIN_TMAX_RTT             50
#define IPLCAP_MAX_TMAX_RTT             3000
#define IPLCAP_MIN_TS_RES               1
#define IPLCAP_MAX_TS_RES               1000
#define IPLCAP_MAX_SEQ_ERR_THRESH       100
#define IPLCAP_MIN_LOWER_THRESH         5
#define IPLCAP_MAX_LOWER_THRESH         250
#define IPLCAP_MIN_UPPER_THRESH         5
#define IPLCAP_MAX_UPPER_THRESH         250
#define IPLCAP_MIN_RETRY_THRESH         1
#define IPLCAP_MAX_RETRY_THRESH         3000
#define IPLCAP_MIN_HIGH_SPEED_DELTA     2
#define IPLCAP_MIN_SLOW_ADJ_THRESH      2
#define IPLCAP_MIN_HSPEED_THRESH        1
#define IPLCAP_DEFAULT_MTU              1500
#define IPLCAP_MAX_MAX_BANDWIDTH        32767
#define IPLCAP_MIN_MAX_BANDWIDTH        0

#define CPE_PREFIX "cpe-IPLayerCapacityAuthCode-"

// JSON path definitions
#define IPLCAP_JSON_OUTPUT_KEY            "Output"
#define IPLCAP_JSON_ATMAX_KEY             "AtMax"
#define IPLCAP_JSON_SUMMARY_KEY           "Summary"
#define IPLCAP_JSON_INPUT_KEY             "Input"
#define IPLCAP_JSON_SUPP_KEY              "IPLayerCapSupported"
#define IPLCAP_JSON_INC_KEY               IPLCAP_RET_KEY_INC
#define IPLCAP_JSON_MODAL_KEY             IPLCAP_RET_KEY_MODAL

// common section paths
#define IPLCAP_JSON_PATH_MAX_CONN            IPLCAP_RET_KEY_MAX_CONN
#define IPLCAP_JSON_PATH_MAX_INC_RES         IPLCAP_RET_KEY_MAX_INC_RES
#define IPLCAP_JSON_PATH_SUPP_SW_VER         IPLCAP_JSON_SUPP_KEY "."IPLCAP_RET_KEY_SUPP_SW_VER
#define IPLCAP_JSON_PATH_SUPP_CTRL_VER       IPLCAP_JSON_SUPP_KEY "."IPLCAP_RET_KEY_SUPP_CTRL_VER
#define IPLCAP_JSON_PATH_SUPP_METRICS        IPLCAP_JSON_SUPP_KEY "."IPLCAP_RET_KEY_SUPP_METRICS

// AtMax section paths
#define IPLCAP_JSON_PATH_TIME_OF_MAX              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_TIME_OF_MAX
#define IPLCAP_JSON_PATH_LOSS_RATIO_MAX           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_LOSS_RATIO_MAX
#define IPLCAP_JSON_PATH_REORD_RATIO_MAX          IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_REORD_RATIO_MAX
#define IPLCAP_JSON_PATH_REPL_RATIO_MAX           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_REPL_RATIO_MAX
#define IPLCAP_JSON_PATH_RTT_MAX_MAX              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY ".RTTMax"
#define IPLCAP_JSON_PATH_RTT_MIN_MAX              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY ".RTTMin"
#define IPLCAP_JSON_PATH_PDV_RANGE_MAX            IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_PDV_RANGE_MAX
#define IPLCAP_JSON_PATH_RTT_RANGE_MAX            IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_RTT_RANGE_MAX
#define IPLCAP_JSON_PATH_MAX_IP_CAP               IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_MAX_IP_CAP
#define IPLCAP_JSON_PATH_ETH_MBPS_MAX             IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY ".InterfaceEthMbps"
#define IPLCAP_JSON_PATH_MAX_ETH_NO_FCS           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_MAX_ETH_NO_FCS
#define IPLCAP_JSON_PATH_MAX_ETH_WITH_FCS         IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_MAX_ETH_WITH_FCS
#define IPLCAP_JSON_PATH_MAX_ETH_WITH_VLAN        IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_MAX_ETH_WITH_VLAN
#define IPLCAP_JSON_PATH_MIN_OWD_MAX              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_ATMAX_KEY "."IPLCAP_RET_KEY_MIN_OWD_MAX

// Summary section paths
#define IPLCAP_JSON_PATH_LOSS_RATIO_SUM           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_LOSS_RATIO_SUM
#define IPLCAP_JSON_PATH_REORD_RATIO_SUM          IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_REORD_RATIO_SUM
#define IPLCAP_JSON_PATH_REPL_RATIO_SUM           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_REPL_RATIO_SUM
#define IPLCAP_JSON_PATH_PDV_RANGE_SUM            IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_PDV_RANGE_SUM
#define IPLCAP_JSON_PATH_RTT_RANGE_SUM            IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_RTT_RANGE_SUM
#define IPLCAP_JSON_PATH_IP_CAP_SUMMARY           IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_IP_CAP_SUMMARY
#define IPLCAP_JSON_PATH_ETH_MBPS_SUM             IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY ".InterfaceEthMbps"
#define IPLCAP_JSON_PATH_MIN_OWD_SUM              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_MIN_OWD_SUM
#define IPLCAP_JSON_PATH_MIN_RTT_SUM              IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_SUMMARY_KEY "."IPLCAP_RET_KEY_MIN_RTT_SUM

// Input section paths
#define IPLCAP_JSON_PATH_ROLE                      IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_ROLE
#define IPLCAP_JSON_PATH_JUMBO_FRAMES              IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_JUMBO_FRAMES
#define IPLCAP_JSON_PATH_TEST_TYPE                 IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TEST_TYPE
#define IPLCAP_JSON_PATH_DSCP                      IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_DSCP
#define IPLCAP_JSON_PATH_IPDV_ENABLE               IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_IPDV_ENABLE
#define IPLCAP_JSON_PATH_IPRR_ENABLE               IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_IPRR_ENABLE
#define IPLCAP_JSON_PATH_RIPR_ENABLE               IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_RIPR_ENABLE
#define IPLCAP_JSON_PATH_PREAMBLE_DUR              IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_PREAMBLE_DUR
#define IPLCAP_JSON_PATH_START_RATE_INDEX          IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_START_RATE_INDEX
#define IPLCAP_JSON_PATH_NUM_SUB_INTERVALS         IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_NUM_SUB_INTERVALS
#define IPLCAP_JSON_PATH_NUM_FIRST_MODE            IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_NUM_FIRST_MODE
#define IPLCAP_JSON_PATH_SUB_INTERVAL              IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_SUB_INTERVAL
#define IPLCAP_JSON_PATH_FEEDBACK_INTERVAL         IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_FEEDBACK_INTERVAL
#define IPLCAP_JSON_PATH_TIMEOUT_NO_TEST_TRAFFIC   IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TIMEOUT_NO_TEST_TRAFFIC
#define IPLCAP_JSON_PATH_TIMEOUT_NO_STATUS_MESSAGE IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TIMEOUT_NO_STATUS_MESSAGE
#define IPLCAP_JSON_PATH_TMAX                      IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TMAX
#define IPLCAP_JSON_PATH_TMAX_RTT                  IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TMAX_RTT
#define IPLCAP_JSON_PATH_TIMESTAMP_RES             IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_TIMESTAMP_RES
#define IPLCAP_JSON_PATH_SEQ_ERR_THRESH            IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_SEQ_ERR_THRESH
#define IPLCAP_JSON_PATH_REORD_DUP_IGNORE          IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_REORD_DUP_IGNORE
#define IPLCAP_JSON_PATH_LOWER_THRESH              IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_LOWER_THRESH
#define IPLCAP_JSON_PATH_UPPER_THRESH              IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_UPPER_THRESH
#define IPLCAP_JSON_PATH_HIGH_SPEED_DELTA          IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_HIGH_SPEED_DELTA
#define IPLCAP_JSON_PATH_SLOW_ADJ_THRESH           IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_SLOW_ADJ_THRESH
#define IPLCAP_JSON_PATH_HSPEED_THRESH             IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_HSPEED_THRESH
#define IPLCAP_JSON_PATH_RATE_ADJ_ALGO             IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_RATE_ADJ_ALGO
#define IPLCAP_JSON_PATH_UDP_PAYLOAD_CONTENT       IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT
#define IPLCAP_JSON_PATH_UDP_PAYLOAD_MIN           IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_UDP_PAYLOAD_MIN
#define IPLCAP_JSON_PATH_UDP_PAYLOAD_MAX           IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_UDP_PAYLOAD_MAX
#define IPLCAP_JSON_PATH_PRTCLV                    IPLCAP_JSON_INPUT_KEY "."IPLCAP_RET_KEY_PRTCLV

// Output basic section paths
#define IPLCAP_JSON_PATH_BOM_TIME                  IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_BOM_TIME
#define IPLCAP_JSON_PATH_EOM_TIME                  IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_EOM_TIME
#define IPLCAP_JSON_PATH_TMAX_USED                 IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_TMAX_USED
#define IPLCAP_JSON_PATH_TEST_INTERVAL             IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_TEST_INTERVAL
#define IPLCAP_JSON_PATH_TMAX_RTT_USED             IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_TMAX_RTT_USED
#define IPLCAP_JSON_PATH_TS_RES_USED               IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_RET_KEY_TS_RES_USED

// modal result section paths
#define IPLCAP_JSON_KEY_MODAL_TIME_MAX             IPLCAP_RET_KEY_MODAL_TIME_MAX
#define IPLCAP_JSON_KEY_MODAL_LOSS_RATIO           IPLCAP_RET_KEY_MODAL_LOSS_RATIO
#define IPLCAP_JSON_KEY_MODAL_REORD_RATIO          IPLCAP_RET_KEY_MODAL_REORD_RATIO
#define IPLCAP_JSON_KEY_MODAL_REPL_RATIO           IPLCAP_RET_KEY_MODAL_REPL_RATIO
#define IPLCAP_JSON_KEY_MODAL_PDV_RANGE            IPLCAP_RET_KEY_MODAL_PDV_RANGE
#define IPLCAP_JSON_KEY_MODAL_RTT_RANGE            IPLCAP_RET_KEY_MODAL_RTT_RANGE
#define IPLCAP_JSON_KEY_MODAL_MAX_IP_CAP           IPLCAP_RET_KEY_MODAL_MAX_IP_CAP
#define IPLCAP_JSON_KEY_MODAL_ETH_MBPS             "InterfaceEthMbps"
#define IPLCAP_JSON_KEY_MODAL_MAX_ETH_NO_FCS       IPLCAP_RET_KEY_MODAL_MAX_ETH_NO_FCS
#define IPLCAP_JSON_KEY_MODAL_MAX_ETH_WITH_FCS     IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_FCS
#define IPLCAP_JSON_KEY_MODAL_MAX_ETH_WITH_VLAN    IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_VLAN
#define IPLCAP_JSON_KEY_MODAL_MIN_OWD              IPLCAP_RET_KEY_MODAL_MIN_OWD

// incremental result section paths
#define IPLCAP_JSON_KEY_INC_TIME                IPLCAP_RET_KEY_INC_TIME
#define IPLCAP_JSON_KEY_INC_LOSS_RATIO          IPLCAP_RET_KEY_INC_LOSS_RATIO
#define IPLCAP_JSON_KEY_INC_REORD_RATIO         IPLCAP_RET_KEY_INC_REORD_RATIO
#define IPLCAP_JSON_KEY_INC_REPL_RATIO          IPLCAP_RET_KEY_INC_REPL_RATIO
#define IPLCAP_JSON_KEY_INC_PDV_RANGE           IPLCAP_RET_KEY_INC_PDV_RANGE
#define IPLCAP_JSON_KEY_INC_RTT_RANGE           IPLCAP_RET_KEY_INC_RTT_RANGE
#define IPLCAP_JSON_KEY_INC_IP_CAP              IPLCAP_RET_KEY_INC_IP_CAP
#define IPLCAP_JSON_KEY_INC_ETH_MBPS            IPLCAP_RET_KEY_INC_ETH_MBPS
#define IPLCAP_JSON_KEY_INC_MIN_OWD             IPLCAP_RET_KEY_INC_MIN_OWD

// list section paths
#define IPLCAP_JSON_PATH_INC                       IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_INC_KEY
#define IPLCAP_JSON_PATH_MODAL                     IPLCAP_JSON_OUTPUT_KEY "."IPLCAP_JSON_MODAL_KEY

#define GETP_DOUBLE(var, key)                     amxc_var_get_double(amxc_var_get_key(var, key, AMXC_VAR_FLAG_DEFAULT))

/**
 * @brief Error pattern mapping structure for IP Layer Capacity diagnostics.
 *
 * @details
 * Structure that associates a string pattern with a corresponding test status code.
 *
 * @param[in]  pattern String pattern to match against error messages.
 * @param[in]  status  Corresponding test status code for the matched pattern.
 *
 * @return None.
 */
typedef struct {
    const char* pattern;              /**< Error message pattern to match */
    iplcap_test_status_t status;      /**< Corresponding test status code */
} iplcap_error_pattern_t;

/**
 * @brief Converts a status string to a status integer.
 *
 * @details
 * Converts the provided status string to its corresponding integer status code.
 *
 * @param[in]  status_string String representation of the status.
 *
 * @return The integer status code corresponding to the status string.
 */
iplcap_test_status_t iplcap_st_str_to_st_int(const cstring_t status_string);

/**
 * @brief Creates a command string for the IP Layer Capacity test.
 *
 * @details
 * Generates a command string based on the provided test parameters.
 *
 * @param[in]  params Test parameters (owned by caller).
 * @param[out] cmd    Output command string (owned by caller).
 *
 * @return 0 on success, -1 on failure.
 */
int iplcap_create_command(amxc_var_t* params, amxc_string_t* cmd);

/**
 * @brief Maps an error message string to an IPLCAP test status code.
 *
 * @details
 * Analyzes the provided error message string and maps it to a corresponding IPLCAP test status code.
 *
 * @param[in]  error_msg The error message string to analyze. May be NULL.
 *
 * @return The mapped status code corresponding to the error message, or
 *         iplcap_test_error_err_other if no match is found or input is invalid.
 */
iplcap_test_status_t iplcap_map_error_message_to_status(const char* error_msg);

/**
 * @brief Terminate a running IP Layer Capacity subprocess.
 *
 * @details Attempts graceful termination (SIGTERM) and escalates to SIGKILL
 *          if the process does not exit within a short timeout.
 *
 * @param[in] params Variant containing process metadata (PID under Proc.PID).
 *
 * @return 0 when the process is confirmed terminated, -1 otherwise.
 */
int iplcap_kill_iplcap_test(amxc_var_t* params);

/**
 * @brief Delete test script file
 *
 * Removes the temporary test script file from the filesystem.
 */
void iplcap_delete_test_script(void);

/**
 * @brief Create a shell script to execute the IP Layer Capacity command.
 *
 * @details Validates the command string for safety, writes a simple
 *          executable script to disk, and returns the interpreter
 *          and script path in the provided array.
 *
 * @param[in]  params    Unused test parameters.
 * @param[in]  cmd       Prepared and validated command string.
 * @param[out] sh_script Array receiving "sh" and script filename.
 *
 * @return 0 on success, -1 on failure.
 */
int iplcap_create_sh_script(amxc_var_t* params, amxc_string_t* cmd, amxc_array_t* sh_script);

#ifdef __cplusplus
}
#endif

#endif // __MOD_IPD_IPLCAP_COMMON_H__
