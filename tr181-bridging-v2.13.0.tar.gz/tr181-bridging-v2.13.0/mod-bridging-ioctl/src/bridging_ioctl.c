/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <net/if.h>
#include <linux/if_bridge.h>
#include <linux/sockios.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>

#include "bridging_ioctl.h"

#define ME "mod-bridging"

static int bridgefd = -1;

static int port_ioctl(amxc_var_t* args, unsigned long command) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const cstring_t bridge_name = GETP_CHAR(args, "bridge_name");
    const cstring_t port_name = GETP_CHAR(args, "port_name");

    when_str_empty_trace(bridge_name, exit, ERROR, "port not added/removed, no bridge name given");
    when_str_empty_trace(port_name, exit, ERROR, "port not added/removed, no port name given");

    struct ifreq ifreq;
    strncpy(ifreq.ifr_name, bridge_name, IF_NAMESIZE);
    ifreq.ifr_name[IF_NAMESIZE - 1] = '\0';
    ifreq.ifr_ifindex = if_nametoindex(port_name);

    switch(command) {
    case BRCTL_ADD_IF:
        SAH_TRACEZ_INFO(ME, "Add port \"%s\" to bridge \"%s\"", port_name, bridge_name);
        rv = ioctl(bridgefd, SIOCBRADDIF, &ifreq);
        if(rv < 0) {
            SAH_TRACEZ_ERROR(ME, "Add port \"%s\" to bridge \"%s\" failed: %d(%s)",
                             port_name, bridge_name, errno, strerror(errno));
            rv = 2;
        }
        break;
    case BRCTL_DEL_IF:
        SAH_TRACEZ_INFO(ME, "Remove port \"%s\" from bridge \"%s\"", port_name, bridge_name);
        rv = ioctl(bridgefd, SIOCBRDELIF, &ifreq);
        if(rv < 0) {
            SAH_TRACEZ_ERROR(ME, "Remove port \"%s\" from bridge \"%s\" failed: %d(%s)",
                             port_name, bridge_name, errno, strerror(errno));
            rv = 3;
        }
        break;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int bridge_set_status(const cstring_t bridge_name, bool up) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("Ethernet.");
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    when_null_trace(ctx, exit, WARNING, "Ethernet plugin context not found");

    amxc_var_add_key(cstring_t, &args, "Name", bridge_name);
    amxc_var_add_key(bool, &args, "Enable", up);

    rv = amxb_call(ctx, "Ethernet.", "EnableLink", &args, &ret, 3);
    when_failed_trace(rv, exit, ERROR, "Failed to call EnableLink on Ethernet., error '%d'", rv);

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int bridge_setDown(const cstring_t bridge_name) {
    SAH_TRACEZ_IN(ME);
    int rv = bridge_set_status(bridge_name, false);

    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int bridge_setUp(const cstring_t bridge_name) {
    SAH_TRACEZ_IN(ME);
    int rv = bridge_set_status(bridge_name, true);

    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int bridge_brioctl(amxc_var_t* args, unsigned long command) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const cstring_t bridge_name = GETP_CHAR(args, "bridge_name");
    when_str_empty_trace(bridge_name, exit, ERROR, "bridge not added, no name given");

    switch(command) {
    case BRCTL_ADD_BRIDGE:
        SAH_TRACEZ_INFO(ME, "Create bridge \"%s\"", bridge_name);
        rv = ioctl(bridgefd, SIOCBRADDBR, bridge_name);
        if(rv < 0) {
            SAH_TRACEZ_ERROR(ME, "Create bridge \"%s\" failed: %d (%s)",
                             bridge_name, errno, strerror(errno));
        }
        break;
    case BRCTL_DEL_BRIDGE:
        SAH_TRACEZ_INFO(ME, "Destroy bridge \"%s\"", bridge_name);
        rv = bridge_setDown(bridge_name);
        when_failed_trace(rv, exit, ERROR, "Failed to disable the bridge '%s' before removing it", bridge_name);
        rv = ioctl(bridgefd, SIOCBRDELBR, bridge_name);
        if(rv < 0) {
            SAH_TRACEZ_ERROR(ME, "Destroy bridge \"%s\" failed: %d (%s)",
                             bridge_name, errno, strerror(errno));
            rv = 4;
        }
        break;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int add_bridge(UNUSED const char* function_name,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    when_null_trace(args, exit, ERROR, "can not add bridge, no information provided");
    when_failed(bridge_brioctl(args, BRCTL_ADD_BRIDGE), exit);

    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int enable_bridge(UNUSED const char* function_name,
                         amxc_var_t* args,
                         UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const cstring_t bridge_name = GETP_CHAR(args, "bridge_name");
    when_str_empty_trace(bridge_name, exit, ERROR, "bridge not enabled, no name given");
    when_null_trace(args, exit, ERROR, "can not enable bridge, no information provided");

    rv = bridge_setUp(bridge_name);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int disable_bridge(UNUSED const char* function_name,
                          amxc_var_t* args,
                          UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const cstring_t bridge_name = GETP_CHAR(args, "bridge_name");
    when_str_empty_trace(bridge_name, exit, ERROR, "bridge not disabled, no name given");
    when_null_trace(args, exit, ERROR, "can not disable bridge, no information provided");

    rv = bridge_setDown(bridge_name);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int remove_bridge(UNUSED const char* function_name,
                         amxc_var_t* args,
                         UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    when_null_trace(args, exit, ERROR, "can not remove bridge, no information provided");
    rv = bridge_brioctl(args, BRCTL_DEL_BRIDGE);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int add_port(UNUSED const char* function_name,
                    amxc_var_t* args,
                    UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    when_null_trace(args, exit, ERROR, "can not add port, no information provided");
    if(GETP_BOOL(args, "parameters.ManagementPort")) {
        SAH_TRACEZ_INFO(ME, "not adding management port as bridge interface");
        rv = 0;
        goto exit;
    }
    rv = port_ioctl(args, BRCTL_ADD_IF);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int remove_port(UNUSED const char* function_name,
                       amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    when_null_trace(args, exit, ERROR, "can not remove port, no information provided");
    rv = port_ioctl(args, BRCTL_DEL_IF);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static AMXM_CONSTRUCTOR bridging_ioctl_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    bridgefd = socket(AF_INET, SOCK_STREAM, 0);

    amxm_module_register(&mod, so, MOD_BRIDGE_CTRL);
    amxm_module_add_function(mod, "add-bridge", add_bridge);
    amxm_module_add_function(mod, "enable-bridge", enable_bridge);
    amxm_module_add_function(mod, "disable-bridge", disable_bridge);
    amxm_module_add_function(mod, "remove-bridge", remove_bridge);
    amxm_module_add_function(mod, "add-port", add_port);
    amxm_module_add_function(mod, "remove-port", remove_port);

    return 0;
}

static AMXM_DESTRUCTOR bridging_ioctl_stop(void) {
    close(bridgefd);
    return 0;
}
