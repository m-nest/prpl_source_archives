#!/bin/sh

# Check if the user provided an argument
if [ -z "$1" ]; then
  echo "Error: No interface name provided."
  echo "Usage: $0 <interface-name>"
  exit 1
fi

# Get the interface name from the first argument
ifname=$1

# Get the state value from 'ip link show <ifname>'
state=$(ip link show "$ifname" | awk '{for(i=1;i<=NF;i++) if($i=="state") print $(i+1)}')

# Print the state value
echo $state
