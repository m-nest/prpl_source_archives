/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <time.h>
#include <debug/sahtrace_macros.h>

#include "bulkdata.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_http.h"
#include "bulkdata_utils.h"
#include "bulkdata_profile_http_request_uri_parameter.h"
#include "filetransfer/filetransfer.h"

const char* days[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
const char* months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

#define ME "http"

#define HTTP_RETRY_MAX 9

amxd_object_t* bulkdata_get_http_object(amxd_object_t* profile) {
    cstring_t path = amxd_object_get_path(profile, AMXD_OBJECT_NAMED);
    amxd_object_t* obj = amxd_dm_findf(bulkdata_get_dm(), "%s.HTTP.", path);
    free(path);
    return obj;
}

const cstring_t bulkdata_http_get_url(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "URL"));
}

const cstring_t bulkdata_http_get_username(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "Username"));
}

const cstring_t bulkdata_http_get_password(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "Password"));
}

const csv_string_t bulkdata_http_get_compressions_supported(amxd_object_t* http) {
    return amxc_var_constcast(csv_string_t, amxd_object_get_param_value(http, "CompressionsSupported"));
}

const cstring_t bulkdata_http_get_compression(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "Compression"));
}

const csv_string_t bulkdata_http_get_method_supported(amxd_object_t* http) {
    return amxc_var_constcast(csv_string_t, amxd_object_get_param_value(http, "MethodsSupported"));
}

const cstring_t bulkdata_http_get_method(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "Method"));
}

bool bulkdata_http_get_use_date_header(amxd_object_t* http) {
    return amxd_object_get_value(bool, http, "UseDateHeader", NULL);
}

bool bulkdata_http_get_retry_enable(amxd_object_t* http) {
    return amxd_object_get_value(bool, http, "RetryEnable", NULL);
}

uint32_t bulkdata_http_get_retry_minimum_wait_interval(amxd_object_t* http) {
    return amxd_object_get_value(uint32_t, http, "RetryMinimumWaitInterval", NULL);
}

uint32_t bulkdata_http_get_retry_interval_multiplier(amxd_object_t* http) {
    return amxd_object_get_value(uint32_t, http, "RetryIntervalMultiplier", NULL);
}

bool bulkdata_http_get_persist_across_reboot(amxd_object_t* http) {
    return amxd_object_get_value(bool, http, "PersistAcrossReboot", NULL);
}

const cstring_t bulkdata_http_get_certificate(amxd_object_t* http) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(http, "CACertificate"));
}

static amxd_status_t bulkdata_profile_http_send_ftx_request(ftx_request_t* ftx_request, amxc_var_t* userdata);

static int http_request_set_header(ftx_request_t* request, const cstring_t encoding, const cstring_t compression, const cstring_t report_format, bool user_date_header) {
    int ret = -1;
    amxc_string_t header_str;
    amxc_string_init(&header_str, 0);
    when_null(request, exit);

    // encoding
    if(strncmp(encoding, "JSON", sizeof("JSON")) == 0) {
        when_failed_trace(ftx_request_set_http_header(request, "Content-Type", "application/json"), exit, ERROR, "Could not set Content Type");
    } else if(strncmp(encoding, "CSV", sizeof("CSV")) == 0) {
        when_failed_trace(ftx_request_set_http_header(request, "Content-Type", "text/csv"), exit, ERROR, "Could not set Content Type");
        // CSV header
        when_failed_trace(ftx_request_set_http_header(request, "header", "present"), exit, ERROR, "Could not set header is present for CSV report");
    }
    // charset
    when_failed_trace(ftx_request_set_http_header(request, "charset", "UTF-8"), exit, ERROR, "Could not set charset");
    // report format
    when_failed_trace(ftx_request_set_http_header(request, "BBF-Report-Format", report_format), exit, ERROR, "Could not set reportFormat");

    // compression
    if(strncmp(compression, "GZIP", sizeof("GZIP")) == 0) {
        when_failed(ftx_request_set_http_header(request, "Content-Encoding", "gzip"), exit);
    }

    if(true == user_date_header) {
        time_t t;
        struct tm tm;
        time(&t);
        gmtime_r(&t, &tm);

        amxc_string_setf(&header_str, "%s, %d %s %d %02d:%02d:%02d GMT",
                         days[tm.tm_wday],
                         tm.tm_mday,
                         months[tm.tm_mon],
                         1900 + tm.tm_year,
                         tm.tm_hour,
                         tm.tm_min,
                         tm.tm_sec);
        // Date
        when_failed(ftx_request_set_http_header(request, "Date", amxc_string_get(&header_str, 0)), exit);
    }
    ret = 0;
exit:

    amxc_string_clean(&header_str);
    return ret;
}

static uint32_t bulkdata_profile_http_retry_timeout(uint32_t interval_mult, uint32_t interval_min, profile_priv_t* private_data) {
    uint32_t ret = 0;
    uint32_t interval_max = 0;
    when_null(private_data, exit);

    if(1 == private_data->retry_attempts) {
        interval_max = interval_min * (interval_mult / 1000);
    } else {
        interval_max = interval_min * (interval_mult / 1000) * private_data->retry_attempts;
        interval_min = interval_min * (interval_mult / 1000) * (private_data->retry_attempts - 1);
    }

    ret = (rand() % (interval_max - interval_min)) + interval_min;
exit:
    return ret;
}

static void bulkdata_profile_http_exec_retry_cb(amxp_timer_t* timer, void* priv) {
    uint32_t retry_interval_multiplier = 0;
    uint32_t retry_minimum_wait_interval = 0;
    ftx_request_t* ftx_request = NULL;
    amxc_var_t* copy_var = NULL;

    amxd_object_t* profile = (amxd_object_t*) priv;
    when_null(profile, exit);

    profile_priv_t* private_data = (profile_priv_t*) profile->priv;
    when_null(private_data, exit);

    if(private_data->retry_attempts < HTTP_RETRY_MAX) {
        (private_data->retry_attempts)++;
    }
    retry_interval_multiplier = bulkdata_http_get_retry_interval_multiplier(amxd_object_get_child(profile, "HTTP"));
    retry_minimum_wait_interval = bulkdata_http_get_retry_minimum_wait_interval(amxd_object_get_child(profile, "HTTP"));
    private_data->retry_time = bulkdata_profile_http_retry_timeout(retry_interval_multiplier, retry_minimum_wait_interval, private_data);

    // stop the timer + restart it again with the new timeout
    SAH_TRACEZ_NOTICE(ME, "HTTP retry %d: next retry in %d seconds", private_data->retry_attempts, private_data->retry_time);
    amxp_timer_start(timer, 1000 * private_data->retry_time);

    // prepare a copy that will be user as http request userdata
    amxc_var_new(&copy_var);
    amxc_var_copy(copy_var, private_data->request_elements);

    // exec the retry http ftx_request
    if(0 != bulkdata_profile_http_send_ftx_request(ftx_request, copy_var)) {
        amxc_var_delete(&copy_var);
    }
exit:
    return;
}

static void bulkdata_profile_http_retry(amxc_var_t* ftx_userdata) {
    const cstring_t object_path = NULL;
    amxd_object_t* profile = NULL;
    amxp_timer_t* timer = NULL;
    profile_priv_t* profile_private_data = NULL;

    object_path = GET_CHAR(ftx_userdata, "path");
    when_null_trace(object_path, exit, ERROR, "Could not make the retry, object path is null");

    profile = amxd_dm_findf(bulkdata_get_dm(), "%s", object_path);
    when_null_trace(profile, exit, ERROR, "Could not make the retry, object not found");

    profile_private_data = profile->priv;
    when_null_trace(profile_private_data, exit, ERROR, "Could not make the retry, object priv is NULL");

    if(profile_private_data->retry_timer != NULL) {
        SAH_TRACEZ_INFO(ME, "Retry for profile '%s' is already ongoing, exit (nbr attempt %d)", object_path, profile_private_data->retry_attempts);
        goto exit;
    }

    // set the attempts
    profile_private_data->retry_attempts = 1;

    // compute timeout
    profile_private_data->retry_time = bulkdata_profile_http_retry_timeout(
        GET_INT32(ftx_userdata, "retry_interval_multiplier"),
        GET_INT32(ftx_userdata, "retry_minimum_wait_interval"),
        profile_private_data);

    // Create + start the retry timer (+ profile as priv data)
    amxp_timer_new(&timer, bulkdata_profile_http_exec_retry_cb, profile);
    profile_private_data->retry_timer = timer;
    amxp_timer_set_interval(timer, 1000);

    SAH_TRACEZ_NOTICE(ME, "HTTP next retry in %d seconds", profile_private_data->retry_time);
    amxp_timer_start(profile_private_data->retry_timer, 1000 * profile_private_data->retry_time);
exit:
    return;
}

static bool response_cb(ftx_request_t* req, void* userdata) {
    amxc_var_t* ftx_userdata = NULL;
    const cstring_t object_path = NULL;
    ftx_error_code_t error_code = ftx_error_code_no_error;
    bool retry_enabled = false;

    when_null(req, exit);
    when_null(userdata, exit);
    error_code = ftx_request_get_error_code(req);
    ftx_userdata = (amxc_var_t*) userdata;
    when_null(ftx_userdata, exit);

    object_path = GET_CHAR(ftx_userdata, "path");
    retry_enabled = GET_BOOL(userdata, "retry_enabled");

    when_null(object_path, exit);
    when_null(ftx_userdata, exit);
    if(error_code != ftx_error_code_no_error) {
        SAH_TRACEZ_ERROR(ME, "HTTP Response error code: (%u) reason: %s (profile '%s')",
                         error_code, ftx_request_get_error_reason(req), object_path);
        if(false == retry_enabled) {
            SAH_TRACEZ_INFO(ME, "Retry is not enbaled, request to be ignored");
        } else {
            SAH_TRACEZ_INFO(ME, "will Retry to send the message for profile %s", object_path);
            bulkdata_profile_http_retry(ftx_userdata);
        }
    } else {
        SAH_TRACEZ_INFO(ME, "HTTP request sent successfully for profile '%s'", object_path);
        // check if a retry was ongoing
        amxd_object_t* profile = amxd_dm_findf(bulkdata_get_dm(), "%s", object_path);
        when_null(profile, exit);
        profile_priv_t* profile_private_data = profile->priv;
        when_null(profile_private_data, exit);
        if(NULL != profile_private_data->retry_timer) {
            SAH_TRACEZ_INFO(ME, "http request sent successfully for profile after %d retries '%s'", profile_private_data->retry_attempts, object_path);
            amxp_timer_delete(&profile_private_data->retry_timer);
        }
    }

exit:
    amxc_var_delete(&ftx_userdata);
    ftx_userdata = NULL;
    ftx_request_delete(&req);
    return true;
}

static void bulkdata_profile_http_ftx_set_user_data(amxd_object_t* profile,
                                                    amxc_string_t* str,
                                                    cstring_t profile_instance_path,
                                                    amxc_var_t* userdata,
                                                    amxc_string_t* url) {
    amxd_object_t* http_obj = NULL;
    const char* password = NULL;
    const char* username = NULL;
    const char* encoding = NULL;
    const char* certificate = NULL;
    char* report_format = NULL;
    encoding = bulkdata_profile_get_encoding_type(profile);

    when_null_trace(str, exit, ERROR, "str is null");
    when_null_trace(profile_instance_path, exit, ERROR, "object path is null");
    when_null_trace(userdata, exit, ERROR, "userdata var is NULL!");

    http_obj = bulkdata_get_http_object(profile);
    when_null_trace(http_obj, exit, ERROR, "unable to get http object");

    password = bulkdata_http_get_password(http_obj);
    username = bulkdata_http_get_username(http_obj);
    certificate = bulkdata_http_get_certificate(http_obj);

    amxc_var_set_type(userdata, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, userdata, "url", amxc_string_get(url, 0));
    amxc_var_add_key(cstring_t, userdata, "path", profile_instance_path);
    amxc_var_add_key(cstring_t, userdata, "data", amxc_string_get(str, 0));
    amxc_var_add_key(bool, userdata, "retry_enabled", bulkdata_http_get_retry_enable(http_obj));
    amxc_var_add_key(uint32_t, userdata, "retry_minimum_wait_interval", bulkdata_http_get_retry_minimum_wait_interval(http_obj));
    amxc_var_add_key(uint32_t, userdata, "retry_interval_multiplier", bulkdata_http_get_retry_interval_multiplier(http_obj));
    if(username && (username[0] != '\0') && (password) && (password[0] != '\0')) {
        amxc_var_add_key(cstring_t, userdata, "username", username);
        amxc_var_add_key(cstring_t, userdata, "password", password);
    }
    if((NULL != certificate) && (certificate[0] != '\0')) {
        amxc_var_add_key(cstring_t, userdata, "certificate", certificate);
    }
    amxc_var_add_key(cstring_t, userdata, "method", bulkdata_http_get_method(http_obj));

    amxc_var_add_key(cstring_t, userdata, "encoding", encoding);
    amxc_var_add_key(cstring_t, userdata, "compression", bulkdata_http_get_compression(http_obj));

    if(strncmp(encoding, "JSON", strlen("JSON")) == 0) {
        report_format = amxd_object_get_value(cstring_t, amxd_object_get_child(profile, "JSONEncoding"), "ReportFormat", NULL);
    } else if(strncmp(encoding, "CSV", strlen("CSV")) == 0) {
        report_format = amxd_object_get_value(cstring_t, amxd_object_get_child(profile, "CSVEncoding"), "ReportFormat", NULL);
    }
    amxc_var_add_key(cstring_t, userdata, "report_format", report_format);

    amxc_var_add_key(bool, userdata, "user_date_header", bulkdata_http_get_use_date_header(http_obj));

exit:
    free(report_format);
    return;
}

static amxd_status_t bulkdata_profile_http_send_ftx_request(ftx_request_t* ftx_request, amxc_var_t* userdata) {
    amxd_status_t status = amxd_status_unknown_error;
    when_null_trace(userdata, exit, ERROR, "userdata var is NULL!");
    const cstring_t url = GET_CHAR(userdata, "url");
    const cstring_t username = GET_CHAR(userdata, "username");
    const cstring_t password = GET_CHAR(userdata, "password");
    const cstring_t certificate = GET_CHAR(userdata, "certificate");
    const cstring_t data_to_send = GET_CHAR(userdata, "data");
    const cstring_t method = GET_CHAR(userdata, "method");
    const cstring_t encoding = GET_CHAR(userdata, "encoding");
    const cstring_t compression = GET_CHAR(userdata, "compression");
    const cstring_t report_format = GET_CHAR(userdata, "report_format");
    bool user_date_header = GET_BOOL(userdata, "user_date_header");

    when_failed_trace(ftx_request_new(&ftx_request, ftx_request_type_stream, response_cb), exit, ERROR, "Could not allocate memory.");
    when_failed_trace(ftx_request_set_url(ftx_request, url), exit, ERROR, "URL does not set.");
    if((NULL != username) && (username[0] != '\0') && (NULL != password) && (password[0] != '\0')) {
        when_failed_trace(ftx_request_set_credentials(ftx_request, ftx_authentication_any, username, password), exit, ERROR, "Credentials Error.");
    }
    if((NULL != certificate) && (certificate[0] != '\0')) {
        when_failed_trace(ftx_request_set_ca_certificates(ftx_request, certificate, NULL), exit, ERROR, "Unable to set certificate");
    }
    when_failed_trace(ftx_request_set_data(ftx_request, (void*) userdata), exit, ERROR, "Could not set userdata.");
    when_failed_trace(ftx_request_set_data_stream(ftx_request, data_to_send), exit, ERROR, "Could not set stream data.");
    if(strncmp(method, "POST", strlen("POST")) == 0) {
        when_failed_trace(ftx_request_set_upload_method(ftx_request, ftx_upload_method_post), exit, ERROR, "Could not set upload method.");
    } else {
        when_failed_trace(ftx_request_set_upload_method(ftx_request, ftx_upload_method_put), exit, ERROR, "Could not set upload method.");
    }

    when_failed_trace(http_request_set_header(ftx_request, encoding, compression, report_format, user_date_header), exit, ERROR, "Could not set header");
    when_failed_trace(ftx_request_send(ftx_request), exit, ERROR, "The send ftx_request failed.");
    SAH_TRACEZ_INFO(ME, "HTTP message was sent (profile %s)", GET_CHAR(userdata, "path"));

    status = amxd_status_ok;
exit:
    return status;
}

static amxd_status_t bulkdata_profile_http_perform_request(amxd_object_t* profile, amxc_string_t* str, amxc_string_t* url) {
    amxd_status_t status = amxd_status_unknown_error;
    ftx_request_t* ftx_request = NULL;
    amxc_var_t* ftx_userdata = NULL;
    amxc_var_t* profile_priv_data_elements = NULL;
    cstring_t profile_instance_path = NULL;
    profile_priv_t* profile_private_data = NULL;

    amxc_var_new(&ftx_userdata);
    amxc_var_new(&profile_priv_data_elements);

    when_null_trace(str, exit, ERROR, "string is null");
    when_null_trace(profile, exit, ERROR, "object is null");

    profile_instance_path = amxd_object_get_path(profile, AMXD_OBJECT_NAMED);

    // prepare the HTTP request userdata
    bulkdata_profile_http_ftx_set_user_data(profile, str, profile_instance_path, ftx_userdata, url);

    // set profile user_data
    amxc_var_copy(profile_priv_data_elements, ftx_userdata);
    profile_private_data = (profile_priv_t*) profile->priv;
    if(NULL != profile_private_data->request_elements) {
        amxc_var_delete(&profile_private_data->request_elements);
    }
    profile_private_data->request_elements = profile_priv_data_elements;

    // send the http request
    when_failed_trace(bulkdata_profile_http_send_ftx_request(ftx_request, ftx_userdata), fail, ERROR, "The send request failed.");
    status = amxd_status_ok;

exit:
    free(profile_instance_path);
    return status;

fail:
    amxc_var_delete(&ftx_userdata);
    ftx_userdata = NULL;
    ftx_request_delete(&ftx_request);
    free(profile_instance_path);
    return status;
}

static size_t bulkdata_profile_http_prepare_data(amxd_object_t* profile, amxc_var_t* data, amxc_string_t* ouput) {
    size_t res = 0;
    const cstring_t string = NULL;
    const cstring_t encoding = NULL;
    const cstring_t compression = NULL;
    amxd_object_t* http_obj = NULL;

    when_null_trace(ouput, exit, ERROR, "output is null!");
    when_null_trace(data, exit, ERROR, "data is null!");
    when_null_trace(profile, exit, ERROR, "profile is null!");

    http_obj = bulkdata_get_http_object(profile);
    when_null_trace(http_obj, exit, ERROR, "unable to get http object");

    encoding = bulkdata_profile_get_encoding_type(profile);
    when_str_empty_trace(encoding, exit, ERROR, "encoding is empty!");

    compression = bulkdata_http_get_compression(http_obj);
    when_str_empty_trace(compression, exit, ERROR, "compression is empty!");

    if(strncmp(encoding, "JSON", sizeof("JSON")) == 0) {
        amxc_var_cast(data, AMXC_VAR_ID_JSON);
        string = amxc_var_constcast(jstring_t, data);
        when_str_empty_trace(string, exit, ERROR, "string to be send is empty");
    } else if(strncmp(encoding, "CSV", sizeof("CSV")) == 0) {
        amxc_var_cast(data, AMXC_VAR_ID_CSV_STRING);
        string = amxc_var_constcast(csv_string_t, data);
        when_str_empty_trace(string, exit, ERROR, "string to be send is empty");
    } else {
        goto exit;
    }

    res = strlen(string);
    amxc_string_append(ouput, string, res);

    if(strncmp(compression, "GZIP", sizeof("GZIP")) == 0) {
        // todo
    }

exit:
    return res;
}

int bulkdata_profile_http_send_data(amxd_object_t* profile, amxc_var_t* json) {
    amxd_status_t status = amxd_status_unknown_error;
    amxc_string_t data_to_send;
    size_t data_to_send_len = 0;
    amxd_object_t* uri_params = NULL;
    amxd_object_t* http_obj = NULL;
    amxc_string_t* composed_url;
    const cstring_t url = NULL;

    amxc_string_init(&data_to_send, 0);
    amxc_string_new(&composed_url, 0);

    http_obj = bulkdata_get_http_object(profile);
    when_null_trace(http_obj, exit, ERROR, "unable to get http object");

    url = bulkdata_http_get_url(http_obj);
    amxc_string_setf(composed_url, "%s", url);

    uri_params = bulkdata_get_request_uri_parameter_object(http_obj);
    status = bulkdata_request_uri_parameter_get_full_url(uri_params, composed_url);
    when_failed_trace(status, exit, ERROR, "Unable to get the url");

    data_to_send_len = bulkdata_profile_http_prepare_data(profile, json, &data_to_send);
    when_true_trace((data_to_send_len == 0), exit, ERROR, "error: Data to be sent empty, so be ignored");

    status = bulkdata_profile_http_perform_request(profile, &data_to_send, composed_url);
    when_failed_trace(status, exit, ERROR, "sending http request failed");

exit:
    amxc_string_clean(&data_to_send);
    amxc_string_delete(&composed_url);
    return status;
}
