/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "test_promise.h"

void test_promise_is_pending_after_creation(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // it is in pending state
    assert_true(amxp_promise_is_pending(p1));
    assert_false(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));

    // when deleting a pending promise
    // the cancel callback is called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);

    amxp_promise_delete(&p1);
}

void test_promise_can_reject_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected
    assert_int_equal(amxp_promise_reject(p1, 10), 0);
    // it is in rejected state
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
    // and the status is propagated
    assert_int_equal(amxp_promise_get_status(p1), 10);

    amxp_promise_delete(&p1);
}

void test_promise_reject_with_status_0_sets_rejected_status(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected with AMXP_PROMISE_STATUS_OK
    assert_int_equal(amxp_promise_reject(p1, AMXP_PROMISE_STATUS_OK), AMXP_PROMISE_STATUS_OK);
    // it is in rejected state
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
    // and the status is set to AMXP_PROMISE_STATUS_REJECTED
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_REJECTED);

    amxp_promise_delete(&p1);
}

void test_promise_can_fulfill_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is fulfilled
    assert_int_equal(amxp_promise_fulfill(p1, NULL), 0);
    // it is in fulfilled state
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_false(amxp_promise_is_rejected(p1));
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);
}

void test_promise_can_not_change_state_after_settled(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_OK);
    // subsequent state changes are failing
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_REJECTED);
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_REJECTED);

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    // subsequent state changes are failing
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_FULFILLED);
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_FULFILLED);

    amxp_promise_delete(&p1);
}

void test_promise_calls_correct_callback_when_rejected(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and rejected callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), 0);
    // and it is rejected it is expected that the reject callback is called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 10);
    expect_value(rejected_callback, promise, p1);
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and settled callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, rejected_callback, NULL), 0);
    // and it is rejected it is expected that the reject callback is called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 10);
    expect_value(rejected_callback, promise, p1);
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&p1);
}

void test_promise_calls_correct_callback_when_fulfilled(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxc_var_t data;
    int result = 0;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "TestField1", "Hello");
    amxc_var_add_key(cstring_t, &data, "TestField2", "World");
    amxc_var_add_key(cstring_t, &data, "Number", "666");

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and rejected callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), 0);
    // and it is rejected it is expected that the reject callback is called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, 0);
    expect_value(fulfilled_callback, promise, p1);
    assert_int_equal(amxp_promise_fulfill(p1, &data), AMXP_PROMISE_STATUS_OK);

    // The future of the promise must be matching the passed data
    amxc_var_compare(&data, amxp_promise_get_future(p1), &result);
    assert_int_equal(result, 0);

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and rejected callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, fulfilled_callback, NULL), 0);
    // and it is rejected it is expected that the reject callback is called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, 0);
    expect_value(fulfilled_callback, promise, p1);
    assert_int_equal(amxp_promise_fulfill(p1, &data), AMXP_PROMISE_STATUS_OK);

    // The future of the promise must be matching the passed data
    amxc_var_compare(&data, amxp_promise_get_future(p1), &result);
    assert_int_equal(result, 0);

    amxp_promise_delete(&p1);

    amxc_var_clean(&data);
}

void test_promise_set_callback_on_pending_state_fails(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // setting callback function on pending state fails
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_pending, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // when deleting a pending promise
    // the cancel callback is called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);

    amxp_promise_delete(&p1);
}

void test_promise_calls_cancel_callback_when_deleted(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    uint32_t number = 100;
    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, &number), 0);
    // and deleted before it is settled
    // the cancel callback is expected to be called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number);

    amxp_promise_delete(&p1);
}

void test_promise_is_not_waitable_by_default(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // it is not waitable by default
    assert_false(amxp_promise_is_waitable(p1));
    // and wait will return not supported
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // and deleted before it is settled
    // the cancel callback is expected to be called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);

    amxp_promise_delete(&p1);
}

void test_promise_settled_promise_is_waitable(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected
    assert_int_equal(amxp_promise_reject(p1, 10), AMXP_PROMISE_STATUS_OK);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // and wait will return immediately
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is rejected
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // and wait will return immediately
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&p1);
}

void test_promise_with_wait_function_is_waitable(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    uint32_t number = 100;

    // when a promise is created with wait function
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_fulfill, &number), 0);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // amxp_promise_wait must call the wait function
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number);
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);
    // and when the wait returns the promise must be settled
    assert_true(amxp_promise_is_settled(p1));

    amxp_promise_delete(&p1);

    // when a promise is created with wait function
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_reject, &number), 0);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // amxp_promise_wait must call the wait function
    expect_function_call(wait_reject);
    expect_value(wait_reject, provider_priv, &number);
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);
    // and when the wait returns the promise must be settled
    assert_true(amxp_promise_is_settled(p1));

    amxp_promise_delete(&p1);
}

void test_promise_with_wait_can_delete_promise_in_settled_callbacks(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    uint32_t number = 100;

    // when a promise is created with wait function
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_fulfill, &number), 0);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // and when settled callback is installed which deletes the promise
    amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_deletes, NULL);
    // and when amxp_promise_wait is called
    // - the settled callback function must be called
    expect_function_call(settle_callback_deletes);
    expect_value(settle_callback_deletes, promise, p1);
    expect_value(settle_callback_deletes, status, AMXP_PROMISE_STATUS_OK);
    expect_value(settle_callback_deletes, state, amxp_promise_state_fulfilled);
    // - amxp_promise_wait must call the wait function
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number);
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);
    // and when the wait returns the promise is deleted
}

void test_promise_failed_wait_error_code_is_propagated(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    uint32_t number = 100;

    // when a promise is created with wait function
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_fail, &number), 0);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // amxp_promise_wait must call the wait function
    expect_function_call(wait_fail);
    expect_value(wait_fail, provider_priv, &number);
    // and the error code if the wait fails must be propagated
    assert_int_equal(amxp_promise_wait(p1, 5000), 1001);
    // and when the wait returns the promise must be settled
    assert_true(amxp_promise_is_settled(p1));

    amxp_promise_delete(&p1);
}

void test_promise_after_wait_the_promise_must_be_settled(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    uint32_t number = 100;

    // when a promise is created with wait function
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_success_not_resolving, &number), 0);
    // it is waitable
    assert_true(amxp_promise_is_waitable(p1));
    // amxp_promise_wait must call the wait function
    expect_function_call(wait_success_not_resolving);
    expect_value(wait_success_not_resolving, provider_priv, &number);
    // and the error code if the wait fails must be propagated
    assert_int_equal(amxp_promise_wait(p1, 5000), AMXP_PROMISE_STATUS_OK);
    // and when the wait returns the promise must be settled
    assert_true(amxp_promise_is_settled(p1));

    amxp_promise_delete(&p1);
}

void test_promise_take_future_hands_over_ownership(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxc_var_t data;
    int result = 0;
    amxc_var_t* future = NULL;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "TestField1", "Hello");
    amxc_var_add_key(cstring_t, &data, "TestField2", "World");
    amxc_var_add_key(cstring_t, &data, "Number", "666");

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and it is fulfilled
    assert_int_equal(amxp_promise_fulfill(p1, &data), AMXP_PROMISE_STATUS_OK);
    // the ownership of the future can be taken
    future = amxp_promise_take_future(p1);
    amxc_var_compare(&data, future, &result);
    assert_int_equal(result, 0);

    // and the future is not available any more in the promise
    assert_null(amxp_promise_get_future(p1));
    assert_null(amxp_promise_take_future(p1));

    // the taken future must be deleted
    amxc_var_delete(&future);

    amxp_promise_delete(&p1);
    amxc_var_clean(&data);
}

void test_promise_take_future_fails_when_pending(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and is still pending
    // then taking the future returns a NULL pointer
    assert_null(amxp_promise_take_future(p1));

    // and deleted before it is settled
    // the cancel callback is expected to be called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);

    amxp_promise_delete(&p1);
}

void test_promise_api_can_handle_null_pointers_as_input(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // mainly check if the functions are failing gracefully
    // and dont cause a crash or segmentation fault on NULL pointer
    // input arguments.
    assert_int_equal(amxp_promise_new(NULL, NULL, NULL, NULL), -1);
    assert_int_equal(amxp_promise_new(&p1, NULL, NULL, NULL), -1);
    amxp_promise_delete(NULL);
    amxp_promise_delete(&p1);
    assert_int_equal(amxp_promise_fulfill(NULL, NULL), -1);
    assert_int_equal(amxp_promise_reject(NULL, 0), -1);
    assert_int_equal(amxp_promise_when(NULL, amxp_promise_state_rejected, NULL, NULL), -1);
    assert_int_equal(amxp_promise_wait(NULL, 5000), -1);
    assert_false(amxp_promise_is_rejected(NULL));
    assert_false(amxp_promise_is_fulfilled(NULL));
    assert_false(amxp_promise_is_settled(NULL));
    assert_false(amxp_promise_is_pending(NULL));
    assert_false(amxp_promise_is_waitable(NULL));
    assert_int_equal(amxp_promise_get_status(NULL), -1);
    assert_null(amxp_promise_get_future(NULL));
    assert_null(amxp_promise_take_future(NULL));
}

void test_promise_is_automatically_rejected_after_timeout(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(p1, 1000), AMXP_PROMISE_STATUS_OK);
    // a timer must be set on the promise
    assert_non_null(p1->reject_timer);
    // the promise is rejected if not settled within the given time
    // and the rejected callback is expected to be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(rejected_callback, promise, p1);
    // and the cancel callback is expected to be called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);
    // emulate event-loop and watch SIGALRM
    read_sigalrm();

    // and the timer is deleted
    assert_null(p1->reject_timer);

    // after the timeout the promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
    // and the status is set to timeout
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_TIMEOUT);

    amxp_promise_delete(&p1);
}

void test_promise_reject_after_timeout_can_be_changed(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;
    amxp_timer_t* reject_timer = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(p1, 1000), AMXP_PROMISE_STATUS_OK);

    // a timer must be set on the promise
    assert_non_null(p1->reject_timer);
    reject_timer = p1->reject_timer;
    assert_int_equal(amxp_timer_remaining_time(p1->reject_timer), 1000);
    assert_int_equal(amxp_timer_get_state(p1->reject_timer), amxp_timer_running);

    usleep(500);
    amxp_timers_calculate();
    assert_true(amxp_timer_remaining_time(p1->reject_timer) < 1000);

    // when a reject timeout is set again
    assert_int_equal(amxp_promise_reject_after(p1, 1000), AMXP_PROMISE_STATUS_OK);
    // it only updates the time out of the timer
    assert_non_null(p1->reject_timer);
    assert_ptr_equal(reject_timer, p1->reject_timer);
    // and the timer is restarted
    assert_int_equal(amxp_timer_remaining_time(p1->reject_timer), 1000);
    assert_int_equal(amxp_timer_get_state(p1->reject_timer), amxp_timer_running);

    // the promise is rejected if not settled within the given time
    // and the rejected callback is expected to be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(rejected_callback, promise, p1);
    // and the cancel callback is expected to be called
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, NULL);
    // emulate event-loop and watch SIGALRM
    read_sigalrm();

    // and the timer is deleted
    assert_null(p1->reject_timer);

    // after the timeout the promise must be rejected
    assert_false(amxp_promise_is_pending(p1));
    assert_true(amxp_promise_is_settled(p1));
    assert_true(amxp_promise_is_rejected(p1));
    assert_false(amxp_promise_is_fulfilled(p1));
    // and the status is set to timeout
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_TIMEOUT);

    amxp_promise_delete(&p1);
}

void test_promise_settle_callback_misbehaves(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and a settle callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_rejects, NULL), AMXP_PROMISE_STATUS_OK);
    // and is fulfilled
    // the callback must be called
    expect_function_call(settle_callback_rejects);
    expect_value(settle_callback_rejects, promise, p1);
    expect_value(settle_callback_rejects, status, AMXP_PROMISE_STATUS_OK);
    expect_value(settle_callback_rejects, state, amxp_promise_state_fulfilled);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    // the state can not be changed by the callback
    assert_true(amxp_promise_is_fulfilled(p1));

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and a settle callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_fulfills, NULL), AMXP_PROMISE_STATUS_OK);
    // and is rejected
    // the callback must be called
    expect_function_call(settle_callback_fulfills);
    expect_value(settle_callback_fulfills, promise, p1);
    expect_value(settle_callback_fulfills, status, 666);
    expect_value(settle_callback_fulfills, state, amxp_promise_state_rejected);
    assert_int_equal(amxp_promise_reject(p1, 666), AMXP_PROMISE_STATUS_OK);
    // the state can not be changed by the callback
    assert_true(amxp_promise_is_rejected(p1));

    amxp_promise_delete(&p1);
}

void test_promise_settle_callback_deletes_promise(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and a settle callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_deletes, NULL), AMXP_PROMISE_STATUS_OK);
    // and is fulfilled
    // the callback must be called
    expect_function_call(settle_callback_deletes);
    expect_value(settle_callback_deletes, promise, p1);
    expect_value(settle_callback_deletes, status, AMXP_PROMISE_STATUS_OK);
    expect_value(settle_callback_deletes, state, amxp_promise_state_fulfilled);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);

    // the promise is deleted in the callback.

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, NULL, NULL), 0);
    // and a settle callback is set
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_settled, settle_callback_deletes, NULL), AMXP_PROMISE_STATUS_OK);
    // and is rejected
    // the callback must be called
    expect_function_call(settle_callback_deletes);
    expect_value(settle_callback_deletes, promise, p1);
    expect_value(settle_callback_deletes, status, 666);
    expect_value(settle_callback_deletes, state, amxp_promise_state_rejected);
    assert_int_equal(amxp_promise_reject(p1, 666), AMXP_PROMISE_STATUS_OK);

    // the promise is deleted in the callback.
    // the pointer here is not valid anymore
    // don't call delete again
}

void test_promise_misbehaving_cancel_function(UNUSED void** state) {
    amxp_promise_t* p1 = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback_deletes, NULL, NULL), 0);
    // and deleted
    // the cancel callback must be called
    expect_function_call(cancel_callback_deletes);

    amxp_promise_delete(&p1);

    // when a promise is created
    assert_int_equal(amxp_promise_new(&p1, cancel_callback_fulfills, NULL, NULL), 0);
    // and rejected and fulfilled callbacks are installed
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(p1, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and deleted
    // the rejected callback must be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, promise, p1);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    // and the cancel callback must be called
    expect_function_call(cancel_callback_fulfills);
    // fulfilled callback should not be called, event if the cancel calbackk fulfills the promise.
    amxp_promise_delete(&p1);
}

