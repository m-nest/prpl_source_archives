/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__TR_DDNS_H__)
#define __TR_DDNS_H__

#ifdef __cplusplus
extern "C" {
#endif
#include <amxc/amxc.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <netmodel/common_api.h>

#define str_empty(x) ((x == NULL) || (*x == '\0'))

#define FREE(X) do { \
        if(X != NULL) { \
            free(X); \
            X = NULL; \
        } \
}while(0);

#define DEFAULT_SET_PATH_FLAGS AMXC_VAR_FLAG_AUTO_ADD | AMXC_VAR_FLAG_COPY

// module names
#define MOD_DDNS_CTRL "ddns-cfgctrlr"
#define MOD_DDNS_ADD_SERVICE

#define DDNS          "DynamicDNS"

#define DDNS_SUPPORTED_SERVICES "SupportedServices"

// #define CLIENT_ALIAS          "Alias"
#define CLIENT_ENABLE         "Enable"
#define CLIENT_SERVER         "Server"
#define CLIENT_INTERFACE      "Interface"
#define CLIENT_IPVERSION      "IPVersion"
#define CLIENT_IP_INTERFACE   "IPInterfaceRef"
#define CLIENT_IP             "IP"
#define CLIENT_DNS            "DNSServer"
#define CLIENT_USERNAME       "Username"
#define CLIENT_PASSWORD       "Password"

#define CLIENT_HOSTNAME_ENABLE "Enable"
#define CLIENT_HOSTNAME_NAME   "Name"
#define CLIENT_HOSTNAME_LAST_UPDATE "LastUpdate"

#define SERVER_NAME           "Name"
#define SERVER_SERVICE        "ServiceName"
#define SERVER_ADDRESS        "ServerAddress"
#define SERVER_PORT           "ServerPort"
#define SERVER_PROTOCOL       "Protocol"
#define SERVER_CHECK_INTERVAL "CheckInterval"
#define SERVER_RETRY_INTERVAL "RetryInterval"
#define SERVER_MAX_RETRIES    "MaxRetries"
#define SERVER_ENABLE         "Enable"
#define SERVER_ORIGIN         "Origin"

#define SERVER_ORIGIN_USER    "User"
#define SERVER_ORIGIN_MOD     "Module"

#define MOD_DOMAIN            "Domain"
#define MOD_FORCE_IPVERSION   "force_ipversion"
#define MOD_USE_IPV6          "use_ipv6"
#define MOD_IP_SOURCE         "ip_source"

#define DDNS_IP_TMP           "/tmp/ddns_ip"

typedef struct _dynamic_dns {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxb_bus_ctx_t* ctx;                        // bus context
    amxb_bus_ctx_t* dns_ctx;
    amxp_timer_t* dns_timer;
    int count_timer;
} dynamic_dns_t;

#ifdef __cplusplus
}
#endif

#endif // __TR_DDNS_H__
