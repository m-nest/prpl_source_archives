#include "helpers.h"
#include "mod_usb_filter.h"

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <ctype.h>
#include <string.h>

/**
 * @brief Return hex value or empty string.
 *
 * @param src String that may contain a hexadecimal value.
 * @return Hexadecimal value or empty string ("").
 */
char* set_hex_value(const char* src) {
    char* result = NULL;

    when_null(src, exit);

    result = strdup(src);

exit:
    if(result == NULL) {
        result = strdup("");
    }

    return result;
}

/**
 * @brief Converts a number to a hexadecimal string.
 *
 * @param i unsigned integer value
 * @return Hexadecimal value or empty string ("").
 */
char* int_to_hex_value(uint32_t i) {
    char* result = NULL;
    char buffer[5];

    when_true(i > 0xFFFF, exit);
    when_false(sprintf(buffer, "%X", i) > 0, exit);
    result = set_hex_value(buffer);

exit:
    if(result == NULL) {
        result = strdup("");
    }

    return result;
}

/**
 * @brief Verifies whether a hexadecimal string is allowed or not.
 *
 * @param allowed_str String containing hexadecimal characters and or wildcards as defined in tr181.
 * @param value Hexadecimal string that needs to be verified.
 * @return true when valid, false otherwise.
 */
bool is_valid_hex_number(char* allowed_str, char* value) {
    bool valid = false;
    size_t i = 0;
    size_t diff = 0;

    when_null(allowed_str, exit);
    when_str_empty_status(allowed_str, exit, valid = true);
    when_true_status(strcmp(allowed_str, "*") == 0, exit, valid = true);
    when_true_status(strcmp(allowed_str, value) == 0, exit, valid = true);

    if(strlen(allowed_str) != strlen(value)) {
        size_t j = 0;
        when_null(strstr(allowed_str, "*"), exit); // No wildcards in allowed_str
        when_true(strlen(allowed_str) < strlen(value), exit);

        diff = strlen(allowed_str) - strlen(value);
        for(j = 0; j < diff; j++) {
            when_false(allowed_str[j] == '*', exit);
        }
    }

    for(i = 0; i < strlen(value); i++) {
        // In case allowed_str is longer than value it must be prepended by wildcards, as validated in the if block above.
        // We don't have to validate them again so move up the allowed_str in this comparison.
        when_true(allowed_str[i + diff] != '*' && (tolower(allowed_str[i + diff]) != tolower(value[i])), exit);
    }

    valid = true;

exit:
    return valid;
}

/**
 * @brief Verifies whether a USB device interface is allowed or not.
 *
 * @param allowed_intf Internal usb interface structure containing hexadecimal values and/or wildcards.
 * @param value Internal usb interface that needs to be verified
 * @return true when valid, false otherwise
 */
bool is_valid_interface(usb_device_interface_t* allowed_intf, usb_device_interface_t* value) {
    bool valid = false;

    when_null_trace(allowed_intf, exit, ERROR, "AllowedIntf NULL");
    when_null_trace(value, exit, ERROR, "Value NULL");

    when_false(is_valid_hex_number(allowed_intf->interface_class, value->interface_class), exit);
    when_false(is_valid_hex_number(allowed_intf->interface_subclass, value->interface_subclass), exit);
    valid = is_valid_hex_number(allowed_intf->interface_protocol, value->interface_protocol);

exit:
    return valid;
}
