
# **Amx-ProcessMonitor Plugin for prplOS**

## **Summary**

A plugin designed to monitor the health and reliability of TR-181/prplWare services within prplOS.

## **Description**

The **Amx-ProcessMonitor** plugin periodically evaluates the health of TR-181/prplWare services based on a configurable test interval. Depending on the service type—**Plugin**, **Process**, or **Custom**—it performs appropriate health checks, updates health status and logs timestamps.

It supports configurable failure handling actions such as **restart**, **reboot**, or custom-defined responses when failure thresholds are exceeded.

Additionally, it:
- Listens to **procd** events to track service restarts and failures.
- Maintains statistics on **maximum failure count** and **maximum failure duration**.
- Integrates with the **TR-181 data model** to expose **procd** respawn parameters.

## **Installation**

You can build and install the Amx-ProcessMonitor by running:

```bash
make && sudo make install
```

### **Compile and Install**

```bash
make
sudo make install
```

### **Run Test**

```bash
make test
```

### **Run Plugin Inside an Ambiorix Docker Container**

Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

**Compile/install dependencies** (`make && sudo make install`):

- libsahtrace
- libamxb
- libamxc
- libamxd
- libamxo
- libamxp
- libubus
- libubox

## **General Requirements**

- Implement the proposed **TR-181 data model**.
- Act as a **health checker** for prplWare services, ensuring they are running and responsive.
- Interact with configured **prplOS components** to report service status or trigger recovery actions.
- Support modeling of **process failures and respawns** configured via `procd`, including:
  - Maximum failure count
  - Recovery duration
- Persist configuration settings for consistent behavior across reboots.

## **Implementation**

- **Amx-ProcessMonitor Core**: Provides high-level APIs for dynamic interface management and service monitoring.
- **Periodic Monitoring**: Utilizes Amx Timer interfaces to execute health checks at defined intervals, ensuring continuous service evaluation.
- **Health Check Verification API**:
  - Uses `ubus._get()` for plugin-based services.
  - Verifies process health via PID file checks.
  - Executes and evaluates custom scripts based on exit status.
- **procd Integration**: Subscribes to `ubus` service events to collect runtime statistics and update TR-181 data models accordingly.
- **Data Model Population**: Automatically reflects monitoring results in TR-181 objects for real-time visibility.

## **Amx-ProcessMonitor Enhancements**

### **Background**

- Before prplOS 4.1.0:

    - Amx-ProcessMonitor handles prplWare service monitoring and recovery independently, without utilizing the OpenWrt procd framework. This results in increased load, performance bottlenecks, and reduced system stability due to the lack of efficient process management and respawning

    - configured services were monitored sequentially using a cyclic duration. This caused delays in detecting service unavailability and reduced gateway reliability.

    - MaxFail statistics prior to recovery were not captured during monitoring, limiting the depth of failure analysis. Additionally, intentionally shut-down services continued to be monitored by the Amx Process Monitor, leading to inaccurate reporting and unnecessary resource consumption

- With prplOs 4.1.0 (implements Amx process monitor Enhancements):

    - Service monitoring and automatic respawning are now handled by the OpenWrt process management framework — **procd**. However, Amx-ProcessMonitor still detects process hangs when **procd** respawn attempts are exhausted and takes recovery actions if needed.

    - Each monitored process can have an independent testing frequency, allowing higher-priority processes to be tested more frequently.

    - **Event Listening and Statistics Collection**: Amx-ProcessMonitor now listens to **procd** events (`instance.fail`, `instance.respawn`) on `ubus`. This enables tracking of process restarts and failures handled by **procd**.

    - Added capabilities to records statistics on periodic monitoring:
        - Maximum failures before recovery
        - Maximum duration taken to recover

    - Amx-ProcessMonitor now avoids monitoring services that are intentionally shut down, improving accuracy and reducing unnecessary resource usage.

### **Functions**

- Deprecate the cyclic duration principle. Services are now monitored starting from the nearest possible test interval, with a minimum threshold interval of 500 ms between tests to reduce CPU load and improve system performance.

- Listen to **procd** events:
  - `instance.fail` and `instance.stop` to track process failures and take recovery actions.
  - `instance.respawn` to track automatic respawns triggered by **procd**.
  - Use `instance.fail` to detect process hangs when **procd** respawn attempts are exhausted.

- Ensure backward compatibility with existing non-**procd**-based monitoring mechanisms, including failure detection, recovery procedures, and reboot strategies.

- Record statistics on:
  - Maximum duration taken for recovery
  - Maximum time a service remained in a failed state before recovery

- Improve monitoring accuracy by supervising only active and eligible services.

### **Implementation Recommendations**

- Use **procd**-based monitoring as the primary mechanism. If sufficient, do not configure the service in Amx-ProcessMonitor.

- Only configure Amx-ProcessMonitor for critical prplWare services where additional hung detection and recovery actions are required.

- Choose the `test_interval` wisely. While it can be as low as 3 seconds, it should be based on the number of test entries and their monitoring priority to avoid overloading the gateway. The default is 60 seconds.

- A `test_interval` of 0 disables monitoring for that service.

- If additional restarts are needed before rebooting the gateway (e.g., when **procd** retries are exhausted), configure a reboot threshold greater than 0 and set the failure action to **restart** instead of **reboot**.

- **Test Entry Naming Convention** (used for scheduling):
  - `11_<prplWareName>`: For services where failure action is gateway reboot (no restart)
  - `21_<prplWareName>`: Data plane services
  - `31_<prplWareName>`: Control plane services
  - `41_<prplWareName>`: Management plane services

# Configuring `amx-processmonitor` plugin

## 🚀 Startup Instructions

Once built and installed with the prplOS image, the amx-processmonitor auto-starts at boot via the init script.

### Manual Start Options

1. **Via symbolic link** (no arguments required):
   ```bash
   $ amx-processmonitor
   ```

2. **Via AMX runtime**:
   ```bash
   $ amxrt /etc/amx/amx-processmonitor/amx-processmonitor.odl
   ```

---

## 🔍 Verifying Data Model Availability

After launch, confirm the data model is active:

```bash
$ ubus list | grep "ProcessMonitor"
```

You should see entries like:
```
ProcessMonitor
ProcessMonitor.Test
ProcessMonitor.Test.1
ProcessMonitor.Test.1.ProcessRespawnParams
...
```

---

## 📚 Exploring Methods and Parameters

### List Available Methods

```bash
$ ubus -v list ProcessMonitor.Test
```

Key methods include:
- `_get`, `_set`, `_add`, `_del`, `reset`
- `_describe`, `_exec`, `set_trace_zone`, `list_trace_zones`

### Retrieve Parameters of a Test Object

```bash
$ ubus call ProcessMonitor.Test.1 _get
```

Returns details like:
- `Health`, `TestInterval`, `FailAction`, `NumFailed`, `LastSuccess`, etc.
---

## 🧪 Managing Test Objects

### Add new Test

Now let's invoke the `_add` method. This method will add the new Test Instance to the Amx process monitor - `ProcessMonitor.Test[]` object using the parameters passed to it.

```bash
$  ubus call ProcessMonitor.Test _add '{"parameters":{"Nam
e":"pcm-manager", "Subject":"PCM"}}'
..
..
{
        "amxd-error-code": 0
}
```

### Delete the existing Test


Now let's invoke the `_del` method. This method will delete the existing Test on the Amx process monitor - ProcessMonitor.Test[] object based on the index (or) Test name passed to it

```bash
$ ubus call ProcessMonitor.Test _del '{"index":10}'
..
..
{
        "amxd-error-code": 0
}
```

### Reset the existing Test
Now let's invoke the `reset` method. This method will reset the test parameters on the Amx process monitor - ProcessMonitor.Test.n with its default values

```bash
$ ubus call ProcessMonitor.Test.35 reset
{
        "retval": ""
}
{
        "amxd-error-code": 0
}
```
---

## ⚙️ Real Time Functionality Aspects

Each `Test` instance defines a monitoring configuration. At minimum, the following parameters must be set:
- `Type`: Specifies the test type (`Plugin`, `Process`, or `Custom`)
- `Subject`: Defines the target of the test
- `MaxFailNum` and/or `MaxFailDuration`: Set thresholds for failure detection

If the configuration is invalid, the `Health` parameter will reflect the issue.

Each test can be configured with a `TestInterval`, which determines how frequently the test is executed. 

After a failure, the monitor checks whether either `MaxFailNum` or `MaxFailDuration` thresholds have been exceeded. if exceeded, Amx process monitor would perform the recovery action - Rebbot/Restart/No action

Detailed explanation on the configuration are provided as below

---

## 🧪 Test Types/Subject

The Amx Process Monitor supports three test types, configured via the `Type` and `Subject` parameters:

- **Plugin**: Verifies if an Ambiorix service is active by querying it over the system bus. The `Subject` should be a valid bus path—either the plugin’s root or any subpath.

- **Process**: Checks whether a process is running. The `Subject` can be a PID (`integer ≥ 1`) or a PID file (e.g., `/var/run/xxx.pid`).

- **Custom**: Executes a user-defined command that must exit with code `0` to be considered successful. If the command exceeds 5 seconds, it is treated as a failure.

---

## Test Configuration Parameters

### ⏱️ Test Interval

This interval defines the minimum wait time before a test is executed again. It ensures that each test can be individually configured with its own frequency, allowing prioritization based on the criticality of the monitored service.

### ⏱️ Current Test Interval

A read-only parameter that reflects the active test interval, including any dynamic adjustments due to failures and the configured multiplier.

### ⏱️ TestIntervalMultiplier

After each test failure, the interval is multiplied by this value to delay the next check. The adjusted interval will not exceed `MaxFailDuration`, if set.

### ⏱️ TestResetInterval

Defines how long a test runs before its interval resets to the original value. Default is 60 minutes, allowing sufficient time between resets.

----

### 🔁 Recovery Actions

If failure thresholds are met, the amx-process monitor inspects the `FailAction` parameter:

- If `FailAction` includes `"REBOOT"`, the system initiates a reboot sequence.
- Otherwise, the monitor executes the specified recovery command using a system call.

Once a reboot is triggered, all tests are suspended. If a test causes more reboots than allowed by the `MaxReboot` parameter, further reboots are suppressed to prevent a reboot loop.


### 🔄 Restart

When a monitored service exceeds its failure threshold, the amx-process monitor attempts a restart:

- Uses the `Name` parameter to identify the service.
- Executes `/etc/init.d/${Name} restart` to restart via its init script.
- If a reboot threshold is configured and with repeated restarts fail action beyond this threshold,  still it fails - a system reboot is triggered to preserve stability.

### 🔁 Reboot

If a reboot is required as a recovery action, the amx-process monitor performs the following steps:

1. Collects and stores debug data in a persistent location.
2. Attempts to reboot using the TR-181-USP function `Device.Reboot()`.
3. If that fails, executes the shell command `reboot`.
4. If all reboot attempts fail, it stops signaling the watchdog.

This layered approach ensures system reliability and preserves diagnostic data.

### 🚫 No Action

If no recovery action is configured, the monitor continues to track health status based on test results but does not initiate any corrective steps.

---

### 📡 Integration with procd

The monitor subscribes to `procd` events to track process state changes:

- Marks a test as failed when receiving `instance.stop` or `instance.fail` events.
- Uses `instance.respawn` to detect automatic recovery initiated by `procd`.

---

### 📊 Failure Statistics

The monitor records the following metrics for each test:

- `MaxFailNum`: Maximum number of failures before recovery
- `MaxFailDuration`: Maximum duration taken to recover from failure

These statistics help assess system reliability and recovery performance.

---

## 📝 Notes

- `ProcessMonitor.Test` is the root object; numbered instances represent individual monitored processes.
- Use `_get` to inspect parameters and `_set` to modify them.
- All methods follow standard AMXD object conventions.

---

## 🛠️ Real-Time Monitoring Example

### Scenario: Monitoring a Openwrt crond Process

#### Test Configuration

- **Type**: `Process`
- **Subject**: `/var/run/crond.pid`
- **MaxFailNum**: `3`
- **MaxFailDuration**: `300` seconds (5 minutes)
- **TestInterval**: `60` seconds (1 minute)
- **RecoveryAction**: `Restart`

#### How It Works

1. **Test Execution**
   Every 60 seconds, the amx-process monitor checks if the crond service is running.

2. **Failure Detection**
   - If the service is **not running** (or) receiving either 'instance.stop' (or) 'instance.fail' procd event, this counts as a failure.
   - The monitor tracks the number of consecutive failures and the total duration of failures.

3. **Auto Recovery**
    - If the service is configured with procd, auto recovery will be attempted via respawn.
    - In such cases, the Amx process monitor only treats failures as consecutive if respawn attempts are exhausted and the service remains down (i.e., a "hung" state).

4. **Threshold Evaluation**
   - If the service fails **3 times in a row** (`MaxFailNum`), **or**
   - If the service has been down for **more than 5 minutes** (`MaxFailDuration`),
   - The amx-process monitor triggers the configured recovery action.

5. **Recovery Action**
   - The amx-process monitor attempts to **restart** the crond service.

6. **Health Parameter**
   - If the configuration is invalid (e.g., missing `Type` or `Subject`), the `Health` parameter will indicate the issue (e.g., `Health: Invalid configuration - Subject missing`).

7. **MaxFail Statistics**
   - After restart, Once the service health becomes good, the monitor updates the MaxFailNum and/or MaxFailDuration statistics if the latest failure count or duration exceeds previous records.
   - This helps track the worst-case failure and recovery scenarios for ongoing reliability assessment.


#### Example Timeline

| Time   | Status Check         | Failure Count | Failure Duration | Action Taken          |
|--------|----------------------|---------------|------------------|-----------------------|
| 00:00  | Service running      | 0             | 0                | None                  |
| 01:00  | Service not running  | 1             | 60s              | None                  |
| 02:00  | Service not running  | 2             | 120s             | None                  |
| 03:00  | Service not running  | 3             | 180s             | **Restart Service**   |
| 04:00  | Service running      | 0             | 0                | None<br>MaxFail Summary:<br>- MaxFailNum: 3<br>- MaxFailDuration: 180 seconds |


- Note: MaxFail statistics will be updated to MaxFailNum=3 and MaxFailDuration=180s once the service recovers, if these values exceed the previously recorded MaxFail statistics.
---
