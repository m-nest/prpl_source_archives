/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file main.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief The main file of the prplMesh DataModel Mapper, that descibes
 *          launching application via Abmiorix Runtime application.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2025 Inango
 *
 */

#include <string.h>
#include <stdlib.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <amxp/amxp.h>
#include <amxb/amxb_config.h>
#include <debug/sahtrace.h>

#include "dmm.h"
#include "dmm_connect_mngr.h"
#include "dmm_subscribe.h"
#include "dmm_trie.h"
#include "dmm_trie_translator.h"

#define ME "dmm"                      /*!< Prefix for SAH logger method */

const amxc_llist_t* hide_po_list = NULL;
amxc_llist_t* bus_ctx_list = NULL;
amxc_var_t* rename_po = NULL;

/**
 * @brief Lexicographical comparison function for strings stored in an `amxc_array`.
 *
 * This function is designed to be used as a custom comparator for sorting
 * or searching within an `amxc_array` where the elements contain C-style strings (`const char*`).
 *
 * It retrieves the string data from the array iterators and uses the standard
 * C function **strcmp()** to perform a lexicographical comparison.
 *
 * @param[in] it1 Pointer to the iterator of the first element (`amxc_array_it_t`).
 * @param[in] it2 Pointer to the iterator of the second element (`amxc_array_it_t`).
 * @return The result of **strcmp(str1, str2)**:
 * - A value **less than 0** if str1 is lexicographically smaller than str2.
 * - **0** if str1 is equal to str2.
 * - A value **greater than 0** if str1 is lexicographically larger than str2.
 */
static int cmp_strings_lex(amxc_array_it_t* it1, amxc_array_it_t* it2) {
    const char* str1 = (const char*) amxc_array_it_get_data(it1);
    const char* str2 = (const char*) amxc_array_it_get_data(it2);
    return strcmp(str1, str2);
}

/**
 * @brief Identifies and extracts the unique root object paths from a list of data model paths.
 *
 * Given a DMM mapping, return an array of root paths
 * A root path is defined as a path that is not a subpath of any other path
 *
 * The returned array does not own the strings,
 * they are pointers into the original DMM object
 *
 * @param[in] dmm_object A constant pointer to an `amxc_var_t` containing the list
 * of data model paths (likely a map or list of strings).
 * @return A new `amxc_array_t` containing pointers to the strings of the identified
 * root paths, or a clean, empty `amxc_array_t` if no valid object paths were found.
 * The paths stored in the returned array are references to strings in `dmm_object`.
 */
amxc_array_t* dmm_root_paths(const amxc_var_t* dmm_object) {
    amxc_array_t paths;
    // initially reserve space for 100 paths, will grow if needed
    amxc_array_init(&paths, 100);

    amxc_array_t* root_paths = NULL;
    // initially reserve space for 10 root paths, will grow if needed
    amxc_array_new(&root_paths, 10);

    amxc_var_for_each(path_var, dmm_object) {
        const char* path = GET_CHAR(path_var, NULL);
        if(!path || !*path) {
            continue;
        }
        // Skip non-objects
        if(path[strlen(path) - 1] != '.') {
            continue;
        }
        amxc_array_append_data(&paths, (void*) path);
    }

    if(amxc_array_is_empty(&paths)) {
        goto out;
    }

    amxc_array_sort(&paths, cmp_strings_lex);

    // The first path is always a root
    amxc_array_it_t* it = amxc_array_get_first(&paths);
    amxc_array_append_data(root_paths, amxc_array_it_get_data(it));

    while((it = amxc_array_it_get_next(it))) {
        const char* path = (const char*) amxc_array_it_get_data(it);
        amxc_array_it_t* last_root_it = amxc_array_get_last(root_paths);
        const char* last_root_path = (const char*) amxc_array_it_get_data(last_root_it);
        size_t last_root_path_len = strlen(last_root_path);
        if(strncmp(path, last_root_path, last_root_path_len) != 0) {
            // Not a subpath of the last root, so it's a new root
            amxc_array_append_data(root_paths, (void*) path);
        }
    }

out:
    amxc_array_clean(&paths, NULL);
    return root_paths;
}

/**
 * @brief Frees a list element from the DMM context list.
 *
 * This function is intended to be used as a cleanup callback for an `amxc_llist`
 * (linked list). It takes an iterator pointing to an element in the list,
 * extracts the containing structure (`actx_llist_t*`) using `amxc_container_of()`,
 * and frees the memory allocated for that list item structure.
 *
 * @param[in] it The iterator (`amxc_llist_it_t*`) pointing to the element
 * to be cleaned up and freed.
 */
static void dmm_free_list_elem(amxc_llist_it_t* it) {
    actx_llist_t* actx_list_item = amxc_container_of(it, actx_llist_t, it);
    free(actx_list_item);
}

/**
 * @brief Initializes and starts the Data Model Manager (DMM) module.
 *
 * This function performs the core initialization required for the DMM to start
 * managing data models and connections.
 *
 * The initialization process includes:
 * 1. **Context List Initialization:** Creates a new linked list (`bus_ctx_list`)
 * to track active bus contexts and their corresponding root paths.
 * 2. **Root Path Identification:** Calls **dmm_root_paths()** to extract the
 * unique root object paths (e.g., "Device.", "Custom.") from the DMM's
 * configuration data (`DMM_OBJECTS_CONFIG`).
 * 3. **Context Structure Creation:** Iterates over the identified root paths,
 * allocates a new list item (`actx_llist_t`) for each, copies the root path,
 * and appends the structure to `bus_ctx_list`. This prepares the DMM to
 * receive connections for these specific root paths. Paths exceeding
 * `ROOT_PATH_LEN` are skipped.
 * 4. **Listener Setup:** Calls **dmm_start_amx_listen()** to open the listening
 * socket and wait for incoming USP Agent (AMX) connections.
 * 5. **Translator Initialization:** Calls **dmm_translator_init()** to set up
 * the data model translation mechanism using the provided data model (`dm`) and
 * parser context (`parser`).
 *
 * @param[in] dm The main data model instance (`amxd_dm_t*`).
 * @param[in] parser The AMX parser context (`amxo_parser_t*`) containing the configuration.
 * @return Returns **0** on successful initialization.
 */
static int dmm_start(amxd_dm_t* dm, amxo_parser_t* parser) {
    actx_llist_t* actx_list_item = NULL;
    SAH_TRACEZ_IN(ME);

    amxc_llist_new(&bus_ctx_list);

    amxc_var_t* config_po = GET_ARG(&parser->config, DMM_OBJECTS_CONFIG);

    amxc_var_for_each(mapping, config_po) {
        const char* mapped_path = amxc_var_key(mapping);
        const char* original_path = amxc_var_constcast(cstring_t, mapping);
        const char* path = original_path;

        SAH_TRACEZ_INFO(ME, "Root path: %s", path);
        if(strlen(path) >= ROOT_PATH_LEN) {
            SAH_TRACEZ_ERROR(ME, "Root path %s is longer than %d", path, ROOT_PATH_LEN);
            continue;
        }
        if(strlen(mapped_path) >= ROOT_PATH_LEN) {
            SAH_TRACEZ_ERROR(ME, "Maped path %s is longer than %d", mapped_path, ROOT_PATH_LEN);
            continue;
        }

        actx_list_item = malloc(sizeof(actx_llist_t));
        if(!actx_list_item) {
            SAH_TRACEZ_ERROR(ME, "Failed memory allocation for a path %s:", path);
            continue;
        }
        actx_list_item->a_bus_ctx = NULL;
        snprintf(actx_list_item->root_path, sizeof(actx_list_item->root_path), "%s", path);
        snprintf(actx_list_item->mapped_path, sizeof(actx_list_item->mapped_path), "%s", mapped_path);
        amxc_llist_it_init(&(actx_list_item->it));
        amxc_llist_append(bus_ctx_list, &(actx_list_item->it));

    }

    dmm_start_amx_listen();
    dmm_translator_init(dm, parser);

    init_tree();
    parse_mapping();

    dmm_subscription_init();

    SAH_TRACEZ_OUT(ME);
    return 0;
}

/**
 * @brief Cleans up and stops the Data Model Manager (DMM) module.
 *
 * This function performs all necessary de-initialization and cleanup when the
 * DMM module is shutting down.
 *
 * The cleanup process includes:
 * 1. **Translator Cleanup:** Calls **dmm_translator_cleanup()** to free all
 * resources and data structures related to the data model translation layer
 * (using the provided data model `dm` and parser context `parser`).
 * 2. **Bus Context List Cleanup:** Deletes the linked list of active bus
 * contexts (`bus_ctx_list`). The helper function **dmm_free_list_elem** is
 * used as the free function to ensure all allocated `actx_llist_t` structures
 * are properly deallocated.
 *
 * @param[in] dm The main data model instance (`amxd_dm_t*`).
 * @param[in] parser The AMX parser context (`amxo_parser_t*`).
 */
static void dmm_stop(amxd_dm_t* dm, amxo_parser_t* parser) {
    dmm_translator_cleanup(dm, parser);
    amxc_llist_delete(&bus_ctx_list, dmm_free_list_elem);
}

/**
 * @brief Generic startup function in AMXRT app.
 * @param reason application startup reason (AMXO_START or AMXO_STOP)
 * @param dm pointer to the application datamodel
 * @param parser pointer to the pre-configured datamodel parser
 * @return Always return successfull error code 0
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_INFO(ME, "Starting %s", ME);
        amxb_set_minimal_timeout(1);
        if(dmm_start(dm, parser) != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to start %s", ME);
            return -1;
        }

        break;
    case AMXO_STOP:
        SAH_TRACEZ_INFO(ME, "Stopping %s", ME);
        dmm_stop(dm, parser);
        break;
    }

    return 0;
}
