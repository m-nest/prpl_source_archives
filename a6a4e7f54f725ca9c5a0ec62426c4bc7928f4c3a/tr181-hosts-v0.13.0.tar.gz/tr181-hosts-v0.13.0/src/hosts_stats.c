/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "hosts_accesscontroller.h"
#include "hosts_manager.h"

#define ME "hosts-stats"
#define HOSTS_WANSTATS_READ_MIN_DEBOUNCE_S 1

typedef struct _host_stats {
    /** If the current time is past this timestamp, a read should fetch fresh
     * data for the active connections. If not, the data from active_stats is used.
     *
     * This mechanism serves as a way to rate-limit read requests.
     */
    amxc_ts_t read_deadline;
    /** Cached previously read data. If NULL or the current time has progressed
     * past read_deadline, this data is stale and should be disgarded. */
    amxc_var_t data;
    bool valid;
} s_host_stats_t;

static amxc_ts_t null_time;
static uint32_t debounce_time = HOSTS_WANSTATS_READ_MIN_DEBOUNCE_S;

CONSTRUCTOR static void init_null_time(void) {
    amxc_ts_parse(&null_time, "0001-01-01T00:00:00Z", 20);
}

/**
   @brief Retrieves the statistics object associated with a host, or creates one if it doesn't exist.

   If the host object already has an associated statistics structure, it is returned.
   Otherwise, a new @c s_host_stats_t structure is allocated, initialized, and assigned
   to the host object's @c priv field.

   @param object Pointer to the host object. Must not be NULL.
   @return Pointer to the associated or newly created @c s_host_stats_t structure,
           or NULL if allocation failed or @c object is NULL.
 */
static s_host_stats_t* s_stats_get_or_create(amxd_object_t* object) {
    s_host_stats_t* item = NULL;

    when_null_trace(object, exit, ERROR, "Cannot get or create stats: host object pointer is NULL");
    item = (s_host_stats_t*) object->priv;

    when_not_null(item, exit);

    item = malloc(sizeof(s_host_stats_t));
    when_null_trace(item, exit, ERROR, "Out of memory");

    amxc_var_init(&item->data);
    item->read_deadline = null_time;
    item->valid = false;

    object->priv = item;

exit:
    return item;
}

/**
   @brief Frees a host statistics object.

   Cleans up the internal data of the statistics object and releases its memory.
   If the provided pointer is NULL, the function does nothing.

   @param stats Pointer to the @c s_host_stats_t object to free.
 */
static void s_stats_free(s_host_stats_t* stats) {
    when_null(stats, exit);

    amxc_var_clean(&stats->data);
    free(stats);

exit:
    return;
}

/**
   @brief Reads internal statistics for a host object.

   Queries the device's statistics via gMap and updates the provided s_host_stats_t object.
   Marks the statistics as valid only if the retrieved data indicates success or if status cannot be determined.

   @param object Pointer to the host object whose statistics are to be read.
   @param stats Pointer to the statistics object to populate.
   @return amxd_status_t Status of the operation. Returns `amxd_status_unknown_error` if retrieval fails,
           or `amxd_status_invalid_value` if the stats indicate failure.
 */
static amxd_status_t s_stats_read_internal(amxd_object_t* object, s_host_stats_t* stats) {
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t result;
    amxc_var_t devicepath;
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t path;
    amxd_object_t* parent = NULL;
    const char* data_status = NULL;

    amxc_var_init(&result);
    amxc_var_init(&devicepath);
    amxc_string_init(&path, 0);

    parent = amxd_object_get_parent(object);
    when_null_trace(parent, exit, ERROR, "Couldn't retreive parent node");
    amxd_object_get_param(parent, "DeviceReference", &devicepath);

    ctx = amxb_be_who_has("Devices.Device");
    when_null_trace(ctx, exit, ERROR, "gMap data model not found 'Devices.Device' - is gmap-server running?");

    amxc_string_set(&path, GET_CHAR(&devicepath, NULL));
    amxc_string_append(&path, "Stats.", 6);
    status = amxb_get(ctx, amxc_string_get(&path, 0), 0, &result, 1);
    if(status != 0) {
        SAH_TRACEZ_NOTICE(ME,
                          "Couldn't retrieve Stats for Device: %s - is 'stats' tag present?",
                          GET_CHAR(&devicepath, NULL));
        amxc_var_clean(&stats->data);
        goto exit;
    }

    amxc_var_move(&stats->data, amxc_var_get_first(GETI_ARG(&result, 0)));

    /* Only accept the value when it comes from a succesful sample. Assume success if it can't be determined. */
    data_status = GET_CHAR(&stats->data, "Status");
    stats->valid = data_status == NULL || strcmp(data_status, "Success") == 0;
    when_false_status(stats->valid, exit, status = amxd_status_invalid_value);

exit:
    amxc_var_clean(&result);
    amxc_var_clean(&devicepath);
    amxc_string_clean(&path);

    return status;
}

amxd_status_t hosts_manager_get_stats(amxd_object_t* object, const amxc_var_t** out) {
    amxd_status_t status = amxd_status_unknown_error;
    s_host_stats_t* item = s_stats_get_or_create(object);
    amxc_ts_t now;
    int now_ok;

    when_null_trace(out, exit, ERROR, "NULL");
    *out = NULL;

    when_null(item, exit);

    now_ok = amxc_ts_now(&now);

    if((now_ok == 0) &&
       (item->data.type_id != AMXC_VAR_ID_NULL) &&
       (amxc_ts_compare(&now, &item->read_deadline) == -1)) {
        when_false_status(item->valid, exit, status = amxd_status_invalid_value);

        *out = &item->data;
        status = amxd_status_ok;
        goto exit;
    }

    status = s_stats_read_internal(object, item);
    when_failed(status, exit);

    *out = &item->data;

    if(now_ok == 0) {
        item->read_deadline = now;
        item->read_deadline.sec += debounce_time;
    }

exit:
    return status;
}

amxd_status_t _on_wanstats_destroyed(amxd_object_t* const object,
                                     UNUSED amxd_param_t* const param,
                                     UNUSED amxd_action_t reason,
                                     UNUSED const amxc_var_t* const args,
                                     UNUSED amxc_var_t* const retval,
                                     UNUSED void* priv) {
    when_null(object, exit);
    s_stats_free(object->priv);
    object->priv = NULL;

exit:
    return amxd_status_ok;
}

void hosts_manager_set_stats_debounce_seconds(uint32_t seconds) {
    debounce_time = seconds < HOSTS_WANSTATS_READ_MIN_DEBOUNCE_S ? HOSTS_WANSTATS_READ_MIN_DEBOUNCE_S : seconds;
    SAH_TRACEZ_INFO(ME, "Debouncing future WANStats. reads to %d seconds", debounce_time);
}