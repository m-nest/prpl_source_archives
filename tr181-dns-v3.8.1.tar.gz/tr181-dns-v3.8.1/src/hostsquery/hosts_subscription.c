/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "hostsquery/subscription.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

#define PROBE_PARAM_HOST "Active"
#define MAX_DEPTH_TO_SEARCH 5
#define MAX_BUS_TIMEOUT 5

static amxb_bus_ctx_t* hosts_ctx = NULL;
static amxp_timer_t* timer_retry_start = NULL;

amxb_bus_ctx_t* hosts_get_amxb_bus(void) {
    hosts_ctx = amxb_be_who_has("Hosts.");
    return hosts_ctx;
}

static int copy_hosts_variant(amxc_var_t* const dest, const amxc_var_t* const src, const char* filter_key) {
    int rv = -1;
    amxc_var_t* var = NULL;
    const amxc_var_t* htable = NULL;
    amxc_string_t key;
    amxc_string_t key_index;

    amxc_string_init(&key_index, 0);
    amxc_string_init(&key, 0);

    when_str_empty(filter_key, exit);
    when_null(dest, exit);
    when_null(src, exit);

    for(int i = 0; i < MAX_DEPTH_TO_SEARCH; i++) {
        htable = NULL;
        amxc_string_copy(&key, &key_index);
        amxc_string_appendf(&key, "%s", filter_key);
        var = GETP_ARG(src, amxc_string_get(&key, 0));
        if(var == NULL) {
            amxc_string_appendf(&key_index, "0.");
            continue;
        }
        if(strcmp(amxc_string_get(&key_index, 0), "") == 0) {
            htable = src;
            break;
        } else {
            htable = GETP_ARG(src, amxc_string_get(&key_index, 0));
            break;
        }
    }

    when_null(htable, exit);

    amxc_var_copy(dest, htable);

    rv = 0;
exit:
    amxc_string_clean(&key);
    amxc_string_clean(&key_index);
    return rv;
}

static int extract_ipaddresses_variant(amxc_var_t* const dest, const amxc_var_t* const src, const char* substring) {
    int rv = -1;
    const amxc_var_t* var = NULL;
    const amxc_var_t* htable = NULL;
    amxc_string_t key_var;

    amxc_string_init(&key_var, 0);

    when_str_empty(substring, exit);
    when_null(dest, exit);
    when_null(src, exit);

    for(int i = 0; i < MAX_DEPTH_TO_SEARCH; i++) {
        const char* key = NULL;
        if(strcmp(amxc_string_get(&key_var, 0), "") == 0) {
            var = src;
        } else {
            var = GETP_ARG(src, amxc_string_get(&key_var, 0));
        }
        when_null(var, exit);
        key = amxc_var_key(var);
        if(!STRING_EMPTY(key) && (strstr(key, substring) != NULL)) {
            break;
        }
        amxc_string_appendf(&key_var, "0.");
    }

    when_null(var, exit);

    amxc_string_replace(&key_var, "0.", "", 1);
    if(strcmp(amxc_string_get(&key_var, 0), "") == 0) {
        var = src;
    } else {
        var = GETP_ARG(src, amxc_string_get(&key_var, 0));
    }
    when_null(var, exit);
    htable = var;

    amxc_var_copy(dest, htable);

    rv = 0;
exit:
    amxc_string_clean(&key_var);
    return rv;
}

static void add_last_dot_to_path(amxc_string_t* path_string) {
    int string_size = 0;

    when_null(path_string, out);
    string_size = amxc_string_text_length(path_string);
    when_true(string_size == 0, out);

    if(strcmp(amxc_string_get(path_string, string_size - 1), ".") != 0) {
        amxc_string_appendf(path_string, ".");
    }
out:
    return;
}

static int get_hosts_ipaddress_variant(amxc_var_t* const dest, const char* hosts_path, bool ipv4) {
    int rv = -1;
    amxc_var_t tmp;
    amxc_var_t tmp_list;
    amxc_string_t path_string;
    amxc_var_t* ipaddr_list = NULL;
    const amxc_htable_t* ipaddr_htable = NULL;
    const char* ipaddr_param = NULL;

    amxc_var_init(&tmp);
    amxc_var_init(&tmp_list);
    amxc_string_init(&path_string, 0);

    when_null(dest, exit);
    when_str_empty(hosts_path, exit);

    if(ipv4) {
        ipaddr_param = HOSTS_PARAM_IPV4;
    } else {
        ipaddr_param = HOSTS_PARAM_IPV6;
    }

    amxc_string_setf(&path_string, "%s", hosts_path);
    add_last_dot_to_path(&path_string);
    amxc_string_appendf(&path_string, "%s.", ipaddr_param);
    amxb_get_instances(hosts_ctx, amxc_string_get(&path_string, 0), UINT32_MAX, &tmp, 5);

    rv = extract_ipaddresses_variant(&tmp_list, &tmp, "Hosts");
    when_failed(rv, exit);

    ipaddr_list = GET_ARG(dest, ipaddr_param);

    amxc_var_for_each(var, &tmp_list) {
        amxc_var_t ipaddr_var;
        const char* ipaddr = GET_CHAR(var, HOSTS_PARAM_IPADDRESS);
        if(STRING_EMPTY(ipaddr)) {
            continue;
        }
        amxc_var_init(&ipaddr_var);
        amxc_var_copy(&ipaddr_var, var);
        ipaddr_htable = amxc_var_constcast(amxc_htable_t, &ipaddr_var);
        if(ipaddr_htable == NULL) {
            amxc_var_clean(&ipaddr_var);
            continue;
        }
        if(ipaddr_list == NULL) {
            ipaddr_list = amxc_var_add_key(amxc_llist_t, dest, ipaddr_param, NULL);
            if(ipaddr_list == NULL) {
                amxc_var_clean(&ipaddr_var);
                continue;
            }
        }
        amxc_var_add(amxc_htable_t, ipaddr_list, ipaddr_htable);
        amxc_var_clean(&ipaddr_var);
    }

    rv = 0;
exit:
    amxc_var_clean(&tmp);
    amxc_var_clean(&tmp_list);
    amxc_string_clean(&path_string);
    return rv;
}

int get_hosts_variant(amxc_var_t* const dest, const char* hosts_path) {
    int rv = -1;
    amxc_var_t tmp;
    amxc_string_t path_string;
    uint32_t n_ipv4 = 0;
    uint32_t n_ipv6 = 0;

    amxc_var_init(&tmp);
    amxc_string_init(&path_string, 0);

    when_null(dest, exit);
    when_str_empty(hosts_path, exit);

    amxc_string_setf(&path_string, "%s", hosts_path);
    add_last_dot_to_path(&path_string);

    amxb_get(hosts_get_amxb_bus(), amxc_string_get(&path_string, 0), 0, &tmp, MAX_BUS_TIMEOUT);
    copy_hosts_variant(dest, &tmp, HOSTS_PARAM_ACTIVE);
    when_null(GET_ARG(dest, HOSTS_PARAM_ACTIVE), exit);
    when_false_status(GET_BOOL(dest, HOSTS_PARAM_ACTIVE), exit, rv = 0);
    n_ipv4 = GET_UINT32(dest, HOSTS_PARAM_NUMBER_IPV4);
    n_ipv6 = GET_UINT32(dest, HOSTS_PARAM_NUMBER_IPV6);

    if(n_ipv4 > 0) {
        get_hosts_ipaddress_variant(dest, amxc_string_get(&path_string, 0), true);
    }

    if(n_ipv6 > 0) {
        get_hosts_ipaddress_variant(dest, amxc_string_get(&path_string, 0), false);
    }

    rv = 0;
exit:
    amxc_var_clean(&tmp);
    amxc_string_clean(&path_string);
    return rv;
}

int subscribe_to_hosts_path(amxb_subscription_t** subscription, const char* hosts_path, amxp_slot_fn_t slot_cb, void* userdata, amxc_var_t* ret) {
    int rv = -1;
    amxc_string_t path_string;

    amxc_string_init(&path_string, 0);

    when_null(subscription, exit);
    when_null(ret, exit);
    when_str_empty(hosts_path, exit);
    when_null(slot_cb, exit);
    when_null(hosts_get_amxb_bus(), exit);

    amxc_string_setf(&path_string, "%s", hosts_path);
    add_last_dot_to_path(&path_string);

    rv = amxb_subscription_new(subscription,
                               hosts_ctx,
                               amxc_string_get(&path_string, 0),
                               "notification in ['dm:object-changed'] && path matches 'Hosts.Host.[0-9]+.$'",
                               slot_cb,
                               userdata);
    when_failed(rv, exit);

    get_hosts_variant(ret, hosts_path);

    rv = 0;
exit:
    amxc_string_clean(&path_string);
    return rv;
}

static void continue_initialization(UNUSED amxp_timer_t* timer, void* data) {
    int ret_value = -1;
    hosts_init_callback_t cb = (hosts_init_callback_t) data;

    hosts_ctx = amxb_be_who_has("Hosts.");
    if(hosts_ctx == NULL) {
        SAH_TRACEZ_ERROR(ME, "No Hosts bus context found - retrying again in 3 seconds.");
        if(timer_retry_start == NULL) {
            ret_value = amxp_timer_new(&timer_retry_start, continue_initialization, data);
            when_failed_trace(ret_value, exit, ERROR, "Failed to initialize the timer.");
        }
        ret_value = amxp_timer_start(timer_retry_start, 3000);
        when_failed_trace(ret_value, exit, ERROR, "Failed to start the retry timer.");
        goto rearm;
    }

    if(cb != NULL) {
        cb();
    }
exit:
    amxp_timer_delete(&timer_retry_start);
rearm:
    return;
}

static void wait_for_hosts_cb(UNUSED const char* signame,
                              UNUSED const amxc_var_t* const data,
                              void* const priv) {
    continue_initialization(NULL, priv);
}

bool hosts_initialize(hosts_init_callback_t handler) {
    bool result = false;
    int ret_value = -1;

    hosts_ctx = amxb_be_who_has("Hosts.");
    if(hosts_ctx == NULL) {
        amxb_wait_for_object("Hosts.");
        ret_value = amxp_slot_connect_filtered(NULL, "^wait:Hosts\\.$", NULL, wait_for_hosts_cb, handler);
        when_failed_trace(ret_value, exit, ERROR, "Failed to wait for Hosts to be available");
        SAH_TRACEZ_WARNING(ME, "Waiting for Hosts");
        goto exit;
    }

    result = true;
    if(handler != NULL) {
        handler();
    }
exit:
    return result;
}

void hosts_cleanup(void) {
    hosts_ctx = NULL;
    amxp_timer_delete(&timer_retry_start);
}