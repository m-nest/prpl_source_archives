/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _GNU_SOURCE

#include <curl/curl.h>
#include <upnp/upnp.h>
#include <string.h>
#include <stdlib.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include "tr181-description.h"
#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"

#define ME "desc"

static int upnp_description_parse_devicedescription(IXML_Node* node, device_desc_t* data);
static int upnp_description_parse_device(IXML_Node* node, device_desc_t* data);
static int upnp_description_parse_service(IXML_Node* node, device_desc_t* data);

static amxc_string_t _parent_device;
static struct {const char* mnemo; int (* func)(IXML_Node*, device_desc_t*);} _node_func[] = {
    {"specVersion", upnp_description_parse_devicedescription},
    {"device", upnp_description_parse_device},
    {"service", upnp_description_parse_service},
};
static struct {const char* xml_mnemo; const char* dm_mnemo;} _translate_device[] = {
    {"UDN", "UDN"},
    {"deviceType", "DeviceType"},
    {"friendlyName", "FriendlyName"},
    {"deviceCategory", "DeviceCategory"},
    {"manufacturer", "Manufacturer"},
    {"manufacturerOUI", "ManufacturerOUI"},
    {"manufacturerURL", "ManufacturerURL"},
    {"modelDescription", "ModelDescription"},
    {"modelName", "ModelName"},
    {"modelNumber", "ModelNumber"},
    {"modelURL", "ModelURL"},
    {"serialNumber", "SerialNumber"},
    {"UPC", "UPC"},
    {"presentationURL", "PresentationURL"},
};
static struct {const char* xml_mnemo; const char* dm_mnemo;} _translate_service[] = {
    {"serviceId", "ServiceId"},
    {"serviceType", "ServiceType"},
    {"SCPDURL", "SCPDURL"},
    {"controlURL", "ControlURL"},
    {"eventSubURL", "EventSubURL"},
};

#define _NODE_FUNC_ARRAY_SIZE (sizeof(_node_func) / sizeof(*_node_func))
#define _TRANSLATE_DEVICE_ARRAY_SIZE (sizeof(_translate_device) / sizeof(*_translate_device))
#define _TRANSLATE_SERVICE_ARRAY_SIZE (sizeof(_translate_service) / sizeof(*_translate_service))

#define CURL_TIMEOUT 2L

static int upnp_description_create_device_description(const char* location) {
    int rv = -1;
    amxd_trans_t trans;
    amxd_object_t* device_desc_obj = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    device_desc_obj = amxd_dm_findf(get_dm(), "%s", UPNP_DESCRIPTION_DEVDESC_OBJ_PATH);
    when_null(device_desc_obj, exit);
    amxd_trans_select_object(&trans, device_desc_obj);
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "URLBase", location);
    rv = amxd_trans_apply(&trans, get_dm());
    when_false_trace(rv == 0, exit, ERROR, "Couldn't create new device description for %s (%d)", location, rv);
exit:
    amxd_trans_clean(&trans);
    return rv;
}

amxd_object_t* upnp_description_get_device_description(const char* location) {
    amxd_object_t* device_desc = NULL;

    device_desc = amxd_dm_findf(get_dm(), "UPnPDescription.DeviceDescription.[URLBase=='%s'].", location);
    if(device_desc == NULL) {
        when_failed(upnp_description_create_device_description(location), exit);
        device_desc = amxd_dm_findf(get_dm(), "UPnPDescription.DeviceDescription.[URLBase=='%s'].", location);
    }
exit:
    return device_desc;
}

static int upnp_description_parse_devicedescription(IXML_Node* node, device_desc_t* data) {
    int minor = 0;
    int major = 0;
    amxc_string_t spec_ver_str;
    amxc_var_t param;

    amxc_string_init(&spec_ver_str, 0);
    amxc_var_init(&param);
    for(; node; node = node->nextSibling) {
        if(strcmp(node->nodeName, "major") == 0) {
            major = atoi(ixmlNode_getNodeValue(ixmlNode_getFirstChild(node)));
        } else if(strcmp(node->nodeName, "minor") == 0) {
            minor = atoi(ixmlNode_getNodeValue(ixmlNode_getFirstChild(node)));
        }
    }
    amxc_string_setf(&spec_ver_str, "%d.%d", major, minor);
    amxc_var_set(cstring_t, &param, amxc_string_get(&spec_ver_str, 0));
    amxd_object_set_param(data->device_desc, "SpecVersion", &param);
    amxc_string_clean(&spec_ver_str);
    amxc_var_clean(&param);
    return 0;
}

static void upnp_description_device_to_amxc_var(IXML_Node* device, amxc_var_t* var, IXML_Node** device_list, IXML_Node** service_list) {
    amxc_var_set_type(var, AMXC_VAR_ID_HTABLE);
    for(; device; device = device->nextSibling) {
        for(uint32_t i = 0; i < _TRANSLATE_DEVICE_ARRAY_SIZE; ++i) {
            if(!device->nodeName || !*device->nodeName) {
                continue;
            }
            if(strcmp(device->nodeName, _translate_device[i].xml_mnemo) == 0) {
                if((strcmp(device->nodeName, "UDN") == 0) && (strlen(ixmlNode_getNodeValue(ixmlNode_getFirstChild(device))) > strlen(UUID_LABEL))) {
                    amxc_var_add_key(cstring_t, var, _translate_device[i].dm_mnemo, ixmlNode_getNodeValue(ixmlNode_getFirstChild(device)) + strlen(UUID_LABEL));
                } else {
                    amxc_var_add_key(cstring_t, var, _translate_device[i].dm_mnemo, ixmlNode_getNodeValue(ixmlNode_getFirstChild(device)));
                }
                break;
            } else if(strcmp(device->nodeName, "deviceList") == 0) {
                *device_list = device;
            } else if(strcmp(device->nodeName, "serviceList") == 0) {
                *service_list = device;
            }
        }
    }
}


static int upnp_description_parse_device(IXML_Node* node, UNUSED device_desc_t* data) {
    amxc_var_t var;
    IXML_Node* device_list = NULL;
    IXML_Node* service_list = NULL;
    amxc_string_t old_parent;

    amxc_string_init(&old_parent, 0);
    amxc_string_copy(&old_parent, &_parent_device);
    amxc_var_init(&var);
    upnp_description_device_to_amxc_var(node, &var, &device_list, &service_list);
    upnp_description_update_device(&var, data);
    if(service_list != NULL) {
        parse_xmlnode(ixmlNode_getFirstChild(service_list), data);
    }
    if(device_list != NULL) {
        parse_xmlnode(ixmlNode_getFirstChild(device_list), data);
    }
    amxc_string_copy(&_parent_device, &old_parent);
    amxc_string_clean(&old_parent);
    amxc_var_clean(&var);
    return 0;
}

static void upnp_description_service_to_amxc_var(IXML_Node* service, amxc_var_t* var) {
    amxc_var_set_type(var, AMXC_VAR_ID_HTABLE);
    for(; service != NULL; service = service->nextSibling) {
        for(uint32_t i = 0; i < _TRANSLATE_SERVICE_ARRAY_SIZE; ++i) {
            if(strcmp(service->nodeName, _translate_service[i].xml_mnemo) == 0) {
                amxc_var_add_key(cstring_t, var, _translate_service[i].dm_mnemo, ixmlNode_getNodeValue(ixmlNode_getFirstChild(service)));
                break;
            }
        }
    }
}

static int upnp_description_parse_service(IXML_Node* node, UNUSED device_desc_t* data) {
    amxc_var_t var;

    amxc_var_init(&var);
    upnp_description_service_to_amxc_var(node, &var);
    upnp_description_update_service(&var);
    amxc_var_clean(&var);
    return 0;
}

static int is_location_accessible(const char* location) {
    int ret = -1;
    CURL* curl = NULL;
    CURLcode res = CURLE_COULDNT_CONNECT;

    when_null_trace((curl = curl_easy_init()), exit, ERROR, "curl_easy_init failed");
    when_false_trace((curl_easy_setopt(curl, CURLOPT_URL, location) == CURLE_OK), exit, ERROR, "Failed to set CURLOPT_URL");
    when_false_trace((curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L) == CURLE_OK), exit, ERROR, "Failed to set CURLOPT_FAILONERROR");
    when_false_trace((curl_easy_setopt(curl, CURLOPT_TIMEOUT, CURL_TIMEOUT) == CURLE_OK), exit, ERROR, "Failed to set CURLOPT_TIMEOUT");
    when_false_trace((curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, CURL_TIMEOUT) == CURLE_OK), exit, ERROR, "Failed to set CURLOPT_CONNECTTIMEOUT");
    when_false_trace((res = curl_easy_perform(curl)) == CURLE_OK, exit, ERROR, "curl_easy_perform error: %s", curl_easy_strerror(res));
    ret = 0;

exit:
    curl_easy_cleanup(curl);

    return ret;
}

int parse_xmlnode(IXML_Node* node, device_desc_t* data) {
    uint32_t i = 0;

    for(; node != NULL; node = node->nextSibling) {
        if(ixmlNode_hasChildNodes(node)) {
            for(i = 0; i < _NODE_FUNC_ARRAY_SIZE; ++i) {
                if(strcmp(_node_func[i].mnemo, node->nodeName) == 0) {
                    _node_func[i].func(ixmlNode_getFirstChild(node), data);
                    break;
                }
            }
            if(i == _NODE_FUNC_ARRAY_SIZE) {
                parse_xmlnode(ixmlNode_getFirstChild(node), data);
            }
        }
    }
    return 0;
}

void upnp_description_extract_ipaddress(device_desc_t* data) {
    int32_t len = 0;
    const char* tmp = data->location;

    when_str_empty(tmp, exit);
    tmp = strstr(tmp, "//");
    when_str_empty(tmp, exit);
    tmp += 2;
    when_str_empty(tmp, exit);
    if(tmp[0] == '[') {
        len = strchr(tmp, ']') - (tmp + 1);
        data->ip_address = strndup(tmp + 1, len);
    } else {
        len = (strchr(tmp, ':') != NULL) ? strchr(tmp, ':') - tmp : len;
        len = (strchr(tmp, '/') != NULL && strchr(tmp, '/') - tmp < len) ? strchr(tmp, '/') - tmp : len;
        data->ip_address = strndup(tmp, len);
    }
    SAH_TRACEZ_INFO(ME, "IP: %s", data->ip_address);
exit:
    return;
}

int upnp_description_update_from_location(const char* location) {
    int rv = -1;
    device_desc_t data = {0};

    amxc_string_init(&_parent_device, 0);
    when_str_empty_trace(location, exit, ERROR, "Location is empty");
    data.location = location;
    when_true(is_location_accessible(data.location) != 0, exit);
    when_true(UpnpDownloadXmlDoc(data.location, &data.xmlDoc) != UPNP_E_SUCCESS, exit);
    upnp_description_extract_ipaddress(&data);
    data.device_desc = upnp_description_get_device_description(data.location);
    when_null(data.device_desc, exit);
    parse_xmlnode(ixmlNode_getFirstChild(&data.xmlDoc->n), &data);
    rv = 0;
exit:
    amxc_string_clean(&_parent_device);
    free(data.ip_address);
    ixmlDocument_free(data.xmlDoc);
    return rv;
}

int upnp_description_update_service_discovery(amxd_object_t* service) {
    int rv = -1;
    const char* service_type = GET_CHAR(amxd_object_get_param_value(service, "ServiceType"), NULL);
    amxd_object_t* discovery_service_obj = amxd_dm_findf(get_dm(), UPNP_DISCOVERY_SERVICE_OBJ_PATH);
    amxc_string_t usp_path;

    amxc_string_init(&usp_path, 0);
    when_null(discovery_service_obj, exit);
    amxd_object_for_each(instance, it, discovery_service_obj) {
        amxd_object_t* service_obj = amxc_container_of(it, amxd_object_t, it);

        if(strstr(GET_CHAR(amxd_object_get_param_value(service_obj, "USN"), NULL), service_type)) {
            amxc_string_setf(&usp_path, "%s%d", UPNP_DISCOVERY_SERVICE_USP_PATH, amxd_object_get_index(service_obj));
            amxd_object_set_cstring_t(service, "ServiceDiscovery", amxc_string_get(&usp_path, 0));
        }
    }
    rv = 0;
exit:
    amxc_string_clean(&usp_path);
    return rv;
}

int upnp_description_update_device_discovery(amxd_object_t* device) {
    int rv = -1;
    const char* device_type = GET_CHAR(amxd_object_get_param_value(device, "DeviceType"), NULL);
    amxd_object_t* discovery_device_obj = amxd_dm_findf(get_dm(), UPNP_DISCOVERY_DEVICE_OBJ_PATH);
    amxc_string_t usp_path;
    amxd_trans_t trans;

    amxc_string_init(&usp_path, 0);
    amxd_trans_init(&trans);

    when_null(discovery_device_obj, exit);
    amxd_object_for_each(instance, it, discovery_device_obj) {
        amxd_object_t* device_obj = amxc_container_of(it, amxd_object_t, it);

        if(strstr(GET_CHAR(amxd_object_get_param_value(device_obj, "USN"), NULL), device_type)) {
            amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
            amxd_trans_select_object(&trans, device);

            amxc_string_setf(&usp_path, "%s%d", UPNP_DISCOVERY_DEVICE_USP_PATH, amxd_object_get_index(device_obj));
            amxd_trans_set_cstring_t(&trans, "DiscoveryDevice", amxc_string_get(&usp_path, 0));

            rv = amxd_trans_apply(&trans, get_dm());
            when_false_trace(rv == 0, exit, ERROR, "Couldn't set 'DiscoveryDevice' %d", rv);
        }
    }
    rv = 0;
exit:
    amxc_string_clean(&usp_path);
    amxd_trans_clean(&trans);
    return rv;
}

void set_parent(const char* parent) {
    amxc_string_set(&_parent_device, parent);
}

int upnp_description_update_device(amxc_var_t* var, device_desc_t* data) {
    const char* udn = NULL;
    amxd_object_t* device_obj = NULL;
    amxd_trans_t trans;
    int rv = -1;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    udn = (GET_CHAR(var, "UDN")) ? GET_CHAR(var, "UDN") : "";
    when_str_empty_trace(udn, exit, ERROR, "UDN is empty");
    device_obj = amxd_dm_findf(get_dm(), "UPnPDescription.DeviceInstance.[UDN=='%s'].", udn);
    if(device_obj) {
        amxd_trans_select_object(&trans, device_obj);
    } else {
        device_obj = amxd_dm_findf(get_dm(), UPNP_DESCRIPTION_DEVINST_OBJ_PATH);
        amxd_trans_select_object(&trans, device_obj);
        amxd_trans_add_inst(&trans, 0, NULL);
        amxd_trans_set_cstring_t(&trans, "UDN", udn);
    }
    amxd_trans_set_cstring_t(&trans, "ParentDevice", (amxc_string_text_length(&_parent_device)) ? amxc_string_get(&_parent_device, 0) : "");
    amxd_trans_set_cstring_t(&trans, "DeviceType", (GET_CHAR(var, "DeviceType")) ? GET_CHAR(var, "DeviceType") : "");
    amxd_trans_set_cstring_t(&trans, "FriendlyName", (GET_CHAR(var, "FriendlyName")) ? GET_CHAR(var, "FriendlyName") : "");
    amxd_trans_set_cstring_t(&trans, "DeviceCategory", (GET_CHAR(var, "DeviceCategory")) ? GET_CHAR(var, "DeviceCategory") : "");
    amxd_trans_set_cstring_t(&trans, "Manufacturer", (GET_CHAR(var, "Manufacturer")) ? GET_CHAR(var, "Manufacturer") : "");
    amxd_trans_set_cstring_t(&trans, "ManufacturerOUI", (GET_CHAR(var, "ManufacturerOUI")) ? GET_CHAR(var, "ManufacturerOUI") : "");
    amxd_trans_set_cstring_t(&trans, "ManufacturerURL", (GET_CHAR(var, "ManufacturerURL")) ? GET_CHAR(var, "ManufacturerURL") : "");
    amxd_trans_set_cstring_t(&trans, "ModelDescription", (GET_CHAR(var, "ModelDescription")) ? GET_CHAR(var, "ModelDescription") : "");
    amxd_trans_set_cstring_t(&trans, "ModelName", (GET_CHAR(var, "ModelName")) ? GET_CHAR(var, "ModelName") : "");
    amxd_trans_set_cstring_t(&trans, "ModelNumber", (GET_CHAR(var, "ModelNumber")) ? GET_CHAR(var, "ModelNumber") : "");
    amxd_trans_set_cstring_t(&trans, "ModelURL", (GET_CHAR(var, "ModelURL")) ? GET_CHAR(var, "ModelURL") : "");
    amxd_trans_set_cstring_t(&trans, "SerialNumber", (GET_CHAR(var, "SerialNumber")) ? GET_CHAR(var, "SerialNumber") : "");
    amxd_trans_set_cstring_t(&trans, "UPC", (GET_CHAR(var, "UPC")) ? GET_CHAR(var, "UPC") : "");
    amxd_trans_set_cstring_t(&trans, "PresentationURL", (GET_CHAR(var, "PresentationURL")) ? GET_CHAR(var, "PresentationURL") : "");
    amxd_trans_set_cstring_t(&trans, "IPAddress", (data->ip_address) ? data->ip_address : "");
    rv = amxd_trans_apply(&trans, get_dm());
    device_obj = amxd_dm_findf(get_dm(), "UPnPDescription.DeviceInstance.[UDN=='%s'].", udn);
    amxc_string_setf(&_parent_device, "%s%d", UPNP_DESCRIPTION_DEVICE_USP_PATH, amxd_object_get_index(device_obj));
    when_false_trace(rv == 0, exit, ERROR, "Couldn't create DeviceInstance: %d", rv);
exit:
    amxd_trans_clean(&trans);
    return rv;
}

int upnp_description_update_service(amxc_var_t* var) {
    int rv = -1;
    amxd_trans_t trans;
    amxd_object_t* service_obj = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    when_str_empty_trace(amxc_string_get(&_parent_device, 0), exit, ERROR, "Service found but no parent device");
    when_str_empty_trace(GET_CHAR(var, "ServiceId"), exit, ERROR, "Service found but no ServiceId in XML");
    service_obj = amxd_dm_findf(get_dm(), "UPnPDescription.ServiceInstance.[ParentDevice=='%s' && ServiceId=='%s'].", amxc_string_get(&_parent_device, 0), GET_CHAR(var, "ServiceId"));
    if(service_obj) {
        amxd_trans_select_object(&trans, service_obj);
    } else {
        service_obj = amxd_dm_findf(get_dm(), UPNP_DESCRIPTION_SERVINST_OBJ_PATH);
        amxd_trans_select_object(&trans, service_obj);
        amxd_trans_add_inst(&trans, 0, NULL);
        amxd_trans_set_cstring_t(&trans, "ParentDevice", amxc_string_get(&_parent_device, 0));
        amxd_trans_set_cstring_t(&trans, "ServiceId", GET_CHAR(var, "ServiceId"));
    }
    amxd_trans_set_cstring_t(&trans, "ServiceType", (GET_CHAR(var, "ServiceType") ? GET_CHAR(var, "ServiceType") : ""));
    amxd_trans_set_cstring_t(&trans, "SCPDURL", (GET_CHAR(var, "SCPDURL") ? GET_CHAR(var, "SCPDURL") : ""));
    amxd_trans_set_cstring_t(&trans, "ControlURL", (GET_CHAR(var, "ControlURL") ? GET_CHAR(var, "ControlURL") : ""));
    amxd_trans_set_cstring_t(&trans, "EventSubURL", (GET_CHAR(var, "EventSubURL") ? GET_CHAR(var, "EventSubURL") : ""));
    rv = amxd_trans_apply(&trans, get_dm());
    when_false_trace(rv == 0, exit, ERROR, "Couldn't create ServiceInstance: %d", rv);
exit:
    amxd_trans_clean(&trans);
    return rv;
}
