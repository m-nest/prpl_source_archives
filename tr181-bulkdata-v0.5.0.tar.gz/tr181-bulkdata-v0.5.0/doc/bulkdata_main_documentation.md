﻿# **TR-181 Bulkdata**
[Requirements](#tr-181bulkdata-requirements) 

[Introduction and High-Level Description](#tr-181bulkdata-introductionandhigh-leveldescription)

[Use Case Definition](#tr-181bulkdata-usecasedefinition)

[References](#tr-181bulkdata-references)

[Architecture](#tr-181bulkdata-architecture) 

[High Level Architecture](#tr-181bulkdata-highlevelarchitecture)

[Detailed architecture](#tr-181bulkdata-detailedarchitecture)

[Bulkdata Service](#tr-181bulkdata-bulkdataservice) 

[Bulkdata Profile: MQTT](#tr-181bulkdata-bulkdataprofile:mqtt)

[Bulkdata Profile: HTTP(s)](#tr-181bulkdata-bulkdataprofile:http\(s\))

[Implementation](#tr-181bulkdata-implementation) 

[Bulkdata service](#tr-181bulkdata-bulkdataservice) 

[mod_dmext](#tr-181bulkdata-mod_dmext)

[libsahtrace](#tr-181bulkdata-libsahtrace)

[libimtp](#tr-181bulkdata-libimtp)

[Bulkdata USPAgent interaction](#tr-181bulkdata-bulkdatauspagentinteraction)

[Data Model](#tr-181bulkdata-datamodel)

[Low-Level API](#tr-181bulkdata-low-levelapi)

[API](#tr-181bulkdata-api)

[Files](#tr-181bulkdata-files)

[Firewall](#tr-181bulkdata-firewall)

[Dependants and Dependencies](#tr-181bulkdata-dependantsanddependencies) 

[Dependants](#tr-181bulkdata-dependants)

[Dependencies](#tr-181bulkdata-dependencies)

[Configuration](#tr-181bulkdata-configuration)

[Backup/Restore, Upgrade, Reset](#tr-181bulkdata-backup/restore,upgrade,reset)

[Web UI](#tr-181bulkdata-webui)

[Considerations](#tr-181bulkdata-considerations) 

[IPv6](#tr-181bulkdata-ipv6)

[Packet Acceleration](#tr-181bulkdata-packetacceleration)

[Memory Usage](#tr-181bulkdata-memoryusage)

[Boot Time](#tr-181bulkdata-boottime)

[Security](#tr-181bulkdata-security)

[Remote Management](#tr-181bulkdata-remotemanagement)

[Operational Monitoring](#tr-181bulkdata-operationalmonitoring)

[Quality](#tr-181bulkdata-quality) 

[Project Reference Configuration](#tr-181bulkdata-projectreferenceconfiguration)

[Build-time Checks](#tr-181bulkdata-build-timechecks)

[Run-time Checks](#tr-181bulkdata-run-timechecks)

[Unit Tests](#tr-181bulkdata-unittests)

[Logging and Debugging](#tr-181bulkdata-logginganddebugging)

[Functional Tests](#tr-181bulkdata-functionaltests) 

[Validating bulkdata reports via BulkData.Profile.{i}.Push! event](#tr-181bulkdata-validatingbulkdatareportsviabulkdata.profile.{i}.push!event)

[CI Tests](#tr-181bulkdata-citests)

[Certification](#tr-181bulkdata-certification)

[Design Review Documentation](#tr-181bulkdata-designreviewdocumentation)
# <a name="tr-181bulkdata-requirements"></a>**Requirements**
## <a name="tr-181bulkdata-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
The Bulkdata plugin fulfills two different use cases :

- Data collection based on the TR-181 data model
- Transfer of the collected data to a remote location. Targeted methods are :
  - Push! events sent on the USP channel.
  - *Upload through a separate HTTP(S) push.* 
    - *HTTP support must be implemented using the libfiletransfer*
  - MQTT uploads must be supported.
- It must be possible to access the Bulkdata model delivered by the Bulkdata TR181 component.
- The Bulkdata plugin must be TR181 compatible (<https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.BulkData.> )
  - Vendor extensions can be used but must be clearly indicated by vendor extension prefix.
- What protocol should be supported:
  - Priority 1 : USP Push! event
    - The Push! event must be generated in a way that
      - it can be sent to a remote USP controller
      - it can be caught by another service running on the CPE, on the Host, on the container.
    - Connection with the MQTT Client (using libimtp and tr181-mqttclient)
  - *Priority 2 : HTTPs*
    - *authentication methods: username/password, certificates*
- Support of Bulkdata Profiles
  - What part of the data model should be supported?
  - Focus on Support for Profiles:
    - [BulkDataColl:1 Profile](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataColl:1%20Profile) (highest priority)
      - It must be possible to configure different profiles with different collection settings (for example different parameters).
    - [BulkDataReports:1 Profile](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataReports:1%20Profile)
    - [BulkDataJSONEncoding:1 Profile](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataJSONEncoding:1%20Profile)
    - [*BulkDataCSVEncoding:1 Profile](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataCSVEncoding:1%20Profile)* 
    - [*BulkDataHTTP:1 Profile*](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataHTTP:1%20Profile)
    - [*BulkDataFileTransfer:1 Profile*](https://usp-data-models.broadband-forum.org/tr-181-2-14-1-usp.html#H.Device:2.BulkDataFileTransfer:1%20Profile)
  - It must be possible to add/delete dynamically Profiles.
  - It must be possible to add/delete dynamically Parameters in a profile.
- *TR181 does not provide support for certificates* 
  - *HTTP(s) support must be implemented using libfiletransfer.*
  - Certificates can be specified in either Vendor Extensions Parameters as done for other services.
  - Either can be specified as a reference towards Device.Security.
- Bulkdata must support reboot persistence for the writable parameters.
- Bulkdata must support upgrade persistence using the pcm manager for dedicated parameters.
- The Bulkdata plugin must support the use of a defaults.d directory where more defaults.odl files can be specified
  - defaults.d/00\_bulkdata-defaults.odl
  - defaults.d/10\_bulkdata\_usp-defaults.odl
- It must be possible to define Periodic Bulkdata uploads.
  - ReportingInterval + TimeReference
## <a name="tr-181bulkdata-usecasedefinition"></a>**Use Case Definition[](https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20\(%22PCF-1062%22%2C%20%22HAPM-77%22\)%20ORDER%20BY%20type%2C%20created%20DESC)**
<https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20(%22PCF-1062%22%2C%20%22HAPM-77%22)%20ORDER%20BY%20type%2C%20created%20DESC> 
## <a name="tr-181bulkdata-references"></a>**References**
<https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.BulkData.>

PCF-1204

[MQTT Client](file:///C:/wiki/spaces/PRPLWRT/pages/165019662/MQTT+Client)
# <a name="tr-181bulkdata-architecture"></a>**Architecture**
## <a name="tr-181bulkdata-highlevelarchitecture"></a>**High Level Architecture**
![](image/HL_architecture.png) 
## <a name="tr-181bulkdata-detailedarchitecture"></a>**Detailed architecture**
![](image/detailed_architecture.png) 
## <a name="tr-181bulkdata-bulkdataservice"></a>**Bulkdata Service**
Bulkdata will be implemented as a separate amx plugin. The service is implemented using amx, and will expose a TR181 compatible Data model on the bus.

The Bulkdata data model will be based on the TR181 (USP) version, deprecated (and CWMP specific) parameters will not be taken into account.
### <a name="tr-181bulkdata-bulkdataprofile:mqtt"></a>**Bulkdata Profile: MQTT**
Bulkdata will use the TR181-MQTTClient, the configuration of the MQTT Broker should be done under Device.MQTT.Client.

The communication will between Bulkdata and MQTT Client is using a direct socket connection (libimtp).
### <a name="tr-181bulkdata-bulkdataprofile:http(s)"></a>**Bulkdata Profile: HTTP(s)**
For the Bulkdata HTTP(S) Profile, libfiletransfer will be used to set up a connection to a HTTP(s) Server.  libfiletransfer is a front-end for (lib)curl.

In The current TR181 data model, the possibilities for HTTP(s) authentication are limited, only username/password authentication is in scope.
# <a name="tr-181bulkdata-implementation"></a>**Implementation**
## **Bulkdata service**
The service is implemented as an ambiorix plugin and exposes a TR-181 Data model. As the plugin relies on time/date based schedules, it is important to have time sync.

It is also possible to trigger a manual collection.
### <a name="tr-181bulkdata-mod_dmext"></a>**mod\_dmext**
This module is used to add Data model limitations, Parameter validation functions.
### <a name="tr-181bulkdata-libsahtrace"></a>**libsahtrace**
SAH trace macros are used to log INFO, NOTICE, WARNING, ERROR messages. limited functionality is provided to enable different log levels.
```
 // default\_log\_level = 200 /\* log WARNING, ERROR's \*/



 sahtrace = {

    type = "syslog",

    level = "${default\_log\_level}"

};

trace-zones = {

    "bulkdata" = "${default\_trace\_zone\_level}",

    "profile" = "${default\_trace\_zone\_level}",

    "events" = "${default\_trace\_zone\_level}",

    "parameter" = "${default\_trace\_zone\_level}",

    "csv\_encoding" = "${default\_trace\_zone\_level}",

    "json\_encoding" = "${default\_trace\_zone\_level}",

    "http" = "${default\_trace\_zone\_level}",

    "mqtt" = "${default\_trace\_zone\_level}",

    "request\_uri\_parameter" = "${default\_trace\_zone\_level}",

    "actions" = "${default\_trace\_zone\_level}"

};
```
### <a name="tr-181bulkdata-libimtp"></a>**libimtp**
Bulkdata supports an MQTT profile. It uses the MQTT Client to connect to a broker. As the MQTT Client is a separate service (and a different linux process), a unix domain socket is used to communicate between Bulkdata/MQTTClient.

libimtp is (re)used for this purpose. It helps the service to set up the unix domain socket, and it uses a simple TLV (Type, Length, Value) based protocol to communicate. (libimtp is developed for USP and part of the TR369 protocol)

In order to Connect to the unix domain socket. The Bulkdata calls the MQTT.Client.1.CreateListenSocket(uri, topics) function. This socket can then be used to communicate with the TR181 MQTT client.

![](image/libimtp.png) 
### <a name="tr-181bulkdata-bulkdatauspagentinteraction"></a>**Bulkdata USPAgent interaction**
TR181 specifies how to use of the Controller Parameter in a profile. This requires some interaction with the USP Agent.

When a Bulkdata Profile is created by a USP Controller, the read-only parameter needs to be filled in by the USP Agent with the correct LocalAgent Controller reference.

Based on this Controller parameter, Bulkdata must decide if it is allowed to get the Parameters or not.
## <a name="tr-181bulkdata-datamodel"></a>**Data Model**
|**Name**|**Type**|**W/P/V**|**Description**|**Legal Values/Default**|**Action on Add/Delete/Modify**|**Version**|
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
|**BulkData**|**Object**|**RWP**|**This object provides bulk data collection capabilities and global collection settings that affect the entire device. Bulk Data utilizes various solutions (e.g., IPDR, HTTP) to collect data from devices and transfer the data to a collection server. The IPDR solution is based on a service specification described in [TR-232](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=TR-232&linkCreation=true&fromPageId=417176497). The HTTP solution is based on transfer mechanisms described in [Annex A/TR-369](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Annex+A%2FTR-369&linkCreation=true&fromPageId=417176497). The USPEventNotif solution is based on sending a Profile.i.Push! Event Notification via USP [TR-369](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=TR-369&linkCreation=true&fromPageId=417176497). The Bulk Data Collection Profiles are measured over a reporting interval (which can be aligned with absolute time) and are made available to the collection server.**|**–**||**1.0**|
|Enable|bool|RWP|Enables or disables all collection profiles. If false, bulk data will not be collected or reported.|**default**:|–|1\.0|
|Status|string|R|Indicates the status of the Bulk Data Collection mechanism. Enumeration of: - Enabled (Bulk Data Collection is enabled and working as intended) - Disabled (Bulk Data Collection is disabled) - Error (Bulk Data Collection is enabled, but there is an error condition preventing the successful collection of bulk data, OPTIONAL)|**default**: Disabled|–|1\.0|
|MinReportingInterval|uint32|R|Minimum reporting interval in seconds that the CPE is capable of supporting. A value of 0 indicates no minimum reporting interval.|**default**:|–|1\.0|
|Protocols|csv\_string|R|Comma-separated list of strings. Represents the IPDR and transport protocols that this device is capable of supporting. Each list item is an enumeration of: - Streaming (IPDR Streaming Protocol [IPDR-SP](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IPDR-SP&linkCreation=true&fromPageId=417176497)) - File (IPDR File Transfer Protocol [IPDR-FTP](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IPDR-FTP&linkCreation=true&fromPageId=417176497)) - HTTP (Hypertext Transfer Protocol [RFC2616](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=RFC2616&linkCreation=true&fromPageId=417176497)) - MQTT (Message Queuing Telemetry Transport [MQTT31](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=MQTT31&linkCreation=true&fromPageId=417176497), [MQTT311](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=MQTT311&linkCreation=true&fromPageId=417176497), and [MQTT50](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=MQTT50&linkCreation=true&fromPageId=417176497)) - USPEventNotif (User Services Platform (USP - [Annex A/TR-369](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Annex+A%2FTR-369&linkCreation=true&fromPageId=417176497)) Event Notification)|**default**: MQTT,USPEventNotif|–|1\.0|
|EncodingTypes|csv\_string|R|Comma-separated list of strings. Represents the Encoding Types for the protocols that this device is capable of supporting. Each list item is an enumeration of: - XML (Used with the IPDR Streaming and File Protocols. [IPDR-XML](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IPDR-XML&linkCreation=true&fromPageId=417176497)) - XDR (Used with the IPDR Streaming and File Protocols. [IPDR-XDR](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=IPDR-XDR&linkCreation=true&fromPageId=417176497)) - CSV (Comma Separated Values. Used with the HTTP and USPEventNotif Protocols. [RFC4180](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=RFC4180&linkCreation=true&fromPageId=417176497)) - JSON (JavaScript Object Notation. Used with the HTTP and USPEventNotif Protocols. [RFC7159](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=RFC7159&linkCreation=true&fromPageId=417176497))|**default**: JSON|–|1\.0|
|ParameterWildCardSupported|bool|R|When true, the Device supports the use of wildcards to determine the parameters that are reported using a Profile.|**default**: true|–|1\.0|
|MaxNumberOfProfiles|int32|R|The maximum number of profiles that can exist at any given time. Specifically, the maximum number of Profile.i. instances that the Controller can create. If the value of this parameter is -1, then it means that the CPE doesn't have a limit to the number of profiles that can exist.|**default**:|–|1\.0|
|MaxNumberOfParameterReferences|int32|R|The maximum number of parameters that can be referenced via the bulk data collection mechanism. Specifically, the maximum number of parameters that can be referenced via Profile.i.Parameter.i.Reference across all Profile and Parameter instances (including the expansion of partial paths within the Reference parameter). If the value of this parameter is -1, then it means that the CPE doesn't have a limit to the number of parameter that can be referenced via the bulk data collection mechanism.|**default**:|–|1\.0|
|**BulkData.Profile.i**|**Object**|**RWP**|**A set of Bulk Data Collection profiles. Each profile represents a bulk data report, including its own timing configuration, communications configuration, and set of parameters. This allows the Controller to configure multiple reports to be generated at different times for different sets of data. At most one entry in this table can exist with a given value for Alias. On creation of a new table entry, the Agent MUST choose an initial value for Alias such that the new entry does not conflict with any existing entries. The non-functional key parameter Alias is immutable and therefore MUST NOT change once it's been assigned.**|**–**||**1.0**|
|ProfileNumberOfEntries|uint32|RW|The number of entries in the Profile table.|**default**:|–|1\.0|
|Enable|bool|RWP|Enables or disables this specific bulk data profile. If false, this profile will not be collected or reported.|**default**: false|–|1\.0|
|Alias|string|RWP|[Alias](https://confluence.softathome.com/pages/createpage.action?spaceKey=PRPLWRT&title=Alias&linkCreation=true&fromPageId=417176497) A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference. The following mandatory constraints MUST be enforced: - The value MUST NOT be empty. - The value MUST start with a letter. - If the value is not assigned by the Controller at creation time, the Agent MUST assign a value with an "cpe-" prefix. The value MUST NOT change once it's been assigned.|**default**:|–|1\.0|
|Name|string|RWP|The name of the profile.|**default**:|–|1\.0|
|Controller|string|R|<p>The value MUST be the Path Name of the Device.LocalAgent.Controller. instance that created or last updated this Profile. If the referenced object is deleted, the parameter value MUST be set to an empty string. The value of this parameter is automatically populated by the USP Agent upon Profile creation using the reference to the USP Controller that created the instance. The value of this parameter is automatically updated by the USP Agent upon Profile alteration using the reference to the USP Controller that changed the instance.</p><p>Not Yet Supported.</p>|**default**:|–|1\.0|
|NumberOfRetainedFailedReports|int32|RWP|The number of failed reports to be retained and transmitted (in addition to the current report) at the end of the current reporting interval. If the value of the EncodingType parameter is modified any outstanding failed reports are deleted. If the CPE cannot retain the number of failed reports from previous reporting intervals while transmitting the report of the current reporting interval, then the oldest failed reports are deleted until the CPE is able to transmit the report from the current reporting interval. 0 indicates that failed reports are not to be retained, -1 indicates that the CPE will retain as many failed reports as possible.|**default**: 0|–|1\.0|
|Protocol|string|RWP|The value MUST be a member of the list reported by the Protocols parameter. The Bulk Data Protocol being used for this collection profile.|**default**: MQTT|–|1\.0|
|EncodingType|string|RWP|The value MUST be a member of the list reported by the EncodingTypes parameter. The Bulk Data encoding type being used for this collection profile.|**default**: JSON|–|1\.0|
|ReportingInterval|uint32|RWP|The reporting interval in seconds. Each report is generated based on this interval and TimeReference. The CPE MAY reject a request to set ReportingInterval to less than MinReportingInterval. Reporting intervals MUST begin every ReportingInterval seconds. If ReportingInterval is changed while collection is enabled, the first reporting interval begins immediately. For example, if ReportingInterval is 86400 (a day) and if TimeReference is set to UTC midnight on some day (in the past, present, or future) then the CPE will generate (and transmit, if the Protocol parameter is set to Streaming) its report at midnight every 24 hours.|**default**: 86400|–|1\.0|
## <a name="tr-181bulkdata-low-levelapi"></a>**Low-Level API**
N/A
## <a name="tr-181bulkdata-api"></a>**API**
High Level API is fully based on TR181.

<https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.BulkData.Profile.>
## <a name="tr-181bulkdata-files"></a>**Files**
Standard amx files apply under /etc/amx/tr181-bulkdata/

- defaults can be added /etc/amx/tr181-bulkdata/tr181-bulkdata\_defaults/
- Persistent configuration is saved here: /etc/config/tr181-bulkdata/odl/
- upgrade persistent files is done here; /cfg/pcm/\*
- Start-up script: /etc/init.d/tr181-bulkdata
## <a name="tr-181bulkdata-firewall"></a>**Firewall**
N/A
## <a name="tr-181bulkdata-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="tr-181bulkdata-dependants"></a>**Dependants**
- amx: Bulkdata uses the amx framework to export a Data model on the bus.
- TR181 MQTT Client is used to transfer information using MQTT.
- libfiletransfer will be used to implement the HTTP(S) transfer.
- Time synchronisation. (TR181-Time)
### <a name="tr-181bulkdata-dependencies"></a>**Dependencies**
- Persistent configuration manager will need to handle upgrade persistent configuration.
- libimpt is used to communicate with the TR181 MQTT Client.
## <a name="tr-181bulkdata-configuration"></a>**Configuration**
- No default profiles will be provided
- In a typical scenario, Bulkdata Profiles will be configured based on the needs of the customer. These configured profiles needs to be stored in the /etc/amx/tr181-bulkdata/tr181-bulkdata\_defaults/ (using the odl format)
## <a name="tr-181bulkdata-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
- Parameters marked with %upc, %usersettings will be upgrade persistent.
## <a name="tr-181bulkdata-webui"></a>**Web UI**
The UI can modify the bulkdata service if needed (using the TR181 data model)
# <a name="tr-181bulkdata-considerations"></a>**Considerations**
## <a name="tr-181bulkdata-ipv6"></a>**IPv6**
Bulkdata can work on IPv4/IPv6.

- For MQTT, it depends on the MQTT client configuration.
- For HTTP(s) it depends on FQDN name resolving. (IPversion to take into account)
## <a name="tr-181bulkdata-packetacceleration"></a>**Packet Acceleration**
N/A
## <a name="tr-181bulkdata-memoryusage"></a>**Memory Usage**
Memory usage depends on the amount of (active) profiles and the number of parameters considered in a profile.

The RAM usage is depending on the Profiles configuration, Doing a upload of the full data model “Device.?” can therefor have a serious impact on RAM usage (and perfomance). As Bulkdata does a get on the Data model of all services, it’s the micro services' responsibility to return the data and return it efficiently!.
## <a name="tr-181bulkdata-boottime"></a>**Boot Time**
No impact foreseen on Boot time.
## <a name="tr-181bulkdata-security"></a>**Security**
- ACL must be used to secure Bulkdata Profiles from modified by Services which are not allowed to do so.
- HTTP(S) mutual authentication must be possible through configuration of the Device.Security.
- Bulkdata Profiles created by USP (the Controller Parameter is set), must have limited access right, and should only have access to parameter which matches the ACL configuration.
## <a name="tr-181bulkdata-remotemanagement"></a>**Remote Management**
Bulkdata can configured via the TR181 data model by TR369, TR69, UI, and other management processes using the TR181 DM.
## <a name="tr-181bulkdata-operationalmonitoring"></a>**Operational Monitoring**
Syslog messages are used to monitor the operational state of Bulkdata.
# <a name="tr-181bulkdata-quality"></a>**Quality**
## <a name="tr-181bulkdata-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="tr-181bulkdata-build-timechecks"></a>**Build-time Checks**
## <a name="tr-181bulkdata-run-timechecks"></a>**Run-time Checks**
The goal is to enable CDRouter tests as CI criteria.
## <a name="tr-181bulkdata-unittests"></a>**Unit Tests**
The Service is covered by Unit tests. ( +80% coverage)
## <a name="tr-181bulkdata-logginganddebugging"></a>**Logging and Debugging**
SAH\_trace library is used for debug logs.
## <a name="tr-181bulkdata-functionaltests"></a>**Functional Tests**
### <a name="tr-181bulkdata-validatingbulkdatareportsviabulkdata.profile.{i}.push!event"></a>**Validating bulkdata reports via BulkData.Profile.{i}.Push! event**
- Add a listener on bulkdata

BulkData.?&

- Check BulkData is disabled by default (Enable=0 and Status=Disabled)

\> BulkData.?&

BulkData

BulkData.ProfileNumberOfEntries=0

BulkData.ParameterWildCardSupported=1

BulkData.Status=Disabled

BulkData.EncodingTypes=JSON

BulkData.MinReportingInterval=0

BulkData.Enable=0

BulkData.MaxNumberOfParameterReferences=0

BulkData.MaxNumberOfProfiles=0

BulkData.Protocols=USPEventNotif

BulkData.Profile

- Enable BulkData

BulkData.Enable=true

- Check Status changed to Enabled

\> BulkData.Enable=true

BulkData.Enable=1
```
[2022-02-09T23:06:22Z] BulkData.[dm:object-changed|1000]{object=BulkData., parameters=

{

    Enable : 

    {

        from : 0,

        to   : 1

    }

}, path=BulkData.}

[2022-02-09T23:06:22Z] BulkData.Enable=1

[2022-02-09T23:06:22Z] BulkData.[dm:object-changed|1000]{object=BulkData., parameters=

{

    Status : 

    {

        from : Disabled,

        to   : Enabled

    }

}, path=BulkData.}

[2022-02-09T23:06:22Z] BulkData.Status=Enabled
```
- Create a profile with Protocol=USPEventNotif and Enable=true

BulkData.Profile.+{Protocol=USPEventNotif, Enable=true}

- Set ReportingInterval low enough for testing

BulkData.Profile.cpe-Profile-1.ReportingInterval=15

- Add a simple Parameter instance for basic testing

BulkData.Profile.cpe-Profile-1.Parameter.+{Reference="Device.DeviceInfo.SerialNumber"}

- Check Push notif is correctly sent every <ReportingInterval> seconds
```
[2022-02-09T23:07:54Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448074281

        }

    ]

}, path=BulkData.Profile.1.}

[2022-02-09T23:08:09Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448089274

        }

    ]

}, path=BulkData.Profile.1.}

[2022-02-09T23:08:24Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448104275

        }

    ]

}, path=BulkData.Profile.1.}
```
- Check notif format:
  - notif name is Push
  - notif contains a Data object
  - Data object contains a Report array
  - Report array contains, in a map, the requested parameter in the format <Reference> : <value>
```
[2022-02-09T23:08:24Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448104275

        }

    ]

}, path=BulkData.Profile.1.}
```
- Set TimeReference

BulkData.Profile.cpe-Profile-1.TimeReference=2021-07-25T22:22:22Z

- Check Push notif is sent according to <TimeReference>
```
[2022-02-09T23:09:22Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448162558

        }

    ]

}, path=BulkData.Profile.1.}

[2022-02-09T23:09:37Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.DeviceInfo.SerialNumber : BCM963128ref0000,

            CollectionTime                 : 1644448177552

        }

    ]

}, path=BulkData.Profile.1.}
```
- Add several instances of parameter to cover the following cases
  - Parameter (already added)
  - Object
  - Wildcard Parameter
  - Wildcard Object

BulkData.Profile.cpe-Profile-1.Parameter.+{Reference="Device.DeviceInfo.MemoryStatus."}

BulkData.Profile.cpe-Profile-1.Parameter.+{Reference="Device.Services.X\_SOFTATHOME-COM\_SSH.\*.Enable"}

BulkData.Profile.cpe-Profile-1.Parameter.+{Reference="Device.Services.VoiceService.1.POTS.FXS.\*.DiagTests."}

- Check all previous <Reference> values are correctly retrieved
```
[2022-02-09T23:15:37Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            Device.Services.X\_SOFTATHOME-COM\_SSH.1.Enable                        : true,

            Device.Services.VoiceService.1.POTS.FXS.2.DiagTests.TestSelector     : REN,

            Device.Services.X\_SOFTATHOME-COM\_SSH.2.Enable                        : false,

            Device.Services.VoiceService.1.POTS.FXS.2.DiagTests.DiagnosticsState : None,

            Device.Services.VoiceService.1.POTS.FXS.2.DiagTests.TestResult       : ,

            Device.Services.VoiceService.1.POTS.FXS.1.DiagTests.TestResult       : ,

            Device.DeviceInfo.MemoryStatus.Free                                  : 1878360,

            Device.DeviceInfo.MemoryStatus.Total                                 : 2039040,

            Device.DeviceInfo.SerialNumber                                       : BCM963128ref0000,

            Device.Services.VoiceService.1.POTS.FXS.1.DiagTests.TestSelector     : REN,

            Device.Services.VoiceService.1.POTS.FXS.1.DiagTests.DiagnosticsState : None,

            CollectionTime                                                       : 1644448537600

        }

    ]

}, path=BulkData.Profile.1.}
```
- Set Name parameter for the 4 Parameter instances

BulkData.Profile.cpe-Profile-1.Parameter.1.Name=SN

BulkData.Profile.cpe-Profile-1.Parameter.2.Name=MemStatus

BulkData.Profile.cpe-Profile-1.Parameter.3.Name=SSHEnable

BulkData.Profile.cpe-Profile-1.Parameter.4.Name=DiagTestsFXS

- Check <Reference> are replaced correctly with <Name> (for wildcard, instances must be visible in the key)
```
[2022-02-09T23:19:22Z] BulkData.Profile.cpe-Profile-1.[Push|1000]{object=BulkData.Profile.cpe-Profile-1., Data=

{

    Report : 

    [

        {

            DiagTestsFXS.1.TestSelector     : REN,

            SSHEnable.1                     : true,

            SN                              : BCM963128ref0000,

            MemStatus.Free                  : 1878072,

            SSHEnable.2                     : false,

            DiagTestsFXS.2.TestResult       : ,

            DiagTestsFXS.2.DiagnosticsState : None,

            DiagTestsFXS.2.TestSelector     : REN,

            MemStatus.Total                 : 2039040,

            DiagTestsFXS.1.DiagnosticsState : None,

            DiagTestsFXS.1.TestResult       : ,

            CollectionTime                  : 1644448762603

        }

    ]

}, path=BulkData.Profile.1.}
```
### <a name="tr-181bulkdata-citests"></a>**CI Tests**
## <a name="tr-181bulkdata-certification"></a>**Certification**
# <a name="tr-181bulkdata-designreviewdocumentation"></a>**Design Review Documentation**
