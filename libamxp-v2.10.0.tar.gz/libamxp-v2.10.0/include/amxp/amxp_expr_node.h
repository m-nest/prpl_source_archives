/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__AMXP_EXPR_NODE_H__)
#define __AMXO_EXPR_NODE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include <amxp/amxp_expression.h>

/**
   @file
   @brief
   Ambiorix binary expression tree node functions
 */

/**
   @ingroup amxp_expression
   @defgroup amxp_expr_node Expression Tree

   Functions to access node information in a binary expression tree
 */

/**
   @ingroup amxp_expr_node
   @brief
   Node types, corresponds to the expression parts introduced in @ref _amxp_expr expression
 */
typedef enum _amxp_expr_node_type {
    amxp_expr_compare_oper, /**< Node is a compare operator */
    amxp_expr_value,        /**< Node is a constant value */
    amxp_expr_value_func,   /**< Node is a function that returns a value */
    amxp_expr_bool_func,    /**< Node is a function that returns a boolean */
    amxp_expr_field,        /**< Node is a field value */
    amxp_expr_not,          /**< Node is a NOT logical operator ("not"/"!") */
    amxp_expr_and,          /**< Node is an AND logical operator ("and"/"&&") */
    amxp_expr_or            /**< Node is an OR logical operator ("or"/"||") */
} amxp_expr_node_type_t;

/**
   @ingroup amxp_expr_node
   @brief
   Compare operator types
   (associated to amxp_expr_compare_oper nodes).
 */
typedef enum _amxp_expr_comp {
    amxp_expr_comp_invalid = -1,      /**< Invalid compare operator */
    amxp_expr_comp_equal,             /**< Is equal comparison ("==") */
    amxp_expr_comp_not_equal,         /**< Is not equal comparison ("!=") */
    amxp_expr_comp_lesser,            /**< Is lesser comparison ("<") */
    amxp_expr_comp_bigger,            /**< Is bigger comparison (">") */
    amxp_expr_comp_lesser_equal,      /**< Is lesser or equal comparison ("<=") */
    amxp_expr_comp_bigger_equal,      /**< Is bigger or equal comparison (">=") */
    amxp_expr_comp_matches,           /**< Regular expression matching ("matches") */
    amxp_expr_comp_starts_with,       /**< Beginning of string comparison ("starts with") */
    amxp_expr_comp_in,                /**< Value is in array of values comparison ("in") */
    amxp_expr_comp_contains,          /**< Array of values contains a value comparison ("~=") */
    amxp_expr_comp_equals_ignorecase, /**< Case insensitive string comparison ("^=") */
    amxp_expr_comp_ends_with,         /**< End of string comparison ("ends with") */
} amxp_expr_comp_t;

typedef void (* amxp_expr_node_fn_t) (const amxp_expr_node_t* node, void* priv);

/**
   @ingroup amxp_expr_node
   @brief
   Node entry in a binary expression tree

   Stores the type, the associated data if it exists,
   and pointers the next nodes in the tree.
 */
struct _amxp_expr_node {
    amxc_llist_it_t it;         /**< List iterator (for insertion in the tree) */
    amxp_expr_node_type_t type; /**< Type of the node */
    amxp_expr_comp_t compare;   /**< Type of compare operator if node is of type compare operator */
    amxc_var_t* value;          /**< Node value if node is a field value, constant value, or function that returns a value  */
    union {                     /**< Left node information */
        amxp_expr_node_t* node; /**< Link to another node */
        amxc_var_t* value;      /**< Value when node is a constant value */
        char* func_name;        /**< Name of function when node is a function */
        char* field;            /**< Name of field when node is a field value */
    } left;
    union {                     /* Right node information */
        amxp_expr_node_t* node; /**< Link to another node */
        amxc_llist_t args;      /**< Function arguments when node is a function that returns a value */
    } right;
};

/**
   @ingroup amxp_expr_node
   @brief
   Returns the top node of a binary expression tree

   Returns an amxp_expr_node_t pointer to the first entry
   in the internal stack of nodes of an amxp_expr_t structure

   @param expr pointer to an amxp_expr_t structure, should not be NULL

   @return
   A pointer to amxp_expr_node_t, or NULL if the amxp_expr_t structure
   has no entries in its internal stack of nodes
 */
amxp_expr_node_t* amxp_expr_get_node(const amxp_expr_t* expr);

/**
   @ingroup amxp_expr_node
   @brief
   Gets the value attached to a node, if it exists

   The nodes of the following @ref amxp_expr_node_type_t types will redirect to a value :
   - amxp_expr_value
   - amxp_expr_field
   - amxp_expr_value_func
   The rest of the types will be ignored, returning NULL

   @param expr pointer to an amxp_expr_t structure, should not be NULL
   @param node pointer to an amxp_expr_node_t structure, should not be NULL

   @return
   A pointer to amxp_var_t, or NULL if the node does not point to a value
 */
amxc_var_t* amxp_expr_node_get_value(amxp_expr_t* expr, amxp_expr_node_t* node);

/**
   @ingroup amxp_expr_node
   @brief
   Evaluates an expression starting from a specific node

   @param expr pointer to an amxp_expr_t structure, should not be NULL
   @param node pointer to an amxp_expr_node_t structure

   @return
   - true when the expression evaluates to true
   - false when the expression evaluates to false
 */
bool amxp_expr_node_eval(amxp_expr_t* expr, amxp_expr_node_t* node);

/**
 * @ingroup amxp_expr_node
 * @brief Iterates over all nodes in an expression tree and calls a callback function for each node that matches
 *        the specified type.
 *
 * This function traverses through all nodes in an expression tree and performs a specific action on nodes of a certain type.
 *
 * The function doesn't produce any direct outputs, but instead executes the provided callback function on each
 * matching node it finds.
 *
 * The way it works is by first getting the root node of the expression tree using @ref amxp_expr_get_node.
 * Then it recursively walks through the entire tree structure. As it traverses the tree,
 * it checks each node's type against the requested type.
 * When it finds a matching node, it executes the callback function, passing both the node and the private data as parameters.
 *
 * This function essentially provides a way to visit and process specific types of nodes in an expression tree structure,
 * which is useful for operations like evaluation, validation, or transformation of expressions.
 *
 * @param expr Pointer to the amxp_expr_t structure containing the expression tree.
 * @param type The type of nodes to include in the iteration, specified using the amxp_expr_node_type_t enumeration.
 * @param cb The callback function to call for each matching node.
 *           The callback function should have the signature `void (*amxp_expr_node_fn_t)(const amxp_expr_node_t* node, void* priv)`.
 * @param priv A private data pointer that will be passed to the callback function.
 */
void amxp_expr_for_all_nodes(const amxp_expr_t* expr, amxp_expr_node_type_t type, amxp_expr_node_fn_t cb, void* priv);

/**
 * @brief Gets the name of the field associated with the given expression node.
 *
 * This function retrieves the field name from an expression node.
 *
 * This function takes one input: a pointer to an expression node (const amxp_expr_node_t* node).
 * The node represents part of an expression tree structure used for evaluating conditions or expressions.
 *
 * The function outputs a string (const char*) which contains the field name stored in the node, or NULL if there is no valid field name to return.
 *
 * It verifies if the node is specifically of type "field" (amxp_expr_field) - if not, it returns NULL
 *
 * The purpose of this function is to provide a safe way to access the field name stored within an expression node.
 * It's commonly used when working with expression trees where nodes can represent different parts of an expression,
 * including field references.
 * The function ensures that callers can only get field names from nodes that actually represent fields,
 * preventing invalid access attempts.
 *
 * @param node The expression node to get the field name for.
 * @return The name of the field, or NULL if the node is not of type amxp_expr_field.
 */
const char* amxp_expr_node_field_name(const amxp_expr_node_t* node);

/**
 * @brief Gets the left child node of the given expression node.
 *
 * This function is designed to get the left child node from an expression tree node.
 * Think of it like getting the left branch of a tree structure that represents a logical expression.
 *
 * The function takes one input: a pointer to a constant expression node (const amxp_expr_node_t* node).
 * This node represents a part of an expression tree structure.
 *
 * The output is another constant expression node pointer that represents the left child of the input node.
 * If there is no valid left child or if the input is invalid, it returns NULL.
 *
 * The function works by first checking if the input node exists (is not NULL).
 * Then it looks at the type of the node and only returns the left child for specific types of nodes:
 *  - comparison operators
 *  - AND operations
 *  - OR operations
 *  - NOT operations
 *
 * For these types, it returns the node stored in the left.node field of the input node.
 * For all other node types, it returns NULL.
 *
 * This function is particularly useful when traversing or analyzing expression trees,
 * as it provides a way to navigate to the left side of any expression node.
 * It's commonly used in expression parsers and evaluators to process logical expressions.
 *
 * @param node The expression node to get the left child for.
 * @return The left child node, or NULL if the node has no left child.
 */
const amxp_expr_node_t* amxp_expr_node_left(const amxp_expr_node_t* node);

/**
 * @brief Gets the right child node of the given expression node.
 *
 * This function is designed to get the right-hand node from an expression tree node structure.
 * Think of it like getting the right branch of a tree structure that represents a logical expression.
 *
 * The function takes one input: a pointer to a constant expression node (const amxp_expr_node_t* node).
 * This node represents a part of an expression tree structure.
 *
 * The output is another constant expression node pointer that represents the right child of the input node.
 * If there is no valid right child or if the input is invalid, it returns NULL.
 *
 * The function works by first checking if the input node exists (is not NULL).
 * Then it looks at the type of the node and only returns the right child for specific types of nodes:
 *  - comparison operators
 *  - AND operations
 *  - OR operations
 *
 * For these types, it returns the node stored in the right.node field of the input node.
 * For all other node types, it returns NULL.
 *
 * This function is particularly useful when traversing or analyzing expression trees,
 * as it provides a way to navigate to the right side of any expression node.
 * It's commonly used in expression parsers and evaluators to process logical expressions.
 *
 * @param node The expression node to get the right child for.
 * @return The right child node, or NULL if the node has no right child.
 */
const amxp_expr_node_t* amxp_expr_node_right(const amxp_expr_node_t* node);

/**
 * @brief Gets the operator associated with the given expression node.
 *
 * This function extracts the comparison operator from an expression node in a syntax tree.
 * It takes a single input parameter - a pointer to an expression node (const amxp_expr_node_t* node)
 * and returns an enumerated type amxp_expr_comp_t that represents different kinds of comparison operators
 * (like equals, not equals, less than, etc.).
 *
 * It verifies the node is specifically a comparison operator type node (amxp_expr_compare_oper).
 * For all other node types the function returns amxp_expr_comp_invalid.
 *
 * The function acts as a safe getter method, ensuring that we only try to get comparison operators from nodes
 * that actually contain them. This prevents errors that could occur from trying to get operators from the wrong
 * types of nodes in the expression tree.
 *
 * @param node The expression node to get the operator for.
 * @return The operator of the expression node, as specified by the amxp_expr_comp_t enumeration.
 */
amxp_expr_comp_t amxp_expr_node_operator(const amxp_expr_node_t* node);

/**
 * @brief Gets the type of the given expression node.
 *
 * This function serves as a simple getter method that returns the type of an expression node.
 * It takes a single input parameter - a pointer to a constant expression node (const amxp_expr_node_t* node)
 * and returns an enumerated type value (amxp_expr_node_type_t) representing the node's type.
 *
 * This function is particularly useful when code needs to determine what kind of expression node it's dealing with,
 * which could be things like a value node, comparison operator node, logical operator node (AND/OR), or other types defined
 * in the expression system.
 * By providing a safe way to access this information, other parts of the code can make decisions about how to process or
 * handle different types of nodes appropriately.
 *
 * @param node The expression node to get the type for.
 * @return The type of the expression node, as specified by the amxp_expr_node_type_t enumeration.
 */
amxp_expr_node_type_t amxp_expr_node_type(const amxp_expr_node_t* node);

/**
 * @brief Gets the name of the function associated with the given expression node.
 *
 * This function retrieves the name of a function stored within an expression node.
 *
 * This function takes a single input parameter - a pointer to an expression node (const amxp_expr_node_t* node).
 * The node represents a piece of an expression tree used for evaluating conditions.
 *
 * The function returns a string (const char*) which contains the function name if one exists, or NULL if there
 * isn't one or if the node is invalid.
 *
 * If the node type is either amxp_expr_value_func or amxp_expr_bool_func, it returns the function name stored in the node.
 *
 * The purpose of this function is to provide a safe way to access the function name stored in expression nodes
 * that represent function calls. It's particularly useful when you need to inspect or analyze the structure of an
 * expression tree, such as during debugging or when processing expressions.
 *
 * @param node The expression node to get the function name for.
 * @return The name of the function, or NULL if the node is not of type amxp_expr_function.
 */
const char* amxp_expr_node_func_name(const amxp_expr_node_t* node);

/**
 * @brief Gets the value associated with the given expression node.
 *
 * This function retrieves the value stored in an expression node. Here's a simple breakdown:
 *
 * The function takes a single input parameter - a pointer to an expression node (const amxp_expr_node_t* node).
 * This node represents a piece of data in an expression tree structure.
 *
 * The output is a pointer to a variable (const amxc_var_t*) that contains the actual value stored in the node.
 * If something goes wrong, it returns NULL instead.
 *
 * The function performs two safety checks:
 * - Verifies that the input node isn't NULL
 * - Checks if the node's type is amxp_expr_value
 *
 * The function acts like a safe getter method - it provides controlled access to the value stored inside an
 * expression node while ensuring the node exists and is of the correct type.
 * This helps prevent errors that could occur if someone tried to get a value from the wrong type of node or
 * from a non-existent node.
 *
 * @param node The expression node to get the value for.
 * @return The value of the expression node, or NULL if the node does not have a value.
 */
const amxc_var_t* amxp_expr_node_value(const amxp_expr_node_t* node);

#ifdef __cplusplus
}
#endif

#endif // __AMXP_EXPR_NODE_H__

