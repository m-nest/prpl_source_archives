/**
 * @file mod-network-selector.c
 *
 * @brief This file contains implementation of mod network selector functionalities.
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxm/amxm.h>
#include <amxd/amxd_dm.h>
#include "mod-network-selector.h"

static amxm_module_t* mod = NULL;

/**
 * @brief             select_wanmode
 *
 * @detail            This function iterates through available network modes and selects the
 *                    appropriate mode based on the physical type.
 *
 * @param[in] modes - Arguments containing the network modes.
 *
 * @param[in] physical_type - Arguments containing the wan mode physical type to check.
 *
 * @param[in] ret -   Variable to store the selected network mode.
 *
 * @retval rv     -   Returns 1 if successful, 0 in case failure
 */
int select_wanmode(amxc_var_t* modes, const char* physical_type, amxc_var_t* ret) {
    int mode_selected = 0;
    bool enableSensing = false;
    const char* sfpType = NULL;
    const char* phyType = NULL;
    amxc_var_t* curr_mode = NULL;

    when_null_trace(physical_type, exit, ERROR, "Physical type is NULL. Cannot proceed with WAN mode selection.");
    when_null_trace(ret, exit, ERROR, "Cannot copy selected wanmode. Cannot proceed with WAN mode selection.");
    when_null_trace(modes, exit, ERROR, "Passed wan modes is NULL. Cannot proceed with WAN mode selection.");

    curr_mode = amxc_var_get_first(modes);

    // Iterating in all the available wan modes
    while((mode_selected == 0) && (curr_mode != NULL)) {
        // Retrieve attributes of the current mode
        sfpType = GET_CHAR(curr_mode, "SFPType");
        if(sfpType == NULL) {
            goto exit;
        }

        phyType = GET_CHAR(curr_mode, "PhysicalType");
        if(phyType == NULL) {
            goto exit;
        }

        enableSensing = GET_BOOL(curr_mode, "EnableSensing");

        if((strncmp(phyType, PHYSICAL_TYPE_ETH_STR, strlen(PHYSICAL_TYPE_ETH_STR)) == 0) &&
           (strncmp(physical_type, PHYSICAL_TYPE_ETH_STR, strlen(PHYSICAL_TYPE_ETH_STR)) == 0) &&
           (enableSensing == true)) {
            mode_selected = 1;
            amxc_var_copy(ret, curr_mode);
            break;
        }

        if((strncmp(phyType, PHYSICAL_TYPE_SFP_STR, strlen(PHYSICAL_TYPE_SFP_STR)) == 0) &&
           (strncmp(physical_type, PHYSICAL_TYPE_SFP_STR, strlen(PHYSICAL_TYPE_SFP_STR)) == 0) &&
           (strlen(sfpType) > 1)) {
            mode_selected = 1;
            amxc_var_copy(ret, curr_mode);
            break;
        }

        if((strncmp(phyType, PHYSICAL_TYPE_GPN_STR, strlen(PHYSICAL_TYPE_GPN_STR)) == 0) &&
           (strncmp(physical_type, PHYSICAL_TYPE_GPN_STR, strlen(PHYSICAL_TYPE_GPN_STR)) == 0) &&
           (strlen(sfpType) > 1)) {
            mode_selected = 1;
            amxc_var_copy(ret, curr_mode);
            break;
        }

        // Move to the next mode
        curr_mode = amxc_var_get_next(curr_mode);
    }

exit:
    return mode_selected;
}

/**
 * @brief           detect_network
 *
 * @detail          This function checks the available WAN modes,
 *                  giving priority to the optical WAN modes.
 *                  If no optical WAN mode is selected,
 *                  then an Ethernet mode with auto-sensing enabled is selected.
 *                  The selected mode is then set in the WAN Manager using the "set-wan-mode" function.
 *
 * @param[in] args - Arguments containing the list of WAN  modes.
 *
 * @param[in] ret -  Variable to store the selected network mode.
 *
 * @retval rv     -  Returns 0 if successful, or a non-zero error code if an error occurred.
 */
int detect_network(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int rv = 0;
    int mode_selected = 0;
    amxc_var_t* all_modes = NULL;
    amxc_var_t* selected_wanmode = NULL;

    amxc_var_new(&all_modes);
    amxc_var_new(&selected_wanmode);

    if(all_modes == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to allocate memory all_modes");
        rv = -1;
        goto exit;
    }

    if(selected_wanmode == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to allocate memory selected_wanmode");
        rv = -1;
        goto exit;
    }


    // Copy the "modes" argument into all_modes
    rv = amxc_var_copy(all_modes, GET_ARG(args, "modes"));

    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to copy wan modes");
        goto exit;
    }

    /*
     * The optical wan mode have more priority over the
     * ethernet wanmode. If no optical wan mode is available
     * selecting ethernet wan mode with autosensing enabled.
     */
    mode_selected = select_wanmode(all_modes, PHYSICAL_TYPE_GPN_STR, selected_wanmode);
    if(mode_selected == 0) {
        mode_selected = select_wanmode(all_modes, PHYSICAL_TYPE_SFP_STR, selected_wanmode);
    }

    if(mode_selected == 0) {
        mode_selected = select_wanmode(all_modes, PHYSICAL_TYPE_ETH_STR, selected_wanmode);
    }

    if(mode_selected) {
        // Setting the selected wanmode in wan manager using [Wan-Manager] set-mode function.
        rv = amxm_execute_function("self", MOD_DM_MNGR, "set-wan-mode", selected_wanmode, ret);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Error : failed to call [Wan-Manager]set-mode function, '%d'", rv);
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "Error : Not able to select wanmode");
    }

exit:
    amxc_var_delete(&all_modes);
    amxc_var_delete(&selected_wanmode);
    return rv;
}

/**
 * @brief Start and register functions for the mod-network-selector module.
 *
 * @return AMXM_CONSTRUCTOR always return 0.
 */
static AMXM_CONSTRUCTOR mod_network_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    // Registering module namespace and adding functions
    amxm_module_register(&mod, so, MOD_NETWORK_CTRL);
    amxm_module_add_function(mod, "detect-network", detect_network);
    return 0;
}

/**
 * @brief Stop and clean the mod-network-selector module.
 *
 * @return AMXM_DESTRUCTOR always return 0.
 */
static AMXM_DESTRUCTOR mod_network_stop(void) {
    SAH_TRACEZ_INFO(ME, "Exiting mod-network-selector destructor");
    return 0;
}
