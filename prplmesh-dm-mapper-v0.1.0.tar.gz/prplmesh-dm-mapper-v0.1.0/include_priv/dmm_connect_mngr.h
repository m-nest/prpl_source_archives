/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file dmm_connect_mngr.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief Header file describes structures and functions for
 *        services connection to the DataModel mapper.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2025 Inango
 *
 */

#ifndef _DMM_CONNECT_MNGR__
#define _DMM_CONNECT_MNGR__

#define ROOT_PATH_LEN 256 /*!< Root path length assumed as maximum 255 characters and final \0 symbol */

/**
   @ingroup dm_mapper
   @brief
   A associated list structure

   Used to track couples 'root path' <-> 'ctx connection'
   to have immediate access to ctx by knowen root path.
 */
typedef struct {
    amxb_bus_ctx_t* a_bus_ctx;       /*!< Ponter to the proper USP context for connected service */
    char root_path[ROOT_PATH_LEN];   /*!< String contains root path like X_PRPLWARE-COM-WiFiSensing */
    char mapped_path[ROOT_PATH_LEN]; /*!< mapped path (e.g. Device.WiFi.) */
    amxc_llist_it_t it;              /*!< List iterator, helps work with the list */
} actx_llist_t;

/**
 * @brief Retrieves the active bus context associated with a given data model path.
 *
 * This is a wrapper function that uses **dmm_find_ctx()** to locate the
 * correct `amxb_bus_ctx_t` structure. The context represents the connection
 * (bus) responsible for managing the root object of the specified data model
 * parameter path.
 *
 * If a connection context is successfully found, its address and backend name
 * are logged for tracing. If no context is found, an error is logged.
 *
 * @param[in] param_path The full parameter path within the data model
 * (e.g., "Device.LocalAgent.MTP.1.Endpoint").
 * @return A pointer to the active `amxb_bus_ctx_t` if a connection is found
 * for the root object of the path; otherwise, returns **NULL**.
 */
amxb_bus_ctx_t* dmm_get_connection(const char* param_path);

/**
   @ingroup dm_mapper
   @brief
   Function is colled when there need creat listen socket
   Used mainly on internal goals

   @param void

   @return
   void
 */
void dmm_start_amx_listen();

#endif // _DMM_CONNECT_MNGR__
