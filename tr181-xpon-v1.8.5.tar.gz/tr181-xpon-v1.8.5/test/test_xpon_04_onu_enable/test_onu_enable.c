/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_onu_enable.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <string.h> /* strcmp() */
#include <unistd.h> /* access() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>           /* needed by amxd_dm.h */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxm/amxm.h>                  /* amxm_module_t */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "common_functions.h"   /* read_sig_alarm() */
#include "file_utils.h"         /* touch_file() */
#include "persistence_utils.h"  /* remove_persistent_files() */
#include "setup_and_teardown.h" /* setup_common() */
#include "test_constants.h"     /* STORAGE_DIR */
#include "xpon_macros.h"        /* ARRAY_SIZE() */
#include "xpon_trace.h"

#undef ME
#define ME "runtest"

static const char* const NAME_PARAMETER = "Name";
static const char* const MOD_PON_CTRL = "pon_ctrl";

static amxd_dm_t dm;
static amxo_parser_t parser;

typedef struct _func_info {
    const char* const name;
    amxm_callback_t cb;
} func_info_t;

typedef struct _expected_set_enable {
    const char* path;
    bool enable;
} expected_set_enable_t;
#define MAX_EXPECTED_SET_ENABLE_CALLS 2
static expected_set_enable_t s_expected_set_enable_calls[MAX_EXPECTED_SET_ENABLE_CALLS];
static uint32_t s_nr_of_expected_set_enable_calls = 0;
static uint32_t s_cntr_set_enable_calls = 0;

static int test_set_enable(UNUSED const char* function_name,
                           amxc_var_t* args,
                           UNUSED amxc_var_t* ret) {
    assert_non_null(args);
    assert_int_equal(amxc_var_type_of(args), AMXC_VAR_ID_HTABLE);
    const char* const path = GET_CHAR(args, "path");
    assert_non_null(path);
    const bool enable = GET_BOOL(args, "enable");
    SAH_TRACEZ_DEBUG(ME, "path='%s' enable=%d", path, enable);
    ++s_cntr_set_enable_calls;
    assert_true(s_cntr_set_enable_calls <= s_nr_of_expected_set_enable_calls);
    const uint32_t idx = s_cntr_set_enable_calls - 1;
    assert_true(idx < MAX_EXPECTED_SET_ENABLE_CALLS);
    assert_non_null(s_expected_set_enable_calls[idx].path);
    const bool path_is_ok = (strcmp(path, s_expected_set_enable_calls[idx].path) == 0);
    SAH_TRACEZ_DEBUG(ME, "idx=%u expected path='%s'", idx,
                     s_expected_set_enable_calls[idx].path);
    assert_true(path_is_ok);
    assert_true(enable == s_expected_set_enable_calls[idx].enable);

    return 0;
}

static const func_info_t MOD_PON_CTRL_FUNCS[] = {
    { .name = "set_enable", .cb = test_set_enable },
};

/**
 * Add set_enable() function to "pon_ctrl" namespace of VM.
 *
 * Register test_set_enable() as callback function for the function
 * "set_enable()" in the "pon_ctrl" namespace of the VM.
 *
 * The dummy VM mod-xpon-dummy.so has the "pon_ctrl" namespace. But it does not
 * register a callback function for the function "set_enable()". Let this
 * function do that. Then it looks to tr181-xpon as if the VM has such a
 * function. The callback function registered is test_set_enable(). It checks if
 * the invocations done by tr181-xpon are correct.
 */
static void add_set_enable_to_pon_ctrl_namespace(void) {
    int i;
    int rc;

    amxm_module_t* const pon_ctrl_module = amxm_get_module("mod-xpon-dummy", MOD_PON_CTRL);
    assert_non_null(pon_ctrl_module);

    const int n_functions = ARRAY_SIZE(MOD_PON_CTRL_FUNCS);
    for(i = 0; i < n_functions; ++i) {
        rc = amxm_module_add_function(pon_ctrl_module, MOD_PON_CTRL_FUNCS[i].name,
                                      MOD_PON_CTRL_FUNCS[i].cb);
        assert_int_equal(rc, 0);
    }
}

/**
 * Add ONU instance.
 *
 * @param[in] index: index of ONU to create, e.g. 1 to create XPON.ONU.1
 * @param[in] expected_value_for_enable: expected value of
 *     XPON.ONU.<index>.Enable on creating XPON.ONU.<index>
 */
static void add_ONU_instance(uint32_t index, bool expected_value_for_enable) {
    int rc;
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    v = amxc_var_add_key(cstring_t, &args, "path", "XPON.ONU");
    assert_non_null(v);
    v = amxc_var_add_key(uint32_t, &args, "index", index);
    assert_non_null(v);
    amxc_var_t* const keys = amxc_var_add_key(amxc_htable_t, &args, "keys", NULL);
    assert_non_null(keys);
    char name[16];
    rc = snprintf(name, 16, "ONU-%u", index);
    assert_true(rc >= 0 && rc < 16);
    v = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, name);
    assert_non_null(v);

    rc = call_xpon_mngr_pon_stat_function("dm_instance_added", &args);
    assert_int_equal(rc, 0);

    /* Call handle_events() to trigger _onu_added() */
    handle_events();

    char path[32];
    rc = snprintf(path, 32, "XPON.ONU.%u", index);
    assert_true(rc >= 0 && rc < 32);
    amxd_object_t* const obj = amxd_dm_findf(&dm, path);
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), name);

    assert_int_equal(amxd_object_get_param(obj, "Enable", &value), amxd_status_ok);
    assert_int_equal(GET_BOOL(&value, NULL), expected_value_for_enable);

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

/**
 * Enable/disable ONU, i.e. set XPON.ONU.<index>.Enable to true or false.
 *
 * @param[in] index: index of ONU to enable/disable, e.g. 1 for XPON.ONU.1
 * @param[in] enable: true to enable the ONU, false to disable
 */
static void enable_ONU_instance(uint32_t index, bool enable) {
    int rc;
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    char path[32];
    rc = snprintf(path, 32, "XPON.ONU.%u", index);
    assert_true(rc >= 0 && rc < 32);
    v = amxc_var_add_key(cstring_t, &args, "path", path);
    assert_non_null(v);

    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    assert_non_null(parameters);
    v = amxc_var_add_key(bool, parameters, "Enable", enable);
    assert_non_null(v);

    rc = call_xpon_mngr_pon_stat_function("dm_object_changed", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* const obj = amxd_dm_findf(&dm, path);
    assert_non_null(obj);

    assert_int_equal(amxd_object_get_param(obj, "Enable", &value), amxd_status_ok);
    assert_int_equal(GET_BOOL(&value, NULL), enable);

    /* Trigger _onu_enable_changed() */
    handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

static void check_onu_enabled_file_exists(uint32_t index, bool file_exists) {
    int rc;
    char onu_enabled_file[128];
    rc = snprintf(onu_enabled_file, 128, "%s/XPON.ONU.%u_enabled.txt", STORAGE_DIR, index);
    assert_true(rc >= 0 && rc < 128);
    const bool onu_enabled_exists = (access(onu_enabled_file, F_OK) == 0);
    assert_int_equal(onu_enabled_exists, file_exists);
}

/**
 * Touch <STORAGE_DIR>.XPON.ONU.<index>_enabled.txt.
 *
 * The unit tests use /tmp/tr181-xpon as STORAGE_DIR. Hence if @a index is 1,
 * the function creates /tmp/tr181-xpon/XPON.ONU.1_enabled.txt.
 */
static void create_onu_enabled_file(uint32_t index) {
    int rc;
    char onu_enabled_file[128];
    rc = snprintf(onu_enabled_file, 128, "%s/XPON.ONU.%u_enabled.txt", STORAGE_DIR, index);
    SAH_TRACEZ_DEBUG(ME, "Touch %s", onu_enabled_file);
    assert_true(rc >= 0 && rc < 128);
    const bool ok = touch_file(onu_enabled_file);
    assert_true(ok);
    const bool exists = (access(onu_enabled_file, F_OK) == 0);
    assert_true(exists);
}

/**
 * Remove all files in STORAGE_DIR and call setup_common().
 */
int test_onu_enable_setup(UNUSED void** state) {
    remove_persistent_files();
    setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);

    /**
     * Call read_sig_alarm() once. It triggers the timer to populate the XPON DM
     * at startup. It won't actually populate the DM: the call
     * 'get_list_of_instances(XPON.ONU)' fails because the dummy vendor module
     * does not implement it. But if read_sig_alarm() is not called, something
     * goes wrong in the unit tests.
     */
    read_sig_alarm();

    add_set_enable_to_pon_ctrl_namespace();

    return 0;
}

/**
 * Call teardown_common() and remove all files in STORAGE_DIR.
 *
 * It removes all files in STORAGE_DIR to not influence the other tests.
 */
int test_onu_enable_teardown(UNUSED void** state) {
    teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
    remove_persistent_files();
    return 0;
}

/**
 * Basic test of XPON.ONU.{i}.Enable.
 *
 * This test does not yet really test persistence. But it already checks if
 * tr181-xpon saves whether XPON.ONU.{i}.Enable is true when enabling the ONU.
 *
 * - Create 1 ONU: XPON.ONU.1. Check that XPON.ONU.1.Enable is false.
 * - Enable XPON.ONU.1. When tr181-xpon runs as plugin, tr181-xpon calls a
 *   couple of times a timer with a timeout period of 1 s. It checks if the ONU
 *   has an EthernetUNI and ANI. It waits with applying the Enable value towards
 *   the VM until the ONU has at least 1 EthernetUNI and 1 ANI. If that's still
 *   not the case after 5 s, tr181-xpon applies the Enable towards the VM
 *   anyway. This test does not create any EthernetUNIs or ANIs. Therefore this
 *   test calls read_sig_alarm() 6 times to ensure tr181-xpon has called the
 *   timer a few times and has decided to apply the Enable towards the VM
 *   anyway.
 * - Check that tr181-xpon did 1 set_enable() call in the "pon_ctrl" namespace
 *   of the VM with path='XPON.ONU.1" and enable=true.
 * - Check that tr181-xpon created the persistent file indicating that XPON.ONU.1
 *   should be re-enabled on startup.
 * - Disable XPON.ONU.1.
 *   Note - There is no reason to call read_sig_alarm(). tr181-xpon immediately
 *   applies the disable towards the VM.
 * - Check that tr181-xpon did 1 set_enable() call in the "pon_ctrl" namespace
 *   of the VM with path='XPON.ONU.1" and enable=false.
 * - Check that tr181-xpon removed the persistent file it created earlier.
 */
void test_onu_enable_basic(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "** test_onu_enable_basic() **");

    check_onu_enabled_file_exists(1, false);

    add_ONU_instance(1, false);
    enable_ONU_instance(1, true);

    s_nr_of_expected_set_enable_calls = 1;
    s_expected_set_enable_calls[0].path = "XPON.ONU.1";
    s_expected_set_enable_calls[0].enable = true;

    /* Trigger tr181-xpon to apply the Enable value towards the VM */
    int i;
    for(i = 0; i < 6; ++i) {
        read_sig_alarm();
    }

    /* Check that tr181-xpon did 1 set_enable() call */
    assert_int_equal(s_cntr_set_enable_calls, 1);

    check_onu_enabled_file_exists(1, true);

    s_cntr_set_enable_calls = 0;
    s_expected_set_enable_calls[0].enable = false;

    enable_ONU_instance(1, false);

    /* Check that tr181-xpon did 1 set_enable() call */
    assert_int_equal(s_cntr_set_enable_calls, 1);
    check_onu_enabled_file_exists(1, false);
}

/**
 * Trigger tr181-xpon to cancel a scheduled enabling of an ONU towards the VM.
 *
 * - Create XPON.ONU.1. Check that XPON.ONU.1.Enable is false.
 * - Enable the ONU: set XPON.ONU.1.Enable to true.
 * - Call read_sig_alarm(). This is not really needed. It causes tr181-xpon to
 *   trigger the timer one time to check if it should forward the Enable to the
 *   VM. Because the ONU does not have an EthernetUNI (and also no ANI) it does
 *   not yet apply the Enable to the VM. Check that tr181-xpon did not do any
 *   set_enable() calls.
 * - Disable the ONU. Check that the ONU did one set_enable() call to the VM to
 *   disable the ONU.
 * - Upon disabling the ONU, tr181-xpon should also have deleted the timer to
 *   forward XPON.ONU.1.Enable=true to the VM. Let's check this as follows. Call
 *   read_sig_alarm() a few times. Check that tr181-xpon did not do any
 *   set_enable() calls. This does not give a 100% guarantee that tr181-xpon
 *   deleted the timer. But I think this is the best we can get.
 */
void test_cancel_onu_enable(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "** test_cancel_onu_enable() **");
    s_cntr_set_enable_calls = 0;

    add_ONU_instance(1, false);
    enable_ONU_instance(1, true);

    read_sig_alarm();
    assert_int_equal(s_cntr_set_enable_calls, 0);

    s_cntr_set_enable_calls = 0;
    s_nr_of_expected_set_enable_calls = 1;
    s_expected_set_enable_calls[0].path = "XPON.ONU.1";
    s_expected_set_enable_calls[0].enable = false;

    enable_ONU_instance(1, false);
    assert_int_equal(s_cntr_set_enable_calls, 1);

    s_cntr_set_enable_calls = 0;

    int i;
    for(i = 0; i < 6; ++i) {
        read_sig_alarm();
    }
    assert_int_equal(s_cntr_set_enable_calls, 0);
}

/**
 * Test persistence of XPON.ONU.{i}.Enable.
 *
 * - Create 3 ONUs: XPON.ONU.1, XPON.ONU.2 and XPON.ONU.3. Because there are no
 *   persistent files, all ONUs have false as value for Enable.
 * - Enable XPON.ONU.1 and XPON.ONU.3.
 * - Call read_sig_alarm() 6 times to trigger tr181-xpon to apply the Enable
 *   values towards the VM (see test_onu_enable() on why read_sig_alarm() must
 *   be called 6 times).
 * - Check that tr181-xpon did 2 set_enable() calls in the "pon_ctrl" namespace
 *   of the VM.
 * - Call teardown_common() to simulate tr181-xpon stops.
 * - Call setup_common() to simulate tr181-xpon starts again.
 * - Create the 3 ONUs again: XPON.ONU.1, XPON.ONU.2 and XPON.ONU.3. Check that
 *   tr181-xpon has set XPON.ONU.1.Enable and XPON.ONU.3.Enable to true, and
 *   that XPON.ONU.2.Enable is false.
 * - Again call read_sig_alarm() a few times, and check that tr181-xpon did 2
 *   set_enable() calls as expected.
 */
void test_onu_enable_persistence(UNUSED void** state) {
    int rc;
    uint32_t index;
    SAH_TRACEZ_INFO(ME, "** test_onu_enable_persistence() **");
    for(index = 1; index < 4; ++index) {
        add_ONU_instance(index, false);
    }
    enable_ONU_instance(1, true);
    enable_ONU_instance(3, true);

    s_cntr_set_enable_calls = 0;
    s_nr_of_expected_set_enable_calls = 2;
    s_expected_set_enable_calls[0].path = "XPON.ONU.1";
    s_expected_set_enable_calls[0].enable = true;
    s_expected_set_enable_calls[1].path = "XPON.ONU.3";
    s_expected_set_enable_calls[1].enable = true;

    int i;
    for(i = 0; i < 6; ++i) {
        read_sig_alarm();
    }

    check_onu_enabled_file_exists(1, true);
    check_onu_enabled_file_exists(2, false);
    check_onu_enabled_file_exists(3, true);

    /* Check that tr181-xpon did 2 set_enable() calls */
    assert_int_equal(s_cntr_set_enable_calls, 2);

    rc = teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
    assert_int_equal(rc, 0);
    rc = setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
    assert_int_equal(rc, 0);

    /*
     * teardown_common() caused the unloading of the dummy VM, and hence the
     * "pon_ctrl" namespace was unregistered. setup_common() loaded the dummy VM
     * and registered the "pon_ctrl" namespace again. Call next function to
     * again register test_set_enable() as callback function for the function
     * set_enable() in the "pon_ctrl" namespace.
     */
    add_set_enable_to_pon_ctrl_namespace();

    add_ONU_instance(1, true);
    add_ONU_instance(2, false);
    add_ONU_instance(3, true);

    /**
     * Again call read_sig_alarm() a few times to trigger tr181-xpon do the
     * set_enable() calls in the "pon_ctrl" namespace. Check those calls. Reset
     * s_cntr_set_enable_calls. The value of s_nr_of_expected_set_enable_calls
     * and the contents of s_expected_set_enable_calls are still ok.
     */
    s_cntr_set_enable_calls = 0;

    for(i = 0; i < 8; ++i) {
        read_sig_alarm();
    }
    /* Check that tr181-xpon did 2 set_enable() calls */
    assert_int_equal(s_cntr_set_enable_calls, 2);
}

static void update_onu_one(void) {
    int rc;
    amxc_var_t* v;
    amxc_var_t value;
    amxc_var_t args;
    amxc_var_init(&value);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    const char* const path = "XPON.ONU.1";
    v = amxc_var_add_key(cstring_t, &args, "path", path);
    assert_non_null(v);

    amxc_var_t* const parameters = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    assert_non_null(parameters);
    v = amxc_var_add_key(cstring_t, parameters, "Version", "v4.5.6");
    assert_non_null(v);

    rc = call_xpon_mngr_pon_stat_function("dm_object_changed", &args);
    assert_int_equal(rc, 0);

    amxd_object_t* const obj = amxd_dm_findf(&dm, path);
    assert_non_null(obj);

    assert_int_equal(amxd_object_get_param(obj, "Version", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), "v4.5.6");

    amxc_var_clean(&args);
    amxc_var_clean(&value);
}

/**
 * Test use case where tr181-xpon loads 00_tr181-xpon_defaults.odl with ONU
 * instance which is enabled according to the persistence data.
 *
 * The most important steps are:
 * - When loading the odl files, also load "00_tr181-xpon_defaults.odl". It
 *   creates XPON.ONU.1.
 * - Call the main entry point.
 * - Instead of enabling the ONU and then simulating tr181-xpon restarts (by
 *   calling the main entry point twice with AMXO_STOP and AMXO_START), create
 *   the file /tmp/tr181-xpon/XPON.ONU.1_enabled.txt to simulate that the ONU
 *   was already enabled.
 * - Call dm_object_changed() to update XPON.ONU.1. Then tr181-xpon should check
 *   whether the ONU is enabled according to persistence. If the ONU is enabled,
 *   it must apply the Enable=true towards the VM. Because the test created
 *   /tmp/tr181-xpon/XPON.ONU.1_enabled.txt earlier, tr181-xpon should see the
 *   ONU is enabled, and call set_enable() once towards the VM to enable the
 *   ONU. Check that tr181-xpon does that.
 */
void test_onu_enable_persistence_when_onu_created_on_loading_odls(UNUSED void** state) {
    SAH_TRACEZ_INFO(ME, "** test_onu_enable_persistence_when_onu_created_on_loading_odls() **");

    remove_persistent_files();
    setup_common_with_extra_odl(&dm, &parser, /*invoke_main_entry_point=*/ true,
                                "00_tr181-xpon_defaults.odl");

    /**
     * Call read_sig_alarm() once to trigger timer to populate the XPON DM at
     * startup. See test_onu_enable_setup() for more info.
     */
    read_sig_alarm();

    add_set_enable_to_pon_ctrl_namespace();

    create_onu_enabled_file(/*index=*/ 1);

    /**
     * Check that tr181-xpon calls set_enable() once with path = "XPON.ONU.1"
     * and enable = true.
     */
    s_cntr_set_enable_calls = 0;
    s_nr_of_expected_set_enable_calls = 1;
    s_expected_set_enable_calls[0].path = "XPON.ONU.1";
    s_expected_set_enable_calls[0].enable = true;

    /**
     * Update XPON.ONU.1. This should cause tr181-xpon to check whether
     * XPON.ONU.1 is enabled according to the persistence data.
     */
    update_onu_one();

    /* Trigger tr181-xpon to apply the Enable value towards the VM */
    int i;
    for(i = 0; i < 6; ++i) {
        read_sig_alarm();
    }

    assert_int_equal(s_cntr_set_enable_calls, 1);
}

