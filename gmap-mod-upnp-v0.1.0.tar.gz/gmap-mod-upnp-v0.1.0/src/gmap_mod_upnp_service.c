/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>

#include <gmap/gmap.h>
#include <gmap/gmap_devices.h>
#include <gmap/gmap_device.h>

#include "gmap/extensions/ip/gmap_ext_ipaddress.h"
#include "gmap/extensions/ip/gmap_ext_ip_devices.h"

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "gmap-mod-upnp.h"

#include "../test/common/dummy.h"
#include <amxo/amxo_mibs.h>

#define UPNP_DEVICE_PATH "UPnPDescription.DeviceInstance."
#define UPNP_SERVICE_PATH "UPnPDescription.ServiceInstance."
#define UPNP_DISCOVERY_DEVICE "Device.UPnP.Discovery."
#define UPNP_DISCOVERY "UPnPDiscovery."
#define UPNP_PREFIX "UPnP-"
#define LINK_ZONE "gmap_upnp_service"
#define AMXB_DESCRIBE_TIMEOUT_SEC 5

static amxd_status_t mod_upnp_link_devices(const amxc_var_t* const data, uint32_t indx);


/**
   @ingroup gmap_upnp_service
   @brief Generates a GMAP key from a UPnP device path.

   This function fetches the UPnP device context, describes the device at the
   given path to retrieve its instance index, and constructs a GMAP key using
   the UPNP_PREFIX and the instance index.

   @param[in] upnp_path The full UPnP path of the device (e.g., "Devices.Device.1").

   @return char* A dynamically allocated string containing the GMAP key.
                The caller is responsible for freeing this buffer.
                Returns NULL on failure.

   @note The function uses `amxb_describe()` to get the instance index of the device.
   @warning Ensure the returned string is freed to avoid memory leaks.
 */
static char* get_gmap_key_from_upnp_path(const char* upnp_path) {
    amxb_bus_ctx_t* upnp_ctx = amxb_be_who_has(UPNP_DEVICE_PATH);
    amxc_var_t ret;
    amxc_string_t alias;
    char* gmap_key = NULL;
    int32_t index = 0;
    int32_t status = 0;

    amxc_string_init(&alias, 0);
    amxc_var_init(&ret);

    when_null_trace(upnp_ctx, exit, ERROR, "Could not fetch bus context for %s", UPNP_DEVICE_PATH);
    when_str_empty(upnp_path, exit);

    status = amxb_describe(upnp_ctx, upnp_path, AMXB_FLAG_INSTANCES, &ret, AMXB_DESCRIBE_TIMEOUT_SEC);
    when_failed_trace(status, exit, ERROR, "Could not describe %s", upnp_path);

    index = GET_INT32(amxc_var_get_first(&ret), "index");
    amxc_string_setf(&alias, "%s%d", UPNP_PREFIX, index);
    gmap_key = amxc_string_take_buffer(&alias);

exit:
    amxc_string_clean(&alias);
    amxc_var_clean(&ret);

    return gmap_key;
}

/**
   @ingroup gmap_upnp_service
   @brief Callback for handling the "Server" value update in a UPnP device.

   This function is invoked when the "Server" value of a UPnP device changes.
   It performs the following steps:
   - Validates the provided device entry (`priv`).
   - Deletes the discovery subscription for the device.
   - Converts the discovery device path from UPnP format to internal format.
   - Creates a new synchronization context between the UPnP discovery path and the
    GMAP device path.
   - Adds the "Server" parameter to the sync context and starts the synchronization.

   @param[in] sig_name Name of the signal triggering the callback (unused).
   @param[in] data     Pointer to the event data structure containing parameters.
   @param[in] priv     Pointer to the device entry context (`ctx_htable_device_entry_t`).

   @note This function uses `amxs_sync_ctx_new()` and related functions to synchronize
        the "Server" value from the UPnP device to the GMAP device representation.
   @warning Ensure that `priv` is valid; otherwise, the function will exit early.
 */
static void server_value_cb(UNUSED const char* const sig_name,
                            const amxc_var_t* const data,
                            void* const priv) {
    amxs_status_t ret = amxs_status_ok;
    amxc_string_t upnp_discovery_path;
    amxc_string_t gmap_device_path;
    amxc_var_t result;
    amxc_var_t res;
    amxc_string_t expr_path;
    amxs_status_t amx_ret = amxs_status_ok;
    int32_t status = 0;
    amxb_bus_ctx_t* upnp_ctx = amxb_be_who_has(UPNP_DEVICE_PATH);
    ctx_htable_device_entry_t* entry = (ctx_htable_device_entry_t*) priv;
    const char* discovery_device = GETP_CHAR(data, "parameters.DiscoveryDevice.to.");

    amxc_string_init(&upnp_discovery_path, 0);
    amxc_string_init(&gmap_device_path, 0);

    when_null_trace(entry, exit, ERROR, "cb to %s.DiscoveryDevice contains no entry htable", GET_CHAR(data, "path"));
    amxb_subscription_delete(&entry->discover_device_subscription);

    when_str_empty_trace(discovery_device, exit, ERROR, "DiscoveryDevice not filled in at event for %s", GET_CHAR(data, "path"));

    amxc_string_appendf(&upnp_discovery_path, "%s.", discovery_device);
    amxc_string_replace(&upnp_discovery_path, UPNP_DISCOVERY_DEVICE, UPNP_DISCOVERY, 1);

    amxc_string_setf(&gmap_device_path, "Devices.Device.%s.", entry->device_name);

    ret |= amxs_sync_ctx_new(&entry->ctx_discovery, amxc_string_get(&upnp_discovery_path, 0), amxc_string_get(&gmap_device_path, 0), AMXS_SYNC_ONLY_A_TO_B);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_discovery,
                                            "Server",
                                            "Server",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_start_sync(entry->ctx_discovery);

    when_failed_trace(ret, exit, ERROR, "Could not sync to the %s 'Server' value", amxc_string_get(&upnp_discovery_path, 0));

    amxc_var_init(&result);
    amxc_var_init(&res);
    amxc_string_init(&expr_path, 0);
    amxc_string_setf(&expr_path, "%s[ DiscoveryDevice == '%s']", UPNP_DEVICE_PATH, discovery_device);
    amxb_set_access(upnp_ctx, AMXB_PROTECTED);
    amx_ret = amxb_get(upnp_ctx, amxc_string_get(&expr_path, 0), 0, &result, gmap_get_timeout());
    when_failed_trace(amx_ret, exit, ERROR, "Could not get device instance %s with discovery %s", UPNP_DEVICE_PATH, discovery_device);
    amxc_var_for_each(var, amxc_var_get_first(&result)) {
        status = amxb_describe(upnp_ctx, amxc_var_key(var), AMXB_FLAG_INSTANCES, &res, AMXB_DESCRIBE_TIMEOUT_SEC);
        when_failed_trace(status, exit, ERROR, "Could not describe %s", amxc_var_key(var));
        int32_t index = GET_INT32(amxc_var_get_first(&res), "index");
        mod_upnp_link_devices(var, index);
    }

exit:
    amxc_string_clean(&upnp_discovery_path);
    amxc_string_clean(&gmap_device_path);
    amxc_string_clean(&expr_path);
    amxc_var_clean(&res);
    amxc_var_clean(&result);

    return;
}

/**
   @ingroup gmap_upnp_service
   @brief Checks and subscribes to the "DiscoveryDevice" value of a UPnP device.

   This function performs the following actions:
   - Retrieves the UPnP bus context.
   - Subscribes to `dm:object-changed` notifications for the specified device path,
    specifically when the `parameters.DiscoveryDevice.to` value changes.
   - Fetches the current device data using `amxb_get()`.
   - Extracts the `DiscoveryDevice` value from the device data and stores it in
    the provided `upnp_discovery_path`.

   @param[in,out] entry               Pointer to the device entry context (`ctx_htable_device_entry_t`).
   @param[in]     upnp_device_path    The UPnP device path to check and subscribe to.
   @param[out]    upnp_discovery_path Pointer to a string where the discovery device path will be stored.

   @note The subscription triggers `server_value_cb()` when the `DiscoveryDevice` value changes.
   @warning Ensure that `entry` and `upnp_discovery_path` are valid. The function cleans
           allocated variables before returning.
 */
static void check_disco_device_value(ctx_htable_device_entry_t* entry,
                                     const char* upnp_device_path,
                                     amxc_string_t* upnp_discovery_path) {
    amxs_status_t ret = amxs_status_ok;
    amxb_bus_ctx_t* upnp_ctx = amxb_be_who_has(UPNP_DEVICE_PATH);
    amxc_var_t upnp_device;
    amxc_string_t expr;
    const char* disco = NULL;

    amxc_var_init(&upnp_device);
    amxc_string_init(&expr, 0);

    amxc_string_setf(&expr, "notification == 'dm:object-changed' && contains('parameters.DiscoveryDevice.to')");
    ret = amxb_subscription_new(&entry->discover_device_subscription,
                                upnp_ctx,
                                upnp_device_path,
                                amxc_string_get(&expr, 0),
                                server_value_cb,
                                entry);
    when_failed_trace(ret, exit, ERROR, "Could not subscribe to the %s instance", upnp_device_path);

    ret = amxb_get(upnp_ctx, upnp_device_path, 0, &upnp_device, gmap_get_timeout());
    when_failed_trace(ret, exit, ERROR, "Could not perform get: %s", upnp_device_path);

    disco = GET_CHAR(GETI_ARG(GETI_ARG(&upnp_device, 0), 0), "DiscoveryDevice");
    amxc_string_set(upnp_discovery_path, disco);

exit:
    amxc_var_clean(&upnp_device);
    amxc_string_clean(&expr);
}

/**
   @ingroup gmap_upnp_service
   @brief Initializes the "Server" value synchronization for a UPnP device.

   This function ensures that the "Server" value of a UPnP device is properly
   synchronized to the GMAP representation. It performs the following steps:
   - If `discovery_device` is NULL or empty, calls `check_disco_device_value()` to
    fetch the discovery device path.
   - Converts the discovery device path to internal format.
   - Creates a new synchronization context for the "Server" parameter.
   - Adds the "Server" parameter to the sync context and starts synchronization.

   @param[in,out] entry             Pointer to the device entry context (`ctx_htable_device_entry_t`).
   @param[in]     discovery_device  The current discovery device path, or NULL/empty to fetch it dynamically.
   @param[in]     upnp_device_path  The UPnP device path corresponding to the device.
   @param[in]     gmap_device_path  Pointer to the GMAP device path string.

   @return amxs_status_t Returns AMXS status code indicating success or failure.

   @note The function uses `amxs_sync_ctx_new()`, `amxs_sync_ctx_add_new_copy_param()`,
        and `amxs_sync_ctx_start_sync()` to synchronize the "Server" value.
   @warning Ensure that `entry` and `gmap_device_path` are valid. The allocated
           `upnp_discovery_path` string is cleaned before returning.
 */
static amxs_status_t init_server_value(ctx_htable_device_entry_t* entry,
                                       const char* discovery_device,
                                       const char* upnp_device_path,
                                       amxc_string_t* gmap_device_path) {
    amxs_status_t ret = amxs_status_ok;
    amxc_string_t upnp_discovery_path;

    amxc_string_init(&upnp_discovery_path, 0);

    if((discovery_device == NULL) || (discovery_device[0] == '\0')) {
        check_disco_device_value(entry, upnp_device_path, &upnp_discovery_path);
        when_true(amxc_string_is_empty(&upnp_discovery_path), exit);
        amxc_string_appendf(&upnp_discovery_path, ".");
    } else {
        amxc_string_appendf(&upnp_discovery_path, "%s.", discovery_device);
    }

    amxc_string_replace(&upnp_discovery_path, UPNP_DISCOVERY_DEVICE, UPNP_DISCOVERY, 1);

    ret |= amxs_sync_ctx_new(&entry->ctx_discovery, amxc_string_get(&upnp_discovery_path, 0), amxc_string_get(gmap_device_path, 0), AMXS_SYNC_ONLY_A_TO_B);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_discovery,
                                            "Server",
                                            "Server",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_start_sync(entry->ctx_discovery);

    when_failed_trace(ret, exit, ERROR, "Could not sync to the %s 'Server' value", amxc_string_get(&upnp_discovery_path, 0));

exit:
    amxc_string_clean(&upnp_discovery_path);
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Synchronizes the parameters of a UPnP device to GMAP.

   This function performs the following steps for the given device entry:
   - Constructs the UPnP device path and corresponding GMAP device path.
   - Creates a new synchronization context for the device.
   - Adds standard UPnP device parameters (DeviceType, Manufacturer, ModelName, etc.)
    to the sync context to copy them to the GMAP representation.
   - Starts the device synchronization.
   - Initializes the "Server" value synchronization using `init_server_value()`.

   @param[in,out] entry            Pointer to the device entry context (`ctx_htable_device_entry_t`).
   @param[in]     discovery_device The discovery device path, or NULL/empty to fetch dynamically.

   @return amxs_status_t Returns AMXS status code indicating success or failure.

   @note This function relies on `amxs_sync_ctx_new()`, `amxs_sync_ctx_add_new_copy_param()`,
        and `amxs_sync_ctx_start_sync()` for the synchronization process.
   @warning Ensure that `entry` is valid. All allocated strings are cleaned before
           the function returns.
 */
static amxs_status_t mod_upnp_sync_device_params(ctx_htable_device_entry_t* entry, const char* discovery_device) {
    amxs_status_t ret = amxs_status_ok;
    amxc_string_t upnp_device_path;
    amxc_string_t gmap_device_path;

    amxc_string_init(&upnp_device_path, 0);
    amxc_string_init(&gmap_device_path, 0);

    amxc_string_setf(&upnp_device_path, "%s%d.", UPNP_DEVICE_PATH, entry->index);
    amxc_string_setf(&gmap_device_path, "Devices.Device.%s.", entry->device_name);

    ret = amxs_sync_ctx_new(&entry->ctx_device, amxc_string_get(&upnp_device_path, 0), amxc_string_get(&gmap_device_path, 0), AMXS_SYNC_ONLY_A_TO_B);

    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "DeviceType",
                                            "Type",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "Manufacturer",
                                            "Manufacturer",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "ManufacturerURL",
                                            "ManufacturerURL",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "ModelName",
                                            "ModelName",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "ModelDescription",
                                            "ModelDescription",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "ModelNumber",
                                            "ModelNumber",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "ModelURL",
                                            "ModelURL",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "FriendlyName",
                                            "FriendlyName",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "SerialNumber",
                                            "SerialNumber",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "UDN",
                                            "UDN",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "UPC",
                                            "UPC",
                                            AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(entry->ctx_device,
                                            "PresentationURL",
                                            "PresentationURL",
                                            AMXS_SYNC_DEFAULT);

    ret |= amxs_sync_ctx_start_sync(entry->ctx_device);

    ret |= init_server_value(entry, discovery_device, amxc_string_get(&upnp_device_path, 0), &gmap_device_path);

    amxc_string_clean(&gmap_device_path);
    amxc_string_clean(&upnp_device_path);

    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Synchronizes a single UPnP device service to the GMAP data model.

   This function performs the following steps:
   - Retrieves the device entry from the global UPnP entry table using the device name.
   - Constructs the UPnP service path and the corresponding GMAP service path.
   - Creates a new synchronization context for the service.
   - Adds standard service parameters to the sync context:
    ServiceId, ServiceType, SCPDURL, ControlURL, EventSubURL.
   - Starts the service synchronization.
   - Appends the service context to the device's list of synchronized services.

   @param[in,out] sync_entry Pointer to the service synchronization entry (`sync_ctx_service_llist_entry_t`).

   @return amxs_status_t Returns AMXS status code indicating success or failure.

   @note The function uses `amxs_sync_ctx_new()`, `amxs_sync_ctx_add_new_copy_param()`,
        and `amxs_sync_ctx_start_sync()` for the synchronization.
   @warning Ensure that `sync_entry` is valid. If the corresponding device entry
           cannot be found, the function exits early with an error status.
           All allocated strings are cleaned before returning.
 */
static amxs_status_t mod_upnp_sync_device_service(sync_ctx_service_llist_entry_t* sync_entry) {
    amxs_status_t ret = amxs_status_unknown_error;
    amxc_string_t gmap_service_path;
    amxc_string_t upnp_service_path;
    amxc_htable_t* entry_table = mod_upnp_get_entry_table();
    amxc_htable_it_t* it = amxc_htable_get(entry_table, sync_entry->device_name);
    ctx_htable_device_entry_t* entry = amxc_htable_it_get_data(it, ctx_htable_device_entry_t, it);

    when_null(entry, exit);

    amxc_string_init(&gmap_service_path, 0);
    amxc_string_init(&upnp_service_path, 0);

    amxc_string_appendf(&gmap_service_path, "Devices.Device.%s.Service.%d.", sync_entry->device_name, sync_entry->gmap_index);
    amxc_string_appendf(&upnp_service_path, "%s%d.", UPNP_SERVICE_PATH, sync_entry->upnp_index);

    ret = amxs_sync_ctx_new(&sync_entry->ctx_service, amxc_string_get(&upnp_service_path, 0), amxc_string_get(&gmap_service_path, 0), AMXS_SYNC_ONLY_A_TO_B);
    ret |= amxs_sync_ctx_add_new_copy_param(sync_entry->ctx_service, "ServiceId", "ServiceId", AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(sync_entry->ctx_service, "ServiceType", "ServiceType", AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(sync_entry->ctx_service, "SCPDURL", "SCPDURL", AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(sync_entry->ctx_service, "ControlURL", "ControlURL", AMXS_SYNC_DEFAULT);
    ret |= amxs_sync_ctx_add_new_copy_param(sync_entry->ctx_service, "EventSubURL", "EventSubURL", AMXS_SYNC_DEFAULT);

    ret |= amxs_sync_ctx_start_sync(sync_entry->ctx_service);

    amxc_llist_append(&entry->ctx_services_llist, &sync_entry->it);

    amxc_string_clean(&gmap_service_path);
    amxc_string_clean(&upnp_service_path);

exit:
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Fetches all UPnP devices from the UPnP bus context.

   This function retrieves all instances of UPnP devices from the bus context
   and populates the provided `devices` variable with the results.

   @param[out] devices Pointer to an `amxc_var_t` variable that will be filled
                      with the list of UPnP devices.

   @return amxd_status_t Returns 0 on success, or a negative error code on failure.

   @note The function uses `amxb_be_who_has()` to get the UPnP bus context and
        `amxb_get()` to fetch all devices. The timeout for fetching is obtained
        from `gmap_get_timeout()`.
   @warning Ensure that `devices` is a valid, initialized `amxc_var_t`. The
           function cleans up internal temporary strings before returning.
 */
static amxd_status_t get_all_upnp_devices(amxc_var_t* devices) {
    int ret = 0;
    amxb_bus_ctx_t* upnp_ctx = amxb_be_who_has(UPNP_DEVICE_PATH);
    amxc_string_t expr;

    amxc_string_init(&expr, 0);
    when_null_trace(upnp_ctx, exit, ERROR, "Could not fetch bus context for %s", UPNP_DEVICE_PATH);

    amxc_string_appendf(&expr, "%s*.", UPNP_DEVICE_PATH);
    ret = amxb_get(upnp_ctx, amxc_string_get(&expr, 0), 0, devices, gmap_get_timeout());
    when_failed_trace(ret, exit, ERROR, "Could not fetch %s*.", amxc_string_get(&expr, 0));

exit:
    amxc_string_clean(&expr);
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Links all lower (child) UPnP devices to a given GMAP device key.

   This function iterates over all UPnP devices, determines their parent-child
   relationships, and links the child devices to the specified GMAP device key
   using the "upnp" link type.

   @param[in] gmap_key The GMAP key of the parent device to which lower devices should be linked.

   @return amxd_status_t Returns AMXD status code indicating success or failure.

   @note Uses `get_all_upnp_devices()` to retrieve UPnP devices, `get_gmap_key_from_upnp_path()`
        to obtain GMAP keys, and `gmap_devices_linkAdd()` to create the links.
   @warning Ensure `gmap_key` is valid. Memory allocated for keys is freed within the function.
           Any failure during linking will exit the loop and return an error code.
 */
static amxd_status_t link_all_lower_devices(const char* gmap_key) {
    int ret = 0;
    amxc_var_t devices;

    amxc_var_init(&devices);

    // loop over existing devices to check if there are lower ones
    ret = get_all_upnp_devices(&devices);
    when_failed_trace(ret, exit, ERROR, "Could not fetch %s*.", UPNP_DEVICE_PATH);

    amxc_var_for_each(var, amxc_var_get_first(&devices)) {
        amxc_var_t* gmap_parent = NULL;
        amxc_var_t* gmap_child = NULL;
        char* child_key = get_gmap_key_from_upnp_path(amxc_var_key(var));
        char* child_parent = get_gmap_key_from_upnp_path(GET_CHAR(var, "ParentDevice"));

        if((child_parent == NULL) || (child_parent[0] == '\0')) {
            free(child_key);
            free(child_parent);
            continue;
        }

        gmap_parent = gmap_device_get(child_parent, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
        gmap_child = gmap_device_get(child_key, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);

        if((strcmp(gmap_key, child_parent) == 0) && gmap_parent && gmap_child) {
            ret = gmap_devices_linkAdd(gmap_key, child_key, "upnp", LINK_ZONE, PRIO) == 1 ? amxd_status_ok : amxd_status_unknown_error;
        }

        free(child_parent);
        free(child_key);
        amxc_var_delete(&gmap_parent);
        amxc_var_delete(&gmap_child);
        when_failed(ret, exit);
    }

exit:
    amxc_var_clean(&devices);
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Callback function invoked for GMAP UPnP queries.

   This function implements the `gmap_query_cb_t` interface. When a GMAP query
   completes, this callback is called to:
   - Link UPnP devices using the query data.
   - Clean up the query entry from the internal query list if it exists.
   - Free the query data and close the query if it was called directly and
    not yet stored in the query list.

   @param[in] query Pointer to the GMAP query (`gmap_query_t`) that triggered the callback.
   @param[in] dev_key Unused parameter.
   @param[in] dev_fields Unused parameter.
   @param[in] action Unused parameter.

   @note This function ensures proper cleanup depending on whether the query
        was already stored in the internal list or invoked directly.
   @implements gmap_query_cb_t
 */
static void upnp_cb(gmap_query_t* query, UNUSED const char* dev_key, UNUSED amxc_var_t* dev_fields, UNUSED gmap_query_action_t action) {
    amxc_var_t* data = NULL;
    query_llist_entry_t* entry = NULL;

    when_null_trace(query, exit, ERROR, "No query found");

    data = (amxc_var_t*) query->data;
    mod_upnp_link_devices(data, 0);

    amxc_llist_for_each(it, mod_upnp_get_query_list()) {
        query_llist_entry_t* it_entry = amxc_llist_it_get_data(it, query_llist_entry_t, it);
        if(it_entry->query == query) {
            entry = it_entry;
            break;
        }
    }

    if(entry == NULL) {
        /* The query was not yet stored in the entry list. This callback is therefore
         * called directly from gmap_query_open_ext_2 and needs to clean up itself directly. */
        amxc_var_delete(&data);
        gmap_query_close(query);
    } else {
        /* The callback is executed at a later time. Cleaning up its entry from
         * the query list suffices */
        amxc_llist_it_clean(&(entry->it), mod_upnp_clean_query_entry);
    }

exit:
    return;
}

static const char* get_param_fallback(const amxc_var_t* data,
                                      const char* p1,
                                      const char* p2) {
    const char* param = GETP_CHAR(data, p1);
    return (param && *param) ? param : GETP_CHAR(data, p2);
}

/**
   @ingroup gmap_upnp_service
   @brief Links a UPnP device to its parent in the GMAP data model.

   This function determines the parent-child relationship of a UPnP device
   and creates a link in the GMAP data model:
   - If the `ParentDevice` parameter is empty, it treats the device as a root device
    and attempts to find a GMAP device with the same IP address.
   - If the parent device exists, it links the child device under the parent using
    the "upnp" link type.
   - If the device has lower (child) devices, they are linked recursively.
   - Uses `gmap_query_open_ext_2` with `upnp_cb` to asynchronously query missing
    parent devices by IP.

   @param[in] data Pointer to an `amxc_var_t` representing the UPnP device data.

   @return amxd_status_t Returns status code indicating success or failure.

   @note The function uses `get_gmap_key_from_upnp_path()` to translate UPnP paths
        to GMAP keys and `link_all_lower_devices()` to handle child devices.
   @warning Ensure `data` contains valid `index`, `IPAddress`, and optional `ParentDevice`.
           Memory allocated internally (strings, query entries) is cleaned properly.
 */
static amxd_status_t mod_upnp_link_devices(const amxc_var_t* const data, uint32_t indx) {
    int ret = 0;
    const char* parent_path = get_param_fallback(data, "parameters.ParentDevice", "ParentDevice");
    const char* dev = NULL;
    amxc_string_t dev_key;
    int32_t index;
    int ret_name = 0;

    const char* nameUpnp = get_param_fallback(data, "parameters.ModelName", "ModelName");
    if(!nameUpnp || !(*nameUpnp)) {
        nameUpnp = get_param_fallback(data, "parameters.FriendlyName", "FriendlyName");
    }

    if(indx == 0) {
        index = GET_INT32(data, "index");
    } else {
        index = indx;
    }
    amxc_string_init(&dev_key, 0);
    amxc_string_setf(&dev_key, "%s%d", UPNP_PREFIX, index);
    dev = amxc_string_get(&dev_key, 0);

    // Check if the ParentDevice param is filled in. If not the device is a root device.
    // In that case the UDevice will be the gmap device that contains the same IP address.
    if((parent_path == NULL) || (parent_path[0] == '\0')) {
        const char* ip = get_param_fallback(data, "parameters.IPAddress", "IPAddress");
        when_str_empty(ip, exit);
        char* ip_dev = gmap_devices_findByIp(ip);

        if(((ip_dev == NULL) || (ip_dev[0] == '\0')) &&
           ((ip != NULL) || (ip[0] != '\0'))) {
            const char* ip_family = gmap_ip_family_id2string(gmap_ip_family(ip));
            const char* ip_object = gmap_ip_family_id_to_objname(gmap_ip_family(ip));
            bool success;
            gmap_query_t* query = NULL;
            amxc_var_t* data_copy = NULL;
            amxc_string_t name;
            amxc_string_t expr;

            amxc_var_new(&data_copy);
            amxc_var_copy(data_copy, data);

            amxc_string_init(&name, 0);
            amxc_string_setf(&name, "parent_%s", dev);

            amxc_string_init(&expr, 0);
            amxc_string_setf(&expr, "%s && has_instance(\"%s\", \".Address == '%s' && .Status == 'reachable'\")", ip_family, ip_object, ip);

            success = gmap_query_open_ext_2(&query, amxc_string_get(&expr, 0), amxc_string_get(&name, 0), 0, upnp_cb, data_copy);
            if(success == false) {
                /* No query object was created. The callback was not run. */
                amxc_var_delete(&data_copy);
            } else if(query) {
                /* A query object was created. The callback was not run. */
                query_llist_entry_t* entry = calloc(1, sizeof(query_llist_entry_t));
                amxc_llist_it_init(&entry->it);
                entry->query = query;
                amxc_llist_append(mod_upnp_get_query_list(), &entry->it);
            } else {
                /* A query object was created. The callback was executed and it cleaned up everything. */
                data_copy = NULL;
            }

            amxc_string_clean(&name);
            amxc_string_clean(&expr);
        } else {
            ret = gmap_devices_linkAdd(ip_dev, dev, "upnp", LINK_ZONE, PRIO) == 1 ? amxd_status_ok : amxd_status_unknown_error;
            ret_name = gmap_device_setName(ip_dev, nameUpnp, "upnp");
            SAH_TRACEZ_ERROR("gmap_upnp", "upnp, ret_name=%d", ret_name);
            if(!ret_name) {
                SAH_TRACEZ_ERROR(ME, "Error setting name %s %s with source upnp", ip_dev, nameUpnp);
            }
        }

        free(ip_dev);
        when_failed(ret, exit);

    } else {
        char* parent = get_gmap_key_from_upnp_path(parent_path);
        amxc_var_t* gmap_parent = gmap_device_get(parent, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);

        if(gmap_parent) {
            ret = gmap_devices_linkAdd(parent, dev, "upnp", LINK_ZONE, PRIO) == 1 ? amxd_status_ok : amxd_status_unknown_error;
            ret_name = gmap_device_setName(parent, nameUpnp, "upnp");
            if(!ret_name) {
                SAH_TRACEZ_ERROR(ME, "Error setting name %s %s with source upnp", parent, nameUpnp);
            }
        }

        free(parent);
        amxc_var_delete(&gmap_parent);
        when_failed(ret, exit);
    }

exit:
    ret = link_all_lower_devices(dev);
    amxc_string_clean(&dev_key);
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Checks whether a UPnP service is already present under a given device.

   This function queries the GMAP data model to determine if a service with the
   specified `service_id` already exists for the given `device_name`. It constructs
   a query path and uses `gmap_devices_find` to retrieve any matching service instances.

   @param[in] device_name Name of the device to check.
   @param[in] service_id The service identifier to look for.

   @return true if the service already exists under the device, false otherwise.

   @note This function only checks existence; it does not modify the GMAP model.
   @warning Both `device_name` and `service_id` must be valid, non-NULL strings.
 */
static bool service_already_present(UNUSED const char* device_name, const char* service_id) {
    bool ret = false;
    amxc_string_t path;
    amxc_var_t list;

    amxc_string_init(&path, 0);
    amxc_var_init(&list);

    amxc_var_set_type(&list, AMXC_VAR_ID_LIST);

    amxc_string_setf(&path, ".Key == \"%s\" and has_instance(\"Service\", \".ServiceId == '%s'\")", device_name, service_id);
    when_false(gmap_devices_find(amxc_string_get(&path, 0), GMAP_NO_DETAILS, &list), exit);

    if(amxc_llist_size(amxc_var_constcast(amxc_llist_t, GETI_ARG(&list, 0))) != 0) {
        ret = true;
    }

exit:
    amxc_string_clean(&path);
    amxc_var_clean(&list);
    return ret;
}

/**
   @ingroup gmap_upnp_service
   @brief Adds a UPnP service instance from a given variable retrieved via `amxb_get`.

   This function:
   - Describes the UPnP object represented by `var` to obtain its instance index.
   - Prepares an event parameter table with the service index and parameters.
   - Calls `upnp_add_service_instance` to register the service in the system.

   @param[in] var Pointer to an `amxc_var_t` representing the UPnP service object.
   @param[in] upnp_ctx Pointer to the UPnP bus context used to describe the service.

   @note Cleans up temporary variables `ret` and `event_params` before returning.
   @warning `var` and `upnp_ctx` must be valid pointers. The function may fail
           if `amxb_describe` does not succeed.
 */
static void add_service_from_get(amxc_var_t* var, amxb_bus_ctx_t* upnp_ctx) {
    amxc_var_t event_params;
    amxc_var_t ret;
    int32_t service_index = 0;
    int32_t status = 0;

    amxc_var_init(&ret);
    amxc_var_init(&event_params);
    amxc_var_set_type(&event_params, AMXC_VAR_ID_HTABLE);

    status = amxb_describe(upnp_ctx, amxc_var_key(var), AMXB_FLAG_INSTANCES, &ret, AMXB_DESCRIBE_TIMEOUT_SEC);
    when_failed_trace(status, exit, ERROR, "Could not describe %s", amxc_var_key(var));

    service_index = GET_INT32(amxc_var_get_first(&ret), "index");

    amxc_var_add_key(int32_t, &event_params, "index", service_index);
    amxc_var_add_key(amxc_htable_t, &event_params, "parameters", amxc_var_constcast(amxc_htable_t, var));

    upnp_add_service_instance(NULL, &event_params, NULL);

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&event_params);
    return;
}

/**
   @ingroup gmap_upnp_service
   @brief Adds all UPnP services that are already present for a given device index.

   This function:
   - Fetches the list of existing UPnP services whose parent device matches
    `UPNP_DEVICE_PATH` with the given `index`.
   - Iterates over the retrieved services and calls `add_service_from_get`
    to register each service in the system.

   @param[in] index The device index for which to add already present services.

   @return 1 on failure, 0 on success (matches `amxb_get` / internal logic conventions).

   @note Temporary variables `expr` and `services` are cleaned up before returning.
   @warning The function assumes `UPNP_SERVICE_PATH` and `UPNP_DEVICE_PATH` are valid
           and that the bus context exists.
 */
static int add_already_present_services(int32_t index) {
    int ret = 1;
    amxc_string_t expr;
    amxc_var_t services;
    amxb_bus_ctx_t* upnp_ctx = amxb_be_who_has(UPNP_SERVICE_PATH);

    amxc_var_init(&services);
    amxc_string_init(&expr, 0);

    when_null_trace(upnp_ctx, exit, ERROR, "Could not fetch bus context for %s", UPNP_DEVICE_PATH);

    amxc_string_appendf(&expr, "%s[ParentDevice == '%s%d.'].", UPNP_SERVICE_PATH, UPNP_DEVICE_PATH, index);
    ret = amxb_get(upnp_ctx, amxc_string_get(&expr, 0), 0, &services, gmap_get_timeout());
    when_failed_trace(ret, exit, ERROR, "Could not fetch %s*.", UPNP_SERVICE_PATH);

    amxc_var_for_each(var, amxc_var_get_first(&services)) {
        add_service_from_get(var, upnp_ctx);
    }

exit:
    amxc_string_clean(&expr);
    amxc_var_clean(&services);

    return ret;
}

void upnp_add_device_instance(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {

    ctx_htable_device_entry_t* entry = NULL;
    amxc_htable_t* entry_table = mod_upnp_get_entry_table();
    amxc_string_t gmap_key_string;
    amxc_var_t* gmap_dev = NULL;
    const char* gmap_key = NULL;

    amxc_string_init(&gmap_key_string, 0);
    amxc_string_setf(&gmap_key_string, "%s%d", UPNP_PREFIX, GET_INT32(data, "index"));

    gmap_key = amxc_string_get(&gmap_key_string, 0);
    when_str_empty(gmap_key, exit);

    entry = calloc(1, sizeof(ctx_htable_device_entry_t));
    amxc_htable_it_init(&entry->it);
    amxc_llist_init(&entry->ctx_services_llist);

    entry->device_name = strdup(gmap_key);
    entry->index = GET_INT32(data, "index");

    gmap_dev = gmap_device_get(gmap_key, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);

    if(!gmap_dev) {
        const char* upnp_name = GETP_CHAR(data, "parameters.ModelName");

        if(!upnp_name || !(*upnp_name)) {
            upnp_name = GETP_CHAR(data, "parameters.FriendlyName");
        }

        if(!gmap_devices_createDevice(gmap_key, ME, "upnp logical", false, upnp_name)) {
            amxc_htable_it_clean(&entry->it, mod_upnp_clean_device_entry);
            goto exit;
        }
    }

    amxc_htable_insert(entry_table, gmap_key, &entry->it);

    // Sync the gmap device with the parameters from the UPNP datamodel
    when_failed_trace(mod_upnp_sync_device_params(entry, GETP_CHAR(data, "parameters.DiscoveryDevice")), exit, ERROR, "Could not sync the %s device object", gmap_key);

    // link device with upper device
    mod_upnp_link_devices(data, 0);

    // add services that match with the device but already exist
    add_already_present_services(entry->index);

exit:
    amxc_string_clean(&gmap_key_string);
    amxc_var_delete(&gmap_dev);
    return;
}

void upnp_add_service_instance(UNUSED const char* const sig_name,
                               const amxc_var_t* const data,
                               UNUSED void* const priv) {
    char* dev = get_gmap_key_from_upnp_path(GETP_CHAR(data, "parameters.ParentDevice"));
    sync_ctx_service_llist_entry_t* sync_entry = NULL;
    amxc_htable_t* entry_table = mod_upnp_get_entry_table();

    if(service_already_present(dev, GETP_CHAR(data, "parameters.ServiceId")) ||
       (amxc_htable_get(entry_table, dev) == NULL)) {
        free(dev);
        goto exit;
    }

    sync_entry = calloc(1, sizeof(sync_ctx_service_llist_entry_t));
    amxc_llist_it_init(&sync_entry->it);

    sync_entry->device_name = dev;
    sync_entry->upnp_index = GET_INT32(data, "index");
    sync_entry->gmap_index = gmap_add_instance(sync_entry->device_name, "Service.", NULL);

    when_failed_trace(mod_upnp_sync_device_service(sync_entry), exit, ERROR,
                      "Could not sync the service object '%s' for the %s device", GETP_CHAR(data, "parameters.ServiceId"), sync_entry->device_name);

exit:
    return;
}

void upnp_remove_deviceinstance(UNUSED const char* const sig_name,
                                UNUSED const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxc_htable_t* entry_table = mod_upnp_get_entry_table();
    amxc_string_t name;
    amxc_string_init(&name, 0);
    amxc_string_setf(&name, "%s%d", UPNP_PREFIX, GET_INT32(data, "index"));

    amxc_htable_it_t* hit = amxc_htable_get(entry_table, amxc_string_get(&name, 0));
    ctx_htable_device_entry_t* entry = amxc_container_of(hit, ctx_htable_device_entry_t, it);
    amxc_var_t* topo = gmap_device_topology(amxc_string_get(&name, 0), "", 0, "");
    amxc_var_t* udevs = amxc_var_get_path(topo, "UDevice", AMXC_VAR_FLAG_DEFAULT);
    amxc_var_t* ldevs = amxc_var_get_path(topo, "LDevice", AMXC_VAR_FLAG_DEFAULT);

    // unlink the linked devices
    amxc_var_for_each(var, udevs) {
        gmap_devices_linkRemove(GET_CHAR(var, "Alias"), amxc_string_get(&name, 0), LINK_ZONE);
    }

    amxc_var_for_each(var, ldevs) {
        gmap_devices_linkRemove(amxc_string_get(&name, 0), GET_CHAR(var, "Alias"), LINK_ZONE);
    }

    // remove the device
    gmap_devices_destroyDevice(amxc_string_get(&name, 0));

    // clean op the amxs_sync_ctx_t params
    when_null(hit, exit);
    when_null(entry, exit);
    amxc_llist_clean(&entry->ctx_services_llist, mod_upnp_clean_sync_entry);
    amxc_htable_it_clean(hit, mod_upnp_clean_device_entry);

exit:
    amxc_string_clean(&name);
    amxc_var_clean(udevs);
    amxc_var_clean(ldevs);
    amxc_var_delete(&topo);
    return;
}

void upnp_remove_serviceinstance(UNUSED const char* const sig_name,
                                 UNUSED const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    int32_t upnp_index = GET_INT32(data, "index");
    int32_t gmap_index = 0;
    char* dev = get_gmap_key_from_upnp_path(GETP_CHAR(data, "parameters.ParentDevice"));
    amxc_htable_t* entry_table = mod_upnp_get_entry_table();
    amxc_htable_it_t* it = NULL;
    ctx_htable_device_entry_t* entry = NULL;
    amxc_var_t* gmap_dev = NULL;

    it = amxc_htable_get(entry_table, dev);

    if(it != NULL) {
        entry = amxc_htable_it_get_data(it, ctx_htable_device_entry_t, it);

        amxc_llist_for_each(lit, &entry->ctx_services_llist) {
            sync_ctx_service_llist_entry_t* sync_entry = amxc_llist_it_get_data(lit, sync_ctx_service_llist_entry_t, it);

            if(sync_entry->upnp_index == upnp_index) {
                gmap_index = sync_entry->gmap_index;
                amxc_llist_it_clean(lit, mod_upnp_clean_sync_entry);
                break;
            }
        }

        gmap_delete_instance(dev, "Service", gmap_index);
    }

    free(dev);
    amxc_var_delete(&gmap_dev);
}
