/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <math.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include <amxo/amxo.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"

#include "mock.h"
#include "test_common.h"
#include "test_interval_management.h"

static uint64_t get_timestamp_from_push_notif(void) {
    uint64_t timestamp = 0;
    amxc_var_t last_report;
    assert_int_equal(amxc_var_init(&last_report), 0);
    assert_int_equal(amxb_subscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", "notification in 'Push!'", push_event_handler, &last_report), 0);
    go_to_future_ms(15000);
    assert_int_equal(amxb_unsubscribe(test_get_bus_ctx(), "BulkData.Profile.simple_profile.", push_event_handler, &last_report), 0);
    /* Check report contains required parameters and check their values */
    timestamp = amxc_var_dyncast(uint64_t, GET_ARG(&last_report, "CollectionTime"));
    amxc_var_clean(&last_report);
    return timestamp;
}

void test_interval(UNUSED void** state) {
    set_bulkdata_reporting_interval("BulkData.Profile.simple_profile.", 15);
    uint64_t timestamp1 = get_timestamp_from_push_notif();
    uint64_t timestamp2 = get_timestamp_from_push_notif();
    /* If timestamp can be converted to long and is the same value as now then it is an epoch unix timestamp */
    assert_in_range(round((timestamp2 - timestamp1) / 1000), 14, 16);
}

void test_time_reference(UNUSED void** state) {
    set_bulkdata_time_reference("BulkData.Profile.simple_profile.", "2022-01-27T14:26:12Z");
    uint64_t timestamp = get_timestamp_from_push_notif();
    /* If timestamp value ( / 1000 to convert in seconds) modulo ReportingInterval value (15 seconds here) is equal
       to the seconds part (as ReportingInterval is lower than 1 mn we can simplify like that) of the TimeReference
       then we can consider we're compliant with TimeReference behaviour */
    assert_int_equal((timestamp / 1000) % 15, 12);
}
