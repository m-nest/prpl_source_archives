# Promise API for C Developers

## Table of Contents

[[_TOC_]]

## Overview

This guide introduces the **Promise API** for C developers, an abstraction to manage asynchronous flows with simplicity and modularity, inspired by modern languages like JavaScript (Promises), Rust (Futures), and C++ (std::promise/std::future). In C, asynchronous operations are usually handled via callbacks, polling, or threads, often resulting in tangled, hard-to-read code. The Promise API offers a structured way to represent work that completes in the future.

### What is a Promise?

A **promise** is a programming construct that represents the result of an operation that hasn't completed yet but is expected to in the future. It's a placeholder or a proxy for a value that becomes available later. The key advantage of using promises is **decoupling the initiation of an operation from the handling of its result**, which can also represent the result of a synchronous operation.

A promise has:

- A **provider**: creates the promise and will eventually fulfill or reject it.
- A **watcher**: receives the result or failure once available and can attach callback functions.

Promises transition through the following states:

- `pending`: The operation hasn't completed yet.
- `fulfilled`: The operation completed successfully, and the result is available.
- `rejected`: The operation failed, possibly due to error, timeout, or cancellation.

Only one of `fulfilled` or `rejected` is reached and a promise **cannot change state** after that point. Once a promise is either fulfilled or rejected, it enters a **settled** state.

The `settled` state is a superstate that indicates the promise has completed—either successfully or with failure. This is useful when a watcher wants to react regardless of whether the operation succeeded or failed. For example, using the `amxp_promise_state_settled` state in callback registration will ensure the callback is triggered as soon as the promise completes in either direction.

If the result is immediately available at the time of creation (e.g., from a cache or static computation), the promise can be created and fulfilled in a single step, effectively wrapping a synchronous operation within the same API. Mermaid diagram for a single Promise lifecycle:

```mermaid
stateDiagram-v2
    [*] --> Pending
    state Settled {
        Fulfilled
        Rejected
    }
    Pending --> Fulfilled: fulfill()
    Pending --> Rejected: reject()
    Fulfilled --> [*]
    Rejected --> [*]
```

### What is a Future?

A **future** is the read-only value associated with a promise. When the promise is fulfilled, the future contains the result. If the promise is rejected, the future may contain nothing or an error description. Only the watcher can inspect the future, and only after settlement.

### Aggregated Promises

An **aggregated promise** allows combining multiple promises into one logical unit. This is useful when you need to wait for several operations to complete before continuing. There are different strategies:

- `ALL`: Fulfill only when all sub-promises are fulfilled.
- `ANY`: Fulfill when any one sub-promise is fulfilled.
- `RACE`: Fulfill/reject as soon as the first one settles.
- `ALL_SETTLED`: Fulfill when all sub-promises are either fulfilled or rejected.

#### Example: ALL Strategy Aggregated Promise

```mermaid
graph LR
    subgraph AggregatePromise
        direction TB
        A1[Promise 1]:::sub
        A2[Promise 2]:::sub
        A3[Promise 3]:::sub
    end
    classDef sub fill:#f9f,stroke:#333,stroke-width:1px;
```

When the `ALL` strategy is used, the aggregated promise waits until all its sub-promises are fulfilled. If any one of them is rejected, the aggregated promise is immediately rejected, and the remaining pending sub-promises will be canceled.

Below is a visual representation of a successful aggregation using the `ALL` strategy:

```mermaid
graph TD
    subgraph AggregatePromise[Aggregated Promise - ALL Strategy]
        direction TB
        P1[Promise 1 Fulfilled ✅]
        P2[Promise 2 Fulfilled ✅]
        P3[Promise 3 Fulfilled ✅]
    end
    AggregatePromise --> Result[Aggregated Promise Fulfilled 🎉]
```

The order in which sub-promises are fulfilled does not matter. The aggregated promise will wait until **all** sub-promises are fulfilled, regardless of their individual completion timing.

And here is a sequence diagram showing the flow of resolution under the `ALL` strategy:

```mermaid
sequenceDiagram
    participant Watcher
    participant Provider
    participant Aggregate
    participant P1
    participant P2
    participant P3

    Watcher->>Provider: Request Promise 1
    Provider-->>Watcher: Return Promise 1

    Watcher->>Provider: Request Promise 2
    Provider-->>Watcher: Return Promise 2

    Watcher->>Provider: Request Promise 3
    Provider-->>Watcher: Return Promise 3

    Watcher->>Aggregate: Create aggregate promise (ALL)

    Aggregate->>P1: Install internal callback
    Aggregate->>P2: Install internal callback
    Aggregate->>P3: Install internal callback

    P1-->>Aggregate: Fulfilled
    P2-->>Aggregate: Fulfilled
    P3-->>Aggregate: Fulfilled
    Aggregate-->>Watcher: Settled callback (fulfilled)
```

To illustrate how failure is handled in the `ALL` strategy, consider the following sequence diagram. If any sub-promise is rejected, all remaining pending sub-promises are canceled and the aggregated promise is rejected:

```mermaid
sequenceDiagram
    participant Watcher
    participant Provider
    participant Aggregate
    participant P1
    participant P2
    participant P3

    Watcher->>Provider: Request Promise 1
    Provider-->>Watcher: Return Promise 1

    Watcher->>Provider: Request Promise 2
    Provider-->>Watcher: Return Promise 2

    Watcher->>Provider: Request Promise 3
    Provider-->>Watcher: Return Promise 3

    Watcher->>Aggregate: Create aggregate promise (ALL)

    Aggregate->>P1: Install internal callback
    Aggregate->>P2: Install internal callback
    Aggregate->>P3: Install internal callback

    P1-->>Aggregate: Fulfilled
    P2-->>Aggregate: Rejected ❌
    Aggregate-->>P3: Cancel pending
    Aggregate-->>Watcher: Settled callback (rejected)
```

### Chained Promises

A **chained promise** is used to sequence multiple asynchronous operations, where each step depends on the successful completion of the previous one. For each step in the chain, a callback function is defined that returns a new promise to continue the sequence.

The result of the final chained promise is determined by:

- The future of the last promise in the sequence, if all steps fulfill.
- The first rejected sub-promise or a callback returning `NULL`, which will immediately reject the chain.

An optional **final callback** can be specified. This callback is always executed once the chained promise settles—either fulfilled or rejected—providing a single point for final result handling or cleanup.

The final callback will get as input arguments the chained promise and the last step promise.

When the chained promise is canceled or rejected after timeout, the final is called as well but the last step promise will be a NULL
pointer, and the chained promise will be in the reject state with the status set either to `canceled` or `timeout`

#### Example: Chained Promise with Final Callback

```mermaid
graph TD
    Start[Start Chain] --> A[Promise 1]
    A -->|fulfilled| B[Promise 2]
    B -->|fulfilled| C[Promise 3]
    C -->|fulfilled| D[Final Callback]
    A -->|rejected| D
    B -->|rejected| D
    C -->|rejected| D
```

This diagram shows a successful flow as well as the fallback path in case any promise in the chain is rejected. The final callback is always invoked regardless of outcome.

The following sequence diagram illustrates how a chained promise is executed step by step, starting from the Watcher calling a Provider to obtain an initial Promise and then setting up a chained Promise with a final callback:

```mermaid
sequenceDiagram
    participant Watcher
    participant Chain
    participant Step1
    participant Step2
    participant Step3
    participant Provider

    rect rgba(0,0,0,0)
        Watcher->>Chain: Create chained Promise with final callback
        activate Chain

        Chain->>Step1: Execute step1 callback without promise
        Step1->>Provider: Request Promise 1
        Provider-->>Step1: Return Promise 1 (e.g., file read)
        Step1-->>Chain: Returns Promise1

        Chain-->>Watcher: Returns chained promise
        deactivate Chain
    end

    rect rgba(0,0,0,0)
        Note over Step1: Step1 fulfills (file read complete)
        Provider->>Chain: Fulfills Promise1
        activate Chain

        Chain->>Step2: Execute step2 callback with result of Promise 1

        Step2->>Provider: Request Promise 2
        Provider-->>Step2: Return Promise 2 (e.g., HTTP request)

        Step2-->>Chain: Returns Promise2
        deactivate Chain
    end

    rect rgba(0,0,0,0)
        Note over Step2: Step2 rejects (HTTP error)
        Provider->>Chain: Rejects Promise2 
        activate Chain

        Chain-->>Watcher: Final callback invoked with rejection
        deactivate Chain
    end

    rect rgba(0,0,0,0)
        Note over Step3: Step3 is never executed
    end
```

## Promise Glossary

### Core Types

- **Promise**: Represents an asynchronous operation managed by a *provider*.
- **Future**: A read-only result of a Promise, accessible by a *watcher*. Internally, an `amxc_var_t` is used to store the future result. For pending promises, the content of the future may change at any time until the promise is settled, at which point it becomes fixed. The future can be read at any time, even if the promise has not yet settled. However, the content of the future for a rejected promise is undefined. Developers should consult the provider's documentation to understand how it manages the future when rejecting a promise.

### Roles

- **Provider**: Creates the promise and is responsible for fulfilling or rejecting it. It typically represents the part of the system performing the asynchronous operation. The provider sets a cancel callback that will be called if the promise is deleted by the watcher while still pending. The provider creates the promise but transfers ownership to the watcher.

- **Watcher** (also called **consumer** in other implementations): Observes and reacts to the result of the promise. The watcher registers callbacks and handles the eventual fulfillment or rejection. The watcher is responsible for deleting the promise when it is no longer needed or may transfer ownership to another watcher.

### Promise States

A promise progresses through the following states:

- `pending`: The promise has been created, but neither fulfilled nor rejected.
- `fulfilled`: The promise has been successfully fulfilled with a result.
- `rejected`: The promise has been settled with an error.
- `settled`: A superstate that includes both `fulfilled` and `rejected`.

#### State Transitions

- A promise starts in the `pending` state.
- It transitions to `fulfilled` when `amxp_promise_fulfill()` is called.
- It transitions to `rejected` when `amxp_promise_reject()` is called.
- Once `fulfilled` or `rejected`, the promise enters the superstate `settled`.
- A promise can only transition once from `pending` to a settled state.

```mermaid
stateDiagram-v2
    [*] --> Pending
    state Settled {
        Fulfilled
        Rejected
    }
    Pending --> Fulfilled: fulfill()
    Pending --> Rejected: reject()
    Fulfilled --> [*]
    Rejected --> [*]
```

### Callback Types

- **Fulfillment callback**: Invoked when a promise is fulfilled.
- **Rejection callback**: Invoked when a promise is rejected.
- **Settled callback**: Because settled is a superstate, the callback registered for it is triggered when the promise is either fulfilled or rejected.

### Aggregation Strategies

- `ALL`: Fulfill only when all promises fulfill; reject on the first rejection.

```mermaid
sequenceDiagram
    participant Watcher
    participant Aggregate
    participant P1
    participant P2

    Watcher->>Aggregate: Create Aggregate (ALL)
    Aggregate->>P1: Attach callback
    Aggregate->>P2: Attach callback
    P1-->>Aggregate: Fulfilled
    P2-->>Aggregate: Fulfilled
    Aggregate-->>Watcher: Fulfilled
```

- `ANY`: Fulfill on the first fulfillment; reject only if all reject.

```mermaid
sequenceDiagram
    participant Watcher
    participant Aggregate
    participant P1
    participant P2

    Watcher->>Aggregate: Create Aggregate (ANY)
    Aggregate->>P1: Attach callback
    Aggregate->>P2: Attach callback
    P2-->>Aggregate: Fulfilled
    Aggregate-->>Watcher: Fulfilled
```

- `RACE`: Fulfill or reject as soon as one settles.

```mermaid
sequenceDiagram
    participant Watcher
    participant Aggregate
    participant P1
    participant P2

    Watcher->>Aggregate: Create Aggregate (RACE)
    Aggregate->>P1: Attach callback
    Aggregate->>P2: Attach callback
    P1-->>Aggregate: Rejected
    Aggregate-->>Watcher: Rejected
```

- `ALL_SETTLED`: Fulfill after all have fulfilled or rejected, regardless of success.

```mermaid
sequenceDiagram
    participant Watcher
    participant Aggregate
    participant P1
    participant P2

    Watcher->>Aggregate: Create Aggregate (ALL_SETTLED)
    Aggregate->>P1: Attach callback
    Aggregate->>P2: Attach callback
    P1-->>Aggregate: Fulfilled
    P2-->>Aggregate: Rejected
    Aggregate-->>Watcher: Fulfilled
```

### Chaining Promises

- Sequentially connect async steps.
- Each step must return a promise.
- A `final callback` may be specified for completion cleanup.

### Additional Features

- **Timeouts**: Reject a promise if not fulfilled within a given time.

- **Waitable Promises**: Allow blocking wait on async result.

- **Cancellation**: Drop a promise early, triggering a cleanup via cancel callback.


## Building and Using Promises

This section walks through practical steps to create, manage, and use promises in real applications. The examples assume familiarity with basic C syntax but no prior experience with promises is required.

### Creating Promises

Any promise that has been created must eventually be deleted to prevent memory/resource leaks. A provider is responsible for creating the promise and handing over ownership to a watcher. The watcher is responsible for deleting the promise when it's no longer needed or after it has been settled. Ownership may be transferred to another watcher, but there can be only **one** active watcher responsible for managing the promise's lifecycle at any time.

#### Simple Promise

A promise provider creates a promise using this function and returns it to the watcher. Ownership is handed over to the watcher. The provider may keep a reference to the promise, but must drop it immediately once the promise is settled or the cancel callback is triggered.

**Function Signature:**

```c
int amxp_promise_new(amxp_promise_t** promise,
                     amxp_promise_cancel_fn_t cancel_cb,
                     amxp_promise_wait_fn_t wait_cb,
                     void* data);
```

**Arguments:**

* `amxp_promise_t** promise`: Pointer to store the created promise.
* `amxp_promise_cancel_fn_t cancel_cb`: Callback to invoke on cancellation. This parameter is **mandatory** and must not be `NULL`. It will be triggered by the watcher to signal cancellation by calling `amxp_promise_delete()` on a still-pending promise. The provider must use this callback to perform any cleanup, and must drop all references to the promise once the callback is invoked.
* `amxp_promise_wait_fn_t wait_cb`: Optional; callback used to implement blocking behavior when `amxp_promise_wait()` is called. If this is `NULL`, the promise is not waitable, and `amxp_promise_wait()` will return `AMXP_PROMISE_STATUS_NOT_SUPPORTED`. This callback is called internally by `amxp_promise_wait()` and should block until the promise is settled.
* `void* data`: Provider-specific context passed to callbacks. If no context is needed, pass `NULL`.

\*\*Usage Example\*\*

```c
amxp_promise_t* promise = NULL;
amxp_promise_new(&promise, cancel_cb, wait_cb, provider_data);
```

#### Aggregated Promise

These functions are typically used by a watcher to combine multiple promises into a single aggregated promise. This allows the watcher to coordinate actions based on multiple asynchronous operations.

---
> **NOTE**<br>
> When an aggregated promise gets settled, any still pending promises are canceled.<br>
> e.g.: An aggregated **RACE** promise will be settled as soon as the first promise is settled, regardless of the other promises' status.
> All other sub-promises will be canceled immediately.
---

The future of an aggregated promise is determined by the aggregation type and only guaranteed when the aggregated promise is fulfilled.
- ALL and ALL_SETTLED: The future is a list variant containing the individual results of each sub-promise. The futures are in the same order in the list as the sub-promises were passed to the aggregation function.
- ANY and RACE: The future is a single variant containing the result of the first settled sub-promise.

**Function Signatures:**

```c
int amxp_promise_new_aggregate(amxp_promise_t** aggregated,
                               amxp_promise_aggregate_type_t aggr_type,
                               ...);

int amxp_promise_new_aggregate_array(amxp_promise_t** aggregated,
                                     amxp_promise_aggregate_type_t aggr_type,
                                     uint32_t count,
                                     amxp_promise_t* promises[]);

int amxp_promise_new_aggregate_list(amxp_promise_t** aggregated,
                                    amxp_promise_aggregate_type_t aggr_type,
                                    amxc_llist_t* promises);
```

**Arguments for `amxp_promise_new_aggregate`:**

* `amxp_promise_t** aggregated`: Pointer to the new aggregated promise.
* `amxp_promise_aggregate_type_t aggr_type`: Aggregation strategy.
* `...`: Variadic list of promises. Terminate the list with `NULL` to indicate the end.

**Arguments for `amxp_promise_new_aggregate_array`:**

* `amxp_promise_t** aggregated`: Pointer to the new aggregated promise.
* `amxp_promise_aggregate_type_t aggr_type`: Aggregation strategy (e.g., ALL, ANY).
* `uint32_t count`: Number of sub-promises.
* `amxp_promise_t* promises[]`: Array of sub-promises.

**Arguments for `amxp_promise_new_aggregate_list`**

* `amxp_promise_t** aggregated`: Pointer to the new aggregated promise.
* `amxp_promise_aggregate_type_t aggr_type`: Aggregation strategy.
* `amxc_llist_t* promises`: Linked list of promises.

**Usage Example:**

```c
amxp_promise_t* list[2] = { p1, p2 };
amxp_promise_t* aggregate = NULL;
amxp_promise_new_aggregate_array(&aggregate, amxp_promise_aggregate_all, 2, list);
amxp_promise_when(aggregate, amxp_promise_state_settled, on_all_done, NULL);
```

#### Chained Promise

These functions are typically used by a provider to define a sequence of asynchronous operations. Each step in the chain returns a promise, and the next step will only be executed if the previous one is fulfilled. A final callback is always called at the end, regardless of success or failure.

The future of a chained promise can be set or changed in each individual step, including the final callback. If none of the steps including the final callback change the future and the chained promise is finished (fulfilled), the future of the last step is used as future of the chained promise.

**Function Signatures:**

```c
int amxp_promise_new_chained(amxp_promise_t** chained,
                             amxp_promise_final_fn_t final,
                             void* provider_priv,
                             ...);

int amxp_promise_new_chained_array(amxp_promise_t** chained,
                                   amxp_promise_final_fn_t final,
                                   void* provider_priv,
                                   uint32_t count,
                                   amxp_promise_chain_fn_t promises[]);
```

**Arguments for `amxp_promise_new_chained`:**

* `amxp_promise_t** chained`: Pointer to the resulting chained promise.
* `amxp_promise_final_fn_t final`: Final callback invoked once the chain is settled. A final is optional, if not needed pass `NULL`.
* `void* provider_priv`: Provider-specific context passed to each chain step. If not needed, pass `NULL`.
* `...`: Variadic list of chain step functions of type `amxp_promise_chain_fn_t`. Must be terminated with `NULL`.

**Arguments for `amxp_promise_new_chained_array`:**

* `amxp_promise_t** chained`: Pointer to the resulting chained promise.
* `amxp_promise_final_fn_t final`: Final callback invoked once the chain is settled. A final is optional, if not needed pass `NULL`.
* `void* provider_priv`: Provider-specific context passed to each chain step. If not needed, pass `NULL`.
* `uint32_t count`: Number of chain steps.
* `amxp_promise_chain_fn_t promises[]`: Array of chain step functions.

**Usage Example:**

```c
amxp_promise_t* chain = NULL;
amxp_promise_chain_fn_t steps[] = { step1_cb, step2_cb };
amxp_promise_new_chained_array(&chain, final_callback, provider_data, 2, steps);
amxp_promise_when(chain, amxp_promise_state_settled, final_callback, NULL);
```

Each `stepX_cb` must return a new promise based on the result of the previous step.

### Settling a Promise

#### Provider-Side Settlement

**Function Signatures:**

```c
void amxp_promise_fulfill(amxp_promise_t* promise, amxc_var_t* result);
void amxp_promise_reject(amxp_promise_t* promise, amxp_promise_status_t reason);
```

These functions are used by the **provider** to settle the promise. Once `amxp_promise_fulfill()` or `amxp_promise_reject()` is called, the provider **must drop all references** to the promise object.

#### Auto-Reject Timeout

```c
void amxp_promise_reject_after(amxp_promise_t* promise, int timeout);
```

This function is typically used by a **watcher** to ensure a promise does not hang indefinitely. It can also be used by a provider. It sets a timeout in milliseconds after which the promise will be automatically rejected if it hasn't been settled.

A promise that gets rejected after the timeout is reached will have the status `AMXP_PROMISE_STATUS_TIMEOUT`.

**Arguments:**

* `amxp_promise_t* promise`: The promise to be settled.

* `int timeout`: Time in ms to auto-reject after.

**Usage Examples:**

```c
amxp_promise_fulfill(promise, result_var);
amxp_promise_reject(promise, AMXP_PROMISE_STATUS_REJECTED);
amxp_promise_reject_after(promise, 5000); // 5 seconds
```

### Watching a Promise

Note: `amxp_promise_state_settled` is not a separate internal state. When used with `amxp_promise_when()`, it registers the callback for both the `fulfilled` and `rejected` states.

When `amxp_promise_when()` is called on a pending promise, the callback is stored and will be invoked once the promise reaches the specified state.

If the promise is already in the target state at the time of registration, the callback will be invoked immediately.

It is allowed to call `amxp_promise_when()` multiple times on the same promise, but each call will overwrite the previously registered callbacks for the same state.&#x20;

**Function Signature:**

```c
int amxp_promise_when(amxp_promise_t* promise,
                      amxp_promise_state_t state,
                      amxp_promise_callback_t cb,
                      void* priv);
```

**Arguments:**

* `amxp_promise_t* promise`: Promise to attach callback to.
* `amxp_promise_state_t state`: State to watch for (fulfilled, rejected, settled).
* `amxp_promise_callback_t cb`: Callback function to execute.
  If unused, pass `NULL`.
* `void* priv`: Watcher-specific context passed to the callback. If no context is needed, pass NULL.

**Usage Example:**

```c
amxp_promise_when(promise, amxp_promise_state_fulfilled, on_success, NULL);
amxp_promise_when(promise, amxp_promise_state_rejected, on_failure, NULL);
amxp_promise_when(promise, amxp_promise_state_settled, on_complete, NULL);
```

### Waitable Promises

A promise is considered waitable if it was created with a non-`NULL` `wait_cb` (wait callback) during its initialization via `amxp_promise_new()`. Only such promises can be used with `amxp_promise_wait()` to perform blocking waits.

If `amxp_promise_wait()` is called on a non-waitable promise, it returns `AMXP_PROMISE_STATUS_NOT_SUPPORTED` to indicate that waiting is not supported.

**Function Signatures:**

```c
bool amxp_promise_is_waitable(const amxp_promise_t* promise);
int amxp_promise_wait(amxp_promise_t* promise, int timeout);
```

**Arguments:**

* `const amxp_promise_t* promise`: Promise to check.
* `int timeout`: Time in ms to wait.

**Usage Example:**

```c
if(amxp_promise_is_waitable(promise)) {
    amxp_promise_wait(promise, 1000); // wait 1s
}
```

### Access Futures

**Function Signatures:**

```c
const amxc_var_t* amxp_promise_get_future(amxp_promise_t* promise);
amxc_var_t* amxp_promise_take_future(amxp_promise_t* promise);
```

- `amxp_promise_get_future` returns a constant pointer to the future value. Ownership of the variant is not transferred. When the promise is deleted, the variant is deleted as well.
- `amxp_promise_take_future` returns a pointer to the future value. Ownership of the variant is transferred. When the promise is deleted, the variant is not deleted.

### Cleanup

**Function Signatures:**

```c
void amxp_promise_delete(amxp_promise_t** promise);
```

**Arguments:**

* `amxp_promise_t** promise`: Pointer to the promise to delete.

**Usage Example:**

```c
// Transfer ownership of result value, if you need to keep the result
amxc_var_t* result = amxp_promise_take_future(promise);
amxp_promise_delete(&promise);
```

## Ownership & Memory

- Provider drops any reference to the promise after settling.
- Provider drops any reference to the promise when cancel callback function is called.
- Watcher deletes the Promise when done.
- Aggregated/Chained Promises manage their sub-promises.

## Usage Example

```c
void on_data_ready(amxp_promise_t* promise, UNUSED void* priv) {
    if(amxp_promise_is_fulfilled(promise)) {
        const amxc_var_t* result = amxp_promise_get_future(promise);
        // Process result
    }
    amxp_promise_delete(&promise);
}

void fetch_data(amxb_bus_ctx* ctx) {
    amxp_promise_t* p1 = amxb_async_get(ctx, "Device.IP.Interface.[Alias=='wan'].");
    amxp_promise_t* p2 = amxb_async_get(ctx, "Device.Firewall.Service.[Alias=='ssh-wan'].");
    amxp_promise_t* agg = NULL;
    amxp_promise_new_aggregate(&agg, amxp_promise_aggregate_all, p1, p2, NULL);
    amxp_promise_when(agg, amxp_promise_state_settled, on_data_ready, NULL);
}
```
