# libnetmodel

Client library that facilitates interaction with NetModel.