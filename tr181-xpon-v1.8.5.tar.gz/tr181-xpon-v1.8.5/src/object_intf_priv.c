/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "object_intf_priv.h"

/* System headers */
#include <stdlib.h> /* calloc(), free() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* when_null() */

/* Own headers */
#include "utils_time.h" /* time_get_system_uptime() */
#include "xpon_trace.h"


typedef struct _uni_priv {
    uint32_t last_change;
} uni_priv_t;

typedef struct _ani_priv {
    uint32_t last_change;
} ani_priv_t;


/**
 * Create and attach private data to EthernetUNI object.
 *
 * @param[in,out] object: EthernetUNI object to which this function must attach
 *                        private data
 * @param[in] now: uptime. The function stores it in the private data.
 */
static void attach_uni_priv(amxd_object_t* object, uint32_t now) {
    uni_priv_t* const priv = (uni_priv_t*) calloc(1, sizeof(uni_priv_t));
    when_null_trace(priv, exit, ERROR, "Failed to create uni_priv_t");
    object->priv = priv;
    priv->last_change = now;
exit:
    return;
}

/**
 * Create and attach private data to ANI object.
 *
 * @param[in,out] object: ANI object to which this function must attach
 *                        private data
 * @param[in] now: uptime. The function stores it in the private data.
 */
static void attach_ani_priv(amxd_object_t* object, uint32_t now) {
    ani_priv_t* const priv = (ani_priv_t*) calloc(1, sizeof(ani_priv_t));
    when_null_trace(priv, exit, ERROR, "Failed to create ani_priv_t");
    object->priv = priv;
    priv->last_change = now;
exit:
    return;
}

/**
 * Create and attach private data to interface object.
 *
 * @param[in,out] object: object to which this function must attach private data
 * @param[in,out] path: path to the EthernetUNI or ANI template object, e.g.,
 *                      "XPON.ONU.1.EthernetUNI"
 * @param[in] index: index of the instance object
 * @param[in] oid: oid of @a object
 *
 * tr181-xpon calls this function if an EthernetUNI or ANI instance is added.
 */
void oipriv_attach_private_data(amxd_object_t* object, const char* path,
                                uint32_t index, object_id_t oid) {
    when_null(object, exit);
    when_not_null_trace(object->priv, exit, ERROR, "%s.%d already has private data",
                        path, index);
    const uint32_t now = time_get_system_uptime();
    switch(oid) {
    case oid_ethernet_uni:
        attach_uni_priv(object, now);
        break;
    case oid_ani:
        attach_ani_priv(object, now);
        break;
    default:
        break;
    }
exit:
    return;
}

/**
 * Delete private data of an EthernetUNI.
 *
 * @param[in] object: EthernetUNI object for which to delete the private data
 */
static void delete_uni_priv(amxd_object_t* object) {
    uni_priv_t* priv = (uni_priv_t*) object->priv;
    if(priv) {
        free(priv);
    }
    object->priv = NULL;
}

/**
 * Delete private data of an ANI.
 *
 * @param[in] object: ANI object for which to delete the private data
 */
static void delete_ani_priv(amxd_object_t* object) {
    ani_priv_t* priv = (ani_priv_t*) object->priv;
    if(priv) {
        free(priv);
    }
    object->priv = NULL;
}

/**
 * Delete private data of an interface object.
 *
 * @param[in,out] object: object for which this function must delete the private
 *                        data
 * @param[in] oid: oid of @a object
 *
 * tr181-xpon calls this function if an EthernetUNI or ANI instance is deleted.
 */
void oipriv_delete_private_data(amxd_object_t* object, object_id_t oid) {
    when_null(object, exit);
    when_null(object->priv, exit);
    switch(oid) {
    case oid_ethernet_uni:
        delete_uni_priv(object);
        break;
    case oid_ani:
        delete_ani_priv(object);
        break;
    default:
        break;
    }

exit:
    return;
}

/**
 * Update the @c last_change field in the private data of an EthernetUNI.
 *
 * @param[in,out] object: EthernetUNI for which this function must update the
 *                        @c last_change field
 * @param[in] now: uptime
 */
static void uni_update_last_change(amxd_object_t* object, uint32_t now) {
    uni_priv_t* const priv = (uni_priv_t*) object->priv;
    priv->last_change = now;
}

/**
 * Update the @c last_change field in the private data of an ANI.
 *
 * @param[in,out] object: ANI for for which this function must update the
 *                        @c last_change field
 * @param[in] now: uptime
 */
static void ani_update_last_change(amxd_object_t* object, uint32_t now) {
    ani_priv_t* const priv = (ani_priv_t*) object->priv;
    priv->last_change = now;
}

/**
 * Update the last_change field in the private data of an interface object.
 *
 * @param[in,out] object: object for which this function must update the
 *                        last_change field
 * @param[in] oid: oid of @a object
 *
 * tr181-xpon calls this function if the Status parameter of an interface object
 * is changed.
 */
void oipriv_update_last_change(amxd_object_t* object, object_id_t oid) {
    when_null(object, exit);
    when_null(object->priv, exit);
    const uint32_t now = time_get_system_uptime();
    switch(oid) {
    case oid_ethernet_uni:
        uni_update_last_change(object, now);
        break;
    case oid_ani:
        ani_update_last_change(object, now);
        break;
    default:
        break;
    }
exit:
    return;
}

/**
 * Get the timestamp when Status of an EthernetUNI last changed value.
 *
 * @param[in] object: EthernetUNI for which this function must return when its
 *                    Status last changed value
 *
 * @return the timestamp when Status of an EthernetUNI last changed value
 */
static uint32_t get_uni_last_change(const amxd_object_t* object) {
    const uni_priv_t* const priv = (const uni_priv_t*) object->priv;
    return priv->last_change;
}

/**
 * Get the timestamp when Status of an ANI last changed value.
 *
 * @param[in] object: ANI for which this function must return when its
 *                    Status last changed value
 *
 * @return the timestamp when Status of an ANI last changed value
 */
static uint32_t get_ani_last_change(const amxd_object_t* object) {
    const ani_priv_t* const priv = (const ani_priv_t*) object->priv;
    return priv->last_change;
}

/**
 * Get the timestamp when Status of an object last changed value.
 *
 * @param[in] object: object for which this function must return when its Status
 *                    last changed value
 * @param[in] path: path of @a object
 *
 * @return the timestamp when Status of an object last changed value
 */
uint32_t oipriv_get_last_change(const amxd_object_t* object, const char* path) {
    uint32_t result = 0;
    when_null(object, exit);
    when_null(object->priv, exit);
    when_null(path, exit);
    const object_id_t oid = dm_get_object_id(path);
    switch(oid) {
    case oid_ethernet_uni:
        result = get_uni_last_change(object);
        break;
    case oid_ani:
        result = get_ani_last_change(object);
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "path='%s': not EthernetUNI or ANI", path);
        break;
    }
exit:
    return result;
}

