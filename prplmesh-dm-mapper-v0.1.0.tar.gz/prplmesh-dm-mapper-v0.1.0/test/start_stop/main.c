/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <stdio.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxrt/amxrt.h>

#include "dmm.h"

int test_setup(void** state) {
    amxut_bus_setup(state);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

void __wrap_dmm_start_amx_listen() {
    function_called();
}

int __wrap_dmm_translator_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    function_called();
    check_expected(dm);
    check_expected(parser);

    return mock_type(int);
}

void test_dmm_can_start(UNUSED void** state) {

    amxc_var_t* config = &amxut_bus_parser()->config;
    amxc_var_t* mapped_objects = amxc_var_add_new_key(config, DMM_OBJECTS_CONFIG);
    amxc_var_set_type(mapped_objects, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, mapped_objects, "WIFIMapped.", "WiFi.");
    amxc_var_add_key(cstring_t, mapped_objects, "WIFIMapped.DataElements.", "DataElements.");

    expect_function_call(__wrap_dmm_start_amx_listen);
    expect_function_call(__wrap_dmm_translator_init);
    expect_value(__wrap_dmm_translator_init, dm, amxut_bus_dm());
    expect_value(__wrap_dmm_translator_init, parser, amxut_bus_parser());
    will_return(__wrap_dmm_translator_init, 0);

    assert_int_equal(_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
}

int __wrap_dmm_translator_cleanup(amxd_dm_t* dm, amxo_parser_t* parser) {
    function_called();
    check_expected(dm);
    check_expected(parser);

    return mock_type(int);

}

void test_dmm_can_stop(UNUSED void** state) {
    expect_function_call(__wrap_dmm_translator_cleanup);
    expect_value(__wrap_dmm_translator_cleanup, dm, amxut_bus_dm());
    expect_value(__wrap_dmm_translator_cleanup, parser, amxut_bus_parser());
    will_return(__wrap_dmm_translator_cleanup, 0);

    assert_int_equal(_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
}

int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_dmm_can_start),
        cmocka_unit_test(test_dmm_can_stop)
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);

}
