/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <signal.h>

#include "test_tr069-connectionrequest.h"

#define UNUSED __attribute__((unused))

static const char* g_test_ipv4 = "192.168.1.2";
static const char* g_test_ipv6 = "3004:3000:1101:107::6";
static uint16_t g_test_port_v4 = 50805;
static uint16_t g_test_port_v6 = 50805;
static uint16_t g_test_port_v6_ula_gua = 50805;
static const char* g_test_ipv6_ula_gua = "3004:3000:1101:107::6";

int __wrap_amxb_be_load(const char* path_name) {
    (void) path_name;
    return 0;
}

int __wrap_amxb_connect(amxb_bus_ctx_t** ctx, const char* uri) {
    static amxb_bus_ctx_t dummy_ctx;

    assert_non_null(ctx);
    assert_non_null(uri);
    assert_true(strlen(uri) > 0);

    *ctx = &dummy_ctx;

    return 0;
}

int __wrap_UpnpGetIfInfo(const char* IfName) {
    assert_non_null(IfName);
    assert_string_equal(IfName, "br-lan");
    return 0;
}

int __wrap_amxb_wait_for_object(const char* object) {
    (void) object;
    return 0;
}

int __wrap_init_amx(void) {
    return 0;
}

int __wrap_amxb_get(amxb_bus_ctx_t* const bus_ctx,
                    const char* object,
                    int32_t depth,
                    amxc_var_t* ret,
                    int timeout) {
    (void) bus_ctx; (void) depth; (void) timeout;
    assert_non_null(object);
    assert_non_null(ret);
    amxc_var_init(ret);

    if(strcmp(object, "ManagementServer.") == 0) {
        amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

        amxc_var_t* L0_1 = amxc_var_add_new(ret);
        amxc_var_set_type(L0_1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, L0_1, "Interface", "Device.Logical.Interface.1");

        amxc_var_t* L0 = amxc_var_add_new(ret);
        amxc_var_set_type(L0, AMXC_VAR_ID_LIST);

        amxc_var_t* L1 = amxc_var_add_new(L0);
        amxc_var_set_type(L1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, L1, "URL",
                         "http://192.168.77.161:50555/");

        return 0;
    }

    if(strcmp(object, "ManagementServer.State.") == 0) {
        amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

        amxc_var_t* L0 = amxc_var_add_new(ret);
        amxc_var_set_type(L0, AMXC_VAR_ID_LIST);

        amxc_var_t* L1 = amxc_var_add_new(L0);
        amxc_var_set_type(L1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, L1, "ACSIP", "192.168.77.161");

        return 0;
    }

    if(strcmp(object, "ManagementServer.Stats.") == 0) {
        amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

        amxc_var_t* L0 = amxc_var_add_new(ret);
        amxc_var_set_type(L0, AMXC_VAR_ID_LIST);

        amxc_var_t* L1 = amxc_var_add_new(L0);
        amxc_var_set_type(L1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(uint32_t, L1, "SessionsSinceReboot", 15);

        return 0;
    }

    if(strcmp(object, "IP.Interface.[Alias == 'lan'].IPv4Address.[Enable == 1].") == 0) {
        amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

        amxc_var_t* L0 = amxc_var_add_new(ret);
        amxc_var_set_type(L0, AMXC_VAR_ID_LIST);

        amxc_var_t* L1 = amxc_var_add_new(L0);
        amxc_var_set_type(L1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(uint32_t, L1, "Enable", 1);
        amxc_var_add_key(cstring_t, L1, "IPAddress", "192.168.1.2");
        amxc_var_add_key(cstring_t, L1, "SubnetMask", "255.255.255.0");

        return 0;
    }

    if(strcmp(object, "ManagementServer.ConnRequest.") == 0) {
        amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

        amxc_var_t* L0 = amxc_var_add_new(ret);
        amxc_var_set_type(L0, AMXC_VAR_ID_LIST);

        amxc_var_t* L1 = amxc_var_add_new(L0);
        amxc_var_set_type(L1, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(uint32_t, L1, "ConnRequestPort", 50805);

        return 0;
    }

    return 1;
}

int __wrap_UpnpInit2(const char* IfName, unsigned short DestPort) {
    assert_non_null(IfName);
    assert_int_equal(DestPort, 0);
    return UPNP_E_SUCCESS;
}

int __wrap_UpnpFinish(void) {
    return UPNP_E_SUCCESS;
}

char* __wrap_UpnpGetServerIpAddress(void) {
    return (char*) g_test_ipv4;
}

char* __wrap_UpnpGetServerIp6Address(void) {
    return (char*) g_test_ipv6;
}

unsigned short __wrap_UpnpGetServerPort(void) {
    return g_test_port_v4;
}

unsigned short __wrap_UpnpGetServerPort6(void) {
    return g_test_port_v6;
}

unsigned short __wrap_UpnpGetServerUlaGuaPort6(void) {
    return g_test_port_v6_ula_gua;
}

char* __wrap_UpnpGetServerUlaGuaIp6Address(void) {
    return (char*) g_test_ipv6_ula_gua;
}

void __wrap_create_upnp_firewall_rules(unsigned short port, int isIPv6) {
    assert_non_null(port);
    (void) isIPv6;
    return;
}

void __wrap_create_upnp_ssdp_firewall_rules(int isIPv6) {
    (void) isIPv6;
    return;
}

void __wrap_destroy_upnp_firewall_rules(int isIPv6) {
    (void) isIPv6;
    return;
}

void __wrap_destroy_upnp_ssdp_firewall_rules(int isIPv6) {
    (void) isIPv6;
    return;
}

int __wrap_UpnpRegisterClient(Upnp_FunPtr Fun, const void* Cookie, UpnpClient_Handle* Hnd) {
    assert_non_null(Fun);
    assert_non_null(Cookie);
    assert_non_null(Hnd);
    return UPNP_E_SUCCESS;
}

int __wrap_UpnpSearchAsync(UpnpClient_Handle Hnd,
                           int Mx,
                           const char* Target_const,
                           const void* Cookie_const) {
    assert_non_null(Hnd);
    assert_non_null(Mx);
    assert_non_null(Target_const);
    (void) Cookie_const;
    return UPNP_E_SUCCESS;
}

int __wrap_UpnpUnSubscribe(UpnpClient_Handle Hnd, const Upnp_SID SubsId) {
    assert_non_null(Hnd);
    assert_non_null(SubsId);
    return UPNP_E_SUCCESS;
}

int __wrap_UpnpUnRegisterClient(UpnpClient_Handle Hnd) {
    assert_non_null(Hnd);
    return UPNP_E_SUCCESS;
}

int __wrap_amxm_so_open(const char* path) {
    (void) path;
    return 0;
}

int __wrap_sigwait(const sigset_t* set, int* sig) {
    (void) set;
    sleep(5);
    *sig = SIGINT;
    return 0;
}
