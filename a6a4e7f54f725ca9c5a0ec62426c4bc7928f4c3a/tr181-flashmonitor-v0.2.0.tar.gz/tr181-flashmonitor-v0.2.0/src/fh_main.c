/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <dirent.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "flash_health.h"
#include "dm_flash_health.h"

#define ME "events"
/**
 * @struct flash_health_app_t
 * @brief Structure representing the Flash Health application context.
 */
static flash_health_app_t app;

/**
 * @fn amxd_dm_t* fh_get_dm(void)
 * @brief Retrieves the data model pointer for the Flash Health application.
 *
 * @return Pointer to the application's data model.
 */
amxd_dm_t* fh_get_dm(void) {
    return app.dm;
}

/**
 * @fn int _fh_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser)
 * @brief Main entry function for the Flash Health application lifecycle.
 *
 * Handles initialization and cleanup based on the provided reason.
 *
 * @param reason Reason for invocation (0 = START, 1 = STOP).
 * @param dm Pointer to the application's data model.
 * @param parser Pointer to the application's parser.
 * @return Always returns 0.
 */
int _fh_main(int reason,
             amxd_dm_t* dm,
             amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    switch(reason) {
    case AMXO_START:     // START
        app.dm = dm;
        app.parser = parser;
        flash_device_init();
        break;
    case AMXO_STOP:     // STOP
        flash_device_cleanup();
        app.dm = NULL;
        app.parser = NULL;
        break;
    }
    SAH_TRACEZ_OUT(ME);
    return 0;
}
