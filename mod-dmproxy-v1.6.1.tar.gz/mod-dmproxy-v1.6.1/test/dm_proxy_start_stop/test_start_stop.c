/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <sys/signalfd.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include "dm_proxy.h"

#include <amxb/amxb_register.h>

#include "../mocks/test_common.h"

#include "test_start_stop.h"

void test_can_start_and_stop(UNUSED void** state) {
    amxo_parser_t parser;
    amxd_dm_t dm;
    amxd_object_t* root_obj = NULL;
    amxd_object_t* device_obj = NULL;

    amxo_parser_init(&parser);
    amxd_dm_init(&dm);

    root_obj = amxd_dm_get_root(&dm);
    amxo_parser_parse_file(&parser, "../mocks/test.odl", root_obj);

    amxd_object_new(&device_obj, amxd_object_singleton, "Device");
    amxd_object_add_object(root_obj, device_obj);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_STOP, &dm, &parser), 0);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

void test_can_start_with_objects_defined(UNUSED void** state) {
    amxo_parser_t parser;
    amxd_dm_t dm;
    amxd_object_t* root_obj = amxd_dm_get_root(&dm);

    amxo_parser_init(&parser);
    amxd_dm_init(&dm);

    root_obj = amxd_dm_get_root(&dm);
    amxo_parser_parse_file(&parser, "../mocks/test.odl", root_obj);
    amxo_parser_parse_file(&parser, "../mocks/proxy_definition.odl", root_obj);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_STOP, &dm, &parser), 0);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

void test_can_start_without_objects_defined(UNUSED void** state) {
    amxo_parser_t parser;
    amxd_dm_t dm;
    amxd_object_t* root_obj = amxd_dm_get_root(&dm);

    amxo_parser_init(&parser);
    amxd_dm_init(&dm);

    root_obj = amxd_dm_get_root(&dm);
    amxo_parser_parse_file(&parser, "../mocks/test_no_mapping.odl", root_obj);
    amxo_parser_parse_file(&parser, "../mocks/proxy_definition.odl", root_obj);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    assert_non_null(GET_ARG(&parser.config, "proxy-object"));
    assert_int_equal(_dm_proxy_main(AMXO_STOP, &dm, &parser), 0);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

void test_start_fails_when_proxy_defintion_is_not_htable(UNUSED void** state) {
    amxo_parser_t parser;
    amxd_dm_t dm;
    amxd_object_t* root_obj = NULL;

    amxo_parser_init(&parser);
    amxd_dm_init(&dm);

    root_obj = amxd_dm_get_root(&dm);
    amxo_parser_parse_file(&parser, "../mocks/test_invalid_proxy.odl", root_obj);

    handle_events();

    assert_int_not_equal(_dm_proxy_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_STOP, &dm, &parser), 0);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

void test_unregister_after_stop(UNUSED void** state) {
    amxo_parser_t parser;
    amxd_dm_t dm;
    amxd_object_t* root_obj = amxd_dm_get_root(&dm);
    amxd_object_t* device_obj = NULL;

    amxo_parser_init(&parser);
    amxd_dm_init(&dm);

    root_obj = amxd_dm_get_root(&dm);
    amxo_parser_parse_file(&parser, "../mocks/test.odl", root_obj);

    amxd_object_new(&device_obj, amxd_object_singleton, "Device");
    amxd_object_add_object(root_obj, device_obj);

    handle_events();

    assert_int_equal(_dm_proxy_main(AMXO_START, &dm, &parser), 0);

    handle_events();

    assert_int_equal(dm_proxy_unregister("Device.IP.Diagnostics."), 0);
    assert_int_equal(_dm_proxy_main(AMXO_STOP, &dm, &parser), 0);
    assert_int_equal(dm_proxy_unregister("Device.IP.Diagnostics."), -1);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}
