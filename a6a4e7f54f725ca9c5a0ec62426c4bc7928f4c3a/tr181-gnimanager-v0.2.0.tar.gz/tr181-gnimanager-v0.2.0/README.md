# tr181-gnimanager

## Summary

GNI Manager for modelling of Generic Logical Interface

## Description

GNI manager will manage the dynamically created generic interface which is currently not managed by any other TR181 layers.
Model logical interface and its "Status" sync with lower layers(NetDev, NetModel) and upper layers(IP).

## Installation

You can build and install the GNI Manager by running
```
make && sudo make install
```

### compile and install

```
make
sudo make install
```

### run test

```
make test
```

### run plugin inside a Ambiorix Docker container
Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

compile/install dependencies: (make + sudo make install)

 * libsahtrace
 * libamxb
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxj

## Purpose
Currently, a management component with corresponding data model is required in order to model a network interface under Device.Bridging.Bridge. or Device.IP.The dynamically created network interfaces, such as tunnel devices or USB network interfaces, cannot be managed by prplOS. The tr181-gnimanager plugin is to ease software development to be able to use interfaces that are not yet managed.

## Scope
A network management component that allows dynamic instantiation of new generic interfaces, specifying the Linux netdev interface name, which link to the netdev plug-in to update status in real-time, and allow modelling under other network layers (logical, IP, PPP, bridge). 

## Implementation
* The status change of an interface is notified to GNI upon subscription. Upon notification, the status would be modified accordingly in GNI for that interface.
* When there is default configuration(via default ODL), the validation is skipped to ensure if the underlying netdev interface exists or not. It is by presumption that it is by default present in the system during boot-up.
* When GNI instance is created dynamically by any upper layers or manually, if the netdev interface is not present, the configuration is rejected.
* To avoid duplication, if the netdev interface is already managed by any other TR-181 object modelling an InterfaceStack network interface, then the configuration shall be rejected during dynamic case.
* The plugin shall iterate all the netmodel interfaces and check for the interface if it is managed by any other TR-181 object, if so configuration is rejected during dynamic creation case.
* The status would be "NotPresent" if the netdev interface is removed/deleted from the system.
* The tr181-gnimanager reflects the current state of the underlying netdev interface
* Does not persist configuration
* Statistics Module: Interfaces report usage metrics via mod-dm-stats.

## Usage

Consider an example where netdev interface br0 is present  and status is down.
The corresponding GNI instance is created, then any change in status in NetDev is reflected in GNI too upon subscription.

```
root@prplOS:/# ip link set dev br0 up
```
```
>GenericNetworkInterface.Interface.1.Status?
GenericNetworkInterface.Interface.1.Status="Up"

root - * - [bus-cli] (0)
```

Deleting the netdev interface would make the corresponding GNI interface status as "NotPresent"

```
root@prplOS:/# ip link delete br0
```
```
>GenericNetworkInterface.Interface.1.Status?
GenericNetworkInterface.Interface.1.Status="NotPresent"

root - * - [bus-cli] (0)
```

In other scenario, if a GNI instance is created with an interface name and that interface is not part of the netdev interfaces, then the configuration is rejected.

```
 > NetDev.Link.*.Alias?
NetDev.Link.1.Alias="lo"
NetDev.Link.10.Alias="br-guest"
NetDev.Link.11.Alias="br-lcm"
NetDev.Link.12.Alias="wlan0"
NetDev.Link.13.Alias="wlan1"
NetDev.Link.14.Alias="wlan0p1"
NetDev.Link.15.Alias="wlan1p1"
NetDev.Link.16.Alias="wlan0.1"
NetDev.Link.2.Alias="eth0"
NetDev.Link.3.Alias="eth1"
NetDev.Link.4.Alias="eth2"
NetDev.Link.5.Alias="eth3"
NetDev.Link.6.Alias="ip6tnl0"
NetDev.Link.7.Alias="teql0"
NetDev.Link.8.Alias="hwsim0"
NetDev.Link.9.Alias="br-lan"

 > GenericNetworkInterface.Interface+{Alias="gni-veth1", Name="veth1"}
ERROR: add GenericNetworkInterface.Interface failed (10 - invalid value)

root - * - [bus-cli] (10)
```

In addition, the configuration is rejected if it is part of the netdev interfaces but already managed by any other TR-181 object modelling an InterfaceStack network interface.

```
 > GenericNetworkInterface.Interface+{Alias="gni-eth0", Name="eth0"}
ERROR: add GenericNetworkInterface.Interface failed (10 - invalid value)

root - * - [bus-cli] (10)
 > NetModel.Intf.[Name=='eth0'].InterfacePath?
NetModel.Intf.24.InterfacePath="Device.Ethernet.Interface.2."
NetModel.Intf.31.InterfacePath="Device.Bridging.Bridge.1.Port.2."
```
