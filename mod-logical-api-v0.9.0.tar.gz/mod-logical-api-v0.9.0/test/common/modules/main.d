../modules//main.o ../modules//main.d: src//main.c \
 ../../../include_priv/logical_api_lan.h
../../../include_priv/logical_api_lan.h:
