{% import * as fs from 'fs'; %}
%populate {
    object 'Syslog' {
        object 'Filter' {
            instance add(0, 'resmon-mmon', 'Alias' = "resmon-mmon") {
                parameter 'PatternMatch' = "mmonLog";
            }
{% for (let cpu in fs.lsdir("/sys/devices/system/cpu/")) : -%}
{% if (match(cpu, regexp("^cpu[0-9]+$")) != null): %}
{% let core_id = match(cpu, regexp("^cpu([0-9]+)$"))[1]; %}
            instance add(0, 'cmon-cpu{{ core_id }}', 'Alias' = "cmon-cpu{{ core_id }}") {
                parameter 'PatternMatch' = "Logcpu{{ core_id }}";
            }
{% endif %}
{% endfor -%}
        }
        object 'Action' {
            instance add(0, 'resmon-mmon', 'Alias' = "resmon-mmon") {
                parameter 'SourceRef' = "Device.Syslog.Source.[Alias == \"system\"],Device.Syslog.Source.[Alias == \"kernel\"],Device.Syslog.Source.[Alias == \"localhost\"]";
                parameter 'FilterRef' = "Device.Syslog.Filter.[Alias == \"resmon-mmon\"]";
                parameter 'TemplateRef' = "Device.Syslog.Template.[Alias == \"default_template\"]";
                object 'LogFile' {
                    parameter 'Enable' = false;
                    parameter 'FilePath' = "file://${log-dir}/resmon-memory.log";
                }
            }
{% for (let cpu in fs.lsdir("/sys/devices/system/cpu/")) : -%}
{% if (match(cpu, regexp("^cpu[0-9]+$")) != null): %}
{% let core_id = match(cpu, regexp("^cpu([0-9]+)$"))[1]; %}
            instance add(0, 'cmon-cpu{{ core_id }}', 'Alias' = "cmon-cpu{{ core_id }}") {
                parameter 'SourceRef' = "Device.Syslog.Source.[Alias == \"system\"],Device.Syslog.Source.[Alias == \"kernel\"],Device.Syslog.Source.[Alias == \"localhost\"]";
                parameter 'FilterRef' = "Device.Syslog.Filter.[Alias == \"cmon-cpu{{ core_id }}\"]";
                parameter 'TemplateRef' = "Device.Syslog.Template.[Alias == \"default_template\"]";
                object 'LogFile' {
                    parameter 'Enable' = false;
                    parameter 'FilePath' = "file://${log-dir}/resmon-cpu{{ core_id }}.log";
                }
            }
{% endif %}
{% endfor -%}
        }
    }
}
