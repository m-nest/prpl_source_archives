/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

#define ME "tmp_dev"

static int scan_callback(const char* name, void* priv) {
    int rv = 1;
    tempsensor_info_t* tempsensor_info = (tempsensor_info_t*) priv;

    when_null(tempsensor_info, exit);
    when_str_empty(name, exit);

    free(tempsensor_info->hwmon_complete_sensor_path);
    tempsensor_info->hwmon_complete_sensor_path = strdup(name);
    rv = 0;
exit:
    return rv;
}

bool tempsensor_device_exists(tempsensor_info_t* tempsensor_info) {
    SAH_TRACEZ_IN(ME);
    bool retval = false;
    struct stat s_dev = {0};
    amxc_string_t filter;

    amxc_string_init(&filter, 0);

    when_null(tempsensor_info, exit);

    if(tempsensor_info->hwmon_dev) {
        when_str_empty_trace(tempsensor_info->name, exit, ERROR, "Path of the hwmon sensor empty in structure");
        amxc_string_setf(&filter, "d_type == DT_REG && d_name matches '%s'", tempsensor_info->hwmon_name);
        amxp_dir_scan(tempsensor_info->name, amxc_string_get(&filter, 0), true, scan_callback, (void*) tempsensor_info);

        if(!str_empty(tempsensor_info->hwmon_complete_sensor_path)) {
            retval = true;
        }
    } else {
        when_str_empty_trace(tempsensor_info->name, exit, ERROR, "Path of the sensor empty in structure");
        if(stat(tempsensor_info->name, &s_dev) == 0) {
            retval = true;
        }
    }

exit:
    amxc_string_clean(&filter);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

int32_t probe_tempsensor(tempsensor_info_t* tempsensor_info) {
    SAH_TRACEZ_IN(ME);
    int32_t temp = 0;
    amxc_string_t sensor_path;
    FILE* temp_file = NULL;
    int matched_val = 0;
    int32_t scaling_parameter = 1;

    amxc_string_init(&sensor_path, 0);

    temp = get_bad_temp();

    when_null(tempsensor_info, exit);
    temp *= tempsensor_info->scaling_parameter;
    scaling_parameter = tempsensor_info->scaling_parameter;

    if(tempsensor_info->hwmon_dev) {
        when_str_empty_trace(tempsensor_info->hwmon_complete_sensor_path, exit, ERROR, "Could not read hwmon temp sensor value");
        amxc_string_setf(&sensor_path, "%s", tempsensor_info->hwmon_complete_sensor_path);
    } else {
        when_str_empty_trace(tempsensor_info->name, exit, ERROR, "Could not read temp sensor value");
        amxc_string_setf(&sensor_path, "%s/%s", tempsensor_info->name, TEMP_VAL);
    }

    temp_file = fopen(amxc_string_get(&sensor_path, 0), "r");
    if(temp_file == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to open temperature file of %s. Err message: %s", tempsensor_info->name, strerror(errno));
        goto exit;
    }

    matched_val = fscanf(temp_file, "%d", &temp);

    if(matched_val < 1) {
        SAH_TRACEZ_INFO(ME, "No temperature value could be read");
    }
    fclose(temp_file);
exit:
    amxc_string_clean(&sensor_path);
    SAH_TRACEZ_OUT(ME);
    return temp / scaling_parameter;
}
