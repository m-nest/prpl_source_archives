/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_qos_queue.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_qos_queue_new_delete),
        cmocka_unit_test(test_qos_queue_init_deinit),
        cmocka_unit_test(test_dm_qos_queue_evt_instance_added),
        cmocka_unit_test(test_dm_qos_queue_evt_instance_changed),
        cmocka_unit_test(test_dm_qos_queue_action_on_read),
        cmocka_unit_test(test_dm_qos_queue_action_on_destroy),
        cmocka_unit_test(test_qos_queue_get_dm_object),
        cmocka_unit_test(test_qos_queue_dm_get_enable),
        cmocka_unit_test(test_qos_queue_dm_set_enable),
        cmocka_unit_test(test_qos_queue_dm_get_set_status),
        cmocka_unit_test(test_qos_queue_dm_get_alias),
        cmocka_unit_test(test_qos_queue_dm_get_set_drop_algorithm),
        cmocka_unit_test(test_qos_queue_dm_get_precedence),
        cmocka_unit_test(test_qos_queue_dm_get_traffic_classes),
        cmocka_unit_test(test_qos_queue_dm_get_interface),
        cmocka_unit_test(test_qos_queue_dm_get_all_interfaces),
        cmocka_unit_test(test_qos_queue_dm_get_hardware_assisted),
        cmocka_unit_test(test_qos_queue_dm_get_buffer_length),
        cmocka_unit_test(test_qos_queue_dm_get_weight),
        cmocka_unit_test(test_qos_queue_dm_get_red_threshold),
        cmocka_unit_test(test_qos_queue_dm_get_red_percentage),
        cmocka_unit_test(test_qos_queue_dm_get_scheduler_algorithm),
        cmocka_unit_test(test_qos_queue_dm_get_shaping_rate),
        cmocka_unit_test(test_qos_queue_dm_get_assured_rate),
        cmocka_unit_test(test_qos_queue_dm_get_shaping_burst_size),
        cmocka_unit_test(test_qos_queue_interface_netdevname_changed),
        cmocka_unit_test(test_qos_queue_update_stats),
        cmocka_unit_test(test_qos_queue_activate),
        cmocka_unit_test(test_qos_queue_deactivate),
        cmocka_unit_test(test_qos_queue_asked),

    };
    return cmocka_run_group_tests(tests, test_qos_queue_setup, test_qos_queue_teardown);
}
