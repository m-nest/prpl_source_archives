/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>

#include "mock_dhcp.h"

static const char* const mock_dhcp_odl = "../common/mock_dhcpclient_dm.odl";

int32_t mock_dhcp4_client_1_expected_toggles = 0;
int32_t mock_dhcp6_client_1_expected_toggles = 0;

static bool is_rising_flank_bool_param_change(amxc_var_t* param) {
    return !GET_BOOL(param, "from") && GET_BOOL(param, "to");
}

void _mock_dhcp_client_enable_count_toggles(UNUSED const char* const sig_name,
                                            const amxc_var_t* const data,
                                            UNUSED void* const priv) {
    int32_t* counter = NULL;
    const char* path = GET_CHAR(data, "path");
    assert_non_null(path);

    amxc_var_t* param = GETP_ARG(data, "parameters.Enable");
    assert_non_null(param);
    if(!is_rising_flank_bool_param_change(param)) {
        return;
    }

    if(strcmp(path, "DHCPv4Client.Client.1.") == 0) {
        counter = &mock_dhcp4_client_1_expected_toggles;
    } else if(strcmp(path, "DHCPv6Client.Client.1.") == 0) {
        counter = &mock_dhcp6_client_1_expected_toggles;
    } else {
        return;
    }
    if((*counter) <= 0) {
        fail_msg("Fail: %sEnable was toggled without expect", path);
    }
    (*counter)--;
}

void mock_dhcp_expect_dhcpv4_toggles(uint32_t times) {
    mock_dhcp4_client_1_expected_toggles = times;
}

void mock_dhcp_expect_dhcpv6_toggles(uint32_t times) {
    mock_dhcp6_client_1_expected_toggles = times;
}

void mock_dhcp_all_expectations_succeeded(void) {
    assert_int_equal(mock_dhcp4_client_1_expected_toggles, 0);
    assert_int_equal(mock_dhcp6_client_1_expected_toggles, 0);
}

void mock_dhcp_setup(void) {
    mock_dhcp4_client_1_expected_toggles = 0;
    mock_dhcp6_client_1_expected_toggles = 0;

    amxut_resolve_function("mock_dhcp_client_enable_count_toggles", _mock_dhcp_client_enable_count_toggles);

    amxut_dm_load_odl(mock_dhcp_odl);
}

void mock_dhcp_teardown(void) {
    mock_dhcp_all_expectations_succeeded();
}
