/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "sfpmgr_main.h"

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param_value() */
#include <amxm/amxm.h>                  /* amxm_shared_object_t */
#include <amxp/amxp_timer.h>

/* Own headers */
#include "dm_sfp_db.h" /* dm_sfp_db_init() */
#include "sfpmgr.h"    /* sfpmgr_poll_sfp() */

static amxp_timer_t* s_diagpoll_timer = NULL;
static sfp_app_t app;
amxm_shared_object_t* so_load_controllers_discovery = NULL;
static amxm_shared_object_t* s_default_mod_sfp_type_so = NULL;

/**
 * @brief Retrieves the `dm` (data manager) associated with the application.
 *
 * This function returns the `dm` pointer from the `app` structure. The `dm`
 * represents the data manager, which is typically used to manage or store
 * application-specific data. This function provides access to the `dm`
 * object, which can be used by other parts of the application.
 *
 * @return A pointer to the `amxd_dm_t` structure representing the data manager.
 *         The returned pointer is the same as stored in the `app` structure.
 *         It is the caller's responsibility to ensure that `app.dm` is valid
 *         before using the returned pointer.
 */
amxd_dm_t* sfp_get_dm(void) {
    return app.dm;
}

amxo_parser_t* sfp_get_parser(void) {
    return app.parser;
}

bool sfp_mods_are_loaded(void) {
    return app.mods_are_loaded;
}

void sfp_set_dm_parser(amxd_dm_t* dm, amxo_parser_t* parser) {
    app.dm = dm;
    app.parser = parser;
}



/**
 * @brief Starts the SFP diagnostics polling timer.
 *
 * Creates and starts a timer that periodically checks the presence of SFP modules.
 * Logs an error and exits with a failure status if the timer creation or start fails.
 *
 * @return int 0 on success, non-zero error code on failure.
 */
static int sfpmgr_diagpoll_start_timer (void) {
    int rv = -1;

    /* Diagnostics polling check */
    rv = amxp_timer_new(&s_diagpoll_timer, sfpmgr_poll_sfp, NULL);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to create diagpoll timer: rv = %d", rv);
        goto exit;  // Jump to exit label on failure
    }
    amxp_timer_set_interval(s_diagpoll_timer, 2000);
    rv = amxp_timer_start(s_diagpoll_timer, 100);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start diagpoll timer: rv = %d", rv);
        goto exit;  // Jump to exit label on failure
    }

exit:
    return rv;
}

/**
 * @brief Loads SFPs controller.
 *
 * @return int 0 on success, non-zero on failure.
 */
static int sfpmgr_load_controllers(void) {
    int rv = -1;
    amxd_object_t* sfps_obj = amxd_dm_findf(app.dm, SFPS_PATH);
    const amxc_var_t* controllers = amxd_object_get_param_value(sfps_obj,
                                                                "SupportedControllers");
    amxc_var_t lcontrollers;
    amxm_shared_object_t* so = NULL;
    amxc_string_t mod_path;

    amxc_var_init(&lcontrollers);
    amxc_string_init(&mod_path, 0);
    app.mods_are_loaded = false;

    when_null_trace(controllers, exit, ERROR, "SupportedControllers not found");
    when_null_trace(app.parser, exit, ERROR, "Parser not initialized");

    const char* const mod_dir = GETP_CHAR(&app.parser->config, "tr181-sfp.mod-dir");
    const char* const external_mod_dir = GETP_CHAR(&app.parser->config,
                                                   "tr181-sfp.external-mod-dir");
    when_null_trace(external_mod_dir, load_default, ERROR, "external-mod-dir is NULL");

    amxc_var_convert(&lcontrollers, controllers, AMXC_VAR_ID_LIST);
    amxc_var_for_each(controller, &lcontrollers) {
        const char* name = GET_CHAR(controller, NULL);
        amxc_string_setf(&mod_path, "%s/%s.so", external_mod_dir, name);
        SAH_TRACEZ_INFO(ME, "Loading controller '%s' (file = %s)", name, amxc_string_get(&mod_path, 0));
        rv = amxm_so_open(&so, name, amxc_string_get(&mod_path, 0));
        SAH_TRACEZ_INFO(ME, "Loading controller '%s' %s", name, rv ? "failed" : "successful");
        when_failed_trace(rv, load_default, ERROR, "Failed to load controller %s, default module will be used", name);
        app.mods_are_loaded = true;
    }

    when_true(app.mods_are_loaded, exit);

load_default:
    app.mods_are_loaded = false;
    when_null_trace(mod_dir, exit, ERROR, "mod-dir is NULL");
    amxc_string_setf(&mod_path, "%s/%s.so", mod_dir, DEFAULT_MOD_SFP_TYPE_NAME);
    SAH_TRACEZ_INFO(ME, "Loading controller '%s' (file = %s)",
                    DEFAULT_MOD_SFP_TYPE_NAME,
                    amxc_string_get(&mod_path, 0));
    rv = amxm_so_open(&s_default_mod_sfp_type_so, DEFAULT_MOD_SFP_TYPE_NAME,
                      amxc_string_get(&mod_path, 0));
    when_failed_trace(rv, exit, ERROR, "Failed to load default module, tr181-sfp will not be started");

exit:
    amxc_string_clean(&mod_path);
    amxc_var_clean(&lcontrollers);
    return rv;
}

static void sfpmgr_close_controllers(void) {
    if(s_default_mod_sfp_type_so) {
        amxm_so_close(&s_default_mod_sfp_type_so);
    }
}

/**
 * Handle the 'app:start' event.
 *
 * The Ambiorix run-time sends the 'app:start' event after calling all entry
 * points. The function determines the number of SFP cages by reading
 * SFPs.SFPCageNumberOfEntries. If tr181-sfp reads that value before it receives
 * the app:start event, SFPs.SFPCageNumberOfEntries is still 0 while there is
 * already an SFPCage instance.
 */
void sfpmgr_app_start_received(void) {

    int rc;

    rc = discover_cages();
    when_failed(rc, exit);
    when_true_trace(0 == get_max_cage(), exit, WARNING, "No cages found");

    rc = sfpmgr_diagpoll_start_timer();
    when_failed(rc, exit);

exit:
    return;
}

/**
 * @brief Main function for managing SFP operations.
 *
 * Handles the start and stop operations of the SFP manager, initializing resources,
 * loading the ODL file, configuring the manager, and managing timers for SFP checks.
 * Starts or stops the SFP manager based on the provided reason.
 *
 * @param reason The action to perform: `START` or `STOP`.
 * @param dm A pointer to the data model used by the SFP manager.
 * @param parser A pointer to the parser for loading configuration.
 *
 * @return int 0 on success, error code on failure.
 */
int _sfpmgr_main(int reason,
                 amxd_dm_t* dm,
                 amxo_parser_t* parser) {
    int retval = -1;

    if((dm == NULL) || (parser == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Arguments are NULL");
        goto exit;  /* Jump to exit label on failure */
    }

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_INFO(ME, "START event received");
        sfp_set_dm_parser(dm, parser);
        retval = sfpmgr_load_controllers();
        when_failed(retval, exit);
        dm_sfp_db_init(dm);
        break;

    case AMXO_STOP:
        SAH_TRACEZ_INFO(ME, "STOP event received");
        discovery_stop();
        free_cage();
        amxp_timer_delete(&s_diagpoll_timer);
        sfpmgr_close_controllers();
        dm_sfp_db_cleanup();
        app.dm = NULL;
        app.parser = NULL;
        retval = 0;
        break;
    default:
        break;
    }

exit:
    return retval;
}

