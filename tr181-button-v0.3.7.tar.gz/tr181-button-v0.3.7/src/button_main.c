/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "button.h"
#include "dm_button.h"

typedef struct _tr181_button {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
} tr181_button_t;

static tr181_button_t app;

amxd_dm_t* button_get_dm(void) {
    return app.dm;
}

amxo_parser_t* button_get_parser(void) {
    return app.parser;
}

amxc_var_t* button_get_config(void) {
    amxo_parser_t* parser = button_get_parser();
    return parser != NULL ? &(parser->config) : NULL;
}

amxd_object_t* button_get_object(const char* path) {
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(button_get_dm(), "%s", path);
exit:
    return object;
}

const char* button_get_gpio_keys_path(void) {
    amxc_var_t* setting = amxo_parser_get_config(button_get_parser(), "button_dts_gpio_keys_path");
    return amxc_var_constcast(cstring_t, setting);
}

int button_deinit_all(void) {
    int retval = 0;
    SAH_TRACEZ_INFO(ME, "Stopping Button devices");
    amxd_object_for_each(instance, it, button_get_object(BUTTON_TR181_PATH)) {
        retval |= button_device_clean(amxc_llist_it_get_data(it, amxd_object_t, it));
    }
    return retval;
}

int button_init_all(void) {
    int retval = 0;
    SAH_TRACEZ_INFO(ME, "Initializing Button devices");
    amxd_object_for_each(instance, it, button_get_object(BUTTON_TR181_PATH)) {
        retval |= button_device_init(amxc_llist_it_get_data(it, amxd_object_t, it));
    }
    return retval;
}

static int button_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    app.dm = dm;
    app.parser = parser;
    return 0;
}

static int button_cleanup(void) {
    int retval = button_deinit_all();
    app.dm = NULL;
    app.parser = NULL;
    return retval;
}

int _button_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 0;

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "Starting tr181-button plugin");
        retval = button_init(dm, parser);
        break;
    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "Stopping tr181-button plugin");
        retval = button_cleanup();
        break;
    }
    return retval;
}
