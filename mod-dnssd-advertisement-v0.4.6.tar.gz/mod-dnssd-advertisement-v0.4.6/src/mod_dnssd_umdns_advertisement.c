/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <yajl/yajl_gen.h>

#include <amxc/amxc.h>
#include <amxp/amxp_subproc.h>
#include <amxj/amxj_variant.h>

#include "mod_umdns_advertisement.h"
#define ME "dnssd-umdns-advertisement"

/**
 * @brief
 * Parse the service data to a compatible json variant.
 *
 * @param data data to fill for the json parser
 * @param service Variant with the service data.
 * @return int The number of text entries.
 */
static bool fill_service_data(amxc_var_t* data, amxc_var_t* service) {
    int nb_txt_entries = 0;
    amxc_string_t service_entry;
    amxc_var_t* service_htable = NULL;
    amxc_var_t* txt_htable = NULL;
    amxc_var_t* text_entries = NULL;
    amxc_var_t* tmp = NULL;
    const char* inst_name = NULL;
    const char* app_proto = NULL;
    const char* trans_proto = NULL;

    amxc_string_init(&service_entry, 0);

    when_null_trace(service, exit, ERROR, "No advertise service given.");
    when_null_trace(data, exit, ERROR, "No data to fill given.");

    inst_name = GET_CHAR(service, "InstanceName");
    when_str_empty_trace(inst_name, exit, ERROR, "No instance name given.");
    app_proto = GET_CHAR(service, "ApplicationProtocol");
    when_null_trace(app_proto, exit, ERROR, "No application protocol given.");
    trans_proto = GET_CHAR(service, "TransportProtocol");
    when_null_trace(trans_proto, exit, ERROR, "No transport protocol given.");


    service_htable = amxc_var_add_key(amxc_htable_t, data, inst_name, NULL);

    amxc_string_appendf(&service_entry,
                        "_%s.%s.local",
                        app_proto,
                        strncmp(trans_proto, "TCP", 3) == 0 ? "_tcp" : "_udp");
    tmp = amxc_var_add_new_key(service_htable, "service");
    amxc_var_push(cstring_t, tmp, amxc_string_take_buffer(&service_entry));
    amxc_var_add_key(uint16_t, service_htable, "port", GET_UINT32(service, "Port"));

    txt_htable = amxc_var_add_key(amxc_llist_t, service_htable, "txt", NULL);
    text_entries = GET_ARG(service, "TextRecord");
    amxc_var_for_each(text_entry, text_entries) {
        nb_txt_entries++;
        const char* key = GET_CHAR(text_entry, "Key");
        const char* value = GET_CHAR(text_entry, "Value");
        amxc_string_t text;

        amxc_string_init(&text, 0);
        amxc_string_setf(&text, "%s=%s", key, value);
        tmp = amxc_var_add_new(txt_htable);
        amxc_var_push(cstring_t, tmp, amxc_string_take_buffer(&text));

        amxc_string_clean(&text);
    }
exit:
    amxc_string_clean(&service_entry);
    return nb_txt_entries;
}

static void restart_umdns(void) {
    amxc_var_t data;
    amxc_var_t ret;
    int status = 1;

    amxc_var_init(&data);
    amxc_var_init(&ret);

    status = amxm_execute_function("self",
                                   MOD_DM_MNGR,
                                   "restart-backend",
                                   &data,
                                   &ret);

    when_failed_trace(status, exit, ERROR, "Could not restart the umdns %d.", status);
exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return;
}

/**
 * @brief
 * Add a service to advertise by umdns.
 *
 * @param function_name Name of the function called.
 * @param args list of listening interfaces Alias.
 * @param ret Return variant.
 * @return int 0 on success.
 */
int umdns_add_advertisement_service(amxc_var_t* args) {
    int fd = -1;
    int status = 1;
    const char* file_name = NULL;
    struct stat st = {0};
    amxc_var_t* service = NULL;
    variant_json_t* writer = NULL;
    amxc_var_t data;
    amxc_string_t file_path;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    amxc_string_init(&file_path, 0);

    when_null_trace(args, exit, ERROR, "No arguments given.");

    service = GET_ARG(args, "service");
    when_null_trace(service, exit, ERROR, "No service given.");
    file_name = GET_CHAR(args, "file_name");
    when_null_trace(file_name, exit, ERROR, "No file name given.");

    status = fill_service_data(&data, service) > 0 ? amxd_status_ok : amxd_status_unknown_error;
    when_failed_trace(status, exit, ERROR, "Service need at least one text entry to be updated.");

    amxc_string_setf(&file_path, "%s/%s.json", SERVICES_DIR, file_name);

    if(stat(SERVICES_DIR, &st) == -1) {
        mkdir(SERVICES_DIR, 0644);
    }
    fd = open(amxc_string_get(&file_path, 0), O_WRONLY | O_CREAT, 0644);
    when_false_trace(fd > 0, exit, ERROR, "Unable open json file.");

    status = amxj_writer_new(&writer, &data);
    when_failed_trace(status, exit, ERROR, "Unable to write the service data in json.");

    status = amxj_write(writer, fd) > 0 ? amxd_status_ok : amxd_status_unknown_error;
    when_failed_trace(status, exit, ERROR, "Unable to write the service data in file.");

    restart_umdns();
exit:
    if(writer != NULL) {
        amxj_writer_delete(&writer);
    }
    close(fd);
    amxc_string_clean(&file_path);
    amxc_var_clean(&data);
    return status;
}

/**
 * @brief
 * Delete a umdns advertised service
 *
 * @param args The file name of the advertised service
 * @return int 0 when the service is removed.
 */
int umdns_del_advertisement_service(amxc_var_t* args) {
    int status = 1;
    const char* file_name = NULL;
    amxc_string_t file_path;

    amxc_string_init(&file_path, 0);

    when_null_trace(args, exit, ERROR, "No arguments given.");

    file_name = GET_CHAR(args, NULL);
    when_null_trace(file_name, exit, ERROR, "No file name given.");

    amxc_string_setf(&file_path, "%s%s.json", SERVICES_DIR, file_name);

    status = remove(amxc_string_get(&file_path, 0));
    when_false_trace(status == 0, exit, ERROR, "Cannot remove file %s.", amxc_string_get(&file_path, 0));
    restart_umdns();
exit:
    amxc_string_clean(&file_path);
    return status;
}
