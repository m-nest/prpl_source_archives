/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>

#include "bulkdata.h"
#include "bulkdata_utils.h"
#include "bulkdata_profile_http_request_uri_parameter.h"

#define ME "request_uri_parameter"
#define MANUFACTURER_OUI "oui"
#define PRODUCT_CLASS "pc"
#define SERIAL_NUMBER "sn"

#define UNUSED __attribute__((unused))

static cstring_t bulkdata_get_request_uri_get_params(const cstring_t param) {
    cstring_t ret = NULL;
    const cstring_t object_path = "Device.DeviceInfo.";
    const cstring_t value = NULL;
    amxc_string_t reference;
    amxc_string_t param_var_path;
    amxb_bus_ctx_t* ctx = NULL;
    amxc_var_t var;

    amxc_string_init(&reference, 0);
    amxc_string_setf(&reference, "%s", object_path);
    amxc_string_init(&param_var_path, 0);
    amxc_string_setf(&param_var_path, "0.0.%s", param);
    amxc_var_init(&var);

    if(bulkdata_utils_device_prefix_check(object_path)) {
        bulkdata_utils_device_prefix_strip(&reference);
    }

    ctx = amxb_be_who_has(amxc_string_get(&reference, 0));
    when_null(ctx, exit);

    when_failed(amxb_get(ctx, amxc_string_get(&reference, 0), 0, &var, 3), exit);
    value = GETP_CHAR(&var, amxc_string_get(&param_var_path, 0));
    if(NULL != value) {
        ret = strdup(value);
    }

exit:
    amxc_string_clean(&reference);
    amxc_string_clean(&param_var_path);
    amxc_var_clean(&var);
    return ret;
}

static void bulkdata_get_request_uri_get_extra(amxd_object_t* request_uri_parameter, amxc_string_t* url, bool first_element) {

    amxd_object_t* uri_instance = NULL;
    amxc_var_t var;
    amxc_string_t reference_str;

    amxc_var_init(&var);
    amxc_string_init(&reference_str, 0);
    when_null(request_uri_parameter, exit);
    when_null(url, exit);

    amxd_object_for_each(instance, it, request_uri_parameter) {
        cstring_t name = NULL;
        cstring_t reference = NULL;
        cstring_t value = NULL;

        uri_instance = amxc_container_of(it, amxd_object_t, it);
        if(NULL == uri_instance) {
            continue;
        }

        name = amxd_object_get_value(cstring_t, uri_instance, "Name", NULL);
        when_null_trace(name, continue_foreach, ERROR, "Request URI param name is NULL");
        reference = amxd_object_get_value(cstring_t, uri_instance, "Reference", NULL);
        when_null_trace(reference, continue_foreach, ERROR, "Request URI param reference is NULL");


        amxc_string_setf(&reference_str, "%s", reference);
        if(bulkdata_utils_device_prefix_check(reference)) {
            bulkdata_utils_device_prefix_strip(&reference_str);
        }

        when_failed_trace(amxb_get(amxb_be_who_has(amxc_string_get(&reference_str, 0)), amxc_string_get(&reference_str, 0), 0, &var, 3), continue_foreach, ERROR, "Unable to get reference '%s' value", amxc_string_get(&reference_str, 0));
        value = amxc_var_dyncast(cstring_t, GETP_ARG(&var, "0.0.0"));
        when_null_trace(value, continue_foreach, ERROR, "Unable to get reference '%s' value", amxc_string_get(&reference_str, 0));

        SAH_TRACEZ_NOTICE(ME, "Will add '%s=%s' to the url", name, value);

        if(true == first_element) {
            amxc_string_appendf(url, "%s=%s", name, value);
            first_element = false;
        } else {
            amxc_string_appendf(url, "&%s=%s", name, value);
        }

continue_foreach:
        free(name);
        free(reference);
        free(value);
        continue;
    }

exit:
    amxc_var_clean(&var);
    amxc_string_clean(&reference_str);
    return;
}

amxd_object_t* bulkdata_get_request_uri_parameter_object(amxd_object_t* http) {
    cstring_t path = amxd_object_get_path(http, AMXD_OBJECT_NAMED);
    amxd_object_t* obj = amxd_dm_findf(bulkdata_get_dm(), "%s.RequestURIParameter.", path);
    free(path);
    return obj;
}

const cstring_t bulkdata_request_uri_parameter_get_name(amxd_object_t* request_uri_parameter) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(request_uri_parameter, "Name"));
}

const cstring_t bulkdata_request_uri_parameter_get_reference(amxd_object_t* request_uri_parameter) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(request_uri_parameter, "Reference"));
}

int bulkdata_request_uri_parameter_get_full_url(amxd_object_t* request_uri_parameter, amxc_string_t* url) {
    int ret = -1;
    cstring_t manufacturer_oui = NULL;
    cstring_t product_class = NULL;
    cstring_t serial_number = NULL;
    bool first_element = true;

    when_null(request_uri_parameter, exit);
    when_null(url, exit);

    manufacturer_oui = bulkdata_get_request_uri_get_params("ManufacturerOUI");
    product_class = bulkdata_get_request_uri_get_params("ProductClass");
    serial_number = bulkdata_get_request_uri_get_params("SerialNumber");

    amxc_string_append(url, "?", 1);

    if(NULL != manufacturer_oui) {
        amxc_string_appendf(url, "%s=%s", MANUFACTURER_OUI, manufacturer_oui);
        first_element = false;
    }

    if(NULL != product_class) {
        if(true == first_element) {
            amxc_string_appendf(url, "%s=%s", PRODUCT_CLASS, product_class);
            first_element = false;
        } else {
            amxc_string_appendf(url, "&%s=%s", PRODUCT_CLASS, product_class);
        }
    }

    if(NULL != serial_number) {
        if(true == first_element) {
            amxc_string_appendf(url, "%s=%s", SERIAL_NUMBER, serial_number);
            first_element = false;
        } else {
            amxc_string_appendf(url, "&%s=%s", SERIAL_NUMBER, serial_number);
        }
    }

    bulkdata_get_request_uri_get_extra(request_uri_parameter, url, first_element);

    SAH_TRACEZ_INFO(ME, "Full url is %s", amxc_string_get(url, 0));
    ret = 0;

exit:
    free(serial_number);
    free(product_class);
    free(manufacturer_oui);
    return ret;
}