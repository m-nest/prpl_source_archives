/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __TR181_UPNP_H__
#define __TR181_UPNP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/common_api.h>

#define string_empty(X) ((X == NULL) || (*X == '\0'))

extern bool upnpadvertise;

/**
 * @brief Main entry point handling start and stop reasons.
 *
 * This function handles different reasons for invocation, such as start and stop,
 * and calls the appropriate initialization or cleanup functions accordingly.
 *
 * @param reason The reason for invocation, typically AMXO_START or AMXO_STOP.
 * @param dm Pointer to the device management structure.
 * @param parser Pointer to the parser structure.
 * @return int Returns 0 on success or an error code on failure.
 *
 * @note The function logs the reason for invocation and delegates to `init` or `cleanup`.
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

/**
 * @brief Retrieves the device management structure.
 *
 * This function returns a pointer to the global or application-specific
 * device management structure (`amxd_dm_t`).
 *
 * @return amxd_dm_t* Pointer to the device management structure.
 */
amxd_dm_t* get_dm(void);

/**
 * @brief Retrieves the parser structure.
 *
 * This function returns a pointer to the global or application-specific
 * parser structure (`amxo_parser_t`).
 *
 * @return amxo_parser_t* Pointer to the parser structure.
 */
amxo_parser_t* get_parser(void);

/**
 * @brief Retrieves the configuration variable.
 *
 * This function returns a pointer to the configuration variable within the parser structure.
 * If the parser is NULL, it returns NULL.
 *
 * @return amxc_var_t* Pointer to the configuration variable, or NULL if parser is NULL.
 */
amxc_var_t* get_config(void);

/**
 * @brief Handles the IGD (Internet Gateway Device) change event.
 *
 * This function retrieves the IGD configuration, checks if the IGD is enabled,
 * and creates or destroys UPnP firewall rules accordingly. It also executes
 * the "igd-changed" function in the "upnp" module and logs an error if the execution fails.
 */
void igd_changed(void);

/**
 * @brief Initializes the UPnP module and optionally the UPnP advertise module.
 *
 * This function executes the "init" function in the "upnp" module and, if enabled,
 * also executes the "init" function in the "upnpadvertise" module. It logs warnings
 * if any of the function calls fail.
 */
void init_upnp_module(void);

/**
 * @brief Retrieves and sets the UPnP device capabilities.
 *
 * This function executes the "get_capabilities" function in the "upnp" module,
 * retrieves the capabilities into a hash table, and updates the "UPnP.Device.Capabilities."
 * object with these capabilities within a transaction.
 *
 * @note Logs warnings if the function execution or transaction application fails.
 */
void get_capabilities_upnp_module(void);

/**
 * @brief Destroys the UPnP PMP firewall rules.
 *
 * This function calls `destroy_upnp_firewall_rule` for both IPv4 and IPv6 PMP firewall rules.
 */
void destroy_upnp_pmp_firewall_rules(void);

/**
 * @brief Destroys the UPnP SSDP firewall rules.
 *
 * This function calls `destroy_upnp_firewall_rule` for both IPv4 and IPv6 SSDP firewall rules.
 */
void destroy_upnp_ssdp_firewall_rules(void);

/**
 * @brief Advertises devices via UPnP.
 *
 * This function checks if UPnP advertising is enabled, resolves device management values,
 * and iterates over the list of devices to add each as a root device for UPnP advertising.
 * It then starts the advertising process. Logs errors if adding a device fails.
 */
void advertise_device(void);


#ifdef __cplusplus
}
#endif

#endif // __TR181_UPNP_H__
