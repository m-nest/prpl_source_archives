/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#ifndef __USB_DM_H__
#define __USB_DM_H__

#ifdef __cplusplus
extern "C"
{
#endif

/***************************************************************************
* Datamodel functions
***************************************************************************/
/**
 * @brief RPC to Add USB device called from event2usb binary on system event.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _addDev(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief RPC to Delete USB device called from event2usb binary on system event.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _delDev(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief RPC to signal a USB device unbinding called from event2usb binary on system event.
 *        This is used when a device authorization changes.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _unbindDev(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief RPC to Eject USB device called from WEB UI.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _eject(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief RPC to Add USB Host called from event2usb binary on system event.
 *
 * @param obj Pointer to the AMXD object.
 * @param func Pointer to the AMXD function.
 * @param var1 Pointer to the first AMXC variable.
 * @param var2 Pointer to the second AMXC variable.
 * @return Status of the operation.
 */
amxd_status_t _addBus(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief RPC to Reset the Host Controller and apply the reset signaling to all of the Host Controller Hub downstream ports.
 *
 *
 * @param object The data model object.
 * @param func The function to be executed.
 * @param args The arguments for the function.
 * @param ret The return value.
 * @return amxd_status_t The status of the operation.
 */
amxd_status_t _Reset(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Called on event change on USB.USBHosts.Host.{i}.Reset.
 * When set to true, reset the Host Controller and apply the reset signaling
 * (see [Chapter 7.1.7.5/USB2.0]) to all of the Host Controller Hub downstream ports.
 *
 * @param sig_name Name of the signal.
 * @param data Pointer to the AMXC variable containing the data.
 * @param priv Pointer to private data.
 * @return Status of the operation.
 */
amxd_status_t _host_reset_changed(const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv);

/**
 * @brief Called when print_event events are enabled in the config.
 *
 * @param sig_name Name of the signal.
 * @param data Pointer to the AMXC variable containing the data.
 * @param priv Pointer to private data.
 */
void _print_event(const char* const sig_name,
                  const amxc_var_t* const data,
                  void* const priv);

/**
 * @brief Called when a USB port is added.
 *
 * This function is triggered when a new USB port is detected and added to the system.
 *
 * @param sig_name Name of the signal.
 * @param data Pointer to the AMXC variable containing the data.
 * @param priv Pointer to private data.
 */
void _usb_port_added(const char* const sig_name,
                     const amxc_var_t* const data,
                     void* const priv);

/**
 * @brief Initialize power management for a USB port object.
 *
 * This function sets up power management features for the specified USB port object.
 * @param object Pointer to the USB port AMXD object.
 */
void usb_port_pwr_init(amxd_object_t* object);

/**
 * @brief Initialize power management for all saved USB port objects in the data model.
 *
 * This function iterates through all existing USB port objects in the data model and initializes
 * their power management settings.
 */
void dm_usb_ports_pwr_init(void);

#ifdef __cplusplus
}
#endif

#endif // __USB_DM_H__
