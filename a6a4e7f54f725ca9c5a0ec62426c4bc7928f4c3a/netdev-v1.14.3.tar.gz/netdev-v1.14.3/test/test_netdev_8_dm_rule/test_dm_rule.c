/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxo/amxo_mibs.h>

#include <arpa/inet.h>
#include <linux/rtnetlink.h>

#include "netdev_netlink.h"
#include "dm_netdev.h"
#include "dm_convert.h"
#include "../common/test_netdev_common_setup.h"
#include "../common/common_functions.h"
#include "dm_rule.h"
#include "test_dm_rule.h"

//ip rule add from 80.80.80.0/24 to 9.9.9.0/24 iif br-guest oif eth1 ipproto udp sport 777-788 dport 666-677 lookup main
static const char* ip_rule_add_raw = "\x80\x00\x00\x00\x20\x00\x00\x00\xb7\xc8\xda\x67\x15\x34\x40\xe0\x02\x18\x18\x00\xfe\x00\x00\x00\x00\x00\x00\x00\x08\x00\x0f\x00\xfe\x00\x00\x00\x08\x00\x0e\x00\xff\xff\xff\xff\x05\x00\x15\x00\x00\x00\x00\x00\x0d\x00\x03\x00\x62\x72\x2d\x67\x75\x65\x73\x74\x00\x00\x00\x00\x09\x00\x11\x00\x65\x74\x68\x31\x00\x00\x00\x00\x08\x00\x06\x00\xfb\x7f\x00\x00\x08\x00\x17\x00\x09\x03\x14\x03\x08\x00\x18\x00\x9a\x02\xa5\x02\x05\x00\x16\x00\x11\x00\x00\x00\x08\x00\x01\x00\x09\x09\x09\x00\x08\x00\x02\x00\x50\x50\x50\x00";

//ip rule del from 80.80.80.0/24 to 9.9.9.0/24 iif br-guest oif eth1 ipproto udp sport 777-788 dport 666-677 lookup main
static const char* ip_rule_del_raw = "\x80\x00\x00\x00\x21\x00\x00\x00\xfa\xcd\xda\x67\x15\x34\x00\x13\x02\x18\x18\x00\xfe\x00\x00\x00\x00\x00\x00\x00\x08\x00\x0f\x00\xfe\x00\x00\x00\x08\x00\x0e\x00\xff\xff\xff\xff\x05\x00\x15\x00\x00\x00\x00\x00\x0d\x00\x03\x00\x62\x72\x2d\x67\x75\x65\x73\x74\x00\x00\x00\x00\x09\x00\x11\x00\x65\x74\x68\x31\x00\x00\x00\x00\x08\x00\x06\x00\xfb\x7f\x00\x00\x08\x00\x17\x00\x09\x03\x14\x03\x08\x00\x18\x00\x9a\x02\xa5\x02\x05\x00\x16\x00\x11\x00\x00\x00\x08\x00\x01\x00\x09\x09\x09\x00\x08\x00\x02\x00\x50\x50\x50\x00";

static rule_t* add_test_rule(void) {
    rtnlmsg_t* msg = rtnlmsg_instance();
    rule_t ws;
    rule_t* rule = NULL;
    amxd_object_t* rule_obj = NULL;

    //Message coming from "ip a add 192.168.100.1/24 dev dummy100"
    msg->nlmsg = (struct nlmsghdr*) ip_rule_add_raw;
    msg->buflen = 8192;
    msg->hdrlen = 12;

    // Make sure the rules does not yet exist
    assert_int_equal(msg2rule(&ws, msg), 0);
    rule = rule_find(&ws);
    assert_null(rule);

    // Call handler to add the rules
    assert_int_equal(handle_new_rule(msg), 0);
    handle_events();

    rule = rule_find(&ws);
    assert_non_null(rule);
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", rule->dyn_index);
    assert_non_null(rule_obj);

    return rule;
}

int test_netdev_setup(void** state) {
    test_netdev_common_setup(state, false);
    assert_int_equal(0, amxo_parser_scan_mib_dir(test_setup_parser(), "../../mibs"));
    _netdev_main(AMXO_START, test_setup_dm(), test_setup_parser());
    handle_events();

    return 0;
}

int test_netdev_teardown(void** state) {
    _netdev_main(AMXO_STOP, test_setup_dm(), test_setup_parser());
    handle_events();
    test_netdev_common_teardown(state);
    return 0;
}

void test_init_rule_table_converter(UNUSED void** state) {
    converter_t* test_converter = init_rule_table_converter();
    assert_non_null(test_converter);

    assert_string_equal(convert_bin2str(test_converter, RT_TABLE_UNSPEC), "unspec");
    assert_string_equal(convert_bin2str(test_converter, RT_TABLE_DEFAULT), "default");
    assert_string_equal(convert_bin2str(test_converter, RT_TABLE_MAIN), "main");
    assert_string_equal(convert_bin2str(test_converter, RT_TABLE_LOCAL), "local");

    // Any other bin value should return the bin value as a string (since no default is set)
    assert_string_equal(convert_bin2str(test_converter, 99), "99");
    assert_string_equal(convert_bin2str(test_converter, 35), "35");

    converter_destroy(&test_converter);

    // Make sure that an empty string is returned in case the converter is destroyed
    assert_string_equal(convert_bin2str(test_converter, RT_TABLE_MAIN), "");
}

/*
 * Test the rule copy function
 * Expectations:
 *  - When providing invalid input the function should return -1
 *  - When valid inputs are provided the destination rule should be a copy of the source*
 *      * with exception of index, dyn_index and object
 */
void test_rule_copy(UNUSED void** state) {
    rule_t rule_src;
    rule_t rule_dst;

    memset(&rule_src, 0, sizeof(rule_t));
    memset(&rule_dst, 0, sizeof(rule_t));

    // Build up valid input
    rule_src.family = AF_INET;
    rule_src.dstlen = 24;
    rule_src.srclen = 24;
    rule_src.table = RT_TABLE_MAIN;
    memcpy(rule_src.dst, str2addr(AF_INET, "8.8.8.0", NULL), addrlen(AF_INET));
    memcpy(rule_src.src, str2addr(AF_INET, "192.168.1.0", NULL), addrlen(AF_INET));
    memcpy(rule_src.oif, "eth1", strlen("eth1") + 1);
    memcpy(rule_src.iif, "br-lan", strlen("br-lan") + 1);
    rule_src.ipproto = 17;
    rule_src.sport = 100;
    rule_src.sport_max = 250;
    rule_src.dport = 8000;
    rule_src.dport_max = 9000;
    rule_src.dyn_index = 5;
    rule_src.index = 3;

    // First provide invalid input
    assert_int_equal(rule_copy(&rule_dst, NULL), -1);
    assert_int_equal(rule_copy(NULL, &rule_src), -1);

    // Provide valid input
    assert_int_equal(rule_copy(&rule_dst, &rule_src), 0);

    // Check if copy was successful
    assert_int_equal(rule_dst.family, rule_src.family);
    assert_int_equal(rule_dst.srclen, rule_src.srclen);
    assert_int_equal(rule_dst.dstlen, rule_src.dstlen);
    assert_int_equal(rule_dst.table, rule_src.table);
    assert_int_equal(rule_dst.ipproto, rule_src.ipproto);
    assert_int_equal(rule_dst.sport, rule_src.sport);
    assert_int_equal(rule_dst.sport_max, rule_src.sport_max);
    assert_int_equal(rule_dst.dport, rule_src.dport);
    assert_int_equal(rule_dst.dport_max, rule_src.dport_max);
    assert_string_equal(addr2str(rule_dst.family, rule_dst.dst, false), addr2str(rule_src.family, rule_src.dst, false));
    assert_string_equal(addr2str(rule_dst.family, rule_dst.src, false), addr2str(rule_src.family, rule_src.src, false));
    assert_string_equal(rule_dst.oif, rule_src.oif);
    assert_string_equal(rule_dst.iif, rule_src.iif);
}

/*
 * Test the functions to create, find and destroy the rule structs
 * Expectations:
 *  - When a rule is created it should be active
 *  - When the correct information is provided it should be able be found
 *  - The found rule should contain the same information
 *  - When the rule_destroy is called it should be scheduled for deletion and no longer be able to be found
 */
void test_rule_struct_functions(UNUSED void** state) {
    rule_t* found_rule = NULL;
    rule_t* rule = rule_create();
    rule_t ws;

    memset(&ws, 0, sizeof(rule_t));
    assert_true(rule->active);

    // Build up valid input
    rule->family = AF_INET;
    rule->dstlen = 24;
    rule->srclen = 24;
    rule->table = RT_TABLE_MAIN;
    memcpy(rule->dst, str2addr(AF_INET, "8.8.8.0", NULL), addrlen(AF_INET));
    memcpy(rule->src, str2addr(AF_INET, "192.168.1.0", NULL), addrlen(AF_INET));
    memcpy(rule->oif, "eth1", strlen("eth1") + 1);
    memcpy(rule->iif, "br-lan", strlen("br-lan") + 1);
    rule->ipproto = 17;
    rule->sport = 100;
    rule->sport_max = 250;
    rule->dport = 8000;
    rule->dport_max = 9000;

    rule_copy(&ws, rule);

    rule->dyn_index = 10;
    rule->index = 3;

    found_rule = rule_find(NULL);
    assert_null(found_rule);
    found_rule = rule_find(&ws);
    assert_non_null(found_rule);

    assert_int_equal(found_rule->family, AF_INET);
    assert_int_equal(found_rule->dstlen, 24);
    assert_int_equal(found_rule->srclen, 24);
    assert_int_equal(found_rule->table, RT_TABLE_MAIN);
    assert_string_equal(found_rule->oif, "eth1");
    assert_string_equal(found_rule->iif, "br-lan");
    assert_int_equal(found_rule->ipproto, 17);
    assert_int_equal(found_rule->sport, 100);
    assert_int_equal(found_rule->sport_max, 250);
    assert_int_equal(found_rule->dport, 8000);
    assert_int_equal(found_rule->dport_max, 9000);
    assert_int_equal(found_rule->dyn_index, 10);
    assert_int_equal(found_rule->index, 3);
    assert_string_equal(addr2str(found_rule->family, found_rule->dst, false), "8.8.8.0");
    assert_string_equal(addr2str(found_rule->family, found_rule->src, false), "192.168.1.0");

    ws.family = AF_INET6;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.family = AF_INET;
    ws.dstlen = 23;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.dstlen = 24;
    ws.table = RT_TABLE_DEFAULT;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.table = RT_TABLE_MAIN;
    memcpy(ws.oif, "eth2", strlen("eth2") + 1);
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    memcpy(ws.oif, "eth1", strlen("eth1") + 1);
    memcpy(rule->dst, str2addr(AF_INET, "192.168.1.0", NULL), addrlen(AF_INET));
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    memcpy(rule->dst, str2addr(AF_INET, "8.8.8.0", NULL), addrlen(AF_INET));
    memcpy(rule->src, str2addr(AF_INET, "90.90.90.0", NULL), addrlen(AF_INET));
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    memcpy(rule->src, str2addr(AF_INET, "192.168.1.0", NULL), addrlen(AF_INET));
    ws.sport = 700;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.sport = 100;
    ws.sport_max = 300;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.sport_max = 250;
    ws.dport = 699;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.dport = 8000;
    ws.dport_max = 9999;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.dport_max = 9000;
    ws.ipproto = 6;
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    ws.ipproto = 17;
    found_rule = rule_find(&ws);
    assert_non_null(found_rule);

    rule_destroy(rule, false);
    assert_false(rule->active);
    found_rule = rule_find(&ws);
    assert_null(found_rule);

    handle_events();
}

/*
 * Make sure msg2rule can handle invalid inputs
 * Expectations:
 *  - Invalid inputs return a -1 instead of causing a valgrind error
 */
void test_msg2rule_invalid_input(UNUSED void** state) {
    rule_t rule;
    rtnlmsg_t* msg = rtnlmsg_instance();

    assert_int_equal(msg2rule(NULL, msg), -1);
    msg->nlmsg = NULL;
    assert_int_equal(msg2rule(&rule, msg), -1);
    msg = NULL;
    assert_int_equal(msg2rule(&rule, msg), -1);
}

/*
 * Make sure that netlink messages are converted to the rule structure correctly
 * The test message comes from calling:
 *  - "ip rule add from 80.80.80.0/24 to 9.9.9.0/24 iif br-guest oif eth1 ipproto udp sport 777-788 dport 666-677 lookup main"
 * Expectations:
 *  - All parameters present in the netlink msg are set in the rule struct
 */
void test_msg2rule(UNUSED void** state) {
    rule_t rule;
    rtnlmsg_t* msg = rtnlmsg_instance();

    //ip rule add from 80.80.80.0/24 to 9.9.9.0/24 iif br-guest oif eth1 ipproto udp sport 777-788 dport 666-677 lookup main
    msg->nlmsg = (struct nlmsghdr*) ip_rule_add_raw;
    msg->buflen = 8192;
    msg->hdrlen = 12;

    assert_int_equal(msg2rule(&rule, msg), 0);

    // parameters not set by the msg2rule should be 0
    assert_int_equal(rule.dyn_index, 0);
    assert_int_equal(rule.index, 0);

    // Other parameters
    assert_int_equal(rule.family, AF_INET);
    assert_int_equal(rule.dstlen, 24);
    assert_int_equal(rule.srclen, 24);
    assert_int_equal(rule.table, RT_TABLE_MAIN);
    assert_string_equal(rule.iif, "br-guest");
    assert_string_equal(rule.oif, "eth1");
    assert_int_equal(rule.sport, 777);
    assert_int_equal(rule.sport_max, 788);
    assert_int_equal(rule.dport, 666);
    assert_int_equal(rule.dport_max, 677);
    assert_int_equal(rule.ipproto, 17);

    assert_string_equal(addr2str(rule.family, rule.dst, false), "9.9.9.0");
    assert_string_equal(addr2str(rule.family, rule.src, false), "80.80.80.0");
}

/*
 * Start the mercy time and let it run out
 * Expectations:
 *  - After the timer runs out, the rule should be scheduled for removing
 */
void test_rule_expire_mercy(UNUSED void** state) {
    rule_t* rule = rule_create();
    assert_true(rule->active);
    amxp_timer_start(rule->mercytimer, 0);
    read_sig_alarm();
    assert_false(rule->active);
    handle_events();
}


/*
 * Make sure the translation from rule to transaction works properly
 * Expectations:
 *  - When provided with invalid inputs the function should fail
 *  - When provided with valid inputs the transactions should contain all values
 *      - When the converters are not initialized some values will be an empty string
 *      - When the converters are initialized the values should be correctly converted
 */

void test_create_transaction_from_rule(UNUSED void** state) {
    int rv = -1;
    rule_t* rule = rule_create();
    amxd_trans_t* trans = NULL;
    amxc_var_t* expected_data = NULL;

    // Build up valid rule
    rule->active = true;
    rule->family = AF_INET;
    rule->dstlen = 24;
    rule->srclen = 24;
    rule->table = RT_TABLE_MAIN;
    memcpy(rule->dst, str2addr(AF_INET, "8.8.8.0", NULL), addrlen(AF_INET));
    memcpy(rule->src, str2addr(AF_INET, "192.168.1.0", NULL), addrlen(AF_INET));
    memcpy(rule->oif, "eth1", strlen("eth1") + 1);
    memcpy(rule->iif, "br-lan", strlen("br-lan") + 1);
    rule->ipproto = 17;
    rule->sport = 100;
    rule->sport_max = 250;
    rule->dport = 8000;
    rule->dport_max = 9000;
    rule->dyn_index = 10;
    rule->index = 3;

    // Call with invalid input
    trans = create_transaction_from_rule(NULL, true);
    assert_null(trans);
    trans = create_transaction_from_rule(NULL, false);
    assert_null(trans);

    // Call with valid input
    expected_data = read_json_from_file("test_data/trans_new_rule_no_converters.json");
    trans = create_transaction_from_rule(rule, true);
    rv = validate_transaction(trans, "NetDev.Rule.", action_object_add_inst, expected_data);
    assert_int_equal(rv, 0);
    amxd_trans_delete(&trans);
    amxc_var_delete(&expected_data);

    expected_data = read_json_from_file("test_data/trans_write_rule_no_converters.json");
    trans = create_transaction_from_rule(rule, false);
    rv = validate_transaction(trans, "NetDev.Rule.dyn10.", action_object_write, expected_data);
    assert_int_equal(rv, 0);
    amxd_trans_delete(&trans);
    amxc_var_delete(&expected_data);

    rule_init_converters();

    expected_data = read_json_from_file("test_data/trans_new_rule.json");
    trans = create_transaction_from_rule(rule, true);
    rv = validate_transaction(trans, "NetDev.Rule.", action_object_add_inst, expected_data);
    assert_int_equal(rv, 0);
    amxd_trans_delete(&trans);
    amxc_var_delete(&expected_data);

    expected_data = read_json_from_file("test_data/trans_write_rule.json");
    trans = create_transaction_from_rule(rule, false);
    rv = validate_transaction(trans, "NetDev.Rule.dyn10.", action_object_write, expected_data);
    assert_int_equal(rv, 0);
    amxd_trans_delete(&trans);
    amxc_var_delete(&expected_data);

    rule_cleanup();
}

/*
 * Provide the handle_new_rule function with invalid input parameters
 * Expectations:
 *  - The function should return '-1' and no error should be reported by Valgrind
 */
void test_handle_new_rule_invalid_input(UNUSED void** state) {
    rtnlmsg_t* msg = rtnlmsg_instance();

    msg->nlmsg = NULL;
    assert_int_equal(handle_new_rule(msg), -1);
    msg = NULL;
    assert_int_equal(handle_new_rule(msg), -1);
}

/*
 * Provides the handle_new_rule with a valid scenario
 *  - The rule test data is coming from the rule created by manually addind rules in docker and storing the msg in this test
 * Expectations:
 *  - Before calling the handle_new_rule no matching rule should exist
 *  - handle_new_rule should return without issue
 *  - An active rule struct should be found directly after calling the handle_new_rule (no dm instance yet)
 *  - After handling the events
 *      - The rule struct should still be active
 *      - An rule instance should exist in the datamodel
 *      - The data should match
 *  - When calling the handle_new_rule for the second time (update message)
 *      - The rule struct should be updated
 *      - The existing dm instance should be updated
 *  - When calling rule_destroy with the option set to true
 *      - Right after calling:
 *          - The rule should become inactive
 *          - The rule should no longer be found by the rule_find function
 *          - The rule instance should remain in the DM
 *      - After handling the events:
 *          - The rule structure should no longer be accessed since it will be invalid
 *          - The rule instance should be removed from the DM
 */
void test_handle_new_rule(UNUSED void** state) {
    rtnlmsg_t* msg = rtnlmsg_instance();
    rule_t ws;
    rule_t* rule = NULL;
    amxd_object_t* rule_obj = NULL;
    int dyn_index = 0;
    amxc_var_t params;

    //Message coming from the rule generated by "ip r add 192.168.100.0/24 via 192.168.100.1 dev dummy100 mtu 1500"
    msg->nlmsg = (struct nlmsghdr*) ip_rule_add_raw;
    msg->buflen = 8192;
    msg->hdrlen = 12;

    // Make sure the rule does not yet exist
    assert_int_equal(msg2rule(&ws, msg), 0);
    rule = rule_find(&ws);
    assert_null(rule);

    // Call handler to add the new rules
    assert_int_equal(handle_new_rule(msg), 0);

    // The rule should exist as soon as the handler is called
    rule = rule_find(&ws);
    assert_non_null(rule);
    assert_true(rule->active);
    // Should not exist in the DM until events are handled
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", rule->dyn_index);
    assert_null(rule_obj);

    handle_events();
    rule = rule_find(&ws);
    assert_non_null(rule);
    assert_true(rule->active);
    dyn_index = rule->dyn_index;
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", rule->dyn_index);
    assert_non_null(rule_obj);

    assert_int_equal(rule->index, rule_obj->index);

    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    amxd_object_get_params(rule_obj, &params, amxd_dm_access_protected);

    assert_true(rule_obj == rule->object);

    assert_string_equal(GET_CHAR(&params, "Dst"), "9.9.9.0");
    assert_int_equal(GET_INT32(&params, "DstLen"), 24);
    assert_string_equal(GET_CHAR(&params, "Src"), "80.80.80.0");
    assert_int_equal(GET_INT32(&params, "SrcLen"), 24);
    assert_int_equal(GET_INT32(&params, "SourcePort"), 777);
    assert_int_equal(GET_INT32(&params, "SourcePortMax"), 788);
    assert_int_equal(GET_INT32(&params, "DestPort"), 666);
    assert_int_equal(GET_INT32(&params, "DestPortMax"), 677);
    assert_string_equal(GET_CHAR(&params, "SourceInterface"), "br-guest");
    assert_string_equal(GET_CHAR(&params, "DestInterface"), "eth1");
    assert_string_equal(GET_CHAR(&params, "Table"), "main");
    amxc_var_clean(&params);

    rule_destroy(rule, true);
    assert_false(rule->active);
    assert_null(rule->object);
    rule = rule_find(&ws);
    assert_null(rule);
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj); // Should only be removed from the datamodel after events are handled

    handle_events();

    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_null(rule_obj);
}

/*
 * Provide the handle_del_rule function with invalid input parameters
 * Expectations:
 *  - The function should return '-1' and no error should be reported by Valgrind
 */
void test_handle_del_rule_invalid_input(UNUSED void** state) {
    rtnlmsg_t* msg = rtnlmsg_instance();
    assert_int_equal(handle_del_rule(NULL), -1);
    msg->nlmsg = NULL;
    assert_int_equal(handle_del_rule(msg), -1);
}

/*
 * Make sure the delete handler does not schedule rules to be deleted that are already inactive
 * Expectations:
 *  - After calling the delete handler (expected to fail because no active rule could be found)
 *    - The instance should still exist in the DM
 *  - No mercy timer should be started so read_sig_alarm should timeout
 *    - The object value in the rule struct should NOT be set to NULL
 *    - The datamodel objects priv value should NOT be set to NULL
 *    - The instance should still be available in the DM
 *  - After handling the events
 *    - The object value in the rule struct should NOT be set to NULL
 *    - The datamodel objects priv value should NOT be set to NULL
 *    - The instance should still be available in the DM
 */
void test_handle_del_rule_inactive_rule(UNUSED void** state) {
    rtnlmsg_t* msg = rtnlmsg_instance();
    rule_t* test_rule = NULL;
    amxd_object_t* rule_obj = NULL;
    int dyn_index = 0;

    test_rule = add_test_rule();
    assert_non_null(test_rule);
    dyn_index = test_rule->dyn_index;

    test_rule->active = false;

    // Call the handler to remove the rule
    msg->nlmsg = (struct nlmsghdr*) ip_rule_del_raw;
    msg->buflen = 8192;
    msg->hdrlen = 12;
    assert_int_equal(handle_del_rule(msg), -1); // Should fail because no active rule was found
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj);
    assert_non_null(rule_obj->priv);
    assert_non_null(test_rule->object);

    read_sig_alarm(); // The timer should not be started so this should timeout
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj);
    assert_non_null(rule_obj->priv);
    assert_non_null(test_rule->object);

    handle_events();
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj);
    assert_non_null(rule_obj->priv);
    assert_non_null(test_rule->object);

    test_rule->active = true;
    rule_destroy(test_rule, true);
    handle_events();
}

/*
 * Make sure the rule delete messages are handled correctly
 * Expectations:
 *  - After calling the delete handler
 *    - The rule should still be active and should still be found by rule_find
 *    - The instance should still exist in the DM
 *  - After letting the mercytimer run out
 *    - The rule should go to inactive and no longer be able to be found by rule_find
 *    - The object value in the rule struct should be set to NULL
 *    - The datamodel objects priv value should be set to NULL
 *    - The instance should still be available in the DM
 *  - After handling the events, the instance should be removed from the dm
 */
void test_handle_del_rule(UNUSED void** state) {
    rtnlmsg_t* msg = rtnlmsg_instance();
    rule_t* rule = NULL;
    rule_t* test_rule = NULL;
    amxd_object_t* rule_obj = NULL;
    int dyn_index = 0;

    test_rule = add_test_rule();
    assert_non_null(test_rule);
    dyn_index = test_rule->dyn_index;

    // Call the handler to remove the rule
    msg->nlmsg = (struct nlmsghdr*) ip_rule_del_raw;
    msg->buflen = 8192;
    msg->hdrlen = 12;
    assert_int_equal(handle_del_rule(msg), 0);
    rule = rule_find(test_rule);
    assert_non_null(rule);
    assert_true(rule->active);
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj);
    assert_non_null(rule_obj->priv);

    read_sig_alarm(); // Let the mercytimer run out
    assert_false(rule->active);
    assert_null(rule->object);
    rule = rule_find(test_rule);
    assert_null(rule);
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_non_null(rule_obj);
    assert_null(rule_obj->priv);

    handle_events();
    rule_obj = amxd_dm_findf(test_setup_dm(), "NetDev.Rule.dyn%d", dyn_index);
    assert_null(rule_obj);
}

