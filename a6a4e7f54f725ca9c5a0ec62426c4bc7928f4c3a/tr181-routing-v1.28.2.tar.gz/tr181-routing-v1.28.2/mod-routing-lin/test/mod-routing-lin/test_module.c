/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb_types.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <debug/sahtrace.h>

#include "test_module.h"
#include "mod_routing_lin.h"

#define MOD_NAME "target_module"
#define MOD_PATH "../modules_under_test/" MOD_NAME ".so"

int test_setup(UNUSED void** state) {
    sahTraceOpen("test", TRACE_TYPE_STDERR);
    sahTraceSetLevel(TRACE_LEVEL_ERROR);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);
    return 0;
}

int test_teardown(UNUSED void** state) {
    sahTraceClose();
    amxm_close_all();
    return 0;
}

void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

void test_module_has_functions(UNUSED void** state) {
    assert_true(amxm_has_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route"));
    assert_true(amxm_has_function(MOD_NAME, MOD_ROUTING_CTRL, "remove-route"));
}

void test_add_ipv4_route(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* to_del = NULL;

    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    // Add static IPv4 route
    amxc_var_add_key(cstring_t, &args, "DestIPAddress", "80.80.80.7");
    amxc_var_add_key(cstring_t, &args, "DestSubnetMask", "255.255.255.0");
    amxc_var_add_key(cstring_t, &args, "GatewayIPAddress", "192.168.99.1");
    amxc_var_add_key(uint32_t, &args, "ID", 254);
    amxc_var_add_key(bool, &args, "IPVx", false);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Add route to specific IP address iso entire subnet
    to_del = amxc_var_take_key(&args, "DestSubnetMask");
    amxc_var_delete(&to_del);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Add default route (empty DestIPAddress and DestSubnetMask)
    to_del = amxc_var_take_key(&args, "DestIPAddress");
    amxc_var_delete(&to_del);

    amxc_var_add_key(cstring_t, &args, "DestIPAddress", "");
    amxc_var_add_key(cstring_t, &args, "DestSubnetMask", "");

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Route without GatewayIPAddress or Interface, should fail
    to_del = amxc_var_take_key(&args, "GatewayIPAddress");
    amxc_var_delete(&to_del);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), -1);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_add_ipv6_route(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* to_del = NULL;

    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    // Add static IPv4 route
    amxc_var_add_key(cstring_t, &args, "DestIPPrefix", "2a02:1802:94:4000::/60");
    amxc_var_add_key(cstring_t, &args, "interface_name", "lo");
    amxc_var_add_key(cstring_t, &args, "Type", "Blackhole");
    amxc_var_add_key(uint32_t, &args, "ID", 254);
    amxc_var_add_key(bool, &args, "IPVx", true);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Add default route
    amxc_var_set(cstring_t, amxc_var_get_key(&args, "DestIPPrefix", AMXC_VAR_FLAG_DEFAULT), "");
    amxc_var_set(cstring_t, amxc_var_get_key(&args, "interface_name", AMXC_VAR_FLAG_DEFAULT), "eth1");
    amxc_var_set(cstring_t, amxc_var_get_key(&args, "Type", AMXC_VAR_FLAG_DEFAULT), "Normal");

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Route without GatewayIPAddress or Interface, should fail
    to_del = amxc_var_take_key(&args, "interface_name");
    amxc_var_delete(&to_del);
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "add-route", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), -1);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_add_ip_rule(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* to_del = NULL;

    amxc_var_init(&ret);
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    // Add static IPv4 route
    amxc_var_add_key(cstring_t, &args, "iif", "br-lan");
    amxc_var_add_key(cstring_t, &args, "oif", "eth1");
    amxc_var_add_key(cstring_t, &args, "SourceIPPrefix", "192.168.1.0/24");
    amxc_var_add_key(cstring_t, &args, "DestIPPrefix", "80.80.80.0/24");
    amxc_var_add_key(uint32_t, &args, "ID", 254);
    amxc_var_add_key(uint32_t, &args, "SourcePort", 666);
    amxc_var_add_key(uint32_t, &args, "SourcePortRangeMax", 677);
    amxc_var_add_key(uint32_t, &args, "DestPort", 777);
    amxc_var_add_key(uint32_t, &args, "DestPortRangeMax", 788);
    amxc_var_add_key(uint32_t, &args, "Protocol", 17);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "set-policy", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    // Rule fails because SourcePortRangeMax < SourcePort
    amxc_var_set(uint32_t, amxc_var_get_key(&args, "SourcePortRangeMax", AMXC_VAR_FLAG_DEFAULT), 500);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "set-policy", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), -1);

    // Rule fails because DestIPPrefix is invalid
    amxc_var_set(cstring_t, amxc_var_get_key(&args, "DestIPPrefix", AMXC_VAR_FLAG_DEFAULT), "1234567890");
    to_del = amxc_var_take_key(&args, "SourcePortRangeMax");
    amxc_var_delete(&to_del);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "set-policy", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), -1);

    // Rule fails because Protocol is invalid
    to_del = amxc_var_take_key(&args, "DestIPPrefix");
    amxc_var_delete(&to_del);
    amxc_var_set(uint32_t, amxc_var_get_key(&args, "Protocol", AMXC_VAR_FLAG_DEFAULT), 500);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "set-policy", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), -1);

    // Rule succeeds
    to_del = amxc_var_take_key(&args, "Protocol");
    amxc_var_delete(&to_del);
    amxc_var_set(cstring_t, amxc_var_get_key(&args, "SourceIPPrefix", AMXC_VAR_FLAG_DEFAULT), "2001:db8:3333:4444:5555:6666:7777:8888");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ROUTING_CTRL, "set-policy", &args, &ret), 0);
    assert_int_equal(GET_INT32(&ret, NULL), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}
