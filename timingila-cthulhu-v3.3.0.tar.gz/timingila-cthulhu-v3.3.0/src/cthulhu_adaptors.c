/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>

#include <cthulhu/cthulhu_defines.h>
#include <timingila/timingila_defines.h>
#include <lcm/lcm_assert.h>

#include "timingila_cthulhu_priv.h"
#include "cthulhu_adaptors.h"

#define ADAPTER_BASE "Timingila.CthulhuAdapters"
#define ADAPTER_CMD_DEFAULT_FMT ADAPTER_BASE ".CthulhuCommandDefaults.%s"
#define ADAPTER_CMD_MAPPING ADAPTER_BASE ".CthulhuCommandMapping"
#define SRC_OBJ_PATH "SourceObjectPath"
#define ADAPTER_FN_OVERLOAD ADAPTER_BASE ".SoftwareModulesFuncArgsOverload"

#define PARAM_MAP_SRC_PATH_FMT "ParamMapping.[ DestinationParameter == \"%s\" ].SourceParameterPath"
#define PARAM_MAP_VALUE_TRANS_FMT "ParamMapping.[ DestinationParameter == \"%s\" ].ValueTransformation"
#define PARAM_MAP_VALUE_TRANS_ARG_FMT "ParamMapping.[ DestinationParameter == \"%s\" ].ValueTransformationParameters"
#define TABLE_OBJ_FMT ADAPTER_BASE ".SoftwareModulesTable.[ TableName  == \"%s\" && DestinationObject == \"%s\" ]."
#define GET_SRC_PARAM_FMT "[ TargetParameter == \"%s\" ].SourceParameter"
#define GET_VALUE_TRANS_FMT "[ TargetParameter == \"%s\" ].ValueTransformation"
#define VALIDATION_MAX_LENGTH "validate.check_maximum_length"

#define FN_PATH "FunctionPath"
#define ALIAS "Alias"
#define AMXB_CALL_TIMEOUT 5

#define ME "cthulhu"

#define BUFFER_MAX_SIZE 256
#define VALID_TRANS_FN(s) (s && strcmp(s, "none"))
static amxc_var_t* invert_bool_value(const amxc_var_t* src,
                                     UNUSED const char* fn_call, UNUSED const char* fn_params);

static amxc_var_t* convert_list_htable_to_param(const amxc_var_t* src,
                                                const char* fn_call, const char* fn_params);

/**
 * @brief List of supported transformation functions.
 *
 * This array maps transformation function names to their corresponding function pointers.
 * It is used to look up and execute transformation functions by name.
 *
 * Each entry consists of:
 *   - The name of the transformation function as a string.
 *   - A pointer to the function implementing the transformation.
 *
 * The array is terminated by an entry with both fields set to NULL.
 */
adapter_tranformation_map_t functions[] = {
    {"invert_bool", invert_bool_value},
    {"list_htable_to_param", convert_list_htable_to_param},
    {NULL, NULL}
};

/**
 * @brief Inverts a boolean value stored in an amxc_var_t variable.
 *
 * This function takes a source variable, attempts to convert it to a boolean,
 * and returns a new amxc_var_t containing the inverted boolean value.
 * If the conversion fails, NULL is returned.
 *
 * @param  src        Pointer to the source amxc_var_t variable.
 * @param  fn_call    (Unused) Function call context.
 * @param  fn_params  (Unused) Function parameters context.
 *
 * @return Pointer to a new amxc_var_t containing the inverted boolean value,
 *         or NULL if the input could not be converted to boolean.
 *
 * @note The caller is responsible for freeing the returned amxc_var_t.
 */
static amxc_var_t* invert_bool_value(const amxc_var_t* src,
                                     UNUSED const char* fn_call, UNUSED const char* fn_params) {
    amxc_var_t* converted = NULL;
    amxc_var_t temp;
    amxc_var_init(&temp);

    ASSERT_SUCCESS(amxc_var_convert(&temp, src, AMXC_VAR_ID_BOOL), goto end,
                   "Parameter value is not boolean. It cannot be inverted");

    amxc_var_new(&converted);
    amxc_var_set(bool, converted, !amxc_var_get_bool(src));

end:
    amxc_var_clean(&temp);
    return converted;
}

/**
 * @brief Converts a list or hash table variable to a parameter variable.
 *
 * This function takes a source variable (which is expected to be a list or hash table),
 * extracts string values from each entry using the specified parameter name, and joins
 * them into a comma-separated string. The result is returned as a new variable.
 *
 * @param src        The source variable (list or hash table) to convert.
 * @param fn_call    The name of the conversion function to use.
 * @param fn_params  The parameter name to extract from each entry.
 *
 * @return Pointer to a newly allocated variable containing the comma-separated string,
 *         or NULL if conversion fails or input is invalid.
 *
 * @note The caller is responsible for freeing the returned variable.
 */
static amxc_var_t* convert_list_htable_to_param(const amxc_var_t* src,
                                                const char* fn_call, const char* fn_params) {

    amxc_var_t* converted = NULL;
    amxc_var_t temp;
    amxc_llist_t input_list;
    amxc_string_t input_list_csv;

    ASSERT_NOT_NULL(src, return converted);
    ASSERT_STR_NOT_EMPTY(fn_call, return converted);
    ASSERT_STR_NOT_EMPTY(fn_params, return converted, "Missing params for conversion function");

    amxc_var_init(&temp);
    amxc_llist_init(&input_list);
    amxc_string_init(&input_list_csv, 0);


    if(GETP_ARG(src, "0")) {
        amxc_var_for_each(entry, src) {
            const char* value = GET_CHAR(entry, fn_params);
            if(!STRING_EMPTY(value)) {
                amxc_llist_add_string(&input_list, value);
            }
        }
    }

    amxc_string_join_llist(&input_list_csv, &input_list, ',');
    amxc_var_new(&converted);
    amxc_var_set(csv_string_t, converted, amxc_string_get(&input_list_csv, 0));

    amxc_var_clean(&temp);
    amxc_string_clean(&input_list_csv);
    amxc_llist_clean(&input_list, amxc_string_list_it_free);

    return converted;
}

/**
 * @brief Executes a transformation function on a source variable based on the function name.
 *
 * Searches for a transformation function by name and applies it to the given source variable.
 *
 * @param src        The source variable to be transformed.
 * @param fn_call    The name of the transformation function to call.
 * @param fn_params  Parameters to pass to the transformation function.
 *
 * @return A pointer to the result variable produced by the transformation function,
 *         or NULL if the function is not found.
 *
 * @note The caller is responsible for freeing the returned variable, if not NULL.
 */
static amxc_var_t* action_parameter_value(const amxc_var_t* src,
                                          const char* fn_call, const char* fn_params) {
    amxc_var_t* var = NULL;
    bool found = false;

    for(int i = 0; functions[i].name != NULL; i++) {
        if(strncmp(fn_call, functions[i].name, strlen(functions[i].name)) == 0) {
            var = functions[i].func(src, fn_call, fn_params);
            found = true;
            break;
        }
    }

    CHECK_FALSE_LOG(WARNING, found, NO_INSTRUCTION, "Transformation function [%s] not found", fn_call);
    return var;
}

/**
 * @brief Applies a value to a parameter, optionally make some
 * automatic transformation.
 *
 * This function sets the value of a parameter by copying the value
 * from `src` to `dest` under the given `name`.
 *
 * If the source variable is a cstring_t and the parameter description
 * specifies a maximum length, the string is truncated to this length
 * before being set.
 *
 * @param  param  Pointer to the parameter descriptor.
 * @param  dest   Destination variant where the value will be set.
 * @param  src    Source variant containing the value to apply.
 * @param  name   Name of the key under which the value will be set in `dest`.
 * @param  flags  Flags to control how the value is set in `dest`.
 *
 * @retval 0 returned on success, -1 otherwise.
 */
static int apply_transformed_value(amxd_param_t* param, amxc_var_t* dest,
                                   amxc_var_t* src, const char* name,
                                   int flags) {
    bool set = false;
    amxc_var_t descr;
    amxc_var_init(&descr);

    if(amxc_var_type_of(src) == AMXC_VAR_ID_CSTRING) {
        amxd_param_describe(param, &descr);
        if(GETP_ARG(&descr, VALIDATION_MAX_LENGTH)) {
            int max = GETP_UINT32(&descr, VALIDATION_MAX_LENGTH);
            const char* value = GET_CHAR(src, NULL);
            if((int) strlen(value) > max) {
                char* new_value = strdup(value);
                new_value[max] = '\0';
                SAH_TRACEZ_INFO(ME, "Parameter [%s] has been truncated to the maximum size [%d]",
                                name, max);
                amxc_var_add_key(cstring_t, dest, name, new_value);
                set = true;
                free(new_value);
            }
        }

    }

    amxc_var_clean(&descr);

    if(set != true) {
        amxc_var_set_key(dest, name, src, flags);
    }
    return 0;
}


/**
 * @brief Copies parameters from source to destination based on translation mappings.
 *
 * This function iterates over each parameter in the provided object, checks for a translation,
 * and copies the corresponding parameter from the source to the destination, without optionally
 * modifying the value.
 *
 * @param dest Destination variable where parameters will be added.
 * @param object Object containing parameter definitions.
 * @param source Source variable containing parameter values.
 * @param translation Object containing translation mappings.
 * @param root Boolean indicating if this is the top level object being processed.
 * @return The number of parameters copied.
 */
static int copy_parameters_with_optional_translation(amxc_var_t* dest,
                                                     amxd_object_t* object,
                                                     const amxc_var_t* source,
                                                     amxd_object_t* translation,
                                                     bool root) {
    char buffer[BUFFER_MAX_SIZE] = {0};
    int copied = 0;

    ASSERT_NOT_NULL(object, goto exit, "Missing object to populate");
    ASSERT_NOT_NULL(source, goto exit, "Missing source data");
    ASSERT_NOT_NULL(dest, goto exit, "Missing destination to populate");

    amxd_object_for_each(parameter, it, object) {
        amxc_var_t* var = NULL;
        char* source_param = NULL;
        char* trans_fn = NULL;
        char* trans_params = NULL;

        amxd_param_t* parameter = amxc_container_of(it, amxd_param_t, it);
        const char* name = amxd_param_get_name(parameter);
        if(!strcmp(name, ALIAS) && (root != true)) {
            continue; // Skip special parameter
        }

        if(translation) {
            // Retrieve the translated parameter path
            snprintf(buffer, sizeof(buffer), PARAM_MAP_SRC_PATH_FMT, name);
            source_param = amxd_object_get_cstring_t(translation, buffer, NULL);
        }

        // Use the translated name or fallback to parameter name
        var = GETP_ARG(source, source_param ? source_param : name);
        if(var == NULL) {
            goto next; // No value found
        }

        if(translation) {
            // Get transformation function
            snprintf(buffer, sizeof(buffer), PARAM_MAP_VALUE_TRANS_FMT, name);
            trans_fn = amxd_object_get_cstring_t(translation, buffer, NULL);
            snprintf(buffer, sizeof(buffer), PARAM_MAP_VALUE_TRANS_ARG_FMT, name);
            trans_params = amxd_object_get_cstring_t(translation, buffer, NULL);
        }

        if(VALID_TRANS_FN(trans_fn)) {
            amxc_var_t* res = action_parameter_value(var, trans_fn, trans_params);
            ASSERT_NOT_NULL(res, goto next, "Cannot set parameter [%s]", name);
            apply_transformed_value(parameter, dest, res, name, AMXC_VAR_FLAG_COPY);
            amxc_var_delete(&res);
        } else {
            apply_transformed_value(parameter, dest, var, name, AMXC_VAR_FLAG_COPY);
        }
        copied++;

next:
        free(trans_fn);
        free(trans_params);
        free(source_param);

    }

exit:
    return copied;
}

/**
 * @brief Recursively fills object parameters into destination variables
 * Using a amxd_object notification source.
 *
 * This function retrieves translation mappings, determines the source data,
 * and processes each object and its children recursively.
 *
 * @param dm Datamodel pointer.
 * @param dest Destination variable to store parameters.
 * @param src Source variable containing initial parameters.
 * @param object Object whose parameters are to be processed.
 * @param table Name of the table for translation lookup.
 * @param root Boolean indicating if this is the top level object being processed.
 * @return number of parameters copied, or -1 on error.
 */
int populate_object_and_children(amxd_dm_t* dm, amxc_var_t* src, amxc_var_t* dest,
                                 amxd_object_t* object, const char* table, bool root) {
    int copied = -1;
    amxc_var_t* args = dest;
    amxc_var_t* source = src;
    const char* name = NULL;
    amxd_object_t* translation = NULL;

    ASSERT_NOT_NULL(table, goto exit, "Missing table to populate");
    ASSERT_NOT_NULL(src, goto exit, "Missing source notification");
    ASSERT_NOT_NULL(dest, goto exit, "Missing destination to populate");
    ASSERT_NOT_NULL(dm, goto exit, "Missing datmodel pointer");

    if((object == NULL) && (root == true)) { // Root object
        object = amxd_dm_findf(dm, SOFTWAREMODULES_DM ".%s", table);
    }

    ASSERT_NOT_NULL(object, goto exit, "Missing object to populate");
    name = object->name;

    // Find translation mapping for the current object
    translation = amxd_dm_findf(dm, TABLE_OBJ_FMT, table, name);

    // Determine the source data, possibly using a source path from translation
    if(translation) {
        char* src_path = amxd_object_get_cstring_t(translation, SRC_OBJ_PATH, NULL);
        source = STRING_EMPTY(src_path) ? src : GETP_ARG(src, src_path);
        free(src_path);
    } else {
        source = GETP_ARG(src, name);
    }

    copied = 0;
    if(source == NULL) { // If no source data => Nothing to copy
        goto exit;
    }

    // If not root, add a new key to the destination for this object
    if(!root) {
        args = amxc_var_add_key(amxc_htable_t, dest, name, NULL);
    }

    // Handle object if it's a template
    if(!root && (amxd_object_get_type(object) == amxd_object_template)) {
        // Iterate over each instance in the source
        amxc_var_for_each(inst, source) {
            amxc_var_t* new_var = amxc_var_add_new_key_amxc_htable_t(args, amxc_var_key(inst), NULL);
            copied += copy_parameters_with_optional_translation(new_var, object, inst, translation, root);
        }
    } else {
        // Handle parameters directly
        copied += copy_parameters_with_optional_translation(args, object, source, translation, root);
    }

    // Recursively process child objects
    amxd_object_for_each(child, it, object) {
        amxd_object_t* child_obj = amxc_container_of(it, amxd_object_t, it);
        copied += populate_object_and_children(dm, source, args, child_obj, table, false);
    }

    // remove unecessary key if no parameter is copied in this object
    if((copied == 0) && !root) {
        amxc_var_t* s = amxc_var_take_key(dest, name);
        amxc_var_delete(&s);

    }

exit:
    return copied;
}

/**
 * @brief Adds default parameters for a specified command if they
 * are not already present.
 *
 * This function looks up the default parameters for the given command in the
 * CthulhuCommandDefaults object and adds them to the destination variant if they
 * are not already set. This ensures that all required default parameters are present
 * for the specified command.
 *
 * @param  dm      Pointer to the data model containing the command defaults.
 * @param  dest    Destination variant where default parameters will be added.
 * @param  command Name of the command for which to add default parameters.
 *
 * @retval 0 on success, -1 on failure.
 */
static int add_default_params(amxd_dm_t* dm, amxc_var_t* dest, const char* command) {
    amxd_object_t* obj = NULL;
    ASSERT_NOT_NULL(dm, return -1, "dm NULL, can't add defaults for [%s] command", command);

    obj = amxd_dm_findf(dm, ADAPTER_CMD_DEFAULT_FMT, command);
    ASSERT_NOT_NULL(obj, return 0);

    amxd_object_for_each(parameter, iter, obj) {
        amxd_param_t* param = amxc_container_of(iter, amxd_param_t, it);
        if(!GET_ARG(dest, amxd_param_get_name(param))) {
            amxc_var_t value;
            amxc_var_init(&value);
            amxd_param_get_value(param, &value);
            amxc_var_set_key(dest, amxd_param_get_name(param), &value, AMXC_VAR_FLAG_COPY);
            amxc_var_clean(&value);
        }
    }

    return 0;
}

/**
 * @brief Adds command parameters from source arguments to destination arguments based on a command mapping.
 *
 * This function retrieves the parameter definitions for a given command, then copies the relevant
 * parameters from the source arguments to the destination arguments, transforming parameter names
 * as needed. It also checks for mandatory parameters and reports errors if they are missing.
 *
 * @param ctx Bus Cthulhu context
 * @param dm Datamodel pointer.
 * @param src_args Pointer to the source arguments.
 * @param dest_args Pointer to the destination arguments.
 * @param command The command name for which parameters are to be added.
 * @return 0 on success, -1 on failure.
 */
int cthulhu_add_command_parameters(amxb_bus_ctx_t* ctx, amxd_dm_t* dm,
                                   const amxc_var_t* const src_args,
                                   amxc_var_t* const dest_args,
                                   const char* command) {
    int result_code = -1;
    amxc_var_t cmd_args;
    char buffer[BUFFER_MAX_SIZE] = {0};
    amxc_var_t* param_instance = NULL;
    amxc_var_t* var = NULL;
    amxd_object_t* cmd_map_obj = NULL;
    const char* param_name = NULL;
    amxc_var_t* args_list = NULL;
    amxd_status_t status = amxd_status_unknown_error;
    bool error = false;

    ASSERT_NOT_NULL(ctx, return result_code, "ctx NULL, can't add command [%s] parameters", command);
    ASSERT_NOT_NULL(dm, return result_code, "dm NULL, can't add command [%s] parameters", command);

    // Initialize temporary variables
    amxc_var_init(&cmd_args);

    // Retrieve the Cthulhu command mapping object
    cmd_map_obj = amxd_dm_findf(dm, ADAPTER_CMD_MAPPING);

    // Describe the command to get its argument definitions
    status = amxb_describe(ctx, CTHULHU_DM_CONTAINER,
                           AMXB_FLAG_FUNCTIONS, &cmd_args, AMXB_CALL_TIMEOUT);
    ASSERT_SUCCESS(status, goto cleanup, "Failed to get [%s] definition", command);

    // Extract the list of arguments for the command
    snprintf(buffer, sizeof(buffer), "0.functions.%s.arguments", command);
    args_list = GETP_ARG(&cmd_args, buffer);
    if(args_list) {
        // Ensure the extracted argument list is of the correct type
        ASSERT_EQUAL(amxc_var_type_of(&cmd_args), AMXC_VAR_ID_LIST, goto cleanup,
                     "Failed to extract function params");

        // Iterate over each argument definition
        amxc_llist_for_each(it, amxc_var_constcast(amxc_llist_t, args_list)) {
            char* trans_param = NULL;
            char* trans_fn = NULL;
            var = amxc_llist_it_get_data(it, amxc_var_t, lit);
            if(GETP_BOOL(var, ATTR_IN)) {
                param_name = GET_CHAR(var, "name");

                if(cmd_map_obj) {
                    // Get the transformed parameter name from the Cthulhu parameters object
                    snprintf(buffer, sizeof(buffer), GET_SRC_PARAM_FMT, param_name);
                    trans_param = amxd_object_get_cstring_t(cmd_map_obj, buffer, NULL);

                    // Get transformation function
                    snprintf(buffer, sizeof(buffer), GET_VALUE_TRANS_FMT, param_name);
                    trans_fn = amxd_object_get_cstring_t(cmd_map_obj, buffer, NULL);
                }

                // Retrieve the argument from source args, fallback to original name if transformation is NULL
                if((param_instance = GET_ARG(src_args, trans_param ? trans_param : param_name)) != NULL) {
                    if(VALID_TRANS_FN(trans_fn)) {
                        amxc_var_t* res = action_parameter_value(param_instance, trans_fn, NULL);
                        ASSERT_NOT_NULL(res, goto next,
                                        "Cannot set parameter [%s]", param_name);
                        amxc_var_set_key(dest_args, param_name, res, AMXC_VAR_FLAG_COPY);
                        amxc_var_delete(&res);
                    } else {
                        amxc_var_set_key(dest_args, param_name, param_instance, AMXC_VAR_FLAG_COPY);
                    }
                } else {
                    // Check if the parameter is mandatory
                    if(GETP_BOOL(var, ATTR_MANDATORY)) {
                        SAH_TRACEZ_ERROR(ME, "Mandatory parameter [%s] missing", param_name);
                        error = true;
                    }
                }
            }
next:
            free(trans_param);
            free(trans_fn);
            if(error) {
                break;
            }
        }

        if(error) {
            result_code = amxd_status_invalid_function_argument;
        } else {
            add_default_params(dm, dest_args, command);
            result_code = amxd_status_ok;
        }
    }

cleanup:
    // Clean up resources
    amxc_var_clean(&cmd_args);
    return result_code;
}

/**
 * @brief Overloads functions parameters in the data model.
 *
 * This function iterates over the list of functions in the source object
 * and adds any missing arguments to the corresponding functions in the destination object.
 * Only arguments that are not already declared in the destination functions are added.
 *
 * @param src_obj Object with functions. The functions have new arguments that should be
 *                added to the corresponding functions in the dst_obj
 * @param dst_obj Pointer to the destination object to be overloaded.
 * @return The number of arguments added to the destination functions.
 */
static int overload_function_arg(amxd_object_t* src_obj, amxd_object_t* dst_obj) {
    int rc = 0;
    amxc_var_t* fn_args = NULL;
    amxc_var_t args;
    amxd_function_t* src_func = NULL;
    amxd_function_t* dst_func = NULL;
    amxd_status_t status = amxd_status_unknown_error;

    amxd_object_for_each(function, it, src_obj) {
        src_func = amxc_container_of(it, amxd_function_t, it);

        amxc_var_init(&args);
        amxd_function_describe(src_func, &args);
        fn_args = GET_ARG(&args, "arguments");
        if(!fn_args) {
            amxc_var_clean(&args);
            continue; // No arguments to process
        }

        // Ensure the extracted argument list is of the correct type
        ASSERT_EQUAL(amxc_var_type_of(fn_args), AMXC_VAR_ID_LIST,
                     amxc_var_clean(&args); continue, "Failed to extract command args");

        // Iterate over each argument in the argument list
        amxc_llist_for_each(iterl, amxc_var_constcast(amxc_llist_t, fn_args)) {
            amxd_func_arg_t* src_arg = NULL;
            amxc_var_t* var = amxc_llist_it_get_data(iterl, amxc_var_t, lit);
            const char* arg_name = GET_CHAR(var, "name");
            const char* func_name = amxd_function_get_name(src_func);

            dst_func = amxd_object_get_function(dst_obj, func_name);
            CHECK_NULL_LOG(WARNING, dst_func, continue, "Function [%s] not found", func_name);

            CHECK_FAILURE_LOG(WARNING, amxd_function_get_arg(dst_func, arg_name), continue,
                              "Argument [%s] already defined in [%s]", arg_name, func_name);

            src_arg = amxd_function_get_arg(src_func, arg_name);
            ASSERT_NOT_NULL(src_arg, continue, "Failed to get arg [%s] info", arg_name)

            SAH_TRACEZ_INFO(ME, "Expanding cmd [%s] by an additional parameter [%s]",
                            func_name, arg_name);

            // Add new argument to destination function
            status = amxd_function_new_arg(dst_func, arg_name, src_arg->type, &src_arg->default_value);
            ASSERT_SUCCESS(status, continue, "Failed to add argument [%s] to func [%s]", arg_name, func_name);
            rc++;

            // Copy attributes from source argument
            if(amxd_function_arg_is_attr_set(src_func, arg_name, amxd_aattr_in)) {
                amxd_function_arg_set_attr(dst_func, arg_name, amxd_aattr_in, true);
            }
            if(amxd_function_arg_is_attr_set(src_func, arg_name, amxd_aattr_out)) {
                amxd_function_arg_set_attr(dst_func, arg_name, amxd_aattr_out, true);
            }
            if(amxd_function_arg_is_attr_set(src_func, arg_name, amxd_aattr_mandatory)) {
                amxd_function_arg_set_attr(dst_func, arg_name, amxd_aattr_mandatory, true);
            }
            if(amxd_function_arg_is_attr_set(src_func, arg_name, amxd_aattr_strict)) {
                amxd_function_arg_set_attr(dst_func, arg_name, amxd_aattr_strict, true);
            }
        }

        amxc_var_clean(&args);
    }

    return rc;
}

/**
 * @brief Overloads function parameters in the data model.
 *
 * This function iterates over functions definitions to add missing arguments from
 * alternative definitions, copying their attributes if they do not already exist.
 *
 * @param datamodel Pointer to the data model object.
 * @return number of added arguments.
 */
int cthulhu_sm_overload_cmd_params(amxd_dm_t* datamodel) {
    int rc = 0;
    amxd_object_t* root = NULL;
    amxd_object_t* fn_overload_config = NULL;
    char* fn_path = NULL;
    amxd_object_t* fn_object = NULL;

    ASSERT_NOT_NULL(datamodel, goto exit);

    root = amxd_dm_get_root(datamodel);
    fn_overload_config = amxd_dm_findf(datamodel, ADAPTER_FN_OVERLOAD);
    if(!fn_overload_config) {
        goto exit; // No overloads found
    }

    // Iterate over each function in the overload config
    amxd_object_for_each(instance, iter, fn_overload_config) {
        amxd_object_t* obj = amxc_container_of(iter, amxd_object_t, it);
        fn_path = amxd_object_get_cstring_t(obj, FN_PATH, NULL);
        if(STRING_EMPTY(fn_path)) {
            free(fn_path);
            continue; // Skip if no path
        }

        // Find the function object
        fn_object = amxd_object_findf(root, "%s", fn_path);
        if(!fn_object) {
            free(fn_path);
            continue;
        }
        rc += overload_function_arg(obj, fn_object);

        free(fn_path);
    }

exit:
    return rc;
}
