/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxm/amxm.h>
#include <debug/sahtrace.h>

#include "ddns.h"
#include "ddns_priv.h"
#include "ddns_config.h"
#include "server/dm_server.h"

#define ME "ddns"

#define CUSTOM_SERVICE "custom"

int ddns_open_cfgctrlrs(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxc_var_t* args = NULL;
    amxc_var_t* mod_services = NULL;
    amxc_var_t lcontrollers;
    amxc_string_t mod_path;
    amxm_shared_object_t* so = NULL;
    amxd_object_t* ddns_obj = amxd_dm_findf(ddns_get_dm(), DDNS);
    amxo_parser_t* parser = ddns_get_parser();
    const amxc_var_t* controllers = amxd_object_get_param_value(ddns_obj, "SupportedControllers");
    const char* const mod_dir = GETP_CHAR(&parser->config, "mod-dir");

    amxc_var_init(&lcontrollers);
    amxc_string_init(&mod_path, 0);
    amxc_var_new(&args);
    amxc_var_new(&mod_services);

    amxc_var_convert(&lcontrollers, controllers, AMXC_VAR_ID_LIST);
    //Load controllers
    amxc_var_for_each(controller, &lcontrollers) {
        const char* name = GET_CHAR(controller, NULL);
        amxc_string_setf(&mod_path, "%s/%s.so", mod_dir, name);
        rv = amxm_so_open(&so, name, amxc_string_get(&mod_path, 0));
        SAH_TRACEZ_INFO(ME, "Loading controller '%s'", name);
        when_failed_trace(rv, exit, ERROR, "Failed to load the controller '%s'", name);
    }

    //Initialize controllers
    amxc_var_for_each(controller, &lcontrollers) {
        const char* name = GET_CHAR(controller, NULL);
        rv = amxm_execute_function(name, MOD_DDNS_CTRL, "init", args, mod_services);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to initialize the controller '%s'", name);
        }
    }

    rv = 0;
exit:
    amxc_string_clean(&mod_path);
    amxc_var_clean(&lcontrollers);
    amxc_var_delete(&args);
    amxc_var_delete(&mod_services);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static void merge_servers(amxc_var_t* all_servers, amxc_var_t* module_servers) {
    when_null(all_servers, exit);
    when_null(module_servers, exit);

    amxc_var_for_each(server, module_servers) {
        const amxc_htable_t* htable = amxc_var_constcast(amxc_htable_t, server);
        amxc_var_add_key(amxc_htable_t, all_servers, amxc_var_key(server), htable);
    }
exit:
    return;
}

static void remove_old_servers(amxc_var_t* all_services) {
    int rv = -1;
    amxd_object_t* templ_server = ddns_server_template(ddns_get_dm());

    when_null(templ_server, exit);

    amxd_object_for_each(instance, it, templ_server) {
        amxd_object_t* obj_server = amxc_container_of(it, amxd_object_t, it);
        const char* obj_server_origin = ddns_get_string_param(obj_server, NULL, SERVER_ORIGIN);
        const char* obj_server_name = ddns_get_string_param(obj_server, NULL, SERVER_NAME);
        const char* obj_server_service = NULL;
        char* server_name = NULL;
        char* server_service = NULL;

        if(str_empty(obj_server_name)) {
            continue;
        }

        if(str_empty(obj_server_origin)) {
            continue;
        }

        if(strcmp(obj_server_origin, SERVER_ORIGIN_USER) == 0) {
            continue;
        }

        server_name = (char*) calloc(1, strlen(obj_server_name) + 1);
        if(server_name == NULL) {
            continue;
        }
        strcpy(server_name, obj_server_name);

        obj_server_service = ddns_get_string_param(obj_server, NULL, SERVER_SERVICE);
        if(obj_server_service != NULL) {
            server_service = (char*) calloc(1, strlen(obj_server_service) + 1);
            if(server_service != NULL) {
                strcpy(server_service, obj_server_service);
            }
        }

        if(GET_ARG(all_services, server_name) == NULL) {
            rv = remove_server(server_name);
            if(rv != 0) {
                FREE(server_service);
                FREE(server_name);
                continue;
            }
            remove_old_supported_service(server_service, server_name);
        }
        FREE(server_service);
        FREE(server_name);
    }

exit:
    return;
}

int cfgctrlr_ddns_fetch_servers(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    int ret_value = -1;
    amxc_var_t args;
    amxc_var_t* all_services;
    amxc_var_t mod_services;
    const cstring_t service_name = NULL;
    amxc_var_t lcontrollers;
    amxd_object_t* ddns_obj = amxd_dm_findf(ddns_get_dm(), DDNS);
    const amxc_var_t* controllers = amxd_object_get_param_value(ddns_obj, "SupportedControllers");

    amxc_var_init(&lcontrollers);
    amxc_var_init(&args);
    amxc_var_new(&all_services);
    amxc_var_set_type(all_services, AMXC_VAR_ID_HTABLE);

    when_null_trace(controllers, exit, ERROR, "SupportedControllers is NULL.");

    amxc_var_convert(&lcontrollers, controllers, AMXC_VAR_ID_LIST);
    amxc_var_for_each(controller, &lcontrollers) {
        const char* name = GET_CHAR(controller, NULL);
        amxc_var_init(&mod_services);

        //Fill the available servers from each module.
        rv = amxm_execute_function(name, MOD_DDNS_CTRL, "supported-services", &args, &mod_services);
        if(rv != 0) {
            SAH_TRACEZ_ERROR(ME, "Could not execute 'supported-services' on the %s controller", name);
            amxc_var_clean(&mod_services);
            continue;
        }

        amxc_var_for_each(server, &mod_services) {
            service_name = ddns_get_string_param(NULL, server, SERVER_SERVICE);
            add_new_supported_service(service_name);

            rv = add_new_server(server);
            if(rv != 0) {
                rv = edit_server(server);
                if(rv != 0) {
                    continue;
                }
            }
        }

        merge_servers(all_services, &mod_services);
        amxc_var_clean(&mod_services);
    }

    remove_old_servers(all_services);

    // Add the service "custom" to allow custom DDNS servers
    add_new_supported_service(CUSTOM_SERVICE);

    ret_value = 0;

exit:
    amxc_var_clean(&lcontrollers);
    amxc_var_clean(&args);
    amxc_var_clean(&mod_services);
    amxc_var_delete(&all_services);
    SAH_TRACEZ_OUT(ME);
    return ret_value;
}

/**
 * @brief Executes a function on the DynamicDNS's configuration controller
 * @param obj The object from which to get the module name to use, if NULL mod_dynamicdns_uci is used
 * @param func_name The name of the function to execute
 * @param args variant structure of the arguments to the function. All functions expect the same fields in the variant!
 * @param ret variant structure of the return values from the function
 * @return 0 if the function executed without errors, otherwise it return -1
 */
int cfgctrlr_execute_function(amxd_object_t* obj,
                              const char* const func_name,
                              amxc_var_t* args,
                              amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int status = -1;
    const amxc_var_t* ddns_ctrl = amxd_object_get_param_value(obj, "Controller");
    const char* ddns_ctrlr_name = NULL;

    // find controller for the configuration
    if(obj == NULL) {
        // If no object was given we want to use the uci module
        ddns_ctrlr_name = "mod_dynamicdns_uci";
    } else {
        ddns_ctrlr_name = GET_CHAR(ddns_ctrl, NULL);
        when_str_empty_trace(ddns_ctrlr_name, exit, ERROR, "Could not find the controller for this configuration");
    }

    // Call controller-specific implementation
    status = amxm_execute_function(ddns_ctrlr_name, MOD_DDNS_CTRL, func_name, args, ret);
    if(status < 0) {
        SAH_TRACEZ_ERROR(ME, "Could not execute '%s' on the %s controller", func_name, ddns_ctrlr_name);
        goto exit;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

int cfgctrlr_ddns_execute_function(amxd_object_t* ddns_obj,
                                   const char* function,
                                   amxc_var_t* data,
                                   amxc_var_t* ret) {
    int rv = -1;

    when_str_empty_trace(function, exit, ERROR, "Can not execute function, empty string");
    when_null_trace(ddns_obj, exit, ERROR, "can not execute %s, no object given", function);

    rv = cfgctrlr_execute_function(ddns_obj, function, data, ret);
    if(rv < 0) {
        SAH_TRACEZ_ERROR(ME, "function %s failed", function);
    }

exit:
    return rv;
}