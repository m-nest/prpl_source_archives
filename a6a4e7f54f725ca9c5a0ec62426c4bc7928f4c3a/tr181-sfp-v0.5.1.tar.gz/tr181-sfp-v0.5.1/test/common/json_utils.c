/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "json_utils.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <fcntl.h>  /* open() */
#include <unistd.h> /* close() */

/* Other libraries' headers */
#include <yajl/yajl_gen.h>
#include <amxc/amxc_variant_type.h>
#include <amxj/amxj_variant.h>

/* Own headers */
#include "sfpmgr_trace.h"

#undef ME
#define ME "runtest"

/**
 * Read JSON file and return the resulting variant.
 *
 * @param[in] fname: path to JSON file
 *
 * The caller gets ownership of the returned variant. If the variant is not
 * needed anymore it must be freed by calling amxc_var_delete().
 *
 * @return the JSON data read on success, NULL on error
 */
amxc_var_t* read_json_from_file(const char* fname) {
    int rc;
    int fd = -1;
    variant_json_t* reader = NULL;
    amxc_var_t* data = NULL;
    amxj_reader_state_t state;
    unsigned cntr = 0;
    SAH_TRACEZ_INFO(ME, "fname='%s'", fname);

    const int present = (access(fname, F_OK) == 0) ? 1 : 0;
    assert_int_equal(present, 1);

    // create a json reader
    rc = amxj_reader_new(&reader);
    assert_int_equal(rc, 0);

    // open the json file
    fd = open(fname, O_RDONLY);

    assert_true(fd > 0);

    // read the json file and parse the json text
    while(cntr < 10) { // avoid endless loop
        rc = amxj_read(reader, fd);
        assert_true(rc >= 0);
        if(rc == 0) {
            state = amxj_reader_get_state(reader);
            assert_int_equal(state, amxj_reader_done);
            break;
        }
        ++cntr;
    }

    // get the variant
    data = amxj_reader_result(reader);
    assert_non_null(data);

    close(fd);

    amxj_reader_delete(&reader);
    return data;
}

