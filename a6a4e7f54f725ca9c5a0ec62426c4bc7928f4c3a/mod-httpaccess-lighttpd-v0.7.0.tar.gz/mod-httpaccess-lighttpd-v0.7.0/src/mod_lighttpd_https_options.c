/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#define _POSIX_C_SOURCE 200809L // needed for strdup
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>
#include <amxc/amxc_string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_lighttpd_https_options.h"

#define string_empty(X) ((X == NULL) || (*X == '\0'))
#define ME "mod-lighttpd-https-options"

/**
 * @brief Retrieves the certificate and private key URIs for a given path.
 *
 * This function calls the "GetCertificateURI" method on the backend associated with the provided `fullpath`.
 *
 * @param[in]  fullpath  A path name of a row in the Security.Certificate table, e.g. "Security.Certificate.1."
 * @param[out] certuri   Pointer to a string that will be allocated and set to the certificate URI.
 * @param[out] keyuri    Pointer to a string that will be allocated and set to the private key URI.
 *
 * @return 0 on success, -1 on failure.
 *
 * @note The caller is responsible for freeing the memory allocated for `*certuri` and `*keyuri`.
 */
int get_certificate_uri(const char* fullpath, char** certuri, char** keyuri) {
    amxc_var_t inargs;
    amxc_var_t outargs;
    int ret = -1;

    amxc_var_init(&inargs);
    amxc_var_init(&outargs);

    ret = amxb_call(amxb_be_who_has(fullpath), fullpath, "GetCertificateURI", &inargs, &outargs, 3);

    if(ret == 0) {
        amxc_var_t* outputs = amxc_var_get_first(&outargs); // string error/status
        outputs = amxc_var_get_next(outputs);               // map
        const char* cert = amxc_var_constcast(cstring_t, amxc_var_get_key(outputs, "CertificateURI", AMXC_VAR_FLAG_DEFAULT));
        const char* key = amxc_var_constcast(cstring_t, amxc_var_get_key(outputs, "PrivateKeyURI", AMXC_VAR_FLAG_DEFAULT));

        if(cert) {
            *certuri = strdup(cert);
        }
        if(key) {
            *keyuri = strdup(key);
        }

        ret = 0;
    }

    amxc_var_clean(&inargs);
    amxc_var_clean(&outargs);
    return ret;
}

/**
 * @brief Appends HTTPS configuration options to a Lighttpd config string.
 *
 * If the protocol specified in the `access` variable is "HTTPS", it attempts
 * to retrieve the certificate and private key URIs using the `get_certificate_uri`
 * function and appends the appropriate Lighttpd SSL configuration directives
 * to the config string.
 *
 * @param[in]  access A variable container holding access configuration,
 *                    including the protocol and certificate reference.
 *                    Expected to contain at least the "Protocol" and
 *                    "Certificate" keys.
 *
 * @param[out] config A string representing the Lighttpd configuration to which
 *                    the appropriate https lines will be appended, e.g. `ssl.engine`,
 *                    `ssl.pemfile`, and `ssl.privkey` as applicable.
 *
 * @return 0 on success, or a non-zero error code if the HTTPS setup is
 *         incomplete or fails to retrieve the required certificate data.
 */

int mod_lighttpd_config_https_options(amxc_var_t* access, amxc_string_t* config) {
    int err = 0;

    if(!strcmp(GET_CHAR(access, "Protocol"), "HTTPS")) {
        int emptycert = -1;
        int engineuse = 1;
        const char* certref = GETP_CHAR(access, "Certificate");
        if(!string_empty(certref)) {
            static const char fileprefix[] = "file://";
            const int prefixlen = sizeof(fileprefix) - 1;
            char* certuri = NULL;
            char* keyuri = NULL;

            get_certificate_uri(certref, &certuri, &keyuri);
            if((certuri != NULL) && (0 == strncmp(certuri, fileprefix, prefixlen))) {
                memmove(certuri, certuri + prefixlen, strlen(certuri + prefixlen) + 1);
            }
            if((keyuri != NULL) && (0 == strncmp(keyuri, fileprefix, prefixlen))) {
                memmove(keyuri, keyuri + prefixlen, strlen(keyuri + prefixlen) + 1);
                engineuse = 0;
            }

            if(!string_empty(certuri) && !string_empty(keyuri)) {
                emptycert = 0;
                if(engineuse) {
                    err |= amxc_string_appendf(config, "  ssl.engine = \"enable\"\n");
                }
                err |= amxc_string_appendf(config, "  ssl.pemfile = \"%s\"\n", certuri);
                err |= amxc_string_appendf(config, "  ssl.privkey = \"%s\"\n", keyuri);
            }
            free(certuri);
            free(keyuri);
        }
        err |= emptycert;
        if(err) {
            SAH_TRACEZ_ERROR(ME, "Incomplete https setup");
        }
    }
    return err;
}