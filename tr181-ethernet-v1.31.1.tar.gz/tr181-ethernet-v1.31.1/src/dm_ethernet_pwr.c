/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
   @file dm_ethernet_pwr.c
   @brief Implements asynchronous Ethernet power mode transitions.

   This source file contains the data-model side of the Ethernet power
   management flow. It handles the asynchronous ChangePowerMode RPC, tracks the
   pending deferred request, enforces a timeout, and finalizes the request when
   the selected power controller reports completion.
 */

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <inttypes.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_timer.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_function.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ethernet_pwr.h"
#include "ethernet.h"
#include "ethernet_soc_utils.h"

#define ME "pwr"
#define CHANGE_POWER_MODE_TIMEOUT_MS 1000

/**
   @brief Tracks the state of a pending asynchronous ChangePowerMode request.

   The structure stores the deferred call identifier, timeout timer, target
   Ethernet interface, and requested power state until the power controller
   reports completion or the operation times out.
 */
typedef struct ethernet_async_change_pwr_s {
    bool call_busy;             // Boolean value representing if a call ongoing
    uint64_t call_id;           // Unique identifier of the ongoing call
    amxp_timer_t* timer;        // Timout timer for the call
    ethernet_info_t* ethernet;  // Internal information of the ethernet interface
    char* new_state;            // New state to be applied to the ethernet interface
} ethernet_async_change_pwr_t;

static ethernet_async_change_pwr_t s_async_change_power_mode = {
    .call_busy = false,
    .call_id = 0,
    .timer = NULL,
    .ethernet = NULL,
    .new_state = NULL,
};

/**
   @brief Reset the pending asynchronous power change state.

   Stops and destroys the timeout timer, clears the deferred request metadata,
   and releases the stored target power state string.
 */
static void reset_async_change_power_mode_status(void) {
    SAH_TRACEZ_IN(ME);
    s_async_change_power_mode.call_busy = false;
    s_async_change_power_mode.call_id = 0;
    amxp_timer_delete(&s_async_change_power_mode.timer);
    s_async_change_power_mode.ethernet = NULL;
    if(s_async_change_power_mode.new_state != NULL) {
        free(s_async_change_power_mode.new_state);
        s_async_change_power_mode.new_state = NULL;
    }
    SAH_TRACEZ_OUT(ME);
}

/**
   @brief Cancel the deferred power mode change when the timeout expires.

   @param timer Pointer to the expired timer.
   @param priv Private user data, unused.
 */
static void ethernet_async_change_power_mode_status_cancel(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "Deferred call removed (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);
    amxd_function_deferred_remove(s_async_change_power_mode.call_id);
    reset_async_change_power_mode_status();
    SAH_TRACEZ_OUT(ME);
}

/**
   @brief Complete a deferred ChangePowerMode request.

   This callback is invoked through the internal `pwr-async-done` AMXM function
   after the low-level power controller finishes its platform-specific work. On
   success, it updates the interface `PowerStatus` and completes the deferred
   RPC.

   @param function_name Name of the invoked function, unused.
   @param args Callback arguments, unused.
   @param ret Return value container, unused.
   @return `amxd_status_ok` on successful completion, `amxd_status_timeout`
           when no request is pending, or another error code on failure.
 */
int ethernet_async_change_power_mode_status_set_done(UNUSED const char* function_name,
                                                     UNUSED amxc_var_t* args,
                                                     UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    if(s_async_change_power_mode.call_busy) {
        SAH_TRACEZ_INFO(ME, "LL API call done (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);

        amxd_object_set_attr(s_async_change_power_mode.ethernet->object, amxd_oattr_read_only, true);
        rv = amxd_object_set_value(cstring_t, s_async_change_power_mode.ethernet->object, "PowerStatus", s_async_change_power_mode.new_state);
        if(rv != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Failed to set PowerState synchronously; rv=%d", rv);
            amxd_function_deferred_remove(s_async_change_power_mode.call_id);
            reset_async_change_power_mode_status();
            goto exit;
        }
        rv = amxd_function_deferred_done(s_async_change_power_mode.call_id, rv, NULL, NULL);
        if(rv != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Failed to complete deferred ChangePowerMode call; rv=%d", rv);
        }
        reset_async_change_power_mode_status();
    } else {
        SAH_TRACEZ_INFO(ME, "LL API call timeout (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);
        rv = amxd_status_timeout;
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
   @brief Handle the asynchronous `ChangePowerMode` data-model RPC.

   The function validates the requested target state, creates a deferred RPC,
   starts a timeout timer, and forwards the request to the selected power
   controller. The final result is completed later by
   `ethernet_async_change_power_mode_status_set_done`.

   @param object Data-model object on which the RPC was invoked.
   @param func Function descriptor used to create the deferred call.
   @param args Input arguments containing the requested `PowerState`.
   @param ret Return value container used for the deferred response.
   @return `amxd_status_deferred` when the asynchronous operation starts
           successfully, or an error status when setup fails.
 */
amxd_status_t _ChangePowerMode(amxd_object_t* object,
                               amxd_function_t* func,
                               amxc_var_t* args,
                               amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t rv = amxd_status_ok;
    ethernet_info_t* ethernet = (ethernet_info_t*) object->priv;
    const char* new_state = GET_CHAR(args, "PowerState");

    when_null_status(ethernet, exit, rv = amxd_status_invalid_value);
    when_str_empty_status(new_state, exit, rv = amxd_status_invalid_value);

    if(s_async_change_power_mode.call_busy) {
        SAH_TRACEZ_INFO(ME, "Previous ChangePowerMode() in progress; canceling old call_id=%" PRIu64, s_async_change_power_mode.call_id);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
    }

    s_async_change_power_mode.ethernet = ethernet;
    s_async_change_power_mode.new_state = strdup(new_state);
    if(s_async_change_power_mode.new_state == NULL) {
        reset_async_change_power_mode_status();
        return amxd_status_out_of_mem;
    }

    rv = amxd_function_defer(func, &s_async_change_power_mode.call_id, ret, NULL, NULL);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "amxd_function_defer() failed; rv=%d", rv);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Deferred call created (call_id=%" PRIu64 ")", s_async_change_power_mode.call_id);

    s_async_change_power_mode.call_busy = true;

    rv = amxp_timer_new(&s_async_change_power_mode.timer, ethernet_async_change_power_mode_status_cancel, NULL);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to create async power mode timer; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    rv = amxp_timer_start(s_async_change_power_mode.timer, CHANGE_POWER_MODE_TIMEOUT_MS);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start async power mode timer; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Setting PowerState (deferred) to '%s'", s_async_change_power_mode.new_state);
    rv = mod_ethernet_set_pwr_mode(s_async_change_power_mode.ethernet, s_async_change_power_mode.new_state);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to set PowerState synchronously; rv=%d", rv);
        amxd_function_deferred_remove(s_async_change_power_mode.call_id);
        reset_async_change_power_mode_status();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Deferred call_id=%" PRIu64 " done (rv=%d)", s_async_change_power_mode.call_id, rv);

    rv = amxd_status_deferred;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}
