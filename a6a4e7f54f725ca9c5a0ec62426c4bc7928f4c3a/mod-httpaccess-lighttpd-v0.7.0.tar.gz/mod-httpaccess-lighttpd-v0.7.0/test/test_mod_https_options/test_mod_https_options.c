/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#include <string.h>
#include <setjmp.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>

#include <cmocka.h>
#include "mod_lighttpd_https_options.h"
#include "test_mod_https_options.h"

int __wrap_amxb_call(amxb_bus_ctx_t* const bus_ctx,
                     const char* object,
                     const char* method,
                     UNUSED amxc_var_t* args,
                     amxc_var_t* ret,
                     int timeout) {
    amxc_var_t* out_args;

    check_expected_ptr(bus_ctx);
    check_expected_ptr(object);
    check_expected_ptr(method);
    check_expected_ptr(args);
    check_expected_ptr(ret);
    check_expected(timeout);

    amxc_var_new(&out_args);
    amxc_var_set_type(out_args, AMXC_VAR_ID_LIST);

    amxc_var_add(cstring_t, out_args, "");

    amxc_var_t* uris = amxc_var_add_new(out_args);
    amxc_var_set_type(uris, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, uris, "CertificateURI", "TestCertURI");
    amxc_var_add_key(cstring_t, uris, "PrivateKeyURI", "TestKeyURI");

    amxc_var_move(ret, out_args);
    amxc_var_delete(&out_args);

    return mock_type(int);
}

amxb_bus_ctx_t* __wrap_amxb_be_who_has(const char* object_path) {
    check_expected(object_path);
    return (amxb_bus_ctx_t*) mock_ptr_type(amxb_bus_ctx_t*);
}

void test_get_certificate_uri_success(UNUSED void** state) {
    const char* fullpath = "/some/path";
    char* certuri = NULL;
    char* keyuri = NULL;
    amxb_bus_ctx_t dummy_ctx;

    expect_string(__wrap_amxb_be_who_has, object_path, fullpath);
    will_return(__wrap_amxb_be_who_has, &dummy_ctx);
    expect_any(__wrap_amxb_call, bus_ctx);
    expect_any(__wrap_amxb_call, object);
    expect_any(__wrap_amxb_call, method);
    expect_any(__wrap_amxb_call, args);
    expect_any(__wrap_amxb_call, ret);
    expect_any(__wrap_amxb_call, timeout);
    will_return(__wrap_amxb_call, 0);

    int result = get_certificate_uri(fullpath, &certuri, &keyuri);

    assert_int_equal(result, 0);
    assert_string_equal(certuri, "TestCertURI");
    assert_string_equal(keyuri, "TestKeyURI");

    free(certuri);
    free(keyuri);
}

void test_get_certificate_uri_invalid_input(UNUSED void** state) {
    char* certuri = NULL;
    char* keyuri = NULL;
    amxb_bus_ctx_t dummy_ctx;

    expect_value(__wrap_amxb_be_who_has, object_path, NULL);
    will_return(__wrap_amxb_be_who_has, &dummy_ctx);
    expect_any(__wrap_amxb_call, bus_ctx);
    expect_any(__wrap_amxb_call, object);
    expect_any(__wrap_amxb_call, method);
    expect_any(__wrap_amxb_call, args);
    expect_any(__wrap_amxb_call, ret);
    expect_any(__wrap_amxb_call, timeout);
    will_return(__wrap_amxb_call, 1);

    int result = get_certificate_uri(NULL, &certuri, &keyuri);
    assert_int_not_equal(result, 0);
}

void test_mod_lighttpd_config_https_options(UNUSED void** state) {
    amxc_var_t access;
    amxc_string_t config;
    const char* cert_string = "Device.Security.Certificate.1.";
    amxb_bus_ctx_t dummy_ctx;

    amxc_string_init(&config, 0);
    amxc_var_init(&access);
    amxc_var_set_type(&access, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &access, "Protocol", "HTTPS");
    amxc_var_add_key(cstring_t, &access, "Certificate", cert_string);

    expect_string(__wrap_amxb_be_who_has, object_path, cert_string);
    will_return(__wrap_amxb_be_who_has, &dummy_ctx);
    expect_any(__wrap_amxb_call, bus_ctx);
    expect_any(__wrap_amxb_call, object);
    expect_any(__wrap_amxb_call, method);
    expect_any(__wrap_amxb_call, args);
    expect_any(__wrap_amxb_call, ret);
    expect_any(__wrap_amxb_call, timeout);
    will_return(__wrap_amxb_call, 0);
    int result = mod_lighttpd_config_https_options(&access, &config);

    assert_int_equal(result, 0);

    const char* config_str = amxc_string_get(&config, 0);
    assert_non_null(config_str);
    assert_non_null(strstr(config_str, "ssl.engine = \"enable\""));
    assert_non_null(strstr(config_str, "ssl.pemfile = \"TestCertURI\""));
    assert_non_null(strstr(config_str, "ssl.privkey = \"TestKeyURI\""));

    amxc_var_clean(&access);
    amxc_string_clean(&config);
}
