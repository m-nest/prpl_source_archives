/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "../common/mock.h"
#include "test_module.h"

static amxd_dm_t dm;
static amxo_parser_t parser;
static amxb_bus_ctx_t* bus_ctx = NULL;

#define DUMMY_TEST_ODL "../common/dummy.odl"
#define UCI_ADD "uci_add"
#define UCI_DELETE "uci_delete"
#define UCI_SET "uci_set"
#define UCI_GET "uci_get"
#define UCI_COMMIT "uci_commit"

#define MOD_CORE "mod-ppp"

static void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
}

static int dummy_func(UNUSED const char* function_name,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    return 0;
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);
    assert_int_equal(test_register_dummy_be(), 0);

    amxo_resolver_ftab_add(&parser, "commit", AMXO_FUNC(dummy_function_commit));
    amxo_resolver_ftab_add(&parser, "set", AMXO_FUNC(dummy_function_set));

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, DUMMY_TEST_ODL, root_obj), 0);

    // Create dummy/fake bus connections
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    amxo_connection_add(&parser, amxb_get_fd(bus_ctx), connection_read, "dummy:/tmp/dummy.sock", AMXO_BUS, bus_ctx);

    // Register data model
    amxb_register(bus_ctx, &dm);

    _dummy_main(0, &dm, &parser);

    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxm_close_all();

    amxo_resolver_import_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    test_unregister_dummy_be();

    return 0;
}

void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, "target_module", "../modules_under_test/target_module.so"), 0);
}

void test_has_correct_functions(UNUSED void** state) {
    assert_true(amxm_has_function("target_module", "ppp-ctrl", "update-config"));
    assert_true(amxm_has_function("target_module", "ppp-ctrl", "stop"));
    assert_true(amxm_has_function("target_module", "ppp-ctrl", "handle-script"));
    assert_true(amxm_has_function("target_module", "ppp-ctrl", "use-netdev-subscriptions"));
    assert_true(amxm_has_function("target_module", "ppp-ctrl", "use-timers"));
}

void test_use_netdev(UNUSED void** state) {
    amxc_var_t ret;
    amxc_var_t data;

    amxc_var_init(&ret);
    amxc_var_init(&data);

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "use-netdev-subscriptions", &data, &ret), 1);
    handle_events();

    amxc_var_clean(&data);
    amxc_var_clean(&ret);
}

void test_use_timers(UNUSED void** state) {
    amxc_var_t ret;
    amxc_var_t data;

    amxc_var_init(&ret);
    amxc_var_init(&data);

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "use-timers", &data, &ret), 1);
    handle_events();

    amxc_var_clean(&data);
    amxc_var_clean(&ret);
}

void test_stop(UNUSED void** state) {
    amxc_var_t ret;
    amxc_var_t data;

    amxc_var_init(&ret);
    amxc_var_init(&data);

    dummy_set_file(UCI_SET, "../common/data/set_config_proto_none.json", "network_wan");

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "stop", &data, &ret), 0);
    handle_events();

    amxc_var_clean(&data);
    amxc_var_clean(&ret);
}

void test_update_config(UNUSED void** state) {
    amxc_var_t ret;
    amxc_var_t* data;

    amxc_var_init(&ret);

    data = dummy_read_json_from_file("test_data/test_update_config.json");
    dummy_set_file(UCI_SET, "../common/data/test_update_config_enabled.json", "network_wan");

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "update-config", data, &ret), 0);
    handle_events();

    amxc_var_delete(&data);
    amxc_var_clean(&ret);
}

void test_handle_script(UNUSED void** state) {
    amxc_var_t ret;
    amxc_var_t* data;
    amxm_shared_object_t* so = amxm_get_so("self");
    amxm_module_t* mod = NULL;

    amxc_var_init(&ret);

    assert_non_null(so);
    assert_int_equal(amxm_module_register(&mod, so, MOD_CORE), 0);
    assert_int_equal(amxm_module_add_function(mod, "update-dm", dummy_func), 0);

    data = dummy_read_json_from_file("test_data/test_handle_script_up.json");

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "handle-script", data, &ret), 0);
    handle_events();
    amxc_var_delete(&data);

    data = dummy_read_json_from_file("test_data/test_handle_script_down.json");

    assert_int_equal(amxm_execute_function("target_module", "ppp-ctrl", "handle-script", data, &ret), 0);
    handle_events();

    amxc_var_delete(&data);
    amxc_var_clean(&ret);
}
