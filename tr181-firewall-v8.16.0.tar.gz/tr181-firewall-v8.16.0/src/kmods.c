/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE
#include <string.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/utsname.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include "kmods.h"

#define ME "connectiontracking"

#define finit_module(fd, param_values, flags) syscall(__NR_finit_module, fd, param_values, flags)
#define delete_module(name, flags) syscall(__NR_delete_module, name, flags)

static char* kernel_release_version = NULL;

void kmods_initialize(void) {
    struct utsname buf;

    when_failed_trace(uname(&buf), exit, ERROR, "Failed getting kernel information: %s", strerror(errno));
    when_str_empty_trace(buf.release, exit, ERROR, "Failed to get kernel release version");
    kernel_release_version = strdup(buf.release);

exit:
    return;
}

void kmods_cleanup(void) {
    free(kernel_release_version);
    kernel_release_version = NULL;
}

static char* get_absolute_path(const char* module_name) {
    amxc_string_t module_path;
    char* result = NULL;

    amxc_string_init(&module_path, 0);

    when_str_empty_trace(module_name, exit, ERROR, "Empty module name");
    when_str_empty_trace(kernel_release_version, exit, ERROR, "Empty kernel release version");

    amxc_string_setf(&module_path, "/lib/modules/%s/%s.ko", kernel_release_version, module_name);
    result = amxc_string_take_buffer(&module_path);

exit:
    amxc_string_clean(&module_path);
    return result;
}

int fw_load_kernel_module(const char* module_name, const char* options) {
    int fd = -1;
    int rv = -2;
    char* module_path = NULL;

    when_str_empty_trace(module_name, exit, ERROR, "Empty module name");
    module_path = get_absolute_path(module_name);
    when_str_empty_trace(module_path, exit, ERROR, "Could not get module path for module '%s'", module_name);

    SAH_TRACEZ_INFO(ME, "Loading kernel module '%s'", module_name);
    fd = open(module_path, O_RDONLY);
    when_false_trace(fd > 0, exit, ERROR, "Failed to open %s: %s", module_path, strerror(errno));

    rv = finit_module(fd, options, 0);
    when_failed_trace(rv, exit, ERROR, "Failed loading kernel module %s: %s", module_name, strerror(errno));
    rv = 0;

exit:
    free(module_path);
    if(fd >= 0) {
        close(fd);
    }
    return rv;
}

int fw_unload_kernel_module(const char* module_name, bool check_result) {
    int rv = -1;

    when_str_empty_trace(module_name, exit, ERROR, "Empty module_name");

    SAH_TRACEZ_INFO(ME, "Unloading kernel module %s", module_name);
    rv = delete_module(module_name, O_NONBLOCK);

    if(check_result) {
        when_failed_trace(rv, exit, ERROR, "Failed unloading module %s", module_name);
    } else {
        rv = 0;
    }

exit:
    return rv;
}
