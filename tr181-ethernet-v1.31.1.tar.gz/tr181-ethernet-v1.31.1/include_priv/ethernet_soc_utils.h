/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
   @file ethernet_soc_utils.h
   @brief Ethernet SoC utility API.

   This header provides utility functions for interacting with Ethernet SoC
   (System on Chip) features such as VLAN, MTU, LED, and power management.

   SPDX-License-Identifier: BSD-2-Clause-Patent
   Copyright (c) 2024 SoftAtHome
 */

#if !defined(__ETHERNET_MANAGER_SOC_UTILS_H__)
#define __ETHERNET_MANAGER_SOC_UTILS_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
   @brief Get the controller module name from an object.

   @param obj Pointer to the Ethernet object.
   @param ctrl_param Name of the controller parameter.
   @return Controller module name as a string, or NULL if not found.
 */
const char* mod_ctrl_get(amxd_object_t* obj, const char* ctrl_param);

/**
   @brief Execute a VLAN-related function on the Ethernet instance.

   @param function Name of the function to execute.
   @param ethernet Pointer to the Ethernet instance information.
   @return 0 on success, error code otherwise.
 */
int mod_vlan_execute_function(const char* function, ethernet_info_t* ethernet);

/**
   @brief Set the MTU for the Ethernet instance.

   @param ethernet Pointer to the Ethernet instance information.
   @return 0 on success, error code otherwise.
 */
int mod_ethernet_set_mtu(ethernet_info_t* ethernet);

/**
   @brief Set the LED state for the Ethernet instance.

   @param ethernet Pointer to the Ethernet instance information.
   @return 0 on success, error code otherwise.
 */
int mod_ethernet_set_led(ethernet_info_t* ethernet);

/**
   @brief Set the power mode for the Ethernet.Interface.* instance.

   @param ethernet Pointer to the Ethernet instance information.
   @param power_mode String representing the desired power mode.
   @return 0 on success, error code otherwise.
 */
int mod_ethernet_set_pwr_mode(ethernet_info_t* ethernet, const char* power_mode);

/**
   @brief Set the power state in the data model for the Ethernet.Interface.* instance.

   @param ethernet Pointer to the Ethernet instance information.
   @return 0 on success, error code otherwise.
 */
int dm_ethernet_soc_set_pwr(ethernet_info_t* ethernet);

#ifdef __cplusplus
}
#endif

#endif // __ETHERNET_MANAGER_SOC_UTILS_H__
