/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "test_helpers.h"

extern void AddPortMapping(void);
extern int CtrlPointSendAction(int service, const char* actionname,
                               const char** param_name, char** param_val, int param_count);

extern int gCtrlptHandle;
extern unsigned short gExternalPort;
extern const char* ServiceURN[];

/* Wrapers */
// All recured wrapers defined in test_add_any_port_mapping.c

/* Tests */
static void test_add_port_mapping_builds_params_and_sends(UNUSED void** state) {

    const int svc = SERVICE_WANPPPCONNECTION;
    gCtrlptHandle = 900;
    gExternalPort = 54321;
    snprintf(gListenPort, MAX_PORT_LEN, "%s", "6000");

    memset(&IGD, 0, sizeof(IGD));
    IGD.Updated = 1;
    strncpy(IGD.Service[svc].ControlURL, "http://router/pppctrl",
            sizeof(IGD.Service[svc].ControlURL) - 1);

    const char* acs_ip = "203.0.113.10";
    const char* our_ip = "192.0.2.5";
    will_return(__wrap_GetAmxAgentAcsIp, acs_ip);
    will_return(__wrap_GetAmxAgentIp4, our_ip);

    // Check for NewRemoteHost = acs_ip
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewRemoteHost");
    expect_string(__wrap_UpnpAddToAction, paramVal, acs_ip);
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    // Check for NewExternalPort = "54321"
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewExternalPort");
    expect_string(__wrap_UpnpAddToAction, paramVal, "54321");
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    // Check for NewProtocol = UPNP_PROTOCOL)
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewProtocol");
    expect_any(__wrap_UpnpAddToAction, paramVal);
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    // Check for NewInternalPort = gListenPort
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewInternalPort");
    expect_string(__wrap_UpnpAddToAction, paramVal, "6000");
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    // Check for NewInternalClient = our_ip
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewInternalClient");
    expect_string(__wrap_UpnpAddToAction, paramVal, our_ip);
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    // Check for NewLeaseDuration = DEFAULT_SERVICE_LEASE_TIME
    expect_string(__wrap_UpnpAddToAction, actionName, "AddPortMapping");
    expect_string(__wrap_UpnpAddToAction, serviceType, ServiceURN[svc]);
    expect_string(__wrap_UpnpAddToAction, paramName, "NewLeaseDuration");
    expect_any(__wrap_UpnpAddToAction, paramVal);
    will_return(__wrap_UpnpAddToAction, UPNP_E_SUCCESS);

    IXML_Document* fake_doc = (IXML_Document*) 0xBEEF;
    expect_value(__wrap_UpnpSendActionAsync, handle, gCtrlptHandle);
    expect_string(__wrap_UpnpSendActionAsync, ctrlURL, IGD.Service[svc].ControlURL);
    expect_string(__wrap_UpnpSendActionAsync, serviceType, ServiceURN[svc]);
    expect_value(__wrap_UpnpSendActionAsync, devUDN, (intptr_t) NULL);
    expect_value(__wrap_UpnpSendActionAsync, actionNode, (intptr_t) fake_doc);
    expect_any(__wrap_UpnpSendActionAsync, cb);
    expect_value(__wrap_UpnpSendActionAsync, cookie, (intptr_t) NULL);
    will_return(__wrap_UpnpSendActionAsync, UPNP_E_SUCCESS);

    AddPortMapping();
}

const struct CMUnitTest g_add_port_mapping_tests[] = {
    cmocka_unit_test(test_add_port_mapping_builds_params_and_sends),
};
const size_t g_add_port_mapping_count =
    sizeof(g_add_port_mapping_tests) / sizeof(g_add_port_mapping_tests[0]);
