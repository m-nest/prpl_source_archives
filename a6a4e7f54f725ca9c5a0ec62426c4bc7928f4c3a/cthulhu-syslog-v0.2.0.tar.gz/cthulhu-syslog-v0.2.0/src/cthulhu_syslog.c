/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_helpers.h>
#include <cthulhu/cthulhu_config.h>

#include <lcm/lcm_assert.h>
#include <lcm/amxc_data.h>
#include <debug/sahtrace.h>

#include "cthulhu_syslog.h"
#include "cthulhu_syslog_common.h"
#include "cthulhu_syslog_object.h"
#include "cthulhu_syslog_defines.h"

#define DEFAULT_LOG_LOCATION "/lcm/cthulhu/syslog"
#define SOCK_ALTERNATIVE_MOUNT_LOCATION "/run/log.sock"
#define SOCK_MOUNT_LOCATION "/dev/log"


static amxd_dm_t* dm = NULL;
static amxm_shared_object_t* so = NULL;
static amxm_module_t* mod = NULL;
/**
 * @brief Finds a container object by its ID.
 *
 * This function searches the data model for a container instance whose ID matches the given string.
 *
 * @param ctr_id The ID of the container to find.
 * @return Pointer to the found amxd_object_t, or NULL if not found.
 */
static inline amxd_object_t* ctr_get(const char* const ctr_id) {
    return amxd_dm_findf(dm, CTHULHU_DM_CONTAINER_INSTANCES ".[" CTHULHU_CONTAINER_ID "==\"%s\"].", ctr_id);
}

/**
 * @brief Retrieves the syslog plugin settings object from the given object.
 *
 * This function locates the syslog plugin settings within the provided object.
 *
 * @param obj The parent amxd_object_t from which to retrieve the syslog settings.
 * @return Pointer to the syslog plugin settings object, or NULL if not found.
 */
static inline amxd_object_t* cthulhu_syslog_get_plugin_settings(amxd_object_t* obj) {
    return amxd_object_findf(obj, SYSLOG ".");
}

/**
 * @brief Gets the syslog log location from the data model.
 *
 * This function retrieves the log location string from the syslog configuration in the data model.
 * If the log location is not defined, it returns a default value.
 *
 * @return Newly allocated string containing the log location. The caller is responsible for freeing it.
 */
static char* cthulhu_syslog_get_loglocation(void) {
    amxd_object_t* syslog_config;
    char* log_location = NULL;

    syslog_config = amxd_dm_findf(dm, CTHULHU_DM "." CTHULHU_CONFIG "." SYSLOG);
    ASSERT_NOT_NULL(syslog_config, goto exit);
    log_location = amxd_object_get_cstring_t(syslog_config, LOGLOCATION, NULL);
    if(STRING_EMPTY(log_location)) {
        SAH_TRACEZ_WARNING(ME, "Log Location is not defined in the datamodel");
        log_location = strdup(DEFAULT_LOG_LOCATION);
    }
exit:
    return log_location;
}

int cthulhu_syslog_init(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    dm = (amxd_dm_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_DATAMODEL);

    ASSERT_NOT_NULL(dm, return -1);

    return 0;
}

int cthulhu_syslog_cleanup(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {

    syslog_object_teardown();

    return 0;
}

/**
 * @brief Removes legacy log files from the legacy log location.
 *
 * This function checks if the legacy log directory exists and, if appropriate,
 * removes it to clean up old log files. It avoids removal if the current log location
 * matches the legacy location or if the log location is undefined.
 *
 * @param log_location The current log location path.
 * @return 0 on success or if no action is needed, -1 if log_location is undefined,
 *         or the result of cthulhu_rmdir on failure.
 */
static int remove_legacy_logs(const char* log_location) {
    if(cthulhu_isdir(LEGACY_LOG_LOCATION) == false) {
        return 0;
    }

    ASSERT_STR_NOT_EMPTY(log_location, return -1,
                         "Log location undefined: Legacy logs [%s] will not be purged", LEGACY_LOG_LOCATION);

    if(!strncmp(log_location, LEGACY_LOG_LOCATION, sizeof(LEGACY_LOG_LOCATION) - 1)) {
        return 0;
    }

    return cthulhu_rmdir(LEGACY_LOG_LOCATION);
}

/**
 * @brief Retrieves the alias of a container object.
 *
 * This function fetches the alias string property from the given container object.
 *
 * @param ctr_obj Pointer to the container amxd_object_t.
 * @return Newly allocated string containing the alias, or NULL if not found.
 *         The caller is responsible for freeing the returned string.
 */
static char* cthulhu_syslog_alias_get(amxd_object_t* ctr_obj) {
    return amxd_object_get_cstring_t(ctr_obj, CTHULHU_CONTAINER_ALIAS, NULL);
}

int cthulhu_syslog_odl_loaded(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    char* log_location = NULL;
    struct stat sb;

    ASSERT_SUCCESS(syslog_object_init(), goto exit);
    // Always expose lcm logs to /var/log/lcm/ regardless of lcm config
    // do not return error if creating the symlink fails
    res = 0;
    log_location = cthulhu_syslog_get_loglocation();
    ASSERT_STR_NOT_EMPTY(log_location, goto exit);
    remove_legacy_logs(log_location);
    if(!cthulhu_isdir(log_location)) {
        ASSERT_SUCCESS(cthulhu_mkdir(log_location, true), goto exit,
                       "Failed to create loglocation [%s]", log_location);
    }
    if(strcmp(log_location, LOG_LOCATION_SYMLINK) == 0) {
        // no need to create symlink
        goto exit;
    }

    if(stat(LOG_LOCATION_SYMLINK, &sb) < 0) {
        ASSERT_SUCCESS(symlink(log_location, LOG_LOCATION_SYMLINK), goto exit,
                       "Could not create logs link [%s->%s]", log_location, LOG_LOCATION_SYMLINK);
    }

    res = 0;
exit:
    free(log_location);
    return res;
}

static int cthulhu_syslog_store_refs(amxd_object_t* ctr_obj,
                                     const char* source_ref,
                                     const char* template_ref,
                                     const char* action_ref,
                                     const char* vendorlogfile_ref) {
    int res = -1;
    amxd_object_t* plugin_settings = NULL;
    amxd_trans_t trans;

    amxd_trans_init(&trans);

    plugin_settings = cthulhu_syslog_get_plugin_settings(ctr_obj);
    ASSERT_NOT_NULL(plugin_settings, goto exit, "Syslog config not found in datamodel");

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, plugin_settings);
    if(source_ref) {
        amxd_trans_set_cstring_t(&trans, SOURCEREF, source_ref);
    }
    if(template_ref) {
        amxd_trans_set_cstring_t(&trans, TEMPLATEREF, template_ref);
    }
    if(action_ref) {
        amxd_trans_set_cstring_t(&trans, ACTIONREF, action_ref);
    }
    if(vendorlogfile_ref) {
        amxd_trans_set_cstring_t(&trans, VENDORLOGFILEREF, vendorlogfile_ref);
    }
    res = amxd_trans_apply(&trans, dm);
    ASSERT_SUCCESS(res, goto exit, "Transaction failed. Err [%d]", res);
exit:
    amxd_trans_clean(&trans);
    return res;
}

/**
 * @brief Removes a specified substring from the end of a string if it matches.
 *
 * This function checks if the input string `src` ends with the substring `to_remove`.
 * If a match is found, it removes the suffix from `src` by modifying the string in place.
 * The function assumes that `src` is a null-terminated string.
 *
 * @param src Pointer to the source string to be modified. Must be null-terminated.
 * @param to_remove Pointer to the substring to remove from the end. Must be null-terminated.
 * @return Returns 0 if the substring was successfully removed, -1 otherwise
 */
static int string_remove_at_end(char* src, const char* to_remove) {
    if(strlen(src) < strlen(to_remove)) {
        return -1;
    }
    if(strncmp(&src[strlen(src) - strlen(to_remove)], to_remove, strlen(to_remove)) == 0) {
        src[strlen(src) - strlen(to_remove)] = '\0';
        return 0;
    }
    return -1;
}

static void syslog_action_changed_cb(UNUSED const char* const sig_name,
                                     const amxc_var_t* const data,
                                     void* const priv) {
    ASSERT_NOT_NULL(data, return );
    amxd_object_t* ctr_obj = (amxd_object_t*) priv;
    ASSERT_NOT_NULL(ctr_obj, return );
    const char* notification = GET_CHAR(data, "notification");
    ASSERT_STR_NOT_EMPTY(notification, return );
    ASSERT_STR_EQUAL_NL(notification, "dm:object-changed", return );
    amxc_var_t* parameters = GET_ARG(data, "parameters");
    ASSERT_NOT_NULL_NL(parameters, return );
    amxc_var_t* vendorlogref = GET_ARG(parameters, VENDORLOGFILEREF);
    ASSERT_NOT_NULL_NL(vendorlogref, return );
    const char* vendorlogref_new = GET_CHAR(vendorlogref, "to");
    const char* logfile_path = GET_CHAR(data, "path");
    if(!STRING_EMPTY(vendorlogref_new) && !STRING_EMPTY(logfile_path)) {
        char* action_path = strdup(logfile_path);
        if(string_remove_at_end(action_path, "." SYSLOG_LOGFILE ".") != 0) {
            string_remove_at_end(action_path, "." SYSLOG_LOGFILE);
        }
        ASSERT_SUCCESS(syslog_unsubscribe(action_path, syslog_action_changed_cb, ctr_obj),
                       NO_INSTRUCTION, "Failed to unsubscribe from [%s]", action_path);
        free(action_path);
    }

    cthulhu_syslog_store_refs(ctr_obj, NULL, NULL, NULL, vendorlogref_new);
}

int cthulhu_syslog_ctr_create(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    char* source_ref = NULL;
    char* action_ref = NULL;
    char* template_ref = NULL;
    char* vendorlogfile_ref = NULL;
    char* alias = NULL;
    amxc_string_t socket_dir;
    amxc_string_t socket_path;
    amxc_string_t log_path;
    amxc_string_t template;
    char* log_location = NULL;

    amxc_string_init(&socket_path, 0);
    amxc_string_init(&socket_dir, 0);
    amxc_string_init(&log_path, 0);
    amxc_string_init(&template, 0);

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_STR_NOT_EMPTY(ctr_id, goto exit, "Argument [%s] is not provided", CTHULHU_PLUGIN_ARG_CTR_ID);

    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit, "CTR[%s]: object not found in datamodel", ctr_id);

    alias = cthulhu_syslog_alias_get(ctr_obj);
    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    // add the syslog source
    ASSERT_SUCCESS(amxc_string_appendf(&socket_dir, SOCKET_LOCATION "/%s", ctr_id), goto exit, "CTR[%s]: Failed to create scocket_dir", ctr_id);
    cthulhu_mkdir_ext(amxc_string_get(&socket_dir, 0), 0, 0,
                      S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH, true);
    ASSERT_SUCCESS(amxc_string_appendf(&socket_path, FILE_PREFIX "%s/log.sock", amxc_string_get(&socket_dir, 0)),
                   goto exit, "CTR[%s]: Failed to create scocket_path", ctr_id);
    source_ref = syslog_source_configure(alias, amxc_string_get(&socket_path, 0), true);

    // add the syslog template
    ASSERT_SUCCESS(amxc_string_appendf(&template, "\"${FULLDATE} %s ${MSGHDR}${MSG}\n\"", ctr_id),
                   goto exit, "CTR[%s]: Failed to create template expression", ctr_id);
    template_ref = syslog_template_configure(alias, amxc_string_get(&template, 0));
    // add the syslog action

    log_location = cthulhu_syslog_get_loglocation();
    ASSERT_STR_NOT_EMPTY(log_location, goto exit);
    ASSERT_SUCCESS(amxc_string_appendf(&log_path, FILE_PREFIX "%s/%s/messages", log_location, ctr_id),
                   goto err_rm_source, "CTR[%s]: Failed to create log_path", ctr_id);
    action_ref = syslog_action_configure(alias, source_ref, template_ref,
                                         amxc_string_get(&log_path, 0));
    ASSERT_STR_NOT_EMPTY(action_ref, goto err_rm_source);

    vendorlogfile_ref = syslog_vendorlogfileref_get(alias);

    // store the source_ref and action_ref
    ASSERT_SUCCESS(cthulhu_syslog_store_refs(ctr_obj, source_ref, template_ref, action_ref, vendorlogfile_ref),
                   goto err_rm_action, "CTR[%s]: Failed to store SourceRef and ActionRef in the datamodel", ctr_id);

    // subscribe on the action_ref to get the VendorLogFileRef when it is set
    syslog_subscribe(action_ref, NULL, syslog_action_changed_cb, ctr_obj);

    res = 0;
    goto exit;
err_rm_action:
    syslog_object_del(action_ref);
err_rm_source:
    syslog_object_del(source_ref);
exit:
    free(log_location);
    free(source_ref);
    free(action_ref);
    free(template_ref);
    free(vendorlogfile_ref);
    free(alias);
    amxc_string_clean(&socket_path);
    amxc_string_clean(&socket_dir);
    amxc_string_clean(&log_path);
    amxc_string_clean(&template);
    return res;
}

int cthulhu_syslog_ctr_prestart(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    cthulhu_ctr_start_data_t* start_data = NULL;
    char* alias = NULL;
    char* socket_path = NULL;
    char* socket_path_wo_prefix = NULL;

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_NOT_NULL(ctr_id, goto exit);

    start_data = (cthulhu_ctr_start_data_t*) GET_DATA(args, CTHULHU_PLUGIN_ARG_START_DATA);
    ASSERT_NOT_NULL(start_data, goto exit);

    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit, "CTR[%s]: object not found in datamodel", ctr_id);

    alias = cthulhu_syslog_alias_get(ctr_obj);
    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    // get socketpath
    socket_path = syslog_socket_path_get(alias);
    ASSERT_STR_NOT_EMPTY(socket_path, goto exit, "CTR[%s]: SocketPath is empty", ctr_id);

    if(strncmp(socket_path, FILE_PREFIX, sizeof(FILE_PREFIX) - 1) == 0) {
        socket_path_wo_prefix = socket_path + sizeof(FILE_PREFIX) - 1;
    } else {
        socket_path_wo_prefix = socket_path;
    }

    if(!cthulhu_issocket(socket_path_wo_prefix)) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: Syslog did not create the log socket [%s]", ctr_id, socket_path_wo_prefix);
        goto exit;
    }
    if(cthulhu_ctr_start_data_add_mount_data(start_data, socket_path_wo_prefix, SOCK_ALTERNATIVE_MOUNT_LOCATION, NULL, NULL) < 0) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: Could not configure socket mount", ctr_id);
        goto exit;
    }
    if(cthulhu_ctr_start_data_add_mount_data(start_data, socket_path_wo_prefix, SOCK_MOUNT_LOCATION, NULL, NULL) < 0) {
        SAH_TRACEZ_ERROR(ME, "CTR[%s]: Could not configure socket mount", ctr_id);
        goto exit;
    }

    res = 0;

exit:
    if(res) {
        SAH_TRACEZ_ERROR(ME, "Error during cthulhu_syslog_ctr_prestart.\
         Syslog for this container will probably not be enabled.");
    }
    free(alias);
    free(socket_path);
    return res;
}

int cthulhu_syslog_ctr_poststop(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    char* alias = NULL;
    char* socket_path = NULL;

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_NOT_NULL(ctr_id, goto exit);

    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit, "CTR[%s]: object not found in datamodel", ctr_id);

    alias = cthulhu_syslog_alias_get(ctr_obj);
    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    // get socketpath
    socket_path = syslog_socket_path_get(alias);
    ASSERT_STR_NOT_EMPTY(socket_path, goto exit, "CTR[%s]: SocketPath is empty", ctr_id);

    res = 0;

exit:
    if(res) {
        SAH_TRACEZ_ERROR(ME, "Error during cthulhu_syslog_ctr_poststop.\
         If syslog was enabled for this container, it will probably not be disabled now.");
    }
    free(alias);
    free(socket_path);
    return res;
}

int cthulhu_syslog_ctr_preremove(UNUSED const char* function_name, UNUSED amxc_var_t* args, UNUSED amxc_var_t* ret) {
    int res = -1;
    const char* ctr_id = NULL;
    amxd_object_t* ctr_obj = NULL;
    amxd_object_t* plugin_settings = NULL;
    char* source_path = NULL;
    char* template_path = NULL;
    char* action_path = NULL;
    amxd_status_t status = amxd_status_ok;

    ctr_id = GET_CHAR(args, CTHULHU_PLUGIN_ARG_CTR_ID);
    ASSERT_NOT_NULL(ctr_id, goto exit);
    ctr_obj = ctr_get(ctr_id);
    ASSERT_NOT_NULL(ctr_obj, goto exit, "CTR[%s] not found in datamodel", ctr_id);

    plugin_settings = cthulhu_syslog_get_plugin_settings(ctr_obj);
    ASSERT_NOT_NULL(plugin_settings, goto exit, "CTR[%s] syslog config not found in datamodel", ctr_id);

    action_path = amxd_object_get_cstring_t(plugin_settings, ACTIONREF, &status);
    ASSERT_STR_NOT_EMPTY(action_path, NO_INSTRUCTION, "CTR[%s]: Action ref is empty", ctr_id);
    if(action_path) {
        syslog_object_del(action_path);
    }

    template_path = amxd_object_get_cstring_t(plugin_settings, TEMPLATEREF, &status);
    ASSERT_STR_NOT_EMPTY(template_path, NO_INSTRUCTION, "CTR[%s]: Template ref is empty", ctr_id);
    if(template_path) {
        syslog_object_del(template_path);
    }

    source_path = amxd_object_get_cstring_t(plugin_settings, SOURCEREF, &status);
    ASSERT_STR_NOT_EMPTY(source_path, NO_INSTRUCTION, "CTR[%s]: Source ref is empty", ctr_id);
    if(source_path) {
        syslog_object_del(source_path);
    }

    res = 0;

exit:
    if(res) {
        SAH_TRACEZ_ERROR(ME, "Error during cthulhu_syslog_ctr_preremove.\
         If syslog was configured for this container, the settings will \
         probably not be removed.");
    }
    free(source_path);
    free(template_path);
    free(action_path);
    return res;
}

static int register_function(const char* const func_name, amxm_callback_t cb) {
    ASSERT_SUCCESS(amxm_module_add_function(mod, func_name, cb), return -1,
                   "Could not add function [%s]", func_name);
    return 0;
}

AMXM_CONSTRUCTOR module_init(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu syslog constructor");
    int ret = 1;

    so = amxm_so_get_current();
    ASSERT_NOT_NULL(so, goto exit, "Could not get shared object");
    ASSERT_SUCCESS(amxm_module_register(&mod, so, CTHULHU_PLUGIN), goto exit,
                   "Could not register module %s", CTHULHU_PLUGIN);

    /* Init hook */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_INIT, cthulhu_syslog_init), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CLEANUP, cthulhu_syslog_cleanup), goto exit);

    /* Hooks template */
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_ODL_LOADED, cthulhu_syslog_odl_loaded), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_CREATE, cthulhu_syslog_ctr_create), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_PRESTART, cthulhu_syslog_ctr_prestart), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_POSTSTOP, cthulhu_syslog_ctr_poststop), goto exit);
    ASSERT_SUCCESS(register_function(CTHULHU_PLUGIN_CTR_PREREMOVE, cthulhu_syslog_ctr_preremove), goto exit);

    ret = 0;
exit:
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu syslog constructor");
    return ret;
}

AMXM_DESTRUCTOR module_exit(void) {
    SAH_TRACEZ_INFO(ME, ">>> Cthulhu syslog destructor");
    SAH_TRACEZ_INFO(ME, "<<< Cthulhu syslog destructor");
    return 0;
}
