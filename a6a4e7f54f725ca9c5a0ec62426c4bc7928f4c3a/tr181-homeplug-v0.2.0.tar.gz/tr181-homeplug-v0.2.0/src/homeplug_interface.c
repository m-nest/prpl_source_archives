/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "homeplug.h"
#include "dm_homeplug.h"

static amxc_htable_t homeplug_interfaces;

/**
   @brief Creates a new HomePlug interface structure.

   Allocates and initializes a @c homeplug_interface_t structure using the
   parameters provided in @p params. Copies the interface name and, if
   available, the underlying interface identifier.

   @param params Pointer to a parameter object containing at least the "Name" key.
                 Optionally, the "Interface" key may be provided.

   @return Pointer to the newly created @c homeplug_interface_t on success,
           or @c NULL on failure.
 */
static homeplug_interface_t* create_interface(amxc_var_t* params) {
    homeplug_interface_t* interface = NULL;
    const char* interface_name = GET_CHAR(params, "Name");
    const char* interface_interface = GET_CHAR(params, "Interface");
    SAH_TRACEZ_INFO(ME, "create interface name: %s", interface_name);
    when_str_empty_trace(interface_name, error, ERROR, "cannot create interface with empty name");
    interface = calloc(1, sizeof(homeplug_interface_t));
    when_null_trace(interface, error, ERROR, "Out of memory");
    interface->name = strdup(interface_name);
    when_null_trace(interface->name, error, ERROR, "Out of memory");
    if(interface_interface != NULL) {
        interface->interface = strdup(interface_interface);
        when_null_trace(interface->interface, error_interface, ERROR, "Out of memory");
    } else {
        interface->interface = strdup(""); // Always initialize as empty string
        when_null_trace(interface->interface, error_interface, ERROR, "Out of memory");
    }
    return interface;

error_interface:
    free(interface->name);
error:
    free(interface);
    interface = NULL;
    return interface;
}

/**
   @brief Callback invoked to delete a HomePlug interface retrieved from a hash table iterator.

   Frees the memory allocated for the @c homeplug_interface_t structure,
   including its @c name and @c interface members.

   @param key   The key associated with the hash table entry (Unused).
   @param it    Iterator pointing to the hash table entry containing the interface.
 */
static void delete_interface_it(const char* key UNUSED, amxc_htable_it_t* it) {
    homeplug_interface_t* interface = amxc_htable_it_get_data(it, homeplug_interface_t, it);
    when_null_trace(interface, error, ERROR, "interface is a NULL pointer");
    free(interface->name);
    free(interface->interface);
    free(interface);
error:
    return;
}

void homeplug_interface_send_discovery_request(void) {
    SAH_TRACEZ_INFO(ME, "send_discovery_request");
    amxc_htable_for_each(it, &homeplug_interfaces) {
        homeplug_interface_t* interface = amxc_htable_it_get_data(it, homeplug_interface_t, it);
        if(interface && interface->sock) {
            homeplug_socket_send_discovery_request(interface->sock);
        }
    }
}

void homeplug_interface_up_cb(UNUSED const char* sig_name,
                              const amxc_var_t* data,
                              void* priv) {

    amxc_var_t* var_param = NULL;
    const char* dev_name = NULL;
    homeplug_interface_t* interface = (homeplug_interface_t*) priv;
    when_null_trace(data, exit, ERROR, "NULL data in interface up callback");
    when_null_trace(interface, exit, ERROR, "NULL interface pointer");
    bool up = GET_BOOL(data, NULL);
    SAH_TRACEZ_INFO(ME, "interface up cb up: %d", up);
    if(up) {
        var_param = netmodel_getParameters(interface->interface, "NetDevName", "bridge netdev", "down");
        var_param = netmodel_getFirstParameter(interface->interface, "NetDevName", "bridge netdev", "down");
        when_null_trace(var_param, exit, ERROR, "var is NULL");
        dev_name = GET_CHAR(var_param, NULL);
        SAH_TRACEZ_INFO(ME, "interface dev name: %s", dev_name);
        when_str_empty_trace(dev_name, exit, ERROR, "Empty interface dev_name");
        interface->sock = homeplug_socket_new(dev_name);
        when_null_trace(interface->sock, exit, ERROR, "Can not create new socket");
        interface->sock->interface = interface;
        interface->up = true;

    } else {
        homeplug_socket_delete(interface->sock);
        interface->sock = NULL;
        interface->up = false;
    }
exit:
    amxc_var_delete(&var_param);
    return;
}

void homeplug_interface_disable(homeplug_interface_t* interface) {
    SAH_TRACEZ_INFO(ME, "interface disable");
    when_null_trace(interface, exit, ERROR, "NULL interface pointer");
    if(interface->enabled) {
        netmodel_closeQuery(interface->up_query);
        interface->up_query = NULL;
        amxc_llist_clean(&interface->active_devices, amxc_string_list_it_free);
        if(interface->up) {
            homeplug_socket_delete(interface->sock);
        }
    }
    interface->sock = NULL;
    interface->up = false;
    interface->enabled = false;
exit:
    return;
}

bool homeplug_interface_enable(homeplug_interface_t* interface) {
    bool res = false;
    SAH_TRACEZ_INFO(ME, "interface enable");
    when_null_trace(interface, exit, ERROR, "NULL interface pointer");
    if(!interface->enabled) {
        amxc_llist_init(&interface->active_devices);
        interface->up_query = netmodel_openQuery_isUp(interface->interface,
                                                      ME,
                                                      "netdev and bridge and netdev-bound",
                                                      "down",
                                                      homeplug_interface_up_cb,
                                                      (void*) interface);
        when_null_trace(interface->up_query, exit, ERROR, "can not open query for interface: %s", interface->interface);
    }
    interface->enabled = true;
    res = true;
exit:
    return res;
}

homeplug_interface_t* homeplug_interface_create(const char* key, amxc_var_t* params) {
    homeplug_interface_t* interface = NULL;
    SAH_TRACEZ_INFO(ME, "homeplug interface create");
    when_str_empty_trace(key, exit, ERROR, "empty key");
    interface = create_interface(params);
    when_null_trace(interface, exit, ERROR, "can not create interface %s", key);
    if(amxc_htable_insert(&homeplug_interfaces, key, &interface->it) != 0) {
        SAH_TRACEZ_ERROR(ME, "failed to insert interface %s into hash table", key);
        free(interface);
        interface = NULL;
    }
exit:
    return interface;
}
void homeplug_interface_delete(const char* key) {
    amxc_htable_it_t* it = NULL;
    SAH_TRACEZ_INFO(ME, "homeplug interface delete");
    when_str_empty_trace(key, exit, ERROR, "empty key");
    it = amxc_htable_get(&homeplug_interfaces, key);
    when_null_trace(it, exit, INFO, "delete non yet enabled interface");
    homeplug_interface_t* interface = amxc_htable_it_get_data(it, homeplug_interface_t, it);
    when_null_trace(interface, exit, ERROR, "interface is a NULL pointer");
    homeplug_interface_disable(interface);
    amxc_htable_it_clean(it, delete_interface_it);
exit:
    return;
}

void homeplug_interface_initialize(void) {
    amxc_htable_init(&homeplug_interfaces, 0);
}

void homeplug_interface_cleanup(void) {
    amxc_htable_for_each(it, &homeplug_interfaces) {
        const char* key = amxc_htable_it_get_key(it);
        homeplug_interface_delete(key);
    }
}

bool homeplug_interface_add_activedevice(homeplug_interface_t* interface,
                                         const uint8_t* device_mac) {

    bool result = false;
    amxc_string_t* active_device = NULL;
    SAH_TRACEZ_INFO(ME, "homeplug interface add activedevice");
    amxc_string_new(&active_device, strlen((const char*) device_mac) + 1);
    when_null_trace(active_device, exit, ERROR, "Out of mem");
    amxc_string_set(active_device, (const char*) device_mac);
    amxc_llist_append(&interface->active_devices, &active_device->it);
    result = true;
exit:
    return result;
}

void homeplug_interface_cleanup_inactive_devices(void) {
    SAH_TRACEZ_INFO(ME, "homeplug interface cleanup inactive devices");
    amxc_htable_for_each(it, &homeplug_interfaces) {
        homeplug_interface_t* interface = amxc_htable_it_get_data(it, homeplug_interface_t, it);
        // cleanup check is only done when interface is up, means for now detected devices stays in
        // the data model when interface is down (homeplug disabled, or interface disabled).
        // They are not removed when interface becomes down.
        // Decision subject to change
        if(interface && interface->up) {
            dm_interface_cleanup_inactive_devices(interface->interface_obj,
                                                  &interface->active_devices);
            amxc_llist_clean(&interface->active_devices, amxc_string_list_it_free);
        }
    }
}

