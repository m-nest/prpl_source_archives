/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxm/amxm.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <cthulhu/cthulhu.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_defines_plugin.h>

#include "cthulhu_networking.h"
#include "cthulhu_networking_defines.h"

#include "test_import.h"
#include "test_setup.h"

#undef ME
#define ME "test"

int test_setup(UNUSED void** state) {
    networking_init("networking_init", NULL, NULL);
    return 0;
}

int test_teardown(UNUSED void** state) {
    module_exit();
    return 0;
}


void test_cthulhu_networking_ctr_import_full_nc(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* imported_data = NULL;
    const char* ctr_import_data = "ctr_import_data_full_nc.json";

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    assert_non_null(imported_data = test_read_json_from_file(ctr_import_data));
    amxc_var_set_key(&args, CTHULHU_PLUGIN_ARG_IMPORT_DATA, imported_data, AMXC_VAR_FLAG_COPY);
    assert_int_equal(networking_ctr_import("networking_ctr_import", &args, &ret), amxd_status_ok);


    amxc_var_t* nc = GET_ARG(&ret, CTHULHU_CONTAINER_NETWORKCONFIG);
    assert_non_null(nc);
    amxc_var_t* acc_intfs = GET_ARG(nc, NC_ACCESSINTERFACES);
    assert_non_null(acc_intfs);
    assert_string_equal(GETP_CHAR(acc_intfs, "0." NC_ACCESSINTERFACES_REFERENCE), "Lan");
    assert_string_equal(GETP_CHAR(acc_intfs, "1." NC_ACCESSINTERFACES_REFERENCE), "Wan");
    amxc_var_t* port_forward = GET_ARG(nc, NC_PORTFORWARDING);
    assert_non_null(port_forward);
    assert_string_equal(GETP_CHAR(port_forward, "0." NC_PORTFORWARDING_INTERFACE), "Lan");
    assert_int_equal(GETP_UINT32(port_forward, "0." NC_PORTFORWARDING_INTERNALPORT), 123);
    assert_int_equal(GETP_UINT32(port_forward, "0." NC_PORTFORWARDING_EXTERNALPORT), 321);
    assert_string_equal(GETP_CHAR(port_forward, "0." NC_PORTFORWARDING_PROTOCOL), "TCP");
    amxc_var_t* dnssd = GET_ARG(nc, NC_DNSSD);
    assert_non_null(dnssd);
    assert_int_equal(GETP_BOOL(dnssd, "0." NC_DNSSD_ENABLE), 1);
    assert_string_equal(GETP_CHAR(dnssd, "0." NC_DNSSD_INTERFACE), "Device.IP.Interface.1.");
    assert_string_equal(GETP_CHAR(dnssd, "0." NC_DNSSD_INSTANCENAME), "IDK");
    assert_string_equal(GETP_CHAR(dnssd, "0." NC_DNSSD_APPLICATIONPROTOCOL), "daap");
    assert_string_equal(GETP_CHAR(dnssd, "0." NC_DNSSD_TRANSPORTPROTOCOL), "TCP");
    assert_string_equal(GETP_CHAR(dnssd, "0." NC_DNSSD_DOMAIN), "local");
    assert_int_equal(GETP_UINT32(dnssd, "0." NC_DNSSD_PORT), 456);
    assert_int_equal(GETP_UINT32(dnssd, "0." NC_DNSSD_INTERNALPORT), 678);
    amxc_var_t* text_record = GETP_ARG(dnssd, "0." NC_DNSSD_TEXTRECORD);
    assert_non_null(text_record);
    assert_string_equal(GETP_CHAR(text_record, "0." NC_DNSSD_TEXTRECORD_KEY), "Plugin");
    assert_string_equal(GETP_CHAR(text_record, "0." NC_DNSSD_TEXTRECORD_VALUE), "Networking");

    amxc_var_delete(&imported_data);
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
}

void test_cthulhu_networking_ctr_import_absent_nc(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* imported_data = NULL;
    const char* ctr_import_data = "ctr_import_data_absent_nc.json";

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    assert_non_null(imported_data = test_read_json_from_file(ctr_import_data));
    amxc_var_set_key(&args, CTHULHU_PLUGIN_ARG_IMPORT_DATA, imported_data, AMXC_VAR_FLAG_COPY);
    assert_int_equal(networking_ctr_import("networking_ctr_import", &args, &ret), amxd_status_ok);


    amxc_var_t* nc = GET_ARG(&ret, CTHULHU_CONTAINER_NETWORKCONFIG);
    assert_null(nc);

    amxc_var_delete(&imported_data);
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
}

void test_cthulhu_networking_ctr_import_parent_network(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* imported_data = NULL;
    const char* ctr_import_data = "ctr_import_data_parent_network.json";

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    assert_non_null(imported_data = test_read_json_from_file(ctr_import_data));
    amxc_var_set_key(&args, CTHULHU_PLUGIN_ARG_IMPORT_DATA, imported_data, AMXC_VAR_FLAG_COPY);
    assert_int_equal(networking_ctr_import("networking_ctr_import", &args, &ret), amxd_status_ok);


    amxc_var_t* nc = GET_ARG(&ret, CTHULHU_CONTAINER_NETWORKCONFIG);
    assert_non_null(nc);
    bool share_network = GET_BOOL(nc, NC_SHAREPARENTNETWORK);
    assert_true(share_network);

    amxc_var_delete(&imported_data);
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
}
