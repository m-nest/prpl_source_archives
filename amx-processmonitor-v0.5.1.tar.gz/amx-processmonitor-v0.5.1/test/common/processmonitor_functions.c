/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>

#include "mock_amx.h"
#include "processmonitor_functions.h"

static bool custom_return = true;
bool real_perform_test = false;

// mock functions
static bool mock_pm_perform(test_t* test) {
    test->has_result = true;
    switch(test->type) {
    case PM_TEST_TYPE_PLUGIN:
        if(strcmp(test->subject, "VoiceService") == 0) {
            test->result = true;
            return true;
        }
        test->result = false;
        return false;
        break;
    case PM_TEST_TYPE_PROCESS:
        if(strcmp(test->subject, "7777") == 0) {
            test->result = true;
        } else {
            test->result = false;
        }
        return true;
        break;
    case PM_TEST_TYPE_CUSTOM:
        if(test->process) {
            return true;
        }
        test->result = false;
        return false;
        break;
    default:
        return false;
        break;
    }
}

// wrapped functions
void __wrap_pm_perform_test(test_t* test, processmonitor_batch_test_t* pm_batch_test) {
    // simulate current_test_interval expiration
    // to trigger full test perform
    struct tm origin = {0};
    amxc_ts_from_tm(&test->last_check, &origin);

    if(real_perform_test) {
        __real_pm_perform_test(test, pm_batch_test);
        return;
    }

    if(!pm_check_if_perform_test(test)) {
        printf("Test %s not performed \n", test->name);
        return;
    }

    test->active = true;
    test->has_result = false;
    test->result = false;
    test->fail_action_executed = false;

    if(test->funcs->perform != NULL) {
        mock_pm_perform(test);
    } else {
        test->has_result = true;
    }

    if(test->has_result) {
        pm_handle_result(test);
    }
}

void __wrap_pm_initialize_test(test_t* test) {
    pm_set_initialized(test);
}

void set_custom_return(bool ret) {
    custom_return = ret;
}

//function to check test criterias with Custom Jobs - verify test success when return exit code is 0/failure when its != 0
void pm_test_helper_custom(test_t* test, amxc_var_t* data) {
    if(test->funcs->provide != NULL) {
        test->funcs->provide(test);
    }
    real_perform_test = true;
    processmonitor_t* pm = pm_get_process_monitor();
    pm_perform_test(test, &pm->processmonitor_batch_test);
    test->active = true;
    amxb_trigger_custom_cb(data, (void*) test);
    if(test->funcs->release != NULL) {
        test->funcs->release(test);
    }
    real_perform_test = false;
    return;
}

//function to check test failure with Plugin getting timed out - Initialize/Provide/perform/Timeout call followed by verification on test module
void pm_test_helper_plugins(test_t* test) {
    set_amxb_bus_obj_off();
    if(test->funcs->initialize != NULL) {
        test->funcs->initialize(test);
    }
    if(test->funcs->provide != NULL) {
        test->funcs->provide(test);
    }
    real_perform_test = true;
    processmonitor_t* pm = pm_get_process_monitor();
    pm_perform_test(test, &pm->processmonitor_batch_test);
    test->active = true;

    set_amxb_bus_obj_on();

    amxb_trigger_plugin_init_cb((void*) test);
    amxb_trigger_plugin_cb((void*) test);
    real_perform_test = false;
    if(test->funcs->timed_out != NULL) {
        test->funcs->timed_out(test);
    }
    if(test->funcs->release != NULL) {
        test->funcs->release(test);
    }
    return;
}

//function to check test failure with Process getting failed with real test perform() call - Initialize/Provide/perform/release call followed by verification on test module
void pm_test_helper_process(test_t* test) {
    if(test->funcs->initialize != NULL) {
        test->funcs->initialize(test);
    }
    if(test->funcs->provide != NULL) {
        test->funcs->provide(test);
    }

    real_perform_test = true;
    processmonitor_t* pm = pm_get_process_monitor();
    pm_perform_test(test, &pm->processmonitor_batch_test);

    if(test->funcs->release != NULL) {
        test->funcs->release(test);
    }

    real_perform_test = false;
}
