/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "sfp.h"

/* System headers */
#include <string.h>

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>      /* needed by amxd_transaction.h */
#include <amxd/amxd_transaction.h>
#include <amxp/amxp_slot.h>        /* needed by amxb.h */
#include <amxb/amxb.h>             /* amxb_bus_ctx_t */

/* Own headers */
#include "xpon_mngr.h"  /* xpon_mngr_get_dm() */
#include "xpon_trace.h"


/**
 * Update XPON.ONU.1.ANI.1.Transceiver.1.X_PRPLWARE-COM_SFPReference if needed.
 *
 * @param[in] spath: path to Transceiver instance in SFP DM, e.g.
 *                   "SFPs.Cage.1.SFP.Transceiver."
 * @param[in] data: variant with old and new value of @c SFPCategory.
 *
 * The function updates
 * @c XPON.ONU.1.ANI.1.Transceiver.1.X_PRPLWARE-COM_SFPReference. It sets it
 * to "SFPs.Cage.1.SFP.Transceiver." if the @c SFPCategory is "SFP_XGSPON" or
 * "SFP_GPON", else it sets the parameter to the empty string.
 */
static void sfp_category_changed(UNUSED const char* const spath, const amxc_var_t* const data, UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_ERROR(ME, "####sfp category changed cb started");
    const char* new_state = NULL;
    const char* old_state = NULL;
    int status = -1;

    amxc_var_t str_val;
    amxd_trans_t trans;

    amxc_var_init(&str_val);
    amxd_trans_init(&trans);

    amxc_var_set_type(&str_val, AMXC_VAR_ID_CSTRING);

    amxd_dm_t* dm = xpon_mngr_get_dm();

    when_null_trace(data, exit, ERROR, "input arg data is NULL");
    when_null_trace(spath, exit, ERROR, "Arg spath is NULL");

    old_state = GETP_CHAR(data, "parameters.SFPCategory.from");
    new_state = GETP_CHAR(data, "parameters.SFPCategory.to");
    when_null_trace(old_state, exit, ERROR, "SFPCategory old state is NULL");
    when_null_trace(new_state, exit, ERROR, "SFPCategory new state is NULL");

    SAH_TRACEZ_INFO(ME, "SFP State changed from %s to %s", old_state, new_state);
    amxd_object_t* xpon_intf_object = amxd_dm_findf(dm, "XPON.ONU.1.ANI.1.Transceiver.1");
    when_null_trace(xpon_intf_object, exit, ERROR, "xpon interface object is NULL");

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    status = amxd_trans_select_object(&trans, xpon_intf_object);
    when_failed_trace(status, exit, ERROR,
                      "amxd_trans_select_object() failed: status=%d", status);

    if(strcmp(new_state, "SFP_XGSPON") == 0) {
        amxc_var_set_cstring_t(&str_val, spath);
        SAH_TRACEZ_INFO(ME, "Setting SFPReference param, detecting the SFP_XGSPON");
    } else if(strcmp(new_state, "SFP_GPON") == 0) {
        amxc_var_set_cstring_t(&str_val, spath);
        SAH_TRACEZ_INFO(ME, "Setting SFPReference param, detecting the SFP_GPON");
    } else {
        amxc_var_set_cstring_t(&str_val, "");
        SAH_TRACEZ_INFO(ME, "Clearing SFPReference param, detecting the sfp plugout.");
    }
    amxd_trans_set_param(&trans, "X_PRPLWARE-COM_SFPReference", &str_val);

    status = amxd_trans_apply(&trans, dm);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "%s : %d : Issue in trans apply", __func__, __LINE__);
    } else {
        SAH_TRACEZ_INFO(ME, "%s : %d : Eth Intf sfp reference changed", __func__, __LINE__);
    }

exit:
    amxd_trans_clean(&trans);
    amxc_var_clean(&str_val);
    SAH_TRACEZ_OUT(ME);
}

/************************************************************
*@brief subscribe_to_sfp()
*
* @detail subscribe to sfp notification when ever SFP Type
* and event changes
*
* @retVal returns 0 if success
*          return 1 if fail
* **********************************************************/
static int subscribe_to_sfp(void) {
    int ret = amxd_status_unknown_error;
    amxb_bus_ctx_t* ctx = amxb_be_who_has("SFPs.");
    when_null_trace(ctx, exit, ERROR, "Failed to get bus context");

    SAH_TRACEZ_INFO(ME, "####subscribe_to_sfp");

    /* Subscribe to sfp to handle SFPCategory param changes.
       Currently there's only 1 Cage supported
       This code needs to be optimized when multiple Cages come into picture */
    ret = amxb_subscribe(ctx, "SFPs.Cage.1.SFP.Transceiver.",
                         "notification in ['dm:object-changed'] && contains('parameters.SFPCategory')",
                         sfp_category_changed, NULL);

    if(ret != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR(ME, "###Failed to subscribe SFP object. \n");
        return ret;
    } else {
        SAH_TRACEZ_INFO(ME, "####Successfully subscribed to SFP\n");
        ret = 0;
    }
exit:
    return ret;
}

/**
 * @brief wait_sfps_objects_cb
 *
 * @details Callback function that handles the signal for Device.SFPs.
 *          It disconnects the slot, subscribes to SFP, and initializes the usage stats timer.
 *
 * @param[in] signal The signal received (unused).
 * @param[in] data The data variable (unused).
 * @param[in] priv The private data (unused).
 *
 * @return void
 */
static void wait_sfps_objects_cb(UNUSED const char* const signal,
                                 UNUSED const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    rv = amxp_slot_disconnect(NULL, "wait:SFPs.", wait_sfps_objects_cb);
    when_failed_trace(rv, exit, ERROR, "Failed to slot disconnect: %d", rv);

    when_failed_trace(subscribe_to_sfp(), exit, ERROR, "subscribe_to_sfp failed");

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief wait_for_depending_objects
 *
 * @details Initializes the waiting process for dependent objects NetDev and Device.SFPs.
 *          It connects slots with filtered signals and waits for the specified objects.
 *
 * @param[in] None
 *
 * @return int Returns 0 on success, or an error code on failure.
 */
static int wait_for_depending_objects(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    rv = amxp_slot_connect_filtered(NULL, "wait:SFPs.", NULL, wait_sfps_objects_cb, NULL);
    when_failed_trace(rv, exit, ERROR, "Failed to wait for SFPs to be available: %d", rv);
    rv = amxb_wait_for_object("SFPs.");
    when_failed_trace(rv, exit, ERROR, "Failed to wait for SFPs: %d", rv);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief dependent_app_start
 *
 * @details Entry point function that starts the application.
 *          It initializes the waiting process for dependent objects.
 *
 */
void dependent_app_start(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;

    rv = wait_for_depending_objects();
    when_failed_trace(rv, exit, ERROR, "Failed to wait for depending objects: %d", rv);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}
