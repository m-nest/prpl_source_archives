/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2026 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


/**
 * @file service.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contains Process Manager logic for start/stop service.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2026 Inango
 *
 */

#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxp/amxp_syssig.h>
#include <amxp/amxp_subproc.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "service.h"

#define ME "svc"                     /*!< File name for SAH Logger. Highlights service source file */

#define PRPLMESH_DIR "/opt/prplmesh" /*!< Path to the prplMesh files in prplOS device */

/**
 * @brief Helper function returning init system's service name for given ServiceKind enum
 *
 * @param service ServiceKind enum value to be converted
 *
 * @return string containing service's name in init system
 */
static const char* service_kind_to_service_name(ServiceKind service) {

#if defined(INIT_SYSTEM_PROCD)
    switch(service) {
    case SERVICE_KIND_PWHM:     return "prplmesh_whm";
    case SERVICE_KIND_SENSING:  return "wifi-sensing";
    case SERVICE_KIND_PRPLMESH: return "prplmesh";
    default:  return NULL;
    }

    return NULL;
#elif defined(INIT_SYSTEM_SYSTEMD)
#error object_path_to_service_name is not implemented for systemd
#endif

}

/**
 * @brief Helper function returning init system's action name for given ServiceAction enum
 *
 * @param action ServiceAction enum value to be converted
 *
 * @return string containing action name in init system
 */
static const char* service_action_to_str(ServiceAction action) {
    switch(action) {
    case SERVICE_ACTION_STOP:                  return "stop";
    case SERVICE_ACTION_START:                 return "start";
    default: return NULL;
    }

    return NULL;
}

typedef struct {
    amxp_subproc_t* proc;
    ServiceKind service;
    service_control_cb_t* user_cb;
} AsyncData;

static void service_control_signal_handler(UNUSED const char* const sig_name,
                                           const amxc_var_t* const data,
                                           void* const priv) {
    AsyncData* ctx = (AsyncData*) priv;
    when_null_trace(ctx, exit, ERROR, "signal handler context is NULL");

    amxc_var_t* var_code = GET_ARG(data, "ExitCode");
    if(!var_code) {
        SAH_TRACEZ_INFO(ME, "signal without ExitCode data, ignoring, keep waiting");
        return;
    }

    int64_t ret_code = amxc_var_dyncast(int64_t, var_code);
    if(ctx->user_cb) {
        ServiceControlResult result = {
            .service = ctx->service,
            .ret_code = ret_code,
        };
        ctx->user_cb(result);
    }

exit:
    if(ctx) {
        amxp_subproc_delete(&(ctx->proc));
        free(ctx);
    }
    return;
}

/**
 * @brief Worker function for launching commands in amxp subprocesses,
 *        with optional callback support on exit signal
 *
 * @param argv String array containing command and arguments
 * @param wait_for_child If true function will be blocking and wait for child process to finish
 *                       If false function will run child asynchronously, with callback called on child exit, if specified
 * @param service  information that will be passed to callback, on which ServiceKind operation was performed
 * @param callback optional callback for asynchronous use, will be called after childs finished.
 *        May be NULL
 *
 * @return Child's exit code value for calls with wait_for_child = true
 *         0 for calls with wait_for_child = false
 */
static int run_command(const char** argv, bool wait_for_child, ServiceKind service, service_control_cb_t callback) {
    int retval = -1;
    SAH_TRACEZ_INFO(ME, "run command: (%s)", argv[0]);
    amxp_subproc_t* proc = NULL;
    AsyncData* data = NULL;

    amxp_subproc_new(&proc);

    if(!wait_for_child) {
        data = malloc(sizeof(AsyncData));

        when_null_trace(data, exit, ERROR, "Failed to allocate memory for async data");

        data->proc = proc;
        data->service = service;
        data->user_cb = callback;

        retval = amxp_slot_connect(amxp_subproc_get_sigmngr(proc), "stop", NULL,
                                   service_control_signal_handler, data);

        if(retval) {
            free(data);
            SAH_TRACEZ_WARNING(ME, "'stop' slot connect failed: retval (%d)", retval);
            goto exit;
        }
    }

    int status = amxp_subproc_vstart(proc, (char**) argv);
    if(status) {
        SAH_TRACEZ_ERROR(ME, "Failed to start subprocess: '%s'", argv[0]);
        free(data);
        goto exit;
    }

    if(!wait_for_child) {
        return 0;
    }

    status = amxp_subproc_wait(proc, -1);
    when_failed_trace(status, exit, ERROR, "Failed to wait for subprocess: '%s'", argv[0]);
    when_false_trace(amxp_subproc_ifexited(proc), exit, ERROR, "Failed to get exit status of subprocess");

    retval = amxp_subproc_get_exitstatus(proc);

exit:
    amxp_subproc_delete(&proc);

    return retval;
}

/**
 * @brief Handles transitioning services between states
 *
 * @param service Service on which operation will be performed
 * @param action Operation to be performed
 * @param callback Optional callback to process exit code of finished operation
 *
 * @return 0 if operation was successfully started
 */
int process_monitor_service_control(ServiceKind service, ServiceAction action, service_control_cb_t callback) {
    int status = -1;

    when_true_trace(service == SERVICE_KIND_INVALID, exit, ERROR, "invalid service");
    const char* name = service_kind_to_service_name(service);
    when_null_trace(name, exit, WARNING, "failed to get service name for service %d", service);

    const char* action_str = service_action_to_str(action);
    when_null_trace(action_str, exit, WARNING, "Failed to get action string for action %d", action);

    SAH_TRACEZ_INFO(ME, "Acting on '%s' (%s)", name, action_str);

#if defined(INIT_SYSTEM_PROCD)
    const char* argv[] = {
        "service",
        name,
        action_str,
        NULL,
    };
#elif defined(INIT_SYSTEM_SYSTEMD)
    const char* argv[] = {
        "systemctl",
        action_str,
        name,
        NULL,
    };
#endif
    status = run_command(argv, false, service, callback);
    if(status) {
        SAH_TRACEZ_WARNING(ME, "Failed to run action '%s' on '%s', got %d", action_str, name, status);
    }
exit:
    return status;
}

/**
 * @brief Struct describes pattern for pgrep tool for each service.
 *
 */
typedef struct PgrepArgs {
    const char* pattern; /*!< Process name pattern for pgrep tool */
    bool full_proc_name; /*!< Full process name or not */
} PgrepArgs;

/**
 * @brief Helper function returning running process name for given ServiceKind enum
 *
 * @param service ServiceKind enum value to be converted
 *
 * @return string containing process name in the system
 */
static PgrepArgs service_to_pgrep_args(ServiceKind service) {
    switch(service) {
    case SERVICE_KIND_PWHM:
        return (PgrepArgs) {.pattern = "wld"};

    case SERVICE_KIND_SENSING:
        return (PgrepArgs) {.pattern = "wifi-sensing"};

    case SERVICE_KIND_PRPLMESH:
        /* pattern copied from ${PRPLMESH_DIR}/scripts/prplmesh_utils.sh main_agent_operational function */
        return (PgrepArgs) {.pattern = PRPLMESH_DIR "/bin/beerocks_agent($|[[:blank:]])", .full_proc_name = true};

    default:
        return (PgrepArgs) {0};
    }

    return (PgrepArgs) {0};
}

/**
 * @brief Function to get live status of service
 *
 * @param service Service to check live status of
 *
 * @return SERVICE_STATUS_RUNNING if process is found
 *         SERVICE_STATUS_IDLE if no process found
 */
ServiceStatus process_monitor_service_status(ServiceKind service) {
    ServiceStatus retval = SERVICE_STATUS_ERROR;

    when_true_trace(service == SERVICE_KIND_INVALID, exit, ERROR, "invalid service");

    const PgrepArgs pgrep = service_to_pgrep_args(service);

    // Use of pgrep is a temporary solution,
    // "service <service> status" command will be used
    // once relevant components are switched to procd
    const char* argv[] = {
        "pgrep",
        pgrep.full_proc_name ? "-fx" : "-x",
        pgrep.pattern,
        NULL,
    };

    SAH_TRACEZ_INFO(ME, "running '%s' with option '%s' and pattern '%s'", argv[0], argv[1], argv[2]);

    int exit_code = run_command(argv, true, service, NULL);
    when_true_trace(exit_code < 0, exit, ERROR, "failed to run command '%s'", argv[0]);

    SAH_TRACEZ_INFO(ME, "service '%s': pgrep status '%d';", argv[2], exit_code);

    if(exit_code == 0) {
        retval = SERVICE_STATUS_RUNNING;
    } else if(exit_code == 1) {
        retval = SERVICE_STATUS_IDLE;
    } else {
        retval = SERVICE_STATUS_IDLE;
        SAH_TRACEZ_WARNING(ME, "Got error pgrep exit code '%d'", exit_code);
    }

exit:

    return retval;
}

