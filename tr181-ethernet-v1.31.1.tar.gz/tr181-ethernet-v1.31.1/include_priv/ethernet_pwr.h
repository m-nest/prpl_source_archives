/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
   @file ethernet_pwr.h
   @brief Declares the asynchronous Ethernet power mode transition API.

   This header declares the data-model side of the Ethernet power management
   flow. It exposes the asynchronous ChangePowerMode RPC handler and the
   completion callback used to finalize a deferred request after the selected
   power controller reports completion.

   SPDX-License-Identifier: BSD-2-Clause-Patent
   Copyright (c) 2025 SoftAtHome
 */

#if !defined(__ETHERNET_MANAGER_PWR_H__)
#define __ETHERNET_MANAGER_PWR_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>

/**
   @brief Handle the asynchronous `ChangePowerMode` data-model RPC.

   The function validates the requested target state, creates a deferred RPC,
   starts a timeout timer, and forwards the request to the selected power
   controller. The final result is completed later by
   `ethernet_async_change_power_mode_status_set_done`.

   @param object Data-model object on which the RPC was invoked.
   @param func Function descriptor used to create the deferred call.
   @param args Input arguments containing the requested `PowerState`.
   @param ret Return value container used for the deferred response.
   @return `amxd_status_deferred` when the asynchronous operation starts
           successfully, or an error status when setup fails.
 */
amxd_status_t _ChangePowerMode(amxd_object_t* object,
                               amxd_function_t* func,
                               amxc_var_t* args,
                               amxc_var_t* ret);

/**
   @brief Complete a deferred ChangePowerMode request.

   This callback is invoked through the internal `pwr-async-done` AMXM function
   after the low-level power controller finishes its platform-specific work. On
   success, it updates the interface `PowerStatus` and completes the deferred
   RPC.

   @param function_name Name of the invoked function, unused.
   @param args Callback arguments, unused.
   @param ret Return value container, unused.
   @return `amxd_status_ok` on successful completion, `amxd_status_timeout`
           when no request is pending, or another error code on failure.
 */
int ethernet_async_change_power_mode_status_set_done(const char* function_name,
                                                     amxc_var_t* args,
                                                     amxc_var_t* ret);
#ifdef __cplusplus
}
#endif

#endif // __ETHERNET_MANAGER_PWR_H__
