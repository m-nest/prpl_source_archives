/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "hostsquery/query.h"
#include "hostsquery/subscription.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

static amxc_htable_t* queries = NULL;

static void extract_ipaddress(amxc_var_t* var, amxc_llist_t* ipaddr, bool ipv4) {
    amxc_var_t* tmp = NULL;
    const char* str_ipaddr = NULL;
    const char* addr_key = ipv4 ? HOSTS_PARAM_IPV4 : HOSTS_PARAM_IPV6;

    when_null(var, exit);
    when_null(ipaddr, exit);

    amxc_llist_clean(ipaddr, amxc_string_list_it_free);
    amxc_llist_init(ipaddr);
    tmp = GET_ARG(var, addr_key);
    amxc_var_for_each(addr, tmp) {
        str_ipaddr = GET_CHAR(addr, HOSTS_PARAM_IPADDRESS);
        if(STRING_EMPTY(str_ipaddr)) {
            continue;
        }
        amxc_llist_add_string(ipaddr, str_ipaddr);
    }

exit:
    return;
}

static void handle_hosts_change_cb(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   void* const priv) {
    amxc_var_t ret;
    int result = -1;
    hosts_query_impl_t* impl = (hosts_query_impl_t*) priv;

    amxc_var_init(&ret);

    when_null_trace(impl, exit, ERROR, "Query impl struct is NULL");

    get_hosts_variant(&ret, amxc_string_get(&impl->hosts_path, 0));

    when_failed(amxc_var_compare(&ret, &impl->last_result, &result), exit);
    when_true(result == 0, exit);

    amxc_var_copy(&impl->last_result, &ret);
    extract_ipaddress(&impl->last_result, &impl->ipv4_addresses, true);
    extract_ipaddress(&impl->last_result, &impl->ipv6_addresses, false);

    amxc_llist_for_each(it, &impl->cbs) {
        hosts_query_cb_t* cb = amxc_container_of(it, hosts_query_cb_t, it);
        cb->handler(sig_name, data, cb->userdata);
    }
exit:
    amxc_var_clean(&ret);
    return;
}

static void normalize_hosts_path(amxc_string_t* str, const char* hosts_path) {
    int length = -1;
    int i = -1;

    when_null(str, exit);

    amxc_string_clean(str);

    when_str_empty(hosts_path, exit);
    amxc_string_setf(str, "%s", hosts_path);

    amxc_string_replace(str, "Device.", "", UINT32_MAX);
    length = amxc_string_text_length(str);
    when_false(length >= 2, exit); // Valid path for this function should be something that contains at least a character + '.', thus a length of 2
    i = length - 1;
    when_false(str->buffer[i] == '.', exit);

    /* If there is a previous character and it is a '.', go to that */
    while(i > 0 && str->buffer[i - 1] == '.') {
        i--;
    }
    when_true(i <= 0, exit); //To avoid removing the whole string
    amxc_string_remove_at(str, i, UINT32_MAX);

exit:
    return;
}

static hosts_query_cb_t* hosts_query_cb_new(hosts_callback_t handler, void* userdata) {
    hosts_query_cb_t* q_cb = NULL;

    when_null(handler, exit);

    q_cb = (hosts_query_cb_t*) calloc(1, sizeof(hosts_query_cb_t));
    when_null_trace(q_cb, exit, ERROR, "Failed to allocate hosts_query_cb_t");
    q_cb->handler = handler;
    q_cb->userdata = userdata;

exit:
    return q_cb;
}

static int hosts_query_cb_delete(hosts_query_cb_t** q_cb) {
    int rv = -1;

    when_null(q_cb, exit);
    when_null(*q_cb, exit);
    amxc_llist_it_clean(&(*q_cb)->it, NULL);
    FREE(*q_cb);
    rv = 0;
exit:
    return rv;
}

static void hosts_query_impl_init(hosts_query_impl_t* query_impl, const char* hosts_path) {
    when_null(query_impl, exit);

    amxc_string_init(&query_impl->hosts_path, 0);
    amxc_string_setf(&query_impl->hosts_path, "%s", hosts_path);
    amxc_var_init(&query_impl->last_result);
    amxc_llist_init(&query_impl->ipv4_addresses);
    amxc_llist_init(&query_impl->ipv6_addresses);
    amxc_llist_init(&query_impl->queries);
    amxc_llist_init(&query_impl->cbs);
    amxc_htable_it_init(&query_impl->it);
    query_impl->ref_count = 0;
exit:
    return;
}

static void hosts_query_impl_clean(hosts_query_impl_t* query_impl) {
    when_null(query_impl, exit);

    amxb_subscription_delete(&query_impl->result);
    amxc_htable_it_clean(&query_impl->it, NULL);
    amxc_string_clean(&query_impl->hosts_path);
    amxc_var_clean(&query_impl->last_result);
    amxc_llist_clean(&query_impl->ipv4_addresses, amxc_string_list_it_free);
    amxc_llist_clean(&query_impl->ipv6_addresses, amxc_string_list_it_free);
    amxc_llist_clean(&query_impl->queries, NULL);
    amxc_llist_clean(&query_impl->cbs, NULL);
    query_impl->ref_count = 0;
exit:
    return;
}

static hosts_query_impl_t* hosts_query_impl_new(const char* hosts_path) {
    amxc_htable_it_t* it_queries = NULL;
    hosts_query_impl_t* q = NULL;
    amxc_string_t* str_hosts_path = NULL;

    amxc_string_new(&str_hosts_path, 0);

    when_str_empty(hosts_path, exit);
    normalize_hosts_path(str_hosts_path, hosts_path);

    it_queries = amxc_htable_get(queries, amxc_string_get(str_hosts_path, 0));
    if(it_queries == NULL) {
        q = (hosts_query_impl_t*) calloc(1, sizeof(hosts_query_impl_t));
        when_null_trace(q, exit, ERROR, "Failed to allocate hosts_query_impl_t");
        hosts_query_impl_init(q, amxc_string_get(str_hosts_path, 0));
        amxc_htable_insert(queries, amxc_string_get(str_hosts_path, 0), &q->it);
    } else {
        q = amxc_htable_it_get_data(it_queries, hosts_query_impl_t, it);
    }
    when_null(q, exit);

    if(q->result == NULL) {
        subscribe_to_hosts_path(&q->result, amxc_string_get(str_hosts_path, 0), handle_hosts_change_cb, q, &q->last_result);
        extract_ipaddress(&q->last_result, &q->ipv4_addresses, true);
        extract_ipaddress(&q->last_result, &q->ipv6_addresses, false);
    }
exit:
    amxc_string_delete(&str_hosts_path);
    return q;
}

static int hosts_query_impl_delete(hosts_query_impl_t** query_impl) {
    int rv = -1;

    when_null(query_impl, exit);
    when_null(*query_impl, exit);

    hosts_query_impl_clean(*query_impl);
    FREE(*query_impl);

    rv = 0;
exit:
    return rv;
}

hosts_query_t* hosts_openQuery(const char* hosts_path, hosts_callback_t handler, void* userdata) {
    hosts_query_t* query = NULL;
    amxc_string_t* str_hosts_path = NULL;

    amxc_string_new(&str_hosts_path, 0);

    when_str_empty(hosts_path, exit);
    normalize_hosts_path(str_hosts_path, hosts_path);

    query = (hosts_query_t*) calloc(1, sizeof(hosts_query_t));
    when_null_trace(query, exit, ERROR, "Failed to allocate hosts_query_t");

    query->cb = hosts_query_cb_new(handler, userdata);
    if(query->cb == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to create hosts_query_cb_t");
        FREE(query);
        goto exit;
    }

    query->impl = hosts_query_impl_new(amxc_string_get(str_hosts_path, 0));
    if(query->impl == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to create hosts_query_impl_t");
        hosts_query_cb_delete(&query->cb);
        FREE(query);
        goto exit;
    }

    amxc_llist_append(&query->impl->cbs, &query->cb->it);
    amxc_llist_append(&query->impl->queries, &query->it);
    query->impl->ref_count++;

exit:
    amxc_string_delete(&str_hosts_path);
    return query;
}

int hosts_closeQuery(hosts_query_t* query) {
    int rv = -1;

    when_null(query, exit);
    when_null(query->cb, exit);
    when_null(query->impl, exit);

    amxc_llist_it_clean(&query->it, NULL);
    hosts_query_cb_delete(&query->cb);

    if(query->impl->ref_count <= 1) {
        hosts_query_impl_delete(&query->impl);
    } else {
        query->impl->ref_count--;
        query->impl = NULL;
    }

    rv = 0;
exit:
    return rv;
}