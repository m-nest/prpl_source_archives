/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __ROUTING_POLICY_EVENTS_H__
#define __ROUTING_POLICY_EVENTS_H__

#include "common.h"

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   @brief
   Header file which includes the event handlers for the Routing.Policy object
 */

/**
 * @defgroup routing_policy_events Routing Policy Event Handlers
 * @ingroup tr181-routing
 * @brief Event handler functions for Routing.Policy instance objects.
 * @{
 */

/**
 * @brief Event handler for when a Routing.Policy instance object is added.
 *
 * This function is called when a new Routing.Policy instance object is added.
 *
 * @param sig_name Name of the event.
 * @param data Pointer to the event data.
 * @param priv Pointer to private user data.
 */
void _routing_policy_added(const cstring_t const sig_name,
                           const amxc_var_t* const data,
                           void* const priv);

/**
 * @brief Event handler for when the enable status of a Routing.Policy instance object changes.
 *
 * This function is called when the enable status of a Routing.Policy instance object changes.
 *
 * @param sig_name Name of the event.
 * @param data Pointer to the event data.
 * @param priv Pointer to private user data.
 */
void _routing_policy_enable_changed(const cstring_t const sig_name,
                                    const amxc_var_t* const data,
                                    void* const priv);

/**
 * @brief Event handler for when a Routing.Policy instance object is changed.
 *
 * This function is called when a Routing.Policy instance object is modified.
 *
 * @param sig_name Name of the event.
 * @param data Pointer to the event data.
 * @param priv Pointer to private user data.
 */
void _routing_policy_changed(const cstring_t const sig_name,
                             const amxc_var_t* const data,
                             void* const priv);

/**
 * @brief Action handler for when a Routing.Policy instance object is deleted.
 *
 * This function is called when a Routing.Policy instance object is deleted.
 *
 * @param object Pointer to the Routing.Policy instance object being deleted.
 * @param param Pointer to the parameter associated with the deletion.
 * @param reason Reason that this action handler was called. Should be action_object_destroy.
 * @param args Pointer to additional arguments.
 * @param retval Pointer to a variant containing the return value.
 * @param priv Pointer to private user data.
 * @return AMXD_STATUS_OK on success, or an error code on failure.
 */
amxd_status_t _routing_policy_deleted(amxd_object_t* object,
                                      amxd_param_t* param,
                                      amxd_action_t reason,
                                      const amxc_var_t* const args,
                                      amxc_var_t* const retval,
                                      void* priv);

/** @} */ // end of routing_policy_events group

#ifdef __cplusplus
}
#endif

#endif //__ROUTING_POLICY_EVENTS_H__
