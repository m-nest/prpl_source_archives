﻿# **TR-181 LED Manager**
- [Specification](#tr181ledmanager-specification) 
  - [Use Cases](#tr181ledmanager-usecases)
  - [Introduction](#tr181ledmanager-introduction)
- [Architecture](#tr181ledmanager-architecture) 
  - [Design](#tr181ledmanager-design)
- [Implementation](#tr181ledmanager-implementation) 
  - [Data Model](#tr181ledmanager-datamodel)
  - [API](#tr181ledmanager-api)
  - [Files](#tr181ledmanager-files)
  - [Firewall](#tr181ledmanager-firewall)
  - [Dependants and dependencies](#tr181ledmanager-dependantsanddependencies)
  - [Dependencies](#tr181ledmanager-dependencies)
  - [Configuration](#tr181ledmanager-configuration)
  - [Backup/Restore, Upgrade, Reset](#tr181ledmanager-backup/restore,upgrade,reset)
  - [Web UI](#tr181ledmanager-webui)
- [Considerations](#tr181ledmanager-considerations) 
  - [IPv6](#tr181ledmanager-ipv6)
  - [Packet Acceleration](#tr181ledmanager-packetacceleration)
  - [Memory Usage](#tr181ledmanager-memoryusage)
  - [Boot Time](#tr181ledmanager-boottime)
  - [Security](#tr181ledmanager-security)
  - [Remote Management](#tr181ledmanager-remotemanagement)
  - [Operational Monitoring](#tr181ledmanager-operationalmonitoring)
- [Quality](#tr181ledmanager-quality) 
  - [Project Reference Configuration](#tr181ledmanager-projectreferenceconfiguration)
  - [Build-time Checks](#tr181ledmanager-build-timechecks)
  - [Run-time Checks](#tr181ledmanager-run-timechecks)
  - [Unit Tests](#tr181ledmanager-unittests)
  - [Logging and Debugging](#tr181ledmanager-logginganddebugging)
  - [Functional Tests](#tr181ledmanager-functionaltests)
  - [Validation Test Plan](#tr181ledmanager-validationtestplan)
- [Design Review Documentation](#tr181ledmanager-designreviewdocumentation)
# <a name="tr181ledmanager-specification"></a>**Specification**
## <a name="tr181ledmanager-usecases"></a>**Use Cases**

It must be possible to manage several LEDs on a given hardware.

It must be possible to control a monochrome LED (single color) via HL APIs :

- turn on/off
- set brightness between 0 and 100% 
  - 0 is equivalent to turning off
  - 100 means the brightness is set to the maximum value
- blink 
  - blink frequency must be configurable (e.g. slow vs fast blinking)
  - on/off duration must be configurable individually (e.g. 50/50 or 80/20)
- pulse (if supported by the LED driver) 
  - pulse frequency must be configurable (e.g. slow pulse vs fast pulse)
  - increasing/decreasing duration must be configurable individually (e.g. 50/50 or 80/20)
  - pulse intensity must be configurable (e.g. from 20% to 80% brightness)

A multi-color LED must be controlled the same way as monochrome LEDs, additionally it must be possible to change its color. Depending on the low level implementation, a multi-color LED may be modeled differently :

- as a single entity. In that case, it must be possible to set the color explicitely
- as an overlay of several monochrome LEDs. In that case, setting the color must be achieved by turning on/off and/or setting brightness of each invidual LEDs 
  - when an overlay is used, blink and pulse must be synchronized to ensure a proper visual experience.

LED management must not impact the hardware performance :

- blink and pulse modes must be handled by the low level driver (not in userspace) 
  - in case multi-color LEDs are modeled as an overlay, synchronization must also be handled by the low level driver
- if HW acceleration is supported, it should be used

It must be possible to get the current state of the LEDs via an HL API. In case multi-color LEDs are modeled as an overlay, the state must reflect the end user experience (e.g. in case of an overlay of red and blue, it must be possible to infer that the LED color is purple).
## <a name="tr181ledmanager-introduction"></a>**Introduction**
# <a name="tr181ledmanager-architecture"></a>**Architecture**
## <a name="tr181ledmanager-design"></a>**Design**

# <a name="tr181ledmanager-implementation"></a>**Implementation** 
## <a name="tr181ledmanager-datamodel"></a>**Data Model**
|**Name**|**Type**|**W/P/V**|**Description**|**Legal Values/Default**|**Action on Add/Delete/Modify**|**Version**|
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
|**LEDs**|**Object**|**RWP**|**This object describes the LEDs on the device.**|**–**|** |**1.0**|
|Suspend|bool|RW|Switches on or off all LED devices.|**default**: false|–|1\.0|
|LEDNumberOfEntries|uint32|RW|The number of entries in the LED table.|**default**:|–|1\.0|
|**LEDs.LED.{i}**|**Object**|**RW**|**Each instance of this object describes an LED on the device.**|**–**|** |**1.0**|
|Alias|string|RW|Alias A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.|**default**:|–|1\.0|
|Enable|bool|RW|Switches on or off the power of the LED.|**default**: 1|–|2\.19|
|Name|string|RW|The internal name used to identify this LED.|**default**:|–|1\.0|
|Status|string|R|The status of the LED. Enumeration of: - Disabled (The LED is currently not in use). - InUse (The LED is currently being used by the CPE). - Controlled (Indicates that the LED is controlled from an electronic circuit which cannot be monitored). - Error (The LED status cannot be determined by the CPE).|**default**: Disabled|–|1\.0|
|Reason|string|R|The textual purpose that represents the visual display of the LED (e.g., Broadband Down).|**default**:|–|1\.0|
|CyclePeriodRepetitions|int32|RW|The number of cycle periods left for this LED. As each cycle period is completed this parameter is reduced by 1. A value of -1 indicates an infinite number of cycle period repetitions.|**default**: 0|–|1\.0|
|Location|string|R|The location of the LED as the user looks at the front of the device in its typical orientation (e.g., on-end, flat). Enumeration of: - Front - Back - Left - Right - Top - Bottom|**default**: Front|–|1\.0|
|RelativeXPosition|uint32|R|The relative x position of the LED from left to right and top to bottom as the user looks at the device from the orientation identified in the Location parameter in its typical orientation(e.g., on-end, flat).|**default**:|–|1\.0|
|RelativeYPosition|uint32|R|The relative y position of the LED from left to right and top to bottom as the user looks at the device from the orientation identified in the Location parameter in its typical orientation(e.g., on-end, flat).|**default**:|–|1\.0|
|MaxBrightness|int32|R|The maximum brightness value that can be set for this led, initialized with the value of max\_brightness in the sysfs|**default**: -1|–|2\.19|
|CycleElementNumberOfEntries|uint32|RW|The number of entries in the CycleElement table.|**default**:|–|1\.0|
|**LEDs.LED.{i}.CycleElement.{i}**|**Object**|**RW**|**Each instance of this object describes the LED characteristics for a portion of the LED cycle period.**|**–**|** |**1.0**|
|Alias|string|RW|Alias A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.|**default**:|–|1\.0|
|Enable|bool|RW|Enables or disables this CycleElement instance.|**default**:|–|1\.0|
|Order|uint32|RW|The relative order of this CycleElement in the LED's cycle period.|**default**:|–|1\.0|
|Color|string|RW|The color being displayed by the LED RGB hexadecimal notation (e.g., FF0088). Note: If the parameter is set to an unsupported color the CPE MUST NOT infer a different color.|**default**:|–|1\.0|
|Brightness|int32|RW|The brightness being set to the LEDs in percentage, or -1 if not changed Note: If MaxBrightness < 0 for a LED, its brightness is not changed|**default**: -1|–|2\.19|
|Duration|uint32|RW|The duration, in milliseconds, for this element of the cycle period.|**default**:|–|1\.0|
|FadeInterval|uint32|RW|The interval corresponding to this CycleElement instance, in milliseconds, from the starting from the target illumination characteristics of the previous CycleElement instance to the target illumination characteristics of this CycleElement instance.|**default**:|–|1\.0|
|**LEDs.LED.{i}.ULED.{i}**|**Object**|**RW**|** |**–**|** |**0.8.3-3-g6f6b8de**|
|LEDReference|string|RW| |**default**:|–|0\.8.3-3-g6f6b8de|
|SupportedColor|string|RW| |**default**:|–|0\.8.3-3-g6f6b8de|
|**LEDs.LED.{i}.CurrentCycleElement**|**Object**|**RW**|**This object describes the status of the current cycle element for this LED.**|**–**|** |**1.0**|
|CycleElementReference|string|RW|<p>This object describes the current properties of the CycleElement.</p><p>Unknown macro: {i}</p><p>object instance that is currently active.</p>|**default**:|–|1\.0|
## <a name="tr181ledmanager-api"></a>**API**
## <a name="tr181ledmanager-files"></a>**Files**
## <a name="tr181ledmanager-firewall"></a>**Firewall**
## <a name="tr181ledmanager-dependantsanddependencies"></a>**Dependants and dependencies**
N/A
## <a name="tr181ledmanager-dependencies"></a>**Dependencies**
## <a name="tr181ledmanager-configuration"></a>**Configuration**
## <a name="tr181ledmanager-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
## <a name="tr181ledmanager-webui"></a>**Web UI** 
# <a name="tr181ledmanager-considerations"></a>**Considerations**
## <a name="tr181ledmanager-ipv6"></a>**IPv6** 
N/A
## <a name="tr181ledmanager-packetacceleration"></a>**Packet Acceleration** 
N/A
## <a name="tr181ledmanager-memoryusage"></a>**Memory Usage**
## <a name="tr181ledmanager-boottime"></a>**Boot Time**
## <a name="tr181ledmanager-security"></a>**Security** 
The plugin execute with the tr181\_app user and drop all the capabilities except :

- CAP\_DAC\_OVERRIDE : To write in /sys/class/leds


## <a name="tr181ledmanager-remotemanagement"></a>**Remote Management** 
N/A
## <a name="tr181ledmanager-operationalmonitoring"></a>**Operational Monitoring**
N/A
# <a name="tr181ledmanager-quality"></a>**Quality** 
## <a name="tr181ledmanager-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="tr181ledmanager-build-timechecks"></a>**Build-time Checks** 
## <a name="tr181ledmanager-run-timechecks"></a>**Run-time Checks**
## <a name="tr181ledmanager-unittests"></a>**Unit Tests** 
## <a name="tr181ledmanager-logginganddebugging"></a>**Logging and Debugging** 
## <a name="tr181ledmanager-functionaltests"></a>**Functional Tests** 
## <a name="tr181ledmanager-validationtestplan"></a>**Validation Test Plan** 
# <a name="tr181ledmanager-designreviewdocumentation"></a>**Design Review Documentation**
N/A
