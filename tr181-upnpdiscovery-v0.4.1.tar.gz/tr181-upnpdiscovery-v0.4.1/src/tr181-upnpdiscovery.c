/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <upnp/upnp.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/client.h>
#include <amxc/amxc_macros.h>
#include <amxb/amxb.h>
#include <amxm/amxm.h>
#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"

#define ME "upnpdiscovery"
amxc_string_t lan_intf;

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxm_shared_object_t* so;
    amxc_llist_t* lan_addrs_list;
} app_t;

static app_t app;
static netmodel_query_t* lan_query;

inline amxd_dm_t* get_dm(void) {
    return app.dm;
}

inline amxo_parser_t* get_parser(void) {
    return app.parser;
}

inline amxc_var_t* get_config(void) {
    amxo_parser_t* parser = get_parser();
    return parser != NULL ? &(parser->config) : NULL;
}

inline amxc_llist_t* get_lan_addrs(void) {
    return app.lan_addrs_list;
}

inline const char* get_lan_intf(void) {
    return amxc_string_get(&lan_intf, 0);
}

static int init(amxd_dm_t* dm, amxo_parser_t* parser) {
    int rv = -1;

    memset(&app, 0, sizeof(app));
    app.dm = dm;
    app.parser = parser;
    amxc_llist_new(&app.lan_addrs_list);

    when_false_trace(netmodel_initialize(), exit, ERROR, "Failed to initialize libnetmodel!");
    amxc_string_init(&lan_intf, 0);
    rv = upnp_discovery_init();
exit:
    return rv;
}

static void clean_lan_range_it(amxc_llist_it_t* it) {
    lan_range_t* range = amxc_llist_it_get_data(it, lan_range_t, it);
    ipat_cleanup(&range->range);
    free(range);
}

static int cleanup(void) {
    netmodel_closeQuery(lan_query);
    upnp_discovery_stop();
    upnp_discovery_cleanup();

    netmodel_cleanup();
    app.dm = NULL;
    app.parser = NULL;
    amxc_llist_delete(&app.lan_addrs_list, clean_lan_range_it);
    amxc_string_clean(&lan_intf);
    return 0;
}

void lan_addr_changed(const char* sig_name, const amxc_var_t* data, UNUSED void* priv) {
    lan_range_t* range = NULL;

    if(GETP_ARG(data, "0.NetDevName")) {
        amxc_string_setf(&lan_intf, "%s", GETP_CHAR(data, "0.NetDevName"));
        upnp_discovery_start();
    }
    SAH_TRACEZ_INFO(ME, "lan_addr_changed signame: %s", sig_name);
    amxc_llist_clean(get_lan_addrs(), clean_lan_range_it);
    amxc_var_for_each(addr, data) {
        range = malloc(sizeof(*range));
        if(!range) {
            continue;
        }
        memset(range, 0, sizeof(*range));
        ipat_initialize(&range->range);
        ipat_pton(&range->range, AF_INET_ANY, GET_CHAR(addr, "Address"));
        ipat_set_prefix_length(&range->range, GET_UINT32(addr, "PrefixLen"));
        if(ipat_valid(&range->range)) {
            SAH_TRACEZ_NOTICE(ME, "Adding %s %s/%u to IPAT LAN range list", GET_CHAR(addr, "Family"), GET_CHAR(addr, "Address"), GET_UINT32(addr, "PrefixLen"));
            amxc_llist_append(get_lan_addrs(), &range->it);
        } else {
            SAH_TRACEZ_ERROR(ME, "%s entry %s/%u to IPAT did not result in a valid result", GET_CHAR(addr, "Family"), GET_CHAR(addr, "Address"), GET_UINT32(addr, "PrefixLen"));
            ipat_cleanup(&range->range);
            free(range);
        }
    }
    return;
}

static void start_stop_discovery(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    if(GETP_BOOL(data, "parameters.Enable") && (lan_query == NULL)) {
        when_str_empty_trace(GET_CHAR(get_config(), "ip_intf_lan"), exit, ERROR, "ip_intf_lan odl's variable isn't set");
        lan_query = netmodel_openQuery_getAddrs(GET_CHAR(get_config(), "ip_intf_lan"), "tr181-upnpdiscovery", "ipv4", "down", lan_addr_changed, NULL);
        when_null_trace(lan_query, exit, ERROR, "");
    } else {
        netmodel_closeQuery(lan_query);
        lan_query = NULL;
        upnp_discovery_stop();
    }
exit:
    return;
}

void _app_start(UNUSED const char* const sig_name,
                UNUSED const amxc_var_t* const data,
                UNUSED void* const priv) {
    amxb_bus_ctx_t* ctx = amxb_be_who_has("UPnP.");
    amxc_var_t ret;
    int rv = 0;

    SAH_TRACEZ_NOTICE(ME, "app-start");
    amxc_var_init(&ret);
    when_null(ctx, exit);
    when_str_empty_trace(GET_CHAR(get_config(), "ip_intf_lan"), exit, ERROR, "ip_intf_lan odl's variable isn't set");
    when_failed_trace((rv = amxb_subscribe(ctx, "UPnP.Device.", "notification == 'dm:object-changed' && contains('parameters.Enable')", start_stop_discovery, NULL)), exit, ERROR, "Couldn't subscribe to UPnP.Device.Enable (%d)", rv);
    when_failed_trace((rv = amxb_get(ctx, "UPnP.Device.", 0, &ret, 1)), exit, ERROR, "Couldn't amxb_get UPnP.Device. (%d)", rv);
    if(GETP_BOOL(&ret, "0.'UPnP.Device.'.Enable") && (lan_query == NULL)) {
        lan_query = netmodel_openQuery_getAddrs(GET_CHAR(get_config(), "ip_intf_lan"), "tr181-upnpdiscovery", "ipv4", "down", lan_addr_changed, NULL);
    }
exit:
    amxc_var_clean(&ret);
}

int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 0;
    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "entrypoint - start");
        retval = init(dm, parser);
        break;

    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "entrypoint - stop");
        retval = cleanup();
        break;
    }

    return retval;
}
