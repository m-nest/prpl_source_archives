#!/bin/sh

# Iterate over all USB devices in /sys/bus/usb/devices using find with while loop
find /sys/ -name uevent -perm +444 -exec grep -l "DEVTYPE=usb_device" {} + | while IFS= read -r uevent; do
    # Extract required environment variables dynamically for USB devices
    SUBSYSTEM="usb"
    DEVTYPE=$(grep "DEVTYPE="  "${uevent}" | cut -d'=' -f2)
    DEVPATH=$(dirname "${uevent}")
    BUSNUM=$(cat "${DEVPATH}/busnum" 2>/dev/null)
    DEVPATH=$(echo "$DEVPATH" | sed 's|^/sys||')  # Remove /sys prefix
    ACTION="add"  # Set the action

    # Skip if BUSNUM or DEVPATH is not available
    if [ -z "$BUSNUM" ] || [ -z "$DEVPATH" ] || [ -z "${DEVTYPE}" ]; then
        continue
    fi

    # Export the environment variables for USB devices
    export ACTION
    export SUBSYSTEM
    export DEVTYPE
    export BUSNUM
    export DEVPATH

    # Call the hotplug system for the USB subsystem
    /sbin/hotplug-call usb

    # Search for associated devices (block, tty, printers, etc.) deeper in the device tree
    find "/sys$DEVPATH/" -type d | while IFS= read -r subdevice; do
        if [ -d "$subdevice" ] && [ -e "$subdevice/uevent" ]; then
            DEVTYPE=$(grep "DEVTYPE="  "$subdevice/uevent" | cut -d'=' -f2)
            if [ -z "${DEVTYPE}" ] ; then
                continue
            fi
            # Check for block devices
            if echo "$subdevice" | grep -q "/block/"; then
                SUBSYSTEM="block"
                DEVNAME=$(basename "$subdevice")
            # Check for tty devices
            elif echo "$subdevice" | grep -q "/tty/"; then
                SUBSYSTEM="tty"
                DEVNAME=$(basename "$subdevice")
            # Check for printers
            elif echo "$subdevice" | grep -q "/lp"; then
                SUBSYSTEM="printer"
                DEVNAME=$(basename "$subdevice")
            else
                continue
            fi

            DEVPATH=$(dirname "${subdevice}/uevent")
            DEVPATH=$(echo "$DEVPATH" | sed 's|^/sys||')  # Remove /sys prefix
            ACTION="add"

            # Export the environment variables for devices
            export ACTION
            export SUBSYSTEM
            export DEVTYPE
            export DEVNAME
            export DEVPATH

            # Call the hotplug system for the devices
            /sbin/hotplug-call "$SUBSYSTEM"
        fi
    done
done
