# libtr181-hosts

Client library that facilitates interaction with tr181-hosts.