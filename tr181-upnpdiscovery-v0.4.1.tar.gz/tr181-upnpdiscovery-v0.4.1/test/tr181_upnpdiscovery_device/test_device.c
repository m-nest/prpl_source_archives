/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <signal.h>
#include <sys/signalfd.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"
#include "test_device.h"
#include "mock.h"

static amxd_dm_t* dm = NULL;
static amxo_parser_t* parser = NULL;

static void read_sigalrm(void) {
    sigset_t mask;
    int sfd;
    struct signalfd_siginfo fdsi;
    ssize_t s;

    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);

    sigprocmask(SIG_BLOCK, &mask, NULL);

    sfd = signalfd(-1, &mask, 0);
    s = read(sfd, &fdsi, sizeof(struct signalfd_siginfo));
    assert_int_equal(s, sizeof(struct signalfd_siginfo));
    if(fdsi.ssi_signo == SIGALRM) {
    } else {
        printf("Read unexpected signal\n");
        assert_true(false);
    }
}


void create_subnet_list() {
    amxc_llist_t* lan_list = get_lan_addrs();
    amxc_var_t subnet_list;
    amxc_var_t subnet;

    assert_non_null(lan_list);
    amxc_var_init(&subnet_list);
    amxc_var_init(&subnet);
    amxc_var_set_type(&subnet_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(&subnet, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &subnet, "Address", "192.168.1.0");
    amxc_var_add_key(uint32_t, &subnet, "PrefixLen", 24);
    amxc_var_add(amxc_htable_t, &subnet_list, amxc_var_constcast(amxc_htable_t, &subnet));
    lan_addr_changed("test", &subnet_list, NULL);
    amxc_var_clean(&subnet);
    amxc_var_clean(&subnet_list);
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root = NULL;
    int retval = 0;
    const char* odl =
        "%config {"
        "    include-dirs = ["
        "        \"../../odl/\""
        "    ];"
        "    modules = {"
        "        fw-directory = \"../common/modules/\""
        "    };"
        "    lan = \"Device.IP.Interface.lan.\";"
        "}"
        "include \"tr181-upnpdiscovery_definition.odl\";"
        "include \"tr181-upnpdescription_definition.odl\";"
        "%define {"
        "}"
        "%populate {"
        "on event \"app:start\" call app_start;"
        "}";

    assert_int_equal(amxd_dm_new(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_new(&parser), 0);

    root = amxd_dm_get_root(dm);
    assert_non_null(root);

    //events
    amxo_resolver_ftab_add(parser, "app_start", AMXO_FUNC(_app_start));
    amxo_resolver_ftab_add(parser, "upnp_discovery_service_added", AMXO_FUNC(_upnp_discovery_service_added));
    amxo_resolver_ftab_add(parser, "upnp_discovery_device_added", AMXO_FUNC(_upnp_discovery_device_added));
    amxo_resolver_ftab_add(parser, "dm_discovery_item_destroyed", AMXO_FUNC(_dm_discovery_item_destroyed));

    test_init_dummy_dm(dm, parser);

    retval = amxo_parser_parse_string(parser, odl, root);
    if(retval) {
        printf("PARSER MESSAGE = %s\n", amxc_string_get(&parser->msg, 0));
    }
    assert_int_equal(retval, 0);

    handle_events();

    assert_int_equal(_main(0, dm, parser), 0);
    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);
    handle_events();
    return 0;
}

int test_teardown(UNUSED void** state) {
    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:stop", NULL);
    handle_events();
    assert_int_equal(_main(1, dm, parser), 0);

    test_clean_dummy_dm(dm, parser);

    amxo_parser_delete(&parser);
    amxd_dm_delete(&dm);

    return 0;
}

void test_add_discovery_device_no_subnetlist(UNUSED void** state) {
    amxc_var_t disc_info;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");

    amxc_var_init(&disc_info);
    assert_non_null(amxp_sigmngr_find_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO));
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxc_var_add_key(cstring_t, &disc_info, "os", "Linux/4.9.227-perf UPnP/1.0 BubbleUPnP/3.7.3.1");
    amxc_var_add_key(uint32_t, &disc_info, "expires", 1800);
    amxc_var_add_key(cstring_t, &disc_info, "location", "http://192.168.1.10:58645/dev/b4509ee0-d90a-4f49-ad71-dbf58dda3f12/desc.xml");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 0);
}

void test_add_discovery_device_not_in_subnetlist(UNUSED void** state) {
    amxc_var_t disc_info;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");

    create_subnet_list();
    amxc_var_init(&disc_info);
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxc_var_add_key(cstring_t, &disc_info, "os", "Linux/4.9.227-perf UPnP/1.0 BubbleUPnP/3.7.3.1");
    amxc_var_add_key(uint32_t, &disc_info, "expires", 1800);
    amxc_var_add_key(cstring_t, &disc_info, "location", "http://127.0.0.1:58645/dev/b4509ee0-d90a-4f49-ad71-dbf58dda3f12/desc.xml");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 0);
}

void test_add_discovery_device_in_subnetlist(UNUSED void** state) {
    amxc_var_t disc_info;
    amxc_var_t notification;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");
    amxd_object_t* device;
    char* host = NULL;

    assert_non_null(devices_obj);
    amxc_var_init(&disc_info);
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxc_var_add_key(cstring_t, &disc_info, "os", "Linux/4.9.227-perf UPnP/1.0 BubbleUPnP/3.7.3.1");
    amxc_var_add_key(uint32_t, &disc_info, "expires", 1800);
    amxc_var_add_key(cstring_t, &disc_info, "location", "http://192.168.1.10:58645/dev/b4509ee0-d90a-4f49-ad71-dbf58dda3f12/desc.xml");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 1);
    device = upnp_disc_get_item_by_key(devices_obj, "afce9342-5b6c-42fe-bdaf-07e65403c1ce", "UUID");
    assert_non_null(device);
    assert_true(amxp_timer_remaining_time(((upnp_discovery_item_t*) device->priv)->lease) <= 1800 * 1000);
    host = amxd_object_get_value(cstring_t, device, "Host", NULL);
    assert_string_equal(host, "Hosts.Host.2");
    free(host);

    amxc_var_init(&notification);
    amxc_var_set_type(&notification, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &notification, "notification", "dm:instance-removed");
    trigger_open_hostquery_callback(&notification);
    host = amxd_object_get_value(cstring_t, device, "Host", NULL);
    assert_string_equal(host, "");
    amxc_var_clean(&notification);
    free(host);
}

void test_add_existing_discovery_device(UNUSED void** state) {
    amxc_var_t disc_info;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");
    amxd_object_t* device;

    sleep(1);
    amxp_timers_calculate();
    assert_non_null(devices_obj);
    device = upnp_disc_get_item_by_key(devices_obj, "afce9342-5b6c-42fe-bdaf-07e65403c1ce", "UUID");
    assert_non_null(device);
    assert_int_not_equal(amxp_timer_remaining_time(((upnp_discovery_item_t*) device->priv)->lease), 1800 * 1000);
    amxc_var_init(&disc_info);
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxc_var_add_key(cstring_t, &disc_info, "os", "Linux/4.9.227-perf UPnP/1.0 BubbleUPnP/3.7.3.1");
    amxc_var_add_key(uint32_t, &disc_info, "expires", 1800);
    amxc_var_add_key(cstring_t, &disc_info, "location", "http://192.168.1.10:58645/dev/b4509ee0-d90a-4f49-ad71-dbf58dda3f12/desc.xml");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 1);
    assert_int_equal(amxp_timer_remaining_time(((upnp_discovery_item_t*) device->priv)->lease), 1800 * 1000);
}

void test_discovery_device_lease_expired(UNUSED void** state) {
    amxc_var_t disc_info;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");
    amxd_object_t* device;

    assert_non_null(devices_obj);
    amxc_var_init(&disc_info);
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxc_var_add_key(cstring_t, &disc_info, "os", "Linux/4.9.227-perf UPnP/1.0 BubbleUPnP/3.7.3.1");
    amxc_var_add_key(uint32_t, &disc_info, "expires", 3);
    amxc_var_add_key(cstring_t, &disc_info, "location", "http://192.168.1.10:58645/dev/b4509ee0-d90a-4f49-ad71-dbf58dda3f12/desc.xml");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_INFO, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 1);
    device = upnp_disc_get_item_by_key(devices_obj, "afce9342-5b6c-42fe-bdaf-07e65403c1ce", "UUID");
    assert_non_null(device);
    read_sigalrm();
    amxp_timers_calculate();
    amxp_timers_check();
}

void test_byebye_discovery_device(UNUSED void** state) {
    amxc_var_t disc_info;
    amxd_object_t* devices_obj = amxd_dm_findf(dm, "%s", "UPnPDiscovery.Device.");
    amxd_object_t* device;

    assert_non_null(devices_obj);
    amxc_var_init(&disc_info);
    amxc_var_set_type(&disc_info, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &disc_info, "device_id", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce");
    amxc_var_add_key(cstring_t, &disc_info, "usn", "uuid:afce9342-5b6c-42fe-bdaf-07e65403c1ce::urn:schemas-upnp-org:device:MediaServer:1");
    amxp_sigmngr_emit_signal(&dm->sigmngr, UPNP_SIGNAL_DISC_BYEBYE, &disc_info);
    handle_events();
    amxc_var_clean(&disc_info);
    assert_int_equal(amxd_object_get_instance_count(devices_obj), 1);
    device = upnp_disc_get_item_by_key(devices_obj, "afce9342-5b6c-42fe-bdaf-07e65403c1ce", "UUID");
    assert_non_null(device);
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(device, "Status"), NULL), "ByebyeReceived");
    assert_int_equal(amxp_timer_remaining_time(((upnp_discovery_item_t*) device->priv)->lease), 0);
}
