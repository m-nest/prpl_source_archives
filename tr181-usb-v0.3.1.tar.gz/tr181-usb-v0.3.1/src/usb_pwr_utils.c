/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "usb.h"
#include "usb-pwr-utils.h"

#define ME "utils"

const char* mod_ctrl_get(amxd_object_t* obj, const char* ctrl_param) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* usb_obj = amxd_dm_findf(get_dm(), "USB");
    const amxc_var_t* ctrl_arg = NULL;
    const char* ctrl_name = NULL;

    // If no object is given, use the default
    if(obj == NULL) {
        obj = usb_obj;
    }
    ctrl_arg = amxd_object_get_param_value(obj, ctrl_param);

    // If no controller value is found, try the default
    if(ctrl_arg == NULL) {
        ctrl_arg = amxd_object_get_param_value(usb_obj, ctrl_param);
    }

    ctrl_name = GET_CHAR(ctrl_arg, NULL);

    SAH_TRACEZ_OUT(ME);
    return ctrl_name;
}

int mod_usb_set_pwr_mode(const char* port_name, const char* power_mode) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_dm_t* dm = get_dm();
    amxd_object_t* usb_obj = NULL;
    const char* ctrl = NULL;
    amxc_var_t data;
    amxc_var_t ret;

    amxc_var_init(&data);
    amxc_var_init(&ret);

    when_str_empty_trace(power_mode, exit, ERROR, "Power mode is empty");
    when_null_trace(port_name, exit, ERROR, "Port name must be set");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // Add mandatory arguments
    amxc_var_add_key(cstring_t, &data, "port_name", port_name);
    amxc_var_add_key(cstring_t, &data, "power_mode", power_mode);

    usb_obj = amxd_dm_findf(dm, "USB.Port.%s", port_name);
    when_null_trace(usb_obj, exit, ERROR, "Problem amxd_dm_findf cannot find USB.Port. object");

    ctrl = mod_ctrl_get(usb_obj, PWR_CTRL);
    SAH_TRACEZ_INFO(ME, "Calling pwr-mode-set implementation for Port '%s' (controller = '%s')", port_name, ctrl);
    rv = amxm_execute_function(ctrl, MOD_PWR_CTRL, "pwr-mode-set", &data, &ret);
    when_failed_trace(rv, exit, ERROR, "Failed to call pwr-status-get, return '%d'", rv);

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

int dm_usb_soc_set_pwr(const char* port_name) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_dm_t* dm = get_dm();
    amxd_object_t* usb_obj = NULL;
    const char* ctrl = NULL;
    const char* pwr_status = NULL;
    const char* pwr_capabilities = NULL;
    amxc_var_t data;
    amxc_var_t ret;

    amxc_var_init(&data);
    amxc_var_init(&ret);

    when_null_trace(port_name, exit, ERROR, "Port name must be set");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);

    // Add mandatory arguments
    amxc_var_add_key(cstring_t, &data, "port_name", port_name);

    usb_obj = amxd_dm_findf(dm, "USB.Port.%s", port_name);
    when_null_trace(usb_obj, exit, ERROR, "Problem amxd_dm_findf cannot find USB.Port. object");

    ctrl = mod_ctrl_get(usb_obj, PWR_CTRL);
    SAH_TRACEZ_INFO(ME, "Calling pwr-mode-set implementation for Port '%s' (controller = '%s')", port_name, ctrl);

    rv = amxm_execute_function(ctrl, MOD_PWR_CTRL, "pwr-capabilities-get", &data, &ret);
    when_failed_trace(rv, exit, ERROR, "Failed to call pwr-capabilities-get, return '%d'", rv);

    pwr_capabilities = GET_CHAR(&ret, "power_capabilities");
    when_str_empty(pwr_capabilities, exit);

    amxd_object_set_attr(usb_obj, amxd_oattr_read_only, true);
    rv = amxd_object_set_value(cstring_t, usb_obj, "PowerCapability", pwr_capabilities);
    when_failed_trace(rv, exit, ERROR, "Failed to update PowerManagement parameters : PowerCapability");

    rv = amxm_execute_function(ctrl, MOD_PWR_CTRL, "pwr-status-get", &data, &ret);
    when_failed_trace(rv, exit, ERROR, "Failed to call pwr-status-get, return '%d'", rv);

    pwr_status = GET_CHAR(&ret, "power_status");
    when_null(pwr_status, exit);

    amxd_object_set_attr(usb_obj, amxd_oattr_read_only, true);
    rv = amxd_object_set_value(cstring_t, usb_obj, "PowerStatus", pwr_status);
    if(rv != amxd_status_ok) {
        rv = amxd_object_set_value(cstring_t, usb_obj, "PowerStatus", "Error");
        if(rv != amxd_status_ok) {
            when_failed_trace(rv, exit, ERROR, "Failed to update PowerManagement parameters : PowerStatus");
        } else {
            rv = amxd_status_invalid_value;
            SAH_TRACEZ_ERROR(ME, "Failed to update PowerManagement parameters : PowerStatus, set to 'Error'");
        }
    }

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
