# netmodel-ethernet

## Feature

### netmodel flags

Update netmodel flags with the DM status of the ethernet interface
