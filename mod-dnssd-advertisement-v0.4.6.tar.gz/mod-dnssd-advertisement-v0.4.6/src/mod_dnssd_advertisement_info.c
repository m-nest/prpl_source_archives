/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dnssd_advertisement_info.h"
#include "dnssd_advertisement.h"

/**
 * @brief
 * Clear the data allocated in a service_info structure
 *
 * @param info The service_info data to clear.
 */
void service_info_clear(service_info_t* info) {
    when_null_trace(info, exit, WARNING, "Info given is null");
    if(info->obj != NULL) {
        info->obj->priv = NULL;
    }
    free(info->file_service_name);
    free(info);
exit:
    return;
}

/**
 * @brief
 * Allocate memory for private server info data to a service object.
 *
 * @param obj The service object.
 */
void service_info_create(amxd_object_t* obj) {
    service_info_t* info = NULL;

    info = (service_info_t*) calloc(1, sizeof(service_info_t));
    when_null_trace(info, exit, ERROR, "Cannot allocate memory for private data info.");
    obj->priv = info;
    info->obj = obj;
    info->file_service_name = NULL;
    info->flags.all_flags = 0;
exit:
    return;
}

/**
 * @brief
 * Add the name of the service file and reset the the flags.
 *
 * @param obj The amxd service object.
 */
void service_info_enable(amxd_object_t* obj) {
    service_info_t* info;
    char* name = NULL;

    SAH_TRACEZ_INFO(ME, "Enabling NetModel query subscription.");

    when_null_trace(obj, exit, ERROR, "Cannot get the service object.");
    when_null_trace(obj->priv, exit, ERROR, "Cannot get private service info data from service object.");

    info = (service_info_t*) obj->priv;

    name = amxd_object_get_value(cstring_t, obj, "Alias", NULL);
    if(info->file_service_name != NULL) {
        free(info->file_service_name);
    }
    info->file_service_name = name;
    name = NULL;
    info->flags.bit.file_ok = 1;

exit:
    return;
}