/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <linux/rtnetlink.h>
#include <linux/fib_rules.h>

#include "netdev_netlink.h"
#include "netdev_util.h"
#include <net/if.h>

#include "dm_netdev.h"
#include "dm_convert.h"
#include "dm_rule.h"

#define ME "netdev"

/**
 * @defgroup dm_rule Rule Management
 * @ingroup netdev
 * @brief Functions and converters for managing rule objects in the netdev plugin.
 * @{
 */

static amxc_llist_t rules = {NULL, NULL};

static converter_t* table_converter = NULL;

/**
 * @ingroup dm_rule
 * @brief Checks if two rule_t structures match.
 *
 * Compares all relevant fields of two rule_t structures to determine if they represent the same rule.
 *
 * @param r1 Pointer to the first rule_t structure.
 * @param r2 Pointer to the second rule_t structure.
 * @return true if the rules match, false otherwise.
 */
static bool rule_match(rule_t* r1, rule_t* r2) {
    bool rv = false;
    when_null_trace(r1, exit, ERROR, "First rule is invalid, can not try to match");
    when_null_trace(r2, exit, ERROR, "Second rule is invalid, can not try to match");

    rv = (r1->family == r2->family) &&
        (r1->dstlen == r2->dstlen) &&
        (r1->srclen == r2->srclen) &&
        (r1->table == r2->table) &&
        (r1->ipproto == r2->ipproto) &&
        (r1->sport == r2->sport) &&
        (r1->sport_max == r2->sport_max) &&
        (r1->dport == r2->dport) &&
        (r1->dport_max == r2->dport_max) &&
        (r1->fwmark == r2->fwmark) &&
        (r1->fwmask == r2->fwmask) &&
        (memcmp(r1->iif, r2->iif, IF_NAMESIZE) == 0) &&
        (memcmp(r1->oif, r2->oif, IF_NAMESIZE) == 0) &&
        (memcmp(r1->src, r2->src, addrlen(r1->family)) == 0) &&
        (memcmp(r1->dst, r2->dst, addrlen(r1->family)) == 0);

exit:
    return rv;
}

/**
 * @ingroup dm_rule
 * @brief Finds an active rule matching the reference rule.
 *
 * Searches the internal rule list for an active rule that matches the provided reference.
 *
 * @param ref Pointer to the reference rule_t structure.
 * @return Pointer to the matching rule_t, or NULL if not found.
 */
rule_t* rule_find(rule_t* ref) {
    rule_t* rule = NULL;
    when_null_trace(ref, exit, ERROR, "No reference provided to find rule");
    amxc_llist_iterate(it, &rules) {
        rule = amxc_container_of(it, rule_t, it);
        if((rule->active == true) && rule_match(rule, ref)) {
            break;
        }
        rule = NULL;
    }
exit:
    return rule;
}

/**
 * @ingroup dm_rule
 * @brief Deferred destroy callback for a rule.
 *
 * Called asynchronously to destroy a rule and optionally delete its instance from the data model.
 *
 * @param data Pointer to a variant containing deferred data.
 * @param priv Pointer to the rule_t structure to destroy.
 */
static void rule_deferred_destroy(const amxc_var_t* data, void* priv) {
    SAH_TRACEZ_IN(ME);
    rule_t* rule = (rule_t*) priv;

    when_null(rule, exit);

    if(GET_BOOL(data, "delete")) {
        amxd_trans_t transaction;
        amxd_status_t status = amxd_status_unknown_error;
        amxd_trans_init(&transaction);
        amxd_trans_select_pathf(&transaction, "NetDev.Rule.");
        amxd_trans_del_inst(&transaction, rule->index, NULL);
        status = amxd_trans_apply(&transaction, netdev_get_dm());
        if(amxd_status_ok != status) {
            SAH_TRACEZ_WARNING(ME, "Transaction failed with status %u", status);
        }
        amxd_trans_clean(&transaction);
    }
    amxp_timer_delete(&rule->mercytimer);
    amxc_llist_it_take(&rule->it);
    free(rule);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @ingroup dm_rule
 * @brief Destroys a rule and optionally deletes its instance from the data model.
 *
 * Marks the rule as inactive and schedules its destruction.
 *
 * @param rule Pointer to the rule_t structure to destroy.
 * @param delete If true, deletes the rule instance from the data model.
 */
void rule_destroy(rule_t* rule, bool delete) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t var_deferred_data;

    amxc_var_init(&var_deferred_data);
    amxc_var_set_type(&var_deferred_data, AMXC_VAR_ID_HTABLE);

    when_null_trace(rule, exit, ERROR, "No rule provided, can not remove rule");
    when_false_trace(rule->active, exit, INFO, "Rule already set to be destroyed");

    amxc_var_add_key(bool, &var_deferred_data, "delete", delete);
    // Set to inactive to prevent use between this point and deferred_destroy call
    rule->active = false;
    if(rule->object != NULL) {
        rule->object->priv = NULL;
        rule->object = NULL;
    }
    amxp_sigmngr_deferred_call(NULL, rule_deferred_destroy, &var_deferred_data, rule);

exit:
    amxc_var_clean(&var_deferred_data);
    SAH_TRACEZ_OUT(ME);
    return;
}

// callback function; answers to amxp_timer_cb_t signature
static void rule_expire_mercy(UNUSED amxp_timer_t* timer, void* userdata) {
    rule_destroy((rule_t*) userdata, true);
}

/**
 * @ingroup dm_rule
 * @brief Creates and initializes a new rule_t structure.
 *
 * Allocates memory for a new rule, initializes its timer, and adds it to the rule list.
 *
 * @return Pointer to the newly created rule_t structure, or NULL on failure.
 */
rule_t* rule_create(void) {
    rule_t* rule = (rule_t*) calloc(1, sizeof(rule_t));
    when_null_trace(rule, exit, ERROR, "Failed to allocate memory for rule structure");
    amxp_timer_new(&rule->mercytimer, rule_expire_mercy, rule);
    amxc_llist_it_init(&rule->it);
    amxc_llist_append(&rules, &rule->it);
    rule->active = true;
exit:
    return rule;
}

/**
 * @ingroup dm_rule
 * @brief Copies the contents of one rule_t structure to another.
 *
 * Copies all relevant fields from the source rule to the destination rule.
 *
 * @param dst Pointer to the destination rule_t structure.
 * @param src Pointer to the source rule_t structure.
 * @return 0 on success, or -1 on failure.
 */
int rule_copy(rule_t* dst, rule_t* src) {
    int rv = -1;

    when_null_trace(dst, exit, ERROR, "No destination rule struct provided");
    when_null_trace(src, exit, ERROR, "No source rule struct provided");

    dst->family = src->family;
    dst->srclen = src->srclen;
    dst->dstlen = src->dstlen;
    dst->table = src->table;
    dst->ipproto = src->ipproto;
    dst->sport = src->sport;
    dst->sport_max = src->sport_max;
    dst->dport = src->dport;
    dst->dport_max = src->dport_max;
    memcpy(dst->src, src->src, addrlen(dst->family));
    memcpy(dst->dst, src->dst, addrlen(dst->family));
    dst->fwmark = src->fwmark;
    dst->fwmask = src->fwmask;
    memcpy(dst->iif, src->iif, IF_NAMESIZE);
    memcpy(dst->oif, src->oif, IF_NAMESIZE);
    rv = 0;
exit:
    return rv;
}

/**
 * @ingroup dm_rule
 * @brief Converts a rtnetlink message to a rule_t structure.
 *
 * @param rule empty rule struct to be filled with the data in the message.
 *  Do NOT provide a rule that contains any data or that is put in the rule list
 * (so no rule that was created with the rule_create function)
 * @param msg rtnl message
 * @return 0 if ok, -1 in case of error
 */
int msg2rule(rule_t* rule, rtnlmsg_t* msg) {
    int rv = -1;
    struct fib_rule_hdr* rl = NULL;
    struct rtattr* rta = NULL;

    when_null_trace(rule, exit, ERROR, "No rule structure provided");
    memset(rule, 0, sizeof(rule_t));
    when_null_trace(msg, exit, ERROR, "No rtnetlink message provided");
    when_null_trace(msg->nlmsg, exit, ERROR, "Does not contain netlink message");

    rl = (struct fib_rule_hdr*) rtnlmsg_hdr(msg);
    when_null_trace(rl, exit, WARNING, "Netlink message header is NULL");

    rule->family = rl->family;
    rule->srclen = rl->src_len;
    rule->dstlen = rl->dst_len;
    rule->table = rl->table;

    if((rta = rtnlmsg_attr(msg, FRA_SRC))) {
        memcpy(rule->src, RTA_DATA(rta), addrlen(rule->family));
    }
    if((rta = rtnlmsg_attr(msg, FRA_DST))) {
        memcpy(rule->dst, RTA_DATA(rta), addrlen(rule->family));
    }
    if((rta = rtnlmsg_attr(msg, FRA_IIFNAME))) {
        memcpy(rule->iif, RTA_DATA(rta), IF_NAMESIZE);
    }
    if((rta = rtnlmsg_attr(msg, FRA_OIFNAME))) {
        memcpy(rule->oif, RTA_DATA(rta), IF_NAMESIZE);
    }
    if((rta = rtnlmsg_attr(msg, FRA_IP_PROTO))) {
        rule->ipproto = *(int*) RTA_DATA(rta);
    }
    if((rta = rtnlmsg_attr(msg, FRA_FWMARK))) {
        rule->fwmark = *(int*) RTA_DATA(rta);
    }
    if((rta = rtnlmsg_attr(msg, FRA_FWMASK))) {
        rule->fwmask = *(int*) RTA_DATA(rta);
    }
    if((rta = rtnlmsg_attr(msg, FRA_SPORT_RANGE))) {
        struct fib_rule_port_range* r = RTA_DATA(rta);
        rule->sport = r->start;
        if(r->end > r->start) {
            rule->sport_max = r->end;
        }
    }
    if((rta = rtnlmsg_attr(msg, FRA_DPORT_RANGE))) {
        struct fib_rule_port_range* r = RTA_DATA(rta);
        rule->dport = r->start;
        if(r->end > r->start) {
            rule->dport_max = r->end;
        }
    }

    rv = 0;
exit:
    return rv;
}

/**
 * @ingroup dm_rule
 * @brief Deferred transaction callback for creating or updating a rule.
 *
 * Applies the transaction and updates the rule's data model instance if needed.
 *
 * @param data Pointer to a variant containing deferred data.
 * @param priv Pointer to the deferred_trans_t structure.
 */
static void new_rule_deferred_transaction(const amxc_var_t* data, void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t ret = amxd_status_invalid_value;
    deferred_trans_t* deferred_trans = (deferred_trans_t*) priv;
    amxd_trans_t* transaction = NULL;
    rule_t* rule = NULL;

    when_null_trace(deferred_trans, exit, ERROR, "No deferred transaction provided");
    transaction = deferred_trans->transaction;
    rule = (rule_t*) deferred_trans->priv;
    when_null_trace(transaction, exit, ERROR, "No transaction provided");
    when_null_trace(rule, exit, ERROR, "No addr structure provided");
    when_false_trace(rule->active, exit, INFO, "Rule set to be destroyed, not updating it anymore");

    ret = amxd_trans_apply(transaction, netdev_get_dm());
    if(ret != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction, return %d", ret);
    }

    if(GET_BOOL(data, "new_instance")) {
        rule->object = amxd_dm_findf(netdev_get_dm(), "NetDev.Rule.%s", GET_CHAR(data, "pathbuf"));
        if(rule->object == NULL) {
            rule_destroy(rule, false);
            goto exit;
        }
        rule->index = rule->object->index;
        rule->object->priv = rule;
    }
    SAH_TRACEZ_INFO(ME, "Deferred rule transaction successful");

exit:
    deferred_trans_clean(&deferred_trans);
    SAH_TRACEZ_OUT(ME);
}

/**
 * @ingroup dm_rule
 * @brief Creates a transaction from a rule_t structure.
 *
 * Builds a transaction to create or update a rule instance in the data model.
 *
 * @param rule Pointer to the rule_t structure.
 * @param new_inst If true, creates a transaction for a new instance.
 * @return Pointer to the created amxd_trans_t transaction, or NULL on failure.
 */
amxd_trans_t* create_transaction_from_rule(rule_t* rule, bool new_inst) {
    SAH_TRACEZ_IN(ME);
    char pathbuf[40];
    amxd_trans_t* trans = NULL;

    when_null_trace(rule, exit, ERROR, "No rule provide to create transaction");

    amxd_trans_new(&trans);
    amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    amxd_trans_set_attr(trans, amxd_tattr_change_priv, true);

    if(new_inst) {
        sprintf(pathbuf, "dyn%u", rule->dyn_index);
        amxd_trans_select_pathf(trans, "NetDev.Rule");
        amxd_trans_add_inst(trans, 0, pathbuf);
    } else {
        amxd_trans_select_pathf(trans, "NetDev.Rule.dyn%u.", rule->dyn_index);
    }

    amxd_trans_set_value(uint8_t, trans, "SrcLen", rule->srclen);
    amxd_trans_set_value(uint8_t, trans, "DstLen", rule->dstlen);
    amxd_trans_set_value(cstring_t, trans, "Table", convert_bin2str(table_converter, rule->table));
    amxd_trans_set_value(cstring_t, trans, "Src", addr2str(rule->family, rule->src, false));
    amxd_trans_set_value(cstring_t, trans, "Dst", addr2str(rule->family, rule->dst, false));
    amxd_trans_set_value(cstring_t, trans, "SourceInterface", rule->iif);
    amxd_trans_set_value(cstring_t, trans, "DestInterface", rule->oif);
    amxd_trans_set_value(int32_t, trans, "SourcePort", rule->sport);
    amxd_trans_set_value(int32_t, trans, "SourcePortMax", rule->sport_max);
    amxd_trans_set_value(int32_t, trans, "DestPort", rule->dport);
    amxd_trans_set_value(int32_t, trans, "DestPortMax", rule->dport_max);
    amxd_trans_set_value(uint8_t, trans, "IPProto", rule->ipproto);
    amxd_trans_set_value(int32_t, trans, "FwMark", rule->fwmark);
    amxd_trans_set_value(int32_t, trans, "FwMask", rule->fwmask);

exit:
    SAH_TRACEZ_OUT(ME);
    return trans;
}

/**
 * @ingroup dm_rule
 * @brief Handles the addition of a new rule from a rtnetlink message.
 *
 * Converts the message to a rule, finds or creates the rule, and applies the transaction.
 *
 * @param msg Pointer to the rtnlmsg_t message.
 * @return 0 on success, or a negative value on failure.
 */
int handle_new_rule(rtnlmsg_t* msg) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    rule_t ws;
    rule_t* rule = NULL;
    char pathbuf[40];
    deferred_trans_t* deferred_trans = NULL;
    amxd_trans_t* transaction = NULL;
    amxc_var_t var_deferred_data;

    amxc_var_init(&var_deferred_data);
    amxc_var_set_type(&var_deferred_data, AMXC_VAR_ID_HTABLE);

    when_null_trace(msg, exit, ERROR, "No rtnetlink message provided");
    when_null_trace(msg->nlmsg, exit, ERROR, "Does not contain netlink message");

    when_failed_trace(msg2rule(&ws, msg), exit, ERROR, "Failed to convert msg to rule");
    // ignore rules in the local and default table
    when_true_status((ws.table == RT_TABLE_LOCAL), exit, rv = 0);
    when_true_status((ws.table == RT_TABLE_DEFAULT), exit, rv = 0);

    rule = rule_find(&ws);
    if(rule != NULL) {
        SAH_TRACEZ_INFO(ME, "Existing 'rule' found");
        amxp_timer_stop(rule->mercytimer);
    } else {
        SAH_TRACEZ_INFO(ME, "Creating new 'rule'; NetDev.Rule");
        rule = rule_create();
        when_null_trace(rule, exit, ERROR, "Failed to create new rule");
        rule->dyn_index = ({static unsigned counter = 0; counter++;});
        sprintf(pathbuf, "dyn%u", rule->dyn_index);

        amxc_var_add_key(bool, &var_deferred_data, "new_instance", true);
        amxc_var_add_key(cstring_t, &var_deferred_data, "pathbuf", pathbuf);
        SAH_TRACEZ_INFO(ME, "pathbuf = %s", pathbuf);
    }
    rule_copy(rule, &ws);

    transaction = create_transaction_from_rule(rule, GET_BOOL(&var_deferred_data, "new_instance"));
    when_null_trace(transaction, exit, ERROR, "Failed to create transaction");

    deferred_trans_create(&deferred_trans, transaction, rule);
    rv = amxp_sigmngr_deferred_call(NULL, new_rule_deferred_transaction, &var_deferred_data, deferred_trans);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to defer the new rule transaction");
        deferred_trans_clean(&deferred_trans);
    }

exit:
    amxc_var_clean(&var_deferred_data);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @ingroup dm_rule
 * @brief Handles the deletion of a rule from a rtnetlink message.
 *
 * Finds the matching rule and schedules its destruction.
 *
 * @param msg Pointer to the rtnlmsg_t message.
 * @return 0 on success, or a negative value on failure.
 */
int handle_del_rule(rtnlmsg_t* msg) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    rule_t ws;
    rule_t* rule = NULL;

    when_null_trace(msg, exit, ERROR, "No rtnetlink message provided");
    when_null_trace(msg->nlmsg, exit, ERROR, "Does not contain netlink message");

    when_failed_trace(msg2rule(&ws, msg), exit, ERROR, "Failed to convert msg to rule");
    rule = rule_find(&ws);

    when_null_trace(rule, exit, ERROR, "No matching rule found to delete");
    rv = amxp_timer_start(rule->mercytimer, 100);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static void print_rule_msg(FILE* f, rtnlmsg_t* msg) {
    struct fib_rule_hdr* rl = (struct fib_rule_hdr*) rtnlmsg_hdr(msg);
    struct rtattr* rta;
    unsigned int rtalen = rtnlmsg_attrLen(msg);

    when_null_trace(rl, exit, ERROR, "Cannot print empty rule");

    fprintf(f, "%s{",
            rtnlmsg_type(msg) == RTM_NEWRULE ? "RTM_NEWRULE" :
            rtnlmsg_type(msg) == RTM_DELRULE ? "RTM_DELRULE" :
            rtnlmsg_type(msg) == RTM_GETRULE ? "RTM_GETRULE" : "<UNKNOWN>");
    fprintf(f, " family=%u(%s)", rl->family, family2str(rl->family));
    fprintf(f, " dst_len=%u src_len=%u tos=%u", rl->dst_len, rl->src_len, rl->tos);
    fprintf(f, " table=%u(%s)", rl->table, convert_bin2str(table_converter, rl->table));
    fprintf(f, " flags=0x%x", rl->flags);

    for(rta = rtnlmsg_attrFirst(msg); rta != NULL && RTA_OK(rta, rtalen); rta = RTA_NEXT(rta, rtalen)) {
        switch(rta->rta_type) {
        case FRA_DST:      fprintf(f, " dst=%s", addr2str(rl->family, (unsigned char*) RTA_DATA(rta), false)); break;
        case FRA_SRC:      fprintf(f, " src=%s", addr2str(rl->family, (unsigned char*) RTA_DATA(rta), false)); break;
        case FRA_IIFNAME:      fprintf(f, " iif=%s", (char*) RTA_DATA(rta)); break;
        case FRA_OIFNAME:      fprintf(f, " oif=%s", (char*) RTA_DATA(rta)); break;
        case FRA_FWMARK:  fprintf(f, " fwmark=0x%x", *(int*) RTA_DATA(rta)); break;
        case FRA_FWMASK:  fprintf(f, " fwmask=0x%x", *(int*) RTA_DATA(rta)); break;
        case FRA_IP_PROTO: fprintf(f, " ipproto=%d", *(int*) RTA_DATA(rta)); break;
        case FRA_SPORT_RANGE: {
            struct fib_rule_port_range* r = RTA_DATA(rta);
            if(r->start == r->end) {
                fprintf(f, " sport=%u", r->start);
            } else {
                fprintf(f, " sport=%u-%u", r->start, r->end);
            }
            break;
        }
        case FRA_DPORT_RANGE: {
            struct fib_rule_port_range* r = RTA_DATA(rta);
            if(r->start == r->end) {
                fprintf(f, " dport=%u", r->start);
            } else {
                fprintf(f, " dport=%u-%u", r->start, r->end);
            }
            break;
        }
        case FRA_TABLE: {
            unsigned int table = *(unsigned int*) RTA_DATA(rta);
            fprintf(f, " table=%u(%s)", table, convert_bin2str(table_converter, table));
            break;
        }
        default:
            fprintf(f, " attr[%u](%lu byte%s)", rta->rta_type, (long unsigned int) RTA_PAYLOAD(rta), RTA_PAYLOAD(rta) == 1 ? "" : "s");
            break;
        }
    }
    fprintf(f, " }");
exit:
    return;
}

/**
 * @ingroup dm_rule
 * @brief Action handler for destroying a rule object in the data model.
 *
 * Called when a rule object is deleted from the data model.
 *
 * @param object Pointer to the rule object.
 * @param param Pointer to the parameter associated with the deletion.
 * @param reason Reason for the action.
 * @param args Pointer to additional arguments.
 * @param retval Pointer to the return value.
 * @param priv Pointer to private user data.
 * @return AMXD_STATUS_OK on success, or an error code on failure.
 */
amxd_status_t _rule_destroy(amxd_object_t* object,
                            UNUSED amxd_param_t* param,
                            amxd_action_t reason,
                            UNUSED const amxc_var_t* const args,
                            UNUSED amxc_var_t* const retval,
                            UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t status = amxd_status_ok;
    rule_t* rule = NULL;

    if(reason != action_object_destroy) {
        status = amxd_status_function_not_implemented;
        goto exit;
    }

    if((object == NULL) || (amxd_object_get_type(object) == amxd_object_template)) {
        goto exit;
    }

    rule = (rule_t*) object->priv;
    when_null(rule, exit);
    rule_destroy(rule, false);

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

static rtnlhandler_t new_rule_handler = { RTM_NEWRULE, sizeof(struct fib_rule_hdr), handle_new_rule, print_rule_msg };
static rtnlhandler_t del_rule_handler = { RTM_DELRULE, sizeof(struct fib_rule_hdr), handle_del_rule, print_rule_msg };
static rtnlhandler_t get_rule_handler = { RTM_GETRULE, sizeof(struct fib_rule_hdr), NULL, print_rule_msg };

converter_t* init_rule_table_converter(void) {
    converter_t* converter = converter_create("route_table", converter_attribute_fallback);
    converter_loadEntry(converter, RT_TABLE_UNSPEC, "unspec");
    converter_loadEntry(converter, RT_TABLE_DEFAULT, "default");
    converter_loadEntry(converter, RT_TABLE_MAIN, "main");
    converter_loadEntry(converter, RT_TABLE_LOCAL, "local");
    converter_loadTable(converter, amxd_dm_findf(netdev_get_dm(), "NetDev.ConversionTable.Table"));
    return converter;
}

/**
 * @ingroup dm_rule
 * @brief Initializes all rule converters.
 */
void rule_init_converters(void) {
    table_converter = init_rule_table_converter();
}

/**
 * @ingroup dm_rule
 * @brief Initializes the rule subsystem.
 *
 * Registers handlers and sets up converters for rule management.
 *
 * @return true on success, false on failure.
 */
bool rule_init(void) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_param_t* parameter = NULL;
    const char* path = "NetDev.Rule";
    amxd_object_t* netdev_addr = amxd_dm_findf(netdev_get_dm(), path, NULL);

    rule_init_converters();

    parameter = amxd_object_get_param_def(netdev_addr, "Table");
    rv |= amxd_param_add_action_cb(parameter, action_param_validate, param_validate_converter, table_converter);

    rtnl_register_handler(&new_rule_handler);
    rtnl_register_handler(&del_rule_handler);
    rtnl_register_handler(&get_rule_handler);

    SAH_TRACEZ_OUT(ME);
    return (rv == amxd_status_ok);
}

/**
 * @ingroup dm_rule
 * @brief Starts the rule subsystem.
 *
 * Sends and reads netlink messages to initialize rule state.
 *
 * @return true on success, false on failure.
 */
bool rule_start(void) {
    SAH_TRACEZ_IN(ME);

    rtnlmsg_t* msg = rtnlmsg_instance();
    rtnlmsg_initialize(msg, RTM_GETRULE, sizeof(struct fib_rule_hdr), NLM_F_REQUEST | NLM_F_DUMP);
    if(!rtnl_send(netdev_get_nlfd(), msg)) {
        return false;
    }
    if(!rtnl_read(netdev_get_nlfd(), msg, true)) {
        return false;
    }

    SAH_TRACEZ_OUT(ME);
    return true;
}

/**
 * @ingroup dm_rule
 * @brief Clears all rules from the subsystem.
 *
 * Destroys all rules in the internal rule list.
 */
void rule_clear(void) {
    while(!amxc_llist_is_empty(&rules)) {
        amxc_llist_it_t* it = amxc_llist_get_first(&rules);
        rule_t* rule = amxc_container_of(it, rule_t, it);
        rule_destroy(rule, false);
        amxc_llist_it_take(it);
    }
}

/**
 * @ingroup dm_rule
 * @brief Cleans up the rule subsystem.
 *
 * Clears all rules and destroys converters.
 */
void rule_cleanup(void) {
    rule_clear();
    converter_destroy(&table_converter);
}

/** @} */ // end of dm_rule group