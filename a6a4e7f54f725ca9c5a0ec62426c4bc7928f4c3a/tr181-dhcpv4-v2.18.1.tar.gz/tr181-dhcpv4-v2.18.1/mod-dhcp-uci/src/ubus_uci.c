/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>

#include "ubus_uci.h"

#define ME "ubus_uci"

int uci_call(const char* method,
             const char* config,
             const char* section,
             const char* type,
             amxc_var_t* values,
             amxc_var_t* result) {
    amxb_bus_ctx_t* ctx = NULL;
    amxc_var_t args;
    int r = -1;

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    when_null_trace(method, exit, ERROR, "Invalid method argument");
    ctx = amxb_be_who_has("uci.");
    when_null_trace(ctx, exit, ERROR, "uci is not available on bus");

    if(config != NULL) {
        amxc_var_add_key(cstring_t, &args, "config", config);
    }

    if(section != NULL) {
        bool add = (strncmp(method, "add", 3) == 0);
        amxc_var_add_key(cstring_t, &args, add ? "name" : "section", section);
    }

    if(type != NULL) {
        amxc_var_add_key(cstring_t, &args, "type", type);
    }

    if(values != NULL) {
        if(values->type_id == AMXC_VAR_ID_HTABLE) {
            amxc_var_add_key(amxc_htable_t,
                             &args,
                             "values",
                             amxc_var_constcast(amxc_htable_t, values));
        } else {
            amxc_var_add_key(amxc_llist_t,
                             &args,
                             "options",
                             amxc_var_constcast(amxc_llist_t, values));
        }
    }

    r = amxb_call(ctx, "uci.", method, &args, result, 10);
    when_failed_trace(r, exit, ERROR, "Call to UCI '%s' (config='%s', section='%s', type='%s') failed", method, config ? config : "NULL", section ? section : "NULL", type ? type : "NULL");
    SAH_TRACEZ_INFO(ME, "Call to UCI '%s' (config='%s', section='%s', type='%s') returned %d", method, config ? config : "NULL", section ? section : "NULL", type ? type : "NULL", r);
exit:
    amxc_var_clean(&args);
    return r;
}
