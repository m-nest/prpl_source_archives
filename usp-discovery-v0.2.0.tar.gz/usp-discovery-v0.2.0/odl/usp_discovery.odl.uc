{%
    // find out how many wan interfaces we have
    let wan_interfaces=0;
    for (let Itf in BD.Interfaces) {
        if (Itf.Upstream == "true" || Itf.DefaultUpstream == "true") {
            wan_interfaces++;
        }
    }
%}    

#include "mod_sahtrace.odl";
#include "global_variables.odl";

%config {
    // Application name
    name = "usp_discovery";

    sahtrace = {
        type = "syslog",
        level = "${default_log_level}"
    };

    trace-zones = {
        usp_discovery = "${default_trace_zone_level}"
    };

    ubus = {
        watch-ubus-events = true,
        register-on-start-event = true
    };

    NetModelIntfName = "{% (wan_interfaces == 0) ? print("ip-lan") : print("ip-wan") %}";
    UseSingleControllerInstance = false;
}

import "${name}.so" as "${name}";

%define {
    entry-point usp_discovery.usp_discovery_main;
}
