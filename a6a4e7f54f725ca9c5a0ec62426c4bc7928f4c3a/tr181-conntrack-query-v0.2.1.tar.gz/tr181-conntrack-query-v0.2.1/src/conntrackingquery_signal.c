/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "conntrackingquery.h"
#include <sys/sysinfo.h>
#include <signal.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/un.h>
#include <sys/stat.h>

static int sock = -1;

/**
 * @brief Handles incoming connection tracking data signals.
 *
 * Processes the signal and associated data when connection tracking
 * information is received.
 *
 * @param sig_name  Name of the received signal.
 * @param data      Data associated with the signal.
 * @param priv      Private data (unused).
 * @return Always returns an integer status.
 */
int _conntrack_data_handler(const char* const sig_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv);

/**
 * @brief Get system's uptime
 *
 * Get the latest system uptime
 *
 * @param	void
 * @ret		int		returns uptime in secs
 */
int get_system_uptime(void) {
    uint32_t uptime = 0;
    struct sysinfo info;

    if(sysinfo(&info) != 0) {
        SAH_TRACEZ_ERROR(ME, "sysinfo failed");
        goto exit;
    }
    uptime = info.uptime;
exit:
    return uptime;
}


/**
 * @brief Updates query metadata and emits connection tracking data.
 *
 * Sets the query's last change timestamp, applies a transaction to update
 * the data model, and emits a signal with the query's connection tracking data.
 *
 * @param fd socket descriptor which is used to receive the notify flow data from the agent
 */
void process_sock_event(int fd) {
    conntrack_entry_t ct_entry;
    amxd_trans_t trans;
    ssize_t recv_len;
    query_t* squery;
    amxd_status_t rv;
    amxd_dm_t* dm;
    amxc_var_t signal_data;
    char intbuf[8];

    amxd_trans_init(&trans);

    recv_len = recv(fd, &ct_entry, sizeof(conntrack_entry_t), 0);
    if(recv_len == -1) {
        // Check if this is a temporary/recoverable error
        if((errno == EINTR) || (errno == EAGAIN) || (errno == EWOULDBLOCK)) {
            SAH_TRACEZ_INFO(ME, "recv temporary error: (%d) %s", errno, strerror(errno));
            goto exit;
        }

        // Permanent/fatal error - socket is broken
        SAH_TRACEZ_ERROR(ME, "recv permanent error: (%d) %s - removing fd from event loop",
                         errno, strerror(errno));
        amxp_connection_remove(fd);
        goto exit;
    }
    if(recv_len != (ssize_t) sizeof(conntrack_entry_t)) {
        SAH_TRACEZ_ERROR(ME, "recv: expected %zu bytes, got %zd bytes", sizeof(conntrack_entry_t), recv_len);
        goto exit;
    }

    squery = query_find_by_pid(ct_entry.pid);
    when_null(squery, exit);
    rv = amxd_status_invalid_function_argument;
    dm = query_get_dm();
    when_null(dm, exit);
    squery->last_change = get_system_uptime();
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, squery->object);
    amxd_trans_set_value(uint32_t, &trans, "LastChange", squery->last_change);

    rv = amxd_trans_apply(&trans, dm);
    when_true_trace(rv != amxd_status_ok, exit, ERROR, "Transaction status: %d", rv);

    amxc_var_init(&signal_data);
    amxc_var_set_type(&signal_data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &signal_data, "Event", ct_entry.event);
    amxc_var_add_key(cstring_t, &signal_data, "SourceIP", ct_entry.src_ip);
    amxc_var_add_key(cstring_t, &signal_data, "DestIP", ct_entry.dst_ip);

    snprintf(intbuf, sizeof(intbuf), "%d", ct_entry.protocol);
    amxc_var_add_key(cstring_t, &signal_data, "Protocol", intbuf);

    snprintf(intbuf, sizeof(intbuf), "%d", ct_entry.src_port);
    amxc_var_add_key(cstring_t, &signal_data, "SourcePort", intbuf);

    snprintf(intbuf, sizeof(intbuf), "%d", ct_entry.dst_port);
    amxc_var_add_key(cstring_t, &signal_data, "DestPort", intbuf);
    amxc_var_add_key(cstring_t, &signal_data, "Name", amxc_string_get(&(squery->name), 0));

    SAH_TRACEZ_INFO(ME, "Inside emit_conntrack_data_signal -- sending ConntrackNotifyEvent");
    amxd_object_emit_signal(squery->object, "ConntrackNotifyEvent", &signal_data);
    amxc_var_clean(&signal_data);
exit:
    amxd_trans_clean(&trans);
    return;
}

/**
 * @brief Callback function for handling the socket data
 *
 * This functions acts as a callback function and it is passed to amxp_connection_add
 * for handling the received data
 *
 * @param fd Socket Descriptor
 * @param data the received data in the socket
 */
static void sock_event_handler(int fd, UNUSED void* data) {
    process_sock_event(fd);
    return;
}

/**
 * @brief Sets Nonblocking mode on the socket
 *
 * This functions sets Nonblocking mode on the opened socket
 *
 * @param socket socket descriptor
 *
 * @return bool returns the true or false status
 */
static bool set_nonblock(int socket) {
    int flags = fcntl(socket, F_GETFL, 0);
    int ret = -1;
    bool rc = false;

    ret = fcntl(socket, F_SETFL, flags | O_NONBLOCK);
    when_true_trace(ret == -1, exit, ERROR, "Failed to set socket non blocking: (%d) - %s",
                    errno, strerror(errno));

    rc = true;

exit:
    return rc;
}


/**
 * @brief Opens a UNIX socket
 *
 * This functions opens a UNIX socket and passes the callback function sock_event_handler
 * for handling the data
 *
 * @param query the query object which was got from the data model
 *
 * @return int returns 0 on success -1 on failure
 */
static int unix_socket(void) {
    struct sockaddr_un addr;
    bool close_socket = false;

    when_true(sock != -1, exit);

    memset(&addr, 0, sizeof(struct sockaddr_un));

    sock = socket(AF_UNIX, SOCK_DGRAM, 0);
    when_true_trace(sock < 0, exit, ERROR, "Failed to open socket: (%d) - %s",
                    errno, strerror(errno));

    when_false_status(set_nonblock(sock), exit, close_socket = true);

    unlink(TR181_CT_MGR_SOCK);
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TR181_CT_MGR_SOCK, sizeof(addr.sun_path) - 1);

    if(bind(sock, (const struct sockaddr*) &addr, sizeof(addr)) < 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot bind socket \"%s\": (%d) - %s",
                         TR181_CT_MGR_SOCK, errno, strerror(errno));
        close_socket = true;
        goto exit;
    }

    if(chmod(TR181_CT_MGR_SOCK, 0666) < 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot chmod 0666 \"%s\": (%d) - %s",
                         TR181_CT_MGR_SOCK, errno, strerror(errno));
        close_socket = true;
        goto exit;
    }

    amxp_connection_add(sock, sock_event_handler, NULL, AMXP_CONNECTION_CUSTOM, NULL);
exit:
    if(close_socket) {
        close(sock);
        sock = -1;
    }

    return sock;
}

void query_destroy_unix_socket(void) {
    if(sock >= 0) {
        close(sock);
        sock = -1;
    }
    unlink(TR181_CT_MGR_SOCK);
}

/**
 * @brief Creates a unix domain socket for notification query
 * Creates a unix domain socket for notification query
 *
 * @param query , query object for which the socket will be created
 */

void query_create_unix_socket (void) {
    unix_socket();
}



/**
 * @brief Handles the ConntrackNotifyEvent signal and prints its key-value data.
 *
 * Checks if the received signal matches the expected event name and,
 * if so, iterates through the signal data to print each key-value pair.
 *
 * @return 0 if the signal was handled successfully, -1 otherwise.
 */

int _conntrack_data_handler(const char* const sig_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv) {
    int retval = -1;

    if(strncmp(sig_name, "ConntrackNotifyEvent", strlen("ConntrackNotifyEvent")) == 0) {

        amxc_var_for_each(entryy, data) {
            const char* key = amxc_var_key(entryy);
            const char* value = amxc_var_constcast(cstring_t, entryy);
            if(key && value) {
                SAH_TRACEZ_ERROR(ME, "_conntrack_data_handler , key: %s, Value: %s", key, value);
            }
        }

        retval = 0;
    }

    return retval;
}

