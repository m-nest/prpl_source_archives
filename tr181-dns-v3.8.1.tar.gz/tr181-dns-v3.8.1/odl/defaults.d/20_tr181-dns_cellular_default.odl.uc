{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1"); let has_cellular_wan = (BDfn.getInterfaceIndex("wan", "cellular") != "-1"); %}
%populate {
{% if (BDfn.hasAnyUpstream()) : %}
    object DNS {
        object Relay {
            object Forwarding {
{% if (has_cellular_wan) : %}
                instance add("cellular-1") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.1";
                    parameter Enable = true;
                }
                instance add("cellular-2") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.1";
                    parameter Enable = true;
                }
                instance add("cellular-3") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.1";
                    parameter Enable = true;
                }
                instance add("cellular-4") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.1";
                    parameter Enable = true;
                }
{% endif; if(has_failover) : %}
                instance add("failover-1") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.8";
                    parameter Enable = true;
                }
                instance add("failover-2") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.8";
                    parameter Enable = true;
                }
                instance add("failover-3") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.8";
                    parameter Enable = true;
                }
                instance add("failover-4") {
                    parameter Type = "3GPP-NAS";
                    parameter Interface = "Device.Logical.Interface.8";
                    parameter Enable = true;
                }
{% endif; %}
            }
        }
    }
{% endif; %}
}
