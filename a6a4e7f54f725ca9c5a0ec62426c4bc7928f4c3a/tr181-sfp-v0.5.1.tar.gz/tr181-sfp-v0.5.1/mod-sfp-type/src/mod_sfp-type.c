/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>  /* snprintf() */
#include <stdlib.h> /* strtol() */
#include <string.h> /* strcmp() */

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h> /* UNUSED */
#include <amxm/amxm.h>

#include "sfp_type_control_common.h" /* SFP_UNSUPPORTED */
#include "sfpmgr_trace.h"

#define COMMAND_SIZE 64

#ifdef UNIT_TEST
static const char* const EEPROM_SCRIPT_FOR_UNIT_TESTS = "/tmp/tr181-sfp/scripts/get_eeprom_info.sh";
static const char* const GET_RXLOS_FOR_UNIT_TESTS = "/tmp/tr181-sfp/scripts/get_rxlos.sh";
#else
#define EEPROM_SCRIPT_PATH  "/bin/sh /lib/sfp/get_eeprom_info.sh"
#define RXLOS_SCRIPT_PATH "/bin/sh /lib/sfp/get_rxlos.sh"
#endif

/* MOD_SFP_TYPE module namespace */
static amxm_module_t* s_module = NULL;

/**
 * Execute get_eeprom_info.sh to get certain SFF-8472 register values.
 *
 * This function runs a script using the provided interface name (`ifname`),
 * retrieves its output, and assigns the extracted values to the arguments.
 *
 * @param[out] sff8024_identifier: SFF-8024 identifier (SFF-8472 address A0h offset 0)
 * @param[out] ten_G_eth_compliance_codes: 10G Ethernet compliance codes (SFF-8472
 *                                         address A0h offset 3)
 * @param[out] eth_compliance_codes: Ethernet compliance codes (SFF-8472 address A0h
 *                                   offset 6)
 * @param[out] signaling_rate: signaling rate (SFF-8472 address A0h offset 12)
 * @param[in]  ifname The interface name passed to the script.
 *
 * @return SFPMGR_SUCCESS on success, SFPMGR_INVALID if an error occurred.
 */
static int get_sff8472_register_values(uint8_t* sff8024_identifier,
                                       uint8_t* ten_G_eth_compliance_codes,
                                       uint8_t* eth_compliance_codes,
                                       uint8_t* signaling_rate,
                                       const char* ifname) {
    int rc = SFPMGR_INVALID;
    int rc2;
    FILE* fp;
#define MAX_LINE_LEN 32
#define VALUE_LEN 4
    char output[MAX_LINE_LEN];
    char buffer_0[VALUE_LEN];
    char buffer_3[VALUE_LEN];
    char buffer_6[VALUE_LEN];
    char buffer_12[VALUE_LEN];
    char command[COMMAND_SIZE];
    int status;

    when_null(sff8024_identifier, exit);
    when_null(ten_G_eth_compliance_codes, exit);
    when_null(eth_compliance_codes, exit);
    when_null(signaling_rate, exit);
    when_null(ifname, exit);

    // Construct the script path
#ifdef UNIT_TEST
    rc2 = snprintf(command, sizeof(command), "/bin/sh %s", EEPROM_SCRIPT_FOR_UNIT_TESTS);
#else
    rc2 = snprintf(command, sizeof(command), "%s %s", EEPROM_SCRIPT_PATH, ifname);
#endif
    when_true_trace(rc2 < 0 || rc2 >= COMMAND_SIZE, exit, ERROR, "snprintf() failed rc=%d", rc2);

    SAH_TRACEZ_INFO(ME, "command='%s'", command);

    // Open the script for reading
    fp = popen(command, "r");
    if(fp == NULL) {
        SAH_TRACEZ_ERROR(ME, "popen failed for %s: %s", command, strerror(errno));
        return SFPMGR_INVALID;
    }

    // Read the output of the script
    if(fgets(output, sizeof(output), fp) == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to read output from script or script returned no output.");
        pclose(fp);
        return SFPMGR_INVALID;
    }

    // Check the exit status of the script
    status = pclose(fp);
    if(status != 0) {
        SAH_TRACEZ_ERROR(ME, "Script failed with status code %d", status);
        return SFPMGR_INVALID;
    }

    if(sscanf(output, "%s %s %s %s", buffer_0, buffer_3, buffer_6, buffer_12) != 4) {
        SAH_TRACEZ_ERROR(ME, "Failed to extract values from the script output.");
        return SFPMGR_INVALID;
    }

    /* Set errno to 0 to o distinguish success/failure after strtol() calls */
    errno = 0;
    const long reg_0 = strtol(buffer_0, NULL, 16);   // Convert buffer_0 to decimal
    const long reg_3 = strtol(buffer_3, NULL, 16);   // Convert buffer_3 to decimal
    const long reg_6 = strtol(buffer_6, NULL, 16);   // Convert buffer_6 to decimal
    const long reg_12 = strtol(buffer_12, NULL, 16); // Convert buffer_12 to decimal
    when_failed_trace(errno, exit, ERROR, "One or more strtol() calls failed; errno=%d", errno);

    when_true_trace(reg_0 < 0 || reg_0 > 255, exit, ERROR, "Invalid value for register 0 [%ld]", reg_0);
    when_true_trace(reg_3 < 0 || reg_3 > 255, exit, ERROR, "Invalid value for register 3 [%ld", reg_3);
    when_true_trace(reg_6 < 0 || reg_6 > 255, exit, ERROR, "Invalid value for register 6 [%ld]", reg_6);
    when_true_trace(reg_12 < 0 || reg_12 > 255, exit, ERROR, "Invalid value for register 12 [%ld]", reg_12);

    *sff8024_identifier = (uint8_t) reg_0;
    *ten_G_eth_compliance_codes = (uint8_t) reg_3;
    *eth_compliance_codes = (uint8_t) reg_6;
    *signaling_rate = (uint8_t) reg_12;

    rc = SFPMGR_SUCCESS;
exit:
    return rc;
}

/**
 * @brief Reads the RX LOS (Loss of Signal) status for a given interface.
 *
 * This function executes a script to retrieve the RX LOS status for the specified
 * interface and stores the result in the provided buffer.
 *
 * @param[out] output_buffer The buffer to store the script's output.
 * @param[in] buffer_size The size of the output buffer.
 * @param[in] ifname The name of the interface.
 *
 * @return 0 on success, -1 on failure.
 */
static int read_rxlos(char* output_buffer, size_t buffer_size, const char* ifname) {
#ifdef UNIT_TEST
    (void) ifname;
#endif
    int rc = SFPMGR_INVALID;
    int rc2;
    FILE* fp = NULL;
    char command[COMMAND_SIZE];

#ifdef UNIT_TEST
    rc2 = snprintf(command, sizeof(command), "/bin/sh %s", GET_RXLOS_FOR_UNIT_TESTS);
#else
    rc2 = snprintf(command, sizeof(command), "%s %s", RXLOS_SCRIPT_PATH, ifname);
#endif
    when_true_trace(rc2 < 0 || rc2 >= COMMAND_SIZE, exit, ERROR, "snprintf() failed rc=%d", rc2);
    SAH_TRACEZ_INFO(ME, "command='%s'", command);

    // Call the shell script using popen() to capture its output
    fp = popen(command, "r");
    if(fp == NULL) {
        SAH_TRACEZ_ERROR(ME, "popen failed for %s: %s", command, strerror(errno));
        return SFPMGR_INVALID;
    }

    // Read the output from the script and store it in the provided buffer
    if(fgets(output_buffer, buffer_size, fp) == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to read output buffer");
        pclose(fp);
        return SFPMGR_INVALID;
    }

    rc = SFPMGR_SUCCESS;
exit:
    if(fp) {
        pclose(fp);
    }
    return rc;
}

static int sfptype_poll(UNUSED const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret) {
    int retval = -1;
    /* current implementation seems to be always working on one i2c bus
     * in future have to extend to work on more than one */
    const cstring_t ifName;
    uint8_t sff8024_identifier = 0;
    uint8_t ten_G_eth_compliance_codes = 0;
    uint8_t eth_compliance_codes = 0;
    uint8_t signaling_rate = 0;
    bool present = false;
    bool rx_los = false;
    sfp_types_e sfp_type = SFP_UNSUPPORTED;
    char state_output[10];

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    ifName = GET_CHAR(args, "InterfaceName");
    when_str_empty_trace(ifName, exit, ERROR, "Passed interface name is empty");

    retval = get_sff8472_register_values(&sff8024_identifier, &ten_G_eth_compliance_codes,
                                         &eth_compliance_codes, &signaling_rate, ifName);
    when_failed_trace(retval, exit, ERROR, "Failed to get ethtool buffer values");
    SAH_TRACEZ_INFO(ME, "%s: %u %u %u %u", ifName, sff8024_identifier,
                    ten_G_eth_compliance_codes, eth_compliance_codes,
                    signaling_rate);

    if(sff8024_identifier == 0) {
        present = false;
        rx_los = true;
    } else {
        retval = read_rxlos(state_output, sizeof(state_output), ifName);
        when_failed_trace(retval, exit, ERROR, "Failed to read rx_los value");

        present = true;
        rx_los = true;

        if(strcmp(state_output, "UP\n") == 0) {
            rx_los = false;
        }

        if(((ten_G_eth_compliance_codes & 0xF0) != 0) ||
           ((eth_compliance_codes & 0xF3) != 0)) {
            sfp_type = SFP_OPTICAL_ETHERNET;
        } else if((eth_compliance_codes & 0xC) != 0) {
            sfp_type = SFP_ELECTRICAL_ETHERNET;
        } else {
            if((signaling_rate >= 12) && (signaling_rate <= 25)) {
                sfp_type = SFP_GPON;
            } else if(signaling_rate >= 80) {
                sfp_type = SFP_XGSPON;
            }
        }
        SAH_TRACEZ_INFO(ME, "sfp_type %d rx_los %s", sfp_type, rx_los ? "true" : "false");
    }
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, ret, "Present", present);
    amxc_var_add_key(bool, ret, "RxLoss", rx_los);
    amxc_var_add_key(uint32_t, ret, "SFPType", sfp_type);

exit:
    return retval;
}

static AMXM_CONSTRUCTOR sfptype_module_start(void) {
    int rc;
    amxm_shared_object_t* so = amxm_so_get_current();

    rc = amxm_module_register(&s_module, so, MOD_SFP_TYPE);
    when_failed_trace(rc, exit, ERROR, "Failed to create namespace %s", MOD_SFP_TYPE);

    rc = amxm_module_add_function(s_module, "sfptype-poll", sfptype_poll);
    when_failed_trace(rc, exit, ERROR, "Failed to register %s.%s()", MOD_SFP_TYPE,
                      "sfptype-poll");

    SAH_TRACEZ_NOTICE(ME, "Module loaded");
    rc = 0;

exit:
    return rc;
}
