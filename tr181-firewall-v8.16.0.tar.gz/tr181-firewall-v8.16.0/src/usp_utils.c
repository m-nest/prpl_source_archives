/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "usp_utils.h"
#include "firewall_utilities.h"
#include "firewall.h"
#include <amxc/amxc_macros.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#define ME "firewall"

static size_t last_char_position(amxc_string_t* buf) {
    return amxc_string_text_length(buf) - 1;
}

static bool is_dot_terminated(amxc_string_t* buf) {
    size_t pos = last_char_position(buf);
    return (pos > 0) && (strcmp(".", amxc_string_get(buf, pos)) == 0);
}

static void make_last_char_a_dot(amxc_string_t* buf) {
    when_false(last_char_position(buf) > 1, exit);

    if(!is_dot_terminated(buf)) {
        amxc_string_append(buf, ".", 1);
    }

exit:
    return;
}

void objpath_to_refparam(amxc_string_t* refpath) {
    // object paths end in dot "." but references don't (see USP spec)
    size_t pos = last_char_position(refpath);

    when_false(pos > 1, exit);

    if(is_dot_terminated(refpath)) {
        amxc_string_remove_at(refpath, pos, 1);
    }

exit:
    return;
}

char* refparam_to_objpath(const amxd_object_t* const obj, const char* const ref_param) {
    const char* value = NULL;
    char* object_ref = NULL;
    amxd_param_t* param = NULL;

    param = amxd_object_get_param_def(obj, ref_param);
    when_null_trace(param, exit, ERROR, "Failed to read parameter %s", ref_param);

    value = object_da_string(obj, ref_param);

    if(STRING_EMPTY(value)) {
        object_ref = strdup("");
    } else {
        amxc_string_t buf;

        amxc_string_init(&buf, 0);

        amxc_string_set(&buf, value);
        make_last_char_a_dot(&buf);

        object_ref = amxc_string_take_buffer(&buf);

        amxc_string_clean(&buf);
    }

exit:
    return object_ref;
}

void ip_lan_interface_objpath(amxc_string_t* objpath) {
    const char* opt = "ip_intf_lan";
    const char* opt_value = GET_CHAR(amxo_parser_get_config(fw_get_parser(), opt), NULL);

    when_str_empty_trace(opt_value, exit, ERROR, "%s not defined in ODL config section", opt);

    amxc_string_setf(objpath, "%s", opt_value);
    make_last_char_a_dot(objpath);

exit:
    return;
}