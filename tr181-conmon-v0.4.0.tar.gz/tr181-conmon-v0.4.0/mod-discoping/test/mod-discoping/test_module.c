/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_origin.h>

#include <debug/sahtrace.h>

#include "test_module.h"
#include "../common/mock.h"
#include "../common/mock_dhcp.h"

#include "discoping_list.h"

#define DEFAULT_MAIN_INTERVAL (60000)
#define DEFAULT_RETRY_INTERVAL (1000)
#define DEFAULT_FAIL_INTERVAL (15000)
#define DEFAULT_RETRIES_MAX (5)
#define DEFAULT_ALIAS(v) (v == 4 ? ("wan") : ("wan6"))

#define INITIAL_ARPNSERRORSSENT_ND (3)
#define INITIAL_ARPNSTOTALFAIL_ND (2)
#define INITIAL_TOTALDHCPRESTARTS_ND (1)

bool arp_fails = false;
bool nd_fails = false;
bool arp_send_fails = false;
bool nd_send_fails = false;

static void set_default_values(amxc_var_t* data, uint32_t ip_version) {
    const char* alias = DEFAULT_ALIAS(ip_version);
    amxc_var_add_key(cstring_t, data, "alias", alias);
    amxc_var_add_key(uint32_t, data, "ip_version", ip_version);
    amxc_var_add_key(cstring_t, data, "interface_name", "eth0");
    amxc_var_add_key(uint32_t, data, "retries_max", DEFAULT_RETRIES_MAX);
    amxc_var_add_key(uint32_t, data, "fail_interval", DEFAULT_FAIL_INTERVAL);
    amxc_var_add_key(cstring_t, data, "local_mac", "12:ab:d8:59:72:35");
    amxc_var_add_key(cstring_t, data, "logical_path", "Device.Logical.Interface.2.");
    amxc_var_add_key(uint32_t, data, "main_interval", DEFAULT_MAIN_INTERVAL);
    amxc_var_add_key(uint32_t, data, "retry_interval", DEFAULT_RETRY_INTERVAL);
}

#define assert_int_equal_expressive(a, b, origin) _assert_int_equal_expressive(a, #a, b, #b, origin)
static void _assert_int_equal_expressive(unsigned long a, const char* a_str, unsigned long b, const char* b_str, amxut_origin_t origin) {
    if(a == b) {
        return;
    }
    print_error("[  ERROR   ] --- CMP %s != %s\n", a_str, b_str);
    _assert_int_equal(a, b, AMXUT_ORIGIN_TO_CMOCKA(origin));
}

#define assert_entry(entry, arpns_total_fail, arpns_errors_sent, total_dhcp_restarts, state) _assert_entry(entry, arpns_total_fail, arpns_errors_sent, total_dhcp_restarts, state, AMXUT_ORIGIN)
static void _assert_entry(active_discoping_t* entry, uint32_t arpns_total_fail, uint32_t arpns_errors_sent, uint32_t total_dhcp_restarts, uint32_t state, UNUSED amxut_origin_t origin) {
    assert_int_equal_expressive(entry->arpns_total_fail, arpns_total_fail, origin);
    assert_int_equal_expressive(entry->arpns_errors_sent, arpns_errors_sent, origin);
    assert_int_equal_expressive(entry->total_dhcp_restarts, total_dhcp_restarts, origin);
    assert_int_equal_expressive(entry->state, state, origin);
}

int test_setup(void** state) {
    amxut_bus_setup(state);

    mock_dhcp_setup();

    assert_int_equal(_dummy_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 0);

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_dummy_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    mock_dhcp_teardown();
    amxm_close_all();

    amxut_bus_teardown(state);
    amxut_bus_handle_events();

    return 0;
}

void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, "target_module", "./target_module.so"), 0);

    assert_int_equal(discoping_list_size(), 0);
}

void test_has_correct_functions(UNUSED void** state) {
    assert_true(amxm_has_function("target_module", "conmon-ctrl", "update-config"));
    assert_true(amxm_has_function("target_module", "conmon-ctrl", "stop"));

    assert_int_equal(discoping_list_size(), 0);
}

void test_add_arp(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, 4);

    update_config(NULL, &data, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 1);

    amxc_var_clean(&data);
}

void test_add_nd(UNUSED void** state) {
    amxc_var_t data;
    active_discoping_t* entry_ipv6 = NULL;
    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, 6);
    amxc_var_add_key(uint32_t, &data, "arpns_errors_sent", INITIAL_ARPNSERRORSSENT_ND);
    amxc_var_add_key(uint32_t, &data, "arpns_total_fail", INITIAL_ARPNSTOTALFAIL_ND);
    amxc_var_add_key(uint32_t, &data, "total_dhcp_restarts", INITIAL_TOTALDHCPRESTARTS_ND);

    update_config(NULL, &data, NULL);
    amxut_bus_handle_events();

    entry_ipv6 = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv6, INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, DISABLED);
    assert_int_equal(entry_ipv6->retry_current, 0);

    amxc_var_clean(&data);
}

void test_short_disconnect(UNUSED void** state) {
    amxc_var_t data_ipv4;
    amxc_var_t data_ipv6;
    amxc_var_t* up_ipv4 = NULL;
    amxc_var_t* up_ipv6 = NULL;
    amxc_var_t* phys_up_ipv4 = NULL;
    amxc_var_t* phys_up_ipv6 = NULL;
    amxc_var_t* wan_ipv4 = NULL;
    amxc_var_t* wan_ipv6 = NULL;
    active_discoping_t* entry_ipv4 = NULL;
    active_discoping_t* entry_ipv6 = NULL;
    const char* wan_addr4 = "192.168.1.1";
    const char* wan_addr6 = "ab:75:d8:30:8c:39";

    amxc_var_init(&data_ipv4);
    amxc_var_init(&data_ipv6);
    amxc_var_set_type(&data_ipv4, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&data_ipv6, AMXC_VAR_ID_HTABLE);

    set_default_values(&data_ipv4, 4);
    amxc_var_add_key(cstring_t, &data_ipv4, "local_mac", "12:ab:d8:59:72:35");
    wan_ipv4 = amxc_var_add_key(cstring_t, &data_ipv4, "wan_ip", wan_addr4);
    amxc_var_add_key(cstring_t, &data_ipv4, "local_ip", "192.168.1.100");
    amxc_var_add_key(cstring_t, &data_ipv4, "ll_interface_path", "Device.IP.Interface.2.");
    up_ipv4 = amxc_var_add_key(bool, &data_ipv4, "up_changed", true);
    phys_up_ipv4 = amxc_var_add_key(bool, &data_ipv4, "physup_changed", true);

    set_default_values(&data_ipv6, 6);
    amxc_var_add_key(cstring_t, &data_ipv6, "local_mac", "12:ab:d8:59:72:35");
    wan_ipv6 = amxc_var_add_key(cstring_t, &data_ipv6, "wan_ip", wan_addr6);
    amxc_var_add_key(cstring_t, &data_ipv6, "local_ip", "aa:ab:cc:10:ee:22");
    amxc_var_add_key(cstring_t, &data_ipv6, "ll_interface_path", "Device.IP.Interface.2.");
    up_ipv6 = amxc_var_add_key(bool, &data_ipv6, "up_changed", true);
    phys_up_ipv6 = amxc_var_add_key(bool, &data_ipv6, "physup_changed", true);

    update_config(NULL, &data_ipv4, NULL);
    update_config(NULL, &data_ipv6, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 2);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry_ipv4 = find_or_add_discoping_item(&data_ipv4);
    assert_entry(entry_ipv4, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, MAINLOOP);
    assert_int_equal(entry_ipv4->retry_current, 0);
    assert_int_equal(discoping_list_size(), 2);

    entry_ipv6 = find_or_add_discoping_item(&data_ipv6);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv6, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, MAINLOOP);
    assert_int_equal(entry_ipv6->retry_current, 0);

    // Everything is running OK up until this moment.
    // Now simulate a link loss.
    amxc_var_set(bool, up_ipv4, false);
    amxc_var_set(bool, up_ipv6, false);
    amxc_var_set(bool, phys_up_ipv4, false);
    amxc_var_set(bool, phys_up_ipv6, false);
    amxc_var_set(cstring_t, wan_ipv4, "");
    amxc_var_set(cstring_t, wan_ipv6, "");

    update_config(NULL, &data_ipv4, NULL);
    update_config(NULL, &data_ipv6, NULL);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry_ipv4 = find_or_add_discoping_item(&data_ipv4);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv4, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, WAN_DOWN);
    assert_int_equal(entry_ipv4->retry_current, 0);

    entry_ipv6 = find_or_add_discoping_item(&data_ipv6);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv6, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, WAN_DOWN);
    assert_int_equal(entry_ipv6->retry_current, 0);

    // Link loss is fixed.
    amxc_var_set(bool, up_ipv4, true);
    amxc_var_set(bool, up_ipv6, true);
    amxc_var_set(bool, phys_up_ipv4, true);
    amxc_var_set(bool, phys_up_ipv6, true);
    amxc_var_set(cstring_t, wan_ipv4, wan_addr4);
    amxc_var_set(cstring_t, wan_ipv6, wan_addr6);

    update_config(NULL, &data_ipv4, NULL);
    update_config(NULL, &data_ipv6, NULL);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry_ipv4 = find_or_add_discoping_item(&data_ipv4);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv4, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, MAINLOOP);
    assert_int_equal(entry_ipv4->retry_current, 0);

    entry_ipv6 = find_or_add_discoping_item(&data_ipv6);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry_ipv6, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, MAINLOOP);
    assert_int_equal(entry_ipv6->retry_current, 0);

    stop(NULL, &data_ipv4, NULL);
    stop(NULL, &data_ipv6, NULL);
    amxut_bus_handle_events();

    amxc_var_clean(&data_ipv4);
    amxc_var_clean(&data_ipv6);
}

void test_start_arp(UNUSED void** state) {
    amxc_var_t data;
    active_discoping_t* entry = NULL;
    uint32_t ip_version = 4;
    int i = 0;
    amxc_var_t* value = NULL;

    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, ip_version);

    amxc_var_add_key(cstring_t, &data, "local_mac", "12:ab:d8:59:72:35");
    amxc_var_add_key(cstring_t, &data, "wan_ip", "192.168.1.1");
    amxc_var_add_key(cstring_t, &data, "local_ip", "192.168.1.100");
    amxc_var_add_key(cstring_t, &data, "ll_interface_path", "Device.IP.Interface.2.");
    amxc_var_add_key(bool, &data, "up_changed", true);
    amxc_var_add_key(bool, &data, "physup_changed", true);

    update_config(NULL, &data, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 2);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    arp_fails = true;
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, 0 /*arpns_total_fail*/, 0 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    arp_send_fails = true;

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, 1 /*arpns_total_fail*/, 1 /*arpns_errors_sent*/, 0 /*TotalDHCPRestart*/, RETRY);
    assert_int_equal(entry->retry_current, 1);

    // starts failing now
    for(i = 0; i < DEFAULT_RETRIES_MAX - 2; i++) {
        amxut_timer_go_to_future_ms(1);
        amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

        entry = find_or_add_discoping_item(&data);
        assert_int_equal(discoping_list_size(), 2);
        assert_int_equal(entry->arpns_total_fail, i + 2);
        assert_int_equal(entry->retry_current, i + 2);
    }
    mock_dhcp_expect_dhcpv4_toggles(1);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    mock_dhcp_all_expectations_succeeded();

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_int_equal(entry->arpns_total_fail, i + 2);
    assert_int_equal(entry->retry_current, 0);


    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX /*arpns_total_fail*/, 1 /*arpns_errors_sent*/, 1 /*TotalDHCPRestart*/, WAN_DOWN);
    assert_int_equal(entry->retry_current, 0);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX /*arpns_total_fail*/, 1 /*arpns_errors_sent*/, 1 /*TotalDHCPRestart*/, WAN_DOWN);
    assert_int_equal(entry->retry_current, 0);

    arp_fails = false;

    // verify current wan ip
    assert_string_equal(entry->wan_ip, "192.168.1.1");
    // update data->wan_ip
    value = GET_ARG(&data, "wan_ip");
    amxc_var_set(cstring_t, value, "192.168.42.1");
    // update config
    update_config(NULL, &data, NULL);
    // verify new wan_ip
    assert_string_equal(entry->wan_ip, "192.168.42.1");

    amxc_var_clean(&data);
}

void test_start_nd(UNUSED void** state) {
    amxc_var_t data;
    active_discoping_t* entry = NULL;
    uint32_t ip_version = 6;
    int i = 0;

    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, ip_version);

    amxc_var_add_key(cstring_t, &data, "local_mac", "12:ab:d8:59:72:35");
    amxc_var_add_key(cstring_t, &data, "wan_ip", "ab:75:d8:30:8c:39");
    amxc_var_add_key(cstring_t, &data, "local_ip", "aa:ab:cc:10:ee:22");
    amxc_var_add_key(cstring_t, &data, "ll_interface_path", "Device.IP.Interface.2.");
    amxc_var_add_key(bool, &data, "up_changed", true);
    amxc_var_add_key(bool, &data, "physup_changed", true);

    update_config(NULL, &data, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 2);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    nd_fails = true;
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    // starts failing now
    for(i = 0; i < DEFAULT_RETRIES_MAX - 2; i++) {
        amxut_timer_go_to_future_ms(1);
        amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

        entry = find_or_add_discoping_item(&data);
        assert_int_equal(discoping_list_size(), 2);
        assert_int_equal(entry->arpns_total_fail, i + 1 + INITIAL_ARPNSTOTALFAIL_ND);
        assert_int_equal(entry->retry_current, i + 1);
    }
    nd_fails = false;
    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 2 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, RETRY);
    assert_int_equal(entry->retry_current, DEFAULT_RETRIES_MAX - 2);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 1 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, RETRY);
    assert_int_equal(entry->retry_current, DEFAULT_RETRIES_MAX - 1);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 1 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    nd_send_fails = true;

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 1 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND + 1, INITIAL_TOTALDHCPRESTARTS_ND, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    amxc_var_clean(&data);
}

void test_remove_nd(UNUSED void** state) {
    amxc_var_t data;

    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, 6);

    stop(NULL, &data, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 1);

    amxc_var_clean(&data);
}

void test_nd_indirect_disconnect(UNUSED void** state) {
    amxc_var_t data;
    active_discoping_t* entry = NULL;
    uint32_t ip_version = 6;
    int i = 0;

    amxc_var_init(&data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, ip_version);

    amxc_var_add_key(cstring_t, &data, "local_mac", "12:ab:d8:59:72:35");
    amxc_var_add_key(cstring_t, &data, "wan_ip", "ab:75:d8:30:8c:39");
    amxc_var_add_key(cstring_t, &data, "local_ip", "aa:ab:cc:10:ee:22");
    amxc_var_add_key(cstring_t, &data, "ll_interface_path", "Device.IP.Interface.2.");
    amxc_var_add_key(bool, &data, "up_changed", true);
    amxc_var_add_key(bool, &data, "physup_changed", true);

    update_config(NULL, &data, NULL);
    amxut_bus_handle_events();

    assert_int_equal(discoping_list_size(), 2);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    nd_fails = true;
    amxut_timer_go_to_future_ms(DEFAULT_MAIN_INTERVAL - DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    // starts failing now
    for(i = 0; i < DEFAULT_RETRIES_MAX - 2; i++) {
        amxut_timer_go_to_future_ms(1);
        amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

        entry = find_or_add_discoping_item(&data);
        assert_int_equal(discoping_list_size(), 2);
        assert_int_equal(entry->arpns_total_fail, i + 1 + INITIAL_ARPNSTOTALFAIL_ND);
        assert_int_equal(entry->retry_current, i + 1);
    }
    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 2 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, RETRY);
    assert_int_equal(entry->retry_current, DEFAULT_RETRIES_MAX - 2);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX - 1 + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND, RETRY);
    assert_int_equal(entry->retry_current, DEFAULT_RETRIES_MAX - 1);

    mock_dhcp_expect_dhcpv6_toggles(1);
    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    mock_dhcp_all_expectations_succeeded();

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND + 1, WAN_DOWN);
    assert_int_equal(entry->retry_current, 0);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND + 1, WAN_DOWN);
    assert_int_equal(entry->retry_current, 0);

    amxut_timer_go_to_future_ms(1);
    amxut_timer_go_to_future_ms(DEFAULT_FAIL_INTERVAL);
    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND + 1, WAN_DOWN);
    assert_int_equal(entry->retry_current, 0);

    // Reconnected
    nd_fails = false;
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    set_default_values(&data, ip_version);
    amxc_var_add_key(bool, &data, "dhcpup_changed", true);
    update_config(NULL, &data, NULL);
    amxut_timer_go_to_future_ms(1);

    entry = find_or_add_discoping_item(&data);
    assert_int_equal(discoping_list_size(), 2);
    assert_entry(entry, DEFAULT_RETRIES_MAX + INITIAL_ARPNSTOTALFAIL_ND, INITIAL_ARPNSERRORSSENT_ND, INITIAL_TOTALDHCPRESTARTS_ND + 1, MAINLOOP);
    assert_int_equal(entry->retry_current, 0);

    amxc_var_clean(&data);
}
