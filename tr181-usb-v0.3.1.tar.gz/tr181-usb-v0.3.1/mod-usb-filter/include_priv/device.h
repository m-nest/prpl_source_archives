#ifndef __USB_DEVICE_H__
#define __USB_DEVICE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>

typedef enum _device_type {
    DEVICE,
    ALLOWED_DEVICE,
} device_type_t;

typedef enum _auth_state {
    UNDEFINED,
    ALLOWED,
    BLOCKED,
    LAST,
} auth_state_t;

typedef struct usb_device {
    char* device_class;
    char* device_subclass;
    char* device_protocol;
    char* product_id;
    char* vendor_id;
    amxc_llist_t* interface_list;
    device_type_t type;

    // AllowedDevice specific
    bool enable;

    // Device specific
    auth_state_t authorized;
    char* sysfs_id;
    amxd_object_t* object;
} usb_device_t;

typedef struct usb_device_interface {
    char* interface_class;
    char* interface_protocol;
    char* interface_subclass;
} usb_device_interface_t;

/**
 * @brief Find an interface from an internal device structure.
 *
 * @param state Enum value representing authentication state.
 * @return When allowed 1, When blocked 0, -1 otherwise
 */
int auth_state_to_int(auth_state_t state);

/**
 * @brief Create an internal device structure.
 *
 * @param type Enum value of USB device type, either DEVICE or ALLOWED_DEVICE.
 * @param template_object Template object of the Device Object.
 * @param parameters Hashtable containing device settings.
 * @return Internal usb device object
 */
usb_device_t* create_usb_device(device_type_t type, amxd_object_t* template_object, amxc_var_t* args);

/**
 * @brief Cleanup an internal device structure.
 *
 * @param device Internal device structure.
 */
void usb_device_clean(usb_device_t* usb_device);

/**
 * @brief Create an internal interface structure.
 *
 * @param interface String representation of interface class, subclass and protocol
 * @return Internal usb interface object
 */
usb_device_interface_t create_usb_device_interface(const char* interface);

/**
 * @brief Cleanup an internal interface structure.
 *
 * @param interface Internal usb interface object
 */
void usb_device_interface_clean(usb_device_interface_t* interface);

/**
 * @brief Change interface for a certain internal usb device structure
 *
 * @param device Internal device structure.
 * @param old_intf Old interface structure.
 * @param new_parameters Hashtable containing interface settings.
 */
void usb_device_change_interface(usb_device_t* device, usb_device_interface_t* old_intf, const amxc_var_t* const new_parameters);

#ifdef __cplusplus
}
#endif

#endif // __USB_DEVICE_H__
