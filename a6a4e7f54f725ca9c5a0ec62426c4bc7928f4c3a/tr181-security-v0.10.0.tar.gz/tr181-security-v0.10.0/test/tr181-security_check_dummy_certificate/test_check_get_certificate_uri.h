/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#ifndef __TEST_CHECK_GET_CERTIFICATE_URI_H__
#define __TEST_CHECK_GET_CERTIFICATE_URI_H__

void test_check_get_certificate_uri(void** state);

#endif // __TEST_CHECK_GET_CERTIFICATE_URI_H__