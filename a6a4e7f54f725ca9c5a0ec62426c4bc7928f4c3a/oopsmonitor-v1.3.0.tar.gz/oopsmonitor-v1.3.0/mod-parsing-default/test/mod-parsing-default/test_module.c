/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxb/amxb_types.h>

#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "test_module.h"
#include "oopsmonitor.h"
#include "mod_parsing_default.h"

static amxd_dm_t dm;
static amxo_parser_t parser;

static void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    handle_events();
    return 0;
}

int test_teardown(UNUSED void** state) {
    amxm_close_all();

    amxo_resolver_import_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, "target_module", "../modules_under_test/target_module.so"), 0);
    handle_events();
}

void test_mod_get_process_ID(UNUSED void** state) {
    amxc_var_t ret_data;
    amxc_var_t data;

    char* test_input = "CPU: 0 PID: 292 Comm: ash Tainted: P                  5.4.213 #0";
    char* test_output = "ash";

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_PROCESS_ID_INPUT, test_input);

    assert_int_equal(mod_get_process_ID(NULL, &data, &ret_data), 0);

    assert_int_equal(strcmp(test_output, GET_CHAR(&ret_data, GET_PROCESS_ID_OUTPUT)), 0);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);
}

static int helper_test_mod_get_process_ID(char* test_input) {
    amxc_var_t ret_data;
    amxc_var_t data;
    int rv = -1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_PROCESS_ID_INPUT, test_input);

    rv = mod_get_process_ID(NULL, &data, &ret_data);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);

    return rv;
}

void test_mod_get_process_ID_invalid(UNUSED void** state) {
    int rv = -1;

    rv = helper_test_mod_get_process_ID(NULL);
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_process_ID("");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_process_ID("CPU:");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_process_ID("CP");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_process_ID("CPU: 1 PID: 2 Comm:");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_process_ID("Something completely different");
    assert_int_equal(rv, 1);
}

void test_mod_get_last_instruction(UNUSED void** state) {
    amxc_var_t ret_data;
    amxc_var_t data;

    char* test_input = "LR : 0x0082ee40";
    char* test_output = "0x0082ee40";

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_LAST_INSTRUCTION_INPUT, test_input);

    assert_int_equal(mod_get_last_instruction(NULL, &data, &ret_data), 0);

    assert_int_equal(strcmp(test_output, GET_CHAR(&ret_data, GET_LAST_INSTRUCTION_OUTPUT)), 0);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);
}

static int helper_test_mod_get_last_instruction(char* test_input) {
    amxc_var_t ret_data;
    amxc_var_t data;
    int rv = -1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_LAST_INSTRUCTION_INPUT, test_input);

    rv = mod_get_last_instruction(NULL, &data, &ret_data);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);

    return rv;
}

void test_mod_get_last_instruction_invalid(UNUSED void** state) {
    int rv = -1;

    rv = helper_test_mod_get_last_instruction(NULL);
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_last_instruction("");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_last_instruction("***");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_last_instruction("LR :");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_last_instruction("Something completely different");
    assert_int_equal(rv, 1);
}

void test_mod_get_reason(UNUSED void** state) {
    amxc_var_t ret_data;
    amxc_var_t data;

    char* test_input = "Kernel panic - not syncing: sysrq triggered crash";
    char* test_output = "SysRq triggered crash";

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_REASON_INPUT, test_input);

    assert_int_equal(mod_get_reason(NULL, &data, &ret_data), 0);

    assert_int_equal(strcmp(test_output, GET_CHAR(&ret_data, GET_REASON_OUTPUT)), 0);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);
}

static int helper_test_mod_get_reason(char* test_input) {
    amxc_var_t ret_data;
    amxc_var_t data;
    int rv = -1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_REASON_INPUT, test_input);

    rv = mod_get_reason(NULL, &data, &ret_data);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);

    return rv;
}

void test_mod_get_reason_invalid(UNUSED void** state) {
    int rv = -1;

    rv = helper_test_mod_get_reason(NULL);
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_reason("");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_reason("Kernel panic");
    assert_int_equal(rv, 1);
}

void test_mod_get_useful_log(UNUSED void** state) {
    amxc_var_t ret_data;
    amxc_var_t data;

    char* test_input = "<4>[   17.555304] smart_antenna: module license 'Proprietary' taints kernel.";
    char* test_output = "smart_antenna: module license 'Proprietary' taints kernel.";

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_USEFUL_LOG_INPUT, test_input);

    assert_int_equal(mod_get_useful_log(NULL, &data, &ret_data), 0);

    assert_int_equal(strcmp(test_output, GET_CHAR(&ret_data, GET_USEFUL_LOG_OUTPUT)), 0);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);
}

static int helper_test_mod_get_useful_log(char* test_input) {
    amxc_var_t ret_data;
    amxc_var_t data;
    int rv = -1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_USEFUL_LOG_INPUT, test_input);

    rv = mod_get_useful_log(NULL, &data, &ret_data);

    amxc_var_clean(&data);
    amxc_var_clean(&ret_data);

    return rv;
}

void test_mod_get_useful_log_invalid(UNUSED void** state) {
    int rv = -1;

    rv = helper_test_mod_get_useful_log(NULL);
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("***");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("<>[ Log");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("<XXX>[ Log");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("<X>[ Log");
    assert_int_equal(rv, 1);

    rv = helper_test_mod_get_useful_log("<X>[ ]");
    assert_int_equal(rv, 1);
}