/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>

#include <imtp/imtp_connection.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_mqtt.h"

#include "mock.h"
#include "test_common.h"
#include "test_profile_mqtt.h"

imtp_connection_t* con_listen = NULL;
int fd_accept = -1;

static amxd_status_t _CreateListenSocket(UNUSED amxd_object_t* object,
                                         UNUSED amxd_function_t* func,
                                         UNUSED amxc_var_t* args,
                                         UNUSED amxc_var_t* ret) {
    const char* uri = "usp:/tmp/bulkdata-mqtt-1.sock";
    assert_int_equal(imtp_connection_listen(&con_listen, uri, NULL), 0);
    return amxd_status_ok;
}

int test_mqtt_profile_setup(UNUSED void** state) {
    const char* odl_mqtt = "../common/tr181-mqtt.odl";
    amxo_parser_t* parser = NULL;

    test_setup(NULL);
    capture_sigalrm();

    parser = test_get_parser();
    amxo_resolver_ftab_add(parser, "CreateListenSocket", AMXO_FUNC(_CreateListenSocket));
    amxo_parser_parse_file(parser, odl_mqtt, amxd_dm_get_root(mock_get_dm()));

    return 0;
}

int test_mqtt_profile_teardown(UNUSED void** state) {
    imtp_connection_t* con_accepted = imtp_connection_get_con(fd_accept);
    imtp_connection_delete(&con_accepted);
    imtp_connection_delete(&con_listen);
    test_teardown(NULL);

    return 0;
}

static void add_profile_mqtt(const char* alias, uint32_t interval) {
    amxb_bus_ctx_t* bus_ctx = test_get_bus_ctx();
    amxc_var_t values;
    amxc_var_t ret;
    amxc_string_t path;

    amxc_var_init(&values);
    amxc_var_init(&ret);
    amxc_string_init(&path, 0);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, "Enable", true);
    amxc_var_add_key(uint32_t, &values, "ReportingInterval", interval);
    amxc_var_add_key(cstring_t, &values, "Alias", alias);
    amxc_var_add_key(cstring_t, &values, "Protocol", "MQTT");

    amxc_string_setf(&path, "%sProfile.", ROOT_OBJECT_NAME);
    assert_int_equal(amxb_add(bus_ctx, amxc_string_get(&path, 0), 0, NULL, &values, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "Reference", "MQTT.Client.1.");
    amxc_var_add_key(cstring_t, &values, "PublishTopic", "test-topic");
    amxc_string_appendf(&path, "%s.MQTT.", alias);
    assert_int_equal(amxb_set(bus_ctx, amxc_string_get(&path, 0), &values, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    amxc_string_clean(&path);
    amxc_var_clean(&ret);
    amxc_var_clean(&values);
}

void test_can_add_profile_mqtt(UNUSED void** state) {
    amxd_object_t* object = NULL;
    const char* alias = "mqtt-profile-1";

    add_profile_mqtt(alias, 15);
    handle_events();

    set_bulkdata_enable(true);
    handle_events();
    fd_accept = imtp_connection_accept(con_listen);
    assert_int_not_equal(fd_accept, -1);

    object = amxd_dm_findf(mock_get_dm(), "MQTT.Client.1.");
    assert_non_null(object);
    assert_true(amxd_object_get_value(bool, object, "Enable", NULL));

    object = amxd_dm_findf(mock_get_dm(), "%sProfile.%s.MQTT.", ROOT_OBJECT_NAME, alias);
    assert_non_null(object);
    assert_non_null(object->priv);
}

void test_can_send_report_to_mqtt_client(UNUSED void** state) {
    imtp_connection_t* con_accepted = imtp_connection_get_con(fd_accept);
    imtp_frame_t* frame = NULL;
    const imtp_tlv_t* tlv_json = NULL;
    const imtp_tlv_t* tlv_mqtt_props = NULL;
    char* json_string = NULL;
    char* mqtt_props_buffer = NULL;
    const char* profile = "BulkData.Profile.1.";
    amxc_var_t json_var;
    amxc_var_t mqtt_props;

    amxc_var_init(&json_var);
    amxc_var_init(&mqtt_props);

    add_parameter(profile, "MQTT.Client.1.Enable", NULL);
    handle_events();
    go_to_future_ms(15000);

    assert_non_null(con_accepted);
    assert_int_equal(imtp_connection_read_frame(con_accepted, &frame), 0);

    tlv_json = imtp_frame_get_first_tlv(frame, imtp_tlv_type_json);
    assert_non_null(tlv_json);

    json_string = (char*) calloc(1, tlv_json->length + 1);
    strncpy(json_string, (char*) tlv_json->value + tlv_json->offset, tlv_json->length);
    amxc_var_set(cstring_t, &json_var, json_string);
    amxc_var_dump(&json_var, STDOUT_FILENO);

    tlv_mqtt_props = imtp_frame_get_first_tlv(frame, imtp_tlv_type_mqtt_props);
    assert_non_null(tlv_mqtt_props);

    mqtt_props_buffer = (char*) calloc(1, tlv_mqtt_props->length + 1);
    memcpy(mqtt_props_buffer, (uint8_t*) tlv_mqtt_props->value + tlv_mqtt_props->offset, tlv_mqtt_props->length);

    amxc_var_set(jstring_t, &mqtt_props, mqtt_props_buffer);
    amxc_var_cast(&mqtt_props, AMXC_VAR_ID_ANY);
    amxc_var_dump(&mqtt_props, STDOUT_FILENO);
    assert_string_equal(GET_CHAR(&mqtt_props, "content-type"), "application/json; charset=UTF-8");

    free(mqtt_props_buffer);
    free(json_string);
    amxc_var_clean(&mqtt_props);
    amxc_var_clean(&json_var);
    imtp_frame_delete(&frame);
}

void test_second_profile_reuses_mqtt_client(UNUSED void** state) {
    amxd_object_t* profile_1 = NULL;
    amxd_object_t* profile_2 = NULL;
    mqtt_connection_t* mqtt_con = NULL;
    const char* alias = "mqtt-profile-2";
    imtp_connection_t* con_accepted = imtp_connection_get_con(fd_accept);
    imtp_frame_t* frame = NULL;
    const imtp_tlv_t* tlv_json = NULL;
    char* json_string = NULL;
    amxc_var_t json_var;

    amxc_var_init(&json_var);

    add_profile_mqtt(alias, 15);
    handle_events();

    profile_2 = amxd_dm_findf(mock_get_dm(), "%sProfile.%s.MQTT", ROOT_OBJECT_NAME, alias);
    assert_non_null(profile_2);
    assert_non_null(profile_2->priv);

    profile_1 = amxd_dm_findf(mock_get_dm(), "BulkData.Profile.1.MQTT.");
    assert_non_null(profile_1);
    assert_non_null(profile_1->priv);
    assert_ptr_not_equal(profile_1, profile_2);
    assert_ptr_equal(profile_1->priv, profile_2->priv);

    mqtt_con = (mqtt_connection_t*) profile_1->priv;
    assert_int_equal(mqtt_con->counter, 2);

    add_parameter("BulkData.Profile.2.", "MQTT.Client.1.Alias", NULL);
    handle_events();

    // Wait for report 1
    go_to_future_ms(15000);

    assert_non_null(con_accepted);
    assert_int_equal(imtp_connection_read_frame(con_accepted, &frame), 0);

    tlv_json = imtp_frame_get_first_tlv(frame, imtp_tlv_type_json);
    assert_non_null(tlv_json);

    json_string = (char*) calloc(1, tlv_json->length + 1);
    strncpy(json_string, (char*) tlv_json->value + tlv_json->offset, tlv_json->length);
    amxc_var_set(jstring_t, &json_var, json_string);
    amxc_var_cast(&json_var, AMXC_VAR_ID_ANY);
    amxc_var_dump(&json_var, STDOUT_FILENO);
    assert_true(GETP_BOOL(&json_var, "Report.0.MQTT.Client.1.Enable"));

    // Clean up data for next read
    imtp_frame_delete(&frame);
    free(json_string);

    // Wait for report 2
    go_to_future_ms(15000);

    assert_non_null(con_accepted);
    assert_int_equal(imtp_connection_read_frame(con_accepted, &frame), 0);

    tlv_json = imtp_frame_get_first_tlv(frame, imtp_tlv_type_json);
    assert_non_null(tlv_json);

    json_string = (char*) calloc(1, tlv_json->length + 1);
    strncpy(json_string, (char*) tlv_json->value + tlv_json->offset, tlv_json->length);
    amxc_var_set(jstring_t, &json_var, json_string);
    amxc_var_cast(&json_var, AMXC_VAR_ID_ANY);
    amxc_var_dump(&json_var, STDOUT_FILENO);
    assert_string_equal(GETP_CHAR(&json_var, "Report.0.MQTT.Client.1.Alias"), "test-client");

    free(json_string);
    amxc_var_clean(&json_var);
    imtp_frame_delete(&frame);
}

void test_can_disable_mqtt_profile(UNUSED void** state) {
    amxd_trans_t trans;
    amxd_object_t* object = NULL;
    mqtt_connection_t* mqtt_con = NULL;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "BulkData.Profile.2.");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    assert_int_equal(amxd_trans_apply(&trans, mock_get_dm()), 0);
    handle_events();

    object = amxd_dm_findf(mock_get_dm(), "BulkData.Profile.1.MQTT.");
    assert_non_null(object);
    assert_non_null(object->priv);

    mqtt_con = (mqtt_connection_t*) object->priv;
    assert_int_equal(mqtt_con->counter, 1);

    amxd_trans_clean(&trans);
}
