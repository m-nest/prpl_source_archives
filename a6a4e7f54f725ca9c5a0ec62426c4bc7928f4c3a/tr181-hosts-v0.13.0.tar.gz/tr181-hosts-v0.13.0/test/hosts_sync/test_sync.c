/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdarg.h>
#include <setjmp.h>
#include <unistd.h>
#include <cmocka.h>
#include <string.h>

#include "hosts_manager.h"
#include "hosts_sync.h"
#include "hosts_utils.h"
#include "hosts_accesscontroller.h"

#include "../common/mock.h"
#include "../common/mock_netmodel.h"
#include "../common/common_functions.h"
#include "test_sync.h"

#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_util.h>

#define DEVICE_TEST_ODL "../common/mock_devices_dm.odl"
#define MOCK_TEST_ODL "mock_test.odl"
#define NETMODEL_TEST_ODL "../common/mock_netmodel_dm.odl"
#define HOSTS_DEFINITION_ODL "../../odl/hosts-manager-definitions.odl"

#define TEST_FILES "./test_files"

#define HOSTS_QUERY_EXPRESSION "lan and not self and physical and .Master==\"\""
#define HOSTS_NETMODEL_LUCKY_INTF_TAGS "bridgeport and not vlan"
#define HOSTS_NETMODEL_FIRST_PARAM_TAGS "ip"
#define GMAP_DEV_IFACE_NAME_2 "ethIntf-ETH2"
#define GMAP_DEV_IFACE_NAME_4 "ssid-vap5g0priv"

#define GMAP_DEV_ALIAS_5 "ID-c434b692-66e3-42a8-beef-5e99a7099d15"
#define GMAP_DEV_ALIAS_6 "ID-c434b692-66e3-42a8-beef-5e99a7089d16"
#define GMAP_DEV_ALIAS_7 "ID-c434b692-66e3-42a8-beef-5e99a7089d17"

static amxd_dm_t* dm = NULL;
static amxo_parser_t* parser = NULL;
static amxb_bus_ctx_t* bus_ctx = NULL;


/**
   @brief Mocks the mod_pcm_svc default import implementation.

   @warning
   This implementation does not actually restore the data, so any verification
   checks afterwards can't include the actual restored data beyond what the custom
   gmap-server import implementation can restore.

   @implements amxd_object_fn_t
 */
static amxd_status_t s_mock_mod_pcm_pcmimport(UNUSED amxd_object_t* object,
                                              UNUSED amxd_function_t* func,
                                              amxc_var_t* args,
                                              UNUSED amxc_var_t* ret) {
    const char* source = mock_type(const char*);
    const char* file = mock_type(const char*);
    int line = mock_type(int);
    amxc_var_t* data = GET_ARG(args, "data");

    _assert_variant_equal_from_file(data, source, file, line);
    return amxd_status_ok;
}

static void _expect_pcm_import(const char* source,
                               const char* file,
                               int line) {
    assert_non_null(source);
    will_return(s_mock_mod_pcm_pcmimport, source);
    will_return(s_mock_mod_pcm_pcmimport, file);
    will_return(s_mock_mod_pcm_pcmimport, line);
}

#define expect_pcm_import(source) _expect_pcm_import(source, __FILE__, __LINE__)

static void s_create_pcmimport_function(void) {
    amxd_object_t* devices_obj = amxd_object_findf(amxd_dm_get_root(amxut_bus_dm()), "Hosts.");
    amxd_function_t* function = NULL;
    assert_int_equal(0, amxd_function_new(&function,
                                          "PcmImport",
                                          AMXC_VAR_ID_NULL,
                                          s_mock_mod_pcm_pcmimport));
    assert_int_equal(0, amxd_function_set_attr(function, amxd_fattr_protected, true));
    assert_int_equal(0, amxd_function_new_arg(function, "data", AMXC_VAR_ID_HTABLE, NULL));
    assert_int_equal(0, amxd_function_arg_is_attr_set(function, "data", amxd_aattr_in));
    assert_int_equal(0, amxd_function_arg_is_attr_set(function, "data", amxd_aattr_mandatory));
    assert_int_equal(0, amxd_object_add_function(devices_obj, function));
}

int test_setup(void** state) {
    amxd_object_t* root_obj = NULL;

    amxut_bus_setup(state);

    sahTraceOpen("test", TRACE_TYPE_STDERR);
    sahTraceSetLevel(TRACE_LEVEL_ERROR);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);

    dm = amxut_bus_dm();
    parser = amxut_bus_parser();
    bus_ctx = amxut_bus_ctx();
    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    resolver_add_all_functions(parser);
    test_init_dummy_fn_resolvers(parser);

    amxo_resolver_import_open(parser, "/usr/lib/amx/modules/mod-dmext.so", "mod-dmext", 0);
    amxut_dm_load_odl(DEVICE_TEST_ODL);
    amxut_dm_load_odl(NETMODEL_TEST_ODL);
    amxut_dm_load_odl(MOCK_TEST_ODL);
    amxut_dm_load_odl(HOSTS_DEFINITION_ODL);

    s_create_pcmimport_function();

    _dummy_main(0, dm, parser);

    assert_int_equal(amxo_parser_start_synchronize(parser), 0);

    amxut_bus_handle_events();

    return 0;
}

int test_custom_setup(void** state) {
    int result = test_setup(state);
    amxd_object_t* root_obj = NULL;

    when_false(result == 0, exit);

    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    amxut_dm_load_odl("../common/mock_inactive_devices_dm.odl");
    amxut_dm_load_odl("../common/mock_inactive_hosts.odl");

    amxut_bus_handle_events();

exit:
    return result;
}

int test_teardown(UNUSED void** state) {
    _dummy_main(1, dm, parser);
    amxo_parser_stop_synchronize(parser);
    sahTraceClose();

    dm = NULL;
    parser = NULL;
    bus_ctx = NULL;

    amxut_bus_teardown(state);
    amxo_resolver_import_close_all();

    return 0;
}

void hosts_sync_init_success(void** state) {
    gmap_query_t query = {0};

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_init_delay_success(void** state) {
    gmap_query_t query = {0};

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, NULL);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, NULL);
    amxut_timer_go_to_future_ms(10010);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    amxut_timer_go_to_future_ms(5000);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_add_remove_success(void** state) {
    gmap_query_t query = {0};
    amxc_var_t* device = NULL;
    amxd_object_t* host = NULL;
    char* dhcp_path = NULL;
    mock_netmodel_query_t nm_query_2 = {
        .value = "",
    };

    amxd_object_t* interface = NULL;
    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query_2);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    /* Don't expect a NetModel query for device with Alias 3, it has an empty InterfaceName. */
    // mock_netmodel_expect_openQuery_luckyIntf("", HOSTS_NETMODEL_LUCKY_INTF_TAGS, "up", &nm_query_3);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    dhcp_path = amxd_object_get_value(cstring_t, host, "DHCPClient", NULL);
    assert_string_equal(dhcp_path, "DHCPv4.Server.Pool.lan.Client.1");
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_stop_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_stop_matching);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);

    free(dhcp_path);
}

void hosts_sync_add_remove_failure(void** state) {
    gmap_query_t query = {0};
    amxc_var_t device;
    amxd_object_t* interface = NULL;

    amxc_var_init(&device);
    amxc_var_set_type(&device, AMXC_VAR_ID_HTABLE);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    hosts_query_cb(&query, "ID-is-not-there", &device, gmap_query_expression_start_matching);
    hosts_query_cb(&query, "ID-is-not-there", &device, gmap_query_expression_stop_matching);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);

    amxc_var_clean(&device);
}

void hosts_sync_change_protected(void** state) {
    amxc_var_t* check_data = NULL;
    amxd_object_t* interface = NULL;
    gmap_query_t query = {0};
    amxd_trans_t transaction;
    amxc_string_t param;
    char* key = NULL;
    const char* prefix;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);

    assert_int_equal(_hosts_manager_main(AMXO_START, dm, parser), 0);
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);

    /* Change host's ${global_vendor_prefix_}Protected parameter and expect gmap_device_setTag()
     * to be called */
    key = calloc(64, sizeof(char));
    sprintf(key, GMAP_DEV_ALIAS_2);
    expect_string(__wrap_gmap_devices_findByMac, mac, "80:E8:2C:2E:7D:89");
    will_return(__wrap_gmap_devices_findByMac, key);
    mock_gmap_expect_setTag(GMAP_DEV_ALIAS_2, "protected",
                            NULL, gmap_traverse_this);

    prefix = GET_CHAR(amxo_parser_get_config(parser, "prefix_"), NULL);
    amxc_string_init(&param, 0);
    amxc_string_setf(&param, "%sProtected", prefix);

    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "Hosts.Host.1.");
    amxd_trans_set_value(bool, &transaction, amxc_string_get(&param, 0), true);
    assert_int_equal(amxd_trans_apply(&transaction, dm), 0);
    amxut_bus_handle_events();
    amxd_trans_clean(&transaction);
    amxc_string_clean(&param);

    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_stop_matching);
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(_hosts_manager_main(AMXO_STOP, dm, parser), 0);
}

void hosts_sync_tag_untag(void** state) {
    gmap_query_t query = {0};
    amxd_object_t* host = NULL;
    amxd_object_t* device = NULL;
    amxd_trans_t transaction;
    bool protected = false;
    amxc_string_t param;
    const char* prefix;
    char* key;
    amxd_object_t* interface = NULL;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);

    /* Create a host object. Expect ${global_vendor_prefix_}Protected parameter to be false */
    assert_int_equal(_hosts_manager_main(AMXO_START, dm, parser), 0);
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);

    prefix = GET_CHAR(amxo_parser_get_config(parser, "global_vendor_prefix_"), NULL);
    amxc_string_init(&param, 0);
    amxc_string_setf(&param, "%sProtected", prefix);

    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    protected = amxd_object_get_value(bool, host, amxc_string_get(&param, 0), NULL);
    assert_int_equal((int) protected, 0);

    /* Add "protected" to the Device's tags, expect ${global_vendor_prefix_}Protected to
     * change to true */
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "Devices.Device.2.");
    amxd_trans_set_value(cstring_t, &transaction, "Tags", "lan edev mac physical eth protected");
    assert_int_equal(amxd_trans_apply(&transaction, dm), 0);

    key = calloc(64, sizeof(char));
    sprintf(key, GMAP_DEV_ALIAS_2);
    expect_string(__wrap_gmap_devices_findByMac, mac, "80:E8:2C:2E:7D:89");
    will_return(__wrap_gmap_devices_findByMac, key);
    mock_gmap_expect_setTag(GMAP_DEV_ALIAS_2, "protected",
                            NULL, gmap_traverse_this);

    amxut_bus_handle_events();
    amxd_trans_clean(&transaction);

    protected = amxd_object_get_value(bool, host, amxc_string_get(&param, 0), NULL);
    assert_int_equal((int) protected, 1);

    /* Remove "protected" from the Device's tags, expect ${global_vendor_prefix_}Protected to
     * change back to false */
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "Devices.Device.2.");
    amxd_trans_set_value(cstring_t, &transaction, "Tags", "lan edev mac physical eth");
    assert_int_equal(amxd_trans_apply(&transaction, dm), 0);

    key = calloc(64, sizeof(char));
    sprintf(key, GMAP_DEV_ALIAS_2);
    expect_string(__wrap_gmap_devices_findByMac, mac, "80:E8:2C:2E:7D:89");
    will_return(__wrap_gmap_devices_findByMac, key);
    mock_gmap_expect_clearTag(GMAP_DEV_ALIAS_2, "protected",
                              NULL, gmap_traverse_this);
    amxut_bus_handle_events();
    amxd_trans_clean(&transaction);

    protected = amxd_object_get_value(bool, host, amxc_string_get(&param, 0), NULL);
    assert_int_equal((int) protected, 0);

    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_stop_matching);
    amxc_string_clean(&param);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(_hosts_manager_main(AMXO_STOP, dm, parser), 0);
}

void hosts_sync_wifi_device(void** state) {
    gmap_query_t query = {0};
    amxc_var_t* device = NULL;
    amxd_object_t* host = NULL;
    mock_netmodel_query_t nm_query_4 = {
        .value = "bridge-wlan_port0",
    };
    mock_netmodel_query_t nm_query_4_param = {
        .value = "Device.IP.Interface.3",
    };

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_4,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query_4);
    mock_netmodel_expect_openQuery_getFirstParameter("bridge-wlan_port0",
                                                     "InterfacePath",
                                                     HOSTS_NETMODEL_FIRST_PARAM_TAGS,
                                                     "up", &nm_query_4_param);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_4, gmap_query_expression_start_matching);

    // Verify parameters in Host object
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    assert_non_null(host);

    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer1Interface"), NULL), "Device.WiFi.Radio.1");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "Device.IP.Interface.3");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL), "Device.WiFi.AccessPoint.1.AssociatedDevice.1");

    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_4, gmap_query_expression_stop_matching);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_layer3iface(void** state) {
    gmap_query_t query = {0};
    amxd_trans_t trans;
    amxc_var_t* device = NULL;
    amxd_object_t* host = NULL;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };
    mock_netmodel_query_t nm_query_param = {
        .value = "",
    };

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);

    // Verify parameters in Host object
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    assert_non_null(host);

    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer1Interface"), NULL), "");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "InterfaceName"), NULL), "");

    // WHEN the InterfaceName is modified
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_3 ".");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceName", GMAP_DEV_IFACE_NAME_2);
    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);

    // EXPECT the creation of a new NetModel query
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    amxut_bus_handle_events();
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "InterfaceName"), NULL), GMAP_DEV_IFACE_NAME_2);

    // WHEN the first NetModel query updates, expect follow up
    nm_query_param.value = "Device.IP.Interface.3";
    mock_netmodel_expect_openQuery_getFirstParameter("bridge-wlan_port0",
                                                     "InterfacePath",
                                                     HOSTS_NETMODEL_FIRST_PARAM_TAGS,
                                                     "up", &nm_query_param);
    mock_netmodel_call_luckyIntf_callback(&nm_query, "bridge-wlan_port0");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), nm_query_param.value);

    // WHEN the second NetModel query updates, expect follow up
    mock_netmodel_call_getFirstParameter_callback(&nm_query_param, "Device.IP.Interface.2");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "Device.IP.Interface.2");

    // WHEN the first NetModel query updates again, expect follow up
    mock_netmodel_call_getFirstParameter_callback(&nm_query, "");
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "");

    // WHEN the InterfaceName changes, the item is updated as well
    nm_query.value = "bridge-wlan_port0";
    nm_query_param.value = "Device.IP.Interface.3";
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_4,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    mock_netmodel_expect_openQuery_getFirstParameter("bridge-wlan_port0",
                                                     "InterfacePath",
                                                     HOSTS_NETMODEL_FIRST_PARAM_TAGS,
                                                     "up", &nm_query_param);
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_3 ".");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceName", GMAP_DEV_IFACE_NAME_4);
    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    assert_non_null(nm_query.intfname);
    assert_non_null(nm_query_param.intfname);
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "Device.IP.Interface.3");

    // WHEN the InterfaceName is cleared, the item is updated as well
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_3 ".");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceName", "");
    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    assert_null(nm_query.intfname);
    assert_null(nm_query_param.intfname);
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host, "Layer3Interface"), NULL), "");


    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_stop_matching);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

static int compare_params(amxc_var_t* data_a,
                          amxc_var_t* data_b,
                          const char* key_a,
                          const char* key_b) {
    int ret = -1;
    int status = 0;

    amxc_var_t* a = GET_ARG(data_a, key_a);
    amxc_var_t* b = GET_ARG(data_b, key_b);

    when_null(a, exit);
    when_null(b, exit);

    if((amxc_var_compare(a, b, &status) == 0) && (status == 0)) {
        ret = 0;
    }

exit:
    return ret;
}

void hosts_sync_config(void** state) {
    gmap_query_t query = {0};
    amxc_var_t* prefix_var = NULL;
    amxd_object_t* devices_cfg = NULL;
    amxd_object_t* hosts_cfg = NULL;
    amxc_var_t devices_params;
    amxc_var_t hosts_params;

    amxc_var_init(&devices_params);
    amxc_var_init(&hosts_params);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(_hosts_manager_main(AMXO_START, dm, parser), 0);

    prefix_var = get_prefix_var();
    devices_cfg = amxd_dm_findf(dm, "Devices.Config.global.");
    hosts_cfg = amxd_dm_findf(dm, "Hosts.%sHostConfig.", GET_CHAR(prefix_var, NULL));

    assert_non_null(devices_cfg);
    assert_non_null(hosts_cfg);

    assert_int_equal(amxd_object_get_params(devices_cfg, &devices_params, amxd_dm_access_private), 0);
    assert_int_equal(amxd_object_get_params(hosts_cfg, &hosts_params, amxd_dm_access_private), 0);

    // Verify that the config parameters have the default gmap values
    assert_int_equal(compare_params(&devices_params, &hosts_params, "MaxLanDevices", "MaxDevices"), 0);
    assert_int_equal(compare_params(&devices_params, &hosts_params, "InactiveCheckInterval", "InactiveCheckInterval"), 0);
    assert_int_equal(compare_params(&devices_params, &hosts_params, "InactiveCheckThreshold", "InactiveCheckThreshold"), 0);
    assert_int_equal(compare_params(&devices_params, &hosts_params, "MaxInactiveTime", "MaxInactiveTime"), 0);
    assert_int_equal(compare_params(&devices_params, &hosts_params, "MaxInactiveTimeThreshold", "MaxInactiveTimeThreshold"), 0);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(_hosts_manager_main(AMXO_STOP, dm, parser), 0);

    amxc_var_clean(&devices_params);
    amxc_var_clean(&hosts_params);
}

void hosts_sync_ip_address(UNUSED void** state) {
    gmap_query_t query = {0};
    amxc_var_t* device = NULL;
    amxd_object_t* host = NULL;
    const char* addr = NULL;
    amxd_object_t* interface = NULL;
    amxd_trans_t trans;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(_hosts_manager_main(AMXO_START, dm, parser), 0);

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    amxut_bus_handle_events();
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);

    // IPAddress should be 123.123.123.123
    assert_string_equal(addr, "123.123.123.123");

    // Remove v4 address in gmap
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_2 ".IPv4Address.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);

    // IPAddress should become ff::ff
    amxut_bus_handle_events();
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);
    assert_string_equal(addr, "ff::ff");

    // Remove v6 address in gmap
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_2 ".IPv6Address.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);

    // IPAddress should become empty
    amxut_bus_handle_events();
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);
    assert_string_equal(addr, "");

    // Add IPv4 192.168.42.42
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_2 ".IPv4Address.");
    amxd_trans_add_inst(&trans, 0, "global");
    amxd_trans_set_value(cstring_t, &trans, "Address", "192.168.42.42");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);

    // IPAddress should become 192.168.42.42
    amxut_bus_handle_events();
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);
    assert_string_equal(addr, "192.168.42.42");

    // Add IPv4 192.168.42.1 with Scope = link
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_2 ".IPv4Address.");
    amxd_trans_add_inst(&trans, 0, "link");
    amxd_trans_set_value(cstring_t, &trans, "Address", "192.168.42.1");
    amxd_trans_set_value(cstring_t, &trans, "Scope", "link");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);

    // IPAddress should still be 192.168.42.42
    amxut_bus_handle_events();
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);
    assert_string_equal(addr, "192.168.42.42");

    // Add IPv4 192.168.42.44 with Scope = link and Status reachable
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_2 ".IPv4Address.");
    amxd_trans_add_inst(&trans, 0, "reachable");
    amxd_trans_set_value(cstring_t, &trans, "Address", "192.168.42.44");
    amxd_trans_set_value(cstring_t, &trans, "Scope", "link");
    amxd_trans_set_value(cstring_t, &trans, "Status", "reachable");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);

    // IPAddress should now be 192.168.42.44
    amxut_bus_handle_events();
    addr = GET_CHAR(amxd_object_get_param_value(host, "IPAddress"), NULL);
    assert_string_equal(addr, "192.168.42.44");

    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_stop_matching);

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(_hosts_manager_main(AMXO_STOP, dm, parser), 0);
}

void hosts_sync_from_alternative(UNUSED void** state) {
    gmap_query_t query = {0};
    const char* value = NULL;
    amxd_object_t* host = NULL;
    amxd_trans_t trans;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    // Initialize the hosts manager
    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    // Step 1: Matching device that doesn't have any alternatives set
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    amxut_bus_handle_events();
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "");

    // WHEN the alternative is added, its associated device value is synced
    mock_gmap_make_alternative(GMAP_DEV_ALIAS_2, GMAP_DEV_ALIAS_4);
    amxut_bus_handle_events();
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.1.AssociatedDevice.1");

    // WHEN further changes are made, they are synced too
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_4 ".SSWSta.");
    amxd_trans_set_value(cstring_t, &trans, "AssociatedDevice", "Device.WiFi.AccessPoint.2.AssociatedDevice.10");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.2.AssociatedDevice.10");

    // WHEN the device alternative association is stopped...
    mock_gmap_remove_alternative(GMAP_DEV_ALIAS_2, GMAP_DEV_ALIAS_4);
    amxut_bus_handle_events();
    // further changes are no longer synced
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_4 ".SSWSta.");
    amxd_trans_set_value(cstring_t, &trans, "AssociatedDevice", "Device.HomePlug.Interface.1.AssociatedDevice.12");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.2.AssociatedDevice.10");

    // cleanup
    amxd_trans_clean(&trans);
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_from_alternative_at_start(UNUSED void** state) {
    gmap_query_t query = {0};
    const char* value = NULL;
    amxd_object_t* host = NULL;
    amxd_trans_t trans;
    mock_netmodel_query_t nm_query = {
        .value = "",
    };

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    // Make the devices alternatives of each other
    mock_gmap_make_alternative(GMAP_DEV_ALIAS_2, GMAP_DEV_ALIAS_3);
    mock_gmap_make_alternative(GMAP_DEV_ALIAS_2, GMAP_DEV_ALIAS_4);
    amxut_bus_handle_events();

    // Initialize the hosts manager
    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    // Step 1: Matching device with alternatives already in place
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    amxut_bus_handle_events();
    host = amxd_dm_findf(dm, "Hosts.Host.1.");
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.1.AssociatedDevice.1");

    // WHEN further changes are made, they are synced too
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_3 ".SSWSta.");
    amxd_trans_set_value(cstring_t, &trans, "AssociatedDevice", "Device.WiFi.AccessPoint.2.AssociatedDevice.10");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.2.AssociatedDevice.10");

    // WHEN the device alternative association is stopped...
    mock_gmap_remove_alternative(GMAP_DEV_ALIAS_2, GMAP_DEV_ALIAS_4);
    amxut_bus_handle_events();
    // further changes are no longer synced
    amxd_trans_select_pathf(&trans, "Devices.Device." GMAP_DEV_ALIAS_4 ".SSWSta.");
    amxd_trans_set_value(cstring_t, &trans, "AssociatedDevice", "Device.HomePlug.Interface.1.AssociatedDevice.12");
    assert_int_equal(amxd_trans_apply(&trans, dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    value = GET_CHAR(amxd_object_get_param_value(host, "AssociatedDevice"), NULL);
    assert_string_equal(value, "Device.WiFi.AccessPoint.2.AssociatedDevice.10");

    // cleanup
    amxd_trans_clean(&trans);
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

static int s_call_import(const char* data_file) {
    amxc_var_t* data = amxut_util_read_json_from_file(data_file);

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_set_key(&args, "data", data, AMXC_VAR_FLAG_COPY);
    int status_call = amxb_call(amxb_be_who_has("Hosts"),
                                "Hosts.",
                                "Import",
                                &args,
                                &ret,
                                1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);

    return status_call;
}

void hosts_sync_restore__ok(UNUSED void** state) {
    const char* data_file = TEST_FILES "/restore__ok__data.json";
    const char* import_file = TEST_FILES "/restore__ok__import.json";
    gmap_query_t query = {0};
    mock_netmodel_query_t nm_query_2 = {
        .value = "",
    };
    mock_netmodel_query_t nm_query_3 = {
        .value = "",
    };
    mock_netmodel_query_t nm_query_4 = {
        .value = "bridge-wlan_port0",
    };
    mock_netmodel_query_t nm_query_4_param = {
        .value = "Device.IP.Interface.3",
    };

    // GIVEN a running hosts manager with a few synced devices
    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    amxut_dm_load_odl(TEST_FILES "/mock_extra_devices_dm.odl");
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query_2);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query_3);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_5, gmap_query_expression_start_matching);
    amxut_bus_handle_events();
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-1' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:89' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_2 ".'"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-2' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:88' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_3 ".'"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-3' && "
                                  "  PhysAddress=='80:DE:AD:2E:7D:89' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_5 ".'"
                                  "]."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-4."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.[PhysAddress=='80:E8:2C:2E:7D:87']."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.[DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_4 ".']."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-5."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.[PhysAddress=='80:DE:AD:2E:7D:88']."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.[DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_6 ".']."));

    // WHEN attempting to import the following devices:
    //   - A device matching only with the physical address
    //   - A device without physical address, but with matching device reference
    //   - a device without physical address, not matching any device reference
    //     but exists in gmap and hosts under a different reference
    //   - a device without physical address, not matching any device reference
    //     nor phys address that was looked up in gmap
    //   - An unknown device that exists in gmap
    expect_pcm_import(import_file);
    assert_success(s_call_import(data_file));

    // THEN the correct host objects are created
    amxut_bus_handle_events();
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-1' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:89' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_2 ".'"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-2' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:88' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_3 ".'"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-3' && "
                                  "  PhysAddress=='80:DE:AD:2E:7D:89' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_5 ".'"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-4' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:87' && "
                                  "  DeviceReference==''"
                                  "]."));
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-5' && "
                                  "  PhysAddress=='80:DE:AD:2E:7D:88' && "
                                  "  DeviceReference==''"
                                  "]."));

    // WHEN the corresponding gmap query event is then fired
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_4,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query_4);
    mock_netmodel_expect_openQuery_getFirstParameter("bridge-wlan_port0",
                                                     "InterfacePath",
                                                     HOSTS_NETMODEL_FIRST_PARAM_TAGS,
                                                     "up", &nm_query_4_param);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_4, gmap_query_expression_start_matching);
    amxut_bus_handle_events();

    // THEN the pre-created device is synced
    assert_non_null(amxd_dm_findf(dm,
                                  "Hosts.Host.["
                                  "  Alias=='cpe-Host-4' && "
                                  "  PhysAddress=='80:E8:2C:2E:7D:87' && "
                                  "  DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_4 ".'"
                                  "]."));

    // Verify PhysAddress content in Host object is upper-cased
    amxd_object_t* host_obj = amxd_dm_findf(dm, "Hosts.Host.cpe-Host-1.");
    assert_non_null(host_obj);
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(host_obj, "PhysAddress"), NULL), "80:E8:2C:2E:7D:89");

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_restore__error(UNUSED void** state) {
    const char* data_file = TEST_FILES "/restore__error__data.json";
    gmap_query_t query = {0};

    // GIVEN a running hosts manager with a few synced devices
    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    amxut_bus_handle_events();
    // WHEN attempting to import a device without PhysAddress or device reference:
    /* Don't expect_pcm_import(import_file); */
    assert_int_not_equal(0, s_call_import(data_file));

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

static int s_call_remove_inactive_hosts(int minInactiveSec, uint32_t* out) {
    amxc_var_t args;
    amxc_var_t ret;
    int status;

    assert_non_null(out);

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    if(minInactiveSec >= 0) {
        amxc_var_add_key(uint32_t, &args, "MinimumInactiveTime", minInactiveSec);
    }
    amxc_var_init(&ret);
    status = amxb_call(amxut_bus_ctx(), "Hosts.", "RemoveInactiveHosts", &args, &ret, 10);

    *out = GET_UINT32(amxc_var_get_first(&ret), "NumberOfRemovedHosts");

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return status;
}

void hosts_sync_remove_inactive_gmap_hosts_time_not_synced(UNUSED void** state) {
    gmap_query_t query = {0};
    mock_netmodel_query_t nm_query = {
        .value = "",
    };
    uint32_t nr_removed = 0;

    will_return_always(__wrap_is_ntp_time_synchronized, false);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);
    amxut_dm_load_odl(TEST_FILES "/mock_extra_devices_dm.odl");

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_5, gmap_query_expression_start_matching);
    amxut_bus_handle_events();

    assert_int_not_equal(s_call_remove_inactive_hosts(3600, &nr_removed), 0);

    amxut_bus_handle_events();

    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_remove_inactive_gmap_hosts_min_time_zero(UNUSED void** state) {
    gmap_query_t query = {0};
    mock_netmodel_query_t nm_query = {
        .value = "",
    };
    uint32_t nr_removed = 0;

    will_return_always(__wrap_is_ntp_time_synchronized, false);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);
    amxut_dm_load_odl(TEST_FILES "/mock_extra_devices_dm.odl");

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_5, gmap_query_expression_start_matching);
    amxut_bus_handle_events();

    assert_non_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-4."));
    assert_non_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-5."));

    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_8);
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_9);
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_10);
    assert_success(s_call_remove_inactive_hosts(0, &nr_removed));
    assert_int_equal(nr_removed, 5u);

    amxut_bus_handle_events();

    assert_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-4."));
    assert_null(amxd_dm_findf(dm, "Hosts.Host.cpe-Host-5."));


    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}

void hosts_sync_remove_inactive_gmap_hosts_time_synced(UNUSED void** state) {
    gmap_query_t query = {0};
    mock_netmodel_query_t nm_query[2] = {
        {.value = "", },
        {.value = "", },
    };
    uint32_t nr_removed = 0;
    will_return_always(__wrap_is_ntp_time_synchronized, true);

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(_hosts_manager_main(AMXO_START, dm, parser), 0);
    amxut_dm_load_odl(TEST_FILES "/mock_extra_devices_dm.odl");
    amxut_timer_go_to_future_ms(0);

    // GIVEN a set of hosts with two hosts inactive with a couple of seconds in
    // between and one active.

    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query[0]);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_4,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query[1]);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_4, gmap_query_expression_start_matching);
    amxut_bus_handle_events();

    assert_non_null(amxd_dm_findf(dm, "Hosts.Host.[DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_2 ".']."));
    assert_non_null(amxd_dm_findf(dm, "Hosts.Host.[DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_3 ".']."));
    assert_non_null(amxd_dm_findf(dm, "Hosts.Host.[DeviceReference=='Devices.Device." GMAP_DEV_ALIAS_4 ".']."));

    mock_gmap_set_active(GMAP_DEV_ALIAS_2, false);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(5000);
    mock_gmap_set_active(GMAP_DEV_ALIAS_4, false);
    amxut_bus_handle_events();

    // WHEN removing devices inactive for more than 3 seconds, only the first
    // inactive device is removed
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_2);
    assert_success(s_call_remove_inactive_hosts(3, &nr_removed));
    assert_int_equal(nr_removed, 1u);
    nr_removed = 0xffff;

    // WHEN another device is made inactive after a couple of seconds
    amxut_timer_go_to_future_ms(5000);
    mock_gmap_set_active(GMAP_DEV_ALIAS_3, false);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(10000);
    amxut_bus_handle_events();

    // THEN calling the method again, removes both inactive device
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_4);
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_3);
    assert_success(s_call_remove_inactive_hosts(3, &nr_removed));
    assert_int_equal(nr_removed, 2u);
    nr_removed = 0xffff;

    amxut_bus_handle_events();
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(_hosts_manager_main(AMXO_STOP, dm, parser), 0);
}

void hosts_sync_cleanup_hosts_threshold_changed(UNUSED void** state) {
    amxd_trans_t trans;
    amxc_var_t ret;
    gmap_query_t query = {0};
    mock_netmodel_query_t nm_query[2] = {
        {.value = "", },
        {.value = "", },
    };

    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);

    amxut_dm_load_odl(TEST_FILES "/mock_extra_devices_dm.odl");
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_2,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query[0]);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_3, gmap_query_expression_start_matching);
    mock_netmodel_expect_openQuery_luckyIntf(GMAP_DEV_IFACE_NAME_4,
                                             HOSTS_NETMODEL_LUCKY_INTF_TAGS,
                                             "up", &nm_query[1]);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_4, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_5, gmap_query_expression_start_matching);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_6, gmap_query_expression_start_matching);
    amxut_bus_handle_events();

    amxd_object_t* hosts = amxd_dm_findf(dm, "Hosts.");
    assert_non_null(hosts);

    will_return(__wrap_is_ntp_time_synchronized, true);
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Hosts.");
    amxd_trans_set_int32_t(&trans, "CleanupHostsThreshold", 2);
    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);

    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_10);
    expect_string(__wrap_gmap_devices_destroyDevice, key, GMAP_DEV_ALIAS_9);
    amxut_bus_handle_events();

    // cleanup
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);
}
