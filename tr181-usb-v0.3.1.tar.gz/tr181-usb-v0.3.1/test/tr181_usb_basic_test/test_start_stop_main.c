/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_start_stop.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_exec_addBus),
        cmocka_unit_test(test_exec_addDev),
        cmocka_unit_test(test_exec_reset),
        cmocka_unit_test(test_exec_eject),
        cmocka_unit_test(test_exec_addDev),
        cmocka_unit_test(test_exec_delDev),
        cmocka_unit_test(test_pwr_status),
        cmocka_unit_test(test_power_state_validator),
        cmocka_unit_test(test_usb_port_added),
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
