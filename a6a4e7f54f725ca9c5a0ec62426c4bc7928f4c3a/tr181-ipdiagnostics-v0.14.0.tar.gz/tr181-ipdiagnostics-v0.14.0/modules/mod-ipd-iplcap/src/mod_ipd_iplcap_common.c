/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_dm.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_ipd_iplcap_common.h"
#include "mod_ipd_iplcap.h"
#include "mod_ipd_iplcap_status.h"
#include "mod_ipd_common.h"
#include "iplcap.h"

/**
 * @brief Module trace zone identifier for IPLayerCapacity common helpers.
 */
#define ME "mod-iplcap-common"

/**
 * @brief Validate that a command string is safe to write in a shell script
 *
 * Rules:
 * - Non-empty, length <= 4096
 * - First token (binary path) contains only [A-Za-z0-9_/.-]
 * - For the whole string, disallow shell metacharacters that enable injection:
 *   `;`, `|`, `&`, `>`, `<`, `` ` ``, `\\`, `$`, `(`, `)` and any CR/LF
 * - No command substitution: "$(" or backticks
 */
static bool iplcap_is_cmd_safe(const char* cmd_str) {
    size_t i = 0;
    const size_t max_len = 4096;
    if((cmd_str == NULL) || (cmd_str[0] == '\0')) {
        return false;
    }
    if(strnlen(cmd_str, max_len + 1) > max_len) {
        return false;
    }

    // Validate first token (binary path)
    while((cmd_str[i] != '\0') && (cmd_str[i] != ' ')) {
        const char c = cmd_str[i];
        if(!(((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9')) ||
             (c == '/') || (c == '.') || (c == '-') || (c == '_'))) {
            return false;
        }
        i++;
    }

    // Scan entire string for disallowed characters/patterns
    for(i = 0; cmd_str[i] != '\0'; i++) {
        const char c = cmd_str[i];
        if((c == ';') || (c == '|') || (c == '&') || (c == '>') || (c == '<') ||
           (c == '`') || (c == '\\') || (c == '$') || (c == '(') || (c == ')') ||
           (c == '\n') || (c == '\r')) {
            return false;
        }
        if((c == '$') && (cmd_str[i + 1] == '(')) {
            return false; // command substitution
        }
    }

    return true;
}

int iplcap_kill_iplcap_test(amxc_var_t* params) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    int wait_res = 1;
    amxp_subproc_t* proc_iplcap = NULL;
    const int pid = GETP_INT32(params, IPLCAP_RET_KEY_PROC "." IPLCAP_RET_KEY_PROC_PID);

    when_null_trace(params, exit, ERROR, "Parameters are NULL.");

    proc_iplcap = amxp_subproc_find(pid);
    when_null_trace(proc_iplcap, exit, ERROR, "Process not found.");
    if(proc_iplcap != NULL) {
        amxp_subproc_kill(proc_iplcap, SIGTERM);
        wait_res = amxp_subproc_wait(proc_iplcap, 3);
        if(wait_res == 1) {
            amxp_subproc_kill(proc_iplcap, SIGKILL);
            wait_res = amxp_subproc_wait(proc_iplcap, 3);
        }
        rv = (wait_res == 0) ? 0 : -1;
        amxp_subproc_delete(&proc_iplcap);
    }

    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

void iplcap_delete_test_script(void) {
    SAH_TRACEZ_IN(ME);

    mod_ipd_delete_filef(IPLCAP_SCRIPT_FILE);

    SAH_TRACEZ_OUT(ME);
}

int iplcap_create_sh_script(amxc_var_t* params,
                            amxc_string_t* cmd,
                            amxc_array_t* sh_script) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    FILE* p_sh_file = NULL;
    const char* cmd_str = NULL;

    when_null_trace(params, exit, ERROR, "Input parameter is NULL.");
    when_null_trace(cmd, exit, ERROR, "Command is NULL.");
    when_null_trace(sh_script, exit, ERROR, "Array is not initialised.");

    cmd_str = amxc_string_get(cmd, 0);
    when_true_trace((cmd_str == NULL) || (cmd_str[0] == '\0'), exit, ERROR, "Command string is empty.");
    when_false_trace(iplcap_is_cmd_safe(cmd_str), exit, ERROR, "Command contains unsafe characters/patterns.");

    amxc_array_append_data(sh_script, strdup("sh"));
    amxc_array_append_data(sh_script, strdup(IPLCAP_SCRIPT_FILE));
    p_sh_file = fopen(IPLCAP_SCRIPT_FILE, "w");
    when_null_trace(p_sh_file, exit, ERROR, "Unable to create the shell script.");

    fprintf(p_sh_file, "#!/bin/bash\n\n");
    fprintf(p_sh_file, "set +x\n");
    fprintf(p_sh_file, "%s\n", cmd_str);

    if(p_sh_file != NULL) {
        fclose(p_sh_file);
    }
    chmod(IPLCAP_SCRIPT_FILE, 0755);

    rv = 0;

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

iplcap_test_status_t iplcap_st_str_to_st_int(const cstring_t status_string) {
    SAH_TRACEZ_IN(ME);
    iplcap_test_status_t status = iplcap_test_error_err_other;
    iplcap_test_status_t idx = iplcap_test_none;

    when_str_empty_trace(status_string, exit, ERROR, "Status_string empty");

    for(idx = iplcap_test_none; idx < iplcap_test_num_of_status; idx++) {
        if(strcmp(str_iplcap_test_status[idx], status_string) == 0) {
            status = idx;
            break;
        }
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}
