/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file Please read documentation in `gmap_eth_dev_dhcp_pool.h`.
 */

#include "gmap_eth_dev_dhcp.h"
#include "gmap_eth_dev_dhcp_pool.h"
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_includes.h"
#include "gmap_eth_dev_util.h"
#include <amxb/amxb_subscribe.h>
#include <amxd/amxd_object_event.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxb/amxb.h>
#include <amxd/amxd_path.h>
#include <string.h>
#include <stdlib.h>


#define GMAP_DHCPV4SERVER_POOL_PATH GMAP_DHCPV4SERVER_PATH "Pool."


struct gmap_eth_dev_dhcp_pool {
    amxb_subscription_t* subscription_pool_instance;
    amxb_subscription_t* subscription_pool_modified;
    amxc_llist_t pools;
    amxc_llist_t subscriptions;
};


typedef struct s_pool_entry {
    amxc_llist_it_t it;
    char* path;
    char* iface;
} s_pool_entry_t;

struct gmap_eth_dev_dhcp_pool_subscription {
    amxc_llist_it_t it;
    char* iface;
    gmap_eth_dev_dhcp_pool_cb_t cb;
    void* priv;
};


/** @brief Places a copy of @p path in @p out, stripping any trailing dots.
 *
 * @param[out] out Pointer to an amxc_string where the stripped path must be
 *             stored. The new data will be appended to the existing content of
 *             the string.
 * @param path A data model object path.
 * @retval 0 on success
 * @retval non-0 if invalid parameters or on failure.
 */
static int s_clean_trailing_dots(amxc_string_t* out, const char* path) {
    size_t path_len;
    int success = -1;

    when_null_trace(out, exit, ERROR, "Invalid out argument");
    when_null_trace(path, exit, ERROR, "Invalid path");

    path_len = strlen(path);
    while(path_len > 0 && path[path_len - 1] == '.') {
        --path_len;
    }
    when_true_trace(path_len == 0, exit, ERROR, "Path consists only of dots");
    success = amxc_string_append(out, path, path_len);
    if(success != 0) {
        SAH_TRACEZ_ERROR(ME, "Out of memory");
    }

exit:
    return success;
}


// pool_entry implementation
////////////////////////////////////////////////////////////////////////////////

static bool s_pool_entry_new(s_pool_entry_t** out,
                             const char* path,
                             const char* iface) {
    bool success = false;
    s_pool_entry_t* entry = NULL;
    amxc_string_t clean_iface;

    amxc_string_init(&clean_iface, 0);

    when_null_trace(out, exit, ERROR, "Null");
    *out = NULL;
    when_str_empty_trace(path, exit, ERROR, "Null or empty string");
    when_str_empty_trace(iface, exit, ERROR, "Null or empty string");
    when_failed(s_clean_trailing_dots(&clean_iface, iface), exit);

    entry = malloc(sizeof(s_pool_entry_t));

    when_null_trace(entry, exit, ERROR, "Out of memory");
    amxc_llist_it_init(&entry->it);
    entry->path = strdup(path);
    entry->iface = amxc_string_take_buffer(&clean_iface);

    when_null_trace(entry->path, exit, ERROR, "Out of memory");
    when_null_trace(entry->iface, exit, ERROR, "Out of memory");

    success = true;
    *out = entry;

exit:
    if(!success && (entry != NULL)) {
        free(entry->path);
        free(entry->iface);
        free(entry);
    }
    amxc_string_clean(&clean_iface);
    return success;
}

static void s_pool_entry_delete(amxc_llist_it_t* it) {
    s_pool_entry_t* entry = NULL;

    when_null(it, exit);
    entry = amxc_llist_it_get_data(it, s_pool_entry_t, it);

    free(entry->path);
    free(entry->iface);
    free(entry);
exit:
    return;
}

static s_pool_entry_t* s_get_pool(gmap_eth_dev_dhcp_pool_t* pool,
                                  const char* path) {
    s_pool_entry_t* entry = NULL;

    when_null_trace(pool, exit, ERROR, "Null");
    when_str_empty_trace(path, exit, ERROR, "Null or empty string");

    amxc_llist_for_each(it, &pool->pools) {
        s_pool_entry_t* item = amxc_llist_it_get_data(it, s_pool_entry_t, it);
        if(strcmp(item->path, path) == 0) {
            entry = item;
            break;
        }
    }

exit:
    return entry;
}


// pool_subscription implementation
////////////////////////////////////////////////////////////////////////////////

static bool s_pool_subscription_new(gmap_eth_dev_dhcp_pool_subscription_t** out,
                                    const char* iface,
                                    gmap_eth_dev_dhcp_pool_cb_t cb,
                                    void* priv) {
    bool success = false;
    gmap_eth_dev_dhcp_pool_subscription_t* entry = NULL;

    when_null_trace(out, exit, ERROR, "Null");
    *out = NULL;
    when_str_empty_trace(cb, exit, ERROR, "Null or empty string");
    when_str_empty_trace(iface, exit, ERROR, "Null or empty string");
    entry = malloc(sizeof(gmap_eth_dev_dhcp_pool_subscription_t));

    when_null_trace(entry, exit, ERROR, "Out of memory");
    amxc_llist_it_init(&entry->it);
    entry->iface = strdup(iface);

    when_null_trace(entry->iface, exit, ERROR, "Out of memory");

    entry->cb = cb;
    entry->priv = priv;

    success = true;
    *out = entry;

exit:
    if(!success && (entry != NULL)) {
        free(entry->iface);
        free(entry);
    }
    return success;
}

static void s_pool_subscription_delete(amxc_llist_it_t* it) {
    gmap_eth_dev_dhcp_pool_subscription_t* entry = NULL;

    when_null(it, exit);
    entry = amxc_llist_it_get_data(it, gmap_eth_dev_dhcp_pool_subscription_t, it);

    free(entry->iface);
    free(entry);
exit:
    return;
}


// pool event implementation
////////////////////////////////////////////////////////////////////////////////

static void s_pool_set_iface(gmap_eth_dev_dhcp_pool_t* pool,
                             s_pool_entry_t* entry,
                             const char* iface) {
    amxc_string_t clean_iface;

    amxc_string_init(&clean_iface, 0);
    when_failed(s_clean_trailing_dots(&clean_iface, iface), exit);
    iface = amxc_string_get(&clean_iface, 0);

    when_true(strcmp(entry->iface, iface) == 0, exit);

    /* notify stopped matching. */
    amxc_llist_for_each(it, &pool->subscriptions) {
        gmap_eth_dev_dhcp_pool_subscription_t* subscription = amxc_llist_it_get_data(it, gmap_eth_dev_dhcp_pool_subscription_t, it);
        if(strcmp(entry->iface, subscription->iface) == 0) {
            subscription->cb(pool, entry->path, entry->iface, false, subscription->priv);
        }
    }

    /* modify entry */
    free(entry->iface);
    entry->iface = amxc_string_take_buffer(&clean_iface);
    if(entry->iface == NULL) {
        SAH_TRACEZ_ERROR(ME, "Out of memory");
        amxc_llist_it_clean(&entry->it, s_pool_entry_delete);
        goto exit;
    }

    /* notify started matching. */
    amxc_llist_for_each(it, &pool->subscriptions) {
        gmap_eth_dev_dhcp_pool_subscription_t* subscription = amxc_llist_it_get_data(it, gmap_eth_dev_dhcp_pool_subscription_t, it);
        if(strcmp(iface, subscription->iface) == 0) {
            subscription->cb(pool, entry->path, entry->iface, true, subscription->priv);
        }
    }

    SAH_TRACEZ_INFO(ME, "Pool interface changed '%s' -> '%s'", entry->path, entry->iface);

exit:
    amxc_string_clean(&clean_iface);
    return;
}

static void s_instance_cb(const char* const sig_name UNUSED,
                          const amxc_var_t* const notification_data,
                          void* const priv) {
    gmap_eth_dev_dhcp_pool_t* pool = (gmap_eth_dev_dhcp_pool_t*) priv;
    const char* notification = NULL;
    const char* path_root = NULL;
    const char* path = NULL;
    uint32_t index;
    s_pool_entry_t* entry = NULL;
    amxc_string_t full_path;

    amxc_string_init(&full_path, 0);

    when_null_trace(notification_data, exit, ERROR, "NULL");
    when_null_trace(pool, exit, ERROR, "NULL");

    notification = GET_CHAR(notification_data, "notification");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty string");

    path_root = GET_CHAR(notification_data, "path");
    when_str_empty_trace(path_root, exit, ERROR, "NULL/empty string");
    /* Check if some sub-instance was created/deleted. */
    when_false(strcmp(path_root, GMAP_DHCPV4SERVER_POOL_PATH) == 0, exit);

    index = GET_UINT32(notification_data, "index");
    when_true_trace(index == 0, exit, ERROR, "0 index");

    when_failed_trace(amxc_string_setf(&full_path, GMAP_DHCPV4SERVER_POOL_PATH "%d.", index),
                      exit, ERROR, "Failed to build pool instance path.");
    path = amxc_string_get(&full_path, 0);

    if(strcmp(notification, "dm:instance-removed") == 0) {
        // A pool was removed, clean it up
        entry = s_get_pool(pool, path);
        when_null(entry, exit);

        amxc_llist_for_each(it, &pool->subscriptions) {
            gmap_eth_dev_dhcp_pool_subscription_t* subscription = amxc_llist_it_get_data(it, gmap_eth_dev_dhcp_pool_subscription_t, it);
            if(strcmp(entry->iface, subscription->iface) == 0) {
                subscription->cb(pool, path, entry->iface, false, subscription->priv);
            }
        }

        amxc_llist_it_clean(&entry->it, s_pool_entry_delete);
        entry = NULL;

        SAH_TRACEZ_INFO(ME, "Stopped tracking pool '%s'", path);
    } else if(strcmp(notification, "dm:instance-added") == 0) {
        // A pool was created, add it if we don't know it yet.
        const char* iface = GET_CHAR(GET_ARG(notification_data, "parameters"), "Interface");
        when_str_empty_trace(iface, exit, ERROR, "NULL/empty string");

        entry = s_get_pool(pool, path);
        if(entry != NULL) {
            SAH_TRACEZ_WARNING(ME, "New instance '%s' created, but the path is already known", path);
            s_pool_set_iface(pool, entry, iface);
        } else {
            when_false_trace(s_pool_entry_new(&entry, path, iface), exit,
                             ERROR, "Failed to create new pool entry");
            amxc_llist_append(&pool->pools, &entry->it);

            amxc_llist_for_each(it, &pool->subscriptions) {
                gmap_eth_dev_dhcp_pool_subscription_t* subscription = amxc_llist_it_get_data(it, gmap_eth_dev_dhcp_pool_subscription_t, it);
                if(strcmp(entry->iface, subscription->iface) == 0) {
                    subscription->cb(pool, path, entry->iface, true, subscription->priv);
                }
            }

            SAH_TRACEZ_INFO(ME, "Tracking new pool '%s'", path);
        }
    }

exit:
    amxc_string_clean(&full_path);
    return;
}

static void s_mod_cb(const char* const sig_name UNUSED,
                     const amxc_var_t* const notification_data,
                     void* const priv) {
    gmap_eth_dev_dhcp_pool_t* pool = (gmap_eth_dev_dhcp_pool_t*) priv;
    const size_t prefix_len = strlen(GMAP_DHCPV4SERVER_POOL_PATH);
    const char* notification = NULL;
    const char* path = NULL;
    const char* needle = NULL;
    const char* iface = NULL;
    s_pool_entry_t* entry = NULL;

    when_null_trace(notification_data, exit, ERROR, "NULL");
    when_null_trace(pool, exit, ERROR, "NULL");

    notification = GET_CHAR(notification_data, "notification");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty string");
    when_true(strcmp(notification, "dm:object-changed") != 0, exit);

    path = GET_CHAR(notification_data, "path");
    when_str_empty_trace(path, exit, ERROR, "NULL/empty string");
    when_true(strncmp(path, GMAP_DHCPV4SERVER_POOL_PATH, prefix_len) != 0, exit);
    needle = strchr(path + prefix_len, '.');
    /* Expect an index after the known fixed prefix. */
    when_null(needle, exit);
    /* Expect no other path parts after the index. */
    when_false(*(needle + 1) == '\0', exit);

    iface = GET_CHAR(GET_ARG(GET_ARG(notification_data, "parameters"), "Interface"), "to");
    when_str_empty_trace(iface, exit, ERROR, "NULL/empty string");

    entry = s_get_pool(pool, path);
    when_null_trace(entry, exit, ERROR, "Unknown pool '%s' changed interface", path);

    s_pool_set_iface(pool, entry, iface);

exit:
    return;
}

static void s_subscribe(gmap_eth_dev_dhcp_pool_t* pool, amxb_bus_ctx_t* ctx) {
    when_failed_trace(amxb_subscription_new(&pool->subscription_pool_instance,
                                            ctx,
                                            GMAP_DHCPV4SERVER_POOL_PATH,
                                            "notification == 'dm:instance-added' || notification == 'dm:instance-removed'",
                                            s_instance_cb,
                                            pool),
                      exit, ERROR, "Failed to subscribe to Pool instance creation/destruction");

    when_failed_trace(amxb_subscription_new(&pool->subscription_pool_modified,
                                            ctx,
                                            GMAP_DHCPV4SERVER_POOL_PATH,
                                            "notification == 'dm:object-changed' && contains('parameters.Interface.to')",
                                            s_mod_cb,
                                            pool),
                      exit, ERROR, "Failed to subscribe to Pool instance modification");
exit:
    return;
}

static void s_init_fetch(gmap_eth_dev_dhcp_pool_t* pool, amxb_bus_ctx_t* ctx) {
    int status = -1;
    amxc_var_t var;

    amxc_var_init(&var);
    when_null_trace(pool, exit, ERROR, "Null");

    status = amxb_get(ctx,
                      GMAP_DHCPV4SERVER_POOL_PATH "*.Interface", 1,
                      &var, GMAP_ETH_DEV_BUS_TIMEOUT_SEC);
    when_failed_trace(status, exit, ERROR, "Failed to fetch " GMAP_DHCPV4SERVER_PATH " pool interfaces: %d", status);

    /* Return variant has the form [{ "path" = {Interface = "" }, }] */
    amxc_var_for_each(entry, amxc_var_get_first(&var)) {
        const char* path = amxc_var_key(entry);
        const char* iface = GET_CHAR(entry, "Interface");
        s_pool_entry_t* pool_entry = NULL;

        when_str_empty(path, next);
        when_str_empty(iface, next);

        when_false(s_pool_entry_new(&pool_entry, path, iface), next);
        when_null(pool_entry, next);

        amxc_llist_append(&pool->pools, &pool_entry->it);
        SAH_TRACEZ_INFO(ME, "Found "GMAP_DHCPV4SERVER_PATH " pool instance '%s' for interface '%s'", path, iface);

next:
        continue;
    }

exit:
    amxc_var_clean(&var);
}


// pool api implementation
////////////////////////////////////////////////////////////////////////////////

void gmap_eth_dev_dhcp_pool_new(gmap_eth_dev_dhcp_pool_t** pool, amxb_bus_ctx_t* ctx) {
    when_null_trace(pool, exit, ERROR, "NULL argument");
    when_null_trace(ctx, exit, ERROR, "NULL argument");

    *pool = malloc(sizeof(gmap_eth_dev_dhcp_pool_t));
    when_null_trace(*pool, exit, ERROR, "Out of Memory");

    (*pool)->subscription_pool_instance = NULL;
    (*pool)->subscription_pool_modified = NULL;
    amxc_llist_init(&(*pool)->pools);
    amxc_llist_init(&(*pool)->subscriptions);

    s_subscribe(*pool, ctx);
    s_init_fetch(*pool, ctx);

exit:
    return;
}

void gmap_eth_dev_dhcp_pool_delete(gmap_eth_dev_dhcp_pool_t** pool) {
    if((pool == NULL) || (*pool == NULL)) {
        return;
    }

    amxb_subscription_delete(&(*pool)->subscription_pool_modified);
    amxb_subscription_delete(&(*pool)->subscription_pool_instance);
    amxc_llist_clean(&(*pool)->pools, s_pool_entry_delete);
    amxc_llist_clean(&(*pool)->subscriptions, s_pool_subscription_delete);

    free(*pool);
    *pool = NULL;
}


gmap_eth_dev_dhcp_pool_subscription_t*
gmap_eth_dev_dhcp_pool_subscribe(gmap_eth_dev_dhcp_pool_t* pool,
                                 const char* iface,
                                 gmap_eth_dev_dhcp_pool_cb_t cb,
                                 void* priv) {
    gmap_eth_dev_dhcp_pool_subscription_t* subscription = NULL;
    amxc_string_t iface_clean;

    amxc_string_init(&iface_clean, 0);

    when_null_trace(pool, exit, ERROR, "Null");
    when_str_empty_trace(iface, exit, ERROR, "Null/empty string");
    when_null_trace(cb, exit, ERROR, "Null");

    when_failed(s_clean_trailing_dots(&iface_clean, iface), exit);
    iface = amxc_string_get(&iface_clean, 0);

    when_false(s_pool_subscription_new(&subscription, iface, cb, priv), exit);

    amxc_llist_append(&pool->subscriptions, &subscription->it);

    amxc_llist_for_each(it, &pool->pools) {
        const s_pool_entry_t* entry = amxc_llist_it_get_data(it, s_pool_entry_t, it);
        if(strcmp(entry->iface, iface) == 0) {
            cb(pool, entry->path, iface, true, subscription->priv);
        }
    }

exit:
    amxc_string_clean(&iface_clean);
    return subscription;
}

void gmap_eth_dev_dhcp_pool_unsubscribe(gmap_eth_dev_dhcp_pool_subscription_t* subscription) {
    when_null(subscription, exit);

    amxc_llist_it_clean(&subscription->it, s_pool_subscription_delete);

exit:
    return;
}
