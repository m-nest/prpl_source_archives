/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <sys/sysinfo.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_eth_switch.h"

#define ME "mod-eth-switch"

static int mod_eth_switch_noop(UNUSED const char* function_name,
                               UNUSED amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_INFO(ME, "Nothing to be done, handled by amxs");
    return 0;
}

static int mod_eth_switch_not_supported(const char* function_name,
                                        UNUSED amxc_var_t* args,
                                        UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_INFO(ME, "Function %s not supported", function_name);
    return -1;
}

static int system_uptime_get(UNUSED const char* function_name,
                             UNUSED amxc_var_t* args,
                             amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    struct sysinfo info;

    rv = sysinfo(&info);
    when_failed_trace(rv, exit, ERROR, "Could not read total uptime of the system");

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, ret, "uptime", info.uptime);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static AMXM_CONSTRUCTOR module_start(void) {
    SAH_TRACEZ_IN(ME);
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_ETH_LLA_CTRL);
    amxm_module_add_function(mod, "ethernet-enable-set", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-settings-get", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-settings-set", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-eee-get", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-eee-set", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-edpd-get", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-edpd-set", mod_eth_switch_noop);
    amxm_module_add_function(mod, "link-disable-arp", mod_eth_switch_noop);
    amxm_module_add_function(mod, "mtu-set", mod_eth_switch_noop);
    amxm_module_add_function(mod, "mac-address-get", mod_eth_switch_not_supported);
    amxm_module_add_function(mod, "mac-address-set", mod_eth_switch_not_supported);
    amxm_module_add_function(mod, "system-uptime-get", system_uptime_get);

    SAH_TRACEZ_OUT(ME);
    return 0;
}
