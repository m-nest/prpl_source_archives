# TR069 Discovery - implementation of the ACS Discovery mechanism from the TR-069 standard

The [TR-069 standard](https://www.broadband-forum.org/pdfs/tr-069-1-6-1.pdf) at section 3.1 "ACS Discovery" defines a mechanism to discover associated ACS via DHCP.

| Encapsulated Option              | DHCPv4 Option 125 | DHCPv6 Option 17 | Parameter                                     |
|----------------------------------|-------------------|------------------|-----------------------------------------------|
| URL of the ACS                   | 11                | 1                | ManagementServer.URL                          |
| Provisioning code                | 12                | 2                | DeviceInfo.ProvisioningCode                   |
| CWMP retry minimum wait interval | 13                | 3                | ManagementServer.CWMPRetryMinimumWaitInterval |
| CWMP retry interval multiplier   | 14                | 4                | ManagementServer.CWMPRetryIntervalMultiplier  |

`tr069-discovery` service implements provisioning of `ManagementServer.URL` and `DeviceInfo.ProvisioningCode`.