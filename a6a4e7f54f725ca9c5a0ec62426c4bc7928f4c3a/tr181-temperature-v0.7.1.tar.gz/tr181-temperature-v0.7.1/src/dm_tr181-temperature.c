/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

#define ME "tmp_start"

void _tempsensor_app_start(UNUSED const char* const sig_name,
                           UNUSED const amxc_var_t* const data,
                           UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "TR181-Temperature plugin starting");
    tempsensor_init_all();
}

amxd_status_t _tempsensor_destroy(amxd_object_t* object,
                                  UNUSED amxd_param_t* param,
                                  amxd_action_t reason,
                                  UNUSED const amxc_var_t* const args,
                                  UNUSED amxc_var_t* const retval,
                                  UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);

    tempsensor_info_t* tempsensor_info = NULL;
    amxd_status_t rv = amxd_status_invalid_function_argument;

    if(reason != action_object_destroy) {
        SAH_TRACEZ_NOTICE(ME, "Wrong reason, expected action_object_destroy(%d) got %d", action_object_destroy, reason);
        rv = amxd_status_invalid_action;
        goto exit;
    }

    when_null_trace(object, exit, ERROR, "Object can not be NULL, invalid argument");
    when_null_status(object->priv, exit, rv = amxd_status_ok);
    tempsensor_info = (tempsensor_info_t*) object->priv;
    tempsensor_high_alarm_reset(tempsensor_info);
    tempsensor_low_alarm_reset(tempsensor_info);

    object->priv = NULL;
    rv = tempsensor_info_clean(&tempsensor_info);

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

void _tempsensor_update(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* tempsensor_object = amxd_dm_signal_get_object(get_dm(), data);
    tempsensor_info_t* tempsensor_info = NULL;
    amxc_ts_t def_time = {0};
    amxc_var_t* parameters = GET_ARG(data, "parameters");
    amxc_var_t* high_alarm_value_var = GET_ARG(parameters, "HighAlarmValue");
    amxc_var_t* low_alarm_value_var = GET_ARG(parameters, "LowAlarmValue");
    amxc_var_t* polling_interval_var = GET_ARG(parameters, "PollingInterval");
    amxc_var_t* alarm_enabled_var = GET_ARG(parameters, "AlarmEnabled");
    int32_t high_alarm_value = GET_INT32(high_alarm_value_var, "to");
    int32_t low_alarm_value = GET_INT32(low_alarm_value_var, "to");
    int32_t polling_interval = GET_INT32(polling_interval_var, "to");
    bool alarm_enabled = GET_BOOL(alarm_enabled_var, "to");
    char* def_time_string = get_unknown_time();

    when_null_trace(tempsensor_object, exit, ERROR, "TemperatureSensor object could not be found");
    when_null_trace(tempsensor_object->priv, exit, ERROR, "TemperatureSensor has no private data");
    tempsensor_info = (tempsensor_info_t*) tempsensor_object->priv;

    // Stop the timer
    when_failed_trace(amxp_timer_stop(tempsensor_info->polling_timer), exit, ERROR, "Could not stop the timer");
    //Parse default time
    when_failed_trace(amxc_ts_parse(&def_time, def_time_string, strlen(def_time_string)), exit, ERROR, "Could not parse default time");

    // Update the data structure
    if(polling_interval != 0) {
        tempsensor_info->polling_interval = polling_interval * 1000;
    } else if(polling_interval_var != NULL) {
        tempsensor_info->polling_interval = tempsensor_info->def_polling_interval;
    }
    if(high_alarm_value_var != NULL) {
        tempsensor_info->high_alarm_value = high_alarm_value;
        tempsensor_info->high_alarm_time = def_time;
        tempsensor_info->high_alarm_set = true;
        if((high_alarm_value <= get_bad_temp()) && tempsensor_info->alarm_enabled) {
            tempsensor_high_alarm_reset(tempsensor_info);
        }
    }
    if(low_alarm_value_var != NULL) {
        tempsensor_info->low_alarm_value = low_alarm_value;
        tempsensor_info->low_alarm_time = def_time;
        tempsensor_info->low_alarm_set = true;
        if((low_alarm_value <= get_bad_temp()) && tempsensor_info->alarm_enabled) {
            tempsensor_low_alarm_reset(tempsensor_info);
        }
    }
    if(alarm_enabled_var != NULL) {
        if(!alarm_enabled) {
            tempsensor_high_alarm_reset(tempsensor_info);
            tempsensor_low_alarm_reset(tempsensor_info);
        }
        tempsensor_info->alarm_enabled = alarm_enabled;
    }

    // Restart timer
    amxp_timer_set_interval(tempsensor_info->polling_timer, tempsensor_info->polling_interval);
    when_failed_trace(amxp_timer_start(tempsensor_info->polling_timer, 0), exit, ERROR, "Could not start the timer");

exit:
    SAH_TRACEZ_OUT(ME);
}

void _tempsensor_toggled(UNUSED const char* const sig_name,
                         const amxc_var_t* const data,
                         UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);

    amxd_object_t* tempsensor_object = amxd_dm_signal_get_object(get_dm(), data);
    tempsensor_info_t* tempsensor_info = NULL;
    bool enable = GETP_BOOL(data, "parameters.Enable.to");

    when_null_trace(tempsensor_object, exit, ERROR, "TemperatureSensor object could not be found");
    when_null_trace(tempsensor_object->priv, exit, ERROR, "TemperatureSensor has no private data");

    tempsensor_info = (tempsensor_info_t*) tempsensor_object->priv;

    // Stop the timer
    when_failed_trace(amxp_timer_stop(tempsensor_info->polling_timer), exit, ERROR, "Could not stop the timer");

    tempsensor_info->enabled = enable;
    tempsensor_info->err = false;

    if(enable) {
        tempsensor_reset(tempsensor_object);
    }

    // Restart timer
    amxp_timer_set_interval(tempsensor_info->polling_timer, tempsensor_info->polling_interval);
    when_failed_trace(amxp_timer_start(tempsensor_info->polling_timer, 0), exit, ERROR, "Could not start the timer");

exit:
    SAH_TRACEZ_OUT(ME);
}

amxd_status_t _Reset(amxd_object_t* tempsensor_object,
                     UNUSED amxd_function_t* func,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_unknown_error;

    when_null_trace(tempsensor_object, exit, ERROR, "TemperatureSensor object could not be found");
    when_null_trace(tempsensor_object->priv, exit, ERROR, "TemperatureSensor has no private data");

    retval = tempsensor_reset(tempsensor_object);

exit:
    return retval;
}

amxd_status_t tempsensor_reset(amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t retval = amxd_status_unknown_error;
    amxd_trans_t trans;
    amxc_ts_t the_time;
    amxc_ts_t def_time;
    tempsensor_info_t* tempsensor_info = NULL;
    char* def_time_string = get_unknown_time();
    int32_t bad_temp = get_bad_temp();

    when_null_trace(object, exit, ERROR, "TemperatureSensor object could not be found");
    when_null_trace(object->priv, exit, ERROR, "TemperatureSensor has no private data");
    tempsensor_info = (tempsensor_info_t*) object->priv;

    // Some time
    amxc_ts_now(&the_time);
    amxc_ts_parse(&def_time, def_time_string, strlen(def_time_string));
    tempsensor_info->min_value = bad_temp;
    tempsensor_info->min_time = def_time;
    tempsensor_info->max_value = bad_temp;
    tempsensor_info->max_time = def_time;
    tempsensor_info->low_alarm_time = def_time;
    tempsensor_info->high_alarm_time = def_time;
    tempsensor_info->reset_time = the_time;
    tempsensor_info->high_alarm_set = true;
    tempsensor_info->low_alarm_set = true;
    tempsensor_high_alarm_reset(tempsensor_info);
    tempsensor_low_alarm_reset(tempsensor_info);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, object);

    amxd_trans_set_value(int32_t, &trans, "MaxValue", bad_temp);
    amxd_trans_set_value(int32_t, &trans, "MinValue", bad_temp);
    amxd_trans_set_value(int32_t, &trans, "Value", bad_temp);
    amxd_trans_set_value(amxc_ts_t, &trans, "ResetTime", &the_time);
    amxd_trans_set_value(amxc_ts_t, &trans, "MinTime", &def_time);
    amxd_trans_set_value(amxc_ts_t, &trans, "MaxTime", &def_time);
    amxd_trans_set_value(amxc_ts_t, &trans, "LastUpdate", &def_time);
    amxd_trans_set_value(amxc_ts_t, &trans, "HighAlarmTime", &def_time);
    amxd_trans_set_value(amxc_ts_t, &trans, "LowAlarmTime", &def_time);

    retval = amxd_trans_apply(&trans, get_dm());
    if(retval != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction with error code %d", retval);
    }

exit:
    amxd_trans_clean(&trans);
    SAH_TRACEZ_OUT(ME);
    return retval;
}
