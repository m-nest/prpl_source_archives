/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <cmocka.h>
#include <stdlib.h>

#include <amxc/amxc_macros.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include "../mocks/mock_amxm.h"

#include "common.h"
#include "test_dm.h"
#include "../../include_priv/dm_dnssd.h"
#include "../../include_priv/dnssd_dm_mngr.h"

static void resolver_add_all_functions(amxo_parser_t* parser) {
    assert_int_equal(amxo_resolver_ftab_add(parser, "dnssd_enable_changed",
                                            AMXO_FUNC(_dnssd_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dnssd_interfaces_changed",
                                            AMXO_FUNC(_dnssd_interfaces_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "service_subscribe",
                                            AMXO_FUNC(_service_subscribe)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "service_unsubscribe",
                                            AMXO_FUNC(_service_unsubscribe)), 0);
}

int test_setup(void** state) {
    amxut_bus_setup(state);
    const char* odl =
        "%config {"
        "    %global ip_intf_lan = \"Device.IP.Interface.3.\";"
        "}";

    amxo_parser_t* parser = amxut_bus_parser();
    resolver_add_all_functions(parser);
    amxo_parser_parse_string(amxut_bus_parser(), odl, amxd_dm_get_root(amxut_bus_dm()));

    amxut_dm_load_odl("../../odl/tr181-dnssd_definition.odl");

    assert_int_equal(_dnssd_main(0, amxut_bus_dm(), parser), 0);

    amxut_dm_load_odl("../../odl/defaults.d/00_main.odl");

    expect_amxm_execute_function_umdns("enable-intfs");
    expect_amxm_execute_function_umdns("update-timers");
    test_dm_handle_events(1000);
    assert_dm_param_equal(cstring_t, "DNSSD.", "Status", "Enabled");
    return 0;
}

int test_teardown(UNUSED void** state) {
    amxut_bus_handle_events();

    expect_amxm_execute_function_umdns("stop-backend");
    assert_int_equal(_dnssd_main(1, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_handle_events();
    amxut_bus_teardown(state);
    return 0;
}
