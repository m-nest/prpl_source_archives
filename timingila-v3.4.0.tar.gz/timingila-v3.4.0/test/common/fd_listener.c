/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <poll.h>

#include <amxc/amxc_variant.h>
#include <amxc/amxc_lqueue.h>
#include <amxc/amxc_llist.h>
#include <amxp/amxp_connection.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>

#include <lcm/lcm_assert.h>
#include <debug/sahtrace.h>
#include "fd_listener.h"

#define UNUSED __attribute__((unused))
#define ME "test"

typedef struct _fd_con_t {
    amxc_llist_it_t it;
    amxp_connection_t* con;
} fd_con_t;

static amxc_llist_t fd_con_list = { .head = NULL, .tail = NULL };

static int fd_con_new(fd_con_t** inst) {
    int retval = -1;
    ASSERT_NOT_NULL(inst, goto exit);
    ASSERT_NOT_NULL(!*inst, goto  exit);

    *inst = (fd_con_t*) calloc(1, sizeof(fd_con_t));
    ASSERT_NOT_NULL(*inst, goto exit);

    amxc_llist_append(&fd_con_list, &(*inst)->it);

    retval = 0;

exit:
    return retval;
}

static int fd_con_delete(fd_con_t** inst) {
    int retval = -1;
    ASSERT_NOT_NULL(inst, goto exit);
    ASSERT_NOT_NULL(*inst, goto exit);
    amxc_llist_it_take(&(*inst)->it);
    free(*inst);
    *inst = NULL;

    retval = 0;
exit:
    return retval;
}

static void slot_add_fd(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    amxp_connection_t* con = NULL;
    fd_con_t* fd_con = NULL;

    ASSERT_TRUE(amxc_var_type_of(data) == AMXC_VAR_ID_FD, goto  exit);

    con = amxp_connection_get(amxc_var_constcast(fd_t, data));
    ASSERT_NOT_NULL(con, goto exit);

    fd_con_new(&fd_con);
    ASSERT_NOT_NULL(fd_con, goto exit);
    fd_con->con = con;

exit:
    return;
}

static void slot_remove_fd(UNUSED const char* const sig_name,
                           const amxc_var_t* const data,
                           UNUSED void* const priv) {
    amxp_connection_t* con = NULL;

    ASSERT_TRUE(amxc_var_type_of(data) == AMXC_VAR_ID_FD, goto  exit);

    con = amxp_connection_get(amxc_var_constcast(fd_t, data));
    ASSERT_NOT_NULL(con, goto exit);

    amxc_llist_for_each(it, &fd_con_list) {
        fd_con_t* fd_con = amxc_llist_it_get_data(it, fd_con_t, it);
        if(fd_con->con == con) {
            fd_con_delete(&fd_con);
            goto exit;
        }
    }

exit:
    return;
}

static void fd_con_list_it_free(amxc_llist_it_t* it) {
    fd_con_t* part = amxc_llist_it_get_data(it, fd_con_t, it);
    fd_con_delete(&part);
}

int fd_listener_start(void) {
    int res = -1;
    ASSERT_SUCCESS(amxp_slot_connect(NULL, "listen-added", NULL, slot_add_fd, NULL), goto exit);
    ASSERT_SUCCESS(amxp_slot_connect(NULL, "listen-deleted", NULL, slot_remove_fd, NULL), goto exit);
    res = 0;
exit:
    return res;
}

void fd_listener_stop(void) {
    amxc_llist_clean(&fd_con_list, fd_con_list_it_free);
}

void fd_listener_check(void) {
    amxc_llist_for_each(it, &fd_con_list) {
        fd_con_t* fd_con = amxc_llist_it_get_data(it, fd_con_t, it);
        amxp_connection_t* con = fd_con->con;
        struct pollfd fds = {0};
        fds.fd = con->fd;
        fds.events = POLLIN;
        if(poll(&fds, 1, 0) > 0) {
            con->reader(con->fd, con->priv);
        }
    }
}
