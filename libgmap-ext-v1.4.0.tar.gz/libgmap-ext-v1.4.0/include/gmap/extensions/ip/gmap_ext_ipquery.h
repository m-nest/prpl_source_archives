/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_EXT_IPQUERY_H__)
#define __GMAP_EXT_IPQUERY_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <stdbool.h>
#include <stdint.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>


typedef struct gmap_ipquery gmap_ipquery_t;

/**
 * @brief ip query callback function type.
 *
 * An ip query will invoke its callback when an ip address
 * - is added and its status is reachable (ip_active = true)
 * - is changed and its status becomes reachable (ip_active = true) or not rachable (ip_active = false)
 * - is removed and its statis was reachable (ip_active = false)
 *
 * If the .Address parameter changes value, the callback may be called up to two
 * times: once to signal the disappearance of the old ip address and once again
 * to signal the appearance of the new address.
 *
 * @note Calling @ref gmap_ipquery_delete from within this callback function is
 *       supported on the condition that the `gmap_ipquery_t*` referenced in the
 *       parameters to @ref gmap_ipquery_new is not deallocated until
 *       @ref gmap_ipquery_new has returned.
 *
 * @note In other words, the callback function itself may not free the memory
 *       where this pointer resides unless it is certain that it is not called
 *       from within @ref gmap_ipquery_new.
 *
 * @param dev_key The unique device key containing the ip address.
 * @param ip The specific ip address that has become reachable/unreachable
 * @param ip_active true if the device has become reachable through this ip address,
 *                  false otherwise.
 */
typedef void (* gmap_ipquery_cb_t) (const char* dev_key,
                                    const char* ip,
                                    bool ip_active,
                                    void* const userdata);

/**
 * @brief Create and initialize a new ip query.
 *
 * ip queries allow tracking the reachable ip addresses of a device for a specific
 * ip address family.
 *
 * @note It is possible to close the created query from within its callback given
 *       some limitations. See @ref gmap_ipquery_cb_t and @ref gmap_ipquery_delete.
 *
 * @warning The library does not automatically delete any open ip queries. These
 *          must be cleaned up explicitly with a call to @ref gmap_ipquery_delete.
 *
 * @param ipquery Will be filled with the pointer to the newly created gmap_ipquery_t object,
 *                or NULL on failure.
 * @param family IP address family (one of @ref AF_INET or @ref AF_INET6)
 * @param tag Only watch devices that have this tag. This feature is no longer supported.
 * @param callback The callback function to be executed whenever a device becomes
 *                 reachable through an ip address or stops being reachable through
 *                 an earlier reported address.
 *                 On ip query creation, the callback will be called for every
 *                 known reachable address before this function returns.
 * @param userdata: userdata to be passed to the callback. This pointer is never
 *                  dereferenced or modified or interpreted in any way by the
 *                  ip query implementation.
 * @retval true if the ip query was opened successfully.
 * @retval false if opening the ip query failed for some reason.
 */
bool gmap_ipquery_new(gmap_ipquery_t** ipquery,
                      uint32_t family,
                      UNUSED const char* tag,
                      gmap_ipquery_cb_t callback,
                      void* userdata);

/**
 * @brief Deletes the ip query and cleans up any allocated resources.
 *
 * @note Calling this function from within the ipquery callback is supported as
 *       long as the memory containing the pointer referenced by `ipquery` is
 *       not deallocated before @ref gmap_ipquery_new has returned.
 *
 * @warning On systems using musl as their libc implementation, it is *not* safe
 *          to call this from a destructor context.
 *          Musl may execute these functions in an incorrect order, calling the
 *          destructor of libamxb first. When that happens, gmap_ipquery_delete
 *          may attempt to clean up resources through a dangling amxb_bus_ctx
 *          pointer.
 * @warning Instead, all ipquery objects must be cleaned up from the module or
 *          plugin entry-point or at least before main returns.
 *
 * @internal
 *     The caveat of requiring the ipquery pointer to remain allocated during
 *     calls to @ref gmap_ipquery_new may be tricky to adhere to when these are
 *     for example stored in a linked list and need to be cleaned up at some point.
 * @endinternal
 *
 * @param ipquery Pointer to the query object to delete. This pointer will be set
 *                to NULL.
 */
void gmap_ipquery_delete(gmap_ipquery_t** ipquery);

#ifdef __cplusplus
}
#endif
#endif // __GMAP_EXT_IPQUERY_H__
