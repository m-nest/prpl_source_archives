/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <setjmp.h>
#include <cmocka.h>
#include <debug/sahtrace.h>
#include <dmcom/dm_com.h>
#include <dmengine/DM_ENG_Device.h>

#include "test_gpn.h"
#include "../common/common.h"

extern device_adapter_t* device_adapter;
int FAKE_DM_ENG_Device_GPN(const char* parameterName, bool nextLevel, dm_eng_pn_list_t* pn_list);

int test_setup(UNUSED void** state) {
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "CWMPD");
    sahTraceOpen("TEST", TRACE_TYPE_STDOUT);
    return 0;
}

int test_teardown(UNUSED void** state) {
    xmlCleanupParser();
    sahTraceClose();
    return 0;
}

int FAKE_DM_ENG_Device_GPN(const char* parameterName, UNUSED bool nextLevel, dm_eng_pn_list_t* pn_list) {
    dm_eng_pn_t* pn = NULL;
    struct {
        const char* name;
        bool writable;
    } result[] = {
        {"Device.IP.", false},
        {"Device.IP.ActivePortNumberOfEntries", false},
        {"Device.IP.ActivePort.", true},
        {"Device.IP.Diagnostics.Controller", false},
        {"Device.IP.Diagnostics.DownloadDiagnosticsMaxConnections", true},
        {NULL, false} // end marker
    };

    assert_string_equal(parameterName, "Device.IP.");

    size_t i = 0;
    while(result[i].name) {
        pn = dm_eng_pn_list_get(pn_list, result[i].name);
        if(!pn) {
            pn = dm_eng_pn_new(result[i].name, result[i].writable);
            dm_eng_pn_list_add(pn_list, pn);
        }
        i++;
    }
    return 0;
}

void test_gpn(UNUSED void** state) {
    int retval = 0;
    device_adapter_t da;
    device_adapter = &da;
    device_adapter->DM_ENG_Device_GPN = FAKE_DM_ENG_Device_GPN;

    unlink("/tmp/message_sent.xml");
    retval = DM_SUB_GetParameterNames("Just-A-Test", "Device.IP.", false);
    assert_int_equal(retval, 0);

    assert_int_equal(compare_files_sha256("/tmp/message_sent.xml", flatten_xml("./files/expected_message_sent.xml")), 0);
    DM_COM_STOP();
    assert_int_equal(retval, 0);
}
