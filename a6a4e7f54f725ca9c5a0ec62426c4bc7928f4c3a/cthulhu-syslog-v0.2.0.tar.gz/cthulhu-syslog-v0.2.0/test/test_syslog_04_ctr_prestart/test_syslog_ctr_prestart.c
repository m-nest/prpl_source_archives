/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <libgen.h>
#include <sys/stat.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>
#include <debug/sahtrace.h>

#include <lcm/amxc_data.h>
#include <lcm/lcm_assert.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_ctr_start_data.h>
#include <cthulhu/cthulhu_helpers.h>

#include "cthulhu_syslog.h"
#include "cthulhu_syslog_defines.h"
#include "log.h"
#include "test_setup.h"
#include "lcm_bus.h"
#include "test_syslog_ctr_prestart.h"

lcm_bus_t* bus_syslog = NULL;

const char* sb_id = "prestart_sb";
const char* ctr_id = "prestart_ctr";


static void debug_create_socket(const char* socket_path) {
    char* dupl = strdup(socket_path);
    cthulhu_mkdir(dirname(dupl), true);
    free(dupl);
    if(cthulhu_issocket(socket_path)) {
        return;
    }
    SAH_TRACEZ_ERROR(ME, "DEBUG: CREATE SOCKET");
    struct sockaddr_un address;
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, socket_path);
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    bind(fd, (struct sockaddr*) (&address), sizeof(address));
    chmod(socket_path, S_IRWXU | S_IRWXG | S_IRWXO);
}


static void test_syslog_init(void) {
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, test_get_main_dm());

    int res = cthulhu_syslog_init("", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

static void test_syslog_odl_loaded(void) {
    bus_syslog = lcm_bus_create("syslog");
    assert_true(bus_syslog);

    if(amxo_parser_parse_file(&bus_syslog->parser, "../odl/device_syslog.odl", amxd_dm_get_root(&bus_syslog->dm))) {
        SAH_TRACEZ_ERROR(ME, "%s", amxo_parser_get_message(&bus_syslog->parser));
        assert_true(0);
    }

    int res = cthulhu_syslog_odl_loaded("", NULL, NULL);
    assert_int_equal(res, 0);
}

static void test_syslog_ctr_create(void) {
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, ctr_id);

    int res = cthulhu_syslog_ctr_create("", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

}

static void test_syslog_cleanup(void) {
    int res = cthulhu_syslog_cleanup("", NULL, NULL);
    assert_int_equal(res, 0);
    lcm_bus_delete(&bus_syslog, false);
}


int test_setup(UNUSED void** state) {
    assert_int_equal(test_syslog_setup(), 0);

    test_add_sb(sb_id);
    test_add_ctr(ctr_id, sb_id);

    test_syslog_init();
    test_syslog_odl_loaded();
    test_syslog_ctr_create();

    return 0;
}

int test_teardown(UNUSED void** state) {
    test_syslog_cleanup();
    test_syslog_teardown();
    return 0;
}


void test_syslog_ctr_prestart(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;
    cthulhu_ctr_start_data_t* start_data = NULL;


    test_handle_events();

    amxc_var_init(&args);
    amxc_var_init(&ret);

    assert_int_equal(cthulhu_ctr_start_data_new(&start_data), 0);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, ctr_id);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_START_DATA, start_data);

    // create the log file, so the test succeeds
    debug_create_socket("/var/run/cthulhu/syslog/prestart_ctr/log.sock");

    int res = cthulhu_syslog_ctr_prestart("", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    // check source data
    amxd_object_t* source = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Source.[Alias == 'prestart_ctr']");
    assert_non_null(source);
    amxd_object_t* socket = amxd_object_findf(source, SYSLOG_SOCKET);
    assert_non_null(socket);
    bool enable = amxd_object_get_bool(socket, SYSLOG_ENABLE, NULL);
    assert_true(enable);
    char* socketpath = amxd_object_get_cstring_t(socket, SYSLOG_SOCKETPATH, NULL);
    assert_string_equal("file:///var/run/cthulhu/syslog/prestart_ctr/log.sock", socketpath);
    free(socketpath);

    // check template data
    amxd_object_t* template = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Template.[Alias == 'prestart_ctr']");
    assert_non_null(template);
    char* expression = amxd_object_get_cstring_t(template, "Expression", NULL);
    assert_string_equal("\"${FULLDATE} prestart_ctr ${MSGHDR}${MSG}\n\"", expression);
    free(expression);

    // check action data
    amxd_object_t* action = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Action.[Alias == 'prestart_ctr']");
    assert_non_null(action);
    char* source_path = amxd_object_get_path(source, AMXD_OBJECT_INDEXED);
    char* action_source_ref = amxd_object_get_cstring_t(action, "SourceRef", NULL);
    assert_string_equal(source_path, action_source_ref);
    free(source_path);
    free(action_source_ref);
    char* template_ref = amxd_object_get_cstring_t(action, "TemplateRef", NULL);
    assert_string_equal(template_ref, "Device.Syslog.Template.1");
    free(template_ref);
    amxd_object_t* logfile = amxd_object_findf(action, "LogFile");
    assert_non_null(logfile);
    enable = amxd_object_get_bool(logfile, "Enable", NULL);
    assert_true(enable);
    char* file_path = amxd_object_get_cstring_t(logfile, "FilePath", NULL);
    assert_string_equal(file_path, "file:///tmp/cthulhu/syslog/prestart_ctr/messages");
    free(file_path);

    // check start_data
    amxc_llist_it_t* mounts_it = amxc_llist_get_first(&start_data->mounts);
    cthulhu_mount_data_t* mount_data = amxc_llist_it_get_data(mounts_it, cthulhu_mount_data_t, lit);
    assert_string_equal(mount_data->source, "/var/run/cthulhu/syslog/prestart_ctr/log.sock");
    assert_string_equal(mount_data->destination, "/run/log.sock");

    mounts_it = amxc_llist_it_get_next(mounts_it);
    mount_data = amxc_llist_it_get_data(mounts_it, cthulhu_mount_data_t, lit);
    assert_string_equal(mount_data->source, "/var/run/cthulhu/syslog/prestart_ctr/log.sock");
    assert_string_equal(mount_data->destination, "/dev/log");


    cthulhu_ctr_start_data_delete(&start_data);
    LOG_EXIT
}

void test_syslog_ctr_poststop(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;

    test_handle_events();

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, ctr_id);

    int res = cthulhu_syslog_ctr_poststop("", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    // check source data
    amxd_object_t* source = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Source.[Alias == 'prestart_ctr']");
    assert_non_null(source);
    amxd_object_t* socket = amxd_object_findf(source, SYSLOG_SOCKET);
    assert_non_null(socket);
    bool enable = amxd_object_get_bool(socket, SYSLOG_ENABLE, NULL);
    assert_true(enable);
    char* socketpath = amxd_object_get_cstring_t(socket, SYSLOG_SOCKETPATH, NULL);
    assert_string_equal("file:///var/run/cthulhu/syslog/prestart_ctr/log.sock", socketpath);
    free(socketpath);

    // check action data
    amxd_object_t* action = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Action.[Alias == 'prestart_ctr']");
    assert_non_null(action);
    char* source_path = amxd_object_get_path(source, AMXD_OBJECT_INDEXED);
    char* action_source_ref = amxd_object_get_cstring_t(action, "SourceRef", NULL);
    assert_string_equal(source_path, action_source_ref);
    free(source_path);
    free(action_source_ref);
    char* template_ref = amxd_object_get_cstring_t(action, "TemplateRef", NULL);
    assert_string_equal(template_ref, "Device.Syslog.Template.1");
    free(template_ref);
    amxd_object_t* logfile = amxd_object_findf(action, "LogFile");
    assert_non_null(logfile);
    enable = amxd_object_get_bool(logfile, "Enable", NULL);
    assert_true(enable);
    char* file_path = amxd_object_get_cstring_t(logfile, "FilePath", NULL);
    assert_string_equal(file_path, "file:///tmp/cthulhu/syslog/prestart_ctr/messages");
    free(file_path);

    LOG_EXIT
}

void test_syslog_ctr_preremove(UNUSED void** state) {
    LOG_ENTRY
    amxc_var_t args;
    amxc_var_t ret;

    test_handle_events();

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_cstring_t(&args, CTHULHU_PLUGIN_ARG_CTR_ID, ctr_id);

    int res = cthulhu_syslog_ctr_preremove("", &args, &ret);
    assert_int_equal(res, 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    // check source data
    amxd_object_t* source = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Source.[Alias == 'prestart_ctr']");
    assert_null(source);

    // check action data
    amxd_object_t* action = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Action.[Alias == 'prestart_ctr']");
    assert_null(action);

    // check template data
    amxd_object_t* template = amxd_dm_findf(&bus_syslog->dm, "Device.Syslog.Template.[Alias == 'prestart_ctr']");
    assert_null(template);

    LOG_EXIT
}