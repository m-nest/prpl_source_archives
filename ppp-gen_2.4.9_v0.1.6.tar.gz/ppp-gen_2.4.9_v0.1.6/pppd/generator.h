#ifndef __GENERATOR_H
#define __GENERATOR_H

#define ERROR_NO_TIMEPOINT_LEFT -1
#define REPEAT_LAST_TIMEPOINT   -1

typedef struct timepoints_t {
    int i;
    int size;
    int* tps;
    int (* next)(struct timepoints_t* self);
    void (* reset)(struct timepoints_t* self);
} timepoints_t;

timepoints_t* initialize_timepoints(const char* timepoints);
timepoints_t* generate_timepoints(int timeout_value, int max_transmits);
int next(timepoints_t* t);
int peek(timepoints_t* t);
void reset(timepoints_t* t);
void cleanup_timepoints(timepoints_t** t);

#endif
