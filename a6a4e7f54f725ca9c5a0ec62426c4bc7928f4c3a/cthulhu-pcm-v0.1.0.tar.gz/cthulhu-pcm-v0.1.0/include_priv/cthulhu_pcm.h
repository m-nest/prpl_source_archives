/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#if !defined(__CTHULHU_PCM_H__)
#define __CTHULHU_PCM_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_function.h>

#define SIZE 128

// Helper structure to copy parameters from imported data
// to arguments expected in Cthulhu RPC (e.g: Sandbox.restore(), Container.restore(), etc.)
typedef struct _cthulhu_restore_data {
    char parameter[SIZE]; // The parameter name to be set
    char path[SIZE];      // The path of the parameter value to be retrieved from the source variant
    int flags;            // flag to be used when copying
} cthulhu_restore_data_t;

#define PRIVATE __attribute__ ((visibility("hidden")))
#define UNUSED __attribute__((unused))

/**
 * @brief Module constructor for the Cthulhu Pcm plugin.
 *
 * Called automatically when the module is loaded.
 */
AMXM_CONSTRUCTOR module_init(void);

/**
 * @brief Module destructor for the Cthulhu Pcm plugin.
 *
 * Called automatically when the module is unloaded.
 */
AMXM_DESTRUCTOR module_exit(void);

/**
 * @brief Initializes the Cthulhu Pcm plugin.
 *
 * @param function_name Name of the function being called.
 * @param args Arguments for initialization.
 * @param ret Return value variable.
 * @return 0 on success, non-zero on failure.
 */
int cthulhu_pcm_init(UNUSED const char* function_name,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret);

/**
 * @brief Gets the prestaup_config pointer.
 * @return Pointer to saved prestaup_config.
 */
cthulhu_prestartup_config_t* get_prestartup_config(void);

/**
 * @brief Sets the prestaup_config pointer.
 * @return Pointer to saved prestaup_config.
 */
void set_prestartup_config(cthulhu_prestartup_config_t* config);

amxd_status_t custom_pcm_export(amxd_object_t* object,
                                amxd_function_t* func,
                                amxc_var_t* args,
                                amxc_var_t* ret);

amxd_status_t custom_pcm_import(amxd_object_t* object,
                                amxd_function_t* func,
                                amxc_var_t* args,
                                amxc_var_t* ret);

void cthulhu_sb_restore_fill(amxc_var_t* dest_sb, const amxc_var_t* src_sb);
void cthulhu_ctr_restore_fill(amxc_var_t* dest_ctr, const amxc_var_t* src_ctr,
                              const amxc_var_t* sandboxes);
void cthulhu_copy_args(amxc_var_t* dest, const amxc_var_t* src,
                       const cthulhu_restore_data_t* rpc_args, size_t args_count);

#ifdef __cplusplus
}
#endif

#endif // __CTHULHU_PCM_H__
