/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_string.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include "tr181-periodicfileupload.h"
#include "libperiodicfileupload.h"

#define ME "periodic-upload"

#define INCR_OBJ_PARAM(obj, param) (amxd_object_get_uint64_t(obj, param, NULL) + 1)

/**
 * @brief Gets state mnemonic string
 *
 * Converts a numeric state value to its corresponding human-readable
 * string representation.
 *
 * @param[in] state Numeric state value
 *
 * @return String representation of the state, "Error" if state is invalid
 *
 * @note Returns one of: "Idle", "Creating", "Uploading", "Success", "Retrying", "Error"
 */
static const char* get_libpfu_state_mnemo(uint32_t state) {
    const char* mnemo[] = {"Idle", "Creating", "Uploading", "Success", "Retrying", "Error"};

    if(state >= (sizeof(mnemo) / sizeof(const char*))) {
        return "Error";
    }
    return mnemo[state];
}

/**
 * @brief Updates transfer statistics in transaction
 *
 * Updates both per-transfer and global statistics based on transfer state
 * within a data model transaction for updates.
 *
 * @param[in] transfer Transfer object to update statistics for
 * @param[in] data Transfer event data containing state and error information
 * @param[in] trans Transaction object for atomic updates
 */
static void transfer_stats_transac(amxd_object_t* transfer, const amxc_var_t* const data, amxd_trans_t* trans) {
    amxc_ts_t now;
    amxd_object_t* stats = amxd_dm_findf(periodic_fupload_get_dm(), "%sStats.", PFU_ROOT_DM_PATH);

    amxc_ts_now(&now);
    amxd_trans_select_object(trans, amxd_object_findf(transfer, "Stats"));
    switch(GET_UINT32(data, "State")) {
    case pfu_state_success:
        amxd_trans_set_amxc_ts_t(trans, "LastSuccess", &now);
        amxd_trans_set_uint64_t(trans, "SuccessCount", INCR_OBJ_PARAM(transfer, "SuccessCount"));
        amxd_trans_select_object(trans, stats);
        amxd_trans_set_uint64_t(trans, "UploadSuccessful", INCR_OBJ_PARAM(stats, "UploadSuccessful"));
        break;
    case pfu_state_retrying:
    case pfu_state_error:
        amxd_trans_set_amxc_ts_t(trans, "LastFailed", &now);
        amxd_trans_set_uint32_t(trans, "LastErrorCode", GET_UINT32(data, "Error"));
        amxd_trans_set_uint64_t(trans, "FailedCount", INCR_OBJ_PARAM(transfer, "FailedCount"));
        amxd_trans_select_object(trans, stats);
        amxd_trans_set_uint64_t(trans, "UploadFailed", INCR_OBJ_PARAM(stats, "UploadFailed"));
        break;
    default:
        break;
    }
}

/**
 * @brief Handles force transfer completion
 *
 * Completes a forced transfer operation by sending deferred response,
 * cleaning up resources, and restarting normal periodic transfers.
 *
 * @param[in] transfer Transfer object that completed
 * @param[in] data Transfer completion data
 * @param[in] state Final transfer state
 *
 * @note Sends deferred function response with completion status
 * @note Restarts transfer with original interval
 */
static void forcetransfer_done(amxd_object_t* transfer, const amxc_var_t* const data, periodicfileupload_state_t state) {
    uint64_t* call_id = (uint64_t*) transfer->priv;
    amxc_string_t data_str;
    amxc_var_t ret_val;

    amxc_var_init(&ret_val);
    amxc_string_init(&data_str, 0);
    amxc_var_set_type(&ret_val, AMXC_VAR_ID_HTABLE);
    amxc_string_setf(&data_str, "Transfer ended with error code (%u)", GET_UINT32(data, "Error"));
    amxc_var_add_key(cstring_t, &ret_val, "data", amxc_string_get(&data_str, 0));
    if(*call_id != (uint64_t) -1) {
        amxd_function_deferred_done(*call_id, (state == pfu_state_success) ? amxd_status_ok : amxd_status_unknown_error, NULL, &ret_val);
    }
    free(call_id);
    transfer->priv = NULL;
    periodicfileupload_stop(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED));
    amxc_ts_t* time_reference = amxd_object_get_amxc_ts_t(transfer, "TimeReference", NULL);
    periodicfileupload_set_interval(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED), amxd_object_get_uint32_t(transfer, "UploadInterval", NULL), time_reference);
    periodicfileupload_start(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED));
    free(time_reference);
    amxc_var_clean(&ret_val);
    amxc_string_clean(&data_str);
}

/**
 * @brief Transfer state change callback
 *
 * Main callback for handling transfer state changes, updating data model
 * parameters and statistics based on transfer events.
 *
 * @param[in] data Transfer event data containing state, error, and timing info
 * @param[in] priv Transfer object pointer
 * @note Uses transactions for data model updates
 */
static void transfer_cb(const amxc_var_t* const data, void* const priv) {
    amxd_object_t* transfer = (amxd_object_t*) priv;
    amxd_trans_t trans;
    periodicfileupload_state_t state;

    when_null(transfer, exit);
    when_null(data, exit);
    state = GET_UINT32(data, "State");
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, transfer);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_cstring_t(&trans, "Status", get_libpfu_state_mnemo(state));
    if(GET_ARG(data, "NextTransfer") != NULL) {
        amxd_trans_set_cstring_t(&trans, "NextTransferDate", GET_CHAR(data, "NextTransfer"));
    }
    if((state == pfu_state_success) || (state == pfu_state_error)) {
        transfer_stats_transac(transfer, data, &trans);
        if(transfer->priv != NULL) {
            forcetransfer_done(transfer, data, state);
        }
    } else if((state == pfu_state_retrying)) {
        transfer_stats_transac(transfer, data, &trans);
    }
    amxd_trans_apply(&trans, periodic_fupload_get_dm());
    amxd_trans_clean(&trans);
exit:
    return;
}

void register_transfer(amxd_object_t* instance) {
    const char* script = NULL;
    const char* id = amxd_object_get_name(instance, AMXD_OBJECT_NAMED);
    amxd_object_t* file = amxd_dm_findf(periodic_fupload_get_dm(), "%sFileTypeConfig.[FileTypeReference=='%s'].", PFU_ROOT_DM_PATH, GET_CHAR(amxd_object_get_param_value(instance, "Type"), NULL));

    if(file == NULL) {
        SAH_TRACEZ_ERROR(ME, "Couldn't find FileTypeConfig %s", GET_CHAR(amxd_object_get_param_value(instance, "Type"), NULL));
        return;
    }
    periodicfileupload_register_file(id,
                                     GET_CHAR(amxd_object_get_param_value(file, "FilePath"), NULL),
                                     GET_CHAR(amxd_object_get_param_value(instance, "ProfileReference"), NULL));

    amxc_ts_t* time_reference = amxd_object_get_amxc_ts_t(instance, "TimeReference", NULL);
    periodicfileupload_set_interval(id, amxd_object_get_uint32_t(instance, "UploadInterval", NULL), time_reference);
    free(time_reference);
    script = GET_CHAR(amxd_object_get_param_value(file, "PreHookScript"), NULL);
    if(script && *script) {
        periodicfileupload_preupload_cb(id, periodicfileupload_exec_script_cb, (void*) script);
    }
    script = GET_CHAR(amxd_object_get_param_value(file, "PostHookScript"), NULL);
    if(script && *script) {
        periodicfileupload_postupload_cb(id, periodicfileupload_exec_script_cb, (void*) script);
    }
    periodicfileupload_set_transfer_cb(id, transfer_cb, instance);
    periodicfileupload_start(id);
}

void _dm_transfer_added(UNUSED const char* const sig_name,
                        const amxc_var_t* const data,
                        UNUSED void* const priv) {
    amxd_object_t* file = amxd_dm_signal_get_object(periodic_fupload_get_dm(), data);
    amxd_object_t* instance = amxd_object_get_instance(file, NULL, GET_UINT32(data, "index"));

    if((instance == NULL) || !periodic_fupload_enabled() ||
       (amxd_object_get_bool(instance, "Enable", NULL) == false)) {
        return;
    }
    SAH_TRACEZ_NOTICE(ME, "New transfer (%s) has been added", amxd_object_get_name(instance, AMXD_OBJECT_NAMED));
    register_transfer(instance);
}

void _dm_transfer_changed(UNUSED const char* const sig_name,
                          const amxc_var_t* const data,
                          UNUSED void* const priv) {
    amxd_object_t* file = amxd_dm_signal_get_object(periodic_fupload_get_dm(), data);

    if((file == NULL) || !periodic_fupload_enabled()) {
        return;
    }
    SAH_TRACEZ_NOTICE(ME, "Transfer (%s) has changed", amxd_object_get_name(file, AMXD_OBJECT_NAMED));
    if((amxd_object_get_bool(file, "Enable", NULL) == false)) {
        if((GETP_ARG(data, "parameters.Enable") != NULL) && (GETP_BOOL(data, "parameters.Enable.from") == true)) {
            periodicfileupload_deregister_file(amxd_object_get_name(file, AMXD_OBJECT_NAMED));
        }
        return;
    }
    register_transfer(file);
}

void _dm_transfer_status_done(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    amxd_object_t* file = amxd_dm_signal_get_object(periodic_fupload_get_dm(), data);
    amxd_trans_t trans;

    if(file == NULL) {
        return;
    }
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, file);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_cstring_t(&trans, "Status", "Idle");
    amxd_trans_apply(&trans, periodic_fupload_get_dm());
    amxd_trans_clean(&trans);
}

amxd_status_t _dm_transfer_destroyed(amxd_object_t* object,
                                     UNUSED amxd_param_t* param,
                                     amxd_action_t reason,
                                     UNUSED const amxc_var_t* const args,
                                     amxc_var_t* const retval,
                                     UNUSED void* priv) {
    amxd_status_t status = amxd_status_ok;

    if(reason != action_object_destroy) {
        status = amxd_status_function_not_implemented;
        goto leave;
    }
    SAH_TRACEZ_NOTICE(ME, "Transfer %s has been removed", amxd_object_get_name(object, AMXD_OBJECT_NAMED));
    periodicfileupload_deregister_file(amxd_object_get_name(object, AMXD_OBJECT_NAMED));
    amxc_var_clean(retval);
leave:
    return status;
}

amxd_status_t _ForceTransfer(amxd_object_t* transfer, amxd_function_t* func, UNUSED amxc_var_t* args, amxc_var_t* ret) {
    amxd_status_t ret_status = amxd_status_unknown_error;
    const char* id = amxd_object_get_name(transfer, AMXD_OBJECT_NAMED);
    uint64_t* call_id = NULL;

    when_false_trace(transfer->priv == NULL, exit, ERROR, "the transfer is already being forced");
    when_false_trace(strcmp(GET_CHAR(amxd_object_get_param_value(transfer, "Status"), NULL), "Idle") == 0, exit, ERROR, "the transfer is already on going")
    call_id = malloc(sizeof(*call_id));
    transfer->priv = call_id;
    amxd_function_defer(func, call_id, ret, NULL, NULL);
    periodicfileupload_stop(id);
    amxc_ts_t* time_reference = amxd_object_get_amxc_ts_t(transfer, "TimeReference", NULL);
    periodicfileupload_set_interval(id, 0, time_reference);
    when_failed(periodicfileupload_start(id), error);
    free(time_reference);
    ret_status = amxd_status_deferred;
exit:
    return ret_status;
error:
    free(call_id);
    transfer->priv = NULL;
    periodicfileupload_set_interval(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED), amxd_object_get_uint32_t(transfer, "UploadInterval", NULL), time_reference);
    periodicfileupload_start(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED));
    free(time_reference);
    return ret_status;
}

void _dm_transfer_forcetransfer(UNUSED const char* const sig_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxd_object_t* transfer = amxd_dm_signal_get_object(periodic_fupload_get_dm(), data);
    const char* id = amxd_object_get_name(transfer, AMXD_OBJECT_NAMED);
    amxd_trans_t trans;
    uint64_t* call_id = NULL;
    amxc_string_t forcetransfer_param_name;

    amxc_string_init(&forcetransfer_param_name, 0);
    amxc_string_setf(&forcetransfer_param_name, "%sForceTransfer", GET_CHAR(&periodic_fupload_get_parser()->config, "global_vendor_prefix_"));
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, transfer);
    amxd_trans_set_bool(&trans, amxc_string_get(&forcetransfer_param_name, 0), false);
    amxd_trans_apply(&trans, periodic_fupload_get_dm());
    amxd_trans_clean(&trans);
    amxc_string_clean(&forcetransfer_param_name);
    when_false_trace(strcmp(GET_CHAR(amxd_object_get_param_value(transfer, "Status"), NULL), "Idle") == 0, exit, ERROR, "the transfer is already on going")
    call_id = malloc(sizeof(*call_id));
    *call_id = (uint64_t) -1;
    transfer->priv = call_id;
    periodicfileupload_stop(id);
    amxc_ts_t* time_reference = amxd_object_get_amxc_ts_t(transfer, "TimeReference", NULL);
    periodicfileupload_set_interval(id, 0, time_reference);
    when_failed(periodicfileupload_start(id), error);
    free(time_reference);
exit:
    return;
error:
    free(call_id);
    transfer->priv = NULL;
    periodicfileupload_set_interval(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED), amxd_object_get_uint32_t(transfer, "UploadInterval", NULL), time_reference);
    periodicfileupload_start(amxd_object_get_name(transfer, AMXD_OBJECT_NAMED));
    free(time_reference);
}