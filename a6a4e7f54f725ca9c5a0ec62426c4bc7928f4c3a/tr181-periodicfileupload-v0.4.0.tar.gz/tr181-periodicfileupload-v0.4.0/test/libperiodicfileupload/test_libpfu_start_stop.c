/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <fcntl.h>
#include <unistd.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>

#include "libperiodicfileupload.h"

#include "test_libpfu_start_stop.h"

void libpfu_transfer_cb(const amxc_var_t* const data, void* const priv);

int test_setup(UNUSED void** state) {
    int retval;

    amxut_bus_setup(state);

    amxo_parser_parse_string(amxut_bus_parser(), "%config{import-dirs=[\"../output/x86_64-linux-gnu/\",\"/usr/lib/amx/modules\"];include-dirs=[\".\"];}import \"mod-dmext.so\";", amxd_dm_get_root(amxut_bus_dm()));

    amxut_dm_load_odl("../../odl/tr181-periodicfileupload_definition.odl");
    amxut_dm_load_odl("../../odl/tr181-periodicfileupload_transfer_definition.odl");

    retval = periodicfileupload_init(amxut_bus_parser());
    assert_int_equal(retval, 0);

    return 0;
}

int test_teardown(UNUSED void** state) {
    periodicfileupload_deinit();
    amxut_bus_handle_events();
    amxut_bus_teardown(state);
    return 0;
}

void test_can_start_libpfu(UNUSED void** state) {
    amxc_ts_t now;

    amxc_ts_now(&now);
    assert_int_not_equal(periodicfileupload_register_file(NULL, NULL, NULL), 0);
    assert_int_not_equal(periodicfileupload_register_file("toto", NULL, NULL), 0);
    assert_int_not_equal(periodicfileupload_register_file("toto", "toto", NULL), 0);
    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    amxut_bus_handle_events();

    assert_int_not_equal(periodicfileupload_set_interval(NULL, 0, NULL), 0);
    assert_int_not_equal(periodicfileupload_set_interval("", 0, NULL), 0);
    assert_int_not_equal(periodicfileupload_set_interval("tata", 60, NULL), 0);
    assert_int_equal(periodicfileupload_set_interval("toto", 60, &now), 0);
    amxut_bus_handle_events();

    assert_int_not_equal(periodicfileupload_stop(NULL), 0);
    assert_int_not_equal(periodicfileupload_stop(""), 0);
    assert_int_not_equal(periodicfileupload_stop("tata"), 0);
    assert_int_equal(periodicfileupload_stop("toto"), 0);
    amxut_bus_handle_events();

    assert_int_not_equal(periodicfileupload_start(NULL), 0);
    assert_int_not_equal(periodicfileupload_start(""), 0);
    assert_int_not_equal(periodicfileupload_start("tata"), 0);
    assert_int_not_equal(periodicfileupload_start("toto"), 0); // Start without profile existing PeriodicFileTransfer.Profile.1.
    amxut_bus_handle_events();

    amxut_dm_load_odl("profile.odl"); // Create profile
    assert_int_equal(periodicfileupload_start("toto"), 0);

    assert_int_equal(periodicfileupload_stop("toto"), 0);
    amxut_bus_handle_events();

    periodicfileupload_deregister_file(NULL);
    periodicfileupload_deregister_file("");
    periodicfileupload_deregister_file("tata");
    periodicfileupload_deregister_file("toto");
}

void test_libpfu_upload_timer(UNUSED void** state) {
    int fd;

    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    assert_int_equal(periodicfileupload_set_interval("toto", 60, NULL), 0);
    assert_int_equal(periodicfileupload_start("toto"), 0);
    amxut_timer_go_to_future_ms(61000);
    amxut_bus_handle_events();
    fd = open("toto", O_CREAT | O_TRUNC | O_WRONLY, 0644);
    assert_int_not_equal(fd, -1);
    assert_int_equal(write(fd, "toto", 4), 4);
    assert_int_equal(close(fd), 0);
    amxut_timer_go_to_future_ms(61000);
    amxut_bus_handle_events();
    assert_int_equal(unlink("toto"), 0);
    assert_int_equal(periodicfileupload_stop("toto"), 0);
    periodicfileupload_deregister_file("toto");
}

void libpfu_transfer_cb(const amxc_var_t* const data, UNUSED void* const priv) {
    int state = GET_UINT32(data, "State");

    check_expected(state);
    return;
}

void test_libpfu_transfer_cb(UNUSED void** state) {
    int fd;

    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    assert_int_equal(periodicfileupload_set_interval("toto", 60, NULL), 0);
    periodicfileupload_set_transfer_cb("toto", libpfu_transfer_cb, state);
    expect_value(libpfu_transfer_cb, state, pfu_state_idle);
    assert_int_equal(periodicfileupload_start("toto"), 0);
    amxut_bus_handle_events();
    fd = open("toto", O_CREAT | O_TRUNC | O_WRONLY, 0644);
    assert_int_not_equal(fd, -1);
    assert_int_equal(write(fd, "toto", 4), 4);
    assert_int_equal(close(fd), 0);
    expect_value(libpfu_transfer_cb, state, pfu_state_uploading);
    amxut_timer_go_to_future_ms(61000);
    amxut_bus_handle_events();
    assert_int_equal(unlink("toto"), 0);
    assert_int_equal(periodicfileupload_stop("toto"), 0);
    periodicfileupload_deregister_file("toto");
}

void test_libpfu_compression(UNUSED void** state) {
    int fd;
    amxd_trans_t trans;

    fd = open("toto", O_CREAT | O_TRUNC | O_WRONLY, 0644);
    assert_int_not_equal(fd, -1);
    assert_int_equal(write(fd, "toto", 4), 4);
    assert_int_equal(close(fd), 0);

    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, amxd_dm_findf(amxut_bus_dm(), "PeriodicFileTransfer.Profile.1.HTTP."));
    amxd_trans_set_cstring_t(&trans, "Compression", "GZIP");
    amxd_trans_apply(&trans, amxut_bus_dm());
    assert_int_equal(periodicfileupload_start("toto"), 0);
    amxut_bus_handle_events();
    amxd_trans_clean(&trans);
    periodicfileupload_deregister_file("toto");

    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, amxd_dm_findf(amxut_bus_dm(), "PeriodicFileTransfer.Profile.1.HTTP."));
    amxd_trans_set_cstring_t(&trans, "Compression", "Deflate");
    amxd_trans_apply(&trans, amxut_bus_dm());
    assert_int_equal(periodicfileupload_start("toto"), 0);
    amxut_bus_handle_events();
    amxd_trans_clean(&trans);
    periodicfileupload_deregister_file("toto");

    assert_int_equal(periodicfileupload_register_file("toto", "toto", "Device.PeriodicFileTransfer.Profile.1"), 0);
    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, amxd_dm_findf(amxut_bus_dm(), "PeriodicFileTransfer.Profile.1.HTTP."));
    amxd_trans_set_cstring_t(&trans, "Compression", "Compress");
    amxd_trans_apply(&trans, amxut_bus_dm());
    assert_int_equal(periodicfileupload_start("toto"), 0);
    amxut_bus_handle_events();
    amxd_trans_clean(&trans);
    periodicfileupload_deregister_file("toto");

    assert_int_equal(unlink("toto"), 0);
}