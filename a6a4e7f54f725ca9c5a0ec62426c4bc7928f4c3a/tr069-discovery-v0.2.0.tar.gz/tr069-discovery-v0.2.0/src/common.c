/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "tr069_discovery.h"

#define ME "common"

provision_type_t provision_type_from_string(const char* value) {
    if(!strcmp(value, "None")) {
        return PROVISION_NONE;
    }
    if(!strcmp(value, "DHCP")) {
        return PROVISION_DHCP;
    }
    if(!strcmp(value, "Manual")) {
        return PROVISION_MANUAL;
    }
    return -1;
}

const char* provision_type_to_string(provision_type_t value) {
    switch(value) {
    case PROVISION_NONE:
        return "None";
    case PROVISION_DHCP:
        return "DHCP";
    case PROVISION_MANUAL:
        return "Manual";
    }
    return NULL;
}

int get_string_parameter_value(const char* obj_path, const char* param_name, char* dst, size_t dst_len) {
    char param_path[PATH_BUFFER_SIZE];
    int rc = -1;

    amxc_var_t* params = NULL;
    amxc_var_t result;
    amxc_var_init(&result);

    snprintf(param_path, sizeof(param_path), "%s%s", obj_path, param_name);

    amxb_bus_ctx_t* ctx = amxb_be_who_has(obj_path);
    when_null_trace(ctx, exit, ERROR, "Failed to get context of \"%s\"", obj_path);

    rc = amxb_get(ctx, param_path, 0, &result, 5);
    when_failed_trace(rc, exit, ERROR, "Failed to get value of \"%s\", rc=%d", param_path, rc);

    params = amxc_var_get_first(amxc_var_get_first(&result));
    const char* param_value = GET_CHAR(params, param_name);

    snprintf(dst, dst_len, "%s", param_value);

    rc = 0;
exit:
    amxc_var_clean(&result);
    return rc;
}

int set_string_parameter_value(const char* obj_path, const char* param_name, const char* value) {
    int rc = -1;

    amxc_var_t values;
    amxc_var_t ret;
    amxc_var_init(&values);
    amxc_var_init(&ret);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    amxb_bus_ctx_t* ctx = amxb_be_who_has(obj_path);
    when_null_trace(ctx, exit, ERROR, "Failed to find context for \"%s\"", obj_path);

    amxc_var_add_key(cstring_t, &values, param_name, value);

    rc = amxb_set(ctx, obj_path, &values, &ret, 5);
    when_failed_trace(rc, exit, ERROR, "Failed to set \"%s%s\" to \"%s\"", obj_path, param_name, value);

exit:
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
    return rc;
}

bool dhcp_option_equals(dhcp_option_t* first, dhcp_option_t* second) {
    if((first == NULL) || (second == NULL)) {
        return first == second;
    }
    if(strcmp(first->url_of_acs, second->url_of_acs)) {
        return false;
    }
    return !strcmp(first->provisioning_code, second->provisioning_code);
}

int register_cwmp_dm(void) {
    int rc = -1;

    amxc_var_for_each(proxy_object, GET_ARG(amxrt_get_config(), "proxy-object")) {
        const char* proxy = amxc_var_key(proxy_object);
        const char* real = amxc_var_constcast(cstring_t, proxy_object);
        SAH_TRACEZ_INFO(ME, "Registering '%s' as '%s'", proxy, real);

        amxb_bus_ctx_t* ctx = amxb_be_who_has("ProxyManager");
        when_null_trace(ctx, exit, WARNING, "Cannot register CWMP model: cannot obtain bus ctx for 'ProxyManager'");

        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "proxy", proxy);
        amxc_var_add_key(cstring_t, &parameters, "real", real);

        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_call(ctx, "ProxyManager.", "register", &parameters, &ret, 5);

        amxc_var_clean(&ret);
        amxc_var_clean(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot register proxy '%s' -> '%s', got %d", proxy, real, status);
    }

    rc = 0;
exit:
    return rc;
}


int deregister_cwmp_dm(void) {
    int rc = -1;

    amxc_var_for_each(proxy_object, GET_ARG(amxrt_get_config(), "proxy-object")) {
        const char* proxy = amxc_var_key(proxy_object);
        SAH_TRACEZ_INFO(ME, "Deregistering '%s'", proxy);

        amxb_bus_ctx_t* ctx = amxb_be_who_has("ProxyManager");
        when_null_trace(ctx, exit, WARNING, "Cannot deregister CWMP model: cannot obtain bus ctx for 'ProxyManager'");

        amxc_var_t parameters;
        amxc_var_init(&parameters);
        amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, &parameters, "proxy", proxy);

        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_call(ctx, "ProxyManager.", "unregister", &parameters, &ret, 5);

        amxc_var_clean(&ret);
        amxc_var_clean(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot unregister proxy '%s', got %d", proxy, status);
    }

    rc = 0;
exit:
    return rc;
}


