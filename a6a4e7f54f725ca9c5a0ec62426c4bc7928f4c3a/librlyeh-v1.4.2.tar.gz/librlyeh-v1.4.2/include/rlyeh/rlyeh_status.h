/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _RLYEH_ERROR_CODE_H_
#define _RLYEH_ERROR_CODE_H_

#ifdef __cplusplus
extern "C"
{
#endif

// Define some specific status that are used do to a rlyeh_copy(...) and rlyeh_remove(...)
typedef enum _rlyeh_status {
    RLYEH_NO_ERROR = 0,
    RLYEH_IMAGE_ALREADY_EXISTS,
    RLYEH_ERROR_INVALID_ARGUMENTS,
    RLYEH_ERROR_CURL_OPERATION_TIMEDOUT,
    RLYEH_ERROR_CURL_COULDNT_RESOLVE_HOST,
    RLYEH_ERROR_DOWNLOAD_FAILED,
    RLYEH_ERROR_DISK_SPACE,
    RLYEH_ERROR_SIZE_CHECK,
    RLYEH_ERROR_INVALID_SIGNATURE,
    RLYEH_ERROR_INVALID_CONTENT,
    RLYEH_ERROR_CERTIFICATE_CHECK_FAILED,
    RLYEH_ERROR_CANNOT_CREATE_INDEX_MANIFEST,
    RLYEH_ERROR_CANNOT_CREATE_OCI_LAYOUT_FILE,
    RLYEH_ERROR_CANNOT_PATCH_MEDIATYPE,
    RLYEH_ERROR_UNKNOWN_ERROR,
    rlyeh_status_last
} rlyeh_status_t;

const char* rlyeh_status_to_string(rlyeh_status_t status);


#ifdef __cplusplus
}
#endif

#endif // _RLYEH_ERROR_CODE_H_
