/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "hostsquery/query.h"
#include "zone/zone.h"
#include "zone/dm_zone.h"
#include "dm_relay.h"
#include "dm_common.h"
#include "netdevname.h"
#include "internal_zone.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

static zone_ipaddr_t* zone_ipaddr_new(void) {
    zone_ipaddr_t* ipaddr = NULL;
    ipaddr = (zone_ipaddr_t*) calloc(1, sizeof(zone_ipaddr_t));
    when_null(ipaddr, exit);
    amxc_llist_it_init(&ipaddr->it);
exit:
    return ipaddr;
}

static void add_ipaddr_to_list(amxc_llist_t* list, const char* ip, const char* hostname, const char* domain, const char* iface) {
    zone_ipaddr_t* ipaddr = NULL;
    when_null(list, exit);
    when_str_empty(ip, exit);
    when_str_empty(hostname, exit);
    when_str_empty(iface, exit);
    ipaddr = zone_ipaddr_new();
    when_null(ipaddr, exit);
    ipaddr->ip = strdup(ip);
    ipaddr->hostname = strdup(hostname);
    if(domain != NULL) {
        ipaddr->domain = strdup(domain);
    }
    ipaddr->iface = strdup(iface);
    amxc_llist_append(list, &ipaddr->it);
exit:
    return;
}

static void zone_ipaddr_clean(zone_ipaddr_t* ipaddr) {
    when_null(ipaddr, exit);
    FREE(ipaddr->ip);
    FREE(ipaddr->hostname);
    FREE(ipaddr->domain);
    FREE(ipaddr->iface);
exit:
    return;
}

static void ipaddr_delete(amxc_llist_it_t* it) {
    zone_ipaddr_t* ipaddr = NULL;
    when_null(it, exit);
    ipaddr = amxc_container_of(it, zone_ipaddr_t, it);
    when_null(ipaddr, exit);
    zone_ipaddr_clean(ipaddr);
    free(ipaddr);
exit:
    return;
}

zone_host_t* zone_host_new(amxd_object_t* obj) {
    zone_host_t* zone_host = NULL;
    when_null(obj, exit);
    zone_host = (zone_host_t*) calloc(1, sizeof(zone_host_t));
    when_null(zone_host, exit);

    amxc_llist_init(&zone_host->list_hostnames);
    amxc_llist_init(&zone_host->list_ipaddr);

    zone_host->name = amxd_object_get_name(obj, AMXD_OBJECT_NAMED);
    zone_host->obj = obj;
    obj->priv = zone_host;
exit:
    return zone_host;
}

static int zone_host_clean(zone_host_t* zone_host) {
    int rv = -1;

    when_null(zone_host, exit);
    hosts_closeQuery(zone_host->query_hosts);
    FREE(zone_host->query_hosts);
    amxc_llist_clean(&zone_host->list_hostnames, amxc_string_list_it_free);
    amxc_llist_clean(&zone_host->list_ipaddr, ipaddr_delete);
    rv = 0;
exit:
    return rv;
}

int zone_host_delete(zone_host_t** zone_host) {
    int rv = -1;
    amxd_object_t* obj = NULL;

    when_null(zone_host, exit);
    when_null(*zone_host, exit);
    zone_host_clean(*zone_host);
    obj = (*zone_host)->obj;
    if(obj != NULL) {
        obj->priv = NULL;
    }
    FREE(*zone_host);
    rv = 0;
exit:
    return rv;
}

zone_t* zone_new(amxd_object_t* obj) {
    zone_t* zone = NULL;
    when_null(obj, exit);
    zone = (zone_t*) calloc(1, sizeof(zone_t));
    when_null(zone, exit);

    zone->name = amxd_object_get_name(obj, AMXD_OBJECT_NAMED);
    zone->obj = obj;
    obj->priv = zone;
exit:
    return zone;
}

static int zone_clean(zone_t* zone) {
    int rv = -1;

    when_null(zone, exit);
    CLOSE_QUERY(zone->query_netdevname);
    FREE(zone->netdevname);
    FREE(zone->domain);
    rv = 0;
exit:
    return rv;
}

int zone_delete(zone_t** zone) {
    int rv = -1;
    amxd_object_t* obj = NULL;

    when_null(zone, exit);
    when_null(*zone, exit);
    zone_clean(*zone);
    obj = (*zone)->obj;
    if(obj != NULL) {
        obj->priv = NULL;
    }
    FREE(*zone);
    rv = 0;
exit:
    return rv;
}

static amxc_set_t* aggregate_list(amxc_llist_t* list) {
    amxc_set_t* set = NULL;

    when_null(list, exit);

    amxc_llist_for_each(it, list) {
        amxc_string_t* it_str = (amxc_string_t*) amxc_llist_it_get_data(it, amxc_string_t, it);
        const char* element = amxc_string_get(it_str, 0);
        if(STRING_EMPTY(element)) {
            continue;
        }

        if(set == NULL) {
            amxc_set_new(&set, false);
        }

        amxc_set_add_flag(set, element);
    }
exit:
    return set;
}

static void ipaddr_list_copy(amxc_llist_t* dest_list_address, amxc_llist_t* src_list_address, bool filter) {
    when_null(dest_list_address, exit);
    when_null(src_list_address, exit);
    amxc_llist_clean(dest_list_address, ipaddr_delete);
    amxc_llist_init(dest_list_address);
    amxc_llist_for_each(it, src_list_address) {
        zone_ipaddr_t* ipaddr = (zone_ipaddr_t*) amxc_llist_it_get_data(it, zone_ipaddr_t, it);
        if(ipaddr == NULL) {
            continue;
        }
        if(filter && ipaddr->to_delete) {
            continue;
        }
        add_ipaddr_to_list(dest_list_address, ipaddr->ip, ipaddr->hostname, ipaddr->domain, ipaddr->iface);
    }
exit:
    return;
}

static void ipaddr_list_clean_deleted(amxc_llist_t* list_address) {
    amxc_llist_t tmp_list;

    amxc_llist_init(&tmp_list);

    when_null(list_address, exit);

    ipaddr_list_copy(&tmp_list, list_address, true);
    ipaddr_list_copy(list_address, &tmp_list, false);
exit:
    amxc_llist_clean(&tmp_list, ipaddr_delete);
    return;
}

static amxd_object_t* zone_from_host(amxd_object_t* zone_host_obj) {
    amxd_object_t* zone_obj = NULL;

    when_null(zone_host_obj, exit);

    zone_obj = amxd_object_findf(zone_host_obj, ".^.^");
exit:
    return zone_obj;
}

static bool zone_host_adresses_remove(amxc_llist_t* list_address) {
    bool rv = false;
    when_null_status(list_address, exit, rv = true);

    amxc_llist_for_each(it, list_address) {
        zone_ipaddr_t* ipaddr = (zone_ipaddr_t*) amxc_llist_it_get_data(it, zone_ipaddr_t, it);
        if(ipaddr == NULL) {
            continue;
        }
        if(STRING_EMPTY(ipaddr->ip)) {
            continue;
        }
        if(STRING_EMPTY(ipaddr->hostname)) {
            continue;
        }
        if(STRING_EMPTY(ipaddr->iface)) {
            continue;
        }

        rv |= internal_zone_remove_ipaddr(ipaddr->iface, ipaddr->hostname, ipaddr->domain, ipaddr->ip);
        ipaddr->to_delete = true;
    }
exit:
    ipaddr_list_clean_deleted(list_address);
    return rv;
}

static bool zone_host_remove(amxd_object_t* zone_host_obj, bool cleanup) {
    bool rv = false;
    zone_host_t* zone_host = NULL;

    when_null(zone_host_obj, exit);
    when_null(zone_host_obj->priv, exit);
    zone_host = (zone_host_t*) zone_host_obj->priv;
    when_null(zone_host, exit);
    when_false_status(zone_host->is_enabled, exit, rv = true);

    rv = zone_host_adresses_remove(&zone_host->list_ipaddr);

exit:
    if(zone_host != NULL) {
        zone_host->is_enabled = false;
        if(cleanup) {
            zone_host_delete(&zone_host);
        }
    }
    return rv;
}

static bool zone_remove(amxd_object_t* zone_obj, bool cleanup) {
    amxd_object_t* templ = NULL;
    bool rv = false;

    when_null(zone_obj, exit);
    templ = amxd_object_findf(zone_obj, ".%s.", "Host");

    when_null(templ, exit);

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* host_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        rv &= zone_host_remove(host_obj, cleanup);
    }

exit:
    return rv;
}

static void evaluate_disabled_zone(amxd_object_t* zone_obj) {
    zone_t* zone = NULL;
    amxd_object_t* templ = NULL;
    bool all_disabled = true;

    when_null(zone_obj, exit);
    templ = amxd_object_findf(zone_obj, ".%s.", "Host");
    when_null(templ, exit);
    zone = (zone_t*) zone_obj->priv;
    when_null(zone, exit);

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* host_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        zone_host_t* zone_host = (zone_host_t*) host_obj->priv;
        if(zone_host == NULL) {
            continue;
        }
        if(zone_host->is_enabled) {
            all_disabled = false;
        }
    }

    if(all_disabled && zone->is_enabled) {
        zone->is_enabled = false;
    }
exit:
    return;
}

void zone_host_disable(zone_host_t* zone_host, bool cleanup) {
    amxd_object_t* zone_obj = NULL;

    when_null(zone_host, exit);
    zone_obj = zone_from_host(zone_host->obj);

    if(zone_host->is_enabled) {
        zone_host_remove(zone_host->obj, cleanup);
        if(!cleanup) {
            zone_host->is_enabled = false;
        }
    } else if(cleanup) {
        zone_host_delete(&zone_host);
    }

    evaluate_disabled_zone(zone_obj);
exit:
    return;
}

void zone_disable(zone_t* zone, bool cleanup) {
    when_null(zone, exit);
    if(zone->is_enabled) {
        zone_remove(zone->obj, cleanup);
        if(!cleanup) {
            zone->is_enabled = false;
        }
    }
    if(cleanup) {
        zone_delete(&zone);
    }
exit:
    return;
}

static int zone_get_current_time(amxc_var_t* var) {
    amxc_string_t* str = NULL;
    amxc_ts_t ts;
    int rv = -1;

    amxc_string_new(&str, 0);

    when_null_trace(var, exit, ERROR, "Output variant is not initialised.");

    when_failed_trace(amxc_ts_now(&ts), exit, ERROR, "Failed to get the current time.");
    amxc_string_setf(str, "0000-00-00T00:00:00.000000Z");
    amxc_ts_format_precision(&ts, str->buffer, amxc_string_buffer_length(str), 6);

    amxc_var_set(cstring_t, var, str->buffer);

    rv = 0;

exit:
    amxc_string_delete(&str);
    return rv;
}

static void zone_host_last_update(amxd_object_t* obj) {
    amxc_var_t* curr_time = NULL;
    amxd_trans_t* trans = NULL;
    int ret_value = -1;

    when_null(obj, exit);

    amxc_var_new(&curr_time);
    ret_value = zone_get_current_time(curr_time);
    when_failed(ret_value, exit);

    when_failed(amxd_trans_new(&trans), exit);
    amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    when_failed(amxd_trans_select_object(trans, obj), exit);
    amxd_trans_set_param(trans, "LastUpdate", curr_time);
    when_failed(amxd_trans_apply(trans, get_dm()), exit);

exit:
    amxc_var_delete(&curr_time);
    amxd_trans_delete(&trans);
    return;
}


static bool zone_host_adresses_add(const char* iface, const char* host, const char* domain, amxc_llist_t* list_string_address, amxc_llist_t* list_ipaddr) {
    bool rv = false;
    amxc_set_t* set_addresses = NULL;

    when_str_empty(iface, exit);
    when_str_empty(host, exit);
    when_null(list_string_address, exit);
    when_false(amxc_llist_size(list_string_address) > 0, exit);

    set_addresses = aggregate_list(list_string_address);
    when_null_trace(set_addresses, exit, ERROR, "Unexpected error. Failed to add hostname '%s'", host);

    amxc_set_iterate(address, set_addresses) {
        const char* ipaddr = address->flag;

        if(STRING_EMPTY(ipaddr)) {
            continue;
        }

        rv |= internal_zone_add_ipaddr(iface, host, domain, ipaddr);
        if(internal_zone_find(host, iface) == NULL) {
            continue;
        }
        add_ipaddr_to_list(list_ipaddr, ipaddr, host, domain, iface);
    }
exit:
    amxc_set_delete(&set_addresses);
    return rv;
}

static bool zone_host_add(amxd_object_t* zone_host_obj) {
    amxd_object_t* zone_obj = zone_from_host(zone_host_obj);
    const char* domain = NULL;
    const char* iface = NULL;
    bool rv = false;
    zone_t* zone = NULL;
    zone_host_t* zone_host = NULL;
    amxc_set_t* set_hostnames = NULL;
    hosts_query_t* query = NULL;

    when_null(zone_obj, exit);
    when_null(zone_host_obj, exit);
    when_null(zone_obj->priv, exit);
    when_null(zone_host_obj->priv, exit);
    zone = (zone_t*) zone_obj->priv;
    zone_host = (zone_host_t*) zone_host_obj->priv;
    when_false(zone_host->enable, exit);
    domain = zone->domain;
    iface = zone->netdevname;
    query = zone_host->query_hosts;

    when_str_empty_trace(iface, exit, ERROR, "Missing interface. Unexpected error. Host[%s]", zone_host->name);
    when_null_trace(query, exit, ERROR, "Hosts query is NULL. Unexpected behavior. Host[%s]", zone_host->name);
    when_null_trace(query->impl, exit, ERROR, "Unexpected error. Host[%s]", zone_host->name);
    when_false_trace(amxc_llist_size(&zone_host->list_hostnames) > 0, exit, ERROR, "No hostnames to be added. Host[%s]", zone_host->name);

    set_hostnames = aggregate_list(&zone_host->list_hostnames);
    when_null_trace(set_hostnames, exit, ERROR, "Unexpected error.");

    amxc_set_iterate(hostname, set_hostnames) {
        const char* host = hostname->flag;

        if(STRING_EMPTY(host)) {
            continue;
        }

        rv |= zone_host_adresses_add(iface, host, domain, &query->impl->ipv4_addresses, &zone_host->list_ipaddr);
        rv |= zone_host_adresses_add(iface, host, domain, &query->impl->ipv6_addresses, &zone_host->list_ipaddr);
    }

exit:
    if((zone_host != NULL) && rv) {
        zone_host->is_enabled = true;
        zone_host_last_update(zone_host->obj);
    }
    amxc_set_delete(&set_hostnames);
    return rv;
}

static bool zone_add(amxd_object_t* zone_obj) {
    amxd_object_t* templ = NULL;
    bool rv = false;
    zone_t* zone = NULL;

    when_null(zone_obj, exit);
    when_null(zone_obj->priv, exit);
    zone = (zone_t*) zone_obj->priv;
    when_false(zone->enable, exit);

    templ = amxd_object_findf(zone_obj, ".%s.", "Host");

    when_null_trace(templ, exit, INFO, "Zone %s is missing Host sub-object", zone->name);
    when_str_empty_trace(zone->netdevname, exit, ERROR, "Missing interface. Unexpected error. Zone[%s]", zone->name);

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* host_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        rv |= zone_host_add(host_obj);
    }

exit:
    if((zone != NULL) && rv) {
        zone->is_enabled = true;
    }
    return rv;
}

static void evaluate_enabled_zone(amxd_object_t* zone_obj) {
    zone_t* zone = NULL;
    amxd_object_t* templ = NULL;
    bool all_enabled = true;

    when_null(zone_obj, exit);
    templ = amxd_object_findf(zone_obj, ".%s.", "Host");
    when_null(templ, exit);
    zone = (zone_t*) zone_obj->priv;
    when_null(zone, exit);

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* host_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        zone_host_t* zone_host = (zone_host_t*) host_obj->priv;
        if(zone_host == NULL) {
            continue;
        }
        if(!zone_host->is_enabled) {
            all_enabled = false;
        }
    }

    if(all_enabled && !zone->is_enabled) {
        zone->is_enabled = true;
    }
exit:
    return;
}

bool zone_host_enable(zone_host_t* zone_host) {
    zone_t* zone = NULL;
    amxd_object_t* zone_host_obj = NULL;
    amxd_object_t* zone_obj = NULL;

    when_null(zone_host, exit);
    when_true_trace(zone_host->is_enabled, exit, INFO, "%s is already enabled", zone_host->name);
    when_false(zone_host->enable, exit);

    zone_host_obj = zone_host->obj;
    when_null_trace(zone_host_obj, exit, INFO, "Zone.{}.Host.{}. object is NULL");
    zone_obj = zone_from_host(zone_host_obj);
    when_null(zone_obj->priv, exit);
    zone = (zone_t*) zone_obj->priv;

    if(STRING_EMPTY(zone->netdevname)) {
        SAH_TRACEZ_INFO(ME, "%s is waiting for query result", zone->name);
        zone_host->is_enabled = false; // for sanity?
        goto exit;
    }

    zone_host_add(zone_host_obj);
    evaluate_enabled_zone(zone_obj);
exit:
    return zone_host->is_enabled;
}


bool zone_enable(zone_t* zone) {
    when_null(zone, exit);
    when_true_trace(zone->is_enabled, exit, INFO, "%s is already enabled", zone->name);
    when_false(zone->enable, exit);

    if(STRING_EMPTY(zone->netdevname)) {
        SAH_TRACEZ_INFO(ME, "%s is waiting for query result", zone->name);
        zone->is_enabled = false; // for sanity?
        goto exit;
    }

    zone_add(zone->obj);

exit:
    return zone->is_enabled;
}