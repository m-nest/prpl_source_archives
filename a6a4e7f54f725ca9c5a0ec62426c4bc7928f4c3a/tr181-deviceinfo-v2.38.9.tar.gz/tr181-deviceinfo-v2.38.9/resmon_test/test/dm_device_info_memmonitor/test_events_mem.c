/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <math.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>
#include "deviceinfo.h"
#include "common_functions.h"
#include "mock_res_functions.h"
#include "test_main_mem.h"

static bool test_verify_data(const amxc_var_t* data, const char* field, const char* value);
static void check_mem_event(UNUSED const char* const sig_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv);
int test_setup_mem(void** state) {
    amxut_bus_setup(state);
    resolver_add_all_functions();

    amxd_dm_t* dm = amxut_bus_dm();
    amxo_parser_t* parser = amxut_bus_parser();
    assert_non_null(dm);
    assert_non_null(parser);

    amxd_object_t* root = amxd_dm_get_root(dm);
    assert_non_null(root);

    test_setup_parse_odl(ODL_DEFS);
    test_setup_parse_odl(ODL_MOCK_MAIN);
    test_setup_parse_odl(ODL_DEFAULTS);

    _deviceinfo_main(AMXO_START, dm, parser);
    handle_events();
    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);

    return 0;
}

void test_mem_change_enable(UNUSED void** state) {
    _amxut_dm_param_set(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "Enable", 1);
    _amxut_dm_param_equals(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "Enable", 1);
    amxut_timer_go_to_future_ms(5 * 1000);

}
void test_mem_change_critical_log_enable(UNUSED void** state) {
    _amxut_dm_param_set(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "EnableCriticalLog", true);
    _amxut_dm_param_equals(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "EnableCriticalLog", true);
}

void test_mem_change_polling_interval(UNUSED void** state) {
    _amxut_dm_param_set(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "PollingInterval", 5);
    _amxut_dm_param_equals(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "PollingInterval", 5);

}
void test_mem_change_fall_threshold_wrong(UNUSED void** state) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object = amxd_dm_findf(dm, "DeviceInfo.MemoryStatus.MemoryMonitor.");
    amxd_object_set_value(uint32_t, object, "CriticalFallThreshold", 90);
    uint32_t ret = amxd_object_get_value(uint32_t, object, "CriticalFallThreshold", NULL);
    assert_int_not_equal(ret, 90);
}
void test_mem_change_fall_threshold(UNUSED void** state) {
    _amxut_dm_param_set(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "CriticalFallThreshold", 50);
    _amxut_dm_param_equals(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "CriticalFallThreshold", 50);
}

void test_mem_change_rise_threshold(UNUSED void** state) {
    _amxut_dm_param_set(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "CriticalRiseThreshold", 60);
    _amxut_dm_param_equals(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "CriticalRiseThreshold", 60);
    amxut_timer_go_to_future_ms(25 * 1000);
}
void test_mem_check_utilization(UNUSED void** state) {
    amxut_timer_go_to_future_ms(25 * 1000);
    assert_non_null(memory_timer);
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object = amxd_dm_findf(dm, "DeviceInfo.MemoryStatus.MemoryMonitor.");
    uint32_t ret = amxd_object_get_value(uint32_t, object, "MemUtilization", NULL);
    assert_int_equal(ret, 75);
}

void test_mem_change_disable(UNUSED void** state) {
    _amxut_dm_param_set(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "Enable", 0);
    _amxut_dm_param_equals(bool, "DeviceInfo.MemoryStatus.MemoryMonitor.", "Enable", 0);
    amxut_timer_go_to_future_ms(5 * 1000);
}

void check_fall_threshold_used(void) {
    assert_int_equal(mmon.fall_threshold, 50);
}
void check_rise_threshold_used(void) {
    assert_int_equal(mmon.rise_threshold, 60);
}
void check_polling_interval_used(void) {
    assert_int_equal(mmon.polling_interval, 5);
}

void test_subscribe_mem_event(UNUSED void** state) {
    int retval = 0;
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* object = amxd_dm_findf(dm, "DeviceInfo.MemoryStatus.MemoryMonitor.");
    amxb_bus_ctx_t* bus_ctx = NULL;
    bus_ctx = amxut_bus_ctx();
    assert_non_null(bus_ctx);
    retval = amxb_subscribe(bus_ctx, "DeviceInfo.MemoryStatus.MemoryMonitor.", "(notification == 'MemoryCriticalState!')", check_mem_event, NULL);
    assert_int_equal(retval, 0);
    assert_non_null(object);
}

void test_mem_check_timer_deleted_utilization_cleared(UNUSED void** state) {
    assert_null(memory_timer);
    _amxut_dm_param_equals(uint32_t, "DeviceInfo.MemoryStatus.MemoryMonitor.", "MemUtilization", 0);
}

static void check_mem_event(UNUSED const char* const sig_name,
                            const amxc_var_t* const data,
                            UNUSED void* const priv) {
    amxc_var_dump(data, STDOUT_FILENO);

    assert_true(test_verify_data(data, "notification", "MemoryCriticalState!"));
    assert_true(test_verify_data(data, "path", "DeviceInfo.MemoryStatus.MemoryMonitor."));
    assert_true(test_verify_data(data, "object", "DeviceInfo.MemoryStatus.MemoryMonitor."));
    assert_true(test_verify_data(data, "eobject", "DeviceInfo.MemoryStatus.MemoryMonitor."));
    assert_true(test_verify_data(data, "MemUtilization", "75"));
    check_fall_threshold_used();
    check_rise_threshold_used();
    check_polling_interval_used();
}

static bool test_verify_data(const amxc_var_t* data, const char* field, const char* value) {
    bool rv = false;
    char* field_value = NULL;
    amxc_var_t* field_data = GETP_ARG(data, field);

    printf("Verify table data: check field [%s] contains [%s]\n", field, value);
    fflush(stdout);
    assert_non_null(field_data);

    field_value = amxc_var_dyncast(cstring_t, field_data);
    assert_non_null(field_data);

    rv = (strcmp(field_value, value) == 0);

    free(field_value);
    return rv;
}

int test_teardown_mem(void** state) {
    _deviceinfo_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser());
    amxut_bus_teardown(state);
    return 0;
}
