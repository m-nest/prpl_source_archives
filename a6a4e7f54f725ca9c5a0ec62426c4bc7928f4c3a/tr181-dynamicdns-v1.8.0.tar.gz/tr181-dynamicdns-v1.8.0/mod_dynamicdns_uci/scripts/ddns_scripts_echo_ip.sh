#!/bin/sh
TMP_DDNS_IP="/tmp/ddns_ip"

IP=`cat $TMP_DDNS_IP 2> /dev/null || true`
echo $IP