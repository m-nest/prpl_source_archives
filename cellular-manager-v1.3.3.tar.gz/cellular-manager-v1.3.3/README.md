[TOC]

# tr181-cellular

This is an Ambiorix plug-in for a TR-181 compatible Cellular manager.

## Building

### Prerequisites

- [libamxc](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxc)
- [libamxp](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxp)
- [libamxj](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxj)
- [libamxd](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxd)
- [libamxb](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxb)
- [libamxo](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxo)
- [libamxm](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxm)
- [libsahtrace](https://gitlab.com/soft.at.home/network/libsahtrace)
- [libnetmodel](https://gitlab.com/prpl-foundation/components/core/libraries/libnetmodel)

You can install these libraries from source or using their debian packages. To install them from source, refer to their corresponding repositories for more information.
To install them using debian packages, you can run

```
bash
sudo apt update
sudo apt install sah-lib-sahtrace-dev libamxc libamxp libamxj libamxd libamxb libamxo libamxm libnetmodel
```

To communicate with the cellular modem hardware via libmm (ModemManager) you will need to enable the following options

- The latest (>=1.22) ModemManger. Make sure that the following options are enabled in your configuration:

```
CONFIG_MODEMMANAGER_WITH_MBIM=y
CONFIG_MODEMMANAGER_WITH_QMI=y
CONFIG_MODEMMANAGER_WITH_QRTR=y
```

- [mod_cellular-libmm](https://gitlab.com/prpl-foundation/components/core/modules/mod_cellular-libmm)

Make sure that you enable in your configuration

```
CONFIG_PACKAGE_mod-cellular-libmm=y
```

- [netmodel-cellular](https://gitlab.com/prpl-foundation/components/netmodel/clients/netmodel-cellular)

To communicate with NetModel make sure that you enable in your configuration

```
CONFIG_PACKAGE_netmodel-cellular=y
```

- Linux Kernel drivers

Most probably you will use some USB cellular modem - make sure that the following options are enabled in your configuration:

```
CONFIG_PACKAGE_usb-modeswitch=y
CONFIG_PACKAGE_kmod-usb-serial=y
CONFIG_PACKAGE_kmod-usb-serial-wwan=y
CONFIG_PACKAGE_kmod-usb-serial-option=y
CONFIG_PACKAGE_kmod-usb-net=y
CONFIG_PACKAGE_kmod-usb-net-qmi-wwan=y
CONFIG_PACKAGE_kmod-usb-net-cdc-mbim=y
CONFIG_PACKAGE_wwan=y
```

Look for proper kmod-usb-net-<modem vendor> for your particular modem.

For example, for Huawei E3276 USB 4G modem enable
```
CONFIG_PACKAGE_kmod-usb-net-huawei-cdc-ncm
```

### compile + install
```
# compile
make

# install
sudo make install
```

## Runtime

### Quick connectivity test

Supposing that you have a USB 4G(LTE) modem (f.e Huawei E3276 USB dongle) plugged into your system with SIM card with pin disabled (for simpilicity).
We suppose that IP settings are assigned internally by the Cellular network (aka 3GPP-NAS or PCO method)

Wait until ModemManager discovers modem and connect it to the network:

```
root@prplOS:/# mmcli -L
    /org/freedesktop/ModemManager1/Modem/0 [huawei] E3276
root@prplOS:/# mmcli -m 0
  --------------------------------
  General  |                 path: /org/freedesktop/ModemManager1/Modem/0
           |            device id: 4c7b22b31701353bfca18df65fb56dea84e85901
  --------------------------------
  Hardware |         manufacturer: huawei
           |                model: E3276
           |    firmware revision: 21.263.30.02.103
           |            supported: gsm-umts
           |              current: gsm-umts
           |         equipment id: 863781016084494
  --------------------------------
  System   |               device: /sys/devices/platform/soc/8cf8800.usb3/8c00000.dwc3/xhci-hcd.1.auto/usb3/3-1
           |              physdev: /sys/devices/platform/soc/8cf8800.usb3/8c00000.dwc3/xhci-hcd.1.auto/usb3/3-1
           |              drivers: option1, huawei_cdc_ncm
           |               plugin: huawei
           |         primary port: cdc-wdm0
           |                ports: cdc-wdm0 (at), ttyUSB0 (at), ttyUSB1 (at), wwan0 (net)
  --------------------------------
  Status   |       unlock retries: sim-pin (3), sim-puk (10), sim-pin2 (3), sim-puk2 (10)
           |                state: disabled
           |          power state: on
  --------------------------------
  Modes    |            supported: allowed: 2g; preferred: none
           |                       allowed: 3g; preferred: none
           |                       allowed: 4g; preferred: none
           |                       allowed: 2g, 3g, 4g; preferred: none
           |              current: allowed: 4g; preferred: none
  --------------------------------
  IP       |            supported: ipv4
  --------------------------------
  3GPP     |                 imei: 863781016084494
  --------------------------------
  3GPP EPS | ue mode of operation: csps-2
  --------------------------------
  SIM      |     primary sim path: /org/freedesktop/ModemManager1/SIM/0

root@prplOS:/# mmcli -i 0
  -------------------------------
  General    |              path: /org/freedesktop/ModemManager1/SIM/0
  -------------------------------
  Properties |            active: yes
             |              imsi: 206102300806160
             |             iccid: 89320299220208006010
             |       operator id: 20610
             |     operator name: Orange B
             |              gid1: FFFFFFFF
             |              gid2: FFFFFFFF

```

NOTE:
To disable PIN check run `mmcli --pin=<pin code> --disable-pin`


```
root@prplOS:/# mmcli -m 0 --simple-connect="apn=<apn_name_of_your_operator>"
successfully connected the modem
root@prplOS:/# mmcli -b 0
  ---------------------------------
  General            |        path: /org/freedesktop/ModemManager1/Bearer/0
                     |        type: default
  ---------------------------------
  Status             |   connected: yes
                     |   suspended: no
                     | multiplexed: no
                     |   interface: wwan0
                     |  ip timeout: 20
  ---------------------------------
  Properties         |         apn: orangedefault
                     |     roaming: allowed
  ---------------------------------
  IPv4 configuration |      method: static
                     |     address: 10.78.139.46
                     |      prefix: 30
                     |     gateway: 10.78.139.45
                     |         dns: 212.224.129.90, 212.224.129.94
  ---------------------------------
  Statistics         |  start date: 2024-03-21T14:53:19Z
                     |    attempts: 1
root@prplOS:/#

```

## module configuration

>>>
Most of the module configurations are applied only at start of this plugin. Keep in mind the reboot persistency file located at `/etc/config/cellular-manager/odl/cellular-manager.odl`.
>>>

### Cellular Controller

By default `mod-cellular-libmm` is used.

The Cellular controller is configurable in ODL:

```
%populate {
    object 'Cellular' {
            parameter 'CellularController' = "mod-cellular-libmm";
    }
}
```

## Configuration example

Supposing that we have single cellular modem installed and we want to make it default WAN interface.
Make sure that the following configuration is applied to your system:

```
1) cellular-manager_defaults.odl

root@prplOS:/# cat /etc/amx/cellular-manager/defaults.d/cellular-manager_defauls.odl
%populate {
    object Cellular.Interface {
        instance add (Alias = "CELLULAR0", Name = "wwan0") {
            parameter Enable = "true";
            object USIM {
            }
            object Bearer {
            }
        }
    }
    object Cellular.AccessPoint {
        instance add (Alias = "AP0") {
            parameter APN = "<apn_of_your_operator>";
            parameter Enable = "true";
            parameter Interface = "Device.Cellular.Interface.1.";
        }
    }
}
root@prplOS:/#

2) cellular.odl

root@prplOS:/# cat /etc/amx/netmodel/mibs/cellular.odl
/*expr: cellular */
%define
{
    /**
     * MIB is loaded on all network devices that have (or had) an Cellular layer
     *
     * All devices matching expression: "cellular" are extended with this MIB
     *
     * @version 1.0
     */
    mib cellular {
        /**
         * maps TR181 "UpstreamMaxBitRate"
         * @version 1.0
         */
        uint32 UpstreamMaxBitRateEnabled;

        /**
         * maps TR181 "DownstreamMaxBitRate"
         * @version 1.0
         */
        uint32 DownstreamMaxBitRateEnabled;

        /**
        * maps TR181 "IPAddress"
        * @version 1.0
        */
        string IPAddress;

        /**
        * maps TR181 "GatewayIPAddress"
        * @version 1.0
        */
        string GatewayIPAddress;

        /**
        * maps TR181 "SubnetMask"
        * @version 1.0
        */
        string SubnetMask;

        /**
        * maps TR181 "DNSServers"
        * @version 1.0
        */
        string DNSServers;

        /**
         * maps TR181 "Upstream"
         * @version 1.0
         */
        bool Upstream;
    }
}
root@prplOS:/#

3) Add Ethernet.Link instance corresponding to wwan interface

 > Ethernet.Link.+{Alias="wwan", Enable = 1, LowerLayers = "Device.Cellular.Interface.1.", Name = "wwan0" }
Ethernet.Link.6.
Ethernet.Link.6.Alias="wwan"
Ethernet.Link.6.Name="wwan0"

root - ubus: - [ubus-cli] (0)
 > Ethernet.Link.wwan.?
Ethernet.Link.6.
Ethernet.Link.6.Alias="wwan"
Ethernet.Link.6.Enable=1
Ethernet.Link.6.FlowControl=0
Ethernet.Link.6.LastChange=47
Ethernet.Link.6.LowerLayers="Device.Cellular.Interface.1."
Ethernet.Link.6.MACAddress="0c:5b:8f:27:9a:64"
Ethernet.Link.6.Name="wwan0"
Ethernet.Link.6.PriorityTagging=0
Ethernet.Link.6.Status="Unknown"
Ethernet.Link.6.Stats.
Ethernet.Link.6.Stats.BroadcastPacketsReceived=0
Ethernet.Link.6.Stats.BroadcastPacketsSent=0
Ethernet.Link.6.Stats.BytesReceived=63848
Ethernet.Link.6.Stats.BytesSent=0
Ethernet.Link.6.Stats.DiscardPacketsReceived=0
Ethernet.Link.6.Stats.DiscardPacketsSent=0
Ethernet.Link.6.Stats.ErrorsReceived=0
Ethernet.Link.6.Stats.ErrorsSent=0
Ethernet.Link.6.Stats.MulticastPacketsReceived=0
Ethernet.Link.6.Stats.MulticastPacketsSent=0
Ethernet.Link.6.Stats.PacketsReceived=1388
Ethernet.Link.6.Stats.PacketsSent=0
Ethernet.Link.6.Stats.UnicastPacketsReceived=0
Ethernet.Link.6.Stats.UnicastPacketsSent=0
Ethernet.Link.6.Stats.UnknownProtoPacketsReceived=0

root - ubus: - [ubus-cli] (0)
 >

3) Add IP.Interface.wwan instance corresponding to wwan interface
IP.Interface.+{Alias="wwan", Enable = 1, LowerLayers = "Device.Ethernet.Link.6.", Name = "wwan0" }
IP.Interface.12.IPv4Address.+
IP.Interface.12.IPv4Address.1.AddressingType="3GPP-NAS"

4) Adjust IP.Interface instance corresposnding to wan interface

IP.Interface.wan.LowerLayers="Device.Ethernet.Link.6."

5) Change IP.Interface.wan.IPv4Address instance with AddressingType set to '3GPP-NAS'

IP.Interface.2.IPv4Address.1.AddressingType="3GPP-NAS"


root - ubus: - [ubus-cli] (0)
 >

6) Double-check that Logical.Interface.wan points to proper Device.IP.Interface:
Logical.Interface.1.LowerLayers="Device.IP.Interface.2."

7) Routing.Router.1.IPv4Forwarding.1.Origin="3GPP-NAS"
```

## Running the plug-in

Reboot your system and wait for modem & cellular managers to start.

Doublecheck the Cellular Datamodel - if cellular modem was successfully connected to the network,
it should contain IP settings (enable hidden extension paramaters with `protected` keyword in `ubus-cli`).

For example it may look like that

```
root@prplOS:~# ubus-cli
Copyright (c) 2020 - 2024 SoftAtHome
amxcli version : 0.5.1

!amx silent true

                   _  ___  ____
  _ __  _ __ _ __ | |/ _ \/ ___|
 | '_ \| '__| '_ \| | | | \___ \
 | |_) | |  | |_) | | |_| |___) |
 | .__/|_|  | .__/|_|\___/|____/
 |_|        |_| based on OpenWrt
 -----------------------------------------------------
 ubus - cli
 -----------------------------------------------------

root - ubus: - [ubus-cli] (0)
 > protected
> !addon select mod_ba
> connection access ubus: protected
> !addon select mod_ba cli

root - ubus: - [ubus-cli] (0)
 > Cellular.?
Cellular.
Cellular.AccessPointNumberOfEntries=1
Cellular.CellularController="mod-cellular-libmm"
Cellular.InterfaceNumberOfEntries=1
Cellular.RoamingEnabled=0
Cellular.RoamingStatus="Home"
Cellular.SupportedControllers="mod-cellular-libmm"
Cellular.AccessPoint.
Cellular.AccessPoint.1.
Cellular.AccessPoint.1.APN="orangedefault"
Cellular.AccessPoint.1.Alias="AP0"
Cellular.AccessPoint.1.Enable=1
Cellular.AccessPoint.1.Interface="Device.Cellular.Interface.1."
Cellular.AccessPoint.1.Password=""
Cellular.AccessPoint.1.Proxy=""
Cellular.AccessPoint.1.ProxyPort=0
Cellular.AccessPoint.1.Username=""
Cellular.Interface.
Cellular.Interface.1.
Cellular.Interface.1.Alias="CELLULAR0"
Cellular.Interface.1.AvailableNetworks=""
Cellular.Interface.1.CurrentAccessTechnology="LTE"
Cellular.Interface.1.DownstreamMaxBitRate=100000
Cellular.Interface.1.Enable=1
Cellular.Interface.1.IMEI="863781016084494"
Cellular.Interface.1.InternalName="/org/freedesktop/ModemManager1/Modem/0"
Cellular.Interface.1.LastChange=8
Cellular.Interface.1.LowerLayers=""
Cellular.Interface.1.Name="wwan0"
Cellular.Interface.1.NetworkInUse="Mobistar"
Cellular.Interface.1.NetworkRequested=""
Cellular.Interface.1.PreferredAccessTechnology="Auto"
Cellular.Interface.1.RSRP=-140
Cellular.Interface.1.RSRQ=-20
Cellular.Interface.1.RSSI=-117
Cellular.Interface.1.Status="Up"
Cellular.Interface.1.SupportedAccessTechnologies="UMTS"
Cellular.Interface.1.Upstream=1
Cellular.Interface.1.UpstreamMaxBitRate=50000
Cellular.Interface.1.Bearer.
Cellular.Interface.1.Bearer.DNSServers="212.224.129.94,212.224.129.90"
Cellular.Interface.1.Bearer.IPAddress="10.210.126.113"
Cellular.Interface.1.Bearer.GatewayIPAddress="10.210.126.114"
Cellular.Interface.1.Bearer.InternalName="/org/freedesktop/ModemManager1/Bearer/0"
Cellular.Interface.1.Bearer.SubnetMask="255.255.255.252"
Cellular.Interface.1.Stats.
Cellular.Interface.1.Stats.BroadcastPacketsReceived=0
Cellular.Interface.1.Stats.BroadcastPacketsSent=0
Cellular.Interface.1.Stats.BytesReceived=1712
Cellular.Interface.1.Stats.BytesSent=2035
Cellular.Interface.1.Stats.DiscardPacketsReceived=0
Cellular.Interface.1.Stats.DiscardPacketsSent=0
Cellular.Interface.1.Stats.ErrorsReceived=0
Cellular.Interface.1.Stats.ErrorsSent=0
Cellular.Interface.1.Stats.MulticastPacketsReceived=0
Cellular.Interface.1.Stats.MulticastPacketsSent=0
Cellular.Interface.1.Stats.PacketsReceived=13
Cellular.Interface.1.Stats.PacketsSent=16
Cellular.Interface.1.Stats.UnicastPacketsReceived=0
Cellular.Interface.1.Stats.UnicastPacketsSent=0
Cellular.Interface.1.Stats.UnknownProtoPacketsReceived=0
Cellular.Interface.1.USIM.
Cellular.Interface.1.USIM.ICCID="89320299220208006010"
Cellular.Interface.1.USIM.IMSI="206102300806160"
Cellular.Interface.1.USIM.InternalName="/org/freedesktop/ModemManager1/SIM/0"
Cellular.Interface.1.USIM.MSISDN=""
Cellular.Interface.1.USIM.PIN=""
Cellular.Interface.1.USIM.PINCheck="Off"
Cellular.Interface.1.USIM.Status="Valid"

root - ubus: - [ubus-cli] (0)
 >

```

Make sure that the wwan0 interface is configured as wan and you can ping:

```
root@prplOS:~# ifconfig wwan0
wwan0     Link encap:Ethernet  HWaddr 0C:5B:8F:27:9A:64
          inet addr:10.210.126.113  Bcast:0.0.0.0  Mask:255.255.255.252
          UP BROADCAST RUNNING NOARP MULTICAST  MTU:1500  Metric:1
          RX packets:195 errors:0 dropped:0 overruns:0 frame:0
          TX packets:198 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15875 (15.5 KiB)  TX bytes:17803 (17.3 KiB)

root@prplOS:~#
root@prplOS:~# route -n
Kernel IP routing table
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
0.0.0.0         10.210.126.114  0.0.0.0         U     0      0        0 wwan0
10.210.126.112  0.0.0.0         255.255.255.252 U     0      0        0 wwan0
192.168.1.0     0.0.0.0         255.255.255.0   U     0      0        0 br-lan
192.168.2.0     0.0.0.0         255.255.255.0   U     0      0        0 br-guest
192.168.5.0     0.0.0.0         255.255.255.0   U     0      0        0 br-lcm
root@prplOS:~#
root@prplOS:~# ping kernel.org
PING kernel.org (139.178.84.217) 56(84) bytes of data.
64 bytes from dfw.source.kernel.org (139.178.84.217): icmp_seq=1 ttl=52 time=143 ms
64 bytes from dfw.source.kernel.org (139.178.84.217): icmp_seq=2 ttl=52 time=184 ms
64 bytes from dfw.source.kernel.org (139.178.84.217): icmp_seq=3 ttl=52 time=178 ms
^C
--- kernel.org ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 2003ms
rtt min/avg/max/mdev = 143.450/168.496/183.581/17.833 ms
root@prplOS:~#
```
Cellular manager will successfully (re)configure modem assigned to Cellular.Interface
in every scenarios enumerated below:
* cellular manager restart
* modem manager restart
* unplugging and plugging back the same modem
* unplugging the modem and plugging back a different modem

## Limitation

* Cellular manager currently supports only static IPv4 modem configuration. When
modem does not return an IPv4 configuration or its type is not static, modem
will be disconnected immediately and reconnection will not be reattempted until
modem gets unplugged and plugged back again
* SIM slot selection is not supported
* Each modem can be assigned to only one Cellular.Interface object
* Cellular manager must be the only agent that create bearers on the modem and
connects/disconnects them
