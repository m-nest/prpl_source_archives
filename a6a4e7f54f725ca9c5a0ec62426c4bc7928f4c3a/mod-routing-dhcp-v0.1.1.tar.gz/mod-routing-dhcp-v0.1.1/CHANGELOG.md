# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release master_v0.3.0 - 2025-03-25(08:37:24 +0000)

### Other

- Issue: HOP-9207 [INTERNAL] [Module][mod_routing-dhcp] Replace prefix within global variable call

## Release master_v0.2.0 - 2023-10-12(11:28:45 +0000)

### New

- Issue: HOP-4547 Update Licenses in oss components

## Release master_v0.1.2 - 2023-09-07(13:07:23 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release master_v0.1.1 - 2023-05-11(07:34:29 +0000)

## Release master_v0.1.0 - 2023-04-28(11:44:56 +0000)

### New

- Issue: HOP-2740 [DHCPv4Client][option 121] Dynamically create routes based on option121

