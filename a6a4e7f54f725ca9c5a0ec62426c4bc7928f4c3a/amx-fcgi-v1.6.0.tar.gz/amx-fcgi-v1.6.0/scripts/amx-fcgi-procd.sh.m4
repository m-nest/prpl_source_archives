#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="amx-fcgi"
PROG="/usr/bin/amx-fcgi"
datamodel_root=""
PROG_OPTIONS=""

prepare(){
    FCGI_SOCKET_DIR=/var/run/http/
    LIGHTTPD_USER=lighttpd
    LIGHTTPD_CHROOT=/webui
    FCGI_SOCKET=amx-fcgi.sock

    mkdir -p $LIGHTTPD_CHROOT$FCGI_SOCKET_DIR
    chown lighttpd $LIGHTTPD_CHROOT$FCGI_SOCKET_DIR
    mkdir -p /tmp/upload && chmod 1777 /tmp/upload
    mkdir -p /tmp/download && chmod 1777 /tmp/download

    #set them to use within start-up module
    procd_append_env_opts FCGI_SOCKET_DIR=${FCGI_SOCKET_DIR}
    procd_append_env_opts LIGHTTPD_USER=${LIGHTTPD_USER}
    procd_append_env_opts LIGHTTPD_CHROOT=${LIGHTTPD_CHROOT}
    procd_append_env_opts FCGI_SOCKET=${FCGI_SOCKET}
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

preservice_hook() {
    if ${log_trace};then
        logger -s "pre-service hook ${name}"
    fi
    prepare
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    if ${log_trace};then
#        logger -s "post-service hook ${name}"
#    fi
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}
