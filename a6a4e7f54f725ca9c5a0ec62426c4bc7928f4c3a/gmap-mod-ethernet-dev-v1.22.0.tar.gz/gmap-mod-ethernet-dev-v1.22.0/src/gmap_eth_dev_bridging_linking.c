/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "gmap_eth_dev_bridging.h"
#include "gmap_eth_dev_linker.h"
#include "gmap_eth_dev_discoping.h"
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_includes.h"

#include <features.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_path.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>


#define GMAP_DISCOVERY_SOURCE_BRIDGING "bridging"

typedef struct gmap_eth_dev_bridging_linker {
    uint32_t protocol;
    gmap_eth_dev_discoping_t* discoping;
    gmap_eth_dev_linker_t* linker;
    gmap_eth_dev_bridging_port_subscription_t* port_subscription;
    amxc_htable_t ports;
} s_linker_t;

typedef struct s_linker_port {
    amxc_htable_it_t it;
    s_linker_t* parent;
    uint32_t netdev_idx;
    gmap_eth_dev_bridging_mac_subscription_t* subscription;
} s_linker_port_t;

static void s_linker_port_clean(const char* key,
                                amxc_htable_it_t* it);

static void s_linker_port_on_mac(const char* mac_address,
                                 bool added,
                                 void* const priv);

static s_linker_port_t* s_linker_port_new(s_linker_t* linker,
                                          const gmap_eth_dev_bridging_port_data_t* data) {
    s_linker_port_t* port = calloc(1, sizeof(s_linker_port_t));
    when_null_trace(port, exit, ERROR, "Out of memory");

    amxc_htable_it_init(&port->it);
    port->parent = linker;
    port->netdev_idx = data->port_index;

    gmap_eth_dev_bridging_subscribe_mac(&port->subscription,
                                        data->bridge, data->port,
                                        s_linker_port_on_mac, port);
    when_null(port->subscription, failure);

    goto exit;

failure:
    amxc_htable_it_clean(&port->it, s_linker_port_clean);
    port = NULL;

exit:
    return port;
}


static void s_linker_port_clean(UNUSED const char* key,
                                amxc_htable_it_t* it) {
    s_linker_port_t* port = amxc_htable_it_get_data(it, s_linker_port_t, it);

    gmap_eth_dev_bridging_unsubscribe_mac(&port->subscription);
    free(port);
}

static void s_linker_port_on_mac(const char* mac_address,
                                 bool added,
                                 void* const priv) {
    s_linker_port_t* port = priv;
    char* dev_key = NULL;
    bool ok = false;
    bool already_existed = false;

    when_str_empty(mac_address, exit);

    ok = gmap_devices_createIfActive(&dev_key, &already_existed,
                                     mac_address,
                                     GMAP_DISCOVERY_SOURCE_BRIDGING,
                                     "lan edev mac physical",
                                     true,
                                     NULL,
                                     NULL, added);
    when_false_trace(ok, exit, ERROR, "Error createIfActive %s", mac_address);
    when_null(dev_key, exit); // can legitimately happen if device is inactive.

    if(added) {
        gmap_eth_dev_linker_link(port->parent->linker, NULL, port->netdev_idx, dev_key);
    } else if(already_existed) {
        gmap_eth_dev_linker_make_inactive(port->parent->linker, port->netdev_idx, dev_key);
    }

    if(added && already_existed) {
        gmap_eth_dev_discoping_verify_all_ips(port->parent->discoping,
                                              mac_address, dev_key,
                                              port->parent->protocol);
    }

exit:
    free(dev_key);
}



static void s_linker_delete(s_linker_t* linker);
static void s_linker_on_port(const gmap_eth_dev_bridging_port_data_t* data,
                             bool added,
                             void* priv);

static s_linker_t* s_linker_new(const gmap_eth_dev_bridge_t* bridge) {
    s_linker_t* linker = NULL;

    linker = calloc(1, sizeof(s_linker_t));
    when_null_trace(linker, exit, ERROR, "Out of memory");

    when_failed(amxc_htable_init(&linker->ports, 0), failure);

    linker->protocol = gmap_eth_dev_bridge_get_protocol_family(bridge);
    linker->discoping = gmap_eth_dev_bridge_get_discoping(bridge);
    when_null(linker->discoping, failure);

    gmap_eth_dev_linker_new(&linker->linker, bridge, gmap_eth_dev_bridging_macs_for_port);
    when_null(linker->linker, failure);

    gmap_eth_dev_bridging_subscribe_port(&linker->port_subscription,
                                         gmap_eth_dev_bridge_get_netdev_name(bridge),
                                         s_linker_on_port, linker);
    when_null(linker->port_subscription, failure);

    goto exit;

failure:
    s_linker_delete(linker);
    linker = NULL;

exit:
    return linker;
}

static void s_linker_delete(s_linker_t* linker) {
    when_null(linker, exit);

    gmap_eth_dev_bridging_unsubscribe_port(&linker->port_subscription);
    gmap_eth_dev_linker_delete(&linker->linker);
    amxc_htable_clean(&linker->ports, s_linker_port_clean);
    free(linker);

exit:
    return;
}

static void s_linker_on_port(const gmap_eth_dev_bridging_port_data_t* data,
                             bool added,
                             void* priv) {
    s_linker_t* linker = priv;
    amxc_htable_it_t* entry = amxc_htable_get(&linker->ports, data->port);
    s_linker_port_t* port = NULL;

    if(added) {
        when_not_null(entry, exit);
        port = s_linker_port_new(linker, data);
        when_null(port, exit);
        if(amxc_htable_insert(&linker->ports, data->port, &port->it) != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to add port to table");
            amxc_htable_it_clean(&port->it, s_linker_port_clean);
        }
    } else {
        amxc_htable_it_clean(entry, s_linker_port_clean);
    }

exit:
    return;
}



void gmap_eth_dev_bridging_linker_new(gmap_eth_dev_bridging_linker_t** bridging_linker,
                                      const gmap_eth_dev_bridge_t* bridge) {
    when_null(bridging_linker, exit);
    *bridging_linker = NULL;

    when_null(bridge, exit);

    *bridging_linker = s_linker_new(bridge);

exit:
    return;
}

void gmap_eth_dev_bridging_linker_delete(gmap_eth_dev_bridging_linker_t** bridging_linker) {
    when_null(bridging_linker, exit);
    when_null(*bridging_linker, exit);

    s_linker_delete(*bridging_linker);
    *bridging_linker = NULL;

exit:
    return;
}
