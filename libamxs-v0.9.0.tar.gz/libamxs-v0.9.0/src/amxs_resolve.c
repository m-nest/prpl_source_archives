/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdlib.h>
#include <string.h>

#include <amxs/amxs.h>
#include <amxp/amxp_expr_node.h>
#include <amxd/amxd_path.h>
#include <amxd/amxd_object.h>

static void amxs_resolve_evaluate(const char* path, amxs_resolve_ctx_t* ctx) {
    amxc_var_t* data = NULL;
    amxp_expr_status_t status = amxp_expr_status_unknown_error;
    amxd_path_t local_path;
    const char* path_str = NULL;
    amxc_var_t* match_var = NULL;

    amxd_path_init(&local_path, path);

    // The given path can have a larger depth than the fixed_path
    // Strip off everything higher than the given depth
    while(amxd_path_get_depth(&local_path) > ctx->depth) {
        char* last = amxd_path_get_last(&local_path, true);
        free(last);
    }
    path_str = amxd_path_get(&local_path, 0);
    data = GETP_ARG(&ctx->current_data, path_str);
    match_var = GET_ARG(&ctx->matches, path_str);

    if(amxp_expr_eval_var(&ctx->expr, data, &status)) {
        if(match_var == NULL) {
            amxc_var_add_new_key(&ctx->matches, path_str);
            if(ctx->cb != NULL) {
                ctx->cb(amxd_path_get(&local_path, AMXD_OBJECT_TERMINATE), true, ctx->priv);
            }
        }
    } else {
        if(match_var != NULL) {
            amxc_var_delete(&match_var);
            if(ctx->cb != NULL) {
                ctx->cb(amxd_path_get(&local_path, AMXD_OBJECT_TERMINATE), false, ctx->priv);
            }
        }
    }

    amxd_path_clean(&local_path);
}

static amxs_status_t amxs_resolve_object_action_cb(UNUSED const amxs_sync_entry_t* entry,
                                                   UNUSED amxs_sync_direction_t direction,
                                                   amxc_var_t* data,
                                                   void* priv) {
    amxs_status_t status = amxs_status_ok;
    const char* path = GET_CHAR(data, "path");
    const char* notification = GET_CHAR(data, "notification");
    uint32_t index = GET_UINT32(data, "index");
    amxs_resolve_ctx_t* ctx = (amxs_resolve_ctx_t*) priv;
    amxc_string_t str;

    amxc_string_init(&str, 64);
    when_str_empty(notification, exit);
    when_str_empty(path, exit);

    amxc_string_setf(&str, "%s%u", path, index);

    if((strcmp(notification, "dm:instance-added") == 0) ||
       (strcmp(notification, "sync:init-object") == 0)) {
        amxc_var_t var;
        amxc_var_init(&var);
        amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
        amxc_var_set_path(&ctx->current_data, amxc_string_get(&str, 0), &var, AMXC_VAR_FLAG_AUTO_ADD);
        amxc_var_clean(&var);
    } else {
        amxc_var_t* var = GETP_ARG(&ctx->current_data, amxc_string_get(&str, 0));
        amxc_var_delete(&var);
        var = GET_ARG(&ctx->matches, amxc_string_get(&str, 0));
        amxc_var_delete(&var);
        amxc_string_append(&str, ".", 1);
        if(ctx->cb != NULL) {
            ctx->cb(amxc_string_get(&str, 0), false, ctx->priv);
        }
    }

exit:
    amxc_string_clean(&str);
    return status;
}

static amxs_status_t amxs_resolve_param_action_cb(const amxs_sync_entry_t* entry,
                                                  amxs_sync_direction_t direction,
                                                  amxc_var_t* data,
                                                  void* priv) {
    amxs_status_t status = amxs_status_ok;
    amxs_resolve_ctx_t* ctx = (amxs_resolve_ctx_t*) priv;
    const char* path = GET_CHAR(data, "path");
    const char* name = amxs_sync_entry_get_name(entry, direction);
    amxc_var_t* value = NULL;

    when_str_empty(path, exit);
    when_str_empty(name, exit);

    value = amxc_var_get_pathf(data, AMXC_VAR_FLAG_DEFAULT, "parameters.%s", name);
    when_null(value, exit);

    amxc_var_set_pathf(&ctx->current_data, value, AMXC_VAR_FLAG_AUTO_ADD, "%s%s", path, name);
    amxs_resolve_evaluate(path, ctx);

exit:
    return status;
}

static void amxs_resolve_add_field_to_sync(const amxp_expr_node_t* node, void* priv) {
    const char* field = amxp_expr_node_field_name(node);
    amxs_resolve_ctx_t* ctx = (amxs_resolve_ctx_t*) priv;

    if(strstr(field, ".") != NULL) {
        amxd_path_t path;
        amxs_sync_object_t* sub_obj = NULL;
        const char* obj_path = NULL;
        const char* param_path = NULL;

        amxd_path_init(&path, field);

        obj_path = amxd_path_get(&path, AMXD_OBJECT_TERMINATE);
        param_path = amxd_path_get_param(&path);

        amxs_sync_object_new(&sub_obj, obj_path, obj_path, AMXS_SYNC_ONLY_A_TO_B, NULL, NULL, NULL);
        amxs_sync_object_add_new_param(sub_obj,
                                       param_path,
                                       param_path,
                                       AMXS_SYNC_ONLY_A_TO_B,
                                       amxs_sync_param_copy_trans_cb,
                                       amxs_resolve_param_action_cb,
                                       ctx);
        amxs_sync_object_add_object(ctx->obj, sub_obj);

        amxd_path_clean(&path);
    } else {
        amxs_sync_object_add_new_param(ctx->obj,
                                       field,
                                       field,
                                       AMXS_SYNC_ONLY_A_TO_B,
                                       amxs_sync_param_copy_trans_cb,
                                       amxs_resolve_param_action_cb,
                                       ctx);
    }
}

static amxs_status_t amxs_resolve_parse_path(const char* search_path,
                                             amxd_path_t* path,
                                             amxs_resolve_ctx_t* ctx) {
    amxs_status_t status = amxs_status_invalid_arg;
    char* tmp = NULL;
    size_t len = 0;

    when_str_empty(search_path, exit);
    when_failed(amxd_path_setf(path, false, "%s", search_path), exit);

    ctx->depth = amxd_path_get_depth(path);

    tmp = amxd_path_get_last(path, true);
    when_str_empty(tmp, exit);

    // The remaining depth should be at least 2, amxs sync won't work on a single template object
    when_false(ctx->depth - 1 >= 2, exit);

    when_false(tmp[0] == '[', exit);
    len = strlen(tmp);
    when_false(tmp[len - 2] == ']', exit);

    tmp[len - 2] = '\0';
    when_failed(amxp_expr_init(&ctx->expr, tmp + 1), exit);

    status = amxs_status_ok;

exit:
    free(tmp);
    return status;
}

static void amxs_resolve_create_sync(amxd_path_t* path, amxs_resolve_ctx_t* ctx) {
    amxs_sync_object_t* obj = NULL;
    char* tmp = NULL;

    tmp = amxd_path_get_first(path, true);
    amxs_sync_ctx_new(&ctx->ctx, tmp, tmp, AMXS_SYNC_ONLY_A_TO_B);

    free(tmp);
    tmp = amxd_path_get_first(path, true);
    amxs_sync_object_new(&obj,
                         tmp,
                         tmp,
                         AMXS_SYNC_ONLY_A_TO_B,
                         amxs_sync_object_copy_trans_cb,
                         amxs_resolve_object_action_cb,
                         ctx);
    amxs_sync_ctx_add_object(ctx->ctx, obj);

    while(amxd_path_get_depth(path) > 0) {
        amxs_sync_object_t* child_obj = NULL;
        free(tmp);

        tmp = amxd_path_get_first(path, true);
        amxs_sync_object_new(&child_obj,
                             tmp,
                             tmp,
                             AMXS_SYNC_ONLY_A_TO_B,
                             amxs_sync_object_copy_trans_cb,
                             amxs_resolve_object_action_cb,
                             ctx);
        amxs_sync_object_add_object(obj, child_obj);
        obj = child_obj;
    }

    ctx->obj = obj;
    amxp_expr_for_all_nodes(&ctx->expr, amxp_expr_field, amxs_resolve_add_field_to_sync, ctx);

    free(tmp);
}

amxs_status_t amxs_resolve_ctx_new(amxs_resolve_ctx_t** ctx,
                                   const char* search_path,
                                   amxs_resolve_fn_t cb,
                                   void* priv) {
    amxs_status_t status = amxs_status_invalid_arg;
    amxd_path_t path;
    amxs_resolve_ctx_t* tmp_ctx = NULL;

    amxd_path_init(&path, NULL);

    when_null(ctx, exit);
    when_null(cb, exit);

    tmp_ctx = (amxs_resolve_ctx_t*) malloc(sizeof(amxs_resolve_ctx_t));
    when_null_status(tmp_ctx, exit, status = amxs_status_out_of_mem);
    memset(tmp_ctx, 0, sizeof(amxs_resolve_ctx_t));

    amxc_var_init(&tmp_ctx->current_data);
    amxc_var_set_type(&tmp_ctx->current_data, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&tmp_ctx->matches);
    amxc_var_set_type(&tmp_ctx->matches, AMXC_VAR_ID_HTABLE);
    tmp_ctx->priv = priv;
    tmp_ctx->cb = cb;

    status = amxs_resolve_parse_path(search_path, &path, tmp_ctx);
    when_failed(status, exit);

    amxs_resolve_create_sync(&path, tmp_ctx);

    status = amxs_sync_ctx_start_sync(tmp_ctx->ctx);
    when_failed(status, exit);

    *ctx = tmp_ctx;

exit:
    amxd_path_clean(&path);
    if(status != amxs_status_ok) {
        amxs_resolve_ctx_delete(&tmp_ctx);
    }
    return status;
}

void amxs_resolve_ctx_delete(amxs_resolve_ctx_t** ctx) {
    amxs_resolve_ctx_t* ctx_p = NULL;
    amxc_string_t str;

    amxc_string_init(&str, 64);

    when_null(ctx, exit);
    when_null(*ctx, exit);

    ctx_p = *ctx;

    amxc_var_for_each(var, &ctx_p->matches) {
        amxc_string_setf(&str, "%s.", amxc_var_key(var));
        if(ctx_p->cb != NULL) {
            ctx_p->cb(amxc_string_get(&str, 0), false, ctx_p->priv);
        }
    }

    amxc_var_clean(&ctx_p->current_data);
    amxc_var_clean(&ctx_p->matches);
    amxp_expr_clean(&ctx_p->expr);
    amxs_sync_ctx_delete(&ctx_p->ctx);
    free(ctx_p);
    *ctx = NULL;

exit:
    amxc_string_clean(&str);
    return;
}
