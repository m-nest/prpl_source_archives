/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "button.h"
#include "dm_button.h"

#ifndef input_event_sec
#define input_event_sec time.tv_sec
#define input_event_usec time.tv_usec
#endif

void button_set_status(amxd_object_t* button_instance, button_status_t status) {
    button_instance_t* priv_data = NULL;
    amxd_trans_t trans;
    const char* status_str = NULL;

    when_null(button_instance, exit);
    priv_data = (button_instance_t*) button_instance->priv;
    when_null(priv_data, exit);
    priv_data->status = status;

    when_null(amxd_object_get_param_def(button_instance, "Status"), exit);
    if(status == BUTTON_RELEASED) {
        status_str = "Released";
    } else if(status == BUTTON_PUSHED) {
        status_str = "Pushed";
    } else if(status == BUTTON_ERROR) {
        status_str = "Error";
    }
    when_null(status_str, exit);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    amxd_trans_select_object(&trans, button_instance);
    amxd_trans_set_value(cstring_t, &trans, "Status", status_str);
    if(amxd_trans_apply(&trans, button_get_dm()) != amxd_status_ok) {
        SAH_TRACEZ_NOTICE(ME, "Transaction failed");
    }

    amxd_trans_clean(&trans);
exit:
    return;
}

int button_input_event(amxd_object_t* button_instance, button_status_t status, UNUSED amxc_ts_t ts) {
    int retval = 1;
    button_instance_t* priv_data = NULL;
    button_event_t* event_info = NULL;
    const char* button_name = NULL;

    when_null(button_instance, exit);
    button_name = GET_CHAR(amxd_object_get_param_value(button_instance, "Name"), NULL);
    priv_data = (button_instance_t*) button_instance->priv;
    when_null(priv_data, exit);
    if(priv_data->status == status) {
        SAH_TRACEZ_WARNING(ME, "Button input event is the same as the current status");
        goto exit;
    }
    SAH_TRACEZ_INFO(ME, "Button [%s] input event - [%s]", button_name, status == BUTTON_PUSHED ? "Pushed" : "Released");
    button_set_status(button_instance, status);
    retval = 0;
    amxc_llist_for_each(it, priv_data->llist_event) {
        event_info = amxc_llist_it_get_data(it, button_event_t, ll_it);
        if((event_info != NULL) && event_info->enabled) {
            button_event_trigger(event_info, status, ts);
        }
    }
exit:
    return retval;
}

void button_read_handler(int fd, UNUSED void* priv) {
    struct input_event event;
    ssize_t bytes_read = 0;
    amxd_object_t* button_instance = NULL;
    button_instance_t* priv_data = NULL;
    button_status_t status = BUTTON_ERROR;
    amxc_ts_t ts;

    bytes_read = read(fd, &event, sizeof(event));
    if(bytes_read == sizeof(event)) {
        if(event.type == EV_KEY) {
            SAH_TRACEZ_INFO(ME, "Received Button Event: type:%d code:%d value:%d", event.type, event.code, event.value);
            SAH_TRACEZ_INFO(ME, "Received Button Event: %ld seconds %ld microseconds", event.input_event_sec, event.input_event_usec);
            if(event.value == 0) {
                status = BUTTON_RELEASED;
            } else {
                status = BUTTON_PUSHED;
            }
            ts.sec = event.input_event_sec;
            ts.nsec = event.input_event_usec * 1000;
            amxd_object_for_each(instance, it, button_get_object(BUTTON_TR181_PATH)) {
                button_instance = amxc_llist_it_get_data(it, amxd_object_t, it);
                if(button_instance != NULL) {
                    priv_data = (button_instance_t*) button_instance->priv;
                    if((priv_data != NULL) && (priv_data->key_code == event.code)) {
                        button_input_event(button_instance, status, ts);
                        break;
                    }
                }
            }
        }
    }
    return;
}

static void button_event_loop_remove_fd(const char* device) {
    amxc_llist_t* registered_listeners = amxp_connection_get_listeners();

    when_null(device, exit);
    amxc_llist_for_each(it, registered_listeners) {
        amxp_connection_t* connection = amxc_llist_it_get_data(it, amxp_connection_t, it);
        if((connection->type == AMXP_CONNECTION_LISTEN) &&
           (connection->reader == button_read_handler) && connection->uri &&
           (strncmp(connection->uri, device, strlen(device)) == 0)) {
            close(connection->fd);
            when_failed_trace(amxp_connection_remove(connection->fd), exit, ERROR, "Failed to remove fd [%s] from event loop", device);
        }
    }
exit:
    return;
}

int button_device_clean(amxd_object_t* button_instance) {
    int retval = 1;
    const char* button_device = NULL;
    button_instance_t* priv_data = NULL;

    when_null(button_instance, exit);
    button_device = GET_CHAR(amxd_object_get_param_value(button_instance, "Device"), NULL);
    if((NULL != button_device) && (strcmp(button_device, "") != 0)) {
        button_event_loop_remove_fd(button_device);
    }

    priv_data = (button_instance_t*) button_instance->priv;
    if(priv_data != NULL) {
        amxc_llist_delete(&priv_data->llist_event, button_event_clean);
        free(priv_data);
        priv_data = NULL;
        retval = 0;
    }
exit:
    return retval;
}

static unsigned short process_get_gpio_keys(const char* base_dir, const char* button_name) {
    amxc_string_t path;
    amxc_string_t label_path;
    amxc_string_t code_path;
    const char* path_str = NULL;
    const char* label_path_str = NULL;
    const char* code_path_str = NULL;
    unsigned short key_code = 0;
    DIR* p_dir;
    struct dirent* entry;
    struct stat path_stat;
    FILE* p_label_file = NULL;
    char* label = NULL;
    long length;
    FILE* p_code_file = NULL;
    unsigned char code[4];

    amxc_string_init(&path, 0);
    amxc_string_init(&label_path, 0);
    amxc_string_init(&code_path, 0);

    p_dir = opendir(base_dir);
    when_null(p_dir, exit);

    while((entry = readdir(p_dir)) != NULL) {
        amxc_string_setf(&path, "%s/%s", base_dir, entry->d_name);
        path_str = amxc_string_get(&path, 0);
        if((stat(path_str, &path_stat) == 0) && S_ISDIR(path_stat.st_mode) && (entry->d_name[0] != '.')) {
            amxc_string_setf(&label_path, "%s/%s", path_str, "label");
            label_path_str = amxc_string_get(&label_path, 0);
            p_label_file = fopen(label_path_str, "r");
            if(p_label_file != NULL) {
                fseek(p_label_file, 0, SEEK_END);
                length = ftell(p_label_file);
                if(length < 0) {
                    SAH_TRACEZ_ERROR(ME, "Failed to get length of label file [%s]", label_path_str);
                    fclose(p_label_file);
                    continue;
                }
                fseek(p_label_file, 0, SEEK_SET);
                label = (char*) malloc(length + 1);
                if(label != NULL) {
                    size_t bytesRead = fread(label, 1, length, p_label_file);
                    if(bytesRead == (size_t) length) {
                        label[length] = '\0';
                        if(strcmp(label, button_name) == 0) {
                            amxc_string_setf(&code_path, "%s/%s", path_str, "linux,code");
                            code_path_str = amxc_string_get(&code_path, 0);
                            p_code_file = fopen(code_path_str, "rb");
                            if(p_code_file != NULL) {
                                bytesRead = fread(code, sizeof(unsigned char), 4, p_code_file);
                                fclose(p_code_file);
                                if(bytesRead == 4) {
                                    key_code = (code[2] << 8) | code[3];
                                    SAH_TRACEZ_INFO(ME, "Button device [%s] key code is [%d]", button_name, key_code);
                                }
                            }
                        }
                    }
                    free(label);
                }
                fclose(p_label_file);
            }
        }
        if(key_code != 0) {
            break;
        }
    }
    closedir(p_dir);

exit:
    amxc_string_clean(&path);
    amxc_string_clean(&label_path);
    amxc_string_clean(&code_path);
    return key_code;
}

static unsigned short process_scan_gpio_keys(const char* base_dir, const char* button_name) {
    amxc_string_t path;
    const char* path_str = NULL;
    unsigned short key_code = 0;
    DIR* p_dir = NULL;
    struct dirent* entry;
    struct stat path_stat;

    amxc_string_init(&path, 0);

    p_dir = opendir(base_dir);
    when_null(p_dir, exit);

    while((entry = readdir(p_dir)) != NULL) {
        amxc_string_setf(&path, "%s/%s", base_dir, entry->d_name);
        path_str = amxc_string_get(&path, 0);
        if((stat(path_str, &path_stat) == 0) && S_ISDIR(path_stat.st_mode)) {
            if((strncmp(entry->d_name, "gpio", 4) == 0) || strstr(entry->d_name, "keys")) {
                key_code = process_get_gpio_keys(path_str, button_name);
            } else if(entry->d_name[0] != '.') {
                key_code = process_scan_gpio_keys(path_str, button_name);
            }
            if(key_code != 0) {
                break;
            }
        }
    }
    closedir(p_dir);

exit:
    amxc_string_clean(&path);
    return key_code;
}

static unsigned short get_button_key_code(const char* button_name) {
    return process_scan_gpio_keys(button_get_gpio_keys_path(), button_name);
}

static void button_event_loop_add_fd(const char* device, amxd_object_t* button_instance) {
    int fd = -1;
    amxc_llist_t* registered_listeners = amxp_connection_get_listeners();

    when_null(device, exit);
    when_null(button_instance, exit);

    amxc_llist_for_each(it, registered_listeners) {
        amxp_connection_t* connection = amxc_llist_it_get_data(it, amxp_connection_t, it);
        if((connection->type == AMXP_CONNECTION_LISTEN) &&
           (connection->reader == button_read_handler) && connection->uri &&
           (strncmp(connection->uri, device, strlen(device)) == 0)) {
            SAH_TRACEZ_INFO(ME, "Button [%s] fd [%s] is in evemt loop - Skip", amxd_object_get_name(button_instance, AMXD_OBJECT_NAMED), device);
            goto exit;
        }
    }

    fd = open(device, O_RDONLY);
    when_true_trace((fd <= 0) || (amxp_connection_get(fd) != NULL), cleanup_fd, ERROR, "[%s] Invalid fd [%d]", device, fd);
    when_failed_trace(amxp_connection_add(fd, button_read_handler, device, AMXP_CONNECTION_LISTEN, NULL), cleanup_fd, ERROR, "Failed to add fd [%d] to event loop", fd)
    SAH_TRACEZ_INFO(ME, "Button [%s] add fd [%s] to event loop", amxd_object_get_name(button_instance, AMXD_OBJECT_NAMED), device);
    goto exit;

cleanup_fd:
    if(fd > 0) {
        close(fd);
    }

exit:
    return;
}

static int init_button_events(amxd_object_t* button_instance) {
    amxd_object_t* event_instance = NULL;
    amxd_object_t* button_events = NULL;
    button_event_t* event_info = NULL;
    button_instance_t* priv_data = NULL;
    int retval = 1;

    when_null(button_instance, exit);
    button_events = amxd_object_get_child(button_instance, "Event");
    priv_data = (button_instance_t*) button_instance->priv;
    when_null(button_events, exit);
    when_null(priv_data, exit);

    amxd_object_for_each(instance, it, button_events) {
        event_instance = amxc_container_of(it, amxd_object_t, it);
        when_null(event_instance, exit);
        event_info = (button_event_t*) calloc(1, sizeof(button_event_t));
        when_null(event_info, exit);
        button_event_init(event_info, event_instance);
        if(amxc_llist_append(priv_data->llist_event, &event_info->ll_it)) {
            amxp_timer_delete(&event_info->timer);
            free(event_info->obj_path);
            free(event_info);
            event_info = NULL;
            goto exit;
        }
    }
    retval = 0;
exit:
    return retval;
}

int button_device_init(amxd_object_t* button_instance) {
    button_instance_t* priv_data = NULL;
    const char* button_device = NULL;
    const char* button_name = NULL;
    FILE* p_file = NULL;
    int retval = 1;

    when_null(button_instance, exit);
    SAH_TRACEZ_INFO(ME, "Button device init [%s]", amxd_object_get_name(button_instance, AMXD_OBJECT_NAMED));

    when_not_null(button_instance->priv, exit);
    priv_data = calloc(1, sizeof(button_instance_t));
    when_null(priv_data, exit);
    button_instance->priv = priv_data;

    amxc_llist_new(&priv_data->llist_event);
    when_failed(init_button_events(button_instance), exit);

    button_name = GET_CHAR(amxd_object_get_param_value(button_instance, "Name"), NULL);
    when_null(button_name, exit);
    priv_data->key_code = get_button_key_code(button_name);
    if(priv_data->key_code == 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to get key code for button [%s]", button_name);
        button_set_status(button_instance, BUTTON_ERROR);
    }

    button_device = GET_CHAR(amxd_object_get_param_value(button_instance, "Device"), NULL);
    when_null(button_device, exit);
    p_file = fopen(button_device, "rb");
    if(p_file != NULL) {
        fclose(p_file);
        button_event_loop_add_fd(button_device, button_instance);
    } else {
        SAH_TRACEZ_ERROR(ME, "Failed to open [%s]", button_device);
        button_set_status(button_instance, BUTTON_ERROR);
    }

    retval = 0;

exit:
    return retval;
}
