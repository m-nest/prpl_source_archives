﻿# **TR-181 PowerStatus**

- [Specification](#tr181powerstatus-specification) 
  - [Requirements](#tr181powerstatus-requirements)
  - [Development tickets](#tr181powerstatus-developmenttickets)
  - [Related documents:](#tr181powerstatus-relateddocuments:)
  - [Use case](#tr181powerstatus-usecase)
- [Architecture](#tr181powerstatus-architecture) 
  - [Design](#tr181powerstatus-design)
  - [TR181 PowerStatus plugin:](#tr181powerstatus-tr181powerstatusplugin:) 
    - [Power information polling](#tr181powerstatus-powerinformationpolling)
    - [Source of the power readings](#tr181powerstatus-sourceofthepowerreadings)
- [Implementation](#tr181powerstatus-implementation) 
  - [Data Model](#tr181powerstatus-datamodel)
  - [Files](#tr181powerstatus-files) 
  - [API](#tr181powerstatus-api)
  - [Dependants and dependencies](#tr181powerstatus-dependantsanddependencies) 
    - [Dependencies](#tr181powerstatus-dependencies)
  - [Configuration](#tr181powerstatus-configuration) 
    - [%config section](#tr181powerstatus-%configsection) 
      - [vendor prefix](#tr181powerstatus-vendorprefix)
  - [Web UI](#tr181powerstatus-webui)
- [Considerations](#tr181powerstatus-considerations) 
  - [Memory Usage](#tr181powerstatus-memoryusage)
  - [Boot Time](#tr181powerstatus-boottime)
  - [Security](#tr181powerstatus-security)
  - [Remote Management](#tr181powerstatus-remotemanagement)
  - [Operational Monitoring](#tr181powerstatus-operationalmonitoring)
- [Quality](#tr181powerstatus-quality) 
  - [Project Reference Configuration](#tr181powerstatus-projectreferenceconfiguration)
  - [Build-time Checks](#tr181powerstatus-build-timechecks)
  - [Run-time Checks](#tr181powerstatus-run-timechecks)
  - [Unit Tests](#tr181powerstatus-unittests)
  - [Logging and Debugging](#tr181powerstatus-logginganddebugging)
  - [Functional Tests](#tr181powerstatus-functionaltests)
  - [Validation Test Plan](#tr181powerstatus-validationtestplan)
- [Design Review Documentation](#tr181powerstatus-designreviewdocumentation)

# <a name="tr181powerstatus-specification"></a>**Specification**
## <a name="tr181powerstatus-requirements"></a>**Requirements**
## <a name="tr181powerstatus-developmenttickets"></a>**Development** 
## <a name="tr181powerstatus-relateddocuments:"></a>**Related documents:**
## <a name="tr181powerstatus-usecase"></a>**Use case** 
- It must be possible to model and expose the Device.DeviceInfo.PowerStatus. functionality as defined by TR181: 
  - See: [https://usp-data-models.broadband-forum.org/tr-181-2-19-0-usp.html#D.Device:2.Device.DeviceInfo.PowerStatus](https://usp-data-models.broadband-forum.org/tr-181-2-12-0-usp.html#D.Device:2.Device.DeviceInfo.TemperatureStatus).
- It must be possible to set up a power sensor which will be polled. 
  - It must be possible for the plugin to get the current, voltage and power.
  - It must be possible to fill the path to the power sensor in the protected "PowerPath" parameter.
# <a name="tr181powerstatus-architecture"></a>**Architecture**
The Device.DeviceInfo.PowerStatus. contains a multi instance object PowerSensor.{i}
### <a name="tr181powerstatus-design"></a>**Design**
### ![](image/architectture.png)
### <a name="tr181powerstatus-truetr181_temperaturefalseautotoptrue6811912"></a><a name="tr181powerstatus-tr181powerstatusplugin:"></a>**TR181 PowerStatus plugin:**
A new ambiorix plugin must be created which exposes the the PowerStatus data model to the bus.
#### <a name="tr181powerstatus-powerinformationpolling"></a>**Power information polling**
The tr181-powerstatus plugin must poll the power values of the configured sensors. when the datamodel object is read.

If the sensors can be read, the current timestamp is saved in the LastUpdate parameter.
#### <a name="tr181powerstatus-sourceofthepowerreadings"></a>**Source of the power readings**
The parameter "PowerPath" is used to store the path to the power file from the drivers.
# <a name="tr181powerstatus-implementation"></a>**Implementation** 
## <a name="tr181powerstatus-datamodel"></a>**Data Model** 
|**Name**|**Type**|**W/P/V**|**Description**|**Legal Values/Default**|**Action on Add/Delete/Modify**|**Version**|
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
|**PowerStatus**|**Object**|**RP**|**Status of the power of the device.**|**–**||**2.19**|
|PowerSensorNumberOfEntries|uint32|R|The number of entries in the PowerSensor table|**Instance counter for**:|–|2\.19|
|**PowerStatus.PowerSensor.{i}**|**Object**|**RWP**|**Represents the power sensor parameters including voltage, current, and power measurements. At most one entry in this table can exist with a given value for Name, or with a given value for Alias.**|**–**||**2.19**|
|Alias|string|RWP|A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.|**default**:|–|2\.19|
|Enable|bool|RWP|Indicates whether or not the power sensor is enabled.|**default**: false|–|2\.19|
|Status|string|R|The status of this power sensor. Enumeration of: + Disabled (The sensor is not currently sampling the power) + Enabled (The sensor is currently sampling the power) + Error (The sensor error currently prevents sampling the power)|**default**: Disabled|–|2\.19|
|Name|string|RWP|Name of this power sensor. This text MUST be sufficient to distinguish this power sensor from other power sensors.|**default**:|–|2\.19|
|LastUpdate|datetime|R|The time at which this power sensor’s last good reading was obtained. The Unknown Time value, as defined in TR-106, indicates a good reading has not been obtained since last reset. Value Change Notification requests for this parameter MAY be denied.|**default**: 0001-01-01T00:00:00Z|–|2\.19|
|Voltage|int32|R|The voltage measured by the sensor, in mV. Not implemented.|**default**:|–|2\.19|
|Current|int32|R|The current measured by the sensor, in mA. Not implemented.|**default**:|–|2\.19|
|Power|int32|R|The power measured by the sensor, in mW.|**default**:|–|2\.19|
|PowerPath|string|RWP|Filepath to the power register.|**default**:|–|0\.0.0|
|PollingInterval|uint32|RWP|The interval, measured in seconds, in which the device polls this PowerSensor.|**default:** 10|–|0\.0.0|

## <a name="tr181powerstatus-files"></a>**Files** 

Files in directory /sys/class/\* will be polled to read power informations. See PowerPath parameter.
## <a name="tr181powerstatus-api"></a>**API** 
## <a name="tr181powerstatus-dependantsanddependencies"></a>**Dependants and dependencies** 
### <a name="tr181powerstatus-dependencies"></a>**Dependencies**
- lib\_amxb
- lib\_amxc
- lib\_amxd
- lib\_amxp
- lib\_amxo
- lib\_sahtrace
## <a name="tr181powerstatus-configuration"></a>**Configuration** 
### <a name="tr181powerstatus-%configsection"></a>**%config section**
#### <a name="tr181powerstatus-vendorprefix"></a>**vendor prefix**
All non TR181 objects/parameters have a vendor prefix.
## <a name="tr181powerstatus-webui"></a>**Web UI** 
# <a name="tr181powerstatus-considerations"></a>**Considerations** 
## <a name="tr181powerstatus-memoryusage"></a>**Memory Usage** 
## <a name="tr181powerstatus-boottime"></a>**Boot Time** 
## <a name="tr181powerstatus-security"></a>**Security** 
The plugin executes with the tr181\_app user and drops all the capabilities except :

- CAP\_DAC\_OVERRIDE : To allow read access to powersensor
## <a name="tr181powerstatus-remotemanagement"></a>**Remote Management** 
## <a name="tr181powerstatus-operationalmonitoring"></a>**Operational Monitoring** 
# <a name="tr181powerstatus-quality"></a>**Quality** 
## <a name="tr181powerstatus-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="tr181powerstatus-build-timechecks"></a>**Build-time Checks** 
## <a name="tr181powerstatus-run-timechecks"></a>**Run-time Checks** 
## <a name="tr181powerstatus-unittests"></a>**Unit Tests**
<table><tr><th><b>Test name</b></th><th><b>Description</b></th></tr>
<tr><td colspan="2"><b>Test on Device.DeviceInfo.PowerStatus.PowerSensor.</b></td></tr>
<tr><td>test_powersensor_initialized</td><td>Registers the datamodel of the plugin and add a dummy PowerSensor instance → Checks that the datamodel is indeed reachable through the bus and the private info are correctly initialized</td></tr>
<tr><td>test_powersensor_enable-toggle</td><td>Enable the PowerSensor instance and use different values for the PowerPath parameter → Checks that the datamodel parameters are correctly updated with the power information </td></tr>
<tr><td>test_powersensor_pollinginterval</td><td>Use different values for PollingInterval parameter → Check that the polling mechanism is working</td></tr>
</table>

## <a name="tr181powerstatus-logginganddebugging"></a>**Logging an debugging**

## <a name="tr181powerstatus-functionaltests"></a>**Functional tests**

|**Test<br>nr**|**Feature<br>(reference to req/dev ticket)**|**Test done<br>(command and output, copy&paste from RTM)**|
| :-: | :-: | :-: |
## <a name="tr181powerstatus-validationtestplan"></a>**Validation Test Plan** 
# <a name="tr181powerstatus-designreviewdocumentation"></a>**Design Review Documentation**

