/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "gmap/extensions/ip/gmap_ext_ipquery.h"
#include "gmap_ext_util.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxb/amxb_subscribe.h>
#include <amxd/amxd_path.h>
#include <amxd/amxd_object.h>
#include <string.h>
#include <arpa/inet.h>

#include <gmap/gmap_main.h>
#include <gmap/gmap_query.h>
#include "gmap/extensions/ip/gmap_ext_ipaddress.h"

#define ME "libgmap"

typedef struct _ip_family {
    gmap_query_t* query;                // gmap query to discover matching devices for this family
    amxc_htable_t devices;              // hash table of devices by key
    amxc_llist_t ipqueries;             // list of current active ip queries
    uint32_t family;                    // ip address family, AF_NET or AF_NET6
    const char* objname;                // object name containing the address instances within a device
    const char* tag;                    // tag name for devices that have an address of this family
} ip_family_t;

typedef struct _ip_device {
    amxc_htable_it_t it;                // iterator of the device within the ip family device table
    amxc_llist_t addresses;             // List of known addresses, both inactive and active
    amxb_subscription_t* subscription;  // event subscription to the IPv[46]Address template
} ip_device_t;

typedef struct _ip_address {
    amxc_llist_it_t it;                 // iterator of the address within the ip device address table
    uint32_t index;                     // index of the address object, should be unique
    char* address;                      // address in textual notation
    bool reachable;                     // true if, according to latest information, the address is reachable
} ip_address_t;

struct gmap_ipquery {
    amxc_llist_it_t it;                 // iterator of the ip query within the ip family ipqueries list
    gmap_ipquery_cb_t callback;         // client callback function
    void* userdata;                     // user data
    bool defer_delete;                  // true during gmap_ipquery_new, to allow closing the query from the callback
};


//
// Static global variables
//

static struct {
    ip_family_t* ipv4;
    ip_family_t* ipv6;
} s_address_families = { 0 };


//
// Address creation/destruction
//

static ip_address_t* s_address_create(uint32_t index,
                                      const char* address,
                                      bool reachable) {
    ip_address_t* ip_address = malloc(sizeof(ip_address_t));
    when_null_trace(ip_address, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&ip_address->it);
    ip_address->index = index;
    ip_address->address = strdup(address);
    ip_address->reachable = reachable;
    when_null_trace(ip_address->address, error, ERROR, "Out of memory");

    goto exit;

error:
    free(ip_address);
    ip_address = NULL;

exit:
    return ip_address;
}

static void s_address_cleanup(amxc_llist_it_t* it) {
    ip_address_t* ip_address;
    when_null(it, exit);

    ip_address = amxc_llist_it_get_data(it, ip_address_t, it);
    free(ip_address->address);
    free(ip_address);

exit:
    return;
}


//
// Family creation/destruction
//

static void s_family_query_cb(gmap_query_t* query,
                              const char* key,
                              amxc_var_t* device,
                              gmap_query_action_t action);

static void s_device_cleanup(const char* key,
                             amxc_htable_it_t* it);

static ip_family_t* s_family_create(uint32_t family) {
    ip_family_t* ip_family = NULL;
    amxc_string_t query_name;

    amxc_string_init(&query_name, 0);

    when_false(gmap_ip_family_is_valid(family), exit);

    ip_family = malloc(sizeof(ip_family_t));
    when_null_trace(ip_family, exit, ERROR, "Out of memory");

    ip_family->query = NULL;
    amxc_htable_init(&ip_family->devices, 0);
    amxc_llist_init(&ip_family->ipqueries);
    ip_family->family = family;
    ip_family->objname = gmap_ip_family_id_to_objname(family);
    ip_family->tag = gmap_ip_family_id_to_tag(family);

    when_str_empty_trace(ip_family->objname, error, ERROR,
                         "gmap doesn't track addresses of family %" PRIu32, family);
    when_str_empty_trace(ip_family->tag, error, ERROR,
                         "gmap doesn't tag devices with addresses of family %" PRIu32, family);

    /* gmap_query requires unique names across processes opening queries.
     * Because we already rely on sahtrace, we can attempt to use the given
     * identifier as a basis to build our unique query name.
     *
     * This is not foolproof, clients using this library that don't use sahtrace
     * will share the same query name per family. In that case, we also can't
     * sahtrace any messages to the error log.
     * Additionally, clients that do properly use sahtrace, but don't bother
     * setting a unique identifier, may run into trouble as well. For these, we
     * can log errors when opening the query fails.
     */
    if(1 == sahTraceIsOpen()) {
        amxc_string_set(&query_name, sahTraceIdentifier());
        amxc_string_append(&query_name, "_", 1);
    }
    amxc_string_append(&query_name, "ipquery_", 8);
    amxc_string_append(&query_name, ip_family->tag, strlen(ip_family->tag));

    when_false_trace(gmap_query_open_ext_2(&ip_family->query, ip_family->tag,
                                           amxc_string_get(&query_name, 0),
                                           GMAP_QUERY_IGNORE_DEVICE_UPDATED,
                                           s_family_query_cb, ip_family),
                     error, ERROR,
                     "Failed to open gmap query for family %" PRIu32, family);

    SAH_TRACEZ_INFO(ME, "Started watching ip devices with query %s",
                    amxc_string_get(&query_name, 0));
    goto exit;

error:
    gmap_query_close(ip_family->query);
    /* Cleaning without item cleanup is fine, this function is called before any
     * ip query object could have been created or added. */
    amxc_llist_clean(&ip_family->ipqueries, NULL);
    /* Opening the gmap query could have created some devices before failing. */
    amxc_htable_clean(&ip_family->devices, s_device_cleanup);
    free(ip_family);
    ip_family = NULL;

exit:
    amxc_string_clean(&query_name);

    return ip_family;
}

static ip_family_t* s_family_get_or_create(uint32_t family) {
    ip_family_t** ip_family_ptr;
    switch(family) {
    case AF_INET:
        ip_family_ptr = &s_address_families.ipv4;
        break;
    case AF_INET6:
        ip_family_ptr = &s_address_families.ipv6;
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "Invalid address family %" PRIu32, family);
        return NULL;
    }

    if(*ip_family_ptr == NULL) {
        *ip_family_ptr = s_family_create(family);
    }
    return *ip_family_ptr;
}

static void s_family_destroy(ip_family_t* ip_family) {
    when_null(ip_family, exit);

    if((ip_family->query != NULL) && (ip_family->query->name != NULL)) {
        SAH_TRACEZ_INFO(ME, "Stopping watching ip devices with query %s",
                        ip_family->query->name);
    }
    gmap_query_close(ip_family->query);

    if(!amxc_llist_is_empty(&ip_family->ipqueries)) {
        /* Note: the client is responsible for properly closing all ipqueries.
         * This is similar to regular gmap queries. */
        SAH_TRACEZ_ERROR(ME, "BUG: There are still active ip queries when destroying ip family %" PRIu32,
                         ip_family->family);
    }
    amxc_llist_clean(&ip_family->ipqueries, NULL);
    amxc_htable_clean(&ip_family->devices, s_device_cleanup);

    /* Also take away the static pointer, unless it doesn't point to this object. */
    switch(ip_family->family) {
    case AF_INET:
        if(s_address_families.ipv4 != ip_family) {
            SAH_TRACEZ_ERROR(ME, "Destroying non-current family for AF_INET");
        } else {
            s_address_families.ipv4 = NULL;
        }
        break;
    case AF_INET6:
        if(s_address_families.ipv6 != ip_family) {
            SAH_TRACEZ_ERROR(ME, "Destroying non-current family for AF_INET6");
        } else {
            s_address_families.ipv6 = NULL;
        }
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "BUG: Destroying family for invalid address family %" PRIu32,
                         ip_family->family);
        break;
    }

    free(ip_family);

exit:
    return;
}

DESTRUCTOR static void s_family_destructor(void) {
    /* At least do an attempt to clean up the gmap queries.
     * The client library is responsible for cleaning all ip queries, but these
     * are a purely in-process construct. Not doing so may still leak subscriptions,
     * but at least it won't leak a gmap-query, which would otherwise create
     * issues if the process is restarted.
     */
    s_family_destroy(s_address_families.ipv4);
    s_family_destroy(s_address_families.ipv6);
}


//
// Family device tracking
//

static ip_device_t* s_device_create(ip_family_t* family,
                                    const char* key,
                                    uint32_t index);

static void s_family_notify_all(ip_family_t* ip_family,
                                ip_device_t* device,
                                bool active) {
    const char* key = amxc_htable_it_get_key(&device->it);

    when_str_empty(key, exit);

    amxc_llist_for_each(query_it, &ip_family->ipqueries) {
        gmap_ipquery_t* ip_query = amxc_llist_it_get_data(query_it, gmap_ipquery_t, it);
        /* Defer query deletion until after the callback has returned. Otherwise,
         * deletion may destroy the ip family instance while we're still iterating
         * device addresses.
         *
         * In particular, this addresses the following situation:
         * 1. An ip family has one query attached to it.
         * 2. A device starts matching the gmap query and this device has multiple
         *    addresses matching this family.
         * 3. A devices entry is created and all its addresses are added to it.
         * 4. As a final step, this function is called to notify the ip queries.
         * 5. Halfway through the list of addresses, the callback of the only
         *    registered ip query deletes its ip query object.
         * 6. If deletion is not deferred, the query is removed from the family,
         *    which has no other queries left anymore. The ip family structure,
         *    together with all contained devices and addresses is destroyed.
         * 7. All pointers in this function are now dangling and pointing to
         *    deallocated memory.
         * 8. The next iteration of the inner loop tries to get the next address,
         *    reading from deallocated memory.
         *
         * By deferring the deletion, step 6 is delayed, there are no dangling
         * pointers and all structures are properly disposed of.
         */
        ip_query->defer_delete = true;

        amxc_llist_for_each(addr_it, &device->addresses) {
            ip_address_t* ip_address = amxc_llist_it_get_data(addr_it, ip_address_t, it);
            if(ip_address->reachable) {
                /* Don't report the actual reachability, but the override value
                 * given in the active parameter.
                 * This function is also used for when a device stops matching
                 * and all its active addresses need to be reported as removed.
                 */
                ip_query->callback(key, ip_address->address, active, ip_query->userdata);
                /* delete called on the query from the callback. */
                when_null(ip_query->callback, handle_delete);
            }
        }

        ip_query->defer_delete = false;
        continue;

handle_delete:
        amxc_llist_it_take(query_it);
        free(ip_query);
        /* Don't destroy the family here, but at the top of the query callback. */
    }

exit:
    return;
}

static void s_family_notify_address(ip_family_t* ip_family,
                                    const char* key,
                                    const ip_address_t* ip_address) {
    when_null(ip_family, exit);
    when_str_empty(key, exit);
    when_null(ip_address, exit);

    amxc_llist_for_each(query_it, &ip_family->ipqueries) {
        gmap_ipquery_t* ip_query = amxc_llist_it_get_data(query_it, gmap_ipquery_t, it);
        ip_query->callback(key, ip_address->address, ip_address->reachable, ip_query->userdata);
    }

exit:
    return;
}

static void s_family_start_matching(ip_family_t* ip_family,
                                    const char* key,
                                    uint32_t index) {
    amxc_htable_it_t* entry = amxc_htable_get(&ip_family->devices, key);
    ip_device_t* device;

    when_not_null(entry, exit);

    device = s_device_create(ip_family, key, index);
    when_null(device, exit);

    when_failed_trace(amxc_htable_insert(&ip_family->devices, key, &device->it),
                      error, ERROR,
                      "Failed to insert device into ip family device table");

    s_family_notify_all(ip_family, device, true);

    goto exit;

error:
    s_device_cleanup(NULL, &device->it);

exit:
    return;
}

static void s_family_stop_matching(ip_family_t* ip_family,
                                   const char* key) {
    amxc_htable_it_t* entry = amxc_htable_get(&ip_family->devices, key);

    when_null(entry, exit);

    s_family_notify_all(ip_family, amxc_htable_it_get_data(entry, ip_device_t, it), false);

    amxc_htable_it_clean(entry, s_device_cleanup);

exit:
    return;

}

static void s_family_query_cb(gmap_query_t* query,
                              const char* key,
                              amxc_var_t* device,
                              gmap_query_action_t action) {
    ip_family_t* ip_family;
    bool startup;

    when_null_trace(query, exit, ERROR, "NULL");
    when_str_empty_trace(key, exit, ERROR, "NULL/empty string");

    ip_family = query->data;
    when_null_trace(ip_family, exit, ERROR, "Query callback with NULL ip family object");
    startup = amxc_llist_is_empty(&ip_family->ipqueries);

    switch(action) {
    case gmap_query_expression_start_matching:
        s_family_start_matching(ip_family, key, GET_UINT32(device, "Index"));
        break;
    case gmap_query_expression_stop_matching:
        s_family_stop_matching(ip_family, key);
        break;
    case gmap_query_device_updated:
        /* Should not be reached, given the query flags. */
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "Unknown or unexpected action %d for ip family callback", action);
        break;
    }

    /* libgmap-client assures that deleting the query from the callback is safe. */
    if(!startup && amxc_llist_is_empty(&ip_family->ipqueries)) {
        s_family_destroy(ip_family);
    }

exit:
    return;
}


//
// Family ip query management
//

static int s_family_add_query(ip_family_t* ip_family,
                              gmap_ipquery_t* ip_query) {
    int status = amxc_llist_append(&ip_family->ipqueries, &ip_query->it);
    when_failed_trace(status, exit, ERROR, "Failed to add query to ip family query list");

    amxc_htable_for_each(device_it, &ip_family->devices) {
        ip_device_t* device = amxc_htable_it_get_data(device_it, ip_device_t, it);
        const char* key = amxc_htable_it_get_key(&device->it);
        amxc_llist_for_each(addr_it, &device->addresses) {
            ip_address_t* ip_address = amxc_llist_it_get_data(addr_it, ip_address_t, it);
            if(ip_address->reachable) {
                ip_query->callback(key, ip_address->address, true, ip_query->userdata);
                when_null(ip_query->callback, exit);
            }
        }
    }

exit:
    return status;
}


//
// Device creation/destruction
//

static int s_device_subscribe(ip_device_t* device,
                              const char* path);
static int s_device_fetch_initial(ip_device_t* device,
                                  const char* path);

static ip_device_t* s_device_create(ip_family_t* family,
                                    const char* key,
                                    uint32_t index) {
    ip_device_t* device = NULL;
    amxc_string_t path;
    const char* path_str;
    char index_str[AMXC_INTEGER_UINT32_MAX_DIGITS];
    char* index_str_end = amxc_uint32_to_buf(index, index_str);

    amxc_string_init(&path, 0);

    when_null_trace(family, exit, ERROR, "NULL");
    when_str_empty_trace(family->objname, exit, ERROR, "NULL/empty string");
    when_str_empty_trace(key, exit, ERROR, "NULL/empty string");

    device = malloc(sizeof(ip_device_t));
    when_null_trace(device, exit, ERROR, "Out of memory");

    amxc_htable_it_init(&device->it);
    amxc_llist_init(&device->addresses);
    device->subscription = NULL;

    amxc_string_set(&path, "Devices.Device.");
    amxc_string_append(&path, index_str, index_str_end - index_str);
    amxc_string_append(&path, ".", 1);
    amxc_string_append(&path, family->objname, strlen(family->objname));
    amxc_string_append(&path, ".", 1);
    path_str = amxc_string_get(&path, 0);

    /* If the subscription fails, this device entry is useless and can not be recovered. */
    when_failed(s_device_subscribe(device, path_str), error);
    /* If, on the other hand, only the initial fetch fails, events are still
     * processed and the device entry is partially functional. Specific errors
     * are logged within s_device_fetch_initial. */
    when_failed(s_device_fetch_initial(device, path_str), exit);

    goto exit;

error:
    amxc_llist_clean(&device->addresses, s_address_cleanup);
    free(device);
    device = NULL;

exit:
    amxc_string_clean(&path);

    return device;
}

static void s_device_cleanup(UNUSED const char* key,
                             amxc_htable_it_t* it) {
    ip_device_t* device = amxc_htable_it_get_data(it, ip_device_t, it);

    when_null(it, exit);

    amxb_subscription_delete(&device->subscription);
    amxc_llist_clean(&device->addresses, s_address_cleanup);

    free(device);

exit:
    return;
}

static ip_family_t* s_device_get_family(ip_device_t* device) {
    ip_family_t* family = NULL;

    when_null(device, exit);
    when_null(device->it.ait, exit);
    when_null(device->it.ait->array, exit);

    family = amxc_container_of(amxc_container_of(device->it.ait->array,
                                                 amxc_htable_t,
                                                 table),
                               ip_family_t,
                               devices);
exit:
    return family;
}


//
// Device subscription and event handling
//

/**
 * @brief Searches a known ip address in the given device.
 *
 * @param device Only the address table of this device will be considered.
 * @param index if not `0`, find the ip_address_t with this data model index.
 */
static ip_address_t* s_device_find_address(ip_device_t* device,
                                           uint32_t index) {
    ip_address_t* ip_address = NULL;

    when_true_trace(index == 0u, exit, ERROR, "0 value on address lookup by index");

    amxc_llist_for_each(it, &device->addresses) {
        ip_address_t* entry_address = amxc_llist_it_get_data(it, ip_address_t, it);
        if(entry_address->index == index) {
            ip_address = entry_address;
            break;
        }
    }

exit:
    return ip_address;
}

static void s_device_modify_address(ip_family_t* family,
                                    const char* key,
                                    ip_address_t* ip_address,
                                    const char* new_address,
                                    int new_reachable) {
    bool reachable = ip_address->reachable;
    if(new_reachable >= 0) {
        reachable = new_reachable != 0;
    }

    if((new_address != NULL) && (strcmp(ip_address->address, new_address) != 0)) {
        /* The address of the entry has changed. This is highly unexpected,
         * but must still be handled gracefully.
         */
        char* dup_address = strdup(new_address);
        when_null_trace(dup_address, exit, ERROR, "Out of memory");

        if(ip_address->reachable) {
            /* Force unreachable. If new_reachable is unset(-1) or remains
             * reachable, this situation is fixed later and all query callbacks
             * are notified again.
             */
            ip_address->reachable = false;
            s_family_notify_address(family, key, ip_address);
        }

        free(ip_address->address);
        ip_address->address = dup_address;
    }

    if(ip_address->reachable != reachable) {
        ip_address->reachable = reachable;
        s_family_notify_address(family, key, ip_address);
    }

exit:
    return;
}

static void s_device_event_new_address(ip_family_t* family,
                                       ip_device_t* device,
                                       const amxc_var_t* const notif_data) {
    const char* key = amxc_htable_it_get_key(&device->it);
    const amxc_var_t* params = GET_ARG(notif_data, "parameters");
    uint32_t index = GET_UINT32(notif_data, "index");
    const char* address = GET_CHAR(params, "Address");
    const char* status = GET_CHAR(params, "Status");
    bool reachable;
    ip_address_t* ip_address;

    when_str_empty_trace(key, exit, ERROR, "BUG: unexpected event callback for loose device.");
    when_true_trace(index == 0, exit, ERROR, "Missing index in event");
    when_str_empty_trace(address, exit, ERROR, "Missing or empty address in event");
    when_str_empty_trace(status, exit, ERROR, "Missing or empty status in event");

    reachable = strcmp(status, GMAP_IP_STATUS_REACHABLE) == 0;
    ip_address = s_device_find_address(device, index);

    if(ip_address == NULL) {
        ip_address = s_address_create(index, address, reachable);
        when_null(ip_address, exit);
        amxc_llist_append(&device->addresses, &ip_address->it);
        if(reachable) {
            s_family_notify_address(family, key, ip_address);
        }
    } else {
        /* This can genuinely happen when a device is added with all ip addresses
         * already available. */
        SAH_TRACEZ_INFO(ME,
                        "Received instance-added for already known "
                        "ip address entry '%s' for device '%s' at index %" PRIu32 ".",
                        address, key, index);
        s_device_modify_address(family, key, ip_address, address, reachable ? 1 : 0);
    }

exit:
    return;
}

static void s_device_event_remove_address(ip_family_t* family,
                                          ip_device_t* device,
                                          const amxc_var_t* const notif_data) {
    const char* key = amxc_htable_it_get_key(&device->it);
    uint32_t index = GET_UINT32(notif_data, "index");
    ip_address_t* ip_address;

    when_str_empty_trace(key, exit, ERROR, "BUG: unexpected event callback for loose device.");
    when_true_trace(index == 0, exit, ERROR, "Missing index in event");

    ip_address = s_device_find_address(device, index);
    when_true(ip_address == NULL, exit);

    if(ip_address->reachable) {
        ip_address->reachable = false;
        s_family_notify_address(family, key, ip_address);
    }
    amxc_llist_it_clean(&ip_address->it, s_address_cleanup);

exit:
    return;
}

static void s_device_event_change_address(ip_family_t* family,
                                          ip_device_t* device,
                                          const amxc_var_t* const notif_data) {
    const char* key = amxc_htable_it_get_key(&device->it);
    const amxc_var_t* params = GET_ARG(notif_data, "parameters");
    const char* path = GET_CHAR(notif_data, "path");
    uint32_t index = gmap_ext_path_to_last_index(path);
    const char* address = GET_CHAR(GET_ARG(params, "Address"), "to");
    const char* status = GET_CHAR(GET_ARG(params, "Status"), "to");
    ip_address_t* ip_address;
    int reachable = -1;

    when_str_empty_trace(key, exit, ERROR, "BUG: unexpected event callback for loose device.");
    when_true_trace(index == 0, exit, ERROR, "Failed to derive index from event");
    when_true(address == NULL && status == NULL, exit); /* Don't react on changes to other parameters */

    if(status != NULL) {
        reachable = strcmp(status, GMAP_IP_STATUS_REACHABLE) == 0 ? 1 : 0;
    }

    ip_address = s_device_find_address(device, index);
    when_null_trace(ip_address, exit, ERROR,
                    "BUG: Received address modified event for unknown address "
                    "at index %" PRIu32 " of device '%s'.",
                    index, key);

    s_device_modify_address(family, key, ip_address, address, reachable);

exit:
    return;
}

static void s_device_event_cb(UNUSED const char* const sig_name,
                              const amxc_var_t* const notif_data,
                              void* const priv) {
    ip_device_t* device = priv;
    ip_family_t* family = s_device_get_family(device);
    const char* notification = GET_CHAR(notif_data, "notification");

    when_null_trace(notif_data, exit, ERROR, "NULL event");
    when_null_trace(device, exit, ERROR, "BUG: NULL device in event callback");
    when_null_trace(family, exit, ERROR, "BUG: NULL family for device");
    when_str_empty_trace(notification, exit, ERROR,
                         "BUG: device event callback called for released device.");

    if(0 == strcmp(notification, "dm:instance-added")) {
        s_device_event_new_address(family, device, notif_data);
    } else if(0 == strcmp(notification, "dm:instance-removed")) {
        s_device_event_remove_address(family, device, notif_data);
    } else if(0 == strcmp(notification, "dm:object-changed")) {
        s_device_event_change_address(family, device, notif_data);
    }

exit:
    return;
}

static int s_device_subscribe(ip_device_t* device,
                              const char* path) {
    /* Note: device is not added to the htable yet, so it doesn't have a key. */
    int status = -1;

    when_str_empty_trace(path, exit, ERROR, "NULL or empty path");

    status = amxb_subscription_new(&device->subscription,
                                   gmap_get_bus_ctx(), path,
                                   "notification in ['dm:instance-added', 'dm:instance-removed', 'dm:object-changed']",
                                   s_device_event_cb, device);
    when_failed_trace(status, exit, ERROR,
                      "Failed to subscribe to '%s': %d", path, status);

exit:
    return status;
}

static int s_device_fetch_initial(ip_device_t* device,
                                  const char* path) {
    /* Note: device is not added to the htable yet, so it doesn't have a key. */
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t ret;

    amxc_var_init(&ret);

    when_str_empty_trace(path, exit, ERROR, "NULL or empty path");

    status = amxb_get(gmap_get_bus_ctx(), path, 0, &ret, gmap_get_timeout());
    when_failed_trace(status, exit, ERROR,
                      "Failed to fetch known ip addresses for path '%s': %d",
                      path, status);

    /* Don't call any ipquery callbacks here. They are called by the ip_family
     * that created the device. */
    amxc_var_for_each(var, amxc_var_get_first(&ret)) {
        uint32_t index;
        const char* address;
        const char* ip_status;
        bool reachable;
        ip_address_t* ip_address;

        if(amxc_htable_is_empty(amxc_var_constcast(amxc_htable_t, var))) {
            /* Empty Devices.Device.[].IPv[46]Address. = {} */
            continue;
        }

        index = gmap_ext_path_to_last_index(amxc_var_key(var));
        address = GET_CHAR(var, "Address");
        ip_status = GET_CHAR(var, "Status");

        when_str_empty_trace(address, next, ERROR,
                             "Missing or empty address in initial fetched data");
        when_str_empty_trace(ip_status, next, ERROR,
                             "Missing or empty status in initial fetched data");

        reachable = strcmp(ip_status, GMAP_IP_STATUS_REACHABLE) == 0;

        ip_address = s_address_create(index, address, reachable);
        when_null(ip_address, next);
        amxc_llist_append(&device->addresses, &ip_address->it);
next:
        continue;
    }

exit:
    amxc_var_clean(&ret);
    return status;
}


//
// API implementation
//

void gmap_ipquery_cleanup(void) {
    s_family_destructor();
}

bool gmap_ipquery_new(gmap_ipquery_t** ipquery,
                      uint32_t family,
                      UNUSED const char* tag,
                      gmap_ipquery_cb_t callback,
                      void* userdata) {
    bool ret = false;
    ip_family_t* ip_family;
    /* Internal working pointer. This function will never read from *ipquery
     * in case it is modified by the callback function. */
    gmap_ipquery_t* ipquery_int = NULL;

    when_null_trace(ipquery, exit, ERROR, "NULL");
    *ipquery = NULL;
    when_null_trace(callback, exit, ERROR, "NULL");

    ipquery_int = malloc(sizeof(gmap_ipquery_t));
    when_null_trace(ipquery_int, exit, ERROR, "Out of memory");
    *ipquery = ipquery_int;

    amxc_llist_it_init(&ipquery_int->it);
    ipquery_int->defer_delete = true;
    ipquery_int->callback = callback;
    ipquery_int->userdata = userdata;

    ip_family = s_family_get_or_create(family);
    when_null_trace(ip_family, remove, ERROR,
                    "Couldn't fetch or create ip family object to add the query to");

    /* Also calls the query callback for any known active addresses. */
    when_failed(s_family_add_query(ip_family, ipquery_int), remove);

    ret = true;

    /* Callback is set to NULL when opening the query and the user requested
     * to delete it again. This is still considered as a successful operation.
     */
    when_null(ipquery_int->callback, remove);

    ipquery_int->defer_delete = false;
    goto exit;

remove:
    amxc_llist_it_take(&ipquery_int->it);
    free(ipquery_int);
    *ipquery = NULL;
    if((ip_family != NULL) && amxc_llist_is_empty(&ip_family->ipqueries)) {
        s_family_destroy(ip_family);
    }

exit:
    return ret;
}

void gmap_ipquery_delete(gmap_ipquery_t** ipquery) {
    ip_family_t* ip_family = NULL;

    when_null(ipquery, exit);
    when_null(*ipquery, exit);

    /* Delete called from within the ipquery callback during its creation or on
     * a location where we can't destroy the query or the family it belongs to.
     * Signal up the call stack that this callback is already deleted, but don't
     * reclaim the memory just yet.
     * The final free must be performed by whoever set this to true once we know
     * all dangling pointers to it within libgmap-ext have been removed and there
     * is no risk of double frees.
     */
    when_true_status((*ipquery)->defer_delete, exit, (*ipquery)->callback = NULL);

    if((*ipquery)->it.llist != NULL) {
        ip_family = amxc_container_of((*ipquery)->it.llist, ip_family_t, ipqueries);
        amxc_llist_it_take(&(*ipquery)->it);
        if(amxc_llist_is_empty(&ip_family->ipqueries)) {
            s_family_destroy(ip_family);
        }
    }
    free(*ipquery);
    *ipquery = NULL;

exit:
    return;
}
