/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "mock_netmodel.h"
#include "mib_ip.h"

#include <setjmp.h>
#include <cmocka.h>
#include <amxc/amxc.h>

#include <string.h>

#define STR_EMPTY(x) ((x == NULL) || (*x == '\0'))
#define STR_HAS_PREFIX(str, prefix) (strncmp(str, prefix, strlen(prefix)) == 0)

static bool ip_addresses_enabled(const char* ip_intf, bool ipv4) {
    amxc_var_t ret;
    amxc_var_t* matches = NULL;
    amxc_string_t search_path_str;
    const char* search_path = NULL;
    bool retval = false;

    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&search_path_str, 0);
    amxc_string_setf(&search_path_str, "IP.Interface.%s.IPv%dAddress.[Status == 'Enabled'].", ip_intf, ipv4 ? 4 : 6);
    search_path = amxc_string_get(&search_path_str, 0);

    assert_int_equal(amxb_get(netmodel_get_amxb_bus(), search_path, 0, &ret, 5), 0);

    matches = GETP_ARG(&ret, "0");
    retval = amxc_var_get_first(matches) != NULL;

    amxc_var_clean(&ret);
    amxc_string_clean(&search_path_str);
    return retval;
}

static void set_data(amxc_var_t* data, bool ipv4) {
    amxc_var_t* var = amxc_var_add_new(data);
    amxc_var_set_type(var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, var, "Address", ipv4 ? "192.168.1.1" : "2a02:1802:94:43b0::1");
    amxc_var_add_key(cstring_t, var, "Family", ipv4 ? "ipv4" : "ipv6");
    amxc_var_add_key(cstring_t, var, "Flags", "permanent");
    amxc_var_add_key(cstring_t, var, "NetDevName", "br-lan");
    amxc_var_add_key(cstring_t, var, "TypeFlags", ipv4 ? "@private" : "@gua");
    amxc_var_add_key(cstring_t, var, "NetModelIntf", "ip-lan");
    amxc_var_add_key(cstring_t, var, "NetModelIntf", "ip-lan");
}

amxd_status_t __wrap_amxd_trans_apply(amxd_trans_t* const trans, amxd_dm_t* const dm) {
    amxd_status_t status = amxd_status_unknown_error;
    char* path = NULL;
    bool ipv4 = false;
    bool status_changed = false;

    amxc_llist_for_each(it, (&trans->actions)) {
        amxd_trans_action_t* action = amxc_llist_it_get_data(it, amxd_trans_action_t, it);
        if(GET_CHAR(&action->data, "path") != NULL) {
            path = strdup(GET_CHAR(&action->data, "path"));
            ipv4 = strstr(path, "IPv4Address") != 0 ? true : false;
        } else if(GETP_CHAR(&action->data, "parameters.Status") != NULL) {
            status_changed = true;
        }
    }

    status = __real_amxd_trans_apply(trans, dm);

    // If a Status parameter changes for an IPv4Address or IPv6Address trigger the NetModel query directly
    if(!STR_EMPTY(path) && status_changed) {
        amxc_var_t data;
        amxc_var_init(&data);
        amxc_var_set_type(&data, AMXC_VAR_ID_LIST);

        if(ip_addresses_enabled("lan", ipv4)) {
            set_data(&data, ipv4);
        }

        ipaddress_cb_impl("NetModel.Intf.ip-lan.", &data, ipv4? "ipv4-up" : "ipv6-up");
        amxc_var_clean(&data);
    }

    free(path);
    return status;
}

netmodel_query_t* __wrap_netmodel_openQuery_getAddrs(const char* intf,
                                                     const char* subscriber,
                                                     const char* flag,
                                                     const char* traverse,
                                                     netmodel_callback_t handler,
                                                     void* userdata) {
    amxc_var_t data;
    bool ipv4 = false;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_LIST);

    assert_non_null(intf);
    assert_non_null(subscriber);
    assert_non_null(traverse);
    assert_non_null(handler);
    assert_true(strcmp(subscriber, "mib_ip") == 0);
    assert_true(strcmp(flag, "ipv4") == 0 || strcmp(flag, "ipv6") == 0);
    ipv4 = strcmp(flag, "ipv4") == 0;

    assert_true(STR_HAS_PREFIX(intf, "NetModel.Intf."));

    if((strcmp(intf, "NetModel.Intf.ip-lan.") == 0)) {
        if(ip_addresses_enabled("lan", ipv4)) {
            set_data(&data, ipv4);
        }
    } else {
        fail_msg("No known interface given: %s", intf);
    }

    handler("", &data, userdata);

    amxc_var_clean(&data);
    return malloc(sizeof(netmodel_query_t*));
}

void __wrap_netmodel_closeQuery(netmodel_query_t* query) {
    assert_non_null(query);
    free(query);
}