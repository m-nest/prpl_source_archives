/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <stdio.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_util.h>
#include <amxrt/amxrt.h>

#include "dmm.h"
#include "dmm_methods.h"

int test_setup(void** state) {
    amxut_bus_setup(state);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

void test_dmm_indexes_replace_strict(UNUSED void** state) {
    {
        char* templates[] = {
            "Foo.{i}.Bar.{i}.Buzz.{i}.",
            "Foo.{i}.Bar.{i}.Buzz.{i}.FooBar",
            "Foo.Bar.",
        };
        char* concrete[] = {
            "Foo.1.Bar.2.Buzz.3.",
            "Foo.1.Bar.2.Buzz.3.FooBar",
            "Foo.Bar.",
        };
        for(size_t i = 0; i != sizeof(templates) / sizeof(templates[0]); ++i) {
            char buf[MAX_PATH_LEN] = {0};
            snprintf(buf, MAX_PATH_LEN, "%s", templates[i]);
            char* result = dmm_indexes_replace_strict(buf, sizeof(buf), concrete[i]);
            assert_non_null(result);
            assert_string_equal(result, concrete[i]);
        }
    }
    {
        char* templates[] = {
            "Foo.{i}.Bar.Buzz.",
            "Foo.{i}.Bar.",
            "Foo.{i}.Bar.",
        };
        char* concrete[] = {
            "Foo.1.Bar.",
            "Foo.1.BarBuzz.",
            "Foo.Bar.",
        };
        for(size_t i = 0; i != sizeof(templates) / sizeof(templates[0]); ++i) {
            char buf[MAX_PATH_LEN] = {0};
            snprintf(buf, MAX_PATH_LEN, "%s", templates[i]);
            char* result = dmm_indexes_replace_strict(buf, sizeof(buf), concrete[i]);
            assert_null(result);
        }
    }
}

void test_dmm_indexes_replace(UNUSED void** state) {
    {
        char* templates[] = {
            "Foo.{i}.Bar.{i}.Buzz.{i}.",
            "Foo.{i}.Bar.{i}.Buzz.{i}.",
            "Foo.{i}.Bar.{i}.Buzz.{i}.FooBar",
            "Foo.Bar.",
            "Foo.{i}.BarBuzz.",
        };
        char* concrete[] = {
            "Foo.1.Bar.2.Buzz.3.",
            "Buzz.1.Bar.2.Foo.3.",
            "A.1.B.2.C.3.D",
            "Foo.Bar.",
            "Foo.1.Bar.",
        };
        char* result_paths[] = {
            "Foo.1.Bar.2.Buzz.3.",
            "Foo.1.Bar.2.Buzz.3.",
            "Foo.1.Bar.2.Buzz.3.FooBar",
            "Foo.Bar.",
            "Foo.1.BarBuzz.",
        };

        for(size_t i = 0; i != sizeof(templates) / sizeof(templates[0]); ++i) {
            char buf[MAX_PATH_LEN] = {0};
            snprintf(buf, MAX_PATH_LEN, "%s", templates[i]);
            char* result = dmm_indexes_replace(buf, sizeof(buf), concrete[i]);
            assert_non_null(result);
            assert_string_equal(result, result_paths[i]);
        }
    }
    {
        char* templates[] = {
            "Foo.{i}.Bar.Buzz.",
            "Foo.{i}.Bar.",
        };
        char* concrete[] = {
            "Foo.1.Bar.",
            "Foo.Bar.",
        };
        for(size_t i = 0; i != sizeof(templates) / sizeof(templates[0]); ++i) {
            char buf[MAX_PATH_LEN] = {0};
            snprintf(buf, MAX_PATH_LEN, "%s", templates[i]);
            char* result = dmm_indexes_replace(buf, sizeof(buf), concrete[i]);
            assert_null(result);
        }
    }
}

void test_dmm_build_supported_path(UNUSED void** state) {
    char* concrete[] = {
        "Foo.1.Bar.2.Buzz.3.",
        "Foo.1.Bar.2.Buzz.3.FooBar",
        "Foo.Bar.",
    };
    char* templates[] = {
        "Foo.{i}.Bar.{i}.Buzz.{i}.",
        "Foo.{i}.Bar.{i}.Buzz.{i}.FooBar",
        "Foo.Bar.",
    };
    for(size_t i = 0; i != sizeof(templates) / sizeof(templates[0]); ++i) {
        char* result = dmm_build_supported_path(concrete[i]);
        assert_non_null(result);
        assert_string_equal(result, templates[i]);
        free(result);
    }
}

static amxd_object_t* create_object(const char* name, amxd_object_t* parent) {
    amxd_object_t* object = NULL;
    assert_int_equal(amxd_object_new(&object, amxd_object_singleton, name), amxd_status_ok);
    assert_non_null(object);

    if(parent) {
        assert_int_equal(amxd_object_add_object(parent, object), amxd_status_ok);
    }
    return object;
}

amxd_dm_t* __wrap_dmm_get_dm() {
    return amxrt_get_dm();
}

void test_dmm_get_mapped_subpath(UNUSED void** state) {
    amxd_object_t* root = amxd_dm_get_root(amxrt_get_dm());

    amxd_object_t* wifi = create_object("WiFi", root);
    amxd_object_t* dataelements = create_object("DataElements", wifi);
    amxd_object_t* agent = create_object("Agent", dataelements);
    amxd_object_t* radio = create_object("Radio", wifi);

    char* paths[] = {
        "WiFi.Foo.",
        "WiFi.DataElements.",
        "WiFi.DataElements.Controller.",
        "WiFi.DataElements.Foo",
        "WiFi.DataElements.Agent.Foo.",
        "WiFi.Radio.Foo.Bar",
    };

    char* mapped_roots[] = {
        "WiFi.",
        "WiFi.DataElements.",
        "WiFi.DataElements.",
        "WiFi.DataElements.",
        "WiFi.DataElements.Agent.",
        "WiFi.Radio.",
    };

    const size_t n = sizeof(paths) / sizeof(paths[0]);

    for(size_t i = 0; i != n; ++i) {
        amxc_var_t in_path;
        amxc_var_init(&in_path);
        amxc_var_set(cstring_t, &in_path, paths[i]);
        char* result = dmm_get_mapped_subpath(&in_path);
        assert_non_null(result);
        assert_string_equal(result, mapped_roots[i]);
        free(result);
        amxc_var_clean(&in_path);
    }

    amxd_object_delete(&wifi);
}

void test_dmm_is_ret_dm_resp(UNUSED void** state) {

    // time response is used as an example of GSDM with several objects/subobjects
    // DM function being tested are indifferent to the root of the response, Time. was used as an example
    amxc_var_t* get_supported_dm_dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_gsdm.json");
    assert_non_null(get_supported_dm_dump);

    // Time. response is used as an example of GET with several objects/subobjects
    amxc_var_t* get_dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_get.json");
    assert_non_null(get_dump);

    assert_true(dmm_is_ret_dm_resp("Time.Client.{i}.", get_supported_dm_dump));
    assert_false(dmm_is_ret_dm_resp("Time.Server.1.Stats", get_dump));

    amxc_var_delete(&get_supported_dm_dump);
    amxc_var_delete(&get_dump);
}

void test_dmm_take_entity_by_path_in_dm_resp(UNUSED void** state) {
    // SoftwareModules. root was chosen as an object with functions, parameters and events
    const char* gsdm_dump = "../test/common/bus_responses/softwaremodules_gsdm.json";
    {
        amxc_var_t* get_supported_dm_dump = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(get_supported_dm_dump);

        assert_non_null(GET_ARG(get_supported_dm_dump, "SoftwareModules."));
        assert_int_equal(dmm_take_entity_by_path_in_dm_resp("SoftwareModules.", get_supported_dm_dump, NULL, true), 0);
        assert_null(GET_ARG(get_supported_dm_dump, "SoftwareModules."));

        amxc_var_delete(&get_supported_dm_dump);
    }
    {
        amxc_var_t* get_supported_dm_dump = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(get_supported_dm_dump);

        assert_string_equal(GETP_CHAR(get_supported_dm_dump, "'SoftwareModules.'.supported_params.0.param_name"), "ExecutionUnitNumberOfEntries");
        assert_int_equal(dmm_take_entity_by_path_in_dm_resp("SoftwareModules.ExecutionUnitNumberOfEntries", get_supported_dm_dump, NULL, true), 0);
        assert_string_not_equal(GETP_CHAR(get_supported_dm_dump, "'SoftwareModules.'.supported_params.0.param_name"), "ExecutionUnitNumberOfEntries");

        amxc_var_delete(&get_supported_dm_dump);
    }
    {
        amxc_var_t* get_supported_dm_dump = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(get_supported_dm_dump);

        assert_string_equal(GETP_CHAR(get_supported_dm_dump, "'SoftwareModules.'.supported_commands.0.command_name"), "InstallDU()");
        assert_int_equal(dmm_take_entity_by_path_in_dm_resp("SoftwareModules.InstallDU()", get_supported_dm_dump, NULL, true), 0);
        assert_string_not_equal(GETP_CHAR(get_supported_dm_dump, "'SoftwareModules.'.supported_commands.0.command_name"), "InstallDU()");

        amxc_var_delete(&get_supported_dm_dump);
    }
    {
        amxc_var_t* get_supported_dm_dump = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(get_supported_dm_dump);

        assert_non_null(GETP_ARG(get_supported_dm_dump, "'SoftwareModules.'.supported_events.DUStateChange!"));
        assert_int_equal(dmm_take_entity_by_path_in_dm_resp("SoftwareModules.DUStateChange!", get_supported_dm_dump, NULL, true), 0);
        assert_null(GETP_ARG(get_supported_dm_dump, "'SoftwareModules.'.supported_events.DUStateChange!"));

        amxc_var_delete(&get_supported_dm_dump);
    }
}

void test_dmm_take_entity_by_path(UNUSED void** state) {

    const char* gsdm_dump = "../test/common/bus_responses/time_get.json";
    {
        amxc_var_t* resp = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(resp);

        assert_non_null(GET_ARG(resp, "Time."));
        assert_int_equal(dmm_take_entity_by_path("Time.", resp, NULL, true), 0);
        assert_null(GET_ARG(resp, "Time."));

        amxc_var_delete(&resp);
    }
    {
        amxc_var_t* resp = amxut_util_read_json_from_file(gsdm_dump);
        assert_non_null(resp);

        assert_non_null(GETP_ARG(resp, "'Time.'.Enable"));
        assert_int_equal(dmm_take_entity_by_path("Time.Enable", resp, NULL, true), 0);
        assert_null(GETP_ARG(resp, "'Time.'.Enable"));

        amxc_var_delete(&resp);
    }
}

void test_dmm_remove_entity_by_template(UNUSED void** state) {
    const char* dump = "../test/common/bus_responses/time_get.json";

    amxc_var_t* resp = amxut_util_read_json_from_file(dump);
    assert_non_null(resp);

    assert_non_null(GET_ARG(resp, "Time.Server.1."));
    assert_non_null(GET_ARG(resp, "Time.Server.2."));
    assert_non_null(GET_ARG(resp, "Time.Server.3."));

    dmm_remove_entity_by_template("Time.Server.{i}.", resp);

    assert_null(GET_ARG(resp, "Time.Server.1."));
    assert_null(GET_ARG(resp, "Time.Server.2."));
    assert_null(GET_ARG(resp, "Time.Server.3."));

    amxc_var_delete(&resp);
}

void test_dmm_hide_proc(UNUSED void** state) {
    amxd_object_t* root = amxd_dm_get_root(amxrt_get_dm());
    amxd_object_t* time = create_object("Time", root);

    assert_int_equal(amxc_llist_new((amxc_llist_t**) &hide_po_list), 0);
    amxc_var_t time_client;
    amxc_var_init(&time_client);
    amxc_var_set(cstring_t, &time_client, "Time.Client.{i}.");
    amxc_llist_append((amxc_llist_t*) hide_po_list, &time_client.lit);

    {
        map_info_t minfo;
        minfo.ds_rq_type = DMM_GET_SUPPORTED;
        amxc_var_init(&minfo.ret);

        amxc_var_t* dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_gsdm.json");
        assert_non_null(dump);
        amxc_var_move(&minfo.ret, dump);
        amxc_var_delete(&dump);
        dump = &minfo.ret;

        assert_non_null(GET_ARG(dump, "Time.Client.{i}."));
        assert_non_null(GET_ARG(dump, "Time.Client.{i}.Authentication."));
        assert_non_null(GET_ARG(dump, "Time.Client.{i}.Stats."));

        assert_int_equal(dmm_hide_proc(&minfo), 0);

        assert_null(GET_ARG(dump, "Time.Client.{i}."));
        assert_null(GET_ARG(dump, "Time.Client.{i}.Authentication."));
        assert_null(GET_ARG(dump, "Time.Client.{i}.Stats."));

        amxc_var_clean(dump);
    }

    {
        map_info_t minfo;
        minfo.ds_rq_type = DMM_GET;
        amxc_var_init(&minfo.ret);

        amxc_var_t* dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_get.json");
        assert_non_null(dump);
        amxc_var_move(&minfo.ret, dump);
        amxc_var_delete(&dump);
        dump = &minfo.ret;

        assert_non_null(GET_ARG(dump, "Time.Client.1."));
        assert_non_null(GET_ARG(dump, "Time.Client.1.Authentication."));
        assert_non_null(GET_ARG(dump, "Time.Client.1.Stats."));

        assert_int_equal(dmm_hide_proc(&minfo), 0);

        assert_null(GET_ARG(dump, "Time.Client.1."));
        assert_null(GET_ARG(dump, "Time.Client.1.Authentication."));
        assert_null(GET_ARG(dump, "Time.Client.1.Stats."));

        amxc_var_clean(dump);
    }

    amxc_var_clean(&time_client);
    amxc_llist_delete((amxc_llist_t**) &hide_po_list, NULL);
    amxd_object_delete(&time);
}

void test_dmm_move_entity_by_path_object(UNUSED void** state) {
    const char* dump = "../test/common/bus_responses/time_get.json";

    amxc_var_t* resp = amxut_util_read_json_from_file(dump);
    assert_non_null(resp);

    assert_non_null(GET_ARG(resp, "Time.Server.1."));
    assert_non_null(GET_ARG(resp, "Time.Server.2."));
    assert_non_null(GET_ARG(resp, "Time.Server.3."));
    assert_null(GET_ARG(resp, "Time.Foo.1."));
    assert_null(GET_ARG(resp, "Time.Foo.2."));
    assert_null(GET_ARG(resp, "Time.Foo.3."));

    assert_int_equal(dmm_move_entity_by_path("Time.Server.{i}.", "Time.Foo.{i}.", resp), 0);

    assert_non_null(GET_ARG(resp, "Time.Foo.1."));
    assert_non_null(GET_ARG(resp, "Time.Foo.2."));
    assert_non_null(GET_ARG(resp, "Time.Foo.3."));
    assert_null(GET_ARG(resp, "Time.Server.1."));
    assert_null(GET_ARG(resp, "Time.Server.2."));
    assert_null(GET_ARG(resp, "Time.Server.3."));

    amxc_var_delete(&resp);
}
void test_dmm_move_entity_by_path_parameter(UNUSED void** state) {
    const char* dump = "../test/common/bus_responses/time_get.json";

    amxc_var_t* resp = amxut_util_read_json_from_file(dump);
    assert_non_null(resp);

    assert_non_null(GETP_ARG(resp, "'Time.Server.1.'.Port"));
    assert_non_null(GETP_ARG(resp, "'Time.Server.2.'.Port"));
    assert_non_null(GETP_ARG(resp, "'Time.Server.3.'.Port"));
    assert_null(GETP_ARG(resp, "'Time.Server.1.'.Bar"));
    assert_null(GETP_ARG(resp, "'Time.Server.2.'.Bar"));
    assert_null(GETP_ARG(resp, "'Time.Server.3.'.Bar"));

    assert_int_equal(dmm_move_entity_by_path("Time.Server.{i}.Port", "Time.Server.{i}.Bar", resp), 0);

    assert_non_null(GETP_ARG(resp, "'Time.Server.1.'.Bar"));
    assert_non_null(GETP_ARG(resp, "'Time.Server.2.'.Bar"));
    assert_non_null(GETP_ARG(resp, "'Time.Server.3.'.Bar"));
    assert_null(GETP_ARG(resp, "'Time.Server.1.'.Port"));
    assert_null(GETP_ARG(resp, "'Time.Server.2.'.Port"));
    assert_null(GETP_ARG(resp, "'Time.Server.3.'.Port"));

    amxc_var_delete(&resp);
}

void test_dmm_move_entity_by_path_in_dm_resp_object(UNUSED void** state) {
    const char* dump = "../test/common/bus_responses/time_gsdm.json";

    amxc_var_t* resp = amxut_util_read_json_from_file(dump);
    assert_non_null(resp);

    assert_non_null(GET_ARG(resp, "Time.Client.{i}."));
    assert_null(GET_ARG(resp, "Time.Foo.{i}."));

    assert_int_equal(dmm_move_entity_by_path_in_dm_resp("Time.Client.{i}.", "Time.Foo.{i}.", resp), 0);

    assert_non_null(GET_ARG(resp, "Time.Foo.{i}."));
    assert_null(GET_ARG(resp, "Time.Client.{i}."));

    amxc_var_delete(&resp);
}
void test_dmm_move_entity_by_path_in_dm_resp_param(UNUSED void** state) {
    const char* dump = "../test/common/bus_responses/time_gsdm.json";

    amxc_var_t* resp = amxut_util_read_json_from_file(dump);
    assert_non_null(resp);

    assert_string_equal(GETP_CHAR(resp, "'Time.Client.{i}.'.supported_params.0.param_name"), "Port");

    assert_int_equal(dmm_move_entity_by_path_in_dm_resp("Time.Client.{i}.Port", "Time.Client.{i}.Bar", resp), 0);

    assert_string_equal(GETP_CHAR(resp, "'Time.Client.{i}.'.supported_params.0.param_name"), "Bar");

    amxc_var_delete(&resp);
}

void test_dmm_rename_proc(UNUSED void** state) {
    assert_int_equal(amxc_var_new(&rename_po), 0);
    assert_int_equal(amxc_var_set_type(rename_po, AMXC_VAR_ID_HTABLE), 0);
    assert_non_null(amxc_var_add_key(cstring_t, rename_po, "Time.Client.{i}.", "Time.Foo.{i}."));

    amxd_object_t* root = amxd_dm_get_root(amxrt_get_dm());
    amxd_object_t* time = create_object("Time", root);

    {
        map_info_t minfo;
        minfo.ds_rq_type = DMM_GET_SUPPORTED;
        amxc_var_init(&minfo.ret);

        amxc_var_t* dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_gsdm.json");
        assert_non_null(dump);
        amxc_var_move(&minfo.ret, dump);
        amxc_var_delete(&dump);
        dump = &minfo.ret;

        assert_non_null(GET_ARG(dump, "Time.Client.{i}."));
        assert_null(GET_ARG(dump, "Time.Foo.{i}."));

        assert_int_equal(dmm_rename_proc(&minfo), 0);
        assert_null(GET_ARG(dump, "Time.Client.{i}."));
        assert_non_null(GET_ARG(dump, "Time.Foo.{i}."));

        amxc_var_clean(dump);
    }
    {
        map_info_t minfo;
        minfo.ds_rq_type = DMM_GET;
        amxc_var_init(&minfo.ret);

        amxc_var_t* dump = amxut_util_read_json_from_file("../test/common/bus_responses/time_get.json");
        assert_non_null(dump);
        amxc_var_move(&minfo.ret, dump);
        amxc_var_delete(&dump);
        dump = &minfo.ret;

        assert_non_null(GET_ARG(dump, "Time.Client.1."));
        assert_non_null(GET_ARG(dump, "Time.Client.1.Authentication."));
        assert_non_null(GET_ARG(dump, "Time.Client.1.Stats."));

        assert_null(GET_ARG(dump, "Time.Foo.1."));
        assert_null(GET_ARG(dump, "Time.Foo.1.Authentication."));
        assert_null(GET_ARG(dump, "Time.Foo.1.Stats."));

        assert_int_equal(dmm_rename_proc(&minfo), 0);

        assert_non_null(GET_ARG(dump, "Time.Foo.1."));
        assert_non_null(GET_ARG(dump, "Time.Foo.1.Authentication."));
        assert_non_null(GET_ARG(dump, "Time.Foo.1.Stats."));

        assert_null(GET_ARG(dump, "Time.Client.1."));
        assert_null(GET_ARG(dump, "Time.Client.1.Authentication."));
        assert_null(GET_ARG(dump, "Time.Client.1.Stats."));

        amxc_var_clean(dump);
    }

    amxd_object_delete(&time);
    amxc_var_delete(&rename_po);
}



int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_dmm_indexes_replace_strict),
        cmocka_unit_test(test_dmm_indexes_replace),
        cmocka_unit_test(test_dmm_build_supported_path),
        cmocka_unit_test(test_dmm_get_mapped_subpath),
        cmocka_unit_test(test_dmm_is_ret_dm_resp),
        cmocka_unit_test(test_dmm_take_entity_by_path_in_dm_resp),
        cmocka_unit_test(test_dmm_take_entity_by_path),
        cmocka_unit_test(test_dmm_remove_entity_by_template),
        cmocka_unit_test(test_dmm_hide_proc),
        cmocka_unit_test(test_dmm_move_entity_by_path_object),
        cmocka_unit_test(test_dmm_move_entity_by_path_parameter),
        cmocka_unit_test(test_dmm_move_entity_by_path_in_dm_resp_object),
        cmocka_unit_test(test_dmm_move_entity_by_path_in_dm_resp_param),
        cmocka_unit_test(test_dmm_rename_proc)
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);

}
