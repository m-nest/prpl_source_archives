/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __CONNTRACKINGQUERY_H__
#define __CONNTRACKINGQUERY_H__

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <amxc/amxc.h>
#include <amxc/amxc_common.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxb/amxb_types.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <amxb/amxb_be_intf.h>
#include <amxb/amxb.h>
#include <amxb/amxb_register.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxm/amxm.h>
#include <amxd/amxd_function.h>
#include "conntrackingquery_common.h"

#define ME "conntracking_query"

#define MAX_NR_OF_PROTOCOLS       2
#define MAX_NR_OF_PORTS           4
#define MAX_NOTIFY_QUERIES 16
#define CT_DEF_FILENAME      "/tmp/ct_retrieve_default.txt"
#define MAX_NOTIFY_RECORDS       40
#define MAX_NOTIFY_RECORD_SIZE   160
#define MAX_CT_LINE_LENGTH 256
#define MAX_NUM_ENTRIES 256
#define SIZE_PER_ENTRY  256

/**
 * @brief Structure representing the retrieve flow contrack entries
 *
 * This structure holds attributes for representing the tuple and other statistics
 */
typedef struct {
    bool enable;                  /**< Flag to enable or disable the query application. */
    amxd_dm_t* dm;                /**< Pointer to the data model. */
    amxo_parser_t* parser;        /**< Pointer to the parser instance. */
} conntrackingquery_app_t;


/**
 * @brief Structure representing the query object that will be formed
 *
 * This structure holds attributes for representing the tuple filter, event and the subprocess ids
 */
typedef struct  {
    amxd_object_t* object;        /**< Pointer to the associated data model object. */
    amxc_llist_it_t it;           /**< Iterator for linked list traversal. */
    uint32_t index;               /**< Index of the query object. */
    amxc_string_t name;           /**< Name of the query object. */
    amxp_subproc_t* process;      /**< Pointer to the subprocess handling the query. */
    uint32_t notify_time;         /**< Time interval for sending notifications. */
    uint32_t last_change;         /**< Timestamp of the last change detected. */
    amxc_string_t protocol;       /**< Protocol used (e.g., TCP, UDP). */
    amxc_string_t src_ip;         /**< Source IP address. */
    amxc_string_t dst_ip;         /**< Destination IP address. */
    amxc_string_t src_port;       /**< Source port number. */
    amxc_string_t dst_port;       /**< Destination port number. */
    amxc_string_t event;          /**< Event type associated with the query. */
} query_t;


/**
 * @brief Structure representing the retrieve flow contrack entries
 *
 * This structure holds attributes for representing the tuple and other statistics
 */

typedef struct {
    char src[INET6_ADDRSTRLEN];   /**< Source IP address. */
    char dst[INET6_ADDRSTRLEN];   /**< Destination IP address. */
    char proto[8];                /**< Protocol type (e.g., TCP, UDP). */
    char sport[8];                /**< Source port number. */
    char dport[8];                /**< Destination port number. */
    uint32_t o_packets;           /**< Number of outgoing packets. */
    uint32_t o_bytes;             /**< Number of outgoing bytes. */
    uint32_t r_packets;           /**< Number of return packets. */
    uint32_t r_bytes;             /**< Number of return bytes. */
} Record;

amxd_object_t* query_template(amxd_dm_t* dm);
amxd_dm_t* query_get_dm (void);
void query_create_unix_socket (void);
void query_destroy_unix_socket (void);
void query_signal_register (void);

extern unsigned int no_of_notify_queries;

/* query utilities */
query_t* query_create(amxd_object_t* object);
void query_delete(query_t* query);
query_t* query_find_by_name(const char* name);
query_t* query_find_by_pid(pid_t pid);
query_t* query_find_by_index(const uint32_t index);
int get_system_uptime(void);
bool query_set_address(query_t* query, const char* ip_address, bool source);
bool query_set_protocol(query_t* query, const char* protocol);
bool validate_port_range(const char* port_str);
bool query_set_port(query_t* query, const char* ports_str, bool source);
bool query_set_event_filter(query_t* query, const char* event_filter);
int query_cleanup(amxd_object_t* templ, amxd_object_t* instance, void* priv);
void query_set_conntrack_cache_path (query_t* query);
const char* object_da_string(amxd_object_t* const object, const char* name);

/* Worker interface */
bool stop_notify_query_worker (query_t* query);
bool start_notify_query_worker(query_t* query);


void _conntrack_query_start(const char* const sig_name, const amxc_var_t* const event_data, void* const priv);
void _conntrack_query_stop(const char* const sig_name, const amxc_var_t* const event_data, void* const priv);
int _connectiontrackingquery_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

amxd_status_t _check_max_instances(amxd_object_t* object, amxd_param_t* param,
                                   amxd_action_t reason, const amxc_var_t* const args,
                                   amxc_var_t* const retval, void* priv);

amxd_status_t _query_check_IP(amxd_object_t* object, amxd_param_t* param,
                              amxd_action_t reason, const amxc_var_t* const args,
                              amxc_var_t* const retval, void* priv);

amxd_status_t _query_check_protocol(amxd_object_t* object, amxd_param_t* param,
                                    amxd_action_t reason, const amxc_var_t* const args,
                                    amxc_var_t* const retval, void* priv);


amxd_status_t _query_check_port(amxd_object_t* object, amxd_param_t* param,
                                amxd_action_t reason, const amxc_var_t* const args,
                                amxc_var_t* const retval, void* priv);


amxd_status_t _query_check_event_filter(amxd_object_t* object, amxd_param_t* param,
                                        amxd_action_t reason, const amxc_var_t* const args,
                                        amxc_var_t* const retval, void* priv);

amxd_status_t _query_instance_cleanup(amxd_object_t* object, amxd_param_t* param, amxd_action_t reason,
                                      const amxc_var_t* const args, amxc_var_t* const retval,
                                      void* priv);


void _conntrack_notifyflow_query_added (const char* const sig_name, const amxc_var_t* const event_data, void* const priv);


amxd_status_t _ConnectionTrackingQuery_RetrieveFlows(amxd_object_t* object,
                                                     amxd_function_t* func,
                                                     amxc_var_t* args,
                                                     amxc_var_t* ret);

int check_ip_type(const char* ip);
void process_sock_event(int fd);
int unix_socket_init(void);

#endif
