/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <amxc/amxc_macros.h>
#include <amxut/amxut_util.h>

#include "mock_amxb.h"

// internal variable
static amxb_bus_ctx_t bus = {0};

// Function
// wrapper

extern int __real_amxb_subscription_new(amxb_subscription_t** subscription,
                                        amxb_bus_ctx_t* bus_ctx,
                                        const char* object,
                                        const char* expression,
                                        amxp_slot_fn_t slot_cb,
                                        void* priv);

amxb_bus_ctx_t* __wrap_amxb_be_who_has(const char* path) {
    assert_non_null(path);
    return &bus;
}

int __wrap_amxb_subscription_new(UNUSED amxb_subscription_t** subscription,
                                 UNUSED amxb_bus_ctx_t* bus_ctx,
                                 const char* object,
                                 const char* expression,
                                 amxp_slot_fn_t slot_cb,
                                 void* priv) {

    assert_string_equal(object, "Device.Hosts.Host.");
    assert_string_equal(expression, "notification in ['dm:instance-added', 'dm:instance-removed', 'dm:object-changed'] && path matches 'Device\\.Hosts\\.Host\\.[0-9]+\\.IPv4Address\\.$' && contains('parameters.IPAddress') && parameters.IPAddress == '192.168.1.3'");
    assert_non_null(slot_cb);
    assert_string_equal((char*) priv, "private_data");

    __real_amxb_subscription_new(subscription,
                                 bus_ctx,
                                 object,
                                 expression,
                                 slot_cb,
                                 priv);

    return 1;
}

int __wrap_amxb_get(UNUSED amxb_bus_ctx_t* const bus_ctx,
                    UNUSED const char* object,
                    UNUSED int32_t depth,
                    UNUSED amxc_var_t* ret,
                    UNUSED int timeout) {
    amxc_var_t* data = NULL;
    data = amxut_util_read_json_from_file("test_data/hosts.json");
    amxc_var_copy(ret, data);
    amxc_var_delete(&data);
    return 0;
}
