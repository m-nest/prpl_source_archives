/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_upnp_service.h"
#include "../common/dummy.h"
#include "gmap-mod-upnp.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object_event.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <amxo/amxo_mibs.h>

#include <gmap/gmap.h>


/**********************************************************
* Variable declarations
**********************************************************/
static amxb_bus_ctx_t* bus_ctx = NULL;

amxd_status_t _get(AMXB_UNUSED amxd_object_t* object,
                   AMXB_UNUSED amxd_function_t* func,
                   AMXB_UNUSED amxc_var_t* args,
                   AMXB_UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

amxd_status_t _createDevice(AMXB_UNUSED amxd_object_t* object,
                            AMXB_UNUSED amxd_function_t* func,
                            amxc_var_t* args,
                            AMXB_UNUSED amxc_var_t* ret) {
    int status = 0;
    amxc_var_t params;

    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &params, "Alias", GET_CHAR(args, "key"));
    amxc_var_add_key(cstring_t, &params, "Tags", GET_CHAR(args, "tags"));
    status = amxb_add(bus_ctx, "Devices.Device.", 0, NULL, &params, NULL, gmap_get_timeout());

    amxc_var_clean(&params);
    return status == 0 ? amxd_status_ok : amxd_status_unknown_error;
}

amxd_status_t _destroyDevice(AMXB_UNUSED amxd_object_t* object,
                             AMXB_UNUSED amxd_function_t* func,
                             amxc_var_t* args,
                             AMXB_UNUSED amxc_var_t* ret) {
    int status = 0;

    status = amxb_del(bus_ctx, "Devices.Device.", 0, GET_CHAR(args, "key"), NULL, gmap_get_timeout());

    return status == 0 ? amxd_status_ok : amxd_status_unknown_error;
}

amxd_status_t _linkAdd(AMXB_UNUSED amxd_object_t* object,
                       AMXB_UNUSED amxd_function_t* func,
                       amxc_var_t* args,
                       AMXB_UNUSED amxc_var_t* ret) {
    const char* uname = GET_CHAR(args, "upper_device");
    const char* lname = GET_CHAR(args, "lower_device");
    const char* type = GET_CHAR(args, "type");
    amxd_dm_t* dm = test_get_dm();
    amxc_var_t* u_gmap = NULL;
    amxc_var_t* l_gmap = NULL;
    amxd_object_t* udev = amxd_dm_findf(dm, "Devices.Device.%s.LDevice.%s.", uname, lname);
    amxd_object_t* ldev = amxd_dm_findf(dm, "Devices.Device.%s.UDevice.%s.", lname, uname);

    u_gmap = gmap_device_get(uname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    l_gmap = gmap_device_get(lname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    assert_non_null(u_gmap);
    assert_non_null(l_gmap);

    if(!udev) {
        amxc_var_t values;
        amxc_var_init(&values);
        amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &values, "Alias", lname);
        amxc_var_add_key(cstring_t, &values, "Type", type);

        gmap_add_instance(uname, "LDevice", &values);

        amxc_var_clean(&values);
    }
    if(!ldev) {
        amxc_var_t values;
        amxc_var_init(&values);
        amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &values, "Alias", uname);
        amxc_var_add_key(cstring_t, &values, "Type", type);

        gmap_add_instance(lname, "UDevice", &values);

        amxc_var_clean(&values);
    }

    amxc_var_delete(&u_gmap);
    amxc_var_delete(&l_gmap);
    return amxd_status_ok;
}

amxd_status_t _linkRemove(AMXB_UNUSED amxd_object_t* object,
                          AMXB_UNUSED amxd_function_t* func,
                          amxc_var_t* args,
                          AMXB_UNUSED amxc_var_t* ret) {
    const char* uname = GET_CHAR(args, "upper_device");
    const char* lname = GET_CHAR(args, "lower_device");
    amxd_dm_t* dm = test_get_dm();
    amxc_var_t* u_gmap = NULL;
    amxc_var_t* l_gmap = NULL;
    amxd_object_t* udev = amxd_dm_findf(dm, "Devices.Device.%s.LDevice.%s.", uname, lname);
    amxd_object_t* ldev = amxd_dm_findf(dm, "Devices.Device.%s.UDevice.%s.", lname, uname);

    u_gmap = gmap_device_get(uname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    l_gmap = gmap_device_get(lname, GMAP_NO_DETAILS | GMAP_NO_ACTIONS);
    assert_non_null(u_gmap);
    assert_non_null(l_gmap);

    if(udev) {
        int index = amxd_object_get_index(udev);
        gmap_delete_instance(uname, "LDevice", index);
    }
    if(ldev) {
        int index = amxd_object_get_index(ldev);
        gmap_delete_instance(lname, "UDevice", index);
    }

    amxc_var_delete(&u_gmap);
    amxc_var_delete(&l_gmap);
    return amxd_status_ok;
}

amxd_status_t _topology(amxd_object_t* object,
                        AMXB_UNUSED amxd_function_t* func,
                        AMXB_UNUSED amxc_var_t* args,
                        amxc_var_t* ret) {
    /* amxc_var_t topo;
       amxc_var_init(&topo);

       amxc_var_set_type(&topo, AMXC_VAR_ID_HTABLE); */
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    amxd_object_get_params(object, ret, amxd_dm_access_public);

    amxd_object_t* udevs = amxd_object_findf(object, "UDevice");
    amxd_object_t* ldevs = amxd_object_findf(object, "LDevice");

    amxc_var_t* ulist = amxc_var_add_key(amxc_llist_t, ret, "UDevice", NULL);
    amxc_var_t* llist = amxc_var_add_key(amxc_llist_t, ret, "LDevice", NULL);

    amxd_object_for_each(instance, it, udevs) {
        amxd_object_t* data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_t params;
        amxc_var_init(&params);
        amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

        amxd_object_get_params(data, &params, amxd_dm_access_public);
        amxc_var_add(amxc_htable_t, ulist, amxc_var_constcast(amxc_htable_t, &params));

        amxc_var_clean(&params);
    }

    amxd_object_for_each(instance, it, ldevs) {
        amxd_object_t* data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_t params;
        amxc_var_init(&params);
        amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

        amxd_object_get_params(data, &params, amxd_dm_access_public);
        amxc_var_add(amxc_htable_t, llist, amxc_var_constcast(amxc_htable_t, &params));

        amxc_var_clean(&params);
    }

    //amxc_var_add(amxc_htable_t, ret, amxc_var_constcast(amxc_htable_t, &topo));

    //amxc_var_clean(&topo);
    return amxd_status_ok;
}

amxd_status_t _find(amxd_object_t* object,
                    AMXB_UNUSED amxd_function_t* func,
                    amxc_var_t* args,
                    amxc_var_t* ret) {
    amxc_var_t dev_list;
    amxd_object_t* device = amxd_object_get_child(object, "Device");
    const char* expression = GETP_CHAR(args, "expression");

    amxc_var_init(&dev_list);
    amxc_var_set_type(&dev_list, AMXC_VAR_ID_LIST);
    amxc_var_set_type(ret, AMXC_VAR_ID_LIST);

    amxd_object_for_each(instance, it, device) {
        const char* dev_name = NULL;
        const char* ip = NULL;
        amxc_var_t params;
        amxd_object_t* data = NULL;

        amxc_var_init(&params);

        data = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxd_object_get_params(data, &params, amxd_dm_access_public);

        dev_name = GETP_CHAR(&params, "Alias");
        ip = GETP_CHAR(&params, "IPAddress");

        if((ip != NULL) && (ip[0] != '\0') && strstr(expression, "IPv")) {
            if(strstr(expression, ip) != NULL) {
                amxc_var_add(cstring_t, ret, dev_name);
            }
        } else if(strstr(expression, dev_name) != NULL) {
            amxc_var_t devices;
            amxc_string_t service_id;
            amxc_string_t expr;

            amxc_var_init(&devices);
            amxc_string_init(&service_id, 0);
            amxc_string_init(&expr, 0);

            amxc_string_set(&service_id, expression);

            amxc_string_replace(&service_id, dev_name, "", 1);
            amxc_string_replace(&service_id, ".Key == \"\" and has_instance(\"Service\", \".ServiceId ^= '", "", 1);
            amxc_string_replace(&service_id, "'\")", "", 1);
            amxc_string_replace(&service_id, "'\")", "", 1);

            amxc_string_setf(&expr, "Devices.Device.%s.Service.[ServiceId == '%s'].", dev_name, amxc_string_get(&service_id, 0));
            printf("\n%s\n", amxc_string_get(&expr, 0));

            amxb_get(bus_ctx, amxc_string_get(&expr, 0), 0, &devices, gmap_get_timeout());

            if(amxc_llist_size(amxc_var_constcast(amxc_llist_t, GETI_ARG(&devices, 0))) != 0) {
                amxc_var_add(cstring_t, &dev_list, dev_name);
            }

            amxc_var_clean(&devices);
            amxc_string_clean(&service_id);
            amxc_string_clean(&expr);
        }
        amxc_var_clean(&params);
    }

    if(!amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, &dev_list))) {
        amxc_var_add(amxc_llist_t, ret, amxc_var_constcast(amxc_llist_t, &dev_list));
    }

    amxc_var_clean(&dev_list);
    return amxd_status_ok;
}

bool __wrap_gmap_query_open_ext_2(gmap_query_t** query,
                                  const char* expression,
                                  UNUSED const char* name,
                                  UNUSED gmap_query_flags_t flags,
                                  UNUSED gmap_query_cb_t fn,
                                  UNUSED void* user_data) {
    assert_non_null(query);
    check_expected(expression);

    *query = NULL;
    return false;
}

static void load_mib_module() {
    amxo_parser_t* parser = test_get_parser();
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* dev = NULL;

    assert_int_equal(amxo_parser_scan_mib_dir(parser, "../common"), 0);
    assert_int_equal(amxo_parser_load_mib(parser, dm, "upnpDev"), 0);

    // As the mib itself adds the devices, the mib cant be added for a specific device
    // Thus the mib is added for Devices.Device.
    dev = amxd_dm_findf(dm, "Devices.Device.");
    assert_non_null(dev);
    amxo_parser_apply_mib(parser, dev, "upnpDev");

}

int test_mod_upnp_setup(AMXB_UNUSED void** state) {
    amxc_var_t* var = NULL;

    assert_int_equal(test_register_dummy(), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    gmap_client_init(bus_ctx);

    /* do not load import so files */
    var = amxo_parser_claim_config(test_get_parser(), "odl-import");
    amxc_var_set(bool, var, false);

    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "get", AMXO_FUNC(_get)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "createDevice", AMXO_FUNC(_createDevice)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "destroyDevice", AMXO_FUNC(_destroyDevice)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "linkAdd", AMXO_FUNC(_linkAdd)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "linkRemove", AMXO_FUNC(_linkRemove)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "topology", AMXO_FUNC(_topology)), 0);
    assert_int_equal(amxo_resolver_ftab_add(test_get_parser(), "find", AMXO_FUNC(_find)), 0);

    assert_int_equal(test_load_dummy_remote("../common/dummy_upnpdis.odl"), 0);
    assert_int_equal(test_load_dummy_remote("../common/dummy_upnp.odl"), 0);
    assert_int_equal(test_load_dummy_remote("../common/dummy_gmap.odl"), 0);

    load_mib_module();

    handle_events();

    assert_int_equal(_gmap_upnp_main(0, test_get_dm(), test_get_parser()), 0);

    handle_events();

    return amxd_status_ok;
}

int test_mod_upnp_teardown(AMXB_UNUSED void** state) {
    assert_int_equal(_gmap_upnp_main(1, test_get_dm(), test_get_parser()), 0);

    amxb_disconnect(bus_ctx);
    amxb_free(&bus_ctx);
    assert_int_equal(test_unregister_dummy(), 0);

    return amxd_status_ok;
}

void test_mod_upnp_adds_existing_devices(UNUSED void** state) {
    /*
        The upnpDev mib should add a Device and a Device.Service instance,
        for each upnp DeviceInstance and DeviceService.
        This tests checks that those instances exist and contain the correct parameters.
     */
    const char* name = "UPnP-1";
    const char* udn = NULL;
    const char* manu = NULL;
    const char* service_id = NULL;
    amxc_var_t param;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* upnp_obj = NULL;
    amxd_object_t* upnp_obj_service = NULL;
    amxd_object_t* gmap_obj = NULL;
    amxd_object_t* gmap_obj_service = NULL;

    amxc_var_init(&param);

    // check that the gmap device is added correctly
    upnp_obj = amxd_dm_findf(dm, "UPnPDescription.DeviceInstance.1.");
    assert_non_null(upnp_obj);
    gmap_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(gmap_obj);

    amxd_object_get_param(gmap_obj, "Alias", &param);
    udn = amxc_var_constcast(cstring_t, &param);
    assert_string_equal(udn, name);
    amxc_var_clean(&param);
    amxd_object_get_param(gmap_obj, "Manufacturer", &param);
    manu = amxc_var_constcast(cstring_t, &param);
    assert_string_equal(manu, "manu1");
    amxc_var_clean(&param);

    // Check that the gmap service is added correctly
    upnp_obj_service = amxd_dm_findf(dm, "UPnPDescription.ServiceInstance.1.");
    assert_non_null(upnp_obj_service);
    gmap_obj_service = amxd_dm_findf(dm, "Devices.Device.%s.Service.1.", name);
    assert_non_null(gmap_obj_service);

    amxd_object_get_param(gmap_obj_service, "ServiceId", &param);
    service_id = amxc_var_constcast(cstring_t, &param);
    assert_string_equal(service_id, "id1_1");

    // Check that no linking has happened. As the ParentDevice and the IP param are empty
    assert_null(amxd_object_findf(gmap_obj, "UDevice.1."));

    amxc_var_clean(&param);
}

void test_server_parameter_set_at_beginning(UNUSED void** state) {
    /*
     * The first Device is added with a DiscoveryDevice filled in.
     * This means that the Server value should also already be filled in.
     */
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* gmap_obj = NULL;
    const char* name = "UPnP-1";
    char* server_value = NULL;

    gmap_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(gmap_obj);

    server_value = amxd_object_get_value(cstring_t, gmap_obj, "Server", NULL);
    assert_string_equal(server_value, "testServer");

    free(server_value);
}

void test_mod_upnp_add_second_service_instance(UNUSED void** state) {
    /*
        Add a second service instance with the same parent device.
        Now a second service should be added to the gmap device.
     */
    const char* name = "UPnP-1";
    const char* parentDevice = "UPnPDescription.DeviceInstance.1.";
    const char* ServiceId = "id1_2";
    amxc_var_t values;
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* service_obj = NULL;
    char* service_id = NULL;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.Service.", name);
    assert_null(amxd_object_findf(service_obj, "2"));

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", parentDevice);
    amxc_var_add_key(cstring_t, &values, "ServiceId", ServiceId);
    amxc_var_add_key(cstring_t, &values, "ServiceType", "stype1_2");
    amxc_var_add_key(cstring_t, &values, "SCPDURL", "scp1_2");
    amxc_var_add_key(cstring_t, &values, "ControlURL", "curl1_2");
    amxc_var_add_key(cstring_t, &values, "EventSubURL", "surl1_2");

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.ServiceInstance.", 0, NULL, &values, &ret, 5), 0);

    handle_events();

    service_obj = amxd_object_findf(service_obj, "2");
    assert_non_null(service_obj);

    service_id = amxd_object_get_value(cstring_t, service_obj, "ServiceId", NULL);
    assert_string_equal(service_id, ServiceId);

    free(service_id);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void test_mod_upnp_add_device_with_non_existing_parent(UNUSED void** state) {
    /*
        Check that a service can be added to gmap with a certain ParentDevice.
        Altough this parent is not yet added to gmap.
        This should cause no linking to happen in between the gmap devices.
     */
    const char* parentDevice = "UPnPDescription.DeviceInstance.3.";
    const char* udn = "ThisMustBeExactly36CharactersLong002";
    const char* name = "UPnP-2";
    amxc_var_t values;
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* service_obj = NULL;
    char* device_udn = NULL;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    assert_null(amxd_dm_findf(dm, "Devices.Device.%s.", name));

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", parentDevice);

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.DeviceInstance.", 0, NULL, &values, &ret, 5), 0);

    handle_events();

    // Check that the device is added to gmap
    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(service_obj);

    // Check that it is the correct device
    device_udn = amxd_object_get_value(cstring_t, service_obj, "UDN", NULL);
    assert_string_equal(device_udn, udn);

    // Check that no linking has happened yet
    assert_null(amxd_object_findf(service_obj, "UDevice.1."));

    free(device_udn);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void test_mod_upnp_add_device_parent_later(UNUSED void** state) {
    /*
        A parent device is added to gmap after its lower device already exist.
        Check that it is linked to its lower device component.
        It also should link to a gmap device which contains the correct IP address.
     */
    const char* udn = "ThisMustBeExactly36CharactersLong003";
    const char* name = "UPnP-3";
    amxc_var_t values;
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* service_obj = NULL;
    char* device_udn = NULL;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    assert_null(amxd_dm_findf(dm, "Devices.Device.%s.", name));

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", "");
    amxc_var_add_key(cstring_t, &values, "IPAddress", "192.168.1.10");

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.DeviceInstance.", 0, NULL, &values, &ret, 5), 0);

    handle_events();

    // Check that the device is added to gmap
    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(service_obj);

    // Check that it is the correct device
    device_udn = amxd_object_get_value(cstring_t, service_obj, "UDN", NULL);
    assert_string_equal(device_udn, udn);

    // Check that the linking has happened with the other upnp device
    assert_non_null(amxd_object_findf(service_obj, "LDevice.1."));

    // Check that the linking has happened with the device containing the ip address
    assert_non_null(amxd_object_findf(service_obj, "UDevice.1."));

    free(device_udn);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void test_mod_upnp_add_ip_device_later(UNUSED void** state) {
    /*
        Checks that it makes a query to wait for a not yet existing device
     */
    amxc_var_t values;
    const char* udn = "ThisMustBeExactly36CharactersLong004";

    amxc_var_init(&values);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", "");
    amxc_var_add_key(cstring_t, &values, "IPAddress", "192.168.1.30");

    expect_string(__wrap_gmap_query_open_ext_2, expression, "ipv4 && has_instance(\"IPv4Address\", \".Address == '192.168.1.30' && .Status == 'reachable'\")");

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.DeviceInstance.", 0, NULL, &values, NULL, 5), 0);
    handle_events();

    amxc_var_clean(&values);
}

void test_mod_upnp_add_lower_linked_device(UNUSED void** state) {
    /*
        Check that a service can be added to gmap with a certain ParentDevice.
        The ParentDevice already exists and thus the device should be linked to it.
     */
    const char* parentDevice = "UPnPDescription.DeviceInstance.3.";
    const char* udn = "ThisMustBeExactly36CharactersLong005";
    const char* name = "UPnP-5";
    amxc_var_t values;
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* service_obj = NULL;
    char* device_udn = NULL;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    assert_null(amxd_dm_findf(dm, "Devices.Device.%s.", name));

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", parentDevice);

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.DeviceInstance.", 0, NULL, &values, &ret, 5), 0);

    handle_events();

    // Check that the device is added to gmap
    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(service_obj);

    // Check that it is the correct device
    device_udn = amxd_object_get_value(cstring_t, service_obj, "UDN", NULL);
    assert_string_equal(device_udn, udn);

    // Check that linking has happened
    assert_non_null(amxd_object_findf(service_obj, "UDevice.1."));
    assert_null(amxd_object_findf(service_obj, "LDevice.1."));

    free(device_udn);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void test_add_service_before_device_instance(UNUSED void** state) {
    /*
     * Check that a service that is added to UPNPDescription before the device is still added
     * when the device is added.
     */
    const char* parentDevice = "UPnPDescription.DeviceInstance.2.";
    const char* serviceParentDevice = "UPnPDescription.DeviceInstance.6.";
    const char* udn = "ThisMustBeExactly36CharactersLong006";
    const char* name = "UPnP-6";
    const char* ServiceId = "id5_1";
    char* service_id = NULL;
    amxc_var_t values;
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* device_obj = NULL;
    amxd_object_t* service_obj = NULL;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    assert_null(amxd_dm_findf(dm, "Devices.Device.%s.", name));

    /* Add a service */
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", serviceParentDevice);
    amxc_var_add_key(cstring_t, &values, "ServiceId", ServiceId);
    amxc_var_add_key(cstring_t, &values, "ServiceType", "stype1_2");
    amxc_var_add_key(cstring_t, &values, "SCPDURL", "scp1_2");
    amxc_var_add_key(cstring_t, &values, "ControlURL", "curl1_2");
    amxc_var_add_key(cstring_t, &values, "EventSubURL", "surl1_2");

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.ServiceInstance.", 0, NULL, &values, &ret, 5), 0);
    amxc_var_clean(&values);

    handle_events();

    /* Add a device */
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", parentDevice);

    assert_int_equal(amxb_add(bus_ctx, "UPnPDescription.DeviceInstance.", 0, NULL, &values, &ret, 5), 0);

    handle_events();

    // Check that the device is added to gmap
    device_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(device_obj);

    // Check that the service is added
    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.Service.1.", name);
    assert_non_null(service_obj);
    service_id = amxd_object_get_value(cstring_t, service_obj, "ServiceId", NULL);
    assert_string_equal(service_id, ServiceId);

    free(service_id);
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void test_server_parameter_set_later(UNUSED void** state) {
    /*
     * Checks that when the 'DiscoverDevice' parameter is filled in later,
     * That the 'Server' parameter is updated.
     */
    const char* name = "UPnP-2";
    char* server_value = NULL;
    amxd_object_t* upnp_obj = NULL;
    amxd_object_t* device_obj = NULL;
    amxd_trans_t transaction;
    amxd_dm_t* dm = test_get_dm();
    amxc_var_t disc_dev;

    amxd_trans_init(&transaction);
    amxc_var_init(&disc_dev);

    upnp_obj = amxd_dm_findf(dm, "UPnPDescription.DeviceInstance.2.");
    device_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);

    server_value = amxd_object_get_value(cstring_t, device_obj, "Server", NULL);
    assert_string_equal(server_value, "");
    free(server_value);

    amxc_var_set(cstring_t, &disc_dev, "Device.UPnP.Discovery.Device.1.");
    amxd_trans_select_object(&transaction, upnp_obj);
    amxd_trans_set_param(&transaction, "DiscoveryDevice", &disc_dev);
    assert_int_equal(amxd_trans_apply(&transaction, dm), 0);
    handle_events();

    server_value = amxd_object_get_value(cstring_t, device_obj, "Server", NULL);
    assert_string_equal(server_value, "testServer");

    free(server_value);
    amxd_trans_clean(&transaction);
    amxc_var_clean(&disc_dev);
}

void test_server_parameter_set_in_between(UNUSED void** state) {
    /*
     * Situation in which the event for the 'DiscoveryDevice' is sent,
     * very shortly after the creation of the device.
     * The 'Server' value should be filled in correclty
     */
    const char* udn = "ThisMustBeExactly36CharactersLong007";
    const char* name = "UPnP-7";
    char* retval = NULL;
    amxd_dm_t* dm = test_get_dm();
    amxd_trans_t transaction;
    amxc_var_t values;
    amxc_var_t disc_dev;
    amxd_object_t* instance = NULL;
    amxd_object_t* device_instance = NULL;
    amxd_object_t* gmap_device = NULL;

    amxd_trans_init(&transaction);
    amxc_var_init(&values);
    amxc_var_init(&disc_dev);

    assert_null(amxd_dm_findf(dm, "Devices.Device.%s.", name));
    device_instance = amxd_dm_findf(dm, "UPnPDescription.DeviceInstance.");

    // Add a new instance without handling events
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "UDN", udn);
    amxc_var_add_key(cstring_t, &values, "ParentDevice", "");
    amxc_var_add_key(cstring_t, &values, "IPAddress", "192.168.1.10");

    amxd_object_add_instance(&instance, device_instance, NULL, 7, &values);
    amxd_object_emit_add_inst(instance);

    // Update 'DiscoveryDevice' parameter without handling events
    amxc_var_set(cstring_t, &disc_dev, "Device.UPnP.Discovery.Device.1.");
    amxd_trans_select_object(&transaction, instance);
    amxd_trans_set_param(&transaction, "DiscoveryDevice", &disc_dev);

    assert_int_equal(amxd_trans_apply(&transaction, dm), 0);

    // Handle both events shortly after each other
    handle_events();

    // Check that the device is added to gmap
    gmap_device = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(gmap_device);

    // Check that the server value is filled in
    retval = amxd_object_get_value(cstring_t, gmap_device, "Server", NULL);
    assert_string_equal(retval, "testServer");

    free(retval);
    amxd_trans_clean(&transaction);
    amxc_var_clean(&values);
    amxc_var_clean(&disc_dev);
}

void test_mod_upnp_remove_service_instance(UNUSED void** state) {
    /*
        Remove a upnp ServiceInstance. Check that it is also removed in gmap.
        It should also not remove the other services in gmap for that device.
     */
    const char* name = "UPnP-1";
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* service_obj = NULL;

    amxc_var_init(&ret);

    service_obj = amxd_dm_findf(dm, "Devices.Device.%s.Service.", name);
    assert_non_null(service_obj);

    assert_int_equal(amxb_del(bus_ctx, "UPnPDescription.ServiceInstance.", 1, NULL, &ret, 5), 0);

    handle_events();

    assert_null(amxd_object_findf(service_obj, "1"));
    assert_non_null(amxd_object_findf(service_obj, "2"));

    amxc_var_clean(&ret);
}

void test_mod_upnp_remove_device_instance(UNUSED void** state) {
    /*
        Remove a upnp DeviceInstance. Check that it is also removed in gmap.
        The remaining Device.Service should also be cleaned.
        (there are list keeping track of them in the mib code)
        This is checked by Valgrind, checking for memory leaks.

        Not all devices are removed. This should then be cleaned up by
        the cleanup function of gmap-mod-upnp.
     */
    const char* name = "UPnP-1";
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* device_obj = NULL;

    amxc_var_init(&ret);

    device_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_non_null(device_obj);

    assert_int_equal(amxb_del(bus_ctx, "UPnPDescription.DeviceInstance.", 1, NULL, &ret, 5), 0);

    handle_events();

    device_obj = amxd_dm_findf(dm, "Devices.Device.%s.", name);
    assert_null(device_obj);

    amxc_var_clean(&ret);
}

void test_mod_upnp_remove_device_unlinks_linked_devices(UNUSED void** state) {
    /*
        Check that the when a device is removed. Its links are unlinked too.
     */
    const char* parent = "UPnP-3";
    amxc_var_t ret;
    amxd_dm_t* dm = test_get_dm();
    amxd_object_t* parent_obj = NULL;

    amxc_var_init(&ret);

    parent_obj = amxd_dm_findf(dm, "Devices.Device.%s.LDevice.", parent);
    assert_non_null(amxd_object_findf(parent_obj, "2"));

    assert_int_equal(amxb_del(bus_ctx, "UPnPDescription.DeviceInstance.", 5, NULL, &ret, 5), 0);

    handle_events();

    assert_null(amxd_object_findf(parent_obj, "2"));

    amxc_var_clean(&ret);
}
