# TR-181 Resource Monitoring — DeviceInfo Module (Memory + CPU)

## Overview

TR-181–compatible Resource Monitoring under the DeviceInfo module that exposes:
  • Memory status and monitoring controls  
  • CPU status and per-CPU monitoring controls  

The feature provides periodic polling, hysteresis-based critical state handling, timestamps, events, and optional logging to file and/or a vendor logging backend.

## Installation

Build and install:  
```
make && sudo make install
```

Compile and install (step-by-step):  
```
make
sudo make install
```

Run tests:  
```
make test
```
- Unit tests are broken in deviceInfo. Issue is tracked in defect PPW-760
https://prplfoundationcloud.atlassian.net/browse/PPW-760

- To run unit test for Resource Monitor, comment the following tests in makefile.

makefile before change:
```
test:
        $(MAKE) -C mod-lr-logrotate/test run
        $(MAKE) -C mod-lr-logrotate/test coverage
        $(MAKE) -C mod-syslog/test run
        $(MAKE) -C mod-syslog/test coverage
        $(MAKE) -C system/test run
        $(MAKE) -C system/test coverage
        $(MAKE) -C test run
        $(MAKE) -C test coverage
        $(MAKE) -C resmon_test/test run
        $(MAKE) -C resmon_test/test coverage

```

makefile after change:
```
test:
        #$(MAKE) -C mod-lr-logrotate/test run
        #$(MAKE) -C mod-lr-logrotate/test coverage
        #$(MAKE) -C mod-syslog/test run
        #$(MAKE) -C mod-syslog/test coverage
        $(MAKE) -C system/test run
        $(MAKE) -C system/test coverage
        #$(MAKE) -C test run
        #$(MAKE) -C test coverage
        $(MAKE) -C resmon_test/test run
        $(MAKE) -C resmon_test/test coverage

```


## Run Inside an Ambiorix Docker Container

Refer to the Ambiorix tutorials for steps to launch the container.

Compile/install dependencies (Ambiorix stack):  
```
libsahtrace
libamxb
libamxc
libamxd
libamxm
libamxo
libamxp
libamxj
```

Runtime dependencies:  
```
amxrt
```

Activate the DeviceInfo Resource Monitoring plugin:  
```
sudo /etc/init.d/deviceinfo-manager start
```

## General Requirements

• TR-181 data model implementation for DeviceInfo Resource Monitoring  
• Clear separation of “raw status” vs “monitoring control” surfaces  
  - MemoryStatus exposes Total/Free and a MemoryMonitor control  
  - ProcessStatus exposes aggregate CPUUsage and per-CPU CPU[] monitors  
• Hysteresis for critical states using Rise/Fall thresholds to avoid flapping  
• Optional logging to a file path (file:///...) and/or vendor logging backend  

## Behavior:
  • Each CPU[] instance can be enabled/disabled independently (Enable).  
  • PollInterval >= 0 is allowed.  
  • Hysteresis per instance:  
      - Enter critical: CPUUtilization >= CriticalRiseThreshold  
      - Exit critical : CPUUtilization <= CriticalFallThreshold  
  • NumSamples defines the averaging window for smoothing utilization.  
  • On transitions, update timestamps and emit CPUCriticalState!.  
  • If EnableCriticalLog=true, write to FilePath and/or vendor log sink.  
  • Memory can be enabled/disabled independently (Enable).  
  • PollInterval>=0 is allowed.  
  • Hysteresis per instance:  
      - Enter critical: MemUtilization >= CriticalRiseThreshold  
      - Exit critical : MemUtilization <= CriticalFallThreshold  
  • On transitions, update timestamps and emit MemoryCriticalState!.  
  • If EnableCriticalLog=true, write to FilePath and/or vendor log sink.  

## Events Generated

**MemoryCriticalState!:**  
Trigger: Enter critical memory state based on utilization thresholds.  
Example payload:  
```
{
  "object": "Device.DeviceInfo.MemoryStatus.MemoryMonitor",
  "event": "MemoryCriticalState!"
}
```

**CPUCriticalState!:**  
Trigger: Enter critical CPU state for a CPU[] instance.  
Example payload:  
```
{
  "object": "Device.DeviceInfo.ProcessStatus.CPU.1",
  "event": "CPUCriticalState!"
}
```

## Example Workflows

**A) Memory — Enable monitoring with 5s polling and critical logging**  
1) (optional) Set thresholds:  
```
CriticalRiseThreshold = 80
CriticalFallThreshold = 60
```
2) Set log path (optional):  
```
FilePath = "file:///var/log/memory_monitor.log"
```
3) Enable:  
```
Enable = true
EnableCriticalLog = true
```
4) Observe:  
- MemUtilization reflects current %  
- MemoryCriticalState! events emitted on transitions  
- Timestamps updated on transitions  

**B) CPU — Create/enable a CPU monitor instance with smoothing**  
1) Ensure a CPU.{i} instance exists; set:  
```
Enable = true
PollInterval = 5
CriticalRiseThreshold = 80
CriticalFallThreshold = 60
NumSamples = 30
FilePath = "file:///var/log/cpu_monitor_cpu0.log"
EnableCriticalLog = true
```
2) Read status:  
```
CPUUtilization, UserModeUtilization, SystemModeUtilization, IdleModeUtilization, UpTime
```
3) Observe:  
- CPUCriticalState! events on threshold crossings  
- CriticalRiseTimeStamp / CriticalFallTimeStamp updates  

**C) Disable monitoring**  
• Memory: set Enable=false  
• CPU: set Enable=false (per CPU instance).  

## End of README
