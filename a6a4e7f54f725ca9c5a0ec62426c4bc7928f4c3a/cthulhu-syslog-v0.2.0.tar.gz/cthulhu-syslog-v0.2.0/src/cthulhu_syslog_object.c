/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <debug/sahtrace.h>
#include <unistd.h>
#include <string.h>

#include <lcm/lcm_remote_object.h>
#include <lcm/lcm_assert.h>
#include <lcm/lcm_helpers.h>
#include "cthulhu_syslog_common.h"
#include "cthulhu_syslog_object.h"
#include "cthulhu_syslog_defines.h"

static remote_object_t* syslog_object = NULL;

int syslog_object_init(void) {
    int res = -1;
    syslog_object = lcm_remote_object_register(SYSLOG_DM);
    ASSERT_NOT_NULL(syslog_object, goto exit);
    res = 0;
exit:
    return res;
}

void syslog_object_teardown(void) {
    ASSERT_NOT_NULL_NL(syslog_object, return );
    lcm_remote_object_unregister(&syslog_object);
}

char* syslog_source_configure(const char* alias, const char* socket_path, bool enable) {
    char* source_path = NULL;
    amxc_var_t values;
    amxc_string_t object_socket_path;
    int res = -1;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&object_socket_path, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);
    ASSERT_STR_NOT_EMPTY(socket_path, goto exit);

    amxc_var_add_key(bool, &values, SYSLOG_CATEGORY_KERNEL, false);
    amxc_var_add_key(bool, &values, SYSLOG_CATEGORY_SYSTEM, false);
    amxc_var_add_key(cstring_t, &values, SYSLOG_SEVERITY, "All");
    amxc_var_add_key(cstring_t, &values, SYSLOG_FACILITYLEVEL, "All");

    // check if the source already exists
    if(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_SOURCE ".", alias, &source_path, NULL) == 0) {
        SAH_TRACEZ_INFO(ME, "Source path [%s] already exists for alias [%s]. It will be reused", source_path, alias);
        res = lcm_remote_object_set(syslog_object, source_path, &values);
        ASSERT_SUCCESS(res, NO_INSTRUCTION, "Failed to update Syslog Source [%s: %s] Err [%d]", SYSLOG_DM SYSLOG_SOURCE, alias, res);
    } else {
        // first add a source
        amxc_var_add_key(cstring_t, &values, "Alias", alias);

        res = lcm_remote_object_add(syslog_object, SYSLOG_DM SYSLOG_SOURCE ".", &values, &source_path);
        ASSERT_SUCCESS(res, goto exit, "Failed to add Syslog Source [%s: %s] Err [%d]", SYSLOG_DM SYSLOG_SOURCE, alias, res);
        ASSERT_STR_NOT_EMPTY(source_path, goto exit, "Source Path is empty [%s: %s]", SYSLOG_DM SYSLOG_SOURCE, alias);
    }
    ASSERT_SUCCESS(amxc_string_appendf(&object_socket_path, "%s."SYSLOG_SOCKET ".", source_path), goto error, "Failed to create socket_path");

    amxc_var_clean(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, SYSLOG_ENABLE, enable);
    amxc_var_add_key(cstring_t, &values, SYSLOG_SOCKETPATH, socket_path);

    res = lcm_remote_object_set(syslog_object, amxc_string_get(&object_socket_path, 0), &values);
    ASSERT_SUCCESS(res, goto error, "Failed to update socket info of [%s] Err [%d]", amxc_string_get(&object_socket_path, 0), res);

    goto exit;
error:
    if(source_path) {
        lcm_remote_object_remove(syslog_object, source_path);
        free_null(source_path);
    }

exit:
    amxc_var_clean(&values);
    amxc_string_clean(&object_socket_path);
    return source_path;
}

int syslog_source_enable(const char* alias, bool enable) {
    int res = -1;
    char* source_path = NULL;
    amxc_var_t values;
    amxc_string_t object_socket_path;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&object_socket_path, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    ASSERT_SUCCESS(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_SOURCE ".", alias, &source_path, NULL), goto exit, "Syslog source for alias [%s] does not exit", alias);
    ASSERT_SUCCESS(amxc_string_appendf(&object_socket_path, "%s."SYSLOG_SOCKET ".", source_path), goto exit, "Failed to create socket_path");
    amxc_var_add_key(bool, &values, SYSLOG_ENABLE, enable);

    ASSERT_SUCCESS(lcm_remote_object_set(syslog_object, amxc_string_get(&object_socket_path, 0), &values), goto exit, "Failed to update socket info of [%s]", source_path);

    res = 0;
exit:
    amxc_var_clean(&values);
    amxc_string_clean(&object_socket_path);
    free(source_path);
    return res;
}

char* syslog_socket_path_get(const char* alias) {
    char* socket_path = NULL;
    char* source_path = NULL;
    amxc_var_t values;
    amxc_string_t object_socket_path;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&object_socket_path, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    ASSERT_SUCCESS(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_SOURCE ".", alias, &source_path, NULL),
                   goto exit, "Syslog source for alias [%s] does not exit", alias);
    ASSERT_SUCCESS(amxc_string_appendf(&object_socket_path, "%s."SYSLOG_SOCKET ".", source_path),
                   goto exit, "Failed to create socket_path");

    ASSERT_SUCCESS(lcm_remote_object_get_one(syslog_object, amxc_string_get(&object_socket_path, 0), &values),
                   goto exit, "Failed to get socket info of [%s]", amxc_string_get(&object_socket_path, 0));
    socket_path = amxc_var_dyncast(cstring_t, GET_ARG(&values, SYSLOG_SOCKETPATH));
    ASSERT_STR_NOT_EMPTY(socket_path, goto exit,
                         "Failed to get " SYSLOG_SOCKETPATH " for alias [%s]", alias);
exit:
    amxc_var_clean(&values);
    amxc_string_clean(&object_socket_path);
    free(source_path);
    return socket_path;
}

char* syslog_vendorlogfileref_get(const char* alias) {
    char* log_path = NULL;
    char* action_path = NULL;
    amxc_var_t values;
    amxc_string_t object_logfile_path;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&object_logfile_path, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    ASSERT_SUCCESS(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_ACTION ".", alias, &action_path, NULL), goto exit, "Syslog Action for alias [%s] does not exit", alias);
    ASSERT_SUCCESS(amxc_string_appendf(&object_logfile_path, "%s."SYSLOG_LOGFILE ".", action_path), goto exit, "Failed to create logfile path");

    ASSERT_SUCCESS(lcm_remote_object_get_one(syslog_object, amxc_string_get(&object_logfile_path, 0), &values), goto exit, "Failed to get logfile info of [%s]", amxc_string_get(&object_logfile_path, 0));

    log_path = amxc_var_dyncast(cstring_t, GET_ARG(&values, SYSLOG_VENDORLOGFILEREF));
    ASSERT_STR_NOT_EMPTY(log_path, goto exit,
                         "Failed to get " SYSLOG_VENDORLOGFILEREF " for alias [%s]", alias);

exit:
    free(action_path);
    amxc_var_clean(&values);
    amxc_string_clean(&object_logfile_path);
    return log_path;
}

int syslog_object_del(const char* object_path) {
    int res = -1;
    ASSERT_STR_NOT_EMPTY(object_path, return res);
    amxc_var_t ret;
    amxc_var_init(&ret);

    res = lcm_remote_object_del(syslog_object, object_path, &ret);

    amxc_var_clean(&ret);
    return res;
}

char* syslog_template_configure(const char* alias,
                                const char* template) {
    char* template_path = NULL;
    amxc_var_t values;
    int res = 0;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);
    ASSERT_STR_NOT_EMPTY(template, goto exit);

    // check if the template already exists
    if(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_TEMPLATE ".", alias, &template_path, NULL) == 0) {

        SAH_TRACEZ_WARNING(ME, "Template path [%s] already exists for alias [%s]. It will be reused", template_path, alias);
        amxc_var_add_key(cstring_t, &values, SYSLOG_TEMPLATE_EXPRESSION, template);
        res = lcm_remote_object_set(syslog_object, template_path, &values);
        ASSERT_SUCCESS(res, goto exit, "Failed to update Syslog Template [%s] Err [%d]", template_path, res);
    } else {
        // add the template
        amxc_var_add_key(cstring_t, &values, SYSLOG_ALIAS, alias);
        amxc_var_add_key(cstring_t, &values, SYSLOG_TEMPLATE_EXPRESSION, template);
        res = lcm_remote_object_add(syslog_object, SYSLOG_DM SYSLOG_TEMPLATE ".", &values, &template_path);
        ASSERT_SUCCESS(res, goto exit, "Failed to add Syslog Template [%s: %s] Err [%d]", SYSLOG_DM SYSLOG_TEMPLATE ".", alias, res);
        ASSERT_STR_NOT_EMPTY(template_path, goto exit, "Failed to add Syslog Template [%s: %s]", SYSLOG_DM SYSLOG_TEMPLATE ".", alias);
    }
exit:
    amxc_var_clean(&values);
    return template_path;
}

char* syslog_action_configure(const char* alias,
                              const char* source_ref,
                              const char* template_ref,
                              const char* log_path) {
    char* action_path = NULL;
    amxc_var_t values;
    amxc_string_t object_logfile_path;
    int res = 0;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_string_init(&object_logfile_path, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);
    ASSERT_STR_NOT_EMPTY(source_ref, goto exit);
    ASSERT_STR_NOT_EMPTY(template_ref, goto exit);
    ASSERT_STR_NOT_EMPTY(log_path, goto exit);

    // check if the source already exists
    if(lcm_remote_object_get_by_alias(syslog_object, SYSLOG_DM SYSLOG_ACTION ".", alias, &action_path, NULL) == 0) {

        SAH_TRACEZ_WARNING(ME, "Action path [%s] already exists for alias [%s]. It will be reused", action_path, alias);
        amxc_var_add_key(cstring_t, &values, SYSLOG_ACTION_SOURCEREF, source_ref);
        amxc_var_add_key(cstring_t, &values, SYSLOG_ACTION_TEMPLATEREF, template_ref);
        res = lcm_remote_object_set(syslog_object, action_path, &values);
        ASSERT_SUCCESS(res, goto exit, "Failed to update Syslog Action [%s] Err [%d]", action_path, res);
    } else {
        // first add a source
        amxc_var_add_key(cstring_t, &values, SYSLOG_ALIAS, alias);
        amxc_var_add_key(cstring_t, &values, SYSLOG_ACTION_SOURCEREF, source_ref);
        amxc_var_add_key(cstring_t, &values, SYSLOG_ACTION_TEMPLATEREF, template_ref);

        res = lcm_remote_object_add(syslog_object, SYSLOG_DM SYSLOG_ACTION ".", &values, &action_path);
        ASSERT_SUCCESS(res, goto exit, "Failed to add Syslog Action [%s: %s] Err [%d]", SYSLOG_DM SYSLOG_ACTION ".", alias, res);
        ASSERT_STR_NOT_EMPTY(action_path, goto exit, "Failed to add Syslog Action [%s: %s]", SYSLOG_DM SYSLOG_ACTION ".", alias);
    }
    ASSERT_SUCCESS(amxc_string_appendf(&object_logfile_path, "%s."SYSLOG_LOGFILE ".", action_path), goto error, "Failed to create socket_path");

    amxc_var_clean(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, SYSLOG_ENABLE, true);
    amxc_var_add_key(cstring_t, &values, SYSLOG_LOGFILE_FILEPATH, log_path);

    res = lcm_remote_object_set(syslog_object, amxc_string_get(&object_logfile_path, 0), &values);
    ASSERT_SUCCESS(res, goto error, "Failed to update Syslog Action info of [%s] Err [%d]", action_path, res);

    goto exit;
error:
    if(action_path) {
        lcm_remote_object_remove(syslog_object, action_path);
        free_null(action_path);
    }

exit:
    amxc_var_clean(&values);
    amxc_string_clean(&object_logfile_path);
    return action_path;
}

int syslog_subscribe(const char* object_path,
                     const char* expression,
                     amxp_slot_fn_t slot_cb,
                     void* priv) {
    return lcm_remote_object_subscribe(syslog_object, object_path, expression, slot_cb, priv);
}

int syslog_unsubscribe(const char* object_path,
                       amxp_slot_fn_t slot_cb,
                       void* priv) {
    return lcm_remote_object_unsubscribe(syslog_object, object_path, slot_cb, priv);
}
