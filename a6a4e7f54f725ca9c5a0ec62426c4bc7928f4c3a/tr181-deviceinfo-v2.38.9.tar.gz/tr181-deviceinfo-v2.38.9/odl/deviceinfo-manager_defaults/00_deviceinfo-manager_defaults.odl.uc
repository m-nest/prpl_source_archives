{% import * as fs from 'fs'; %}
%populate {
    object "${prefix_}DeviceInfo" {
        parameter FriendlyName = "$(MY_FRIENDLYNAME)";
        parameter FirstUseDate = "0001-01-01T00:00:00Z";
        parameter "${global_vendor_prefix_}Country" = "$(COUNTRY_CODE)";
        parameter HostName = "$(MY_HOSTNAME)";

        object FirmwareImage {
            instance add (1, "active") {
                parameter Available = true;
                parameter Status = "Active";
            }
            instance add (2, "inactive") {
                parameter Available = false;
                parameter Status = "NoImage";
            }
        }

        object VendorConfigFile {
            instance add (0, "userSettings") {
                parameter UseForBackupRestore = true;
            }
        }

        object MemoryStatus {
            object MemoryMonitor {
                parameter CriticalFallThreshold = 60;
                parameter CriticalRiseThreshold = 80;
                parameter FilePath = "file://${log-dir}/resmon-memory.log";
            }
        }

        object ProcessStatus {
            object CPU {
{% for (let cpu in fs.lsdir("/sys/devices/system/cpu/")) : -%}
{% if (match(cpu, regexp("^cpu[0-9]+$")) != null): %}
{% let core_id = match(cpu, regexp("^cpu([0-9]+)$"))[1]; %}
                instance add(0, Alias="CORE-{{ core_id }}") {
                    parameter Enable = false;
                    parameter PollInterval = 5;
                    parameter EnableCriticalLog = false;
                    parameter NumSamples = 30;
                    parameter FilePath = "file://${log-dir}/resmon-cpu{{ core_id }}.log";
                    parameter Name = "cpu-{{ core_id }}";
                    parameter CriticalFallThreshold = 60;
                    parameter CriticalRiseThreshold = 80;
                }
{% endif %}
{% endfor -%}
            }
        }
    }
}

