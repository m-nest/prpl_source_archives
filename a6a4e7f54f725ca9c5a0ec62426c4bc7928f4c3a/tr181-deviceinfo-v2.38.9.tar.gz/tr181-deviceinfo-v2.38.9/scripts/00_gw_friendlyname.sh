#!/bin/sh

# create the friendlyname 
MY_FRIENDLYNAME="prplHGW"

echo "export MY_FRIENDLYNAME=\"$MY_FRIENDLYNAME\"" >> /var/etc/environment