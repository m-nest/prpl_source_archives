{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
{% upstream_interfaces = "Device.Logical.Interface.1." %}
{% if (has_failover) : upstream_interfaces = upstream_interfaces + ",Device.Logical.Interface.8." endif %}
%populate {
    object 'RouterAdvertisement' {
        parameter 'Enable' = true;
        parameter 'WANInterfaces' = "{{upstream_interfaces}}";
    }
}
