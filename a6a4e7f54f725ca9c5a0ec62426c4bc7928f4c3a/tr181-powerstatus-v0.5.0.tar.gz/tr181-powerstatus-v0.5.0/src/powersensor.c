/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_transaction.h>

#include "tr181-powerstatus.h"
#include "dm_powerstatus.h"
#include "powersensor_info.h"

#define ME "powersensor"

static uint32_t read_power_value(const char* filepath) {
    uint32_t power = 0;
    FILE* file = NULL;

    when_str_empty_trace(filepath, exit, ERROR, "Filepath to read power sensor is empty");

    file = fopen(filepath, "r");
    when_false_trace(file, exit, ERROR, "Cannot open file '%s' to read power sensor", filepath);

    if(fscanf(file, "%u", &power) == 1) {
        SAH_TRACEZ_INFO(ME, "Power parsed from file '%s' : %u mW", filepath, power);
    } else {
        SAH_TRACEZ_ERROR(ME, "Cannot parse power from file '%s'", filepath);
        power = 0;
    }

    fclose(file);

exit:
    return power;
}

void powersensor_timer_cb(UNUSED amxp_timer_t* timer, void* priv) {
    powersensor_info_t* info = (powersensor_info_t*) priv;
    const char* filepath = NULL;
    uint32_t power = 0;

    when_null_trace(info, exit, ERROR, "Sensor info cannot be retrieved");
    when_null_trace(info->obj, exit, ERROR, "Sensor object cannot be retrieved");

    SAH_TRACEZ_INFO(ME, "Reading power values for %s", info->obj->name);

    filepath = GET_CHAR(amxd_object_get_param_value(info->obj, "PowerPath"), NULL);
    power = read_power_value(filepath);

    dm_powersensor_update_readings(info->obj, power);
exit:
    return;
}

int powersensor_timer_update(powersensor_info_t* info) {
    uint32_t polling_interval = 0;
    bool rv = -1;

    when_null_trace(info, exit, ERROR, "Sensor info cannot be retrieved");
    when_null_trace(info->obj, exit, ERROR, "Sensor object cannot be retrieved");
    when_null_trace(info->polling_timer, exit, ERROR, "Time is NULL");

    if(amxd_object_get_value(bool, info->obj, "Enable", NULL)) {
        polling_interval = amxd_object_get_value(uint32_t, info->obj, "PollingInterval", NULL);
        when_false_trace(polling_interval > 0, exit, ERROR, "Failed to get polling interval");
        SAH_TRACEZ_INFO(ME, "Starting power sensor '%s' polling every %u s", info->obj->name, polling_interval);
        when_failed_trace(amxp_timer_set_interval(info->polling_timer, polling_interval * 1000), exit, ERROR, "Failed to set polling timer interval");
        when_failed_trace(amxp_timer_start(info->polling_timer, 0), exit, ERROR, "Failed to start the timer");
    } else {
        when_failed_trace(amxp_timer_stop(info->polling_timer), exit, ERROR, "Failed to stop the timer");
    }

    rv = 0;
exit:
    return rv;
}