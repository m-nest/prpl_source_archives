/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <amxc/amxc_macros.h>

#include "test_mod_https_options.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_get_certificate_uri_success),
        cmocka_unit_test(test_get_certificate_uri_invalid_input),
        cmocka_unit_test(test_mod_lighttpd_config_https_options),
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
