/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <ctype.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <amxm/amxm.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "umdns_utils.h"

#define ME "dnssd_umdns"

struct _umdns umdns;

/**
 * @brief
 * start umdns timers.
 *
 * @param update_intervall time between repeated multicast DNS queries.
 * @param browse_intervall time between repeated DNS-SD browse queries.
 */
void umdns_update_timers(uint32_t update_intervall, uint32_t browse_intervall) {

    when_null_trace(umdns.timer_update, exit, ERROR, "update timer is not initialised");
    when_null_trace(umdns.timer_set_service, exit, ERROR, "browse timer is not initialised");

    // keep the timer interval for restart
    umdns.last_update_intervall = 1000 * update_intervall;
    umdns.last_browse_intervall = 1000 * browse_intervall;

    amxp_timer_start(umdns.timer_update, umdns.last_update_intervall);
    amxp_timer_start(umdns.timer_set_service, umdns.last_browse_intervall);
exit:
    return;
}
/**
 * @brief
 * Initialise the umdns library and timers.
 *
 * @param handler_send The call back function to send services.
 */
void umdns_init(umdns_callback_t handler_send) {
    umdns.send_services = handler_send;
    amxp_timer_new(&umdns.timer_update, umdns_update_services, NULL);
    amxp_timer_start(umdns.timer_update, DEFAULT_UMDNS_UPDATE_INTERVAL_SEC * 1000);
    amxp_timer_new(&umdns.timer_set_service, umdns_get_services, NULL);
    amxp_timer_start(umdns.timer_set_service, DEFAULT_UMDNS_SET_SERVICE_INTERVAL_SEC * 1000);
    return;
}

/**
 * @brief
 * Clean umdns library.
 */
void umdns_clean(void) {
    umdns.send_services = NULL;
    amxp_timer_delete(&umdns.timer_set_service);
    amxp_timer_delete(&umdns.timer_update);
    return;
}
