/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "interfacesetting/dm_interfacesetting.h"
#include "interfacesetting/dm_accept_udp_traceroute.h"
#include "interfacesetting/accept_udp_traceroute.h"
#include "protocols.h"
#include "logs/logs.h"
#include "firewall.h" // for fw_get_dm
#include "usp_utils.h"
#include "profiling/profiling.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>

#define ME "firewall"

static void query_result_changed(firewall_interface_t* fwiface) {
    FW_PROFILING_IN(TRACE_CALLBACK);
    common_t* common = (common_t*) fwiface->query_priv;
    when_null_trace(common, exit, ERROR, "Common object is NULL.");
    accept_udp_traceroute_t* accept_udp_traceroute = (accept_udp_traceroute_t*) common->priv_data;
    when_null_trace(accept_udp_traceroute, exit, ERROR, "AcceptUDPTraceroute object is NULL.");

    when_true(common->flags != 0, exit); // already being configured
    common->flags = FW_MODIFIED;

    log_update(&common->folders.log, true,
               log_get_dm_controller_param(common->object, NULL, "LogController"),
               !EXCLUDE_SRC_INTERFACE, !EXCLUDE_DST_INTERFACE,
               NULL);

    accept_udp_traceroute_implement_changes(accept_udp_traceroute, IPvAll);
exit:
    FW_PROFILING_OUT();
}

/**
   @brief
   Initialise the AcceptUDPTraceroute internal structure.

   @param[in] instance Object with the InterfaceSetting's instance.

   @return
   0 if success, 1 if failed.
 */
int fw_accept_udp_traceroute_init(amxd_object_t* object) {
    FW_PROFILING_IN(TRACE_INTERNAL);
    ifsetting_t* ifsetting = NULL;
    accept_udp_traceroute_t* accept_udp_traceroute = NULL;
    int ret_value = 1;

    when_null(object, exit);
    ifsetting = (ifsetting_t*) object->priv;
    when_null(ifsetting, exit);

    accept_udp_traceroute = ifsetting->accept_udp_traceroute;
    if(accept_udp_traceroute == NULL) {
        accept_udp_traceroute = create_fw_accept_udp_traceroute(object);
        when_null(accept_udp_traceroute, exit);
        ifsetting->accept_udp_traceroute = accept_udp_traceroute;
    }

    accept_udp_traceroute->common.dest_fwiface.query_priv = &accept_udp_traceroute->common;
    accept_udp_traceroute->common.dest_fwiface.query_result_changed = query_result_changed;
    accept_udp_traceroute->common.priv_data = accept_udp_traceroute;

    accept_udp_traceroute->target4 = amxd_object_get_value(bool, object, "IPv4AcceptUDPTraceroute", NULL) ? TARGET_ACCEPT : TARGET_DROP;
    accept_udp_traceroute->target6 = amxd_object_get_value(bool, object, "IPv6AcceptUDPTraceroute", NULL) ? TARGET_ACCEPT : TARGET_DROP;

    set_interface(NULL,
                  refparam_to_objpath(object, "Interface"),
                  NULL,
                  &accept_udp_traceroute->common.dest_fwiface,
                  IPvAll);

    log_init(object, &accept_udp_traceroute->common.folders.log, &accept_udp_traceroute->common.dest_fwiface, !EXCLUDE_SRC_INTERFACE, NULL, !EXCLUDE_DST_INTERFACE, !USE_LOG_CONTROLLER_INTERFACE,
             true, log_get_dm_controller_param(object, NULL, "LogController"), accept_udp_traceroute->target4);

    log_init(object, &accept_udp_traceroute->log_ipv6, &accept_udp_traceroute->common.dest_fwiface, !EXCLUDE_SRC_INTERFACE, NULL, !EXCLUDE_DST_INTERFACE, !USE_LOG_CONTROLLER_INTERFACE,
             true, log_get_dm_controller_param(object, NULL, "LogController"), accept_udp_traceroute->target6);

    ret_value = 0;
exit:
    FW_PROFILING_OUT();
    return ret_value;
}

/**
   @brief
   Set the flags to "delete" and update the AcceptUDPTraceroute.

   @param[in] ifsetting InterfaceSetting's struct

   @return
   0 if success, 1 if failed.
 */
int fw_accept_udp_traceroute_cleanup(ifsetting_t* ifsetting) {
    accept_udp_traceroute_t* accept_udp_traceroute = NULL;
    bool res;
    int ret_value = 1;

    when_null(ifsetting, exit);

    accept_udp_traceroute = ifsetting->accept_udp_traceroute;
    if(accept_udp_traceroute != NULL) {
        accept_udp_traceroute->common.flags = FW_DELETED;
        res = accept_udp_traceroute_implement_changes(accept_udp_traceroute, IPvAll);
        when_false(res, exit);
    }

    ret_value = 0;
exit:
    return ret_value;
}

void _accept_udp_traceroute_changed(const char* const sig_name,
                                    const amxc_var_t* const event_data,
                                    UNUSED void* const priv) {
    FW_PROFILING_IN(TRACE_DM_EVENT);
    ifsetting_t* ifsetting = NULL;
    accept_udp_traceroute_t* accept_udp_traceroute = NULL;
    amxd_dm_t* dm = fw_get_dm();
    amxd_object_t* obj_setting = amxd_dm_signal_get_object(dm, event_data);
    amxc_var_t* var = NULL;
    bool changed_ipv4 = false;
    bool changed_ipv6 = false;
    ipversion_t ipversion = IPvAll;
    (void) sig_name; // when tracing is disabled, variable is not used anymore

    SAH_TRACEZ_NOTICE(ME, "Received event: %s", sig_name);

    when_null(dm, exit);
    when_null(obj_setting, exit);
    ifsetting = (ifsetting_t*) obj_setting->priv;
    when_null(ifsetting, exit);
    accept_udp_traceroute = ifsetting->accept_udp_traceroute;
    when_null(accept_udp_traceroute, exit);

    accept_udp_traceroute->common.flags = FW_MODIFIED;

    var = GETP_ARG(event_data, "parameters.IPv4AcceptUDPTraceroute");
    if(var != NULL) {
        accept_udp_traceroute->target4 = GET_BOOL(var, "to") ? TARGET_ACCEPT : TARGET_DROP;
        changed_ipv4 = true;
    }

    var = GETP_ARG(event_data, "parameters.IPv6AcceptUDPTraceroute");
    if(var != NULL) {
        accept_udp_traceroute->target6 = GET_BOOL(var, "to") ? TARGET_ACCEPT : TARGET_DROP;
        changed_ipv6 = true;
    }

    if(changed_ipv4) {
        log_set_policy(&accept_udp_traceroute->common.folders.log, accept_udp_traceroute->target4);
        log_update(&accept_udp_traceroute->common.folders.log, true,
                   log_get_dm_controller_param(obj_setting, event_data, "LogController"),
                   !EXCLUDE_SRC_INTERFACE, !EXCLUDE_DST_INTERFACE,
                   event_data);
        ipversion = IPv4;
    }

    if(changed_ipv6) {
        log_set_policy(&accept_udp_traceroute->log_ipv6, accept_udp_traceroute->target6);
        log_update(&accept_udp_traceroute->log_ipv6, true,
                   log_get_dm_controller_param(obj_setting, event_data, "LogController"),
                   !EXCLUDE_SRC_INTERFACE, !EXCLUDE_DST_INTERFACE,
                   event_data);
        ipversion = IPv6;
    }

    if(changed_ipv4 && changed_ipv6) {
        ipversion = IPvAll;
    }

    accept_udp_traceroute_implement_changes(accept_udp_traceroute, ipversion);
exit:
    FW_PROFILING_OUT();
    return;
}