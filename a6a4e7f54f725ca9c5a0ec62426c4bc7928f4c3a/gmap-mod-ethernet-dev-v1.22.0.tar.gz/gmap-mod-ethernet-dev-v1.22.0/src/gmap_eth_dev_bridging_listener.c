/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "gmap_eth_dev_bridging.h"
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_includes.h"
#include "gmap_eth_dev_util.h"

#include <features.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_path.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>

/*
   Bridge and port names and where they come from.
   ===============================================

   tr181-bridging/odl/tr181-bridging_defaults/00_bridging_defaults.odl.uc
   ----------------------------------------------------------------------
   lowercase(networklayout.json:bridges.[key]) -> Bridging.Bridge.*.Alias
   e.g. lan
   lowercase(networklayout.json:bridges.[key]) + "_bridge" -> Bridging.Bridge.*.Port.1.Alias
   e.g. lan_bridge
   networklayout.json:bridges.[key].Name -> Bridging.Bridge.*.Port.1.Name
   e.g. br-lan
   networklayout.json:bridges.[key].Ports[i].Alias -> Bridging.Bridge.*.Port.[i + 1].Alias + ("_vlan" if vlan else "")
   e.g. eth_port1
   e.g. wlan_port3
   e.g. moca_port0

   for ethernet ports only:
   networklayout.json:bridges.[key].Ports[i].Name -> Bridging.Bridge.*.Port.[i + 1].Name
   e.g. eth0_1

   tr181-bridging/odl/tr181-bridging.odl
   -------------------------------------
   "bridge-" + Bridging.Bridge.*.Port.*.Alias -> NetModel.Intf.["bridgeport" in Flags].Alias
                                           == "bridge-" + lowercase(networklayout.json:bridges.[key])

   tr181-bridging/src/bridging_utils.c:port_create_nm_query
   --------------------------------------------------------
   NetModel.Intf.[].NetDevName -> Bridging.Bridge.*.Port.[! ManagementPort && Enable].Name
   this may overwrite the name set from networklayout.json

   gmap-mod-self/src/gmap_self_disco.c:gmap_self_disco_start
   ---------------------------------------------------------
   NetModel.Intf.["bridge" in Flags].Name -> Devices.Device.["bridge" in Tags].NetDevName

   gmap-mod-self/src/gmap_self_eth.c:s_start_sync_params
   -----------------------------------------------------
   NetModel.Intf.[].NetDevName -> Devices.Device.["interface" in Tags && !("bridge" in Tags)].NetDevName

   netdev/src/dm_link.c:create_transaction_from_link
   -------------------------------------------------
   kernel interface index -> NetDev.Link.{i}
   kernel interface index -> NetDev.Link.{i}.Index
   kernel interface name -> NetDev.Link.{i}.Alias
   kernel interface name -> NetDev.Link.{i}.Name

   Therefore:
   ==========
   gmap-server port NetDevName == tr181-bridging non-management port Name
   gmap-server non-port interface NetDevName == tr181-bridging management port Name

   libc functions if_nametoindex and if_indextoname for fetching the index given
   an interface name and vice versa will return correct results and may be used
   instead of data model lookups.
 */


/** Port instance, manages a list of mac addresses */
typedef struct s_port {
    amxc_llist_it_t it;                     /**< Iterator, owned through s_bridge_t.ports */

    char* bridging_path;                    /**< Full Bridging.Bridge.{i}.Port.{i}. indexed path */
    uint32_t bridging_index;                /**< Index of the Bridging port instance */

    char* netdev_name;                      /**< Associated netdev name */
    uint32_t netdev_index;                  /**< Associated netdev index */

    amxc_set_t mac_addresses;               /**< Set of MAC addresses, only available when listening */
    amxc_llist_t subscribers;               /**< Non-owning list of subscribers for this port, maps to s_mac_subscription_t.it_port */

    amxb_subscription_t* on_macevent_cb;    /**< Subscription to the MacEvent! event */
} s_port_t;

/** Bridge instance, manages its list of ports */
typedef struct s_bridge {
    amxc_llist_it_t it;                     /**< Iterator, owned through s_bridging_t.bridges */

    char* bridging_path;                    /**< Full Bridging.Bridge.{i}. indexed path */
    char* bridging_port_path;               /**< Full Bridging.Bridge.{i}.Port.{i}. indexed path of the management port */
    uint32_t bridging_index;                /**< Index of the Bridging bridge instance */

    char* netdev_name;                      /**< Associated netdev name */
    uint32_t netdev_index;                  /**< Associated netdev index */

    amxc_llist_t ports;                     /**< Owning list of ports for this bridge, maps to s_port_t.it */
    amxc_llist_t subscribers;               /**< Non-owning list of subscribers for this port, maps to s_port_subscription_t.it_bridge */
} s_bridge_t;

/** A bridge port subscription. Subscriptions are specific to a given bridge combination */
typedef struct gmap_eth_dev_bridging_port_subscription {
    amxc_llist_it_t it_bridging;            /**< Iterator, owned through s_bridging_t.subscriptions */
    amxc_llist_it_t it_bridge;              /**< Iterator, *NOT* owned through s_bridge_t.subscribers */

    char* bridge_netdev_name;

    gmap_eth_dev_bridging_port_cb cb;
    void* priv;
} s_port_subscription_t;

/** A MAC address subscription. Subscriptions are specific to a given bridge/port combination */
typedef struct gmap_eth_dev_bridging_mac_subscription {
    amxc_llist_it_t it_bridging;            /**< Iterator, owned through s_bridging_t.subscriptions */
    amxc_llist_it_t it_port;                /**< Iterator, *NOT* owned through s_port_t.subscribers */

    char* bridge_netdev_name;
    char* port_netdev_name;

    gmap_eth_dev_bridging_addr_cb cb;
    void* priv;
} s_mac_subscription_t;

/** Root bridging listener instance */
typedef struct s_bridging {
    amxb_bus_ctx_t* ctx_bridging;

    amxc_llist_t bridges;                   /**< Owning list of bridges, maps to s_bridge_t.it */
    amxc_llist_t port_subscriptions;        /**< Owning list of subscriptions, maps to s_port_subscription_t.it */
    amxc_llist_t mac_subscriptions;         /**< Owning list of subscriptions, maps to s_mac_subscription_t.it */

    amxb_subscription_t* on_instance_cb;
    amxb_subscription_t* on_change_cb;
} s_bridging_t;

static s_bridging_t* s_bridging = NULL;


/**
 * Decomposes the given path and returns pointers to the various beginnings and
 * ends of the various path components.
 * For example:
 *
 * @verbatim
 *      Bridging.Bridge.2.Port.10.Parameter
 *       out_bridge_idx ^
 *    out_bridge_idx_end ^
 *                out_port_idx ^
 *              out_port_idx_end ^
 * @endverbatim
 *
 * If a pointer would point past the 0-terminator, it is set to NULL.
 */
static void s_port_path_decompose(const char* port_path,
                                  const char** out_bridge_idx,
                                  const char** out_bridge_idx_end,
                                  const char** out_port_idx,
                                  const char** out_port_idx_end) {
    const char* tmp;
    if(out_bridge_idx != NULL) {
        *out_bridge_idx = NULL;
    }
    if(out_bridge_idx_end != NULL) {
        *out_bridge_idx_end = NULL;
    }
    if(out_port_idx != NULL) {
        *out_port_idx = NULL;
    }
    if(out_port_idx_end != NULL) {
        *out_port_idx_end = NULL;
    }

    when_null(port_path, exit);

    when_false_trace(strncmp(port_path, "Bridging.Bridge.", 16) == 0, exit,
                     ERROR, "Not a bridge (port) path: '%s'", port_path);
    port_path += 16;
    when_str_empty(port_path, exit);

    if(out_bridge_idx != NULL) {
        *out_bridge_idx = port_path;
    }

    // port_path = {i}.Port.{i}.Parameter
    tmp = strchr(port_path, '.');
    if(tmp == NULL) {
        if(out_bridge_idx_end != NULL) {
            *out_bridge_idx_end = strchr(port_path, '\0');
        }
        goto exit;
    } else if(out_bridge_idx_end != NULL) {
        *out_bridge_idx_end = tmp;
    }
    when_null(tmp, exit);
    port_path = tmp + 1;

    // port_path = Port.{i}.Parameter
    when_false(strncmp(port_path, "Port.", 5) == 0, exit);
    port_path += 5;
    when_str_empty(port_path, exit);

    if(out_port_idx != NULL) {
        *out_port_idx = port_path;
    }

    // port_path = {i}.Parameter
    tmp = strchr(port_path, '.');
    if(out_port_idx_end != NULL) {
        *out_port_idx_end = tmp == NULL ? strchr(port_path, '\0') : tmp;
    }

exit:
    return;
}

static bool s_is_port_subobject_path(const char* path) {
    /* A full path is Bridging.Bridge.{i}.Port.{j}.[Parameter] and therefore
     * counts at most 5 '.'
     */
    int c = 0;

    while(c <= 5 && (path = strchr(path, '.')) != NULL) {
        ++c;
        ++path;
    }

    return c > 5;
}

static void s_port_path_get_indices(const char* path,
                                    uint32_t* out_bridge_idx,
                                    uint32_t* out_port_idx) {
    const char* bridge_idx_start;
    const char* bridge_idx_end;
    const char* port_idx_start;
    const char* port_idx_end;

    if(out_bridge_idx != NULL) {
        *out_bridge_idx = 0u;
    }
    if(out_port_idx != NULL) {
        *out_port_idx = 0u;
    }

    s_port_path_decompose(path,
                          &bridge_idx_start,
                          &bridge_idx_end,
                          &port_idx_start,
                          &port_idx_end);

    if(out_bridge_idx != NULL) {
        *out_bridge_idx = gmap_eth_dev_util_parse_index(bridge_idx_start, bridge_idx_end);
        when_true(*out_bridge_idx == 0, exit);
    }

    if(out_port_idx != NULL) {
        *out_port_idx = gmap_eth_dev_util_parse_index(port_idx_start, port_idx_end);
        when_true(*out_port_idx == 0, exit);
    }

exit:
    return;
}


static s_port_t* s_port_new(void) {
    s_port_t* port = malloc(sizeof(s_port_t));
    when_null_trace(port, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&port->it);
    port->bridging_path = NULL;
    port->bridging_index = 0;
    port->netdev_name = NULL;
    port->netdev_index = 0;
    amxc_set_init(&port->mac_addresses, false);
    amxc_llist_init(&port->subscribers);
    port->on_macevent_cb = NULL;

exit:
    return port;
}

static void s_port_delete(amxc_llist_it_t* it) {
    s_port_t* port = amxc_llist_it_get_data(it, s_port_t, it);

    amxb_subscription_delete(&port->on_macevent_cb);
    /* Not owned, so only remove items from list. */
    amxc_llist_clean(&port->subscribers, NULL);
    amxc_set_clean(&port->mac_addresses);
    free(port->bridging_path);
    free(port->netdev_name);

    free(port);
}

static void s_port_on_mac_event(UNUSED const char* const sig_name,
                                const amxc_var_t* const notification_data,
                                void* const priv) {
    s_port_t* port = priv;
    const size_t old_mac_count = amxc_set_get_count(&port->mac_addresses, NULL);
    const amxc_var_t* data = GET_ARG(notification_data, "data");
    const char* action = GET_CHAR(data, "Action");
    const char* address = GET_CHAR(data, "MACAddress");
    bool added;

    when_str_empty_trace(action, exit, ERROR, "MACEvent! without action");
    when_str_empty_trace(address, exit, ERROR, "MACEvent! without address");

    if(strcmp(action, "MAC_Added") == 0) {
        amxc_set_add_flag(&port->mac_addresses, address);
        added = true;
    } else if(strcmp(action, "MAC_Removed") == 0) {
        amxc_set_remove_flag(&port->mac_addresses, address);
        added = false;
    } else {
        SAH_TRACEZ_ERROR(ME, "MACEvent! with unknown action '%s'", action);
        goto exit;
    }

    if(old_mac_count != amxc_set_get_count(&port->mac_addresses, NULL)) {
        amxc_llist_for_each(it, &port->subscribers) {
            s_mac_subscription_t* subscriber = amxc_llist_it_get_data(it, s_mac_subscription_t, it_port);
            subscriber->cb(address, added, subscriber->priv);
        }
    }

exit:
    return;
}

static void s_port_fetch_mac(s_port_t* port) {
    int status;
    amxc_var_t ret;
    amxc_var_t* addresses = NULL;

    amxc_var_init(&ret);

    when_null(port, exit);

    status = amxb_call(gmap_eth_dev_bridging_ctx(), port->bridging_path, "GetMACList", NULL, &ret, 5);
    when_failed_trace(status, exit, ERROR,
                      "Failed to fetch the current known mac addresses for port %s at '%s'",
                      port->netdev_name, port->bridging_path);

    /* ret = ["", {mac_list = []}] */
    addresses = amxc_var_get_first(amxc_var_get_last(&ret));
    amxc_var_for_each(item, addresses) {
        const char* mac_addr = amxc_var_constcast(cstring_t, item);
        if((mac_addr != NULL) && (*mac_addr != '\0')) {
            amxc_set_add_flag(&port->mac_addresses, mac_addr);
        }
    }

exit:
    amxc_var_clean(&ret);
    return;
}

static void s_subscriber_detach_from_port(s_mac_subscription_t* subscriber) {
    s_port_t* port = NULL;
    when_null(subscriber, exit);
    when_null(subscriber->it_port.llist, exit);

    port = amxc_container_of(subscriber->it_port.llist, s_port_t, subscribers);
    amxc_llist_it_take(&subscriber->it_port);

    if(amxc_llist_is_empty(&port->subscribers)) {
        amxb_subscription_delete(&port->on_macevent_cb);
        amxc_set_clean(&port->mac_addresses);
    }

exit:
    return;
}

static void s_port_add_subscriber(s_port_t* port,
                                  s_mac_subscription_t* subscriber) {
    int status = -1;

    when_true(&port->subscribers == subscriber->it_port.llist, exit);   /* Already subscribed to this port */
    when_not_null_trace(subscriber->it_port.llist, exit, ERROR,
                        "BUG: attaching port subscriber that is already attached to another port.");

    amxc_llist_append(&port->subscribers, &subscriber->it_port);

    if(port->on_macevent_cb == NULL) {
        status = amxb_subscription_new(&port->on_macevent_cb,
                                       gmap_eth_dev_bridging_ctx(),
                                       port->bridging_path,
                                       "notification == 'MACEvent!'",
                                       s_port_on_mac_event, port);
        when_failed_trace(status, exit, ERROR,
                          "Failed to subscribe to MACEvent! for port %s at '%s'",
                          port->bridging_path, port->netdev_name);

        s_port_fetch_mac(port);
    }

    amxc_set_iterate(address, &port->mac_addresses) {
        subscriber->cb(address->flag, true, subscriber->priv);
    }

exit:
    return;
}

static void s_port_notify_all_existing(s_port_t* port, bool added) {
    when_null(port, exit);
    when_true(amxc_set_get_count(&port->mac_addresses, NULL) == 0, exit);

    amxc_llist_for_each(it_sub, &port->subscribers) {
        s_mac_subscription_t* sub = amxc_llist_it_get_data(it_sub, s_mac_subscription_t, it_port);
        amxc_set_iterate(flag, &port->mac_addresses) {
            sub->cb(flag->flag, added, sub->priv);
        }
    }

exit:
    return;
}



static s_bridge_t* s_bridge_new(void) {
    s_bridge_t* bridge = malloc(sizeof(s_bridge_t));
    when_null_trace(bridge, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&bridge->it);
    bridge->bridging_path = NULL;
    bridge->bridging_port_path = NULL;
    bridge->bridging_index = 0u;
    bridge->netdev_name = NULL;
    bridge->netdev_index = 0;
    amxc_llist_init(&bridge->ports);
    amxc_llist_init(&bridge->subscribers);

exit:
    return bridge;
}

static void s_bridge_delete(amxc_llist_it_t* it) {
    s_bridge_t* bridge = amxc_llist_it_get_data(it, s_bridge_t, it);

    amxc_llist_clean(&bridge->ports, s_port_delete);
    /* Not owned, so only remove items from list. */
    amxc_llist_clean(&bridge->subscribers, NULL);
    free(bridge->bridging_path);
    free(bridge->bridging_port_path);
    free(bridge->netdev_name);

    free(bridge);
}

static int s_bridge_fill_info(s_bridge_t* bridge,
                              const char* netdev_name,
                              const char* port_path) {
    int status = -1;
    const char* idx_start;
    const char* idx_end;
    uint32_t idx;

    s_port_path_decompose(port_path, &idx_start, &idx_end, NULL, NULL);
    when_true(idx_start == NULL || idx_end == NULL, exit);
    idx = gmap_eth_dev_util_parse_index(idx_start, idx_end);
    when_true_trace(idx == 0, exit, ERROR, "Invalid index or index out of range");

    bridge->netdev_name = strdup(netdev_name);
    when_null_trace(bridge->netdev_name, exit, ERROR, "Out of memory");
    bridge->netdev_index = gmap_eth_dev_util_netdev_idx_for_name(netdev_name);
    when_true(bridge->netdev_index == 0, exit);

    bridge->bridging_port_path = strdup(port_path);
    when_null_trace(bridge->bridging_port_path, exit, ERROR, "Out of memory");
    bridge->bridging_path = strndup(port_path, idx_end - port_path + 1);
    when_null_trace(bridge->bridging_path, exit, ERROR, "Out of memory");
    bridge->bridging_index = idx;

    status = 0;

exit:
    return status;
}

static s_port_t* s_bridge_find_port(const s_bridge_t* bridge,
                                    const char* netdev_name) {
    s_port_t* port = NULL;

    when_null(bridge, exit);
    when_str_empty(netdev_name, exit);

    amxc_llist_for_each(it, &bridge->ports) {
        s_port_t* entry = amxc_llist_it_get_data(it, s_port_t, it);
        if(strcmp(entry->netdev_name, netdev_name) == 0) {
            port = entry;
            break;
        }
    }

exit:
    return port;
}

static s_port_t* s_bridge_find_port_index(const s_bridge_t* bridge,
                                          uint32_t bridging_idx) {
    s_port_t* port = NULL;

    when_null(bridge, exit);

    amxc_llist_for_each(it, &bridge->ports) {
        s_port_t* entry = amxc_llist_it_get_data(it, s_port_t, it);
        if(entry->bridging_index == bridging_idx) {
            port = entry;
            break;
        }
    }

exit:
    return port;
}

static s_port_t* s_bridge_find_port_netdev_index(const s_bridge_t* bridge,
                                                 uint32_t netdev_idx) {
    s_port_t* port = NULL;

    when_null(bridge, exit);

    amxc_llist_for_each(it, &bridge->ports) {
        s_port_t* entry = amxc_llist_it_get_data(it, s_port_t, it);
        if(entry->netdev_index == netdev_idx) {
            port = entry;
            break;
        }
    }

exit:
    return port;
}

static void s_bridge_add_subscriber(s_bridge_t* bridge, s_port_subscription_t* subscriber) {
    gmap_eth_dev_bridging_port_data_t data = {
        .bridge = bridge->netdev_name,
        .bridge_index = bridge->netdev_index,
        0
    };

    when_true(&bridge->subscribers == subscriber->it_bridge.llist, exit);   /* Already subscribed to this bridge */

    amxc_llist_append(&bridge->subscribers, &subscriber->it_bridge);

    amxc_llist_iterate(it, &bridge->ports) {
        s_port_t* port = amxc_llist_it_get_data(it, s_port_t, it);
        data.port = port->netdev_name;
        data.port_index = port->netdev_index;
        subscriber->cb(&data, true, subscriber->priv);
    }

exit:
    return;
}

static void s_bridge_notify(s_bridge_t* bridge, s_port_t* port, bool added) {
    gmap_eth_dev_bridging_port_data_t data = {
        .bridge = bridge->netdev_name,
        .bridge_index = bridge->netdev_index,
        0
    };

    amxc_llist_iterate(it, &bridge->subscribers) {
        s_port_subscription_t* subscriber = amxc_llist_it_get_data(it, s_port_subscription_t, it_bridge);
        data.port = port->netdev_name;
        data.port_index = port->netdev_index;
        subscriber->cb(&data, added, subscriber->priv);
    }
}

static void s_bridge_notify_and_delete(s_bridge_t* bridge) {
    when_null(bridge, exit);
    amxc_llist_for_each(it, &bridge->ports) {
        s_port_t* entry = amxc_llist_it_get_data(it, s_port_t, it);
        s_port_notify_all_existing(entry, false);
        s_bridge_notify(bridge, entry, false);
    }
    amxc_llist_it_clean(&bridge->it, s_bridge_delete);

exit:
    return;
}



static void s_port_subscription_delete(amxc_llist_it_t* it);

static s_port_subscription_t* s_port_subscription_new(const char* bridge,
                                                      gmap_eth_dev_bridging_port_cb cb,
                                                      void* priv) {
    s_port_subscription_t* subscription = NULL;

    when_str_empty_trace(bridge, exit, ERROR, "NULL or empty string");
    when_str_empty_trace(cb, exit, ERROR, "NULL");

    subscription = malloc(sizeof(s_port_subscription_t));
    when_null_trace(subscription, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&subscription->it_bridging);
    amxc_llist_it_init(&subscription->it_bridge);
    subscription->cb = cb;
    subscription->priv = priv;
    subscription->bridge_netdev_name = strdup(bridge);

    when_null_trace(subscription->bridge_netdev_name, failure, ERROR, "Out of memory");

    goto exit;

failure:
    s_port_subscription_delete(&subscription->it_bridging);
    subscription = NULL;

exit:
    return subscription;
}

static void s_port_subscription_delete(amxc_llist_it_t* it) {
    s_port_subscription_t* subscription = amxc_llist_it_get_data(it, s_port_subscription_t, it_bridging);

    /* No need to take it_bridging, this function is called through the cleanup of that iterator. */
    amxc_llist_it_take(&subscription->it_bridge); /* Not owned, so no cleanup of items. */
    free(subscription->bridge_netdev_name);

    free(subscription);
}



static void s_mac_subscription_delete(amxc_llist_it_t* it);

static s_mac_subscription_t* s_mac_subscription_new(const char* bridge,
                                                    const char* port,
                                                    gmap_eth_dev_bridging_addr_cb cb,
                                                    void* priv) {
    s_mac_subscription_t* subscription = NULL;

    when_str_empty_trace(bridge, exit, ERROR, "NULL or empty string");
    when_str_empty_trace(port, exit, ERROR, "NULL or empty string");
    when_str_empty_trace(cb, exit, ERROR, "NULL");

    subscription = malloc(sizeof(s_mac_subscription_t));
    when_null_trace(subscription, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&subscription->it_bridging);
    amxc_llist_it_init(&subscription->it_port);
    subscription->cb = cb;
    subscription->priv = priv;
    subscription->bridge_netdev_name = strdup(bridge);
    subscription->port_netdev_name = strdup(port);

    when_null_trace(subscription->bridge_netdev_name, failure, ERROR, "Out of memory");
    when_null_trace(subscription->port_netdev_name, failure, ERROR, "Out of memory");

    goto exit;

failure:
    s_mac_subscription_delete(&subscription->it_bridging);
    subscription = NULL;

exit:
    return subscription;
}

static void s_mac_subscription_delete(amxc_llist_it_t* it) {
    s_mac_subscription_t* subscription = amxc_llist_it_get_data(it, s_mac_subscription_t, it_bridging);

    /* No need to take it_bridging, this function is called through the cleanup of that iterator. */
    amxc_llist_it_take(&subscription->it_port); /* Not owned, so no cleanup of items. */
    free(subscription->bridge_netdev_name);
    free(subscription->port_netdev_name);

    free(subscription);
}



static s_bridge_t* s_bridging_find_bridge(const s_bridging_t* bridging,
                                          const char* netdev_name) {
    s_bridge_t* bridge = NULL;

    when_null(bridging, exit);
    when_str_empty(netdev_name, exit);

    amxc_llist_for_each(it, &bridging->bridges) {
        s_bridge_t* entry = amxc_llist_it_get_data(it, s_bridge_t, it);
        if(strcmp(entry->netdev_name, netdev_name) == 0) {
            bridge = entry;
            break;
        }
    }

exit:
    return bridge;
}

static s_bridge_t* s_bridging_find_bridge_index(const s_bridging_t* bridging,
                                                uint32_t bridge_idx) {
    s_bridge_t* bridge = NULL;

    when_null(bridging, exit);

    amxc_llist_for_each(it, &bridging->bridges) {
        s_bridge_t* entry = amxc_llist_it_get_data(it, s_bridge_t, it);
        if(entry->bridging_index == bridge_idx) {
            bridge = entry;
            break;
        }
    }

exit:
    return bridge;
}

static void s_bridging_add_all_port_subscribers(s_bridging_t* bridging,
                                                s_bridge_t* bridge) {
    amxc_llist_for_each(it, &bridging->port_subscriptions) {
        s_port_subscription_t* subscriber = amxc_llist_it_get_data(it, s_port_subscription_t, it_bridging);
        if(strcmp(subscriber->bridge_netdev_name, bridge->netdev_name) == 0) {
            amxc_llist_append(&bridge->subscribers, &subscriber->it_bridge);
        }
    }
}

static void s_bridging_add_all_subscribers(s_bridging_t* bridging,
                                           s_bridge_t* bridge,
                                           s_port_t* port) {
    amxc_llist_for_each(it, &bridging->mac_subscriptions) {
        s_mac_subscription_t* subscriber = amxc_llist_it_get_data(it, s_mac_subscription_t, it_bridging);
        if((strcmp(subscriber->bridge_netdev_name, bridge->netdev_name) == 0) &&
           (strcmp(subscriber->port_netdev_name, port->netdev_name) == 0)) {
            s_port_add_subscriber(port, subscriber);
        }
    }
}

/**
 * Performs an initial fetch for the given port selector.
 * Already known ports are ignored with an error logged.
 */
static int s_bridging_initial_fetch(s_bridging_t* bridging,
                                    const char* port_selector);

static void s_bridging_on_instance(UNUSED const char* const sig_name,
                                   const amxc_var_t* const notification_data,
                                   void* const priv) {
    s_bridging_t* bridging = priv;
    const char* path = GET_CHAR(notification_data, "path");
    const char* notification = GET_CHAR(notification_data, "notification");
    bool removed;
    uint32_t bridge_idx;
    s_bridge_t* bridge = NULL;
    uint32_t port_idx;
    s_port_t* port = NULL;
    amxc_string_t tmp;
    const char* netdev_name;

    amxc_string_init(&tmp, 0);

    when_str_empty_trace(path, exit, ERROR, "NULL/empty path");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty notification");

    if(strcmp(notification, "dm:instance-added") == 0) {
        removed = false;
    } else if(strcmp(notification, "dm:instance-removed") == 0) {
        removed = true;
    } else {
        /* Ignore events we don't care about */
        goto exit;
    }

    if(strcmp(path, "Bridging.Bridge.") == 0) {
        /* Bridge instance added/removed */
        bridge_idx = GET_UINT32(notification_data, "index");
        when_true(bridge_idx == 0, exit);
        bridge = s_bridging_find_bridge_index(bridging, bridge_idx);
        if(removed) {
            /* The entire bridge was removed */
            s_bridge_notify_and_delete(bridge);
            bridge = NULL;
        } else if(bridge == NULL) {
            /* A new bridge was added, simply read the entire dm and handle it in one go */
            amxc_string_setf(&tmp, "Bridging.Bridge.%" PRIu32 ".Port.*.", bridge_idx);
            s_bridging_initial_fetch(bridging, amxc_string_get(&tmp, 0));
        } /* Else, ignore instance-added for known bridge */
    } else {
        /* Port instance added/removed */
        s_port_path_get_indices(path, &bridge_idx, NULL);
        port_idx = GET_UINT32(notification_data, "index");
        when_true(bridge_idx == 0 || port_idx == 0, exit);
        bridge = s_bridging_find_bridge_index(bridging, bridge_idx);
        if(removed) {
            when_null(bridge, exit);
            amxc_string_setf(&tmp, "Bridging.Bridge.%" PRIu32 ".Port.%" PRIu32 ".",
                             bridge_idx, port_idx);
            if(strcmp(bridge->bridging_port_path, amxc_string_get(&tmp, 0)) == 0) {
                /* The management port of a bridge was removed */
                s_bridge_notify_and_delete(bridge);
            } else {
                port = s_bridge_find_port_index(bridge, port_idx);
                when_null(port, exit);

                s_port_notify_all_existing(port, false);
                s_bridge_notify(bridge, port, false);
                amxc_llist_it_clean(&port->it, s_port_delete);
            }
        } else if(GET_BOOL(GET_ARG(notification_data, "parameters"), "ManagementPort")) {
            when_not_null(bridge, exit);
            /* A new unknown management port is added, fetch any ports we may have missed. */
            amxc_string_setf(&tmp, "Bridging.Bridge.%" PRIu32 ".Port.*.", bridge_idx);
            s_bridging_initial_fetch(bridging, amxc_string_get(&tmp, 0));
        } else if(bridge != NULL) {
            port = s_bridge_find_port_index(bridge, port_idx);
            when_not_null(port, exit);
            netdev_name = GET_CHAR(GET_ARG(notification_data, "parameters"), "Name");
            /* A new regular port was added to a known bridge */
            port = s_port_new();
            when_null(port, exit);
            when_str_empty(netdev_name, exit);

            port->bridging_path = strdup(path);
            when_null_trace(port->bridging_path, failure, ERROR, "Out of memory");
            port->bridging_index = port_idx;
            port->netdev_name = strdup(netdev_name);
            when_null_trace(port->netdev_name, failure, ERROR, "Out of memory");
            port->netdev_index = gmap_eth_dev_util_netdev_idx_for_name(netdev_name);
            when_true(port->netdev_index == 0, failure);

            amxc_llist_append(&bridge->ports, &port->it);
            s_bridge_notify(bridge, port, true);

            /* Will also call their callbacks */
            s_bridging_add_all_subscribers(bridging, bridge, port);

            SAH_TRACEZ_INFO(ME, "Found port '%s' at '%s' (managed by bridge '%s)') with netdev index %" PRIu32,
                            port->netdev_name, port->bridging_path, bridge->netdev_name, port->netdev_index);

            goto exit;

failure:
            amxc_llist_it_clean(&port->it, s_port_delete);
        }
    }

exit:
    amxc_string_clean(&tmp);
    return;
}

static void s_bridging_on_change(UNUSED const char* const sig_name,
                                 const amxc_var_t* const notification_data,
                                 void* const priv) {
    s_bridging_t* bridging = priv;
    const char* path = GET_CHAR(notification_data, "path");
    const char* notification = GET_CHAR(notification_data, "notification");
    const amxc_var_t* params = GET_ARG(notification_data, "parameters");
    uint32_t bridge_idx = 0u;
    uint32_t port_idx = 0u;
    s_bridge_t* bridge = NULL;
    s_port_t* port = NULL;
    const char* new_name = GET_CHAR(GET_ARG(params, "Name"), "to");
    const amxc_var_t* param_mgmt = GET_ARG(GET_ARG(params, "ManagementPort"), "to");
    bool has_new_mgmt = param_mgmt != NULL;
    bool new_mgmt = GET_BOOL(param_mgmt, NULL);
    bool new_bridge = false;
    int new_bridge_count = 0;
    amxc_string_t tmp;

    amxc_string_init(&tmp, 0);

    when_str_empty_trace(path, exit, ERROR, "NULL/empty path");
    when_str_empty_trace(notification, exit, ERROR, "NULL/empty notification");
    when_true(s_is_port_subobject_path(path), exit);

    s_port_path_get_indices(path, &bridge_idx, &port_idx);
    when_true(bridge_idx == 0 || port_idx == 0, exit);

    bridge = s_bridging_find_bridge_index(bridging, bridge_idx);
    port = s_bridge_find_port_index(bridge, port_idx);

    if(has_new_mgmt) {
        if(bridge != NULL) {
            /* A known bridge changed management port; shouldn't happen. */
            s_bridge_notify_and_delete(bridge);
            bridge = NULL;
            port = NULL;
        }
        when_true(new_mgmt, init_bridge);
        /* An unknown bridge lost its management port. Just exit and wait until
         * a new bridge management port is assigned before reloading the data.
         */
        goto exit;
    }

    when_null(new_name, exit);

    when_true(port != NULL && strcmp(new_name, port->netdev_name) == 0, exit);
    /* in case we're dealing with this bridges management port */
    when_true(bridge != NULL && strcmp(new_name, bridge->netdev_name) == 0, exit);

    if(port != NULL) {
        /* Port changed name. Pretend it disappeared and reappeared again. */
        s_port_notify_all_existing(port, false);
        s_bridge_notify(bridge, port, false);
        amxc_llist_it_clean(&port->it, s_port_delete);
        port = NULL;
    } else if((bridge != NULL) && (strcmp(path, bridge->bridging_port_path) == 0)) {
        /* The management port of a bridge changed name.
         * Fetch the entire structure again. */
        s_bridge_notify_and_delete(bridge);
        bridge = NULL;
        port = NULL;
        goto init_bridge;
    }

    goto fetch_data;

init_bridge:
    amxc_string_setf(&tmp, "Bridging.Bridge.%" PRIu32 ".Port.*.", bridge_idx);
    path = amxc_string_get(&tmp, 0);
    new_bridge = true;

fetch_data:
    when_str_empty(new_name, exit);
    /* New port name. Just fetch the most up-to-date information.
     * This will eventually fetch the mac addresses and call the subscribers. */
    new_bridge_count = s_bridging_initial_fetch(bridging, path);

    when_true(new_bridge || new_bridge_count <= 0, exit);

    /* Fetching the existing port unexpectedly resulted in creating a new bridge.
     * Fetch all its ports again to make sure we didn't miss any. */
    SAH_TRACEZ_WARNING(ME, "Re-initializing unexpected new bridge");
    amxc_string_setf(&tmp, "Bridging.Bridge.%" PRIu32 ".Port.*.", bridge_idx);
    path = amxc_string_get(&tmp, 0);
    s_bridging_initial_fetch(bridging, path);

exit:
    amxc_string_clean(&tmp);
    return;
}

static bool s_bridging_handle_mgmt_port(s_bridging_t* bridging,
                                        const char* path,
                                        const amxc_var_t* data) {
    bool success = false;
    s_bridge_t* bridge;
    const char* netdev_name = GET_CHAR(data, "Name");

    when_str_empty_trace(path, exit, ERROR, "NULL or empty string");
    when_str_empty_trace(netdev_name, exit, INFO,
                         "Skipping port without name at '%s'",
                         path);

    bridge = s_bridging_find_bridge(bridging, netdev_name);
    when_not_null_trace(bridge, exit, ERROR,
                        "Multiple management ports for bridge '%s'", netdev_name);

    bridge = s_bridge_new();
    when_null(bridge, exit);

    when_failed(s_bridge_fill_info(bridge, netdev_name, path), failure);
    amxc_llist_append(&bridging->bridges, &bridge->it);

    s_bridging_add_all_port_subscribers(bridging, bridge);

    SAH_TRACEZ_INFO(ME, "Found bridge '%s' at '%s' (managed at '%s)') with netdev index %" PRIu32,
                    bridge->netdev_name, bridge->bridging_path, bridge->bridging_port_path, bridge->netdev_index);

    success = true;
    goto exit;

failure:
    amxc_llist_it_clean(&bridge->it, s_bridge_delete);

exit:
    return success;
}

static void s_bridging_handle_port(s_bridging_t* bridging,
                                   const char* path,
                                   const amxc_var_t* data) {
    s_port_t* port;
    s_bridge_t* bridge;
    const char* netdev_name = GET_CHAR(data, "Name");
    uint32_t bridge_idx;
    uint32_t port_idx;

    when_str_empty_trace(path, exit, ERROR, "NULL or empty string");
    when_str_empty_trace(netdev_name, exit, WARNING,
                         "Skipping port without name at '%s'",
                         path);

    s_port_path_get_indices(path, &bridge_idx, &port_idx);
    when_true_trace(bridge_idx == 0 || port_idx == 0, exit, ERROR,
                    "Can't create port entry without valid path");

    bridge = s_bridging_find_bridge_index(bridging, bridge_idx);
    when_null_trace(bridge, exit, WARNING,
                    "Skipping port '%s' with unknown management port",
                    path);

    port = s_bridge_find_port(bridge, netdev_name);
    when_not_null_trace(port, exit, ERROR,
                        "Multiple ports with the same name '%s' for bridge '%s'",
                        netdev_name, bridge->netdev_name);

    port = s_port_new();
    when_null(port, exit);

    port->bridging_path = strdup(path);
    when_null_trace(port->bridging_path, failure, ERROR, "Out of memory");
    port->bridging_index = port_idx;
    port->netdev_name = strdup(netdev_name);
    when_null_trace(port->netdev_name, failure, ERROR, "Out of memory");
    port->netdev_index = gmap_eth_dev_util_netdev_idx_for_name(netdev_name);
    when_true(port->netdev_index == 0, failure);

    amxc_llist_append(&bridge->ports, &port->it);
    s_bridge_notify(bridge, port, true);

    /* Will also call their callbacks */
    s_bridging_add_all_subscribers(bridging, bridge, port);

    SAH_TRACEZ_INFO(ME, "Found port '%s' at '%s' (managed by bridge '%s)') with netdev index %" PRIu32,
                    port->netdev_name, port->bridging_path, bridge->netdev_name, port->netdev_index);

    goto exit;

failure:
    amxc_llist_it_clean(&port->it, s_port_delete);

exit:
    return;
}

static int s_bridging_initial_fetch(s_bridging_t* bridging,
                                    const char* port_selector) {
    int status = -1;
    amxc_var_t ret;
    amxc_var_t* ports;

    amxc_var_init(&ret);

    SAH_TRACEZ_INFO(ME, "Fetching ports for '%s'", port_selector);

    status = amxb_get(gmap_eth_dev_bridging_ctx(), port_selector, 0, &ret, GMAP_ETH_DEV_BUS_TIMEOUT_SEC);
    if(status != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to fetch initial bridging state for '%s': %d",
                         port_selector, status);
        status = status > 0 ? -status : status;
        goto exit;
    }

    status = 0;

    ports = amxc_var_get_first(&ret);
    when_null(ports, exit);

    /* For each management port, create a bridge */
    amxc_var_for_each(var, ports) {
        if(GET_BOOL(var, "ManagementPort")) {
            if(s_bridging_handle_mgmt_port(bridging, amxc_var_key(var), var)) {
                ++status;
            }
            amxc_var_delete(&var);
        }
    }

    /* For each remaining regular port, try to attach it to a bridge */
    amxc_var_for_each(var, ports) {
        s_bridging_handle_port(bridging, amxc_var_key(var), var);
    }

exit:
    amxc_var_clean(&ret);
    return status;
}

static void s_bridging_delete(s_bridging_t* bridging);

static s_bridging_t* s_bridging_new(void) {
    s_bridging_t* bridging = malloc(sizeof(s_bridging_t));
    when_null_trace(bridging, exit, ERROR, "Out of memory");

    amxc_llist_init(&bridging->bridges);
    amxc_llist_init(&bridging->port_subscriptions);
    amxc_llist_init(&bridging->mac_subscriptions);
    bridging->ctx_bridging = gmap_eth_dev_bridging_ctx();
    bridging->on_instance_cb = NULL;
    bridging->on_change_cb = NULL;

    when_null_trace(bridging->ctx_bridging, failure, ERROR, "Bridging bus context not known, is bridging properly initialized?");

    when_failed_trace(amxb_subscription_new(&bridging->on_instance_cb,
                                            bridging->ctx_bridging,
                                            "Bridging.Bridge.",
                                            "(notification == 'dm:instance-added' || notification == 'dm:instance-removed') && "
                                            "path matches '^Bridging\\.Bridge\\.(([0-9]+)\\.Port\\.)?$'",
                                            s_bridging_on_instance,
                                            bridging),
                      failure, ERROR,
                      "Failed to subscribe to Bridging.Bridge. instance events.");

    when_failed_trace(amxb_subscription_new(&bridging->on_change_cb,
                                            bridging->ctx_bridging,
                                            "Bridging.Bridge.",
                                            "notification == 'dm:object-changed' && "
                                            "(contains('parameters.ManagementPort') ||"
                                            " contains('parameters.Name'))",
                                            s_bridging_on_change,
                                            bridging),
                      failure, ERROR,
                      "Failed to subscribe to Bridging.Bridge. instance events.");

    s_bridging_initial_fetch(bridging, "Bridging.Bridge.*.Port.*.");

    goto exit;

failure:
    s_bridging_delete(bridging);
    bridging = NULL;

exit:
    return bridging;
}

static void s_bridging_delete(s_bridging_t* bridging) {
    when_null(bridging, exit);

    amxb_subscription_delete(&bridging->on_change_cb);
    amxb_subscription_delete(&bridging->on_instance_cb);
    amxc_llist_clean(&bridging->mac_subscriptions, s_mac_subscription_delete);
    amxc_llist_clean(&bridging->port_subscriptions, s_port_subscription_delete);
    amxc_llist_clean(&bridging->bridges, s_bridge_delete);

    free(bridging);

exit:
    return;
}

static void s_bridging_add_port_subscription(s_bridging_t* bridging,
                                             s_port_subscription_t* subscription) {
    s_bridge_t* bridge = s_bridging_find_bridge(bridging, subscription->bridge_netdev_name);

    amxc_llist_append(&bridging->port_subscriptions, &subscription->it_bridging);

    if(bridge != NULL) {
        s_bridge_add_subscriber(bridge, subscription);
    }
}

static void s_bridging_add_mac_subscription(s_bridging_t* bridging,
                                            s_mac_subscription_t* subscription) {
    s_bridge_t* bridge = s_bridging_find_bridge(bridging, subscription->bridge_netdev_name);
    s_port_t* port = s_bridge_find_port(bridge, subscription->port_netdev_name);

    amxc_llist_append(&bridging->mac_subscriptions, &subscription->it_bridging);

    if(port != NULL) {
        s_port_add_subscriber(port, subscription);
    }
}



int gmap_eth_dev_bridging_init(void) {
    when_not_null(s_bridging, exit);

    s_bridging = s_bridging_new();

exit:
    return s_bridging == NULL ? -1 : 0;
}

void gmap_eth_dev_bridging_clean(void) {
    when_null(s_bridging, exit);

    s_bridging_delete(s_bridging);
    s_bridging = NULL;

exit:
    return;
}

void gmap_eth_dev_bridging_subscribe_port(gmap_eth_dev_bridging_port_subscription_t** subscription,
                                          const char* bridge_netdev_name,
                                          gmap_eth_dev_bridging_port_cb cb,
                                          void* priv) {
    when_null_trace(s_bridging, exit, ERROR, "Bridging not initialized");
    when_null_trace(subscription, exit, ERROR, "NULL");

    *subscription = s_port_subscription_new(bridge_netdev_name, cb, priv);
    when_null(*subscription, exit);

    s_bridging_add_port_subscription(s_bridging, *subscription);

exit:
    return;
}

void gmap_eth_dev_bridging_unsubscribe_port(gmap_eth_dev_bridging_port_subscription_t** subscription) {
    when_null(subscription, exit);
    when_null(*subscription, exit);

    amxc_llist_it_take(&(*subscription)->it_bridge);
    amxc_llist_it_clean(&(*subscription)->it_bridging, s_port_subscription_delete);

    *subscription = NULL;

exit:
    return;
}

void gmap_eth_dev_bridging_subscribe_mac(gmap_eth_dev_bridging_mac_subscription_t** subscription,
                                         const char* bridge_netdev_name,
                                         const char* port_netdev_name,
                                         gmap_eth_dev_bridging_addr_cb cb,
                                         void* priv) {
    when_null_trace(s_bridging, exit, ERROR, "Bridging not initialized");
    when_null_trace(subscription, exit, ERROR, "NULL");

    *subscription = s_mac_subscription_new(bridge_netdev_name, port_netdev_name, cb, priv);
    when_null(*subscription, exit);

    s_bridging_add_mac_subscription(s_bridging, *subscription);

exit:
    return;
}

void gmap_eth_dev_bridging_unsubscribe_mac(gmap_eth_dev_bridging_mac_subscription_t** subscription) {
    when_null(subscription, exit);
    when_null(*subscription, exit);

    s_subscriber_detach_from_port(*subscription);
    amxc_llist_it_clean(&(*subscription)->it_bridging, s_mac_subscription_delete);

    *subscription = NULL;

exit:
    return;
}

amxc_htable_t* gmap_eth_dev_bridging_macs_for_port(uint32_t port_netdev_index) {
    amxc_htable_t* table = NULL;
    s_port_t* port = NULL;
    bool do_fetch = false;

    when_null_trace(s_bridging, exit, ERROR, "Bridging not initialized");

    amxc_llist_for_each(it, &s_bridging->bridges) {
        s_bridge_t* bridge = amxc_llist_it_get_data(it, s_bridge_t, it);
        port = s_bridge_find_port_netdev_index(bridge, port_netdev_index);
        if(port != NULL) {
            break;
        }
    }

    when_null(port, exit);
    /* The port is known, but not actively being monitored. Fetch its mac addresses anyway */
    do_fetch = port->on_macevent_cb == NULL;

    if(do_fetch) {
        s_port_fetch_mac(port);
    }

    when_true(amxc_set_get_count(&port->mac_addresses, NULL) == 0, exit);

    when_failed_trace(amxc_htable_new(&table, amxc_set_get_count(&port->mac_addresses, NULL)),
                      exit, ERROR, "Out of memory");
    amxc_set_iterate(flag, &port->mac_addresses) {
        amxc_var_t* entry;
        when_failed_trace(amxc_var_new(&entry), exit, ERROR, "Out of memory");
        amxc_var_set(uint32_t, entry, port_netdev_index);
        if(amxc_htable_insert(table, flag->flag, &entry->hit) != 0) {
            amxc_var_delete(&entry);
            SAH_TRACEZ_ERROR(ME, "Failed to add entry to table");
        }
    }

exit:
    if((port != NULL) && do_fetch) {
        amxc_set_clean(&port->mac_addresses);
    }
    return table;
}
