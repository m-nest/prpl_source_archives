%populate {
    object DHCPv4Client {
        object Client {
            instance add('lan') {
                parameter 'PassthroughDHCPPool' = "";
                parameter 'Enable' = true;
                parameter 'Interface' = "${ip_intf_lan}";
                parameter 'ResetOnPhysDownTimeout' = 20000;
                parameter 'IncludeClientId' = "MACAddress";
                parameter 'PassthroughEnable' = false;
                parameter 'Controller' = "mod-dhcpv4c";
                object 'SentOption' {
                    instance add('cpe-SentOption-1') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 61;
                        parameter 'Value' = "";
                    }
                    instance add('cpe-SentOption-2') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 12;
                        parameter 'Value' = "4F70656E575254";
                    }
                    instance add('cpe-SentOption-3') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 60;
                        parameter 'Value' = "7072706C2064686370";
                    }
m4_ifdef(`CONFIG_SAH_AMX_TR181_DHCPV4CLIENT_SENTOPTION_125', `
                    instance add("sent-option-125") {
                        parameter "Enable" = true;
                        parameter "Tag" = 125;  // vendor-specific information option
                        parameter "Alias" = "sent-option-125";
                        parameter "Value" = "CONFIG_SAH_AMX_TR181_DHCPV4CLIENT_SENTOPTION_125";
                    }
')
                    instance add("cpe-SentOption-124") {
                        parameter "Enable" = true;
                        parameter "Tag" = 124; // vendor-class option
                        parameter "Alias" = "cpe-SentOption-124";
                        parameter "Value" = "${vendor_class_dslforum_org_usp}";
                    }
                }
                object 'ReqOption' {
                    instance add('cpe-ReqOption-1') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 1;
                    }
                    instance add('cpe-ReqOption-2') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 3;
                    }
                    instance add('cpe-ReqOption-3') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 6;
                    }
                    instance add('cpe-ReqOption-4') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 15;
                    }
                    instance add('cpe-ReqOption-5') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 43;
                    }
                    instance add('cpe-ReqOption-6') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 51;
                    }
                    instance add('cpe-ReqOption-7') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 58;
                    }
                    instance add('cpe-ReqOption-8') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 59;
                    }
                    instance add('cpe-ReqOption-9') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 121;
                    }
                    instance add('cpe-ReqOption-10') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 212;
                    }
                    instance add('cpe-ReqOption-11') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 42;
                    }
                    instance add('cpe-option-timezone') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 100;
                    }
                    instance add('cpe-ReqOption-12') {
                        parameter 'Enable' = true;
                        parameter 'Tag' = 125;
                    }
                }
            }
        }
    }
}
