/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <string.h>
#include <cmocka.h>

#include <yajl/yajl_gen.h>
#include <yajl/yajl_parse.h>

#include <debug/sahtrace.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxj/amxj_variant.h>

#include <lcm/lcm_assert.h>
#include <lcm/lcm_helpers.h>
#include <lcm/amxc_data.h>

#include <cthulhu/cthulhu_config.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include "cthulhu_lpm_defines.h"
#include "cthulhu_lpm.h"
#include "ctr_policy.h"
#include "utils.h"
#include "test_policy.h"

#define UNUSED __attribute__((unused))

static void p_assert_null(void* val) {
    if(val) {
        printf("ERROR ASSERT\n");
    } else {
        printf("ASSERT OK\n");
    }
    assert_null(val);
}
static void p_assert_non_null(void* val) {
    if(!val) {
        printf("ERROR ASSERT\n");
    } else {
        printf("ASSERT OK\n");
    }
    assert_non_null(val);
}
static void p_assert_string_equal(const char* a, const char* b) {
    if(strcmp(a, b)) {
        printf("ERROR ASSERT [%s][%s]\n", a, b);
    } else {
        printf("ASSERT OK\n");
    }
    assert_string_equal(a, b);
}

static void p_assert_int_equal(int a, int b) {

    if(a != b) {
        printf("ERROR ASSERT [%d][%d]\n", a, b);
    } else {
        printf("ASSERT OK\n");
    }
    assert_int_equal(a, b);
}

static void p_assert_int_not_equal(int a, int b) {

    if(a == b) {
        printf("ERROR ASSERT [%d][%d]\n", a, b);
    } else {
        printf("ASSERT OK\n");
    }
    assert_int_not_equal(a, b);
}

static amxc_var_t* policydesc = NULL;
static amxd_dm_t datamodel;
static amxo_parser_t parser;

int test_policy_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;

    sahTraceOpen("test", TRACE_TYPE_STDOUT);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "all");

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);
    root_obj = amxd_dm_get_root(&datamodel);
    assert_int_equal(amxo_parser_parse_file(&parser, "testdm.odl", root_obj), 0);

    setbuf(stdout, NULL);

    return res;
}

int test_policy_teardown(UNUSED void** state) {
    int res = 0;

    amxo_parser_clean(&parser);
    amxd_dm_clean(&datamodel);

    return res;
}

static void print_variant(amxc_var_t* var) {
    amxc_var_t var_copy;
    amxc_var_init(&var_copy);
    amxc_var_convert(&var_copy, var, AMXC_VAR_ID_JSON);
    const char* cstr = amxc_var_constcast(jstring_t, &var_copy);
    printf("=> %s\n", cstr);
    amxc_var_clean(&var_copy);
}

static amxc_var_t* get_item(amxc_var_t* itemlist, const char* id, const char* idkey) {
    const amxc_llist_t* llist_item = amxc_var_constcast(amxc_llist_t, itemlist);
    amxc_llist_for_each(it, llist_item) {
        amxc_var_t* item = amxc_var_from_llist_it(it);
        const char* id_ = GET_CHAR(item, idkey);
        if(!strcmp(id, id_)) {
            return item;
        }
    }
    return NULL;
}
static amxc_var_t* get_container(amxc_var_t* sblist, const char* id) {
    return get_item(sblist, id, "LinkedUUID");
}
/*static amxc_var_t* get_container_by_id(amxc_var_t* sblist, const char* id) {
    return get_item(sblist, id, "ContainerId");
   }*/

static void init_lists(amxc_var_t* l1, amxc_var_t* l2, amxc_var_t* l3, amxc_var_t* l4, amxc_var_t* l5) {
    amxc_var_init(l1);
    amxc_var_init(l2);
    amxc_var_init(l3);
    amxc_var_init(l4);
    amxc_var_init(l5);
    amxc_var_set_type(l1, AMXC_VAR_ID_LIST);
    amxc_var_set_type(l2, AMXC_VAR_ID_LIST);
    amxc_var_set_type(l3, AMXC_VAR_ID_LIST);
    amxc_var_set_type(l4, AMXC_VAR_ID_LIST);
    amxc_var_set_type(l5, AMXC_VAR_ID_LIST);
}

static void clean_lists(amxc_var_t* l1, amxc_var_t* l2, amxc_var_t* l3, amxc_var_t* l4, amxc_var_t* l5) {
    amxc_var_clean(l1);
    amxc_var_clean(l2);
    amxc_var_clean(l3);
    amxc_var_clean(l4);
    amxc_var_clean(l5);
}

static policy_action_t get_policy_action_ctr(policy_event_t policy_event, const char* id) {
    return get_policy_action(policy_event, id, GET_ARG(policydesc, "containerpolicy"), "uuid", NULL);
}

static void change_policy_file(const char* file) {
    amxd_trans_t trans;
    amxd_object_t* obj = amxd_dm_findf(&datamodel, LPMC);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&trans, obj);
    amxd_trans_set_cstring_t(&trans, "PolicyFile", file);
    amxd_status_t status = amxd_trans_apply(&trans, &datamodel);
    assert_int_equal(status, amxd_status_ok);
    amxd_trans_clean(&trans);
}

amxd_status_t _LocalManagement_info(UNUSED amxd_object_t* obj,
                                    UNUSED amxd_function_t* func,
                                    UNUSED amxc_var_t* args,
                                    UNUSED amxc_var_t* ret);
amxd_status_t _LocalManagement_info(UNUSED amxd_object_t* obj,
                                    UNUSED amxd_function_t* func,
                                    UNUSED amxc_var_t* args,
                                    UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

void test_apply_policy1(UNUSED void** state) {
    load_json("policy1.json", &policydesc);

    printf("1ST TEST:\n");
    assert_int_equal(get_policy_action_ctr(PE_ONEXISTING, "37a49331-0b30-4afc-8e3e-2a33e5f560b7"), PA_UNINSTALL);
    assert_int_equal(get_policy_action_ctr(PE_ONEXISTING, "edc8f3cb-e91a-4c8c-88e8-043a4ff96ee0"), PA_UNINSTALL);
    assert_int_equal(get_policy_action_ctr(PE_ONEXISTING, "994dfcae-0458-43af-9b04-70a3f688ae7a"), PA_IGNORE);
    assert_int_equal(get_policy_action_ctr(PE_ONNEW, "37a49331-0b30-4afc-8e3e-2a33e5f560b7"), PA_IGNORE);
    assert_int_equal(get_policy_action_ctr(PE_ONNEW, "edc8f3cb-e91a-4c8c-88e8-043a4ff96ee0"), PA_INSTALL);
    assert_int_equal(get_policy_action_ctr(PE_ONNEW, "994dfcae-0458-43af-9b04-70a3f688ae7a"), PA_INSTALL);

    amxc_var_delete(&policydesc);
}

void test_apply_policy2(UNUSED void** state) {
    printf("2ND TEST:\n");
    amxc_var_t* jlist = NULL;
    amxc_var_t* i = NULL;
    amxc_var_t args;

    amxc_var_t ctrlist_c, ctrlist_u, ctrlist_r, imglist_r, sblist;
    init_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);

    load_json("restoredlist.json", &jlist);
    amxc_var_copy(&ctrlist_c, GET_ARG(jlist, "ctr_create"));
    amxc_var_copy(&sblist, GET_ARG(jlist, "sb_create"));

    cthulhu_prestartup_config_t config;
    config.ctr_create = &ctrlist_c;
    config.ctr_upgrade = &ctrlist_u;
    config.ctr_remove = &ctrlist_r;
    config.image_remove = &imglist_r;
    config.sb_create = &sblist;
    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_DATAMODEL, &datamodel);
    amxc_var_add_new_key_data(&args, CTHULHU_PLUGIN_ARG_PRESTART_CONFIG, &config);
    cthulhu_lpm_init(NULL, &args, NULL);

    // check if restore list is correct
    i = get_container(&ctrlist_c, "b8dfcc38-b093-564e-9146-86b1a1ff0974");
    p_assert_non_null(i);
    i = get_container(&ctrlist_c, "b62fdae6-6d86-523f-a841-3d8927f6504f");
    p_assert_null(i);
    i = get_container(&ctrlist_c, "0508fb55-0852-58eb-8321-e9283b1f5148");
    p_assert_non_null(i);
    i = get_container(&ctrlist_c, "a1a744b3-12b4-55a8-b558-3340b16072be");
    p_assert_non_null(i);

    p_assert_int_equal(cthulhu_plugin_odl_loaded(NULL, NULL, NULL), 0);
    printf("ok prestart\n");

    amxd_object_t* obj = amxd_dm_findf(&datamodel, LPMC);
    assert_true(amxd_object_get_value(bool, obj, EXECUTEDAFTERUPGRADE, NULL));
    printf("ok dm\n");

    print_variant(&ctrlist_c);
    print_variant(&ctrlist_u);
    print_variant(&ctrlist_r);
    print_variant(&sblist);

    // Check containers:

    // container should have remained on old version
    i = get_container(&ctrlist_c, "37a49331-0b30-4afc-8e3e-2a33e5f560b7");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "1.45.2");
    printf("ok 3:\n");

    // new container installed using global policy: onNew: INSTALL
    i = get_container(&ctrlist_c, "57c45a1a-6f07-5320-9e3a-395be9b8f3e9");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "1.25.0");
    printf("ok 4:\n");

    // new container should not be installed using specific policy: onNew: IGNORE
    i = get_container(&ctrlist_c, "b62fdae6-6d86-523f-a841-3d8927f6504f");
    p_assert_null(i);
    i = get_container(&ctrlist_u, "b62fdae6-6d86-523f-a841-3d8927f6504f");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "b62fdae6-6d86-523f-a841-3d8927f6504f");
    p_assert_null(i);
    i = get_container(&imglist_r, "b62fdae6-6d86-523f-a841-3d8927f6504f");
    p_assert_non_null(i);
    printf("ok 5:\n");

    // existing container should be updated according to global policy to new version: onExistingUpgrade: UPDATE
    i = get_container(&ctrlist_c, "abcdef46-22c2-5534-a527-884a3b6e581b");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "abcdef46-22c2-5534-a527-884a3b6e581b");
    p_assert_null(i);
    i = get_container(&ctrlist_u, "abcdef46-22c2-5534-a527-884a3b6e581b");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "33.11.1");
    p_assert_string_equal(GET_CHAR(i, "ContainerId"), "fedcba46-22c2-5534-a527-884a3b6e581b");
    i = get_container(&imglist_r, "abcdef46-22c2-5534-a527-884a3b6e581b");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "33.9.1");
    p_assert_string_equal(GET_CHAR(i, "ContainerId"), "117ad346-22c2-5534-a527-884a3b6e581b");
    printf("ok 6:\n");

    // existing container force downgrade: onExistingDowngrade: UPDATE
    i = get_container(&ctrlist_c, "545c015c-88c4-5438-8038-aedfd8c8c9a0");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "545c015c-88c4-5438-8038-aedfd8c8c9a0");
    p_assert_null(i);
    i = get_container(&ctrlist_u, "545c015c-88c4-5438-8038-aedfd8c8c9a0");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "8.4.8");
    printf("ok 7:\n");

    // container with invalid version field should remain at old version: whatever the policy do: IGNORE
    i = get_container(&ctrlist_u, "b8dfcc38-b093-564e-9146-86b1a1ff0974");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "b8dfcc38-b093-564e-9146-86b1a1ff0974");
    p_assert_null(i);
    i = get_container(&ctrlist_c, "b8dfcc38-b093-564e-9146-86b1a1ff0974");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "5.3.2");
    printf("ok 8:\n");

    // remove container that's not in new firmware (specific policy): onUnknown: UNINSTALL
    i = get_container(&ctrlist_c, "0508fb55-0852-58eb-8321-e9283b1f5148");
    p_assert_null(i);
    i = get_container(&ctrlist_u, "0508fb55-0852-58eb-8321-e9283b1f5148");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "0508fb55-0852-58eb-8321-e9283b1f5148");
    p_assert_non_null(i);
    printf("ok 9:\n");

    // keep a container that's not in new firmware (global policy): onUnknown: IGNORE
    i = get_container(&ctrlist_u, "a1a744b3-12b4-55a8-b558-3340b16072be");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "a1a744b3-12b4-55a8-b558-3340b16072be");
    p_assert_null(i);
    i = get_container(&ctrlist_c, "a1a744b3-12b4-55a8-b558-3340b16072be");
    p_assert_non_null(i);
    p_assert_string_equal(GET_CHAR(i, "ModuleVersion"), "2.0.0");
    printf("ok 10:\n");

    // new container with invalid version, ignore version error and install anyway: onNew: INSTALL
    i = get_container(&ctrlist_c, "1a78922c-3633-5b73-93b9-438b30b4b226");
    p_assert_non_null(i);
    i = get_container(&ctrlist_u, "1a78922c-3633-5b73-93b9-438b30b4b226");
    p_assert_null(i);
    i = get_container(&ctrlist_r, "1a78922c-3633-5b73-93b9-438b30b4b226");
    p_assert_null(i);
    printf("ok 11:\n");

    amxc_var_delete(&jlist);
    clean_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    cleanup_policy();
    amxc_var_clean(&args);
}

void test_apply_policy3(UNUSED void** state) {
    printf("3RD TEST (missing onnew policy for containers: expect fatal error):\n");
    amxc_var_t* jlist = NULL;
    amxc_var_t* i = NULL;

    amxc_var_t ctrlist_c, ctrlist_u, ctrlist_r, imglist_r, sblist;
    init_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);

    load_json("restoredlist.json", &jlist);
    amxc_var_copy(&ctrlist_c, GET_ARG(jlist, "ctr_create"));
    amxc_var_copy(&sblist, GET_ARG(jlist, "sb_create"));

    change_policy_file("policy2.json");

    p_assert_int_equal(load_policyfile(), amxd_status_ok);
    p_assert_int_not_equal(update_ctr_list(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r), amxd_status_ok);

    // new container should not have been installed despite global policy: onNew: INSTALL
    i = get_container(&ctrlist_c, "57c45a1a-6f07-5320-9e3a-395be9b8f3e9");
    p_assert_null(i);
    i = get_container(&ctrlist_u, "57c45a1a-6f07-5320-9e3a-395be9b8f3e9");
    p_assert_null(i);
    printf("ok 1:\n");

    amxc_var_delete(&jlist);
    clean_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    cleanup_policy();
}

void test_apply_policy4(UNUSED void** state) {
    printf("4TH TEST (invalid policy file json syntax: expect fatal error):\n");
    amxc_var_t* jlist = NULL;
    amxc_var_t ctrlist_c, ctrlist_u, ctrlist_r, imglist_r, sblist;
    init_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    amxc_var_t* i = NULL;

    load_json("restoredlist.json", &jlist);
    amxc_var_copy(&ctrlist_c, GET_ARG(jlist, "ctr_create"));
    amxc_var_copy(&sblist, GET_ARG(jlist, "sb_create"));

    change_policy_file("policy3.json");

    p_assert_int_not_equal(load_policyfile(), amxd_status_ok);
    p_assert_int_not_equal(update_ctr_list(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r), amxd_status_ok);

    // new container should not have been installed despite global policy: onNew: INSTALL
    i = get_container(&ctrlist_c, "57c45a1a-6f07-5320-9e3a-395be9b8f3e9");
    p_assert_null(i);
    printf("ok 1:\n");

    amxc_var_delete(&jlist);
    clean_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    cleanup_policy();
}

void test_apply_policy5(UNUSED void** state) {
    printf("5TH TEST (policy for onNew is set to invalid string, expect fatal error):\n");
    amxc_var_t* jlist = NULL;
    amxc_var_t ctrlist_c, ctrlist_u, ctrlist_r, imglist_r, sblist;
    init_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    amxc_var_t* i = NULL;

    load_json("restoredlist.json", &jlist);
    amxc_var_copy(&ctrlist_c, GET_ARG(jlist, "ctr_create"));
    amxc_var_copy(&sblist, GET_ARG(jlist, "sb_create"));

    change_policy_file("policy4.json");

    p_assert_int_equal(load_policyfile(), amxd_status_ok);
    p_assert_int_not_equal(update_ctr_list(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r), amxd_status_ok);

    // new container should not have been installed despite global policy: onNew: INSTALL
    i = get_container(&ctrlist_c, "57c45a1a-6f07-5320-9e3a-395be9b8f3e9");
    p_assert_null(i);
    printf("ok 1:\n");

    amxc_var_delete(&jlist);
    clean_lists(&ctrlist_c, &ctrlist_u, &ctrlist_r, &imglist_r, &sblist);
    cleanup_policy();
}


static int count_storage_cleanup = 0;

void cthulhu_cleanup_storage(void) {
    count_storage_cleanup++;
}


