/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#include "ip_diagnostics_priv.h"
#include "ip_diagnostics.h"
#include "ipping.h"
#include "ipd_dns.h"
#include "priv_ipping.h"
#include "config.h"

#define ME "ipd-ipping-s"

static ipping_start_struct_t ipping_start = {0};

/**
 * @brief
 * Deferred callback to perform a no-file-descriptor IPPing status check.
 *
 * This function is invoked asynchronously via amxp_sigmngr_deferred_call()
 * to run ipd_ipping_sched_check_common() without an associated file descriptor.
 * It uses the scheduler object passed in the @p priv argument to continue
 * tracking and updating the ping test status.
 *
 * @param data Unused data argument from the deferred call.
 * @param priv Pointer to an ipd_ipping_scheduler_t structure used for the check.
 */
static void ipd_deferred_ipd_ipping_sched_check_cb(UNUSED const amxc_var_t* data, void* priv) {
    ipd_ipping_sched_check_common(-1, NULL, (ipd_ipping_scheduler_t*) priv, false);
}

/**
 * @brief
 * Start the ping test on the module and links a check_function to the process
 *
 * @param check_function Check function triggered when output is available
 * @param mod_args Input args of the test
 * @param mod_ret Output args of the test
 * @return int
 */
static int ipd_ipping_mod_start(ipd_ipping_scheduler_t* sch,
                                _check_function_t check_function,
                                amxc_var_t* mod_args,
                                amxc_var_t* mod_ret) {
    amxd_object_t* ipd_ping_object = NULL;
    amxc_var_t* fd_var = NULL;
    amxc_var_t* fd_err_var = NULL;
    amxc_var_t* pid_var = NULL;
    amxc_var_t* status_var = NULL;
    const cstring_t status_str = NULL;
    int rv = -1;
    int32_t fd = -1;
    int32_t fd_err = -1;
    int32_t pid = -1;

    amxc_var_new(&status_var);
    amxc_var_set(cstring_t, status_var, IPPING_STATUS_ERR_OTHER);

    ipd_ping_object = ipd_get_ipping_object();

    //First check if a ping test is already running
    //Fetch the fd from the datamodel
    fd = ipd_tool_get_dm_fd(IPPING);
    if(fd > 0) {
        sch->prev_test = true;
        check_function(fd, NULL);
        if(sch->fd_stdout > 0) {
            ipd_ipping_stop(sch);
        }
        sch->prev_test = false;
    }

    rv = ipd_execute_ctrl_function_cb(ipd_ping_object, IPD_IPPING_TEST_START, mod_args, mod_ret);

    fd_var = GETP_ARG(mod_ret, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_FD_STDOUT);
    fd_err_var = GETP_ARG(mod_ret, IPPING_RET_KEY_PROC "." IPPING_RET_KEY_PROC_FD_STDERR);
    pid_var = GETP_ARG(mod_ret, IPPING_RET_KEY_PROC "."IPPING_RET_KEY_PROC_PID);
    if((rv != 0) || (fd_var == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Failed to execute function %s.", IPD_IPPING_TEST_START);
        amxc_var_set_pathf(mod_ret, status_var, DEFAULT_SET_PATH_FLAGS, IPPING_RET_KEY_PST);
        goto exit;
    }
    fd = GET_INT32(fd_var, NULL);
    fd_err = GET_INT32(fd_err_var, NULL);
    pid = GET_INT32(pid_var, NULL);
    if(fd <= 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to execute function %s.", IPD_IPPING_TEST_START);
        amxc_var_set_pathf(mod_ret, status_var, DEFAULT_SET_PATH_FLAGS, IPPING_RET_KEY_PST);
        goto exit;
    }

#ifndef IP_DIAGNOSTICS_UNIT_TEST
    amxc_var_move(mod_args, mod_ret);
    ipd_execute_ctrl_function_cb(ipd_ping_object, IPD_IPPING_TEST_CHECK, mod_args, mod_ret);
#endif

    status_str = GET_CHAR(mod_ret, IPPING_RET_KEY_PST);
    if(!str_empty(status_str) && (strcmp(status_str, IPPING_STATUS_NOT_COMPLETE) == 0)) {
        sch->fd_stderr = fd_err;
        sch->fd_stdout = fd;
        sch->pid = pid;
        amxo_connection_remove(ipd_get_parser(), fd);
        amxo_connection_add(ipd_get_parser(), fd, check_function, NULL, AMXO_CUSTOM, NULL);
        amxc_var_add_key(bool, mod_ret, "ConnectionAdded", true);
    } else {
        SAH_TRACEZ_INFO(ME, "Scheduling final no-FD check for immediate update");
        amxp_sigmngr_deferred_call(NULL, ipd_deferred_ipd_ipping_sched_check_cb, NULL, sch);
        amxc_var_add_key(bool, mod_ret, "ConnectionAdded", false);
    }
    rv = 0;
exit:
    amxc_var_delete(&status_var);
    return rv;
}

/**
 * @brief
 * Checks each input parameters and validates it with the requirements
 * of the datamodel
 *
 * @param args call back function's input args
 * @param mod_args Orginised variant with all the needed parameters to execute a ping test
 * @return int
 */
static int ipd_ipping_validate_input_args(amxc_var_t* args,
                                          amxc_var_t* mod_args) {
    SAH_TRACEZ_IN(ME);
    const cstring_t key_result = IPD_IPPING_CONFIG;
    int rv = -1;
    amxd_object_t* ipd_object = NULL;
    amxd_object_t* ipd_config = NULL;

    ipd_object = ipd_get_root_object();
    ipd_config = amxd_object_findf(ipd_object, "%s.", key_result);
    when_null_trace(ipd_config, exit, ERROR, "Failed to fetch object IPDiagnostics.%s. from datamodel.", key_result);

    rv = ipd_validate_cfg_params(args, ipd_config, mod_args, IPPING);
    when_failed_trace(rv, exit, ERROR, "Failed to validate the parameters.");

    //Sets the non mendatory parameters to default value
    rv = ipd_set_non_mandatory_def_value(mod_args, IPD_IPPING_CONFIG);
    when_failed_trace(rv, exit, ERROR, "Problem while setting default parameters");

    // If the interface is set, find the linux interface linked to it
    rv = ipd_resolve_ip_interface(mod_args);
    when_true_trace(rv == amxd_status_unknown_error, exit, ERROR, "Could not resolve the ip interface with error code %d", rv);

    if(rv == amxd_status_invalid_arg) {
        SAH_TRACEZ_WARNING(ME, "No IP interface specified, PING test will use the default routing configuration");
#ifdef IP_DIAGNOSTICS_UNIT_TEST
        rv = amxd_status_ok;
#endif
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief
 * start function for IP Ping test
 *
 * @param sched scheduler (Verify that the test has finished before launching
 *              another one)
 * @param args imput arguments
 * @param ret output arguments
 * @return amxd_status_t
 */
amxd_status_t ipd_ipping_start(_check_function_t check_function,
                               ipd_ipping_scheduler_t* sch,
                               amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    const cstring_t key_result = IPD_IPPING_CONFIG;
    amxc_var_t* ping_path = NULL;
    amxc_var_t* resolved_host_ip = NULL;
    amxd_status_t ret_status = amxd_status_unknown_error;
    amxd_object_t* ipd_object = NULL;
    amxd_object_t* ipd_results = NULL;
    amxc_var_t* mod_args = NULL;
    amxc_var_t* mod_ret = NULL;
    int ret_val = -1;

    amxc_var_new(&mod_args);
    amxc_var_set_type(mod_args, AMXC_VAR_ID_HTABLE);
    amxc_var_new(&mod_ret);
    amxc_var_set_type(mod_ret, AMXC_VAR_ID_HTABLE);

#ifndef IP_DIAGNOSTICS_UNIT_TEST
    //Check if the ping version is the right one first
    when_false_trace(ipd_ipping_is_iputils(), exit, ERROR, "Non iputils ping tool");
#endif

    ret_status = amxd_status_object_not_found;
    ipd_object = ipd_get_root_object();
    ipd_results = amxd_object_findf(ipd_object, "%s.", key_result);
    when_null_trace(ipd_results, exit, ERROR, "Failed to fetch object IPDiagnostics.%s. from datamodel.", key_result);

    //Set the PingState and DiagnosticState to "Requested" in dm
    amxd_object_set_value(cstring_t, ipd_results, IPPING_RET_KEY_DST, IPPING_STATUS_REQUESTED);
    amxd_object_set_value(cstring_t, ipd_results, IPPING_RET_KEY_PST, IPPING_STATUS_REQUESTED);

    //Validate input arguments
    ret_status = amxd_status_invalid_arg;
    ret_val = ipd_ipping_validate_input_args(args, mod_args);
    when_failed(ret_val, exit);

    amxc_var_add_new_key(mod_args, "PingPath");
    ping_path = amxc_var_get_key(mod_args, "PingPath", AMXC_VAR_FLAG_DEFAULT);
    amxc_var_set(cstring_t, ping_path, ipd_get_ping_path());
    amxc_var_add_new_key(mod_args, "ResolvedHostIP");
    //Start test on the module
    ret_status = amxd_status_deferred;
    if(ipat_text_valid(GET_CHAR(mod_args, "Host"))) {
        resolved_host_ip = amxc_var_get_key(mod_args, "ResolvedHostIP", AMXC_VAR_FLAG_DEFAULT);
        amxc_var_set(cstring_t, resolved_host_ip, GET_CHAR(mod_args, "Host"));
        ret_val = ipd_ipping_mod_start(sch, check_function, mod_args, mod_ret);

        if(ret_val != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Could not launch the test properly, error: %s", GET_CHAR(mod_ret, IPPING_RET_KEY_PST));
        }
        ipd_ipping_save_result_to_dm(mod_ret, ipd_results);
        if(GET_BOOL(mod_ret, "ConnectionAdded") == false) {
            ipd_ipping_save_status_to_dm(mod_ret, ipd_results);
        }
        goto exit;
    } else {
        ipping_start.start_function = ipd_ipping_mod_start;
        ipping_start.sch = sch;
        ipping_start.mod_args = mod_args;
        ipping_start.mod_ret = mod_ret;
        ipping_start.check_function = check_function;
        ipping_start.ipd_results = ipd_results;
        ret_val = resolve_hostname(&ipping_start);
        if(ret_val != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Could not launch the test properly, error: %s", GET_CHAR(mod_ret, IPPING_RET_KEY_PST));
        }
    }

    SAH_TRACEZ_OUT(ME);
    return ret_status;
exit:
    amxc_var_move(ret, mod_ret);
    ipd_filter_ret(ret, true, IPPING);
    amxc_var_delete(&mod_args);
    amxc_var_delete(&mod_ret);
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}
