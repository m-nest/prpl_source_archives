/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <unistd.h>
#include <libgen.h>
#include <cmocka.h>

#include "test_swl_class3.h"

#define ME "class3"

bool swl_oo_class3_doSomething3(swl_oo_class3_t* self, uint32_t testValue) {
    return testValue <= self->data.super.super.var1 + self->data.super.var2 + self->data.var3;
}

bool swl_oo_class3_doSomething1a(swl_oo_class1_t* selfi, uint32_t testValue) {
    swl_oo_class3_t* self = (swl_oo_class3_t* ) selfi;
    if(self->data.var3 > 0) {
        self->data.someData[0] = testValue;
    }
    return testValue > self->data.super.super.var1 + self->data.var3;
}

static void s_destroy(swl_ooRoot_t* selfi) {
    swl_oo_class3_t* self = (swl_oo_class3_t* ) selfi;
    free(self->data.someData);
    self->data.someData = NULL;
}


SWL_OO_SUBCLASS_INST(swl_oo_class3_t, swl_oo_class2_t, KEEP_COMMA(
                         .super = {
    .super = {
        .super = {.destroy = s_destroy},
        .doSomething1a = swl_oo_class3_doSomething1a
    },
},
                         .doSomething3 = swl_oo_class3_doSomething3,
                         ), );

void swl_oo_class3_t_new(swl_oo_class3_t* self, uint32_t val1, uint32_t val2, uint32_t val3) {
    swl_oo_class2_t_new((swl_oo_class2_t*) self, val1, val2);
    self->data.var3 = val3;
    self->data.someData = calloc(val3, sizeof(uint32_t));
}

