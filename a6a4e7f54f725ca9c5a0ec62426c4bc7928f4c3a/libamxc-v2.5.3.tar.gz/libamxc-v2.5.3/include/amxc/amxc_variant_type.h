/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__AMXC_VARIANT_TYPE_H__)
#define __AMXC_VARIANT_TYPE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_htable.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc_common.h>

/**
   @file
   @brief
   Ambiorix variant type API header file
 */

/**
   @ingroup amxc_containers
   @defgroup amxc_variant_type Variant types

   @section variant_type_overview What is a Variant Type?

   A variant type defines how a specific data type behaves within the Ambiorix variant system.
   Variants are polymorphic containers that can hold different types of data (integers, strings,
   arrays, hash tables, etc.). Each variant type defines a set of operations that can be performed
   on that specific data type.

   The variant type system provides a plugin-like architecture where new data types can be added
   dynamically at runtime without modifying the core variant implementation.

   @section variant_type_how_it_works How the Variant Type System Works

   The variant type system works through a registration mechanism:

   1. **Type Registration**: Each variant type is registered with a unique name and assigned a type ID
   2. **Callback Functions**: Types define callback functions for operations like initialization,
      cleanup, copying, conversion, comparison, and data access
   3. **Type Storage**: Registered types are stored in both a hash table (for name-based lookup)
      and an array (for ID-based lookup)
   4. **Dynamic Dispatch**: When operations are performed on variants, the appropriate callback
      function is called based on the variant's type

   Built-in types (with IDs < AMXC_VAR_ID_CUSTOM_BASE) are pre-registered by the system.
   Custom types receive IDs >= AMXC_VAR_ID_CUSTOM_BASE when registered.

   @section variant_type_adding_new_type How to Add a New Variant Type

   To create and register a new variant type, follow these steps:

   1. **Define the Type Structure**: Create an @ref amxc_var_type_t structure and implement
      the necessary callback functions:

      @code{.c}
      static int my_type_init(amxc_var_t* const var) {
          // Initialize your data type
          return 0;
      }

      static void my_type_delete(amxc_var_t* const var) {
          // Clean up allocated resources
      }

      static int my_type_copy(amxc_var_t* const dst, const amxc_var_t* const src) {
          // Create a copy of the data
          return 0;
      }

      static amxc_var_type_t my_custom_type = {
          .init = my_type_init,
          .del = my_type_delete,
          .copy = my_type_copy,
          // ... other callbacks as needed
          .name = "MyCustomType"
      };
      @endcode

   2. **Register the Type**: Call @ref amxc_var_register_type() to register your type:

      @code{.c}
      uint32_t type_id = amxc_var_register_type(&my_custom_type);
      if (type_id == UINT32_MAX) {
          // Registration failed
      }
      @endcode

   3. **Use the Type**: After registration, you can create variants of your custom type

   4. **Unregister When Done**: Call @ref amxc_var_unregister_type() when the type is no longer needed:

      @code{.c}
      amxc_var_unregister_type(&my_custom_type);
      @endcode

   @section variant_type_api_overview API Overview

   The variant type API provides the following main functions:

 **Type Registration:**
   - @ref amxc_var_register_type() - Register a new custom variant type
   - @ref amxc_var_unregister_type() - Unregister a previously registered custom type

 **Type Lookup:**
   - @ref amxc_var_get_type_name_from_id() - Get type name from type ID
   - @ref amxc_var_get_type_id_from_name() - Get type ID from type name
   - @ref amxc_var_get_type() - Get the complete type definition structure

 **Callback Function Types:**
   The following callback function types can be implemented for custom types:
   - @ref amxc_var_new_fn_t - Initialize a variant
   - @ref amxc_var_free_fn_t - Free variant resources
   - @ref amxc_var_copy_fn_t - Copy variant data
   - @ref amxc_var_move_fn_t - Move variant data
   - @ref amxc_var_convert_fn_t - Convert between types
   - @ref amxc_var_compare_fn_t - Compare two variants
   - @ref amxc_var_get_key_fn_t - Get data by key (for container types)
   - @ref amxc_var_set_key_fn_t - Set data by key (for container types)
   - @ref amxc_var_get_index_fn_t - Get data by index (for array-like types)
   - @ref amxc_var_set_index_fn_t - Set data by index (for array-like types)
   - @ref amxc_var_add_fn_t - Add data to variant (for collection types)

   @note All callback functions are optional. If a callback is not provided (NULL),
   the corresponding operation will not be supported for that type.

   @warning When unregistering a type, ensure no variants of that type are still in use,
   as they will become "rogue variants" that cannot be properly managed.
 */

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for initializing a variant of a
   certain type.

   This callback is invoked when a variant is set to this type. It should
   initialize any type-specific data structures and prepare the variant
   for use. Memory allocation is permitted, but ensure the corresponding
   cleanup is implemented in the @ref amxc_var_free_fn_t callback.

   @param var pointer to the variant to initialize. Must not be NULL.
              The variant's type will already be set when this function is called.

   @return
   0 on successful initialization, non-zero error code on failure.

   @retval 0 Initialization successful
   @retval -1 Generic initialization failure
   @retval other Implementation-specific error codes

   @par Implementation Notes:
   - This function should be idempotent (safe to call multiple times)
   - Any allocated memory should be tracked for cleanup in the del callback
   - The variant's data union can be used to store type-specific data

   @see amxc_var_free_fn_t
   @see amxc_var_set_type
 */
typedef int (* amxc_var_new_fn_t) (amxc_var_t* const var);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for freeing previously allocated memory.

   @param var pointer to the variant whose resources should be freed. Must not be NULL.
 */
typedef void (* amxc_var_free_fn_t) (amxc_var_t* const var);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for creating a copy.

   @param dst pointer to the destination variant. Must not be NULL.
   @param src pointer to the source variant to copy from. Must not be NULL.

   @return
   0 on success, error code on failure.
 */
typedef int (* amxc_var_copy_fn_t) (amxc_var_t* const dst,
                                    const amxc_var_t* const src);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for moving the content.

   @param dst pointer to the destination variant. Must not be NULL.
   @param src pointer to the source variant to move from. Must not be NULL.

   @return
   0 on success, error code on failure.
 */
typedef int (* amxc_var_move_fn_t) (amxc_var_t* const dst,
                                    amxc_var_t* const src);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for dynamically converting one type
   to another.

   @param dest pointer to the destination variant. Must not be NULL.
   @param src pointer to the source variant to convert from. Must not be NULL.

   @return
   0 on successful conversion, error code if conversion fails or is not supported.
 */
typedef int (* amxc_var_convert_fn_t) (amxc_var_t* const dest,
                                       const amxc_var_t* const src);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for comparing two variants of the same
   type.

   @param var1 pointer to the first variant to compare. Must not be NULL.
   @param var2 pointer to the second variant to compare. Must not be NULL.
   @param result pointer to store the comparison result. Must not be NULL.
                 Set to < 0 if var1 < var2, > 0 if var1 > var2, 0 if equal.

   @return
   0 on successful comparison, error code on failure.
 */
typedef int (* amxc_var_compare_fn_t) (const amxc_var_t* const var1,
                                       const amxc_var_t* const var2,
                                       int* const result);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for fetching part of a variant by key

   @param src pointer to the source variant. Must not be NULL.
   @param key the key to look up. Must not be NULL.
   @param flags operation flags for the get operation.

   @return
   Pointer to the variant at the specified key, or NULL if not found or on error.
 */
typedef amxc_var_t*(* amxc_var_get_key_fn_t) (const amxc_var_t* const src,
                                              const char* const key,
                                              int flags);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for setting part of a variant by key

   @param dest pointer to the destination variant. Must not be NULL.
   @param src pointer to the source variant to set. Must not be NULL.
   @param key the key to set. Must not be NULL.
   @param flags operation flags for the set operation.

   @return
   0 on success, error code on failure.
 */
typedef int (* amxc_var_set_key_fn_t) (amxc_var_t* const dest,
                                       amxc_var_t* const src,
                                       const char* const key,
                                       int flags);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for fetching part of a variant by index

   @param src pointer to the source variant. Must not be NULL.
   @param index the index to look up.
   @param flags operation flags for the get operation.

   @return
   Pointer to the variant at the specified index, or NULL if not found or on error.
 */
typedef amxc_var_t*(* amxc_var_get_index_fn_t) (const amxc_var_t* const src,
                                                const int64_t index,
                                                int flags);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for setting part of a variant by index

   @param dest pointer to the destination variant. Must not be NULL.
   @param src pointer to the source variant to set. Must not be NULL.
   @param index the index to set at.
   @param flags operation flags for the set operation.

   @return
   0 on success, error code on failure.
 */
typedef int (* amxc_var_set_index_fn_t) (amxc_var_t* const dest,
                                         amxc_var_t* const src,
                                         const int64_t index,
                                         int flags);

/**
   @ingroup amxc_variant_type
   @brief
   Variant type callback function prototype for adding a value to a variant

   @param dest pointer to the destination variant. Must not be NULL.
   @param value pointer to the value to add. Must not be NULL.

   @return
   0 on success, error code on failure.
 */
typedef int (* amxc_var_add_fn_t) (amxc_var_t* const dest,
                                   const amxc_var_t* const value);

/**
   @ingroup amxc_variant_type
   @brief
   A variant type structure.

   New or application specific variants can be defined and registered.
   All function pointers are optional.

   The member type_id and hit will be filled during registration and must never
   be changed.

   A unique name must be provided.

   The init function is called when the type of the variant is set
   see @ref amxc_var_set_type. When the initialization is successful, return 0, otherwise
   return an error code.

   The del function is called when the content of the variant must be cleared.

   The copy function is called when a copy needs to be made.
   @see amxc_var_copy. The function must return 0 when the copy was successful,
   an error code otherwise.

   The convert functions convert_from, convert_to are called when conversion
   from one type to another type is needed. These functions take two arguments,
   the destination variant and the source variant.
   These functions are used by @ref amxc_var_convert. If the source variant type
   has a convert_to function, it will be called. If that conversion fails or the
   source variant type does not have a convert_to function, the convert_from function
   of the destination variant type is called.
   When conversion was successful, these functions must return 0, if conversion was
   impossible (not supported) or fails for any other reason an error code must
   be returned.

   The compare function is called to compare two variants. Before calling
   the compare function, one of the variants will be converted to the same type
   as the other one. If none of the variants can be converted to the type
   of the other variant, the compare fails.
   The compare functions must set the result to a number < 0 if the left variant
   is smaller than the right variant, to a number > 0 if the left variant is
   bigger than the right variant, or to 0 if they are the same.
 */
typedef struct _amxc_var_type {
    amxc_var_new_fn_t init;              /**< Initialize function */
    amxc_var_free_fn_t del;              /**< Free (delete) function */
    amxc_var_copy_fn_t copy;             /**< Copy function */
    amxc_var_move_fn_t move;             /**< Move function */
    amxc_var_convert_fn_t convert_from;  /**< Convert from function */
    amxc_var_convert_fn_t convert_to;    /**< Convert to function */
    amxc_var_compare_fn_t compare;       /**< Compare function */
    amxc_var_get_key_fn_t get_key;       /**< Fetch part of the variant by key */
    amxc_var_set_key_fn_t set_key;       /**< Set part of the variant by key */
    amxc_var_get_index_fn_t get_index;   /**< Fetch part of the variant by index */
    amxc_var_set_index_fn_t set_index;   /**< Set part of the variant by index */
    amxc_var_add_fn_t add_value;         /**< Add a value to a variant */
    uint32_t type_id;                    /**< Type ID - assigned when registered */
    amxc_htable_it_t hit;                /**< Hash table iterator, used to store the type */
    const char* name;                    /**< Unique name of the type */
} amxc_var_type_t;

/**
   @ingroup amxc_variant_type
   @brief
   Register a new variant type.

   This function registers a custom variant type with the variant system, making it
   available for use with variants. After successful registration, variants can be
   created using this type, and the type will be available for type conversions
   and other variant operations.

   The registration process assigns a unique type ID (>= AMXC_VAR_ID_CUSTOM_BASE)
   and stores the type definition in internal lookup tables for efficient access.

   @note
   - The type structure must remain valid until the type is unregistered
   - The type name must be unique across all registered types
   - Registration is typically done during library/module initialization (constructor function)
   - This function is not thread-safe; ensure proper synchronization if called
     from multiple threads

   @param type pointer to a struct defining this type. Must not be NULL.
               The following fields must be properly initialized:
               - name: unique string identifier for the type (required)
               - callback functions: at least init and del are recommended
               After registration, type_id and hit fields will be set automatically.

   @return
   Returns the assigned type ID when registration is successful (>= AMXC_VAR_ID_CUSTOM_BASE),
   or UINT32_MAX on failure.

   @retval UINT32_MAX Registration failed due to:
                      - type parameter is NULL
                      - type name is NULL or empty
                      - type name already exists
                      - internal memory allocation failure

   @par Example:
   @code{.c}
   static amxc_var_type_t my_type = {
       .init = my_init_func,
       .del = my_delete_func,
       .copy = my_copy_func,
       .name = "MyCustomType"
   };

   uint32_t type_id = amxc_var_register_type(&my_type);
   if (type_id == UINT32_MAX) {
       printf("Failed to register type\n");
       return -1;
   }
   printf("Type registered with ID: %u\n", type_id);
   @endcode

   @see amxc_var_unregister_type
   @see amxc_var_type_t
 */
uint32_t amxc_var_register_type(amxc_var_type_t* const type);

/**
   @ingroup amxc_variant_type
   @brief
   Unregisters a previously registered custom variant type.

   This function removes a custom variant type from the variant system. Only custom
   types (with type_id >= AMXC_VAR_ID_CUSTOM_BASE) can be unregistered. Built-in
   system types cannot be unregistered.

   After unregistration, the type can no longer be used to create new variants,
   and type conversion operations involving this type will fail.

   @warning
   Unregistering a type while variants of that type still exist will create
   "rogue variants" that cannot be properly managed. Always ensure all variants
   of the type are cleaned up before unregistering the type.

   @note
   - Only custom types can be unregistered (built-in types are protected)
   - This function is not thread-safe; ensure proper synchronization
   - Typically called during library/module cleanup

   @param type pointer to a previously registered custom type structure. Must not be NULL
               and must have been successfully registered with @ref amxc_var_register_type.

   @return
   0 when unregistration is successful, -1 on failure.

   @retval 0 Type successfully unregistered
   @retval -1 Unregistration failed due to:
              - type parameter is NULL
              - type was not previously registered
              - type is a built-in type (type_id < AMXC_VAR_ID_CUSTOM_BASE)
              - type is currently in use (implementation dependent)

   @par Example:
   @code{.c}
   // During cleanup
   if (amxc_var_unregister_type(&my_type) != 0) {
       printf("Failed to unregister type\n");
   }
   @endcode

   @see amxc_var_register_type
 */
int amxc_var_unregister_type(amxc_var_type_t* const type);

/**
   @ingroup amxc_variant_type
   @brief
   Get the type name from a type ID.

   This function performs a reverse lookup to find the human-readable name
   associated with a given type ID. This is useful for debugging, logging,
   or displaying type information to users.

   @param type_id the type ID to look up. Can be any valid type ID including
                  both built-in types (< AMXC_VAR_ID_CUSTOM_BASE) and custom
                  types (>= AMXC_VAR_ID_CUSTOM_BASE).

   @return
   Returns a pointer to the type name string, or NULL if the type ID is invalid.
   The returned string is owned by the type system and should not be modified
   or freed by the caller.

   @retval "string" Valid type name for the given ID
   @retval NULL Type ID does not exist or is invalid

   @par Example:
   @code{.c}
   uint32_t type_id = amxc_var_get_type_id_from_name("string");
   const char* name = amxc_var_get_type_name_from_id(type_id);
   printf("Type ID %u corresponds to type '%s'\n", type_id, name);
   @endcode

   @see amxc_var_get_type_id_from_name
   @see amxc_var_get_type
 */
const char* amxc_var_get_type_name_from_id(const uint32_t type_id);

/**
   @ingroup amxc_variant_type
   @brief
   Get the type ID from a type name.

   This function performs a lookup to find the numeric type ID associated
   with a given type name. The type ID can then be used for efficient
   type operations and comparisons.

   @param name the name of the type to look up. Must not be NULL or empty string.
               The lookup is case-sensitive and must match exactly with the
               registered type name.

   @return
   Returns the type ID if found, or AMXC_VAR_ID_MAX if the type name was not found.

   @retval type_id Valid type ID for the given name (0 to AMXC_VAR_ID_MAX-1)
   @retval AMXC_VAR_ID_MAX Type name not found, or name parameter is NULL/empty

   @par Example:
   @code{.c}
   uint32_t string_type_id = amxc_var_get_type_id_from_name("string");
   if (string_type_id == AMXC_VAR_ID_MAX) {
       printf("String type not found\n");
   } else {
       printf("String type ID is: %u\n", string_type_id);
   }
   @endcode

   @see amxc_var_get_type_name_from_id
   @see amxc_var_get_type
 */
uint32_t amxc_var_get_type_id_from_name(const char* const name);

/**
   @ingroup amxc_variant_type
   @brief
   Get the complete type definition structure.

   This function retrieves the full type definition structure for a given type ID.
   The returned structure contains all the callback functions and metadata
   associated with the type. This is primarily used internally by the variant
   system, but can also be useful for introspection or advanced type operations.

   @param type_id the type ID to look up. Can be any valid registered type ID.

   @return
   Returns a pointer to the type definition structure, or NULL if the type ID
   does not exist. The returned structure is owned by the type system and
   should not be modified by the caller (except during type registration).

   @retval amxc_var_type_t* Valid type definition structure
   @retval NULL Type ID does not exist or is invalid

   @par Example:
   @code{.c}
   amxc_var_type_t* type_def = amxc_var_get_type(my_type_id);
   if (type_def != NULL) {
       printf("Type name: %s\n", type_def->name);
       printf("Has copy function: %s\n", type_def->copy ? "yes" : "no");
   }
   @endcode

   @see amxc_var_get_type_name_from_id
   @see amxc_var_get_type_id_from_name
   @see amxc_var_type_t
 */
amxc_var_type_t* amxc_var_get_type(unsigned int type_id);


#ifdef __cplusplus
}
#endif

#endif // __AMXC_VARIANT_TYPE_H__
