/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>

#include <hosts/client.h>
#include "tr181_hosts.h"

#define ME "hosts_client"

static amxc_llist_t s_llSubs;        /*!< list of subscriptions */

bool hosts_initialize(void) {
    return (amxc_llist_init(&s_llSubs) == 0);
}

int open_hostquery(const char* ip_address, amxp_slot_fn_t cb, void* userdata) {
    int rv = -1;
    amxb_subscription_t* subs = NULL;
    amxc_string_t sExpress;
    const char* path = "Device.Hosts.Host.";

    rv = amxc_string_init(&sExpress, 0);
    when_failed_trace(rv, exit, ERROR, "Failed to init string");

    amxc_string_appendf(&sExpress, "notification in ['dm:instance-added', 'dm:instance-removed', 'dm:object-changed']"
                        " && path matches 'Device\\.Hosts\\.Host\\.[0-9]+\\.IPv4Address\\.$'"
                        " && contains('parameters.IPAddress')"
                        " && parameters.IPAddress == '%s'",
                        ip_address);

    rv = amxb_subscription_new(&subs, hosts_get_amxb_bus(), path,
                               amxc_string_get(&sExpress, 0), cb, userdata);
    when_failed_trace(rv, exit, ERROR, "subscription failed on Device.Hosts.Host. with userdata %p", userdata);

    amxc_llist_append(&s_llSubs, &subs->it);

exit:
    amxc_string_clean(&sExpress);
    return rv;
}

/**
 * @brief Checks if the given character is a dot ('.').
 *
 * This function returns 1 if the input character is a dot, otherwise returns 0.
 *
 * @param c The character to check.
 * @return int
 * - 1 if the character is '.'.
 * - 0 otherwise.
 */
static int isdot(int c) {
    if(c == '.') {
        return 1;
    }

    return 0;
}

/**
 * @brief Trims the trailing dot ('.') from the given path string.
 *
 * This function creates a copy of the input path, removes any trailing dot characters
 * from the end of the string, and returns the resulting string. If the input path
 * is empty or NULL, it logs an error and returns an empty string.
 *
 * @param path The input path string to be trimmed.
 * @return char* The newly allocated string with the trailing dot removed.
 *
 * @note The caller is responsible for freeing the returned string.
 */
static char* trim_final_dot(const char* path) {
    amxc_string_t trimmed_path;
    amxc_string_init(&trimmed_path, 0);

    when_str_empty_trace(path, exit, ERROR, "No path given to trim");

    amxc_string_set(&trimmed_path, path);
    amxc_string_trimr(&trimmed_path, isdot);
exit:
    return amxc_string_take_buffer(&trimmed_path);
}

void get_host(const char* ip_address, char** find_host) {
    amxc_var_t host;

    when_null_trace(ip_address, exit, ERROR, "empty ip address");
    amxc_var_init(&host);
    amxb_get(hosts_get_amxb_bus(), "Device.Hosts.Host.", 0, &host, 3);
    amxc_var_for_each(host_params, GET_ARG(&host, "0")) {
        const char* host_params_ip_address = GET_CHAR(host_params, "IPAddress");
        if(host_params_ip_address != NULL) {
            if(strcmp(ip_address, host_params_ip_address) == 0) {
                *find_host = trim_final_dot(amxc_var_key(host_params));
                break;
            }
        }
    }
    amxc_var_clean(&host);

exit:
    return;
}

static void s_llistCleanSubs(amxc_llist_it_t* it) {
    amxb_subscription_t* subs = amxc_llist_it_get_data(it, amxb_subscription_t, it);
    amxb_subscription_delete(&subs);
}

void hosts_cleanup(void) {
    amxc_llist_clean(&s_llSubs, s_llistCleanSubs);
}

amxb_bus_ctx_t* hosts_get_amxb_bus(void) {
    return amxb_be_who_has("Device.Hosts.");
}