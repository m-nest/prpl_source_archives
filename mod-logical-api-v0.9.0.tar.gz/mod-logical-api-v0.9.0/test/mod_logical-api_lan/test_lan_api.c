/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>

#include "test_lan_api.h"
#include "logical_api_getters.h"
#include "logical_api_utils.h"
#include "common_utils.h"

int test_setup(void** state) {
    unittests_setup_t ctx;
    ctx.include_dns = true;
    mod_logical_unittests_setup(state, &ctx);
    amxp_sigmngr_emit_signal(NULL, "wait:done", NULL);
    return 0;
}

int test_teardown(void** state) {
    mod_logical_unittests_teardown(state);
    return 0;
}

static void check_config(amxd_object_t* object, bool ip_enable, char* ip_address, char* subnet_mask, bool dhcp_enable,
                         int lease_time, char* min_address, char* max_address, char* pool, char* dns_server) {
    amxc_var_t ret;
    amxc_var_t pool_ref;
    char* dhcp_pool_ref = NULL;

    amxc_var_init(&pool_ref);
    amxc_var_init(&ret);

    // check ip config
    assert_int_equal(component_get_parameters(&ret, "IP.Interface.3.IPv4Address.1.", amxb_be_who_has("IP.")), 0);

    assert_int_equal(ip_enable, GET_BOOL(&ret, "Enable"));
    assert_string_equal(ip_address, GET_CHAR(&ret, "IPAddress"));
    assert_string_equal(subnet_mask, GET_CHAR(&ret, "SubnetMask"));

    // check dhcp config
    amxc_var_convert(&pool_ref, amxd_object_get_param_value(object, "DHCPv4PoolReference"), AMXC_VAR_ID_LIST);
    if(str_empty(GETI_CHAR(&pool_ref, 0))) {
        dhcp_pool_ref = component_get_path_instance(amxb_be_who_has("DHCPv4Server."), "DHCPv4Server.Pool.[Interface=='Device.IP.Interface.3.'].");
        assert_string_not_equal(dhcp_pool_ref, "");
    } else {
        dhcp_pool_ref = strdup(GETI_CHAR(&pool_ref, 0));
    }

    amxc_var_clean(&ret);
    assert_int_equal(component_get_parameters(&ret, dhcp_pool_ref, amxb_be_who_has("DHCPv4Server.")), 0);

    assert_int_equal(dhcp_enable, GET_BOOL(&ret, "Enable"));
    assert_string_equal(ip_address, GET_CHAR(&ret, "IPRouters"));
    assert_string_equal(subnet_mask, GET_CHAR(&ret, "SubnetMask"));
    assert_int_equal(dhcp_enable, GET_BOOL(&ret, "Enable"));
    assert_int_equal(lease_time, GET_UINT32(&ret, "LeaseTime"));
    assert_string_equal(max_address, GET_CHAR(&ret, "MaxAddress"));
    assert_string_equal(min_address, GET_CHAR(&ret, "MinAddress"));
    assert_string_equal(pool, GET_CHAR(&ret, "Alias"));
    assert_string_equal(dns_server, GET_CHAR(&ret, "DNSServers"));
    assert_string_equal("Device.IP.Interface.3.", GET_CHAR(&ret, "Interface"));

    free(dhcp_pool_ref);
    amxc_var_clean(&pool_ref);
    amxc_var_clean(&ret);
}

/**
   @brief Helper function to set up the basic test environment with common parameters
   @param lan_obj[out] Pointer to store the LAN object
   @param parameters[out] Parameters for SetIPv4Config() call, initialized with default values
   @param list_parameters[out] Parameters for SetIPv4ConfigExt() call, initialized with default values
 */
static void setup_basic_test_env(amxd_object_t** lan_obj, amxc_var_t* parameters, amxc_var_t* list_parameters,
                                 char* ip_address, char* subnet_mask, char* min_address, char* max_address) {
    *lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    assert_non_null(*lan_obj);

    amxc_var_t* data = NULL;
    amxc_var_t* list = NULL;

    // initiate parameters for SetIPv4Config()
    amxc_var_set_type(parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, parameters, "Enable", true);
    if(ip_address != NULL) {
        amxc_var_add_key(cstring_t, parameters, "IPAddress", ip_address);
        amxc_var_add_key(cstring_t, parameters, "DNSServers", ip_address);
    }
    amxc_var_add_key(cstring_t, parameters, "SubnetMask", subnet_mask);
    amxc_var_add_key(bool, parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, parameters, "Pool", "lan");
    amxc_var_add_key(cstring_t, parameters, "MinAddress", min_address);
    amxc_var_add_key(cstring_t, parameters, "MaxAddress", max_address);
    amxc_var_add_key(cstring_t, parameters, "LeaseTime", "40000");

    // initiate parameters for SetIPv4ConfigExt()
    amxc_var_set_type(list_parameters, AMXC_VAR_ID_HTABLE);

    // Add IP configs
    list = amxc_var_add_key(amxc_llist_t, list_parameters, "IPConfigs", NULL);

    // Add primary IP config
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    if(ip_address != NULL) {
        amxc_var_add_key(cstring_t, data, "IPAddress", ip_address);
    }
    amxc_var_add_key(cstring_t, data, "SubnetMask", subnet_mask);
    amxc_var_add_key(uint32_t, data, "Index", 1);

    // Add secondary IP config, missing Index
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "IPAddress", "172.16.10.6");
    amxc_var_add_key(cstring_t, data, "SubnetMask", "255.255.0.0");
    amxc_var_add_key(uint32_t, data, "Index", 2);

    // Add DHCP pool configs
    list = amxc_var_add_key(amxc_llist_t, list_parameters, "Pools", NULL);

    // Add lan pool config, missing Alias
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "Alias", "lan");
    amxc_var_add_key(cstring_t, data, "MinAddress", min_address);
    amxc_var_add_key(cstring_t, data, "MaxAddress", max_address);
    if(ip_address != NULL) {
        amxc_var_add_key(cstring_t, data, "DNSServers", ip_address);
    }
    amxc_var_add_key(uint32_t, data, "LeaseTime", 600);

    // Add lan-extender pool config
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "Alias", "lan-extender");
    amxc_var_add_key(cstring_t, data, "MinAddress", "192.168.1.155");
    amxc_var_add_key(cstring_t, data, "MaxAddress", "192.168.1.200");
    if(ip_address != NULL) {
        amxc_var_add_key(cstring_t, data, "DNSServers", ip_address);
    }
    amxc_var_add_key(uint32_t, data, "LeaseTime", 6000);
}

/**
   @brief
   Test that providing an invalid IP address format results in
   invalid function argument status.
 */
void test_SetIPv4Config_invalid_ip_address(void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters;
    amxc_var_t list_parameters;
    char** invalid_IP = (char**) (*state);

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with invalid IP address
    if(*state != NULL) {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, *invalid_IP, "255.255.255.0", "192.168.1.10", "192.168.1.150");
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);
    } else {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, NULL, "255.255.255.0", "192.168.1.10", "192.168.1.150");
        // ip address is null, therefore we fall back on existing interface IP address
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
        check_config(lan_obj, true, "192.168.1.1", "255.255.255.0", true, 40000,
                     "192.168.1.10", "192.168.1.150", "lan", "192.168.1.1");

        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_ok);
    }

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an invalid subnet_mask format results in
   invalid function argument status.
 */
void test_SetIPv4Config_invalid_subnet_mask(void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters;
    amxc_var_t list_parameters;
    char** invalid_IP = (char**) (*state);

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with invalid IP address
    if(*state != NULL) {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", *invalid_IP, "192.168.1.10", "192.168.1.150");
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);
    } else {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", NULL, "192.168.1.10", "192.168.1.150");
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
        check_config(lan_obj, true, "192.168.1.1", "255.255.255.0", true, 40000,
                     "192.168.1.10", "192.168.1.150", "lan", "192.168.1.1");

        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_ok);
    }

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an invalid minimum address format results in
   invalid function argument status.
 */
void test_SetIPv4Config_invalid_min_address(void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters;
    amxc_var_t list_parameters;
    char** invalid_IP = (char**) (*state);

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with invalid min address
    if(*state != NULL) {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", *invalid_IP, "192.168.1.150");
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);
    } else {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", NULL, "192.168.1.150");
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
        check_config(lan_obj, true, "192.168.1.1", "255.255.255.0", true, 40000,
                     "192.168.1.100", "192.168.1.150", "lan", "192.168.1.1");

        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_ok);
    }

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an invalid maximum address format results in
   invalid function argument status.
 */
void test_SetIPv4Config_invalid_max_address(void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters;
    amxc_var_t list_parameters;
    char** invalid_IP = (char**) (*state);

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with invalid max address
    if(*state != NULL) {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "192.168.1.10", *invalid_IP);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);
    } else {
        setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "192.168.1.10", NULL);
        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
        check_config(lan_obj, true, "192.168.1.1", "255.255.255.0", true, 40000,
                     "192.168.1.10", "192.168.1.249", "lan", "192.168.1.1");

        assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_ok);
    }

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a minimum address outside the subnet range results in
   invalid function argument status.
 */
void test_SetIPv4Config_min_address_not_in_subnet(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with min address outside subnet
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "172.16.1.10", "192.168.1.150");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that setting only the interface parameters is allowed (no dhcp pool setup)
 */
void test_SetIPv4Config_no_pool(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with min address outside subnet
    // setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "172.16.1.10", "192.168.1.150");
    lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    assert_non_null(lan_obj);

    // initiate parameters for SetIPv4Config()
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.168.1.5");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    check_config(lan_obj, true, "192.168.1.5", "255.255.255.0", true, 43200,
                 "192.168.1.100", "192.168.1.249", "lan", "192.168.1.1");

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that setting only the dhcp parameters is allowed (no ip interface setup)
 */
void test_SetIPv4Config_no_ip(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with min address outside subnet
    // setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "172.16.1.10", "192.168.1.150");
    lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    assert_non_null(lan_obj);

    // initiate parameters for SetIPv4Config()
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "192.168.1.10");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "192.168.1.150");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newPool");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    check_config(lan_obj, true, "192.168.1.1", "255.255.255.0", true, 86400,
                 "192.168.1.10", "192.168.1.150", "newPool", "192.168.1.1");

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a maximum address outside the subnet range results in
   invalid function argument status.
 */
void test_SetIPv4Config_max_address_not_in_subnet(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with max address outside subnet
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "192.168.1.10", "172.16.1.150");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a minimum address greater than maximum address results in
   invalid function argument status.
 */
void test_SetIPv4Config_min_greater_than_max(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with min address greater than max address
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.1", "255.255.255.0", "192.168.1.200", "192.168.1.100");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an IP address within the [MinAddress, MaxAddress] range results in
   invalid function argument status. The IP address must be outside this range.
 */
void test_SetIPv4Config_ip_in_range(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with IP address within min-max range
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.100", "255.255.255.0", "192.168.1.10", "192.168.1.150");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an IP address that is in the reserved DHCP addresses list
   results in invalid function argument status.
   Uses the reserved address 192.168.5.1 from the 192.168.5.0/24 subnet in mock_dhcpv4_defaults.odl.
 */
void test_SetIPv4Config_ip_in_reserved(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Set subnet to match the reserved address subnet
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.5.1", "255.255.255.0", "192.168.5.10", "192.168.5.150");
    component_set_str_param("DHCPv4Server.Pool.1.", amxb_be_who_has("DHCPv4Server."), "ReservedAddresses", "192.168.5.0/24");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a minimum address that is in the reserved DHCP addresses list
   results in invalid function argument status.
   Uses the reserved subnet
   192.168.5.16/28 (Subnet address: 192.168.5.16, IP Range: 192.168.5.17-192.168.5.30, Broadcast address: 192.168.5.31)
   that is previously forced into DHCPv4 ReservedAddresses.
 */
void test_SetIPv4Config_min_in_reserved(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Set subnet to match the reserved address subnet
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.5.1", "255.255.255.0", "192.168.5.20", "192.168.5.150");
    component_set_str_param("DHCPv4Server.Pool.1.", amxb_be_who_has("DHCPv4Server."), "ReservedAddresses", "192.168.5.16/28");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a maximum address that is in the reserved DHCP addresses list
   results in invalid function argument status.
   Uses the reserved subnet
   192.168.5.16/28 (Subnet address: 192.168.5.16, IP Range: 192.168.5.17-192.168.5.30, Broadcast address: 192.168.5.31)
   that is previously forced into DHCPv4 ReservedAddresses.
 */
void test_SetIPv4Config_max_in_reserved(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Set subnet to match the reserved address subnet
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.5.1", "255.255.255.0", "192.168.5.10", "192.168.5.20");

    component_set_str_param("DHCPv4Server.Pool.1.", amxb_be_who_has("DHCPv4Server."), "ReservedAddresses", "192.168.5.16/28");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing an IP address that matches the subnet address results in
   invalid function argument status. For example, in subnet 192.168.1.0/24,
   the subnet address 192.168.1.0 is not allowed.
 */
void test_SetIPv4Config_ip_is_subnet_address(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with IP address being the subnet address
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.0", "255.255.255.0", "192.168.1.10", "192.168.1.150");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a minimum address that matches the subnet address results in
   invalid function argument status.
   For example, in subnet
   192.168.1.25/28 (Subnet address: 192.168.1.16, IP Range: 192.168.1.17-192.168.1.30, Broadcast address: 192.168.1.31)
   the subnet address 192.168.1.16 is not allowed.
 */
void test_SetIPv4Config_min_is_subnet_address(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with min address being the subnet address
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.25", "255.255.255.240", "192.168.1.16", "192.168.1.19");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that providing a maximum address that matches the broadcast address results in
   invalid function argument status.
   For example, in subnet
   192.168.1.25/28 (Subnet address: 192.168.1.16, IP Range: 192.168.1.17-192.168.1.30, Broadcast address: 192.168.1.31)
   the boradcast address 192.168.1.31 is not allowed.

 */
void test_SetIPv4Config_max_is_broadcast_address(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);

    // Test with max address being the broadcast address
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "192.168.1.25", "255.255.255.240", "192.168.1.26", "192.168.1.31");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that trying to set pool on a not allowed IANA subnet
   results in invalid_function_argument status.
   (only the following private subnets are allowed:
   10.0.0.0 - 10.255.255.255, 172.16.0.0 - 172.31.255.255, 192.168.0.0 - 192.168.255.255)
 */
void test_SetIPv4Config_not_allowed_IANA_subnet(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "80.168.1.1", "255.0.0.0", "80.168.1.10", "80.168.1.255");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &list_parameters, &ret), amxd_status_invalid_function_argument);

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that trying to set pool on an allowed IANA subnet in 10.0.0.1/8
   results in status_ok status.
   (only the following private subnets are allowed:
   10.0.0.0 - 10.255.255.255, 172.16.0.0 - 172.31.255.255, 192.168.0.0 - 192.168.255.255)
 */
void test_SetIPv4Config_allowed_IANA_subnet_10(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "10.0.0.1", "255.0.0.0", "10.100.0.10", "10.100.0.255");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    check_config(lan_obj, true, "10.0.0.1", "255.0.0.0", true, 40000,
                 "10.100.0.10", "10.100.0.255", "lan", "10.0.0.1");

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

/**
   @brief
   Test that trying to set pool on an allowed IANA subnet in 172.16.0.1/12
   results in status_ok status.
   (only the following private subnets are allowed:
   10.0.0.0 - 10.255.255.255, 172.16.0.0 - 172.31.255.255, 192.168.0.0 - 192.168.255.255)
 */
void test_SetIPv4Config_allowed_IANA_subnet_172(UNUSED void** state) {
    amxd_object_t* lan_obj = NULL;
    amxc_var_t ret;
    amxc_var_t parameters, list_parameters;

    amxc_var_init(&parameters);
    amxc_var_init(&list_parameters);
    amxc_var_init(&ret);
    setup_basic_test_env(&lan_obj, &parameters, &list_parameters, "172.16.0.1", "255.240.0.0", "172.30.0.10", "172.30.0.255");

    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    check_config(lan_obj, true, "172.16.0.1", "255.240.0.0", true, 40000,
                 "172.30.0.10", "172.30.0.255", "lan", "172.16.0.1");

    amxc_var_clean(&parameters);
    amxc_var_clean(&list_parameters);
    amxc_var_clean(&ret);
}

void test_private_ipv4_config(UNUSED void** state) {
    amxd_object_t* lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    amxd_object_t* config_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Subnet.Config.");
    amxc_var_t ret;
    amxc_var_t parameters;

    assert_non_null(lan_obj);
    assert_non_null(config_obj);

    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&ret);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "GetIPv4Config", &parameters, &ret), 0);
    assert_true(GET_BOOL(&ret, "Enable"));
    assert_string_equal("192.168.1.1", GET_CHAR(&ret, "IPAddress"));
    assert_string_equal("255.255.255.0", GET_CHAR(&ret, "SubnetMask"));
    assert_true(GETP_BOOL(&ret, "DHCPParameters.Enable"));
    assert_int_equal(43200, GETP_UINT32(&ret, "DHCPParameters.LeaseTime"));
    assert_string_equal("192.168.1.249", GETP_CHAR(&ret, "DHCPParameters.MaxAddress"));
    assert_string_equal("192.168.1.100", GETP_CHAR(&ret, "DHCPParameters.MinAddress"));
    assert_string_equal("lan", GETP_CHAR(&ret, "DHCPParameters.Pool"));
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.168.2.1");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    // Fails because IPAddress conflicts with guest interface
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.169.12.11");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "192.168.8.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "192.168.8.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    // Fails because IPAddress is not in valid subnet set in mock_subnet.odl
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.168.8.1");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "192.168.8.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "192.168.8.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    // Succeeds because IPAddress is in valid subnet set in mock_subnet.odl
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    check_config(lan_obj, true, "192.168.8.1", "255.255.255.0", true, 40000,
                 "192.168.8.100", "192.168.8.249", "newpool", "192.168.8.1");

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.168.8.1");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "192.168.8.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "192.168.8.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    amxd_object_set_value(cstring_t, config_obj, "InvalidSubnets", "192.168.8.0/24");
    amxd_object_set_value(cstring_t, config_obj, "ValidSubnets", "");
    // Fails because IPAddress is in invalid subnet
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_invalid_function_argument);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "192.167.8.1");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "192.167.8.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "192.167.8.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    amxd_object_set_value(cstring_t, config_obj, "InvalidSubnets", "192.168.8.0/16");
    amxd_object_set_value(cstring_t, config_obj, "ValidSubnets", "");
    // Succeeds because IPAddress is not in invalid subnet
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    // DNS Server does not change because it was already set in the existing pool
    // therefore it keeps its previous value, different from current router adress
    check_config(lan_obj, true, "192.167.8.1", "255.255.255.0", true, 40000,
                 "192.167.8.100", "192.167.8.249", "newpool", "192.168.8.1");

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "91.176.0.50");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "91.176.0.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "91.176.0.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    amxd_object_set_value(cstring_t, config_obj, "ValidSubnets", "91.176.140.205/15");
    // Succeeds because IPAddress is in valid subnet
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    // DNS Server does not change because it was already set in the existing pool
    // therefore it keeps its previous value, different from current router adress
    check_config(lan_obj, true, "91.176.0.50", "255.255.255.0", true, 40000,
                 "91.176.0.100", "91.176.0.249", "newpool", "192.168.8.1");

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "91.177.250.253");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(bool, &parameters, "DHCPEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "MinAddress", "91.177.250.100");
    amxc_var_add_key(cstring_t, &parameters, "MaxAddress", "91.177.250.249");
    amxc_var_add_key(cstring_t, &parameters, "Pool", "newpool");
    amxc_var_add_key(cstring_t, &parameters, "LeaseTime", "40000");
    amxc_var_add_key(cstring_t, &parameters, "DNSServers", "91.177.250.254");
    // Succeeds because IPAddress is in valid subnet
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    check_config(lan_obj, true, "91.177.250.253", "255.255.255.0", true, 40000,
                 "91.177.250.100", "91.177.250.249", "newpool", "91.177.250.254");

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "91.177.250.12");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.255.0");
    amxd_object_set_value(cstring_t, config_obj, "ValidSubnets", "");
    amxd_object_set_value(cstring_t, config_obj, "InvalidSubnets", "");
    // Succeeds because there are no Valid or Invalid subnets defined
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    check_config(lan_obj, true, "91.177.250.12", "255.255.255.0", true, 40000,
                 "91.177.250.100", "91.177.250.249", "newpool", "91.177.250.254");
}

void test_alternative_ipv4_config(UNUSED void** state) {
    amxd_object_t* lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    amxc_var_t ret;
    amxc_var_t parameters;

    assert_non_null(lan_obj);
    amxc_var_init(&ret);

    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(cstring_t, &parameters, "IPAddress", "172.10.10.6");
    amxc_var_add_key(cstring_t, &parameters, "SubnetMask", "255.255.0.0");
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetAlternativeIPv4Config", &parameters, &ret), amxd_status_ok);

    assert_int_equal(amxd_object_invoke_function(lan_obj, "GetAlternativeIPv4Config", &parameters, &ret), amxd_status_ok);
    assert_int_equal(true, GET_BOOL(&ret, "Enable"));
    assert_string_equal("172.10.10.6", GET_CHAR(&ret, "IPAddress"));
    assert_string_equal("255.255.0.0", GET_CHAR(&ret, "SubnetMask"));

    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
}

void test_ipv4_config_ext(UNUSED void** state) {
    amxd_object_t* lan_obj = amxd_dm_findf(amxut_bus_dm(), "Logical.Interface.lan.LAN.");
    amxc_var_t ret;
    amxc_var_t parameters;
    amxc_var_t param_copy;
    amxc_var_t* data = NULL;
    amxc_var_t* list = NULL;

    assert_non_null(lan_obj);
    amxc_var_init(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&param_copy);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    // Add IP configs
    list = amxc_var_add_key(amxc_llist_t, &parameters, "IPConfigs", NULL);

    // Add primary IP config
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "IPAddress", "192.168.5.1");
    amxc_var_add_key(cstring_t, data, "SubnetMask", "255.255.255.0");
    amxc_var_add_key(uint32_t, data, "Index", 1);

    // Add secondary IP config, missing Index
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "IPAddress", "172.16.10.6");
    amxc_var_add_key(cstring_t, data, "SubnetMask", "255.255.0.0");

    // Add DHCP pool configs
    list = amxc_var_add_key(amxc_llist_t, &parameters, "Pools", NULL);

    // Add lan pool config, missing Alias
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "MinAddress", "192.168.5.50");
    amxc_var_add_key(cstring_t, data, "MaxAddress", "192.168.5.200");
    amxc_var_add_key(cstring_t, data, "DNSServers", "192.168.5.1");
    amxc_var_add_key(uint32_t, data, "LeaseTime", 600);

    // Add lan-extender pool config
    data = amxc_var_add(amxc_htable_t, list, NULL);
    amxc_var_add_key(bool, data, "Enable", true);
    amxc_var_add_key(cstring_t, data, "Alias", "lan-extender");
    amxc_var_add_key(cstring_t, data, "MinAddress", "192.168.5.100");
    amxc_var_add_key(cstring_t, data, "MaxAddress", "192.168.5.150");
    amxc_var_add_key(cstring_t, data, "DNSServers", "192.168.5.1");
    amxc_var_add_key(uint32_t, data, "LeaseTime", 6000);

    assert_int_equal(amxc_var_copy(&param_copy, &parameters), 0);
    // Should fail, 2nd IP config index and lan pool Alias are missing
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &parameters, &ret), amxd_status_invalid_function_argument);

    // Add 2nd IP config index
    data = GETP_ARG(&param_copy, "IPConfigs.1.");
    amxc_var_add_key(uint32_t, data, "Index", 2);
    assert_int_equal(amxc_var_copy(&parameters, &param_copy), 0);
    // Should fail, lan pool Alias is still missing
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &parameters, &ret), amxd_status_invalid_function_argument);

    // Add lan pool Alias
    data = GETP_ARG(&param_copy, "Pools.0.");
    amxc_var_add_key(cstring_t, data, "Alias", "lan");
    assert_int_equal(amxc_var_copy(&parameters, &param_copy), 0);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv4ConfigExt", &parameters, &ret), amxd_status_ok);

    // Verify the result
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
    amxc_var_init(&ret);
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxd_object_invoke_function(lan_obj, "GetIPv4ConfigExt", &parameters, &ret), amxd_status_ok);
    // check contents
    assert_true(amxc_var_type_of(&ret) == AMXC_VAR_ID_HTABLE);

    list = GET_ARG(&ret, "IPConfigs");
    assert_non_null(list);
    assert_true(amxc_var_type_of(list) == AMXC_VAR_ID_LIST);

    data = GETI_ARG(list, 0);
    assert_non_null(data);
    assert_true(GET_BOOL(data, "Enable"));
    assert_string_equal(GET_CHAR(data, "IPAddress"), "192.168.5.1");
    assert_string_equal(GET_CHAR(data, "SubnetMask"), "255.255.255.0");
    assert_int_equal(GET_UINT32(data, "Index"), 1);

    data = GETI_ARG(list, 1);
    assert_non_null(data);
    assert_true(GET_BOOL(data, "Enable"));
    assert_string_equal(GET_CHAR(data, "IPAddress"), "172.16.10.6");
    assert_string_equal(GET_CHAR(data, "SubnetMask"), "255.255.0.0");
    assert_int_equal(GET_UINT32(data, "Index"), 2);

    list = GET_ARG(&ret, "Pools");
    assert_non_null(list);
    assert_true(amxc_var_type_of(list) == AMXC_VAR_ID_LIST);

    data = GETI_ARG(list, 0);
    assert_non_null(data);
    assert_true(GET_BOOL(data, "Enable"));
    assert_string_equal(GET_CHAR(data, "Pool"), "lan");
    assert_string_equal(GET_CHAR(data, "MinAddress"), "192.168.5.50");
    assert_string_equal(GET_CHAR(data, "MaxAddress"), "192.168.5.200");
    assert_string_equal(GET_CHAR(data, "DNSServers"), "192.168.5.1");
    assert_int_equal(GET_UINT32(data, "LeaseTime"), 600);

    data = GETI_ARG(list, 1);
    assert_non_null(data);
    assert_true(GET_BOOL(data, "Enable"));
    assert_string_equal(GET_CHAR(data, "Pool"), "lan-extender");
    assert_string_equal(GET_CHAR(data, "MinAddress"), "192.168.5.100");
    assert_string_equal(GET_CHAR(data, "MaxAddress"), "192.168.5.150");
    assert_string_equal(GET_CHAR(data, "DNSServers"), "192.168.5.1");
    assert_int_equal(GET_UINT32(data, "LeaseTime"), 6000);

    amxc_var_clean(&parameters);
    amxc_var_clean(&param_copy);
    amxc_var_clean(&ret);
}

void test_ipv6_config(UNUSED void** state) {
    amxd_object_t* lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    amxc_var_t ret;
    amxc_var_t parameters;

    assert_non_null(lan_obj);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "GetIPv6Config", &parameters, &ret), amxd_status_ok);
    assert_true(GET_BOOL(&ret, "Enable"));
    assert_true(GETP_BOOL(&ret, "DHCPParameters.Enable"));
    assert_string_equal("lan", GETP_CHAR(&ret, "DHCPParameters.Pool"));
    assert_false(GETP_BOOL(&ret, "DHCPParameters.IANAEnable"));
    assert_false(GETP_BOOL(&ret, "DHCPParameters.IANAEnable"));
    assert_true(GETP_BOOL(&ret, "RAParameters.RAEnable"));
    assert_string_equal("lan", GETP_CHAR(&ret, "RAParameters.RAPool"));
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", true);
    amxc_var_add_key(bool, &parameters, "DHCPv6Enable", true);
    amxc_var_add_key(bool, &parameters, "IANAEnable", true);
    amxc_var_add_key(bool, &parameters, "IAPDEnable", false);
    amxc_var_add_key(cstring_t, &parameters, "DHCPv6Pool", "newpool");
    amxc_var_add_key(bool, &parameters, "RAEnable", true);
    amxc_var_add_key(cstring_t, &parameters, "RAPool", "newpool");
    assert_int_equal(amxd_object_invoke_function(lan_obj, "SetIPv6Config", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    assert_int_equal(amxd_object_invoke_function(lan_obj, "GetIPv6Config", &parameters, &ret), amxd_status_ok);
    assert_true(GET_BOOL(&ret, "Enable"));
    assert_true(GETP_BOOL(&ret, "DHCPParameters.Enable"));
    assert_true(GETP_BOOL(&ret, "DHCPParameters.IANAEnable"));
    assert_false(GETP_BOOL(&ret, "DHCPParameters.IAPDEnable"));
    assert_string_equal("newpool", GETP_CHAR(&ret, "DHCPParameters.Pool"));
    assert_true(GETP_BOOL(&ret, "RAParameters.RAEnable"));
    assert_string_equal("newpool", GETP_CHAR(&ret, "RAParameters.RAPool"));
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
}

void test_lower_layer_config(UNUSED void** state) {
    amxc_var_t parameters;
    amxc_var_t ret;
    amxd_object_t* lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.lan.LAN.");
    amxd_object_t* guest_obj = amxd_dm_findf(amxut_bus_dm(), "%s", "Logical.Interface.guest.LAN.");

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.2.");
    // Fails because Device.Ethernet.Interface.2 is part of lan interface hierarchy
    assert_int_equal(amxd_object_invoke_function(guest_obj, "AddLowerLayerInterface", &parameters, &ret), amxd_status_invalid_function_argument);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.2.");
    // Fails because Device.Ethernet.Interface.2 is part of lan interface hierarchy
    assert_int_equal(amxd_object_invoke_function(guest_obj, "RemoveLowerLayerInterface", &parameters, &ret), amxd_status_invalid_function_argument);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.2.");
    assert_int_equal(amxd_object_invoke_function(lan_obj, "RemoveLowerLayerInterface", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.2.");
    assert_int_equal(amxd_object_invoke_function(guest_obj, "AddLowerLayerInterface", &parameters, &ret), amxd_status_ok);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.nonexisting");
    // Fails because Device.Ethernet.Interface.nonexisting doesn't exist
    assert_int_equal(amxd_object_invoke_function(guest_obj, "AddLowerLayerInterface", &parameters, &ret), amxd_status_object_not_found);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);

    amxc_var_init(&parameters);
    amxc_var_init(&ret);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "LowerLayerInterface", "Device.Ethernet.Interface.nonexisting");
    // Fails because Device.Ethernet.Interface.nonexisting doesn't exist
    assert_int_equal(amxd_object_invoke_function(guest_obj, "RemoveLowerLayerInterface", &parameters, &ret), amxd_status_object_not_found);
    amxc_var_clean(&parameters);
    amxc_var_clean(&ret);
}

void test_domain_search_list(UNUSED void** state) {
    amxc_var_t parameters;
    const char* lan_obj_string = "Logical.Interface.lan.LAN.";
    amxd_object_t* lan_obj = NULL;
    amxc_var_t option_params;
    char* ra_pool = NULL;
    const char* dhcpv4_pool = "DHCPv4Server.Pool.1.";
    const char* dhcpv6_pool = "DHCPv6Server.Pool.1.";
    amxd_trans_t trans;
    amxc_string_t dhcpv4_option;
    amxc_string_t dhcpv6_option;

    amxc_var_init(&option_params);

    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", lan_obj_string);
    assert_non_null(lan_obj);

    amxc_string_init(&dhcpv4_option, 0);
    amxc_string_setf(&dhcpv4_option, "%sOption.[Tag == '119'].", dhcpv4_pool);
    amxc_string_init(&dhcpv6_option, 0);
    amxc_string_setf(&dhcpv6_option, "%sOption.[Tag == '24'].", dhcpv6_pool);

    component_get_parameters(&option_params, amxc_string_get(&dhcpv6_option, 0), amxb_be_who_has("DHCPv6Server."));
    assert_true(GET_BOOL(&option_params, "Enable"));
    assert_string_equal(GET_CHAR(&option_params, "Value"),
                        "04686F6D65046172706100");

    ra_pool = component_get_path_instance(amxb_be_who_has("RouterAdvertisement."), "RouterAdvertisement.InterfaceSetting.[DNSSL == 'home.arpa']");
    assert_non_null(ra_pool);

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, lan_obj);
    amxd_trans_set_value(cstring_t, &trans, "DomainSearchList", "be.softathome.com,rd.softathome.com,softathome.com");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    component_get_parameters(&option_params, amxc_string_get(&dhcpv4_option, 0), amxb_be_who_has("DHCPv4Server."));
    assert_true(GET_BOOL(&option_params, "Enable"));
    assert_string_equal(GET_CHAR(&option_params, "Value"),
                        "0262650A736F66746174686F6D6503636F6D000272640A736F66746174686F6D6503636F6D000A736F66746174686F6D6503636F6D00");

    component_get_parameters(&option_params, amxc_string_get(&dhcpv6_option, 0), amxb_be_who_has("DHCPv6Server."));
    assert_true(GET_BOOL(&option_params, "Enable"));
    assert_string_equal(GET_CHAR(&option_params, "Value"),
                        "0262650A736F66746174686F6D6503636F6D000272640A736F66746174686F6D6503636F6D000A736F66746174686F6D6503636F6D0004686F6D65046172706100");

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, lan_obj);
    amxd_trans_set_value(cstring_t, &trans, "DomainSearchList", "");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    component_get_parameters(&option_params, amxc_string_get(&dhcpv4_option, 0), amxb_be_who_has("DHCPv4Server."));
    assert_false(GET_BOOL(&option_params, "Enable"));
    assert_string_equal(GET_CHAR(&option_params, "Value"), "");

    component_get_parameters(&option_params, amxc_string_get(&dhcpv6_option, 0), amxb_be_who_has("DHCPv6Server."));
    assert_true(GET_BOOL(&option_params, "Enable"));
    assert_string_equal(GET_CHAR(&option_params, "Value"),
                        "04686F6D65046172706100");

    component_get_param(&option_params, ra_pool, amxb_be_who_has("RouterAdvertisement."), "DNSSL");
    assert_string_equal(GETP_CHAR(&option_params, "0.0.DNSSL"), "home.arpa");

    amxc_var_clean(&parameters);
    amxc_var_clean(&option_params);
    free(ra_pool);
    amxc_string_clean(&dhcpv4_option);
    amxc_string_clean(&dhcpv6_option);
}

void test_domain_name(UNUSED void** state) {
    amxc_var_t parameters;
    const char* lan_obj_string = "Logical.Interface.lan.LAN.";
    amxd_object_t* lan_obj = NULL;
    amxc_var_t option_params;
    const char* dhcpv4_pool = "DHCPv4Server.Pool.1.";
    const char* dns_config = "DNS.Relay.Config.1.";
    amxd_trans_t trans;

    amxc_var_init(&option_params);

    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    lan_obj = amxd_dm_findf(amxut_bus_dm(), "%s", lan_obj_string);
    assert_non_null(lan_obj);

    //include_dns();
    amxp_sigmngr_emit_signal(NULL, "wait:DNS.", NULL);
    expect_check_set_host("hostname-1", "Device.Logical.Interface.2.", "prplOS");
    amxut_bus_handle_events();

    component_get_param(&option_params, dhcpv4_pool, amxb_be_who_has("DHCPv4Server."), "DomainName");
    assert_string_equal(GETP_CHAR(&option_params, "0.0.DomainName"), "home.arpa");

    component_get_param(&option_params, dns_config, amxb_be_who_has("DNS."), "DomainName");
    assert_string_equal(GETP_CHAR(&option_params, "0.0.DomainName"), "home.arpa");

    amxd_trans_init(&trans);
    amxd_trans_select_object(&trans, lan_obj);
    amxd_trans_set_value(cstring_t, &trans, "DomainName", "lan");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    component_get_param(&option_params, dhcpv4_pool, amxb_be_who_has("DHCPv4Server."), "DomainName");
    assert_string_equal(GETP_CHAR(&option_params, "0.0.DomainName"), "lan");

    component_get_param(&option_params, dns_config, amxb_be_who_has("DNS."), "DomainName");
    assert_string_equal(GETP_CHAR(&option_params, "0.0.DomainName"), "lan");

    amxc_var_clean(&parameters);
    amxc_var_clean(&option_params);
}
