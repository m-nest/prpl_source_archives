/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_sfp_db.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <unistd.h> /* unlink() */

/* Other libraries' headers */
#include <amxc/amxc.h>                  /* needed by amxd_types.h */
#include <amxc/amxc_macros.h>           /* UNUSED */
#include <amxp/amxp_signal.h>           /* needed by amxd_types.h */
#include <amxd/amxd_types.h>            /* amxd_dm_t */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxo/amxo_types.h>            /* amxo_parser_t */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */
#include <amxd/amxd_object_hierarchy.h> /* amxd_object_get_instance_count() */

/* Own headers */
#include "common_dm_functions.h"     /* check_no_sfp_is_present() */
#include "common_functions.h"        /* read_sig_alarm() */
#include "file_utils.h"              /* create_folder() */
#include "json_utils.h"              /* read_json_from_file() */
#include "setup_and_teardown.h"      /* setup_common() */
#include "sfpmgr_trace.h"
#include "sfp_types_and_constants.h" /* SFP_ID_UNKNOWN */

#undef ME
#define ME "runtest"

static amxd_dm_t dm;
static amxo_parser_t parser;

static const char* const SCRIPT_FOLDER = "/tmp/tr181-sfp/scripts";
static const char* const GET_EEPROM_INFO = "/tmp/tr181-sfp/scripts/get_eeprom_info.sh";
static const char* const GET_RXLOS = "/tmp/tr181-sfp/scripts/get_rxlos.sh";

static const char* const TEST_VENDOR_NAME = "T&W";
static const char* const TEST_VENDOR_PN = "TW2362H-HDEL-A98";
static const char* const TEST_SFP_TYPE = "EPON";


static void check_vendor_name_and_part_number(void) {
    amxc_var_t value;
    amxc_var_init(&value);

    amxd_object_t* const trx =
        amxd_dm_findf(&dm, "SFPs.Mgmt.SFF8472.1.Transceiver.");
    assert_non_null(trx);

    assert_int_equal(amxd_object_get_param(trx, "VendorName", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), TEST_VENDOR_NAME);

    assert_int_equal(amxd_object_get_param(trx, "VendorPN", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), TEST_VENDOR_PN);

    amxc_var_clean(&value);
}

static void check_dm_of_inserted_sfp(const char* sfp_type) {
    check_sfp_cage_parameters(&dm, sfp_type);
    check_vendor_name_and_part_number();
}

int test_sfp_db_setup(UNUSED void** state) {
    int rc;
    rc = setup_common_with_extra_odl(&dm, &parser, /*invoke_main_entry_point=*/ true,
                                     "sfp_db.odl");
    assert_int_equal(rc, 0);
    create_folder(SCRIPT_FOLDER);
    return 0;
}

int test_sfp_db_teardown(UNUSED void** state) {
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

/**
 * Check that the SFP DB has one entry.
 *
 * Check that the entry specifies that the SFP type of the SFP with vendor name
 * TEST_VENDOR_NAME and part number TEST_VENDOR_PN is TEST_SFP_TYPE.
 */
static void check_sfp_db(void) {
    amxc_var_t value;
    amxc_var_init(&value);

    const amxd_object_t* const sfp_db = amxd_dm_findf(&dm, "SFPs.X_PRPLWARE-COM_SFPDatabase");
    assert_non_null(sfp_db);
    assert_int_equal(amxd_object_get_instance_count(sfp_db), 1);

    amxd_object_t* const entry = amxd_dm_findf(&dm, "SFPs.X_PRPLWARE-COM_SFPDatabase.1");

    assert_int_equal(amxd_object_get_param(entry, "VendorName", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), TEST_VENDOR_NAME);

    assert_int_equal(amxd_object_get_param(entry, "VendorPN", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), TEST_VENDOR_PN);

    assert_int_equal(amxd_object_get_param(entry, "SFPType", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), TEST_SFP_TYPE);

    amxc_var_clean(&value);
}

/**
 * Test that tr181-sfp checks SFP DB to update SFP DB.
 *
 * Do the same as test_plug_unplug_sfp() in test-tr181_sfp_02_plug_unplug_sfp,
 * but first let tr181-sfp load an odl file which adds one entry to
 * SFPs.X_PRPLWARE-COM_SFPDatabase. The entry specifies that the SFP with vendor
 * name "T&W" and part number "TW2362H-HDEL-A98" has EPON as SFP type. (That SFP
 * is a G-PON SFP, but this test says its SFP type is EPON for test reasons.)
 * The addition of the entry is done by test_sfp_db_setup(): it loads an odl
 * file which adds the entry.
 *
 * After simulating that the SFP with that vendor name name and part number is
 * inserted, check that SFPs.SFPCage.1.SFPType reports "EPON" as value (instead
 * of "G-PON").
 */
void test_sfp_db(UNUSED void** state) {

    int i;
    int rc;
    char eeprom_info[64];

    check_no_sfp_is_present(&dm);
    check_sfp_db();

    rc = snprintf(eeprom_info, 64, "echo \"3\" \"0\" \"0\" \"0d\" \"0\"");
    assert_true(rc > 0 && rc < 64);
    create_script(GET_EEPROM_INFO, eeprom_info);
    create_script(GET_RXLOS, "echo DOWN");
    copy_file("../test_data/G-PON_test_data/G-PON_ethtool_data.txt",
              EXAMPLE_ETHTOOL_OUTPUT);

    for(i = 0; i < 2; ++i) {
        read_sig_alarm(1);
    }

    check_dm_of_inserted_sfp("EPON");

    unlink(GET_EEPROM_INFO);
    unlink(GET_RXLOS);
    unlink(EXAMPLE_ETHTOOL_OUTPUT);
}

