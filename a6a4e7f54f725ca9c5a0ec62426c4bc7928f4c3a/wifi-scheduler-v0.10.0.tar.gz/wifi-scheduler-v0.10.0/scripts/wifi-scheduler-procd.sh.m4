#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

[ -f /etc/environment ] && source /etc/environment
ulimit -c ${ULIMIT_CONFIGURATION:-0}

name="wifi-scheduler"
PROG="/usr/bin/amxrt"
datamodel_root="WiFiScheduler"
monitor_pid_file="/var/run/${name}.pid"
PROG_OPTIONS="/etc/amx/${name}/${name}.odl"

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    mkdir -p /var/lib/${name}
    touch /var/lib/${name}/${name}_config.odl
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

log() {
    echo "log ${name}"
}

extra_command log "Show ${name} log Entries"

