#!/bin/sh

itf_name_to_alias()
{
	echo -n "$@" | tr 'a-z' 'A-Z'
}

itf_name_to_dt_alias()
{
	local itf_name=$1
	local dt_alias
	local dt_alias_ref
	local dt_label
	local dt_dir=/proc/device-tree

	for dt_alias in $(ls ${dt_dir}/aliases); do
		[[ "${dt_alias}" == "label-mac-device" ]] && continue
		echo "${dt_alias}" | grep -Eq "^ethernet[0-9]+$" && continue
		echo "${dt_alias}" | grep -Eq "^[-0-9a-z]+$" || continue

		dt_alias_ref=$(cat ${dt_dir}/aliases/${dt_alias})
		[[ ! -z "${dt_alias_ref}" ]] || continue

		[[ -f "${dt_dir}/${dt_alias_ref}/device_type" ]] || continue
		[[ "$(cat ${dt_dir}/${dt_alias_ref}/device_type)" == "network" ]] || continue

		[[ -f "${dt_dir}/${dt_alias_ref}/label" ]] || continue
		dt_label=$(cat ${dt_dir}/${dt_alias_ref}/label 2>/dev/null)
		[[ "${dt_label}" == "$itf_name" ]] || continue

		echo -n "cpe-${dt_alias}"
		return
	done

	# fallback to default alias
	itf_name_to_alias "${itf_name}"
}

NEXT_SFP_CAGE_INDEX=1
netlayout_discover_sfpcage()
{
	local itf_name="$1"
	local sfp_supported_types="$2"

	[ -z "$(which tr181-sfp)" ] && return

	local ethtool_output=/tmp/ethtool-output
	ethtool -m $itf_name >$ethtool_output 2>&1
	if [ $? -eq 0 -o "$(sed -n -e 's/Cannot get .*: \(.*\)$/\1/p' $ethtool_output)" == "Remote I/O error" ]; then
		json_add_string SFPCage $((NEXT_SFP_CAGE_INDEX++))
		json_add_string SFPSupportedType "$sfp_supported_types"
	fi
	rm $ethtool_output
}

netlayout_add_wan_itf()
{
	local itf_name=$(uci -q get network.wan.ifname)
	[ -z "$itf_name" ] && itf_name=$(uci -q get network.wan.device)

	local itf_alias=$(itf_name_to_dt_alias "$itf_name")

	json_select Interfaces
	json_add_object
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name
	json_add_string Type ethernet
	json_add_string Upstream true
	netlayout_discover_sfpcage $itf_name "G-PON,XG-PON,NG-PON2,XGS-PON,Optical Ethernet,Electrical Ethernet,EPON"
	json_close_object
	json_select ..
}

netlayout_add_wwan_itf()
{
	local itf_name
	local i
	for i in rmnet_mhi0 mhi_hwip0; do
		if [ -d "/sys/class/net/$i" ]; then
			itf_name=$i
			break
		fi
	done
	[ -z "$itf_name" ] && itf_name=wwan0

	local itf_alias=$(itf_name_to_dt_alias "$itf_name")

	json_select Interfaces
	json_add_object
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name
	json_add_string Type cellular
	json_add_string Upstream true
	json_add_string Failover true
	json_close_object
	json_select ..
}

# Handles MaxLinear UPDK BSP specific UCI configuration for PON interfaces (will be fixed properly via PPW-765)
netlayout_add_mxl_updk_pon_itf()
{
	local itf_name=$(uci -q get network.pon.ifname)
	[ -z "$itf_name" ] && itf_name=$(uci -q get network.pon.device)
	[ -z "$itf_name" ] && return

	local itf_type=$(uci -q get network.wan2.type)
	[ -z "$itf_type" ] && itf_type='xpon'

	local itf_alias=$(itf_name_to_dt_alias "$itf_name")
	json_select Interfaces
	json_add_object
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name
	json_add_string Type $itf_type
	json_add_string Upstream true
	json_close_object
	json_select ..
}

netlayout_add_itf_description()
{
	local itf_alias=$1
	local itf_name=$2
	local itf_type=$3
	local itf_operFreq=$4
	local itf_ssid=$5

	json_select Interfaces
	json_add_object
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name
	json_add_string Type $itf_type
	[ "$itf_type" == "ethernet" ] && netlayout_discover_sfpcage $itf_name "MoCA,Optical Ethernet,Electrical Ethernet"
	[ ! -z "$itf_operFreq" ] && json_add_string OperatingFrequency $itf_operFreq
	[ ! -z "$itf_ssid" ] && json_add_string SSID $itf_ssid
	json_close_object
	json_select ..
}

netlayout_add_radio_description()
{
	local rad_alias=$1
	local rad_operFreq=$2

	json_select Radios
	json_add_object
	json_add_string Alias $rad_alias
	json_add_string OperatingFrequency $rad_operFreq
	json_close_object
	json_select ..
}

netlayout_add_ep_itf_description()
{
	local itf_alias=$1
	local itf_name=$2
	local itf_operFreq=$3

	json_select Interfaces
	json_add_object
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name
	json_add_string Type wireless
	json_add_string isEndpoint "true"
	json_add_string OperatingFrequency $itf_operFreq
	json_add_string BridgeInterface $brLan

	json_close_object
	json_select ..
}


netlayout_add_itf_to_bridge()
{
	local bridge_name=$1
	local itf_alias=$2
	local itf_name=$3

	json_select Bridges
	json_select $bridge_name
	json_select Ports
	json_add_object 
	json_add_string Alias $itf_alias
	json_add_string Name $itf_name 
	json_close_object
	json_select ..
	json_select ..
	json_select ..
}

netlayout_add_lan_bridged_itfs()
{
	local bridged=$(uci get network.lan.ifname)
	local bridged=$(uci -q get network.lan.ifname)
	[ -z "$bridged" ] && return

	#first add all lan interface description
	for itf in $bridged ; do
		netlayout_add_itf_description "$(itf_name_to_dt_alias "$itf")" "${itf}" "ethernet"
	done

	#then add all lan interfaces as bridge ports
	local idx=0
	for itf in $bridged; do
		netlayout_add_itf_to_bridge "Lan" "eth_port${idx}" "${itf}"
		idx=$((idx+1))
	done
}

netlayout_add_lan_dsa_bridged_itfs()
{
	local intf=$(uci -q get network.lan.device)
	[ -z "$intf" ] && return

	. /lib/functions.sh

	add_network_device()
	{
		local name
		local ports
		local cfg="$1"

		config_get name "$cfg" name
		config_get ports "$cfg" ports

		[ "$intf" != "$name" ] && return

		#first add all lan interface description
		for itf in $ports; do
			netlayout_add_itf_description "$(itf_name_to_dt_alias "$itf")" "${itf}" "ethernet"
		done

		#then add all lan interfaces as bridge ports
		for itf in $ports; do
			netlayout_add_itf_to_bridge "Lan" "$(itf_name_to_dt_alias "$itf")"  "${itf}"
		done
	}

	config_load network
	config_foreach add_network_device device
}

netlayout_add_wireless_itf()
{
	local itf_name=$1
	local linux_itf=$2
	local network=$3
	local operFreq=$4
	local ssid=$5
	local itf_alias=$(itf_name_to_alias "$itf_name")

	#first add wireless interface description
	netlayout_add_itf_description "${itf_alias}" "${linux_itf}" "wireless" "${operFreq}" "${ssid}"

	#then if interface is part of lan or guest network add it to corresponding bridge
	if [ "${network}" = "lan" ] ; then
		netlayout_add_itf_to_bridge "Lan" "${itf_name}" "${linux_itf}"
		wlan_port_idx=$((wlan_port_idx+1))
	elif [ "${network}" = "guest" ] ; then
		netlayout_add_itf_to_bridge "Guest" "${itf_name}" "${linux_itf}"
		guest_wl_idx=$((guest_wl_idx+1))
	elif [ "${network}" = "lcm" ] ; then
		netlayout_add_itf_to_bridge "Lcm" "${itf_name}" "${linux_itf}"
	fi

	# if new radio add the corresponding endpoint entry
	if ! echo "${op_rad_list}" | grep -q "${operFreq}"; then
		ep_itf_name="ep${operFreq:0:1}g0"
		ep_linux_itf=$(echo "$linux_itf" | sed 's/-1/-2/; t; s/$/-2/') # static wlanIDX-2 
		netlayout_add_ep_itf_description "${ep_itf_name}" "${ep_linux_itf}" "${operFreq}"
		netlayout_add_itf_to_bridge "Lan" "${ep_itf_name}" "${ep_linux_itf}"
		wlan_port_idx=$((wlan_port_idx+1))
		op_rad_list="${op_rad_list};${operFreq}"
	fi
}

netlayout_add_wireless_radio()
{
	local name=$1
	local operFreq=$2
	netlayout_add_radio_description "${name}" "${operFreq}"
}

netlayout_add_wireless_entries()
{
	local type=$1
	shift;
	if [ "${type}" == "INTERFACE" ]; then
		netlayout_add_wireless_itf $*
	elif [ "${type}" == "RADIO" ]; then
		netlayout_add_wireless_radio $*
	fi
}

netlayout_add_wireless_itfs()
{
	wlan_port_idx=0
	guest_wl_idx=0
	op_rad_list=""
 	read -r -d '' awkscript << 'EOF'
 	function flush_vap(vap,radios,    radname,vapIdx,operFreq,radIdx){
		if ( vap["name"] == "" )  return;
	
		radname=vap["rad"];
		vapIdx = radios[radname"_nbVap"]++;
		operFreq = radios[radname"_band"];
		if ( vap["itf"] == "" ) { #build ifname if it was not provided as done in mac80211.sh 
			radIdx = radios[radname"_radIdx"];
			vap["itf"]= "wlan" radIdx;
			if (vapIdx != 0) vap["itf"]= vap["itf"] "-" vapIdx;
		}
	
		printf "INTERFACE" ";" vap["name"] ";" vap["itf"] ";" vap["net"] ";" operFreq ";" vap["ssid"] " ";
		delete vap;
	}
	function flush_rad(rad,radios,    operFreq){
		if ( rad == "" ) return;
		operFreq = radios[rad"_band"];
		printf "RADIO" ";" rad ";" operFreq " ";
	}
	BEGIN { FS="="; idxRad=0; currentVap["name"]=""; radname=""; } 
	/wireless/ {
		split($1,path,"."); gsub( "'","",$2);
		
		if ($2 == "wifi-device") {   # new radio section
			flush_rad(radname,arrRad);
			radname=path[2];
			arrRad[radname"_radIdx"]=idxRad++; 
			arrRad[radname"_nbVap"]=0;
		} 
		if ($2 == "wifi-iface")  {   # new interface section
			flush_vap(currentVap,arrRad);
			currentVap["name"] = path[2];
		}
		if (path[3] == "device") { currentVap["rad"]= $2; }  #get radio reference
		if (path[3] == "ifname") { currentVap["itf"]= $2; }  #get linux interface name 	
		if (path[3] == "network") { currentVap["net"]= $2; }  #get associated network  
		if (path[3] == "ssid") { currentVap["ssid"]= $2; }  #get ssid
		if (path[3] == "hwmode") {
			if ($2 == "11g") { arrRad[radname"_band"]="2.4GHz"; }
			if ($2 == "11a") { arrRad[radname"_band"]="5GHz"; }
			if ($2 == "11ax") { arrRad[radname"_band"]="6GHz"; }
		}
		if (path[3] == "band") {
			if ($2 == "2g" || $2 == "2.4GHz") { arrRad[radname"_band"]="2.4GHz"; }
			if ($2 == "5g" || $2 == "5GHz") { arrRad[radname"_band"]="5GHz"; }
			if ($2 == "6g" || $2 == "6GHz") { arrRad[radname"_band"]="6GHz"; }
		}
	}
	END { flush_vap(currentVap,arrRad); flush_rad(radname,arrRad); }
EOF
 
 	wifi_itfs=$(uci show wireless | awk "$awkscript" )
  	for itf in $wifi_itfs; do
		netlayout_add_wireless_entries ${itf//;/ }
	done 
}


netlayout_init()
{
	json_init

	# Create json skeleton for interfaces and bridge definition
	json_add_array Interfaces
	json_close_array

	json_add_object Bridges
		if [ -n "$brLan" ]; then
			json_add_object Lan
				json_add_string Name $brLan
				json_add_array Ports
				json_close_array
			json_close_object
		fi
		if [ -n "$brGuest" ]; then
			json_add_object Guest
				json_add_string Name $brGuest
				json_add_array Ports
				json_close_array
			json_close_object
		fi
		if [ -n "$brLcm" ]; then
			json_add_object Lcm
				json_add_string Name $brLcm
				json_add_array Ports
				json_close_array
			json_close_object
		fi
	json_close_object
	json_add_array Radios
	json_close_array
}

count_matching_lines()
{
	local matching_lines=$(grep -c "$@" 2>/dev/null)
	if [[ "${matching_lines}" =~ '^[0-9]+$' ]]; then
		echo "${matching_lines}"
	else
		echo 0
	fi
}

wait_for_uci_wireless() {
	local phy_count
	local uci_count
	local timeout=3
	local elapsed=0
	local min_phy=0
	local timeout_uci=$(uci -q get wireless.vendor.phy_detect_timeout)
	local min_phy_uci=$(uci -q get wireless.vendor.min_phy)

	[ -n "$timeout_uci" ] && timeout=$timeout_uci
	[ -n "$min_phy_uci" ] && min_phy=$min_phy_uci

	phy_count=$(iw phy | grep -c Wiphy)
	uci_count=$(count_matching_lines 'wifi-device.*radio' /etc/config/wireless)

	while ([ "$phy_count" -lt "$min_phy" ] || [ "$phy_count" -ne "$uci_count" ]) && [ $elapsed -lt $timeout ]; do
		phy_count=$(iw phy | grep -c Wiphy)
		uci_count=$(count_matching_lines 'wifi-device.*radio' /etc/config/wireless)
		elapsed=$((elapsed + 1))
		sleep 1
	done
}

