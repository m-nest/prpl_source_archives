/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object_function.h>
#include <debug/sahtrace.h>

#include <lcm/amxc_data.h>
#include <lcm/lcm_assert.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_defines.h>
#include <timingila/timingila_defines.h>

#include "timingila_cthulhu_priv.h"

#include "wrappers.h"
#include "test_notify_handler.h"

#define ME "test"

static amxd_dm_t datamodel;
static amxo_parser_t parser;

static void cmd_cb(UNUSED const amxb_bus_ctx_t* bus_ctx,
                   UNUSED amxb_request_t* req,
                   UNUSED int status,
                   UNUSED void* priv) {
    SAH_TRACEZ_INFO(ME, "CB");
}

int test_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;

    sahTraceOpen(ME, TRACE_TYPE_STDOUT);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "all");

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&datamodel);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/timingila-fake-definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-definition.odl", root_obj), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/softwaremodules_definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-config.odl", root_obj), 0);

    return res;
}

int test_teardown(UNUSED void** state) {
    amxc_var_clean(get_expected_dustatechange());
    amxo_parser_clean(&parser);
    amxd_dm_clean(&datamodel);
    sahTraceClose();

    return 0;
}

void test_no_notification(UNUSED void** state) {
    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&data);
}

void test_ctr_create(UNUSED void** state) {
    amxc_var_t cmd_args;
    amxc_var_init(&cmd_args);
    amxc_var_set_type(&cmd_args, AMXC_VAR_ID_HTABLE);

    amxc_var_t* cmd_priv;
    amxc_var_new(&cmd_priv);
    amxc_var_set_type(cmd_priv, AMXC_VAR_ID_HTABLE);

    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // send container command
    amxc_var_t* dustatechange_data = amxc_var_add_key(amxc_htable_t, cmd_priv, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, "uuid");
    amxc_ts_t start_time = {0, 0, 0};
    amxc_ts_now(&start_time);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, &start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, SM_DM_EVENT_DUSTATECHANGE_OPERATION_INSTALL);
    amxc_var_copy(get_expected_dustatechange(), dustatechange_data);
    cthulhu_container_command(CTHULHU_CMD_CTR_CREATE, &cmd_args, cmd_cb, cmd_priv);

    // process notify handler
    amxc_var_add_new_key_cstring_t(&data, CTHULHU_NOTIF_COMMAND_ID, get_last_cmd_id());
    amxc_var_add_new_key_cstring_t(&data, AMXM_NOTIFICATION, CTHULHU_NOTIF_CTR_CREATED);
    amxc_var_t* dm_obj_data = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_DM_OBJ_FULL, NULL);
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_SANDBOX, "generic");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_ID, "ctr_id");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_LINKED_UUID, "uuid");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_BUNDLEVERSION, "3.14");

    // tell the handler that the completetime should be checked
    amxc_var_add_key(amxc_ts_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &start_time);

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&cmd_args);
    //amxc_var_clean(&cmd_priv);
    amxc_var_clean(&data);
}


void test_ctr_create_wo_cmd(UNUSED void** state) {
    amxc_var_t cmd_args;
    amxc_var_init(&cmd_args);
    amxc_var_set_type(&cmd_args, AMXC_VAR_ID_HTABLE);

    amxc_var_t* cmd_priv;
    amxc_var_new(&cmd_priv);
    amxc_var_set_type(cmd_priv, AMXC_VAR_ID_HTABLE);

    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // send container command
    amxc_var_t* dustatechange_data = amxc_var_add_key(amxc_htable_t, cmd_priv, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, "uuid");
    amxc_ts_t start_time = {0, 0, 0};
    amxc_ts_now(&start_time);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, &start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, SM_DM_EVENT_DUSTATECHANGE_OPERATION_INSTALL);
    amxc_var_copy(get_expected_dustatechange(), dustatechange_data);
    cthulhu_container_command(CTHULHU_CMD_CTR_CREATE, &cmd_args, cmd_cb, cmd_priv);

    // process notify handler
    // amxc_var_add_new_key_cstring_t(&data, CTHULHU_NOTIF_COMMAND_ID, get_last_cmd_id());
    amxc_var_add_new_key_cstring_t(&data, AMXM_NOTIFICATION, CTHULHU_NOTIF_CTR_CREATED);
    amxc_var_t* dm_obj_data = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_DM_OBJ_FULL, NULL);
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_SANDBOX, "generic");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_ID, "ctr_id");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_LINKED_UUID, "uuid");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_BUNDLEVERSION, "3.14");

    // tell the handler that the completetime should be checked
    amxc_var_add_key(amxc_ts_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &start_time);

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&cmd_args);
    //amxc_var_clean(&cmd_priv);
    amxc_var_clean(&data);
}

void test_ctr_update(UNUSED void** state) {
    amxc_var_t cmd_args;
    amxc_var_init(&cmd_args);
    amxc_var_set_type(&cmd_args, AMXC_VAR_ID_HTABLE);

    amxc_var_t* cmd_priv;
    amxc_var_new(&cmd_priv);
    amxc_var_set_type(cmd_priv, AMXC_VAR_ID_HTABLE);

    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // send container command
    amxc_var_t* dustatechange_data = amxc_var_add_key(amxc_htable_t, cmd_priv, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, "uuid");
    amxc_ts_t start_time = {0, 0, 0};
    amxc_ts_now(&start_time);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, &start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, SM_DM_EVENT_DUSTATECHANGE_OPERATION_UPDATE);
    amxc_var_copy(get_expected_dustatechange(), dustatechange_data);
    amxc_var_add_key(cstring_t, cmd_priv, SM_DM_DU_VERSION_OLD, "3.14");
    amxc_var_add_key(cstring_t, cmd_priv, SM_DM_DU_VERSION, "3.15");
    amxc_var_add_key(cstring_t, cmd_priv, SM_DM_DU_DUID, "duid");
    cthulhu_container_command(CTHULHU_CMD_CTR_CREATE, &cmd_args, cmd_cb, cmd_priv);

    // process notify handler
    amxc_var_add_new_key_cstring_t(&data, CTHULHU_NOTIF_COMMAND_ID, get_last_cmd_id());
    amxc_var_add_new_key_cstring_t(&data, AMXM_NOTIFICATION, CTHULHU_NOTIF_CTR_UPDATED);
    amxc_var_t* dm_obj_data = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_DM_OBJ_FULL, NULL);
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_SANDBOX, "generic");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_ID, "ctr_id");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_LINKED_UUID, "uuid");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_BUNDLEVERSION, "3.15");

    // tell the handler that the completetime should be checked
    amxc_var_add_key(amxc_ts_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &start_time);

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&cmd_args);
    //amxc_var_clean(&cmd_priv);
    amxc_var_clean(&data);
}

void test_ctr_uninstall(UNUSED void** state) {
    amxc_var_t cmd_args;
    amxc_var_init(&cmd_args);
    amxc_var_set_type(&cmd_args, AMXC_VAR_ID_HTABLE);

    amxc_var_t* cmd_priv;
    amxc_var_new(&cmd_priv);
    amxc_var_set_type(cmd_priv, AMXC_VAR_ID_HTABLE);

    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // send container command
    amxc_var_t* dustatechange_data = amxc_var_add_key(amxc_htable_t, cmd_priv, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, "uuid");
    amxc_ts_t start_time = {0, 0, 0};
    amxc_ts_now(&start_time);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, &start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, SM_DM_EVENT_DUSTATECHANGE_OPERATION_UNINSTALL);
    amxc_var_copy(get_expected_dustatechange(), dustatechange_data);
    cthulhu_container_command(CTHULHU_CMD_CTR_CREATE, &cmd_args, cmd_cb, cmd_priv);

    // process notify handler
    amxc_var_add_new_key_cstring_t(&data, CTHULHU_NOTIF_COMMAND_ID, get_last_cmd_id());
    amxc_var_add_new_key_cstring_t(&data, AMXM_NOTIFICATION, CTHULHU_NOTIF_CTR_REMOVED);
    amxc_var_t* dm_obj_data = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_DM_OBJ_FULL, NULL);
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_SANDBOX, "generic");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_ID, "ctr_id");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_LINKED_UUID, "uuid");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_BUNDLEVERSION, "3.14");

    // tell the handler that the completetime should be checked
    amxc_var_add_key(amxc_ts_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_COMPLETETIME, &start_time);

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&cmd_args);
    //amxc_var_clean(&cmd_priv);
    amxc_var_clean(&data);
}

void test_ctr_error(UNUSED void** state) {
    amxc_var_t cmd_args;
    amxc_var_init(&cmd_args);
    amxc_var_set_type(&cmd_args, AMXC_VAR_ID_HTABLE);

    amxc_var_t* cmd_priv;
    amxc_var_new(&cmd_priv);
    amxc_var_set_type(cmd_priv, AMXC_VAR_ID_HTABLE);

    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);

    // send container command
    amxc_var_t* dustatechange_data = amxc_var_add_key(amxc_htable_t, cmd_priv, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, "uuid");
    amxc_ts_t start_time = {0, 0, 0};
    amxc_ts_now(&start_time);
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, &start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, SM_DM_EVENT_DUSTATECHANGE_OPERATION_INSTALL);
    amxc_var_copy(get_expected_dustatechange(), dustatechange_data);
    cthulhu_container_command(CTHULHU_CMD_CTR_CREATE, &cmd_args, cmd_cb, cmd_priv);

    // process notify handler
    amxc_var_add_new_key_cstring_t(&data, CTHULHU_NOTIF_COMMAND_ID, get_last_cmd_id());
    amxc_var_add_new_key_cstring_t(&data, AMXM_NOTIFICATION, CTHULHU_NOTIF_ERROR);
    amxc_var_add_new_key_cstring_t(&data, "path", "Cthulhu.Container.");
    amxc_var_t* dm_obj_data = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_DM_OBJ_FULL, NULL);
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_SANDBOX, "generic");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_ID, "ctr_id");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_LINKED_UUID, "uuid");
    amxc_var_add_key(cstring_t, dm_obj_data, CTHULHU_CONTAINER_BUNDLEVERSION, "3.14");
    amxc_var_t* info = amxc_var_add_key(amxc_htable_t, &data, CTHULHU_NOTIF_INFORMATION, NULL);
    amxc_var_add_key(cstring_t, info, CTHULHU_CMD_COMMAND, CTHULHU_CMD_CTR_UPDATE);
    amxc_var_add_key(cstring_t, info, CTHULHU_NOTIF_REASON, "reason");
    amxc_var_add_key(uint32_t, info, CTHULHU_NOTIF_ERROR_TYPE, 999);
    amxc_var_add_key(cstring_t, info, CTHULHU_NOTIF_ERROR_TYPESTR, "999");

    amxc_var_add_key(uint32_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_FAULTCODE, 999);
    amxc_var_add_key(cstring_t, get_expected_dustatechange(), SM_DM_EVENT_DUSTATECHANGE_FAULTSTRING, "reason");

    cthulhu_notify_handler("sig", &data, NULL);

    amxc_var_clean(&cmd_args);
    amxc_var_clean(&data);
}

