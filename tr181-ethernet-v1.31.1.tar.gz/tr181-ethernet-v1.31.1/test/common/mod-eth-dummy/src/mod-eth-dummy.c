/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mod-eth-dummy.h"

char* test = NULL;
bool eee_enable_state_eth0 = false;
bool eee_enable_state_eth1 = false;
bool eee_enable_state_eth2 = false;
bool edpd_enable_state_eth0 = false;
bool edpd_enable_state_eth1 = false;

static int mac_dummy_get(UNUSED const char* function_name,
                         UNUSED amxc_var_t* args,
                         amxc_var_t* ret) {
    int rv = 0;
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, ret, "mac_address", "00:00:FA:CA:DE:00");
    return rv;
}

static int link_settings_dummy_get(UNUSED const char* function_name,
                                   UNUSED amxc_var_t* args,
                                   amxc_var_t* ret) {
    int rv = 0;
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(int32_t, ret, "current_bit_rate", 1000);
    amxc_var_add_key(cstring_t, ret, "current_duplex_mode", "Full");
    return rv;
}

static int link_eee_dummy_get(UNUSED const char* function_name,
                              amxc_var_t* args,
                              amxc_var_t* ret) {
    int rv = 0;
    const char* intf_name = GET_CHAR(args, "intf_name");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    if(strcmp(intf_name, "eth0") == 0) {
        amxc_var_add_key(bool, ret, "supported", false);
        amxc_var_add_key(bool, ret, "enabled", eee_enable_state_eth0);
        amxc_var_add_key(bool, ret, "active", false);
    } else if(strcmp(intf_name, "eth1") == 0) {
        amxc_var_add_key(bool, ret, "supported", true);
        amxc_var_add_key(bool, ret, "enabled", eee_enable_state_eth1);
        amxc_var_add_key(bool, ret, "active", false);
    } else if(strcmp(intf_name, "eth2") == 0) {
        amxc_var_add_key(bool, ret, "supported", true);
        amxc_var_add_key(bool, ret, "enabled", eee_enable_state_eth2);
        amxc_var_add_key(bool, ret, "active", true);
    } else {
        amxc_var_add_key(bool, ret, "supported", true);
        amxc_var_add_key(bool, ret, "enabled", true);
        amxc_var_add_key(bool, ret, "active", true);
    }

    return rv;
}

static int link_eee_dummy_set(UNUSED const char* function_name,
                              amxc_var_t* args,
                              UNUSED amxc_var_t* ret) {
    int rv = 0;
    const char* intf_name = GET_CHAR(args, "intf_name");

    if(strcmp(intf_name, "eth0") == 0) {
        eee_enable_state_eth0 = GET_BOOL(args, "eee_enable");
    } else if(strcmp(intf_name, "eth1") == 0) {
        eee_enable_state_eth1 = GET_BOOL(args, "eee_enable");
    } else if(strcmp(intf_name, "eth2") == 0) {
        eee_enable_state_eth2 = GET_BOOL(args, "eee_enable");
    }
    return rv;
}

static int link_edpd_dummy_get(UNUSED const char* function_name,
                               amxc_var_t* args,
                               amxc_var_t* ret) {
    int rv = 0;
    const char* intf_name = GET_CHAR(args, "intf_name");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    if(strcmp(intf_name, "eth0") == 0) {
        amxc_var_add_key(bool, ret, "supported", false);
        amxc_var_add_key(bool, ret, "enabled", edpd_enable_state_eth0);
    } else if(strcmp(intf_name, "eth1") == 0) {
        amxc_var_add_key(bool, ret, "supported", true);
        amxc_var_add_key(bool, ret, "enabled", edpd_enable_state_eth1);
    } else {
        amxc_var_add_key(bool, ret, "supported", true);
        amxc_var_add_key(bool, ret, "enabled", true);
    }

    return rv;
}

static int link_edpd_dummy_set(UNUSED const char* function_name,
                               amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {
    int rv = 0;
    const char* intf_name = GET_CHAR(args, "intf_name");

    if(strcmp(intf_name, "eth0") == 0) {
        edpd_enable_state_eth0 = GET_BOOL(args, "enable");
    } else if(strcmp(intf_name, "eth1") == 0) {
        edpd_enable_state_eth1 = GET_BOOL(args, "enable");
    }
    return rv;
}

static int dummy_func(UNUSED const char* function_name,
                      UNUSED amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    int rv = 0;
    return rv;
}


static AMXM_CONSTRUCTOR dummy_module_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    test = strdup("If stop is not called, valgrind will report this");
    (void) test;

    amxm_module_register(&mod, so, MOD_ETH_LLA_CTRL);
    amxm_module_add_function(mod, "mac-address-get", mac_dummy_get);
    amxm_module_add_function(mod, "mac-address-set", dummy_func);
    amxm_module_add_function(mod, "ethernet-enable-set", dummy_func);
    amxm_module_add_function(mod, "link-settings-get", link_settings_dummy_get);
    amxm_module_add_function(mod, "link-settings-set", dummy_func);
    amxm_module_add_function(mod, "link-eee-get", link_eee_dummy_get);
    amxm_module_add_function(mod, "link-eee-set", link_eee_dummy_set);
    amxm_module_add_function(mod, "link-edpd-get", link_edpd_dummy_get);
    amxm_module_add_function(mod, "link-edpd-set", link_edpd_dummy_set);
    amxm_module_add_function(mod, "link-disable-arp", dummy_func);
    amxm_module_add_function(mod, "system-uptime-get", dummy_func);

    return 0;
}

static AMXM_DESTRUCTOR dummy_module_stop(void) {
    free(test);
    return 0;
}
