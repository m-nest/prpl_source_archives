/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object_function.h>
#include <debug/sahtrace.h>

#include <lcm/amxc_data.h>
#include <lcm/lcm_assert.h>
#include <cthulhu/cthulhu_defines_plugin.h>
#include <cthulhu/cthulhu_defines.h>

#include "test_adaptors.h"
#include "wrappers.h"
#include "helpers.h"
#include "cthulhu_adaptors.h"

static amxd_dm_t datamodel;
static amxo_parser_t parser;

int test_sm_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&datamodel);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/timingila-fake-definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-definition.odl", root_obj), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/softwaremodules_definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-config.odl", root_obj), 0);

    return res;
}

int test_extra_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&datamodel);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/timingila-fake-definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-definition.odl", root_obj), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/test-config.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "config/test-softwaremodules-definition.odl", root_obj), 0);

    return res;
}

int test_errors_setup(UNUSED void** state) {
    int res = 0;
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&datamodel), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&datamodel);
    assert_non_null(root_obj);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/timingila-fake-definition.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "../../odl/timingila-cthulhu/timingila-cthulhu-definition.odl", root_obj), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, "config/test-config-errors.odl", root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, "config/test-softwaremodules-definition.odl", root_obj), 0);

    return res;
}

int test_teardown(UNUSED void** state) {
    amxo_parser_clean(&parser);
    amxd_dm_clean(&datamodel);

    return 0;
}

void test_command_arguments(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_init(&args);
    amxc_var_t dest;
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    // check with missing mandatory args
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 1, &datamodel, &args, &dest, "create"), amxd_status_invalid_function_argument);

    // Add all mandatory args only (for create command)
    amxc_var_clean(&dest);
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "DUID", "0f680a7a-325c-54b9-a315-15d9739490d9");
    amxc_var_add_key(cstring_t, &args, "Name", "amd64/alpine");
    amxc_var_add_key(cstring_t, &args, "Version", "3.16");
    amxc_var_add_key(cstring_t, &args, "UUID", "3952a1c9-e02e-5b06-abd2-e789dd6e08ac");
    amxc_var_add_key(cstring_t, &args, "DiskLocation", "/tmp/image_location");
    amxc_var_add_key(cstring_t, &args, "ExecutionEnvRef", "generic");

    // check with mandatory args
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 1, &datamodel, &args, &dest, "create"), amxd_status_ok);

    assert_string_equal(GET_CHAR(&dest, "ContainerId"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GET_CHAR(&dest, "Bundle"), "amd64/alpine");
    assert_string_equal(GET_CHAR(&dest, "BundleVersion"), "3.16");
    assert_string_equal(GET_CHAR(&dest, "LinkedUUID"), "3952a1c9-e02e-5b06-abd2-e789dd6e08ac");
    assert_string_equal(GET_CHAR(&dest, "DiskLocation"), "/tmp/image_location");
    assert_string_equal(GET_CHAR(&dest, "Sandbox"), "generic");


    // Add optional parameter with transformation
    amxc_var_clean(&dest);
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &args, "AutoStart", true);
    amxc_var_add_key(cstring_t, &args, "RequiredUserRoles", "role1,role2");
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 1, &datamodel, &args, &dest, "create"), amxd_status_ok);


    assert_int_equal(GET_UINT32(&dest, "Autostart"), true);
    assert_string_equal(GET_CHAR(&dest, "RequiredUserRoles"), "role1,role2");


    // Add all mandatory args only (for update command)
    amxc_var_clean(&args);
    amxc_var_init(&args);
    amxc_var_clean(&dest);
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "DUID", "0f680a7a-325c-54b9-a315-15d9739490d9");
    amxc_var_add_key(cstring_t, &args, "Name", "amd64/alpine");
    amxc_var_add_key(cstring_t, &args, "Version", "3.16");
    amxc_var_add_key(bool, &args, "RetainData", true);
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 1, &datamodel, &args, &dest, "update"), amxd_status_ok);

    assert_string_equal(GET_CHAR(&dest, "ContainerId"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GET_CHAR(&dest, "Bundle"), "amd64/alpine");
    assert_string_equal(GET_CHAR(&dest, "BundleVersion"), "3.16");
    assert_int_equal(GET_UINT32(&dest, "RemoveData"), false);

    amxc_var_clean(&args);
    amxc_var_clean(&dest);


    // Add all mandatory args only without RemoveData (for update command)
    amxc_var_clean(&args);
    amxc_var_init(&args);
    amxc_var_clean(&dest);
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "DUID", "0f680a7a-325c-54b9-a315-15d9739490d9");
    amxc_var_add_key(cstring_t, &args, "Name", "amd64/alpine");
    amxc_var_add_key(cstring_t, &args, "Version", "3.16");
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 1, &datamodel, &args, &dest, "update"), amxd_status_ok);

    assert_string_equal(GET_CHAR(&dest, "ContainerId"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GET_CHAR(&dest, "Bundle"), "amd64/alpine");
    assert_string_equal(GET_CHAR(&dest, "BundleVersion"), "3.16");
    assert_int_equal(GET_UINT32(&dest, "RemoveData"), true);

    amxc_var_clean(&args);
    amxc_var_clean(&dest);
}

void test_du_parameters_update(UNUSED void** state) {
    amxc_var_t dest;
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);

    amxc_var_t* src = filejson_to_amxc_var("config/cthulhu_ctr_notification.json");
    assert_non_null(src);
    populate_object_and_children(&datamodel, src, &dest, NULL, DU_TABLE, true);

    assert_string_equal(GET_CHAR(&dest, "Alias"), "cpe-0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GET_CHAR(&dest, "Name"), "amd64/alpine_long_long_long_long_name");
    assert_string_equal(GET_CHAR(&dest, "DUID"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GET_CHAR(&dest, "ExecutionEnvRef"), "generic");
    assert_string_equal(GET_CHAR(&dest, "LastUpdate"), "2025-10-02T00:00:00.000000000Z");
    assert_string_equal(GET_CHAR(&dest, "Installed"), "2025-10-01T00:00:00.000000000Z");
    assert_string_equal(GET_CHAR(&dest, "ModuleVersion"), "v1.0.0");
    assert_string_equal(GET_CHAR(&dest, "Status"), "Running");
    assert_string_equal(GET_CHAR(&dest, "URL"), "docker://registry-1.docker.io/amd64/alpine:3.16");
    assert_string_equal(GET_CHAR(&dest, "UUID"), "3952a1c9-e02e-5b06-abd2-e789dd6e08ac");
    assert_string_equal(GET_CHAR(&dest, "Version"), "3.16");

    amxc_var_clean(&dest);
    amxc_var_delete(&src);
}

void test_eu_parameters_update(UNUSED void** state) {
    amxc_var_t dest;
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);

    amxc_var_t* src = filejson_to_amxc_var("config/cthulhu_ctr_notification.json");
    assert_non_null(src);
    populate_object_and_children(&datamodel, src, &dest, NULL, EU_TABLE, true);

    assert_string_equal(GETP_CHAR(&dest, "Alias"), "cpe-0f680a7a-325c-54b9-a315-15d9739490d9");

    assert_int_equal(GETP_INT32(&dest, "AllocatedCPUPercent"), -1);
    assert_int_equal(GETP_INT32(&dest, "AllocatedDiskSpace"), -1);
    assert_int_equal(GETP_INT32(&dest, "AllocatedEUGID"), 0);
    assert_int_equal(GETP_INT32(&dest, "AllocatedEUUID"), 0);
    assert_int_equal(GETP_INT32(&dest, "AllocatedHostGID"), 0);
    assert_int_equal(GETP_INT32(&dest, "AllocatedHostUID"), 0);

    assert_int_equal(GETP_INT32(&dest, "AllocatedMemory"), -1);
    assert_int_equal(GETP_INT32(&dest, "AvailableMemory"), 1000);
    assert_int_equal(GET_UINT32(&dest, "AutoStart"), 1);
    assert_int_equal(GETP_UINT32(&dest, "AvailableDiskSpace"), 2000);

    assert_string_equal(GETP_CHAR(&dest, "AvailableUserRoleCapabilities"), "caps1, caps2");
    assert_string_equal(GETP_CHAR(&dest, "CreationTime"), "2025-10-01T00:00:00.000000000Z");
    assert_string_equal(GETP_CHAR(&dest, "Description"), "");
    assert_int_equal(GETP_INT32(&dest, "DiskSpaceInUse"), 3000);
    assert_string_equal(GETP_CHAR(&dest, "EUID"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GETP_CHAR(&dest, "ExecEnvLabel"), "0f680a7a-325c-54b9-a315-15d9739490d9");
    assert_string_equal(GETP_CHAR(&dest, "ExecutionEnvRef"), "generic");
    assert_int_equal(GETP_UINT32(&dest, "MemoryInUse"), 1234);
    assert_string_equal(GETP_CHAR(&dest, "Name"), "amd64/alpine_long_long_long_long");
    assert_string_equal(GETP_CHAR(&dest, "RequiredUserRoles"), "Device.Users.Roles.[Name = \"test_role\"]");
    assert_int_equal(GETP_UINT32(&dest, "RunLevel"), 0);
    assert_string_equal(GETP_CHAR(&dest, "Status"), "Running");
    assert_string_equal(GETP_CHAR(&dest, "Version"), "3.16");


    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.Enable"), 0);
    assert_string_equal(GETP_CHAR(&dest, "AutoRestart.LastRestarted"), "0001-01-01T00:00:00Z");
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.MaximumRetryCount"), 10);
    assert_string_equal(GETP_CHAR(&dest, "AutoRestart.NextRestart"), "1970-01-01T00:00:00Z");
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.ResetPeriod"), 0);
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.RetryCount"), 0);
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.RetryIntervalMultiplier"), 0);
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.RetryMaximumWaitInterval"), 0);
    assert_int_equal(GETP_UINT32(&dest, "AutoRestart.RetryMinimumWaitInterval"), 0);

    amxc_var_t* env = GETP_ARG(&dest, "EnvVariable.");
    assert_string_equal(GETP_CHAR(env, "1.Key"), "testvar");
    assert_string_equal(GETP_CHAR(env, "1.Value"), "Present");
    assert_string_equal(GETP_CHAR(env, "2.Key"), "testvar3");
    assert_string_equal(GETP_CHAR(env, "2.Value"), "Present2");


    assert_string_equal(GETP_CHAR(&dest, "HostObject.1.Destination"), "/sys/class/net/");
    assert_string_equal(GETP_CHAR(&dest, "HostObject.1.Options"), "type=mount");
    assert_string_equal(GETP_CHAR(&dest, "HostObject.1.Source"), "/sys/class/net/");

    assert_string_equal(GETP_CHAR(&dest, "NetworkConfig.DNSSDRefList"), "Path2,Path1");

    amxc_var_t* net = GETP_ARG(&dest, "NetworkConfig.PortForwarding.");
    assert_int_equal(GETP_UINT32(net, "1.ExternalPort"), 1000);
    assert_int_equal(GETP_UINT32(net, "1.InternalPort"), 1001);
    assert_string_equal(GETP_CHAR(net, "1.Interface"), "Lan");
    assert_string_equal(GETP_CHAR(net, "1.Protocol"), "TCP");

    assert_int_equal(GETP_UINT32(net, "2.ExternalPort"), 2000);
    assert_int_equal(GETP_UINT32(net, "2.InternalPort"), 2001);
    assert_string_equal(GETP_CHAR(net, "2.Interface"), "Wan");
    assert_string_equal(GETP_CHAR(net, "2.Protocol"), "UDP");

    amxc_var_clean(&dest);
    amxc_var_delete(&src);

}


void test_multilevel_parameters_update(UNUSED void** state) {
    amxc_var_t dest;
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);

    amxc_var_t* src = filejson_to_amxc_var("config/multilevel_notification.json");
    assert_non_null(src);
    populate_object_and_children(&datamodel, src, &dest, NULL, EU_TABLE, true);

    assert_string_equal(GETP_CHAR(&dest, "MyParam1"), "param_level1");
    assert_string_equal(GETP_CHAR(&dest, "MyParam2"), "param_level3");
    assert_string_equal(GETP_CHAR(&dest, "MultiList"), "multi_param1_level2_inst2,multi_param1_level2_inst1");
    assert_string_equal(GETP_CHAR(&dest, "MultiList1"), "");
    assert_string_equal(GETP_CHAR(&dest, "ParamToShorten"), "veryyyyy");

    assert_string_equal(GETP_CHAR(&dest, "SubObject.MySubObjectPram"), "param_level4");
    assert_int_equal(GETP_UINT32(&dest, "SubObject.MyBool"), 0);

    amxc_var_clean(&dest);
    amxc_var_delete(&src);
}

void test_errors_parameters_update(UNUSED void** state) {
    amxc_var_t dest;
    amxc_var_init(&dest);
    amxc_var_set_type(&dest, AMXC_VAR_ID_HTABLE);

    amxc_var_t* src = filejson_to_amxc_var("config/multilevel_notification.json");
    assert_non_null(src);

    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 2, &datamodel, src, &dest, "create"), -1);
    assert_int_equal(cthulhu_add_command_parameters((amxb_bus_ctx_t*) 3, &datamodel, src, &dest, "create"), -1);
    assert_int_equal(populate_object_and_children(&datamodel, src, &dest, NULL, EU_TABLE, true), 1);
    assert_int_equal(populate_object_and_children(NULL, NULL, NULL, NULL, NULL, true), -1);

    assert_int_equal(cthulhu_sm_overload_cmd_params(&datamodel), 0);

    amxc_var_clean(&dest);
    amxc_var_delete(&src);
}

void test_function_arguments_overload(UNUSED void** state) {

    assert_int_equal(cthulhu_sm_overload_cmd_params(&datamodel), 2);

    amxd_object_t* sm_obj = amxd_dm_findf(&datamodel, "SoftwareModules");
    amxd_object_t* du_obj = amxd_dm_findf(&datamodel, "SoftwareModules.DeploymentUnit");

    amxd_function_t* sm_func = amxd_object_get_function(sm_obj, "sm_function");
    amxd_function_t* du_func = amxd_object_get_function(du_obj, "du_function");

    assert_non_null(sm_func);
    assert_non_null(du_func);

    assert_non_null(amxd_function_get_arg(sm_func, "arg"));
    assert_non_null(amxd_function_get_arg(sm_func, "additional_uint32_arg"));

    assert_non_null(amxd_function_get_arg(du_func, "arg1"));
    assert_non_null(amxd_function_get_arg(du_func, "arg2"));
    assert_non_null(amxd_function_get_arg(du_func, "additional_string_arg"));

}
