# Network Selector Module
The network selector module is used by wan-manager to loop over different modes to detect if a mode has SFP present and select the WAN mode. If the SFP is not present, chose the first ethernet WAN mode.

 
## Loading/Unloading the Module
The constructor and destructor functions from this module should be called to make sure that the module works and that the data is clean at the end.
 

## Module Functions
This module provides the below function that can be called by the core component.

### Detect Network
This module will traversing the WAN modes provided by the core module and select the WAN mode with priority given to WAN mode which has SFP present.

## Required data
This function expects the core module to provide the list of WAN Modes.

## Core component functions
The core component using this module, should have the below module functions registered that can be called by the module.

### Set WAN Mode
The module will call this function and provide it with the WAN mode to be set. No return data is expected

