{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
%populate {
    object Firewall {
        object Chain {
            instance add(Alias=LCM, Name=LCM) {
                parameter Enable = 1;
            }
        }
        object Policy {
            instance add(Alias=Wan2LCM) {
                parameter SourceInterface = "${logical_intf_wan}";
                parameter DestinationInterface = "${ip_intf_lcm}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='LCM']";
                parameter Enable = 1;
            }
{% if (has_failover): %}
            instance add(Alias=WanCellular2LCM) {
                parameter SourceInterface = "${logical_intf_wan_cellular}";
                parameter DestinationInterface = "${ip_intf_lcm}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='LCM']";
                parameter Enable = 1;
            }
{% endif; %}
            instance add(Alias=Lan2LCM) {
                parameter SourceInterface = "${ip_intf_lan}";
                parameter DestinationInterface = "${ip_intf_lcm}";
                parameter TargetChain = "Chain";
                parameter Chain = "Firewall.Chain.[Alias=='Low']";
                parameter ReverseTargetChain = "Chain";
                parameter ReverseChain = "Firewall.Chain.[Alias=='LCM']";
                parameter Enable = 1;
            }
        }
    }
}
