/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "dbg_if.h" /* dbg_if_init() */

// System headers
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h> /* unlink() */

#include <amxc/amxc.h>
#include "libubus.h"

#include "data_model.h"   /* dm_register_transceiver_two() */
#include "dbg_commands.h" /* ADD_INSTANCE */
#include "notif.h"        /* notif_send_dm_instance_added_for_transceiver_two() */
#include "onu_hal_macros.h"
#include "onu_hal_trace.h"


#define DEBUG_SERVER "/var/run/onu_hal_dbg.sock"
#define MAX_MSG_SIZE 128

static struct uloop_fd s_uloop_fd;

typedef void (* handle_dbg_command_fn_t) (const amxc_var_t* args);

static void handle_add_instance(UNUSED const amxc_var_t* args) {
    if(dm_register_transceiver_two()) {
        return;
    }

    notif_send_dm_instance_added_for_transceiver_two();
}

static void handle_remove_instance(UNUSED const amxc_var_t* args) {
    dm_unregister_transceiver_two();
    notif_send_dm_instance_removed_for_transceiver_two();
}

static void handle_change_transceiver(UNUSED const amxc_var_t* args) {
    dm_change_transceiver_one_vendor_rev();
    notif_send_dm_object_changed_for_transceiver_one();
}

static void handle_change_onu_activation(UNUSED const amxc_var_t* args) {
    dm_change_onu_activation_onu_state();
    notif_send_dm_object_changed_for_onu_activation();
}

static void handle_omci_mib_reset(UNUSED const amxc_var_t* args) {
    notif_send_omci_reset_mib();
}


static void handle_send_change_power_mode_result(const amxc_var_t* args) {

    amxc_var_t* var;
    amxc_var_t args_new;
    amxc_var_init(&args_new);
    amxc_var_set_type(&args_new, AMXC_VAR_ID_HTABLE);

    const amxc_htable_t* const htable = amxc_var_constcast(amxc_htable_t, args);
    when_null_trace(htable, exit, ERROR, "args is not an htable");

    const char* const call_id_str = GET_CHAR(args, "call_id");
    const char* const result_str = GET_CHAR(args, "result");

    when_null_trace(call_id_str, exit, ERROR, "args does not contain key 'call_id'");
    when_null_trace(result_str, exit, ERROR, "args does not contain key 'result'");

    const uint32_t call_id = (uint32_t) atoi(call_id_str);
    const uint32_t result = (uint32_t) atoi(result_str);

    var = amxc_var_add_key(uint32_t, &args_new, "call_id", call_id);
    when_null_trace(var, exit, ERROR, "Failed to add call_id to htable");
    var = amxc_var_add_key(uint32_t, &args_new, "result", result);
    when_null_trace(var, exit, ERROR, "Failed to add result to htable");

    notif_send_change_power_mode_result(&args_new);

exit:
    amxc_var_clean(&args_new);
}

typedef struct _dbg_function {
    const char* name;
    handle_dbg_command_fn_t handler;
} dbg_function_t;

static const dbg_function_t DBG_FUNCTIONS[] = {
    { .name = ADD_INSTANCE, .handler = handle_add_instance },
    { .name = REMOVE_INSTANCE, .handler = handle_remove_instance },
    { .name = CHANGE_TRANSCEIVER, .handler = handle_change_transceiver },
    { .name = CHANGE_ONU_ACTIVATION, .handler = handle_change_onu_activation },
    { .name = OMCI_RESET_MIB, .handler = handle_omci_mib_reset  },
    { .name = SEND_CHANGE_POWER_MODE_RESULT, .handler = handle_send_change_power_mode_result }
};

/**
 * Parse the incoming message and convert it to htable with key-value pairs
 *
 * @param[in] msg: incoming debug message
 * @param[in,out] cmd: htable with key-value pairs extracted from @a msg. The
 *                     values are of tupe cstring_t.
 *
 * Example:
 * - if @a msg is 'command=send_change_power_mode_result call_id=3 result=0', the
 *   function adds 3 key-value pairs to @a cmd:
 *   - command="send_change_power_mode_result"
 *   - call_id="3"
 *   - result="0"
 */
static int parse_dbg_msg(const char* msg, amxc_var_t* cmd) {
    int rc = 1; /* error */
    amxc_string_t str;
    amxc_llist_t list;
    amxc_string_init(&str, 0);
    amxc_llist_init(&list);

    amxc_string_setf(&str, "%s", msg);
    amxc_string_split_status_t status = amxc_string_split_to_llist(&str, &list, ' ');
    when_failed_trace(status, exit, ERROR, "Failed to split");
    const char* elem;
    char* value;
    amxc_var_t* var;
    amxc_llist_for_each(it, &list) {
        elem = amxc_string_get(amxc_string_from_llist_it(it), 0);
        when_null_trace(elem, exit, ERROR, "Failed to get element from splitted string");
        const char* key = elem;
        value = strstr(elem, "=");
        when_null_trace(value, exit, ERROR, "Failed to find = sign");
        *value = '\0';
        ++value;
        SAH_TRACE_DEBUG("- %s=%s", key, value);
        var = amxc_var_add_key(cstring_t, cmd, key, value);
        when_null_trace(var, exit, ERROR, "Failed to add '%s' to htable", key);
    }
    rc = 0;

exit:
    amxc_string_clean(&str);
    amxc_llist_clean(&list, amxc_string_list_it_free);
    return rc;
}

static void dbg_if_handler(struct uloop_fd* u, UNUSED unsigned int events) {
    int rc;
    amxc_var_t cmd;
    amxc_var_init(&cmd);
    amxc_var_set_type(&cmd, AMXC_VAR_ID_HTABLE);

    when_null_trace(u, exit, ERROR, "struct uloop_fd* param is NULL");

    struct sockaddr_un cliaddr;
    socklen_t len = sizeof(cliaddr);
    char msg[MAX_MSG_SIZE];
    memset(msg, 0, MAX_MSG_SIZE);

    if(recvfrom(u->fd, msg, MAX_MSG_SIZE, 0, (struct sockaddr*) &cliaddr, &len) == -1) {
        SAH_TRACE_ERROR("Failed to read data: %s", strerror(errno));
    } else {
        SAH_TRACE_INFO("msg='%s'", msg);
    }
    rc = parse_dbg_msg(msg, &cmd);
    when_failed_trace(rc, exit, ERROR, "Failed to parse incoming debug messages");
    const char* const command = GET_CHAR(&cmd, "command");
    when_null_trace(command, exit, ERROR,
                    "Failed to extract command name from debug message");

    const size_t n_dbg_functions = ARRAY_SIZE(DBG_FUNCTIONS);
    size_t i;
    bool found = false;
    for(i = 0; i < n_dbg_functions; ++i) {
        if(strncmp(command, DBG_FUNCTIONS[i].name, strlen(DBG_FUNCTIONS[i].name)) == 0) {
            DBG_FUNCTIONS[i].handler(&cmd);
            found = true;
            break;
        }
    }

    if(!found) {
        SAH_TRACE_INFO("%s: unknown command", command);
    }

exit:
    amxc_var_clean(&cmd);
}

bool dbg_if_init(void) {
    const int fd = socket(AF_LOCAL, SOCK_DGRAM, 0);
    if(fd == -1) {
        SAH_TRACE_ERROR("Failed to open socket: %s", strerror(errno));
        return false;
    }

    unlink(DEBUG_SERVER);

    struct sockaddr_un servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sun_family = AF_LOCAL;
    strcpy(servaddr.sun_path, DEBUG_SERVER);

    if(bind(fd, (const struct sockaddr*) &servaddr, sizeof(servaddr)) == -1) {
        SAH_TRACE_ERROR("Failed to bind name to socket: %s", strerror(errno));
        goto error;
    }

    s_uloop_fd.cb = dbg_if_handler;
    s_uloop_fd.fd = fd;

    if(uloop_fd_add(&s_uloop_fd, ULOOP_READ)) {
        SAH_TRACE_ERROR("Failed to add dbg IF to uloop");
        goto error;
    }

    return true;

error:
    close(fd);
    s_uloop_fd.fd = 0;
    return false;
}

void dbg_if_cleanup(void) {
    if(s_uloop_fd.fd > 0) {
        uloop_fd_delete(&s_uloop_fd);
        close(s_uloop_fd.fd);
    }
    unlink(DEBUG_SERVER);
}

