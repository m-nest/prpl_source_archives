/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxrt/amxrt.h>
#include <netmodel/common_api.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#include "event_handler.h"
#include "tr181-gatewayinfo.h"
#include "dm_interface.h"

#define ME "gatewayinfo"

/**
 * @file event_handler.c
 * @brief Implementation of the event handler for the tr181-gatewayinfo.
 */

netmodel_query_t* option_125_subscription;
netmodel_query_t* option_17_subscription;

/**
 * Helper function to setup a DHCP option subscription
 *
 * @param type      The request type ("req" for DHCPv4, "req6" for DHCPv6)
 * @param tag       The DHCP option tag number
 * @param callback  The callback function to invoke on changes
 * @param error_msg Error message to display on failure
 *
 * @return Subscription handle on success, NULL on failure
 */
static void* setup_dhcp_option_subscription(const char* type,
                                            uint16_t tag,
                                            netmodel_callback_t callback,
                                            const char* error_msg) {
    amxc_var_t parameters;
    void* subscription = NULL;

    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "type", type);
    amxc_var_add_key(uint16_t, &parameters, "tag", tag);
    amxc_var_add_key(cstring_t, &parameters, "traverse", netmodel_traverse_down);

    subscription = netmodel_openQuery(
        GET_CHAR(amxrt_get_config(), NETMODEL_INTF),
        ME,
        "getDHCPOption",
        &parameters,
        callback,
        NULL);

    amxc_var_clean(&parameters);

    when_null_trace(subscription, exit, ERROR, "%s", error_msg);

exit:
    return subscription;
}


int setup_subscriptions(void) {

    option_125_subscription = setup_dhcp_option_subscription(
        "req",
        125,
        option_125_changed,
        "Cannot subscribe to 125 DHCPv4 option");

    if(!option_125_subscription) {
        return -1;
    }

    option_17_subscription = setup_dhcp_option_subscription(
        "req6",
        17,
        option_17_changed,
        "Cannot subscribe to 17 DHCPv6 option");

    if(!option_17_subscription) {
        return -1;
    }

    return 0;
}

static int parse_netmodel_dhcp_option_125(const amxc_var_t* option, struct DHCPGatewayInformation* dhcp_gateway_information) {

    int rc = -1;

    when_null_trace(option, exit, WARNING, "Cannot parse NULL data");

    DHCPGatewayInformation_reset(dhcp_gateway_information);

    amxc_var_for_each(var, option) {
        uint32_t code = GET_UINT32(var, "Code");
        const char* data = GET_CHAR(var, "Data");
        SAH_TRACEZ_INFO(ME, "Suboption %us: %s", code, data);
        switch(code) {
        case DHCPv4_SUBOPT_MANUFACTURER_OUI:
            amxc_string_set(&dhcp_gateway_information->DeviceManufacturerOUI, GET_CHAR(var, "Data"));
            break;
        case DHCPv4_SUBOPT_SERIAL_NUMBER:
            amxc_string_set(&dhcp_gateway_information->DeviceSerialNumber, GET_CHAR(var, "Data"));
            break;
        case DHCPv4_SUBOPT_PRODUCT_CLASS:
            amxc_string_set(&dhcp_gateway_information->DeviceProductClass, GET_CHAR(var, "Data"));
            break;
        }
    }

    rc = 0;
exit:
    return rc;
}

static int parse_netmodel_dhcp_option_17(const amxc_var_t* option, struct DHCPGatewayInformation* dhcp_gateway_information) {
    int rc = -1;

    when_null_trace(option, exit, WARNING, "Cannot parse NULL data");

    DHCPGatewayInformation_reset(dhcp_gateway_information);

    amxc_var_for_each(var, option) {
        uint32_t code = GET_UINT32(var, "Code");
        const char* data = GET_CHAR(var, "Data");
        SAH_TRACEZ_INFO(ME, "Suboption %us: %s", code, data);
        switch(code) {
        case DHCPv6_SUBOPT_MANUFACTURER_OUI:
            amxc_string_set(&dhcp_gateway_information->DeviceManufacturerOUI, GET_CHAR(var, "Data"));
            break;
        case DHCPv6_SUBOPT_SERIAL_NUMBER:
            amxc_string_set(&dhcp_gateway_information->DeviceSerialNumber, GET_CHAR(var, "Data"));
            break;
        case DHCPv6_SUBOPT_PRODUCT_CLASS:
            amxc_string_set(&dhcp_gateway_information->DeviceProductClass, GET_CHAR(var, "Data"));
            break;
        }
    }

    rc = 0;
exit:
    return rc;
}

/**
 * Middleware function to call @ref dm_update_gatewayinfo if the value of
 * gatewayinfo really changed from the last call of the
 * @ref gateway_info_update_if_changed
 *
 * @param[in] gatewayinfo the DHCP-discovered information about the gateway
 *
 * @return 0, if no error happened
 */
static int gateway_info_update_if_changed(struct DHCPGatewayInformation* gatewayinfo) {
    static struct DHCPGatewayInformation* last_used_gateayinfo = NULL;

    if(!last_used_gateayinfo) {
        last_used_gateayinfo = malloc(sizeof(struct DHCPGatewayInformation));
        DHCPGatewayInformation_init(last_used_gateayinfo);
    }
    if(DHCPGatewayInformation_equal(last_used_gateayinfo, gatewayinfo)) {
        return 0;
    }

    int rc = dm_update_gatewayinfo(gatewayinfo);
    if(rc) {
        SAH_TRACEZ_WARNING(ME, "GatewayInfo datamodel update failed");
        goto exit;
    }

    DHCPGatewayInformation_copy(gatewayinfo, last_used_gateayinfo);

exit:
    return rc;
}

/**
 * Check whether gatewayinfo is changed and call update DM handler if needed.
 *
 * @param[in] current_gatewayinfo current value of the gatewayinfo
 * @param[in] other_gatewayinfo previous value of the gatewayinfo
 *
 * @return whether update was successful
 */
static int gateway_info_changed(struct DHCPGatewayInformation* current_gatewayinfo, struct DHCPGatewayInformation* other_gatewayinfo) {
    if(amxc_string_is_empty(&current_gatewayinfo->DeviceManufacturerOUI) && amxc_string_is_empty(&current_gatewayinfo->DeviceProductClass) && amxc_string_is_empty(&current_gatewayinfo->DeviceSerialNumber)) {
        return gateway_info_update_if_changed(other_gatewayinfo);
    }
    return gateway_info_update_if_changed(current_gatewayinfo);
}

void option_125_changed(UNUSED const char* const sig_name,
                        const amxc_var_t* const data, UNUSED void* const priv) {
    DHCPGatewayInformation_reset(&app.dhcpv4_gateway);

    const amxc_var_t* option_125 = GETP_ARG(data, "0.Data");

    if(option_125 && parse_netmodel_dhcp_option_125(option_125, &app.dhcpv4_gateway)) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse DHCP option 125");
        return;
    }

    if(DHCPGatewayInformation_is_emtpy(&app.dhcpv6_gateway) && gateway_info_changed(&app.dhcpv4_gateway, &app.dhcpv6_gateway)) {
        SAH_TRACEZ_WARNING(ME, "Failed to update GatewayInfo");
    }
}

void option_17_changed(UNUSED const char* const sig_name,
                       const amxc_var_t* const data, UNUSED void* const priv) {
    DHCPGatewayInformation_reset(&app.dhcpv6_gateway);

    const amxc_var_t* option_17 = GETP_ARG(data, "0.Data");

    if(option_17 && parse_netmodel_dhcp_option_17(option_17, &app.dhcpv6_gateway)) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse DHCP option 17");
        return;
    }

    if(gateway_info_changed(&app.dhcpv6_gateway, &app.dhcpv4_gateway)) {
        SAH_TRACEZ_WARNING(ME, "Failed to update GatewayInfo");
    }
}
