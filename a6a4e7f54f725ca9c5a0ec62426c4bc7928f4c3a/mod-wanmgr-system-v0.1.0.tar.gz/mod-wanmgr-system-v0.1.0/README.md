# WAN Manager System Module
This module handles system level changes  and mostly is dependent on vendor requirement
- Based on the WAN change, update L1 configuration changes on driver
- Do device reboot where required

## Loading/Unloading the Module
The constructor and destructor functions from this module should be called to make sure that the module works and that the data is clean at the end.

## Module Functions
This module provides the below function that can be called by the core component.

### request-system-update
This module will receive the request to update L1 configuration changes to the system. The module is vendor specific and required configuration changes can be done to the system

## Required data
This function expects the core module to provide the data required to do the L1 configurations in the system
