#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "test_validate_auth.h"

#include "device.h"
#include "mod_usb_filter.h"
#include "filter_dm.h"
#include "helpers.h"
#include "device_list.h"

static void assert_authorized(usb_device_t* device, bool authorized) {
    amxc_var_t value;

    amxc_var_init(&value);

    assert_non_null(device);
    assert_int_equal(device->authorized, authorized ? 1 : 2);
    assert_non_null(device->object);

    amxd_object_get_param(device->object, "IsAllowed", &value);
    assert_int_equal(amxc_var_constcast(bool, &value), authorized);

    amxc_var_clean(&value);
}

static void add_usb_device(const char* sysfs_id, const char* device_class) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", device_class);
    amxd_trans_set_value(cstring_t, &trans, "DeviceProtocol", "00");
    amxd_trans_set_value(cstring_t, &trans, "DeviceSubClass", "00");
    amxd_trans_set_value(uint32_t, &trans, "ProductID", 2049);
    amxd_trans_set_value(uint32_t, &trans, "VendorID", 11388);
    amxd_trans_set_value(cstring_t, &trans, "SysfsId", sysfs_id);
    amxd_trans_select_pathf(&trans, ".Configuration.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_select_pathf(&trans, ".Interface.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceClass", "ff");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceNumber", "0");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceProtocol", "30");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceSubClass", "ff");
    amxd_trans_select_pathf(&trans, ".^.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceClass", "00");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceNumber", "1");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceProtocol", "20");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceSubClass", "00");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

static void change_usb_device(const char* alias, const char* device_class) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.[SysfsId == '%s'].", alias);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", device_class);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

static void add_allowed_usb_device(const char* alias, const char* device_class) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.");
    amxd_trans_add_inst(&trans, 0, alias);
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", device_class);
    amxd_trans_set_value(cstring_t, &trans, "DeviceProtocol", "*");
    amxd_trans_set_value(cstring_t, &trans, "DeviceSubClass", "00");
    amxd_trans_set_value(cstring_t, &trans, "ProductID", "801");
    amxd_trans_set_value(cstring_t, &trans, "VendorID", "2C7C");
    amxd_trans_set_value(cstring_t, &trans, "Interfaces", "*:*:*0");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

static void change_allowed_device(const char* alias, const char* device_class, bool enable) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.%s.", alias);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", device_class);
    amxd_trans_set_value(bool, &trans, "Enable", enable);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

static void remove_allowed_device(const char* alias) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.");
    amxd_trans_del_inst(&trans, 0, alias);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

int test_setup(void** state) {
    amxd_object_t* root = NULL;
    amxd_trans_t trans;

    amxut_bus_setup(state);

    amxd_trans_init(&trans);

    root = amxd_dm_get_root(amxut_bus_dm());
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_filter_enable_changed", AMXO_FUNC(_usb_filter_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_added", AMXO_FUNC(_usb_device_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_changed", AMXO_FUNC(_usb_device_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_removed", AMXO_FUNC(_usb_device_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_added", AMXO_FUNC(_usb_device_interface_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_changed", AMXO_FUNC(_usb_device_interface_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_removed", AMXO_FUNC(_usb_device_interface_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_added", AMXO_FUNC(_usb_allowed_device_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_changed", AMXO_FUNC(_usb_allowed_device_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_removed", AMXO_FUNC(_usb_allowed_device_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "filter_app_start", AMXO_FUNC(_filter_app_start)), 0);

    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../../odl/tr181-usb_definition.odl", root), 0);
    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../odl/mod-usb-filter_definition.odl", root), 0);
    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../../odl/defaults.d/00_tr181-usb_default.odl", root), 0);
    assert_int_equal(amxo_resolver_import_open(amxut_bus_parser(), "/usr/lib/amx/modules/mod-dmext.so", "mod-dmext", 0), 0);

    assert_int_equal(_filter_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    // Not emitting app:start event here so AllowAllDevices is not set!

    amxut_bus_handle_events();

    // Add first host
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.");
    amxd_trans_add_inst(&trans, 0, "usb-Host-1");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_filter_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);

    return 0;
}

void test_allow_new_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    add_allowed_usb_device("allowed_1", "*0");
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);
    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, true);
}

void test_block_new_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);
    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);
}

void test_allow_all_devices(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.");
    amxd_trans_set_value(bool, &trans, "AllowAllDevices", false);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);
    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.");
    amxd_trans_set_value(bool, &trans, "AllowAllDevices", true);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_authorized(usb_device_entry->device, true);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.");
    amxd_trans_set_value(bool, &trans, "AllowAllDevices", false);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_authorized(usb_device_entry->device, false);
}

void test_allow_blocked_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;
    add_allowed_usb_device("allowed_1", "B0");
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);
    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);

    change_allowed_device("allowed_1", "*0", true);
    assert_authorized(usb_device_entry->device, true);
}

void test_block_changed_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;
    add_allowed_usb_device("allowed_1", "*0");
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);
    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, true);

    change_usb_device("2-1.4", "55");
    assert_authorized(usb_device_entry->device, false);
}

void test_allow_existing_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    add_usb_device("2-1.4", "00");
    assert_int_equal(usb_device_list_size(DEVICE), 1);
    add_allowed_usb_device("allowed_1", "*0");
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, true);
}

void test_block_existing_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    add_allowed_usb_device("allowed_1", "*0");
    add_usb_device("2-1.4", "00");
    change_allowed_device("allowed_1", "A0", true);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);
}

void test_block_existing_device_after_emptying_allowed_devices(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    add_usb_device("2-1.4", "00");
    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);

    add_allowed_usb_device("allowed_1", "*0");
    assert_authorized(usb_device_entry->device, true);

    remove_allowed_device("allowed_1");
    assert_authorized(usb_device_entry->device, false);
}

void test_block_device_after_disable_allowed_device(UNUSED void** state) {
    usb_device_list_entry_t* usb_device_entry = NULL;

    add_usb_device("2-1.4", "00");
    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_authorized(usb_device_entry->device, false);

    add_allowed_usb_device("allowed_1", "*0");
    assert_authorized(usb_device_entry->device, true);

    change_allowed_device("allowed_1", "*0", false);
    assert_authorized(usb_device_entry->device, false);
}
