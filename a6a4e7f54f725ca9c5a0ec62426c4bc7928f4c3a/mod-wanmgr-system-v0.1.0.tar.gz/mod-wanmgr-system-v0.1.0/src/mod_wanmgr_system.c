/**
 * @file mod_wanmgr_system.c
 *
 * @brief This file contains implementation of mod wanmgr system functionalities.
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_action.h>
#include "mod_wanmgr_system.h"

#include <amxb/amxb.h>
#include <amxb/amxb_be_mngr.h>
#include <amxb/amxb_register.h>
#include <amxb/amxb_connect.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#define ME                      "mod-wmmsys-sys"
#define MOD_WANMGR_SYSTEM_CTRL  "mod-wmmsys-ctrl"
/**
 * @brief           request_system_update
 *
 * @param[in]       args, variant containing the wan modes in hash table.
 *                  args cannot be null.
 *
 * @return          NO_ERROR, if system configuration is done successfully.
 *                  ERROR, if system configuration is not done successfully.
 *
 */
static int request_system_update(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {

    amxd_status_t rv = amxd_status_unknown_error;
    when_null_trace(args, exit, ERROR, "args is NULL");
    amxb_bus_ctx_t* bus_ctx = NULL;
    amxc_var_t data;
    amxc_var_t ret1;

    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&ret1);

    /* Any Custom functions can be added here for future use */

    bus_ctx = amxb_be_who_has("Device.");
    when_null_trace(bus_ctx, exit, ERROR, "Failed to get the context bus.");

    amxc_var_add_key(cstring_t, &data, "Cause", "LocalReboot");
    amxc_var_add_key(cstring_t, &data, "Reason", "WanModeMGR");
    SAH_TRACEZ_ERROR(ME, "Calling device.reboot from WMM");
    rv = amxb_call(bus_ctx, "Device.", "Reboot", &data, &ret1, 5);
    when_failed_trace(rv, exit, ERROR, "Failed to call Device.Reboot(): %d", rv);

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret1);
    return rv;
}

/**
 * @brief Start and register functions for the mod-wanmgr-system module.
 *
 * @return AMXM_CONSTRUCTOR always return 0.
 *
 */
static AMXM_CONSTRUCTOR mod_wanmgr_system_start(void) {
    SAH_TRACEZ_INFO(ME, "mod-wanmgr-system start.");
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_WANMGR_SYSTEM_CTRL);
    amxm_module_add_function(mod, "request-system-update", request_system_update);
    return 0;
}

/**
 * @brief Stop and clean the mod-wanmgr-system module.
 *
 * @return AMXM_DESTRUCTOR always return 0.
 */
static AMXM_DESTRUCTOR mod_wanmgr_system_stop(void) {
    SAH_TRACEZ_INFO(ME, "mod-wanmgr-system stop.");
    return 0;

}
