/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "tr181-cpu.h"
#include "cpu_utils.h"
#include "cpu_dm_utils.h"

#define ME "cpu-main"

/**
   @ingroup  CPU Plugin
   @defgroup cpu_main
 */

/**
   @ingroup  cpu_main
   Application context structure.

   Stores the data model and parser references for the entire application lifetime.
   This allows other modules to access the data model and configuration without
   passing these references around constantly.
 */
typedef struct {
    amxd_dm_t* dm;              // The Ambiorix data model instance
    amxo_parser_t* parser;      // The ODL parser containing configuration
} app_t;

static app_t app;

/**
   @ingroup  cpu_main
   Returns the application's data model instance.

   This accessor function is used by other modules to obtain the data model
   so they can query or modify data model objects and parameters.

   @return Pointer to the data model, or NULL if not initialized
 */
amxd_dm_t* cpu_get_dm(void) {
    SAH_TRACEZ_IN(ME);
    return app.dm;
    SAH_TRACEZ_OUT(ME);
}

/**
   @ingroup  cpu_main
   Retrieves a data model object by its path.

   This is a convenience function that wraps the Ambiorix data model lookup.
   Used to find specific objects in the data model tree (e.g., "CPUs.CPU.1.DVFS").

   @param path The data model path to search for
   @return Pointer to the object if found, NULL otherwise
 */
amxd_object_t* cpu_get_object(const char* path) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(app.dm, "%s", path);
exit:
    SAH_TRACEZ_OUT(ME);
    return object;
}

/**
   @ingroup  cpu_main
   Retrieves a configuration option from the ODL config section.

   Configuration options defined in the %config section of the ODL file
   can be accessed through this function. This is used to get values like
   DVFS_PATH, storage-path, trace levels, etc.

   @param option_path The path to the configuration option (e.g., "DVFS_PATH")
   @return Pointer to the variant containing the value, or NULL if not found
 */
amxc_var_t* cpu_get_config(const char* option_path) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t* option = NULL;

    if(app.parser != NULL) {
        option = GET_ARG(&app.parser->config, option_path);
    }
    SAH_TRACEZ_OUT(ME);
    return option;
}

/**
   @ingroup  cpu_main
   Initializes the application on startup.

   This function is called when the plugin is loaded. It stores references
   to the data model and parser, then saves the current system DVFS settings.
   Saving defaults is critical so we can restore the system to its original
   state when the application stops.

   @param dm The Ambiorix data model instance
   @param parser The ODL parser containing configuration
 */
static void init(amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "TR181-cpu plugin : loaded");
    app.dm = dm;
    app.parser = parser;
    // Save current system DVFS settings before we make any changes
    cpu_get_default_dvfs_values();
    SAH_TRACEZ_OUT(ME);
}

/**
   @ingroup  cpu_main
   Cleans up the application on shutdown.

   This function restores all CPUs to their original DVFS settings that were
   saved during initialization. This ensures we don't leave the system in a
   modified state. After restoration, it frees the saved defaults and clears
   internal references.
 */
static void cleanup(void) {
    SAH_TRACEZ_IN(ME);
    // Restore original DVFS settings to all CPUs
    cpu_reset_dvfs_defaults();
    // Free the saved default values
    cpu_clean_dvfs_defaults();
    app.dm = NULL;
    app.parser = NULL;
    SAH_TRACEZ_INFO(ME, "TR181-cpu plugin : stopping");
    SAH_TRACEZ_OUT(ME);
}

/**
   @ingroup  cpu_main
   Plugin entry point called by the Ambiorix framework.

   This is the main lifecycle function that the Ambiorix ODL parser calls
   when loading (AMXO_START) or unloading (AMXO_STOP) the plugin. It delegates
   to init() and cleanup() functions accordingly.

   @param reason The reason for the call (AMXO_START or AMXO_STOP)
   @param dm The Ambiorix data model instance
   @param parser The ODL parser containing configuration
   @return 0 on success, non-zero on error
 */
int _cpu_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    int retval = 0;

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "Starting tr181-cpu plugin");
        init(dm, parser);
        break;
    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "Stopping tr181-cpu plugin");
        cleanup();
        break;
    }
    SAH_TRACEZ_OUT(ME);
    return retval;
}
