/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"

#define ME "configuration"

static char device_name[MAX_ID_SIZE];

/**
 * @brief Create a new instance in USB.USBHosts.Host.*.Device.*.Configuration.
 *
 * @param trans Transaction used to create the configuration.
 * @param sysfs_id The filesystem device id.
 * @param id A unique key to identify the configuration.
 * @param nb_interfaces Number of interfaces in the configuration.
 * @return A pointer to the created object on success, null on failure.
 */
int configuration_create_object(amxd_trans_t* trans, const char* sysfs_id, const char* id, int nb_interfaces) {
    int rv = -1;
    if((sysfs_id == NULL) || (id == NULL)) {
        return rv;                               // Add null check
    }

    SAH_TRACEZ_NOTICE(ME, "Create Configuration %s... nb_interfaces: %d", id, nb_interfaces);
    amxd_trans_select_pathf(trans, ".Configuration.");
    amxd_trans_add_inst(trans, 0, NULL);
    uint32_t configuration_number = strtol(id, (char**) NULL, 10);
    amxd_trans_set_value(uint32_t, trans, "ConfigurationNumber", configuration_number);

    // Create interfaces

    strlcpy(device_name, sysfs_id, sizeof(device_name));
    char interface_id[80];
    amxd_trans_select_pathf(trans, ".Interface.");
    for(int i = 0; i < nb_interfaces; i++) {
        snprintf(interface_id, sizeof(interface_id), "%s.%d", id, i);
        if(strlen(interface_id) < MAX_ID_SIZE) {
            rv = interface_create_object(trans, interface_id);
            amxd_trans_select_pathf(trans, ".^"); // After adding the Interface instance we have to go back to Interface path
        } else {
            SAH_TRACEZ_ERROR(ME, "Interface ID too long: %zu", strlen(interface_id));
        }
    }
    rv = 0;
    return rv;
}

/**
 * @brief Create a new instance in USB.USBHosts.Host.*.Device.*.Configuration.*.Interface.
 *
 * @param trans Transaction used to create the interface.
 * @param id A unique key to identify the interface.
 * @return A pointer to the created object on success, null on failure.
 */
int interface_create_object(amxd_trans_t* trans, const char* id) {
    int rv = -1;
    when_null(trans, exit);
    when_null(id, exit);

    SAH_TRACEZ_NOTICE(ME, "Create Interface %s...", id);
    amxd_trans_add_inst(trans, 0, NULL);
    amxd_trans_set_value(uint32_t, trans, "InterfaceNumber", 0);

    // Set parameters
    rv = interface_set_info(trans, id);

exit:
    return rv;
}

/**
 * @brief Set the interface id.
 *
 * @param trans Transaction used to update the interface.
 * @param id Id to be set.
 * @return True on success, false on failure.
 */
int interface_set_info(amxd_trans_t* trans, const char* id) {
    int rv = -1;
    struct sysfs_device* device = NULL;
    struct dlist* attrlist;

    char interface_name[MAX_ID_SIZE];
    char tmp[128];
    uint32_t interface_number = 0;
    char interface_class[4];
    char interface_subclass[4];
    char interface_protocol[4];

    when_null(trans, exit);
    when_null(id, exit);

    SAH_TRACEZ_NOTICE(ME, "Get Interface %s information from sysfs", id);

    snprintf(tmp, sizeof(tmp), "%s:%s", device_name, id);
    if(strlen(tmp) >= MAX_ID_SIZE) {
        SAH_TRACEZ_ERROR(ME, "Interface ID too long: %zu", strlen(tmp));
        return ERR_ID_TOO_LONG;
    }

    strlcpy(interface_name, tmp, sizeof(interface_name));

    // Find the device
    device = sysfs_open_device("usb", interface_name);

    // Get device info list
    attrlist = sysfs_get_device_attributes(device);

    // Navigate the list
    if(attrlist != NULL) {
        struct sysfs_attribute* attr;
        dlist_for_each_data(attrlist, attr, struct sysfs_attribute) {
            if(strncmp(attr->name, "bInterfaceNumber", sizeof("bInterfaceNumber") - 1) == 0) {
                strlcpy(tmp, trim_str(attr->value), sizeof(tmp) - 1);
                interface_number = strtoul((const char*) tmp, (char**) NULL, 10);
            } else if(strncmp(attr->name, "bInterfaceClass", sizeof("bInterfaceClass") - 1) == 0) {
                strlcpy(interface_class, trim_str(attr->value), sizeof(interface_class) - 1);
            } else if(strncmp(attr->name, "bInterfaceSubClass", sizeof("bInterfaceSubClass") - 1) == 0) {
                strlcpy(interface_subclass, trim_str(attr->value), sizeof(interface_subclass) - 1);
            } else if(strncmp(attr->name, "bInterfaceProtocol", sizeof("bInterfaceProtocol") - 1) == 0) {
                strlcpy(interface_protocol, trim_str(attr->value), sizeof(interface_protocol) - 1);
            }
        }
    }

    sysfs_close_device(device);

    amxd_trans_set_value(uint32_t, trans, "InterfaceNumber", interface_number);
    amxd_trans_set_value(cstring_t, trans, "InterfaceClass", interface_class);
    amxd_trans_set_value(cstring_t, trans, "InterfaceSubClass", interface_subclass);
    amxd_trans_set_value(cstring_t, trans, "InterfaceProtocol", interface_protocol);
    rv = 0;

exit:
    return rv;
}
