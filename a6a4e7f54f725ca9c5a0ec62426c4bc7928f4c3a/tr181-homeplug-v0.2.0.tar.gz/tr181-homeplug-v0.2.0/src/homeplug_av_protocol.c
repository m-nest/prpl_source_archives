/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

#include "homeplug.h"
#include "dm_homeplug.h"
#include "homeplug_av_protocol.h"

#define bswap16(x) (uint16_t) ((((uint16_t) (x) & 0x00ffu) << 8) | (((uint16_t) (x) & 0xff00u) >> 8))

static const unsigned char atheros_oui[3] = { 0x00, 0xb0, 0x52 };

/**
   @brief Extracts the least significant byte (LSB) of a HomePlug AV message type.

   Given a 16-bit message type, this function returns the lower 8 bits (LSB).

   @param mm_type The 16-bit message type.

   @return The extracted least significant byte.
 */
static inline uint8_t av_message_lsb_mm_type(uint16_t mm_type) {
    return (mm_type & 0x00FF);
}

/**
   @brief Extracts the most significant byte (MSB) of a HomePlug AV message type.

   Given a 16-bit message type, this function returns the upper 8 bits (MSB).

   @param mm_type The 16-bit message type.

   @return The extracted most significant byte.
 */
static inline uint16_t av_message_msb_mm_type(uint16_t mm_type) {
    return (mm_type >> 8);
}

/**
   @brief Combines the MSB and LSB of a HomePlug AV message header to get the full
          message type.

   This function reconstructs the 16-bit message type from the
   @c mm_type_MSB and @c mm_type_LSB fields of the message header.

   @param hdr Pointer to the HomePlug AV message header.

   @return The reconstructed 16-bit message type.
 */
static inline uint16_t av_message_mm_type(homeplug_av_hdr_t* hdr) {
    return hdr->mm_type_MSB << 8 | hdr->mm_type_LSB;
}

/**
   @brief Extracts the lower 2 bits of a HomePlug AV message type.

   The lower 2 bits of the mm_type field represent the specific
   message type in the HomePlug AV protocol.

   @param mm_type The 16-bit message type field from a HomePlug AV header.

   @return The extracted lower 2 bits.
 */
static inline uint16_t av_message_message_type(uint16_t mm_type) {
    return (mm_type & 0x0003);
}

/**
   @brief Extracts the HomePlug AV message type field from mm_type.

   This function masks out the irrelevant bits and keeps the bits
   representing the message type in the HomePlug AV protocol.

   @param mm_type 16-bit mm_type field from a HomePlug AV header.

   @return The extracted message type value (bits 2 to 12 of mm_type).
 */
static inline uint16_t av_message_type(uint16_t mm_type) {
    return (mm_type & 0x1FFC);
}

/**
   @brief Extracts the HomePlug AV message category from mm_type.

   The category is represented by the top 3 bits (bits 13–15) of the 16-bit
   mm_type field in a HomePlug AV header.

   @param mm_type 16-bit mm_type field from a HomePlug AV header.

   @return The extracted category bits, masked to the top 3 bits.
 */
static inline uint16_t av_message_category(uint16_t mm_type) {
    return (mm_type & 0xE000);
}

/**
   @brief Calculates the effective payload size for a HomePlug AV frame.

   Ensures that the frame meets the minimum frame size requirement
   (60 bytes excluding the header). If the given message size plus
   the header is less than 60 bytes, the payload is padded accordingly.

   @param messagesize Size of the message payload in bytes (excluding header).

   @return Size of the message payload after accounting for minimum frame size.
 */
static inline size_t av_message_size(size_t messagesize) {
    size_t total = messagesize + ETHER_HDR_LEN;
    SAH_TRACEZ_INFO(ME, "Message size = %zd", ((total > 60) ? total - ETHER_HDR_LEN : (60 - ETHER_HDR_LEN)));
    return ((total > 60) ? total - ETHER_HDR_LEN : (60 - ETHER_HDR_LEN));
}

/**
   @brief Decodes the MMType field of a HomePlug AV header and logs its components.

   This function extracts the following components from the 16-bit MMType field:
     - Category (bits 15:13)
     - Type (bits 12:2)
     - msgType (bits 1:0)

   @param hdr Pointer to the HomePlug AV message header.
 */
static void av_message_decode_mm_type(homeplug_av_hdr_t* hdr) {
    uint16_t mm_type = av_message_mm_type(hdr);
    uint16_t category = av_message_category(mm_type);
    uint16_t type = av_message_type(mm_type);
    uint16_t msgtype = av_message_message_type(mm_type);
    (void) mm_type; // when trace level is set low, the lines below are not compiled in
    (void) category;
    (void) type;
    (void) msgtype;
    SAH_TRACEZ_INFO(ME, "mm_type = 0x%x", mm_type);
    SAH_TRACEZ_INFO(ME, "    Category = 0x%x", category);
    SAH_TRACEZ_INFO(ME, "    Type     = 0x%x", type);
    SAH_TRACEZ_INFO(ME, "    msgType  = 0x%x", msgtype);
}

/**
   @brief Dumps the fields of a HomePlug AV message header.

   Logs the contents of a received MME frame including:
     - Major message version (mmv)
     - Message type (mmType)
     - Number of fragments
     - Fragment number
     - Sequence number

   @param hdr Pointer to the HomePlug AV message header.
 */
static void av_dump(UNUSED homeplug_av_hdr_t* hdr) {
    SAH_TRACEZ_INFO(ME, "Received mme frame");
    SAH_TRACEZ_INFO(ME, "    mmv..............: %d", hdr->mmv);
    SAH_TRACEZ_INFO(ME, "    mmType...........: 0X%x", av_message_mm_type(hdr));
    SAH_TRACEZ_INFO(ME, "    Nr of Fragments .: %d", hdr->fmi_fn);
    SAH_TRACEZ_INFO(ME, "    Fragement Nr    .: %d", hdr->fmi_nf);
    SAH_TRACEZ_INFO(ME, "    Sequence Number .: %d", hdr->fmsn);
}

/**
   @brief Converts a 6-byte MAC address into a human-readable string.

   Formats the given MAC address into the form "XX:XX:XX:XX:XX:XX".

   @param addr Input array containing the 6-byte MAC address.
   @param mac  Output buffer.
 */
static void convert_mac(const uint8_t addr[6], uint8_t mac[18]) {
    snprintf((char*) mac, 18, "%2.2X:%2.2X:%2.2X:%2.2X:%2.2X:%2.2X", addr[0], addr[1], addr[2],
             addr[3], addr[4], addr[5]);
}

/**
   @brief Generates a device name string based on a MAC address.

   Converts a 6-byte MAC address into a string of the form:
   "device_XX_XX_XX_XX_XX_XX".

   @param addr Input array containing the 6-byte MAC address.
   @param mac  Output buffer.
 */
static void convert_devicename_mac(const uint8_t addr[6], uint8_t mac[25]) {
    snprintf((char*) mac, 25, "device_%2.2X_%2.2X_%2.2X_%2.2X_%2.2X_%2.2X", addr[0], addr[1], addr[2],
             addr[3], addr[4], addr[5]);
}

/**
   @brief Checks if a vendor-specific header matches a given OUI.

   Compares the 3-byte Organizationally Unique Identifier (OUI) stored in
   the vendor-specific header with the provided OUI.

   @param vendorhdr Pointer to the vendor-specific header structure.
   @param oui       3-byte array containing the expected OUI.

   @return - true if the OUIs match.
           - false otherwise.
 */
static bool isOUI(vendor_specific_hdr_t* vendorhdr, const uint8_t oui[3]) {
    if(memcmp(vendorhdr->vendorOUI, oui, 3) == 0) {
        return true;
    } else {
        return false;
    }
}

/**
   @brief Handles a CM_BRG_INFO_CNF message from a HomePlug device.

   This function processes a CM_BRG_INFO_CNF confirmation message, extracts
   bridge and end-station MAC addresses, and updates the device management
   database accordingly.

   @param sock       Pointer to the HomePlug socket through which the message was received.
   @param sll_addr   8-byte source link-layer address of the HomePlug device.
   @param hdr        Pointer to the CM_BRG_INFO_CNF message header.
   @param frame_size Size of the received frame (Unused).
 */
static void handle_cm_brg_info_cnf(homeplug_socket_t* sock, const uint8_t sll_addr[8], uint8_t* hdr, UNUSED ssize_t frame_size) {
    uint8_t homeplug_mac[18] = "";
    uint8_t device_mac[18] = "";
    uint8_t device_name_homeplug_mac[25] = "";
    int i = 0;
    cm_brg_info_cnf_t* msg = (cm_brg_info_cnf_t*) hdr;
    amxc_var_t device_params;
    amxc_string_t bridgedmacs;

    amxc_var_init(&device_params);
    amxc_var_set_type(&device_params, AMXC_VAR_ID_HTABLE);

    convert_devicename_mac(sll_addr, device_name_homeplug_mac);
    convert_mac(sll_addr, homeplug_mac);

    homeplug_interface_add_activedevice(sock->interface, device_name_homeplug_mac);

    SAH_TRACEZ_INFO(ME, ">");
    SAH_TRACEZ_INFO(ME, "CM_BRG_INFO_CNF");
    SAH_TRACEZ_INFO(ME, "    received from %s", homeplug_mac);
    SAH_TRACEZ_INFO(ME, "    bsd  = %d", msg->bsd);
    SAH_TRACEZ_INFO(ME, "    btei = %d", msg->btei);
    SAH_TRACEZ_INFO(ME, "    nbda = %d", msg->nbda);
    SAH_TRACEZ_INFO(ME, "<");

    amxc_var_add_key(cstring_t, &device_params, "MACAddress", (char*) homeplug_mac);

    amxc_string_init(&bridgedmacs, 0);
    for(i = 0; i < msg->nbda; i++) {
        convert_mac(msg->bda[i], device_mac);
        if(i == (msg->nbda - 1)) {
            amxc_string_appendf(&bridgedmacs, "%s", device_mac);
        } else {
            amxc_string_appendf(&bridgedmacs, "%s, ", device_mac);
        }
        SAH_TRACEZ_INFO(ME, "bda %s", device_mac);
    }
    amxc_var_add_key(csv_string_t, &device_params, "EndStationMACs",
                     amxc_string_get(&bridgedmacs, 0));

    dm_interface_add_or_update_device(sock->interface->interface_obj,
                                      device_name_homeplug_mac,
                                      &device_params);
    amxc_var_clean(&device_params);
    amxc_string_clean(&bridgedmacs);

    homeplug_socket_send_associated_devices_request(sock, sll_addr);

    return;
}

/**
   @brief Handles a CM_NW_STATS_CNF message from a HomePlug device.

   This function parses a CM_NW_STATS_CNF confirmation message containing
   network statistics about associated stations (STAs). It validates the frame
   size, checks that the number of stations does not exceed the maximum allowed,
   and logs per-station PHY data rates (TX and RX).

   @param sock       Pointer to the HomePlug socket through which the message
                     was received (Unused).
   @param sll_addr   8-byte source link-layer address of the HomePlug device.
   @param hdr        Pointer to the CM_NW_STATS_CNF message header.
   @param frame_size Total size of the received frame.
 */
static void handle_cm_nw_stats_cnf(UNUSED homeplug_socket_t* sock, const uint8_t sll_addr[8], uint8_t* hdr, ssize_t frame_size) {
    int i = 0;
    uint8_t homeplug_mac[18] = "";
    uint8_t device_mac[18] = "";
    cm_nw_stats_cnf_t* msg = (cm_nw_stats_cnf_t*) hdr;
    ssize_t maxSTA = 0;

    convert_mac(sll_addr, homeplug_mac);

    SAH_TRACEZ_INFO(ME, ">");
    SAH_TRACEZ_INFO(ME, "CM_NW_STATS_CNF");
    SAH_TRACEZ_INFO(ME, "    received from %s", homeplug_mac);
    SAH_TRACEZ_INFO(ME, "    numSTA  = %d", msg->numSTA);

    when_false_trace(!((frame_size - sizeof(cm_nw_stats_cnf_t)) % sizeof(cm_nw_stats_cnf_data_t)),
                     exit, ERROR, "Wrong frame size");

    maxSTA = (FRAME_SIZE_MAX - sizeof(cm_nw_stats_cnf_t)) / sizeof(cm_nw_stats_cnf_data_t);
    if(msg->numSTA > maxSTA) {
        SAH_TRACEZ_ERROR(ME, "Wrong value of numSTA > MAX_STA_NR [%d < %zd]", msg->numSTA, maxSTA);
    }

    for(i = 0; i < msg->numSTA; i++) {
        convert_mac(msg->data[i].DA, device_mac);
        SAH_TRACEZ_INFO(ME, "    DA[%d]          = %s", i, device_mac);
        SAH_TRACEZ_INFO(ME, "    avgPHYDR_TX[%d] = %d Mb/s", i, msg->data[i].avgPHYDR_TX);
        SAH_TRACEZ_INFO(ME, "    avgPHYDR_RX[%d] = %d Mb/s", i, msg->data[i].avgPHYDR_RX);
    }
exit:
    return;
}

/* atheros: vs_nw_info_cnf introduces concept of multiple avlns the atheros homeplug can belong */

/**
   @brief Handles a VS_NW_INFO_CNF message from a HomePlug device.

   This function parses a Vendor-Specific Network Info confirmation message.
   It extracts information about all available AVLNs (networks) and their
   associated stations (STAs), validates the received frame structure, and
   updates the data model with device and link statistics.

   Each STA entry includes its MAC address, average TX PHY rate, and
   average RX PHY rate. The function ensures no buffer overreads occur by
   checking that the number of AVLNs and STAs fit in the received frame.

   @param sock       Pointer to the HomePlug socket through which the message
                     was received (Unused).
   @param sll_addr   8-byte source link-layer address of the HomePlug device.
   @param hdr        Pointer to the VS_NW_INFO_CNF message header.
   @param frame_size Total size of the received frame.
 */
static void handle_vs_nw_info_cnf(UNUSED homeplug_socket_t* sock, const uint8_t sll_addr[8], uint8_t* hdr, ssize_t frame_size) {
    uint8_t homeplug_mac[18] = "";
    uint8_t device_name_homeplug_mac[25] = "";
    uint8_t device_mac[18] = "";
    uint8_t device_name_device_mac[25] = "";
    network_data_t* network = NULL;
    sta_data_t* station = NULL;
    int i, j;
    vs_nw_info_cnf_t* msg = (vs_nw_info_cnf_t*) hdr;
    amxc_var_t associated_devices;
    amxc_var_t* associated_device = NULL;

    amxc_var_init(&associated_devices);
    amxc_var_set_type(&associated_devices, AMXC_VAR_ID_HTABLE);

    convert_mac(sll_addr, homeplug_mac);
    convert_devicename_mac(sll_addr, device_name_homeplug_mac);

    SAH_TRACEZ_INFO(ME, ">");
    SAH_TRACEZ_INFO(ME, "VS_NW_INFO_CNF");
    SAH_TRACEZ_INFO(ME, "    received from %s", homeplug_mac);
    SAH_TRACEZ_INFO(ME, "    numAvlns  = %d", msg->numAvlns);

    ssize_t size = frame_size - sizeof(vs_nw_info_cnf_t);
    ssize_t maxAvlns = (FRAME_SIZE_MAX - sizeof(vs_nw_info_cnf_t)) / sizeof(network_data_t);

    when_false_trace((msg->numAvlns <= maxAvlns), exit, ERROR,
                     "Bad Value of numAvlns  > maxAvlns (%zd)", maxAvlns);

    network = msg->network;
    for(i = 0; i < msg->numAvlns; i++) {
        ssize_t maxStas = 0;
        SAH_TRACEZ_INFO(ME, "        numstas  = %d", network->numStas);
        station = network->sta;

        maxStas = (size - (msg->numAvlns - i) * sizeof(network_data_t)) / sizeof(sta_data_t);
        when_false_trace((network->numStas <= maxStas), exit, ERROR,
                         "bad value of numStas (%d > %zd) not enough data", network->numStas, maxStas);

        for(j = 0; j < network->numStas; j++) {
            uint16_t tx = bswap16(htons(station->avgtx));
            uint16_t rx = bswap16(htons(station->avgrx));

            convert_mac(station->mac, device_mac);
            convert_devicename_mac(station->mac, device_name_device_mac);

            SAH_TRACEZ_INFO(ME, "            DA[%d]          = %s", j, device_mac);
            SAH_TRACEZ_INFO(ME, "            avgPHYDR_TX[%d] = %d Mb/s", j, tx);
            SAH_TRACEZ_INFO(ME, "            avgPHYDR_RX[%d] = %d Mb/s", j, rx);

            associated_device = amxc_var_add_new_key(&associated_devices, (const char*) device_name_device_mac);
            amxc_var_set_type(associated_device, AMXC_VAR_ID_HTABLE);
            amxc_var_add_key(cstring_t, associated_device, "MACAddress", (const char*) device_mac);
            amxc_var_add_key(uint16_t, associated_device, "TxPhyRate", tx);
            amxc_var_add_key(uint16_t, associated_device, "RxPhyRate", rx);
            station++;
            size -= sizeof(sta_data_t);
            if(size < 0) {
                break;
            }
        }
        network = (network_data_t*) station;
        size -= sizeof(network_data_t);
        if(size < 0) {
            break;
        }
    }
    /* In the case an associated device is removed from the network,
     * the associated devices remains in the table of the remaining devices for a given time.
     * Even if it easy to know that this associated device does not exist anymore,
     * it has been decided to not remove the corresponding associated device entry until detected by the remaining devices  */
    dm_device_update_associated_devices(
        sock->interface->interface_obj,
        device_name_homeplug_mac,
        &associated_devices);
exit:
    amxc_var_clean(&associated_devices);
    return;
}

/**
   @brief Handles a CM_HFID_CNF message from a HomePlug device.

   This function parses a CM_HFID_CNF confirmation, which contains a
   "Human-Friendly Identifier" (HFID) string. Depending on the response type,
   the HFID may represent the manufacturer name or a user-defined string.
   The information is added to the device model.

   After updating the device information, the function sends an
   Atheros-specific software version request (atheros_sw_ver_req) to the
   same device for further identification.

   @param sock       Pointer to the HomePlug socket on which the message
                     was received.
   @param sll_addr   8-byte source link-layer address of the device.
   @param hdr        Pointer to the CM_HFID_CNF message.
   @param frame_size Size of the received frame (Unused).
 */
static void handle_cm_hfid_cnf(homeplug_socket_t* sock, const uint8_t sll_addr[8], uint8_t* hdr, UNUSED ssize_t frame_size) {
    size_t messagesize = 0;
    atheros_sw_ver_req_t* sw_ver_req = NULL;
    amxc_var_t device_params;
    uint8_t device_name_homeplug_mac[25] = "";
    uint8_t homeplug_mac[18] = "";
    cm_hfid_cnf_t* msg = (cm_hfid_cnf_t*) hdr;

    amxc_var_init(&device_params);
    amxc_var_set_type(&device_params, AMXC_VAR_ID_HTABLE);

    convert_devicename_mac(sll_addr, device_name_homeplug_mac);
    convert_mac(sll_addr, homeplug_mac);

    SAH_TRACEZ_INFO(ME, ">");
    SAH_TRACEZ_INFO(ME, "CM_HIFD_CNF");
    SAH_TRACEZ_INFO(ME, "    received from %s", homeplug_mac);
    SAH_TRACEZ_INFO(ME, "    res_type = %d", msg->res_type);
    SAH_TRACEZ_INFO(ME, "    hfid    = %s", msg->hfid);
    SAH_TRACEZ_INFO(ME, ">");

    switch(msg->res_type) {
    case 0x00:
        SAH_TRACEZ_INFO(ME, "Set manufacturer to %s", msg->hfid);
        amxc_var_add_key(cstring_t, &device_params, "Manufacturer", (char*) msg->hfid);
        break;
    case 0x01:
        SAH_TRACEZ_INFO(ME, "Set user to %s", msg->hfid);
        break;
    }

    dm_interface_add_or_update_device(sock->interface->interface_obj,
                                      device_name_homeplug_mac,
                                      &device_params);
    amxc_var_clean(&device_params);

    sw_ver_req = (atheros_sw_ver_req_t*)
        homeplug_av_protocol_create_atheros_sw_ver_req(&messagesize);
    when_null_trace(sw_ver_req, exit, ERROR, "Failed to create sw_ver request");
    SAH_TRACEZ_NOTICE(ME, "==> Sending atheros_sw_ver request");
    when_false_trace(homeplug_socket_send_request(sock, sll_addr, (uint8_t*) sw_ver_req, messagesize),
                     exit, ERROR, "Failed to send sw ver request");
exit:
    free(sw_ver_req);
}

/**
   @brief Handles the reception of an Atheros software version confirmation message.

   This function processes vendor-specific confirmation messages with an Atheros OUI
   that contain firmware version information. It validates the OUI, extracts version
   details, logs diagnostic information, and updates the device parameters in the
   data model.

   @param sock         The HomePlug socket through which the message was received (Unused).
   @param sll_addr     The source link-layer address (MAC) of the sending device.
   @param hdr          Pointer to the received HomePlug frame payload.
   @param frame_size   Size in bytes of the received frame (Unused).
 */
static void handle_atheros_sw_ver_cnf(UNUSED homeplug_socket_t* sock, const uint8_t sll_addr[8], uint8_t* hdr, UNUSED ssize_t frame_size) {
    vendor_specific_hdr_t* vendorhdr = (vendor_specific_hdr_t*) hdr;
    atheros_sw_ver_cnf_t* msg = NULL;
    uint8_t homeplug_mac[18] = "";
    amxc_var_t device_params;
    uint8_t device_name_homeplug_mac[25] = "";

    SAH_TRACEZ_INFO(ME, "Vendor OUI = %2.2x:%2.2x:%2.2x", vendorhdr->vendorOUI[0], vendorhdr->vendorOUI[1], vendorhdr->vendorOUI[2]);
    if(!isOUI(vendorhdr, atheros_oui)) {
        goto exit;
    }
    SAH_TRACEZ_INFO(ME, "Atheros specific message");

    amxc_var_init(&device_params);
    amxc_var_set_type(&device_params, AMXC_VAR_ID_HTABLE);

    convert_mac(sll_addr, homeplug_mac);
    convert_devicename_mac(sll_addr, device_name_homeplug_mac);

    msg = (atheros_sw_ver_cnf_t*) hdr;
    SAH_TRACEZ_INFO(ME, ">");
    SAH_TRACEZ_INFO(ME, "atheros_sw_ver_cnf");
    SAH_TRACEZ_INFO(ME, "    received from %s", homeplug_mac);
    SAH_TRACEZ_INFO(ME, "    status    = %d", msg->status);
    SAH_TRACEZ_INFO(ME, "    devceid   = %d", msg->deviceid);
    SAH_TRACEZ_INFO(ME, "    verlength = %d", msg->verlength);
    SAH_TRACEZ_INFO(ME, "    version   = %s", (const char*) msg->version);

    amxc_var_add_key(cstring_t, &device_params, "FirmwareVersion", (char*) (&msg->version[0]));

    dm_interface_add_or_update_device(sock->interface->interface_obj,
                                      device_name_homeplug_mac,
                                      &device_params);
    amxc_var_clean(&device_params);
exit:
    return;
}

void homeplug_av_protocol_handle_rcvd_msg(homeplug_socket_t* sock, uint8_t* frame, UNUSED size_t framelength, const uint8_t sll_addr[8]) {
    SAH_TRACEZ_INFO(ME, "homeplug av handle rcvd message");
    homeplug_av_hdr_t* hdr = (homeplug_av_hdr_t*) frame;
    when_false_trace(!((hdr->mmv == HOMEPLUG_AV_VERSION_1_0) &&
                       (av_message_category(av_message_mm_type(hdr)) != MMTYPE_VENDOR_SPEC)),
                     exit, WARNING,
                     "Received a v1.0 management message packet: it's not supported, it will be dropped");

    av_dump(hdr);
    av_message_decode_mm_type(hdr);

    when_false_trace((av_message_message_type(av_message_mm_type(hdr)) == MMTYPE_CNF),
                     exit, INFO,
                     "Message type = %d", av_message_message_type(av_message_mm_type(hdr)));

    switch(av_message_mm_type(hdr)) {
    case CM_BRG_INFO_CNF: {
        SAH_TRACEZ_INFO(ME, "handle brg info cnf");
        handle_cm_brg_info_cnf(sock, sll_addr, frame, framelength);
        break;
    }
    case CM_NW_STATS_CNF: {
        SAH_TRACEZ_INFO(ME, "handle cm nw stats cnf");
        handle_cm_nw_stats_cnf(sock, sll_addr, frame, framelength);
        break;
    }
    case VS_NW_INFO_CNF: {
        SAH_TRACEZ_INFO(ME, "handle vs nw info cnf");
        handle_vs_nw_info_cnf(sock, sll_addr, frame, framelength);
        break;
    }
    case CM_HIFD_CNF: {
        SAH_TRACEZ_INFO(ME, "handle cm hfid cnf");
        handle_cm_hfid_cnf(sock, sll_addr, frame, framelength);
        break;
    }
    case ATHEROS_SW_VER_CNF: {
        SAH_TRACEZ_INFO(ME, "handle atheros sw ver cnf");
        handle_atheros_sw_ver_cnf(sock, sll_addr, frame, framelength);
        break;
    }
    default: {
        SAH_TRACEZ_INFO(ME, "Not handled home plug av message type: %d", av_message_mm_type(hdr));
    }
    }
exit:
    return;
}

uint8_t* homeplug_av_protocol_create_cm_brg_info_req(size_t* messagesize) {
    *messagesize = av_message_size(sizeof(cm_brg_info_req_t));
    cm_brg_info_req_t* req = (cm_brg_info_req_t*) calloc(1, *messagesize);
    when_null_trace(req, exit, ERROR, "Out of mem, alloc failed");
    req->mmv = HOMEPLUG_AV_VERSION_1_1;
    req->mm_type_MSB = av_message_msb_mm_type(CM_BRG_INFO_REQ);
    req->mm_type_LSB = av_message_lsb_mm_type(CM_BRG_INFO_REQ);
exit:
    return (uint8_t*) req;
}

uint8_t* homeplug_av_protocol_create_cm_nw_stats_req(size_t* messagesize) {

    *messagesize = av_message_size(sizeof(cm_nw_stats_req_t));
    cm_nw_stats_req_t* req = (cm_nw_stats_req_t*) calloc(1, *messagesize);

    req->mmv = HOMEPLUG_AV_VERSION_1_1;
    req->mm_type_MSB = av_message_msb_mm_type(CM_NW_STATS_REQ);
    req->mm_type_LSB = av_message_lsb_mm_type(CM_NW_STATS_REQ);

    return (uint8_t*) req;
}

uint8_t* homeplug_av_protocol_create_vs_nw_info_req(size_t* messagesize) {

    *messagesize = av_message_size(sizeof(vs_nw_info_req_t));
    vs_nw_info_req_t* req = (vs_nw_info_req_t*) calloc(1, *messagesize);

    req->hdr.mmv = HOMEPLUG_AV_VERSION_1_1;
    req->hdr.mm_type_MSB = av_message_msb_mm_type(VS_NW_INFO_REQ);
    req->hdr.mm_type_LSB = av_message_lsb_mm_type(VS_NW_INFO_REQ);
    memcpy(req->vendorOUI, atheros_oui, 3);

    return (uint8_t*) req;
}

uint8_t* homeplug_av_protocol_create_cm_hfid_req(uint8_t reqtype, UNUSED uint8_t nid[], UNUSED uint8_t nidlength, UNUSED uint8_t hfid[], UNUSED uint8_t hfidlength, size_t* messagesize) {

    cm_hfid_req_t* req = NULL;
    switch(reqtype) {
    case 0x00:
    case 0x01:
        *messagesize = av_message_size(sizeof(homeplug_av_hdr_t));
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "Invalid request type");
        goto exit;
    }

    // allocate the message
    req = (cm_hfid_req_t*) calloc(1, *messagesize);

    // fill in the header fields
    req->hdr.mmv = HOMEPLUG_AV_VERSION_1_1;
    req->hdr.mm_type_MSB = av_message_msb_mm_type(CM_HIFD_REQ);
    req->hdr.mm_type_LSB = av_message_lsb_mm_type(CM_HIFD_REQ);

    // set the reqtype
    req->req_type = reqtype;

exit:
    return (uint8_t*) req;
}
uint8_t* homeplug_av_protocol_create_atheros_sw_ver_req(size_t* messagesize) {
    *messagesize = av_message_size(sizeof(atheros_sw_ver_req_t));
    atheros_sw_ver_req_t* req = (atheros_sw_ver_req_t*) calloc(1, *messagesize);

    req->mmv = HOMEPLUG_AV_VERSION_1_0;
    req->mm_type_MSB = av_message_msb_mm_type(ATHEROS_SW_VER_REQ);
    req->mm_type_LSB = av_message_lsb_mm_type(ATHEROS_SW_VER_REQ);
    memcpy(req->vendorOUI, atheros_oui, 3);

    return (uint8_t*) req;
}
