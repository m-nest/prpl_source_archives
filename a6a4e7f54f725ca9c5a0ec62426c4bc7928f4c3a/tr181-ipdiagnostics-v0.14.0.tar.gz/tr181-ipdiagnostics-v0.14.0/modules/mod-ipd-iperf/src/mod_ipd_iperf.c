/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_ipd_common.h"
#include "mod_ipd_iperf_download.h"
#include "mod_ipd_iperf_upload.h"
#include "ip_diagnostics.h"
#include "upload_download.h"
#include "download.h"
#include "upload.h"

// module trace zone
#define ME "ipd-iperf"

static AMXM_CONSTRUCTOR ipd_iperf_start(void) {
    int rv = -1;
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;
    function_t function[] = {
        {IPD_DOWNLOAD_TEST_START, mod_download_test_start},
        {IPD_DOWNLOAD_TEST_CHECK, mod_download_test_check},
        {IPD_DOWNLOAD_TEST_STOP, mod_download_test_stop},
        {IPD_DOWNLOAD_TEST_ABORT, mod_download_test_abort},
        {IPD_UPLOAD_TEST_START, mod_upload_test_start},
        {IPD_UPLOAD_TEST_CHECK, mod_upload_test_check},
        {IPD_UPLOAD_TEST_STOP, mod_upload_test_stop},
        {IPD_UPLOAD_TEST_ABORT, mod_upload_test_abort},
        {NULL, 0}
    };

    rv = amxm_module_register(&mod, so, MOD_IPD_CTRL);
    when_failed_trace(rv, error, ERROR, "Failed to register the module %s", MOD_IPD_CTRL);

    for(size_t i = 0; function[i].name != NULL; i++) {
        rv = amxm_module_add_function(mod, function[i].name, function[i].callback);
        if(rv != 0) {
            SAH_TRACEZ_WARNING(ME, "Failed to register function %s from %s", function[i].name, MOD_IPD_CTRL);
        }
    }

error:
    return rv;
}

static AMXM_DESTRUCTOR ipd_iperf_stop(void) {
    return 0;
}
