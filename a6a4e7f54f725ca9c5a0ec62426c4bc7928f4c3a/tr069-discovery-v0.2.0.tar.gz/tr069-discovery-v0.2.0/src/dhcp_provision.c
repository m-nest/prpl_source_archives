/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "tr069_discovery.h"
#include "event_handler.h"

#define ME "dhcp_provision"

static int set_management_server_url(const char* value);
static int apply_config_from_dhcp(void);
static int call_dhcp_client_renew(const char* dhcp_client_path);
static void schedule_session_establishment_timeout(void);

void handle_dhcp_option_change(dhcp_option_t* option) {
    SAH_TRACEZ_INFO(ME, "Retrieved config from DHCP: url_to_acs=\"%s\", provisioning_code=\"%s\", dhcp_version=%d, dhcp_provision_in_use=%d",
                    option->url_of_acs, option->provisioning_code, option->dhcp_version, app.dhcp_provision_in_use);
    // Skip handling option if it contains no changes
    if(dhcp_option_equals(app.option_to_use, option)) {
        return;
    }
    if(option->dhcp_version == DHCPv4) {
        app.dhcpv4 = *option;
    } else {
        app.dhcpv6 = *option;
    }
    dhcp_option_t* old_option = app.option_to_use;
    // See TR-069 Section 3.1: https://www.broadband-forum.org/pdfs/tr-069-1-6-1.pdf
    // If both DHCPv4 and DHCPv6 options are received, the CPE MUST use the DHCPv6 option over the DHCPv4 option.
    if(strlen(app.dhcpv6.url_of_acs)) {
        app.option_to_use = &app.dhcpv6;
    } else if(strlen(app.dhcpv4.url_of_acs)) {
        app.option_to_use = &app.dhcpv4;
    } else {
        app.option_to_use = NULL;
    }
    // Skip handling option if DHCP provisioning disabled
    if(!app.dhcp_provision_in_use) {
        return;
    }
    // Skip if nothing has changed
    if(!old_option && !app.option_to_use) {
        return;
    }
    // Reset ACS URL if DHCP lease expired
    if(!app.option_to_use) {
        if(set_management_server_url("")) {
            SAH_TRACEZ_ERROR(ME, "Failed to reset ACS URL after DHCP lease expiration");
        }
        return;
    }
    // Skip applying new DHCPv4 option if DHCPv6 in use
    if((option->dhcp_version == DHCPv4) && app.option_to_use && (app.option_to_use->dhcp_version == DHCPv6)) {
        SAH_TRACEZ_NOTICE(ME, "Skip applying new DHCPv4 option due to DHCPv6 option in use");
        return;
    }
    apply_config_from_dhcp();
}

static int set_management_server_url(const char* value) {
    if(set_string_parameter_value(MANAGEMENT_SERVER, "URL", value)) {
        SAH_TRACEZ_ERROR(ME, "Failed to set \"%s\" to \"%s\"", MANAGEMENT_SERVER_URL, value);
        return -1;
    }
    if(app.dhcp_provision_in_use || (app.first_successful_provision != PROVISION_MANUAL)) {
        schedule_session_establishment_timeout();
    }
    SAH_TRACEZ_INFO(ME, "Set \"%s\" to \"%s\"", MANAGEMENT_SERVER_URL, value);
    return 0;
}

static int set_management_server_ip_version(dhcp_version_t version) {
    int rc = -1;

    amxc_var_t values;
    amxc_var_t ret;
    amxc_var_init(&values);
    amxc_var_init(&ret);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);

    amxb_bus_ctx_t* ctx = amxb_be_who_has(MANAGEMENT_SERVER_INTERNAL_SETTINGS);
    when_null_trace(ctx, exit, ERROR, "Failed to find context for \"%s\"", MANAGEMENT_SERVER_INTERNAL_SETTINGS);

    amxc_var_add_key(uint8_t, &values, "ACSAddrFamily", (uint8_t) version);
    amxc_var_add_key(cstring_t, &values, "PreferredIPVersion", version == DHCPv4 ? "IPV4ONLY" :
                     (version == DHCPv6 ? "IPV6PREFERRED" : "IPANY"));

    rc = amxb_set(ctx, MANAGEMENT_SERVER_INTERNAL_SETTINGS, &values, &ret, 5);
    when_failed_trace(rc, exit, ERROR, "Failed to set IP version for \"%s\"", MANAGEMENT_SERVER_INTERNAL_SETTINGS);

exit:
    amxc_var_clean(&values);
    amxc_var_clean(&ret);
    return rc;
}

static int set_device_provisioning_code(const char* value) {
    if(set_string_parameter_value(DEVICE_INFO, "ProvisioningCode", value)) {
        SAH_TRACEZ_ERROR(ME, "Failed to set \"%s\" to \"%s\"", DEVICE_INFO_PROVISIONING_CODE, value);
        return -1;
    }
    SAH_TRACEZ_INFO(ME, "Set \"%s\" to \"%s\"", DEVICE_INFO_PROVISIONING_CODE, value);
    return 0;
}

static int apply_config_from_dhcp(void) {
    int rc = 0;

    when_null_trace(app.option_to_use, exit, NOTICE, "No configuration provided by DHCP");

    SAH_TRACEZ_INFO(ME, "Applying config from DHCP");

    rc = set_management_server_url(app.option_to_use->url_of_acs);
    when_failed_trace(rc, exit, ERROR, "Failed to set ACS URL from DHCP");

    if(strlen(app.option_to_use->provisioning_code)) {
        rc = set_device_provisioning_code(app.option_to_use->provisioning_code);
        when_failed_trace(rc, exit, ERROR, "Failed to set provisioning code from DHCP");
    }

    if(set_management_server_ip_version(app.option_to_use->dhcp_version)) {
        SAH_TRACEZ_WARNING(ME, "Failed to specify IP version for CWMP agent");
    }

    SAH_TRACEZ_INFO(ME, "Applied config from DHCP");

exit:
    return rc;
}

static void update_state_at_dm(void) {
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, ACS_DISCOVERY_STATE);
    amxd_trans_set_bool(&trans, DHCP_PROVISION_IN_USE, app.dhcp_provision_in_use);
    amxd_trans_set_cstring_t(&trans, FIRST_SUCCESSFUL_PROVISION, provision_type_to_string(app.first_successful_provision));

    int rc = amxd_trans_apply(&trans, app.dm);
    if(rc) {
        SAH_TRACEZ_ERROR(ME, "Failed to update %s state: rc=%d", ACS_DISCOVERY_STATE, rc);
    }

    amxd_trans_clean(&trans);
}

static int enable_dhcp_provisioning(void) {
    SAH_TRACEZ_INFO(ME, "Enabling DHCP provisioning");

    app.dhcp_provision_in_use = true;
    update_state_at_dm();

    if(apply_config_from_dhcp()) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply config from DHCP");
        return -1;
    }

    SAH_TRACEZ_INFO(ME, "DHCP provisioning enabled");

    return 0;
}

static void disable_dhcp_provisioning(void) {
    SAH_TRACEZ_INFO(ME, "Disabling DHCP provisioning");

    app.dhcp_provision_in_use = false;
    update_state_at_dm();

    if(app.session_timer != NULL) {
        amxp_timer_delete(&app.session_timer);
    }

    if(set_management_server_ip_version(0)) {
        SAH_TRACEZ_WARNING(ME, "Failed to reset IP version for CWMP agent");
    }

    SAH_TRACEZ_INFO(ME, "DHCP provisioning disabled");
}

static void set_first_successful_provision(provision_type_t value) {
    if(app.first_successful_provision == value) {
        SAH_TRACEZ_WARNING(ME, "%s is already \"%s\"", FIRST_SUCCESSFUL_PROVISION, provision_type_to_string(value));
        return;
    }

    app.first_successful_provision = value;
    SAH_TRACEZ_INFO(ME, "Set %s to \"%s\"", FIRST_SUCCESSFUL_PROVISION, provision_type_to_string(value));

    update_state_at_dm();
}

void handle_cwmp_session_establishment(void) {
    if(app.first_successful_provision == PROVISION_NONE) {
        if(app.dhcp_provision_in_use) {
            set_first_successful_provision(PROVISION_DHCP);
        } else {
            if(!app.option_to_use) {
                // Workaround to prevent false triggering of 'ManagementServer.State.LastSession' update by
                // cwmp_plugin after time synchronization.
                return;
            }
            set_first_successful_provision(PROVISION_MANUAL);
        }
    }
    if(app.session_timer) {
        amxp_timer_delete(&app.session_timer);
    }
}

static void renew_dhcp_lease(void) {
    if(call_dhcp_client_renew(app.dhcpv4_client_ref)) {
        SAH_TRACEZ_ERROR(ME, "Failed to force renew DHCPv4 lease");
    }
    if(call_dhcp_client_renew(app.dhcpv6_client_ref)) {
        SAH_TRACEZ_ERROR(ME, "Failed to force renew DHCPv6 lease");
    }
    schedule_session_establishment_timeout();
}

static void handle_session_establishment_timeout(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    SAH_TRACEZ_WARNING(ME, "CWMP session establishment timed out: url=%s", app.management_server_url);

    // Renew DHCP lease if provisioned ACS URL is not available
    if(app.dhcp_provision_in_use) {
        renew_dhcp_lease();
        return;
    }
    // See TR-069 Section 3.1: https://www.broadband-forum.org/pdfs/tr-069-1-6-1.pdf
    // When the CPE needs to contact the ACS, it MUST use the DHCP discovery
    // mechanism in the following scenarios:
    // • If the CPE is unable to contact the ACS and the CPE originally (the first
    //   successful time after the most recent factory reset) obtained its ACS URL through
    //   DHCP.
    if(app.first_successful_provision == PROVISION_DHCP) {
        if(enable_dhcp_provisioning()) {
            SAH_TRACEZ_ERROR(ME, "Failed to enable DHCP provisioning after CWMP session establishment timed out");
        }
    }
}

static void schedule_session_establishment_timeout(void) {
    if(app.session_timer != NULL) {
        amxp_timer_delete(&app.session_timer);
    }
    amxp_timer_new(&app.session_timer, handle_session_establishment_timeout, NULL);
    amxp_timer_start(app.session_timer, app.dhcp_rediscovery_interval_s * 1000);
}

static bool is_acs_url_defined_by_user(void) {
    return app.option_to_use == NULL || strcmp(app.option_to_use->url_of_acs, app.management_server_url);
}

void handle_management_server_url_change(const char* url) {
    SAH_TRACEZ_INFO(ME, "%s changed to \"%s\"", MANAGEMENT_SERVER_URL, url);

    snprintf(app.management_server_url, sizeof(app.management_server_url), "%s", url);

    if(!strlen(app.management_server_url)) {
        // Enable DHCP provisioning if URL is empty
        // See TR-069 Section 3.1: https://www.broadband-forum.org/pdfs/tr-069-1-6-1.pdf
        // When the CPE needs to contact the ACS, it MUST use the DHCP discovery
        // mechanism in the following scenarios:
        // • If the CPE has an empty value for the ManagementServer.URL Parameter
        if(enable_dhcp_provisioning()) {
            SAH_TRACEZ_ERROR(ME, "Failed to enable DHCP provisioning");
        }
    } else if(app.dhcp_provision_in_use && is_acs_url_defined_by_user()) {
        // Disable DHCP provisioning if user changed ACS URL
        disable_dhcp_provisioning();
    }
    if(app.dhcp_provision_in_use || (app.first_successful_provision != PROVISION_MANUAL)) {
        schedule_session_establishment_timeout();
    }
}

static int call_dhcp_client_renew(const char* dhcp_client_path) {
    int rc = -1;

    amxc_var_t params;
    amxc_var_t ret;

    amxc_var_init(&params);
    amxc_var_init(&ret);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);

    amxb_bus_ctx_t* ctx = amxb_be_who_has(dhcp_client_path);
    when_null_trace(ctx, exit, ERROR, "Failed to get context for \"%s\"", dhcp_client_path);
    rc = amxb_call(ctx, dhcp_client_path, "Renew", &params, &ret, 5);
    when_failed_trace(rc, exit, ERROR, "Failed to call Renew() for DHCP client: path=\"%s\", rc=%d",
                      dhcp_client_path, rc);

    SAH_TRACEZ_INFO(ME, "DHCP client renew initiated: dhcp_client_path=\"%s\"", dhcp_client_path);

exit:
    amxc_var_clean(&params);
    amxc_var_clean(&ret);
    return rc;
}

int dhcp_provisioning_start(void) {
    int rc = -1;

    rc = get_string_parameter_value(MANAGEMENT_SERVER, "URL", app.management_server_url, sizeof(app.management_server_url));
    when_failed_trace(rc, exit, ERROR, "Failed to get value of \"%s\"", MANAGEMENT_SERVER_URL);

    if(app.dhcp_provision_in_use) {
        // Recovery from a non-graceful shutdown
        disable_dhcp_provisioning();
        if(strlen(app.management_server_url)) {
            rc = set_management_server_url("");
            when_failed_trace(rc, exit, ERROR, "Failed to reset ACS URL after non-graceful shutdown");
        }
        rc = enable_dhcp_provisioning();
        when_failed_trace(rc, exit, ERROR, "Failed to enable DHCP provisioning");
    } else if(!strlen(app.management_server_url)) {
        // Enable DHCP provision if ACS URL is empty
        rc = enable_dhcp_provisioning();
        when_failed_trace(rc, exit, ERROR, "Failed to enable DHCP provisioning at empty ACS URL");
    } else if(app.first_successful_provision == PROVISION_DHCP) {
        schedule_session_establishment_timeout();
    }

    rc = setup_subscriptions(app.netmodel_intf_alias);
    when_failed_trace(rc, exit, ERROR, "Failed to subscribe on updates");

exit:
    return rc;
}

int dhcp_provisioning_stop(void) {
    int rc = -1;

    cleanup_subscriptions();

    if(app.dhcp_provision_in_use) {
        disable_dhcp_provisioning();
        rc = set_management_server_url("");
        when_failed_trace(rc, exit, ERROR, "Failed to reset ACS URL after non-graceful shutdown");
    }

    rc = 0;
exit:
    return rc;
}
