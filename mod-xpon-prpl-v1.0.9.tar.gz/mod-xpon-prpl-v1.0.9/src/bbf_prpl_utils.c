/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "bbf_prpl_utils.h"

/* System headers */
#include <string.h> /* strlen() */

/* Other libraries' headers */
#include <amxc/amxc_llist.h>
#include <amxc/amxc_macros.h>       /* when_true_status() */
#include <amxc/amxc_string_split.h> /* amxc_string_split_to_llist() */
#include <amxc/amxc_utils.h>        /* amxc_string_list_it_free */

/* Own headers */
#include "dm_info.h" /* dm_convert_prpl_path_to_bbf_path() */
#include "mod_xpon_trace.h"

/**
 * Convert csv string with prpl paths to csv string with equivalent BBF paths.
 *
 * @param[in] prpl_value: csv string with prpl paths
 * @param[in,out] bbf_value: the function converts @a prpl_value to a csv string
 *     with the equivalent BBF paths, and assigns it to this parameter. The
 *     caller must pass an initialized amxc_string_t.
 *
 * The function was introduced to convert the value sent by the ONU HAL agent
 * for the parameter XPON.ONU.{i}.EthernetUNI.{i}.ANIs. The ONU HAL agent
 * follows the ubus PON DM convention. E.g., it might report "xpon_onu.1.ani.1"
 * as value. Then the XPON DM must show "XPON.ONU.1.ANI.1" as value.
 *
 * @return true on success, else false
 */
bool convert_paths_in_csv_string_from_prpl_to_bbf(const char* prpl_value,
                                                  amxc_string_t* bbf_value) {
    bool rv = false;
    int rc;
    amxc_string_t prpl_value_str;
    amxc_string_t bbf_item_str;
    amxc_llist_t string_list;

    amxc_string_init(&prpl_value_str, 0);
    amxc_string_init(&bbf_item_str, 0);
    amxc_llist_init(&string_list);

    const size_t len = strlen(prpl_value);
    when_true_status(0 == len, exit, rv = true); /* nothing to do */

    amxc_string_set(&prpl_value_str, prpl_value);

    rc = amxc_string_split_to_llist(&prpl_value_str, &string_list, ',');
    when_failed_trace(rc, exit, ERROR, "Failed to split '%s' (rc=%d)", prpl_value, rc);
    const size_t n_items = amxc_llist_size(&string_list);
    when_true_trace(0 == n_items, exit, ERROR, "%s: n_items=0", prpl_value);
    uint32_t i;
    const char* prpl_item_cstr;
    const char* bbf_item_cstr;
    bool ok;
    for(i = 0; i < n_items; ++i) {
        prpl_item_cstr = amxc_string_get_text_from_llist(&string_list, i);
        when_null_trace(prpl_item_cstr, exit, ERROR,
                        "%s: failed to get item nr %u", prpl_value, i);
        ok = dm_convert_prpl_path_to_bbf_path(prpl_item_cstr, &bbf_item_str);
        when_false_trace(ok, exit, ERROR, "Failed to convert '%s' to BBF path",
                         prpl_item_cstr);
        bbf_item_cstr = amxc_string_get(&bbf_item_str, 0);
        if(0 == i) {
            rc = amxc_string_appendf(bbf_value, "%s", bbf_item_cstr);
        } else {
            rc = amxc_string_appendf(bbf_value, ",%s", bbf_item_cstr);
        }
        when_failed_trace(rc, exit, ERROR, "Failed to append bbf_item_cstr='%s'",
                          bbf_item_cstr);
    }
    rv = true;
exit:
    amxc_llist_clean(&string_list, amxc_string_list_it_free);
    amxc_string_clean(&prpl_value_str);
    amxc_string_clean(&bbf_item_str);
    return rv;
}

