/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <linux/limits.h>
#include <string.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxd/amxd_action.h>
#include <lcm/lcm_assert.h>

#include <cthulhu/cthulhu_defines.h>
#include <cthulhu/cthulhu_helpers.h>
#include <debug/sahtrace.h>
#include "lcm_bus.h"

#include "test_setup.h"

static const char* main = "main";
static lcm_bus_t* main_bus = NULL;


int test_syslog_setup(void) {

    sahTraceOpen(ME, TRACE_TYPE_STDOUT);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "all");
    main_bus = lcm_bus_create(main);
    assert_int_equal(amxo_parser_parse_file(&main_bus->parser, "../odl/cthulhu.odl", amxd_dm_get_root(&main_bus->dm)), 0);
    assert_int_equal(amxo_parser_parse_file(&main_bus->parser, "../../odl/plugin-syslog/plugin-syslog-definition.odl", amxd_dm_get_root(&main_bus->dm)), 0);

    amxd_object_t* syslog = amxd_dm_findf(&main_bus->dm, "Cthulhu.Config.Syslog");
    assert_non_null(syslog);
    amxd_object_set_cstring_t(syslog, "LogLocation", "/tmp/cthulhu/syslog");
    return 0;
}

int test_syslog_teardown(void) {
    lcm_bus_delete(&main_bus, true);
    sahTraceClose();

    return 0;
}

void test_handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

amxd_object_t* test_sb_get(const char* const sb_id) {
    return amxd_dm_findf(&main_bus->dm, CTHULHU_DM_SANDBOX_INSTANCES ".[" CTHULHU_SANDBOX_ID "==\"%s\"].", sb_id);
}

amxd_object_t* test_ctr_get(const char* const ctr_id) {
    return amxd_dm_findf(&main_bus->dm, CTHULHU_DM_CONTAINER_INSTANCES ".[" CTHULHU_CONTAINER_ID "==\"%s\"].", ctr_id);
}

void test_add_sb(const char* sb_id) {
    amxd_object_t* instances = amxd_dm_findf(&main_bus->dm, CTHULHU_DM_SANDBOX_INSTANCES);
    amxd_object_t* sb_obj = NULL;
    assert_non_null(instances);
    assert_int_equal(amxd_object_add_instance(&sb_obj, instances, sb_id, 0, NULL), 0);
    amxd_object_set_cstring_t(sb_obj, CTHULHU_SANDBOX_ID, sb_id);
}

void test_add_ctr(const char* ctr_id, const char* sb_id) {
    amxd_object_t* instances = amxd_dm_findf(&main_bus->dm, CTHULHU_DM_CONTAINER_INSTANCES);
    amxd_object_t* ctr_obj = NULL;
    assert_non_null(instances);
    assert_int_equal(amxd_object_add_instance(&ctr_obj, instances, ctr_id, 0, NULL), 0);
    amxd_object_set_cstring_t(ctr_obj, CTHULHU_CONTAINER_ID, ctr_id);
    amxd_object_set_cstring_t(ctr_obj, CTHULHU_CONTAINER_SANDBOX, sb_id);
}

void test_describe_object(amxd_object_t* obj) {
    amxc_var_t retval;
    amxc_var_init(&retval);
    amxd_action_object_describe(obj, NULL, action_object_describe, NULL, &retval, NULL);
    amxc_var_dump(&retval, STDOUT_FILENO);
    amxc_var_clean(&retval);
}

amxd_dm_t* test_get_main_dm(void) {
    ASSERT_NOT_NULL(main_bus, return NULL);
    return &main_bus->dm;
}
