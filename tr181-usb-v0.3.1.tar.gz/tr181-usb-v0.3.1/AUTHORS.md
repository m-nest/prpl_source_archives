<!--
****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
** 
** See LICENSE file for more details.
**
****************************************************************************
-->

The tr181-usb module is copyright 2025 its contributors.
This file lists all contributors.

Individuals:
- Messaoud Doudou (sagemcom.com)
