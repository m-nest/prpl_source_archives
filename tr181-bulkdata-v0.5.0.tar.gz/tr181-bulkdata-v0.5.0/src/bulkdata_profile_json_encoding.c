/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "bulkdata.h"
#include "bulkdata_profile_json_encoding.h"
#include "bulkdata_profile_encoding.h"

#define ME "json_encoding"

amxd_object_t* bulkdata_get_json_encoding_object(amxd_object_t* profile) {
    cstring_t path = amxd_object_get_path(profile, AMXD_OBJECT_NAMED);
    amxd_object_t* obj = amxd_dm_findf(bulkdata_get_dm(), "%s.JSONEncoding.", path);
    free(path);
    return obj;
}

const cstring_t bulkdata_json_encoding_get_report_format(amxd_object_t* json_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(json_encoding, "ReportFormat"));
}

const cstring_t bulkdata_json_encoding_get_report_timestamp(amxd_object_t* json_encoding) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(json_encoding, "ReportTimestamp"));
}

static void bulkdata_add_collection_time(amxd_object_t* json_encoding, amxc_var_t* data) {
    amxc_ts_t* timestamp = NULL;
    const cstring_t report_timestamp = NULL;
    cstring_t collection_time = NULL;

    report_timestamp = bulkdata_json_encoding_get_report_timestamp(json_encoding);
    if((report_timestamp == NULL) || (strcmp(report_timestamp, "None") == 0)) {
        SAH_TRACEZ_INFO(ME, "Don't send CollectionTime");
        goto exit;
    }
    timestamp = bulkdata_utc_timestamp(report_timestamp);
    if(timestamp == NULL) {
        SAH_TRACEZ_ERROR(ME, "Could not retrieve UTC timestamp.");
        goto exit;
    }
    collection_time = bulkdata_format_time(report_timestamp, timestamp);
    if(collection_time != NULL) {
        amxc_var_add_key(cstring_t, data, "CollectionTime", collection_time);
    }

exit:
    free(collection_time);
    free(timestamp);
}

static void bulkdata_convert_to_objecthierarchy_data(amxc_var_t* data, amxc_var_t* converted_data) {
    amxc_var_for_each(entry, data) {
        char* key = NULL;
        char* value = NULL;
        amxc_var_t* hierarchy = converted_data;
        amxd_path_t key_path;
        amxd_path_init(&key_path, NULL);
        amxd_path_setf(&key_path, true, "%s", amxc_var_key(entry));
        for(uint32_t depth = amxd_path_get_depth(&key_path); depth > 1; depth--) {
            amxc_var_t* next_depth = NULL;
            char* kpath = amxd_path_get_first(&key_path, true);
            kpath[strlen(kpath) - 1] = '\0';
            next_depth = GET_ARG(hierarchy, kpath);
            if(next_depth == NULL) {
                next_depth = amxc_var_add_key(amxc_htable_t, hierarchy, kpath, NULL);
            }
            hierarchy = next_depth;
            free(kpath);
        }
        key = amxd_path_get_first(&key_path, false);
        value = amxc_var_dyncast(cstring_t, entry);
        key[strlen(key) - 1] = '\0';
        amxc_var_add_key(cstring_t, hierarchy, key, value);
        free(key);
        free(value);
        amxd_path_clean(&key_path);
    }
}

amxc_var_t* bulkdata_json_format_data(amxd_object_t* profile, amxc_var_t* data) {
    amxd_object_t* json_encoding = bulkdata_get_json_encoding_object(profile);
    char* report_format = NULL;
    amxc_var_t converted_data;
    amxc_var_t* json = NULL;

    amxc_var_init(&converted_data);
    amxc_var_set_type(&converted_data, AMXC_VAR_ID_HTABLE);
    amxc_var_new(&json);

    /* Add CollectionTime */
    bulkdata_add_collection_time(json_encoding, data);
    /* Manage json formating */
    report_format = amxd_object_get_value(cstring_t, json_encoding, "ReportFormat", NULL);
    if(strcmp(report_format, "ObjectHierarchy") == 0) {
        bulkdata_convert_to_objecthierarchy_data(data, &converted_data);
        amxc_var_move(json, &converted_data);
    } else {
        /* Do a copy to returned a variant that can be delete later */
        amxc_var_move(json, data);
    }
    amxc_var_clean(&converted_data);
    free(report_format);
    return json;
}

