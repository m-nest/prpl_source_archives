/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_dm.h>

#include "test_cabundle.h"
#include "security.h"
#include "dm_functions.h"

int test_cabundle_setup(void** state) {
    amxo_parser_t* parser = NULL;
    amxd_dm_t* dm = NULL;
    amxd_object_t* root = NULL;

    amxut_bus_setup(state);

    parser = amxut_bus_parser();
    dm = amxut_bus_dm();
    root = amxd_dm_get_root(dm);

    amxo_resolver_ftab_add(parser, "CADir", AMXO_FUNC(_CADir));
    amxo_resolver_ftab_add(parser, "CAFile", AMXO_FUNC(_CAFile));

    assert_int_equal(amxo_parser_parse_file(parser, "cabundle.odl", root), 0);

    _security_main(AMXO_START, dm, parser);

    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);
    amxut_bus_handle_events();

    return 0;
}

int test_cabundle_teardown(void** state) {
    amxo_parser_t* parser = NULL;
    amxd_dm_t* dm = NULL;

    parser = amxut_bus_parser();
    dm = amxut_bus_dm();

    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:stop", NULL);
    amxut_bus_handle_events();

    assert_int_equal(_security_main(AMXO_STOP, dm, parser), 0);

    amxut_bus_teardown(state);

    return 0;
}

/**
 * This test has no preriquisites.
 * It will add an instance of Security.CABundle. and call its command CADir().
 * Expect the following result: the command returns the URI associated with the CABundle instance.
 */
void test_cadir(UNUSED void** state) {
    amxd_trans_t trans;
    amxd_object_t* cabundle = NULL;
    const char* object_name = "cabundle-1";
    amxc_var_t args;
    amxc_var_t ret;
    const char* uri = "file:///some/path/to/cadir/";

// setup
    cabundle = amxd_dm_findf(amxut_bus_dm(), "Security.CABundle.[Name=='%s']", object_name);
    assert_null(cabundle);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true); // CABundle is read-only object
    amxd_trans_set_attr(&trans, amxd_tattr_change_prot, true);
    amxd_trans_select_pathf(&trans, "Security.CABundle");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "CADirURI", uri);
    amxd_trans_set_value(cstring_t, &trans, "Name", object_name);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    cabundle = amxd_dm_findf(amxut_bus_dm(), "Security.CABundle.[Name=='%s']", object_name);
    assert_non_null(cabundle);

// the test
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxd_object_invoke_function(cabundle, "CADir", &args, &ret), amxd_status_ok);
    assert_string_equal(GET_CHAR(&args, "CADir"), uri);

// cleanup
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true); // CABundle is read-only object
    amxd_trans_select_pathf(&trans, "Security.CABundle");
    amxd_trans_del_inst(&trans, amxd_object_get_index(cabundle), NULL);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}

/**
 * This test has no preriquisites.
 * It will add an instance of Security.CABundle. and call its command CAFile().
 * Expect the following result: the command returns the URI associated with the CABundle instance.
 */
void test_cafile(UNUSED void** state) {
    amxd_trans_t trans;
    amxd_object_t* cabundle = NULL;
    const char* object_name = "cabundle-1";
    amxc_var_t args;
    amxc_var_t ret;
    const char* uri = "file:///some/path/to/cafile";

// setup
    cabundle = amxd_dm_findf(amxut_bus_dm(), "Security.CABundle.[Name=='%s']", object_name);
    assert_null(cabundle);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true); // CABundle is read-only object
    amxd_trans_set_attr(&trans, amxd_tattr_change_prot, true);
    amxd_trans_select_pathf(&trans, "Security.CABundle");
    amxd_trans_add_inst(&trans, 0, object_name);
    amxd_trans_set_value(cstring_t, &trans, "CAFileURI", uri);
    amxd_trans_set_value(cstring_t, &trans, "Name", object_name);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    cabundle = amxd_dm_findf(amxut_bus_dm(), "Security.CABundle.[Name=='%s']", object_name);
    assert_non_null(cabundle);

// the test
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    assert_int_equal(amxd_object_invoke_function(cabundle, "CAFile", &args, &ret), amxd_status_ok);
    assert_string_equal(GET_CHAR(&args, "CAFile"), uri);

// cleanup
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true); // CABundle is read-only object
    amxd_trans_select_pathf(&trans, "Security.CABundle");
    amxd_trans_del_inst(&trans, amxd_object_get_index(cabundle), NULL);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), amxd_status_ok);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
}