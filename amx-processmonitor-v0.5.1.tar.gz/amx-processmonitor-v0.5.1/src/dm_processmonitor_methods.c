/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "processmonitor.h"
#include "dm_processmonitor.h"

amxd_status_t _reset(amxd_object_t* object,
                     UNUSED amxd_function_t* func,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    amxd_trans_t transaction;
    amxd_status_t status = amxd_status_ok;
    amxd_dm_t* dm = get_dm();
    amxc_ts_t ts = {0, 0, 0};

    if(object == NULL) {
        status = amxd_status_object_not_found;
        goto exit;
    }

    test_t* test = object->priv;

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, object);
    amxd_trans_set_value(amxc_ts_t, &transaction, "LastCheck", &ts);
    amxd_trans_set_value(amxc_ts_t, &transaction, "LastSuccess", &ts);
    amxd_trans_set_value(amxc_ts_t, &transaction, "FailedSince", &ts);
    amxd_trans_set_value(amxc_ts_t, &transaction, "LastFailAction", &ts);
    amxd_trans_set_value(cstring_t, &transaction, "LastFailReason", PM_TEST_FAIL_REASON_TEST_OK);
    amxd_trans_set_value(uint32_t, &transaction, "NumFailed", 0);
    amxd_trans_set_value(uint32_t, &transaction, "NumFailActions", 0);
    //Reset the newly added read-only data model related with ProcessMonitoring/MaxFail statistics while calling reset()
    amxd_trans_set_value(int32_t, &transaction, "NumProcessFail", test->process_monitor_enabled? 0:-1);
    amxd_trans_set_value(int32_t, &transaction, "NumProcessRespawn", test->process_monitor_enabled? 0:-1);
    amxd_trans_set_value(uint32_t, &transaction, "MaxNumFailed", 0);
    amxd_trans_set_value(uint32_t, &transaction, "MaxFailedDuration", 0);

    test->num_failed = 0;

    status = amxd_trans_apply(&transaction, dm);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Failed to call reset with error %d", status);
    }
    amxd_trans_clean(&transaction);
exit:
    return status;
}
