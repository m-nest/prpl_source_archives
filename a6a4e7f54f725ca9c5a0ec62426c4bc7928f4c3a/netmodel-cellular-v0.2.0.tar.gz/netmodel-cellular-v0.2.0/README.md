# netmodel-cellular

NetModel client use for Cellular Interface synchronisation.
