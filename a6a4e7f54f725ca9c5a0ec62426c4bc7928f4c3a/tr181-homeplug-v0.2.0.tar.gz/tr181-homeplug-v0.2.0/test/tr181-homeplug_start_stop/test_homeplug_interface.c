/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include "homeplug.h"
#include "dm_homeplug.h"
#include "../common/test_common.h"
#include "test_homeplug_interface.h"

void test_enable_homeplug_interface_when_homeplug_enable(UNUSED void** state) {
    amxd_object_t* interface_obj_2 = NULL;
    amxd_trans_t transaction;

    interface_obj_2 = amxd_dm_findf(get_dm(), "HomePlug.Interface.2.");

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj_2);
    amxd_trans_set_value(bool, &transaction, "Enable", true);
    amxd_trans_apply(&transaction, get_dm());

    handle_events();

    assert_str_attr_equal(interface_obj_2, "Status", "Up");

    amxd_trans_clean(&transaction);
}

void test_disable_homeplug_interface_when_homeplug_enable(UNUSED void** state) {
    amxd_object_t* interface_obj_2 = NULL;
    amxd_trans_t transaction;

    interface_obj_2 = amxd_dm_findf(get_dm(), "HomePlug.Interface.2.");

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj_2);
    amxd_trans_set_value(bool, &transaction, "Enable", false);
    amxd_trans_apply(&transaction, get_dm());

    handle_events();

    assert_str_attr_equal(interface_obj_2, "Status", "Down");

    amxd_trans_clean(&transaction);
}

void test_enable_homeplug_interface_when_homeplug_disable(UNUSED void** state) {
    amxd_object_t* homeplug_obj = NULL;
    amxd_object_t* interface_obj_2 = NULL;
    amxd_trans_t transaction;

    homeplug_obj = amxd_dm_findf(get_dm(), "HomePlug.");
    assert_non_null(homeplug_obj);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, homeplug_obj);
    amxd_trans_set_value(bool, &transaction, "Enable", false);
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    assert_str_attr_equal(homeplug_obj, "Status", "Disabled");

    interface_obj_2 = amxd_dm_findf(get_dm(), "HomePlug.Interface.2.");
    assert_non_null(interface_obj_2);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj_2);
    amxd_trans_set_value(bool, &transaction, "Enable", true);
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    assert_str_attr_equal(interface_obj_2, "Status", "Down");

}
void test_disable_homeplug_interface_when_homeplug_disable(UNUSED void** state) {
    amxd_object_t* interface_obj_1 = NULL;
    amxd_trans_t transaction;

    interface_obj_1 = amxd_dm_findf(get_dm(), "HomePlug.Interface.1.");
    assert_non_null(interface_obj_1);
    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj_1);
    amxd_trans_set_value(bool, &transaction, "Enable", false);
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    assert_str_attr_equal(interface_obj_1, "Status", "Down");

}
void test_add_interface_disable_when_homeplug_disable(UNUSED void** state) {
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_3 = NULL;
    amxd_trans_t transaction;

    interface_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.");
    assert_non_null(interface_obj);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(&transaction, 3, "device_3");
    amxd_trans_set_value(cstring_t, &transaction, "Name", "Device.IP.Interface.3.");
    amxd_trans_set_value(bool, &transaction, "Enable", false);
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    interface_obj_3 = amxd_dm_findf(get_dm(), "HomePlug.Interface.3.");
    assert_non_null(interface_obj_3);

    assert_str_attr_equal(interface_obj_3, "Status", "Down");

}
void test_add_interface_enable_when_homeplug_disable(UNUSED void** state) {
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_4 = NULL;
    amxd_trans_t transaction;

    interface_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.");
    assert_non_null(interface_obj);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(&transaction, 4, "device_4");
    amxd_trans_set_value(bool, &transaction, "Enable", true);
    amxd_trans_set_value(cstring_t, &transaction, "Name", "Device.IP.Interface.4.");
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    interface_obj_4 = amxd_dm_findf(get_dm(), "HomePlug.Interface.4.");
    assert_non_null(interface_obj_4);

    assert_str_attr_equal(interface_obj_4, "Status", "Down");

}
void test_add_interface_disable_when_homeplug_enable(UNUSED void** state) {
    amxd_trans_t transaction;
    amxd_object_t* homeplug_obj = NULL;
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_5 = NULL;

    homeplug_obj = amxd_dm_findf(get_dm(), "HomePlug.");
    assert_non_null(homeplug_obj);
    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, homeplug_obj);
    amxd_trans_set_value(bool, &transaction, "Enable", true);
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    assert_str_attr_equal(homeplug_obj, "Status", "Enabled");

    interface_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.");
    assert_non_null(interface_obj);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(&transaction, 5, "device_5");
    amxd_trans_set_value(bool, &transaction, "Enable", false);
    amxd_trans_set_value(cstring_t, &transaction, "Name", "Device.IP.Interface.5.");
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    interface_obj_5 = amxd_dm_findf(get_dm(), "HomePlug.Interface.5.");
    assert_non_null(interface_obj_5);

    assert_str_attr_equal(interface_obj_5, "Status", "Down");

}
void test_add_interface_enable_when_homeplug_enable(UNUSED void** state) {
    amxd_trans_t transaction;
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_6 = NULL;

    interface_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.");
    assert_non_null(interface_obj);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(&transaction, 6, "device_6");
    amxd_trans_set_value(bool, &transaction, "Enable", true);
    amxd_trans_set_value(cstring_t, &transaction, "Name", "Device.IP.Interface.6.");
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    interface_obj_6 = amxd_dm_findf(get_dm(), "HomePlug.Interface.6.");
    assert_non_null(interface_obj_6);

    assert_str_attr_equal(interface_obj_6, "Status", "Up");
}
void test_delete_interface(UNUSED void** state) {
    amxd_trans_t transaction;
    amxd_object_t* interface_obj = NULL;
    amxd_object_t* interface_obj_5 = NULL;

    interface_obj = amxd_dm_findf(get_dm(), "HomePlug.Interface.");
    assert_non_null(interface_obj);

    interface_obj_5 = amxd_dm_findf(get_dm(), "HomePlug.Interface.5.");
    assert_non_null(interface_obj_5);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, interface_obj);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_del_inst(&transaction, 0, "device_5");
    amxd_trans_apply(&transaction, get_dm());
    amxd_trans_clean(&transaction);

    handle_events();

    interface_obj_5 = amxd_dm_findf(get_dm(), "HomePlug.Interface.5.");
    assert_null(interface_obj_5);

}
