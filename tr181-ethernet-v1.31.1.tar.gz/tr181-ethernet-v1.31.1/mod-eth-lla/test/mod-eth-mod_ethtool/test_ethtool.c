/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <regex.h>
#include <linux/sockios.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "../../include_priv/mod_eth_lla.h"
#include "test_ethtool.h"

#define MOD_NAME "target_module"

static int test_call_linksettings_set(const char* name, const char* mode, int32_t bitrate) {
    int rv = -1;
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", name);
    amxc_var_add_key(cstring_t, &var, "duplex_mode", mode);
    amxc_var_add_key(int32_t, &var, "max_bit_rate", bitrate);
    rv = amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-settings-set", &var, &ret);

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
    return rv;
}

int test_setup(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, "../modules_under_test/target_module.so"), 0);
    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(amxm_close_all(), 0);
    return 0;
}

void test_linksettings_get(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-settings-get", &var, &ret), -1);

    // Enable set to false should also disable
    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    // eth0 should exist in set environment and return some data
    amxc_var_add_key(cstring_t, &var, "intf_name", "eth0");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-settings-get", &var, &ret), 0);
    assert_int_equal(GET_INT32(&ret, "current_bit_rate"), 10000);
    assert_non_null(GET_CHAR(&ret, "current_duplex_mode"));
    assert_string_equal(GET_CHAR(&ret, "current_duplex_mode"), "Full");

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}

void test_linksettings_set(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-settings-set", &var, &ret), -1);

    amxc_var_clean(&var);
    amxc_var_clean(&ret);

    // Names needs to be set to these values, determins the checks in the __wrap_ioctl
    assert_int_equal(test_call_linksettings_set("1000.FULL", "Full", 1000), 0);
    assert_int_equal(test_call_linksettings_set("100.HALF", "Half", 100), 0);
    assert_int_equal(test_call_linksettings_set("5000.AUTO", "Auto", 5000), 0);

}

// If the linksettings fails, link-settings-get should fall back on legacy GSET
void test_linksettings_get_fallback(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    // Enable set to false should also disable
    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    // eth0 should exist in set environment and return some data
    amxc_var_add_key(cstring_t, &var, "intf_name", "fallback_gset");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-settings-get", &var, &ret), 0);
    assert_int_equal(GET_INT32(&ret, "current_bit_rate"), 10000);
    assert_non_null(GET_CHAR(&ret, "current_duplex_mode"));
    assert_string_equal(GET_CHAR(&ret, "current_duplex_mode"), "Full");

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}

// If the linksettings fails, link-settings-set should fall back on legacy SSET
void test_linksettings_set_fallback(UNUSED void** state) {

    // Name needs to be set to this, determins the checks in the __wrap_ioctl
    // No speed_unknown, no supported speed set, should fail
    assert_int_equal(test_call_linksettings_set("speed_unknown", "Full", -1), -1);

    // Names needs to be set to these values, determins the checks in the __wrap_ioctl
    assert_int_equal(test_call_linksettings_set("speed_10", "Full", -1), 0);
    assert_int_equal(test_call_linksettings_set("speed_2500", "Full", -1), 0);
    assert_int_equal(test_call_linksettings_set("fallback_gset", "Half", 1000), 0);

}
void test_eee_get(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-get", &var, &ret), -1);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "unsupported");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-get", &var, &ret), 0);
    assert_false(GET_BOOL(&ret, "supported"));
    assert_false(GET_BOOL(&ret, "enabled"));
    assert_false(GET_BOOL(&ret, "active"));

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "disabled");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-get", &var, &ret), 0);
    assert_true(GET_BOOL(&ret, "supported"));
    assert_false(GET_BOOL(&ret, "enabled"));
    assert_false(GET_BOOL(&ret, "active"));

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "inactive");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-get", &var, &ret), 0);
    assert_true(GET_BOOL(&ret, "supported"));
    assert_true(GET_BOOL(&ret, "enabled"));
    assert_false(GET_BOOL(&ret, "active"));

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "active");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-get", &var, &ret), 0);
    assert_true(GET_BOOL(&ret, "supported"));
    assert_true(GET_BOOL(&ret, "enabled"));
    assert_true(GET_BOOL(&ret, "active"));

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}

void test_eee_set(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-set", &var, &ret), -1);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "disable");
    amxc_var_add_key(bool, &var, "eee_enable", false);
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-set", &var, &ret), 0);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "enable");
    amxc_var_add_key(bool, &var, "eee_enable", true);
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-eee-set", &var, &ret), 0);

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}

void test_edpd_get(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-get", &var, &ret), -1);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "unsupported");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-get", &var, &ret), 0);
    assert_false(GET_BOOL(&ret, "supported"));
    assert_false(GET_BOOL(&ret, "enabled"));

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "disabled");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-get", &var, &ret), 0);
    assert_true(GET_BOOL(&ret, "supported"));
    assert_false(GET_BOOL(&ret, "enabled"));

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "enabled");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-get", &var, &ret), 0);
    assert_true(GET_BOOL(&ret, "supported"));
    assert_true(GET_BOOL(&ret, "enabled"));

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}

void test_edpd_set(UNUSED void** state) {
    amxc_var_t var;
    amxc_var_t ret;

    amxc_var_init(&var);
    amxc_var_init(&ret);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-set", &var, &ret), -1);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "disable");
    amxc_var_add_key(bool, &var, "enable", false);
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-set", &var, &ret), 0);

    amxc_var_set_type(&var, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &var, "intf_name", "enable");
    amxc_var_add_key(bool, &var, "enable", true);
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_ETH_LLA_CTRL, "link-edpd-set", &var, &ret), 0);

    amxc_var_clean(&var);
    amxc_var_clean(&ret);
}