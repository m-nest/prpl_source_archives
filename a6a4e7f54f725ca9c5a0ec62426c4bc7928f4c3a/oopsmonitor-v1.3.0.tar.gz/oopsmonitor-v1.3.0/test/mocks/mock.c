/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "mock.h"
#include "oopsmonitor_priv.h"

#include <amxc/amxc_macros.h>
#include <string.h>
#include <setjmp.h>
#include <cmocka.h>

void* userdata = NULL;

int __wrap_amxm_execute_function(UNUSED const char* const shared_object_name,
                                 UNUSED const char* const module_name,
                                 const char* const func_name,
                                 UNUSED amxc_var_t* args,
                                 amxc_var_t* ret) {
    if((NULL != func_name) && (0 == strcmp(func_name, "get_process_ID"))) {
        amxc_var_add_key(cstring_t, ret, "process", "MOCKPROCESS");
        return 0;
    } else if((NULL != func_name) && (0 == strcmp(func_name, "get_last_instruction"))) {
        amxc_var_add_key(cstring_t, ret, "lastinstr", "mock_LR.part.11+0x42/0x42\n");
        return 0;
    } else if((NULL != func_name) && (0 == strcmp(func_name, "get_reason"))) {
        amxc_var_add_key(cstring_t, ret, "reason", "Reason is kernel NULL pointer dereference\n");
        return 0;
    } else if((NULL != func_name) && (0 == strcmp(func_name, "get_useful_log"))) {
        amxc_var_add_key(cstring_t, ret, "useful_log", "useful_log");
        return 0;
    }
    return 0;
}

int __wrap_amxm_so_open(UNUSED amxm_shared_object_t** so, UNUSED const char* shared_object_name, UNUSED const char* const path_to_so) {
    return 0;
}

int __wrap_amxb_call(UNUSED amxb_bus_ctx_t* const bus_ctx,
                     const char* object,
                     const char* method,
                     UNUSED amxc_var_t* args,
                     UNUSED amxc_var_t* ret,
                     UNUSED int timeout) {
    check_expected_ptr(object);
    check_expected_ptr(method);
    return 0;
}

static char* get_mocked_path(const char* path) {
    char* changed_path = NULL;
    amxc_string_t mocked_path;

    assert_non_null(path);
    amxc_string_init(&mocked_path, 0);
    amxc_string_setf(&mocked_path, "%s", path);
    amxc_string_replace(&mocked_path, "/data/oops", "mock_oopses", 1);
    changed_path = amxc_string_take_buffer(&mocked_path);

    amxc_string_clean(&mocked_path);
    return changed_path;
}

int __wrap_mkdir(const char* path, mode_t mode) {
    int res = -1;
    char* mocked_path = get_mocked_path(path);
    res = __real_mkdir(mocked_path, mode);

    free(mocked_path);
    return res;
}

int __wrap_stat(const char* path, struct stat* buf) {
    int res = -1;
    char* mocked_path = get_mocked_path(path);
    res = __real_stat(mocked_path, buf);

    free(mocked_path);
    return res;
}

int __wrap_remove(const char* pathname) {
    int res = -1;
    char* mocked_path = get_mocked_path(pathname);
    res = __real_remove(mocked_path);

    free(mocked_path);
    return res;
}

int __wrap_fopen(const char* path, const char* mode) {
    int res = -1;
    char* mocked_path = get_mocked_path(path);
    res = __real_fopen(mocked_path, mode);

    free(mocked_path);
    return res;
}

int __wrap_ftx_request_send(ftx_request_t* req) {
    upload_cb(req, userdata);
    return 0;
}

int __wrap_ftx_request_set_target_file(UNUSED ftx_request_t* request, const char* file_path) {
    check_expected_ptr(file_path);
    return 0;
}

int __wrap_ftx_request_set_data(UNUSED ftx_request_t* request, void* data) {
    userdata = data;
    return 0;
}

int __wrap_ftx_request_set_http_multipart_form_data(UNUSED ftx_request_t* request,
                                                    const char* const part_name,
                                                    const char* const part_filename,
                                                    const char* const mime_type) {
    assert_string_equal(part_name, "file");
    assert_string_equal(mime_type, "application/octet-stream");
    check_expected_ptr(part_filename);
    return 0;
}