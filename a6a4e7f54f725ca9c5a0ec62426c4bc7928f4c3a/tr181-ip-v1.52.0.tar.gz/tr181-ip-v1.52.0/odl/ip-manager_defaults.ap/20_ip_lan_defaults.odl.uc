%populate {
    object IP.Interface.lan {
        parameter Enable = true;
        parameter IPv4Enable = true;
        parameter IPv6Enable = true;
        parameter ULAEnable = false;
        parameter UCISectionNameIPv4 = "";
        parameter UCISectionNameIPv6 = "";
        parameter MaxMTUSize = 1500;
        parameter Type = "Normal";
        parameter Loopback = false;
        parameter LowerLayers = "Device.Ethernet.Link.2";
        parameter UpLink = true;
    }
    object IP.Interface.lan.IPv4Address {
        instance add("primary") {
            parameter Enable = true;
            parameter AddressingType = "DHCP";
        }
    }
    object IP.Interface.lan.IPv6Prefix {
        instance add ("GUA_RA") {
            parameter Enable = true;
            parameter Origin = "RouterAdvertisement";
            parameter StaticType = "Inapplicable";
        }
    }
    object IP.Interface.lan.IPv6Address {
        instance add ("GUA_RA") {
            parameter Enable = true;
            parameter Origin = "AutoConfigured";
            parameter Prefix = "${ip_intf_lan}IPv6Prefix.1";
        }
        instance add("DHCP") {
            parameter Enable = true;
            parameter Origin = "DHCPv6";
            parameter InterfaceIDType = "None";
        }
    }
}
