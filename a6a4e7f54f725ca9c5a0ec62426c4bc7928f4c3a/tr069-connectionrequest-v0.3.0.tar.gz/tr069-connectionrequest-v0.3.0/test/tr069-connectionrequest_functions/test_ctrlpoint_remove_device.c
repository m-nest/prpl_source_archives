/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "test_helpers.h"

extern void CtrlPointRemoveDevice(const char* UDN);
extern UpnpClient_Handle gCtrlptHandle;

/* Wrappers */
int __wrap_UpnpUnSubscribe(int handle, const char* sid);

int __wrap_UpnpUnSubscribe(int handle, const char* sid) {
    check_expected(handle);
    check_expected_ptr(sid);
    return mock_type(int);
}

/* Helpers */
static void set_igd_state(const char* udn, int updated, int active_service, const char* sid) {
    memset(&IGD, 0, sizeof(IGD));
    if(udn) {
        strncpy(IGD.UDN, udn, sizeof(IGD.UDN) - 1);
    }
    IGD.Updated = updated;
    IGD.ActiveService = active_service;
    if(sid) {
        strncpy(IGD.Service[active_service].SID, sid,
                sizeof(IGD.Service[active_service].SID) - 1);
    }
}

/* Tests */
static void test_remove_device_unsubscribe_success(UNUSED void** state) {
    gCtrlptHandle = 100;
    set_igd_state("uuid:ok", 1, 0, "sid-123");

    expect_value(__wrap_UpnpUnSubscribe, handle, gCtrlptHandle);
    expect_string(__wrap_UpnpUnSubscribe, sid, "sid-123");
    will_return(__wrap_UpnpUnSubscribe, 0);

    CtrlPointRemoveDevice("uuid:ok");
    assert_int_equal(IGD.Updated, 0);
}

static void test_remove_device_unsubscribe_fail(UNUSED void** state) {
    gCtrlptHandle = 200;
    set_igd_state("uuid:fail", 1, 0, "sid-fail");

    expect_value(__wrap_UpnpUnSubscribe, handle, gCtrlptHandle);
    expect_string(__wrap_UpnpUnSubscribe, sid, "sid-fail");
    will_return(__wrap_UpnpUnSubscribe, 501);

    CtrlPointRemoveDevice("uuid:fail");
    assert_int_equal(IGD.Updated, 1);
}

static void test_remove_device_no_sid(UNUSED void** state) {
    gCtrlptHandle = 300;
    set_igd_state("uuid:no-sid", 1, 0, "");

    CtrlPointRemoveDevice("uuid:no-sid");
    assert_int_equal(IGD.Updated, 1);
}

static void test_remove_device_udn_mismatch(UNUSED void** state) {
    gCtrlptHandle = 400;
    set_igd_state("uuid:other", 1, 0, "sid-present");

    CtrlPointRemoveDevice("uuid:not-matching");
    assert_int_equal(IGD.Updated, 1);
}

const struct CMUnitTest g_remove_device_tests[] = {
    cmocka_unit_test(test_remove_device_unsubscribe_success),
    cmocka_unit_test(test_remove_device_unsubscribe_fail),
    cmocka_unit_test(test_remove_device_no_sid),
    cmocka_unit_test(test_remove_device_udn_mismatch),
};
const size_t g_remove_device_tests_count =
    sizeof(g_remove_device_tests) / sizeof(g_remove_device_tests[0]);
