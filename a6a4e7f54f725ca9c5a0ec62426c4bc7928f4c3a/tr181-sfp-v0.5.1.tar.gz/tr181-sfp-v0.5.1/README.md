# TR181 compatible SFP Manager

[[_TOC_]]

# Introduction

## Purpose

`tr181-sfp` is the generic part of the TR-181 SFP manager. It also includes a module to determine the SFP type: `mod-sfp-type`. Projects can use another module if needed.

## Abbreviations

| Abbreviation | Meaning             |
| :----------- | :------------------ |
| DM           | data model          |

## References

| Name           | Link                |
| :------------- | :------------------ |
| odl-generator  | https://gitlab.com/prpl-foundation/components/utilities/odl-generator |


## Installation

You can build and install the SFP Manager by running
```
make && sudo make install
```

### compile and install

```
make
sudo make install
```

### run test

```
make test
```

### run plugin inside a Ambiorix Docker container
Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

compile/install dependencies: (make + sudo make install)

 * libsahtrace
 * libamxb
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxj

### run dependencies

 * amxrt
 * mod-sfp-discovery

### activate SFP Server plugin
```
/etc/init.d/tr181-sfpmgr start
```

## General requirements
* TR-181 proposed Data Model implementation
* Separation of “Cage/SFP discovery”
* Abstraction of “LL API” for interfacing with GPIO where it is needed
* Optical Interface instantiation when “P2P Fiber” SFP is installed
* Device.SFPs.Cage.SFP reference to XPON, Optical & ethernet

## Implementation
The TR-181 SFP manager hosts the core HL-API implementation.
The implementation abstracts the diversity in SFP discovery operation through a module component called SFP-Discovery.
The SFP manager interacts with ethtool user plane application to retrieve status about the SFP manager and presents the data in the data objects.
An SFP LL API instance agent can be optionally employed to manage the SFP Tx Enable or RX LOS detection through GPIO where desired.

### Support for Device.Optical
* Supports Optical Ethernet Interface
* Handles enable/disable of Device.Optical Interface.
* Handles interface statistics via mod-dm-stats

### Mod Implementation Details
* SFP Main - creates SFP objects on every reboot, Updates SFP data model information (including digital diagostics)  from the periodic data polled from ethtool.
  Optical IF Management, On discovery of P2P Fiber SFP, populates Device.Optical.Interface data elements,  retrieves and presents the Tx / Rx Laser power
* MOD-SFP-DISCOVERY - This is provided as a dummy agent which is responsible for gathering information on SFP Cage and SFP Dev Info, notifies the SFP Main about the SFP cages, polls for SFP presence, SFP Type
  and announces SFP insert/removal/rx los conditions to the main process
* An SFP LL API instance agent can be optionally employed to manage the SFP Tx Enable or RX LOS detection through GPIO where desired.

### Populate DM

This `tr181-sfp` repo has the file `tr181-sfp_defaults.odl.uc`. An image runs the script `99build_default_odl.sh` from the package `odl-generator` (see [odl-generator]) to transform it to `tr181-sfp_defaults.odl`. `tr181-sfp` loads `tr181-sfp_defaults.odl` at startup. `99build_default_odl.sh` uses `/etc/networklayout.json` to transform the `.odl.uc` files to `.odl` files. `networklayout.json` must include info about the SFP cages. E.g. if the board has 1 SFP cage, the section `Interfaces` might have following entry:

```
    {"Alias": "ETH1","Name": "eth1","Type": "ethernet","Upstream": "true","SFPCage": "1","SFPSupportedType": "Electrical Ethernet,G-PON"},
```

The resulting `tr181-sfp_defaults.odl` file will instantiate 3 DM objects:
- `SFPs.SFPCage.1.`
- `SFPs.Mgmt.SFF8472.1.`
- `Optical.Interface.1.`


## Interactions with other plugins
### WAN Manager
The wan-manager and auto-sensing functionality relies on SFP Presence state from the datamodel and also crucial in making decision in wan-modes.

### Ethernet Manager
The copper Ethernet SFP presence is announced to the ethernet manager. The ethernet manager instantiates (init or runtine) an Ethernet.Interface.{i}. object upon the event.

## On Startup
SFP Manager Main starts the discovery timer in discovery mod, which periodically checks for change of state in SFP (present, remove, rx-los).
Once the state is determined the appropriate mod functions are executed to update the data model for static parameters of SFP.
Another Poll timer from SFP Main keeps polling for DDM Data updation from Ethtool and updates the Data model.

### Low-Level API (MOD-LLAPI optionally provided)

* Ethtool for SFP MSA parameter retrieval
* I2C for SFP presence, and SFP Type detection during boot
* Optional – GPIO for TxEn,RxLoS,TxFault
