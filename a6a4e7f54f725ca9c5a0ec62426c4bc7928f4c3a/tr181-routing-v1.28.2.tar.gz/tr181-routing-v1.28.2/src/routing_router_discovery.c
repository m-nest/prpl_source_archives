/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>

#include "routing_route_information.h"
#include "routing_router_discovery.h"
#include "routing_manager.h"

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxb/amxb.h>

/**********************************************************
* Functions
**********************************************************/

static const char* skip_prefix(const char* path) {
    const char* prefix = "Device.";
    size_t len = strlen(prefix);

    when_str_empty(path, exit);

    if(strncmp(path, prefix, len) == 0) {
        path += len;
    }
exit:
    return path;
}

void _default_router_status_changed(UNUSED const char* const event_name,
                                    const amxc_var_t* const event_data,
                                    UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);

    amxd_object_t* interface = amxd_dm_signal_get_object(routing_manager_get_dm(), event_data);
    char* ip_interface = NULL;
    int rv = -1;
    amxb_bus_ctx_t* ctx = NULL;
    when_null(interface, exit);

    ip_interface = amxd_object_get_value(cstring_t, interface, "Interface", NULL);
    when_str_empty_trace(ip_interface, exit, ERROR, "Empty IP interface for interfacesetting %s",
                         amxd_object_get_name(interface, AMXD_OBJECT_NAMED));

    ctx = amxb_be_who_has("IP.");
    when_null_trace(ctx, exit, ERROR, "Unable to find bus providing IP.");

    rv = amxb_call(ctx, skip_prefix(ip_interface), "ToggleIPv6", NULL, NULL, 5);
    when_failed_trace(rv, exit, ERROR, "Failed to call 'ToggleIPv6()' for interface %s", ip_interface);

exit:
    free(ip_interface);
    SAH_TRACEZ_OUT(ME);
    return;
}