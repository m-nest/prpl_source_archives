/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <net/if.h>
#include <netlink/netlink.h>
#include <netlink/route/route.h>
#include <netlink/route/addr.h>
#include <ipat/ipat_text.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include "mod_routing_lin.h"
#define ME "mod-routing"

#define IPV6_ROUTE_TYPE_NORMAL "Normal"
#define IPV6_ROUTE_TYPE_RECEIVE "Receive"
#define IPV6_ROUTE_TYPE_BLACKHOLE "Blackhole"
#define IPV6_ROUTE_TYPE_UNREACHABLE "Unreachable"
#define IPV6_ROUTE_TYPE_PROHIBIT "Prohibit"
#define IPV6_ROUTE_TYPE_ANYCAST "Anycast"
#define IPV6_ROUTE_TYPE_MULTICAST "Multicast"

static int str_to_route_type(const cstring_t str) {
    int type = RTN_UNSPEC;

    when_null(str, exit);
    if(strcmp(str, IPV6_ROUTE_TYPE_NORMAL) == 0) {
        type = RTN_UNICAST;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_RECEIVE) == 0) {
        type = RTN_LOCAL;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_BLACKHOLE) == 0) {
        type = RTN_BLACKHOLE;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_UNREACHABLE) == 0) {
        type = RTN_UNREACHABLE;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_PROHIBIT) == 0) {
        type = RTN_PROHIBIT;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_ANYCAST) == 0) {
        type = RTN_ANYCAST;
    } else if(strcmp(str, IPV6_ROUTE_TYPE_MULTICAST) == 0) {
        type = RTN_MULTICAST;
    }
exit:
    return type;
}

// The return value is a newly allocated string that should be freed by the caller
static cstring_t ip_to_prefix(const cstring_t addr, const cstring_t subnet_mask) {
    amxc_string_t ip;
    cstring_t prefix = NULL;

    when_str_empty(addr, exit);
    if(str_empty(subnet_mask)) {
        prefix = strdup(addr);
        goto exit;
    }

    amxc_string_init(&ip, 0);
    amxc_string_setf(&ip, "%s/%s", addr, subnet_mask);

    prefix = ipat_text_to_subnet(amxc_string_get(&ip, 0));

    amxc_string_clean(&ip);
exit:
    return prefix;
}

// The return value is a newly allocated string that should be freed by the caller
static cstring_t get_dest_ip(const amxc_var_t* data) {
    cstring_t dest_ip = NULL;

    if(GET_ARG(data, "DestIPPrefix") != NULL) {
        if(!str_empty(GET_CHAR(data, "DestIPPrefix"))) {
            dest_ip = strdup(GET_CHAR(data, "DestIPPrefix"));
        } else {
            // DestIPPrefix is empty string so match all prefixes
            dest_ip = strdup("::/0");
        }
    } else if((GET_ARG(data, "DestIPAddress") != NULL)) {
        if(str_empty(GET_CHAR(data, "DestIPAddress")) && str_empty(GET_CHAR(data, "DestSubnetMask"))) {
            // if both DestIPAddress and DestSubnetMask are empty, this route is a default route
            dest_ip = strdup("0.0.0.0/0");
        } else {
            dest_ip = ip_to_prefix(GET_CHAR(data, "DestIPAddress"), GET_CHAR(data, "DestSubnetMask"));
        }
    }
    return dest_ip;
}

static const cstring_t get_gateway(const amxc_var_t* data) {
    const cstring_t gateway = GET_CHAR(data, "GatewayIPAddress");

    if(gateway == NULL) {
        gateway = GET_CHAR(data, "NextHop");
    }
    return gateway;
}

static void route_set_intf(struct rtnl_nexthop* nexthop, const cstring_t if_name) {
    if(!str_empty(if_name)) {
        int index = if_nametoindex(if_name);
        if(index != 0) {
            rtnl_route_nh_set_ifindex(nexthop, index);
        } else {
            SAH_TRACEZ_ERROR(ME, "Could not get index for interface %s", if_name);
        }
    }
}

static void route_set_forwarding_metric(struct rtnl_route* route, int32_t forwarding_metric) {
    if(forwarding_metric > 0) {
        /* ForwardingMetric is an int32 which is either -1 (metric not to be used) or a positive integer. */
        rtnl_route_set_priority(route, forwarding_metric);
    }
}

static void route_set_gateway(struct rtnl_nexthop* nexthop, const cstring_t gateway, bool ipv6) {
    if(!str_empty(gateway)) {
        struct nl_addr* gw_addr = NULL;
        if(nl_addr_parse(gateway, ipv6 ? AF_INET6 : AF_INET, &gw_addr) < 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse %s address %s", ipv6 ? "IPv6" : "IPv4", gateway);
        } else {
            rtnl_route_nh_set_gateway(nexthop, gw_addr);
        }
    }
}

static void route_set_dst_addr(struct rtnl_route* route, const cstring_t dst_addr, bool ipv6) {
    if(dst_addr != NULL) {
        struct nl_addr* dest = NULL;
        if(nl_addr_parse(dst_addr, ipv6 ? AF_INET6 : AF_INET, &dest) < 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse %s address %s", ipv6 ? "IPv6" : "IPv4", dst_addr);
        } else {
            when_failed_trace(rtnl_route_set_dst(route, dest), exit, ERROR, "Failed to set %s as destination address for route", dst_addr);
        }
    }
exit:
    return;
}

static void route_set_src_pref(struct rtnl_route* route, const cstring_t src_pref, bool ipv6) {
    if(!str_empty(src_pref)) {
        struct nl_addr* src = NULL;
        if(nl_addr_parse(src_pref, ipv6 ? AF_INET6 : AF_INET, &src) < 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse %s prefix %s", ipv6 ? "IPv6" : "IPv4", src_pref);
        } else {
            when_failed_trace(rtnl_route_set_src(route, src), exit, ERROR, "Failed to set %s as source prefix for route", src_pref);
        }
    }
exit:
    return;
}

static int route_set_type(struct rtnl_route* route, int type) {
    int rv = 0;
    if(type != RTN_UNSPEC) {
        rv = rtnl_route_set_type(route, type);
    }
    return rv;
}

static void route_set_mtu(struct rtnl_route* route, uint32_t mtu) {
    if(mtu > 0) {
        rtnl_route_set_metric(route, RTAX_MTU, mtu);
    }
}

struct nl_sock* init_netlink_socket(void) {
    struct nl_sock* sock = nl_socket_alloc();

    when_null_trace(sock, exit, ERROR, "Failed to allocate netlink socket");
    if(nl_connect(sock, NETLINK_ROUTE) < 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to connect to netlink protocol");
        nl_socket_free(sock);
        sock = NULL;
    }
exit:
    return sock;
}

static struct rtnl_route* init_route(void) {
    struct rtnl_route* route = rtnl_route_alloc();
    struct rtnl_nexthop* nexthop = NULL;

    when_null_trace(route, exit, ERROR, "Failed to allocate route");

    nexthop = rtnl_route_nh_alloc();
    if(nexthop == NULL) {
        rtnl_route_put(route);
        route = NULL;
        SAH_TRACEZ_ERROR(ME, "Failed to allocate nexthop");
        goto exit;
    }
    rtnl_route_add_nexthop(route, nexthop);
exit:
    return route;
}

static int nl_routing_action(const amxc_var_t* data, unsigned short action_type) {
    struct nl_sock* sock = NULL;
    struct rtnl_route* route = NULL;
    struct rtnl_nexthop* nexthop = NULL;
    const cstring_t if_name = GET_CHAR(data, "interface_name");
    const cstring_t gateway = get_gateway(data);
    const cstring_t src_pref = GET_CHAR(data, "SourceIPPrefix");
    cstring_t dst_addr = get_dest_ip(data);
    const uint32_t mtu = GET_UINT32(data, "MTU");
    bool ipv6 = (IPV6 == ((ipvx_t) GET_UINT32(data, "IPVx")));
    int rv = -1;

    when_true_trace((str_empty(if_name) && str_empty(gateway)), exit, WARNING, "Not possible to add route without either interface or gateway configured");

    sock = init_netlink_socket();
    when_null_trace(sock, exit, ERROR, "Failed to initialize netlink socket");

    route = init_route();
    when_null_trace(route, exit, ERROR, "Failed to allocate route object");
    nexthop = rtnl_route_nexthop_n(route, 0);

    route_set_intf(nexthop, if_name);
    route_set_forwarding_metric(route, GET_INT32(data, "ForwardingMetric"));
    route_set_gateway(nexthop, gateway, ipv6);
    route_set_src_pref(route, src_pref, ipv6);
    route_set_dst_addr(route, dst_addr, ipv6);
    when_failed_trace(route_set_type(route, str_to_route_type(GET_CHAR(data, "Type"))), exit, ERROR, "Failed to set route type to %s", GET_CHAR(data, "Type"));
    rtnl_route_set_table(route, GET_UINT32(data, "ID"));
    route_set_mtu(route, mtu);

    SAH_TRACEZ_INFO(ME, "%s IPv%d route with device %s, gateway %s, source prefix %s, destination %s, type %s, table %u, mtu %d, metric %d",
                    (action_type == RTM_NEWROUTE ? "Add" : "Delete"), ipv6 ? 6 : 4, if_name, gateway, src_pref, dst_addr,
                    GET_CHAR(data, "Type"), GET_UINT32(data, "ID"), mtu, GET_INT32(data, "ForwardingMetric"));

    if(action_type == RTM_NEWROUTE) {
        rv = rtnl_route_add(sock, route, NLM_F_CREATE);
        when_true_trace(rv < 0, exit, ERROR, "Failed to add route with error %s", nl_geterror(rv));
    } else if(action_type == RTM_DELROUTE) {
        rv = rtnl_route_delete(sock, route, 0);
        when_true_trace(rv < 0, exit, ERROR, "Failed to delete route with error %s", nl_geterror(rv));
    }
    rv = 0;
exit:
    free(dst_addr);
    if(route != NULL) {
        nl_addr_put(rtnl_route_get_dst(route));
        nl_addr_put(rtnl_route_get_src(route));
    }
    if(nexthop != NULL) {
        nl_addr_put(rtnl_route_nh_get_gateway(nexthop));
    }
    rtnl_route_put(route);
    nl_socket_free(sock);
    return rv;
}

int nl_route_add(const amxc_var_t* data) {
    SAH_TRACEZ_IN(ME);
    int rv = nl_routing_action(data, RTM_NEWROUTE);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

int nl_route_del(const amxc_var_t* data) {
    SAH_TRACEZ_IN(ME);
    int rv = nl_routing_action(data, RTM_DELROUTE);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
