/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#include <stdio.h>
#include <setjmp.h>
#include <cmocka.h>

#include "test_lan_api.h"

int main(void) {
    const char* invalid_IP1 = "invalid.ip.addr";
    const char* invalid_IP2 = "2001:db8:3333:4444:5555:6666:7777:8888";
    const char* invalid_IP3 = "";

    const char* invalid_subnet1 = "255.255.255.255";
    const char* invalid_subnet2 = "255.255.255.254";
    const char* invalid_subnet3 = "255.255.255.253";

    const struct CMUnitTest tests[] = {
        // call parameters context tests
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_no_pool, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_no_ip, test_setup, test_teardown),

        // Input parameter dedicated tests
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_ip_address, test_setup, test_teardown, &invalid_IP1),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_ip_address, test_setup, test_teardown, &invalid_IP2),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_ip_address, test_setup, test_teardown, &invalid_IP3),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_ip_address, test_setup, test_teardown, NULL),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_IP1),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_IP2),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_IP3),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, NULL),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_subnet1),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_subnet2),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_subnet_mask, test_setup, test_teardown, &invalid_subnet3),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_min_address, test_setup, test_teardown, &invalid_IP1),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_min_address, test_setup, test_teardown, &invalid_IP2),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_min_address, test_setup, test_teardown, &invalid_IP3),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_min_address, test_setup, test_teardown, NULL),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_max_address, test_setup, test_teardown, &invalid_IP1),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_max_address, test_setup, test_teardown, &invalid_IP2),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_max_address, test_setup, test_teardown, &invalid_IP3),
        cmocka_unit_test_prestate_setup_teardown(test_SetIPv4Config_invalid_max_address, test_setup, test_teardown, NULL),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_not_allowed_IANA_subnet, test_setup, test_teardown),

        // Network range tests
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_min_address_not_in_subnet, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_max_address_not_in_subnet, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_min_greater_than_max, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_ip_in_range, test_setup, test_teardown),

        // Reserved address tests
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_ip_in_reserved, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_min_in_reserved, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_max_in_reserved, test_setup, test_teardown),

        // Special address tests
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_ip_is_subnet_address, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_min_is_subnet_address, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_max_is_broadcast_address, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_allowed_IANA_subnet_10, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_SetIPv4Config_allowed_IANA_subnet_172, test_setup, test_teardown),

        cmocka_unit_test_setup_teardown(test_private_ipv4_config, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_alternative_ipv4_config, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_ipv4_config_ext, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_ipv6_config, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_lower_layer_config, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_domain_search_list, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_domain_name, test_setup, test_teardown),
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
