/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "test_populate_at_startup.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <stdio.h>   /* snprintf() */
#include <string.h>  /* strcmp() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>           /* needed by amxd_dm.h */
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxm/amxm.h>                  /* amxm_module_t */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param() */

/* Own headers */
#include "common_functions.h"   /* read_sig_alarm() */
#include "setup_and_teardown.h" /* setup_common() */
#include "xpon_macros.h"        /* ARRAY_SIZE() */
#include "xpon_trace.h"

#define MOD_PON_CTRL "pon_ctrl"

#undef ME
#define ME "runtest"

static amxd_dm_t dm;
static amxo_parser_t parser;
static amxm_module_t* s_pon_ctrl_module = NULL;

int test_setup(UNUSED void** state) {
    return setup_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

int test_teardown(UNUSED void** state) {
    return teardown_common(&dm, &parser, /*invoke_main_entry_point=*/ true);
}

static uint32_t s_cntr_get_list_of_instances = 0;

static int get_list_of_instances(UNUSED const char* function_name,
                                 amxc_var_t* args,
                                 amxc_var_t* ret) {
    char indexes[8];
    indexes[0] = 0;
    assert_non_null(args);
    assert_non_null(ret);
    const char* const path = amxc_var_constcast(cstring_t, args);
    assert_non_null(path);
    SAH_TRACEZ_DEBUG(ME, "path='%s'", path);
    if((strcmp(path, "XPON.ONU") == 0) ||
       (strcmp(path, "XPON.ONU.1.EthernetUNI") == 0) ||
       (strcmp(path, "XPON.ONU.1.ANI") == 0)) {
        snprintf(indexes, 8, "%d", 1);
    } else if(strcmp(path, "XPON.ONU.1.SoftwareImage") == 0) {
        snprintf(indexes, 8, "%d,%d", 1, 2);
    }
    SAH_TRACEZ_INFO(ME, "%s: indexes='%s'", path, indexes);
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_t* const indexes_var = amxc_var_add_key(cstring_t, ret, "indexes", indexes);
    assert_non_null(indexes_var);
    ++s_cntr_get_list_of_instances;
    return 0;
}

static const char* const NAME_PARAMETER = "Name";
static const char* const ONU_NAME = "ONU.1";
static const char* const ETHERNET_UNI_NAME = "ETHUNI.1";
static const char* const ANI_NAME = "ANI.1";

static int get_object_content(UNUSED const char* function_name,
                              amxc_var_t* args,
                              amxc_var_t* ret) {

    assert_non_null(args);
    assert_non_null(ret);
    assert_true(amxc_var_type_of(args) == AMXC_VAR_ID_HTABLE);
    const char* const path = GET_CHAR(args, "path");
    assert_non_null(path);
    const uint32_t index = GET_UINT32(args, "index");
    SAH_TRACEZ_DEBUG(ME, "path='%s' index=%d", path, index);
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_t* keys = amxc_var_add_key(amxc_htable_t, ret, "keys", NULL);
    assert_non_null(keys);
    amxc_var_t* var = NULL;
    char name[16];
    uint32_t id;
    if((strcmp(path, "XPON.ONU") == 0) && (1 == index)) {
        snprintf(name, sizeof(name), "%s", ONU_NAME);
        var = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, name);
        assert_non_null(var);
    } else if((strcmp(path, "XPON.ONU.1.EthernetUNI") == 0) && (1 == index)) {
        snprintf(name, sizeof(name), "%s", ETHERNET_UNI_NAME);
        var = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, name);
        assert_non_null(var);
    } else if((strcmp(path, "XPON.ONU.1.ANI") == 0) && (1 == index)) {
        snprintf(name, sizeof(name), "%s", ANI_NAME);
        var = amxc_var_add_key(cstring_t, keys, NAME_PARAMETER, name);
        assert_non_null(var);
    } else if((strcmp(path, "XPON.ONU.1.SoftwareImage") == 0) && (1 == index)) {
        id = 0;
        var = amxc_var_add_key(uint32_t, keys, "ID", id);
        assert_non_null(var);
    } else if((strcmp(path, "XPON.ONU.1.SoftwareImage") == 0) && (2 == index)) {
        id = 1;
        var = amxc_var_add_key(uint32_t, keys, "ID", id);
        assert_non_null(var);
    } else {
        SAH_TRACEZ_WARNING(ME, "path='%s' index=%d: no content", path, index);
    }
    return 0;
}

typedef struct _func_info {
    const char* const name;
    amxm_callback_t cb;
} func_info_t;

static const func_info_t MOD_PON_CTRL_FUNCS[] = {
    { .name = "get_list_of_instances", .cb = get_list_of_instances },
    { .name = "get_object_content", .cb = get_object_content }
};

static const char* const PATH_TO_GEM_PORT_OBJECT = "XPON.ONU.1.ANI.1.TC.GEM.Port";
static const uint32_t GEM_PORT_TEST_INDEX = 1;
static const uint32_t GEM_PORT_ID_TEST_VALUE = 1;

typedef struct _gem_port_properties {
    const char* direction;
    const char* port_type;
} gem_port_properties_t;

static const gem_port_properties_t GEM_PORT_TEST_VALUES[3] = {
    { .direction = "ANI-to-UNI", .port_type = "multicast" },
    { .direction = "bidirectional", .port_type = "unicast" },
    { .direction = "UNI-to-ANI", .port_type = "broadcast" }
};

static void gem_port_add_path_index_and_port_id_key(amxc_var_t* htable) {

    const amxc_var_t* const path =
        amxc_var_add_key(cstring_t, htable, "path", PATH_TO_GEM_PORT_OBJECT);
    assert_non_null(path);

    const amxc_var_t* const index =
        amxc_var_add_key(uint32_t, htable, "index", GEM_PORT_TEST_INDEX);
    assert_non_null(index);

    amxc_var_t* const keys = amxc_var_add_key(amxc_htable_t, htable, "keys", NULL);
    assert_non_null(keys);

    const amxc_var_t* const port_id =
        amxc_var_add_key(uint32_t, keys, "PortID", GEM_PORT_ID_TEST_VALUE);
    assert_non_null(port_id);
}

static void test_gem_port(const char* function, const gem_port_properties_t* gem_port) {

    int rc;
    amxc_var_t args;
    amxc_var_t value;
    amxc_var_init(&args);
    amxc_var_init(&value);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    gem_port_add_path_index_and_port_id_key(&args);

    amxc_var_t* const params = amxc_var_add_key(amxc_htable_t, &args, "parameters", NULL);
    assert_non_null(params);
    const amxc_var_t* const direction =
        amxc_var_add_key(cstring_t, params, "Direction", gem_port->direction);
    assert_non_null(direction);
    const amxc_var_t* const port_type =
        amxc_var_add_key(cstring_t, params, "PortType", gem_port->port_type);
    assert_non_null(port_type);

    rc = call_xpon_mngr_pon_stat_function(function, &args);
    assert_int_equal(rc, 0);

    char path_gem_port[128];
    rc = snprintf(path_gem_port, 128, "%s.%d", PATH_TO_GEM_PORT_OBJECT, GEM_PORT_TEST_INDEX);
    assert_true(rc != -1 && rc < 128);
    amxd_object_t* const obj = amxd_dm_findf(&dm, path_gem_port);
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, "PortID", &value), amxd_status_ok);
    assert_int_equal(GET_UINT32(&value, NULL), GEM_PORT_ID_TEST_VALUE);
    assert_int_equal(amxd_object_get_param(obj, "Direction", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), gem_port->direction);
    assert_int_equal(amxd_object_get_param(obj, "PortType", &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), gem_port->port_type);

    amxc_var_clean(&args);
    amxc_var_clean(&value);

}

static void add_one_gem_port(void) {
    SAH_TRACEZ_INFO(ME, "** add_one_gem_port() **");
    const gem_port_properties_t* gem_port = &GEM_PORT_TEST_VALUES[0];
    test_gem_port("dm_instance_added", gem_port);
}

static void update_gem_port_with_dm_add_or_change_instance(void) {

    SAH_TRACEZ_INFO(ME, "** update_gem_port_with_dm_add_or_change_instance() **");
    const gem_port_properties_t* gem_port = &GEM_PORT_TEST_VALUES[1];
    test_gem_port("dm_add_or_change_instance", gem_port);
}

static void update_gem_port_with_dm_object_changed(void) {
    SAH_TRACEZ_INFO(ME, "** update_gem_port_with_dm_object_changed() **");
    const gem_port_properties_t* gem_port = &GEM_PORT_TEST_VALUES[2];
    test_gem_port("dm_object_changed", gem_port);
}

static void remove_instance(const char* path, uint32_t index) {

    amxc_var_t args;

    SAH_TRACEZ_INFO(ME, "** remove_instance(%s.%d) **", path, index);

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    const amxc_var_t* const path_var =
        amxc_var_add_key(cstring_t, &args, "path", path);
    assert_non_null(path_var);

    const amxc_var_t* const index_var =
        amxc_var_add_key(uint32_t, &args, "index", index);
    assert_non_null(index_var);

    const int rc = call_xpon_mngr_pon_stat_function("dm_instance_removed", &args);
    assert_int_equal(rc, 0);

    char full_path[64];
    snprintf(full_path, 64, "%s.%d", path, index);
    amxd_object_t* obj = amxd_dm_findf(&dm, full_path);
    assert_null(obj);

    amxc_var_clean(&args);
}

static void remove_all_dm_instances(void) {

    SAH_TRACEZ_INFO(ME, "** remove_all_dm_instances() **");
    remove_instance("XPON.ONU.1.ANI", 1);
    remove_instance("XPON.ONU.1.EthernetUNI", 1);
    remove_instance("XPON.ONU.1.SoftwareImage", 1);
    remove_instance("XPON.ONU.1.SoftwareImage", 2);
}

/**
 * Test that tr181-xpon populates the XPON DM at startup.
 *
 * This tests the functionality in populate_dm_startup.c.
 *
 * The test goes a bit further. Once the XPON DM is populated:
 * - it adds and updates an XPON.ONU.1.ANI.1.TC.GEM.Port instance
 * - it removes (all) instances which were added during the population step.
 */
void test_populate_at_startup(UNUSED void** state) {
    int i;
    int rc;
    amxc_var_t value;
    amxc_var_init(&value);

    /**
     * Normally the vendor module has a namespace MOD_PON_CTRL with functions
     * such as get_list_of_instances() and get_object_content(). The dummy
     * vendor module has the namespace, but it does not have those 2 functions.
     * Add those 2 functions to the namespace. Then it appears to tr181-xpon as
     * if the vendor module has those functions. tr181-xpon calls those
     * functions to build up the XPON DM at startup.
     */
    amxm_module_t* const pon_ctrl_module = amxm_get_module("mod-xpon-dummy", MOD_PON_CTRL);
    assert_non_null(pon_ctrl_module);

    const int n_functions = ARRAY_SIZE(MOD_PON_CTRL_FUNCS);
    for(i = 0; i < n_functions; ++i) {
        rc = amxm_module_add_function(pon_ctrl_module, MOD_PON_CTRL_FUNCS[i].name,
                                      MOD_PON_CTRL_FUNCS[i].cb);
        assert_int_equal(rc, 0);
    }
    /* Call read_sig_alarm() to trigger timer which calls query_onu_instances() */
    read_sig_alarm();
    assert_int_equal(s_cntr_get_list_of_instances, 1);

    /**
     * Keep calling read_sig_alarm to trigger the timers in populate_dm_startup.c
     * which call get_list_of_instances() and get_object_content() to build up the
     * XPON DM.
     */
    for(i = 0; i < 15; ++i) {
        read_sig_alarm();
        /**
         * Call handle_events() to ensure _onu_added(), _ethernet_uni_added() and
         * _ani_added() are called.
         */
        handle_events();
    }

    /* Check if tr181-xpon populated the XPON DM */
    amxd_object_t* obj = amxd_dm_findf(&dm, "XPON.ONU.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), ONU_NAME);

    char path[64];
    for(i = 0; i < 2; ++i) {
        snprintf(path, 64, "XPON.ONU.1.SoftwareImage.%d", (i + 1));
        obj = amxd_dm_findf(&dm, path);
        assert_non_null(obj);
        assert_int_equal(amxd_object_get_param(obj, "ID", &value), amxd_status_ok);
        assert_int_equal(GET_UINT32(&value, NULL), i);
    }

    obj = amxd_dm_findf(&dm, "XPON.ONU.1.EthernetUNI.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), ETHERNET_UNI_NAME);

    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1");
    assert_non_null(obj);
    assert_int_equal(amxd_object_get_param(obj, NAME_PARAMETER, &value), amxd_status_ok);
    assert_string_equal(GET_CHAR(&value, NULL), ANI_NAME);

    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1.TC.Alarms");
    assert_non_null(obj);
    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1.TC.Authentication");
    assert_non_null(obj);
    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1.TC.GEM");
    assert_non_null(obj);
    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1.TC.ONUActivation");
    assert_non_null(obj);
    obj = amxd_dm_findf(&dm, "XPON.ONU.1.ANI.1.TC.PerformanceThresholds");
    assert_non_null(obj);

    add_one_gem_port();
    update_gem_port_with_dm_add_or_change_instance();
    update_gem_port_with_dm_object_changed();

    remove_all_dm_instances();

    for(i = 0; i < n_functions; ++i) {
        rc = amxm_module_remove_function(pon_ctrl_module, MOD_PON_CTRL_FUNCS[i].name);
        assert_int_equal(rc, 0);
    }
    amxc_var_clean(&value);
}

