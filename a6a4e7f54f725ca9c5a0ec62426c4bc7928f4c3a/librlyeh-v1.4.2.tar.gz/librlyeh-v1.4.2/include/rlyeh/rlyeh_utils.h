/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__RLYEH_UTILS_H__)
#define __RLYEH_UTILS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <rlyeh/rlyeh_auth.h>
#include <amxc/amxc.h>

#include <libocispec/image_spec_schema_image_manifest_schema.h>
#include <libocispec/image_spec_schema_image_index_schema.h>
#include <stdbool.h>

#define RLYEH_ERR_MSG_LEN 1024

#define CHECK_DIR_DOT_DOT(x) (((x)[0] == '.' ) && (((x)[1] == '\0') || (((x)[1] == '.') && ((x)[2] == '\0'))))

typedef struct _rlyeh_image_parameters {
    char* transport;
    char* duid;
    union {
        char* image_name;
        char* image_dir;
    };
    char* version;
    uint16_t port_number;
    char* signature_url_overload;
    char* server;
    char* server_url_append;
    rlyeh_auth_type_t auth_type;
    char* username;
    char* password;
    char* token;
    bool sv; /* Signature Verification enable */
    bool cv; /* Certificate Verification enable */
} rlyeh_image_parameters_t;

typedef struct _rlyeh_signature_data {
    char* uri;
    char* transport;
    char* server;
    char* image_name;
    char* version;
    char* manifest_hash;
    char* signature_url_overload;
} rlyeh_signature_data_t;

int rlyeh_image_parameters_init(rlyeh_image_parameters_t* data);
int rlyeh_image_parameters_clean(rlyeh_image_parameters_t* data);

void rlyeh_signature_data_init(rlyeh_signature_data_t* data);
void rlyeh_signature_data_clean(rlyeh_signature_data_t* data);


int rlyeh_remove_dir_unsafe(const char* path_to_dir);
int rlyeh_file_is_symlink(const char* filename);
int rlyeh_is_file(const char* filename);
int rlyeh_is_dir(const char* dirname);
bool file_exists(const char* filename);
bool dir_exists(const char* dirname);
bool rlyeh_image_already_exists(const rlyeh_image_parameters_t* image, const char* disk_location);
bool rlyeh_is_empty_dir(const char* dirname);
ssize_t rlyeh_write_file(const char* file_path, const char* data);
int rlyeh_remove_file(const char* file_path);
int rlyeh_move_file(const char* src, const char* dest);
ssize_t rlyeh_copy_file(const char* src, const char* dest);

amxc_var_t* read_config(const char* file);

int rlyeh_parse_uri(const char* uri, rlyeh_image_parameters_t* image_params);

image_spec_schema_image_index_schema* rlyeh_parse_image_spec_schema(const char* image_name);

int rlyeh_get_server_from_file(rlyeh_image_parameters_t* param);

bool build_manifest_filename_from_index(const image_spec_schema_image_index_schema* index_schema,
                                        const char* image_version,
                                        const char* image_duid,
                                        const char* storage_location,
                                        amxc_string_t* manifest_filename);
bool check_manifest_validity(const image_spec_schema_image_manifest_schema* manifest, parser_error err);

int64_t rlyeh_hash_blob(const char* filename, const char* hash_algo, char** hash_blob);

int rlyeh_generate_uri(rlyeh_image_parameters_t* uri_elements, amxc_string_t* full_uri, const char* images_location);

int build_fname_from_digest(const char* storage_location, const char* digest, amxc_string_t* fname);

int set_err_msg(char* dest, const char* msg, ...);

char* digest_to_path(const char* digest);

void print_file(const char* zone, const char* path);

typedef void (index_loop_callback_t)(const char*, const char*, void* args);

void rlyeh_loop_through_index_files(const char* image_location, index_loop_callback_t fn, void* args);

int rlyeh_build_blobs_list(const char* storagepath, amxc_llist_t* lblobs);

int rlyeh_remove_blobs_dir(const char* blobs_dir);

int rlyeh_remove_blob(const char* digest, const char* storage_location);

int rlyeh_remove_image_dir(const char* image_location, const char* image_dir);

int rlyeh_get_it_from_index(size_t* it,
                            const image_spec_schema_image_index_schema* index_schema,
                            const char* image_version,
                            const char* image_duid);

int rlyeh_write_index_file_from_image_spec_schema(const char* index_filename, image_spec_schema_image_index_schema* index_schema);

int rlyeh_remove_manifest_from_image_spec_schema(image_spec_schema_image_index_schema* index_schema, const char* duid, const char* version);

void rlyeh_update_annotation_in_manifest_element(image_spec_schema_image_index_schema_manifests_element* manifest,
                                                 const char* annotation_key,
                                                 const char* annotation_value);

int rlyeh_get_creds_from_file(rlyeh_image_parameters_t* data, const char* server);

void rlyeh_remove_all_files_in_dir(const char* path_to_dir);


#ifdef __cplusplus
}
#endif

#endif // __RLYEH_UTILS_H__
