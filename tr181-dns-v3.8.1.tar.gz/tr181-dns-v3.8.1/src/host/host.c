/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "host/host.h"
#include "host/dm_host.h"
#include "dm_relay.h"
#include "dm_common.h"
#include "netdevname.h"
#include "internal_zone.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

host_addr_t* host_addr_new(amxd_object_t* obj) {
    host_addr_t* host_addr = NULL;
    when_null(obj, exit);
    host_addr = (host_addr_t*) calloc(1, sizeof(host_addr_t));
    when_null(host_addr, exit);
    host_addr->name = amxd_object_get_name(obj, AMXD_OBJECT_NAMED);
    host_addr->obj = obj;
    obj->priv = host_addr;
exit:
    return host_addr;
}

int host_addr_delete(host_addr_t** host_addr) {
    int rv = -1;

    when_null(host_addr, exit);
    when_null(*host_addr, exit);
    FREE((*host_addr)->old_ipaddr);
    FREE(*host_addr);
    rv = 0;
exit:
    return rv;
}

host_t* host_new(amxd_object_t* obj) {
    host_t* host = NULL;
    when_null(obj, exit);
    host = (host_t*) calloc(1, sizeof(host_t));
    when_null(host, exit);
    host->name = amxd_object_get_name(obj, AMXD_OBJECT_NAMED);
    host->obj = obj;
    obj->priv = host;
exit:
    return host;
}

int host_delete(host_t** host) {
    int rv = -1;

    when_null(host, exit);
    when_null(*host, exit);
    FREE((*host)->netdevname);
    FREE((*host)->old_hostname);
    CLOSE_QUERY((*host)->query_getaddrs);
    FREE(*host);
    rv = 0;
exit:
    return rv;
}

static bool host_add(amxd_object_t* host_obj) {
    internal_zone_t* zone = NULL;
    amxd_object_t* templ = NULL;
    const char* domain = NULL;
    const char* iface = NULL;
    bool rv = false;
    bool call_backend = false;
    host_t* host = NULL;

    when_null(host_obj, exit);
    when_null(host_obj->priv, exit);
    host = (host_t*) host_obj->priv;

    domain = object_da_string(host_obj, "Name");

    iface = host->netdevname; // ok for now ok to use host_t until zones do their own netmodel querying
    templ = amxd_object_findf(host_obj, ".%s.", "IPAddress");

    when_null_trace(templ, exit, ERROR, "Host %s is missing IPAddress sub-object", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));
    when_str_empty_trace(domain, exit, INFO, "Host %s is missing Name", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));
    when_str_empty_trace(iface, exit, INFO, "Host %s is missing Interface", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));

    zone = internal_zone_find(domain, iface);
    if(zone == NULL) {
        zone = internal_zone_new(domain, iface);
        when_null_trace(zone, exit, ERROR, "Failed to add zone for domain %s", domain);
    }

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* ipaddr_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        const char* ipaddr = NULL;

        ipaddr = object_da_string(ipaddr_obj, "IPAddress");
        if(STRING_EMPTY(ipaddr)) {
            SAH_TRACEZ_INFO(ME, "Host %s skip %s", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED), amxd_object_get_name(ipaddr_obj, AMXD_OBJECT_NAMED));
            continue;
        }

        internal_zone_add_zoneaddr(zone, ipaddr, NULL, &call_backend);
    }

    // maybe only the refcount was increased
    when_false_status(call_backend, exit, rv = true);

    rv = internal_zone_backend_set_addresses(zone, NULL);

exit:
    // Klocwork suppress: The internal_zone is an API that saves the data that is used in the list 'zones', so the memory is not lost as klocwork reports.
    // The zone is free'd throughout the code everytime the internal_zone_delete is called
    // In the worst case scenario it's cleaned by the destructor 'internal_zone_cleanall'
    // There is no failure scenario that this memory should be free'd
    return rv;
}

static bool host_remove(amxd_object_t* host_obj) {
    internal_zone_t* zone = NULL;
    amxd_object_t* templ = NULL;
    const char* domain = NULL;
    const char* iface = NULL;
    bool rv = false;
    bool call_backend = false;
    host_t* host = NULL;

    when_null(host_obj, exit);
    when_null(host_obj->priv, exit);
    host = (host_t*) host_obj->priv;

    domain = host->old_hostname; // maybe hostname changed
    if(STRING_EMPTY(domain)) {
        domain = object_da_string(host->obj, "Name");
    }

    iface = host->netdevname; // ok for now ok to use host_t until zones do their own netmodel querying
    templ = amxd_object_findf(host_obj, ".%s.", "IPAddress");

    when_null_trace(templ, exit, INFO, "Host %s is missing IPAddress sub-object", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED)); // could happen if DNS.X_PRPL-COM.Host is in destroy action
    when_str_empty_trace(domain, exit, INFO, "Host %s is missing Name", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));
    when_str_empty_trace(iface, exit, INFO, "Host %s is missing Interface", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));

    zone = internal_zone_find(domain, iface);
    when_null_trace(zone, exit, INFO, "No zone for domain %s", domain);

    amxd_object_for_each(instance, it, templ) {
        amxd_object_t* ipaddr_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        const char* ipaddr = NULL;

        ipaddr = object_da_string(ipaddr_obj, "IPAddress");
        if(STRING_EMPTY(ipaddr)) {
            SAH_TRACEZ_INFO(ME, "Host %s skip %s", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED), amxd_object_get_name(ipaddr_obj, AMXD_OBJECT_NAMED));
            continue;
        }

        internal_zone_remove_zoneaddr(zone, ipaddr, NULL, &call_backend);
    }

    if(!call_backend) { // maybe only the refcount was decreased
        rv = true;
        goto exit;
    }

    rv = internal_zone_backend_evaluate_addresses(zone, NULL);

exit:
    return rv;
}

void host_disable(host_t* host, bool cleanup) {
    when_null(host, exit);
    if(host->is_enabled) {
        host_remove(host->obj);
        host->is_enabled = false;
    }
    if(cleanup) {
        CLOSE_QUERY(host->query_getaddrs);
        FREE(host->netdevname);
    }
    FREE(host->old_hostname);
exit:
    return;
}

static bool host_enable(host_t* host) {

    when_null(host, exit);
    when_true_trace(host->is_enabled, exit, INFO, "%s is already enabled", host->name);

    if(STRING_EMPTY(host->netdevname)) {
        SAH_TRACEZ_INFO(ME, "%s is waiting for query result", host->name);
        host->is_enabled = false; // for sanity?
        goto exit;
    }

    host->is_enabled = host_add(host->obj);

    // marking all IP addresses so we know following instance-added events are already handled by zone_add_host
    // (to not mess up the refcount in zones)
    amxd_object_for_each(instance, it, amxd_object_findf(host->obj, "%s", "IPAddress")) {
        amxd_object_t* ipaddr_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        host_addr_t* host_addr = NULL;
        const char* ipaddr = NULL;

        ipaddr = object_da_string(ipaddr_obj, "IPAddress");
        if(STRING_EMPTY(ipaddr)) {
            continue;
        }

        if(ipaddr_obj->priv != NULL) {
            host_addr = (host_addr_t*) ipaddr_obj->priv;
        } else {
            host_addr = host_addr_new(ipaddr_obj);
            if(host_addr == NULL) {
                SAH_TRACEZ_ERROR(ME, "IPAddress %s of Host %s not accounted for", amxd_object_get_name(ipaddr_obj, AMXD_OBJECT_NAMED), amxd_object_get_name(host->obj, AMXD_OBJECT_NAMED));
                continue;
            }
        }

        host_addr->is_enabled = true;
    }

exit:
    return host->is_enabled;
}

static bool host_can_enable(host_t* host) {
    bool can_enable = false;
    const char* name = NULL;
    const char* iface = NULL;

    when_null(host, exit);
    when_true(!amxd_object_get_value(bool, host->obj, "Enable", NULL), exit);

    name = object_da_string(host->obj, "Name");
    when_str_empty_trace(name, exit, ERROR, "%s is misconfigured because Name is empty", host->name);

    iface = object_da_string(host->obj, "Interface");
    when_str_empty_trace(iface, exit, ERROR, "%s is misconfigured because Interface is empty", host->name);

    can_enable = true;
exit:
    return can_enable;
}

void host_add_ipaddr(host_addr_t* host_addr) {
    const char* ipaddr = NULL;
    const char* hostname = NULL;
    host_t* host = NULL;
    amxd_object_t* host_obj = NULL;

    when_null(host_addr, exit);
    when_true_trace(host_addr->is_enabled, exit, INFO, "%s is already enabled", host_addr->name);

    host_obj = amxd_object_findf(host_addr->obj, ".^.^");
    when_null_trace(host_obj, exit, ERROR, "Host object not found");
    when_null_trace(host_obj->priv, exit, ERROR, "Host object has no priv data");
    host = (host_t*) host_obj->priv;

    if(!host->is_enabled) { // maybe host was added without IPAddress instances
        when_false_trace(host_can_enable(host), exit, INFO, "%s is not added because host is disabled", host_addr->name);
        host_enable(host);
        goto exit;
    }

    hostname = object_da_string(host->obj, "Name");
    when_str_empty_trace(hostname, exit, ERROR, "%s is not added because Name is empty", host_addr->name);

    ipaddr = object_da_string(host_addr->obj, "IPAddress");
    when_str_empty_trace(ipaddr, exit, INFO, "%s is not added because IPAddress is empty", host_addr->name);

    host_addr->is_enabled = internal_zone_add_ipaddr(host->netdevname, hostname, NULL, ipaddr);
exit:
    return;
}

void host_remove_ipaddr(host_addr_t* host_addr) {
    const char* hostname = NULL;
    const char* ipaddr = NULL;
    host_t* host = NULL;
    amxd_object_t* host_obj = NULL;

    when_null(host_addr, exit);
    when_false_trace(host_addr->is_enabled, exit, INFO, "%s is already disabled", host_addr->name);

    host_obj = amxd_object_findf(host_addr->obj, ".^.^");
    when_null_trace(host_obj, exit, ERROR, "Host object not found");
    when_null_trace(host_obj->priv, exit, ERROR, "Host object has no priv data");
    host = (host_t*) host_obj->priv;
    when_false_trace(host->is_enabled, exit, INFO, "%s is not removed because host is disabled", host_addr->name);

    ipaddr = host_addr->old_ipaddr;
    if(ipaddr == NULL) {
        ipaddr = object_da_string(host_addr->obj, "IPAddress");
    }
    when_null(ipaddr, exit);

    hostname = object_da_string(host->obj, "Name");
    when_str_empty_trace(hostname, exit, ERROR, "%s is not removed because Name is empty", host_addr->name);

    internal_zone_remove_ipaddr(host->netdevname, hostname, NULL, ipaddr);
exit:
    host_addr->is_enabled = false;
    FREE(host_addr->old_ipaddr);
}

static void update_ipaddress_objects(host_t* host, const amxc_var_t* result) {
    amxd_trans_t trans;
    amxc_var_t addresses_to_add;

    amxd_trans_init(&trans);
    amxc_var_init(&addresses_to_add);
    amxc_var_set_type(&addresses_to_add, AMXC_VAR_ID_HTABLE);

    amxc_var_for_each(var, result) {
        amxc_var_add_new_key(&addresses_to_add, GET_CHAR(var, "Address"));
    }

    // try to reuse existing objects
    amxd_object_for_each(instance, it, amxd_object_findf(host->obj, ".IPAddress")) {
        amxd_object_t* ipaddr_obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        const char* ipaddr = NULL;
        amxc_var_t* addresses_var = NULL;

        ipaddr = object_da_string(ipaddr_obj, "IPAddress");

        addresses_var = GET_ARG(&addresses_to_add, ipaddr);
        if(addresses_var == NULL) {
            amxd_trans_select_object(&trans, ipaddr_obj);
            amxd_trans_select_pathf(&trans, ".^");
            amxd_trans_del_inst(&trans, amxd_object_get_index(ipaddr_obj), NULL);
            if(ipaddr_obj->priv != NULL) {
                host_addr_t* host_addr = (host_addr_t*) ipaddr_obj->priv;
                host_addr->is_enabled = false; // the destroy handler should not let the backend remove the host address
            }
            continue;
        }

        amxc_var_delete(&addresses_var); // remove from list so no new object is created
    }

    amxc_var_for_each(var, &addresses_to_add) {
        amxd_trans_select_object(&trans, host->obj);
        amxd_trans_select_pathf(&trans, ".IPAddress");
        amxd_trans_add_inst(&trans, 0, NULL);
        amxd_trans_set_value(cstring_t, &trans, "IPAddress", amxc_var_key(var));
    }

    if(amxd_trans_apply(&trans, get_dm()) != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed");
    }

    amxd_trans_clean(&trans);
    amxc_var_clean(&addresses_to_add);
}

static void host_getaddrs_changed(UNUSED const char* sig_name, const amxc_var_t* result, void* priv) {
    host_t* host = (host_t*) priv;
    when_null(host, exit);
    const char* netdevname = GETP_CHAR(result, "0.NetDevName");
    char* old_netdevname = NULL;

    if(netdevname == NULL) {
        netdevname = "";
    }

    // hack: If the netdevname didn't change then some other value of getAddrs query changed.
    // If new ip addresses are added then Unbound has to restart to listen on them.
    if((host->netdevname == NULL) || (strcmp(host->netdevname, netdevname) != 0)) {
        old_netdevname = host->netdevname;
        host->netdevname = strdup(netdevname);
    }

    SAH_TRACEZ_INFO(ME, "%s getaddrs query result changed", host->name);

    if(amxd_object_get_value(bool, host->obj, "QueryAddresses", NULL)) {
        update_ipaddress_objects(host, result);
    }

    if(host->query_getaddrs != NULL) {
        if(old_netdevname != NULL) {
            char* tmp = host->netdevname;
            host->netdevname = old_netdevname;
            host_disable(host, false);
            host->netdevname = tmp;
        } else {
            host_disable(host, false);
        }
        host_enable(host);
    } // else called from openQuery
    free(old_netdevname);

exit:
    return;
}

static bool host_iface_changed(host_t* host) {
    bool rv = false;
    const char* iface = NULL;

    when_null(host, exit);
    when_false_status(host->query_getaddrs == NULL, exit, rv = true);

    iface = object_da_string(host->obj, "Interface");
    when_str_empty_trace(iface, exit, ERROR, "%s misconfigured because Interface is empty", host->name);

    host->query_getaddrs = query_getaddrs(iface, host_getaddrs_changed, host);
    when_null_trace(host->query_getaddrs, exit, ERROR, "Failed to open query");

    rv = true;
exit:
    return rv;
}

void host_changed(amxd_object_t* obj) {
    host_t* host = NULL;

    when_null(obj, exit);
    if(obj->priv == NULL) {
        const char* origin = NULL;

        host = host_new(obj);
        when_null(host, exit);

        origin = object_da_string(obj, "Origin");
        if((origin == NULL) || (strcmp(origin, "Static") == 0)) {
            host->is_static = true;
        } else {
            unset_object_persistency(obj);
        }
    } else {
        host = (host_t*) obj->priv;
        host_disable(host, false); // close queries only if Interface changed (not if Name changed)
    }

    if(!host_can_enable(host)) {
        host_disable(host, true); // close queries
        goto exit;
    }
    when_false(host_iface_changed(host), exit);

    host_enable(host);

exit:
    return;
}
