/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <stdio.h>
#include <netmodel/client.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <string.h>

#include "usp_discovery.h"
#include "event_handler.h"
#include "obuspa_interface.h"

#define ME "usp_discovery"

struct App app;

/**
 * @file usp_discovery_main.c
 * @brief USP discovery support for the CPE.
 */

int _usp_discovery_main(int reason, UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser) {
    switch(reason) {
    case 0: // START
        app_init(&app);
        {
            int rc = remove_all_controllers();
            if(rc) {
                SAH_TRACEZ_ERROR(ME, "Cannot remove existing controllers.");
            }
        }
        {
            int rc = netmodel_initialize();
            if(!rc) {
                SAH_TRACEZ_ERROR(ME, "Cannot initialize libnetmodel");
                exit(1);
            }
        }
        {
            int rc = setup_subscriptions();
            if(rc) {
                SAH_TRACEZ_ERROR(ME, "Cannot initialize subscriptions, got %d", rc);
                exit(1);
            }
        }
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*        usp_discovery started       *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        break;
    case 1: // STOP
        remove_all_controllers();
        netmodel_cleanup();
        app_clean(&app);
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        SAH_TRACEZ_NOTICE(ME, "*        usp_discovery stopped       *");
        SAH_TRACEZ_NOTICE(ME, "**************************************");
        break;
    }

    return 0;
}

void DHCPControllerInformation_free(struct DHCPControllerInformation* controller) {
    free(controller->EndpointID);
    free(controller->URL);
    free(controller->ProvisioningCode);
}

/**
 * Duplicate string, return NULL, if string is NULL
 *
 * @param str the string to duplicate
 *
 * @return copy of the string or NULL if the str is NULL
 */
static char* strdup_safe(const char* str) {
    if(!str) {
        return NULL;
    }
    return strdup(str);
}

struct DHCPControllerInformation DHCPControllerInformation_clone(struct DHCPControllerInformation controller) {
    struct DHCPControllerInformation controller_information;
    controller_information.EndpointID = strdup_safe(controller.EndpointID);
    controller_information.URL = strdup_safe(controller.URL);
    controller_information.ProvisioningCode = strdup_safe(controller.ProvisioningCode);
    controller_information.USPNotifRetryIntervalMultiplier = controller.USPNotifRetryIntervalMultiplier;
    controller_information.USPNotifRetryMinimumWaitInterval = controller.USPNotifRetryMinimumWaitInterval;
    return controller_information;
}
/**
 * Checks whether two strings are equal
 *
 * @param[in] str1 first string
 * @param[in] str2 second string
 *
 * @return whether two strings are equal
 */
static bool streq(const char* str1, const char* str2) {
    if(!str1) {
        if(!str2) {
            return true;
        }
        return false;
    }
    if(!str2) {
        return false;
    }
    return !strcmp(str1, str2);
}

bool DHCPControllerInformation_equals(const struct DHCPControllerInformation* info1, const struct DHCPControllerInformation* info2) {
    return streq(info1->URL, info2->URL) &&
           streq(info1->ProvisioningCode, info2->ProvisioningCode) &&
           info1->USPNotifRetryIntervalMultiplier == info2->USPNotifRetryIntervalMultiplier &&
           info1->USPNotifRetryMinimumWaitInterval == info2->USPNotifRetryMinimumWaitInterval &&
           streq(info1->EndpointID, info2->EndpointID);
}


void DHCPStatus_reset(struct DHCPStatus* status) {
    DHCPControllerInformation_free(&status->controller_information);
    memset(&status->controller_information, 0, sizeof(struct DHCPControllerInformation));
    amxc_string_reset(&status->alias);
    status->in_use = false;
}

void app_init(struct App* application) {
    memset(application, 0, sizeof(struct App));
    amxc_string_init(&application->dhcpv4_status.alias, PATH_BUFFER_SIZE);
    amxc_string_init(&application->dhcpv6_status.alias, PATH_BUFFER_SIZE);
}

void app_clean(struct App* application) {
    amxc_string_clean(&application->dhcpv4_status.alias);
    amxc_string_clean(&application->dhcpv6_status.alias);
    memset(application, 0, sizeof(struct App));
}

amxc_string_t search_path_alias_postprocess_function(const char* alias) {
    amxc_string_t alias_postprocessed;
    amxc_string_init(&alias_postprocessed, PATH_BUFFER_SIZE);
    amxc_string_set(&alias_postprocessed, alias);
    return alias_postprocessed;
}
