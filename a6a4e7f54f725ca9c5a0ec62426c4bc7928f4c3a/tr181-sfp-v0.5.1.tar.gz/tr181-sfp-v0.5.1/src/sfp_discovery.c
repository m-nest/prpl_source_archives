/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* System headers */
#include <string.h> /* strncpy() */

/* Other libraries' headers */
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>           /* UNUSED */
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>               /* amxd_dm_findf() */
#include <amxd/amxd_object_parameter.h> /* amxd_object_get_param_value() */
#include <amxm/amxm.h>                  /* amxm_execute_function() */

/* Own headers */
#include "sfpmgr_main.h" /* sfp_get_dm() */
#include "sfp_discovery.h"
#include "optical_if.h"  /* optical_info_t */

static amxc_llist_t sfp_cage_list;

static amxp_timer_t* s_timer_discovery = NULL;

static void discovery_timeout_handle (amxp_timer_t* timer, void* priv);
static void determine_nr_of_cages(void);
static int populate_cage(int cage_index, sfp_cage_t* cage_info);

// Global variable to hold the max nr of cages
static size_t s_max_cage = 0;

/**
 * @brief Returns the selected SFPs controller.
 *
 * @return Returns name of the current SFPs controller.
 */
static const char* get_sfps_ctrl(void) {
    amxd_object_t* sfps_obj = amxd_dm_findf(sfp_get_dm(), SFPS_PATH);
    const amxc_var_t* sfps_ctrl = amxd_object_get_param_value(sfps_obj, "SFPsController");

    const char* sfps_ctrl_name = NULL;

    if(sfp_mods_are_loaded()) {
        sfps_ctrl_name = GET_CHAR(sfps_ctrl, NULL);
    } else {
        sfps_ctrl_name = DEFAULT_MOD_SFP_TYPE_NAME;
    }

    return sfps_ctrl_name;
}

/**
 * @brief Execute an SFPs controller function
 *
 * @param[in] function The name of the function.
 * @param[in] data  Input parameters passed to the function.
 * @param[out] ret  Output parameters returned by the function.
 *
 * @return Returns a status code (-1 on failure, 0 on success).
 */
static int mod_sfps_execute_function(const char* function, amxc_var_t* data, amxc_var_t* ret) {
    const char* sfps_ctrl = NULL;
    int rv = SFPMGR_INVALID;

    when_str_empty(function, exit);

    sfps_ctrl = get_sfps_ctrl();
    SAH_TRACEZ_INFO(ME, "%s -> call implementation (controller = '%s')", function, sfps_ctrl);
    rv = amxm_execute_function(sfps_ctrl, MOD_SFP_TYPE, function, data, ret);
    when_failed_trace(rv, exit, ERROR, "amxm_execute_function failed");

exit:
    return rv;
}

/**
 * @brief Discover cages and start SFP discovery process.
 *
 * First determine the number of cages. Immediately log a warning but return 0
 * (success) if no cages are found.
 *
 * This function allocates memory for each cage's information, retrieves the
 * cage's properties based on the board index, and updates the cage properties.
 * It also starts a discovery timer to complete the SFP discovery process after
 * a timeout. In case of memory allocation failure or other issues, error messages
 * are logged and the process exits gracefully.
 *
 * @return Returns a status code (-1 on failure, 0 on success).
 */
int discover_cages (void) {
    sfp_cage_t* cage_info;
    int cage_count = 0;
    int rv = SFPMGR_INVALID;

    determine_nr_of_cages();
    if(0 == s_max_cage) {
        SAH_TRACEZ_INFO(ME, "No cages found => do not start SFP discovery timer");
        rv = SFPMGR_SUCCESS;
        goto exit;
    }

    amxc_llist_init(&sfp_cage_list);
    SAH_TRACEZ_INFO(ME, "Cage Discovery Initiated");

    for(cage_count = 0; cage_count < get_max_cage(); cage_count++) {
        cage_info = calloc(1, sizeof(sfp_cage_t));
        if(!cage_info) {
            SAH_TRACEZ_ERROR(ME, "Failed to allocate memory for cage info");
            goto exit;
        }

        rv = populate_cage(cage_count + 1, cage_info);
        if(rv != SFPMGR_SUCCESS) {
            SAH_TRACEZ_ERROR(ME, "Failed to populate cage");
            free(cage_info);
            goto exit;
        }
        amxc_llist_append(&sfp_cage_list, &cage_info->it);
        sfpmgr_cage_info_update(cage_info);
    }

    if(amxp_timer_new(&s_timer_discovery, discovery_timeout_handle, NULL) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to create timer to delivery complete callback");
        goto exit;
    }
    amxp_timer_set_interval(s_timer_discovery, DISCOVERY_TIMEOUT_SEC);
    amxp_timer_start(s_timer_discovery, 1000);
    SAH_TRACEZ_INFO(ME, "Started SFP discovery timer");

exit:
    return rv;
}

/**
 * @brief Handles the timeout event for SFP discovery process.
 *
 * This function is called when the discovery timeout occurs. It iterates through
 * the list of SFP cages, checks if an SFP is present and if the RX loss of signal
 * (Rx LOS) condition exists. Based on the results, it updates the state of the
 * corresponding cage and processes the discovery information for each cage.
 *
 * @param[in] timer Unused timer object.
 * @param[in] priv  Unused private data pointer.
 *
 * @return None.
 */
static void discovery_timeout_handle (UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    sfp_cage_t* cage_info = NULL;
    int rv = SFPMGR_INVALID;
    amxc_llist_for_each(it, &sfp_cage_list) {
        bool sfp_present = false;
        bool sfp_rx_los = true;
        sfp_types_e sfp_type = SFP_UNSUPPORTED;
        int prev_state = 0;
        cage_info = amxc_llist_it_get_data(it, sfp_cage_t, it);
        if(!cage_info) {
            continue;
        }
        prev_state = cage_info->state;
        SAH_TRACEZ_INFO(ME, "Discovering cage %d ifname %s",
                        cage_info->cage_id,
                        cage_info->ifName);
        rv = discover_detect_sfp(&sfp_present, &sfp_rx_los,
                                 &sfp_type, cage_info->ifName);
        if(rv == SFPMGR_SUCCESS) {
            SAH_TRACEZ_INFO(ME, "discovery processed in cage %d", cage_info->cage_id);
            discover_update_cage_state(cage_info, sfp_present, sfp_rx_los, sfp_type);
            discover_state_functions(cage_info, prev_state);
        } else {
            SAH_TRACEZ_ERROR(ME, "Error detecting SFP %d SFP DISCOVERY >>> ", cage_info->cage_id);
        }
    }
    return;
}

/**
 * @brief Updates the state of an SFP cage based on the presence and Rx LOS status of the SFP.
 *
 * This function updates the state of the specified SFP cage based on whether the SFP is present
 * and if the receive loss of signal (Rx LOS) condition is detected. The cage's state is set to one
 * of the following values:
 * - `SFP_STATE_RX_LOS_CLEARED` if the SFP is present and Rx LOS is cleared.
 * - `SFP_STATE_RX_LOS` if the SFP is present and Rx LOS is active.
 * - `SFP_STATE_REMOVED` if the SFP is not present.
 *
 * @param[in] cage_info Pointer to the SFP cage structure to be updated.
 * @param[in] sfp_present Boolean flag indicating if the SFP is present.
 * @param[in] sfp_rx_los Boolean flag indicating if Rx LOS is detected.
 * @param[in] sfp_type Integer that will be set to the detected SFP type (e.g., `GPON`, etc.).
 *
 * @return None
 */
void discover_update_cage_state (sfp_cage_t* cage_info, bool sfp_present, bool sfp_rx_los, sfp_types_e sfp_type) {
    if((cage_info->state == SFP_STATE_REMOVED) && sfp_present) {
        /*
         * sfp_type can be overriden by the SFP DB.
         * Set it only when SFP is inserted in the cage.
         */
        cage_info->sfp_type = sfp_type;
    }
    if(sfp_present && !sfp_rx_los) {
        cage_info->state = SFP_STATE_RX_LOS_CLEARED;
    } else if(sfp_present && sfp_rx_los) {
        cage_info->state = SFP_STATE_RX_LOS;
    } else if(!sfp_present) {
        cage_info->state = SFP_STATE_REMOVED;
    }
    SAH_TRACEZ_INFO(ME, "SFP DISCOVER TIMER: Updated cage[%d] state to %d",
                    cage_info->cage_id, cage_info->state);
}

/**
 * @brief Handles state transitions for an SFP cage and performs the corresponding actions.
 *
 * This function compares the current and previous states of the SFP cage and triggers actions
 * based on the transition between states. The actions include handling insertions, removals,
 * and clearing the Rx LOS (Loss of Signal) condition. It ensures that each state change is processed
 * at least once using a flag to account for identical states, which is particularly important for GBE systems.
 *
 * - If the state transitions to `SFP_STATE_RX_LOS_CLEARED`, actions for insertion and clearing the Rx LOS
 *   are triggered based on the previous state.
 * - If the state transitions to `SFP_STATE_RX_LOS`, it handles clearing Rx LOS if transitioning from
 *   `SFP_STATE_RX_LOS_CLEARED` and triggers actions for insertion from `SFP_STATE_REMOVED`.
 * - If the state is `SFP_STATE_REMOVED`, the SFP module is removed and actions for removal are triggered.
 *
 * @param[in] cage_info Pointer to the SFP cage structure holding the current state.
 * @param[in] prev_state The previous state of the SFP cage.
 *
 * @return Returns 0 on success, or an error code if any issues occur.
 */
int discover_state_functions (sfp_cage_t* cage_info, int prev_state) {
    SAH_TRACEZ_INFO(ME, " SFP DISCOVERY >>>> Cage[%d] prev state %d current state %d",
                    cage_info->cage_id, prev_state, cage_info->state);

    if(cage_info == NULL) {
        SAH_TRACEZ_ERROR(ME, "cage_info is NULL");
        return SFPMGR_INVALID;
    }

    /* flag was introduced to ensure all necessary functions execute at least once,
       even if the states are identical, as observered in GBE */

    static bool initial_check = true;

    if(((int) cage_info->state == prev_state) && (initial_check == false)) {
        return SFPMGR_SUCCESS;
    }

    initial_check = false;

    if(cage_info->state == SFP_STATE_RX_LOS_CLEARED) {
        if(prev_state == SFP_STATE_REMOVED) {
            SAH_TRACEZ_INFO(ME, "Insert action");
            discover_insert_action(cage_info, true);
            discover_rxlos_clear(cage_info, true);
        }
        if(prev_state == SFP_STATE_RX_LOS) {
            discover_rxlos_clear(cage_info, true);
        }
    } else if(cage_info->state == SFP_STATE_RX_LOS) {
        if(prev_state == SFP_STATE_RX_LOS_CLEARED) {
            discover_rxlos_clear(cage_info, false);
        }
        if(prev_state == SFP_STATE_REMOVED) {
            SAH_TRACEZ_INFO(ME, "Insert action");
            discover_insert_action(cage_info, true);
            discover_rxlos_clear(cage_info, false);
        }
    } else if((cage_info->state == SFP_STATE_REMOVED) && (prev_state != SFP_STATE_REMOVED)) {
        SAH_TRACEZ_INFO(ME, "Remove");
        discover_insert_action(cage_info, false);
    }
    return SFPMGR_SUCCESS;
}

/**
 * @brief Handles actions for inserting or removing an SFP (Small Form-factor Pluggable) module.
 *
 * This function performs the necessary actions based on whether an SFP module is inserted or removed.
 * It prepares the argument structure, sets up the appropriate actions, and calls the relevant
 * functions to handle SFP insertion or removal. The actions are logged for visibility.
 *
 * - If the `inserted` parameter is `false`, it triggers the removal action for the SFP.
 * - If the `inserted` parameter is `true`, it triggers the insertion action for the SFP.
 *
 * @param[in] cage_info Pointer to the `sfp_cage_t` structure containing the SFP cage information.
 * @param[in] inserted A boolean indicating whether the SFP is inserted (`true`) or removed (`false`).
 *
 * @return None
 */
void discover_insert_action (sfp_cage_t* cage_info, bool inserted) {
    if(inserted == false) {
        SAH_TRACEZ_INFO(ME, "SFP cage %d: SFP removed", cage_info->cage_id);
        sfpmgr_sfp_removed(cage_info->cage_id);
    } else {
        SAH_TRACEZ_INFO(ME, "SFP cage %d: SFP inserted", cage_info->cage_id);
        sfpmgr_sfp_inserted(cage_info->cage_id, cage_info->sfp_type);
    }
}

/**
 * @brief Handles the event of clearing or setting the Loss of Signal (Rx LOS) for an SFP module.
 *
 * This function performs actions based on whether the Rx LOS condition is cleared or set.
 * It prepares the argument structure and calls the relevant functions to either trigger the
 * SFP Rx LOS action or clear the condition. The actions are logged for visibility.
 *
 * - If the `cleared` parameter is `false`, it triggers the Rx LOS action for the SFP.
 * - If the `cleared` parameter is `true`, it clears the Rx LOS condition for the SFP.
 *
 * @param[in] cage_info Pointer to the `sfp_cage_t` structure containing the SFP cage information.
 * @param[in] cleared A boolean indicating whether the Rx LOS condition is cleared (`true`) or set (`false`).
 *
 * @return None
 */
void discover_rxlos_clear (sfp_cage_t* cage_info, bool cleared) {
    SAH_TRACEZ_INFO(ME, "cage_index=%u: LOS=%d", cage_info->cage_id, cleared ? 0 : 1);
    if(cleared == false) {
        sfpmgr_sfp_rxlos(cage_info->cage_id);
    } else {
        sfpmgr_sfp_rxlos_cleared(cage_info->cage_id);
    }
}


/**
 * @brief Detects the presence and type of an SFP module based on the cage's I2C data.
 *
 * This function reads values from buffers associated with the SFP module and determines:
 * - Whether the SFP module is present.
 * - The loss of signal (Rx LOS) status of the SFP.
 * - The type of the SFP module (Copper, GPON, XGSPON, or Active Ethernet).
 *
 * It reads from I2C buffers, checks the Rx LOS state, and determines the SFP type based on the nominal bitrate.
 * The results are stored in the provided output parameters.
 *
 * @param[out] present A pointer to a boolean indicating whether the SFP is present (`true`) or not (`false`).
 * @param[out] rx_los A pointer to a boolean indicating the status of the Rx Loss of Signal (`true` if there is LOS, `false` otherwise).
 * @param[out] sfp_type A pointer to an integer that will be set to the detected SFP type (e.g., `GPON`, etc.).
 * @param[in] ifName The interface name associated with the SFP module, used to retrieve buffer values and check Rx LOS state.
 *
 * @return Returns `true` if detection was successful, `false` otherwise.
 */
int discover_detect_sfp (bool* present, bool* rx_los, sfp_types_e* sfp_type, char* ifName) {
    int retval = SFPMGR_INVALID;
    amxc_var_t data;
    amxc_var_t ret;

    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "InterfaceName", ifName);

    retval = mod_sfps_execute_function("sfptype-poll", &data, &ret);
    when_failed(retval, exit);

    *present = GET_BOOL(&ret, "Present");
    *rx_los = GET_BOOL(&ret, "RxLoss");
    *sfp_type = GET_UINT32(&ret, "SFPType");

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);

    return retval;
}

/**
 * @brief Stops the SFP discovery process.
 *
 * @return Returns a status code indicating the success of the operation (SFPMGR_SUCCESS).
 */
int discovery_stop (void) {
    amxp_timer_delete(&s_timer_discovery);
    return SFPMGR_SUCCESS;
}

/**
 * @brief Retrieve and set the number of cages.
 */
static void determine_nr_of_cages(void) {
    amxd_object_t* sfps_obj = amxd_dm_findf(sfp_get_dm(), SFPS_PATH);
    uint32_t cages_count = 0;

    when_null(sfps_obj, exit);

    cages_count = amxd_object_get_value(uint32_t, sfps_obj, "SFPCageNumberOfEntries", NULL);

exit:
    s_max_cage = cages_count;
}

/**
 * @brief Retrieves the maximum number of cages.
 *
 * This function returns the maximum number of cages stored in the `s_max_cage` variable.
 *
 * @return int The maximum number of cages.
 */
int get_max_cage(void) {
    return s_max_cage;
}

void set_max_cage(size_t maxcage) {
    s_max_cage = maxcage;
}

/**
 * @brief Fills the SFP cage information.
 *
 * This function retrieves cage details using the given index and populates the provided
 * `sfp_cage_t` structure with the cage's ID and interface name.
 *
 * @param cage_index The index of the SFP cage.
 * @param cage_info Pointer to the structure to store cage information.
 *
 * @return 0 on success, -1 if no information is found.
 */
static int populate_cage(int cage_index, sfp_cage_t* cage_info) {
    amxd_object_t* sfp_cage_obj = amxd_dm_findf(sfp_get_dm(), SFP_CAGE_PATH, cage_index);

    if(!sfp_cage_obj) {
        SAH_TRACEZ_ERROR(ME, "Error: Failed to get SFPCage object with index %d", cage_index);
        return SFPMGR_INVALID;
    }

    cstring_t ifName = amxd_object_get_value(cstring_t, sfp_cage_obj, "Name", NULL);

    cage_info->cage_id = cage_index;
    strncpy(cage_info->ifName, ifName, sizeof(cage_info->ifName));

    free(ifName);

    return SFPMGR_SUCCESS;
}

/**
 * @brief Frees memory allocated for SFP cage objects.
 *
 * This function iterates through all SFP cages and frees the memory
 * allocated for each cage object, including transceiver and optical
 * information.
 */
void free_cage(void) {
    amxc_llist_clean(&sfp_cage_list, NULL);
    for(int i = 1; i <= get_max_cage(); i++) {
        sfp_cage_t* cage_info = get_sfp_cage_info(i);
        if(cage_info != NULL) {
            free(cage_info);
        }

        sfp_info_t* sfp_info = get_sfp_cage_info_trans(i);
        if(sfp_info != NULL) {
            free(sfp_info);
        }

        optical_info_t* optical_info = get_sfp_cage_info_optical(i);
        if(optical_info != NULL) {
            free(optical_info);
        }
    }
}

