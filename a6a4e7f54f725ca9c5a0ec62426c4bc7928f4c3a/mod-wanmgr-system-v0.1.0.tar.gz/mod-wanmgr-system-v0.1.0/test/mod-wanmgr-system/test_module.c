/**
 * @file test_module.c
 *
 * @brief This file contains unit test of mod wanmgr system
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#if defined(SAHTRACES_ENABLED)
#include <debug/sahtrace.h>
#endif
 #include <amxp/amxp.h>
 #include <amxp/amxp_signal.h>
 #include <amxp/amxp_slot.h>
 #include <amxd/amxd_dm.h>
 #include <amxd/amxd_types.h>
 #include <amxd/amxd_action.h>

#include <amxp/amxp_signal.h>
#include <amxb/amxb.h>
#include <amxb/amxb_be_mngr.h>
#include <amxb/amxb_register.h>
#include <amxb/amxb_connect.h>


#include "test_module.h"
#include "mod_wanmgr_system.h"

#define MOD_NAME "target_module"
#define MOD_PATH "../modules_under_test/" MOD_NAME ".so"
#define ME                      "mod-wmmsys-sys"
#define MOD_WANMGR_SYSTEM_CTRL  "mod-wmmsys-ctrl"

static amxd_dm_t dm;
static amxo_parser_t parser;
static amxb_bus_ctx_t* bus_ctx = NULL;
amxd_object_t* root = NULL;

amxd_dm_t* get_dm(void);

/**
 * @brief Get the data management (DM) context.
 *
 * Returns a pointer to the DM context used for managing data operations.
 *
 * @return amxd_dm_t* Pointer to the DM context.
 */
amxd_dm_t* get_dm(void) {
    return &dm;
}

static amxd_status_t _reboot(UNUSED amxd_object_t* object,
                             UNUSED amxd_param_t* param,
                             UNUSED amxd_action_t reason,
                             UNUSED const amxc_var_t* const args,
                             UNUSED amxc_var_t* const retval,
                             UNUSED void* priv) {

    return amxd_status_ok;
}

/**
 * @brief Test `request-system-update` with valid inputs.
 *
 * This test checks that the function works correctly when provided with
 * valid arguments.
 *
 * @param state [UNUSED] Test state parameter.
 */
void test_request_system_update_valid(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &args, "dummy", true);

    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_WANMGR_SYSTEM_CTRL, "request-system-update", &args, &ret), 0);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}
/**
 * @brief Test `request-system-update` with null arguments.
 *
 * This test ensures the function handles null arguments gracefully.
 *
 * @param state [UNUSED] Test state parameter.
 */

void test_request_system_update_null_args(UNUSED void** state) {
    amxc_var_t* args = NULL;
    // Call the function with NULL args and verify it still returns success
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_WANMGR_SYSTEM_CTRL, "request-system-update", args, NULL), -1);
}

// Check if the function is present
void test_has_functions(UNUSED void** state) {
    assert_true(amxm_has_function(MOD_NAME, MOD_WANMGR_SYSTEM_CTRL, "request-system-update"));
}

// Loading the mod wanmgr system module
void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

// unloading the mod wanmgr system module
void test_can_close_module(UNUSED void** state) {
    assert_int_equal(amxm_close_all(), 0);
}

int test_setup(UNUSED void** state) {
#if defined(SAHTRACES_ENABLED)
    sahTraceOpen("unittest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "mod-wanmgr-system");
#endif
    amxd_dm_init(&dm);
    amxo_parser_init(&parser);
    root = amxd_dm_get_root(&dm);
    assert_non_null(root);

    assert_int_equal(amxo_resolver_ftab_add(&parser, "Reboot", AMXO_FUNC(_reboot)), 0);
    system("ubusd &");
    assert_int_equal(amxb_be_load("/usr/bin/mods/amxb/mod-amxb-ubus.so"), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "ubus:"), 0);
    amxb_set_access(bus_ctx, amxd_dm_access_public);
    amxb_register(bus_ctx, &dm);
    amxo_parser_parse_file(&parser, "../mocks/datamodel/remote_dm.odl", root);

    return 0;
}

int test_teardown(UNUSED void** state) {
    /* Stopping the the ubusd process
     * in the test teardown */
    system("killall ubusd");
    amxb_be_remove_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}
