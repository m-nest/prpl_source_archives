/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tr181-dns.h"
#include "host/dm_host.h"
#include "dm_relay.h"
#include "dm_common.h"
#include "netdevname.h"
#include "host/host.h"
#include "internal_zone.h"

#include <amxd/amxd_transaction.h>
#include <debug/sahtrace_macros.h>
#include <ipat/ipat.h>

#define ME "host"

void _host_added(UNUSED const char* const sig_name,
                 const amxc_var_t* const data,
                 UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(get_dm(), data);
    amxd_object_t* obj = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));
    when_null(obj, exit);
    host_changed(obj);
exit:
    return;
}

amxd_status_t _host_removed(amxd_object_t* obj,
                            UNUSED amxd_param_t* param,
                            amxd_action_t reason,
                            UNUSED const amxc_var_t* const args,
                            UNUSED amxc_var_t* const retval,
                            UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    host_t* host = NULL;

    when_null(obj, exit);
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);

    host = (host_t*) obj->priv;
    when_null_status(host, exit, status = amxd_status_ok);

    SAH_TRACEZ_INFO(ME, "Object[%s] is about to be destroyed", host->name);

    host_disable(host, true);
    host_delete(&host);
    obj->priv = NULL;

    status = amxd_status_ok;
exit:
    return status;
}

void _host_changed(UNUSED const char* const sig_name,
                   const amxc_var_t* const data,
                   UNUSED void* const priv) {
    amxd_object_t* obj = amxd_dm_signal_get_object(get_dm(), data);
    host_t* host = NULL;
    const char* old_hostname = NULL;

    when_null(obj, exit);
    when_null(obj->priv, exit);
    host = (host_t*) obj->priv;

    if(host->old_hostname != NULL) {
        SAH_TRACEZ_ERROR(ME, "old_hostname should be NULL");
        FREE(host->old_hostname);
    }

    old_hostname = GETP_CHAR(data, "parameters.Name.from");
    if(!STRING_EMPTY(old_hostname)) {
        host->old_hostname = strdup(old_hostname);
    }

    if(GETP_ARG(data, "parameters.Interface.to")) {
        host_disable(host, true);
    }

    host_changed(obj);
exit:
    return;
}

void _host_address_added(UNUSED const char* const sig_name,
                         const amxc_var_t* const data,
                         UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(get_dm(), data);
    amxd_object_t* ipaddress_obj = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));
    amxd_object_t* host_obj = NULL;
    host_addr_t* host_addr = NULL;
    host_t* host = NULL;
    bool address_is_dynamic = false;

    when_null(ipaddress_obj, exit);
    host_obj = amxd_object_findf(ipaddress_obj, ".^.^");
    host = (host_t*) host_obj->priv;
    when_null_trace(host, exit, ERROR, "Host %s priv data is empty", amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED));
    address_is_dynamic = amxd_object_get_value(bool, host_obj, "QueryAddresses", NULL);

    if((address_is_dynamic || !host->is_static)) {
        unset_object_persistency(ipaddress_obj);
    }

    when_true_trace(address_is_dynamic, exit, INFO, "%s change ignored", amxd_object_get_name(ipaddress_obj, AMXD_OBJECT_NAMED));

    if(ipaddress_obj->priv == NULL) {
        host_addr = host_addr_new(ipaddress_obj);
        when_null(host_addr, exit);
    } else {
        host_addr = (host_addr_t*) ipaddress_obj->priv; // maybe amx handled Host-added event before IPAddress-added event
    }

    host_add_ipaddr(host_addr);
exit:
    return;
}

amxd_status_t _host_address_removed(amxd_object_t* obj,
                                    UNUSED amxd_param_t* param,
                                    amxd_action_t reason,
                                    UNUSED const amxc_var_t* const args,
                                    UNUSED amxc_var_t* const retval,
                                    UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    host_addr_t* host_addr = NULL;

    when_null(obj, exit);
    when_true_status(reason != action_object_destroy,
                     exit,
                     status = amxd_status_function_not_implemented);

    host_addr = (host_addr_t*) obj->priv;
    when_null_status(host_addr, exit, status = amxd_status_ok);

    SAH_TRACEZ_INFO(ME, "Object[%s] is about to be destroyed", host_addr->name);

    host_remove_ipaddr(host_addr);
    host_addr_delete(&host_addr);
    obj->priv = NULL;

    status = amxd_status_ok;
exit:
    return status;
}

void _host_address_changed(UNUSED const char* const sig_name,
                           const amxc_var_t* const data,
                           UNUSED void* const priv) {
    amxd_object_t* ipaddress_obj = amxd_dm_signal_get_object(get_dm(), data);
    amxd_object_t* host_obj = NULL;
    host_addr_t* host_addr = NULL;
    const char* from = NULL;

    when_null(ipaddress_obj, exit);

    host_obj = amxd_object_findf(ipaddress_obj, ".^.^");
    when_true_trace(amxd_object_get_value(bool, host_obj, "QueryAddresses", NULL), exit, INFO, "%s change ignored", amxd_object_get_name(ipaddress_obj, AMXD_OBJECT_NAMED));

    when_null_trace(ipaddress_obj->priv, exit, ERROR, "%s priv data is NULL", amxd_object_get_name(ipaddress_obj, AMXD_OBJECT_NAMED));
    host_addr = (host_addr_t*) ipaddress_obj->priv;

    from = GETP_CHAR(data, "parameters.IPAddress.from");
    if(!STRING_EMPTY(from)) {
        host_addr->old_ipaddr = strdup(from);
        when_null(host_addr->old_ipaddr, exit);
        host_remove_ipaddr(host_addr);
    }
    host_add_ipaddr(host_addr);
exit:
    return;
}

void hosts_start(void) {
    amxd_object_for_each(instance, it, amxd_dm_findf(get_dm(), "DNS.%sHost.", get_prefix())) {
        amxd_object_t* obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        host_changed(obj);
    }
}
