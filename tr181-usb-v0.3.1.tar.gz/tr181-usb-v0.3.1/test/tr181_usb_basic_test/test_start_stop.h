/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/

#ifndef __TEST_START_STOP_H__
#define __TEST_START_STOP_H__

int test_setup(void** state);
int test_teardown(void** state);

void test_exec_addBus(void** state);
void test_exec_addDev(void** state);
void test_exec_reset(void** state);
void test_exec_eject(void** state);
void test_exec_delDev(void** state);
void test_pwr_status(void** state);
void test_power_state_validator(void** state);
void test_usb_port_added(void** state);

#endif // __TEST_START_STOP_H__
