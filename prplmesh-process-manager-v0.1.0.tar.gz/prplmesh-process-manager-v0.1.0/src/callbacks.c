/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2026 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file callbacks.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contain callbacks implementation for datamodel
 *        described in prplmesh-process-manager_definition.odl file.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2026 Inango
 *
 */


#include <amxc/amxc.h>
#include <amxc/amxc_aqueue.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_variant.h>

#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_parameter.h>
#include <amxd/amxd_object_hierarchy.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxrt/amxrt.h>

#include <amxo/amxo.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <stdbool.h>
#include <string.h>

#include "service.h"
#include "callbacks.h"

#define ME "cb"                                                                /*!< File name for SAH Logger. Highlights service source file */

static bool app_started = false;                                               /*!< Global variable, describes state of Process Manager app */
static bool prplmesh_is_enabled = false;                                       /*!< Global variable, describes state of prplMesh service */

static ServiceFaultCode service_last_fault_code[SERVICE_KIND_MAX] = {0, };     /*!< Global fault code array per service */
static ServiceStatus service_status[SERVICE_KIND_MAX] = {0, };                 /*!< Global status array per service*/

static bool service_control_request_in_progress[SERVICE_KIND_MAX] = {false, }; /*!< If true, service control request is in progress */
static amxc_aqueue_t service_control_requests[SERVICE_KIND_MAX];               /*!< Pending service control requests */
/** Array [queue] can't store NULL pointers, so add/subtract 1 to/from `action` (which can be 0) when storing/retrieving */
static const int array_value_offset = 1;

/**
 * @brief Initializes service control requests queues.
 */
CONSTRUCTOR static void service_control_requests_init(void) {
    for(int i = 0; i < SERVICE_KIND_MAX; i++) {
        amxc_aqueue_init(&service_control_requests[i]);
    }
}

/**
 * @brief Cleans up service control requests queues.
 */
DESTRUCTOR static void service_control_requests_deinit(void) {
    for(int i = 0; i < SERVICE_KIND_MAX; i++) {
        amxc_aqueue_clean(&service_control_requests[i], NULL);
    }
}

static void next_service_control_request(ServiceKind service);

/**
 * @brief Helper function for updating status of choosen application.
 *
 * @param service application name
 * @param enable application current status
 */
static void update_service_status(ServiceKind service, bool enable) {
    if(enable) {
        service_status[service] = SERVICE_STATUS_STARTING;
    } else {
        service_status[service] = SERVICE_STATUS_STOPPING;
    }
}

/**
 * @brief get transaction instance for service
 *
 * @param service service type to get transaction for
 *
 * @return amxd_trans_t instance for state object for service
 */
static amxd_trans_t* get_transaction_for_service(ServiceKind service) {
    amxd_trans_t* transaction = NULL;
    const char* service_name = NULL;

    switch(service) {
    case SERVICE_KIND_PRPLMESH:
        service_name = "PrplMesh";
        break;
    case SERVICE_KIND_PWHM:
        service_name = "PWHM";
        break;
    case SERVICE_KIND_SENSING:
        service_name = "Sensing";
        break;
    default:
        goto exit;
    }

    amxd_object_t* service_obj = amxd_dm_findf(amxrt_get_dm(), PROCESS_MANAGER_ROOT "%s.", service_name);
    when_null(service_obj, exit);

    amxd_trans_new(&transaction);
    amxd_trans_set_attr(transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(transaction, service_obj);

exit:
    return transaction;
}

/**
 * @brief Update service's status in a transaction
 *
 * @param status new status of the service
 * @param[in, out] transaction transaction in which update happens
 */
static void update_service_status_transaction(ServiceStatus status, amxd_trans_t* transaction) {
    const char* status_cstr = NULL;
    switch(status) {
    case SERVICE_STATUS_ERROR:
        status_cstr = "Error";
        break;

    case SERVICE_STATUS_IDLE:
        status_cstr = "Idle";
        break;

    case SERVICE_STATUS_RUNNING:
        status_cstr = "Active";
        break;

    case SERVICE_STATUS_STOPPING:
        status_cstr = "Stopping";
        break;

    case SERVICE_STATUS_STARTING:
        status_cstr = "Starting";
        break;
    }
    amxd_trans_set_value(cstring_t, transaction, "Status", status_cstr);
}

/**
 * @brief Update service's fault code in a transaction
 *
 * @param fault_code new fault code of the service
 * @param[in, out] transaction transaction in which update happens
 */
static void update_service_fault_code_transaction(ServiceFaultCode fault_code, amxd_trans_t* transaction) {
    const char* fault_code_cstr = NULL;
    switch(fault_code) {
    case SERVICE_NO_FAULT:
        fault_code_cstr = "NoFault";
        break;

    case SERVICE_FAULT_ON_START:
        fault_code_cstr = "FailureOnStart";
        break;

    case SERVICE_FAULT_ON_STOP:
        fault_code_cstr = "FailureOnStop";
        break;
    }

    amxd_trans_set_value(cstring_t, transaction, "FaultCode", fault_code_cstr);
}

/**
 * @brief Update service's status and fault code.
 *
 * @param service service type to update
 * @param status new status of the service
 * @param fault_code new fault code of the service
 */
static void update_service_status_and_fault_code(ServiceKind service, ServiceStatus status, ServiceFaultCode fault_code) {
    amxd_trans_t* transaction = get_transaction_for_service(service);
    when_null_trace(transaction, exit, WARNING, "Failed to get transaction for service %d", service);

    update_service_status_transaction(status, transaction);
    update_service_fault_code_transaction(fault_code, transaction);

    amxd_status_t transaction_status = amxd_trans_apply(transaction, amxrt_get_dm());
    if(transaction_status != amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Failed to apply transaction, got %d", transaction_status);
    }

    amxd_trans_delete(&transaction);

exit:
    return;
}

/**
 * @brief Callback for common service change status operations
 *
 * @param result Service control result with service and exit code
 */
static void _subproc_sighandler(ServiceControlResult result) {
    int64_t ret_code = result.ret_code;
    ServiceKind service = result.service;
    SAH_TRACEZ_INFO(ME, "signal slot handler: info return code:(%" PRId64 ")", ret_code);

    if(ret_code == 0) {
        service_last_fault_code[service] = SERVICE_NO_FAULT;
        if(service_status[service] == SERVICE_STATUS_STARTING) {
            service_status[service] = SERVICE_STATUS_RUNNING;
        } else if(service_status[service] == SERVICE_STATUS_STOPPING) {
            service_status[service] = SERVICE_STATUS_IDLE;
        } else {
            SAH_TRACEZ_INFO(ME, "slot handler: service(%d) status (%d) non-zero return in unexpected status", service, service_status[service]);
        }
    } else {
        if(service_status[service] == SERVICE_STATUS_STARTING) {
            service_last_fault_code[service] = SERVICE_FAULT_ON_START;
        } else if(service_status[service] == SERVICE_STATUS_STOPPING) {
            service_last_fault_code[service] = SERVICE_FAULT_ON_STOP;
        } else {
            SAH_TRACEZ_INFO(ME, "slot handler: service(%d) status (%d) non-zero return in unexpected status", service, service_status[service]);
        }
        service_status[service] = SERVICE_STATUS_ERROR;
    }

    update_service_status_and_fault_code(service, service_status[service], service_last_fault_code[service]);

    service_control_request_in_progress[service] = false;
    next_service_control_request(service);
}

/**
 * @brief Callback for special case of changing prplMesh Management Mode
 * Update prplMesh status field during mode change.
 *
 * @param result Service control result with service and exit code
 */
static void _switchmode_sighandler(ServiceControlResult result) {
    int64_t ret_code = result.ret_code;
    SAH_TRACEZ_INFO(ME, "signal slot handler: info return code:(%" PRId64 ")", ret_code);

    if(ret_code == 0) {
        SAH_TRACEZ_INFO(ME, "switchmode: prplmesh stopped, now starting again");
        service_last_fault_code[SERVICE_KIND_PRPLMESH] = SERVICE_NO_FAULT;
        update_service_status(SERVICE_KIND_PRPLMESH, true);
        if(process_monitor_service_control(SERVICE_KIND_PRPLMESH, SERVICE_ACTION_START, _subproc_sighandler)) {
            service_last_fault_code[SERVICE_KIND_PRPLMESH] = SERVICE_FAULT_ON_START;
            service_status[SERVICE_KIND_PRPLMESH] = SERVICE_STATUS_ERROR;
            service_control_request_in_progress[SERVICE_KIND_PRPLMESH] = false;
        }
    } else {
        SAH_TRACEZ_INFO(ME, "stop for mode switch failed: %" PRId64, ret_code);
        service_last_fault_code[SERVICE_KIND_PRPLMESH] = SERVICE_FAULT_ON_STOP;
        service_status[SERVICE_KIND_PRPLMESH] = SERVICE_STATUS_ERROR;
        service_control_request_in_progress[SERVICE_KIND_PRPLMESH] = false;
    }

    update_service_status_and_fault_code(SERVICE_KIND_PRPLMESH, service_status[SERVICE_KIND_PRPLMESH], service_last_fault_code[SERVICE_KIND_PRPLMESH]);
    next_service_control_request(SERVICE_KIND_PRPLMESH);
}

/**
 * @brief Process the next service control request from the queue for the given service
 *
 * @param service The service for which to process the next request
 */
static void next_service_control_request(ServiceKind service) {
    amxc_aqueue_t* queue = &service_control_requests[service];

    SAH_TRACEZ_INFO(ME, "service: %d, already in progress: %d, queue size: %zu",
                    service, service_control_request_in_progress[service], amxc_aqueue_size(queue));

    if(service_control_request_in_progress[service] || amxc_aqueue_is_empty(queue)) {
        return;
    }

    ServiceAction action = (ServiceAction) (intptr_t) amxc_aqueue_remove(queue) - array_value_offset;
    if((service == SERVICE_KIND_PRPLMESH) && (action == SERVICE_ACTION_RESTART)) {
        update_service_status(SERVICE_KIND_PRPLMESH, false);
        when_failed(process_monitor_service_control(SERVICE_KIND_PRPLMESH, SERVICE_ACTION_STOP, _switchmode_sighandler), exit_error);
    } else {
        update_service_status(service, action == SERVICE_ACTION_START);
        when_failed(process_monitor_service_control(service, action, _subproc_sighandler), exit_error);
    }
    service_control_request_in_progress[service] = true;
    update_service_status_and_fault_code(service, service_status[service], service_last_fault_code[service]);

    return;

exit_error:
    update_service_status_and_fault_code(service, SERVICE_STATUS_ERROR, (action == SERVICE_ACTION_START) ? SERVICE_FAULT_ON_START : SERVICE_FAULT_ON_STOP);
    next_service_control_request(service);
}

/**
 * @brief Schedule a service control request to be processed
 * Adds the given action to the queue of pending service control requests
 * for the given service and schedules the next request to be processed
 *
 * @param service The service to which the request refers
 * @param action The action to be performed on the service
 */
static void schedule_service_control(ServiceKind service, ServiceAction action) {
    amxc_aqueue_add(&service_control_requests[service], (void*) (intptr_t) (action + array_value_offset));
    next_service_control_request(service);
}

/**
 * @brief Callback for app:start event, prints that application
 * started in the log file.
 *
 * @param event_name name of the event
 * @param data pointer to the ambiorix data (unused)
 * @param priv pointer to the additional data (unused)
 */
void _process_manager_start(
    const char* const event_name,
    UNUSED const amxc_var_t* const data,
    UNUSED void* const priv
    ) {
    SAH_TRACEZ_INFO(ME, "%s", event_name);
    app_started = true;
}

/**
 * @brief Handler of AMX object-changed event for PWHM object.
 * Initiates internal enable-disable routines
 *
 * @param event_name the name of the signal
 * @param data the data of the signal
 * @param priv unused
 */
void _pwhm_object_changed(
    const char* const event_name,
    const amxc_var_t* const data,
    UNUSED void* const priv
    ) {
    SAH_TRACEZ_INFO(ME, "%s", __func__);
    amxc_var_t* parameters = GET_ARG(data, "parameters");

    amxc_var_t* enable_p = GET_ARG(parameters, "Enable");
    if(enable_p) {
        bool enable = GET_BOOL(enable_p, "to");
        schedule_service_control(SERVICE_KIND_PWHM, enable);
    }
}

/**
 * @brief Handler of AMX object-changed event for Sensing object.
 * Initiates internal enable-disable routines
 *
 * @param event_name the name of the signal
 * @param data the data of the signal
 * @param priv unused
 */
void _sensing_object_changed(
    const char* const event_name,
    const amxc_var_t* const data,
    UNUSED void* const priv
    ) {
    SAH_TRACEZ_INFO(ME, "%s", __func__);
    amxc_var_t* parameters = GET_ARG(data, "parameters");

    amxc_var_t* enable_p = GET_ARG(parameters, "Enable");
    if(enable_p) {
        bool enable = GET_BOOL(enable_p, "to");
        schedule_service_control(SERVICE_KIND_SENSING, enable);
    }
}

/**
 * @brief Handler of AMX object-changed event for prplMesh object.
 * Initiates internal enable-disable routines.
 * Handles special case of restart for case of changing ManagementMode
 *
 * @param event_name the name of the signal
 * @param data the data of the signal
 * @param priv unused
 */
void _prplmesh_object_changed(
    const char* const event_name,
    const amxc_var_t* const data,
    UNUSED void* const priv
    ) {
    SAH_TRACEZ_INFO(ME, "%s", __func__);
    amxc_var_t* parameters = GET_ARG(data, "parameters");

    amxc_var_t* certification_mode_p = GET_ARG(parameters, "CertificationMode");
    if(certification_mode_p) {
        bool certification_mode = GET_BOOL(certification_mode_p, "to");
        SAH_TRACEZ_INFO(ME, "Requested certification mode: %d", certification_mode);
    }

    amxc_var_t* management_mode_p = GET_ARG(parameters, "ManagementMode");
    if(management_mode_p) {
        const char* management_mode = GET_CHAR(management_mode_p, "to");
        SAH_TRACEZ_INFO(ME, "Requested management mode: %s", management_mode);
    }

    amxc_var_t* enable_p = GET_ARG(parameters, "Enable");
    if(enable_p) {
        bool enable = GET_BOOL(enable_p, "to");
        prplmesh_is_enabled = enable;
    }

    // Restart when management or certification mode is changed while prplMesh is (being) enabled
    // (restart is expected to be equivalent to start if prplMesh wasn't running)
    // Suppress restarts until app:start is received, i.e. while ODL files are being loaded
    bool need_restart = (management_mode_p || certification_mode_p) && prplmesh_is_enabled && app_started;
    if(need_restart) {
        SAH_TRACEZ_INFO(ME, "Restarting prplMesh because management or certification mode changed");
        schedule_service_control(SERVICE_KIND_PRPLMESH, SERVICE_ACTION_RESTART);
        return;
    }

    // When no ManagementMode is involved, or prplMesh is (being) disabled,
    // just start or stop
    if(enable_p) {
        schedule_service_control(SERVICE_KIND_PRPLMESH, prplmesh_is_enabled);
        return;
    }
}

void update_services_statuses_callback(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    ServiceKind services[] = {SERVICE_KIND_SENSING, SERVICE_KIND_PWHM, SERVICE_KIND_PRPLMESH};

    for(int i = 0; i != sizeof(services) / sizeof(services[0]); ++i) {
        ServiceKind service = services[i];

        const ServiceFaultCode service_fault = service_last_fault_code[service];

        ServiceStatus service_live_status;
        if(service_fault == SERVICE_NO_FAULT) {
            service_live_status = process_monitor_service_status(service);

            if((service_live_status == SERVICE_STATUS_IDLE) && (service_status[service] == SERVICE_STATUS_STARTING)) {
                service_live_status = SERVICE_STATUS_STARTING;
            }

            if((service_live_status == SERVICE_STATUS_RUNNING) && (service_status[service] == SERVICE_STATUS_STOPPING)) {
                service_live_status = SERVICE_STATUS_STOPPING;
            }
        } else {
            service_live_status = SERVICE_STATUS_ERROR;
        }

        service_status[service] = service_live_status;
        update_service_status_and_fault_code(service, service_live_status, service_fault);
    }
}
