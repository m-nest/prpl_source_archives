/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#if !defined(_MQTT_GET_CERTIFICATE_URI_)
#define _MQTT_GET_CERTIFICATE_URI_

/**
   @brief Retrieves the certificate and private key URIs for a given path.

   This function calls the "GetCertificateURI" method on the backend associated with the provided `fullpath`.

   @param[in]  fullpath  A path name of a row in the Security.Certificate table, e.g. "Security.Certificate.1."
   @param[out] certuri   Pointer to a string that will be allocated and set to the certificate URI.
   @param[out] keyuri    Pointer to a string that will be allocated and set to the private key URI.

   @return 0 on success, -1 on failure.

   @note The caller is responsible for freeing the memory allocated for `*certuri` and `*keyuri`.
 */
int get_certificate_uri(const char* fullpath, char** certuri, char** keyuri);

#endif