MACHINE = $(shell $(CC) -dumpmachine)

SRCDIR = $(realpath ../../src)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR = $(realpath ../../include_priv)
INCDIR += $(realpath ../common)

SOURCES = $(wildcard $(SRCDIR)/*.c)

COMMON_TEST_SRC_DIR = ../common
COMMON_TEST_SOURCES = $(wildcard $(COMMON_TEST_SRC_DIR)/*.c)
COMMON_TEST_OBJ_DIR = $(OBJDIR)/common
COMMON_TEST_OBJECTS += $(addprefix $(COMMON_TEST_OBJ_DIR)/,$(notdir $(COMMON_TEST_SOURCES:.c=.o)))

CFLAGS += -Werror -Wall -Wextra -Wno-attributes\
          --std=gnu99 -g3 -Wmissing-declarations \
          $(addprefix -I ,$(INCDIR)) \
          -fkeep-inline-functions -fkeep-static-functions \
          -Wno-format-nonliteral -Wno-unused-variable \
          -Wno-unused-but-set-variable \
          $(shell pkg-config --cflags cmocka) \
          -DSAHTRACES_ENABLED -DSAHTRACES_LEVEL_DEFAULT=500

CFLAGS += -DMAX_NR_OF_ONUS=1

LDFLAGS += -fkeep-inline-functions -fkeep-static-functions \
           $(shell pkg-config --libs cmocka) \
           -lamxo -lamxb -lamxd -lamxp -lamxm -lamxc \
           -lsahtrace

# Link to dl because of dlerror() call
LDFLAGS += -ldl


