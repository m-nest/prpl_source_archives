/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "lua_amx.h"

/*
 * Internal function
 *
 * Is added to metatable for timestamp type (AMX.TimeStamp)
 *
 * Whenever the type is fetched as string, this method is called
 * and converts the amxc_ts_t to a RFC3339 timestamp string format
 * with nanosecond precision.
 *
 */
static int ts_mt_tostring(lua_State* L) {
    amxc_ts_t* lamx_ts = (amxc_ts_t*) luaL_checkudata(L, 1, lamx_ts_mt);
    char buffer[64];

    amxc_ts_format_precision(lamx_ts, buffer, 64, 6);
    lua_pushstring(L, buffer);

    return 1;
}

/***
   Ambiorix LUA timestamp class
   @classmod timestamp
 */

/***
   Create a new timestamp

   @usage
   local ts = lamx.timestamp.new()
   local ts = lamx.timestamp.new("2025-12-09T13:23:23Z")
   local ts = lamx.timestamp.new(0)

   @function lamx.timestamp.new

   @param time (optional, default = 0) Number|String - Number of seconds since epoch or RFC3339 timestamp string
   @param nsecs (optional, default = 0) Nanoseconds
   @param offset (optional, default = 0) Time zone offset

   Without any arguments, the timestamp is filled with the current time.

   @return
   Timestamp.
 */
static int lamx_ts_new(lua_State* L) {
    amxc_ts_t ts = { 0, 0, 0};
    if(lua_gettop(L) != 0) {
        if(lua_isnumber(L, 1)) {
            ts.sec = luaL_checkinteger(L, 1);
            ts.nsec = luaL_optinteger(L, 2, 0);
            ts.offset = luaL_optinteger(L, 3, 0);
        } else {
            size_t len = 0;
            const char* ts_str = luaL_checklstring(L, 1, &len);
            if(amxc_ts_parse(&ts, ts_str, len) != 0) {
                luaL_error(L, "Invalid RFC3339 string format");
            }
        }
    } else {
        amxc_ts_now(&ts);
    }

    lamx_push_timestamp(L, &ts);

    return 1;
}

/*
 * Internal function
 *
 * Pushes an amxc_ts_t on the LUA stack as full userdata
 * with metatable.
 *
 */
int lamx_push_timestamp(lua_State* L, const amxc_ts_t* ts) {
    amxc_ts_t* lamx_ts = (amxc_ts_t*) lua_newuserdata(L, sizeof(amxc_ts_t));

    luaL_getmetatable(L, lamx_ts_mt);
    lua_setmetatable(L, -2);
    lamx_ts->sec = ts->sec;
    lamx_ts->nsec = ts->nsec;
    lamx_ts->offset = ts->offset;

    return 1;
}

/*
 * Internal function
 *
 * Registers timestamp.new() method available.
 * Registers timestamp metatable.
 *
 */
void lamx_push_timestamp_mt(lua_State* L) {
    static struct luaL_Reg fns[] = {
        {"new", lamx_ts_new},
        {NULL, NULL}
    };

    if(luaL_newmetatable(L, lamx_ts_mt)) {
        static struct luaL_Reg metamethods[] = {
            {"__tostring", ts_mt_tostring },
            {NULL, NULL}
        };

        luaL_setfuncs(L, metamethods, 0);
        lua_pop(L, 1);  // The table is saved in the Lua's registry.
    }

    luaL_newlib(L, fns);  // Push a new table with fns key/vals.
    lua_setfield(L, -2, "timestamp");
}