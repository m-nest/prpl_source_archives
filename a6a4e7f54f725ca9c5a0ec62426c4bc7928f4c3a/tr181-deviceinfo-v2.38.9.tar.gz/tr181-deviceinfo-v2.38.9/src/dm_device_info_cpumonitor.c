/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_device_info_cpumonitor.h"
// Global array of pointers to cpu_usage_buffer_t, one per core
cpu_usage_buffer_t** cpu_usage_buffers = NULL;

resmon_cpu_monitor_t* cmon = NULL;

cpu_timer_ctx_t** cpu_timer_contexts = NULL;

uint64_t* prev_total = NULL;
uint64_t* prev_idle = NULL;
uint64_t* prev_agg_total = NULL;
uint64_t* prev_agg_idle = NULL;
uint64_t* prev_agg_user = NULL;
uint64_t* prev_agg_system = NULL;

static uint32_t max_cpu;

static void set_cpu_default_timestamp(char* dest, size_t size);

/**
 * @brief Sets a timestamp string in ISO 8601 format.
 * @param target Pointer to the target string buffer.
 */
static void set_timestamp(char* target);
/**
 * @brief Emits a memory critical event with usage data.
 */
static void raise_cpu_critical_event(uint32_t);

/**
 *========================================================================================================
 * @brief      _read_cpu_utilization
 * @details    Reads the total CPU utilization for a specific CPU instance by matching the object.
 *             Sets the retrieved value into the return variable.
 *
 * @param[in]  object   Pointer to the CPU monitoring object.
 * @param[in]  param    Pointer to the parameter being read (unused).
 * @param[in]  reason   Reason for the read operation (unused).
 * @param[in]  args     Additional arguments (unused).
 * @param[out] retval   Variable to store the retrieved CPU utilization.
 * @param[in]  priv     Private data (unused).
 *
 * @return     amxd_status_t  Status of the read operation.
 *========================================================================================================
 */
amxd_status_t _read_cpu_utilization(amxd_object_t* object,
                                    UNUSED amxd_param_t* param,
                                    UNUSED amxd_action_t reason,
                                    UNUSED const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    UNUSED void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    uint32_t instance = 0;
    bool found = false;
    amxd_dm_t* dm = NULL;
    char* parent_path = NULL;

    when_null_trace(retval, exit, ERROR, "read_cpu_utilization: retval is NULL");
    when_null_trace(object, exit, ERROR, "read_cpu_utilization: object is NULL");

    dm = deviceinfo_get_dm();
    when_null_trace(dm, exit, ERROR, "read_cpu_utilization: DM is NULL");

    // Extract instance from parent object hierarchy
    amxd_object_t* parent = amxd_object_get_parent(object);
    when_null(parent, exit);
    parent_path = amxd_object_get_path(parent, AMXD_OBJECT_INDEXED);
    when_null(parent_path, exit);

    if(strcmp(parent_path, RM_CPU_PATH) == 0) {
        uint32_t index = amxd_object_get_index(object);
        when_true(index == 0, exit); // Ensure we have a valid instance index
        instance = index - 1;        // Convert to 0-based
        found = true;
    }

    when_false(found, exit);

    status = amxc_var_set(uint32_t, retval, cmon[instance].total_cpu_usage);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "read_cpu_utilization: Failed to set return value");

    free(parent_path);
    return amxd_status_ok;

exit:
    free(parent_path);
    return status;
}

/**
 *========================================================================================================
 * @brief      _read_cpu_modes_and_uptime
 * @details    Reads specific CPU mode utilization values or uptime for a given CPU instance.
 *             Matches the object and sets the corresponding value into the return variable.
 *
 * @param[in]  object   Pointer to the CPU monitoring object.
 * @param[in]  param    Pointer to the parameter being read.
 * @param[in]  reason   Reason for the read operation (unused).
 * @param[in]  args     Additional arguments (unused).
 * @param[out] retval   Variable to store the retrieved value.
 * @param[in]  priv     Private data (unused).
 *
 * @return     amxd_status_t  Status of the read operation.
 *========================================================================================================
 */
amxd_status_t _read_cpu_modes_and_uptime(amxd_object_t* object,
                                         amxd_param_t* param,
                                         UNUSED amxd_action_t reason,
                                         UNUSED const amxc_var_t* const args,
                                         amxc_var_t* const retval,
                                         UNUSED void* priv) {
    const char* param_name = NULL;
    amxd_status_t status = amxd_status_invalid_function_argument;
    uint32_t instance = 0;
    bool found = false;
    amxd_dm_t* dm = NULL;
    char* parent_path = NULL;

    when_null_trace(param, exit, ERROR, "read_cpu_modes_and_uptime: param is NULL");
    when_null_trace(retval, exit, ERROR, "read_cpu_modes_and_uptime: retval is NULL");

    param_name = amxd_param_get_name(param);
    when_null_trace(param_name, exit, ERROR, "read_cpu_modes_and_uptime: param_name is NULL");
    when_null_trace(object, exit, ERROR, "read_cpu_modes_and_uptime: object is NULL");

    dm = deviceinfo_get_dm();
    when_null_trace(dm, exit, ERROR, "read_cpu_modes_and_uptime: DM is NULL");

    // Extract instance from parent object hierarchy
    amxd_object_t* parent = amxd_object_get_parent(object);
    when_null(parent, exit);
    parent_path = amxd_object_get_path(parent, AMXD_OBJECT_INDEXED);
    when_null(parent_path, exit);

    if(strcmp(parent_path, RM_CPU_PATH) == 0) {
        uint32_t index = amxd_object_get_index(object);
        when_true(index == 0, exit); // Ensure we have a valid instance index
        instance = index - 1;        // Convert to 0-based
        found = true;
    }

    when_false(found, exit);

    if(strcmp(param_name, RM_CPU_USER_MODE_UTILIZATION) == 0) {
        status = amxc_var_set(uint32_t, retval, cmon[instance].user_mode_usage);
    } else if(strcmp(param_name, RM_CPU_SYSTEM_MODE_UTILIZATION) == 0) {
        status = amxc_var_set(uint32_t, retval, cmon[instance].system_mode_usage);
    } else if(strcmp(param_name, RM_CPU_IDLE_MODE_UTILIZATION) == 0) {
        status = amxc_var_set(uint32_t, retval, cmon[instance].idle_mode_usage);
    } else if(strcmp(param_name, RM_CPU_UP_TIME) == 0) {
        status = amxc_var_set(uint64_t, retval, cmon[instance].up_time);
    } else {
        SAH_TRACEZ_ERROR(ME, "read_cpu_modes_and_uptime: Unknown parameter name: %s", param_name);
        status = amxd_status_invalid_function_argument;
    }

exit:
    free(parent_path);
    return status;
}
/**=======================================================================================================
 * @brief set_cpu_default_timestamp
 * @details sets default timestamp to the given string
 *==========================================================================================================*/
static void set_cpu_default_timestamp(char* dest, size_t size) {
    strncpy(dest, "0001-01-01T00:00:00Z", size - 1);
    dest[size - 1] = '\0';
}


/**
 *========================================================================================================
 * @brief      resmon_cpu_init
 * @details    Initializes CPU monitoring by allocating memory, retrieving configuration parameters,
 *             and starting monitoring for each CPU core. It sets thresholds, polling intervals, and timestamps.
 *
 * @return     void
 *========================================================================================================
 */
void _resmon_cpu_init(UNUSED const char* const sig_name,
                      UNUSED const amxc_var_t* const data,
                      UNUSED void* const priv) {
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxc_var_t value;

    SAH_TRACEZ_INFO(ME, "resmon_cpu_init: Initialization started");

    when_null_trace(dm, exit, ERROR, "resmon_cpu_init: DM is NULL");

    amxd_object_t* cpu_object = amxd_dm_findf(dm, RM_CPU_PATH);
    when_null_trace(cpu_object, exit, ERROR, "resmon_cpu_init: CPU Object is NULL");

    max_cpu = amxd_object_get_instance_count(cpu_object);
    when_true_trace((max_cpu == 0), exit, ERROR, "resmon_cpu_init: Incorrect Max CPU(%d)", max_cpu);

    cmon = calloc(max_cpu, sizeof(resmon_cpu_monitor_t));
    when_null_trace(cmon, exit, ERROR, "resmon_cpu_init: Memory allocation failed for CPU monitor");

    cpu_timer_contexts = calloc(max_cpu, sizeof(cpu_timer_ctx_t*));
    when_null_trace(cpu_timer_contexts, exit, ERROR, "resmon_cpu_init: Memory allocation failed for CPU timer contexts");

    prev_total = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_total, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_total");

    prev_idle = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_idle, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_idle");

    prev_agg_total = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_agg_total, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_agg_total");

    prev_agg_idle = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_agg_idle, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_agg_idle");

    prev_agg_user = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_agg_user, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_agg_user");

    prev_agg_system = calloc(max_cpu, sizeof(uint64_t));
    when_null_trace(prev_agg_system, exit, ERROR, "resmon_cpu_init: Memory allocation failed for prev_agg_system");

    uint32_t ret = cpu_usage_init(max_cpu);
    when_true_trace((ret != RM_CPU_SUCCESS), exit, ERROR, "resmon_cpu_init: CPU usage initialization failed");

    for(uint32_t i = 0; i < max_cpu; i++) {
        // Optimized: get instance directly from template without path lookup
        amxd_object_t* cpu_obj = amxd_object_get_instance(cpu_object, NULL, i + 1);

        if(cpu_obj == NULL) {
            SAH_TRACEZ_INFO(ME, "resmon_cpu_init: Skipping CPU index %u - object not found", i);
            continue;
        }

        amxc_var_init(&value);

        if(amxd_object_get_param(cpu_obj, RM_CPU_ENABLE, &value) == amxd_status_ok) {
            cmon[i].cpu_enabled = amxc_var_dyncast(bool, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_CRITICAL_FALL_THRESHOLD, &value) == amxd_status_ok) {
            cmon[i].fall_threshold = amxc_var_dyncast(uint32_t, &value);
        } else {
            cmon[i].fall_threshold = RM_CPU_FALL_THRESHOLD_DEFAULT;
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_CRITICAL_RISE_THRESHOLD, &value) == amxd_status_ok) {
            cmon[i].rise_threshold = amxc_var_dyncast(uint32_t, &value);
        } else {
            cmon[i].rise_threshold = RM_CPU_RISE_THRESHOLD_DEFAULT;
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_POLLING_INTERVAL, &value) == amxd_status_ok) {
            cmon[i].polling_interval = amxc_var_dyncast(uint32_t, &value);
        } else {
            cmon[i].polling_interval = RM_CPU_POLLING_INTERVAL_DEFAULT;
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_CPU_UTILIZATION, &value) == amxd_status_ok) {
            cmon[i].total_cpu_usage = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_SYSTEM_MODE_UTILIZATION, &value) == amxd_status_ok) {
            cmon[i].system_mode_usage = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_USER_MODE_UTILIZATION, &value) == amxd_status_ok) {
            cmon[i].user_mode_usage = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_IDLE_MODE_UTILIZATION, &value) == amxd_status_ok) {
            cmon[i].idle_mode_usage = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_UP_TIME, &value) == amxd_status_ok) {
            cmon[i].up_time = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_NUM_SAMPLES, &value) == amxd_status_ok) {
            cmon[i].num_samples = amxc_var_dyncast(uint32_t, &value);
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_CRITICAL_FALL_TIMESTAMP, &value) == amxd_status_ok) {
            const char* fall_ts = amxc_var_constcast(cstring_t, &value);
            if(fall_ts != NULL) {
                strncpy(cmon[i].fall_timestamp, fall_ts, sizeof(cmon[i].fall_timestamp) - 1);
                cmon[i].fall_timestamp[sizeof(cmon[i].fall_timestamp) - 1] = '\0';
            } else {
                set_cpu_default_timestamp(cmon[i].fall_timestamp, sizeof(cmon[i].fall_timestamp));
            }
        } else {
            set_cpu_default_timestamp(cmon[i].fall_timestamp, sizeof(cmon[i].fall_timestamp));
        }

        if(amxd_object_get_param(cpu_obj, RM_CPU_CRITICAL_RISE_TIMESTAMP, &value) == amxd_status_ok) {
            const char* rise_ts = amxc_var_constcast(cstring_t, &value);
            if(rise_ts != NULL) {
                strncpy(cmon[i].rise_timestamp, rise_ts, sizeof(cmon[i].rise_timestamp) - 1);
                cmon[i].rise_timestamp[sizeof(cmon[i].rise_timestamp) - 1] = '\0';
            } else {
                set_cpu_default_timestamp(cmon[i].rise_timestamp, sizeof(cmon[i].rise_timestamp));
            }
        } else {
            set_cpu_default_timestamp(cmon[i].rise_timestamp, sizeof(cmon[i].rise_timestamp));
        }

        amxc_var_clean(&value);
        resmon_start_cpu_monitor(i);
    }

exit:
    return;
}
/**
 *========================================================================================================
 * @brief      cpu_usage_init
 * @details    Allocates and initializes CPU usage buffers for each core.
 *
 * @param[in]  num_cores   Number of CPU cores to initialize buffers for.
 *
 * @return     int32_t     RM_CPU_SUCCESS on success, RM_CPU_FAILURE on failure.
 *========================================================================================================
 */
int32_t cpu_usage_init(uint32_t num_cores) {
    int32_t ret = RM_CPU_FAILURE;

    cpu_usage_buffers = malloc(num_cores * sizeof(cpu_usage_buffer_t*));
    when_null_trace(cpu_usage_buffers, exit, ERROR, "cpu_usage_init: Memory allocation failed for CPU usage buffers");

    for(uint32_t i = 0; i < num_cores; i++) {
        cpu_usage_buffers[i] = NULL;
    }

    ret = RM_CPU_SUCCESS;

exit:
    return ret;
}
/**
 *========================================================================================================
 * @brief      cpu_usage_buffer_create
 * @details    Allocates and initializes a circular buffer for storing CPU usage samples for a given core.
 *
 * @param[in]  core_index   Index of the CPU core.
 * @param[in]  buffer_size  Number of samples to store in the buffer.
 *
 * @return     int32_t      RM_CPU_SUCCESS on success, RM_CPU_FAILURE on error.
 *========================================================================================================
 */
int32_t cpu_usage_buffer_create(uint32_t core_index, int32_t buffer_size) {
    // Validate input parameters
    if((core_index >= max_cpu) || (buffer_size <= 0)) {
        return RM_CPU_FAILURE;
    }

    // Allocate buffer structure
    cpu_usage_buffer_t* buf = malloc(sizeof(cpu_usage_buffer_t));
    when_null_trace(buf, exit, ERROR, "cpu_usage_buffer_t memory allocation failed for index = %u", core_index);

    // Allocate sample array
    buf->samples = malloc(buffer_size * sizeof(double));
    if(!buf->samples) {
        free(buf);
        SAH_TRACEZ_ERROR(ME, "samples memory allocation failed for index = %u", core_index);
        return RM_CPU_FAILURE;
    }

    // Initialize buffer fields
    buf->head_index = 0;
    buf->sample_count = 0;
    buf->sample_sum = 0.0;
    buf->buffer_size = buffer_size;

    // Assign buffer to global array
    cpu_usage_buffers[core_index] = buf;
    return RM_CPU_SUCCESS;

exit:
    return RM_CPU_FAILURE;
}
/**
 *========================================================================================================
 * @brief      cpu_usage_buffer_clear
 * @details    Initializes the contents of an existing cpu_usage_buffer_t for the specified core index.
 *             Resets sample tracking fields to default values.
 *
 * @param[in]  core_index   Index of the CPU core whose buffer is to be initialized.
 *
 * @return     void
 *========================================================================================================
 */
void cpu_usage_buffer_clear(uint32_t core_index) {
    // Validate input index
    if((core_index >= max_cpu) || (cpu_usage_buffers[core_index] == NULL)) {
        SAH_TRACEZ_ERROR(ME, "cpu_usage_buffer_clear: Invalid core index or buffer not allocated for index = %u", core_index);
        return;
    }

    cpu_usage_buffer_t* buf = cpu_usage_buffers[core_index];

    // Reset buffer fields
    buf->head_index = 0;
    buf->sample_count = 0;
    buf->sample_sum = 0.0;

    // Optionally clear sample values
    if(buf->samples != NULL) {
        memset(buf->samples, 0, buf->buffer_size * sizeof(double));
    }

    return;
}

/**
 *========================================================================================================
 * @brief      cpu_usage_buffer_delete
 * @details    Frees the circular buffer and its sample array for the specified CPU core.
 *
 * @param[in]  core_index  Index of the CPU core.
 *========================================================================================================
 */
void cpu_usage_buffer_delete(uint32_t core_index) {
    // Validate core index and buffer existence
    if((core_index >= max_cpu) || !cpu_usage_buffers[core_index]) {
        return;
    }

    // Free sample array and buffer structure
    free(cpu_usage_buffers[core_index]->samples);
    free(cpu_usage_buffers[core_index]);
    cpu_usage_buffers[core_index] = NULL;
}

/**
 *========================================================================================================
 * @brief      cpu_usage_add_sample
 * @details    Adds a new CPU usage sample to the circular buffer for the specified core.
 *             If the buffer is full, it overwrites the oldest sample.
 *
 * @param[in]  core_index  Index of the CPU core.
 * @param[in]  sample      CPU usage sample to add.
 *
 * @return     int32_t     RM_CPU_SUCCESS on success, RM_CPU_FAILURE on invalid index or buffer.
 *========================================================================================================
 */
int32_t cpu_usage_add_sample(uint32_t core_index, double sample) {
    // Validate core index and buffer existence
    if((core_index >= max_cpu) || !cpu_usage_buffers[core_index]) {
        return RM_CPU_FAILURE;
    }

    cpu_usage_buffer_t* buf = cpu_usage_buffers[core_index];

    // If buffer not full, append sample
    if(buf->sample_count < buf->buffer_size) {
        buf->samples[buf->sample_count++] = sample;
        buf->sample_sum += sample;
    } else {
        // If buffer full, overwrite oldest sample
        buf->sample_sum -= buf->samples[buf->head_index];
        buf->samples[buf->head_index] = sample;
        buf->sample_sum += sample;
        buf->head_index = (buf->head_index + 1) % buf->buffer_size;
    }

    return RM_CPU_SUCCESS;
}

/**
 *========================================================================================================
 * @brief      cpu_usage_get_average
 * @details    Calculates the average CPU usage from the circular buffer for the specified core.
 *
 * @param[in]  core_index  Index of the CPU core.
 *
 * @return     double      Average CPU usage, or 0.0 if no samples are available.
 *========================================================================================================
 */
uint32_t cpu_usage_get_average(uint32_t core_index) {
    // Validate core index and buffer existence
    if((core_index >= max_cpu) || !cpu_usage_buffers[core_index]) {
        return 0.0;
    }

    cpu_usage_buffer_t* buf = cpu_usage_buffers[core_index];

    // Return 0 if samples collected is less than NumSamples
    if(buf->sample_count < buf->buffer_size) {
        return 0;
    }

    // Return average
    return (uint32_t) round(buf->sample_sum / buf->sample_count);
}

/**
 *========================================================================================================
 * @brief      resmon_cpu_shutdown
 * @details    Frees all allocated memory for CPU usage monitoring and resets internal state.
 *             Should be called during shutdown or cleanup phase.
 *========================================================================================================
 */
void resmon_cpu_shutdown(void) {
    SAH_TRACEZ_INFO(ME, "Shutting down CPU monitor");

    // Free timer contexts
    if(cpu_timer_contexts != NULL) {
        for(uint32_t i = 0; i < max_cpu; i++) {
            if(cpu_timer_contexts[i] != NULL) {
                free(cpu_timer_contexts[i]);
                cpu_timer_contexts[i] = NULL;
            }
        }
        free(cpu_timer_contexts);
        cpu_timer_contexts = NULL;
    }

    // Free previous CPU usage tracking arrays
    if(prev_total != NULL) {
        free(prev_total);
        prev_total = NULL;
    }

    if(prev_idle != NULL) {
        free(prev_idle);
        prev_idle = NULL;
    }

    if(prev_agg_total != NULL) {
        free(prev_agg_total);
        prev_agg_total = NULL;
    }

    if(prev_agg_idle != NULL) {
        free(prev_agg_idle);
        prev_agg_idle = NULL;
    }

    if(prev_agg_user != NULL) {
        free(prev_agg_user);
        prev_agg_user = NULL;
    }

    if(prev_agg_system != NULL) {
        free(prev_agg_system);
        prev_agg_system = NULL;
    }

    // Free CPU monitor structures
    if(cmon != NULL) {
        free(cmon);
        cmon = NULL;
    }

    // Free usage buffers
    cpu_usage_buffers_free();

    // Reset global state
    max_cpu = 0;

    SAH_TRACEZ_INFO(ME, "CPU monitor shutdown complete");
}

/**
 *========================================================================================================
 * @brief      cpu_usage_buffers_free
 * @details    Frees all allocated memory for CPU usage monitoring and resets internal state.
 *             Should be called during shutdown or cleanup phase.
 *========================================================================================================
 */
void cpu_usage_buffers_free(void) {
    // Return early if buffer array is already NULL
    if(!cpu_usage_buffers) {
        return;
    }

    // Free each buffer and its sample array
    for(uint32_t i = 0; i < max_cpu; i++) {
        if(cpu_usage_buffers[i]) {
            free(cpu_usage_buffers[i]->samples);
            free(cpu_usage_buffers[i]);
            cpu_usage_buffers[i] = NULL;
        }
    }

    // Free the top-level buffer array and reset state
    free(cpu_usage_buffers);
    cpu_usage_buffers = NULL;
    max_cpu = 0;

    SAH_TRACEZ_INFO(ME, "Freed all CPU usage buffers and reset max_cpu");
}

/**
 *========================================================================================================
 * @brief      resmon_cpu_clear
 * @details    Clears CPU monitoring state including usage, timestamps, and resets the state to NORMAL.
 *
 * @param[in]  index  Index of the CPU monitor instance to clear.
 *
 * @return     int32_t  Return value indicating success (RM_CPU_SUCCESS) or failure (RM_CPU_FAILURE).
 *========================================================================================================
 */
int32_t resmon_cpu_clear(uint32_t index) {
    int32_t ret = RM_CPU_FAILURE;
    amxd_status_t status = amxd_status_unknown_error;

    // Validate instance index
    when_true_trace(index >= max_cpu, exit, ERROR, "Invalid index: %u", index);

    // Reset CPU monitoring state
    cmon[index].cpu_state = RM_CPU_STATE_NORMAL;
    cmon[index].user_mode_usage = 0;
    cmon[index].system_mode_usage = 0;
    cmon[index].idle_mode_usage = 0;
    cmon[index].up_time = 0;
    cmon[index].total_cpu_usage = 0;

    //clear the CPU usage buffer
    cpu_usage_buffer_clear(index);

    // Reset timestamps to default
    set_cpu_default_timestamp(cmon[index].fall_timestamp, sizeof(cmon[index].fall_timestamp));
    set_cpu_default_timestamp(cmon[index].rise_timestamp, sizeof(cmon[index].rise_timestamp));

    SAH_TRACEZ_INFO(ME, "Clearing CPU monitor state for instance %u", index);

    // Update data model with cleared values
    status = set_cpu_param_instance(RM_CPU_CPU_UTILIZATION, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_CPU_UTILIZATION for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_USER_MODE_UTILIZATION, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_USER_MODE_UTILIZATION for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_SYSTEM_MODE_UTILIZATION, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_SYSTEM_MODE_UTILIZATION for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_IDLE_MODE_UTILIZATION, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_IDLE_MODE_UTILIZATION for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_UP_TIME, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_UP_TIME for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_CRITICAL_FALL_TIMESTAMP, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_CRITICAL_FALL_TIMESTAMP for index %u, status = %d", index, status);

    status = set_cpu_param_instance(RM_CPU_CRITICAL_RISE_TIMESTAMP, index);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_CRITICAL_RISE_TIMESTAMP for index %u, status = %d", index, status);

exit:
    if(status == amxd_status_ok) {
        ret = RM_CPU_SUCCESS;
    }

    SAH_TRACEZ_INFO(ME, "resmon_cpu_clear completed for instance %u with return code %d", index, ret);
    return ret;
}

/**
 *========================================================================================================
 * @brief      _rm_cpu_enable_change
 * @details    Callback triggered when the CPU monitoring enable parameter changes.
 *             Starts or stops the CPU monitor based on the new enable status.
 *
 * @param[in]  sig_name  Signal name (unused).
 * @param[in]  data      Signal data containing the updated parameter path.
 * @param[in]  priv      Private data (unused).
 *========================================================================================================
 */
void _rm_cpu_enable_change(UNUSED const char* const sig_name,
                           const amxc_var_t* const data,
                           UNUSED void* const priv) {
    uint32_t index = 0;
    int32_t ret = RM_CPU_FAILURE;
    bool current_status = false;
    char* event_path = NULL;

    SAH_TRACEZ_INFO(ME, "_rm_cpu_enable_change triggered");

    // Extract the parameter path from the signal data
    const amxc_var_t* path_var = amxc_var_get_path(data, "path", AMXC_VAR_FLAG_DEFAULT);
    if(path_var != NULL) {
        event_path = amxc_var_dyncast(cstring_t, path_var);
        SAH_TRACEZ_INFO(ME, "Received event path: %s", event_path);
        sscanf(event_path, "DeviceInfo.ProcessStatus.CPU.%u.", &index);
    }

    if(NULL != event_path) {
        free(event_path);
    }

    // Validate instance index
    if(index > max_cpu) {
        SAH_TRACEZ_ERROR(ME, "CPU index %u out of range", index);
        return;
    }

    index = index - 1;
    SAH_TRACEZ_INFO(ME, "Processing enable change for CPU instance %u", index);

    // Store current enable status
    current_status = cmon[index].cpu_enabled;

    // Read updated enable status from the data model
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", index + 1);
    if(cpu_obj != NULL) {
        cmon[index].cpu_enabled = amxd_object_get_value(bool, cpu_obj, RM_CPU_ENABLE, NULL);
    }

    // Handle enable/disable transitions
    if(!current_status && cmon[index].cpu_enabled) {
        SAH_TRACEZ_INFO(ME, "CPU instance %u: Enable changed from false to true", index);
        ret = resmon_cpu_clear(index);
        when_true_trace(ret != RM_CPU_SUCCESS, exit, ERROR,
                        "Failed to clear CPU utilization. Cannot start monitoring for instance %u", index);
        resmon_start_cpu_monitor(index);
    } else if(current_status && !cmon[index].cpu_enabled) {
        SAH_TRACEZ_INFO(ME, "CPU instance %u: Enable changed from true to false", index);
        resmon_stop_cpu_monitor(index);
        ret = resmon_cpu_clear(index);
        when_true_trace(ret != RM_CPU_SUCCESS, exit, ERROR,
                        "Failed to clear CPU utilization for instance %u", index);
    } else {
        SAH_TRACEZ_INFO(ME, "CPU instance %u: Enable status unchanged", index);
    }

exit:
    SAH_TRACEZ_INFO(ME, "Exiting _rm_cpu_enable_change for instance %u", index);
    return;
}

/**
 *========================================================================================================
 * @brief      resmon_start_cpu_monitor
 * @details    Starts the CPU monitoring timer if monitoring is enabled for the given instance.
 *
 * @param[in]  instance  Index of the CPU monitor instance to start.
 *========================================================================================================
 */
void resmon_start_cpu_monitor(uint32_t instance) {
    // Validate instance range
    if(instance >= max_cpu) {
        SAH_TRACEZ_ERROR(ME, "Could not start CPU Monitoring: Invalid CPU instance: %u", instance);
        return;
    }

    // Check if monitoring is enabled for this instance
    if(!cmon[instance].cpu_enabled) {
        SAH_TRACEZ_ERROR(ME, "Could not start CPU Monitoring: Monitoring not enabled for instance %u", instance);
        return;
    }

    // Initialize CPU usage buffer
    int32_t ret = cpu_usage_buffer_create(instance, cmon[instance].num_samples);
    when_true_trace((ret != RM_CPU_SUCCESS), exit, ERROR,
                    "Could not start CPU Monitoring: Failed to initialize CPU usage buffer");

    // Create and start timer if not already running
    if(cpu_timer_contexts[instance] == NULL) {
        cpu_timer_ctx_t* ctx = malloc(sizeof(cpu_timer_ctx_t));
        if(ctx == NULL) {
            SAH_TRACEZ_ERROR(ME, "Could not start CPU Monitoring: Failed to allocate context for instance %u", instance);
            return;
        }

        ctx->instance = instance;
        ctx->timer = NULL;

        /* As per TR-181 specification, if the polling interval is set to 0,
           the device selects its own polling interval. In this implementation,
           we use a default polling interval of 5 seconds when the value is 0. */

        if(cmon[instance].polling_interval == 0) {
            cmon[instance].polling_interval = RM_CPU_POLLING_INTERVAL_DEFAULT;
        }

        if(amxp_timer_new(&ctx->timer, cpu_usage_handler, ctx) == 0) {
            amxp_timer_set_interval(ctx->timer, (cmon[instance].polling_interval * 1000));
            SAH_TRACEZ_INFO(ME, "Starting CPU Monitoring Timer for instance %u", instance);
            amxp_timer_start(ctx->timer, (cmon[instance].polling_interval * 1000));
            cpu_timer_contexts[instance] = ctx;
        } else {
            SAH_TRACEZ_ERROR(ME, "Failed to create timer for CPU instance %u", instance);
            free(ctx);
        }
    } else {
        SAH_TRACEZ_INFO(ME, "Timer already running for CPU instance %u", instance);
    }

exit:
    return;
}

/**
 *========================================================================================================
 * @brief      resmon_stop_cpu_monitor
 * @details    Stops and deletes the CPU monitoring timer and cleans up associated resources.
 *
 * @param[in]  instance  Index of the CPU monitor instance to stop.
 *========================================================================================================
 */
void resmon_stop_cpu_monitor(uint32_t instance) {
    // Validate instance range
    if(instance > max_cpu) {
        SAH_TRACEZ_ERROR(ME, "Could not stop CPU Monitoring: Invalid CPU instance: %u", instance);
        return;
    }

    // Delete usage buffer for the instance
    cpu_usage_buffer_delete(instance);

    // Retrieve timer context
    cpu_timer_ctx_t* ctx = cpu_timer_contexts[instance];
    if(ctx != NULL) {
        // Stop and delete the timer if it exists
        if(ctx->timer != NULL) {
            amxp_timer_stop(ctx->timer);
            amxp_timer_delete(&ctx->timer);
            ctx->timer = NULL;
        }

        // Free the context memory and clear the reference
        free(ctx);
        cpu_timer_contexts[instance] = NULL;

        SAH_TRACEZ_INFO(ME, "Stopped and cleaned up CPU Monitoring Timer for instance %u", instance);
    } else {
        SAH_TRACEZ_INFO(ME, "No active timer context to stop for CPU instance %u", instance);
    }
}

/**
 *========================================================================================================
 * @brief      cpu_usage_handler
 * @details    Timer handler that reads current CPU usage and updates the data model.
 *             Also triggers state transitions if thresholds are crossed.
 *
 * @param[in]  timer  Pointer to the timer object (unused).
 * @param[in]  priv   Private data containing CPU instance context.
 *========================================================================================================
 */
void cpu_usage_handler(UNUSED amxp_timer_t* timer, void* priv) {
    cpu_timer_ctx_t* ctx = (cpu_timer_ctx_t*) priv;
    uint32_t instance = ctx->instance;
    amxd_status_t status;
    char* vendorlog_ref_path = NULL;

    SAH_TRACEZ_INFO(ME, "CPU Monitor Timer Handler triggered for instance %u", instance);

    // Validate instance range
    if(instance >= max_cpu) {
        SAH_TRACEZ_ERROR(ME, "Invalid CPU instance index: %u", instance);
        return;
    }

    // Retrieve VendorLogFileRef from CPU monitor object
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", instance + 1);
    vendorlog_ref_path = (cpu_obj != NULL) ? amxd_object_get_value(cstring_t, cpu_obj, RM_CPU_VENDOR_LOG_FILE_REF, NULL) : NULL;

    // VendorLogFileRef can't be set during CPU Monitor init as DeviceInfo isn't ready.
    // Update it here once  CPU Monitor is enabled
    if(STR_EMPTY(vendorlog_ref_path)) {
        if(vendorlog_ref_path != NULL) {
            SAH_TRACEZ_ERROR(ME, "VendorLogFileRef is not set. Initiating update via cmon_update_vendorlogfileref_syslog");
            cmon_update_vendorlogfileref_syslog(instance);
        }
    }

    // Update uptime and CPU usage metrics
    cmon[instance].up_time = get_current_up_time();
    cpu_usage_update_and_get_average(instance);
    get_current_agg_mode_usage(instance);

    SAH_TRACEZ_INFO(ME, "Updated CPU usage metrics for instance %u", instance);

    // Update data model with latest values
    status = set_cpu_param_instance(RM_CPU_CPU_UTILIZATION, instance);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_CPU_UTILIZATION for instance %u, status = %d", instance, status);

    status = set_cpu_param_instance(RM_CPU_SYSTEM_MODE_UTILIZATION, instance);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_SYSTEM_MODE_UTILIZATION for instance %u, status = %d", instance, status);

    status = set_cpu_param_instance(RM_CPU_USER_MODE_UTILIZATION, instance);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_USER_MODE_UTILIZATION for instance %u, status = %d", instance, status);

    status = set_cpu_param_instance(RM_CPU_IDLE_MODE_UTILIZATION, instance);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_IDLE_MODE_UTILIZATION for instance %u, status = %d", instance, status);

    status = set_cpu_param_instance(RM_CPU_UP_TIME, instance);
    when_true_trace(status != amxd_status_ok, exit, ERROR,
                    "Failed to set RM_CPU_UP_TIME for instance %u, status = %d", instance, status);

    // Evaluate and handle state transitions
    handle_cpu_monitor_state(instance);

exit:
    free(vendorlog_ref_path);
    return;
}

/**
 *========================================================================================================
 * @brief      get_current_up_time
 * @details    Retrieves the system uptime in seconds using the sysinfo system call.
 *
 * @return     uint64_t  System uptime in seconds. Returns 0 on failure.
 *========================================================================================================
 */
uint64_t get_current_up_time(void) {
    struct sysinfo sis_info;

    // Retrieve system uptime
    if(sysinfo(&sis_info) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to retrieve system uptime: errno = %d", errno);
        return (uint64_t) 0;
    }

    // Convert uptime to uint64_t and return
    uint64_t uptime = (uint64_t) sis_info.uptime;
    SAH_TRACEZ_INFO(ME, "System uptime: %llu seconds", uptime);

    return uptime;
}

/**
 *========================================================================================================
 * @brief      cpu_usage_update_and_get_average
 * @details    Fetches the current CPU usage for the given core index, adds it to the circular buffer,
 *             and updates the moving average in the CPU monitor structure.
 *
 * @param[in]  index  Index of the CPU core.
 *
 * @return     void
 *========================================================================================================
 */
void cpu_usage_update_and_get_average(uint32_t index) {

    // Validate CPU index
    if(index >= max_cpu) {
        SAH_TRACEZ_ERROR(ME, "CPU index %u out of range (max = %u)", index, max_cpu);
        return;
    }

    // Fetch current CPU usage for the core
    double usage = get_current_cpu_usage(index);

    // Add the usage sample to the circular buffer
    if(cpu_usage_add_sample(index, usage) != RM_CPU_SUCCESS) {
        cmon[index].total_cpu_usage = 0;
    }

    // Update the moving average in the monitor structure
    cmon[index].total_cpu_usage = cpu_usage_get_average(index);
    return;
}

/**
 *========================================================================================================
 * @brief      get_current_cpu_usage
 * @details    Reads CPU statistics for a specific core from /proc/stat and calculates the CPU usage
 *             percentage based on the difference from the previous reading. This function helps monitor
 *             per-core CPU utilization.
 *
 * @param[in]  index  Index of the CPU core to monitor.
 *
 * @return     double  CPU usage percentage (0–100) for the specified core.
 *========================================================================================================
 */
double get_current_cpu_usage(uint32_t index) {
    FILE* fp = NULL;
    char line[RM_LINE_OUTPUT_BUFFER_SIZE];
    char cpu_label[RM_CPU_LABEL];
    uint64_t user, nice, system, idle, iowait, irq, softirq, steal;
    uint64_t total, diff_total, diff_idle;
    double usage = 0;

    // Construct CPU label (e.g., "cpu0", "cpu1", ...)
    snprintf(cpu_label, sizeof(cpu_label), "cpu%d", index);
    SAH_TRACEZ_INFO(ME, "Computed CPU label: %s", cpu_label);

    // Open /proc/stat to read CPU statistics
    fp = fopen(RM_CPU_PROC_STAT_PATH, "r");
    if(fp == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to open %s, error: %s", RM_CPU_PROC_STAT_PATH, strerror(errno));
        goto exit;
    }

    // Read lines until the matching CPU label is found
    while(fgets(line, sizeof(line), fp)) {
        if(strncmp(line, cpu_label, strlen(cpu_label)) == 0) {
            uint32_t read_count = sscanf(line + strlen(cpu_label),
                                         "%" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64,
                                         &user, &nice, &system, &idle,
                                         &iowait, &irq, &softirq, &steal);
            if(read_count != RM_CPU_PROC_STAT_COUNT) {
                SAH_TRACEZ_ERROR(ME, "Error parsing CPU stats for %s", cpu_label);
                goto exit;
            }

            // Calculate total and idle deltas
            total = user + nice + system + idle + iowait + irq + softirq + steal;
            diff_total = total - prev_total[index];
            diff_idle = idle - prev_idle[index];

            // Update previous values
            prev_total[index] = total;
            prev_idle[index] = idle;

            // Avoid division by zero
            if(diff_total == 0) {
                SAH_TRACEZ_INFO(ME, "cpu%d: diff_total is 0, setting usage to 0", index);
                goto exit;
            }

            // Calculate CPU usage percentage
            usage = ((double) (diff_total - diff_idle) / diff_total) * RM_CPU_PERCENT_VALUE;

            SAH_TRACEZ_INFO(ME, "cpu%d: usage = %.2f%%", index, usage);
            goto exit;
        }
    }

    // CPU label not found
    SAH_TRACEZ_ERROR(ME, "CPU label %s not found in /proc/stat", cpu_label);

exit:
    if(fp != NULL) {
        fclose(fp);
    }
    return usage;
}

/**
 *========================================================================================================
 * @brief      get_current_agg_mode_usage
 * @details    Reads CPU statistics from /proc/stat and calculates the aggregate CPU usage in user,
 *             system, and idle modes. Updates the global CPU monitor structure with the calculated values.
 *
 * @param[in]  index  Index of the CPU monitor structure to update.
 *
 * @return     void
 *========================================================================================================
 */
void get_current_agg_mode_usage(uint32_t index) {
    FILE* fp = NULL;
    char line[RM_LINE_OUTPUT_BUFFER_SIZE];
    uint64_t user, nice, system, idle, iowait, irq, softirq, steal;
    uint64_t total, diff_total, diff_idle, diff_user, diff_system;

    // Validate CPU index
    if(index >= max_cpu) {
        SAH_TRACEZ_ERROR(ME, "CPU index %u out of range (max = %u)", index, max_cpu);
        return;
    }

    // Open /proc/stat to read CPU statistics
    fp = fopen(RM_CPU_PROC_STAT_PATH, "r");
    if(fp == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to open %s, error: %s", RM_CPU_PROC_STAT_PATH, strerror(errno));
        return;
    }

    // Read lines until the aggregate CPU line is found
    while(fgets(line, sizeof(line), fp)) {
        if(strncmp(line, "cpu ", 4) == 0) {
            uint32_t read_count = sscanf(line + 4,
                                         "%" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64,
                                         &user, &nice, &system, &idle,
                                         &iowait, &irq, &softirq, &steal);
            if(read_count != RM_CPU_PROC_STAT_COUNT) {
                SAH_TRACEZ_ERROR(ME, "Error parsing aggregate CPU stats");
                break;
            }

            // Calculate total and deltas
            total = user + nice + system + idle + iowait + irq + softirq + steal;
            diff_total = total - prev_agg_total[index];
            diff_idle = (idle + iowait) - prev_agg_idle[index];
            diff_user = (user + nice) - prev_agg_user[index];
            diff_system = (system + irq + softirq) - prev_agg_system[index];

            // Update previous values
            prev_agg_total[index] = total;
            prev_agg_idle[index] = idle + iowait;
            prev_agg_user[index] = user + nice;
            prev_agg_system[index] = system + irq + softirq;

            // Calculate and update usage percentages
            if(diff_total != 0) {
                cmon[index].user_mode_usage = (uint32_t) round((((double) diff_user / diff_total) * RM_CPU_PERCENT_VALUE));
                cmon[index].system_mode_usage = (uint32_t) round((((double) diff_system / diff_total) * RM_CPU_PERCENT_VALUE));
                cmon[index].idle_mode_usage = (uint32_t) round((((double) diff_idle / diff_total) * RM_CPU_PERCENT_VALUE));
            } else {
                cmon[index].user_mode_usage = 0;
                cmon[index].system_mode_usage = 0;
                cmon[index].idle_mode_usage = 0;
            }

            break; // Only process the first "cpu " line
        }
    }

    fclose(fp);
}

/**
 *========================================================================================================
 * @brief      handle_cpu_monitor_state
 * @details    Evaluates the current CPU usage and triggers state transitions between NORMAL and CRITICAL
 *             based on configured thresholds.
 *
 * @param[in]  instance  Index of the CPU monitor instance.
 *========================================================================================================
 */
void handle_cpu_monitor_state(uint32_t instance) {
    uint32_t usage = cmon[instance].total_cpu_usage;

    SAH_TRACEZ_INFO(ME, "Evaluating CPU state for instance %u: current state = %d, usage = %u%%",
                    instance, cmon[instance].cpu_state, usage);

    // Handle state transitions based on current state
    if(cmon[instance].cpu_state == RM_CPU_STATE_NORMAL) {
        cpu_normal_state_handler(instance, usage);
    } else if(cmon[instance].cpu_state == RM_CPU_STATE_CRITICAL) {
        cpu_critical_state_handler(instance, usage);
    }
}

/**
 *========================================================================================================
 * @brief      set_timestamp
 * @details    Generates a UTC timestamp in ISO 8601 format and stores it in the provided buffer.
 *
 * @param[out] target  Pointer to the buffer where the timestamp will be stored.
 *========================================================================================================
 */
static void set_timestamp(char* target) {
    time_t current_time;
    struct tm* time_info;

    // Get current UTC time
    time(&current_time);
    time_info = gmtime(&current_time);
    when_null(time_info, exit);

    // Format timestamp as ISO 8601 (e.g., 2025-07-24T12:34:56Z)
    strftime(target, 25, "%Y-%m-%dT%H:%M:%SZ", time_info);

    SAH_TRACEZ_INFO(ME, "Timestamp set to: %s", target);

exit:
    return;
}

/**
 *========================================================================================================
 * @brief      raise_cpu_critical_event
 * @details    Emits a CPU critical state event and triggers associated actions such as logging.
 *
 * @param[in]  instance  Index of the CPU monitor instance that triggered the event.
 *========================================================================================================
 */
static void raise_cpu_critical_event(uint32_t instance) {
    amxc_var_t values;
    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    char* name = NULL;

    // Check if object is valid before emitting signal
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", instance + 1);
    when_null_trace(cpu_obj, exit, ERROR, "CPU object for instance %u not found", instance);
    SAH_TRACEZ_INFO(ME, "Emitting CPU critical state signal for instance %u", instance);
    name = amxd_object_get_value(cstring_t, cpu_obj, RM_CPU_NAME, NULL);
    when_null_trace(name, exit, ERROR, "Failed to read CPU Name");
    amxc_var_add_key(cstring_t, &values, RM_CPU_NAME, name);
    amxc_var_add_key(uint32_t, &values, RM_CPU_CPU_UTILIZATION, cmon[instance].total_cpu_usage);

    // Emit signal and perform critical state actions
    amxd_object_emit_signal(cpu_obj, RM_CPU_CRITICAL_STATE_EVENT, &values);
    cpucriticalstate_actions(instance);

exit:
    if(name != NULL) {
        free(name);
    }
    amxc_var_clean(&values);
    return;
}

/**
 *========================================================================================================
 * @brief      cpu_critical_state_handler
 * @details    Handles transition from CRITICAL to NORMAL state if CPU usage falls below the configured
 *             fall threshold. Updates the state and sets the fall timestamp.
 *
 * @param[in]  instance  Index of the CPU monitor instance.
 * @param[in]  usage     Current CPU usage percentage.
 *========================================================================================================
 */
void cpu_critical_state_handler(uint32_t instance, uint32_t usage) {

    bool enable_critical_log = false;

    SAH_TRACEZ_INFO(ME, "Checking CPU usage: %u against fall threshold: %u for instance %u",
                    usage, cmon[instance].fall_threshold, instance);

    // If usage drops below fall threshold, transition to NORMAL state
    if(usage < cmon[instance].fall_threshold) {
        cmon[instance].cpu_state = RM_CPU_STATE_NORMAL;

        SAH_TRACEZ_INFO(ME, "CPU state changed to NORMAL for instance %u", instance);

        // Get EnableCriticalLog flag from data model
        amxd_dm_t* dm = deviceinfo_get_dm();
        amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", instance + 1);
        enable_critical_log = (cpu_obj != NULL) ? amxd_object_get_value(bool, cpu_obj, RM_CPU_ENABLE_CRITICAL_LOG, false) : false;

        if(enable_critical_log) {
            char log_tag[32];
            snprintf(log_tag, sizeof(log_tag), "%s%u", RM_CMON, instance);  // Constructs "cpu0", "cpu1", etc.

            // write to Vendor log file
            SAH_TRACEZ_ERROR(log_tag, "CPU critical state cleared for instance %u. Utilization: %u%%", instance, cmon[instance].total_cpu_usage);
        }

        // Update fall timestamp and push to data model
        set_timestamp(cmon[instance].fall_timestamp);
        set_cpu_param_instance(RM_CPU_CRITICAL_FALL_TIMESTAMP, instance);
    }
}

/**
 *========================================================================================================
 * @brief      cpu_normal_state_handler
 * @details    Handles transition from NORMAL to CRITICAL state if CPU usage exceeds the configured
 *             rise threshold. Updates the state, sets the rise timestamp, and raises a critical event.
 *
 * @param[in]  instance  Index of the CPU monitor instance.
 * @param[in]  usage     Current CPU usage percentage.
 *========================================================================================================
 */
void cpu_normal_state_handler(uint32_t instance, uint32_t usage) {
    SAH_TRACEZ_INFO(ME, "Checking CPU usage: %u against rise threshold: %u for instance %u",
                    usage, cmon[instance].rise_threshold, instance);

    // If usage exceeds rise threshold, transition to CRITICAL state
    if(usage >= cmon[instance].rise_threshold) {
        cmon[instance].cpu_state = RM_CPU_STATE_CRITICAL;

        SAH_TRACEZ_INFO(ME, "CPU state changed to CRITICAL for instance %u", instance);

        // Update rise timestamp and push to data model
        set_timestamp(cmon[instance].rise_timestamp);
        set_cpu_param_instance(RM_CPU_CRITICAL_RISE_TIMESTAMP, instance);

        // Raise critical event
        raise_cpu_critical_event(instance);
    }
}

/**
 *========================================================================================================
 * @brief      cpucriticalstate_actions
 * @details    Handles the CPU critical state event. Logs the event to system and optionally to a vendor-specific
 *             log file if enabled in the data model.
 *
 * @param[in]  instance  Index of the CPU monitor instance that triggered the critical state.
 *
 * @return     int32_t   Return value indicating success (RM_CPU_SUCCESS) or failure (RM_CPU_FAILURE).
 *========================================================================================================
 */
int32_t cpucriticalstate_actions(uint32_t instance) {
    int retval = RM_CPU_FAILURE;
    bool enable_critical_log = false;

    // Log to system log
    SAH_TRACEZ_ERROR(ME, "CPU critical state reached for CORE %u with utilization: %u%%",
                     instance, cmon[instance].total_cpu_usage);

    // Get EnableCriticalLog flag from data model
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", instance + 1);
    enable_critical_log = (cpu_obj != NULL) ? amxd_object_get_value(bool, cpu_obj, RM_CPU_ENABLE_CRITICAL_LOG, false) : false;
    SAH_TRACEZ_INFO(ME, "EnableCriticalLog = %d", enable_critical_log);

    if(enable_critical_log) {
        char log_tag[32];
        snprintf(log_tag, sizeof(log_tag), "%s%u", RM_CMON, instance);  // Constructs "cpu0", "cpu1", etc.

        // write to Vendor log file
        SAH_TRACEZ_ERROR(log_tag, "CPU critical state reached for instance %u. Utilization: %u%%", instance, cmon[instance].total_cpu_usage);
    }

    retval = RM_CPU_SUCCESS;

    return retval;
}

/**
 *========================================================================================================
 * @brief      set_cpu_param_instance
 * @details    Sets a specific CPU monitoring parameter in the data model using a transaction.
 *
 * @param[in]  param_name  Name of the parameter to be updated.
 * @param[in]  index       Index of the CPU monitor instance.
 *
 * @return     amxd_status_t  Status of the operation.
 *========================================================================================================
 */
amxd_status_t set_cpu_param_instance(const char* param_name, uint32_t index) {
    amxd_status_t status = amxd_status_unknown_error;
    amxd_trans_t transaction;

    // Validate index
    when_true_trace((index >= max_cpu), exit, ERROR, "Invalid index: %u", index);

    // Initialize transaction
    amxd_trans_init(&transaction);

    // Ensure the CPU monitor object exists - fetch it dynamically
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", index + 1);
    when_null(cpu_obj, exit);

    SAH_TRACEZ_INFO(ME, "Setting parameter '%s' for CPU index %u", param_name, index);

    // Set transaction attributes and select the object
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, cpu_obj);

    // Match and set the appropriate parameter
    if(strcmp(param_name, RM_CPU_CPU_UTILIZATION) == 0) {
        amxd_trans_set_value(uint32_t, &transaction, RM_CPU_CPU_UTILIZATION, cmon[index].total_cpu_usage);
    } else if(strcmp(param_name, RM_CPU_CRITICAL_FALL_TIMESTAMP) == 0) {
        amxd_trans_set_value(cstring_t, &transaction, RM_CPU_CRITICAL_FALL_TIMESTAMP, cmon[index].fall_timestamp);
    } else if(strcmp(param_name, RM_CPU_CRITICAL_RISE_TIMESTAMP) == 0) {
        amxd_trans_set_value(cstring_t, &transaction, RM_CPU_CRITICAL_RISE_TIMESTAMP, cmon[index].rise_timestamp);
    } else if(strcmp(param_name, RM_CPU_USER_MODE_UTILIZATION) == 0) {
        amxd_trans_set_value(uint32_t, &transaction, RM_CPU_USER_MODE_UTILIZATION, cmon[index].user_mode_usage);
    } else if(strcmp(param_name, RM_CPU_SYSTEM_MODE_UTILIZATION) == 0) {
        amxd_trans_set_value(uint32_t, &transaction, RM_CPU_SYSTEM_MODE_UTILIZATION, cmon[index].system_mode_usage);
    } else if(strcmp(param_name, RM_CPU_IDLE_MODE_UTILIZATION) == 0) {
        amxd_trans_set_value(uint32_t, &transaction, RM_CPU_IDLE_MODE_UTILIZATION, cmon[index].idle_mode_usage);
    } else if(strcmp(param_name, RM_CPU_UP_TIME) == 0) {
        amxd_trans_set_value(uint64_t, &transaction, RM_CPU_UP_TIME, cmon[index].up_time);
    } else {
        SAH_TRACEZ_INFO(ME, "Unknown parameter: %s", param_name);
        goto exit;
    }

    // Apply the transaction
    status = amxd_trans_apply(&transaction, deviceinfo_get_dm());
    when_true_trace(status != AMXB_STATUS_OK, exit, ERROR, "Failed to apply parameter: %s", param_name);

exit:
    amxd_trans_clean(&transaction);
    return status;
}

/**
 *========================================================================================================
 * @brief      _rm_cpu_polling_threshold_samples_change
 * @details    Callback triggered when polling interval, threshold, or sample parameters change.
 *             Updates the CPU monitor configuration and restarts the monitoring timer for the
 *             corresponding CPU instance.
 *
 * @param[in]  sig_name  Name of the signal received (unused).
 * @param[in]  data      Signal data containing updated parameter values.
 * @param[in]  priv      Private data (unused).
 *========================================================================================================
 */
void _rm_cpu_polling_threshold_samples_change(UNUSED const char* const sig_name,
                                              const amxc_var_t* const data,
                                              UNUSED void* const priv) {
    uint32_t index = 0;
    int32_t ret = RM_CPU_FAILURE;
    char* event_path = NULL;

    SAH_TRACEZ_INFO(ME, "_rm_cpu_polling_threshold_samples_change triggered");

    // Extract the path from the signal data
    const amxc_var_t* path_var = amxc_var_get_path(data, "path", AMXC_VAR_FLAG_DEFAULT);
    if(path_var != NULL) {
        event_path = amxc_var_dyncast(cstring_t, path_var);
        SAH_TRACEZ_INFO(ME, "Received event path: %s", event_path);
        sscanf(event_path, "DeviceInfo.ProcessStatus.CPU.%u.", &index);
    }

    //free the dyncast variable
    if(NULL != event_path) {
        free(event_path);
    }

    // Validate index range
    if(index > max_cpu) {
        SAH_TRACEZ_ERROR(ME, "CPU index %u out of range (max = %u)", index, max_cpu);
        return;
    }

    SAH_TRACEZ_INFO(ME, "Processing CPU monitor update for index: %u", index);

    index = index - 1;

    // Ensure the CPU monitor object exists - fetch it dynamically
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", index + 1);
    when_null(cpu_obj, exit);

    // Read updated parameters from the object
    cmon[index].polling_interval = amxd_object_get_value(uint32_t, cpu_obj, RM_CPU_POLLING_INTERVAL, NULL);
    cmon[index].rise_threshold = amxd_object_get_value(uint32_t, cpu_obj, RM_CPU_CRITICAL_RISE_THRESHOLD, NULL);
    cmon[index].fall_threshold = amxd_object_get_value(uint32_t, cpu_obj, RM_CPU_CRITICAL_FALL_THRESHOLD, NULL);
    cmon[index].num_samples = amxd_object_get_value(uint32_t, cpu_obj, RM_CPU_NUM_SAMPLES, NULL);

    SAH_TRACEZ_INFO(ME, "Updated thresholds for instance %u: polling=%u, rise=%u, fall=%u, num_samples=%u",
                    index, cmon[index].polling_interval, cmon[index].rise_threshold,
                    cmon[index].fall_threshold, cmon[index].num_samples);

    // Restart monitoring with updated configuration
    resmon_stop_cpu_monitor(index);

    ret = resmon_cpu_clear(index);
    when_true_trace(ret != RM_CPU_SUCCESS, exit, ERROR, "Failed to clear CPU utilization for instance %u", index);

    resmon_start_cpu_monitor(index);

exit:
    return;
}

/**
 *========================================================================================================
 * @brief      _validate_cpumonitor
 * @details    Validates CPU threshold parameters to ensure logical consistency between rise and fall values.
 *             This function is used during parameter validation in the CPU monitoring configuration.
 *
 * @param[in]  object   Pointer to the CPU monitoring object.
 * @param[in]  param    Pointer to the parameter being validated.
 * @param[in]  reason   Reason for validation (unused).
 * @param[in]  args     Input value to validate.
 * @param[in]  retval   Return value container (unused).
 * @param[in]  priv     Private data (unused).
 *
 * @return     amxd_status_t  Status of the validation.
 *========================================================================================================
 */

amxd_status_t _validate_cpumonitor(amxd_object_t* object, amxd_param_t* param,
                                   UNUSED amxd_action_t reason, const amxc_var_t* const args,
                                   UNUSED amxc_var_t* const retval, UNUSED void* priv) {
    amxd_status_t status;
    char input_param_name[RM_LINE_OUTPUT_BUFFER_SIZE] = {0};
    int32_t current_value = 0;
    int32_t input_value = 0;
    int32_t reference_value = 0;

    // Log entry into validation function
    SAH_TRACEZ_INFO(ME, "Entered _validate_cpumonitor for CPU threshold validation");

    // Validate input pointers
    status = amxd_status_object_not_found;
    when_null_trace(object, exit, ERROR, "Validation failed: Object is NULL");

    status = amxd_status_parameter_not_found;
    when_null_trace(param, exit, ERROR, "Validation failed: Parameter is NULL");

    status = amxd_status_invalid_function_argument;
    when_null(args, exit);

    status = amxd_status_ok;

    // Copy parameter name safely
    strncpy(input_param_name, amxd_param_get_name(param), sizeof(input_param_name) - 1);
    input_param_name[sizeof(input_param_name) - 1] = '\0';

    // Extract current and input values
    current_value = amxc_var_dyncast(uint32_t, &param->value);
    input_value = amxc_var_dyncast(uint32_t, args);

    SAH_TRACEZ_INFO(ME, "Validating param: %s, instance: %u, current: %d, input: %d",
                    input_param_name, object->index, current_value, input_value);

    // Reject zero input value
    if(input_value == 0) {
        SAH_TRACEZ_ERROR(ME, "Input value for %s cannot be zero", input_param_name);
        return amxd_status_invalid_value;
    }

    // Skip validation if input equals current value
    if(input_value == current_value) {
        SAH_TRACEZ_INFO(ME, "Input value %d is same as current value %d for %s",
                        input_value, current_value, input_param_name);
        return amxd_status_ok;
    }

    // Validate fall threshold
    if(strcmp(input_param_name, RM_CPU_CRITICAL_FALL_THRESHOLD) == 0) {

        reference_value = amxd_object_get_value(uint32_t, object, RM_CPU_CRITICAL_RISE_THRESHOLD, NULL);
        if(reference_value == 0) {
            SAH_TRACEZ_INFO(ME, "Reference rise threshold not set for instance %u", object->index);
            return amxd_status_ok;
        }

        if(input_value >= reference_value) {
            SAH_TRACEZ_ERROR(ME, "Fall threshold (%d) must be less than rise threshold (%d) for instance %u",
                             input_value, reference_value, object->index);
            status = amxd_status_invalid_value;
        }

        // Validate rise threshold
    } else if(strcmp(input_param_name, RM_CPU_CRITICAL_RISE_THRESHOLD) == 0) {

        reference_value = amxd_object_get_value(uint32_t, object, RM_CPU_CRITICAL_FALL_THRESHOLD, NULL);
        if(reference_value == 0) {
            SAH_TRACEZ_INFO(ME, "Reference fall threshold not set for instance %u", object->index);
            return amxd_status_ok;
        }

        if(input_value <= reference_value) {
            SAH_TRACEZ_ERROR(ME, "Rise threshold (%d) must be greater than fall threshold (%d) for instance %u",
                             input_value, reference_value, object->index);
            status = amxd_status_invalid_value;
        }

        // Unsupported parameter
    } else {
        SAH_TRACEZ_ERROR(ME, "Unsupported parameter for validation: %s", input_param_name);
        status = amxd_status_parameter_not_found;
    }

exit:
    return status;
}

/**
 * @brief Handles changes to FilePath or EnableCriticalLog for CPU monitor instances.
 *
 * Triggered by configuration change signals. Extracts the instance index from the object path
 * and updates the corresponding CPU monitor's VendorLogFileRef.
 */
void _cmon_handle_filename_enablelog_change(UNUSED const char* const sig_name,
                                            const amxc_var_t* const data,
                                            UNUSED void* const priv) {
    const char* object_path = NULL;
    amxd_dm_t* dm = NULL;
    uint32_t index = 0;


    // Validate signal data
    when_null_trace(data, exit, ERROR, "Signal data is NULL");

    // Get data model
    dm = deviceinfo_get_dm();
    when_null_trace(dm, exit, ERROR, "Failed to retrieve data model");

    // Get object path from signal data
    object_path = GET_CHAR(data, "path");
    when_null_trace(object_path, exit, ERROR, "Failed to retrieve object path from signal");

    // Extract instance index from path
    if(sscanf(object_path, "DeviceInfo.ProcessStatus.CPU.%u.", &index) == 1) {
        if((index == 0) || (index > max_cpu)) {
            SAH_TRACEZ_ERROR(ME, "CPU index %u out of range (max = %u)", index, max_cpu);
            goto exit;
        }

        index -= 1;  // Adjust for zero-based indexing

        // Fetch CPU object dynamically
        amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", index + 1);
        when_null_trace(cpu_obj, exit, ERROR, "CPU monitor object for index %u not found", index);

        SAH_TRACEZ_INFO(ME, "Log configuration change detected for CPU monitor index: %u", index);

        //Update Log configuration to Syslog and VendorLogFileRef to CPU monitor
        cmon_update_vendorlogfileref_syslog(index);
    } else {
        SAH_TRACEZ_ERROR(ME, "Failed to parse CPU index from path: %s", object_path);
    }

exit:
    return;
}

/**
 * @brief Updates VendorLogFileRef for a specific CPU monitor instance.
 *
 * Synchronizes the log file path and critical log enable status with the syslog configuration
 * for the given CPU monitor instance.
 *
 * @param instance Index of the CPU monitor object to update.
 */
void cmon_update_vendorlogfileref_syslog(uint32_t instance) {
    const char* cpu_file_path = NULL;
    bool enable_critical_log = false;
    amxb_bus_ctx_t* syslog_ctx = NULL;

    amxc_var_t result, parameters, response;
    amxc_var_t* action_entry = NULL;
    char search_path[RM_FILE_PATH_BUFFER_SIZE] = {0};
    char logfile_path[RM_FILE_PATH_BUFFER_SIZE] = {0};
    const char* vendorlog_ref_path = NULL;

    amxc_var_init(&result);
    amxc_var_init(&parameters);
    amxc_var_init(&response);

    SAH_TRACEZ_INFO(ME, "Syncing CPU monitor log settings with Syslog for instance %u", instance);

    // Validate CPU monitor object - fetch it dynamically
    amxd_dm_t* dm = deviceinfo_get_dm();
    amxd_object_t* cpu_obj = amxd_dm_findf(dm, RM_CPU_PATH ".%u", instance + 1);
    when_null_trace(cpu_obj, exit, ERROR, "CPU monitor object for instance %u not found", instance);

    // Get CPU monitor file path
    cpu_file_path = amxd_object_get_value(cstring_t, cpu_obj, RM_CPU_FILE_PATH, NULL);
    when_null_trace(cpu_file_path, exit, ERROR, "CPU monitor file path is NULL for instance %u", instance);

    // Get critical log enable flag
    enable_critical_log = amxd_object_get_value(bool, cpu_obj, RM_CPU_ENABLE_CRITICAL_LOG, NULL);

    // Get Syslog bus context
    syslog_ctx = amxb_be_who_has(CMON_SYSLOG_PATH);
    when_null_trace(syslog_ctx, exit, ERROR, "Syslog bus context not found");

    // Build search path for Syslog.Action.{i} with matching alias
    snprintf(search_path, sizeof(search_path), "Syslog.Action.[Alias == '%s%u'].", CMON_ALIAS_LOG, instance);

    int rc = amxb_get(syslog_ctx, search_path, 1, &result, CMON_TIMEOUT);
    when_true_trace(rc != 0, exit, ERROR, "Failed to locate Syslog.Action instance with Alias == 'cmon-cpu%u'", instance);

    // Get first matching instance
    action_entry = amxc_var_get_first(&result);
    when_null_trace(action_entry, exit, ERROR, "No matching Syslog.Action instance found for CPU%u", instance);

    // Get full object path
    amxc_var_for_each(entry, action_entry) {
        const char* key = amxc_var_key(entry);
        if((key != NULL) && (strstr(key, "LogFile") != NULL)) {
            snprintf(logfile_path, sizeof(logfile_path), "%s", key);
            break;
        }
    }

    SAH_TRACEZ_INFO(ME, "Computed logfile_path = %s for CPU%u", logfile_path, instance);

    // Prepare parameters to update
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, RM_CPU_FILE_PATH, cpu_file_path);
    amxc_var_add_key(bool, &parameters, RM_CPU_ENABLE, enable_critical_log);

    // Update LogFile settings
    rc = amxb_set(syslog_ctx, logfile_path, &parameters, &response, CMON_TIMEOUT);
    when_true_trace(rc != 0, exit, ERROR, "Failed to update Syslog.LogFile settings at path: %s, error: %d", logfile_path, rc);

    // Get VendorLogFileRef from updated data
    vendorlog_ref_path = GET_CHAR(GET_ARG(action_entry, logfile_path), RM_CPU_VENDOR_LOG_FILE_REF);
    when_null_trace(vendorlog_ref_path, exit, ERROR, "VendorLogFileRef not found for CPU%u", instance);

    SAH_TRACEZ_INFO(ME, "Setting VendorLogFileRef = %s for CPU%u", vendorlog_ref_path, instance);
    rc = amxd_object_set_value(cstring_t, cpu_obj, RM_CPU_VENDOR_LOG_FILE_REF, vendorlog_ref_path);
    when_true_trace(rc != 0, exit, ERROR, "Failed to set VendorLogFileRef for CPU%u", instance);

exit:
    if(cpu_file_path != NULL) {
        free((char*) cpu_file_path);
    }
    amxc_var_clean(&result);
    amxc_var_clean(&parameters);
    amxc_var_clean(&response);
}
