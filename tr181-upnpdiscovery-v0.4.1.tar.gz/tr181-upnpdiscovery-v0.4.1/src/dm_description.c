/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE

#include <upnp/upnp.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_transaction.h>
#include "tr181-upnpdiscovery.h"
#include "tr181-description.h"

#define ME "dm-desc"

void _upnp_description_object_added(UNUSED const char* const sig_name,
                                    const amxc_var_t* const data,
                                    UNUSED void* const priv) {
    amxd_object_t* object = NULL;
    const char* location;

    object = amxd_dm_findf(get_dm(), "%s%d.", GET_CHAR(data, "object"), GET_UINT32(data, "index"));
    when_null(object, exit);
    location = GET_CHAR(amxd_object_get_param_value(object, "Location"), NULL);
    upnp_description_update_from_location(location);
exit:
    return;
}

void _upnp_description_service_added(UNUSED const char* const sig_name,
                                     const amxc_var_t* const data,
                                     UNUSED void* const priv) {
    amxd_object_t* service = NULL;

    service = amxd_dm_findf(get_dm(), "%s%d.", GET_CHAR(data, "object"), GET_UINT32(data, "index"));
    when_null(service, exit);
    upnp_description_update_service_discovery(service);
exit:
    return;
}

void _upnp_description_device_added(UNUSED const char* const sig_name,
                                    const amxc_var_t* const data,
                                    UNUSED void* const priv) {
    amxd_object_t* device = NULL;

    device = amxd_dm_findf(get_dm(), "%s%d.", GET_CHAR(data, "object"), GET_UINT32(data, "index"));
    when_null(device, exit);
    upnp_description_update_device_discovery(device);
exit:
    return;
}

amxd_status_t _addDeviceInstance(UNUSED amxd_object_t* object,
                                 UNUSED amxd_function_t* func,
                                 amxc_var_t* args,
                                 amxc_var_t* ret) {
    amxc_var_t* values = amxc_var_get_key(args, "values", AMXC_VAR_FLAG_DEFAULT);
    const char* parent = GETP_CHAR(args, "values.ParentDevice");
    device_desc_t desc;

    amxc_var_set(bool, ret, false);

    // values can not be NULL, but only UDN needs to be filled in
    when_null(values, exit);
    // parent can be empty, but not NULL
    when_null(parent, exit)
    when_str_empty_trace(GET_CHAR(values, "UDN"), exit, ERROR, "UDN was not filled in");

    set_parent(parent);
    desc.ip_address = (char*) GET_CHAR(values, "IPAddress");
    upnp_description_update_device(values, &desc);

    amxc_var_set(bool, ret, true);

exit:
    return amxd_status_ok;
}

amxd_status_t _addServiceInstance(UNUSED amxd_object_t* object,
                                  UNUSED amxd_function_t* func,
                                  amxc_var_t* args,
                                  amxc_var_t* ret) {
    amxc_var_t* values = amxc_var_get_key(args, "values", AMXC_VAR_FLAG_DEFAULT);
    const char* parent = GETP_CHAR(args, "values.ParentDevice");

    amxc_var_set(bool, ret, false);

    // values can not be NULL, but only UDN needs to be filled in
    when_null(values, exit);
    // parent can be empty, but not NULL
    when_null(parent, exit);

    set_parent(parent);
    upnp_description_update_service(values);

    amxc_var_set(bool, ret, true);

exit:
    return amxd_status_ok;
}

amxd_status_t _deleteDeviceInstance(amxd_object_t* object,
                                    UNUSED amxd_function_t* func,
                                    amxc_var_t* args,
                                    amxc_var_t* ret) {
    const uint32_t index = GET_UINT32(args, "index");
    amxd_trans_t transaction;

    amxc_var_set(bool, ret, false);
    when_true((index == 0), exit);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, object);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_del_inst(&transaction, index, NULL);
    amxd_trans_apply(&transaction, get_dm());

    amxd_trans_clean(&transaction);

    amxc_var_set(bool, ret, true);
exit:
    return amxd_status_ok;
}

amxd_status_t _deleteServiceInstance(amxd_object_t* object,
                                     UNUSED amxd_function_t* func,
                                     amxc_var_t* args,
                                     amxc_var_t* ret) {
    const uint32_t index = GET_UINT32(args, "index");
    amxd_trans_t transaction;

    amxc_var_set(bool, ret, false);
    when_true((index == 0), exit);

    amxd_trans_init(&transaction);
    amxd_trans_select_object(&transaction, object);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_del_inst(&transaction, index, NULL);
    amxd_trans_apply(&transaction, get_dm());

    amxd_trans_clean(&transaction);

    amxc_var_set(bool, ret, true);
exit:
    return amxd_status_ok;
}
