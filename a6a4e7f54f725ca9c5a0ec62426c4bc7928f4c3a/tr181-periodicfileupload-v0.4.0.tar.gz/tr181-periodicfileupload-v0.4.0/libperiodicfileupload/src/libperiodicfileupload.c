/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _GNU_SOURCE

#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <filetransfer/filetransfer.h>
#include "libperiodicfileupload.h"
#include "periodicfileupload.h"

#define ME "libperiodicup"
#define str_empty(str) (str == NULL || str[0] == '\0')

static amxc_llist_t* _files = NULL;
static amxo_parser_t* _parser = NULL;

inline amxb_bus_ctx_t* get_periodicfileupload_bus(void) {
    return amxb_be_who_has(PFU_ROOT_DM_PATH);
}

/**
 * @brief File descriptor monitoring callback
 *
 * Handles file descriptor events for filetransfer (libfiletransfer) operations.
 *
 * @param[in] fd File descriptor with activity
 * @param[in] priv Private data (unused)
 *
 * @note Delegates to ftx_fd_event_handler for processing
 */
static void fd_monitored_cb(int fd, UNUSED void* priv) {
    ftx_fd_event_handler(fd);
}

/**
 * @brief Connection management callback
 *
 * Manages addition and removal of file descriptors for monitoring
 * in the event loop system.
 *
 * @param[in] fd File descriptor to manage
 * @param[in] add true to add monitoring, false to remove
 *
 * @return 0 on success, non-zero on failure
 *
 * @note Uses amxo_connection_add/remove for event loop integration
 */
static int connection_cb(int fd, bool add) {
    int rv = 0;

    if(add) {
        rv = amxo_connection_add(_parser, fd, fd_monitored_cb, NULL, AMXO_LISTEN, NULL);
    } else {
        rv = amxo_connection_remove(_parser, fd);
    }
    return rv;
}

/**
 * @brief Finds file object by ID
 *
 * Searches the global file list for a file transfer object with
 * the specified identifier.
 *
 * @param[in] id File transfer identifier to search for
 *
 * @return Pointer to file object if found, NULL otherwise
 *
 * @note Returns NULL for empty/NULL ID
 */
static pfu_file_t* get_file_by_id(const char* id) {
    pfu_file_t* found_file = NULL;

    when_str_empty(id, exit);
    amxc_llist_for_each(file_it, _files) {
        pfu_file_t* file = amxc_container_of(file_it, pfu_file_t, lit);
        if(file->id != NULL) {
            when_true_status(strcmp(file->id, id) == 0, exit, found_file = file);
        }
    }
exit:
    return found_file;
}

/**
 * @brief Retrieves profile data model
 *
 * Fetches the complete data model for a file's upload profile and
 * updates the profile status based on availability and enable state.
 *
 * @param[in] file File transfer object containing profile path
 * @param[out] ret Variable to store retrieved data model
 *
 * @note Updates file->status based on profile availability and enable state
 * @note Handles profile not found, disabled, and unknown error cases
 */
static void get_profile_dm(pfu_file_t* file, amxc_var_t* ret) {
    int rv;
    amxb_bus_ctx_t* ctx = get_periodicfileupload_bus();

    when_null(file, exit);
    when_str_empty(file->profile_path, exit);
    when_null(ret, exit);
    when_null_trace(ctx, exit, ERROR, "Error while fetching %s dm. Has the library been init correctly?", file->profile_path);
    rv = amxb_get(ctx, file->profile_path, 3, ret, AMXB_GET_TIMEOUT);
    switch(rv) {
    case amxd_status_ok:
        file->status = pfu_profile_status_ok;
        break;
    case amxd_status_object_not_found:
        file->status = pfu_profile_status_not_found;
        break;
    default:
        file->status = pfu_profile_status_unknown;
        SAH_TRACEZ_ERROR(ME, "Unknown error while fetching DM for %s (%d)", file->profile_path, rv);
        break;
    }
exit:
    return;
}

/**
 * @brief Calculates time to next upload interval
 *
 * Computes the number of seconds until the next scheduled upload
 * based on the file's interval and reference time.
 *
 * @param[in] file File transfer object with interval configuration
 *
 * @return Seconds until next interval, -1 if no interval configured
 *
 * @note Returns -1 for zero interval (no periodic uploads)
 * @note Handles time reference alignment for consistent scheduling
 */
static int64_t pfu_time_to_next_interval(pfu_file_t* file) {
    int64_t time_to_next_interval = -1;
    amxc_ts_t now;

    when_null(file, exit);
    when_true(file->interval == 0, exit);
    amxc_ts_now(&now);
    time_to_next_interval = (now.sec - file->time_ref.sec) % file->interval;
    time_to_next_interval = (time_to_next_interval < 0) ? (time_to_next_interval * -1) : (file->interval - time_to_next_interval) % file->interval;
    time_to_next_interval = (time_to_next_interval == 0) ? file->interval : time_to_next_interval;
exit:
    return time_to_next_interval;
}

/**
 * @brief Formats next transfer time as string
 *
 * Calculates and formats the next transfer time based on current timer
 * state and remaining time.
 *
 * @param[in] file File transfer object
 * @param[out] next_transfer Buffer to store formatted time string
 * @param[in] state Current transfer state (determines which timer to use)
 *
 * @note Uses retry timer for retrying state, upload timer otherwise
 * @note Formats time with precision 0 (seconds)
 * @note next_transfer size should be NEXT_TRANSFER_TIMER_STR_LEN
 * @note On failure next_transfer is set to empty string
 */
static void pfu_file_next_transfer_time_to_str(pfu_file_t* file, char* next_transfer, periodicfileupload_state_t state) {
    amxc_ts_t now;
    amxp_timer_t* timer = NULL;

    memset(next_transfer, 0, NEXT_TRANSFER_TIMER_STR_LEN);
    when_null(file, exit);
    when_true(file->interval == 0, exit);
    timer = ((state == pfu_state_retrying) ? file->http_retry_timer : file->upload_timer);
    amxc_ts_now(&now);
    now.sec += (amxp_timer_remaining_time(timer) / 1000);
    amxc_ts_format_precision(&now, next_transfer, NEXT_TRANSFER_TIMER_STR_LEN, 0);
exit:
    return;
}

void pfu_transfer_cb(pfu_file_t* file, periodicfileupload_state_t state, uint32_t error_code) {
    char next_transfer[NEXT_TRANSFER_TIMER_STR_LEN] = {0};
    amxc_var_t data;

    when_null(file, exit);
    file->state = state;
    when_null(file->transfer_cb, exit);
    amxc_var_init(&data);
    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    pfu_file_next_transfer_time_to_str(file, next_transfer, state);
    amxc_var_add_key(uint32_t, &data, "State", state);
    amxc_var_add_key(cstring_t, &data, "ID", file->id);
    switch(state) {
    case pfu_state_retrying:
    case pfu_state_error:
        amxc_var_add_key(uint32_t, &data, "Error", error_code);
    case pfu_state_idle:
    case pfu_state_success:
        if(!str_empty(next_transfer)) {
            amxc_var_add_key(cstring_t, &data, "NextTransfer", next_transfer);
        }
        break;
    default:
        break;
    }
    amxp_sigmngr_deferred_call(NULL, file->transfer_cb, &data, file->transfer_data);
    amxc_var_clean(&data);
exit:
    return;
}

/**
 * @brief Executes pre-transfer callback
 *
 * Calls the registered pre-upload callback and handles the response.
 * Updates transfer state and manages error conditions.
 *
 * @param[in] file File transfer object
 *
 * @return PFU_CB_OK on success, PFU_CB_DELAY for delayed execution, PFU_CB_ERROR on failure
 *
 * @note Sets state to creating before calling callback
 * @note Handles delayed execution for asynchronous operations
 * @note Automatically calls post-transfer on error
 */
static periodicfileupload_cb_status_t pfu_pre_transfer(pfu_file_t* file) {
    periodicfileupload_cb_status_t status = PFU_CB_ERROR;

    if(file->preupload_cb != NULL) {
        pfu_transfer_cb(file, pfu_state_creating, 0);
        status = file->preupload_cb(file->id, file->preupload_data);
        if(status == PFU_CB_DELAY) {
            goto exit;
        }
        when_failed_trace(status, exit, ERROR, "pre-hook script failed with status %d for %s", status, file->id);
    }
    status = PFU_CB_OK;
exit:
    if(status == PFU_CB_ERROR) {
        pfu_post_transfer(file, pfu_state_error, ftx_error_code_internal_error);
    }
    return status;
}

int pfu_post_transfer(pfu_file_t* file, periodicfileupload_state_t state, uint32_t error_code) {
    int rv = -1;

    if(file->interval != 0) {
        int64_t time_to_next_interval = pfu_time_to_next_interval(file);
        when_true(time_to_next_interval == -1, exit);
        amxp_timer_start(file->upload_timer, time_to_next_interval * 1000);
    }
    pfu_transfer_cb(file, state, error_code);
    if(((state == pfu_state_success) || (file->http_retry_timer == NULL)) &&
       (file->postupload_cb != NULL) && (file->postupload_cb(file->id, file->postupload_data) == PFU_CB_ERROR)) {
        SAH_TRACEZ_ERROR(ME, "post-hook script failed for %s", file->id);
    }
    rv = 0;
exit:
    return rv;
}


int pfu_do_request(pfu_file_t* file, bool is_retrying) {
    amxc_var_t dm;
    amxc_var_t* profile_dm = NULL;
    int rv = -1;

    when_null(file, exit);
    amxc_var_init(&dm);
    get_profile_dm(file, &dm);
    when_false_trace(file->status == pfu_profile_status_ok, exit, ERROR, "Profile %s is either disable or unavailable (%d)", file->profile_path, file->status);
    profile_dm = amxc_var_get_pathf(&dm, AMXC_VAR_FLAG_DEFAULT, "0.'%s'.", file->profile_path);
    pfu_transfer_cb(file, pfu_state_uploading, 0);
    if((strcmp(GET_CHAR(profile_dm, "Protocol"), "HTTP") == 0) ||
       (strcmp(GET_CHAR(profile_dm, "Protocol"), "HTTPS") == 0)) {
        pfu_http_request(file, &dm, is_retrying);
    }
    rv = 0;
exit:
    amxc_var_clean(&dm);
    return rv;
}

/**
 * @brief Upload timer callback
 *
 * Called when the periodic upload timer expires to initiate a file upload.
 * Validates profile status and executes pre-transfer hooks before starting upload.
 *
 * @param[in] timer Timer that triggered (unused)
 * @param[in] priv Private data containing pfu_file_t pointer
 *
 * @note Calls pre-transfer callback if configured
 * @note Only starts upload if pre-transfer succeeds
 */
static void pfu_upload_timer_cb(UNUSED amxp_timer_t* timer, void* priv) {
    pfu_file_t* file = (pfu_file_t*) priv;
    amxc_var_t ret;

    amxc_var_init(&ret);
    when_null(file, exit);
    get_profile_dm(file, &ret);
    when_false_trace(file->status == pfu_profile_status_ok, exit, ERROR, "Profile %s is either disable or unavailable (%d)", file->profile_path, file->status);
    if(pfu_pre_transfer(file) == PFU_CB_OK) {
        pfu_do_request(file, false);
    }
exit:
    amxc_var_clean(&ret);
    return;
}

/**
 * @brief Deletes file object from list iterator
 *
 * Safely removes and cleans up a file transfer object including all
 * associated resources like timers and temporary files.
 *
 * @param[in] it List iterator pointing to file object
 *
 * @note Safe to call with NULL iterator
 */
static void delete_file_from_it(amxc_llist_it_t* it) {
    pfu_file_t* file = NULL;

    when_null(it, exit);
    file = amxc_container_of(it, pfu_file_t, lit);
    when_null(file, exit);
    amxp_timer_delete(&file->http_retry_timer);
    if(file->upload_timer != NULL) {
        amxp_timer_delete(&file->upload_timer);
    }
    if(!str_empty(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN))) {
        unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    }
    amxc_string_delete(&file->compressed_name);
    free(file->file_url);
    file->file_url = NULL;
    free(file->profile_path);
    file->profile_path = NULL;
    free(file->id);
    file->id = NULL;
    free(file);
exit:
    return;
}

int periodicfileupload_init(amxo_parser_t* parser) {
    int rv = -1;

    when_true_status(_files != NULL, exit, rv = 0);
    when_null_trace(parser, exit, ERROR, "parser argument cannot be NULL");
    _parser = parser;
    when_null_trace(get_periodicfileupload_bus(), exit, ERROR, "Couldn't find bus for %s (is tr181-periodicfileupload running?)", PFU_ROOT_DM_PATH);
    when_not_null(_files, exit);
    amxc_llist_new(&_files);
    when_null_trace(_files, exit, ERROR, "Couldn't allocate memory for list");
    rv = ftx_init(connection_cb);
    when_failed_trace(rv, exit, ERROR, "Couldn't initiate libfiletransfer (%d)", rv);
    SAH_TRACEZ_INFO(ME, "Lib periodicfileupload init");
exit:
    return rv;
}

void periodicfileupload_deinit(void) {
    if(_files != NULL) {
        amxc_llist_delete(&_files, delete_file_from_it);
        _parser = NULL;
        ftx_clean();
    }
}

/**
 * @brief Converts a device path to a cleaned path format.
 *
 * @param path The original path string to clean
 * @return char* The cleaned path string, or NULL on failure. Caller must free the returned string.
 */
static char* path_to_cleaned_path(const char* path) {
    amxc_string_t tmp;
    char* new_path = NULL;

    when_null(path, exit);
    amxc_string_init(&tmp, 0);
    amxc_string_setf(&tmp, "%s.", path);
    amxc_string_replace(&tmp, "Device.", "", 1);
    amxc_string_replace(&tmp, "..", ".", UINT32_MAX);
    new_path = strdup(amxc_string_get(&tmp, AMXC_STRING_BEGIN));
    amxc_string_clean(&tmp);
exit:
    return new_path;
}

int periodicfileupload_register_file(const char* id, const char* internal_path, const char* profile_path) {
    int rv = -1;
    pfu_file_t* file = NULL;

    when_null_trace(get_periodicfileupload_bus(), exit, ERROR, "Couldn't register file. (PeriodicFileTransfer plugin started?)");
    when_str_empty_trace(id, exit, ERROR, "id (%p) cannot be null or empty", id);
    when_str_empty_trace(profile_path, exit, ERROR, "profile_path (%p) cannot be null or empty", profile_path);
    file = get_file_by_id(id);
    if(file == NULL) {
        file = malloc(sizeof(pfu_file_t));
        when_null_trace(file, exit, ERROR, "Couldn't allocation memory for new file");
        memset(file, 0, sizeof(pfu_file_t));
        amxc_llist_it_init(&file->lit);
        amxc_llist_append(_files, &file->lit);
    }
    file->id = (file->id != NULL) ? file->id : strdup(id);
    if(internal_path != NULL) {
        if((file->file_url != NULL) && (strcmp(file->file_url, internal_path) != 0)) {
            free(file->file_url);
            file->file_url = NULL;
        }
        file->file_url = (file->file_url != NULL) ? file->file_url : strdup(internal_path);
    }
    if(str_empty(file->file_url)) {
        file->empty_file_url = true;
    }
    if((file->profile_path != NULL) && (strcmp(file->profile_path, profile_path) != 0)) {
        free(file->profile_path);
        file->profile_path = NULL;
    }
    file->profile_path = (file->profile_path != NULL) ? file->profile_path : path_to_cleaned_path(profile_path);
    file->interval = DEFAULT_PFU_INTERVAL;
    amxc_ts_parse(&file->time_ref, DEFAULT_PFU_TIMEREF, strlen(DEFAULT_PFU_TIMEREF));
    rv = 0;
exit:
    return rv;
}

void periodicfileupload_deregister_file(const char* id) {
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, WARNING, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, WARNING, "Cannot find on going file for id (%s)", id);
    amxc_llist_it_take(&file->lit);
    delete_file_from_it(&file->lit);
exit:
    return;
}

int periodicfileupload_set_interval(const char* id, uint32_t interval, amxc_ts_t* time_ref) {
    int rv = -1;
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id argument (%p) cannot be null or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find ID (%s). Has it been registered already?", id);
    file->interval = interval;
    if(time_ref != NULL) {
        memcpy(&file->time_ref, time_ref, sizeof(*time_ref));
    }
    rv = 0;
exit:
    return rv;
}

int periodicfileupload_start(const char* id) {
    int rv = -1;
    pfu_file_t* file = NULL;
    amxc_var_t profile_dm;

    amxc_var_init(&profile_dm);
    when_str_empty_trace(id, exit, ERROR, "id argument (%p) cannot be null or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find ID (%s). Has it been registered already?", id);
    when_not_null_trace(file->upload_timer, exit, ERROR, "id (%s) is already started", id);
    get_profile_dm(file, &profile_dm);
    when_false_trace(file->status == pfu_profile_status_ok, exit, WARNING, "Skip this profile %s (%d)", file->profile_path, file->status);
    if(file->interval != 0) {
        int64_t time_to_next_interval = pfu_time_to_next_interval(file);
        when_true(time_to_next_interval == -1, exit);
        amxp_timer_new(&file->upload_timer, pfu_upload_timer_cb, file);
        amxp_timer_start(file->upload_timer, time_to_next_interval * 1000);
        pfu_transfer_cb(file, pfu_state_idle, 0);
    } else {
        pfu_upload_timer_cb(NULL, file);
    }
    rv = 0;
exit:
    amxc_var_clean(&profile_dm);
    return rv;
}

int periodicfileupload_stop(const char* id) {
    int rv = -1;
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find on going file for id (%s)", id);
    amxp_timer_delete(&file->upload_timer);
    amxp_timer_delete(&file->http_retry_timer);
    if(!str_empty(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN))) {
        unlink(amxc_string_get(file->compressed_name, AMXC_STRING_BEGIN));
    }
    amxc_string_delete(&file->compressed_name);
    rv = 0;
exit:
    return rv;
}

void periodicfileupload_preupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv) {
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find on going file for id (%s)", id);
    file->preupload_cb = callback;
    file->preupload_data = priv;
exit:
    return;
}

void periodicfileupload_postupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv) {
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find on going file for id (%s)", id);
    file->postupload_cb = callback;
    file->postupload_data = priv;
exit:
    return;
}

void periodicfileupload_set_transfer_cb(const char* id, periodicfileupload_transfer_cb_t callback, void* priv) {
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find on going file for id (%s)", id);
    file->transfer_cb = callback;
    file->transfer_data = priv;
exit:
    return;
}

/**
 * @brief Deletes script execution context
 *
 * Cleans up all resources associated with a script execution context
 * including timers and subprocess objects.
 *
 * @param[in,out] ctx Pointer to script context pointer (set to NULL after deletion)
 *
 * @note Safely handles NULL pointers
 * @note Deletes timeout timer and subprocess
 * @note Sets context pointer to NULL after cleanup
 */
static void periodicfileupload_script_ctx_delete(pfu_script_ctx_t** ctx) {
    pfu_script_ctx_t* old_ctx = NULL;

    when_null(ctx, exit);
    old_ctx = *ctx;
    when_null(old_ctx, exit);
    amxp_timer_delete(&old_ctx->timeout_timer);
    amxp_subproc_delete(&old_ctx->proc);
    old_ctx->id = NULL;
    free(old_ctx);
    *ctx = NULL;
exit:
    return;
}

/**
 * @brief Script execution completion callback
 *
 * Handles script completion for both pre-hook and post-hook scripts.
 * Processes script exit status and continues transfer or reports errors.
 *
 * @param[in] sig_name Signal name (unused)
 * @param[in] data Signal data (unused)
 * @param[in] priv Script context containing file ID and process info
 *
 * @note For pre-hook: continues transfer on success, reports error on failure
 * @note For pre-hook: if file->file_url is empty, reads file_url on stdout
 * @note For post-hook: only reports error on failure
 * @note Automatically disconnects signal and cleans up context
 */
static void periodicfileupload_exec_script_done(UNUSED const char* const sig_name, UNUSED const amxc_var_t* const data, void* const priv) {
    pfu_script_ctx_t* ctx = (pfu_script_ctx_t*) priv;
    pfu_file_t* file = NULL;
    int script_rv = 0;

    amxp_slot_disconnect_with_priv(amxp_subproc_get_sigmngr(ctx->proc), periodicfileupload_exec_script_done, priv);
    when_str_empty_trace(ctx->id, exit, ERROR, "id %p cannot be NULL or empty", ctx->id);
    file = get_file_by_id(ctx->id);
    when_null_trace(file, exit, ERROR, "cannot find on going file for id (%s)", ctx->id);
    script_rv = amxp_subproc_get_exitstatus(ctx->proc);
    if(file->state == pfu_state_creating) {
        if(script_rv == 0) {
            if(file->empty_file_url) {
                char buf[PATH_MAX] = {0};
                script_rv = read(ctx->proc->fd[STDOUT_FILENO][0], buf, PATH_MAX - 1);
                free(file->file_url);
                file->file_url = NULL;
                if(script_rv <= 0) {
                    SAH_TRACEZ_WARNING(ME, "pre-hook script didn't output a valid file url (read rv %d)", script_rv);
                    pfu_post_transfer(file, pfu_state_error, ftx_error_code_internal_error);
                } else {
                    file->file_url = strdup(buf);
                    periodicfileupload_perform_delayed_transfer(ctx->id);
                }
            } else {
                periodicfileupload_perform_delayed_transfer(ctx->id);
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "pre-hook script failed with status %d for %s", script_rv, file->id);
            pfu_post_transfer(file, pfu_state_error, ftx_error_code_internal_error);
        }
    } else if(script_rv != 0) {
        SAH_TRACEZ_ERROR(ME, "post-hook script failed with status %d for %s", script_rv, file->id);
        pfu_transfer_cb(file, pfu_state_error, ftx_error_code_internal_error);
    }
exit:
    periodicfileupload_script_ctx_delete(&ctx);
}

/**
 * @brief Script timeout callback
 *
 * Handles script execution timeout by killing the process and reporting
 * an error for the associated file transfer.
 *
 * @param[in] timer Timer that triggered (unused)
 * @param[in] priv Script context containing file ID and process info
 *
 * @note Kills script process with SIGKILL
 * @note Reports timeout error for both pre-hook and post-hook scripts
 */
static void periodicfileupload_script_timeout_cb(UNUSED amxp_timer_t* timer, void* priv) {
    pfu_script_ctx_t* ctx = (pfu_script_ctx_t*) priv;
    pfu_file_t* file = NULL;

    amxp_slot_disconnect_with_priv(amxp_subproc_get_sigmngr(ctx->proc), periodicfileupload_exec_script_done, priv);
    amxp_subproc_kill(ctx->proc, SIGKILL);
    when_str_empty_trace(ctx->id, exit, ERROR, "id %p cannot be NULL or empty", ctx->id);
    file = get_file_by_id(ctx->id);
    when_null_trace(file, exit, ERROR, "cannot find on going file for id (%s)", ctx->id);
    if(file->state == pfu_state_creating) {
        SAH_TRACEZ_ERROR(ME, "timeout for pre-hook script of %s", ctx->id);
        pfu_post_transfer(file, pfu_state_error, ftx_error_code_internal_error);
    } else {
        SAH_TRACEZ_ERROR(ME, "timeout for post-hook script of %s", ctx->id);
        pfu_transfer_cb(file, pfu_state_error, ftx_error_code_internal_error);
    }
exit:
    periodicfileupload_script_ctx_delete(&ctx);
}

/**
 * @brief Creates new script execution context
 *
 * Allocates and initializes a new script context with subprocess and
 * timeout timer for script execution management.
 *
 * @param[out] ctx Pointer to store new context
 * @param[in] id File transfer identifier
 *
 * @return 0 on success, -1 on failure
 *
 * @note Creates subprocess and timeout timer
 * @note Context must be deleted with periodicfileupload_script_ctx_delete()
 */
static int periodicfileupload_script_ctx_new(pfu_script_ctx_t** ctx, const char* id) {
    int rv = -1;
    pfu_script_ctx_t* new_ctx = NULL;

    when_null(ctx, exit);
    when_str_empty(id, exit);
    new_ctx = calloc(1, sizeof(*new_ctx));
    when_null(new_ctx, exit);
    new_ctx->id = id;
    when_failed(amxp_subproc_new(&new_ctx->proc), exit);
    when_failed(amxp_timer_new(&new_ctx->timeout_timer, periodicfileupload_script_timeout_cb, new_ctx), exit);
    when_false(amxp_subproc_open_fd(new_ctx->proc, STDOUT_FILENO) != -1, exit);
    *ctx = new_ctx;
    rv = 0;
exit:
    if((rv == -1) && (new_ctx != NULL)) {
        amxp_timer_delete(&new_ctx->timeout_timer);
        amxp_subproc_delete(&new_ctx->proc);
        free(new_ctx);
    }
    return rv;
}

/**
 * @brief Gets real path for script file
 *
 * Resolves the full path for a script file and validates it's within
 * the configured scripts directory for security.
 *
 * @param[in] script_name Name of the script file
 *
 * @return Real path string on success, NULL on failure
 *
 * @note Validates script is within configured scripts-directory
 * @note Prevents directory traversal attacks
 * @note Returned string must be freed by caller
 * @note Uses realpath() to resolve symbolic links and relative paths
 */
static char* periodicfileupload_get_script_realpath(const char* script_name) {
    amxc_string_t script_fullpath;
    const char* scripts_directory = NULL;
    char* script_realpath = NULL;
    char* rv = NULL;

    amxc_string_init(&script_fullpath, 0);
    scripts_directory = GET_CHAR(amxo_parser_get_config(_parser, "scripts-directory"), NULL);
    amxc_string_setf(&script_fullpath, "%s/%s", scripts_directory, script_name);
    script_realpath = realpath(amxc_string_get(&script_fullpath, AMXC_STRING_BEGIN), NULL);
    when_str_empty_trace(script_realpath, exit, ERROR, "couldn't find realpath for %s (%s)", amxc_string_get(&script_fullpath, AMXC_STRING_BEGIN), strerror(errno));
    when_false_trace(strncmp(scripts_directory, script_realpath, strlen(scripts_directory)) == 0, exit, ERROR, "trying to escape script directory: %s", script_realpath);
    rv = script_realpath;
exit:
    if(rv == NULL) {
        free(script_realpath);
    }
    amxc_string_clean(&script_fullpath);
    return rv;
}

periodicfileupload_cb_status_t periodicfileupload_exec_script_cb(const char* id, void* priv) {
    periodicfileupload_cb_status_t rv = PFU_CB_ERROR;
    const char* script = (const char*) priv;
    char* script_realpath = NULL;
    pfu_script_ctx_t* ctx = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    when_null_trace(get_file_by_id(id), exit, ERROR, "cannot find on going file for id (%s)", id);
    when_str_empty_trace(script, exit, ERROR, "priv cannot be empty");
    script_realpath = periodicfileupload_get_script_realpath(script);
    when_str_empty(script_realpath, exit);
    when_failed(periodicfileupload_script_ctx_new(&ctx, id), exit);
    if(amxp_subproc_start(ctx->proc, script_realpath, NULL) == 0) {
        rv = PFU_CB_DELAY;
        amxp_slot_connect(amxp_subproc_get_sigmngr(ctx->proc), "stop", NULL, periodicfileupload_exec_script_done, ctx);
        amxp_timer_start(ctx->timeout_timer, PFU_SCRIPT_TIMEOUT_DURATION_MS);
    } else {
        SAH_TRACEZ_ERROR(ME, "couldn't execute %s script", script_realpath);
        rv = PFU_CB_ERROR;
        periodicfileupload_script_ctx_delete(&ctx);
    }
exit:
    free(script_realpath);
    return rv;
}

int periodicfileupload_perform_delayed_transfer(const char* id) {
    int rv = -1;
    pfu_file_t* file = NULL;

    when_str_empty_trace(id, exit, ERROR, "id %p cannot be NULL or empty", id);
    file = get_file_by_id(id);
    when_null_trace(file, exit, ERROR, "Cannot find on going file for id (%s)", id);
    rv = pfu_do_request(file, false);
exit:
    return rv;
}
