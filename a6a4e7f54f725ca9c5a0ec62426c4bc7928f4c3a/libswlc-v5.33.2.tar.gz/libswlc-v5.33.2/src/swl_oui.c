/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include "swl/swl_common.h"
#include "swl/swl_assert.h"
#include "swl/swl_string.h"
#include "swl/swl_hex.h"
#include "swl/swl_common_oui.h"
#define ME "swl_oui"


/**
 * swl_oui_list_t OUI handlers
 */

static bool s_oui_fromChar_cb(swl_type_t* type _UNUSED, swl_oui_t* tgtData, const char* srcStr) {
    ASSERTS_NOT_NULL(srcStr, false, ME, "NULL");
    ASSERTS_NOT_NULL(tgtData, false, ME, "NULL");
    return swl_hex_toBytesSep(tgtData->ouiBytes, SWL_OUI_BYTE_LEN, srcStr, strlen(srcStr), ':', NULL);
}

static ssize_t s_oui_toChar_cb(swl_type_t* type _UNUSED, char* tgtStr, size_t tgtStrSize, const void* srcData) {
    ASSERTS_NOT_NULL(tgtStr, -EINVAL, ME, "NULL");
    ASSERT_NOT_NULL(srcData, -EINVAL, ME, "NULL");
    return snprintf(tgtStr, tgtStrSize, "%02X:%02X:%02X", (*(swl_oui_t*) srcData).ouiBytes[0],
                    (*(swl_oui_t*) srcData).ouiBytes[1],
                    (*(swl_oui_t*) srcData).ouiBytes[2]);
}

swl_typeFun_t swl_type_oui_fun = {
    .name = "swl_oui",
    .isValue = true,
    .toChar = (swl_type_toChar_cb) s_oui_toChar_cb,
    .fromChar = (swl_type_fromChar_cb) s_oui_fromChar_cb,
    .equals = NULL,
    .copy = NULL
};

swl_type_t gtSwl_type_oui = {
    .typeFun = &swl_type_oui_fun,
    .size = sizeof(swl_oui_t),
};
SWL_REF_TYPE_C(gtSwl_type_ouiPtr, gtSwl_type_oui);

