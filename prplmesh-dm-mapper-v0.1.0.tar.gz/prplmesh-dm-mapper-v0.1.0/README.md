# prplMesh DataModel Mapper

prplMesh DataModel mapper is a middleware component, between the prplMesh components (wifi-sensing, pwhm, etc.) and the frontends (ubus, obuspa, TR-069).
Mapper exposes `X_PRPLWARE-COM_WiFiMapped.` root on ubus, which is mapped to the `Device.WiFi.` using `tr181-device`. It also exposes `Device.WiFi.` on the TR-369 using `usp.translate`.

Each prplmesh component connects to the mapper via USP socket (`usp:/var/run/dm-mapper-controller.sock` by default) and exposes own model. After connection mapper iterates over mapped root objects and tries to execute GET request on the connected component's context. If the GET request succeeds, mapper associates root object with the context. When the request from frontends (e.g. get, set, add, etc.) arrives in the `Device.WiFi.` model, mapper searches which root is used and so to which context (prplMesh component) to redirect the request. After response arrives to the mapper from prplMesh component, mapper redirects it back to caller (frontend).
*Note:* the request and response is mapped, meaning that user request `Device.WiFi.Foo.Bar` the request to the component would look like `Foo.Bar`. The response is mapped accordingly.

Additionally to mapping root objects `prplmesh-dm-mapper` supports renaming and hiding objects, parameters, RPCs and events.

## ODL configuration options

### Mapping object root
`dmm-object` table is used to map `Device.WiFi.` object to prplMesh component root, it has the following structure:
* key: subobject under `X_PRPLWARE-COM_WiFiMapped.`, the object on which the prplMesh component would be available
* value: root object of the prplMesh component
For example `wifi-sensing` mapping maps `X_PRPLWARE-COM_WiFiMapped.X_PRPLWARE-COM_WiFiSensing.` to the `X_PRPLWARE-COM_WiFiSensing`:
```
%global dmm-object += {
    "'${global_vendor_prefix_}WiFiMapped.${global_vendor_prefix_}WiFiSensing.'" = "${global_vendor_prefix_}WiFiSensing."
};
```

Each mapping is available in own ODL file (for example, `odl/prplmesh-pwhm-mapping.odl` mapps pwhm component) and the main ODL file just includes them.

*Note:* mapping is available only for root objects, e.g. direct root like the example above or root object under `Device.`, be aware the typically you need to postprocess mapping also if you are planning to map to object under `Device.`. It means you cannot map `X_PRPLWARE-COM_WiFiMapped.Buzz.` to `Foo.Bar.Buzz.` object.
### Mapping post translate
When mapping to the object under `Device.` and the component uses `usp.translate` to make own model available under `Device.` it is important to add post translate mapping. When `ups.translate` is used `amxb-usp` does not translate response of the RPC call, for example you may request `Device.WiFi._get()` but it would return `WiFi.` as root object in the response. In that case it is important to add post translate mapping which would connect response root with the mapped component root.
It is done via `dmm-post-translate` table:
* key: mapped component root (e.g. path with `Device.`)
* value: root in the response (e.g. without `Device.`)

For example, this translates `WiFi.` response root object back to `Device.WiFi.`:
```
%global dmm-post-translate += {
    "'Device.WiFi.'" = "WiFi."
};
```
### Renaming objects, parameters, etc.
Mapper supports renaming objects, parameters, RPCs and events. It is done via `dmm-object-rename` table:
* key: actual name
* value: desired name

Renaming is done *after* translation of the path so it must use mapped object path.

For example, this renames `scan()` RPC to `X_PRPLWARE-COM_scan()`
```
%global dmm-object-rename += {
    "'${dmm-top}Radio.{i}.scan()'" = "${dmm-top}Radio.{i}.${global_vendor_prefix_}scan()",
};
```

### Hiding objects, parameters, etc.
Additionally to renaming, mapper supports hiding objects, parameters, RPCs and events, to do so fill t he `dmm-object-hide` list by adding full path with the object, parameter or so to hide.

*Note:* hiding is also done after translating, mapped path must be used.

For example, this hides `ActiveAssociatedDeviceNumberOfEntries` parameter from the mapper's model:
```
%global dmm-object-hide += [
    "${dmm-top}AccessPoint.{i}.ActiveAssociatedDeviceNumberOfEntries",
];
```

### Misc config values
* `dmm-rootobj-retry-count = 5` retry count to get root object from a connected component. Some components may be slow to register their root objects so retry is added. On slow CPEs that counter may need increasing.
* `dmm-rootobj-retry-interval = 30` retry interval to get root object from the connected component. On slow CPEs that counter may need increasing.
* `dmm-resp-wait-time = 30` timeout for waiting for response
* `dmm-top = "${global_vendor_prefix_}WiFiMapped."` top-level object of the mapper
* `dmm-usp-listen-sock = "usp:/var/run/dm-mapper-controller.sock"` path to listen socket of the mapper (to that socket all the prplMesh components are connected)

For detailed reference please see [arch documentation](https://prplfoundationcloud.atlassian.net/wiki/spaces/PWPWG/pages/1212841994/prplMesh+Data+Model+Mapper#Data-Model-Mapper).
