# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.1.1 - 2024-08-02(09:26:00 +0000)

## Release v0.1.0 - 2024-03-28(15:05:59 +0000)

### New

- - [Cellular] Add support of cellular interfaces

