/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc_variant.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_lqueue.h>

#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>

#include <amxs/amxs.h>

#include <amxc/amxc_macros.h>

#include "test_amxs_resolve.h"
#include "dummy_be.h"

static amxb_bus_ctx_t* bus_ctx = NULL;
static unsigned int cb_count_start = 0;
static unsigned int cb_count_stop = 0;

static void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
}

static void test_callback(UNUSED const char* const path,
                          bool match,
                          UNUSED void* const priv) {
    if(match) {
        cb_count_start++;
    } else {
        cb_count_stop++;
    }
}

int test_amxs_resolve_setup(UNUSED void** state) {
    assert_int_equal(test_register_dummy_be(), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    assert_int_equal(test_load_dummy_remote("a.odl"), 0);

    return 0;
}

int test_amxs_resolve_teardown(UNUSED void** state) {
    amxb_disconnect(bus_ctx);
    amxb_free(&bus_ctx);
    assert_int_equal(test_unregister_dummy_be(), 0);

    return 0;
}

void test_amxs_resolve_input(UNUSED void** state) {
    amxs_resolve_ctx_t* ctx = NULL;

    assert_int_not_equal(amxs_resolve_ctx_new(NULL, NULL, NULL, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, NULL, test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.1.", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "A_template.[param_A == 666].", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[this += 65].", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[flag == 'AA']", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "B.A_template.[flag == 'AA'].", test_callback, NULL), 0);
    assert_int_not_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[param_A == 666].", NULL, NULL), 0);

    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[param_A == 666].", test_callback, NULL), 0);
    amxs_resolve_ctx_delete(&ctx);
    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.object_A.A_template.[string_A == 'A'].", test_callback, NULL), 0);
    amxs_resolve_ctx_delete(&ctx);
    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[param_A == 666 && flag ~= 'AA'].", test_callback, NULL), 0);
    amxs_resolve_ctx_delete(&ctx);
    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.A_template_sub.[param_A == 'I am A' && A_sub.number_A == 101].", test_callback, NULL), 0);
    amxs_resolve_ctx_delete(&ctx);
}

void test_amxs_resolve_match(UNUSED void** state) {
    amxs_resolve_ctx_t* ctx = NULL;
    unsigned int start_count = cb_count_start;
    unsigned int stop_count = cb_count_stop;
    amxd_trans_t trans;

    amxd_trans_init(&trans);

    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[param_A == 1337].", test_callback, NULL), 0);
    assert_int_equal(cb_count_start, start_count + 1);
    amxs_resolve_ctx_delete(&ctx);
    assert_int_equal(cb_count_stop, stop_count + 1);

    start_count = cb_count_start;
    assert_int_equal(amxs_resolve_ctx_new(&ctx, "A.A_template.[param_A == 404].", test_callback, NULL), 0);
    assert_int_equal(cb_count_start, start_count);

    amxd_trans_select_pathf(&trans, "A.A_template.1.");
    amxd_trans_set_value(uint32_t, &trans, "param_A", 404);
    assert_int_equal(amxd_trans_apply(&trans, test_get_dm()), 0);
    amxd_trans_clean(&trans);
    handle_events();
    assert_int_equal(cb_count_start, start_count + 1);

    stop_count = cb_count_stop;
    amxd_trans_select_pathf(&trans, "A.A_template.1.");
    amxd_trans_set_value(uint32_t, &trans, "param_A", 1337);
    assert_int_equal(amxd_trans_apply(&trans, test_get_dm()), 0);
    amxd_trans_clean(&trans);
    handle_events();
    assert_int_equal(cb_count_stop, stop_count + 1);

    start_count = cb_count_start;
    amxd_trans_select_pathf(&trans, "A.A_template.1.");
    amxd_trans_set_value(uint32_t, &trans, "param_A", 404);
    assert_int_equal(amxd_trans_apply(&trans, test_get_dm()), 0);
    amxd_trans_clean(&trans);
    handle_events();
    assert_int_equal(cb_count_start, start_count + 1);

    stop_count = cb_count_stop;
    amxd_trans_select_pathf(&trans, "A.A_template.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, test_get_dm()), 0);
    amxd_trans_clean(&trans);
    handle_events();
    assert_int_equal(cb_count_stop, stop_count + 1);

    amxs_resolve_ctx_delete(&ctx);
}
