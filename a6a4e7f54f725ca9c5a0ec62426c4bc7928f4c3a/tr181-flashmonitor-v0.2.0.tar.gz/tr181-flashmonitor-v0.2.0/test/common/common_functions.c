/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxc/amxc_macros.h>
#include <amxut/amxut_bus.h>

#include <amxo/amxo.h>

#include <cmocka.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "../common/common_functions.h"
void resolver_add_all_functions(amxo_parser_t* parser) {
    assert_int_equal(amxo_resolver_ftab_add(parser, "fh_main",
                                            AMXO_FUNC(_fh_main)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "update_emmc_lifetimea_thresholds",
                                            AMXO_FUNC(_update_emmc_lifetimea_thresholds)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "update_emmc_lifetimeb_thresholds",
                                            AMXO_FUNC(_update_emmc_lifetimeb_thresholds)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "update_emmc_preeol_thresholds",
                                            AMXO_FUNC(_update_emmc_preeol_thresholds)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "update_nand_thresholds",
                                            AMXO_FUNC(_update_nand_thresholds)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "nand_usage",
                                            AMXO_FUNC(_nand_usage)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "emmc_usage",
                                            AMXO_FUNC(_emmc_usage)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "update_flash_monitoring",
                                            AMXO_FUNC(_update_flash_monitoring)), 0);
}

int common_setup(void** state) {
    amxd_object_t* root = NULL;
    amxut_bus_setup(state);
    amxd_dm_t* dm = amxut_bus_dm();
    amxo_parser_t* parser = amxut_bus_parser();
    assert_non_null(dm);
    assert_non_null(parser);

    root = amxd_dm_get_root(dm);
    assert_non_null(root);

    resolver_add_all_functions(parser);

//    assert_int_equal(amxo_parser_parse_file(parser, ODL_MOCK_MAIN, root), 0);
    assert_int_equal(amxo_parser_parse_file(parser, ODL_DEFINITION, root), 0);
    assert_int_equal(amxo_parser_parse_file(parser, ODL_DEFAULTS, root), 0);
    _fh_main(AMXO_START, dm, parser);

    amxut_bus_handle_events();
    return 0;
}

int common_teardown(void** state) {
    _fh_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser());
    amxo_resolver_import_close_all();
    amxut_bus_teardown(state);
    amxut_bus_handle_events();
    return 0;
}


