/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>


#include "dmm.h"
#include "dmm_connect_mngr.h"

int test_setup(void** state) {
    amxut_bus_setup(state);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}


static actx_llist_t* create_bus_ctx_item(const char* root) {
    assert_non_null(root);
    actx_llist_t* ctx_item = malloc(sizeof(actx_llist_t));
    assert_non_null(ctx_item);

    ctx_item->a_bus_ctx = (void*) ctx_item;
    snprintf(ctx_item->root_path, sizeof(ctx_item->root_path), "%s", root);
    assert_string_equal(ctx_item->root_path, root);

    ctx_item->a_bus_ctx->bus_fn = NULL;

    return ctx_item;
}

void test_dmm_get_connection(UNUSED void** state) {
    amxc_llist_new(&bus_ctx_list);

    actx_llist_t* wifi_ctx_item = create_bus_ctx_item("WiFi.");
    amxc_llist_it_init(&(wifi_ctx_item->it));
    amxc_llist_append(bus_ctx_list, &(wifi_ctx_item->it));

    actx_llist_t* device_wifi_ctx_item = create_bus_ctx_item("Device.WiFi.");
    amxc_llist_it_init(&(device_wifi_ctx_item->it));
    amxc_llist_append(bus_ctx_list, &(device_wifi_ctx_item->it));

    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("WiFi.");
        assert_ptr_equal(ctx, wifi_ctx_item->a_bus_ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("WiFi.Foo.");
        assert_ptr_equal(ctx, wifi_ctx_item->a_bus_ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("WiFi.Foo.Bar");
        assert_ptr_equal(ctx, wifi_ctx_item->a_bus_ctx);
    }

    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Device.WiFi.");
        assert_ptr_equal(ctx, device_wifi_ctx_item->a_bus_ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Device.WiFi.Foo.");
        assert_ptr_equal(ctx, device_wifi_ctx_item->a_bus_ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Device.WiFi.Foo.Bar");
        assert_ptr_equal(ctx, device_wifi_ctx_item->a_bus_ctx);
    }

    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Unknown.");
        assert_null(ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Device.Unknown.");
        assert_null(ctx);
    }
    {
        amxb_bus_ctx_t* ctx = dmm_get_connection("Unknown.Foo");
        assert_null(ctx);
    }

    amxc_llist_delete(&bus_ctx_list, NULL);
    free(device_wifi_ctx_item);
    free(wifi_ctx_item);

}

int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_dmm_get_connection)
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);

}
