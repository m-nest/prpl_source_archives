/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dm_dnssd_advertisement.h"
#include "dnssd_advertisement.h"
#include "dnssd_advertisement_info.h"

/**
 * @brief
 * Apply config changes to an advertised service
 *
 * @param advertisement_service the advertise service object to configure
 */
static void change_config(amxd_object_t* advertisement_service) {
    bool enable = false;
    amxd_status_t status = amxd_status_unknown_error;

    when_null_trace(advertisement_service, exit, ERROR, "Unable to get the modified advertise service object.");

    status = disable_service(advertisement_service);
    enable = amxd_object_get_value(bool, advertisement_service, "Enable", NULL);
    when_false_trace(dnssd_advertise_service_ok(advertisement_service), exit, WARNING, "Not all parameters are filled.");
    if(enable) {
        status = enable_service(advertisement_service);
    }
    when_failed_trace(status, exit, ERROR, "Unable to enable or disable advertise.");
exit:
    return;
}
/**
 * @brief
 * Event handler function when there is a modification to the fields of an advertised service.
 *
 * @param event_name Name of the event send to the object, not used.
 * @param event_data data from the called event.
 * @param priv Additionnal arguments, not used.
 */
void _dnssd_advertisement_changed(UNUSED const char* const event_name,
                                  const amxc_var_t* const event_data,
                                  UNUSED void* const priv) {
    amxd_dm_t* dm = NULL;
    amxd_object_t* advertisement_service = NULL;

    SAH_TRACEZ_INFO(ME, "In changed handler event function.");

    dm = dnssd_advertisement_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DNSSD advertise data model object.");
    advertisement_service = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(advertisement_service, exit, ERROR, "Unable to get the modified advertise service object.");

    change_config(advertisement_service);
exit:
    return;
}

/**
 * @brief
 * Event handler function when there is a new text entry of an advertised service.
 *
 * @param event_name Name of the event send to the object, not used.
 * @param event_data data from the called event.
 * @param priv Additionnal arguments, not used.
 */
void _dnssd_advertisement_added_text(UNUSED const char* const event_name,
                                     const amxc_var_t* const event_data,
                                     UNUSED void* const priv) {
    amxd_dm_t* dm = NULL;
    amxd_object_t* advertisement_service = NULL;
    amxd_object_t* text_template = NULL;

    SAH_TRACEZ_INFO(ME, "In added handler event function for text entries.");

    dm = dnssd_advertisement_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DNSSD advertise data model object.");
    text_template = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(text_template, exit, ERROR, "Unable to get the modified text entry object.");
    advertisement_service = amxd_object_get_parent(text_template);
    when_null_trace(advertisement_service, exit, ERROR, "Unable to get the modified advertise service object.");

    change_config(advertisement_service);
exit:
    return;
}

/**
 * @brief
 * Event handler function when there is a modification to the fields of a text entry of an advertised service.
 *
 * @param event_name Name of the event send to the object, not used.
 * @param event_data data from the called event.
 * @param priv Additionnal arguments, not used.
 */
void _dnssd_advertisement_changed_text(UNUSED const char* const event_name,
                                       const amxc_var_t* const event_data,
                                       UNUSED void* const priv) {
    amxd_dm_t* dm = NULL;
    amxd_object_t* advertisement_service = NULL;
    amxd_object_t* text_object = NULL;

    SAH_TRACEZ_INFO(ME, "In changed handler event function for text entries.");

    dm = dnssd_advertisement_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DNSSD advertise data model object.");
    text_object = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(text_object, exit, ERROR, "Unable to get the modified text entry object.");
    advertisement_service = amxd_object_get_parent(amxd_object_get_parent(text_object));
    when_null_trace(advertisement_service, exit, ERROR, "Unable to get the modified advertise service object.");

    change_config(advertisement_service);
exit:
    return;
}

/**
 * @brief
 * Handler event when a new service to advertise is added to the DNSSD.advertise. data model.
 *
 * @param event_name Name of the event send to the object, not used.
 * @param event_data data from the called event.
 * @param priv Additionnal arguments, not used.
 */
void _dnssd_advertisement_added(UNUSED const char* const event_name,
                                const amxc_var_t* const event_data,
                                UNUSED void* const priv) {
    amxd_status_t status = amxd_status_unknown_error;
    bool enable = false;
    amxd_dm_t* dm = NULL;
    amxd_object_t* templ = NULL;
    amxd_object_t* advertisement_service = NULL;
    const char* name = NULL;

    SAH_TRACEZ_INFO(ME, "In advertise service added event handler function.");

    name = GET_CHAR(event_data, "name");
    when_null_trace(name, exit, ERROR, "Cannot get object name.");

    dm = dnssd_advertisement_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DNSSD advertise data model.");
    templ = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(templ, exit, ERROR, "Cannot get template for advertise service object.");
    advertisement_service = amxd_object_get_instance(templ, name, 0);
    when_null_trace(advertisement_service, exit, ERROR, "Cannot get advertise service object.");

    enable = amxd_object_get_value(bool, advertisement_service, "Enable", NULL);
    service_info_create(advertisement_service);
    status = enable ? enable_service(advertisement_service) : disable_service(advertisement_service);
    when_failed_trace(status, exit, ERROR, "Unable to enable or disable pool.");
exit:
    return;
}