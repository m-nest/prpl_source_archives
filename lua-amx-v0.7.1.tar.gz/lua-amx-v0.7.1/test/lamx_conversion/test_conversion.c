/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <sys/signalfd.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <amxb/amxb_register.h>
#include <amxp/amxp_dir.h>

#include "lua_amx.h"

#include "test_conversion.h"

static lua_State* L;



int test_conversion_setup(UNUSED void** state) {
    L = luaL_newstate();
    luaL_openlibs(L);

    luaopen_lamx(L);

    lua_setglobal(L, "lamx");

    return 0;
}

int test_conversion_teardown(UNUSED void** state) {
    lua_close(L);
    return 0;
}

void test_convert_string(UNUSED void** state) {
    lua_settop(L, 0);
    amxc_var_t var;
    amxc_var_init(&var);
    amxc_var_set_cstring_t(&var, "teststring");
    lamx_var2lua(&var, L);

    // check conversion
    int n = lua_gettop(L);
    const char* str = lua_tostring(L, n);
    assert_string_equal("teststring", str);
    amxc_var_clean(&var);
}

void test_convert_int(UNUSED void** state) {
    lua_settop(L, 0);
    amxc_var_t var;
    amxc_var_init(&var);
    amxc_var_set_int32_t(&var, 1234);
    lamx_var2lua(&var, L);

    // check conversion
    int n = lua_gettop(L);
    lua_Integer i = lua_tointeger(L, n);
    assert_int_equal(1234, i);
    amxc_var_clean(&var);
}

void test_convert_bool(UNUSED void** state) {
    lua_settop(L, 0);
    amxc_var_t var;
    amxc_var_init(&var);

    // check true
    amxc_var_set_bool(&var, true);
    lamx_var2lua(&var, L);

    // check conversion
    int n = lua_gettop(L);
    int i = lua_toboolean(L, n);
    assert_true(i);

    // check false
    amxc_var_set_bool(&var, false);
    lamx_var2lua(&var, L);

    // check conversion
    n = lua_gettop(L);
    i = lua_toboolean(L, n);
    assert_false(i);
    amxc_var_clean(&var);
}

void test_convert_double(UNUSED void** state) {
    lua_settop(L, 0);
    amxc_var_t var;
    amxc_var_init(&var);
    amxc_var_set_double(&var, 12.34);
    lamx_var2lua(&var, L);

    // check conversion
    int n = lua_gettop(L);
    lua_Number i = lua_tonumber(L, n);
    assert_float_equal(12.34, i, 0);
    amxc_var_clean(&var);
}

void test_convert_timestamp(UNUSED void** state) {
    lua_settop(L, 0);
    amxc_var_t var;
    amxc_ts_t ts;
    amxc_ts_parse(&ts, "2025-11-19T13:35:22+02:00", strlen("2025-11-19T13:35:22+02:00"));

    amxc_var_init(&var);
    amxc_var_set_amxc_ts_t(&var, &ts);
    lamx_var2lua(&var, L);

    // check conversion
    int n = lua_gettop(L);
    amxc_ts_t* lamx_ts = (amxc_ts_t*) luaL_checkudata(L, 1, lamx_ts_mt);
    assert_non_null(lamx_ts);
    size_t len = 0;
    const char* str = luaL_tolstring(L, n, &len);
    assert_string_equal("2025-11-19T13:35:22.000000+02:00", str);
    amxc_var_clean(&var);
}