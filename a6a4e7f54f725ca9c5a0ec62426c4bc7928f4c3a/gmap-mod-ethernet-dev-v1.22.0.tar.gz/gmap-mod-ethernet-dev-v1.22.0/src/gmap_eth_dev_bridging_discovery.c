/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "gmap_eth_dev_bridging.h"
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_includes.h"

#include <features.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_path.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>

typedef struct s_discovery_ctx {
    gmap_eth_dev_bridging_discovery_cb cb;
    uint32_t timeout_ms;
    amxp_timer_t* timer;
} s_discovery_ctx_t;

static struct {
    gmap_eth_dev_bridging_discovery_result_t result;
    s_discovery_ctx_t* ctx;
    amxb_bus_ctx_t* bus_ctx;
} s_discovery = {
    .result = BRIDGING_DISCOVERY_UNKNOWN,
    .ctx = NULL,
    .bus_ctx = NULL,
};

static void s_discovery_wait_done(const char* const s,
                                  const amxc_var_t* const d,
                                  void* const p);

static void s_discovery_ctx_delete(void) {
    when_null(s_discovery.ctx, exit);

    amxp_slot_disconnect_all(s_discovery_wait_done);
    amxp_timer_delete(&s_discovery.ctx->timer);

    free(s_discovery.ctx);
    s_discovery.ctx = NULL;

exit:
    return;
}

static void s_discovery_failed(UNUSED amxp_timer_t* timer,
                               UNUSED void* priv) {
    when_null_trace(s_discovery.ctx, exit, ERROR, "BUG: Discovery timeout called on stopped discovery.");
    when_true(s_discovery.result != BRIDGING_DISCOVERY_UNKNOWN, exit);

    SAH_TRACEZ_INFO(ME, "Discovery timeout");
    s_discovery.result = BRIDGING_DISCOVERY_NOT_SUPPORTED;
    s_discovery.bus_ctx = NULL;
    s_discovery.ctx->cb(s_discovery.result);

exit:
    s_discovery_ctx_delete();
}

static bool s_bridging_supported(const amxc_var_t* info) {
    bool result = false;
    const amxc_var_t* commands = GET_ARG(info, "supported_commands");
    const amxc_var_t* events = GET_ARG(info, "supported_events");

    when_null(info, exit);
    when_null(GET_ARG(events, "MACEvent!"), exit);

    amxc_var_for_each(command, commands) {
        const char* name = GET_CHAR(command, "command_name");
        if((name != NULL) && (strcmp(name, "GetMACList()") == 0)) {
            result = true;
            break;
        }
    }

exit:
    return result;
}

static void s_discovery_wait_done(UNUSED const char* const s,
                                  UNUSED const amxc_var_t* const d,
                                  UNUSED void* const p) {
    int status;
    amxc_var_t ret;

    amxc_var_init(&ret);

    when_null_trace(s_discovery.ctx, exit, ERROR, "BUG: Bridging discovered after timeout.");
    when_true(s_discovery.result != BRIDGING_DISCOVERY_UNKNOWN, exit);

    s_discovery.bus_ctx = amxb_be_who_has("Bridging.");
    when_null_trace(s_discovery.bus_ctx, failure, ERROR, "BUG: Waiting done for Bridging. but can't find its context.");

    status = amxb_get_supported(s_discovery.bus_ctx,
                                "Bridging.Bridge.{i}.Port.{i}.",
                                AMXB_FLAG_FIRST_LVL | AMXB_FLAG_FUNCTIONS | AMXB_FLAG_EVENTS,
                                &ret, 5);
    when_failed_trace(status, failure, ERROR, "Failed to get supported data model: %d", status);

    when_false_trace(s_bridging_supported(GET_ARG(amxc_var_get_first(&ret), "Bridging.Bridge.{i}.Port.{i}.")),
                     failure, ERROR, "Bridging doesn't support required events and/or commands.");

    SAH_TRACEZ_INFO(ME, "Found Bridging");

    s_discovery.result = BRIDGING_DISCOVERY_SUPPORTED;
    s_discovery.ctx->cb(s_discovery.result);

    goto exit;

failure:
    s_discovery.result = BRIDGING_DISCOVERY_NOT_SUPPORTED;
    s_discovery.bus_ctx = NULL;
    s_discovery.ctx->cb(s_discovery.result);

exit:
    amxc_var_clean(&ret);
    s_discovery_ctx_delete();
}

static void s_deferred_start(UNUSED const amxc_var_t* const data,
                             UNUSED void* const priv) {
    int retval;

    when_null(s_discovery.ctx, exit);   // Already stopped before this function is called.

    retval = amxp_timer_new(&s_discovery.ctx->timer, s_discovery_failed, NULL);
    when_failed_trace(retval, failure, ERROR, "Failed to create discovery timeout timer.");

    retval = amxp_slot_connect_filtered(NULL, "^wait:Bridging\\.$", NULL, s_discovery_wait_done, NULL);
    when_failed_trace(retval, failure, ERROR, "subscribing wait failed for object 'Bridging.': %d", retval);

    retval = amxb_wait_for_object("Bridging.");
    when_failed_trace(retval, failure, ERROR, "waiting failed for object 'Bridging.'");

    retval = amxp_timer_start(s_discovery.ctx->timer, s_discovery.ctx->timeout_ms);
    when_failed_trace(retval, failure, ERROR, "Failed to start discovery timeout timer.");

    SAH_TRACEZ_INFO(ME, "Started Bridging discovery");

    goto exit;

failure:
    s_discovery.result = BRIDGING_DISCOVERY_NOT_SUPPORTED;
    s_discovery.bus_ctx = NULL;
    s_discovery.ctx->cb(s_discovery.result);

    s_discovery_ctx_delete();

exit:
    return;
}

int gmap_eth_dev_bridging_start_discovery(gmap_eth_dev_bridging_discovery_cb cb,
                                          uint32_t timeout_ms) {
    int status = -1;

    when_null_trace(cb, exit, ERROR, "NULL");
    when_not_null_trace(s_discovery.ctx, exit, ERROR, "Can't restart bridging discovery twice.");

    if(s_discovery.result != BRIDGING_DISCOVERY_UNKNOWN) {
        cb(s_discovery.result);
        status = 0;
        goto exit;
    }

    s_discovery.ctx = malloc(sizeof(s_discovery_ctx_t));
    when_null_trace(s_discovery.ctx, failure, ERROR, "Out of memory");
    s_discovery.ctx->cb = cb;
    s_discovery.ctx->timeout_ms = timeout_ms;
    s_discovery.ctx->timer = NULL;

    status = amxp_sigmngr_deferred_call(NULL, s_deferred_start, NULL, NULL);
    when_failed_trace(status, failure, ERROR, "Failed to defer bridging discovery start.");

    status = 0;
    goto exit;

failure:
    free(s_discovery.ctx);
    s_discovery.ctx = NULL;
    s_discovery.result = BRIDGING_DISCOVERY_NOT_SUPPORTED;
    SAH_TRACEZ_ERROR(ME, "Failed to defer bridging discovery start.");
    cb(BRIDGING_DISCOVERY_NOT_SUPPORTED);

exit:
    return status;
}

void gmap_eth_dev_bridging_cancel_discovery(void) {
    s_discovery_ctx_delete();
}

void gmap_eth_dev_bridging_reset_discovery(void) {
    s_discovery_ctx_delete();
    s_discovery.result = BRIDGING_DISCOVERY_UNKNOWN;
    s_discovery.ctx = NULL;
    s_discovery.bus_ctx = NULL;
}

gmap_eth_dev_bridging_discovery_result_t gmap_eth_dev_bridging_discovered(void) {
    return s_discovery.result;
}

amxb_bus_ctx_t* gmap_eth_dev_bridging_ctx(void) {
    return s_discovery.bus_ctx;
}
