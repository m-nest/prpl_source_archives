/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "flash_health.h"
#include "dm_flash_health.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ME "events"

/**
 * @brief Creates a transaction for the given object.
 *
 * @param object Pointer to the AMXD object.
 * @return amxd_trans_t* Pointer to the created transaction.
 */
amxd_trans_t* fh_trans_create(amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    amxd_trans_t* trans = NULL;
    when_null(object, exit);

    when_failed(amxd_trans_new(&trans), exit);
    amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    amxd_trans_select_object(trans, object);

exit:
    SAH_TRACEZ_OUT(ME);
    return trans;
}


/**
 * @brief Applies the given transaction to the data model.
 *
 * @param trans Pointer to the transaction.
 * @return amxd_status_t Status of the transaction application.
 */
amxd_status_t fh_trans_apply(amxd_trans_t* trans) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    when_null(trans, exit);

    status = amxd_trans_apply(trans, fh_get_dm());
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to apply transaction, return %d", status);
    }

    amxd_trans_delete(&trans);

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
 * @brief Sets NAND health values in the transaction.
 *
 * @param trans Pointer to the transaction.
 * @param fh Pointer to the flash health structure.
 */
static void set_nand_health_values (amxd_trans_t* trans, flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(trans, exit);
    when_null(fh, exit);
    amxd_trans_set_value(uint32_t, trans, "Health.TotalGoodBlocks", fh->totalGoodBlocks);
    amxd_trans_set_value(uint32_t, trans, "Health.TotalBadBlocks", fh->totalBadBlocks);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Sets eMMC health values in the transaction.
 *
 * @param trans Pointer to the transaction.
 * @param fh Pointer to the flash health structure.
 */
static void set_emmc_health_values (amxd_trans_t* trans, flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(trans, exit);
    when_null(fh, exit);
    amxd_trans_set_value(cstring_t, trans, "Health.LifeTimeA", fh->lifeTimeA);
    amxd_trans_set_value(cstring_t, trans, "Health.LifeTimeB", fh->lifeTimeB);
    amxd_trans_set_value(cstring_t, trans, "Health.eMMCPreEoLInfo", fh->emmcPreEolInfo);
    amxd_trans_set_value(uint32_t, trans, "Health.LifeTimeAHex", fh->lifeTimeAHex);
    amxd_trans_set_value(uint32_t, trans, "Health.LifeTimeBHex", fh->lifeTimeBHex);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Sets the health status of the flash device.
 *
 * @param fh Pointer to the flash health structure.
 * @param status Health status to set.
 */
void set_health_status (flash_health_t* fh, FlashHealthStatus status) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    amxd_object_t* object = (amxd_object_t*) fh->object;
    amxd_trans_t* trans = NULL;
    amxd_status_t rv = amxd_status_unknown_error;
    char val[128];

    if(status == HEALTH_STATUS_NORMAL) {
        strcpy(val, "Normal");
    } else {
        strcpy(val, "Critical");
    }

    SAH_TRACEZ_INFO(ME, "setting health status %s", val);

    trans = fh_trans_create(object);
    when_null(trans, exit);
    amxd_trans_set_value(cstring_t, trans, "Health.HealthStatus", val);
    if(fh->type == FLASH_TYPE_NAND) {
        set_nand_health_values(trans, fh);
    } else if(fh->type == FLASH_TYPE_EMMC) {
        set_emmc_health_values(trans, fh);
    }
    rv = fh_trans_apply(trans);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed");
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}


/**
 * @brief Performs a health check on the flash device based on its type.
 *
 * This function dispatches the appropriate health check routine depending
 * on whether the flash device is of type NAND or eMMC.
 *
 * @param fh Pointer to the flash_health_t structure representing the device.
 */
void fh_perform_test (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    /* write logic to check the health status */
    if(fh->type == FLASH_TYPE_NAND) {
        fh_nand_check(fh);
    } else if(fh->type == FLASH_TYPE_EMMC) {
        fh_emmc_check(fh);
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Timer callback to check flash health status.
 *
 * @param fh_timer Pointer to the timer.
 * @param priv Private data (flash health structure).
 */
void fh_check (amxp_timer_t* fh_timer, void* priv) {
    SAH_TRACEZ_IN(ME);
    when_null(fh_timer, exit);
    flash_health_t* fh = (flash_health_t*) priv;
    if(fh) {
        fh_perform_test(fh);
        amxp_timer_start(fh_timer, FH_TIMER_TIMEOUT);
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Enables flash monitoring based on configuration.
 *
 * @param fh Pointer to the flash health structure.
 */
void enable_flash_monitoring (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    int ret = -1;

    SAH_TRACEZ_INFO(ME, "flash monitoring for %s is enabled", fh->name);
    ret = amxp_timer_new(&fh->fh_timer, fh_check, (void*) fh);
    when_failed_trace(ret, exit, ERROR, "failed to initialize timer");
    amxp_timer_start(fh->fh_timer, 0);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Disables flash monitoring based on configuration.
 *
 * @param fh Pointer to the flash health structure.
 */
void disable_flash_monitoring (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    amxp_timer_stop(fh->fh_timer);
    amxp_timer_delete(&fh->fh_timer);
    SAH_TRACEZ_INFO(ME, "flash monitoring for %s is disabled", fh->name);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}


/**
 * @brief Retrieves and sets flash device information from the object.
 *
 * @param fh Pointer to the flash health structure.
 * @param object Pointer to the AMXD object.
 */
void flash_device_info (flash_health_t* fh, amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    char* type = NULL;
    char* version = NULL;
    char* path = NULL;
    char* name = NULL;

    when_null(fh, exit);
    when_null(object, exit);
    type = amxd_object_get_value(cstring_t, object, "FlashType", NULL);
    when_null(type, exit);
    SAH_TRACEZ_ERROR(ME, "%s", type);

    name = amxd_object_get_value(cstring_t, object, "Name", NULL);
    if(name) {
        strncpy(fh->name, name, sizeof(fh->name) - 1);
        fh->name[sizeof(fh->name) - 1] = '\0';
    }
    SAH_TRACEZ_INFO(ME, "%s", name);

    version = amxd_object_get_value(cstring_t, object, "Version", NULL);
    if(version) {
        strncpy(fh->version, version, sizeof(fh->version) - 1);
        fh->version[sizeof(fh->version) - 1] = '\0';
    }
    SAH_TRACEZ_INFO(ME, "%s", version);

    path = amxd_object_get_value(cstring_t, object, "Path", NULL);
    if(path) {
        strncpy(fh->path, path, sizeof(fh->path) - 1);
        fh->path[sizeof(fh->path) - 1] = '\0';
    }
    SAH_TRACEZ_INFO(ME, "%s", path);

    if(!strcmp(type, "eMMC")) {
        fh->type = FLASH_TYPE_EMMC;
        SAH_TRACEZ_ERROR(ME, "EMMC detected");
    } else if(!strcmp(type, "NAND")) {
        fh->type = FLASH_TYPE_NAND;
        SAH_TRACEZ_ERROR(ME, "NAND detected");
    } else {
        fh->type = FLASH_TYPE_UNKNOWN;
        SAH_TRACEZ_ERROR(ME, "Unknown flash type");
    }
    free(version);
    free(type);
    free(path);
    free(name);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Restores flash health configuration from the object.
 *
 * @param fh Pointer to the flash health structure.
 * @param object Pointer to the AMXD object.
 */
void flash_health_restore_config (flash_health_t* fh, amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    when_null(object, exit);
    fh->enabled = amxd_object_get_value(bool, object, "Health.Enabled", NULL);
    SAH_TRACEZ_INFO(ME, "Enabled status is: %d", fh->enabled);
    if(fh->type == FLASH_TYPE_NAND) {
        fh->badBlocksThreshold = amxd_object_get_value(uint32_t, object, "Health.BadBlocksThreshold", NULL);
    } else if(fh->type == FLASH_TYPE_EMMC) {
        fh->lifeTimeAThreshold = amxd_object_get_value(uint32_t, object, "Health.LifeTimeAThreshold", NULL);
        fh->lifeTimeBThreshold = amxd_object_get_value(uint32_t, object, "Health.LifeTimeBThreshold", NULL);
        fh->preEolThreshold = amxd_object_get_value(uint32_t, object, "Health.PreEolThreshold", NULL);
    } else {
        SAH_TRACEZ_ERROR(ME, "No config");
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Sets default values for flash lifetime fields.
 *
 * This function initializes the Lifetime A and B fields to "Not Defined".
 *
 * @param fh Pointer to the flash_health_t structure.
 */
void flash_set_default_status (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    when_null(fh, exit);
    strcpy(fh->lifeTimeA, "Not Defined");
    strcpy(fh->lifeTimeB, "Not Defined");
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Initializes flash health monitoring for the given object.
 *
 * @param object Pointer to the AMXD object.
 */
static void flash_health_init (amxd_object_t* object) {
    SAH_TRACEZ_IN(ME);
    when_null(object, exit);
    flash_health_t* fh = NULL;

    fh = malloc(sizeof(flash_health_t));
    when_null(fh, exit);
    memset(fh, 0, sizeof(flash_health_t));
    object->priv = (void*) fh;
    fh->object = object;

    flash_device_info(fh, object);
    flash_health_restore_config(fh, object);
    flash_set_default_status(fh);

    if(fh->enabled) {
        SAH_TRACEZ_INFO(ME, "flash moniting is enabled");
        enable_flash_monitoring(fh);
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Initializes all flash device instances by invoking their health initialization.
 *
 * This function locates the "Hardware.FlashDevice." object in the data model and
 * iterates through each instance, initializing its flash health monitoring.
 */
void flash_device_init(void) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* fds = NULL;
    fds = amxd_dm_findf(fh_get_dm(), "Hardware.FlashDevice.");
    amxd_object_for_each(instance, it, fds) {
        amxd_object_t* fd = amxc_container_of(it, amxd_object_t, it);
        if(fd) {
            flash_health_init(fd);
        }
    }
    SAH_TRACEZ_OUT(ME);
}


/**
 * @brief Cleans up flash health resources associated with a given object.
 *
 * This function disables flash monitoring and frees the memory allocated
 * for the flash_health_t structure, if it exists.
 *
 * @param object Pointer to the AMXD object whose flash health data is to be cleaned up.
 */
void flash_health_cleanup(amxd_object_t* object) {
    when_null(object, exit);
    if(object && object->priv) {
        flash_health_t* fh = (flash_health_t*) object->priv;
        disable_flash_monitoring(fh);  // Stop timers if running
        free(fh);                      // Free allocated memory
        object->priv = NULL;
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}


/**
 * @brief Cleans up all flash device instances.
 *
 * This function locates the "Hardware.FlashDevice." object in the data model
 * and iterates through each instance, invoking cleanup for each flash device.
 */
void flash_device_cleanup(void) {
    amxd_object_t* fds = amxd_dm_findf(fh_get_dm(), "Hardware.FlashDevice.");
    amxd_object_for_each(instance, it, fds) {
        amxd_object_t* fd = amxc_container_of(it, amxd_object_t, it);
        flash_health_cleanup(fd);
    }
}
