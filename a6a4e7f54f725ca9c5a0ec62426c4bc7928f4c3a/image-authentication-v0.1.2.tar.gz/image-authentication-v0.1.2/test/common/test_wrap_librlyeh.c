/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_variant.h>

#include <rlyeh/rlyeh_defines.h>
#include <rlyeh/rlyeh_status.h>
#include <rlyeh/rlyeh_curl.h>
#include <lcm/amxc_data.h>
#include "test_setup.h"

#define UNUSED __attribute__((unused))

rlyeh_status_t __wrap_rlyeh_curl_download_content(const rlyeh_curl_parameters_t* parameters,
                                                  const amxc_string_t* url, void* data,
                                                  curl_off_t* size, char* err_msg);
char* __real_strdup(const char* s);
char* __wrap_strdup(const char* s);

static int mock_download(const char* filename, FILE* fd) {
    FILE* input_file = fopen(filename, "rb");
    unsigned char buffer[1024] = {0};
    size_t bytes_read = 0;

    if(input_file == NULL) {
        printf("Error opening input file\n");
        return -1;
    }

    // Read from input file and write to output file
    while((bytes_read = fread(buffer, 1, sizeof(buffer), input_file)) > 0) {
        if(fwrite(buffer, 1, bytes_read, fd) != bytes_read) {
            printf("Error writing to output file\n");
            fclose(input_file);
            return -1;
        }
    }

    fclose(input_file);
    return 0;
}

rlyeh_status_t __wrap_rlyeh_curl_download_content(UNUSED const rlyeh_curl_parameters_t* parameters,
                                                  const amxc_string_t* url, void* data,
                                                  UNUSED curl_off_t* size, UNUSED char* err_msg) {

    rlyeh_status_t rv = RLYEH_ERROR_DOWNLOAD_FAILED;

    if(strcmp(amxc_string_get(url, 0), "http://testserver.com/alpine_3_18.signature") == 0) {
        if(mock_download("../common/signatures/alpine_3_18.signature", (FILE*) data) != 0) {
            rv = RLYEH_ERROR_DOWNLOAD_FAILED;
        } else {
            rv = RLYEH_NO_ERROR;
        }
    } else if(strcmp(amxc_string_get(url, 0), "http://testserver.com/alpine_3_20.signature") == 0) {
        if(mock_download("../common/signatures/alpine_3_20.signature", (FILE*) data) != 0) {
            rv = RLYEH_ERROR_DOWNLOAD_FAILED;
        } else {
            rv = RLYEH_NO_ERROR;
        }
    } else if(strcmp(amxc_string_get(url, 0), "http://testserver.com/alpine_3_18_bad_key.signature") == 0) {
        if(mock_download("../common/signatures/alpine_3_18_bad_key.signature", (FILE*) data) != 0) {
            rv = RLYEH_ERROR_DOWNLOAD_FAILED;
        } else {
            rv = RLYEH_NO_ERROR;
        }
    }

    return rv;
}

char* __wrap_strdup(const char* s) {

    if(strcmp(s, "/usr/share/rlyeh/keys") == 0) {
        return strdup("../common/keys");
    }

    return __real_strdup(s);
}

char* __wrap_amxd_object_get_cstring_t(amxd_object_t* const object,
                                       const char* name,
                                       amxd_status_t* status);
char* __real_amxd_object_get_cstring_t(amxd_object_t* const object,
                                       const char* name,
                                       amxd_status_t* status);


char* __wrap_amxd_object_get_cstring_t(amxd_object_t* const object,
                                       const char* name,
                                       amxd_status_t* status) {

    if(strcmp(name, "KeyLocation") == 0) {
        return strdup("../common/keys");
    }

    return __real_amxd_object_get_cstring_t(object, name, status);
}