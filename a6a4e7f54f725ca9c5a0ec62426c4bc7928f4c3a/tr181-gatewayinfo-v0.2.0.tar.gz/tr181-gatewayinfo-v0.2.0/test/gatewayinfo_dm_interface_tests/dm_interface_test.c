/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxrt/amxrt.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_verify.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <limits.h>

#include "tr181-gatewayinfo.h"
#include "dm_interface.h"

#include "dm_interface_test.h"
#include "../common/functions.h"

#define GATEWAYINFO_DM_DEF_ODL "tr181-gatewayinfo.odl"

#define ME "gatewayinfo"

int test_setup(void** state) {
    assert_int_equal(amxut_bus_setup(state), 0);
    amxut_dm_load_odl(GATEWAYINFO_DM_DEF_ODL);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

static int bus_get_json_equals(const char* object_path, const char* reference_file, bool update) {
    int rc = -1;
    amxb_bus_ctx_t* ctx = amxb_be_who_has(object_path);
    when_null_trace(ctx, exit, ERROR, "Cannot to find context for \"%s\"", object_path);

    amxc_var_t ret;
    amxc_var_init(&ret);
    rc = amxb_get(ctx, object_path, INT_MAX, &ret, BUS_OPERATION_TIMEOUT);
    when_failed_trace(rc, exit, ERROR, "Cannot resquest bus path");
    if(update && reference_file) {
        amxut_util_write_to_json_file(&ret, reference_file);
    }

    assert_int_equal(amxut_verify_variant_from_json_file(&ret, reference_file), 0);

    amxc_var_clean(&ret);

exit:
    return rc;
}

void test_dm_update_gatewayinfo(UNUSED void** state) {
    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
        amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
        amxc_string_set(&gateway_info.DeviceSerialNumber, "DeviceSerialNumber");

        assert_int_equal(dm_update_gatewayinfo(&gateway_info), 0);
        DHCPGatewayInformation_deinit(&gateway_info);
        assert_int_equal(bus_get_json_equals("GatewayInfo.", "dm_dumps/test_dm_update_gatewayinfo1.json", false), 0);
    }
    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
        amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
        amxc_string_set(&gateway_info.DeviceSerialNumber, "");

        assert_int_equal(dm_update_gatewayinfo(&gateway_info), 0);
        DHCPGatewayInformation_deinit(&gateway_info);
        assert_int_equal(bus_get_json_equals("GatewayInfo.", "dm_dumps/test_dm_update_gatewayinfo2.json", false), 0);
    }
    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        amxc_string_set(&gateway_info.DeviceManufacturerOUI, "");
        amxc_string_set(&gateway_info.DeviceProductClass, "");
        amxc_string_set(&gateway_info.DeviceSerialNumber, "");

        assert_int_equal(dm_update_gatewayinfo(&gateway_info), 0);
        DHCPGatewayInformation_deinit(&gateway_info);
        assert_int_equal(bus_get_json_equals("GatewayInfo.", "dm_dumps/test_dm_update_gatewayinfo3.json", false), 0);
    }
}