/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "hosts_manager.h"
#include "hosts_sync.h"
#include "hosts_accesscontroller.h"
#include "hosts_time_sync.h"
#include "hosts_utils.h"

#include <netmodel/common_api.h>
#include "netmodel/client.h"

#include <gmap/gmap.h>
#include <amxd/amxd_object_event.h>
#include <stdlib.h>
#include <string.h>

#define ME "hosts-sync"

#define HOSTS_QUERY_EXPRESSION "lan and not self and physical and .Master==\"\""

typedef struct hosts_alternative_sync_info {
    amxc_htable_it_t it;         // Hash table iterator, owned by hosts_sync_info_t.alts
    char* device_path;           // Named path to the Devices.Device. instance, dot-terminated
    amxs_sync_ctx_t ctx;         // Synchronization context
} hosts_alternative_sync_info_t;

typedef struct hosts_sync_info {
    char* device_path;            // Named path to the Devices.Device. instance, dot-terminated
    char* host_path;              // Index path to the Hosts.Host instance
    int host_index;               // Index of the Hosts.Host. instance
    amxs_sync_ctx_t* ctx;         // Synchronization context
    netmodel_query_t* query_bp;   // NetModel query to find the appropriate bridge port interface
    netmodel_query_t* query_l3;   // NetModel query to find the layer 3 interface from the bridge port
    amxb_subscription_t* alt_sub; // Subscription to discover alternative devices
    amxc_htable_t alts;           // Hash table of hosts_alternative_sync_info_t.it
    amxc_llist_it_t it;           // Linked list iterator
} hosts_sync_info_t;

typedef struct _hosts_gmap_handles {
    amxd_dm_t* hosts_dm;         // the Hosts data model object
    amxo_parser_t* parser;       // the odl parser
    amxb_bus_ctx_t* ctx;

    amxd_object_t* hosts_host;   // the Hosts.Host. template object
} _hosts_gmap_handles_t;

typedef struct inactive_host_info {
    amxc_llist_it_t it;
    amxd_object_t* host;
} inactive_host_info_t;

static amxc_llist_t inactive_hosts;

static int hosts_setup_object_sync(const char* aliaspath,
                                   const amxc_var_t* device);
static int hosts_destroy_object_sync(const char* path);

static amxs_status_t sync_param_action_cb(const amxs_sync_entry_t* entry,
                                          amxs_sync_direction_t direction, amxc_var_t* data,
                                          void* priv);

static void hosts_sync_initialize_inactive_hosts_list(void);
static void free_inactive_host_info(inactive_host_info_t* info);
static void add_unique_inactive_host_to_list(amxd_object_t* host);
static void remove_host_from_inactive_hosts(amxd_object_t* host);
static void hosts_sync_enforce_inactive_threshold(void);

static _hosts_gmap_handles_t hosts_gmap_handles = { 0 };
static amxc_llist_t sync_info;
static gmap_query_t* query = NULL;
static amxp_timer_t* retry_timer = NULL;

/**
   @brief Frees and cleans up an alternative synchronization info item.

   Releases all allocated resources for the given alternative sync info,
   including its device path, synchronization context, and hash table entry.
   After cleanup, the pointer is set to NULL.

   @param info Double pointer to the alternative sync info structure to be freed.

   @note For alternative devices:
         - keep a list of alternatives for each
         - for each in that list, sync the sswsta associateddevice
         - initially don't care about alternative active
 */
static void s_free_alt_sync_item(hosts_alternative_sync_info_t** info) {
    when_null(info, exit);
    when_null(*info, exit);

    if((*info)->device_path != NULL) {
        SAH_TRACEZ_INFO(ME, "Stopped syncing alternative '%s'", (*info)->device_path);
    }

    amxc_htable_it_clean(&(*info)->it, NULL);
    amxs_sync_ctx_clean(&(*info)->ctx);
    free((*info)->device_path);

    free(*info);
    *info = NULL;

exit:
    return;
}

static void s_clean_alt_sync_it(UNUSED const char* key,
                                amxc_htable_it_t* it) {
    hosts_alternative_sync_info_t* info = amxc_llist_it_get_data(it, hosts_alternative_sync_info_t, it);

    when_null(it, exit);
    s_free_alt_sync_item(&info);

exit:
    return;
}

static hosts_alternative_sync_info_t* s_create_alt_sync_item(const char* key) {
    hosts_alternative_sync_info_t* info = NULL;
    amxc_string_t path;

    amxc_string_init(&path, 0);

    when_str_empty_trace(key, exit, ERROR, "BUG: empty/null key");

    when_failed_trace(amxc_string_setf(&path, "Devices.Device.%s.", key),
                      exit, ERROR, "Out of memory");

    info = calloc(1, sizeof(hosts_alternative_sync_info_t));
    when_null_trace(info, exit, ERROR, "Out of memory");

    amxc_htable_it_init(&info->it);
    info->device_path = amxc_string_take_buffer(&path);

exit:
    amxc_string_clean(&path);
    return info;
}

static hosts_alternative_sync_info_t* s_find_alt_sync_item(const hosts_sync_info_t* info,
                                                           const char* key) {
    hosts_alternative_sync_info_t* item = NULL;
    amxc_htable_it_t* it;

    when_null_trace(info, exit, ERROR, "BUG: NULL info");
    when_str_empty_trace(key, exit, ERROR, "BUG: empty key");

    it = amxc_htable_get(&info->alts, key);
    when_null(it, exit);
    item = amxc_htable_it_get_data(it, hosts_alternative_sync_info_t, it);

exit:
    return item;
}

static int s_init_alt_sync_ctx(const hosts_sync_info_t* info,
                               hosts_alternative_sync_info_t* alt) {
    int status = 0;
    amxs_sync_object_t* obj = NULL;

    status = amxs_sync_ctx_init(&alt->ctx, alt->device_path, info->host_path, AMXS_SYNC_ONLY_A_TO_B);

    status |= amxs_sync_ctx_set_local_dm(&alt->ctx, NULL, hosts_gmap_handles.hosts_dm);
    status |= amxs_sync_object_new_copy(&obj, "SSWSta.", ".", AMXS_SYNC_DEFAULT);
    status |= amxs_sync_object_add_new_param(obj, "AssociatedDevice", "AssociatedDevice", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb, NULL);
    status |= amxs_sync_ctx_add_object(&alt->ctx, obj);

    return status;
}

static void s_setup_alt_sync(hosts_sync_info_t* info,
                             const char* key) {
    hosts_alternative_sync_info_t* entry = NULL;

    when_str_empty_trace(key, exit, ERROR, "NULL or empty key");

    entry = s_find_alt_sync_item(info, key);
    when_not_null_trace(entry, exit, WARNING, "Alternative device '%s' for '%s' already synced",
                        key, info->device_path);

    entry = s_create_alt_sync_item(key);
    when_null(entry, exit);

    when_failed_trace(s_init_alt_sync_ctx(info, entry), delete_entry,
                      ERROR, "Failed to create sync context for '%s'", key);
    when_failed_trace(amxs_sync_ctx_start_sync(&entry->ctx), delete_entry,
                      ERROR, "Failed to start sync context for '%s'", key);

    when_failed_trace(amxc_htable_insert(&info->alts, key, &entry->it),
                      delete_entry,
                      ERROR, "Failed to store alt sync entry for '%s'", key);

    SAH_TRACEZ_INFO(ME, "Syncing alternative '%s' to '%s'", key, info->host_path);
    goto exit;

delete_entry:
    s_free_alt_sync_item(&entry);

exit:
    return;
}

static void s_sync_alt_on_instance(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   void* const priv) {
    hosts_sync_info_t* info = priv;
    const char* notification = GET_CHAR(data, "notification");

    when_null_trace(info, exit, ERROR, "BUG: NULL master info");
    when_str_empty_trace(notification, exit, ERROR, "BUG: event without notification");

    if(0 == strcmp(notification, "dm:instance-added")) {
        s_setup_alt_sync(info, GET_CHAR(data, "name"));
    } else if(0 == strcmp(notification, "dm:instance-removed")) {
        hosts_alternative_sync_info_t* entry = s_find_alt_sync_item(info, GET_CHAR(data, "name"));
        s_free_alt_sync_item(&entry);
    }

exit:
    return;
}

static void s_subscribe_alt(hosts_sync_info_t* info) {
    amxc_string_t object;

    amxc_string_init(&object, 0);

    when_null(info, exit);

    amxc_string_set(&object, info->device_path);
    when_failed_trace(amxc_string_append(&object, "Alternative.", 12), exit,
                      ERROR, "Failed to build alternative device path");

    when_failed_trace(amxb_subscription_new(&(info->alt_sub),
                                            gmap_get_bus_ctx(),
                                            amxc_string_get(&object, 0),
                                            "notification == 'dm:instance-added' || notification == 'dm:instance-removed'",
                                            s_sync_alt_on_instance,
                                            info),
                      exit, ERROR, "Failed to subscribe to %s", amxc_string_get(&object, 0));

exit:
    amxc_string_clean(&object);
}

static void s_init_fetch_alt(hosts_sync_info_t* info) {
    amxc_string_t object;
    amxc_var_t data;
    int status;

    amxc_string_init(&object, 0);
    amxc_var_init(&data);

    when_null(info, exit);

    amxc_string_set(&object, info->device_path);
    when_failed_trace(amxc_string_append(&object, "Alternative.", 12), exit,
                      ERROR, "Failed to build alternative device path");

    status = amxb_get_instances(gmap_get_bus_ctx(),
                                amxc_string_get(&object, 0),
                                0,
                                &data,
                                gmap_get_timeout());
    when_failed_trace(status, exit, ERROR,
                      "Failed to get instances of current alternatives for '%s': %d",
                      amxc_string_get(&object, 0), status);

    amxc_var_for_each(item, amxc_var_get_first(&data)) {
        s_setup_alt_sync(info, GET_CHAR(item, "Alias"));
    }


exit:
    amxc_string_clean(&object);
    amxc_var_clean(&data);
}

/**
 *  Get the corresponding sync information entry for the object
 */
static hosts_sync_info_t* hosts_get_sync_info(const cstring_t path, bool host) {
    hosts_sync_info_t* retv = NULL;
    hosts_sync_info_t* current = NULL;

    amxc_llist_for_each(it, &sync_info) {
        current = amxc_container_of(it, hosts_sync_info_t, it);
        const char* current_path = host ? current->host_path : current->device_path;
        if(strcmp(current_path, path) == 0) {
            retv = current;
            break;
        }
    }
    return retv;
}

static hosts_sync_info_t* hosts_get_sync_info_for_host(amxd_object_t* host) {
    hosts_sync_info_t* retv = NULL;
    hosts_sync_info_t* current = NULL;
    uint32_t index = amxd_object_get_index(host);

    when_true(index == 0u, exit);

    amxc_llist_for_each(it, &sync_info) {
        current = amxc_container_of(it, hosts_sync_info_t, it);
        if(current->host_index == (int) index) {
            retv = current;
            break;
        }
    }

exit:
    return retv;
}

static int hosts_delete_object(int index) {
    amxd_trans_t trans;
    int rv = 0;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    amxd_trans_select_pathf(&trans, "Hosts.Host.");
    amxd_trans_del_inst(&trans, index, NULL);

    rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i for host %d", rv, index);

exit:
    amxd_trans_clean(&trans);
    return rv;
}

static amxd_object_t* hosts_find_host_obj(const char* aliaspath,
                                          const char* phys_address) {
    /* This function is used for two purposes:
     * 1. To check whether a host with the given alias path/physical address
     *    already exists.
     * 2. To fetch the host that was just created with that combination.
     *
     * For use case 1, this typically happens during startup, when gmap sends out
     * query device started matching events for new devices. If the host already
     * exists, it should be reused. If not, a new one is created.
     * On average for existing hosts, half the list will be traversed either way
     * assuming that all restored data will be re-linked.
     * For non-existing hosts, it doesn't matter in which direction the list is
     * first traversed.
     *
     * For use case 2, the newly created host should be the last one or one of
     * the last.
     */
    amxd_object_t* obj = NULL;

    amxc_llist_for_each_reverse(it, &hosts_gmap_handles.hosts_host->instances) {
        amxd_object_t* entry = amxc_llist_it_get_data(it, amxd_object_t, it);
        const amxc_var_t* value = amxd_object_get_param_value(entry, "DeviceReference");
        const char* ref = amxc_var_constcast(cstring_t, value);
        const char* mac;

        if((ref == NULL) || (*ref == '\0')) {
            value = amxd_object_get_param_value(entry, "PhysAddress");
            mac = amxc_var_constcast(cstring_t, value);
            when_true_status(mac != NULL && strcmp(mac, phys_address) == 0, exit, obj = entry);
        } else if(strcmp(ref, aliaspath) == 0) {
            obj = entry;
            break;
        }
    }

exit:
    return obj;
}

static int hosts_create_object(const char* physaddr,
                               const char* aliaspath) {
    int rv = 0;
    int host_index = 0;
    amxd_trans_t trans;
    amxd_object_t* hostobject = NULL;
    amxc_string_t mac;

    amxc_string_init(&mac, 0);
    amxc_string_set(&mac, physaddr);
    when_failed_trace(amxc_string_to_upper(&mac), exit, ERROR, "Failed to convert physaddr to uppercase");
    physaddr = amxc_string_get(&mac, 0);

    hostobject = hosts_find_host_obj(aliaspath, physaddr);
    if(hostobject != NULL) {
        /* 1. If there is already an existing object fit for this device,
         *    patch its device reference if needed and return its index.
         */
        const amxc_var_t* value = amxd_object_get_param_value(hostobject, "DeviceReference");
        const char* ref = amxc_var_constcast(cstring_t, value);
        if((ref == NULL) || (strcmp(ref, aliaspath) != 0)) {
            amxd_trans_init(&trans);
            amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
            amxd_trans_select_object(&trans, hostobject);
            amxd_trans_set_value(cstring_t, &trans, "DeviceReference", aliaspath);

            rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
            amxd_trans_clean(&trans);
            when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);
        }
        host_index = amxd_object_get_index(hostobject);
    } else {
        /* 2. Otherwise, create a new Host object */
        amxd_trans_init(&trans);
        amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
        amxd_trans_select_pathf(&trans, "Hosts.Host.");
        amxd_trans_add_inst(&trans, 0, NULL);
        amxd_trans_set_value(cstring_t, &trans, "DeviceReference", aliaspath);
        amxd_trans_set_value(cstring_t, &trans, "PhysAddress", physaddr);

        rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
        amxd_trans_clean(&trans);
        when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);

        hostobject = hosts_find_host_obj(aliaspath, physaddr);
        when_null_trace(hostobject, exit, ERROR, "BUG: hosts_find_host_obj can't find newly created host object");

        host_index = amxd_object_get_index(hostobject);
    }

exit:
    amxc_string_clean(&mac);
    return host_index;
}

static void delete_item(amxc_llist_it_t* it) {
    hosts_sync_info_t* info = amxc_llist_it_get_data(it, hosts_sync_info_t, it);

    when_null(it, exit);

    amxb_subscription_delete(&info->alt_sub);
    amxc_htable_clean(&info->alts, s_clean_alt_sync_it);
    amxs_sync_ctx_stop_sync(info->ctx);
    amxs_sync_ctx_delete(&info->ctx);
    netmodel_closeQuery(info->query_bp);
    netmodel_closeQuery(info->query_l3);
    hosts_delete_object(info->host_index);
    free(info->device_path);
    free(info->host_path);
    free(info);

exit:
    return;
}

static amxs_status_t sync_param_action_cb(UNUSED const amxs_sync_entry_t* entry, UNUSED amxs_sync_direction_t direction, amxc_var_t* data, UNUSED void* priv) {
    amxd_trans_t trans;
    amxs_status_t status = amxs_status_unknown_error;
    int rv = 0;

    const cstring_t path = GET_CHAR(data, "path");
    amxc_var_t* params = amxc_var_get_first(GET_ARG(data, "parameters"));

    amxd_trans_init(&trans);
    when_null(path, exit);
    when_null(params, exit);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "%s", path);
    amxd_trans_set_param(&trans, amxc_var_key(params), params);

    rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i %s %s", rv, path, amxc_var_key(params));
    status = amxs_status_ok;
exit:
    amxd_trans_clean(&trans);

    return status;
}

static bool check_tag(const cstring_t tag_list, const cstring_t tag) {
    amxc_var_t ssv_tags;
    bool ret = false;

    amxc_var_init(&ssv_tags);
    amxc_var_set(ssv_string_t, &ssv_tags, tag_list);
    amxc_var_cast(&ssv_tags, AMXC_VAR_ID_LIST);

    amxc_var_for_each(it, &ssv_tags) {
        if(!strcmp(GET_CHAR(it, NULL), tag)) {
            ret = true;
            break;
        }
    }
    amxc_var_clean(&ssv_tags);

    return ret;
}

static amxs_status_t sync_param_action_cb_protected(UNUSED const amxs_sync_entry_t* entry,
                                                    UNUSED amxs_sync_direction_t direction,
                                                    amxc_var_t* data, UNUSED void* priv) {
    amxs_status_t status = amxs_status_unknown_error;
    amxd_trans_t trans;
    amxc_var_t res;
    amxc_string_t protected;
    int rv;
    const cstring_t hostpath = GET_CHAR(data, "path");
    amxc_var_t* params = amxc_var_get_first(GET_ARG(data, "parameters"));
    const cstring_t tmp = GET_CHAR(params, NULL);
    const char* prefix = GET_CHAR(amxo_parser_get_config(hosts_manager_get_parser(), "global_vendor_prefix_"), NULL);

    amxc_string_init(&protected, 0);
    amxc_string_setf(&protected, "%sProtected", prefix);

    amxc_var_init(&res);
    amxc_var_set(bool, &res, check_tag(tmp, "protected"));

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "%s", hostpath);
    amxd_trans_set_param(&trans, amxc_string_get(&protected, 0), &res);

    rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);
    status = amxs_status_ok;
exit:
    amxc_var_clean(&res);
    amxd_trans_clean(&trans);
    amxc_string_clean(&protected);

    return status;
}

static amxs_status_t sync_param_action_cb_active(UNUSED const amxs_sync_entry_t* entry,
                                                 UNUSED amxs_sync_direction_t direction,
                                                 amxc_var_t* data,
                                                 UNUSED void* priv) {
    amxd_trans_t trans;
    amxs_status_t status = amxs_status_unknown_error;
    int rv = 0;
    amxc_ts_t now;
    amxc_ts_now(&now);

    const cstring_t path = GET_CHAR(data, "path");
    amxc_var_t* params = amxc_var_get_first(GET_ARG(data, "parameters"));
    bool active = false;
    amxd_object_t* host;

    when_null_trace(path, exit, ERROR, "Missing 'path' in data");
    when_null_trace(params, exit, ERROR, "Missing 'parameters' in data");

    active = GET_BOOL(params, false);

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "%s", path);
    amxd_trans_set_param(&trans, amxc_var_key(params), params);
    amxd_trans_set_value(amxc_ts_t, &trans, "ActiveLastChange", &now);

    rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);
    status = amxs_status_ok;

    host = amxd_dm_findf(hosts_gmap_handles.hosts_dm, "%s", path);
    when_null_trace(host, exit, ERROR, "Failed to find host '%s'", path);

    if(active) {
        SAH_TRACEZ_INFO(ME, "Host [%s] active, Removing from inactive hosts list.", host->name);
        remove_host_from_inactive_hosts(host);
    } else {
        add_unique_inactive_host_to_list(host);
        hosts_sync_enforce_inactive_threshold();
    }

exit:
    amxd_trans_clean(&trans);
    return status;
}

static const char* convert_path_to_interface_type(const char* path) {
    /* path should be of the form
     * Device\.(Ethernet|WiFi|MoCA)(\..*)?
     */
    const char* ret = "Other";
    const char* start;
    const char* end;
    size_t length;

    when_str_empty_trace(path, exit, ERROR, "Path is empty");
    start = strchr(path, '.');
    when_null_trace(start, exit, ERROR, "Invalid type string found");
    ++start;

    end = strchr(start, '.');
    if(end == NULL) {
        length = strlen(start);
    } else {
        length = end - start;
    }

    when_true_trace(length == 0, exit, ERROR, "Invalid type string found");

    if((length == 8) && (strncmp(start, "Ethernet", 8) == 0)) {
        ret = "Ethernet";
    } else if((length == 4) && (strncmp(start, "WiFi", 4) == 0)) {
        ret = "Wi-Fi";
    } else if((length == 4) && (strncmp(start, "MoCA", 4) == 0)) {
        ret = "MoCA";
    }

exit:
    return ret;
}

static void nm_layer3_cb(UNUSED const char* sig_name, const amxc_var_t* data, void* priv) {
    const char* layer3 = GET_CHAR(data, NULL);
    amxd_trans_t trans;
    hosts_sync_info_t* info = (hosts_sync_info_t*) priv;
    int ret = 0;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(info, exit, ERROR, "Info pointer is NULL");
    when_null(layer3, exit);

    amxd_trans_select_pathf(&trans, "%s", info->host_path);
    amxd_trans_set_value(cstring_t, &trans, "Layer3Interface", layer3);

    ret = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(ret, exit, ERROR, "Failed to apply transaction: %d", ret);

exit:
    amxd_trans_clean(&trans);
    return;
}

/**
   @brief Callback triggered when a bridge port signal is received.

   Updates the Layer3 interface of a host synchronization entry.
   If an interface is provided, a netmodel query is opened to resolve the
   associated Layer3 interface path. If no interface is provided, the
   Layer3Interface attribute is cleared in the hosts data model.

   @param sig_name Unused signal name.
   @param data     Variant containing the interface name (string).
   @param priv     Pointer to the host synchronization info object.
 */
static void nm_bridgeport_cb(UNUSED const char* sig_name, const amxc_var_t* data, void* priv) {
    const char* iface = GET_CHAR(data, NULL);
    hosts_sync_info_t* info = (hosts_sync_info_t*) priv;

    when_null_trace(info, exit, ERROR, "BUG: NULL info object");

    if(info->query_l3 != NULL) {
        netmodel_closeQuery(info->query_l3);
        info->query_l3 = NULL;
    }
    if((iface == NULL) || (*iface == '\0')) {
        int ret;
        amxd_trans_t trans;
        amxd_trans_init(&trans);
        amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
        amxd_trans_select_pathf(&trans, "%s", info->host_path);
        amxd_trans_set_value(cstring_t, &trans, "Layer3Interface", "");
        ret = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
        amxd_trans_clean(&trans);
        when_failed_trace(ret, exit, ERROR, "Failed to apply transaction: %d", ret);
    } else {
        info->query_l3 = netmodel_openQuery_getFirstParameter(iface, "hosts", "InterfacePath", "ip",
                                                              netmodel_traverse_up, nm_layer3_cb, info);
        when_null_trace(info->query_l3, exit, ERROR, "Failed to open netmodel query to get layer 3 interface");
    }

exit:
    return;
}

static amxs_status_t sync_param_action_cb_layer1(UNUSED const amxs_sync_entry_t* entry,
                                                 UNUSED amxs_sync_direction_t direction,
                                                 amxc_var_t* data,
                                                 UNUSED void* priv) {
    amxs_status_t status = amxs_status_unknown_error;
    amxd_trans_t trans;
    int ret = -1;
    const char* type = NULL;
    const char* layer1 = GETP_CHAR(data, "parameters.Layer1Interface");
    const char* path = GET_CHAR(data, "path");

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(layer1, exit, ERROR, "Layer1Interface information is missing");
    when_str_empty_trace(path, exit, ERROR, "Path information is missing");

    type = convert_path_to_interface_type(layer1);

    amxd_trans_select_pathf(&trans, "%s", path);
    amxd_trans_set_value(cstring_t, &trans, "Layer1Interface", layer1);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceType", type);

    ret = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(ret, exit, ERROR, "Failed to apply transaction: %d", ret);

    status = amxs_status_ok;

exit:
    amxd_trans_clean(&trans);
    return status;
}

/**
   @brief Synchronization callback for updating the InterfaceName parameter.

   Updates the "InterfaceName" attribute of a host entry in the data model
   and manages associated netmodel queries for bridgeport and Layer3 interface
   resolution. If the interface name is empty, the "Layer3Interface" attribute
   is cleared. Otherwise, a query is opened to determine the non-VLAN bridgeport.

   @param entry      Unused synchronization entry.
   @param direction  Unused synchronization direction.
   @param data       Variant containing the path and parameters (InterfaceName).
   @param priv       Unused user-provided context.

   @return amxs_status_ok on success, or an error status on failure.
 */
static amxs_status_t sync_param_action_cb_ifacename(UNUSED const amxs_sync_entry_t* entry,
                                                    UNUSED amxs_sync_direction_t direction,
                                                    amxc_var_t* data,
                                                    UNUSED void* priv) {
    amxs_status_t status = amxs_status_unknown_error;
    amxd_trans_t trans;
    int ret = -1;
    const char* iface_name = GETP_CHAR(data, "parameters.InterfaceName");
    bool iface_empty = iface_name == NULL || *iface_name == '\0';
    const char* path = GET_CHAR(data, "path");
    hosts_sync_info_t* info = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_str_empty_trace(path, exit, ERROR, "Path information is missing");

    amxd_trans_select_pathf(&trans, "%s", path);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceName", iface_name);

    info = hosts_get_sync_info(path, true);
    when_null_trace(info, exit, ERROR, "Failed to get sync info for path %s", path);
    if(info->query_bp != NULL) {
        netmodel_closeQuery(info->query_bp);
        info->query_bp = NULL;
    }
    if(info->query_l3 != NULL) {
        netmodel_closeQuery(info->query_l3);
        info->query_l3 = NULL;
    }
    if(iface_empty) {
        amxd_trans_set_value(cstring_t, &trans, "Layer3Interface", "");
    }

    ret = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(ret, exit, ERROR, "Failed to apply transaction: %d", ret);

    if(!iface_empty) {
        info->query_bp = netmodel_openQuery_luckyIntf(iface_name, "hosts", "bridgeport and not vlan",
                                                      netmodel_traverse_up, nm_bridgeport_cb, info);
        when_null_trace(info->query_bp, exit, ERROR, "Failed to open netmodel query to get the non-vlan bridgeport interface");
    }

    status = amxs_status_ok;

exit:
    amxd_trans_clean(&trans);
    return status;
}


static amxs_status_t sync_param_action_cb_dhcpclient (UNUSED const amxs_sync_entry_t* entry, UNUSED amxs_sync_direction_t direction, amxc_var_t* data, UNUSED void* priv) {
    amxs_status_t status = amxs_status_unknown_error;
    int rv = 0;
    amxc_var_t dhcpclients;
    amxc_var_t device;
    amxc_string_t csv_dhcpclients;
    const cstring_t dhcpclient = NULL;
    const cstring_t dhcpv6client = NULL;
    amxd_trans_t trans;

    const cstring_t hostpath = GET_CHAR(data, "path");
    const cstring_t devicepath = GET_CHAR(data, "opposite_path");
    amxc_var_t* params = amxc_var_get_first(GET_ARG(data, "parameters"));

    amxc_string_init(&csv_dhcpclients, 0);
    amxc_var_init(&dhcpclients);
    amxc_var_init(&device);
    amxd_trans_init(&trans);
    when_null(hostpath, exit);
    when_null(devicepath, exit);
    when_null(params, exit);

    amxc_var_set_type(&dhcpclients, AMXC_VAR_ID_LIST);

    amxb_get(hosts_gmap_handles.ctx, devicepath, 0, &device, 1);

    dhcpclient = GETP_CHAR(&device, "0.0.DHCPv4Client");
    dhcpv6client = GETP_CHAR(&device, "0.0.DHCPv6Client");

    if(!str_empty(dhcpclient)) {
        amxc_var_add(cstring_t, &dhcpclients, dhcpclient);
    }
    if(!str_empty(dhcpv6client)) {
        amxc_var_add(cstring_t, &dhcpclients, dhcpv6client);
    }

    rv = amxc_string_csv_join_var(&csv_dhcpclients, &dhcpclients);
    when_failed_trace(rv, exit, ERROR, "Problem amxc_string_csv_join_var - %i", rv);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "%s", hostpath);

    amxd_trans_set_value(csv_string_t, &trans, amxc_var_key(params), amxc_string_get(&csv_dhcpclients, 0));

    rv = amxd_trans_apply(&trans, hosts_gmap_handles.hosts_dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction - %i", rv);
    status = amxs_status_ok;

exit:
    amxd_trans_clean(&trans);
    amxc_string_clean(&csv_dhcpclients);
    amxc_var_clean(&dhcpclients);
    amxc_var_clean(&device);
    return status;
}

static amxs_status_t sync_param_trans_cb(const amxs_sync_entry_t* entry,
                                         amxs_sync_direction_t direction,
                                         const amxc_var_t* input,
                                         amxc_var_t* output,
                                         UNUSED void* priv) {
    amxs_status_t status = amxs_sync_param_copy_trans_cb(entry, direction, input, output, priv);
    const char* path = GET_CHAR(input, "path");
    amxc_var_add_key(cstring_t, output, "opposite_path", path);

    return status;
}

static void hosts_set_sync_parameters(amxs_sync_ctx_t* ctx) {
    amxc_string_t protected;
    amxs_sync_object_t* obj = NULL;
    const char* prefix = GET_CHAR(amxo_parser_get_config(hosts_manager_get_parser(), "global_vendor_prefix_"), NULL);

    amxc_string_init(&protected, 0);
    amxc_string_setf(&protected, "%sProtected", prefix);

    amxs_sync_ctx_add_new_param(ctx, "Name", "HostName", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb, NULL);
    amxs_sync_ctx_add_new_param(ctx, "Active", "Active", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb_active, NULL);
    amxs_sync_ctx_add_new_param(ctx, "Layer1Interface", "Layer1Interface", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb_layer1, NULL);
    amxs_sync_ctx_add_new_param(ctx, "InterfaceName", "InterfaceName", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb_ifacename, NULL);

    amxs_sync_ctx_add_new_param(ctx, "DHCPv4Client", "DHCPClient", AMXS_SYNC_DEFAULT, sync_param_trans_cb, sync_param_action_cb_dhcpclient, NULL);
    amxs_sync_ctx_add_new_param(ctx, "DHCPv6Client", "DHCPClient", AMXS_SYNC_DEFAULT, sync_param_trans_cb, sync_param_action_cb_dhcpclient, NULL);

    amxs_sync_ctx_add_new_param(ctx, "Tags", amxc_string_get(&protected, 0), AMXS_SYNC_DEFAULT,
                                amxs_sync_param_copy_trans_cb, sync_param_action_cb_protected, NULL);

    amxs_sync_object_new_copy(&obj, "IPv4Address.", "IPv4Address.", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Address", "IPAddress", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Scope", "Scope", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Status", "Status", AMXS_SYNC_DEFAULT);
    amxs_sync_ctx_add_object(ctx, obj);

    amxs_sync_object_new_copy(&obj, "IPv6Address.", "IPv6Address.", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Address", "IPAddress", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Scope", "Scope", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_copy_param(obj, "Status", "Status", AMXS_SYNC_DEFAULT);
    amxs_sync_ctx_add_object(ctx, obj);

    amxs_sync_object_new_copy(&obj, "SSWSta.", ".", AMXS_SYNC_DEFAULT);
    amxs_sync_object_add_new_param(obj, "AssociatedDevice", "AssociatedDevice", AMXS_SYNC_DEFAULT, amxs_sync_param_copy_trans_cb, sync_param_action_cb, NULL);
    amxs_sync_ctx_add_object(ctx, obj);

    amxc_string_clean(&protected);
}

/*                      *** TEMPORARY WORKAROUND ***
 ****************************
    START A TIMER TO TRY TO OPEN A GMAP QUERY.
    IT CAN HAPPEN THAT DURING BOOT GMAP-SERVER IS NOT VERY RESPONSIVE

    THIS FUNCTION WILL TRY TO OPEN A GMAP QUERY
    WHEN IT FAILS THE TIMER IS RESTARTED
    THE TIMEOUT WILL BE DOUBLED AS LONG AS IT IS BELOW 20 SECONDS

    A GOOD/BETTER SOLUTION WOULD BE THAT LIBGAMP-CLIENT PROVIDES AN ASYNCHRONOUS
    IMPLEMENTATION OF THE OPEN QUERY FUNCTION.

 */
static void hosts_try_open_gmap_query(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    static int timeout = 1000;
    when_not_null(query, exit);

    gmap_query_open_ext_2(&query, HOSTS_QUERY_EXPRESSION, "Hosts",
                          GMAP_QUERY_IGNORE_DEVICE_UPDATED, hosts_query_cb, NULL);
    if(query == NULL) {
        if(timeout < 20000) {
            timeout = timeout * 2;
        }
        amxp_timer_start(retry_timer, timeout);
    }

exit:
    return;
}

int hosts_sync_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    int rv = -1;
    hosts_gmap_handles.ctx = NULL;

    hosts_gmap_handles.hosts_dm = dm;
    hosts_gmap_handles.parser = parser;
    hosts_gmap_handles.hosts_host = amxd_object_get_child(amxd_dm_get_object(dm, "Hosts"), "Host");

    rv = amxc_llist_init(&sync_info);
    when_failed_trace(rv, exit, ERROR, "Problem Initializing Hosts sync_info - %i", rv);

    hosts_sync_initialize_inactive_hosts_list();

    rv = -1;
    when_false_trace(netmodel_initialize(), exit, ERROR, "Failed to initialize libnetmodel");

    hosts_gmap_handles.ctx = amxb_be_who_has("Devices.Device");
    when_null_trace(hosts_gmap_handles.ctx, exit, ERROR, "gMap data model not found 'Devices.Device' - is gmap-server running?");

    gmap_client_init(hosts_gmap_handles.ctx);
    gmap_query_open_ext_2(&query, HOSTS_QUERY_EXPRESSION, "Hosts", GMAP_QUERY_IGNORE_DEVICE_UPDATED, hosts_query_cb, NULL);
    /* *** TEMPORARY WORKAROUND - SEE FUNCTION ABOVE THIS ONE *** */
    if(query == NULL) {
        amxp_timer_new(&retry_timer, hosts_try_open_gmap_query, NULL);
        amxp_timer_start(retry_timer, 10000);
    }

    rv = 0;

exit:
    return rv;
}

static void cleanup_inactive_host(amxc_llist_it_t* it) {
    inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
    when_null(it, exit);
    free_inactive_host_info(info);
exit:
    return;
}

int hosts_sync_cleanup(void) {
    gmap_query_close(query);
    amxc_llist_clean(&sync_info, delete_item);
    amxp_timer_delete(&retry_timer);
    netmodel_cleanup();
    amxc_llist_clean(&inactive_hosts, cleanup_inactive_host);
    return 0;
}

void hosts_query_cb(UNUSED gmap_query_t* lquery,
                    const char* key,
                    amxc_var_t* device,
                    gmap_query_action_t action) {
    int rv = 0;
    amxc_string_t aliaspath;

    amxc_string_init(&aliaspath, 0);

    when_str_empty_trace(key, exit, ERROR, "NULL or empty device key");

    amxc_string_append(&aliaspath, "Devices.Device.", 15);
    amxc_string_append(&aliaspath, key, strlen(key));
    amxc_string_append(&aliaspath, ".", 1);

    if(action == gmap_query_expression_start_matching) {
        rv = hosts_setup_object_sync(amxc_string_get(&aliaspath, 0), device);
        when_failed_trace(rv, exit, ERROR, "Problem Setting up object sync  - %i", rv);
    } else if(action == gmap_query_expression_stop_matching) {
        rv = hosts_destroy_object_sync(amxc_string_get(&aliaspath, 0));
        when_failed_trace(rv, exit, ERROR, "Problem removing object sync  - %i", rv);
    }
exit:
    amxc_string_clean(&aliaspath);
    return;
}

static int hosts_setup_object_sync(const char* aliaspath,
                                   const amxc_var_t* device) {
    int rv = -1;
    int host_index = 0;
    const int index = GET_INT32(device, "Index");
    const char* phys_address = GET_CHAR(device, "PhysAddress");
    amxc_string_t indexpath;
    amxc_string_t hostindexpath;
    amxs_sync_ctx_t* ctx = NULL;
    hosts_sync_info_t* info = NULL;

    amxc_string_init(&indexpath, 0);
    amxc_string_init(&hostindexpath, 0);

    when_true_trace(index <= 0, exit, ERROR, "No or zero object index: %i", index);
    when_str_empty_trace(phys_address, exit, ERROR, "NULL or empty string");

    info = (hosts_sync_info_t*) calloc(1, sizeof(hosts_sync_info_t));
    when_null_trace(info, exit, ERROR, "Calloc hosts_sync_info_t failed");

    amxc_htable_init(&info->alts, 0);

    amxc_string_setf(&indexpath, "Devices.Device.%i.", index);
    host_index = hosts_create_object(phys_address,
                                     aliaspath);
    when_false_trace((host_index != 0), clean, ERROR, "Problem hosts_create_object - Host Index: %i", host_index);

    amxc_string_setf(&hostindexpath, "Hosts.Host.%i.", host_index);

    info->device_path = strdup(aliaspath);
    when_str_empty_trace(info->device_path, clean, ERROR, "Out of memory");
    info->host_path = amxc_string_take_buffer(&hostindexpath);
    info->host_index = host_index;
    rv = amxc_llist_append(&sync_info, &info->it);
    when_failed_trace(rv, clean, ERROR, "Problem amxc_llist_append - %i", rv);

    amxs_sync_ctx_new(&ctx, amxc_string_get(&indexpath, 0), info->host_path, AMXS_SYNC_ONLY_A_TO_B);
    amxs_sync_ctx_set_local_dm(ctx, NULL, hosts_gmap_handles.hosts_dm);
    when_null_trace(ctx, clean, ERROR, "Problem creating Sync");
    hosts_set_sync_parameters(ctx);
    rv = amxs_sync_ctx_start_sync(ctx);
    when_failed_trace(rv, clean, ERROR, "Problem starting Hosts sync");
    info->ctx = ctx;

    s_subscribe_alt(info);
    s_init_fetch_alt(info);

    SAH_TRACEZ_INFO(ME, "Found new Host");
    goto exit;

clean:
    amxs_sync_ctx_delete(&ctx);
    if(info != NULL) {
        free(info->device_path);
        free(info->host_path);
        amxc_htable_clean(&info->alts, s_clean_alt_sync_it);
        amxc_llist_it_take(&info->it);
        free(info);
    }
exit:
    amxc_string_clean(&indexpath);
    amxc_string_clean(&hostindexpath);
    return rv;
}

static int hosts_destroy_object_sync(const cstring_t path) {
    hosts_sync_info_t* info = hosts_get_sync_info(path, false);
    when_null(info, exit);

    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* inactive = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        if((inactive->host != NULL) && ((int) inactive->host->index == info->host_index)) {
            free_inactive_host_info(inactive);
            break;
        }
    }

    amxc_llist_it_clean(&info->it, delete_item);
    return 0;
exit:
    return -1;
}

/**
   @brief Retrieves and normalizes the physical (MAC) address of a device from gMap.

   Builds the path to the "PhysAddress" parameter of the given device reference,
   queries gMap for its value, and ensures the MAC address is converted to
   uppercase before storing it back into the provided result variant.

   @param device_reference  Path to the device in the gMap data model.
   @param ret               Output variant to store the query result.

   @return 0 on success, or -1 on failure.
 */
static int hosts_sync_import_find_gmap_physaddr(const char* device_reference,
                                                amxc_var_t* ret) {
    int status = -1;
    amxc_string_t path;
    amxc_var_t* mac = NULL;
    amxc_string_t mac_add;

    amxc_string_init(&mac_add, 0);
    amxc_string_init(&path, 0);
    amxc_string_set(&path, device_reference);
    amxc_string_append(&path, "PhysAddress", 11);

    status = amxb_get(hosts_gmap_handles.ctx, amxc_string_get(&path, 0), 0, ret, gmap_get_timeout());

    mac = GET_ARG(amxc_var_get_first(amxc_var_get_first(ret)), "PhysAddress");
    if(mac != NULL) {
        amxc_string_set(&mac_add, GET_CHAR(mac, NULL));
        status = amxc_string_to_upper(&mac_add);
        when_failed_trace(status, exit, ERROR, "Failed to convert mac: [%s] to uppercase", GET_CHAR(mac, NULL));
        amxc_var_push(cstring_t, mac, amxc_string_take_buffer(&mac_add));
    }

exit:
    amxc_string_clean(&path);
    amxc_string_clean(&mac_add);
    return status;
}

static amxd_object_t* hosts_sync_import_find_known_host(const char* keyname,
                                                        const char* keyvalue) {
    amxd_object_t* obj = NULL;

    amxd_object_for_each(instance, it, hosts_gmap_handles.hosts_host) {
        amxd_object_t* entry = amxc_container_of(it, amxd_object_t, it);
        const char* val = amxc_var_constcast(cstring_t, amxd_object_get_param_value(entry, keyname));
        if((val != NULL) && (strcmp(val, keyvalue) == 0)) {
            obj = entry;
            break;
        }
    }

    return obj;
}

static amxd_object_t* hosts_sync_import_new_host(const char* physaddr) {
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_t* obj = NULL;
    amxc_var_t values;

    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "PhysAddress", physaddr);
    status = amxd_object_add_instance(&obj, hosts_gmap_handles.hosts_host, NULL, 0, &values);
    if(status != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to create Hosts.Host. instance for newly imported device");
        obj = NULL;
    } else {
        amxd_object_emit_add_inst(obj);
    }

    amxc_var_clean(&values);
    return obj;
}

static int hosts_sync_import_host(amxc_var_t* container) {
    int status = -1;
    amxc_var_t* host = amxc_var_get_first(container);
    amxc_var_t* tmp = NULL;
    amxc_var_t* param = NULL;
    const char* device_reference = GET_CHAR(host, "DeviceReference");
    const char* physical_address = GET_CHAR(host, "PhysAddress");
    amxd_object_t* host_object = NULL;
    amxc_string_t mac;

    amxc_string_init(&mac, 0);

    if((physical_address != NULL) && (*physical_address != '\0')) {
        amxc_string_set(&mac, physical_address);
        when_failed_trace(amxc_string_to_upper(&mac), exit, ERROR, "Failed to convert physaddr to uppercase");
        physical_address = amxc_string_get(&mac, 0);
    }
    /* Prefer matching the physical address. Device references may change across
     * hard resets while devices that don't randomize their mac will keep matching.
     */
    if((physical_address != NULL) && (*physical_address != '\0')) {
        host_object = hosts_sync_import_find_known_host("PhysAddress", physical_address);
        if(host_object == NULL) {
            goto new_host;
        } else {
            goto old_host;
        }
    } else if((device_reference != NULL) && (*device_reference != '\0')) {
        /* Attempt some backwards-compatibility by matching the device reference. */
        host_object = hosts_sync_import_find_known_host("DeviceReference", device_reference);
        when_not_null(host_object, old_host);
        /* The host object doesn't exist (yet?). As a last effort to load in old
         * persistent data, try to fetch the physical address from gmap.
         */
        amxc_var_new(&tmp);
        when_null_trace(tmp, exit, ERROR, "Out of memory");
        status = hosts_sync_import_find_gmap_physaddr(device_reference, tmp);
        /* [{"Devices.Device.X." = {PhysAddress="00:11:22:33:44:55"}}] */
        physical_address = GET_CHAR(amxc_var_get_first(amxc_var_get_first(amxc_var_get_first(tmp))), NULL);
        if((status != 0) || (physical_address == NULL) || (*physical_address == '\0')) {
            /* Failed to find a good reference in gmap. Don't restore data of
             * which it cannot be proven it is still valid.
             * This relies in part on data being restored to gmap before it is
             * restored here.
             */
            SAH_TRACEZ_ERROR(ME, "Failed to import data: no known physical address "
                             "set for imported entry '%s' with reference '%s'",
                             amxc_var_key(host), device_reference);
            amxc_var_delete(&container);
            /* Set the status to success anyway. Failure to import this case does
             * not necessarily imply corrupted data or system failure. */
            status = 0;
            goto exit;
        }

        host_object = hosts_sync_import_find_known_host("PhysAddress", physical_address);
        if(host_object == NULL) {
            goto new_host;
        } else {
            goto old_host;
        }
    } else {
        /* Both the physical address and the device reference are unknown.
         * Remove the data with an error because there's no way to safely import
         * this data.
         */
        SAH_TRACEZ_ERROR(ME, "Failed to import data: no device reference or "
                         "physical address set for imported entry '%s'",
                         amxc_var_key(host));
        amxc_var_delete(&container);
        goto exit;
    }

new_host:
    /* There is no old host, but we know its address.
     * Create one for it first, discarding the device reference, then continue
     * restoring its data.
     */
    host_object = hosts_sync_import_new_host(physical_address);
    when_null(host_object, exit);

old_host:
    /* Patch the old host reference. It must point to the correct dm object and
     * the key properties must not be overwritten so they are removed from the
     * import data.
     */
    amxc_var_set_key(container,
                     amxd_object_get_name(host_object, AMXD_OBJECT_NAMED),
                     host,
                     AMXC_VAR_FLAG_DEFAULT);
    /* Invalidates physical_address and device_reference. */
    param = GET_ARG(host, "PhysAddress");
    amxc_var_delete(&param);
    param = GET_ARG(host, "DeviceReference");
    amxc_var_delete(&param);

    if(amxc_htable_is_empty(amxc_var_constcast(amxc_htable_t, host))) {
        amxc_var_delete(&container);
    }
    status = 0;

exit:
    amxc_var_delete(&tmp);
    amxc_string_clean(&mac);
    return status;
}

int hosts_sync_import(amxc_var_t* data) {
    amxc_var_t* hosts = GETP_ARG(data, "set.hgwconfig.Hosts.Host.");
    int status = 0;

    amxc_var_for_each(host, hosts) {
        status = hosts_sync_import_host(host);
        if(status != 0) {
            break;
        }
    }

    return status;
}

static void free_inactive_host_info(inactive_host_info_t* info) {
    if(info == NULL) {
        return;
    }
    amxc_llist_it_take(&info->it);
    free(info);
}

static void add_inactive_host_to_list(amxd_object_t* host) {
    inactive_host_info_t* info;

    info = calloc(1, sizeof(inactive_host_info_t));
    when_null_trace(info, exit, ERROR, "Out of memory");

    amxc_llist_it_init(&info->it);
    info->host = host;
    amxc_llist_append(&inactive_hosts, &info->it);

exit:
    return;
}

static void add_unique_inactive_host_to_list(amxd_object_t* host) {
    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        when_true(info->host == host, exit);
    }

    add_inactive_host_to_list(host);

exit:
    return;
}

static void hosts_sync_enforce_inactive_threshold(void) {
    int32_t threshold;
    amxd_object_t* hosts_obj = amxd_dm_get_object(hosts_gmap_handles.hosts_dm, "Hosts");
    when_null_trace(hosts_obj, exit, ERROR, "Hosts. object not found in DM");

    threshold = amxd_object_get_int32_t(hosts_obj, "CleanupHostsThreshold", NULL);
    hosts_sync_ensure_inactive_host_count(threshold);
exit:
    return;
}

static void remove_host_from_inactive_hosts(amxd_object_t* host) {
    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        if(info->host == host) {
            free_inactive_host_info(info);
            return;
        }
    }
}

static char* get_device_ref_from_path(const char* path) {
    char* cleaned_ref = NULL;
    const char* prefix = "Devices.Device.";
    size_t prefix_len = strlen(prefix);
    const char* ref_start = path;
    size_t ref_len;

    if(strncmp(path, prefix, prefix_len) == 0) {
        ref_start = path + prefix_len;
    }

    ref_len = strlen(ref_start);
    if((ref_len > 0) && (ref_start[ref_len - 1] == '.')) {
        ref_len--;
    }

    cleaned_ref = malloc(ref_len + 1);
    when_null_trace(cleaned_ref, exit, ERROR, "Out of memory")

    memcpy(cleaned_ref, ref_start, ref_len);
    cleaned_ref[ref_len] = '\0';

exit:
    return cleaned_ref;
}

static uint64_t get_inactive_duration(amxc_ts_t now, amxc_ts_t last_change) {
    int64_t now_epoch = now.sec - ((int64_t) now.offset * 60);
    int64_t last_change_epoch = last_change.sec - ((int64_t) last_change.offset * 60);
    uint64_t duration = (now_epoch > last_change_epoch) ? (now_epoch - last_change_epoch) : 0u;
    return duration;
}

static const amxc_ts_t* s_get_active_last_changed(amxd_object_t* host_obj) {
    const amxc_ts_t* ts = NULL;
    amxd_param_t* param = amxd_object_get_param_def(host_obj, "ActiveLastChange");
    when_null_trace(param, exit, ERROR, "BUG: can't find ActiveLastChange parameter");

    ts = amxc_var_constcast(amxc_ts_t, &param->value);

exit:
    return ts;
}

static void insert_sorted_inactive_host(amxc_llist_t* list, inactive_host_info_t* tmp_info) {
    amxc_ts_t now = {0};
    uint64_t host_inactive_duration;
    const amxc_ts_t* host_inactive_time = s_get_active_last_changed(tmp_info->host);

    amxc_ts_now(&now);
    host_inactive_duration = get_inactive_duration(now, *host_inactive_time);

    amxc_llist_for_each(it, list) {
        inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        const amxc_ts_t* inactive_time = s_get_active_last_changed(info->host);
        uint64_t inactive_duration = get_inactive_duration(now, *inactive_time);
        if(host_inactive_duration > inactive_duration) {
            amxc_llist_it_insert_before(it, &tmp_info->it);
            return;
        }
    }
    amxc_llist_append(list, &tmp_info->it);
}

static void update_inactive_hosts_list(int* inactive_count) {
    if(amxc_llist_is_empty(&inactive_hosts)) {
        return;
    }

    amxc_llist_t sorted_list;
    amxc_llist_init(&sorted_list);
    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        insert_sorted_inactive_host(&sorted_list, info);
        (*inactive_count)++;
    }

    amxc_llist_move(&inactive_hosts, &sorted_list);
    amxc_llist_clean(&sorted_list, cleanup_inactive_host);
}

static void hosts_sync_initialize_inactive_hosts_list(void) {
    amxc_llist_init(&inactive_hosts);

    amxd_object_for_each(instance, it, hosts_gmap_handles.hosts_host) {
        amxd_object_t* host = amxc_llist_it_get_data(it, amxd_object_t, it);
        if(amxd_object_get_value(bool, host, "Active", NULL)) {
            continue;
        }
        add_inactive_host_to_list(host);
    }
}

/** Removes the given inactive entry from gmap or hosts. */
static void s_hosts_kill_inactive_entry(inactive_host_info_t* info) {
    int status;
    char* host_path = NULL;
    char* dev_ref = NULL;
    char* dev_key = NULL;
    hosts_sync_info_t* sync;
    when_null_trace(info->host, exit, ERROR, "BUG: inactive entry with NULL host reference");

    host_path = amxd_object_get_path(info->host, AMXD_OBJECT_INDEXED);
    dev_ref = amxd_object_get_value(cstring_t, info->host, "DeviceReference", NULL);
    when_str_empty_trace(dev_ref, no_dev_ref, WARNING,
                         "Null or empty DeviceReference! Removing unreferenced host %s", host_path);

    dev_key = get_device_ref_from_path(dev_ref);
    when_str_empty_trace(dev_key, no_dev_ref, ERROR,
                         "Failed to extract device reference from path: %s", dev_ref);
    status = gmap_devices_destroyDevice(dev_key);
    when_failed_trace(status, no_dev_ref, ERROR,
                      "Failed to remove Device instance %s: %d, deleting Host instance: %s",
                      dev_ref, status, host_path);
    goto exit;

no_dev_ref:
    sync = hosts_get_sync_info_for_host(info->host);
    if(sync != NULL) {
        amxc_llist_it_clean(&sync->it, delete_item);
    } else {
        hosts_delete_object(amxd_object_get_index(info->host));
    }

    /* fallthrough */
exit:
    free(dev_key);
    free(dev_ref);
    free(host_path);
    return;
}

int hosts_sync_remove_inactive_hosts(uint32_t min_inactive_sec,
                                     uint32_t* out_nbr_removed) {
    int status = -1;
    amxc_ts_t now = {0, 0, 0};

    if(out_nbr_removed != NULL) {
        *out_nbr_removed = 0;
    }

    if(is_ntp_time_synchronized()) {
        amxc_ts_now(&now);
    } else if(min_inactive_sec != 0) {
        SAH_TRACEZ_ERROR(ME, "Cannot remove inactive devices: Time not synchronized and minimumInactiveTime != 0");
        goto exit;
    }

    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        char* host_path = NULL;
        char* dev_ref = NULL;
        const amxc_ts_t* inactive_time = NULL;
        uint64_t duration;

        if(info->host == NULL) {
            SAH_TRACEZ_ERROR(ME, "BUG: inactive entry with NULL host reference");
            free_inactive_host_info(info);
            continue;
        }

        host_path = amxd_object_get_path(info->host, AMXD_OBJECT_INDEXED);
        dev_ref = amxd_object_get_value(cstring_t, info->host, "DeviceReference", NULL);
        when_str_empty_trace(dev_ref, kill_item, WARNING,
                             "Null or empty DeviceReference! Removing unreferenced host %s", host_path);

        inactive_time = s_get_active_last_changed(info->host);
        duration = get_inactive_duration(now, *inactive_time);
        when_true(duration < min_inactive_sec, next_item);

kill_item:
        amxc_llist_it_take(&info->it);
        s_hosts_kill_inactive_entry(info);
        free_inactive_host_info(info);
        if(out_nbr_removed != NULL) {
            (*out_nbr_removed)++;
        }

next_item:
        free(host_path);
        free(dev_ref);
    }

    status = 0;
exit:
    return status;
}

/** @brief Removes the oldest inactive hosts until there are at most @p max_inactive_hosts left. */
void hosts_sync_ensure_inactive_host_count(int max_inactive_hosts) {
    int to_remove;
    int inactive_count = 0;

    when_true(max_inactive_hosts < 0, exit);
    when_true(amxc_llist_is_empty(&inactive_hosts), exit);

    when_false_trace(is_ntp_time_synchronized(), exit, ERROR, "Cannot remove inactive devices: Time not synchronized");

    update_inactive_hosts_list(&inactive_count);
    to_remove = inactive_count - max_inactive_hosts;
    when_true(to_remove <= 0, exit);

    amxc_llist_for_each(it, &inactive_hosts) {
        inactive_host_info_t* info;
        if(to_remove <= 0) {
            break;
        }

        info = amxc_llist_it_get_data(it, inactive_host_info_t, it);
        amxc_llist_it_take(&info->it);
        s_hosts_kill_inactive_entry(info);
        free_inactive_host_info(info);
        to_remove--;
    }

exit:
    return;
}
