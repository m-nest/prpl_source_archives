/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "sfpmgr_utils.h"

/* Own headers */
#include "sfpmgr_trace.h"

/**
 * @brief Sets a string parameter in the transaction.
 *
 * @param[in] transaction Pointer to the transaction object.
 * @param[in] paramName Name of the parameter to set.
 * @param[in] paramValue Value of the parameter to set.
 *
 * @return `amxd_status_ok` on success, or an error code on failure.
 */
int setStringParam(amxd_trans_t* transaction, const char* paramName, const char* paramValue) {
    int retval = amxd_status_ok;

    if((transaction == NULL) || (paramName == NULL) || (paramValue == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Transaction , paramName or paramValue is NULL");
        retval = amxd_status_unknown_error;
        goto exit;
    }

    amxd_trans_set_value(cstring_t, transaction, paramName, paramValue);
    SAH_TRACEZ_INFO(ME, "Successfully set parameter: %s", paramName);

exit:
    return retval;
}

/**
 * @brief Sets a 32-bit unsigned integer parameter in the transaction.
 *
 * @param[in] transaction Pointer to the transaction object.
 * @param[in] paramName Name of the parameter to set.
 * @param[in] paramValue 32-bit unsigned integer value to set.
 *
 * @return `amxd_status_ok` on success, or an error code on failure.
 */
int setUint32Param(amxd_trans_t* transaction, const char* paramName, uint32_t paramValue) {
    int retval = amxd_status_ok;
    amxc_var_t uint32_val;
    amxc_var_init(&uint32_val);
    amxc_var_set_type(&uint32_val, AMXC_VAR_ID_UINT32);

    if((transaction == NULL) || (paramName == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Invalid transaction or parameter name");
        retval = amxd_status_unknown_error;
        goto exit;
    }

    if(amxc_var_set_uint32_t(&uint32_val, paramValue) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to set paramValue");
        goto exit;
    }
    amxd_trans_set_param(transaction, paramName, &uint32_val);
    SAH_TRACEZ_INFO(ME, "Successfully set parameter: %s", paramName);

exit:
    amxc_var_clean(&uint32_val);
    return retval;
}

/**
 * @brief Sets a 32-bit signed integer parameter in the transaction.
 *
 * @param[in] transaction Pointer to the transaction object.
 * @param[in] paramName Name of the parameter to set.
 * @param[in] paramValue 32-bit signed integer value to set.
 *
 * @return `amxd_status_ok` on success, or an error code on failure.
 */
int setint32Param(amxd_trans_t* transaction, const char* paramName, int32_t paramValue) {
    int retval = amxd_status_ok;
    amxc_var_t int32_val;
    amxc_var_init(&int32_val);
    amxc_var_set_type(&int32_val, AMXC_VAR_ID_INT32);

    if((transaction == NULL) || (paramName == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Error: Invalid transaction or parameter name");
        retval = amxd_status_unknown_error;
        goto exit;
    }

    if(amxc_var_set_int32_t(&int32_val, paramValue) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to set paramValue");
        goto exit;
    }
    amxd_trans_set_param(transaction, paramName, &int32_val);
    SAH_TRACEZ_INFO(ME, "Successfully set parameter: %s", paramName);
exit:
    amxc_var_clean(&int32_val);
    return retval;
}

/**
 * @brief Sets a 16-bit unsigned integer parameter in the transaction.
 *
 * @param[in] transaction Pointer to the transaction object.
 * @param[in] paramName Name of the parameter to set.
 * @param[in] paramValue 16-bit unsigned integer value to set.
 *
 * @return `amxd_status_ok` on success, or an error code on failure.
 */
int setUint16Param(amxd_trans_t* transaction, const char* paramName, uint16_t paramValue) {
    int retval = amxd_status_ok;
    amxc_var_t uint16_val;
    amxc_var_init(&uint16_val);
    amxc_var_set_type(&uint16_val, AMXC_VAR_ID_UINT16);

    if((transaction == NULL) || (paramName == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Invalid transaction or parameter name");
        retval = amxd_status_unknown_error;
        goto exit;
    }

    if(amxc_var_set_uint16_t(&uint16_val, paramValue) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to set paramValue");
        goto exit;
    }
    amxd_trans_set_param(transaction, paramName, &uint16_val);
    SAH_TRACEZ_INFO(ME, "Successfully set uint16 parameter: %s %x", paramName, paramValue);

exit:
    amxc_var_clean(&uint16_val);
    return retval;
}

/**
 * @brief Sets a boolean parameter in the transaction.
 *
 * @param[in] transaction Pointer to the transaction object.
 * @param[in] paramName Name of the parameter to set.
 * @param[in] paramValue Boolean value (true or false) to set.
 *
 * @return `amxd_status_ok` on success, or an error code on failure.
 */
int setBoolParam(amxd_trans_t* transaction, const char* paramName, bool paramValue) {
    int retval = amxd_status_ok;
    amxc_var_t bool_val;
    amxc_var_init(&bool_val);
    amxc_var_set_type(&bool_val, AMXC_VAR_ID_BOOL);

    if((transaction == NULL) || (paramName == NULL)) {
        SAH_TRACEZ_ERROR(ME, "Invalid transaction or parameter name");
        retval = amxd_status_unknown_error;
        goto exit;
    }

    if(amxc_var_set_bool(&bool_val, paramValue) != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to set paramValue");
        goto exit;
    }
    amxd_trans_set_param(transaction, paramName, &bool_val);
    SAH_TRACEZ_INFO(ME, "Successfully set bool parameter: %s %x", paramName, paramValue);

exit:
    amxc_var_clean(&bool_val);
    return retval;
}

