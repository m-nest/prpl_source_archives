/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2026 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#if !defined(__CTHULHU_SYSLOG_H__)
#define __CTHULHU_SYSLOG_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_function.h>


#define PRIVATE __attribute__ ((visibility("hidden")))
#define UNUSED __attribute__((unused))

/**
 * @brief Module initialization function
 *
 * This function is called when the module is loaded.
 */
AMXM_CONSTRUCTOR module_init(void);

/**
 * @brief Module cleanup function
 *
 * This function is called when the module is unloaded.
 */
AMXM_DESTRUCTOR module_exit(void);

/**
 * @brief Initialize the syslog functionality
 *
 * @param function_name Name of calling function
 * @param args Input arguments for the initialization
 * @param ret Return value of the function
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_init(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Cleanup syslog resources
 *
 * @param function_name Name of calling function
 * @param args Input arguments for the initialization
 * @param ret Return value of the function
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_cleanup(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handler for ODL loaded event
 *
 * A connection to the syslog component will be setup
 *
 * @param function_name Name of calling function
 * @param args Input arguments for the initialization
 * @param ret Return value of the function
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_odl_loaded(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handler for container creation
 *
 * An Source, Action and Template will be created in syslog
 *
 * @param function_name Name of the function being called
 * @param args Container creation arguments
 * @param ret Return value container
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_ctr_create(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handler called before container start
 *
 * The socket will be activated and added to the container
 *
 * @param function_name Name of the function being called
 * @param args Container pre-start arguments
 * @param ret Return value container
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_ctr_prestart(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handler called after container stop
 *
 * the socket will be deactivated
 *
 * @param function_name Name of the function being called
 * @param args Container post-stop arguments
 * @param ret Return value container
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_ctr_poststop(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
 * @brief Handler called before container removal
 *
 * @param function_name Name of the function being called
 * @param args Container pre-remove arguments
 * @param ret Return value container
 *
 * The Source, Action and Template will be removed from syslog
 *
 * @return int Returns 0 on success, non-zero on failure
 */
int cthulhu_syslog_ctr_preremove(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __CTHULHU_SYSLOG_H__
