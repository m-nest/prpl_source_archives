/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <amxc/amxc_macros.h>
#include <dmengine/dm_eng_pn.h>

static void pn_delete_cb(UNUSED const char* key, amxc_htable_it_t* hit) {
    dm_eng_pn_t* pn = amxc_htable_it_get_data(hit, dm_eng_pn_t, hit);
    dm_eng_pn_destroy(pn);
}

void dm_eng_pn_list_init(dm_eng_pn_list_t* list) {
    amxc_htable_init(list, 0);
}

void dm_eng_pn_list_clean(dm_eng_pn_list_t* list) {
    amxc_htable_clean(list, pn_delete_cb);
}

dm_eng_pn_t* dm_eng_pn_new(const char* name, bool writable) {
    dm_eng_pn_t* pn = NULL;
    when_str_empty(name, stop);
    pn = (dm_eng_pn_t*) calloc(1, sizeof(dm_eng_pn_t));
    when_null(pn, stop);
    pn->name = strdup(name);
    pn->writable = writable;
stop:
    return pn;
}

void dm_eng_pn_destroy(dm_eng_pn_t* pn) {
    when_null(pn, stop);
    free(pn->name);
    free(pn);
stop:
    return;
}

int dm_eng_pn_list_add(dm_eng_pn_list_t* list, dm_eng_pn_t* pn) {
    int retval = -1;
    when_null(pn, stop);
    retval = amxc_htable_insert(list, pn->name, &pn->hit);
stop:
    return retval;
}

dm_eng_pn_t* dm_eng_pn_list_get(dm_eng_pn_list_t* list, const char* name) {
    dm_eng_pn_t* pn = NULL;
    when_str_empty(name, stop);
    amxc_htable_it_t* hit = amxc_htable_get(list, name);
    when_null(hit, stop);
    pn = amxc_container_of(hit, dm_eng_pn_t, hit);
stop:
    return pn;
}
