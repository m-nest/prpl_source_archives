/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2026 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file service.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief Header file describes basic structures and enums for
 *        servises start/stop logic.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright Copyright (c) 2026 Inango
 *
 */

#ifndef _SERVICE_H__
#define _SERVICE_H__

#if !(defined(INIT_SYSTEM_PROCD) || defined(INIT_SYSTEM_SYSTEMD))
#error please define INIT_SYSTEM_* macro
#endif

#include <stdint.h>

/**
 * @brief Enum describes application types.
 *
 */
typedef enum {
    SERVICE_KIND_INVALID = 0, /*!< had to "reserve" NULL/zero for non-waiting calls for convinience */
    SERVICE_KIND_SENSING,     /*!< WiFi-Sensing application, in runtime process called wifi-sensing*/
    SERVICE_KIND_PWHM,        /*!< pWHM application, in runtime process called wld */
    SERVICE_KIND_PRPLMESH,    /*!< prplMesh application, consists of controller, agent, fronthaul processes*/
/* must be last */
    SERVICE_KIND_MAX,         /*!< Number of services described by enum */
} ServiceKind;

/**
 * @brief Enum describes service action
 *
 */
typedef enum {
    SERVICE_ACTION_STOP,    /*!< Shutdown action */
    SERVICE_ACTION_START,   /*!< Startup action */
    SERVICE_ACTION_RESTART, /*!< Restart action, for prplMesh mode change */
} ServiceAction;

/**
 * @brief Enum describes possible services status that
 *        will be shown in DataModel as Status parameter.
 *
 */
typedef enum {
    SERVICE_STATUS_ERROR = -1, /*!< Indicates errors, not used in Datamodel */
    SERVICE_STATUS_IDLE,       /*!< Service down or stopped */
    SERVICE_STATUS_STARTING,   /*!< Service starting up, time-consuming action */
    SERVICE_STATUS_RUNNING,    /*!< Service successfully started */
    SERVICE_STATUS_STOPPING,   /*!< Service stopping, time-consuming action*/
} ServiceStatus;

/**
 * @brief Enum describes possible services fault code that
 *        will be shown in DataModel as FaultCode parameter.
 *
 */
typedef enum {
    SERVICE_FAULT_ON_START = -2, /*!< Issue occured during application start up */
    SERVICE_FAULT_ON_STOP = -1,  /*!< Issue occured during application shutdown */
    SERVICE_NO_FAULT = 0,        /*!< Application started without issues */
} ServiceFaultCode;

/**
 * @brief Result delivered to service control callbacks.
 *
 */
typedef struct {
    ServiceKind service;  /*!< Service name, like prplMesh, pWHM or WiFi-Sensing */
    int64_t ret_code;     /*!< Exit code of service control action */
} ServiceControlResult;

typedef void service_control_cb_t(ServiceControlResult result);
int process_monitor_service_control(ServiceKind service, ServiceAction action, service_control_cb_t callback);
ServiceStatus process_monitor_service_status(ServiceKind service);

#endif
