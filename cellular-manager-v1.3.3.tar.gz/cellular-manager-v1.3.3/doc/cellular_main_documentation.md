﻿# **Cellular Management**
[TODO](#cellularmanagement-todo)

[Introduction](#cellularmanagement-introduction)

[Use cases](#cellularmanagement-usecases) 

[Use Case Definition](#cellularmanagement-usecasedefinition)

[References](#cellularmanagement-references)

[Cellular hardware types](#cellularmanagement-cellularhardwaretypes) 

[SoC with built-in modem running the main OS](#cellularmanagement-socwithbuilt-inmodemrunningthemainos)

[In-CPE PCIe modem connected to SoC running main OS](#cellularmanagement-in-cpepciemodemconnectedtosocrunningmainos)

[In-CPE USB modem connected to SoC running main OS](#cellularmanagement-in-cpeusbmodemconnectedtosocrunningmainos)

[In-CPE xGMII modem connected to SoC running main OS](#cellularmanagement-in-cpexgmiimodemconnectedtosocrunningmainos)

[Externally connected USB modem; various variants: control: serial (CDC-ACM) with AT command set / QMI / MBIM / other proprietary protocol. Data: PPP over serial / Linux network interface (various variants, CDC-NCM/ECM and more)](#cellularmanagement-externallyconnectedusbmodem;variousvariants:control:serial\(cdc-acm\)withatcommandset/qmi/mbim/otherproprietaryprotocol.data:pppoverserial/linuxnetworkinterface\(variousvariants,cdc-ncm/ecmandmore\))

[Tethering to USB-connected smartphone](#cellularmanagement-tetheringtousb-connectedsmartphone)

[Network (Ethernet/WLAN)-connected ODU (outdoor unit) containing modem with proprietary protocol.](#cellularmanagement-network\(ethernet/wlan\)-connectedodu\(outdoorunit\)containingmodemwithproprietaryprotocol.)

[Access network connectivity](#cellularmanagement-accessnetworkconnectivity)

[Wired access network protocol](#cellularmanagement-wiredaccessnetworkprotocol)

[Authentication](#cellularmanagement-authentication)

[Network management co-existence](#cellularmanagement-networkmanagementco-existence)

[Requirements](#cellularmanagement-requirements) 

[Introduction and High-Level Description](#cellularmanagement-introductionandhigh-leveldescription)

[Implementation](#cellularmanagement-implementation) 

[Functional diagram](#cellularmanagement-functionaldiagram)

[Architecture](#cellularmanagement-architecture)

[IP Address assignment](#cellularmanagement-ipaddressassignment)

[IP methods](#cellularmanagement-ipmethods)

[Network configuration](#cellularmanagement-networkconfiguration)

[Modem SLAAC vs Host SLAAC](#cellularmanagement-modemslaacvshostslaac)

[OpenWRT](#cellularmanagement-openwrt)

[Tested Modems](#cellularmanagement-testedmodems)

[NetModel Cellular](#cellularmanagement-netmodelcellular)

[Ethernet Manager](#cellularmanagement-ethernetmanager)

[IP manager](#cellularmanagement-ipmanager)

[DNS manager](#cellularmanagement-dnsmanager)

[Routing manager](#cellularmanagement-routingmanager)

[USB Modem Filtering](#cellularmanagement-usbmodemfiltering) 

[Overview](#cellularmanagement-overview)

[Bash script example](#cellularmanagement-bashscriptexample)

[Code Breakdown](#cellularmanagement-codebreakdown) 

[Variables](#cellularmanagement-variables)

[Notes](#cellularmanagement-notes)

[Fetching the Whitelist](#cellularmanagement-fetchingthewhitelist)

[Reading Device Information](#cellularmanagement-readingdeviceinformation)

[Checking the Whitelist](#cellularmanagement-checkingthewhitelist)

[Blocking Unauthorized Devices](#cellularmanagement-blockingunauthorizeddevices)

[Data Model](#cellularmanagement-datamodel)

[Low-Level API](#cellularmanagement-low-levelapi)

[API](#cellularmanagement-api)

[Files](#cellularmanagement-files)

[Firewall](#cellularmanagement-firewall)

[Dependants and Dependencies](#cellularmanagement-dependantsanddependencies) 

[Dependants](#cellularmanagement-dependants)

[Dependencies](#cellularmanagement-dependencies) 

[TR181 Cellular dependencies list](#cellularmanagement-tr181cellulardependencieslist)

[NetModel Cellular dependencies list](#cellularmanagement-netmodelcellulardependencieslist)

[Configuration](#cellularmanagement-configuration)

[Backup/Restore, Upgrade, Reset](#cellularmanagement-backup/restore,upgrade,reset)

[Web UI](#cellularmanagement-webui)

[Considerations](#cellularmanagement-considerations) 

[IPv6](#cellularmanagement-ipv6)

[Packet Acceleration](#cellularmanagement-packetacceleration)

[Memory Usage](#cellularmanagement-memoryusage)

[Boot Time](#cellularmanagement-boottime)

[Security](#cellularmanagement-security)

[Remote Management](#cellularmanagement-remotemanagement)

[Operational Monitoring](#cellularmanagement-operationalmonitoring)

[Quality](#cellularmanagement-quality) 

[Project Reference Configuration](#cellularmanagement-projectreferenceconfiguration)

[Build-time Checks](#cellularmanagement-build-timechecks)

[Run-time Checks](#cellularmanagement-run-timechecks)

[Unit Tests](#cellularmanagement-unittests)

[Logging and Debugging](#cellularmanagement-logginganddebugging)

[Functional Tests](#cellularmanagement-functionaltests)

[CI Tests](#cellularmanagement-citests)

[Certification](#cellularmanagement-certification)

[Design Review Documentation](#cellularmanagement-designreviewdocumentation)
# <a name="cellularmanagement-todo"></a>**TODO**
1. Unified prpl config that includes all the Cellular components
1. Test Wan modem manager that you can switch between the different Wan modes including Cellular.
1. USB modem detection needs to be implemented in the Cellular manager based on hotplug.d. When the modem is detected mm needs to be polled.
1. Test IPv6. Currently this is not yet activated on the Proximus and Orange BE network. Proposal to test this using the SoftAtHome Femto cell.
1. USB Filtering: Phase 2. Current proposal is to do it in Cellular manager based on Manufacturer and Model. The best way needs to be investigated.
1. List multiple detected modems (inserted modems) , what do with this?
1. How to list the neighbouring cell information when the retrieved information is not always constant (polling every 5 seconds: e.g. 3 cells vs 5 cells).
1. How is mm finding the USB modems, is there an event?
1. Debug why USB dongles are not always connected by MM while they are recognised by the system.
1. Decide which of the OpenWRT MM scripts that are included in the feed are relevant, and if not remove them from the system.
1. Removal of the NETIFD OpenWRT MM manager files are momentarily done during 1st boot. This step MUST be done at build time.
1. Document the NetModel interaction.
1. Document which components have been extended, and how to listen for the netmodel cellular information.
# <a name="cellularmanagement-introduction"></a>**Introduction**
In prplOS, the integration of a CellularManager serves as a component on top of ModemManager obtained from <https://modemmanager.org/> . The CellularManager is needed to streamline the management and functionality of cellular connectivity within the prplOS environment.

The primary responsibilities of the CellularManager extend beyond the capabilities of ModemManager. Its core tasks involve the provision of a compliant TR-181 data model, based on TR-181i2-v17. This data model ensures adherence to industry standards, facilitating seamless integration with various devices and systems.

One key function of the CellularManager is to interact with the ModemManager software, extracting essential network information. This information is subsequently assigned to the relevant **wwan** network interface. By doing so, the CellularManager ensures that network configurations align with the specific requirements of the prplOS framework.

Furthermore, the CellularManager operates as a vigilant overseer of the cellular link and wwan interface statuses. In the event of anomalies or disruptions, such as a cellular link downtime, the CellularManager takes proactive measures. For instance, it may instruct ModemManager to reestablish the connection, thus maintaining a robust and consistent cellular link.
# <a name="cellularmanagement-usecases"></a>**Use cases**
## <a name="cellularmanagement-usecasedefinition"></a>**Use Case Definition[](https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20\(PCF-1173%2C%20LLAPI-8\)%20ORDER%20BY%20type%2C%20created%20DESC)**
<https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20(PCF-1173%2C%20LLAPI-8)%20ORDER%20BY%20type%2C%20created%20DESC> 
## <a name="cellularmanagement-references"></a>**References**
- <https://modemmanager.org/>
- <https://modemmanager.org/><https://git.openwrt.org/?p=feed/packages.git;a=tree;f=net/modemmanager/files;hb=HEAD>
## <a name="cellularmanagement-cellularhardwaretypes"></a>**Cellular hardware types**
### <a name="cellularmanagement-socwithbuilt-inmodemrunningthemainos"></a>**SoC with built-in modem running the main OS**
![](image/soc_modem.png) 
### <a name="cellularmanagement-in-cpepciemodemconnectedtosocrunningmainos"></a>**In-CPE PCIe modem connected to SoC running main OS**
![](image/pcie-modem.png) 
### <a name="cellularmanagement-in-cpeusbmodemconnectedtosocrunningmainos"></a>**In-CPE USB modem connected to SoC running main OS**
![](image/usb-modem.png) 
### <a name="cellularmanagement-in-cpexgmiimodemconnectedtosocrunningmainos"></a>**In-CPE xGMII modem connected to SoC running main OS**
![](image/xGMII-modem.png) 
### <a name="cellularmanagement-externallyconnectedusbmodem;variousvariants:control:serial(cdc-acm)withatcommandset/qmi/mbim/otherproprietaryprotocol.data:pppoverserial/linuxnetworkinterface(variousvariants,cdc-ncm/ecmandmore)"></a>**Externally connected USB modem; various variants: control: serial (CDC-ACM) with AT command set / QMI / MBIM / other proprietary protocol. Data: PPP over serial / Linux network interface (various variants, CDC-NCM/ECM and more)**
![](image/external-modem.png) 
### <a name="cellularmanagement-tetheringtousb-connectedsmartphone"></a>**Tethering to USB-connected smartphone**
![](image/tethering2USB-smartphone.png) 
### <a name="cellularmanagement-network(ethernet/wlan)-connectedodu(outdoorunit)containingmodemwithproprietaryprotocol."></a>**Network (Ethernet/WLAN)-connected ODU (outdoor unit) containing modem with proprietary protocol.**
![](image/network-ODU-modem.png) 
## <a name="cellularmanagement-accessnetworkconnectivity"></a>**Access network connectivity**
- singular interface: FWA
- backup interface; failover to active standby or bringup
- link aggregation; various options, but 3GPP defines ATSSS
## <a name="cellularmanagement-wiredaccessnetworkprotocol"></a>**Wired access network protocol**
- independent (DOCSIS/BNG)
- wireless/wireline legacy (as independent)
- 5G
## <a name="cellularmanagement-authentication"></a>**Authentication**
- None; end user provides configured dongle/smartphone
- data model (APN/PIN/PUK)
- eSIM (5G LPA) with key in modem hardware
- eSIM with key in secure storage handled by main SoC
## <a name="cellularmanagement-networkmanagementco-existence"></a>**Network management co-existence**
It must be possible to manage the cellular modem using multiple management protocols.

For example OMA-DM could be used for provisioning and providing firmware upgrades to the cellular modem. While another management solution based on TR-181 and USP could be used in parallel to retrieve statistics from the cellular modem.
# <a name="cellularmanagement-requirements"></a>**Requirements**
## <a name="cellularmanagement-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
A Cellular Manager must:

- integrate with the WAN Mode Manager and the Network Model components,
  - extending NetModel to reuse NAS signalling information within the prplOS middleware,
  - extending NetModel to encompass Ethernet, IP, DNS, Routing, and WAN mode management.
- provide the TR-181 Data Model as a front-end to ModemManager, either
  - by using mmlib as a back-end , or
  - adding native TR-181 support to ModemManager as a replacement for its D-Bus interface, in coordination with the ModemManager maintainer.

Data paths are per Linux WWAN architecture (WWAN, MBIM, QMI, …) on top of PCI or USB.

Control path is through the Freedesktop ModemManager component.
Any functionality missing from ModemManager must be added and upstreamed. This may be:

- extensions to the D-Bus API / mmlib; necessary for features that must be exposed through the HL-API,
- vendor modules, implementing low-level functionality, specific to dongles / PCIe/USB modules / SoC modems.

All of the above must be open sourced. Proprietary interfaces, i.e. code that is not published in ModemManager or prpl, and undocumented API’s, are not acceptable. The LL-API WG / Platform team will work with the silicon vendor(s) in order to assure any necessary proprietary interfaces are opened.

The conflict between the OpenWrt ModemManager package and the prplOS customised PPP package must be resolved, preferably without further forking OpenWrt packages.

The TR-181 data model is based on the current BBF efforts to extend Device.Cellular. Any extension of the data model by prpl must be contributed to and coordinated with BBF through the prpl HL-API WG.



**Community Interaction**

The avenue of cooperation with the existing RDK-B CellularManager development, which supports additional use cases (hotpluggable USB dongles, Android and iOS USB tethering, protocol interaction with a remote FWA modem), must be explored by prpl.

Reuse of existing SoftAtHome development, contributed in the scope of this development item, is subject to technical assessment by prpl, and must take into account the requirement for open source community collaboration. Any rearchitecture work to align with other open source communities is out of scope, apart from the requirements specified under the *Architecture* section above.



**Scope**

The implementation target for 2024 is limited to a minimal functional scope, plus an analysis. The feature set is as per the TR-181i2v2.17 Device.Cellular. data model.

The full functional scope may be phased, based on a selection of KPI’s. Input for the possible KPI’s are the Operator requirements, RDK-B Cellular Manager current and roadmap functionality, BBF Cellular discussions and TR-181 data model, and protocol feature support (e.g. multiple L2 and L3 links, PPP, IPv6, VoLTE).

The analysis of:

- functionality,
- data model,
- implementation presence or gaps in ModemManager,
- support in hardware modem modules supported (in an open manner),

must be performed and documented for each KPI, to assess future implementation complexity and feasibility.



OMA-DM support is not in scope.



PPP protocol support over a cellular interface is out of scope.



The hardware to be supported is, in order of delivery and priority:

- Quectel RM520N on Freedom
- then, or if the module does not work on Freedom, RM520N on OSPv2.

Note that none of the design may be Qualcomm-centric, to keep open the options for other silicon to be supported in the future.
# <a name="cellularmanagement-implementation"></a>**Implementation**
## <a name="cellularmanagement-functionaldiagram"></a>**Functional diagram**
![](image/functionnal_diagram.png) 
## <a name="cellularmanagement-architecture"></a>**Architecture**
![](image/architecture_diagram.png) 
## <a name="cellularmanagement-ipaddressassignment"></a>**IP Address assignment**
Establishing an Ethernet network connection on a host is a well-known and straightforward process for many individuals. Typically, it involves configuring the network interface with specific predefined IPv4 or IPv6 addresses, netmask, link MTU, default route gateway, and DNS servers. Alternatively, these settings can be obtained dynamically from the network itself through methods such as IPv4 DHCP or IPv6 SLAAC. This simplicity arises because Ethernet network interfaces lack a signaling plane (control protocol) that necessitates management, allowing the user plane (data path) to be readily set up and utilized without additional configuration.

In contrast, LTE modems, along with other cellular modems, demand specific control commands be executed on the host before deeming the data path operational. Even if the modem presents a network interface in the system, this interface remains non-functional until the modem establishes a connection with the operator network.

Within Linux kernel-based systems, the ModemManager system daemon orchestrates the signaling plane interaction between the host and the modem. Typically, ModemManager serves as a backend for other daemons like NetworkManager, OpenWRT netifd, or ChromeOS shill, responsible for managing the overall network connection setup. This process can be succinctly outlined in the following steps:

1. The network management daemon instructs ModemManager to establish a connection with the modem using specific settings.
1. ModemManager utilises control commands to attach and connect the modem to the network, communicating exclusively via the signalling plane between the host and LTE modem (e.g., using QMI, MBIM, or AT commands).
1. The LTE modem negotiates IP addresses with the LTE network, initially via the signaling plane between the LTE modem and the LTE network (e.g., through NAS messages exchanged between the modem and the network's MME).
1. Upon completion of signalling plane communication, additional steps may be necessary in the newly created user plane (e.g., running IPv6 SLAAC with the network's PGW).
1. The LTE modem conveys the IP settings to ModemManager, again via the signaling plane between the host and LTE modem.
1. ModemManager reports the IP settings back to the network management daemon, which uses them to configure the network interface exposed by the modem, effectively establishing the data path within the host.
## <a name="cellularmanagement-ipmethods"></a>**IP methods**
The IP method field in the IP settings of ModemManager specify how the host should configure the network interface in the modem device. This field has little to do with how the modem acquires the IP addressing from the network.

- **PPP**: the modem requests the host to establish a PPP session over the serial port specified as data interface. This method is used in RS232 modems, or in USB modems with limited capabilities (e.g. modems that don’t expose a network interface). For the purpose of this document, this case can be ignored.
- **Static**: the modem requests the host to use the IP settings reported by the modem via control messages.
- **DHCP**: the modem requests the host to use dynamic IP addressing setup, i.e. DHCP for IPv4 or SLAAC for IPv6.
## <a name="cellularmanagement-networkconfiguration"></a>**Network configuration**
The network configuration is provided by the network through 3GPP NAS signaling mechanisms and is made available via ModemManager.

Below is an example of the network configuration:
```
root@prplOS:/# mmcli -b 0

  ------------------------------------

  General            |           path: /org/freedesktop/ModemManager1/Bearer/1

                     |           type: default

  ------------------------------------

  Status             |      connected: yes

                     |      suspended: no

                     |    multiplexed: no

                     |      interface: wwan0

                     |     ip timeout: 20

  ------------------------------------

  Properties         |            apn: apn

                     |        roaming: forbidden

  ------------------------------------

  IPv4 configuration |         method: static

                     |        address: 10.199.56.36

                     |         prefix: 29

                     |        gateway: 10.199.56.37

                     |            dns: 212.224.129.90, 212.224.129.94

                     |            mtu: 1500

  ------------------------------------

  Statistics         |     start date: 2024-12-05T18:59:59Z

                     |       duration: 570

                     |       bytes rx: 6216

                     |       bytes tx: 7562

                     |       attempts: 1

                     | total-duration: 570

                     | total-bytes rx: 6216

                     | total-bytes tx: 7562
```
This configuration includes details such as APN, IPv4 address, DNS, gateway, and network statistics, all of which are provided by the cellular network and managed through ModemManager.

Cellular manager:
```
 > Cellular.Interface.1.?

Cellular.Interface.1.

Cellular.Interface.1.Alias="CELLULAR0"

Cellular.Interface.1.AvailableNetworks=""

Cellular.Interface.1.CurrentAccessTechnology=""

Cellular.Interface.1.DownstreamMaxBitRate=100000

Cellular.Interface.1.Enable=1

Cellular.Interface.1.IMEI="868371051413371"

Cellular.Interface.1.LastChange=933

Cellular.Interface.1.LowerLayers=""

Cellular.Interface.1.Name="wwan0"

Cellular.Interface.1.NetworkInUse=""

Cellular.Interface.1.NetworkRequested=""

Cellular.Interface.1.PreferredAccessTechnology="NR"

Cellular.Interface.1.RSRP=-140

Cellular.Interface.1.RSRQ=-20

Cellular.Interface.1.RSSI=-111

Cellular.Interface.1.Status="Up"

Cellular.Interface.1.SupportedAccessTechnologies="UMTS,LTE,NR"

Cellular.Interface.1.Upstream=1

Cellular.Interface.1.UpstreamMaxBitRate=50000

Cellular.Interface.1.X\_PRPL-COM\_SignalQualityPollingRate=0

Cellular.Interface.1.Stats.

Cellular.Interface.1.Stats.BroadcastPacketsReceived=0

Cellular.Interface.1.Stats.BroadcastPacketsSent=0

Cellular.Interface.1.Stats.BytesReceived=0

Cellular.Interface.1.Stats.BytesSent=0

Cellular.Interface.1.Stats.DiscardPacketsReceived=0

Cellular.Interface.1.Stats.DiscardPacketsSent=0

Cellular.Interface.1.Stats.ErrorsReceived=0

Cellular.Interface.1.Stats.ErrorsSent=0

Cellular.Interface.1.Stats.MulticastPacketsReceived=0

Cellular.Interface.1.Stats.MulticastPacketsSent=0

Cellular.Interface.1.Stats.PacketsReceived=0

Cellular.Interface.1.Stats.PacketsSent=0

Cellular.Interface.1.Stats.UnicastPacketsReceived=0

Cellular.Interface.1.Stats.UnicastPacketsSent=0

Cellular.Interface.1.Stats.UnknownProtoPacketsReceived=0

Cellular.Interface.1.USIM.

Cellular.Interface.1.USIM.ICCID="89320299220208006010"

Cellular.Interface.1.USIM.IMSI="206102300806160"

Cellular.Interface.1.USIM.MSISDN=""

Cellular.Interface.1.USIM.PIN=""

Cellular.Interface.1.USIM.PINCheck="Off"

Cellular.Interface.1.USIM.Status="Valid"
```
The Cellular** Manager makes this information available via NeMo, updating the relevant prplOS middleware components to ensure proper integration with the IP, Routing, and DNS managers.

Logical Interface manager:
```
 > Device.Logical.Interface.?

Device.Logical.Interface.1.

Device.Logical.Interface.1.Alias="wan"

Device.Logical.Interface.1.Enable=1

Device.Logical.Interface.1.LastChange=7129

Device.Logical.Interface.1.LowerLayers="Device.IP.Interface.2."

Device.Logical.Interface.1.Name="wan"

Device.Logical.Interface.1.Status="Up"

Device.Logical.Interface.1.Stats.

Device.Logical.Interface.1.Stats.BroadcastPacketsReceived=0

Device.Logical.Interface.1.Stats.BroadcastPacketsSent=0

Device.Logical.Interface.1.Stats.BytesReceived=0

Device.Logical.Interface.1.Stats.BytesSent=0

Device.Logical.Interface.1.Stats.DiscardPacketsReceived=0

Device.Logical.Interface.1.Stats.DiscardPacketsSent=0

Device.Logical.Interface.1.Stats.ErrorsReceived=0

Device.Logical.Interface.1.Stats.ErrorsSent=0

Device.Logical.Interface.1.Stats.MulticastPacketsReceived=0

Device.Logical.Interface.1.Stats.MulticastPacketsSent=0

Device.Logical.Interface.1.Stats.PacketsReceived=0

Device.Logical.Interface.1.Stats.PacketsSent=0

Device.Logical.Interface.1.Stats.UnicastPacketsReceived=0

Device.Logical.Interface.1.Stats.UnicastPacketsSent=0

Device.Logical.Interface.1.Stats.UnknownProtoPacketsReceived=0

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.DHCPv4PoolReference=""

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.DHCPv6PoolReference=""

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.DomainName="home.arpa"

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.DomainSearchList=""

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.HostNameNumberOfEntries=0

Device.Logical.Interface.1.X\_PRPL-COM\_LAN.Status="Disabled"

Device.Logical.Interface.1.X\_PRPL-COM\_WAN.

Device.Logical.Interface.1.X\_PRPL-COM\_WAN.IPv4Address=""

Device.Logical.Interface.1.X\_PRPL-COM\_WAN.IPv6Address=""

Device.Logical.Interface.1.X\_PRPL-COM\_WAN.Status="Enabled"

...

IP manager:

 > IP.Interface.2.?

IP.Interface.2.

IP.Interface.2.Alias="wan"

IP.Interface.2.AutoIPEnable=0

IP.Interface.2.Enable=1

IP.Interface.2.IPv4AddressNumberOfEntries=1

IP.Interface.2.IPv4Enable=1

IP.Interface.2.IPv6AddressNumberOfEntries=4

IP.Interface.2.IPv6Enable=1

IP.Interface.2.IPv6PrefixNumberOfEntries=4

IP.Interface.2.LastChange=7018

IP.Interface.2.Loopback=0

IP.Interface.2.LowerLayers="Device.Ethernet.Link.2"

IP.Interface.2.MaxMTUSize=1500

IP.Interface.2.Name="wan"

IP.Interface.2.Reset=0

IP.Interface.2.Router="Device.Routing.Router.1"

IP.Interface.2.Status="Up"

IP.Interface.2.Type="Normal"

IP.Interface.2.ULAEnable=0

IP.Interface.2.X\_PRPL-COM\_Description=""

IP.Interface.2.X\_PRPL-COM\_MTUMode="auto"

IP.Interface.2.IPv4Address.1.

IP.Interface.2.IPv4Address.1.AddressingType="3GPP-NAS"

IP.Interface.2.IPv4Address.1.Alias="primary"

IP.Interface.2.IPv4Address.1.Enable=1

IP.Interface.2.IPv4Address.1.IPAddress="10.199.56.36"

IP.Interface.2.IPv4Address.1.Status="Enabled"

IP.Interface.2.IPv4Address.1.SubnetMask="255.255.255.248"

...

Ethernet manager:

Device.Ethernet.Link.3.

Device.Ethernet.Link.3.Alias="cellular\_wan"

Device.Ethernet.Link.3.Enable=0

Device.Ethernet.Link.3.FlowControl=0

Device.Ethernet.Link.3.LastChange=317

Device.Ethernet.Link.3.LowerLayers="Device.Cellular.Interface.1"

Device.Ethernet.Link.3.MACAddress="AC:91:9B:FF:F1:BE"

Device.Ethernet.Link.3.Name="wwan0"

Device.Ethernet.Link.3.PriorityTagging=0

Device.Ethernet.Link.3.Status="Up"

Device.Ethernet.Link.3.Stats.

Device.Ethernet.Link.3.Stats.BroadcastPacketsReceived=0

Device.Ethernet.Link.3.Stats.BroadcastPacketsSent=0

Device.Ethernet.Link.3.Stats.BytesReceived=0

Device.Ethernet.Link.3.Stats.BytesSent=0

Device.Ethernet.Link.3.Stats.DiscardPacketsReceived=0

Device.Ethernet.Link.3.Stats.DiscardPacketsSent=0

Device.Ethernet.Link.3.Stats.ErrorsReceived=0

Device.Ethernet.Link.3.Stats.ErrorsSent=0

Device.Ethernet.Link.3.Stats.MulticastPacketsReceived=0

Device.Ethernet.Link.3.Stats.MulticastPacketsSent=0

Device.Ethernet.Link.3.Stats.PacketsReceived=0

Device.Ethernet.Link.3.Stats.PacketsSent=0

Device.Ethernet.Link.3.Stats.UnicastPacketsReceived=0

Device.Ethernet.Link.3.Stats.UnicastPacketsSent=0

Device.Ethernet.Link.3.Stats.UnknownProtoPacketsReceived=0

Routing manager:

 > Routing.Router.1.?

Routing.Router.1.

Routing.Router.1.Alias="main"

Routing.Router.1.Enable=1

Routing.Router.1.IPv4ForwardingNumberOfEntries=6

Routing.Router.1.IPv6ForwardingNumberOfEntries=3

Routing.Router.1.Status="Enabled"

Routing.Router.1.IPv4Forwarding.1.

Routing.Router.1.IPv4Forwarding.1.Alias="cpe-default"

Routing.Router.1.IPv4Forwarding.1.DestIPAddress="0.0.0.0"

Routing.Router.1.IPv4Forwarding.1.DestSubnetMask="0.0.0.0"

Routing.Router.1.IPv4Forwarding.1.Enable=1

Routing.Router.1.IPv4Forwarding.1.ForwardingMetric=-1

Routing.Router.1.IPv4Forwarding.1.ForwardingPolicy=-1

Routing.Router.1.IPv4Forwarding.1.GatewayIPAddress="10.199.56.37"

Routing.Router.1.IPv4Forwarding.1.Interface="Device.IP.Interface.2."

Routing.Router.1.IPv4Forwarding.1.Origin="3GPP-NAS"

Routing.Router.1.IPv4Forwarding.1.StaticRoute=0

Routing.Router.1.IPv4Forwarding.1.Status="Enabled"

...

DNS manager:

 > DNS.Relay.Forwarding.?

DNS.Relay.Forwarding.10.

DNS.Relay.Forwarding.10.Alias="cellular-2"

DNS.Relay.Forwarding.10.DNSServer="212.224.129.94"

DNS.Relay.Forwarding.10.Enable=1

DNS.Relay.Forwarding.10.Interface="Device.Logical.Interface.1."

DNS.Relay.Forwarding.10.Status="Enabled"

DNS.Relay.Forwarding.10.Type="3GPP-NAS"

DNS.Relay.Forwarding.9.

DNS.Relay.Forwarding.9.Alias="cellular-1"

DNS.Relay.Forwarding.9.DNSServer="212.224.129.90"

DNS.Relay.Forwarding.9.Enable=1

DNS.Relay.Forwarding.9.Interface="Device.Logical.Interface.1."

DNS.Relay.Forwarding.9.Status="Enabled"

DNS.Relay.Forwarding.9.Type="3GPP-NAS"

...
```
## <a name="cellularmanagement-modemslaacvshostslaac"></a>**Modem SLAAC vs Host SLAAC**
Modem SLAAC, within the context of LTE or cellular networks, refers to the autonomous configuration of IPv6 addresses by the LTE modem (not the HGW). This process occurs through specialised signalling and communication protocols between the modem and the cellular network infrastructure.  On the other hand, Host SLAAC involves IPv6 hosts (the HGW) autonomously configuring their addresses based on Router Advertisement messages. The SLAAC procedure is embedded in the host (HGW) and not in the modem.
## <a name="cellularmanagement-openwrt"></a>**OpenWRT**
The ModemManager package in OpenWRT includes additional scripts for status reporting, logging, and retrieving essential network information (from the Bearers). These scripts help configure the wwan0 interface using UCI and netifd.

However, for compatibility with prplOS, dependencies on netifd have been removed, and adjustments have been made to accommodate these changes. Specifically, the following files have been removed:

- **Init script**: /etc/init.d/modemmanager
- **Protocol script**: /lib/netifd/proto/modemmanager.sh
- **Report down script**: /usr/lib/ModemManager/connection.d/10-report-down
- **Monitor script**: /usr/sbin/ModemManager-monitor

Additionally, references to netifd have been removed from the common script using the following command:

sed -ie '/\/lib\/netifd\/netifd-proto.sh/d' /usr/share/ModemManager/modemmanager.common

A new init script, /etc/init.d/modemmanager-prpl, has been created to replace the old init script and remove dependencies on netifd functionality.
## <a name="cellularmanagement-testedmodems"></a>**Tested Modems**
- PCIE

- USB
  - Quectel RM520N-GL
  - Alcatel: IK41VE1 Vendor: Alcatel Product: MobileBroadband
  - HUAWEI Model: E3372H - 153, E3276s - 150
## <a name="cellularmanagement-netmodelcellular"></a>**NetModel Cellular**
**NetModel Cellular** is a module running within the netmodel-client memory space that propagates IP address information from the TR-181 Cellular Manager to other middleware components.

The **Cellular Manager** creates cellular interfaces within NetModel by adding a new object instance to the NetModel interface table, setting the **"Cellular"** flag, and specifying the **InterfacePath** parameter. Setting the **"Cellular"** flag ensures that the NetModel Cellular MIB module is loaded automatically.

The **NetModel Cellular** MIB module manages these interfaces by subscribing to the Device.Cellular.Interface.{i}.Bearer object, as defined in the NetModel.Intf.{i}.InterfacePath parameter (e.g., NetModel.Intf.{i}.InterfacePath = "Device.Cellular.Interface.1.").

When the **TR-181 Cellular Bearer** object is updated, NetModel Cellular copies the relevant information to its internal data model. This update triggers a re-evaluation of NetModel queries, and subscribed middleware components such as the **IP**, **DNS**, and **Routing Managers** receive NetModel notifications and update their data model accordingly.

TR-181 Cellular Bearer information example:
```
Cellular.Interface.1.Bearer.

Cellular.Interface.1.Bearer.DNSServers="212.224.129.94,212.224.129.90"

Cellular.Interface.1.Bearer.IPAddress="10.199.56.36"

Cellular.Interface.1.Bearer.InternalName="/org/freedesktop/ModemManager1/Bearer/1"

Cellular.Interface.1.Bearer.SubnetMask="255.255.255.248"

Cellular.Interface.1.Bearer.GatewayIPAddress="10.199.56.37"

NetModel Cellular Interface example:

 > NetModel.Intf.cellularIntf-CELLULAR0.?

NetModel.Intf.46.

NetModel.Intf.46.Alias="cellularIntf-CELLULAR0"

NetModel.Intf.46.DNSServers="212.224.129.90,212.224.129.94"

NetModel.Intf.46.DownstreamMaxBitRateEnabled=100000

NetModel.Intf.46.Enable=1

NetModel.Intf.46.Flags="cellular netdev upstream netdev-bound netdev-up enabled up cellular-up ipv4 ipv6 nat nat-up"

NetModel.Intf.46.GatewayIPAddress="10.199.56.37"

NetModel.Intf.46.IPAddress="10.199.56.36"

NetModel.Intf.46.InterfaceAlias="CELLULAR0"

NetModel.Intf.46.InterfacePath="Device.Cellular.Interface.1."

NetModel.Intf.46.Name="wwan0"

NetModel.Intf.46.NetDevFlags="up pointopoint running noarp multicast"

NetModel.Intf.46.NetDevIndex=15

NetModel.Intf.46.NetDevName="wwan0"

NetModel.Intf.46.Status=1

NetModel.Intf.46.Status\_ext="Up"

NetModel.Intf.46.SubnetMask="255.255.255.248"

NetModel.Intf.46.Upstream=0

NetModel.Intf.46.UpstreamMaxBitRateEnabled=50000

NetModel.Intf.46.LLIntf.

NetModel.Intf.46.Query.

NetModel.Intf.46.ULIntf.

NetModel.Intf.46.ULIntf.1.

NetModel.Intf.46.ULIntf.1.Name="ethLink-cellular\_wan"
```
## <a name="cellularmanagement-ethernetmanager"></a>**Ethernet Manager**
The Ethernet Manager has been updated to enable or disable the sending of ARP messages on the WWAN netdev interface, configurable through the data model.

|Device.Ethernet.Link.{i}.|object(0:)|W|<p>Ethernet link layer table (a stackable interface object as described in [[Section 4.2/TR-181i2](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.TR-181i2)]). Table entries model the Logical Link Control (LLC) layer. It is expected that an *Ethernet Link* interface can be stacked above any lower-layer interface object capable of carrying Ethernet frames.</p><p>At most one entry in this table can exist with a given value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.Alias), or with a given value for [*Name*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.Name), or with a given value for [*MACAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.MACAddress). On creation of a new table entry, the Agent MUST (if not supplied by the Controller on creation) choose initial values for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.Alias), [*Name*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.Name) and [*MACAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Ethernet.Link.MACAddress) such that the new entry does not conflict with any existing entries.</p>|-|2\.0|
| :- | :- | :- | :- | :- | :- |
|NoARP|boolean|W|Disables or enables sending of ARP messages on the Ethernet link. If *true*, the kernel will not send ARP requests and won’t send ARP replies.|false|2\.18|
## <a name="cellularmanagement-ipmanager"></a>**IP manager**
The IP Manager has been updated to display the IP information of the WWAN netdev interface, such as IP address, netmask, and AddressingType, accessible through the data model. When Cellular information is shown, the AddressingType is set to 3GPP-NAS.

|Device.IP.Interface.{i}.IPv4Address.{i}.|object(0:)|W|<p>IPv4 address table. Entries are auto-created and auto-deleted as IP addresses are added and deleted via DHCP, auto-IP, 3GPP-NAS, or IPCP. Static entries are created and configured by the Controller.</p><p>At most one entry in this table can exist with a given value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.IP.Interface.IPv4Address.Alias), or with the same values for both [*IPAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.IP.Interface.IPv4Address.IPAddress) and [*SubnetMask*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.IP.Interface.IPv4Address.SubnetMask). On creation of a new table entry, the Agent MUST (if not supplied by the Controller on creation) choose initial values for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.IP.Interface.IPv4Address.Alias) and [*IPAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.IP.Interface.IPv4Address.IPAddress) such that the new entry does not conflict with any existing entries.</p>|-|2\.0|
| :- | :- | :- | :- | :- | :- |
|AddressingType|string|R|<p>Addressing method used to assign the IP address. Enumeration of:</p><p>- *DHCP*</p><p>- *IKEv2* (Assigned by IKEv2 [[RFC5996](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.RFC5996)])</p><p>- *AutoIP*</p><p>- *IPCP*</p><p>- *Static*</p><p>- *3GPP-NAS* (Assigned by the core network (fixed or cellular) using 3GPP NAS signalling methods. e.g. PDU Session Establishment Request [[Clause 6.2.4.2/3GPP-TS.24.501](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.24.501)], PDN Connectivity Request [[Clause 6.2.2/3GPP-TS.24.301](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.24.301)], PDP Context Activation Request [[Clause 6.1.2A/3GPP-TS.24.008](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.24.008)], … This information is available from the AT commands [[Clause 10.1.23/3GPP-TS.27.007](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.27.007)] PDP context read dynamic parameters +CGCONTRDP, added in 2.18)</p>|Static|2\.0|
## <a name="cellularmanagement-dnsmanager"></a>**DNS manager**
The DNS Manager has been updated to display DNS information for the Cellular network, including DNS servers and AddressingType, accessible through the data model. When Cellular information is shown, the Type is set to 3GPP-NAS.

|Device.DNS.Relay.Forwarding.{i}.|object(0:)|W|<p>DNS Server forwarding policy to be used by the DNS Relay. Entries are either automatically created as result of DHCP (v4 or v6), IPCP, or RA received DNS server information, or are statically configured by the Controller.</p><p>Note: Management of re-directing queries to the device embedded DNS server is not defined in this version of the specification.</p><p>At most one entry in this table can exist with a given value for [*DNSServer*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.DNSServer), or with a given value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Alias). On creation of a new table entry, the Agent MUST (if not supplied by the Controller on creation) choose initial values for [*DNSServer*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.DNSServer) and [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Alias) such that the new entry does not conflict with any existing entries.</p>|-|2\.0|
| :- | :- | :- | :- | :- | :- |
|Type|string|R|<p>Method used to assign the [*DNSServer*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.DNSServer) address. Enumeration of:</p><p>- *DHCP* (This enumeration was OBSOLETED in 2.14 because it’s been replaced by [*DHCPv4*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.DHCPv4). This enumeration was DELETED in 2.16)</p><p>- *DHCPv4*</p><p>- *DHCPv6*</p><p>- *RouterAdvertisement*</p><p>- *IPCP*</p><p>- *3GPP-NAS* (Address assigned by the core network (fixed or cellular) using 3GPP NAS signalling methods. e.g. PDU Session Establishment Request, PDN Connectivity Request, PDP Context Activation Request, … This information is available from the AT commands [[Clause 10.1.23/3GPP-TS.27.007](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.27.007)] PDP context read dynamic parameters +CGCONTRDP, added in 2.18)</p><p>- *Static*</p><p>Table entries that are automatically created as result of DHCP, IPCP, or RA received DNS server information will have *Type* set to [*DHCPv4*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.DHCPv4), [*DHCPv6*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.DHCPv6), [*IPCP*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.IPCP), or [*RouterAdvertisement*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.RouterAdvertisement), as the case may be. Manually created table entries will have their *Type* set to [*Static*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.DNS.Relay.Forwarding.Type.Static).</p>|Static|2\.0|
## <a name="cellularmanagement-routingmanager"></a>**Routing manager**
The Routing Manager has been updated to display routing information for the Cellular network, including Gateway IP address and Origin, accessible through the data model. When Cellular information is shown, the Origin is set to 3GPP-NAS.

|Device.Routing.Router.{i}.IPv4Forwarding.{i}.|object(0:)|W|<p>Layer 3 IPv4 forwarding table.</p><p>In addition to statically configured routes, this table MUST include dynamic routes learned through layer 3 routing protocols, including RIP (i.e. RIP version 2), OSPF, DHCPv4, 3GPP-NAS and IPCP. The CPE MAY reject attempts to delete or modify a dynamic route entry.</p><p>For each incoming packet, the layer 3 forwarding decision is conceptually made as follows:</p><p>- Only enabled table entries with a matching [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.ForwardingPolicy) are considered, i.e. those that either do not specify a [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.ForwardingPolicy), or else specify a [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.ForwardingPolicy) that matches that of the incoming packet.</p><p>- Next, table entries that also have a matching destination address/mask are considered, and the matching entry with the longest prefix is applied to the packet (i.e. the entry with the most specific network). An unspecified destination address is a wild-card and always matches, but with a prefix length of zero.</p><p>For enabled table entries, if [*Interface*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Interface) is not a valid reference to an IPv4-capable interface (that is attached to the IPv4 stack), then the table entry is inoperable and the CPE MUST set [*Status*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Status) to [*Error_Misconfigured*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Status.Error_Misconfigured).</p><p>Note: The *IPv4Forwarding* table includes a unique key parameter that is a strong reference. If a strongly referenced object is deleted, the CPE will set the referencing parameter to an empty string. However, doing so under these circumstances might cause the updated *IPv4Forwarding* row to then violate the table’s unique key constraint; if this occurs, the CPE MUST disable the offending *IPv4Forwarding* row.</p><p>At most one entry in this table can exist with a given value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Alias), or with the same values for all of [*DestIPAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.DestIPAddress), [*DestSubnetMask*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.DestSubnetMask), [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.ForwardingPolicy), [*GatewayIPAddress*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.GatewayIPAddress), [*Interface*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Interface) and [*ForwardingMetric*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.ForwardingMetric). On creation of a new table entry, the Agent MUST (if not supplied by the Controller on creation) choose an initial value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Alias) such that the new entry does not conflict with any existing entries.</p>|-|2\.0|
| :- | :- | :- | :- | :- | :- |
|GatewayIPAddress|string(:45)|W|<p>[[IPv4Address](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#T.IPv4Address)] IPv4 address of the gateway.</p><p>Only one of *GatewayIPAddress* and Interface SHOULD be configured for a route.</p><p>If both are configured, *GatewayIPAddress* and [*Interface*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv4Forwarding.Interface) MUST be consistent with each other.</p>|*<Empty>*|2\.0|
|Origin|string|R|<p>Protocol via which the IPv4 forwarding rule was learned. Enumeration of:</p><p>- *DHCPv4*</p><p>- *OSPF*</p><p>- *IPCP*</p><p>- *RIP*</p><p>- *3GPP-NAS* (Assigned by the core network (fixed or cellular) using 3GPP NAS signalling methods. e.g. PDU Session Establishment Request, PDN Connectivity Request, PDP Context Activation Request, … This information is available from the AT commands [[Clause 10.1.23/3GPP-TS.27.007](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.27.007)] PDP context read dynamic parameters +CGCONTRDP, added in 2.18)</p><p>- *Static* (For example, present in the factory default configuration, created by the Controller, or created by some other management entity (e.g. via a GUI))</p>|Static|2\.2|
|Device.Routing.Router.{i}.IPv6Forwarding.{i}.|object(0:)|W|<p>Layer 3 IPv6 forwarding table.</p><p>In addition to statically configured routes, this table MUST include dynamic routes learned through layer 3 routing protocols, including RIPng, OSPF, DHCPv6, 3GPP-NAS, and RA. The CPE MAY reject attempts to delete or modify a dynamic route entry.</p><p>For each incoming packet, the layer 3 forwarding decision is conceptually made as follows:</p><p>- Only enabled table entries with a matching [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.ForwardingPolicy) are considered, i.e. those that either do not specify a [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.ForwardingPolicy), or else specify a [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.ForwardingPolicy) that matches that of the incoming packet.</p><p>- Next, table entries that also have a matching destination prefix are considered, and the matching entry with the longest prefix length is applied to the packet (i.e. the entry with the most specific network). An unspecified destination address is a wild-card and always matches, but with a prefix length of zero.</p><p>For enabled table entries, if [*Interface*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Interface) is not a valid reference to an IPv6-capable interface (that is attached to the IPv6 stack), then the table entry is inoperable and the CPE MUST set [*Status*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Status) to [*Error_Misconfigured*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Status.Error_Misconfigured).</p><p>This object is based on *inetCidrRouteTable* from [[RFC4292](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.RFC4292)].</p><p>At most one entry in this table can exist with a given value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Alias), or with the same values for all of [*DestIPPrefix*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.DestIPPrefix), [*ForwardingPolicy*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.ForwardingPolicy), [*NextHop*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.NextHop), [*Interface*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Interface) and [*ForwardingMetric*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.ForwardingMetric). On creation of a new table entry, the Agent MUST (if not supplied by the Controller on creation) choose an initial value for [*Alias*](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#D.Device:2.Device.Routing.Router.IPv6Forwarding.Alias) such that the new entry does not conflict with any existing entries.</p>|-|2\.2|
|Origin|string|R|<p>Protocol via which the IPv6 forwarding rule was learned. Enumeration of:</p><p>- *DHCPv6*</p><p>- *OSPF*</p><p>- *RA* (Router Advertisement Route Information Option [[RFC4191](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.RFC4191)])</p><p>- *RIPng* (RIPng for IPv6 [[RFC2080](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.RFC2080)])</p><p>- *3GPP-NAS* (Address assigned by the core network (fixed or cellular) using 3GPP NAS signalling methods. e.g. PDU Session Establishment Request, PDN Connectivity Request, PDP Context Activation Request, … This information is available from the AT commands [[Clause 10.1.23/3GPP-TS.27.007](https://usp-data-models.broadband-forum.org/tr-181-2-18-0-usp.html#R.3GPP-TS.27.007)] PDP context read dynamic parameters +CGCONTRDP, added in 2.18)</p><p>- *Static* (For example, present in the factory default configuration, created by the Controller, or created by some other management entity (e.g. via a GUI))</p>|Static|2\.2|
## <a name="cellularmanagement-usbmodemfiltering"></a>**USB Modem Filtering**
### <a name="cellularmanagement-overview"></a>**Overview**
This section covers an example bash script used for whitelisting known USB devices in a system. The script leverages Linux's sysfs API to authorize or block USB devices based on a predefined whitelist. This mechanism ensures that only trusted USB devices can connect to the system.

The whitelist is fetched dynamically from a custom TR-181 Data Model (DM). This approach aligns with guidelines from the Linux kernel's USB authorization mechanism as described in the article [Authorizing (or not) your USB devices to connect to the system](https://docs.kernel.org/usb/authorization.html).
### <a name="cellularmanagement-bashscriptexample"></a>**Bash script example**
```
    ALLOWED\_DEVICES=$(ba-cli  'protected;USB.X\_PRPL-COM\_AllowedDevices?'  | \

			sed -ne 's/USB.X\_PRPL-COM\_AllowedDevices="\(.\*\)"/\1/p')

    read VENDOR\_ID < ${SYSFSPATH}/idVendor

    read PRODUCT\_ID < ${SYSFSPATH}/idProduct

    if [ -n "$VENDOR\_ID" -a "$VENDOR\_ID" != "1d6b" -a -n "$PRODUCT\_ID" -a -n "$ALLOWED\_DEVICES" ]; then

	FOUND=

	for ENTRY in $ALLOWED\_DEVICES; do

	    if [ "$ENTRY" == "${VENDOR\_ID}:${PRODUCT\_ID}" ]; then

		FOUND=1

		break

	    fi

	done

	if [ -z "$FOUND" ]; then

	    logger -t "${LOGTAG}" "USB device ${VENDOR\_ID}:${PRODUCT\_ID} is not authorized"

	    echo 0 > ${SYSFSPATH}/authorized

	fi

    fi
```
### <a name="cellularmanagement-codebreakdown"></a>**Code Breakdown**
#### <a name="cellularmanagement-variables"></a>**Variables**
- ALLOWED\_DEVICES: List of allowed vendor\_id:product\_id pairs.
- SYSFSPATH: Path to the sysfs directory for the USB device.
- VENDOR\_ID: The vendor ID of the USB device.
- PRODUCT\_ID: The product ID of the USB device.
- FOUND: Flag indicating if the device is allowed.
- LOGTAG: Tag for logging purposes.
#### <a name="cellularmanagement-notes"></a>**Notes**
1. **Whitelist Source**: The ALLOWED\_DEVICES list comes from a TR-181 DM query. Standardization within the Broadband Forum is required for wider adoption.
1. **USB Authorization**: Uses the sysfs mechanism (/sys/bus/usb/devices/.../authorized) to authorize or block devices.
1. **Default USB Hub**: Devices with vendor ID 1d6b (USB hubs) are excluded from the checks to avoid blocking essential system devices.
#### <a name="cellularmanagement-fetchingthewhitelist"></a>**Fetching the Whitelist**
```
ALLOWED\_DEVICES=$(ba-cli 'protected;USB.X\_PRPL-COM\_AllowedDevices?' | \ sed -ne 's/USB.X\_PRPL-COM\_AllowedDevices="\(.\*\)"/\1/p')
```
- ba-cli: Custom command-line tool to query the TR-181 Data Model.
- sed: Extracts the allowed devices list from the command output.
- ALLOWED\_DEVICES: Contains vendor\_id:product\_id pairs.
#### <a name="cellularmanagement-readingdeviceinformation"></a>**Reading Device Information**
```
read VENDOR\_ID < ${SYSFSPATH}/idVendor read PRODUCT\_ID < ${SYSFSPATH}/idProduct
```
- Reads the **vendor ID** and **product ID** of the current USB device from sysfs.
#### <a name="cellularmanagement-checkingthewhitelist"></a>**Checking the Whitelist**
```
if [ -n "$VENDOR\_ID" -a "$VENDOR\_ID" != "1d6b" -a -n "$PRODUCT\_ID" -a -n "$ALLOWED\_DEVICES" ]; then FOUND= for ENTRY in $ALLOWED\_DEVICES; do if [ "$ENTRY" == "${VENDOR\_ID}:${PRODUCT\_ID}" ]; then FOUND=1 break fi done
```
- **Conditions**:
  - The VENDOR\_ID is not empty.
  - The VENDOR\_ID is not 1d6b (default USB hub).
  - The PRODUCT\_ID and ALLOWED\_DEVICES are not empty.
#### <a name="cellularmanagement-blockingunauthorizeddevices"></a>**Blocking Unauthorized Devices**
```
if [ -z "$FOUND" ]; then logger -t "${LOGTAG}" "USB device ${VENDOR\_ID}:${PRODUCT\_ID} is not authorized" echo 0 > ${SYSFSPATH}/authorized fi
```
- Logs a message and writes 0 to the authorized file to block the device if it is not in the whitelist.
## <a name="cellularmanagement-datamodel"></a>**Data Model**
|**Device.​Cellular.**|**object**|**-**|**This object models cellular interfaces and access points.**|**-**|**2.12**|
| :-: | :-: | :-: | :-: | :-: | :-: |
|RoamingEnabled|boolean|W|Enables or disables roaming.|-|2\.12|
|RoamingStatus|string|-|<p>Current roaming status. Enumeration of:</p><p>- *Home*</p><p>- *Roaming*</p>|-|2\.12|
|InterfaceNumberOfEntries|unsignedInt|-|The number of entries in the *Interface* table.|-|2\.12|
|AccessPointNumberOfEntries|unsignedInt|-|The number of entries in the *AccessPoint* table.|-|2\.12|
|**Device.​Cellular.​Interface.​{i}.**|**object​[0:]**|**-**|<p>**Cellular interface table (a stackable interface object as described in [Section 4.2/[TR-181i2]()]). Each instance of this object models a cellular modem with a single radio and a single *USIM*.**</p><p>**At most one entry in this table can exist with a given value for *Alias*, or with a given value for *Name*.**</p>|**-**|**2.12**|
|Enable|boolean|W|<p>Enables or disables the interface.</p><p>This parameter is based on *ifAdminStatus* from [[RFC2863]()].</p>|-|2\.12|
|Status|string|-|<p>The current operational state of the interface (see [Section 4.2.2/[TR-181i2]()]). Enumeration of:</p><p>- *Up* (Corresponds to *GPRS*, *UMTS*, *LTE* etc *ATTACHED* status)</p><p>- *Down*</p><p>- *Unknown*</p><p>- *Dormant*</p><p>- *NotPresent* (Corresponds to *GPRS*, *UMTS*, *LTE* etc *DETACHED* status)</p><p>- *LowerLayerDown*</p><p>- *Error* (OPTIONAL)</p><p>When *Enable* is *false* then *Status* SHOULD normally be *Down* (or *NotPresent* or *Error* if there is a fault condition on the interface).</p><p>When *Enable* is changed to *true* then *Status*</p><p>- SHOULD change to *Up* if and only if the interface is able to transmit and receive network traffic.</p><p>- SHOULD change to *Dormant* if and only if the interface is operable but is waiting for external actions before it can transmit and receive network traffic (and subsequently change to *Up* if still operable when the expected actions have completed)</p><p>- SHOULD remain in the *Error* state if there is an error or other fault condition detected on the interface</p><p>- SHOULD remain in the *NotPresent* state if the interface has missing (typically hardware) components; it SHOULD change to *Unknown* if the state of the interface can not be determined for some reason.</p><p>Because the interface includes layer 1 the *LowerLayerDown* value SHOULD never be used.</p><p>This parameter is based on *ifOperStatus* from [[RFC2863]()].</p>|-|2\.12|
|Alias|string​(64)|WO|<p>[[*Alias*]()] A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.</p><p>The following mandatory constraints MUST be enforced:</p><p>- The value MUST NOT be empty.</p><p>- The value MUST start with a letter.</p><p>- If the value is not assigned by the Controller at creation time, the Agent MUST assign a value with an "cpe-" prefix.</p><p>This is a non-functional key and its value MUST NOT change once it's been assigned by the Controller or set internally by the Agent.</p>|-|2\.8|
|Name|string​(64)|-|<p>The textual name of the interface as assigned by the CPE.</p><p>This is a non-functional key and its value MUST NOT change once it's been assigned by the Controller or set internally by the Agent.</p>|-|2\.12|
|LastChange|unsignedInt|-|The accumulated time in *seconds* since the interface entered its current operational state.|-|2\.12|
|LowerLayers|string​(1024)​[]|W|<p>Comma-separated list (maximum number of characters 1024) of strings. Each list item MUST be the Path Name of an interface object that is stacked immediately below this interface object. If the referenced object is deleted, the corresponding item MUST be removed from the list. See [Section 4.2.1/[TR-181i2]()].</p><p>Note: Since *Interface* is a layer 1 interface, it is expected that *LowerLayers* will not be used.</p>|-|2\.12|
|Upstream|boolean|-|<p>Indicates whether the interface points towards the Internet (*true*) or towards End Devices (*false*).</p><p>For example:</p><p>- For an Internet Gateway Device, *Upstream* will be *true* for all WAN interfaces and *false* for all LAN interfaces.</p><p>- For a standalone WiFi Access Point that is connected via Ethernet to an Internet Gateway Device, *Upstream* will be *true* for the Ethernet interface and *false* for the WiFi Radio interface.</p><p>- For an End Device, *Upstream* will be *true* for all interfaces.</p>|-|2\.12|
|IMEI|string​(15:15)|-|<p>International Mobile Station Equipment Identity number, represented as a 15 digit string (digits 0-9). Possible patterns:</p><p>- *[0-9]{15,15}*</p>|-|2\.12|
|SupportedAccessTechnologies|string​[]|-|<p>Comma-separated list of strings. Access technologies supported by the interface. Each list item is an enumeration of:</p><p>- *GPRS* (GSM with GPRS)</p><p>- *EDGE* (GSM with EDGE)</p><p>- *UMTS*</p><p>- *UMTSHSPA* (UMTS with High Speed Packet Access (HSPA [[3GPP-HSPA]()]))</p><p>- *CDMA2000OneX*</p><p>- *CDMA2000HRPD*</p><p>- *LTE*</p><p>- *NR* (5G New Radio, added in v2.14)</p>|-|2\.12|
|PreferredAccessTechnology|string|W|<p>The value MUST be a member of the list reported by the *SupportedAccessTechnologies* parameter, or else be *Auto*. Preferred access technology.</p><p>The factory default value MUST be *Auto*.</p>|-|2\.12|
|CurrentAccessTechnology|string|-|The value MUST be a member of the list reported by the *SupportedAccessTechnologies* parameter. Access technology that is currently in use.|-|2\.12|
|AvailableNetworks|string​[]​(64)|-|Comma-separated list of strings (maximum number of characters 64). List of available networks.|-|2\.12|
|NetworkRequested|string​(64)|W|<p>Name of the network which will be used, or an empty string if the network is selected automatically.</p><p>The factory default value MUST be *<Empty>*.</p>|-|2\.12|
|NetworkInUse|string​(64)|-|The value MUST be a member of the list reported by the *AvailableNetworks* parameter, or else be an empty string. The value is an empty string if no network is found, or if the network specified in *NetworkRequested* is not found.|-|2\.12|
|RSSI|int|-|<p>The received signal strength in *dBm*. The allowed values depend on *CurrentAccessTechnology*:</p><p>- For *GPRS*, *EDGE* the range is -111 *dBm* to -49 *dBm*</p><p>- For *UMTS*, *UMTSHSPA* the range is -117 *dBm* to -54 *dBm*</p><p>- For *LTE*, *NR* the range is -117 *dBm* to -25 *dBm*</p><p>Note: An undetectable signal is indicated by the appropriate lower limit, e.g. -117 *dBm* for LTE.</p>|-|2\.12|
|RSRP|int|-|<p>The Reference Signal Received Power in *dBm* for *LTE*, *NR* values of *CurrentAccessTechnology*:</p><p>- The valid range of RSRP values from worst to best is -140 *dBm* to -44 *dBm*</p>|-|2\.14|
|RSRQ|int|-|<p>The Reference Signal Received Quality in *dBm* for *LTE*, *NR* values of *CurrentAccessTechnology*:</p><p>- RSRQ is calculated using RSSI and RSRP values using RSRQ = (N\*RSRP)/RSSI where N is the number of resource blocks (bandwidth).</p><p>- The valid range of RSRP values from worst to best is -20 *dBm* to -3 *dBm*</p>|-|2\.14|
|UpstreamMaxBitRate|unsignedInt|-|The current maximum attainable data rate upstream (expressed in *Kbps*).|-|2\.12|
|DownstreamMaxBitRate|unsignedInt|-|The current maximum attainable data rate downstream (expressed in *Kbps*).|-|2\.12|
|**Device.​Cellular.​Interface.​{i}.​USIM.**|**object**|**-**|**USIM (Universal Subscriber Identity Module or SIM card) parameters for the interface.**|**-**|**2.12**|
|Status|string|-|<p>The current status of the USIM card. Enumeration of:</p><p>- *None* (No card available)</p><p>- *Available* (Card is available but not verified)</p><p>- *Valid* (Card can be used; either valid PIN was entered, or PIN check is deactivated)</p><p>- *Blocked* (USIM is blocked because the maximum number of invalid PIN entries was exceeded)</p><p>- *Error* (An error was detected with the card, OPTIONAL)</p>|-|2\.12|
|IMSI|string​(14:15)|-|<p>International Mobile Subscriber Identity represented as a string with either 14 or 15 digits (digits 0-9). The first 3 digits are the mobile country code (MCC), which are followed by the mobile network code (MNC), either 2 digits (European standard) or 3 digits (North American standard), followed by the mobile subscription identification number (MSIN). Possible patterns:</p><p>- *[0-9]{14,15}*</p>|-|2\.12|
|ICCID|string​(6:20)|-|<p>Integrated Circuit Card Identifier represented as a string of up to 20 digits (digits 0-9). The number is composed of the following parts:</p><p>- Major industry identifier (MII), 2 fixed digits, 89 for telecommunication purposes.</p><p>- Country code, 1–3 digits, as defined by ITU-T recommendation [[ITU-E.164]()].</p><p>- identifier, 1–4 digits.</p><p>- Individual account identification number. Its length is variable, but every number under one IIN will have the same length.</p><p>- Single check digit calculated from the other digits using the Luhn algorithm.</p><p>For cards using an ICCID according to [[ITU-E.118]()] the maximum length is 19 Digits, for GSM cards 20 digits. Possible patterns:</p><p>- *[0-9]{6,20}*</p>|-|2\.12|
|MSISDN|string​(14:15)|-|<p>Mobile Subscriber Integrated Service Digital Network Number, a number uniquely identifying a subscription in a GSM, UMTS, or LTE mobile network. [[ITU-E.164]()]</p><p>Possible patterns:</p><p>- *[0-9]{14,15}*</p>|-|2\.12|
|PINCheck|string|W|<p>Controls the PIN verification of the USIM card. Enumeration of:</p><p>- *OnNetworkAccess* (Check the PIN with each access to a new network)</p><p>- *Reboot* (Check the PIN with first access after (re)boot)</p><p>- *Off* (Disable the PIN check)</p>|-|2\.12|
|PIN|string​(4)|W|<p>Allows the Controller to change the USIM PIN used for SIM card activation.</p><p>When read, this parameter returns an empty string, regardless of the actual value, unless the Controller has a "secured" role.</p>|-|2\.12|
|**Device.​Cellular.​Interface.​{i}.​Stats.**|**object**|**-**|<p>**Throughput statistics for this interface.**</p><p>**The CPE MUST reset the interface's Stats parameters (unless otherwise stated in individual object or parameter descriptions) either when the interface becomes operationally down due to a previous administrative down (i.e. the interface's *Status* parameter transitions to a down state after the interface is disabled) or when the interface becomes administratively up (i.e. the interface's *Enable* parameter transitions from *false* to *true*). Administrative and operational interface status is discussed in [Section 4.2.2/[TR-181i2]()].**</p>|**-**|**2.12**|
|BytesSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of bytes transmitted out of the interface, including framing characters.|-|2\.12|
|BytesReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of bytes received on the interface, including framing characters.|-|2\.12|
|PacketsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets transmitted out of the interface.|-|2\.12|
|PacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets received on the interface.|-|2\.12|
|ErrorsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of outbound packets that could not be transmitted because of errors.|-|2\.12|
|ErrorsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of inbound packets that contained errors preventing them from being delivered to a higher-layer protocol.|-|2\.12|
|UnicastPacketsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets requested for transmission which were not addressed to a multicast or broadcast address at this layer, including those that were discarded or not sent.|-|2\.12|
|UnicastPacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of received packets, delivered by this layer to a higher layer, which were not addressed to a multicast or broadcast address at this layer.|-|2\.12|
|DiscardPacketsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of outbound packets which were chosen to be discarded even though no errors had been detected to prevent their being transmitted. One possible reason for discarding such a packet could be to free up buffer space.|-|2\.12|
|DiscardPacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of inbound packets which were chosen to be discarded even though no errors had been detected to prevent their being delivered. One possible reason for discarding such a packet could be to free up buffer space.|-|2\.12|
|MulticastPacketsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets that higher-level protocols requested for transmission and which were addressed to a multicast address at this layer, including those that were discarded or not sent.|-|2\.12|
|MulticastPacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of received packets, delivered by this layer to a higher layer, which were addressed to a multicast address at this layer.|-|2\.12|
|BroadcastPacketsSent|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets that higher-level protocols requested for transmission and which were addressed to a broadcast address at this layer, including those that were discarded or not sent.|-|2\.12|
|BroadcastPacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of received packets, delivered by this layer to a higher layer, which were addressed to a broadcast address at this layer.|-|2\.12|
|UnknownProtoPacketsReceived|unsignedLong|-|[[*StatsCounter64*]()] The total number of packets received via the interface which were discarded because of an unknown or unsupported protocol.|-|2\.12|
|**Device.​Cellular.​AccessPoint.​{i}.**|**object​[0:]**|**W**|<p>**Cellular Access Point table. Each entry is identified by an *APN* (Access Point Name) that identifies a gateway between the mobile network and another computer network.**</p><p>**At most one entry in this table can exist with a given value for *Alias*, or with a given value for *APN*, or with a given value for *Interface*.**</p>|**-**|**2.12**|
|Enable|boolean|W|Enables or disables the Access Point.|-|2\.12|
|Alias|string​(64)|WO|<p>[[*Alias*]()] A non-volatile unique key used to reference this instance. Alias provides a mechanism for a Controller to label this instance for future reference.</p><p>The following mandatory constraints MUST be enforced:</p><p>- The value MUST NOT be empty.</p><p>- The value MUST start with a letter.</p><p>- If the value is not assigned by the Controller at creation time, the Agent MUST assign a value with an "cpe-" prefix.</p><p>If the value isn't assigned by the Controller on creation, the Agent MUST choose an initial value that doesn't conflict with any existing entries.</p><p>This is a non-functional key and its value MUST NOT change once it's been assigned by the Controller or set internally by the Agent.</p>|-|2\.8|
|APN|string​(64)|W|<p>Access Point Name.</p><p>If the value isn't assigned by the Controller on creation, the Agent MUST choose an initial value that doesn't conflict with any existing entries.</p>|-|2\.12|
|Username|string​(256)|W|Username used to authenticate the CPE when making a connection to the Access Point.|-|2\.12|
|Password|string​(256)|W|<p>Password used to authenticate the CPE when making a connection to the Access Point.</p><p>When read, this parameter returns an empty string, regardless of the actual value, unless the Controller has a "secured" role.</p>|-|2\.12|
|Proxy|string​(45)|W|[[*IPAddress*]()] Proxy server IP address.|-|2\.12|
|ProxyPort|unsignedInt​(1:65535)|W|Proxy server port.|-|2\.12|
|Interface|string|W|<p>The value MUST be the Path Name of a row in the *Interface* table. Reference to the interface with which the access point is associated.</p><p>If the value isn't assigned by the Controller on creation, the Agent MUST choose an initial value that doesn't conflict with any existing entries.</p>|-|2\.12|
## <a name="cellularmanagement-low-levelapi"></a>**Low-Level API**
The Cellular Manager uses the libmm library to communicate with ModemManager. ModemManager itself provides its own low-level API, enabling direct interaction with the modem hardware and drivers.
## <a name="cellularmanagement-api"></a>**API**
The system uses the **TR-181i2-v2.18.1** data model, extended with vendor-specific extensions to support additional cellular and network configurations.
## <a name="cellularmanagement-files"></a>**Files**
## <a name="cellularmanagement-firewall"></a>**Firewall**
The WAN Modem Manager is responsible for linking the TR-181 network interfaces and applying the correct firewall configuration
## <a name="cellularmanagement-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="cellularmanagement-dependants"></a>**Dependants**
The TR-181 IP, Ethernet, DNS, and Routing Manager have been adapted to utilize information exposed by the Cellular NetModel plugin. However, they do not have any compile-time or runtime dependencies on the TR181 Cellular Manager or the Cellular NetModule MIB module.
### <a name="cellularmanagement-dependencies"></a>**Dependencies**
#### <a name="cellularmanagement-tr181cellulardependencieslist"></a>**TR181 Cellular dependencies list**
Compile-time dependencies

The following libraries and modules are required during the compile phase:

- **libamxb**
- **libamxc**
- **libamxd**
- **libamxm**
- **libamxo**
- **libamxp**
- **libsahtrace**
- **libnetmodel**

Runtime Dependencies

The following libraries and modules are required during the runtime phase:

- **libamxb**
- **libamxc**
- **libamxd**
- **libamxm**
- **libamxo**
- **libamxp**
- **libsahtrace**
- **libnetmodel**
- **amxrt**
- **mod-dmstats**
- **mod-netmodel**
#### <a name="cellularmanagement-netmodelcellulardependencieslist"></a>**NetModel Cellular dependencies list**
Compile-time dependencies

The following libraries are required during the compile phase:

- libamxc
- libamxp
- libamxd
- libamxb
- libamxo
- libamxs
- libamxm
- libsahtrace
- libnetmodel

The following libraries and modules are required during the runtime phase:

Runtime Dependencies

- libamxc
- libamxp
- libamxd
- libamxb
- libamxo
- libamxs
- libamxm
- libsahtrace
- libnetmodel
## <a name="cellularmanagement-configuration"></a>**Configuration**
Currently the WAN mode manager is not capable of automatically reconfiguring and detecting cellular interfaces.

To use the cellular interfaces as the WAN connection, the following reconfiguration must be applied manually.

Factory Default WAN Setup

By default, the WAN interface is configured for Ethernet connections. The default settings are:

IP.Interface.2.LowerLayers=Device.Ethernet.Link.2

IP.Interface.2.IPv4Address.1.AddressingType=DHCP

Routing.Router.1.IPv4Forwarding.1.Origin=DHCPv4

Explanation of the changes:

- IP.Interface.wan.LowerLayers points to Ethernet Link 3.
- IP.Interface.wan.IPv4Address.1.AddressingType is set to DHCP, meaning the WAN interface expects to obtain an IP address via DHCP.
- Routing.Router.1.IPv4Forwarding.1.Origin specifies that routing is derived from DHCPv4.

Using Cellular Interface as WAN

To use the cellular interface instead of Ethernet for WAN, the following reconfiguration must be applied:

Cellular.AccessPoint.1.APN="orangedefault"

IP.Interface.2.LowerLayers=Device.Ethernet.Link.3

IP.Interface.2.IPv4Address.1.AddressingType=3GPP-NAS

Routing.Router.1.IPv4Forwarding.1.Origin=3GPP-NAS

Explanation of the changes:

- Cellular.AccessPoint.1.APN: Sets the Access Point Name (APN) for the cellular connection. In this example, the APN is "orangedefault".
- IP.Interface.wan.LowerLayers: Changes the WAN interface to point to **Ethernet Link 2**, which is associated with the cellular modem.
- IP.Interface.wan.IPv4Address.1.AddressingType: Specifies 3GPP-NAS to use the 3GPP NAS (Non-Access Stratum) protocol for IP addressing.
- Routing.Router.1.IPv4Forwarding.1.Origin: Sets the routing origin to 3GPP-NAS for proper routing through the cellular interface.
## <a name="cellularmanagement-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
N/A
## <a name="cellularmanagement-webui"></a>**Web UI**
N/A
# <a name="cellularmanagement-considerations"></a>**Considerations**
## <a name="cellularmanagement-ipv6"></a>**IPv6**
IPv6 support is currently out of scope for the ModemManager configuration with prplOS, though ModemManager itself supports IPv6.

The Orange Belgium network used for testing does not provide IPv6 connectivity. Plans are in place to reconfigure the in-house SoftAtHome femtocell for IPv6 support.

The next steps include extracting IPv6 information from the cellular bearer using ModemManager and updating the NeMo modules to push this data to relevant prplOS middleware components, such as the IP, Routing, and DNS managers.
## <a name="cellularmanagement-packetacceleration"></a>**Packet Acceleration**
Not tested.
## <a name="cellularmanagement-memoryusage"></a>**Memory Usage**
The following memory usage metrics have been observed for the relevant components:

- **ModemManager**: RSS – **9.6 MB**
- **Cellular Manager**: RSS – **7.8 MB**

![Screenshot 2024-12-16 at 15.49.48.png](image/memory_usage.png) 
## <a name="cellularmanagement-boottime"></a>**Boot Time**
Not measured.
## <a name="cellularmanagement-security"></a>**Security**
N/A
## <a name="cellularmanagement-remotemanagement"></a>**Remote Management**
Remote management of the cellular interface can be achieved using **CWMP** (CPE WAN Management Protocol) or **USP** (User Services Platform).

Both protocols can read and configure parameters defined in the **Device.Cellular** section of the **TR-181i2-v2.18.1** data model.
## <a name="cellularmanagement-operationalmonitoring"></a>**Operational Monitoring**
The following components should be active monitored for maintaining a reliable cellular connectivity:

- **D-Bus**
- **ModemManager**
- **Cellular Manager**

It would also be highly advisable to monitor the connection and the reachability of the next hop.

This extra step of monitoring is currently not implemented. It would be advisable to integrate it into a more general connection tracking service that could be used to also monitor other WAN interfaces technologies.
# <a name="cellularmanagement-quality"></a>**Quality**
## <a name="cellularmanagement-projectreferenceconfiguration"></a>**Project Reference Configuration**
N/A
## <a name="cellularmanagement-build-timechecks"></a>**Build-time Checks**
N/A
## <a name="cellularmanagement-run-timechecks"></a>**Run-time Checks**
N/A
## <a name="cellularmanagement-unittests"></a>**Unit Tests**
N/A
## <a name="cellularmanagement-logginganddebugging"></a>**Logging and Debugging**
N/A
## <a name="cellularmanagement-functionaltests"></a>**Functional Tests**
Test that the network configuration provided by the cellular network via 3GPP NAS signaling that is made available through ModemManager is properly applied to the rest of the system

To verify the proper setup, use the following test procedure:

1. **Verify Network Interface**: Ensure the bearer is properly configured by checking the mmcli output for the wwan0 interface.
```
   root@prplOS:/# mmcli -b 0

   Confirm the output shows that the connection is connected and interface is wwan0. 

   Example:

   Status | connected: yes Interface | wwan0 IPv4 configuration | address: 10.199.56.36
```
1. **Check Cellular Manager Configuration**: Verify that the Cellular.Interface.1 parameters are properly set by querying:
```
   > Cellular.Interface.1.?

   Ensure values such as IMEI, RSRP, RSRQ, Status, and NetworkInUse are correctly reported. Example:

   Cellular.Interface.1.IMEI="868371051413371" Cellular.Interface.1.Status="Up"
```
1. **Validate Logical Interface**: Check that the logical interface wan is enabled and mapped to the correct lower layer.
```
   > Device.Logical.Interface.1.?

   Confirm the LowerLayers and Status match the expected configuration.
```
1. **Test IPv4 Configuration**: Ensure that the IP configuration is correct.
```
   > IP.Interface.2.?

   Verify the IPv4Address is 10.199.56.36 and the correct subnet and gateway are set, and that the AddressingType parameter is set to 3GPP-NAS.
```
1. **Verify Ethernet Link**: Confirm that the wwan0 interface is up and correctly linked to the cellular interface.
```
   > Device.Ethernet.Link.3.?

   Ensure that the link is Up and the MACAddress is as expected.
```
1. **Check Routing**: Validate that the router forwards IPv4 packets correctly.
```
   > Routing.Router.1.?

   Ensure IPv4Forwarding is enabled with the correct GatewayIPAddress and Interface, and that the Origin parameter is set to 3GPP-NAS.
```
1. **DNS Configuration**: Verify that the DNS relay settings are correctly applied.
```
   > DNS.Relay.Forwarding.?
```
   Ensure the DNSServer is configured with valid addresses such as 212.224.129.90 and 212.224.129.94, and that the Type parameter is set to 3GPP-NAS.
## <a name="cellularmanagement-citests"></a>**CI Tests**
N/A
## <a name="cellularmanagement-certification"></a>**Certification**
N/A
# <a name="cellularmanagement-designreviewdocumentation"></a>**Design Review Documentation**
