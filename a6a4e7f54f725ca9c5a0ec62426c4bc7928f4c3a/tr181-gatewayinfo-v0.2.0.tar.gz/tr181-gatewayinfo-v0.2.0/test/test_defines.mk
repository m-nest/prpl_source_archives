MACHINE = $(shell $(CC) -dumpmachine)

SRCDIR = $(realpath ../../src)
SRVSRCDIR = $(realpath ../../src/server)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR = $(realpath ../../include_priv)
MOCK_SRCDIR = $(realpath ../common/)

HEADERS = $(wildcard $(INCDIR)/*.h)
SOURCES = $(wildcard $(SRCDIR)/*.c)
SOURCES += $(wildcard $(SRVSRCDIR)/*.c)
SOURCES += $(wildcard $(MOCK_SRCDIR)/*.c)

CFLAGS += -Werror -Wall -Wextra -Wno-attributes\
          --std=gnu99 -g3 -Wmissing-declarations \
		  $(addprefix -I ,$(INCDIR)) -I$(OBJDIR)/.. \
		  -fkeep-inline-functions -fkeep-static-functions \
		  -Wno-format-nonliteral \
		   -fprofile-abs-path \
		  -DSAHTRACES_ENABLED -DSAHTRACES_LEVEL_DEFAULT=500 \
		  $(shell pkg-config --cflags cmocka) -pthread -DUNIT_TEST \
		  -DSUPPORT_MQTT_MTP -DSUPPORT_STOMP_MTP -DIGNORE_STACK_REFERENCE

LDFLAGS += -fkeep-inline-functions -fkeep-static-functions \
		   $(shell pkg-config --libs cmocka) \
		   -lamxb -lamxc -lamxd -lamxo -lamxp -lamxj -lamxut \
		   -lsahtrace -ldl -lpthread -lnetmodel -luriparser -lamxrt
