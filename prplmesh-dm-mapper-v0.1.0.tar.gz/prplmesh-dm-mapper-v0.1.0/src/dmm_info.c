/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_info.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contain methods for creation or deletion and manipulation with
 *          Mapping node structure.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#include <stdlib.h>

#include "dmm.h"
#include "dmm_info.h"


/**
 * @brief Deletes a child request associated with a list item.
 *
 * This function is used as a callback to clean up the list of child requests.
 * It retrieves the map_info_t structure from the list iterator and calls dmm_delete_info to delete it.
 *
 * @param it The amxc_llist_it_t* iterator pointing to the element containing map_info_t.
 */
static void dmm_delete_child_request(amxc_llist_it_t* it) {
    map_info_t* info = amxc_container_of(it, map_info_t, it);
    dmm_delete_info(&info);
}

void dmm_reply_transl_data(map_info_t* minfo, amxc_var_t* data) {
    when_null(minfo, exit);
    when_null(data, exit);

    const char* real_obj = dmm_get_translate_path(minfo->map_obj);
    amxd_object_t* obj = amxd_dm_findf(dmm_get_dm(), "%s", minfo->map_obj);
    amxc_var_t* eobject = GET_ARG(data, "eobject");
    amxc_var_t* object = GET_ARG(data, "object");
    amxc_var_t* path = GET_ARG(data, "path");
    amxc_var_t* name = GET_ARG(data, "name");
    char* stripped = NULL;
    char* p = NULL;

    amxc_string_t mapping_path;
    amxc_string_init(&mapping_path, 128);

    stripped = dmm_strip_mapped(real_obj, GET_CHAR(path, NULL));
    amxc_string_setf(&mapping_path, "%s%s", minfo->map_obj, stripped);
    if((name != NULL) && (stripped != NULL) && (*stripped == 0)) {
        amxc_var_set(cstring_t, name, amxd_object_get_name(obj, 0));
    }
    free(stripped);
    amxc_var_set(cstring_t, path, amxc_string_get(&mapping_path, 0));

    stripped = dmm_strip_mapped(real_obj, GET_CHAR(object, NULL));
    p = amxd_object_get_path(obj, AMXD_OBJECT_TERMINATE);
    amxc_string_setf(&mapping_path, "%s%s", p, stripped);
    free(stripped);
    free(p);
    amxc_var_set(cstring_t, object, amxc_string_get(&mapping_path, 0));

    if(eobject != NULL) {
        stripped = dmm_strip_mapped(real_obj, GET_CHAR(eobject, NULL));
        p = amxd_object_get_path(obj, AMXD_OBJECT_TERMINATE | AMXD_OBJECT_EXTENDED);
        amxc_string_setf(&mapping_path, "%s%s", p, stripped);
        free(stripped);
        free(p);
        amxc_var_set(cstring_t, eobject, amxc_string_get(&mapping_path, 0));
    }

    amxc_var_move(&minfo->ret, data);
    amxc_string_clean(&mapping_path);

exit:
    return;
}

int dmm_new_info(map_info_t** minfo, const char* map_obj) {
    int retval = -1;

    when_null(minfo, exit);

    *minfo = (map_info_t*) calloc(1, sizeof(map_info_t));
    when_null(*minfo, exit);

    (*minfo)->map_obj = map_obj;
    (*minfo)->refs = 1;

    amxc_llist_init(&(*minfo)->child_requests);
    amxc_var_init(&(*minfo)->ret);

    retval = 0;

exit:
    return retval;
}

int dmm_delete_info(map_info_t** minfo) {
    int retval = -1;

    when_null(minfo, exit);

    retval = --(*minfo)->refs;

    if((*minfo)->refs <= 0) {
        amxb_close_request(&(*minfo)->request);
        amxc_var_clean(&(*minfo)->ret);
        amxc_llist_it_take(&(*minfo)->it);
        amxc_llist_clean(&(*minfo)->child_requests, dmm_delete_child_request);
        if((*minfo)->wait_timer != NULL) {
            amxp_timer_delete(&(*minfo)->wait_timer);
            // garbage collect deleted timers
            amxp_timers_check();
        }
        free(*minfo);
        *minfo = NULL;
    }

exit:
    return retval;
}

void dmm_info_refs_inc(map_info_t* minfo, int refs) {
    when_null(minfo, exit);

    minfo->refs += refs;

exit:
    return;
}
