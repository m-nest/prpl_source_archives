#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_validate_auth.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        // test dm
        cmocka_unit_test_setup_teardown(test_allow_new_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_block_new_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_allow_all_devices, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_allow_blocked_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_block_changed_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_allow_existing_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_block_existing_device, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_block_existing_device_after_emptying_allowed_devices, test_setup, test_teardown),
        cmocka_unit_test_setup_teardown(test_block_device_after_disable_allowed_device, test_setup, test_teardown),
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
