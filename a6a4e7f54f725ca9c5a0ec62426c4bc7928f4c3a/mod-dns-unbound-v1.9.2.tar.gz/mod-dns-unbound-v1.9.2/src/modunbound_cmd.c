/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <arpa/inet.h>  // inet_pton, AF_INET, AF_INET6

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_dir.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "modunbound.h"
#include "modunbound_cmd.h"

#define IGNORE_VALIDATION_ERROR true
#define THROW_VALIDATION_ERROR false
#define INTERFACE_LIST_POSITION 6000 //Big number in order to add at the end of the interface list. Usually the list is maximum 4, just put 6000 to be sure, no specific reason for the number.

/**
 * @brief Build the reverse-DNS owner name for an IP address.
 *
 * @details
 * In the TR-181 DNS Hosts model this module not only injects forward records (A/AAAA) for hosts
 * into Unbound, it also creates matching PTR records so reverse lookups work for locally managed hosts.
 * Unbound expects PTR records to be stored under the reverse lookup tree:
 *
 * - IPv4: `<d>.<c>.<b>.<a>.in-addr.arpa.`
 * - IPv6: `<nibble>.<nibble>....ip6.arpa.` (32 nibbles in reverse order)
 *
 * This helper converts a textual IPv4/IPv6 address into that owner name, including the trailing dot,
 * so the caller can add/remove PTR records via `unbound-control` (wrapped by the `UnboundControl` ubus RPC).
 *
 * @param[in] ip Textual IPv4 or IPv6 address.
 *
 * @return Newly allocated reverse lookup name (must be freed by the caller) or @c NULL when @p ip is
 *         empty or not a valid IP address.
 *
 * @note The returned string is allocated with @c malloc and must be released with @c free (or the
 *       project's @c FREE macro).
 */
static char* reverted_ip_address(const char* ip) {
    uint8_t ipv4_bytes[4] = {0};
    uint8_t ipv6_bytes[16] = {0};
    char* out = NULL;
    char* ret = NULL;
    int need = 0;
    size_t len = 0;
    size_t pos = 0;
    int is_ipv4 = 0;
    int is_ipv6 = 0;
    int byte_index = 0;
    uint8_t current_byte = 0;
    static const char hexd[] = "0123456789abcdef";
    static const char suffix[] = "ip6.arpa.";

    when_str_empty(ip, exit);

    /* IPv4 */
    is_ipv4 = inet_pton(AF_INET, ip, ipv4_bytes);
    if(is_ipv4 == 1) {
        need = snprintf(NULL, 0, "%u.%u.%u.%u.in-addr.arpa.",
                        (unsigned) ipv4_bytes[3], (unsigned) ipv4_bytes[2],
                        (unsigned) ipv4_bytes[1], (unsigned) ipv4_bytes[0]);
        when_true(need < 0, exit);

        out = (char*) malloc((size_t) need + 1U);
        when_null(out, exit);

        (void) snprintf(out, (size_t) need + 1U, "%u.%u.%u.%u.in-addr.arpa.",
                        (unsigned) ipv4_bytes[3], (unsigned) ipv4_bytes[2],
                        (unsigned) ipv4_bytes[1], (unsigned) ipv4_bytes[0]);

        ret = out;
        goto exit;
    }

    /* IPv6 */
    is_ipv6 = inet_pton(AF_INET6, ip, ipv6_bytes);
    if(is_ipv6 == 1) {
        /* 32 nibbles + 32 dots + "ip6.arpa." + NUL = 32 + 32 + 9 + 1 = 74 */
        len = 32U + 32U + sizeof(suffix);
        out = (char*) malloc(len);
        when_null(out, exit);

        pos = 0U;
        for(byte_index = 15; byte_index >= 0; --byte_index) {
            current_byte = ipv6_bytes[byte_index];
            out[pos++] = hexd[(unsigned) (current_byte & 0x0FU)];        //low nibble
            out[pos++] = '.';
            out[pos++] = hexd[(unsigned) ((current_byte >> 4) & 0x0FU)]; // high nibble
            out[pos++] = '.';
        }
        /* Append "ip6.arpa." including the NUL byte */
        (void) memcpy(out + pos, suffix, sizeof(suffix));

        ret = out;
    }
exit:
    return ret;
}

/**
 * @brief Check whether a hostname is a "base" local name (no domain suffix).
 *
 * @details
 * TR-181 host entries may be configured as simple names (e.g. `"printer"`) while an interface also
 * advertises a LAN domain (e.g. `"lan"`). In that scenario the module wants Unbound to answer both:
 * `"printer"` and `"printer.lan"`.
 *
 * This function returns @c true when the input contains neither '.' nor ':' characters, meaning:
 * - it is not a fully qualified name (`.`), and
 * - it is not an IPv6 literal (`:`).
 *
 * The result is used to decide whether an additional record for `<hostname>.<domain_name>` must be
 * added/removed alongside the base hostname.
 *
 * @param[in] address Hostname to test.
 *
 * @return @c true when @p address looks like a base local hostname, otherwise @c false.
 */
bool is_local_hostname_base(const char* address) {
    if(string_empty(address)) {
        return false;
    }
    return strpbrk(address, ".:") == NULL;
}

/**
 * @brief Apply runtime resolver timeout parameters to a running Unbound instance.
 *
 * @details
 * When TR-181 updates forwarding settings, the plugin may also update operational parameters such as
 * query timeout and retry count. This function translates those high-level knobs into the
 * `unbound-control` command `timeout_repeat <timeout> <repeat>` and executes it through the
 * `UnboundControl(cmd=<command>)` ubus RPC.
 *
 * @param[in] intf      Interface/view identifier used to locate the Unbound instance.
 * @param[in] timeout   Timeout value passed to `unbound-control timeout_repeat`.
 * @param[in] repeat    Retry count passed to `unbound-control timeout_repeat`.
 * @param[in] zone_name Zone context used for logging/tracing (not part of the command).
 *
 * @return @c unbound_ok when the command succeeded, otherwise an appropriate @ref unbound_status_t.
 *
 * @note This function only changes the live Unbound instance; persistent configuration updates are handled elsewhere.
 */
unbound_status_t cmd_set_server_parameters(const char* intf, int timeout, int repeat, const char* zone_name) {
    unbound_status_t status = unbound_other_error;
    amxc_string_t cmd;

    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "timeout_repeat %d %d", timeout, repeat);

    status = unbound_call_ok(intf, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "failed to update timeout_repeat (zone=%s)", zone_name);

exit:
    amxc_string_clean(&cmd);
    return status;
}

/**
 * @brief Add local DNS records (and optional reverse PTRs) for a host into Unbound.
 *
 * @details
 * High-level TR-181 host configuration (typically `DNS.Zone`) must be reflected in Unbound so
 * clients can resolve local names immediately, without a daemon restart. This function builds a
 * single batched `unbound-control` command that injects multiple local-data records into the target
 * Unbound "view" (identified by @p interface):
 *
 * - Forward mapping:
 *   - `A` records for each IPv4 address
 *   - `AAAA` records for each IPv6 address
 * - Reverse mapping:
 *   - `PTR` records under `in-addr.arpa.` / `ip6.arpa.` pointing back to the hostname
 * - Local domain duplication:
 *   - When @p hostname is a base name (see @ref is_local_hostname_base) and @p domain_name is set,
 *     matching records are also created for `<hostname>.<domain_name>`.
 *
 * The command is sent through `UnboundControl(cmd=<command>)`. Success is validated by expecting the
 * `"added"` token in the response.
 *
 * @param[in] interface            Interface/view identifier used to locate the Unbound instance.
 * @param[in] hostname             Hostname to publish (base name or FQDN).
 * @param[in] domain_name          Optional domain suffix used when duplicating base hostnames.
 * @param[in] ipv4_addresses       Variant list containing IPv4 address strings (may be empty).
 * @param[in] ipv6_addresses       Variant list containing IPv6 address strings (may be empty).
 * @param[in] accept_empty_address When @c true and both address lists are empty, no command is sent
 *                                 and @c unbound_ok is returned.
 *
 * @return @c unbound_ok when the records were successfully applied (or skipped due to
 *         @p accept_empty_address), otherwise an appropriate @ref unbound_status_t.
 *
 * @note PTR entries are only added when the IP address can be converted to a reverse owner name.
 *       Invalid IP strings therefore still allow forward records to be added, but without PTRs.
 */
unbound_status_t cmd_add_host(const char* interface, const char* hostname, const char* domain_name,
                              amxc_var_t* ipv4_addresses, amxc_var_t* ipv6_addresses, bool accept_empty_address) {
    unbound_status_t status = unbound_other_error;
    bool has_addresses = false;
    amxc_var_t str_list;
    cstring_t reversed_addr = NULL;
    amxc_string_t cmd;
    bool is_local = is_local_hostname_base(hostname);

    amxc_string_init(&cmd, 0);
    amxc_var_init(&str_list);
    amxc_var_set_type(&str_list, AMXC_VAR_ID_LIST);

    when_str_empty(interface, exit);
    when_str_empty(hostname, exit);

    has_addresses = (NULL != amxc_var_get_first(ipv4_addresses)) || (NULL != amxc_var_get_first(ipv6_addresses));
    if(!accept_empty_address) {
        when_false(has_addresses, exit);
    } else {
        when_false_status(has_addresses, exit, status = unbound_ok);
    }

    amxc_string_setf(&cmd, "view_local_datas2 %s", interface);
    amxc_var_for_each(var, ipv4_addresses) {
        const char* ip_address = GET_CHAR(var, NULL);
        amxc_string_appendf(&cmd, ",%s IN A %s", hostname, ip_address);
        reversed_addr = reverted_ip_address(ip_address);
        if(!string_empty(reversed_addr)) {
            amxc_string_appendf(&cmd, ",%s IN PTR %s", reversed_addr, hostname);
        }
        if(is_local && !string_empty(domain_name)) {
            amxc_string_appendf(&cmd, ",%s.%s IN A %s", hostname, domain_name, ip_address);
            if(!string_empty(reversed_addr)) {
                amxc_string_appendf(&cmd, ",%s IN PTR %s.%s", reversed_addr, hostname, domain_name);
            }
        }
        FREE(reversed_addr);
    }
    amxc_var_for_each(var, ipv6_addresses) {
        const char* ip_address = GET_CHAR(var, NULL);
        reversed_addr = reverted_ip_address(ip_address);
        amxc_string_appendf(&cmd, ",%s IN AAAA %s", hostname, ip_address);
        if(!string_empty(reversed_addr)) {
            amxc_string_appendf(&cmd, ",%s IN PTR %s", reversed_addr, hostname);
        }
        if(is_local && !string_empty(domain_name)) {
            amxc_string_appendf(&cmd, ",%s.%s IN AAAA %s", hostname, domain_name, ip_address);
            if(!string_empty(reversed_addr)) {
                amxc_string_appendf(&cmd, ",%s IN PTR %s.%s", reversed_addr, hostname, domain_name);
            }
        }
        FREE(reversed_addr);
    }

    amxc_var_add(cstring_t, &str_list, "added");

    status = unbound_call_expected(interface, amxc_string_get(&cmd, 0), &str_list, THROW_VALIDATION_ERROR);
    when_failed_trace(status, exit, ERROR, "failed to add host(s)");

exit:
    amxc_string_clean(&cmd);
    amxc_var_clean(&str_list);
    return status;
}

/**
 * @brief Remove the reverse PTR local-data entry associated with an IP address.
 *
 * @details
 * When a host is added via @ref cmd_add_host, a matching PTR record may be created under the reverse
 * tree (`in-addr.arpa.` / `ip6.arpa.`). Unbound stores these as normal local-data records. This
 * helper computes the reverse owner name and issues:
 *
 * `view_local_data_remove <interface> <reverse-owner>`
 *
 * through the `UnboundControl` RPC.
 *
 * @param[in] interface Interface/view identifier used to locate the Unbound instance.
 * @param[in] ipaddr    Textual IPv4/IPv6 address for which the PTR owner name should be removed.
 *
 * @return A value compatible with @ref unbound_status_t (typically @c unbound_ok on success).
 *
 * @note This is an internal helper; callers typically ignore failures because reverse entries are
 *       treated as best-effort cleanup.
 */
static int cmd_view_local_data_remove_reversed(const char* interface, const char* ipaddr) {
    unbound_status_t status = unbound_other_error;
    amxc_string_t cmd;
    cstring_t reversed_addr = NULL;

    amxc_string_init(&cmd, 0);

    when_str_empty(interface, exit);
    when_str_empty(ipaddr, exit);

    reversed_addr = reverted_ip_address(ipaddr);

    amxc_string_setf(&cmd, "view_local_data_remove %s %s", interface, reversed_addr);

    status = unbound_call_ok(interface, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "failed to remove host(s)");

exit:
    amxc_string_clean(&cmd);
    FREE(reversed_addr);
    return status;
}

/**
 * @brief Remove all local-data records associated with a hostname in a given view.
 *
 * @details
 * This helper deletes the local-data entry for a hostname previously created via
 * @ref cmd_add_host by invoking:
 *
 * `view_local_data_remove <interface> <hostname>[.<domain_name>]`
 *
 * through the `UnboundControl` RPC.
 *
 * @param[in] interface   Interface/view identifier used to locate the Unbound instance.
 * @param[in] hostname    Hostname to remove.
 * @param[in] domain_name Optional suffix to append to @p hostname before removal.
 *
 * @return A value compatible with @ref unbound_status_t (typically @c unbound_ok on success).
 */
static int cmd_view_local_data_remove(const char* interface, const char* hostname, const char* domain_name) {
    unbound_status_t status = unbound_other_error;
    amxc_string_t cmd;

    amxc_string_init(&cmd, 0);

    when_str_empty(interface, exit);
    when_str_empty(hostname, exit);

    amxc_string_setf(&cmd, "view_local_data_remove %s %s", interface, hostname);
    if(!string_empty(domain_name)) {
        amxc_string_appendf(&cmd, ".%s", domain_name);
    }

    status = unbound_call_ok(interface, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "failed to remove host(s)");

exit:
    amxc_string_clean(&cmd);
    return status;
}

/**
 * @brief Remove local DNS records (and associated PTRs) for a host from Unbound.
 *
 * @details
 * This function performs the inverse operation of @ref cmd_add_host for a running Unbound instance:
 *
 * 1. Remove the forward-name local-data for @p hostname.
 * 2. If @p hostname is a base name and @p domain_name is set, also remove `<hostname>.<domain_name>`.
 * 3. For each configured IPv4/IPv6 address, remove the corresponding reverse owner entry (PTR) using
 *    @ref cmd_view_local_data_remove_reversed.
 *
 * The forward-name removals are treated as the primary operation; reverse removals are executed as a
 * best-effort cleanup.
 *
 * @param[in] interface      Interface/view identifier used to locate the Unbound instance.
 * @param[in] hostname       Hostname whose records must be removed.
 * @param[in] domain_name    Optional domain suffix used when removing base hostnames.
 * @param[in] ipv4_addresses Variant list containing IPv4 address strings (may be empty).
 * @param[in] ipv6_addresses Variant list containing IPv6 address strings (may be empty).
 *
 * @return Status of the forward-name removal step(s): @c unbound_ok on success, otherwise an
 *         appropriate @ref unbound_status_t.
 *
 * @note Failures while removing PTR records do not change the returned status.
 */
unbound_status_t cmd_remove_host(const char* interface, const char* hostname, const char* domain_name,
                                 amxc_var_t* ipv4_addresses, amxc_var_t* ipv6_addresses) {
    unbound_status_t status = unbound_other_error;
    bool is_local = is_local_hostname_base(hostname);

    status = cmd_view_local_data_remove(interface, hostname, NULL);
    when_failed(status, exit);

    if(is_local && !string_empty(domain_name)) {
        cmd_view_local_data_remove(interface, hostname, domain_name);
    }

    amxc_var_for_each(var, ipv4_addresses) {
        const char* ip_address = GET_CHAR(var, NULL);
        cmd_view_local_data_remove_reversed(interface, ip_address);
    }

    amxc_var_for_each(var, ipv6_addresses) {
        const char* ip_address = GET_CHAR(var, NULL);
        cmd_view_local_data_remove_reversed(interface, ip_address);
    }

exit:
    return status;
}

/**
 * @brief Flush Unbound's in-flight request list for an interface/view.
 *
 * @details
 * Unbound keeps forwarder information associated with ongoing queries. After changing the forwarder
 * configuration (for example due to a new DHCP offer), the module flushes this request list so active
 * queries do not keep using stale forwarders.
 *
 * This helper executes `flush_requestlist` through the `UnboundControl` RPC.
 *
 * @param[in] interface Interface/view identifier used to locate the Unbound instance.
 *
 * @return @c unbound_ok when the command succeeded, otherwise an appropriate @ref unbound_status_t.
 */
static unbound_status_t cmd_flush_requestlist(const char* interface) {
    unbound_status_t status = unbound_other_error;
    amxc_string_t cmd;

    amxc_string_init(&cmd, 0);
    amxc_string_set(&cmd, "flush_requestlist");

    when_str_empty(interface, exit);

    status = unbound_call_ok(interface, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "Failed to flush ongoing requestlist");

exit:
    amxc_string_clean(&cmd);
    return status;
}

/**
 * @brief Configure (add/update/remove) forwarders for a specific DNS zone in Unbound.
 *
 * @details
 * TR-181 forwarding rules (typically `DNS.Relay.Forwarding` / forwarding configuration) are mapped to
 * Unbound forward-zone settings. This function updates the live Unbound instance by issuing either:
 *
 * - `forward_add <zone> <server1> <server2> ...` when at least one server is provided, or
 * - `forward_remove <zone>` when the server list is empty.
 *
 * The @p servers input is first normalized via @c aggregate_servers() to deduplicate entries and to
 * extract each `"server"` value from the Ambiorix variant list.
 *
 * After a successful update, @ref cmd_flush_requestlist is called so any in-flight queries drop their
 * cached forwarder list and immediately start using the new configuration.
 *
 * @param[in] interface Interface/view identifier used to locate the Unbound instance.
 * @param[in] servers   Variant container holding forwarding servers (entries expose a `"server"` key).
 * @param[in] zone_name DNS zone to which the forwarders apply.
 *
 * @return @c unbound_ok when the update (and subsequent requestlist flush) succeeded, otherwise an
 *         appropriate @ref unbound_status_t.
 */
unbound_status_t cmd_forward_set(const char* interface, amxc_var_t* servers, const char* zone_name) {
    unbound_status_t status = unbound_other_error;
    amxc_set_t* set_servers = NULL;
    amxc_string_t cmd;

    amxc_string_init(&cmd, 0);

    when_str_empty(interface, exit);
    when_str_empty(zone_name, exit);

    set_servers = aggregate_servers(servers);

    if(amxc_set_get_first_flag(set_servers) != NULL) {
        amxc_string_setf(&cmd, "forward_add %s", zone_name);
        amxc_set_iterate(address, set_servers) {
            const char* server = address->flag;
            if(string_empty(server)) {
                continue;
            }
            amxc_string_appendf(&cmd, " %s", server);
        }
    } else {
        amxc_string_setf(&cmd, "forward_remove %s", zone_name);
    }

    status = unbound_call_ok(interface, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "failed to update forwarder(s) for zone (%s)", zone_name);

    // ongoing queries have a copy of the forwarder list (e.g. 1.1.1.1)
    // if the settings change (e.g. new dhcp offer has only 8.8.8.8), then the ongoing queries would still use 1.1.1.1
    // so we discard any ongoing queries
    status = cmd_flush_requestlist(interface);

exit:
    amxc_set_delete(&set_servers);
    amxc_string_clean(&cmd);
    return status;
}

/**
 * @brief Remove forwarder configuration for a DNS zone in Unbound.
 *
 * @details
 * This is the explicit "remove" operation for forward-zone configuration. It issues
 * `forward_remove <zone>` through the `UnboundControl` RPC.
 *
 * @param[in] interface Interface/view identifier used to locate the Unbound instance.
 * @param[in] zone_name DNS zone for which forwarding must be removed.
 *
 * @return @c unbound_ok when the command succeeded, otherwise an appropriate @ref unbound_status_t.
 */
unbound_status_t cmd_forward_remove(const char* interface, const char* zone_name) {
    unbound_status_t status = unbound_other_error;
    amxc_string_t cmd;

    amxc_string_init(&cmd, 0);

    when_str_empty(zone_name, exit);
    amxc_string_setf(&cmd, "forward_remove %s", zone_name);

    status = unbound_call_ok(interface, amxc_string_get(&cmd, 0));
    when_failed_trace(status, exit, ERROR, "failed to remove forwards for zone (%s)", zone_name);

exit:
    amxc_string_clean(&cmd);
    return status;
}

/**
 * @brief Flush the Unbound DNS cache for an interface/view.
 *
 * @details
 * When local-data or forwarding settings change, cached answers may delay the visible effect of the
 * configuration update. This helper clears the cache by executing `flush_zone .` (flush everything)
 * through the `UnboundControl` RPC.
 *
 * @param[in] interface Interface/view identifier used to locate the Unbound instance.
 *
 * @return @c unbound_ok when the command succeeded, otherwise an appropriate @ref unbound_status_t.
 */
unbound_status_t cmd_flush_cache(const char* interface) {
    return unbound_call_ok(interface, "flush_zone .");
}