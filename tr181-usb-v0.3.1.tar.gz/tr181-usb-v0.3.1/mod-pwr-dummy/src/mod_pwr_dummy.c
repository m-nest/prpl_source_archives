/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_pwr_dummy.h"

#define ME "mod-pwr-dummy"
#define PWR_CAPABILITIES_DEFAULT "On,Off,LowPower"
#define PWR_STATUS_DEFAULT "On"
#define PWR_MODE_SET_DELAY_MS_DEFAULT 500

static amxp_timer_t* pwr_timer = NULL;

static int pwr_capabilities_get(UNUSED const char* function_name,
                                amxc_var_t* args,
                                amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const char* port_name = GET_CHAR(args, "port_name");
    amxc_string_t capabilities;

    amxc_string_init(&capabilities, 0);

    when_str_empty_trace(port_name, exit, ERROR, "Port name is required to read settings");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    SAH_TRACEZ_INFO(ME, "LL-API will be called to get PowerCapability (port_name : %s)", port_name);

    // low-level implementation goes here

    amxc_string_setf(&capabilities, "%s", PWR_CAPABILITIES_DEFAULT);

    amxc_var_add_key(csv_string_t, ret, "power_capabilities", amxc_string_get(&capabilities, 0));

    rv = 0;
exit:
    amxc_string_clean(&capabilities);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int pwr_status_get(UNUSED const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const char* port_name = GET_CHAR(args, "port_name");
    amxc_string_t status;

    amxc_string_init(&status, 0);

    when_str_empty_trace(port_name, exit, ERROR, "Port name is required to read settings");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    SAH_TRACEZ_INFO(ME, "LL-API will be called to get PowerStatus (port_name : %s)", port_name);

    // low-level implementation goes here

    amxc_string_setf(&status, "%s", PWR_STATUS_DEFAULT);

    amxc_var_add_key(cstring_t, ret, "power_status", amxc_string_get(&status, 0));

    rv = 0;
exit:
    amxc_string_clean(&status);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static int pwr_mode_set(UNUSED const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    const char* port_name = GET_CHAR(args, "port_name");
    const char* power_mode = GET_CHAR(args, "power_mode");
    amxc_string_t status;

    amxc_string_init(&status, 0);

    when_str_empty_trace(port_name, exit, ERROR, "Port name is required to read settings");
    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);

    SAH_TRACEZ_INFO(ME, "LL-API will be called to set PowerStatus (port_name : %s)", port_name);

    rv = amxp_timer_start(pwr_timer, PWR_MODE_SET_DELAY_MS_DEFAULT);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start power mode timer; rv=%d", rv);
        goto exit;
    }

    // low-level implementation goes here

    amxc_string_setf(&status, "%s", power_mode);

    amxc_var_add_key(cstring_t, ret, "power_status", amxc_string_get(&status, 0));

    rv = 0;
exit:
    amxc_string_clean(&status);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

static void pwr_mode_async_set_done(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    int rv = -1;
    amxc_var_t ret;
    amxc_var_t var;
    amxc_var_init(&ret);
    amxc_var_init(&var);

    rv = amxm_execute_function(NULL, MOD_PWR_CTRL, "pwr-async-done", &var, &ret);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to call pwr-async-done; rv=%d", rv);
    }

    amxc_var_clean(&ret);
    amxc_var_clean(&var);
}

static AMXM_CONSTRUCTOR module_start(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_PWR_CTRL);
    amxm_module_add_function(mod, "pwr-capabilities-get", pwr_capabilities_get);
    amxm_module_add_function(mod, "pwr-status-get", pwr_status_get);
    amxm_module_add_function(mod, "pwr-mode-set", pwr_mode_set);

    rv = amxp_timer_new(&pwr_timer, pwr_mode_async_set_done, NULL);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to create power mode timer; rv=%d", rv);
    }

    SAH_TRACEZ_OUT(ME);
    return rv;
}

static AMXM_DESTRUCTOR module_stop(void) {
    SAH_TRACEZ_IN(ME);
    amxp_timer_delete(&pwr_timer);
    SAH_TRACEZ_OUT(ME);
    return 0;
}