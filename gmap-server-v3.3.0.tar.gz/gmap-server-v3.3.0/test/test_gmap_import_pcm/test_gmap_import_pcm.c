/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>

#include "test_gmap_import_pcm.h"
#include "../test_common/test_util.h"
#include "gmaps_devices.h"
#include <gmap/gmap.h>

#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>

#include <amxd/amxd_common.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_macros.h>

#include "gmaps_devices.h"
#include "gmaps_import_pcm.h"

#define TEST_FILES "./test_files"

/**
 * @brief Mocks the mod_pcm_svc default import implementation.
 *
 * @warning
 * This implementation does not actually restore the data, so any verification
 * checks afterwards can't include the actual restored data beyond what the custom
 * gmap-server import implementation can restore.
 *
 * @implements amxd_object_fn_t
 */
static amxd_status_t s_mock_mod_pcm_pcmimport(UNUSED amxd_object_t* object,
                                              UNUSED amxd_function_t* func,
                                              amxc_var_t* args,
                                              UNUSED amxc_var_t* ret) {
    const char* source = mock_type(const char*);
    const char* file = mock_type(const char*);
    int line = mock_type(int);
    amxc_var_t* data = GET_ARG(args, "data");

    _assert_variant_equal_from_file(data, source, file, line);
    return amxd_status_ok;
}

static void _expect_pcm_import(const char* source,
                               const char* file,
                               int line) {
    assert_non_null(source);
    will_return(s_mock_mod_pcm_pcmimport, source);
    will_return(s_mock_mod_pcm_pcmimport, file);
    will_return(s_mock_mod_pcm_pcmimport, line);
}

#define expect_pcm_import(source) _expect_pcm_import(source, __FILE__, __LINE__)

static void s_create_pcmimport_function(void) {
    amxd_object_t* devices_obj = amxd_object_findf(amxd_dm_get_root(amxut_bus_dm()), "Devices.");
    amxd_function_t* function = NULL;
    assert_int_equal(0, amxd_function_new(&function,
                                          "PcmImport",
                                          AMXC_VAR_ID_NULL,
                                          s_mock_mod_pcm_pcmimport));
    assert_int_equal(0, amxd_function_set_attr(function, amxd_fattr_protected, true));
    assert_int_equal(0, amxd_function_new_arg(function, "data", AMXC_VAR_ID_HTABLE, NULL));
    assert_int_equal(0, amxd_function_arg_is_attr_set(function, "data", amxd_aattr_in));
    assert_int_equal(0, amxd_function_arg_is_attr_set(function, "data", amxd_aattr_mandatory));
    assert_int_equal(0, amxd_object_add_function(devices_obj, function));
}

int test_import_setup(void** state) {
    int status = util_setup(state);

    if(status == 0) {
        s_create_pcmimport_function();
    }

    return status;
}

int test_import_teardown(void** state) {
    return util_teardown(state);
}

static int s_call_import(const char* data_file) {
    amxc_var_t* data = amxut_util_read_json_from_file(data_file);

    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_set_key(&args, "data", data, AMXC_VAR_FLAG_COPY);
    int status_call = amxb_call(amxb_be_who_has("Devices"),
                                "Devices.",
                                "Import",
                                &args,
                                &ret,
                                1);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);

    return status_call;
}

/**
 * Checks the entire Devices.Device. data model by comparing it against
 * a json file.
 *
 * @warning
 * The mocked mod_pcm_svc PcmImport function above does not actually restore any
 * data. Therefore, this function is limited to verifying only what is restored
 * by gmap itself.
 * To verify the would-be imported data, see @ref _expect_pcm_import.
 */
static void _expect_devices(const char* expected_file,
                            const char* file,
                            int line) {
    amxc_var_t actual;
    amxc_var_init(&actual);

    amxc_var_set_type(&actual, AMXC_VAR_ID_LIST);
    amxd_object_for_each(instance, it, gmap_dm_get_devices_device()) {
        amxd_object_t* device = amxc_llist_it_get_data(it, amxd_object_t, it);
        amxc_var_t* entry = amxc_var_add_new(&actual);
        assert_non_null(entry);
        amxc_var_set_type(entry, AMXC_VAR_ID_HTABLE);
        gmaps_device_get_recursive(device, entry, true, 0);
    }

    _assert_variant_equal_from_file(&actual, expected_file, file, line);

    amxc_var_clean(&actual);
}

#define expect_devices(source) _expect_devices(source, __FILE__, __LINE__)

void test_import_pcm_single_device(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data
    const char* data_file = TEST_FILES "/single_device__data.json";
    const char* import_file = data_file;
    const char* devices_file = TEST_FILES "/single_device__devices.json";

    // GIVEN an empty gmap data model
    assert_null(gmaps_get_device("self"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // THEN this succeeded
    assert_non_null(gmaps_get_device("self"));
    expect_devices(devices_file);
}

void test_import_pcm_multiple_devices(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data
    const char* data_file = TEST_FILES "/multiple_devices__data.json";
    const char* import_file = data_file;
    const char* devices_file = TEST_FILES "/multiple_devices__devices.json";

    // GIVEN an empty gmap data model
    assert_null(gmaps_get_device("self"));
    assert_null(gmaps_get_device("bridge-lan_bridge"));
    assert_null(gmaps_get_device("bridge-guest_bridge"));
    assert_null(gmaps_get_device("ethIntf-ETH0"));
    assert_null(gmaps_get_device("ethIntf-ETH1"));
    assert_null(gmaps_get_device("ssid-vap5g0priv"));
    assert_null(gmaps_get_device("ssid-vap2g0priv"));
    assert_null(gmaps_get_device("ethIntf-ETH2"));
    assert_null(gmaps_get_device("ssid-vap6g0priv"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created
    assert_non_null(gmaps_get_device("self"));
    assert_non_null(gmaps_get_device("bridge-lan_bridge"));
    assert_non_null(gmaps_get_device("bridge-guest_bridge"));
    assert_non_null(gmaps_get_device("ethIntf-ETH0"));
    assert_non_null(gmaps_get_device("ethIntf-ETH1"));
    assert_non_null(gmaps_get_device("ssid-vap5g0priv"));
    assert_non_null(gmaps_get_device("ssid-vap2g0priv"));
    assert_non_null(gmaps_get_device("ethIntf-ETH2"));
    assert_non_null(gmaps_get_device("ssid-vap6g0priv"));
    expect_devices(devices_file);
}

void test_import_pcm_mib_data(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data
    const char* data_file = TEST_FILES "/mib_data__data.json";
    const char* import_file = data_file;
    const char* devices_file = TEST_FILES "/mib_data__devices.json";

    // GIVEN an empty gmap data model
    assert_null(gmaps_get_device("device"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created
    assert_non_null(gmaps_get_device("device"));
    expect_devices(devices_file);
}

static void s_precreate_devices(void) {
    utils_init_device_name_t dev1_names[] = {
        {
            .name = "my_device",
            .source = "webui",
        },
        {
            .name = "sah0742pc",
            .source = "dhcp",
        },
        { 0 }
    };
    utils_mib_stats_data_t dev1_stats = {
        .BytesReceived = 2382,
        .BytesSent = 233026,
        .CollectionInterval = 300,
        .InitialTimeStr = "2024-10-05T01:10:34.786432624Z",
        .LastUpdateStr = "2024-10-05T03:45:34.905133397Z",
        .Origin = "gmap-mod-conntrack-stats",
        .PacketsReceived = 18,
        .PacketsSent = 570,
        .Status = "Success",
    };
    utils_mib_ip_ipv4_data_t dev1_ipv4[] = {
        {
            .Address = "192.168.1.2",
            .AddressSource = "DHCP",
            .Reserved = 0,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_ipv6_data_t dev1_ipv6[] = {
        {
            .Address = "fe80::2048:1a98:5e91:33ca",
            .AddressSource = "static",
            .Scope = "link",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t dev1_ip = {
        .IPAddress = "192.168.1.2",
        .IPAddressSource = "self",
        .ipv4_data = dev1_ipv4,
        .ipv6_data = dev1_ipv6,
    };

    utils_init_device_name_t dev2_names[] = {
        {
            .name = "JonsPhone",
            .source = "dhcp",
        },
        { 0 }
    };
    utils_mib_ip_ipv4_data_t dev2_ipv4[] = {
        {
            .Address = "192.168.1.3",
            .AddressSource = "DHCP",
            .Reserved = 0,
            .Scope = "global",
            .Status = "reachable",
        },
        { 0 }
    };
    utils_mib_ip_data_t dev2_ip = {
        .IPAddress = "192.168.1.3",
        .IPAddressSource = "DHCP",
        .ipv4_data = dev2_ipv4,
    };
    utils_mib_dhcp_data_t dev2_dhcp = {
        .ClientID = "8641641ZEVZEX",
        .DHCPOption55 = "1,2,6",
        .DHCPv4Client = "Device.DHCPv4.Server.Pool.1.Client.2.",
    };

    utils_init_device_data_t devices[] = {
        {
            .key = "dev1",
            .tags = "lan edev physical mac eth ipv4 ipv6 stats",
            .discovery_source = "eth-dev",
            .default_name = "device-1_Name",
            .first_seen_str = "2024-12-09T12:29:27.432861232Z",
            .last_connection_str = "2024-12-09T12:33:20.368485052Z",
            .names = dev1_names,
            .phys_address = "11:22:33:44:55:01",
            .mib_stats = &dev1_stats,
            .mib_ip = &dev1_ip,
        },
        {
            .key = "dev2",
            .tags = "lan edev physical mac ipv4 eth dhcp",
            .discovery_source = "eth-dev",
            .default_name = "device-2_Name",
            .first_seen_str = "0001-01-01T00:00:00Z",
            .last_connection_str = "0001-01-01T00:00:00Z",
            .names = dev2_names,
            .phys_address = "11:22:33:44:55:02",
            .mib_ip = &dev2_ip,
            .mib_dhcp = &dev2_dhcp,
        },
        { 0 }
    };

    util_device_create_all(devices);
    amxut_bus_handle_events();
}

void test_import_pcm_merge_new(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data
    const char* data_file = TEST_FILES "/merge_new__data.json";
    const char* import_file = data_file;
    const char* devices_file = TEST_FILES "/merge_new__devices.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));
    assert_null(gmaps_get_device("device"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created
    assert_non_null(gmaps_get_device("dev1"));
    assert_non_null(gmaps_get_device("device"));
    expect_devices(devices_file);
}

void test_import_pcm_merge_existing_newer(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: add tag testmib
    //         remove tag stats
    //         keep other tags
    //         set firstseen and lastconnected to a newer date
    //   dev2: keep all current tags
    //         set firstseen and lastconnected to a newer date from default
    const char* data_file = TEST_FILES "/merge_existing_newer__data.json";
    const char* import_file = TEST_FILES "/merge_existing_newer__import.json";
    const char* devices_file = TEST_FILES "/merge_existing_newer__devices.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created with the following changes:
    //   dev1: tag testmib is added
    //         tag stats is kept
    //         firstseen is kept
    //         lastconnected is updated
    //   dev2: firstseen and lastconnected are updated
    expect_devices(devices_file);
}

void test_import_pcm_merge_existing_older(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: tags not restored,
    //         set firstseen and lastconnected to an earlier date
    //   dev2: set firstseen and lastconnected to an earlier date from default
    const char* data_file = TEST_FILES "/merge_existing_older__data.json";
    const char* import_file = TEST_FILES "/merge_existing_older__import.json";
    const char* devices_file = TEST_FILES "/merge_existing_older__devices.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created with the following changes:
    //   dev1: firstseen is updated
    //         lastconnected is kept
    //   dev2: firstseen and lastconnected are updated
    expect_devices(devices_file);
}

void test_import_pcm_merge_existing_default_time(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: set firstseen and lastconnected to the default date
    //   dev2: set firstseen and lastconnected to the default date from default
    //         set ProductClass
    const char* data_file = TEST_FILES "/merge_existing_default_time__data.json";
    const char* import_file = TEST_FILES "/merge_existing_default_time__import.json";
    const char* devices_file = TEST_FILES "/merge_existing_default_time__devices.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    //   dev1 has no more parameters to restore, so it is completely absent
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created with the following changes:
    //   dev1: firstseen and lastconnected are kept
    //   dev2: firstseen and lastconnected are kept
    expect_devices(devices_file);
}

void test_import_pcm_merge_existing_other_id(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: use "first_device" as device key
    //         add tag testmib
    //         remove tag stats
    //         keep other tags
    //         set firstseen and lastconnected to a newer date
    const char* data_file = TEST_FILES "/merge_existing_other_id__data.json";
    const char* import_file = TEST_FILES "/merge_existing_other_id__import.json";
    const char* devices_file = TEST_FILES "/merge_existing_other_id__devices.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    //   dev1 has no more parameters to restore, so it is completely absent
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created with the following changes:
    //   dev1: tag testmib is added
    //         tag stats is kept
    //         firstseen is kept
    //         lastconnected is updated
    expect_devices(devices_file);
}

void test_import_pcm_merge_existing_self_device(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   me: add tag testmib
    //       remove tag stats
    //       keep other tags
    //       set firstseen and lastconnected to a newer date
    const char* data_file = TEST_FILES "/merge_existing_self_device__data.json";
    const char* import_file = TEST_FILES "/merge_existing_self_device__import.json";
    const char* devices_file = TEST_FILES "/merge_existing_self_device__devices.json";
    utils_init_device_data_t selfdev = {
        .key = "me",
        .tags = "self edev physical mac eth ipv4 ipv6 stats",
        .discovery_source = "self",
        .default_name = "Me",
        .first_seen_str = "2024-12-09T12:29:27.432861232Z",
        .last_connection_str = "2024-12-09T12:33:20.368485052Z",
        .phys_address = "11:22:33:44:55:01",
    };

    // GIVEN a non-empty gmap data model with a self device
    util_device_create(&selfdev);
    assert_non_null(gmaps_get_device("me"));
    expect_devices(devices_file);

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    //   dev1 has no more parameters to restore, so it is completely absent
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // AND multiple devices were created with the following changes:
    //   me: unchanged
    expect_devices(devices_file);
}

void test_import_pcm_merge_bad_tags(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: attempt to set self tag
    const char* data_file = TEST_FILES "/merge_bad_tags__data.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT import to fail, with no call to the import function of mod_svc_pcm
    /* expect_pcm_import(import_file); */
    // WHEN importing the upgrade-persistent configuration data
    assert_int_not_equal(0, s_call_import(data_file));
}

void test_import_pcm_merge_bad_physaddress(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: incorrect physaddress
    const char* data_file = TEST_FILES "/merge_bad_physaddress__data.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT import to fail, with no call to the import function of mod_svc_pcm
    /* expect_pcm_import(import_file); */
    // WHEN importing the upgrade-persistent configuration data
    assert_int_not_equal(0, s_call_import(data_file));
}

void test_import_pcm_merge_mixed_physaddress(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data with the following changes:
    //   dev1: incorrect physaddress of dev2
    const char* data_file = TEST_FILES "/merge_mixed_physaddress__data.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT import to fail, with no call to the import function of mod_svc_pcm
    /* expect_pcm_import(import_file); */
    // WHEN importing the upgrade-persistent configuration data
    assert_int_not_equal(0, s_call_import(data_file));
}

void test_import_pcm_single_device_no_merge(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data
    const char* data_file = TEST_FILES "/single_device_no_merge__data.json";
    const char* import_file = data_file;
    const char* devices_file = TEST_FILES "/single_device_no_merge__devices.json";

    // GIVEN an empty gmap data model
    assert_null(gmaps_get_device("self"));

    // EXPECT the import function of PCM itself is called to continue doing the
    //        non-custom part of importing.
    expect_pcm_import(import_file);
    // WHEN importing the upgrade-persistent configuration data
    assert_success(s_call_import(data_file));

    // THEN this succeeded
    assert_non_null(gmaps_get_device("self"));
    expect_devices(devices_file);
}

void test_import_pcm_existing_device_no_merge(UNUSED void** state) {
    // GIVEN upgrade-persistent configuration data that may not be merged
    const char* data_file = TEST_FILES "/existing_device_no_merge__data.json";

    // GIVEN a non-empty gmap data model
    s_precreate_devices();
    assert_non_null(gmaps_get_device("dev1"));

    // EXPECT import to fail, with no call to the import function of mod_svc_pcm
    /* expect_pcm_import(import_file); */
    // WHEN importing the upgrade-persistent configuration data
    assert_int_not_equal(0, s_call_import(data_file));
}
