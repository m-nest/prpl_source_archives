/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc_macros.h>
#include <amxut/amxut_bus.h>

#include "mock_discoping.h"

static void arp_cb_timer(UNUSED amxp_timer_t* timer, void* priv) {

    arp_socket_t* socket = (arp_socket_t*) priv;
    when_null(socket, exit);
    when_null(socket->my_ip, exit);
    when_null(socket->userdata, exit);
    socket->cb(socket->my_ip, NULL, socket->userdata);

exit:
    return;
}
static void ndp_cb_timer(UNUSED amxp_timer_t* timer, void* priv) {

    ndp_socket_t* socket = (ndp_socket_t*) priv;
    when_null(socket, exit);
    socket->cb(socket->my_ip, NULL, socket->userdata);

exit:
    return;
}

bool __wrap_arp_socket_new(arp_socket_t** socket,
                           amxo_parser_t* odl_parser,
                           const char* netdev_name,
                           const char* ip_from,
                           socket_common_reply_cb_t cb) {
    *socket = (arp_socket_t*) calloc(1, sizeof(arp_socket_t));
    when_null(*socket, error);
    assert_non_null(odl_parser);
    assert_non_null(netdev_name);
    assert_non_null(ip_from);

    (*socket)->cb = cb;
    (*socket)->my_ip = NULL;
    amxp_timer_new(&((*socket)->cb_timer), arp_cb_timer, *socket);

    return true;
error:
    __wrap_arp_socket_delete(socket);
    return false;
}

void __wrap_arp_socket_delete(arp_socket_t** socket) {
    if((socket == NULL) || (*socket == NULL)) {
        return;
    }

    free((*socket)->my_ip);
    (*socket)->my_ip = NULL;
    amxp_timer_delete(&(*socket)->cb_timer);
    free(*socket);
    *socket = NULL;
}

bool __wrap_arp_socket_send_request(arp_socket_t* socket, UNUSED const char* ip_from,
                                    const char* ip_to, UNUSED const char* mac_to) {
    uint32_t timeout = arp_fails ? 1010 : 100;

    assert_non_null(socket);
    socket->my_ip = strdup(ip_to);
    amxp_timer_start(socket->cb_timer, timeout); // Simulate real life by having a delay

    if(arp_send_fails) {
        arp_send_fails = false;
        return false;
    }
    return true;
}

void __wrap_arp_socket_set_userdata(arp_socket_t** socket, UNUSED void* userdata) {
    if((socket == NULL) || (*socket == NULL)) {
        return;
    }

    (*socket)->userdata = userdata;
}

bool __wrap_ndp_socket_new(ndp_socket_t** socket,
                           amxo_parser_t* parser,
                           const char* netdev_name,
                           const char* ip,
                           socket_common_reply_cb_t cb) {
    *socket = (ndp_socket_t*) calloc(1, sizeof(ndp_socket_t));
    when_null(*socket, error);
    assert_non_null(parser);
    assert_non_null(netdev_name);
    assert_non_null(ip);

    (*socket)->cb = cb;
    (*socket)->my_ip = NULL;
    amxp_timer_new(&(*socket)->cb_timer, ndp_cb_timer, *socket);

    return true;
error:
    __wrap_ndp_socket_delete(socket);
    return false;
}

void __wrap_ndp_socket_delete(ndp_socket_t** socket) {
    if((socket == NULL) || (*socket == NULL)) {
        return;
    }

    free((*socket)->my_ip);
    amxp_timer_delete(&(*socket)->cb_timer);
    free(*socket);
    *socket = NULL;
}

bool __wrap_ndp_socket_send_request(ndp_socket_t* socket, UNUSED const char* ip_from,
                                    const char* ip_to, UNUSED const char* mac_from) {
    uint32_t timeout = nd_fails ? 2000 : 100;

    assert_non_null(socket);
    socket->my_ip = strdup(ip_to);
    amxp_timer_start(socket->cb_timer, timeout); // Simulate real life by having a delay

    if(nd_send_fails) {
        nd_send_fails = false;
        return false;
    }
    return true;
}

void __wrap_ndp_socket_set_userdata(ndp_socket_t** socket, UNUSED void* userdata) {
    if((socket == NULL) || (*socket == NULL)) {
        return;
    }

    (*socket)->userdata = userdata;
}