/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* System headers */
#include <unistd.h> /* access() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* when_true() */

/* Own headers */
#include "dm_sfp_db.h" /* dm_sfp_db_look_up_sfp_type() */
#include "sfpmgr.h"
#include "sfpmgr_common.h"
#include "optical_if.h"
#include "sfp_ethdata.h"
#include "sfp_types_and_constants.h" /* EXAMPLE_ETHTOOL_OUTPUT */

/**
 * @brief Populates SFP info by executing the ethtool command.
 *
 * @details Runs the ethtool command for a specified Linux network interface, parses the output,
 * and stores the resulting key-value pairs in a hash per SFP object. This is called after the SFP is inserted.
 *
 * @param[in] cage_object Information for the cage.
 * @param[in] sfp_object Information for the SFP in the cage.
 *
 * @return SFPMGR_SUCCESS on success, else SFPMGR_INVALID
 */
int populate_sfp_info(amxd_object_t* cage_object, amxd_object_t* sfp_object) {
#define ETHTOOL_COMMAND_SIZE    64
    char ethtool_command[ETHTOOL_COMMAND_SIZE] = {0};
    sfp_cage_t* cage_info = (sfp_cage_t*) cage_object->priv;
    sfp_info_t* sfp_info = (sfp_info_t*) sfp_object->priv;
    int retval = SFPMGR_INVALID;
    int rc;
    bool rv;
    SAH_TRACEZ_INFO(ME, "populate_sfp_info");
    when_null(cage_info, exit);
    when_null(sfp_info, exit);

    /* Construct the ethtool command to retrieve SFP data */
#ifdef UNIT_TEST
    rc = snprintf(ethtool_command, sizeof(ethtool_command), "cat %s", EXAMPLE_ETHTOOL_OUTPUT);
#else
    rc = snprintf(ethtool_command, sizeof(ethtool_command), "ethtool -m  %s", cage_info->ifName);
#endif
    when_true_trace(rc < 0 || rc >= ETHTOOL_COMMAND_SIZE, exit, ERROR,
                    "snprintf() failed rc=%d", rc);

#ifdef UNIT_TEST
    const bool example_exists = (access(EXAMPLE_ETHTOOL_OUTPUT, F_OK) == 0);
    retval = SFPMGR_SUCCESS;
    when_false_trace(example_exists, exit, INFO, "%s does not exist",
                     EXAMPLE_ETHTOOL_OUTPUT);
    retval = SFPMGR_INVALID;
#endif

    rv = retrieve_sfp_data(ethtool_command, &sfp_info->key_value_pair);
    when_false_trace(rv, exit, ERROR, "retrieve_sfp_data() failed");
    retval = SFPMGR_SUCCESS;

exit:
    return retval;
}

/**
 * Update the SFP type if the SFB DB has a value for it.
 *
 * @param[in] ethtool_values: hash table with key-value pairs with info about
 *     the SFP. The function gets the vendor name and the part number from this
 *     table.
 * @param[in,out] cage_info: the function overwrites its member 'sfp_type' if
 *     the SFP DB in the DM specifies an SFP type for the vendor name and part
 *     number occurring in @a ethtool_values.
 *
 * If there is no entry in the SFP DB for the vendor name and part number, this
 * function is a no-op.
 */
static void update_sfp_type_based_on_sfp_db(const amxc_var_t* ethtool_values,
                                            sfp_cage_t* cage_info) {
    when_null(ethtool_values, exit);
    when_null(cage_info, exit);

    const char* const vendor_name = GET_CHAR(ethtool_values, "Vendor name");
    when_str_empty_trace(vendor_name, exit, ERROR, "cage %d: failed to get vendor name",
                         cage_info->cage_id);

    const char* const vendor_pn = GET_CHAR(ethtool_values, "Vendor PN");
    when_str_empty_trace(vendor_pn, exit, ERROR, "cage %d: failed to get vendor PN",
                         cage_info->cage_id);

    const sfp_types_e sfp_type = dm_sfp_db_look_up_sfp_type(vendor_name, vendor_pn);
    when_true(SFP_UNSUPPORTED == sfp_type, exit);

    SAH_TRACEZ_INFO(ME, "Name='%s' PN='%s': set SFP type to %s (db)",
                    vendor_name, vendor_pn, sfp_type_to_cstring(sfp_type));
    cage_info->sfp_type = sfp_type;

exit:
    return;
}

/**
 * @brief Populates SFP information for a given cage and SFP object.
 *
 * @details Retrieves SFP data using the ethtool command, processes the output,
 * and updates the SFP object with key-value pairs. Returns an error status if
 * the input is invalid or an error occurs during the ethtool call.
 *
 * @param cage_object The cage object containing information about the SFP cage.
 * @param sfp_object The SFP object to update with retrieved information.
 *
 * @return SFPMGR_SUCCESS on success, or SFPMGR_INVALID on failure.
 */
int sfpmgr_object_init (amxd_object_t* cage_object, amxd_object_t* sfp_object) {
    int rc = SFPMGR_INVALID;
    sfp_ethtool_t* sfp_param = NULL;
    sfp_cage_t* cage_info = NULL;
    sfp_info_t* sfp_info = NULL;
    when_null(cage_object, exit);
    when_null(sfp_object, exit);

    sfp_param = calloc(1, sizeof(sfp_ethtool_t));
    when_null_trace(sfp_param, exit, ERROR, "Failed to allocate memory");

    cage_info = (sfp_cage_t*) cage_object->priv;
    when_null(cage_info, exit);
    sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);

    SAH_TRACEZ_INFO(ME, "object init called during SFP Insert");

    amxc_var_init(&sfp_info->key_value_pair);
    amxc_var_set_type(&sfp_info->key_value_pair, AMXC_VAR_ID_HTABLE);
    if(populate_sfp_info(cage_object, sfp_object) == SFPMGR_SUCCESS) {
        update_sfp_type_based_on_sfp_db(&sfp_info->key_value_pair, cage_info);
        sfpmgr_update_base_ext_structure(sfp_object, sfp_param);
        update_dmc_sff8472_params(sfp_param);
        sfpmgr_update_threshold_structure(sfp_object, sfp_param);
        sfpmgr_update_alarm_structure(sfp_object, sfp_param);
        sfpmgr_update_warning_structure(sfp_object, sfp_param);
        sfpmgr_update_status_structure(sfp_object, sfp_param);
        sfpmgr_update_static_params(cage_object, sfp_object, sfp_param);

    }
    rc = SFPMGR_SUCCESS;
exit:
    if(sfp_param) {
        free(sfp_param);
    }
    if(sfp_info) {
        amxc_var_clean(&sfp_info->key_value_pair);
    }
    return rc;
}


/**
 * @brief Updates the SFP object with new parameters and status.
 *
 * @details Populates the SFP object with data using `ethtool`, then updates
 * related structures, including alarms, warnings, and dynamic parameters
 * based on the retrieved SFP data.
 *
 * @param cage_object The cage object containing information about the SFP cage.
 * @param sfp_object The SFP object to be updated.
 *
 * @return Returns `EXIT_SUCCESS` on success, or `EXIT_FAILURE` on failure.
 */
int sfpmgr_object_update (amxd_object_t* cage_object, amxd_object_t* sfp_object) {
    int retval = EXIT_FAILURE;
    sfp_ethtool_t* sfp_param = NULL;
    when_null(cage_object, exit);
    when_null(sfp_object, exit);

    sfp_param = calloc(1, sizeof(sfp_ethtool_t));
    when_null_trace(sfp_param, exit, ERROR, "Failed to allocate memory");

    sfp_cage_t* const cage_info = (sfp_cage_t*) cage_object->priv;
    when_null(cage_info, exit);
    sfp_info_t* const sfp_info = (sfp_info_t*) sfp_object->priv;
    when_null(sfp_info, exit);

    amxc_var_init(&sfp_info->key_value_pair);
    amxc_var_set_type(&sfp_info->key_value_pair, AMXC_VAR_ID_HTABLE);

    if(populate_sfp_info(cage_object, sfp_object) == SFPMGR_SUCCESS) {
        sfpmgr_update_base_ext_structure(sfp_object, sfp_param);
        update_dmc_sff8472_params(sfp_param);
        sfpmgr_update_alarm_structure(sfp_object, sfp_param);
        sfpmgr_update_warning_structure(sfp_object, sfp_param);
        sfpmgr_update_status_structure(sfp_object, sfp_param);
        retval = sfpmgr_update_dynamic_params(cage_object, sfp_object, sfp_param);
        if(sfp_type_is_optical(cage_info->sfp_type)) {
            optical_interface_update_signal_level_params(sfp_info->sfp_cage_id, sfp_param);
        }

    }
    amxc_var_clean(&sfp_info->key_value_pair);

exit:
    if(sfp_param) {
        free(sfp_param);
    }
    return retval;
}

