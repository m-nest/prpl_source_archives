/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__INTERFACE_SETTING_H__)
#define __INTERFACE_SETTING_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "interfacesetting/icmp_echo_request.h"
#include "interfacesetting/spoofing_protection.h"
#include "interfacesetting/icmpv6_passthrough.h"
#include "interfacesetting/stealth_mode.h"
#include "interfacesetting/accept_udp_traceroute.h"
#include "interfacesetting/log_in_drop.h"
#include "interfacesetting/log_out_drop.h"
#include "interfacesetting/log_out_accept.h"
#include <netmodel/client.h>
#include <fwrules/fw_folder.h>

typedef struct {
    netmodel_query_t* query;
    netmodel_query_t* query_v6;
    folder_container_t folders;
    amxc_var_t subnets;
    amxc_var_t subnets_v6;
} isolate_t;

typedef struct _ifsetting_ {
    amxc_llist_it_t it;
    firewall_interface_t fwiface;
    const char* name;
    amxd_object_t* object;
    icmp_echo_request_t* icmp_echo_request;
    spoofing_protection_t* spoofing;
    icmpv6_passthrough_t* icmpv6_passthrough;
    stealth_mode_t* stealth_mode;
    accept_udp_traceroute_t* accept_udp_traceroute;
    log_in_drop_t* log_in_drop;
    log_out_drop_t* log_out_drop;
    log_out_accept_t* log_out_accept;
    isolate_t* isolate;
} ifsetting_t;

ifsetting_t* create_fw_ifsetting(amxd_object_t* object);
bool delete_fw_ifsetting(ifsetting_t** ifsetting);
int ifsettings_log_update_cb(amxd_object_t* templ, amxd_object_t* object, void* priv);

#ifdef __cplusplus
}
#endif

#endif // __INTERFACE_SETTING_H__
