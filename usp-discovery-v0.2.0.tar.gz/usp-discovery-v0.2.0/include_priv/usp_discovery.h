/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef USP_DISCOVERY_H
#define USP_DISCOVERY_H
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <netmodel/common_api.h>
#include <stdint.h>

#define MQTT_AGENT_REPLY_TOPIC "MQTT.AgentReplyTopic"
#define MQTT_CONTROLLER_SUBSCRIBE_TOPIC "MQTT.ControllerResponseTopic"
#define MQTT_TRANSPORT_PROTOCOL "MQTT.TransportProtocol"
#define MQTT_PROTOCOL_VERSION "MQTT.ProtocolVersion"

#define STOMP_AGENT_CONTROLLER_DESTINATION "STOMP.AgentControllerDestination"
#define STOMP_CONTROLLER_AGENT_DESTINATION "STOMP.ControllerAgentDestination"
#define STOMP_FORCE_NO_ENCRYPTION "STOMP.ForceNoEncryption"

#define NETMODEL_INTF "NetModelIntfName"
#define SINGLE_CONTROLLER_INSTANCE "UseSingleControllerInstance"
#define PATH_BUFFER_SIZE 256
#define BUS_OPERATION_TIMEOUT 5

/**
 * @file usp_discovery.h
 * @brief USP discovery support for the CPE.
 */

/**
 * DHCP-obtained USP controller information
 */
struct DHCPControllerInformation {
    /**
     * URL of the controller (contains FULL URI)
     */
    char* URL;

    /**
     * Provisioning code of the USP controller
     */
    char* ProvisioningCode;

    /**
     * USPNotifRetryMinimumWaitInterval for the USP controller
     */
    uint16_t USPNotifRetryMinimumWaitInterval;

    /**
     * USPNotifRetryIntervalMultiplier for the USP controller
     */
    uint16_t USPNotifRetryIntervalMultiplier;

    /**
     * EndpointID of the controller
     */
    char* EndpointID;
};

/**
 * Clean internal value of the DHCPControllerInformation struct
 *
 * @param controller the instance to clean
 */
void DHCPControllerInformation_free(struct DHCPControllerInformation* controller);

/**
 * Clone DHCPControllerInformation struct
 *
 * @param controller the source for the clone
 *
 * @return copy of the controller instance
 */
struct DHCPControllerInformation DHCPControllerInformation_clone(struct DHCPControllerInformation controller);

/**
 * Whether two DHCPControllerInformation struct instance represent
 * same USP controller configuration
 *
 * @param info1 first instance
 * @param info2 second instance
 *
 * @return whether two instances are equal
 */
bool DHCPControllerInformation_equals(const struct DHCPControllerInformation* info1, const struct DHCPControllerInformation* info2);

/**
 * Status of the configured USP controller
 */
struct DHCPStatus {
    /**
     * USP Controller information
     */
    struct DHCPControllerInformation controller_information;

    /**
     * Alias of the USP controller
     */
    amxc_string_t alias;

    /**
     * Whether the USP controller is in use
     */
    bool in_use;
};

/**
 * Reset DHCPStatus
 *
 * @param status status to reset
 */
void DHCPStatus_reset(struct DHCPStatus* status);

/**
 * Current running application state
 */
struct App {
    /**
     * DHCPv4 status of configuration
     */
    struct DHCPStatus dhcpv4_status;

    /**
     * DHCPv6 status of configuration
     */
    struct DHCPStatus dhcpv6_status;

    netmodel_query_t* option_125_subscription;
    netmodel_query_t* option_17_subscription;
};

/**
 * Initialize App isntance
 *
 * @param app app to init
 */
void app_init(struct App* app);

/**
 * Cleans App isntance
 *
 * @param application app to clean
 */

void app_clean(struct App* application);

/**
 * Alias postprocessing function. Used as a WA
 * for libamxut tests to use need additional
 * quotes in search path ([Alias='alias'])
 *
 * @param[in] alias alias to search
 *
 * @return alias postprocessed
 */
amxc_string_t search_path_alias_postprocess_function(const char* alias);

enum DHCPType {
    DHCPType_DHCPv4,
    DHCPType_DHCPv6
};

int _usp_discovery_main(int reason, UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser);

extern struct App app;

#endif
