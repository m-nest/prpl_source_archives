# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.5.0 - 2025-11-14(13:18:16 +0000)

### Other

- Enable PC_AUTO_OPENSOURCE

## Release v0.4.0 - 2025-11-14(11:04:10 +0000)

## Release v0.3.0 - 2025-11-14(10:27:04 +0000)

## Release v0.2.0 - 2025-06-04(06:50:48 +0000)

### Other

- [AppAmor][gmap-mod-*] AppAmor profile should be created for all gmap modules

## Release v0.1.0 - 2024-09-25(14:39:49 +0000)

### Other

- [BDD][PrPl] missing MDS services on PRPL (umdns + parser instead of avahi )

## Release v0.0.2 - 2024-04-08(15:29:29 +0000)

### Other

- Add cache to mdns scanner on prpl to avoid high CPU usage

## Release v0.0.1 - 2023-12-08(09:06:39 +0000)

### Other

- [BDD] Create an mdns parser module in AMX

## Release v0.1.5 - 2023-09-22(16:19:11 +0000)

### Other

- [gmap] [self] [mod] Self can be started after the modules, causing some detection issues.

## Release v0.1.4 - 2023-09-07(14:09:51 +0000)

### Other

- [amx][gmap] segfault of (module loaded by) gmap-client

## Release v0.1.3 - 2023-09-07(12:02:27 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release v0.1.2 - 2023-07-06(08:06:26 +0000)

### Other

- [gmap][mod-mdns] Mdns cannot handle mutiple ipaddresses in 'Host'

## Release v0.1.1 - 2023-04-17(09:10:30 +0000)

### Other

- Removed deprecated odl keywords in tests

## Release v0.1.0 - 2023-01-23(11:37:46 +0000)

### Other

- [amx][gmap] Expose mdns information in gMap

