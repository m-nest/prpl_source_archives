%populate {
    object 'WANManager' {
        parameter WANMode = "demo_wanmode";
    }

    object 'WANManager.WAN' {
        instance add ("demo_wanmode"){
            parameter Alias = "demo_wanmode";
            parameter PhysicalType = "Ethernet";
            parameter PhysicalReference = "Device.Ethernet.Interface.{{ BDfn.getUpstreamInterfaceIndex() + 1 }}";
        }
    }

    object 'WANManager.WAN.demo_wanmode.Intf'{
        instance add(0,"wan"){
            parameter Type = "untagged";
            parameter IPv4Mode = "dhcp4";
            parameter DefaultRouteReference = "Device.Routing.Router.1.IPv4Forwarding.1.";
            parameter IPv6Mode = "dhcp6";
            parameter IPv4Reference = "${ip_intf_wan}";
            parameter IPv6Reference = "${ip_intf_wan}";
            parameter NeighborDiscoveryReference = "Device.NeighborDiscovery.InterfaceSetting.1";
            parameter DHCPv4Reference = "Device.DHCPv4.Client.1.";
            parameter DHCPv6Reference = "Device.DHCPv6.Client.1.";
            parameter DeferredIPv6Instances = "${ip_intf_lan},${ip_intf_guest},${ip_intf_lcm}";
        }
    }
}
