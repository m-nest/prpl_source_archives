/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdarg.h>
#include <setjmp.h>
#include <unistd.h>
#include <cmocka.h>
#include "hosts_manager.h"
#include "hosts_sync.h"
#include "hosts_accesscontroller.h"

#include "../common/mock.h"
#include "../common/common_functions.h"
#include "test_stats.h"

#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_sahtrace.h>

#define DEVICE_TEST_ODL "../common/mock_devices_dm.odl"
#define MOCK_TEST_ODL "mock_test.odl"
#define NETMODEL_TEST_ODL "../common/mock_netmodel_dm.odl"
#define HOSTS_DEFINITION_ODL "../../odl/hosts-manager-definitions.odl"

#define HOSTS_QUERY_EXPRESSION "lan and not self and physical and .Master==\"\""

static amxd_dm_t* dm = NULL;
static amxo_parser_t* parser = NULL;
static amxb_bus_ctx_t* bus_ctx = NULL;
static gmap_query_t query = {0};

int test_setup(void** state) {
    amxd_object_t* root_obj = NULL;

    amxut_sahtrace_setup(state);
    amxut_bus_setup(state);

    dm = amxut_bus_dm();
    parser = amxut_bus_parser();
    bus_ctx = amxut_bus_ctx();
    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    resolver_add_all_functions(parser);
    test_init_dummy_fn_resolvers(parser);

    amxo_resolver_import_open(parser, "/usr/lib/amx/modules/mod-dmext.so", "mod-dmext", 0);
    assert_int_equal(amxo_parser_parse_file(parser, DEVICE_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(parser, NETMODEL_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(parser, MOCK_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(parser, HOSTS_DEFINITION_ODL, root_obj), 0);

    _dummy_main(0, dm, parser);

    assert_int_equal(amxo_parser_start_synchronize(parser), 0);

    amxut_bus_handle_events();


    expect_string(__wrap_gmap_query_open_ext_2, expression, HOSTS_QUERY_EXPRESSION);
    will_return(__wrap_gmap_query_open_ext_2, &query);
    assert_int_equal(hosts_sync_init(dm, parser), 0);
    gmap_query_exec_callback(&query, GMAP_DEV_ALIAS_2, gmap_query_expression_start_matching);

    return 0;
}

int test_teardown(UNUSED void** state) {
    expect_value(__wrap_gmap_query_close, query, &query);
    assert_int_equal(hosts_sync_cleanup(), 0);

    _dummy_main(1, dm, parser);
    amxo_parser_stop_synchronize(parser);

    dm = NULL;
    parser = NULL;
    bus_ctx = NULL;

    amxut_bus_teardown(state);
    amxut_sahtrace_teardown(state);
    amxo_resolver_import_close_all();

    return 0;
}

typedef struct _gmap_stats {
    const char* status;
    uint64_t bytes_sent;
    uint64_t bytes_received;
    uint64_t packets_sent;
    uint64_t packets_received;
} gmap_stats_t;

static bool gmap_set_stats(const char* key, const gmap_stats_t* stats) {
    amxd_trans_t trans;
    bool success;

    assert_non_null(key);
    assert_string_not_equal(key, "");
    assert_non_null(stats);
    assert_non_null(stats->status);
    assert_string_not_equal(stats->status, "");

    amxd_trans_init(&trans);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "Devices.Device.%s.Stats.", key);
    amxd_trans_set_value(cstring_t, &trans, "Status", stats->status);
    amxd_trans_set_value(uint64_t, &trans, "BytesSent", stats->bytes_sent);
    amxd_trans_set_value(uint64_t, &trans, "BytesReceived", stats->bytes_received);
    amxd_trans_set_value(uint64_t, &trans, "PacketsSent", stats->packets_sent);
    amxd_trans_set_value(uint64_t, &trans, "PacketsReceived", stats->packets_received);

    success = amxd_trans_apply(&trans, amxut_bus_dm()) == 0;
    amxd_trans_clean(&trans);

    return success;
}

typedef struct _hosts_wanstats {
    int status;
    uint64_t bytes_received;
    uint64_t bytes_sent;
    uint64_t packets_received;
    uint64_t packets_sent;
} hosts_wanstats_t;

static void read_host_stats(const char* key, hosts_wanstats_t* out) {
    amxc_var_t ret;
    amxc_var_t* values = NULL;
    amxc_string_t path;

    assert_non_null(key);
    assert_string_not_equal(key, "");
    assert_non_null(out);

    amxc_var_init(&ret);
    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "Hosts.Host.%s.WANStats.", key);

    out->status = amxb_get(amxut_bus_ctx(), amxc_string_get(&path, 0), 1, &ret, 5);
    when_failed(out->status, exit);

    values = amxc_var_get_first(GETI_ARG(&ret, 0));
    out->bytes_received = amxc_var_dyncast(uint64_t, GET_ARG(values, "BytesReceived"));
    out->bytes_sent = amxc_var_dyncast(uint64_t, GET_ARG(values, "BytesSent"));
    out->packets_received = amxc_var_dyncast(uint64_t, GET_ARG(values, "PacketsReceived"));
    out->packets_sent = amxc_var_dyncast(uint64_t, GET_ARG(values, "PacketsSent"));

exit:
    amxc_string_clean(&path);
    amxc_var_clean(&ret);
}

void hosts_stats_read_once(UNUSED void** state) {
    hosts_wanstats_t wanstats = {.status = -1};

    // GIVEN the following stats
    gmap_stats_t stats = {
        .status = "Success",
        .bytes_sent = 4,
        .bytes_received = 3,
        .packets_sent = 2,
        .packets_received = 1,
    };
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // EXPECT the stats to be in sync
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 4);
    assert_int_equal(wanstats.bytes_received, 3);
    assert_int_equal(wanstats.packets_sent, 2);
    assert_int_equal(wanstats.packets_received, 1);
}

void hosts_stats_read_repeated(UNUSED void** state) {
    hosts_wanstats_t wanstats = {.status = -1};

    // GIVEN the following stats
    gmap_stats_t stats = {
        .status = "Success",
        .bytes_sent = 4,
        .bytes_received = 3,
        .packets_sent = 2,
        .packets_received = 1,
    };
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // EXPECT the stats to be in sync
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 4);
    assert_int_equal(wanstats.bytes_received, 3);
    assert_int_equal(wanstats.packets_sent, 2);
    assert_int_equal(wanstats.packets_received, 1);

    // WHEN the stats in gmap change...
    stats.bytes_sent *= 10;
    stats.bytes_received *= 10;
    stats.packets_sent *= 10;
    stats.packets_received *= 10;
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // BUT they are read too quickly

    // EXPECT the stats to still show the old data
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 4);
    assert_int_equal(wanstats.bytes_received, 3);
    assert_int_equal(wanstats.packets_sent, 2);
    assert_int_equal(wanstats.packets_received, 1);

    // WHEN time passes
    amxut_timer_go_to_future_ms(20000);

    // EXPECT the stats to be in sync again
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 40);
    assert_int_equal(wanstats.bytes_received, 30);
    assert_int_equal(wanstats.packets_sent, 20);
    assert_int_equal(wanstats.packets_received, 10);
}

void hosts_stats_read_fail(UNUSED void** state) {
    hosts_wanstats_t wanstats = {.status = 0};

    // WHEN no valid stats are available
    gmap_stats_t stats = {
        .status = "Error",
        .bytes_sent = 1,
        .bytes_received = 1,
        .packets_sent = 1,
        .packets_received = 1,
    };
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // EXPECT the stats to be all zero
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 0);
    assert_int_equal(wanstats.bytes_received, 0);
    assert_int_equal(wanstats.packets_sent, 0);
    assert_int_equal(wanstats.packets_received, 0);
}

void hosts_stats_read_fail_after_success(UNUSED void** state) {
    hosts_wanstats_t wanstats = {.status = -1};

    // GIVEN the following stats
    gmap_stats_t stats = {
        .status = "Success",
        .bytes_sent = 4,
        .bytes_received = 3,
        .packets_sent = 2,
        .packets_received = 1,
    };
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // EXPECT the stats to be in sync
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 4);
    assert_int_equal(wanstats.bytes_received, 3);
    assert_int_equal(wanstats.packets_sent, 2);
    assert_int_equal(wanstats.packets_received, 1);

    // WHEN time passes
    amxut_timer_go_to_future_ms(20000);

    // And the stats in gmap report error
    stats.status = "Error";
    assert_true(gmap_set_stats(GMAP_DEV_ALIAS_2, &stats));

    // EXPECT the stats to be all zero
    read_host_stats("1", &wanstats);

    assert_int_equal(wanstats.status, 0);
    assert_int_equal(wanstats.bytes_sent, 0);
    assert_int_equal(wanstats.bytes_received, 0);
    assert_int_equal(wanstats.packets_sent, 0);
    assert_int_equal(wanstats.packets_received, 0);
}
