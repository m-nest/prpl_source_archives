/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_trie.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief DMM trie declaration used for parsing and storing mapping
 * @version 1.0.0
 * @date 2025-12-03
 *
 * @copyright Copyright (c) 2025 Inango
 */

#ifndef DMM_TRIE
#define DMM_TRIE

#include <amxc/amxc.h>

#define NODE_RESERVER_COUNT 1 /*!< Default size of the htable for child nodes */

/**
 * @brief Action to apply to node in trie
 */
typedef enum {
    NodeAction_Rename, /*!< Rename node */
    NodeAction_Hide,   /*!< Hide node */
    NodeAction_Empty   /*!< No action for node */
} NodeAction;

/**
 * @brief TreeNode represents single node in the trie mapping
 */
typedef struct {
    amxc_htable_it_t hit;                /*!< iterator for terminals/nonterminals map */
    amxc_htable_it_t hit_parameter;      /*!< iterator when stored in parameters map */
    amxc_htable_it_t hit_function;       /*!< iterator when stored in functions map */
    amxc_htable_it_t hit_event;          /*!< iterator when stored in events map */
    bool is_multiinstance;               /*!< whether current node represents a multiinstance object */
    NodeAction action;                   /*!< action for node */
    amxc_string_t* rename_to;            /*!< if action==Rename new name for the node */
    amxc_string_t* rename_to_no_suffix;  /*!< rename_to without suffix */
    amxc_htable_t terminals;             /*!< all child terminals (parameters, functions, events) */
    amxc_htable_t nonterminals;          /*!< all child nonterminals (objects)  */
    amxc_htable_t parameters;            /*!< all child parameters */
    amxc_htable_t functions;             /*!< all child functions (indexed without '()') */
    amxc_htable_t events;                /*!< all child events (indexed without '!') */
} TreeNode;

/** Forward trie */
extern TreeNode forward_tree;

/** Backward trie */
extern TreeNode backward_tree;

/**
 * @brief Initializes the tries.
 *
 * @return 0 if no error
 */
int init_tree();

/**
 * @brief Parse rename/hide mappings into trie.
 *
 * @return 0 if no error
 */
int parse_mapping();

/**
 * @brief Clean the tries.
 */
void clean_tree();

/**
 * @brief Print forward and backward tree to logs.
 */
void print_trees();

/**
 * @brief Find exact node in the tree by nonterminal path and terminal name.
 *
 * @param[in] tree root to start search from
 * @param[in] nonterminals_path nonerminal path (e.g. object path)
 * @param[in] terminal (optional) terminal name to search
 *
 * @return TreeNode or NULL if node cannot be found
 */
const TreeNode* find_exact_node(const TreeNode* tree, const char* nonterminals_path, const char* terminal);

#endif
