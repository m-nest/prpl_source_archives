# XPON prpl module

[[_TOC_]]

## Introduction

### Overview

The XPON prpl module is a PON vendor module (VM) loaded by `tr181-xpon`, i.e. the TR-181 XPON manager. It communicates via ubus with one or more prpl PON HAL agents.

`tr181-xpon` has the TR-181 DM as northbound IF. The PON HAL agent has the prpl ubus PON DM has northbound IF. The XPON prpl module in essence acts like a bridge or proxy between those two.

### Relevant links

- [prpl ubus PON DM](https://prplfoundationcloud.atlassian.net/wiki/spaces/PRPLWRT/pages/17598181/Ubus+PON+DM)
- [prpl XPON Manager](https://prplfoundationcloud.atlassian.net/wiki/spaces/PRPLWRT/pages/17596853/XPON+Manager)
- [TR-181 DM](https://usp-data-models.broadband-forum.org/#sec:current-data-models)
- [tr181-xpon](https://gitlab.com/prpl-foundation/components/core/plugins/tr181-xpon)
- [ubus](https://openwrt.org/docs/techref/ubus)

### Abbreviations

| Abbreviation | Meaning                               |
| ------------ | ------------------------------------- |
| BBF          | Broadband forum                       |
| DM           | data model                            |
| IF           | interface                             |
| ONU          | Optical Network Unit                  |
| PON          | Passive Optical Network               |
| VM           | vendor module                         |


## Architecture

### Overall architecture

The diagram below shows the overall architecture:

```
             Bus (ubus, ...)
                    |
                    | <-- TR-181 DM
                    |
        TR-181 XPON | Manager (tr181-xpon)  
     +----------------------------------------+
     |                                        |
     |                                        |
     |           +-----------------------------+
     |           | prpl XPON vendor module     |
     |           | (mod-xpon-prpl)             |
     +-----------|                             |
                 +-----------------------------+
                           |
                           | ubus
                           |
                           | <--- prpl ubus PON DM
                           |
               +-----------+--------+
               |                    |
               |                    |
       +----------------+     +----------------+
       | PON HAL agent  |     | PON HAL agent  |  ....
       | for ONU 1      |     | for ONU 2      |
       +----------------+     +----------------+
                |                   |
        PON/OMCI stack         PON/OMCI stack
        for ONU 1              for ONU 2

```

`tr181-xpon` has the TR-181 DM as northbound IF. `tr181-xpon` implements the vendor independent part. The vendor specific code is in modules. `mod-xpon-prpl` implements this vendor specific part for a board with a prplOS image with one or more prpl PON HAL agents. A PON HAL agent manages the PON/OMCI stack of a single ONU. It has the prpl ubus PON DM as northbound IF. The TR-181 XPON DM and the prpl ubus PON DM are very similar. `mod-xpon-prpl` acts like a bridge between `tr181-xpon` and one or more PON HAL agents. It does a translation between the TR-181 DM and the prpl ubus PON DM.

E.g. assume a board has 1 ONU with a PON HAL agent to manage it. The agent shows `xpon_onu.1` on ubus. `mod-xpon-prpl` then instructs `tr181-xpon` to show `XPON.ONU.1` in the TR-181 DM. If someone sets `XPON.ONU.1.Enable` to 1, `mod-xpon-prpl` uses ubus to call the method `enable()` on `xpon_onu.1`.

The PON HAL agent is sometimes also called the ONU HAL agent because it manages an ONU.


## Tests

### Unit tests

The folder 'test' has unit tests.

### Howto test in a docker container

See the `README.md` of `tr181-xpon` on how to test `tr181-xpon` and a vendor module in a Docker container with an Ambiorix development image.

This section documents things specific for the `mod-xpon-prpl` module.

I developed a mock for the PON HAL agent. It's in `test_interactive/onu_hal_mock/onu_hal_mock`. To run the mock, build `mod-xpon-prpl`, open a shell with root privileges to the container, and run the `onu_hal_mock`.

I usually open different shells with root privileges to the container.

#### Shell 1: start syslog-ng and ubus, monitor logging

```
rm -f /var/log/messages
syslog-ng
ubusd &
tail -f /var/log/messages
```

#### Shell 2: run `onu_hal_mock`

```
cd test_interactive/onu_hal_mock/onu_hal_mock
./onu_hal_mock
```

#### Shell 3: run tr181-xpon

```
tr181-xpon
```

#### Shell 4: inspect DMs

Use this shell to query the DMs. To query the TR-181 DM:

```
# ubus-cli
[..]
> XPON.?
XPON.
XPON.ONUNumberOfEntries=1
XPON.ONU.1.
XPON.ONU.1.ANINumberOfEntries=1
XPON.ONU.1.Enable=0
[..]
>
```
To query the DMs on ubus, including the prpl ubus PON DM:

```
# ubus list
XPON
XPON.ONU
XPON.ONU.1
XPON.ONU.1.ANI
XPON.ONU.1.ANI.1
[..]
xpon_onu.1
xpon_onu.1.ani.1
[..]
#
```

#### Shell 5: dbgtool

The folder `test_interactive/onu_hal_mock` includes a `dbgtool`. It communicates with the ONU HAL agent via a Unix socket. Run `dbgtool` without arguments (or with argument `-h`) to get help:

```
# ./dbgtool 
Usage:
dbgtool -h
dbgtool <command>

Options:
  -h                     : show this help and exit

Commands:
  add_instance           : add transceiver.2 and send dm:instance-added notification
  remove_instance        : remove transceiver.2 and send dm:instance-removed notification
  change_transceiver     : change transceiver.1 and send dm:object-changed notification
  change_onu_activation  : change onu_activation and send dm:object-changed notification
  omci_reset_mib         : send omci:reset_mib notification
#
```

Its main purpose is to test notifications.

To e.g. test the `dm:instance-added` notification, run:

```
./dbgtool add_instance
```

#### Shell 6: run 2nd `onu_hal_mock`

It's possible to run two ONU HAL agents. In one shell, run `onu_hal_mock`. In another shell, run `onu_hal_mock` with option 2:

```
cd test_interactive/onu_hal_mock/onu_hal_mock
./onu_hal_mock 2
```

This starts a 2nd ONU HAL agent showing `xpon_onu.2` on ubus. The idea is to test 2 `xpon_onu` instances, and hence 2 `XPON.ONU` instances.

Note: the `dbgtool` is intented to only be used in a situation with one `onu_hal_mock` running. The `onu_hal_mock` uses 1 path for the Unix socket for its debug interface, and `dbgtool` sends its messages to this single Unix socket.

### Test ChangePowerMode() interactively

I test the call `XPON.ONU.{i}.ChangePowerMode()` interactively as follows:

- Start the `onu_hal_mock` and `tr181-xpon` as explained before.
- The `onu_hal_mock` reports "On,Off,LowPower" as value for "XPON.ONU.1.PowerCapability".
- Do a `ChangePowerMode()` call in ubus-cli:

```
XPON.ONU.1.ChangePowerMode(PowerState = "Off")
```

`tr181-xpon` calls `change_power_mode()` in the VM. It passes a call ID. The call ID is visible in the logs of `tr181-xpon` and the ONU HAL mock. E.g. in the output of `tr181-xpon`:

```
Aug 26 11:28:25 9694fda7eb3d tr181-xpon[564]: module  - [d]path='xpon_onu.1' call_id=2 power_state=Off timeout_ms=5000 - (sbi_change_power_mode@southbound_if.c:449)
```

Run the debugtool and pass the call ID and the result. The 'signature' is as follows:

```
./dbgtool send_change_power_mode_result <call_id> [result]
```

`result` indicates whether the `change_power_mode()` succeeded: 0 indicates success, a value different from 0 indicates an error.

Example:

```
./dbgtool send_change_power_mode_result 2 0
```

Run `dbgtool` without args to get help about the args.

The log message above shows `tr181-xpon` calls `change_power_mode()` with a value of 5000 ms for `timeout_ms`. Hence `tr181-xpon` expects a reply within 5 s. If you do not call `./dbgtool send_change_power_mode_result` to send a reply, the `ChangePowerMode()` call times out:

```
 > XPON.ONU.1.ChangePowerMode(PowerState = "Off")
ERROR: call XPON.ONU.1.ChangePowerMode() failed with status 27 - timeout

sahsioux01 - ubus: - [ubus-cli] (27)
 > 
```

If you send a reply within the timeout period with value 0 for the option `result` indicating success, e.g. with:

```
./dbgtool send_change_power_mode_result 3 0
```

`ubus-cli` shows:

```
 > XPON.ONU.1.ChangePowerMode(PowerState = "Off")
XPON.ONU.1.ChangePowerMode() returned
[
    ""
]

sahsioux01 - ubus: - [ubus-cli] (0)
```

If you send a reply within the timeout period with value 1 for the option `result` indicating an error, e.g. with:

```
./dbgtool send_change_power_mode_result 4 1
```

`ubus-cli` shows:

```
 > XPON.ONU.1.ChangePowerMode(PowerState = "Off")
ERROR: call XPON.ONU.1.ChangePowerMode() failed with status 1 - unknown error

sahsioux01 - ubus: - [ubus-cli] (1)
 > 
```


