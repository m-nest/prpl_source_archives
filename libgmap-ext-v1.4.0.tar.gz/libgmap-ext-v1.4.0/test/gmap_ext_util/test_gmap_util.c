/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "test_gmap_util.h"
#include "gmap_ext_util.h"

#include <stdio.h>


void test_path_to_last_index(UNUSED void** state) {
    assert_int_equal(0, gmap_ext_path_to_last_index(NULL));
    assert_int_equal(0, gmap_ext_path_to_last_index(""));
    assert_int_equal(0, gmap_ext_path_to_last_index("Test"));
    assert_int_equal(0, gmap_ext_path_to_last_index("Test."));
    assert_int_equal(17, gmap_ext_path_to_last_index("17"));
    assert_int_equal(18, gmap_ext_path_to_last_index("18."));
    assert_int_equal(19, gmap_ext_path_to_last_index(".19."));
    assert_int_equal(20, gmap_ext_path_to_last_index("Test.20."));
    assert_int_equal(645, gmap_ext_path_to_last_index("Test.645.Object"));
    assert_int_equal(869, gmap_ext_path_to_last_index("Test.869.Object."));
    assert_int_equal(45, gmap_ext_path_to_last_index("Test.45.Object.E40."));
    assert_int_equal(519, gmap_ext_path_to_last_index("Test.519.Object.123-piano."));
    assert_int_equal(51, gmap_ext_path_to_last_index("Test.51.Object....."));
    assert_int_equal(64, gmap_ext_path_to_last_index("Test.51.Object.Sub.64"));
    assert_int_equal(87, gmap_ext_path_to_last_index("Test.51.Object.Sub.87."));
    /* First item is out of range, but shouldn't lead to issues */
    assert_int_equal(7, gmap_ext_path_to_last_index("Test.86471864718641677.Object.Sub.7."));
    /* Second item is out of range */
    assert_int_equal(31, gmap_ext_path_to_last_index("Test.31.Object.Sub.86688678617645186718671."));
}
