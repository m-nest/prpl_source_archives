/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025  Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "conntrackingquery.h"

static conntrackingquery_app_t app;

/**
 * @brief Retrieves the NotifyFlow data model object for the NotifyFlow query
 *
 * Searches the data model for the "ConnectionTrackingQuery.NotifyFlow" object
 * and returns it.
 *
 * @param dm  Pointer to the data model
 * @return amxd_object_t* Pointer to the Notify flow object, or NULL if not found.
 */

amxd_object_t* query_template(amxd_dm_t* dm) {
    amxd_object_t* templ = NULL;
    templ = amxd_dm_findf(dm, "ConnectionTrackingQuery.NotifyFlow");
    return templ;
}

/**
 * @brief Retrieve the data model handle for the tr181-Conntrack-query application.
 *
 * Get the data model handle for tr181-Conntrack-query app
 *
 * @return amxd_dm_t* Pointer to the tr181-Conntrack-query datamodel
 */
amxd_dm_t* query_get_dm(void) {
    return app.dm;
}

/**
 * @brief Sets the data model and parser for the application context.
 *
 * Sets the data model and parser reference for tr181-Conntrack-query application
 *
 * @param dm data model pointer
 * @param parser pointer to the tr181-Conntrack-query parser
 */

static void query_set_dm_parser(amxd_dm_t* dm, amxo_parser_t* parser) {

    app.dm = dm;
    app.parser = parser;

}

/**
 * @brief Initializes or cleans up the connection tracking query module based on lifecycle events.
 *
 * On start, it registers signal handlers and sets the data model and parser.
 * On stop, it clears the application context.
 *
 * @param reason Integer indicating the application lifecycle phase (e.g., AMXO_START or AMXO_STOP).
 * @param dm  Pointer to the data model
 * @param parser pointer to the application's parser
 *
 * @return int Returns 0 after processing the events
 */

int _connectiontrackingquery_main(int reason,
                                  amxd_dm_t* dm,
                                  amxo_parser_t* parser) {
    int retval = -1;

    when_null(dm, exit);
    when_null(parser, exit);


    switch(reason) {

    case AMXO_START:
        SAH_TRACEZ_INFO(ME, "START event received\n");
        //query_signal_register();
        query_set_dm_parser(dm, parser);
        SAH_TRACEZ_INFO(ME, "Initialization completed: retval = %d\n", retval);
        retval = 0;
        break;

    case AMXO_STOP:

        SAH_TRACEZ_INFO(ME, "STOP event received\n");
        app.dm = NULL;
        app.parser = NULL;
        query_destroy_unix_socket();
        retval = 0;
        break;
    default:
        break;
    }

exit:
    SAH_TRACEZ_ERROR(ME, "Initialization : retval = %d\n", retval);
    return retval;
}


/**
 * @brief Logs the start of a connection tracking query application.
 * Logs the start of a connection tracking query application.
 *
 * @param sig_name Name of the event
 * @return void
 */
void _conntrack_query_start(const char* const sig_name,
                            UNUSED const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    SAH_TRACEZ_INFO(ME, "Received event [%s]", sig_name);
}


/**
 * @brief Cleans up all query instances when a stop event is received.
 * Cleans up all query instances when a stop event is received.
 *
 * @param sig_name Name of the event
 * @return void
 */
void _conntrack_query_stop(const char* const sig_name,
                           UNUSED const amxc_var_t* const event_data,
                           UNUSED void* const priv) {
    amxd_dm_t* dm = query_get_dm();
    amxd_object_t* queries = query_template(dm);

    SAH_TRACEZ_INFO(ME, "Received event: [%s]", sig_name);

    when_null(queries, exit);
    amxd_object_for_all(queries, "*", query_cleanup, NULL);
    query_destroy_unix_socket();

exit:
    return;
}
