/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>
#include "bulkdata.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_parameter.h"
#include "bulkdata_profile_json_encoding.h"
#include "bulkdata_profile_csv_encoding.h"
#include "bulkdata_profile_mqtt.h"
#include "bulkdata_profile_http.h"

#define ME "profile"

#define MIN_SEC INT64_C(-62135596800)   /* 0001-01-01T00:00:00 */

amxd_object_t* bulkdata_get_profile_object(void) {
    return amxd_object_findf(bulkdata_get_root_object(), "Profile");
}

int32_t bulkdata_profile_get_number_of_retained_failed_reports(amxd_object_t* profile) {
    return amxd_object_get_value(int32_t, profile, "NumberOfRetainedFailedReports", NULL);
}

const cstring_t bulkdata_profile_get_alias(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "Alias"));
}

const cstring_t bulkdata_profile_get_protocol(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "Protocol"));
}

const cstring_t bulkdata_profile_get_encoding_type(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "EncodingType"));
}

uint32_t bulkdata_profile_get_reporting_interval(amxd_object_t* profile) {
    return amxd_object_get_value(uint32_t, profile, "ReportingInterval", NULL);
}

const amxc_ts_t* bulkdata_profile_get_time_reference(amxd_object_t* profile) {
    return amxc_var_constcast(amxc_ts_t, amxd_object_get_param_value(profile, "TimeReference"));
}

const cstring_t bulkdata_profile_get_streaming_host(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "StreamingHost"));
}

uint16_t bulkdata_profile_get_streaming_port(amxd_object_t* profile) {
    return amxd_object_get_value(uint16_t, profile, "StreamingPort", NULL);
}

uint8_t bulkdata_profile_get_streaming_session_id(amxd_object_t* profile) {
    return amxd_object_get_value(uint8_t, profile, "StreamingSessionID", NULL);
}

const cstring_t bulkdata_profile_get_file_transfer_url(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "FileTransferURL"));
}

const cstring_t bulkdata_profile_get_file_transfer_username(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "FileTransferUsername"));
}

const cstring_t bulkdata_profile_get_file_transfer_password(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "FileTransferPassword"));
}

const cstring_t bulkdata_profile_get_control_file_format(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "ControlFileFormat"));
}

const cstring_t bulkdata_profile_get_controller(amxd_object_t* profile) {
    return amxc_var_constcast(cstring_t, amxd_object_get_param_value(profile, "Controller"));
}

static int bulkdata_start_profiles_callback(UNUSED amxd_object_t* profiles,
                                            amxd_object_t* profile,
                                            UNUSED void* priv) {
    bulkdata_start_profile(profile);
    return 0;
}

static int bulkdata_stop_profiles_callback(UNUSED amxd_object_t* profiles,
                                           amxd_object_t* profile,
                                           UNUSED void* priv) {
    bulkdata_stop_profile(profile);
    return 0;
}

static int bulkdata_profile_delete_priv(void* priv) {
    profile_priv_t* private_data = (profile_priv_t*) priv;
    when_null(private_data, exit);

    if(NULL != private_data->periodic_timer) {
        amxp_timer_delete(&private_data->periodic_timer);
    }
    if(NULL != private_data->retry_timer) {
        amxp_timer_delete(&private_data->retry_timer);
    }
    if(NULL != private_data->request_elements) {
        amxc_var_delete(&private_data->request_elements);
        private_data->request_elements = NULL;
    }
    private_data->retry_time = 0;
    private_data->retry_attempts = 0;
    free(private_data);
    private_data = NULL;

exit:
    return 0;
}

void bulkdata_start_collection_profiles(void) {
    SAH_TRACEZ_INFO(ME, "Start collection profiles");
    amxd_object_t* profiles = bulkdata_get_profile_object();
    amxd_object_for_all(profiles, "[Enable == true].", bulkdata_start_profiles_callback, NULL);
}

void bulkdata_stop_collection_profiles(void) {
    SAH_TRACEZ_INFO(ME, "Stop collection profiles");
    amxd_object_t* profiles = bulkdata_get_profile_object();
    amxd_object_for_all(profiles, "*", bulkdata_stop_profiles_callback, NULL);
}

static void bulkdata_send_data_usp(amxd_object_t* profile, amxc_var_t* json) {
    amxc_var_t event;
    amxc_var_t* data = NULL;
    amxc_var_t* json_data = NULL;
    const cstring_t encoding_type = NULL;
    const cstring_t string = NULL;

    amxc_var_init(&event);
    amxc_var_set_type(&event, AMXC_VAR_ID_HTABLE);
    data = amxc_var_add_key(amxc_htable_t, &event, "data", NULL);

    encoding_type = bulkdata_profile_get_encoding_type(profile);
    when_null_trace(encoding_type, exit, ERROR, "Unable to get the EncodingType (%s)", amxd_object_get_path(profile, AMXD_OBJECT_NAMED));

    if(strncmp(encoding_type, "JSON", strlen("JSON")) == 0) {
        json_data = amxc_var_add_key(amxc_htable_t, data, "Data", amxc_var_constcast(amxc_htable_t, json));
        amxc_var_cast(json_data, AMXC_VAR_ID_JSON);
    } else if(strncmp(encoding_type, "CSV", strlen("CSV")) == 0) {
        amxc_var_cast(json, AMXC_VAR_ID_CSV_STRING);
        string = amxc_var_constcast(csv_string_t, json);
        amxc_var_add_key(cstring_t, data, "Data", string);
    }
    amxd_object_send_signal(profile, "Push!", &event, false);

exit:
    amxc_var_clean(&event);
}

static void bulkdata_profile_init(amxd_object_t* profile) {
    const cstring_t protocol = bulkdata_profile_get_protocol(profile);

    when_null(protocol, exit);

    if(strcmp(protocol, "USPEventNotif") == 0) {
        // No specific initialization needed
    } else if(strcmp(protocol, "MQTT") == 0) {
        bulkdata_profile_mqtt_init(profile);
    } else if(strcmp(protocol, "HTTP") == 0) {
        // No specific init action is needed
    } else if(strcmp(protocol, "File") == 0) {
        // Not supported yet
    } else if(strcmp(protocol, "Streaming") == 0) {
        // Not supported yet
    }

exit:
    return;
}

static void bulkdata_profile_clean(amxd_object_t* profile) {
    const cstring_t protocol = bulkdata_profile_get_protocol(profile);

    when_null(protocol, exit);

    if(strcmp(protocol, "USPEventNotif") == 0) {
        // No specific clean up needed
    } else if(strcmp(protocol, "MQTT") == 0) {
        amxd_object_t* mqtt_obj = amxd_object_findf(profile, "MQTT");
        bulkdata_profile_mqtt_clean(mqtt_obj);
    } else if(strcmp(protocol, "HTTP") == 0) {
        // No specific clean up needed
    } else if(strcmp(protocol, "File") == 0) {
        // Not supported yet
    } else if(strcmp(protocol, "Streaming") == 0) {
        // Not supported yet
    }

exit:
    return;
}

static void bulkdata_send_data(amxd_object_t* profile, amxc_var_t* data) {
    const cstring_t protocol = bulkdata_profile_get_protocol(profile);
    when_str_empty_trace(protocol, exit, ERROR, "Failed to get protocol");
    when_null_trace(data, exit, ERROR, "Failed to get data");

    if(strcmp(protocol, "USPEventNotif") == 0) {
        bulkdata_send_data_usp(profile, data);
    } else if(strcmp(protocol, "MQTT") == 0) {
        bulkdata_profile_mqtt_send_data(profile, data);
    } else if(strcmp(protocol, "HTTP") == 0) {
        bulkdata_profile_http_send_data(profile, data);
    } else if(strcmp(protocol, "File") == 0) {
        // Not supported yet
    } else if(strcmp(protocol, "Streaming") == 0) {
        // Not supported yet
    }
exit:
    return;
}

static amxc_var_t* bulkdata_format_data(amxd_object_t* profile, amxc_var_t* data) {
    const cstring_t encoding_type = bulkdata_profile_get_encoding_type(profile);

    when_null_trace(encoding_type, exit, ERROR, "Failed to get the encoding type");

    if(strcmp(encoding_type, "JSON") == 0) {
        return bulkdata_json_format_data(profile, data);
    } else if(strcmp(encoding_type, "CSV") == 0) {
        return bulkdata_csv_format_data(profile, data);
    } else if(strcmp(encoding_type, "XDR") == 0) {
        // Not supported yet
    } else if(strcmp(encoding_type, "XML") == 0) {
        // Not supported yet
    }
exit:
    return NULL;
}

static amxc_var_t* bulkdata_add_data_in_report(amxc_var_t* data) {
    /* Add data in an array */
    amxc_var_t* array = NULL;
    amxc_var_t* report = NULL;

    amxc_var_new(&array);
    amxc_var_set_type(array, AMXC_VAR_ID_LIST);
    amxc_var_add(amxc_htable_t, array, amxc_var_constcast(amxc_htable_t, data));
    /* Add the array in an htable an name it "Report" */
    amxc_var_new(&report);
    amxc_var_set_type(report, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(amxc_llist_t, report, "Report", amxc_var_constcast(amxc_llist_t, array));
    /* Cleanup */
    amxc_var_delete(&array);
    return report;
}

static profile_encoding bulkdata_profile_get_encoding(amxd_object_t* profile) {
    profile_encoding ret = PROFILE_ENCODING_UNDEFINED;
    const cstring_t encoding = NULL;
    when_null(profile, exit);

    encoding = bulkdata_profile_get_encoding_type(profile);
    when_null(encoding, exit);

    if(strncmp(encoding, "JSON", strlen(encoding)) == 0) {
        ret = PROFILE_ENCODING_JSON;
    } else if(strncmp(encoding, "CSV", strlen(encoding)) == 0) {
        ret = PROFILE_ENCODING_CSV;
    }

exit:
    return ret;
}

static void bulkdata_profile_stop_retry_mechanism(amxd_object_t* profile) {
    when_null(profile, exit);
    profile_priv_t* private_data = (profile_priv_t*) profile->priv;

    if(NULL != private_data->retry_timer) {
        SAH_TRACEZ_INFO(ME, "HTTP retry mechanism was aborted due to periodic events (profile %s)",
                        amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
        amxp_timer_delete(&private_data->retry_timer);
    }

    if(NULL != private_data->request_elements) {
        amxc_var_delete(&private_data->request_elements);
        private_data->request_elements = NULL;
    }

    private_data->retry_time = 0;
    private_data->retry_attempts = 0;
exit:
    return;
}

static void bulkdata_profile_collect(amxp_timer_t* timer UNUSED, void* priv) {
    amxd_object_t* profile = (amxd_object_t*) priv;
    bulkdata_profile_stop_retry_mechanism(profile);

    SAH_TRACEZ_INFO(ME, "Collect profile %s", amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
    profile_encoding encoding = bulkdata_profile_get_encoding(profile);

    amxc_var_t* data = bulkdata_retrieve_parameters(profile, encoding);
    amxc_var_t* formatted_data = NULL;
    amxc_var_t* report = NULL;

    if(data == NULL) {
        SAH_TRACEZ_INFO(ME, "Nothing to collect");
        return;
    }
    formatted_data = bulkdata_format_data(profile, data);
    if(PROFILE_ENCODING_JSON == encoding) {
        report = bulkdata_add_data_in_report(formatted_data);
    } else {
        report = formatted_data;
    }
    bulkdata_send_data(profile, report);

    if(PROFILE_ENCODING_JSON == encoding) {
        amxc_var_delete(&report);
    }
    amxc_var_delete(&formatted_data);
    amxc_var_delete(&data);
}

static uint32_t bulkdata_compute_timeout(uint32_t interval, const amxc_ts_t* time_reference) {
    amxc_ts_t ts_now;
    int64_t diff_time = 0;

    if((amxc_ts_now(&ts_now) < 0) || (time_reference->sec == MIN_SEC)) {
        SAH_TRACEZ_INFO(ME, "Undefined time, return 0");
        return 0;
    }
    diff_time = (time_reference->sec - ts_now.sec) % interval;
    SAH_TRACEZ_INFO(ME, "time_ref = %" PRIi64 " - now = %" PRIi64 " - diff_time = %" PRIi64 " - return %" PRIi64,
                    time_reference->sec, ts_now.sec, diff_time, diff_time > 0 ? diff_time : diff_time + interval);
    /* Modulo can be negative number so we need to make it positive */
    return diff_time > 0 ? diff_time : diff_time + interval;
}

amxd_status_t _ForceCollection(amxd_object_t* object,
                               UNUSED amxd_function_t* func,
                               UNUSED amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {

    if(!object) {
        return amxd_status_object_not_found;
    }
    //collect Profile
    amxd_object_t* profile = object;
    SAH_TRACEZ_INFO(ME, "ForceCollection for profile %s", amxd_object_get_name(object, AMXD_OBJECT_INDEXED));
    //send profile for collection
    bulkdata_profile_collect(NULL, profile);

    return amxd_status_ok;
}

void bulkdata_start_profile(amxd_object_t* profile) {
    amxp_timer_t* timer = NULL;
    uint32_t interval = 0;
    const amxc_ts_t* time_reference = NULL;
    uint32_t timeout = 0;
    profile_priv_t* private_data = NULL;
    bool synchronized = bulkdata_get_sync();

    when_null(profile, exit);

    if(!synchronized) {
        SAH_TRACEZ_WARNING(ME, "Time synchronization is not done yet, delay starting profile %s",
                           amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Start profile %s", amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
    /* Initialize profile */
    bulkdata_profile_init(profile);
    /* Initialize timer */
    amxp_timer_new(&timer, bulkdata_profile_collect, profile);
    /* If the previous timer was not deleted, do it here */
    if(profile->priv != NULL) {
        bulkdata_profile_delete_priv(profile->priv);
    }
    private_data = calloc(1, sizeof(profile_priv_t));
    when_null_trace(private_data, exit, ERROR, "Unable to create private data for profile %s",
                    amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
    private_data->periodic_timer = timer;
    profile->priv = private_data;

    /* Set interval */
    interval = bulkdata_profile_get_reporting_interval(profile);
    amxp_timer_set_interval(timer, interval * 1000);
    /* Set timeout based on interval and time reference */
    time_reference = bulkdata_profile_get_time_reference(profile);
    timeout = bulkdata_compute_timeout(interval, time_reference);
    amxp_timer_start(timer, timeout * 1000);

exit:
    return;
}

void bulkdata_stop_profile(amxd_object_t* profile) {
    when_null(profile, exit);
    SAH_TRACEZ_INFO(ME, "Stop profile %s", amxd_object_get_name(profile, AMXD_OBJECT_NAMED));

    bulkdata_profile_clean(profile);
    /* free or delete everything */
    bulkdata_profile_delete_priv(profile->priv);
    profile->priv = NULL;
exit:
    return;
}

void bulkdata_update_timer(amxd_object_t* profile) {
    if(profile == NULL) {
        return;
    }
    SAH_TRACEZ_INFO(ME, "Update profile %s's", amxd_object_get_name(profile, AMXD_OBJECT_NAMED));
    /* If we change ReportingInterval or TimeReference Report MUST be sent immediatly if profile is enabled */
    /* profile->priv is NULL if the profile is disable */
    if(profile->priv != NULL) {
        bulkdata_stop_profile(profile);
        bulkdata_start_profile(profile);
    }
}
