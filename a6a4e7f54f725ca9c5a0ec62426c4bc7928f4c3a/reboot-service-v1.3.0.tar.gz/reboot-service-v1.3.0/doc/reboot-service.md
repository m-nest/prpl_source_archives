# **Reboot Reasons**
[Requirements](#rebootreasons-requirements) 

[Introduction and High-Level Description](#rebootreasons-introductionandhigh-leveldescription)

[Use Case Definition](#rebootreasons-usecasedefinition)

[References](#rebootreasons-references)

[Architecture](#rebootreasons-architecture)

[Implementation](#rebootreasons-implementation) 

[Data Model](#rebootreasons-datamodel)

[Low-Level API](#rebootreasons-low-levelapi)

[API](#rebootreasons-api)

[Files](#rebootreasons-files)

[Firewall](#rebootreasons-firewall)

[Dependants and Dependencies](#rebootreasons-dependantsanddependencies) 

[Dependants](#rebootreasons-dependants)

[Dependencies](#rebootreasons-dependencies)

[Configuration](#rebootreasons-configuration)

[Backup/Restore, Upgrade, Reset](#rebootreasons-backup/restore,upgrade,reset)

[Web UI](#rebootreasons-webui)

[Considerations](#rebootreasons-considerations) 

[IPv6](#rebootreasons-ipv6)

[Packet Acceleration](#rebootreasons-packetacceleration)

[Memory Usage](#rebootreasons-memoryusage)

[Boot Time](#rebootreasons-boottime)

[Security](#rebootreasons-security)

[Remote Management](#rebootreasons-remotemanagement)

[Operational Monitoring](#rebootreasons-operationalmonitoring)

[Quality](#rebootreasons-quality) 

[Project Reference Configuration](#rebootreasons-projectreferenceconfiguration)

[Build-time Checks](#rebootreasons-build-timechecks)

[Run-time Checks](#rebootreasons-run-timechecks)

[Unit Tests](#rebootreasons-unittests)

[Logging and Debugging](#rebootreasons-logginganddebugging)

[Functional Tests](#rebootreasons-functionaltests)

[CI Tests](#rebootreasons-citests)

[Certification](#rebootreasons-certification)

[Design Review Documentation](#rebootreasons-designreviewdocumentation)
# <a name="rebootreasons-requirements"></a>**Requirements**
## <a name="rebootreasons-introductionandhigh-leveldescription"></a>**Introduction and High-Level Description**
This feature aims at logging and exposing in Datamodel an history of CPE reboots and whenever possible a cause and reason.

The goal is to help diagnose on the field any unexpected reboot of CPE and allow further investigations.
## <a name="rebootreasons-usecasedefinition"></a>**Use Case Definition**
<https://prplfoundationcloud.atlassian.net/issues/?jql=key%20in%20(PCF-1195%2C%20HAPM-74%2C%20LLAPI-4)> 
## <a name="rebootreasons-references"></a>**References**
- TR-181 datamodel references (v2.18.1):
  - Device.Reboot() command: <https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.Reboot>
  - Device.DeviceInfo.Reboots. : <https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.Reboots.>
- Reboot reasons in the Linux kernel watchdog framework:<https://docs.kernel.org/watchdog/watchdog-api.html?highlight=watchdog>
# <a name="rebootreasons-architecture"></a>**Architecture**
# <a name="rebootreasons-implementation"></a>**Implementation**
The plugin must manage two types of reboots: **planned** and **unattended** (e.g., power cuts, watchdog events).

1. **Planned Reboots**:
   The Device.Reboot() command can be invoked by a service, end-user interface, or remote controller. The cause for the reboot should be specified as either LocalReboot or RemoteReboot, depending on the source of the command.
1. **Unexpected Reboots**:
   For unexpected reboots, the reason must be determined primarily through the system watchdog. Please refer to the **Low-Level API** section for further details.

Additionally, reboot plugin will listen on tr181-Temperature HighTemperatureAlarm! events to preemptively mark Overheat reason in case system was to freeze due to overheating
## <a name="rebootreasons-datamodel"></a>**Data Model**
See [Reboot reasons](file:///C:/wiki/spaces/HLAP/pages/804847634/Reboot+reasons)

Data model was standardized as part of TR181 v2.18.1.

Main data-model definition is available on broadband forum website here Device.DeviceInfo.Reboots. : <https://usp-data-models.broadband-forum.org/tr-181-2-18-1-usp.html#D.Device:2.Device.DeviceInfo.Reboots.>

Note that the standard Device.Reboot() command was extended to allow two new Input parameters: Cause and reason.
## <a name="rebootreasons-low-levelapi"></a>**Low-Level API**
The Linux watchdog framework allows for registration of multiple watchdog devices. The assumption is that only one will be registered, or the primary SoC watchdog will be registered first, as watchdog0.

The CONFIG\_WATCHDOG kernel configuration parameter must be set.

Status can be queried through ioctl on a character device:

```
fd = open("/dev/watchdog0", O\_WRONLY|O\_CLOEXEC);
ioctl(fd, WDIOC\_GETSTATUS, &wd->status);
ioctl(fd, WDIOC\_GETBOOTSTATUS, &wd->bstatus);
```
or through sysfs, if CONFIG\_WATCHDOG\_SYSFS is set:
```
$ cat /sys/class/watchdog/watchdog0/bootstatus
0
$ cat /sys/class/watchdog/watchdog0/status 
0x8200
```
The following statuses exist in the Linux watchdog interface: <https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/include/uapi/linux/watchdog.h#n39>
```
#define	WDIOF\_OVERHEAT		0x0001	/\* Reset due to CPU overheat \*/
#define	WDIOF\_FANFAULT		0x0002	/\* Fan failed \*/
#define	WDIOF\_EXTERN1		0x0004	/\* External relay 1 \*/
#define	WDIOF\_EXTERN2		0x0008	/\* External relay 2 \*/
#define	WDIOF\_POWERUNDER	0x0010	/\* Power bad/power fault \*/
#define	WDIOF\_CARDRESET		0x0020	/\* Card previously reset the CPU \*/
#define	WDIOF\_POWEROVER		0x0040	/\* Power over voltage \*/
```
When querying the watchdog status (WDIOC\_GETSTATUS), they are returned as a bitmap:
<https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/drivers/watchdog/watchdog_dev.c#n323>
```
        status = wdd->bootstatus & (WDIOF\_CARDRESET |
                        WDIOF\_OVERHEAT |
                        WDIOF\_FANFAULT |
                        WDIOF\_EXTERN1 |
                        WDIOF\_EXTERN2 |
                        WDIOF\_POWERUNDER |
                        WDIOF\_POWEROVER);
```
When querying the watchdog boot status (WDIOC\_GETBOOTSTATUS), the status at boot is returned, which is the relevant status for use as the reboot reason.

Note that it is therefore theoretically possible that multiple boot statuses are set. This is assumed to be unlikely, or an incorrect implementation, but nonetheless, the reboot reason implementation must tests the status bits in order of the following priority, and report only the first.:
```
WDIOF\_FANFAULT
WDIOF\_OVERHEAT
WDIOF\_CARDRESET
WDIOF\_EXTERN1
WDIOF\_EXTERN2
WDIOF\_POWEROVER
WDIOF\_POWERUNDER
```
The logic is that overheating is important to report, and a fan failure may be the cause of it. A watchdog-triggered reboot is important, but not as critical as a hardware failure that may be a fire hazard. External watchdogs are unlikely, but this would be a correct modelling. Overvoltage indicates a problem with the power supply. Power loss is an expected, mundane, cause in a residential environment.

Mapping of watchdog boot status to Cause and Reason in the data model:

||**wdd->bootstatus**|**Cause**|**Reason**|
| :-: | :-: | :-: | :-: |
|hardware watchdog triggered|WDIOF\_CARDRESET|LocalReboot|HardwareWatchdog|
|power failed, cold boot|WDIOF\_POWERUNDER|LocalReboot|PowerOnReset|
|fan failed|WDIOF\_FANFAULT|LocalReboot|FanFault|
|overheat|WDIOF\_OVERHEAT|LocalReboot|Overheat|
|over-Voltage situation; power supply fault|WDIOF\_POWEROVER|LocalReboot|PowerOver|
|external watchdog 1|WDIOF\_EXTERN1|LocalReboot|?|
|external watchdog 2|WDIOF\_EXTERN2|LocalReboot|?|

As watchdog device can be opened by only a single process (see <https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/drivers/watchdog/watchdog_dev.c#n859>) and this is already opened by procd early in boot, the proper interface to use for reboot reason would be the sysfs path
## <a name="rebootreasons-api"></a>**API**
No custom API. Only Standard TR-181 HL-API used

## <a name="rebootreasons-files"></a>**Files**
For planned reboots, reason is stored in userspace in a a file before reboot, so it can be retrieved and parsed on next boot.

A reset persistent file is also supported to allow carrying over reboot reasons due to a board reset.

Location are configurable via parameters in /etc/amx/reboot-service/reboot-service.odl:

- rbt\_reason\_file: path for regular reboot persistent file. Default is set to /cfg/reboot\_reason.json.
- rst\_reason\_file: path for factory reset persistent. It needs to point to a path that is not erased during reset. Default is set to /perm/freset\_reason.json.

Both files are parsed when the plugin starts to populate a new datamodel entry and removed once parsing has been done.
## <a name="rebootreasons-firewall"></a>**Firewall**
N/A
## <a name="rebootreasons-dependantsanddependencies"></a>**Dependants and Dependencies**
### <a name="rebootreasons-dependants"></a>**Dependants**
### <a name="rebootreasons-dependencies"></a>**Dependencies**
Weak dependencies on following part of system:

- System watchdog: used to retrieve unexpected boot reasons
  - kernel configuration CONFIG\_WATCHDOG\_SYSFS must be set to allow retrieval of watchdog informations
- tr181-temperature: to listen for overheating event and trigger reboot
## <a name="rebootreasons-configuration"></a>**Configuration**
Data model has no writeable parameter.

Configuration file used is /etc/amx/reboot-service/reboot-service.odl.

Aside standard ambiorix service configuration only file path are specific (see Files section).
## <a name="rebootreasons-backup/restore,upgrade,reset"></a>**Backup/Restore, Upgrade, Reset**
Reboot entries are kept over reboot and upgrade.

Specific counters are also both reboot and upgrade persistent.

Note that by design a new reboot entry is created on every boot.
## <a name="rebootreasons-webui"></a>**Web UI**
N/A
# <a name="rebootreasons-considerations"></a>**Considerations**
## <a name="rebootreasons-ipv6"></a>**IPv6**
N/A
## <a name="rebootreasons-packetacceleration"></a>**Packet Acceleration**
N/A
## <a name="rebootreasons-memoryusage"></a>**Memory Usage**
## <a name="rebootreasons-boottime"></a>**Boot Time**
no specific impact
## <a name="rebootreasons-security"></a>**Security**
The plugin executes with the tr181\_app user and drop all the capabilities except:

- CAP\_DAC\_OVERRIDE : To allow writes access to reboot reason files (see Files section)
## <a name="rebootreasons-remotemanagement"></a>**Remote Management**
A remote controller can call the Device.Reboot() command to perform a CPE reboot. It is expected that Cause parameter will be set to RemoteRebootvalue by teh controller.
## <a name="rebootreasons-operationalmonitoring"></a>**Operational Monitoring**
# <a name="rebootreasons-quality"></a>**Quality**
## <a name="rebootreasons-projectreferenceconfiguration"></a>**Project Reference Configuration**
## <a name="rebootreasons-build-timechecks"></a>**Build-time Checks**
## <a name="rebootreasons-run-timechecks"></a>**Run-time Checks**
## <a name="rebootreasons-unittests"></a>**Unit Tests**
## <a name="rebootreasons-logginganddebugging"></a>**Logging and Debugging**
Only one trace zone is supported:

- reboot: display logs about reboot service
## <a name="rebootreasons-functionaltests"></a>**Functional Tests**
|**Step**|**Test designation**|**Description** |**Expected result**|
| :-: | :-: | :-: | :-: |
|1|Initial datamodel (after factory reset)|ba-cli Device.DeviceInfo.Reboots.?|Initial datamodel with only one boot accounting for the reset.|
|2|Perform controlled reboot|Device.Reboot(Cause = "LocalReboot", Reason = "I need to demo reboot")|<p>- Device reboots</p><p>- A new Reboots entry should be created and counters incremented by one</p>|
## <a name="rebootreasons-citests"></a>**CI Tests**
CI setup doesn’t allow testing reboot use cases for now.

CRAM tests are limited to fetch initial boot reason and flushing it.

<https://gitlab.com/prpl-foundation/prplos/prplos/-/blob/mainline-3.1/.gitlab/tests/cram/generic/acceleration-plan-components/095-reboot-service.t?ref_type=heads>
## <a name="rebootreasons-certification"></a>**Certification**
# <a name="rebootreasons-designreviewdocumentation"></a>**Design Review Documentation**
