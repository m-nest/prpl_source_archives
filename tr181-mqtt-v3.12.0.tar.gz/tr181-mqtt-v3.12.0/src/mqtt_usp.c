/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace.h>

#include "mqtt_usp.h"

static void connection_read(int fd, void* priv) {
    amxb_bus_ctx_t* ctx = (amxb_bus_ctx_t*) priv;
    amxo_parser_t* parser = mqtt_get_parser();

    if(amxb_read(ctx) != 0) {
        SAH_TRACEZ_WARNING(ME, "Failed to read on direct tr181-mqtt connection, did the remote end hang up?");
        amxo_connection_remove(parser, fd);
        amxb_free(&ctx);
    }
}

static void connection_accept(UNUSED int fd, void* priv) {
    int retval = -1;
    amxb_bus_ctx_t* new_ctx = NULL;
    amxb_bus_ctx_t* listen_ctx = (amxb_bus_ctx_t*) priv;
    amxo_parser_t* parser = mqtt_get_parser();

    retval = amxb_accept(listen_ctx, &new_ctx);
    if(retval == 0) {
        SAH_TRACEZ_INFO(ME, "Accept new connection on pcb listen socket");
        amxo_connection_add(parser, amxb_get_fd(new_ctx), connection_read, NULL, AMXO_BUS, new_ctx);
    }
}

void mqtt_usp_setup_listen_socket(amxo_parser_t* parser) {
    int retval = -1;
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t uri;

    amxc_string_init(&uri, 0);
    amxc_string_setf(&uri, "pcb:%s/tr181-mqtt", SOCKET_DIR);

    retval = amxb_listen(&ctx, amxc_string_get(&uri, 0));
    if(retval == 0) {
        SAH_TRACEZ_INFO(ME, "Setup listen socket on %s", amxc_string_get(&uri, 0));
        amxo_connection_add(parser, amxb_get_fd(ctx), connection_accept, NULL, AMXO_LISTEN, ctx);
    } else {
        SAH_TRACEZ_WARNING(ME, "Failed to listen on %s (expected if pcb is not used)",
                           amxc_string_get(&uri, 0));
        goto exit;
    }

    retval = amxb_register(ctx, mqtt_get_dm());
    if(retval != 0) {
        SAH_TRACEZ_WARNING(ME, "Failed to register DM");
    }

exit:
    amxc_string_clean(&uri);
    return;
}
