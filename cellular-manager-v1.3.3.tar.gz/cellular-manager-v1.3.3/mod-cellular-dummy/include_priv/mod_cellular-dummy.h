/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SMOCA_HALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__MOD_CELLULAR_DUMMY_H__)
#define __MOD_CELLULAR_DUMMY_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>

#include <cellular_priv.h>

// module names
#define MOD_CELLULAR_CTRL "cellular-ctrl"

typedef struct _cell_dummy_bearer_ipcfg {
    char method[10];
    char addr[40];    //local IP address
    char gateway[40]; //Next hop IP address (technically could be empty on a Point-to-Point interface)
    char prefix[25];  // prefix assigned by cellular network to this modem
    uint32_t mtu;
} dummy_cell_bearer_ipcfg_t;

typedef struct _cell_dummy_bearer {
    char name[16]; // Equals to DM Parameter InternalName
    char dns_servers[256];
    dummy_cell_bearer_ipcfg_t ipv4;
    dummy_cell_bearer_ipcfg_t ipv6;
} dummy_cell_bearer_t;

typedef struct _cell_dummy_usim {
    char name[16]; // Equals to DM Parameter InternalName
    char status[10];
    char imsi[16];
    char iccid[21];
    char msisdn[16];
    char pin_check[16];
    char pin[5];
} dummy_cell_usim_t;

typedef struct _cell_dummy_iface {
    bool enable;
    char status[16];
    char object_path[64]; // Cellular.Interface object path
    char name[16];        // Equals to DM Parameter InternalName
    char netdev_name[16]; // Equals to DM Parameter Name
    char imei[16];
    char supported_access_tech[128];
    char preferred_access_tech[128];
    char current_access_tech[128];
    char available_networks[128];
    char network_requested[65];
    char network_in_use[65];
    uint32_t signal_quality_polling_rate;
    int32_t rssi;
    int32_t rsrp;
    int32_t rsrq;
    uint32_t upstream_max_bitrate;
    uint32_t downstream_max_bitrate;
    dummy_cell_usim_t usim;
    dummy_cell_bearer_t bearer;
    amxc_llist_it_t it;
} dummy_cell_iface_t;

int dummy_iface_create(const char* function_name,
                       amxc_var_t* args,
                       amxc_var_t* ret);

int dummy_iface_destroy(const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret);

int dummy_iface_destroy_all(const char* function_name,
                            amxc_var_t* args,
                            amxc_var_t* ret);

int dummy_iface_set(const char* function_name,
                    amxc_var_t* args,
                    amxc_var_t* ret);

int dummy_iface_retrieve(const char* function_name,
                         amxc_var_t* args,
                         amxc_var_t* ret);

int dummy_usim_set(const char* function_name,
                   amxc_var_t* args,
                   amxc_var_t* ret);

int dummy_usim_retrieve(const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret);

int dummy_bearer_retrieve(const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __MOD_CELLULAR_DUMMY_H__
