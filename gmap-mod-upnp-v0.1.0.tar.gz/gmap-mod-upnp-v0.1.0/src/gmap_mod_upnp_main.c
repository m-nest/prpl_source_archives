/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "gmap-mod-upnp.h"

#define UPNP_DEVICE_PATH "UPnPDescription.DeviceInstance."
#define UPNP_SERVICE_PATH "UPnPDescription.ServiceInstance."
#define UPNP_PREFIX "UPnP-"
#define MOD_UPNP_ENTRY_TABLE_SIZE 100

typedef struct _mod_upnp {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxb_subscription_t* upnp_device_subscription_add;
    amxb_subscription_t* upnp_service_subscription_add;
    amxb_subscription_t* upnp_device_subscription_del;
    amxb_subscription_t* upnp_service_subscription_del;
    amxc_htable_t entry_table;
    amxc_llist_t query_list;
} mod_upnp_t;

static mod_upnp_t mod_upnp;

/**
   @ingroup gmap_upnp_module
   @brief Synchronizes the list of UPnP device instances.

   This function fetches all devices under the UPNP_DEVICE_PATH, iterates over them,
   extracts their indices, and triggers the addition of device instances via
   `upnp_add_device_instance()`.

   @param[in] upnp_ctx Pointer to the UPnP bus context.

   @return int Returns 1 on success, or an error code on failure.

   @note The function uses `amxb_get()` to fetch devices and `amxc_htable_for_each()`
        to iterate over the device table. For each device, an event parameter
        structure is created containing the device index and its parameters,
        which is then passed to `upnp_add_device_instance()`.

   @warning Any allocated strings or variables are cleaned up before returning.
 */
static int mod_upnp_sync_device_instance_list(amxb_bus_ctx_t* upnp_ctx) {
    int ret = 1;
    amxc_string_t expr;
    amxc_var_t devices;

    amxc_var_init(&devices);
    amxc_string_init(&expr, 0);

    amxc_string_appendf(&expr, "%s*.", UPNP_DEVICE_PATH);

    ret = amxb_get(upnp_ctx, amxc_string_get(&expr, 0), 0, &devices, gmap_get_timeout());
    when_failed_trace(ret, exit, ERROR, "Could not fetch %s*.", UPNP_DEVICE_PATH);

    amxc_htable_for_each(it, amxc_var_constcast(amxc_htable_t, GETI_ARG(&devices, 0))) {
        int32_t index = 0;
        amxc_var_t event_params;
        amxc_var_t* service = NULL;
        amxc_string_t path;

        amxc_var_init(&event_params);
        amxc_string_init(&path, 0);

        amxc_var_set_type(&event_params, AMXC_VAR_ID_HTABLE);
        amxc_string_set(&path, amxc_htable_it_get_key(it));

        amxc_string_replace(&path, UPNP_DEVICE_PATH, "", 1);
        amxc_string_replace(&path, ".", "", 1);

        index = atoi(amxc_string_get(&path, 0));
        service = amxc_htable_it_get_data(it, amxc_var_t, hit);

        amxc_var_add_key(int32_t, &event_params, "index", index);
        amxc_var_add_key(amxc_htable_t, &event_params, "parameters", amxc_var_constcast(amxc_htable_t, service));

        upnp_add_device_instance(NULL, &event_params, NULL);

        amxc_var_clean(&event_params);
        amxc_string_clean(&path);
    }

exit:
    amxc_string_clean(&expr);
    amxc_var_clean(&devices);

    return ret;
}

/**
   @ingroup gmap_upnp_module
   @brief Initializes the UPnP module.

   This function initializes internal data structures, finds the UPnP and GMAP
   contexts, sets up GMAP client initialization, subscribes to instance-added and
   instance-removed notifications for devices and services, and synchronizes
   already existing UPnP devices.

   @param[in] dm     Pointer to the data model (AMXD).
   @param[in] parser Pointer to the parser object.

   @return int Returns 0 on success, or an error code on failure.

   @note The function creates subscriptions for device/service addition and removal,
        and calls `mod_upnp_sync_device_instance_list()` to sync existing devices.
        Any allocated strings are cleaned up before returning.

   @warning If subscriptions or context fetching fail, the function logs an error
           and returns immediately.
 */
static int mod_upnp_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    amxb_bus_ctx_t* upnp_ctx = NULL;
    amxb_bus_ctx_t* gmap_ctx = NULL;
    amxc_string_t expr;
    int ret = 0;

    mod_upnp.dm = dm;
    mod_upnp.parser = parser;

    amxc_string_init(&expr, 0);
    amxc_htable_init(&mod_upnp.entry_table, MOD_UPNP_ENTRY_TABLE_SIZE);
    amxc_llist_init(&mod_upnp.query_list);

    upnp_ctx = amxb_be_who_has(UPNP_DEVICE_PATH);
    when_null_trace(upnp_ctx, exit, ERROR, "Could not find %s", UPNP_DEVICE_PATH);
    gmap_ctx = amxb_be_who_has("Devices.Device");
    when_null_trace(gmap_ctx, exit, ERROR, "Could not find Devices.Device");

    gmap_client_init(gmap_ctx);

    amxc_string_appendf(&expr, "notification == 'dm:instance-added' && path == '%s'", UPNP_DEVICE_PATH);

    ret = amxb_subscription_new(&mod_upnp.upnp_device_subscription_add,
                                upnp_ctx,
                                UPNP_DEVICE_PATH,
                                amxc_string_get(&expr, 0),
                                upnp_add_device_instance,
                                NULL);
    when_failed_trace(ret, exit, ERROR, "Could not subscribe to the %s object", UPNP_DEVICE_PATH);

    amxc_string_reset(&expr);
    amxc_string_appendf(&expr, "notification == 'dm:instance-added' && path == '%s'", UPNP_SERVICE_PATH);

    ret = amxb_subscription_new(&mod_upnp.upnp_service_subscription_add,
                                upnp_ctx,
                                UPNP_SERVICE_PATH,
                                amxc_string_get(&expr, 0),
                                upnp_add_service_instance,
                                NULL);
    when_failed_trace(ret, exit, ERROR, "Could not subscribe to the %s object", UPNP_SERVICE_PATH);

    amxc_string_reset(&expr);
    amxc_string_appendf(&expr, "notification == 'dm:instance-removed' && path == '%s'", UPNP_DEVICE_PATH);

    ret = amxb_subscription_new(&mod_upnp.upnp_device_subscription_del,
                                upnp_ctx,
                                UPNP_DEVICE_PATH,
                                amxc_string_get(&expr, 0),
                                upnp_remove_deviceinstance,
                                NULL);
    when_failed_trace(ret, exit, ERROR, "Could not subscribe to the %s object", UPNP_DEVICE_PATH);

    amxc_string_reset(&expr);
    amxc_string_appendf(&expr, "notification == 'dm:instance-removed' && path == '%s'", UPNP_SERVICE_PATH);

    ret = amxb_subscription_new(&mod_upnp.upnp_service_subscription_del,
                                upnp_ctx,
                                UPNP_SERVICE_PATH,
                                amxc_string_get(&expr, 0),
                                upnp_remove_serviceinstance,
                                NULL);
    when_failed_trace(ret, exit, ERROR, "Could not subscribe to the %s object", UPNP_SERVICE_PATH);

    ret = mod_upnp_sync_device_instance_list(upnp_ctx);
    when_failed_trace(ret, exit, ERROR, "Could not sync the already existing devices");

exit:
    amxc_string_clean(&expr);
    return ret;
}

/**
   @ingroup gmap_upnp_module
   @brief Cleans up the UPnP module.

   This function releases all resources allocated by the UPnP module, including:
   - Clearing the data model and parser references.
   - Deleting device and service subscriptions.
   - Cleaning up the internal device entry table.
   - Cleaning up the query list.

   @note After this function is called, the UPnP module should not be used
        until it is re-initialized via `mod_upnp_init()`.
 */
static void mod_upnp_clean(void) {
    mod_upnp.dm = NULL;
    mod_upnp.parser = NULL;

    amxb_subscription_delete(&mod_upnp.upnp_device_subscription_add);
    amxb_subscription_delete(&mod_upnp.upnp_service_subscription_add);
    amxb_subscription_delete(&mod_upnp.upnp_service_subscription_del);
    amxb_subscription_delete(&mod_upnp.upnp_device_subscription_del);

    amxc_htable_clean(&mod_upnp.entry_table, mod_upnp_clean_device_entry);
    amxc_llist_clean(&mod_upnp.query_list, mod_upnp_clean_query_entry);
}

void mod_upnp_clean_device_entry(UNUSED const char* key, amxc_htable_it_t* it) {
    ctx_htable_device_entry_t* entry = amxc_container_of(it, ctx_htable_device_entry_t, it);

    amxc_llist_clean(&entry->ctx_services_llist, mod_upnp_clean_sync_entry);
    amxs_sync_ctx_stop_sync(entry->ctx_device);
    amxs_sync_ctx_stop_sync(entry->ctx_discovery);
    amxs_sync_ctx_delete(&entry->ctx_device);
    amxs_sync_ctx_delete(&entry->ctx_discovery);
    amxb_subscription_delete(&entry->discover_device_subscription);
    free(entry->device_name);

    free(entry);
}

void mod_upnp_clean_sync_entry(amxc_llist_it_t* it) {
    sync_ctx_service_llist_entry_t* entry = amxc_container_of(it, sync_ctx_service_llist_entry_t, it);

    amxs_sync_ctx_stop_sync(entry->ctx_service);
    amxs_sync_ctx_delete(&entry->ctx_service);
    free(entry->device_name);

    amxc_llist_it_clean(it, NULL);
    free(entry);
}

void mod_upnp_clean_query_entry(amxc_llist_it_t* it) {
    query_llist_entry_t* entry = amxc_llist_it_get_data(it, query_llist_entry_t, it);
    amxc_var_t* data = (amxc_var_t*) entry->query->data;

    if(data) {
        amxc_var_delete(&data);
    }

    gmap_query_close(entry->query);
    free(entry);
}

amxc_htable_t* mod_upnp_get_entry_table(void) {
    return &mod_upnp.entry_table;
}

amxc_llist_t* mod_upnp_get_query_list(void) {
    return &mod_upnp.query_list;
}

int _gmap_upnp_main(int reason,
                    amxd_dm_t* datamodel,
                    UNUSED amxo_parser_t* parser) {
    int ret = 0;
    switch(reason) {
    case 0:;    /* START */
        ret = mod_upnp_init(datamodel, parser);
        break;

    case 1:     /* STOP */
        mod_upnp_clean();
    default:
        break;
    }

    return ret;
}
