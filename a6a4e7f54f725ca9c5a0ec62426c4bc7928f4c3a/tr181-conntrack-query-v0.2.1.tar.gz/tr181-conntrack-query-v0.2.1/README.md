# Enumerate Conntrack Connections

## 1. Summary, Purpose and Scope

The **Enumerate Conntrack Connections** feature provides a mechanism for retrieving and monitoring connection tracking (conntrack) entries from the Linux kernel.  
It is implemented as a **plugin service** within the prplOS environment and forms part of the **tr181-conntrack-query** module.

This feature allows external services and management frameworks to:
- Retrieve instantaneous snapshots of active network connections.
- Receive event notifications when connection states change (NEW, UPDATE, DELETE).

Its primary purpose is to enhance network visibility, diagnostics, and automation within prplWare-based systems.

---

## 2. Description

The Conntrack Query Manager interfaces with the Linux kernel’s connection tracking subsystem using **libmnl** and **libnetfilter_conntrack** libraries.  
It provides two main interfaces:

1. **RetrieveFlows** – Retrieves the list of current active connections, optionally filtered by protocol, source/destination IP, and ports.  
2. **NotifyFlow** – Subscribes to kernel notifications for connection state changes that match configured filters.

Filtering is performed primarily within the kernel to reduce user-space overhead. Port-based filtering, not supported in the kernel, is handled at user space.

The service runs as a non-persistent prplOS process and may be monitored by the `amx-process-monitor` framework.

---

## 3. Installation Procedure

1. Ensure the build environment is configured for prplOS or equivalent target.  
2. Clone or include the `tr181-conntrack-query` plugin within the **components/core/plugins** directory of the build tree.  
3. Run the standard build process:
   ```bash
   make V=s
   ```
4. Install the resulting package into the target root filesystem:
   ```bash
   sudo make install
   ```
5. Verify installation by checking the plugin binary and associated ODL configuration files under `/etc/amx/`.

---

## 4. Compile and Install Dependencies

The feature depends on the following components and libraries:

| Dependency | Purpose |
|-------------|----------|
| **libmnl** | Provides low-level netlink communication with the kernel. |
| **libnetfilter_conntrack** | Handles kernel conntrack table access and filtering. |
| **amxd, amxc, amxp, amxb, amxo** | Provide data modeling and IPC support for prplWare. |
| **sahtrace** | Logging and trace support. |

To install dependencies manually (for local builds):
```bash
sudo apt install libmnl-dev libnetfilter-conntrack-dev
```

---

## 5. General Requirement

- **Operating System:** prplOS or compatible Linux system with netfilter/conntrack enabled.  
- **Kernel Modules:** `nf_conntrack`, `nfnetlink` must be loaded.  
- **Memory:** Sufficient to support conntrack table (default max 256 entries retrieved per query).  
- **Process Constraints:** Up to 16 concurrent NotifyFlow instances supported.  
- **Protocol Support:** TCP and UDP only.  
- **Wildcard Support:**  
  - IP address `0.0.0.0` matches any IP.  
  - Port `0` matches any port.  

---

## 6. Implementation

The Conntrack Query implementation is divided into three main components:

### a) Conntrack Query Manager
- Manages the lifecycle of worker processes.  
- Exposes RPC interfaces for RetrieveFlows and NotifyFlow operations.  
- Listens on the UNIX domain socket `/var/run/tr181-conntrack-mgr.sock` for worker communication.  
- Parses worker responses and emits TR-181 events.

### b) Conntrack Retrieve Worker
- Uses `libmnl` to query kernel conntrack tables.  
- Applies filtering based on input parameters (protocol, IP, port).  
- Writes results to a temporary file (`/tmp/ct_retrieve_<query>.txt`) and notifies the manager via `SIGUSR1`.

### c) Conntrack Notify Worker
- Uses `libnetfilter_conntrack` to attach filters in kernel space using `nfct_filter_attach()`.  
- Registers a callback (`event_cb`) for NEW, UPDATE, DELETE events.  
- Sends event data to the manager process via UNIX domain sockets.  
- Performs user-space port-based filtering when required.

---

## 7. Background

Linux connection tracking (conntrack) is a kernel subsystem responsible for maintaining the state of network connections.  
It enables applications and firewall rules to identify ongoing connections and related packet flows.

The **Enumerate Conntrack Connections** feature leverages this subsystem to expose two key functions:
- **Query** the current connection tracking table.
- **Subscribe** to real-time connection updates.

By offloading filtering to the kernel (via BPF and netfilter), the feature minimizes latency and CPU overhead compared to user-space parsing.

---

## 8. Functions

### 8.1 RetrieveFlows RPC

Retrieves current active connection tracking entries.

**Prototype:**
```c
htable RetrieveFlows(
    %in string Protocol,
    %in string SourceIP,
    %in string DestIP,
    %in string SourcePort,
    %in string DestPort,
    %in uint16 MaxRtrvEntries
);
```

**Behavior:**
- Returns up to 256 most recent entries by default.
- Supports optional filters for IP, port, and protocol.
- Output includes:
  - SourceIP, DestIP, Protocol, SourcePort, DestPort
  - TxPackets, TxBytes, RxPackets, RxBytes

**Example:**
```bash

ubus call ConnectionTrackingQuery RetrieveFlows
or 
ba-cli 'ConnectionTrackingQuery.RetrieveFlows()'


ubus call ConnectionTrackingQuery RetrieveFlows '{"DestIP":"8.8.8.8"}'
```

### 8.2 NotifyFlow Object

Creates a persistent notification filter for connection state changes.

**Attributes:**
| Parameter | Type | Description |
|------------|------|-------------|
| `Name` | string | Unique filter identifier |
| `Protocol` | string | TCP or UDP |
| `SourceIP` | string | Optional source IP filter |
| `DestIP` | string | Optional destination IP filter |
| `SourcePort` | string | Optional source port filter |
| `DestPort` | string | Optional destination port filter |
| `Event` | string | Filter for specific events (NEW, UPDATE, DELETE) |

**Example:**
```bash
ubus call ConnectionTrackingQuery.NotifyFlow _add '{
  "parameters": { "Name": "Notify_TCP", "Protocol": "tcp", "DestIP": "8.8.4.4" }
}'

or 


ba-cli 'ConnectionTrackingQuery.NotifyFlow+{Name="sample1",DestIP="8.8.8.8"}'
```

---

## 9. Implementation Recommendations

- Use **kernel-based filtering** where possible to optimize performance.  
- Limit concurrent NotifyFlow instances to prevent resource exhaustion.  
- Clean up temporary files under `/tmp/` after RetrieveFlows completion.  
- Validate IP and port parameters before invoking RPCs.  
- Monitor using `amx-process-monitor` to detect hangs or abnormal exits.  
- Keep all queries non-persistent across reboots to ensure system consistency.  
- Use logging via `sahtrace` for traceability during development and integration testing.  

---

© prpl Foundation. All rights reserved.
