/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

/**********************************************************
* Include files
**********************************************************/
#include <syslog.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object_parameter.h>
#include <amxd/amxd_object.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "dm_functions.h"


/**********************************************************
* Macro definitions
**********************************************************/
#define ME "dm functions"

/**********************************************************
* Type definitions
**********************************************************/

/**********************************************************
* Variable declarations
**********************************************************/

/**********************************************************
* Function Prototypes
**********************************************************/

/**********************************************************
* Functions
**********************************************************/

/**
 * @brief Retrieves the certificate and private key URIs from an object representing
 * a row in the Security.Certificate table
 *
 * This function is typically used as a handler for the "GetCertificateURI"
 * method in a USP or TR-181-compliant data model. It attempts to retrieve
 * the values of the `CertificateURI` and `PrivateKeyURI` parameters from
 * the corresponding protected fields in given object and adds them to the
 * `args` variable as output keys.
 *
 * @param[in]  object Pointer to the AMXD object from which the parameters
 *                    should be retrieved. This may be unused depending on
 *                    the context.
 *
 * @param[in]  func   Unused
 *
 * @param[in,out] args A variable container that will be populated with the
 *                     retrieved certificate and key URIs under the keys
 *                     `CertificateURI` and `PrivateKeyURI`, respectively.
 *
 * @param[out] ret   Unused
 *
 * @return `amxd_status_ok` if both URIs were successfully retrieved and added
 *         to the output; otherwise, `amxd_status_parameter_not_found`.
 *
 */
amxd_status_t _GetCertificateURI(UNUSED amxd_object_t* object, UNUSED amxd_function_t* func, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t ret_status = amxd_status_parameter_not_found;
    const amxc_var_t* cert_uri = NULL;
    const amxc_var_t* key_uri = NULL;
    const cstring_t value;

    cert_uri = amxd_object_get_param_value(object, CERTIFICATE_URI_FIELD);
    when_null_trace(cert_uri, exit, ERROR, "Certificate URI field is NULL");
    value = amxc_var_constcast(cstring_t, cert_uri);
    amxc_var_add_key(cstring_t, args, CERTIFICATE_URI_OUTPUT, value);

    key_uri = amxd_object_get_param_value(object, PRIVATE_KEY_URI_FIELD);
    when_null_trace(key_uri, exit, ERROR, "Private key URI field is NULL");
    value = amxc_var_constcast(cstring_t, key_uri);
    amxc_var_add_key(cstring_t, args, PRIVATE_KEY_URI_OUTPUT, value);

    ret_status = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}

/**
 * @brief Retrieves the CADir URI from an object representing
 * a row in the Security.CABundle table.
 *
 * @param[in]  object Pointer to the AMXD object for which the command is called.
 *
 * @param[in]  func   Unused
 *
 * @param[in,out] args Input arguments: N.A. Output arguments: "CADir" with the CADir URI as string value.
 *
 * @param[out] ret   Unused
 *
 * @return `amxd_status_ok` if CADir URI was successfully retrieved and added
 *         to the output; otherwise, `amxd_status_parameter_not_found`.
 *
 */
amxd_status_t _CADir(amxd_object_t* object, UNUSED amxd_function_t* func, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    amxd_status_t ret_status = amxd_status_parameter_not_found;
    const amxc_var_t* uri = NULL;
    const char* value = NULL;

    uri = amxd_object_get_param_value(object, "CADirURI");
    when_null_trace(uri, exit, ERROR, "CABundle[%s] CADirURI is missing", amxd_object_get_name(object, AMXD_OBJECT_NAMED));
    value = GET_CHAR(uri, NULL);
    amxc_var_add_key(cstring_t, args, "CADir", value);

    ret_status = amxd_status_ok;

exit:
    return ret_status;
}

/**
 * @brief Retrieves the CAFile URI from an object representing
 * a row in the Security.CABundle table.
 *
 * @param[in]  object Pointer to the AMXD object for which the command is called.
 *
 * @param[in]  func   Unused
 *
 * @param[in,out] args Input arguments: N.A. Output arguments: "CAFile" with the CAFile URI as string value.
 *
 * @param[out] ret   Unused
 *
 * @return `amxd_status_ok` if CAFile URI was successfully retrieved and added
 *         to the output; otherwise, `amxd_status_parameter_not_found`.
 *
 */
amxd_status_t _CAFile(amxd_object_t* object, UNUSED amxd_function_t* func, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    amxd_status_t ret_status = amxd_status_parameter_not_found;
    const amxc_var_t* uri = NULL;
    const char* value = NULL;

    uri = amxd_object_get_param_value(object, "CAFileURI");
    when_null_trace(uri, exit, ERROR, "CABundle[%s] CAFileURI is missing", amxd_object_get_name(object, AMXD_OBJECT_NAMED));
    value = GET_CHAR(uri, NULL);
    amxc_var_add_key(cstring_t, args, "CAFile", value);

    ret_status = amxd_status_ok;

exit:
    return ret_status;
}