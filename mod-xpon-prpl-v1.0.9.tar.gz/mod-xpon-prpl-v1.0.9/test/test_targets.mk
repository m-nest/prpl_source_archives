run: $(RUN_TEST) $(MODULE)
	set -o pipefail; valgrind --leak-check=full --keep-debuginfo=yes --exit-on-first-error=yes --error-exitcode=1 ./$< 2>&1 | tee -a $(OBJDIR)/unit_test_results.txt;

$(RUN_TEST): $(OBJECTS_RUN_TEST)
	$(CC) -o $@ $(OBJECTS_RUN_TEST) $(LDFLAGS) -fprofile-arcs -ftest-coverage

$(MODULE): $(OBJECTS_MODULE)
	$(CC) -shared $(OBJECTS_MODULE) -fprofile-arcs -ftest-coverage -Wl,-soname,$(@) -o $@ $(LDFLAGS)

-include $(OBJECTS:.o=.d)

$(OBJDIR)/%.o: $(SRCDIR)/%.c | $(OBJDIR)/
	$(CC) $(CFLAGS) -DUNIT_TEST -fprofile-arcs -ftest-coverage -c -o $@ $<
	@$(CC) $(CFLAGS) -DUNIT_TEST -MM -MP -MT '$(@) $(@:.o=.d)' -MF $(@:.o=.d) $(<)

$(UNIT_TEST_DIR)/%.o: ./%.c | $(UNIT_TEST_DIR)/
	$(CC) $(CFLAGS) -fprofile-arcs -ftest-coverage -c -o $@ $<
	@$(CC) $(CFLAGS) -MM -MP -MT '$(@) $(@:.o=.d)' -MF $(@:.o=.d) $(<)

$(OBJDIR)/:
	mkdir -p $@

$(UNIT_TEST_DIR)/:
	mkdir -p $@

clean:
	rm -f $(RUN_TEST) $(MODULE) $(OBJDIR)

.PHONY: clean $(OBJDIR)/ $(UNIT_TEST_DIR)/
