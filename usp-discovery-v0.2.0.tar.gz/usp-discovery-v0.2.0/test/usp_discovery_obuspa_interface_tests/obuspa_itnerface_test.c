/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_verify.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <limits.h>

#include "usp_discovery.h"
#include "event_handler.h"
#include "obuspa_interface.h"

#include "obuspa_interface_test.h"

#define USP_DISCOVERY_ODL "usp_discovery.odl"
#define OBUSPA_DM_DEF_ODL "../common/obuspa_definition.odl"

#define ME "usp_discovery"

int test_setup(UNUSED void** state) {
    amxut_bus_setup(state);

    // amxut_dm_load_odl(USP_DISCOVERY_ODL);
    amxut_dm_load_odl(OBUSPA_DM_DEF_ODL);
    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_usp_discovery_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

#if 0

static void start_usp_discovery(void) {
    assert_int_equal(_usp_discovery_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    assert_int_equal(_usp_discovery_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);

    assert_non_null(app.option_17_subscription);
    assert_non_null(app.option_125_subscription);

    amxut_bus_handle_events();
}
static void _assert_dm_string_equal(const char* obj_path, const char* param_name, const char* expected_value) {
    amxb_bus_ctx_t* ctx = amxb_be_who_has(obj_path);
    assert_non_null(ctx);

    char param_path[PATH_BUFFER_SIZE];
    snprintf(param_path, sizeof(param_path), "%s%s", obj_path, param_name);

    amxc_var_t result;
    amxc_var_init(&result);
    assert_int_equal(amxb_get(ctx, param_path, 0, &result, 1), 0);

    amxc_var_t* params = amxc_var_get_first(amxc_var_get_first(&result));
    char* actual_value = amxc_var_dyncast(cstring_t, GET_ARG(params, param_name));
    bool is_equal = !strcmp(actual_value, expected_value);
    amxc_var_clean(&result);
    free(actual_value);

    assert_true(is_equal);
}
#endif
static int add_object_with_name(const char* table_path, const char* alias, const amxc_var_t* parameters) {
    int rc = -1;

    amxc_var_t actual_parameters;
    amxc_var_init(&actual_parameters);

    if(parameters) {
        amxc_var_copy(&actual_parameters, parameters);
    } else {
        amxc_var_set_type(&actual_parameters, AMXC_VAR_ID_HTABLE);
    }

    amxc_var_add_key(cstring_t, &actual_parameters, "Alias", alias);

    amxb_bus_ctx_t* ctx = amxb_be_who_has(table_path);
    when_null_trace(ctx, exit, ERROR, "Cannot to find context for \"%s\"", table_path);

    rc = amxb_add(ctx, table_path, 0, alias, &actual_parameters, NULL, BUS_OPERATION_TIMEOUT);
    when_failed_trace(rc, exit, ERROR, "Failed to add '%s.%s.' object instance, got %d", table_path, alias, rc);

exit:
    amxc_var_clean(&actual_parameters);
    return rc;
}

static bool instance_exists(const char* table_path, const char* alias) {
    bool ret_is_empty = false;
    amxb_bus_ctx_t* ctx = amxb_be_who_has(table_path);
    when_null_trace(ctx, exit, ERROR, "Cannot to find context for \"%s\"", table_path);

    amxc_string_t search_path;
    amxc_string_init(&search_path, PATH_BUFFER_SIZE);
    amxc_string_setf(&search_path, "%s[Alias=='%s'].", table_path, alias);

    amxc_var_t ret;
    amxc_var_init(&ret);
    int rc = amxb_get(ctx, amxc_string_get(&search_path, 0), 1, &ret, BUS_OPERATION_TIMEOUT);
    amxc_string_clean(&search_path);
    when_failed_trace(rc, exit, ERROR, "Cannot resquest bus path '%s[Alias==%s].'", table_path, alias);

    ret_is_empty = amxc_var_get_first(amxc_var_get_first(&ret)) == NULL;
exit:
    amxc_var_clean(&ret);
    return !ret_is_empty;

}

static int bus_get_json_equals(const char* table_path, const char* alias, const char* reference_file, bool update) {
    int rc = -1;
    amxb_bus_ctx_t* ctx = amxb_be_who_has(table_path);
    when_null_trace(ctx, exit, ERROR, "Cannot to find context for \"%s\"", table_path);

    amxc_string_t search_path;
    amxc_string_init(&search_path, PATH_BUFFER_SIZE);
    if(alias) {
        amxc_string_setf(&search_path, "%s[Alias=='%s'].", table_path, alias);
    } else {
        amxc_string_set(&search_path, table_path);
    }

    amxc_var_t ret;
    amxc_var_init(&ret);
    rc = amxb_get(ctx, amxc_string_get(&search_path, 0), INT_MAX, &ret, BUS_OPERATION_TIMEOUT);
    amxc_string_clean(&search_path);
    when_failed_trace(rc, exit, ERROR, "Cannot resquest bus path");
    if(update && reference_file) {
        amxut_util_write_to_json_file(&ret, reference_file);
    }

    assert_int_equal(amxut_verify_variant_from_json_file(&ret, reference_file), 0);

    amxc_var_clean(&ret);

exit:
    return rc;
}


static void remove_instance(const char* table_path, unsigned index, const char* name) {
    assert_int_equal(amxb_del(amxut_bus_ctx(), table_path, index, name, NULL, BUS_OPERATION_TIMEOUT), 0);
}
void test_adding_controller(UNUSED void** state) {
    struct DHCPControllerInformation controller;
    controller.URL = "ws://controller.cdroutertest.com:8080/ws/agent";
    controller.ProvisioningCode = "abc";
    controller.USPNotifRetryMinimumWaitInterval = 1024;
    controller.USPNotifRetryIntervalMultiplier = 2048;
    controller.EndpointID = "cdrouterTestController";

    assert_int_equal(add_or_replace_controller("usp_discovery_cdrouterTestController", &controller), 0);
    assert_int_equal(bus_get_json_equals("Device.LocalAgent.Controller.", "usp_discovery_cdrouterTestController", "dm_dumps/test_adding_controller.json", false), 0);

    remove_instance("Device.LocalAgent.Controller.", 0, "usp_discovery_cdrouterTestController");
}

void test_adding_updating_controller(UNUSED void** state) {
    struct DHCPControllerInformation controller;
    controller.URL = "ws://controller.cdroutertest.com:8080/ws/agent";
    controller.ProvisioningCode = "abc";
    controller.USPNotifRetryMinimumWaitInterval = 1024;
    controller.USPNotifRetryIntervalMultiplier = 2048;
    controller.EndpointID = "cdrouterTestController";

    assert_int_equal(add_or_replace_controller("usp_discovery_cdrouterTestController", &controller), 0);
    assert_int_equal(bus_get_json_equals("Device.LocalAgent.Controller.", "usp_discovery_cdrouterTestController", "dm_dumps/test_adding_updating_controller1.json", false), 0);

    controller.URL = "ws://NEWcontroller.cdroutertest.com:8080/ws/agent";
    controller.ProvisioningCode = "123";
    controller.USPNotifRetryMinimumWaitInterval = 1111;
    controller.USPNotifRetryIntervalMultiplier = 2222;
    controller.EndpointID = "cdrouterTestController";

    assert_int_equal(add_or_replace_controller("usp_discovery_cdrouterTestController", &controller), 0);
    assert_int_equal(bus_get_json_equals("Device.LocalAgent.Controller.", "usp_discovery_cdrouterTestController", "dm_dumps/test_adding_updating_controller2.json", false), 0);

    remove_instance("Device.LocalAgent.Controller.", 0, "usp_discovery_cdrouterTestController");
}

void test_removing_controller(UNUSED void** state) {
    struct DHCPControllerInformation controller;
    controller.URL = "ws://controller.cdroutertest.com:8080/ws/agent";
    controller.ProvisioningCode = "abc";
    controller.USPNotifRetryMinimumWaitInterval = 1024;
    controller.USPNotifRetryIntervalMultiplier = 2048;
    controller.EndpointID = "cdrouterTestController";

    assert_int_equal(add_or_replace_controller("usp_discovery_cdrouterTestController", &controller), 0);

    assert_int_equal(remove_controller("usp_discovery_cdrouterTestController"), 0);
    assert_int_equal(bus_get_json_equals("Device.LocalAgent.Controller.", "usp_discovery_cdrouterTestController", "dm_dumps/test_removing_controller.json", false), 0);
}

void test_remove_all_controllers(UNUSED void** state) {
    const char* table_paths[] = {"Device.LocalAgent.Controller.", "Device.LocalAgent.MTP.", "Device.MQTT.Client.", "Device.STOMP.Connection."};
    const char* aliases_to_remove[] = {"usp_discovery", "usp_discovery_abc"};
    const char* aliases_not_to_remove[] = {"cdrouter", "test", "abc"};
    for(size_t i = 0; i != sizeof(table_paths) / sizeof(table_paths[0]); ++i) {
        for(size_t j = 0; j != sizeof(aliases_to_remove) / sizeof(aliases_to_remove[0]); ++j) {
            assert_int_equal(add_object_with_name(table_paths[i], aliases_to_remove[j], NULL), 0);
        }
        for(size_t j = 0; j != sizeof(aliases_not_to_remove) / sizeof(aliases_not_to_remove[0]); ++j) {
            assert_int_equal(add_object_with_name(table_paths[i], aliases_not_to_remove[j], NULL), 0);
        }
    }
    remove_all_controllers();
    for(size_t i = 0; i != sizeof(table_paths) / sizeof(table_paths[0]); ++i) {
        for(size_t j = 0; j != sizeof(aliases_to_remove) / sizeof(aliases_to_remove[0]); ++j) {
            assert_false(instance_exists(table_paths[i], aliases_to_remove[j]));
        }
        for(size_t j = 0; j != sizeof(aliases_not_to_remove) / sizeof(aliases_not_to_remove[0]); ++j) {
            assert_true(instance_exists(table_paths[i], aliases_not_to_remove[j]));
        }
    }
}
