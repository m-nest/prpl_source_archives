/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _RLYEH_SIGNALS_H_
#define _RLYEH_SIGNALS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#define EVENT_TIMINGILA_LATE_INIT_START "tmg:lateinit:start"
#define EVENT_TIMINGILA_LATE_INIT_HANDOVER "tmg:lateinit:hover"
#define EVENT_TIMINGILA_LATE_INIT_DONE "tmg:lateinit:done"
#define EVENT_PACKAGER_INSTALL_DU_DONE "pkg:installdu:done"
#define EVENT_PACKAGER_INSTALL_DU_FAILED "pkg:installdu:failed"
#define EVENT_PACKAGER_UNINSTALL_DU_DONE "pkg:uninstalldu:done"
#define EVENT_PACKAGER_UNINSTALL_DU_FAILED "pkg:uninstalldu:failed"
#define EVENT_PACKAGER_UPDATE_DU_DONE "pkg:updatedu:done"
#define EVENT_PACKAGER_UPDATE_DU_FAILED "pkg:updatedu:failed"

#define EVENT_PACKAGER_REMOVED_UNUSED_DONE "pkg:removeunused:done"
#define EVENT_PACKAGER_REMOVED_UNUSED_FAILED "pkg:removeunused:failed"

#define EVENT_CONTAINER_INSTALL_DU_DONE "ctr:installdu:done"
#define EVENT_CONTAINER_INSTALL_DU_FAILED "ctr:installdu:failed"
#define EVENT_CONTAINER_UNINSTALL_DU_DONE "ctr:uninstalldu:done"
#define EVENT_CONTAINER_UNINSTALL_DU_FAILED "ctr:uninstalldu:failed"
#define EVENT_CONTAINER_UPDATE_DU_DONE "ctr:updatedu:done"
#define EVENT_CONTAINER_UPDATE_DU_FAILED "ctr:updatedu:failed"
#define EVENT_CONTAINER_ADD_EE_DONE "ctr:addexecenv:done"
#define EVENT_CONTAINER_ADD_EE_FAILED "ctr:addexecenv:failed"
#define EVENT_CONTAINER_DELETE_EE_DONE "ctr:deleteexecenv:done"
#define EVENT_CONTAINER_DELETE_EE_FAILED "ctr:deleteexecenv:failed"
#define EVENT_CONTAINER_VALIDATE_INSTALL_DU_DONE "ctr:validateinstalldu:done"
#define EVENT_CONTAINER_VALIDATE_UPDATE_DU_DONE "ctr:validateupdatedu:done"

#define EVENT_EXEC_PACKAGER_UNINSTALL_DU "exec:pkg:uninstalldu"
#define EVENT_EXEC_PACKAGER_REMOVE_UNUSED "exec:pkg:removeunused"


#ifdef __cplusplus
}
#endif

#endif // _RLYEH_SIGNALS_H_
