{%
import * as fs from 'fs';

let leds_sysfs_path = "/sys/class/leds";

function file_read(path) {
        let data = fs.readfile(path);
        if (data == null)
                return null;

        return trim(data);
}

function max_brightness(led) {
        let max_brightness = file_read(sprintf("%s/%s/max_brightness", leds_sysfs_path, led));
        return int(max_brightness) || 100;
}

function enable(led) {
        let brightness = int(file_read(sprintf("%s/%s/brightness", leds_sysfs_path, led)));

        if (brightness === NaN || brightness == 0)
                return 0;

        return 1;
}

%}
%populate {
    object LEDs.LED {
{% for (let tz in fs.lsdir(leds_sysfs_path)) : -%}
        instance add(0,"cpe-{{ tz }}") {
            parameter Enable = {{ enable(tz) }};
            parameter Name = "{{ tz }}";
            parameter CyclePeriodRepetitions = -1;
            parameter MaxBrightness = {{ max_brightness(tz) }};
            parameter Status = "InUse";
            object CycleElement {
                instance add(0,"TurnOn") {
                    parameter Color = "000000";
                    parameter Duration = 1000;
                    parameter Enable = 1;
                    parameter FadeInterval = 0;
                    parameter Order = 1;
                    parameter Brightness=100;

                }
            }
            object ULED {
                instance add() {
                    parameter LEDReference="LEDs.LED.cpe-{{ tz }}";
                    parameter SupportedColor = "FFFFFF";
                }
            }
        }
{% endfor -%}
    }
}