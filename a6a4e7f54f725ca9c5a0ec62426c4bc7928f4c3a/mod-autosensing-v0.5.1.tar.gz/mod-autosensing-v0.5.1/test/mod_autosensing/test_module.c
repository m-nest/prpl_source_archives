/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#if defined(SAHTRACES_ENABLED)
#include <debug/sahtrace.h>
#endif

#include "../common/common_functions.h"

#include "test_module.h"
#include "mod_autosensing.h"

#define MOD_NAME "target_module"
#define MOD_PATH "../modules_under_test/" MOD_NAME ".so"

static amxc_var_t stop_data;

// Helper function to check if an amxc_var_t variable is set correctly.
// Returns 1 on success, -1 otherwise.
static int var_equal_check(const LargestIntegralType value, const LargestIntegralType check_value_data) {
    amxc_var_t* a = (amxc_var_t*) value;
    amxc_var_t* b = (amxc_var_t*) check_value_data;
    int result = -1;
    int rv = 0;

    if(amxc_var_is_null(a) && amxc_var_is_null(b)) {
        rv = 1;
        goto exit;
    }

    if((amxc_var_compare(a, b, &result) != 0) || (result != 0)) {
        print_message("Found unexpected value:\n");
        print_message("<from plugin>\n");
        amxc_var_dump(a, 1);
        print_message("<from unit test>\n");
        amxc_var_dump(b, 1);
        goto exit;
    }

    rv = 1;

exit:
    return rv;
}

static int autosensing_set_wan_mode(UNUSED const char* function_name,
                                    amxc_var_t* args,
                                    UNUSED amxc_var_t* ret) {
    print_message("Checking set_wan_mode data...\n");
    check_expected(args);
    return 0;
}

static int autosensing_is_up_query_start(UNUSED const char* function_name,
                                         amxc_var_t* args,
                                         UNUSED amxc_var_t* ret) {
    print_message("Checking start data...\n");
    check_expected(args);
    return 0;
}

static int autosensing_is_up_query_stop(UNUSED const char* function_name,
                                        amxc_var_t* args,
                                        UNUSED amxc_var_t* ret) {
    print_message("Checking stop data...\n");
    check_expected(args);
    return 0;
}

static int register_dummy_core_functions(void) {
    amxm_shared_object_t* so = amxm_get_so("self");
    amxm_module_t* mod = NULL;
    assert_non_null(so);
    assert_int_equal(amxm_module_register(&mod, so, MOD_DM_MNGR), 0);
    assert_int_equal(amxm_module_add_function(mod, "set-mode", autosensing_set_wan_mode), 0);
    assert_int_equal(amxm_module_add_function(mod, "isup-sensing-start", autosensing_is_up_query_start), 0);
    assert_int_equal(amxm_module_add_function(mod, "isup-sensing-stop", autosensing_is_up_query_stop), 0);

    return 0;
}

int test_setup(void** state) {
    amxut_bus_setup(state);
    register_dummy_core_functions();

    amxc_var_init(&stop_data);
#if defined(SAHTRACES_ENABLED)
    sahTraceOpen("unittest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "mod-autosensing");
#endif
    return 0;
}

int test_teardown(void** state) {
    amxut_bus_teardown(state);
    return 0;
}

void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

void test_has_functions(UNUSED void** state) {
    assert_true(amxm_has_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start"));
    assert_true(amxm_has_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop"));
}

/*
 * This tests simulates atboot autosensing of three modes
 * Expectations:
 *      * Sensing is configured for at boot so every mode should only be sensed once
 *      * There are three modes that should be sensed
 */
void test_sensing_atboot(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;
    int i = 0;
    int priority_order[4] = {3, 2, 0, 1000};

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_atboot.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    for(i = 1; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 1; i++) {
        expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
        expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
        amxut_timer_go_to_future_ms(3001);
    }

    // Not continuous so we expect the module to stop the querying
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    amxut_timer_go_to_future_ms(3001);

    // Nothing happens after that
    amxut_timer_go_to_future_ms(90001);

    // So we stop the autosensing
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This tests simulates continuous autosensing of three modes, starting with the current
 * Expectations:
 *      * Sensing is configured for continuous so after the last mode, the first mode should be selected again
 *      * There are three modes that should be continuously sensed
 */
void test_sensing_continuous(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;
    int i = 0;
    int j = 0;
    int priority_order[5] = {4, 2, 3, 1, 1000};

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_continuous.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    // Should cycle continuous between all valid wan modes (so demo_invalid should never become active)
    for(i = 0; i < 50; i++) {
        for(j = 0; j < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 1; j++) {
            if((i == 0) && (j == 0)) {
                j++;
            }
            expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
            expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[j]));
            amxut_timer_go_to_future_ms(3001);
        }
    }

    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[0]));
    amxut_timer_go_to_future_ms(3001);    // will try to set the first mode again

    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[1]));
    amxut_timer_go_to_future_ms(3001);    // will try to set the second mode again

    // Sensing will go on until active mode is found and the stop is called
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);

    // After stopping the sensing, no timer should run out
    amxut_timer_go_to_future_ms(3001);

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This tests simulates atboot autosensing of three modes
 * Expectations:
 *      * Sensing is configured for at boot but we simulate finding a mode
 *      * There are three modes that can be sensed but we stop after setting the second mode, simulating a mode being found
 */
void test_sensing_atboot_no_current(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_atboot_no_current.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    // We expect the a new mode will be set directly after calling the start
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, 2));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, 1));
    amxut_timer_go_to_future_ms(3001);

    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This tests simulates continuous autosensing of three modes
 * Expectations:
 *      * Sensing is configured for continuous but we simulate finding a mode
 *      * There are three modes that can be sensed but we stop after setting the second mode, simulating a mode being found
 */
void test_sensing_continuous_no_current(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_continuous_no_current.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    // We expect the a new mode will be set directly after calling the start
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, 0));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, 2));
    amxut_timer_go_to_future_ms(3001);

    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

void test_sensing_interface_comes_up(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t intf_data;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;
    int i = 0;
    int priority_order[3] = {2, 0, 1};

    amxc_var_init(&intf_data);
    amxc_var_init(&ret);
    amxc_var_set_type(&intf_data, AMXC_VAR_ID_HTABLE);

    data = read_json_from_file("test_data/test_intf_up.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    for(i = 1; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 1; i++) {
        expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
        expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
        amxut_timer_go_to_future_ms(3001);
    }

    // Simulate found wan mode
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    // Simulate ethernet interface 1 coming up
    amxc_var_add_key(bool, &intf_data, "up", true);
    amxc_var_add_key(bool, &intf_data, "restart", true);
    amxc_var_add_key(cstring_t, &intf_data, "physical_ref", "Device.Ethernet.Interface.1");
    for(i = 0; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)); i++) {
        amxc_var_t* mode = GETI_ARG(modes, i);
        if(strcmp(GET_CHAR(mode, "PhysicalReference"), "Device.Ethernet.Interface.1") == 0) {
            amxc_var_t* temp = GET_ARG(mode, "Availability");
            amxc_var_set(uint32_t, temp, 0);
        }
    }

    // Expect mod-autosensing to react by restarting autosensing
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[0]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-physical-intf-change", &intf_data, &ret);

    // Found wan mode on ethernet interface
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[1]));
    amxut_timer_go_to_future_ms(3001);

    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    amxc_var_clean(&intf_data);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

void test_sensing_interface_goes_down_no_restart(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t intf_data;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;
    int i = 0;
    int priority_order[3] = {2, 0, 1};

    amxc_var_init(&intf_data);
    amxc_var_init(&ret);
    amxc_var_set_type(&intf_data, AMXC_VAR_ID_HTABLE);

    data = read_json_from_file("test_data/test_intf_down.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[0]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    for(i = 1; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 2; i++) {
        expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
        expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
        amxut_timer_go_to_future_ms(3001);
    }

    // Simulate found wan mode
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    // Simulate cellular interface 1 going down
    amxc_var_add_key(bool, &intf_data, "up", false);
    amxc_var_add_key(cstring_t, &intf_data, "physical_ref", "Device.Cellular.Interface.1");
    for(i = 0; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)); i++) {
        amxc_var_t* mode = GETI_ARG(modes, i);
        if(strcmp(GET_CHAR(mode, "PhysicalReference"), "Device.Cellular.Interface.1") == 0) {
            amxc_var_t* temp = GET_ARG(mode, "Availability");
            amxc_var_set(uint32_t, temp, 0);
        }
    }

    // Nothing happens since demo_cellular has a lower priority than the detected wanmode (demo_wanmode)
    amxut_timer_go_to_future_ms(100001);

    // Simulate cellular interface 1 coming up again
    amxc_var_add_key(bool, &intf_data, "up", true);
    amxc_var_add_key(bool, &intf_data, "restart", true);
    amxc_var_add_key(cstring_t, &intf_data, "physical_ref", "Device.Cellular.Interface.1");
    for(i = 0; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)); i++) {
        amxc_var_t* mode = GETI_ARG(modes, i);
        if(strcmp(GET_CHAR(mode, "PhysicalReference"), "Device.Cellular.Interface.1") == 0) {
            amxc_var_t* temp = GET_ARG(mode, "Availability");
            amxc_var_set(uint32_t, temp, 0);
        }
    }

    amxc_var_clean(&intf_data);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

void test_sensing_interface_goes_down_restart(UNUSED void** state) {
    amxc_var_t* data = NULL;
    amxc_var_t intf_data;
    amxc_var_t ret;
    amxc_var_t* modes = NULL;
    int i = 0;
    int j = 0;
    int priority_order[3] = {2, 0, 1};
    int priority_order_without_cellular[2] = {2, 0};

    amxc_var_init(&intf_data);
    amxc_var_init(&ret);
    amxc_var_set_type(&intf_data, AMXC_VAR_ID_HTABLE);

    data = read_json_from_file("test_data/test_intf_down.json");
    modes = GET_ARG(data, "modes");
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    for(i = 1; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 1; i++) {
        expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
        expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[i]));
        amxut_timer_go_to_future_ms(3001);
    }

    // Simulate found wan mode (demo_cellular)
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(3001);

    // Simulate cellular interface 1 going down
    expect_check(autosensing_is_up_query_stop, args, var_equal_check, data);
    expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order[0]));
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-start", data, &ret);

    amxc_var_add_key(bool, &intf_data, "up", false);
    amxc_var_add_key(bool, &intf_data, "restart", true);
    amxc_var_add_key(cstring_t, &intf_data, "physical_ref", "Device.Cellular.Interface.1");
    for(i = 0; i < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)); i++) {
        amxc_var_t* mode = GETI_ARG(modes, i);
        if(strcmp(GET_CHAR(mode, "PhysicalReference"), "Device.Cellular.Interface.1") == 0) {
            amxc_var_t* temp = GET_ARG(mode, "Availability");
            amxc_var_set(uint32_t, temp, 0);
        }
    }

    // Expect mod-autosensing to react by restarting autosensing
    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-physical-intf-change", &intf_data, &ret);

    // demo_cellular was found to be inactive so it should not be set anymore.
    // autosensing_set_wan_mode should cycle between demo_wanmode and demo_pppmode
    for(i = 0; i < 50; i++) {
        for(j = 1; j < (int) amxc_llist_size(amxc_var_constcast(amxc_llist_t, modes)) - 2; j++) {
            expect_check(autosensing_is_up_query_stop, args, var_equal_check, &stop_data);
            expect_check(autosensing_set_wan_mode, args, var_equal_check, GETI_ARG(modes, priority_order_without_cellular[j]));
            amxut_timer_go_to_future_ms(3001);
        }
    }

    amxm_execute_function(MOD_NAME, MOD_AUTOSENSING_CTRL, "autosensing-stop", data, &ret);
    amxut_timer_go_to_future_ms(10001);

    amxc_var_clean(&intf_data);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

void test_can_close_module(UNUSED void** state) {
    assert_int_equal(amxm_close_all(), 0);
}
