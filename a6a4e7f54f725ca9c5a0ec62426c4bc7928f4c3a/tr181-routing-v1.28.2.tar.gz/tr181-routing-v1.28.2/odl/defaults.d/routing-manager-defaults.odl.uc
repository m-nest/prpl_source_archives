{% let has_upstream = (BDfn.getUpstreamInterfaceIndex() != "-1") %}
{% let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1") %}
{% let has_cellular_wan = (BDfn.getInterfaceIndex("wan", "cellular") != "-1"); %}
include "global_ip_interfaces.odl";

%populate {
    object 'Routing.Router' {
        instance add ("main"){
            parameter Alias = "main";
            parameter Enable = true;
            parameter Name = "main";
            parameter ID = "254";
        }
    }
    object 'Routing.RouteInformation' {
        parameter Enable = true;
    }
    object 'Routing.RouteInformation.InterfaceSetting' {
        instance add ("main"){
            {% if (has_upstream): %}
            parameter Interface = "${ip_intf_wan}";
            {% else %}
            parameter Interface = "${ip_intf_lan}";
            {% endif %}
        }
{% if (has_failover): %}
        instance add ("failover"){
            parameter Interface = "${ip_intf_failover}";
        }
{% endif; %}
    }
    object 'Routing.Router.main.IPv4Forwarding' {
        instance add ("cpe-default") {
            parameter Alias = "cpe-default";
            parameter DestIPAddress = "0.0.0.0";
            parameter DestSubnetMask = "0.0.0.0";
            parameter Enable = true;
            {% if (has_upstream): %}
            parameter Interface = "${ip_intf_wan}";
            {% else %}
            parameter Interface = "${ip_intf_lan}";
            {% endif %}
            {% if (has_upstream && has_cellular_wan): %}
            parameter Origin = "3GPP-NAS";
            {% else %}
            parameter Origin = "DHCPv4";
            {% endif %}
        }

{% if (has_failover): %}
        instance add ("failover-default") {
            parameter Alias = "failover-default";
            parameter DestIPAddress = "0.0.0.0";
            parameter DestSubnetMask = "0.0.0.0";
            parameter ForwardingMetric = "100";
            parameter Enable = false;
            parameter Interface = "${ip_intf_failover}";
            parameter Origin = "3GPP-NAS";
        }
{% endif; %}
    }
    object 'Routing.Router.main.IPv6Forwarding' {
{% if (has_upstream): %}
{%   if (has_cellular_wan): %}
        instance add ("cpe-default") {
            parameter Alias = "cpe-default";
            parameter DestIPPrefix = "::/0";
            parameter Enable = true;
            parameter Interface = "${ip_intf_wan}";
            parameter Origin = "3GPP-NAS";
        }
{%   endif; %}
        instance add ("prefix_blackhole-default") {
            parameter Alias = "prefix_blackhole-default";
            parameter Type = "Blackhole";
            parameter Enable = false;
            parameter Interface = "${ip_intf_lo}";
            parameter DestIPPrefix = "";
            parameter Origin = "Static";
        }
{% endif %}

{% if (has_failover): %}
        instance add ("failover-default") {
            parameter Alias = "failover-default";
            parameter DestIPPrefix = "::/0";
            parameter Enable = true;
            parameter Interface = "${ip_intf_failover}";
            parameter Origin = "3GPP-NAS";
        }
{% endif; %}
    }
}
