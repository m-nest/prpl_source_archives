/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef TR069_DISCOVERY_H
#define TR069_DISCOVERY_H

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_variant.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_path.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_parameter.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <amxrt/amxrt.h>
#include <amxb/amxb.h>
#include <netmodel/common_api.h>

#define CONFIG_NAME_PARAM "name"
#define CONFIG_NETMODEL_INTF_ALIAS "NetModelIntfAlias"
#define CONFIG_DHCP4_CLIENT_REF "DHCPv4ClientReference"
#define CONFIG_DHCP6_CLIENT_REF "DHCPv6ClientReference"
#define CONFIG_DHCP6_WAIT_TIME "DHCPv6WaitTime"
#define MANAGEMENT_SERVER "ManagementServer."
#define MANAGEMENT_SERVER_INTERNAL_SETTINGS "ManagementServer.InternalSettings."
#define MANAGEMENT_SERVER_STATE "ManagementServer.State."
#define MANAGEMENT_SERVER_URL "ManagementServer.URL"
#define DEVICE_INFO "DeviceInfo."
#define DEVICE_INFO_PROVISIONING_CODE "DeviceInfo.ProvisioningCode"
#define ACS_URL_MAX_LEN 256
#define PROVISIONING_CODE_MAX_LEN 255
#define PATH_BUFFER_SIZE 256
#define ACS_DISCOVERY_STATE "X_PRPLWARE-COM_TR069Discovery.State."
#define FIRST_SUCCESSFUL_PROVISION "FirstSuccessfulProvision"
#define DHCP_PROVISION_IN_USE "DHCPProvisionInUse"
#define DHCP_REDISCOVERY_INTERVAL "DHCPReDiscoveryInterval"

/**
 * @file tr069_discovery.h
 * @brief TR-069 (ACS) discovery using DHCP options.
 */

typedef enum _provision_type {
    PROVISION_NONE,
    PROVISION_DHCP,
    PROVISION_MANUAL
} provision_type_t;

typedef enum {
    DHCPv4 = 4,
    DHCPv6 = 6
} dhcp_version_t;

/**
 * Encapsulated vendor specific suboptions from options 17 and 125.
 * See TR-069 Section 3.1: https://www.broadband-forum.org/pdfs/tr-069-1-6-1.pdf
 */
typedef struct {
    /**
     * URL of the ACS
     */
    char url_of_acs[ACS_URL_MAX_LEN];

    /**
     * Provisioning code, obtained from the DHCP
     */
    char provisioning_code[PROVISIONING_CODE_MAX_LEN];

    /**
     * CWMPRetryMinimumWaitInterval (not implemented)
     */
    uint16_t cwmp_retry_minimum_wait_interval;  // not implemented

    /**
     * CWMPRetryIntervalMultiplier (not implemented)
     */
    uint16_t cwmp_retry_interval_multiplier;    // not implemented

    /**
     * DHCP version, used to obtained information about the ACS
     */
    dhcp_version_t dhcp_version;
} dhcp_option_t;

/**
 * Check whether two DHCP options are the same
 *
 * @param[in] first first DHCP controller options
 * @param[in] second second DHCP controller options
 */
bool dhcp_option_equals(dhcp_option_t* first, dhcp_option_t* second);

/**
 * State of the TR-069 discovery component
 */
typedef struct _tr069_discovery_app {
    /**
     * Datamodel of the tr069-discovery
     */
    amxd_dm_t* dm;

    /**
     * Application name (tr069-discovery)
     */
    char* name;

    /**
     * DHCP client reference
     */
    char dhcpv4_client_ref[PATH_BUFFER_SIZE];

    /**
     * DHCPv client reference
     */
    char dhcpv6_client_ref[PATH_BUFFER_SIZE];

    /**
     * Name of the NetModel interface
     */
    char netmodel_intf_alias[PATH_BUFFER_SIZE];

    /**
     * DHCP re-discovery interval
     */
    uint32_t dhcp_rediscovery_interval_s;

    /**
     * Time to wait for DHCPv6 to resolve address
     */
    uint32_t dhcpv6_wait_time_ms;

    /**
     * Method, which cwmpd was configured when it connected to the ACS
     * successfully first time after the factory reset.
     */
    provision_type_t first_successful_provision;

    /**
     * Whether DHCP provisioning is in use at the current time
     */
    bool dhcp_provision_in_use;

    /**
     * DHCPv4 configured ACS information
     */
    dhcp_option_t dhcpv4;

    /**
     * DHCPv6 configured ACS information
     */
    dhcp_option_t dhcpv6;

    /**
     * Currently used DHCP option to configure ACS
     */
    dhcp_option_t* option_to_use;

    /**
     * URL of the ACS
     */
    char management_server_url[ACS_URL_MAX_LEN];

    /**
     * Timer to wait for the DHCPv6 to configure IPv6 address
     */
    amxp_timer_t* dhcpv6_wait_timer;

    /**
     * Timer to wait for the CWMP session to be established
     */
    amxp_timer_t* session_timer;

    /**
     * Subscription to changes in the DHCPv4 option-125
     */
    netmodel_query_t* option_125_subscription;

    /**
     * Subscription to changes in the DHCPv6 option-17
     */
    netmodel_query_t* option_17_subscription;

    /**
     * Subscription to changed in ManagementServer.URL
     */
    amxb_subscription_t* management_server_subscription;
} tr069_discovery_app_t;

extern tr069_discovery_app_t app;


/**
 * Start of stop the ACS discovery using DHCP options
 *
 * @param reason reason for call, 0 is start and 1 is stop
 * @param[in] dm datamodel of the tr069-discovery
 * @param parser (unusted) parser used for parsing ODL files
 */
int _tr069_discovery_main(int reason,
                          amxd_dm_t* dm,
                          UNUSED amxo_parser_t* parser);

/**
 * Start the DHCP discovery of the ACS address
 */
int _tr069_discovery_start(UNUSED int reason,
                           UNUSED amxd_dm_t* dm,
                           UNUSED amxo_parser_t* parser);

/**
 * Stop the DHCP discovery of the ACS address
 */
int _tr069_discovery_stop(UNUSED int reason,
                          UNUSED amxd_dm_t* dm,
                          UNUSED amxo_parser_t* parser);

/**
 * Start DHCP provisioning of the ACS
 */
int dhcp_provisioning_start(void);

/**
 * Stop DHCP provisioning of the ACS
 */
int dhcp_provisioning_stop(void);

/**
 * Get provisioning type from the string (saved in the ODL save):
 * None -> PROVISION_NONE
 * DHCP -> PROVISION_DHCP
 * Manual -> PROVISION_MANUAL
 * (other) -> -1
 *
 * @param[in] value value of the DHCP provisioning, casted to string
 *
 * @return DHCP provisioning type, -1 if provisioning method is unknown
 */
provision_type_t provision_type_from_string(const char* value);

/**
 * Cast DHCP provisioning type to string
 * PROVISION_NONE -> None
 * PROVISION_DHCP -> DHCP
 * PROVISION_MANUAL -> Manual
 * (other) -> NULL
 *
 * @param value DHCP provisioning type
 *
 * @return string representation of  the provisioning type, or NULL if the type is unknown
 */
const char* provision_type_to_string(provision_type_t value);

/**
 * React to changes in DHCP options:
 * - if option configures ACS controller, the cwmpd configuration is updated
 * - if option is no longer configures ACS, the ACS address is removed from the cwmpd
 * Note: DHCpv6 have higher priority
 *
 * @param[in] config DHCP-obtained config of the ACS
 */
void handle_dhcp_option_change(dhcp_option_t* config);

/**
 * Callback to execute whenever CWMP session gets established.
 * If it is the first CWMP session after the factory reset, first
 * successful provisioning is updated.
 */
void handle_cwmp_session_establishment(void);

/**
 * React to changes in ManagementServer.URL parameter.
 * If the changes are produced by the component itself, it waits
 * for the CWMP session to be established and optionally makes
 * re-discovery. If the URL is updated by user it may also use re-discovery,
 * if CWMP session is not established and the first successful provisioning method
 * is DHCP.
 *
 * @param[in] url new URL of ACS
 */
void handle_management_server_url_change(const char* url);

/**
 * Utility function to get value of the string parameter
 *
 * @param[in] obj_path path to object in which to get parameter value from
 * @param[in] param_name name of the parameter to get
 * @param[out] dst destination buffer
 * @param dst_len size of the destination buffer
 *
 * @return 0 if no error happened
 */
int get_string_parameter_value(const char* obj_path, const char* param_name, char* dst, size_t dst_len);

/**
 * Utility function to set value of the string parameter
 *
 * @param[in] obj_path path to object in which to get parameter value from
 * @param[in] param_name name of the parameter to get
 * @param[in] value value of the parameter
 *
 * @return 0 if no error happened
 */
int set_string_parameter_value(const char* obj_path, const char* param_name, const char* value);

/**
 * Register CWMP datamodel. ProxyManager is used
 * to regsiter datamodel under Device.
 *
 * @return 0 if no error happened
 */
int register_cwmp_dm(void);

/**
 * Deregister CWMP datamodel.
 *
 * @return 0 if no error happened
 */
int deregister_cwmp_dm(void);

#endif
