/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>

#include "test_device.h"
#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

static const char* odl_defs = "../../odl/tr181-temperature_definition.odl";
static const char* odl_config = "../common/mock.odl";
static const char* odl_mock = "../common/mock_defaults.odl";

static amxd_dm_t dm;
static amxo_parser_t parser;

static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void handle_alarm(int sig) {
    printf("sig %d\n", sig);
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "tempsensor_update", AMXO_FUNC(_tempsensor_update));
    amxo_resolver_ftab_add(&parser, "Reset", AMXO_FUNC(_Reset));
    amxo_resolver_ftab_add(&parser, "tempsensor_toggled", AMXO_FUNC(_tempsensor_toggled));
    amxo_resolver_ftab_add(&parser, "tempsensor_app_start", AMXO_FUNC(_tempsensor_app_start));
    amxo_resolver_ftab_add(&parser, "tempsensor_destroy", AMXO_FUNC(_tempsensor_destroy));

    assert_int_equal(amxo_parser_parse_file(&parser, odl_config, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_mock, root_obj), 0);
    assert_int_equal(_tempsensor_main(0, &dm, &parser), 0);

    signal(SIGALRM, handle_alarm);
    _tempsensor_app_start(NULL, NULL, NULL);

    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_tempsensor_main(1, &dm, &parser), 0);
    assert_null(get_dm());
    assert_null(get_parser());
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_tempsensor_exists(UNUSED void** state) {
    amxd_object_t* tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.1.");
    assert_non_null(tempsensor_obj);
    tempsensor_info_t* tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    tempsensor_info_t* tempsensor_info_wrong = calloc(1, sizeof(tempsensor_info_t));
    assert_non_null(tempsensor_info);

    free(tempsensor_info_wrong->name);
    tempsensor_info_wrong->name = strdup("thermal_zone1");

    //Should exist
    assert_true(tempsensor_device_exists(tempsensor_info));
    //Should not exist
    assert_false(tempsensor_device_exists(tempsensor_info_wrong));

    tempsensor_info_clean(&tempsensor_info_wrong);
}

void test_probe_tempsensor(UNUSED void** state) {
    amxd_object_t* tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.1.");
    assert_non_null(tempsensor_obj);
    tempsensor_info_t* tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    tempsensor_info_t* tempsensor_info_wrong = calloc(1, sizeof(tempsensor_info_t));
    assert_non_null(tempsensor_info);

    free(tempsensor_info_wrong->name);
    tempsensor_info_wrong->name = strdup("thermal_zone1");
    tempsensor_info_wrong->scaling_parameter = tempsensor_info->scaling_parameter;

    //should return a value
    assert_int_equal(probe_tempsensor(tempsensor_info), 50);
    //Should return -274
    assert_int_equal(probe_tempsensor(tempsensor_info_wrong), -274);

    tempsensor_info_clean(&tempsensor_info_wrong);
}

void test_hwmon_path(UNUSED void** state) {
    amxd_object_t* tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.3.");
    assert_non_null(tempsensor_obj);
    tempsensor_info_t* tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    assert_non_null(tempsensor_info);

    //Should exist
    assert_true(tempsensor_device_exists(tempsensor_info));

    tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.4.");
    assert_non_null(tempsensor_obj);
    tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    assert_non_null(tempsensor_info);

    //Should not exist
    assert_false(tempsensor_device_exists(tempsensor_info));
}

void test_hwmon_probe_tempsensor(UNUSED void** state) {
    amxd_object_t* tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.3.");
    assert_non_null(tempsensor_obj);
    tempsensor_info_t* tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    assert_non_null(tempsensor_info);

    //Should give a temp
    assert_int_equal(probe_tempsensor(tempsensor_info), 50);

    tempsensor_obj = amxd_dm_findf(&dm, "TemperatureStatus.TemperatureSensor.4.");
    assert_non_null(tempsensor_obj);
    tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    assert_non_null(tempsensor_info);

    //Should not give a temp
    assert_int_equal(probe_tempsensor(tempsensor_info), -274);
}
