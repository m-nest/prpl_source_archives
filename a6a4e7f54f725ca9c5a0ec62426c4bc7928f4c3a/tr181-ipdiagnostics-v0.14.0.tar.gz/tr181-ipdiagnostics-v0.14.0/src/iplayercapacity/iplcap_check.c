/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ip_diagnostics_priv.h"
#include "ip_diagnostics.h"
#include "iplcap.h"
#include "priv_iplcap.h"
#include "config.h"

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxc/amxc_variant.h>

#define ME "ipd-iplcap-check"

/**
 * @brief Save modal results to the data model.
 *
 * @details Creates instances under ModalResult and writes each entry's
 *          values from the provided variant into the data model.
 *
 * @param[in] values     Variant holding modal results keyed by instance id.
 * @param[in] ipd_iplcap Target object that stores the results.
 *
 * @return 0 on success, -1 on error.
 */
static int ipd_iplcap_save_modal_result(amxc_var_t* values, amxd_object_t* ipd_iplcap) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_status_t ret_status = amxd_status_unknown_error;
    amxd_trans_t* transaction = NULL;
    amxc_string_t aux_string;

    // Add each modal result
    amxc_var_for_each(the_result, values) {
        const char* name = amxc_var_key(the_result);
        // Add a new instance
        transaction = ipd_transaction_create(ipd_iplcap);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_MODAL);

        amxc_string_init(&aux_string, 0);

        amxc_string_setf(&aux_string, "mod_%s", name);

        ret_status = amxd_trans_add_inst(transaction, atoi(name), amxc_string_get(&aux_string, 0));
        when_failed_trace(ret_status, exit, ERROR, "Could not add modal result instance in the transaction");

        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);

        // Save the modal result values
        transaction = ipd_transaction_create(ipd_iplcap);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_MODAL);

        ipd_var_to_dm(transaction, amxc_string_get(&aux_string, 0), the_result, NULL);
        amxc_string_clean(&aux_string);
        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);
    }

    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief Save incremental results to the data model.
 *
 * @details Creates instances under IncrementalResult and writes each entry's
 *          values from the provided variant into the data model.
 *
 * @param[in] values     Variant holding incremental results keyed by instance id.
 * @param[in] ipd_iplcap Target object that stores the results.
 *
 * @return 0 on success, -1 on error.
 */
static int ipd_iplcap_save_incremental_result(amxc_var_t* values, amxd_object_t* ipd_iplcap) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxd_status_t ret_status = amxd_status_unknown_error;
    amxd_trans_t* transaction = NULL;
    amxc_string_t aux_string;

    // Add each incremental result
    amxc_var_for_each(the_result, values) {
        const char* name = amxc_var_key(the_result);
        // Add a new instance
        transaction = ipd_transaction_create(ipd_iplcap);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_INC);

        amxc_string_init(&aux_string, 0);

        amxc_string_setf(&aux_string, "inc_%s", name);

        ret_status = amxd_trans_add_inst(transaction, atoi(name), amxc_string_get(&aux_string, 0));
        when_failed_trace(ret_status, exit, ERROR, "Could not add incremental result instance in the transaction");

        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);

        // Save the incremental result values
        transaction = ipd_transaction_create(ipd_iplcap);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_INC);

        ipd_var_to_dm(transaction, amxc_string_get(&aux_string, 0), the_result, NULL);
        amxc_string_clean(&aux_string);
        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);
    }

    rv = 0;
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

amxd_status_t ipd_iplcap_save_result_to_dm(amxc_var_t* ret, amxd_object_t* ipd_iplcap) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t* proc = NULL;
    amxc_var_t* modal_result = NULL;
    amxc_var_t* incremental_result = NULL;
    amxd_trans_t* transaction = NULL;
    amxc_llist_t* filter_list = NULL;
    amxd_status_t ret_status = amxd_status_unknown_error;

    amxc_llist_new(&filter_list);
    amxc_llist_add_string(filter_list, IPLCAP_RET_KEY_PROC);
    amxc_llist_add_string(filter_list, IPLCAP_RET_KEY_DST);
    amxc_llist_add_string(filter_list, IPLCAP_RET_KEY_MODAL);
    amxc_llist_add_string(filter_list, IPLCAP_RET_KEY_INC);
    amxc_llist_add_string(filter_list, "ConnectionAdded");

    proc = GET_ARG(ret, IPLCAP_RET_KEY_PROC);
    modal_result = GET_ARG(ret, IPLCAP_RET_KEY_MODAL);
    incremental_result = GET_ARG(ret, IPLCAP_RET_KEY_INC);

    transaction = ipd_transaction_create(ipd_iplcap);
    when_null_trace(transaction, exit, ERROR, "Could not create transaction");

    //Add results
    ipd_var_to_dm(transaction, NULL, ret, filter_list);
    //Add proc
    ipd_var_to_dm(transaction, IPLCAP_RET_KEY_PROC, proc, filter_list);

    //apply transaction
    ret_status = ipd_transaction_apply(transaction);
    ret_status = amxd_status_ok;

    // Add modal_result
    ipd_iplcap_save_modal_result(modal_result, ipd_iplcap);

    // Add incremental_result
    ipd_iplcap_save_incremental_result(incremental_result, ipd_iplcap);
exit:
    amxc_llist_delete(&filter_list, amxc_string_list_it_free);
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}

amxd_status_t ipd_iplcap_save_status_to_dm(amxc_var_t* ret, amxd_object_t* ipd_iplcap) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t ret_status = amxd_status_unknown_error;
    amxd_trans_t* transaction = NULL;

    transaction = ipd_transaction_create(ipd_iplcap);

    amxd_trans_set_param(transaction, IPLCAP_RET_KEY_DST, GET_ARG(ret, IPLCAP_RET_KEY_DST));

    //apply transaction
    ret_status = ipd_transaction_apply(transaction);
    when_failed_trace(ret_status, exit, ERROR, "Could not update %s with %s", IPLCAP_RET_KEY_DST, GET_CHAR(ret, IPLCAP_RET_KEY_DST));
    ret_status = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}

amxd_status_t ipd_iplcap_clean_result_from_dm(amxd_object_t* iplcap_object) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t ret_status = amxd_status_ok;
    amxd_param_t* param_def = NULL;
    const char* param_name = NULL;
    amxd_object_t* modal_obj = NULL;
    amxd_object_t* inc_obj = NULL;
    amxd_trans_t* transaction = NULL;
    amxc_ts_t null_time = {0};

    when_null_trace(iplcap_object, exit, ERROR, "IPLayerCapacity object is NULL");

    amxc_llist_for_each(it, &(iplcap_object->parameters)) {
        param_def = amxc_llist_it_get_data(it, amxd_param_t, it);
        param_name = amxd_param_get_name(param_def);

        // Reset read-only output parameters to default values
        if(amxd_param_is_attr_set(param_def, amxd_pattr_read_only)) {
            uint32_t param_type = amxd_param_get_type(param_def);
            switch(param_type) {
            case AMXC_VAR_ID_CSTRING:
                ret_status = amxd_object_set_value(cstring_t, iplcap_object, param_name, "");
                break;
            case AMXC_VAR_ID_TIMESTAMP:
                ret_status = amxd_object_set_value(amxc_ts_t, iplcap_object, param_name, &null_time);
                break;
            default:
                ret_status = amxd_object_set_value(uint32_t, iplcap_object, param_name, 0);
                break;
            }
            when_failed_trace(ret_status, exit, ERROR, "Failed to reset read-only output parameter %s", param_name);
        }
    }

    // Delete the previous hops from the datamodel
    modal_obj = amxd_object_findf(ipd_get_iplcap_object(), ".%s.", IPLCAP_RET_KEY_MODAL);
    when_null_trace(modal_obj, exit, ERROR, "Could not get the ModalResult object from dm");
    amxd_object_for_each(instance, it, modal_obj) {
        amxd_object_t* instance = amxc_container_of(it, amxd_object_t, it);
        transaction = ipd_transaction_create(iplcap_object);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_MODAL);
        ret_status = amxd_trans_del_inst(transaction, instance->index, NULL);
        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);
    }

    // Delete the previous hops from the datamodel
    inc_obj = amxd_object_findf(ipd_get_iplcap_object(), ".%s.", IPLCAP_RET_KEY_INC);
    when_null_trace(inc_obj, exit, ERROR, "Could not get the IncrementalResult object from dm");
    amxd_object_for_each(instance, it, inc_obj) {
        amxd_object_t* instance = amxc_container_of(it, amxd_object_t, it);
        transaction = ipd_transaction_create(iplcap_object);
        amxd_trans_select_pathf(transaction, ".%s.", IPLCAP_RET_KEY_INC);
        ret_status = amxd_trans_del_inst(transaction, instance->index, NULL);
        when_failed(ret_status, exit);
        ret_status = ipd_transaction_apply(transaction);
        when_failed(ret_status, exit);
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return ret_status;
}

void ipd_iplcap_sched_check(int fd, UNUSED void* priv, ipd_iplcap_scheduler_t* sch) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t* mod_ret = NULL;
    amxd_object_t* ipd_iplcap_object = NULL;
    amxc_var_t* params = NULL;
    const cstring_t status_str = NULL;
    int status = -1;
    bool abort_flag = true;

    amxc_var_new(&mod_ret);
    amxc_var_new(&params);
    amxc_var_set_type(mod_ret, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(params, AMXC_VAR_ID_HTABLE);

    ipd_iplcap_object = ipd_get_iplcap_object();
    when_null_trace(ipd_iplcap_object, exit, ERROR, "Failed to fetch object IPDiagnostics.IPLayerCapacityMetrics. from datamodel.");

    ipd_obj_data_to_var(ipd_iplcap_object, NULL, params);
    when_null_trace(params, exit, ERROR, "Failed to get the parameters to run the check.");

    abort_flag = false;

exit:
    if(abort_flag) {
        SAH_TRACEZ_ERROR(ME, "Aborting the ongoing iplcap test.");
        if(fd > 0) {
            amxo_connection_remove(ipd_get_parser(), fd);
        }
    } else {
        status = ipd_execute_ctrl_function_cb(ipd_iplcap_object, IPD_IPLCAP_TEST_CHECK, params, mod_ret);

        if(!sch->prev_test) {
            ipd_iplcap_save_result_to_dm(mod_ret, ipd_iplcap_object);
        }

        status_str = GET_CHAR(mod_ret, IPLCAP_RET_KEY_DST);

        if(!str_empty(status_str) && ((status < iplcap_test_not_complete) || (strcmp(status_str, IPLCAP_STATUS_NOT_COMPLETE) != 0))) {
            if(fd > 0) {
                amxo_connection_remove(ipd_get_parser(), fd);
            }
            sch->fd_stderr = 0;
            sch->fd_stdout = 0;
            sch->pid = 0;

            if(!sch->prev_test) {
                ipd_iplcap_save_status_to_dm(mod_ret, ipd_iplcap_object);
                ipd_filter_ret(mod_ret, true, IPLCAP);
                amxd_function_deferred_done(sch->call_id, amxd_status_ok, NULL, mod_ret);
            }
        }
    }

    amxc_var_delete(&params);
    amxc_var_delete(&mod_ret);
    SAH_TRACEZ_OUT(ME);
}
