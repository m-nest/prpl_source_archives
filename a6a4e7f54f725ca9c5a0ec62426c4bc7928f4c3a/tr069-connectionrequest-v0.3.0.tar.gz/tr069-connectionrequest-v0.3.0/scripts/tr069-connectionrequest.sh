#!/bin/sh /etc/rc.common

START=99
STOP=00
USE_PROCD=1

start_service() {
    procd_open_instance
    procd_set_param command /usr/bin/tr069-connectionrequest
    # Enable auto-restart: respawn [threshold] [timeout] [retry]
    procd_set_param respawn 3600 5 5
    # Log output to 'logread'
    procd_set_param stdout 1
    procd_set_param stderr 1
    procd_close_instance
}

