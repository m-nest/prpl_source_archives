# tr181-ethernet

## Introduction

`tr181-ethernet` is a TR-181 compliant Ethernet manager plugin, providing a data model and management interface for Ethernet.

## Architecture

The architecture is based on a modular plugin system, with the main `ethernet-manager` core and several supporting modules:

### Components

- **ethernet-manager**:
    - The main plugin responsible for managing the TR-181 Ethernet data model. It coordinates all submodules, handles configuration persistence, and exposes Ethernet interfaces, links, and VLANs through the TR-181 interface.
- **mod-eth-lla**:
    - Manages low-level Ethernet MAC/PHY operations.
- **mod-eth-switch**:
    - Manages Ethernet switch features.
- **mod-netdev-stats**:
    - Collects and exposes network device statistics.
- **mod-switch-led**:
    - Manages switch LED indicators.
- **mod-switch-stats**:
    - Manages switch-specific statistics.
- **mod-led-dummy**:
    - Dummy module for LED management.
- **mod-vlan-dummy**:
    - Dummy module for VLAN management.
- **mod-pwr-dummy**:
    - Implements a framework for power management integration. It gets the system PowerCapability and PowerStatus via LL-API. This module is a template for future hardware-specific power management implementations.

### SFP support
`Ethernet.Interface` objects can be linked with a `SFPs.SFPCage` object through `SFPReferenceList` parameter. `SFPSupportedType` specify the allowed `SFPs.SFPCage.{i}.SFPType` values for which the `Ethernet.Interface.{i}.Status` can transition to other states than `NotPresent`.

### Workflow

1. **Initialization**:
   On startup, `ethernet-manager` loads all available modules and initializes the TR-181 data model. It reads persisted configuration and sets up the initial state for all Ethernet interfaces, links, and VLANs.

2. **Module Registration**:
   Each module registers its capabilities and event handlers with the core manager. This allows dynamic discovery and activation of features based on the detected hardware and configuration.

3. **Event Handling**:
   The manager listens for system and network events, such as interface state changes, configuration updates. Modules notify the core manager of relevant events, which are then propagated as needed.

4. **Power Management**:
   When the system enters a new power state (e.g., LowPower, On or Off), `mod-pwr-dummy` receives the event and coordinates any necessary changes via LL-API in the Ethernet subsystem. This ensures interfaces are properly managed during power transitions and provides a foundation for future hardware-specific enhancements.

5. **Runtime Operation**:
   During normal operation, the manager continuously monitors and manages Ethernet interfaces, links, VLANs, and statistics. All relevant data is exposed via the TR-181 data model for external management and monitoring.

6. **Shutdown**:
   On shutdown or restart, the manager persists the current configuration and gracefully unloads all modules, ensuring a clean state for the next startup.

### Features

- **Power Management**: Integrates a power management framework to support system power state transitions and to allow hardware-specific power controller implementations. The `ChangePowerMode()` RPC is handled asynchronously and updates `PowerStatus` when the selected power controller reports completion.

## Power Management

This service supports Ethernet interface power management capabilities, allowing each interface to be configured in different power states. The power management feature includes:

- **Power Capability** - The `PowerCapability` parameter describes the possible power states supported by the interface (for example `On`, `Off`, `LowPower`).
- **Power Status** - The `PowerStatus` parameter reports the current power state of the interface.
- **Power State** - The `PowerState` parameter stores the requested target power state.
- **ChangePowerMode** - An asynchronous function `ChangePowerMode(PowerState)` that triggers a power state transition.

### External Modules

The power management functionality is implemented through an external power controller system that allows loading of platform-specific implementations:

- Power controller modules are loaded from `ethernet-manager.mod-dir` (default: `/usr/lib/amx/tr181-ethernet/modules`).
- Controllers must be listed in `Ethernet.SupportedPWRControllers` before they can be selected.
- A controller can be selected globally through `Ethernet.PowerController` or per interface through `Ethernet.Interface.{i}.PowerController`.
- The in-tree `mod-pwr-dummy` module provides a reference implementation for future hardware-specific modules.

#### Power Module API

Power modules implement the following command functions:

- **`pwr-mode-set`** - Starts a power transition for an Ethernet interface. This is used by the `ChangePowerMode()` RPC and is completed asynchronously when the module calls the internal `pwr-async-done` callback.
- **`pwr-capabilities-get`** - Returns the list of power states supported by the hardware platform (for example `On,Off,LowPower`).
- **`pwr-status-get`** - Returns the current power state of the interface from the hardware or platform layer.

The asynchronous execution of `ChangePowerMode()` allows `tr181-ethernet` to keep the RPC deferred while the selected module performs the platform-specific work. When the module signals completion, `tr181-ethernet` updates `PowerStatus` and completes the deferred request.

For detailed information on implementing a power management module in a separate repository, including function signatures, required return keys, registration, asynchronous completion, and build/install examples, see [POWER_MODULE_API.md](POWER_MODULE_API.md).

## Building, Installing, and Testing

### Docker Container

You can install all the necessary tools for testing and developing on your local machine or use a pre-configured environment. A pre-configured environment is available as a Docker container.

1. **Install Docker**:

    Docker must be installed on your system. Here are some links that could help you:

    - [Get Docker Engine - Community for Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

    Make sure your user ID is added to the Docker group:

        sudo usermod -aG docker $USER

2. **Fetch the Container Image**:

    To get access to the pre-configured environment, pull the image and launch a container.

    Pull the image:

        docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    Before launching the container, create a directory that will be shared between your local machine and the container.

        mkdir -p ~/amx/libraries/

    Launch the container:

        docker run -ti -d \
            --name oss-dbg \
            --restart=always \
            --cap-add=SYS_PTRACE \
            --sysctl net.ipv6.conf.all.disable_ipv6=1 \
            -e "USER=$USER" \
            -e "UID=$(id -u)" \
            -e "GID=$(id -g)" \
            -v ~/amx:/home/$USER/amx \
            registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    The `-v` option bind mounts the local directory for the AMX project in the container, at the exact same place. The `-e` options create environment variables in the container. These variables are used to create a user name with the same user ID and group ID in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

        docker exec -ti --user $USER oss-dbg /bin/bash

### Building

#### Prerequisites

`tr181-ethernet` depends on the following libraries:

 * amxrt
 * libamxb
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxs
 * libamxrt
 * libnetmodel
 * libsahtrace
 * mod-dmext
 * mod-dmstats
 * mod-vlan-ioctl
 * mod-vlan-uci
 * mod-netmodel

These libraries can be installed in the container:

    sudo apt-get install libamxb libamxc libamxd libamxm libamxo libamxp libamxs libamxrt mod-sahtrace sah-lib-sahtrace-dev libnetmodel mod-dmext mod-dmstats mod-vlan-ioctl mod-vlan-uci mod-netmodel

### Testing

#### Prerequisites

No extra components are needed for testing `tr181-ethernet`.

#### Run tests

You can run the tests by executing the following command:

    ```bash
    cd ~/amx/plugins/tr181-ethernet/test
    make
    ```

Or this command if you also want the coverage tests to run:

    ```bash
    cd ~/amx/plugins/tr181-ethernet/tests
    make run coverage
    ```

You can combine both commands:

    ```bash
    cd ~/amx/plugins/tr181-ethernet
    make test
    ```

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each C file is printed in your console after the tests are run. An HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used. For example, when using native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/amx/plugins/tr181-ethernet/output/x86_64-linux-gnu/coverage/report`.

You can easily access the reports in your browser. In the container, start a python3 HTTP server in the background.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-ethernet/output/<MACHINE>/coverage/report
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/tr181-ethernet$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/tr181-ethernet/output/x86_64-linux-gnu/coverage/report/`

### Documentation

#### Prerequisites

To generate the documentation, [Doxygen](https://www.doxygen.nl) is required and already available in the container. In case you want to install this on your local machine:

    ```bash
    sudo apt-get install doxygen
    ```

#### Paths

The documentation is split into two parts, starting from the repository path:

    ```bash
    cd ~/amx/plugins/tr181-ethernet
    ```

Here, you can find:

- `README.md`: This file is used on GitLab and is the main page for the Doxygen documentation.
- `docs` directory: Contains the Doxygen settings, code examples, and additional pages used in Doxygen.

The code itself is documented in the appropriate header and source files.

#### Generate documentation

To generate the documentation, Doxygen needs to be installed. Alternatively, `amxo-cg` and `amxo-xml-to` packages can be installed to generate the documentation. You can generate the documentation by executing the following command:

    ```bash
    cd ~/amx/plugins/tr181-ethernet
    make doc
    ```

The full documentation is available in the `output` directory. You can easily access the documentation in your browser. As described in the coverage reports section, you can start an HTTP server in the container.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/tr181-ethernet/output/html/index.html
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/tr181-ethernet$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/tr181-ethernet/output/html/index.html`

Alternatively, you can open the documentation via command:

    ```bash
    xdg-open tr181-ethernet/output/html/index.html
    ```
