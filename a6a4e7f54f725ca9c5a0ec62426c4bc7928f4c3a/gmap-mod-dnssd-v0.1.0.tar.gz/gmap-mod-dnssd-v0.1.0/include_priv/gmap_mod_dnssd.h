/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef GMAP_MOD_DNSSD_H
#define GMAP_MOD_DNSSD_H

#ifdef __cplusplus
extern "C"
{
#endif

/**
   @defgroup gmap_mod_dnssd Generic dnnsd functions
 */

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <time.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <amxb/amxb.h>
#include <amxs/amxs.h>
#include <amxp/amxp_timer.h>

#include <gmap/gmap.h>
#include <gmap/gmap_devices.h>
#include <gmap/gmap_devices_flags.h>
#include <gmap/gmap_device.h>
#include <gmap/extensions/ip/gmap_ext_ip_devices.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>


/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Retrieves the GMAP context.
 *
 * Returns the internal GMAP bus context used for DNSSD operations.
 *
 * @param None
 * @return Pointer to the GMAP bus context.
 */
amxb_bus_ctx_t* retrieve_gmap_ctx(void);

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Retrieves the DNSSD context.
 *
 * Returns the internal DNSSD bus context used for service handling.
 *
 * @param None
 * @return Pointer to the DNSSD bus context.
 */
amxb_bus_ctx_t* retrieve_dnssd_ctx(void);

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief GMAP DNSSD module entry point.
 *
 * Handles subscription or unsubscription to DNSSD services depending
 * on the provided reason. This function is typically invoked by the
 * data model or parser during module lifecycle operations.
 *
 * @param reason     Operation reason:
 *                   - `0`: subscribe
 *                   - `1`: unsubscribe
 * @param datamodel  Pointer to the data model instance. Must not be NULL.
 * @param parser     Pointer to the parser instance. Must not be NULL.
 *
 * @return 1 on successful subscribe/unsubscribe operation,
 *        -1 on error.
 */
int _gmap_mod_dnssd_entrypoint(int reason, amxd_dm_t* datamodel, amxo_parser_t* parser);
#ifdef __cplusplus
}
#endif

#endif  /* GMAP_MOD_DNSSD_H */
