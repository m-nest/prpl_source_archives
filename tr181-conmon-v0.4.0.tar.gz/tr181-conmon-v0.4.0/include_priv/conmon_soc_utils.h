/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__CONMON_SOC_UTILS_H__)
#define __CONMON_SOC_UTILS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "conmon.h"

#define MOD_CONMON_UPDATE_CONFIG_FUNCTION "update-config"
#define MOD_CONMON_UPDATE_STOP_FUNCTION   "stop"

/**
   @file
   @brief
   General tool box for tr181-conmon plugin interaction with back-end module
 */

/**
   @ingroup conmon
   @defgroup conmon_soc_utils ConMon back-end tool box

   Functions used by conmon plugins across the different files
 */

/**
   @ingroup conmon_soc_utils
   @brief
   Create the data structure to be passed to the back-end module

   @param conmon The conmon_info_t structure to use to retreive the informations not available in the data variant
   @param data Return variant containing the following variables :
   - ip_version : The ip version of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - alias : The Alias of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - interface_name : The linux interface name corresponding to the Interface set in the the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - local_mac : The MAC address of the interface link to the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - logical_path : The interface of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - retries_max : The number of retry the ConMon.Entry.i object related to the conmon_info_t conmon pointer has already done
   - retry_interval : The response timout of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - main_interval :  The interval for the main retry loop of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - fail_interval : The interval for the fail retry loop of the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   @param set_stats If the stats need to be included in the data variant. Those variables will also be available
   - arpns_errors_sent : Number of arp error send by the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - arpns_total_fail : Number of arp fail done by the ConMon.Entry.i object related to the conmon_info_t conmon pointer
   - total_dhcp_restarts : Number of dhcp DORA cycle done by the ConMon.Entry.i object related to the conmon_info_t conmon pointer
 */
void mod_conmon_build_basic_data_struct(conmon_info_t* conmon, amxc_var_t* data, bool set_stats);

/**
   @ingroup conmon_soc_utils
   @brief
   Wrapper function to be call in mod-descoping

   @param function The name of the function in the back-end to be called
   @param data The variant data to be sent to the back-end. This should be created by mod_conmon_build_basic_data_struct

   @return
   0 on success
 */
int mod_conmon_execute_function(const char* function, amxc_var_t* data);

#ifdef __cplusplus
}
#endif

#endif // __CONMON_SOC_UTILS_H__
