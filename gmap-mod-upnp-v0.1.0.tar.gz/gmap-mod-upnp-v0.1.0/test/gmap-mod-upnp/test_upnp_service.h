/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_MOD_UPNP_SERVICE_H__)
#define __GMAP_MOD_UPNP_SERVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <gmap/gmap_devices.h>
#include <gmap/gmap_device.h>
#include <gmap/gmap.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Handles a GET operation for a UPNP data model object.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the arguments passed to the function.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _get(amxd_object_t* object,
                   amxd_function_t* func,
                   amxc_var_t* args,
                   amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Creates a new UPNP device instance.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _createDevice(amxd_object_t* object,
                            amxd_function_t* func,
                            amxc_var_t* args,
                            amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Destroys an existing UPNP device instance.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _destroyDevice(amxd_object_t* object,
                             amxd_function_t* func,
                             amxc_var_t* args,
                             amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Adds a link between UPNP device instances.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _linkAdd(amxd_object_t* object,
                       amxd_function_t* func,
                       amxc_var_t* args,
                       amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Removes a link between UPNP device instances.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _linkRemove(amxd_object_t* object,
                          amxd_function_t* func,
                          amxc_var_t* args,
                          amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Retrieves the UPNP device topology.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _topology(amxd_object_t* object,
                        amxd_function_t* func,
                        amxc_var_t* args,
                        amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Executes a search operation in the UPNP hierarchy.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _find(amxd_object_t* object,
                    amxd_function_t* func,
                    amxc_var_t* args,
                    amxc_var_t* ret);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Wrapper used for mocking `gmap_query_open_ext_2` during tests.
 *
 * @param query       Output pointer receiving the newly created query.
 * @param expression  GMAP query expression string.
 * @param name        Query name.
 * @param flags       Query creation flags.
 * @param fn          Callback associated with the query.
 * @param user_data   User-provided callback data.
 *
 * @return true on success, false on failure.
 */
bool __wrap_gmap_query_open_ext_2(gmap_query_t** query,
                                  const char* expression,
                                  const char* name,
                                  gmap_query_flags_t flags,
                                  gmap_query_cb_t fn,
                                  void* user_data);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Test setup function. Allocates and initializes test resources.
 *
 * @param state  CMocka test state pointer.
 *
 * @return 0 on success.
 */
int test_mod_upnp_setup(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Test teardown function. Frees all allocated test resources.
 *
 * @param state  CMocka test state pointer.
 *
 * @return 0 on success.
 */
int test_mod_upnp_teardown(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Verifies that existing devices are added correctly.
 *
 * @param state  CMocka test state pointer.
 */

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests that existing devices are properly added during initialization.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_adds_existing_devices(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests that server parameters are set correctly at module startup.
 *
 * @param state  CMocka test state pointer.
 */
void test_server_parameter_set_at_beginning(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests the addition of a second UPNP service instance for the same device.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_add_second_service_instance(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests adding a device instance whose parent does not yet exist.
 *
 * The module should either defer or reject the addition depending on design.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_add_device_with_non_existing_parent(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests adding a device instance once its parent appears later.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_add_device_parent_later(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests adding an IP-type UPNP device at a later stage.
 *
 * Verifies proper classification and linking in the topology.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_add_ip_device_later(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests adding a device that is linked under another lower-level device.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_add_lower_linked_device(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests adding a UPNP service before its device instance exists.
 *
 * The module should defer the service until the device appears.
 *
 * @param state  CMocka test state pointer.
 */
void test_add_service_before_device_instance(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests setting a server parameter after initialization has completed.
 *
 * @param state  CMocka test state pointer.
 */
void test_server_parameter_set_later(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests setting server parameters between device and service additions.
 *
 * Ensures parameter propagation is correct.
 *
 * @param state  CMocka test state pointer.
 */
void test_server_parameter_set_in_between(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests removal of a UPNP service instance.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_remove_service_instance(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests removal of a UPNP device instance.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_remove_device_instance(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests that cleaning up a service twice does not cause errors.
 *
 * Ensures correct handling of repeated cleanup calls.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_clean_up_service_twice(void** state);

/**
 * @ingroup gmap_mod_upnp_tests
 *
 * @brief Tests that removing a device also unlinks any linked devices.
 *
 * Ensures topology integrity is preserved.
 *
 * @param state  CMocka test state pointer.
 */
void test_mod_upnp_remove_device_unlinks_linked_devices(void** state);


#ifdef __cplusplus
}
#endif

#endif  /* __GMAP_MOD_UPNP_SERVICE_H__ */
