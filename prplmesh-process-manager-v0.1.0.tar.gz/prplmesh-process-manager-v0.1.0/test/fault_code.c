/*
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2026 Inango
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Subject to the terms and conditions of this license, each copyright holder
 * and contributor hereby grants to those receiving rights under this license
 * a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 * (except for failure to satisfy the conditions of this license) patent license
 * to make, have made, use, offer to sell, sell, import, and otherwise transfer
 * this software, where such license applies only to those patent claims, already
 * acquired or hereafter acquired, licensable by such copyright holder or contributor
 * that are necessarily infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright holders and
 * non-copyrightable additions of contributors, in source or binary form) alone;
 * or
 *
 * (b) combination of their Contribution(s) with the work of authorship to which
 * such Contribution(s) was added by such copyright holder or contributor, if,
 * at the time the Contribution is added, such addition causes such combination
 * to be necessarily infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any copyright
 * holder or contributor is granted under this license, whether expressly, by
 * implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <unistd.h>

#include <yajl/yajl_gen.h>

#include <amxc/amxc.h>
#include <amxj/amxj_variant.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>

#include "common.h"
#include "service.h"
#include "callbacks.h"

#define ODL_DIR "./"
#define PROCESS_MANAGER_DEFINITION_ODL ODL_DIR "prplmesh-process-manager_definition.odl"
#define PROCESS_MANAGER_STATUS_PARAM "Status"
#define PROCESS_MANAGER_FAULTCODE_PARAM "FaultCode"
#define NUMBER_OF_MANAGED_SERVICES 3

int test_setup(void** state) {
    amxut_bus_setup(state);
    amxut_dm_load_odl(PROCESS_MANAGER_DEFINITION_ODL);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_teardown(state);

    return 0;
}

// wrappers
amxd_dm_t* __wrap_amxrt_get_dm() {
    return amxut_bus_dm();
}

ServiceStatus service_statuses[SERVICE_KIND_MAX];

ServiceStatus __wrap_process_monitor_service_status(ServiceKind service) {
    return service_statuses[service];
}

// Helper functions
void call_with_json(const char* json, amxp_slot_fn_t fn, void* priv) {
    amxc_var_t data;
    amxc_var_init(&data);
    amxc_var_set(jstring_t, &data, json);
    amxc_var_cast(&data, AMXC_VAR_ID_ANY);

    expect_any(__wrap_process_monitor_service_control, service);
    fn("dm:object-changed", &data, priv);

    amxc_var_clean(&data);
}

void set_service_status(ServiceKind service, ServiceStatus status) {
    service_statuses[service] = status;
}

void set_other_services_idle() {
}

void correct_start(const char* object_path, ServiceKind service, amxp_slot_fn_t handler) {
// Idle
    set_service_status(service, SERVICE_STATUS_IDLE);
    set_other_services_idle();

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Idle");

// Starting
    set_service_status(service, SERVICE_STATUS_IDLE);
    set_other_services_idle();

    expect_value(__wrap_process_monitor_service_control, action, SERVICE_ACTION_START);
    call_with_json(R"({
            "parameters": {
                "Enable": {
                    "to": true
                }
            }
        })", handler, NULL);

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Starting");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "NoFault");

    callback_process(0);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Active");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "NoFault");
}

void correct_stop(const char* object_path, ServiceKind service, amxp_slot_fn_t handler) {
    expect_value(__wrap_process_monitor_service_control, action, SERVICE_ACTION_STOP);
    call_with_json(R"({
            "parameters": {
                "Enable": {
                    "to": false
                }
            }
        })", handler, NULL);

    callback_process(0);

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Idle");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "NoFault");
}

void failed_start(char* object_path, ServiceKind service, amxp_slot_fn_t handler) {
// Idle
    set_service_status(service, SERVICE_STATUS_IDLE);
    set_other_services_idle();

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Idle");

// Starting
    set_service_status(service, SERVICE_STATUS_IDLE);
    set_other_services_idle();

    expect_value(__wrap_process_monitor_service_control, action, SERVICE_ACTION_START);
    call_with_json(R"({
            "parameters": {
                "Enable": {
                    "to": true
                }
            }
        })", handler, NULL);

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Starting");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "NoFault");

    callback_process(1);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Error");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "FailureOnStart");
}

void failed_stop(char* object_path, ServiceKind service, amxp_slot_fn_t handler) {
// Active
    set_service_status(service, SERVICE_STATUS_RUNNING);
    set_other_services_idle();

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Active");

// Stopping
    set_service_status(service, SERVICE_STATUS_RUNNING);
    set_other_services_idle();

    expect_value(__wrap_process_monitor_service_control, action, SERVICE_ACTION_STOP);
    call_with_json(R"({
            "parameters": {
                "Enable": {
                    "to": false
                }
            }
        })", handler, NULL);

    update_services_statuses_callback(NULL, NULL);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Stopping");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "NoFault");

    callback_process(1);

    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_STATUS_PARAM, "Error");
    amxut_dm_param_equals(cstring_t, object_path, PROCESS_MANAGER_FAULTCODE_PARAM, "FailureOnStop");
}

void sensing(void** state) {
    // NOTE: order matters!
    correct_start(PROCESS_MANAGER_ROOT "Sensing", SERVICE_KIND_SENSING, _sensing_object_changed);
    failed_start(PROCESS_MANAGER_ROOT "Sensing", SERVICE_KIND_SENSING, _sensing_object_changed);
    correct_stop(PROCESS_MANAGER_ROOT "Sensing", SERVICE_KIND_SENSING, _sensing_object_changed);
    failed_stop(PROCESS_MANAGER_ROOT "Sensing", SERVICE_KIND_SENSING, _sensing_object_changed);
}

void pwhm(void** state) {
    // NOTE: order matters!
    correct_start(PROCESS_MANAGER_ROOT "PWHM", SERVICE_KIND_PWHM, _pwhm_object_changed);
    failed_start(PROCESS_MANAGER_ROOT "PWHM", SERVICE_KIND_PWHM, _pwhm_object_changed);
    correct_stop(PROCESS_MANAGER_ROOT "PWHM", SERVICE_KIND_PWHM, _pwhm_object_changed);
    failed_stop(PROCESS_MANAGER_ROOT "PWHM", SERVICE_KIND_PWHM, _pwhm_object_changed);
}

void prplmesh(void** state) {
    // NOTE: order matters!
    correct_start(PROCESS_MANAGER_ROOT "PrplMesh", SERVICE_KIND_PRPLMESH, _prplmesh_object_changed);
    failed_start(PROCESS_MANAGER_ROOT "PrplMesh", SERVICE_KIND_PRPLMESH, _prplmesh_object_changed);
    correct_stop(PROCESS_MANAGER_ROOT "PrplMesh", SERVICE_KIND_PRPLMESH, _prplmesh_object_changed);
    failed_stop(PROCESS_MANAGER_ROOT "PrplMesh", SERVICE_KIND_PRPLMESH, _prplmesh_object_changed);
}

int main(void) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(sensing),
        cmocka_unit_test(pwhm),
        cmocka_unit_test(prplmesh),
    };

    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
