/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "discoping_calls.h"
#include "discoping_dm.h"

static void s_arp_callback(const char* ip, UNUSED const char* mac, void* userdata) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = (active_discoping_t*) userdata;
    when_null(entry, exit);

    if(strcmp(ip, entry->wan_ip) == 0) {
        SAH_TRACEZ_INFO(ME, "[%s] ARP succeeded", entry->alias);
        amxp_timer_stop(entry->deadline_timer);
        entry->response_received = true;
    }

exit:
    SAH_TRACEZ_OUT(ME);
}

static void s_ndp_callback(const char* ip, UNUSED const char* mac, void* userdata) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = (active_discoping_t*) userdata;
    when_null(entry, exit);

    if(strcmp(ip, entry->wan_ip) == 0) {
        SAH_TRACEZ_INFO(ME, "[%s] ND succeeded", entry->alias);
        amxp_timer_stop(entry->deadline_timer);
        entry->response_received = true;
    }

exit:
    SAH_TRACEZ_OUT(ME);
}


void send_ipv4(active_discoping_t* entry) {
    SAH_TRACEZ_IN(ME);
    bool socket_created = false;

    when_null_trace(entry, error, ERROR, "entry not found");
    arp_socket_delete(&entry->arp_socket);

    socket_created = arp_socket_new(&entry->arp_socket, get_parser(), entry->interface_name, entry->local_ip, s_arp_callback);
    if(socket_created && (entry->arp_socket != NULL)) {
        arp_socket_set_userdata(&entry->arp_socket, entry);

        SAH_TRACEZ_INFO(ME, "[%s] Sending ARP from [%s - %s] to [%s] on interface %s", entry->alias, entry->local_ip, entry->local_mac, entry->wan_ip, entry->interface_name);
        if(arp_socket_send_request(entry->arp_socket, entry->local_ip, entry->wan_ip, entry->local_mac) == false) {
            SAH_TRACEZ_ERROR(ME, "[%s] Failed to send ARP message", entry->alias);
            entry->arpns_errors_sent++;
            update_dm(entry);
            goto exit;
        }
        entry->isdeferring = true;
    } else {
        SAH_TRACEZ_ERROR(ME, "[%s] Error initializing discoping arp_socket", entry->alias);
    }

exit:
    // we have not yet received a response
    entry->response_received = false;

    amxp_timer_start(entry->response_timer, entry->fail_interval);
    amxp_timer_start(entry->deadline_timer, entry->retry_interval);

error:
    SAH_TRACEZ_OUT(ME);
}

void send_ipv6_ns(active_discoping_t* entry) {
    SAH_TRACEZ_IN(ME);
    bool socket_created = false;

    when_null_trace(entry, error, ERROR, "entry not found");
    ndp_socket_delete(&entry->ndp_socket);

    socket_created = ndp_socket_new(&entry->ndp_socket, get_parser(), entry->interface_name, entry->local_ip, s_ndp_callback);
    if(socket_created && (entry->ndp_socket != NULL)) {
        ndp_socket_set_userdata(&entry->ndp_socket, entry);

        SAH_TRACEZ_INFO(ME, "[%s] Sending NS from [%s - %s] to [%s] on interface %s", entry->alias, entry->local_ip, entry->local_mac, entry->wan_ip, entry->interface_name);
        if(ndp_socket_send_request(entry->ndp_socket, entry->local_ip, entry->wan_ip, entry->local_mac) == false) {
            SAH_TRACEZ_ERROR(ME, "[%s] Failed to send NS message", entry->alias);
            entry->arpns_errors_sent++;
            update_dm(entry);
            goto exit;
        }
        entry->isdeferring = true;
    } else {
        SAH_TRACEZ_ERROR(ME, "[%s] Error initializing discoping ndp_socket", entry->alias);
    }

exit:
    // we have not yet received a response
    entry->response_received = false;

    amxp_timer_start(entry->response_timer, entry->fail_interval);
    amxp_timer_start(entry->deadline_timer, entry->retry_interval);

error:
    SAH_TRACEZ_OUT(ME);
}