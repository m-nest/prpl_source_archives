/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/
#include "usb.h"
#include "usb-dm.h"
#include "usb-pwr.h"

#define ME "usb"
#define ODL_DEFAULTS "?include '${odl.directory}/${name}.odl':'${odl.dm-defaults}';" // location of default configuration

// Structure to hold application context
typedef struct {
    amxd_dm_t* data_model;
    amxo_parser_t* parser;
} app_context_t;

static app_context_t app_ctx;
static amxp_subproc_t* usbscan_proc = NULL;

// Function to get the data model
amxd_dm_t* get_dm(void) {
    return app_ctx.data_model;
}

static int dm_mngr_load_async_controllers(void) {
    SAH_TRACEZ_IN(ME);
    int ret = -1;

    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_PWR_CTRL);
    ret = amxm_module_add_function(mod, "pwr-async-done", usb_async_change_power_mode_status_set_done);

    SAH_TRACEZ_OUT(ME);
    return ret;
}

static int dm_mngr_load_controllers(const char* supported_cntrlrs_param, const char* mod_dir) {
    SAH_TRACEZ_IN(ME);
    int ret = -1;
    amxd_dm_t* dm = get_dm();
    amxd_object_t* usb_obj = amxd_dm_findf(dm, "USB");
    const amxc_var_t* controllers = amxd_object_get_param_value(usb_obj,
                                                                supported_cntrlrs_param);
    amxc_var_t lcontrollers;
    amxm_shared_object_t* so = NULL;
    amxc_string_t mod_path;

    amxc_var_init(&lcontrollers);
    amxc_string_init(&mod_path, 0);

    amxc_var_convert(&lcontrollers, controllers, AMXC_VAR_ID_LIST);
    amxc_var_for_each(controller, &lcontrollers) {
        const char* name = GET_CHAR(controller, NULL);
        amxc_string_setf(&mod_path, "%s/%s.so", mod_dir, name);
        SAH_TRACEZ_INFO(ME, "Loading controller '%s' (file = %s)", name, amxc_string_get(&mod_path, 0));
        ret = amxm_so_open(&so, name, amxc_string_get(&mod_path, 0));
        SAH_TRACEZ_INFO(ME, "Loading controller '%s' %s", name, ret ? "failed" : "successful");
        when_failed_trace(ret, exit, WARNING, "Not continuing with loading modules");
    }

exit:
    amxc_string_clean(&mod_path);
    amxc_var_clean(&lcontrollers);
    SAH_TRACEZ_OUT(ME);
    return ret;
}

static int dm_mngr_load_dummy(const char* mod_dir, const char* name) {
    SAH_TRACEZ_IN(ME);
    int ret = -1;
    amxm_shared_object_t* so = NULL;
    amxc_string_t mod_path;

    amxc_string_init(&mod_path, 0);

    amxc_string_setf(&mod_path, "%s/%s.so", mod_dir, name);
    SAH_TRACEZ_INFO(ME, "Loading controller '%s' (file = %s)", name, amxc_string_get(&mod_path, 0));
    ret = amxm_so_open(&so, name, amxc_string_get(&mod_path, 0));

    amxc_string_clean(&mod_path);
    SAH_TRACEZ_OUT(ME);
    return ret;
}

/**
 * @brief Initializes the modules.
 *
 * @param data_model The data model.
 * @param parser The parser.
 * @return int The status of the operation.
 */
static int initialize_modules(amxd_dm_t* data_model, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    int ret = -1;
    const char* mod_dir = NULL;

    SAH_TRACEZ_INFO(ME, "USB modules loading start");
    if((data_model == NULL) || (parser == NULL)) {
        goto exit;
    }

    mod_dir = GETP_CHAR(&parser->config, "mod-dir");
    if((mod_dir == NULL) || (mod_dir[0] == '\0')) {
        mod_dir = GETP_CHAR(&parser->config, "external-mod-dir");
        if((mod_dir == NULL) || (mod_dir[0] == '\0')) {
            SAH_TRACEZ_ERROR(ME, "No valid module directory specified in config");
            goto exit;
        }
    }

    ret = dm_mngr_load_controllers("SupportedPWRControllers", mod_dir);
    if(ret != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to load all SupportedPWRControllers");
        ret = dm_mngr_load_dummy(mod_dir, DUMMY_PWR_MOD_NAME);
        when_failed_trace(ret, exit, ERROR, "Failed to load dummy PowerController");
    } else {
        SAH_TRACEZ_INFO(ME, "All SupportedPWRControllers loaded successfully");
    }

    ret = dm_mngr_load_async_controllers();
    if(ret != 0) {
        when_failed_trace(ret, exit, ERROR, "Failed to load async controllers");
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return ret;
}

/**
 * @brief Initializes the application.
 *
 * @param data_model The data model.
 * @param parser The parser.
 * @return int The status of the operation.
 */
static int initialize_app(amxd_dm_t* data_model, amxo_parser_t* parser) {
    int ret = -1;
    if((data_model == NULL) || (parser == NULL)) {
        return ret;
    }
    memset(&app_ctx, 0, sizeof(app_ctx));
    app_ctx.data_model = data_model;
    app_ctx.parser = parser;
    amxo_parser_parse_string(parser, ODL_DEFAULTS, amxd_dm_get_root(data_model));

    // Scan available USB devices in filesystem to contruct data model
    amxp_subproc_new(&usbscan_proc);
    ret = amxp_subproc_start(usbscan_proc, (char*) "trigger-usb-events", NULL);
    if(ret == 0) {
        SAH_TRACEZ_INFO(ME, "trigger-usb-events has successfuly started (pid[%d])", amxp_subproc_get_pid(usbscan_proc));
    } else {
        SAH_TRACEZ_ERROR(ME, "Couldn't start trigger-usb-events (%d)", ret);
    }

    // Initialize modules
    ret = initialize_modules(data_model, parser);
    if(ret != 0) {
        when_failed_trace(ret, exit, ERROR, "Failed to initialize modules");
    } else {
        SAH_TRACEZ_INFO(ME, "Modules initialized successfully");
    }

exit:
    return ret;
}

/**
 * @brief Cleans up the application.
 *
 * @return int The status of the operation.
 */
static int cleanup_app(void) {
    app_ctx.data_model = NULL;
    app_ctx.parser = NULL;
    if(usbscan_proc != NULL) {
        if(usbscan_proc->is_running) {
            amxp_subproc_kill(usbscan_proc, SIGKILL);
        }
        amxp_subproc_delete(&usbscan_proc);
    }
    return 0;
}

/**
 * @brief Handler for the app:start signal.
 *
 * Initializes TR-181 USB saved objects and power management procedure in the data model.
 * Runs after the entry point so that saved DM objects, which do not emit
 * events, are properly initialized.
 *
 * @param sig_name Name of the received signal.
 * @param data Optional signal payload.
 * @param priv User-provided context pointer.
 */
void _app_start(UNUSED const char* const sig_name,
                UNUSED const amxc_var_t* const data,
                UNUSED void* const priv) {

    SAH_TRACEZ_INFO(ME, "app:start - TR-181 USB initializing saved objects...");
    dm_usb_ports_pwr_init();
}

/**
 * @brief Main entry point for the application.
 *
 * @param reason The reason for the call.
 * @param dm The data model.
 * @param parser The parser.
 * @return int The status of the operation.
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 0;
    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "entrypoint - start");
        retval = initialize_app(dm, parser);
        break;

    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "entrypoint - stop");
        retval = cleanup_app();
        break;
    }

    return retval;
}
