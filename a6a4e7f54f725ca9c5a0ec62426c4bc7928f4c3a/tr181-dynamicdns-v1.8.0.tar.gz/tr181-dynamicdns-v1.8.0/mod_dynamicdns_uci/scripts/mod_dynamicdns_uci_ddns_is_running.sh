#!/bin/sh

set +x
pgrep -f -a "$1 -- start"
