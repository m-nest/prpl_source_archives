/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <cap-ng.h>
#include "faultmonitor.h"

#include <filetransfer/filetransfer.h>

#define ME DEFAULT_TRACE_ZONE_NAME

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxc_string_t object_name;
    amxd_object_t* root_object;
} app_t;

static app_t app;

amxd_dm_t* get_dm(void) {
    return app.dm;
}

amxo_parser_t* get_parser(void) {
    return app.parser;
}

amxd_object_t* get_root_object(void) {
    return app.root_object;
}

amxd_object_t* get_object(const char* path) {
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(get_dm(), "%s", path);
exit:
    return object;
}

static void filetransfer_event_cb(int fd, UNUSED void* priv) {
    ftx_fd_event_handler(fd);
}

static int filetransfer_fdset_cb(int fd, bool add) {
    int retval = -1;
    if(add) {
        retval = amxo_connection_add(get_parser(), fd, filetransfer_event_cb, NULL, AMXO_LISTEN, NULL);
    } else {
        retval = amxo_connection_remove(get_parser(), fd);
    }
    SAH_TRACEZ_INFO(ME, "%s connection fd %d %s", add ? "add" : "remove", fd, (retval == 0) ? "success" : "failure");
    return retval;
}

static int write_core_pattern(void) {
    int retval = 1;
    int fd = 0;
    amxc_var_t* path = NULL;
    amxc_string_t pattern;

    amxc_string_init(&pattern, 0);
    path = amxo_parser_get_config(get_parser(), "installation_path");

    when_null(path, exit);

    amxc_string_setf(&pattern, "|%s %%p %%s %%t %%P %%e", amxc_var_constcast(cstring_t, path));

    fd = open(PATH_CORE_PATTERN, O_WRONLY | O_TRUNC);
    when_true_trace(fd < 0, exit, ERROR, "Failed to open core pattern file. Error message: %s", strerror(errno));
    if(write(fd, amxc_string_get(&pattern, 0), strlen(amxc_string_get(&pattern, 0))) <= 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to write core pattern. Error message: %s", strerror(errno));
    } else {
        retval = 0;
    }
    close(fd);
exit:
    amxc_string_clean(&pattern);
    return retval;
}


static int init_core_pattern(void) {
    int retval = 1;
    int uid;
    int gid;

    // Switch to root to write core pattern, drop capabilities and goes back to non-root user
    uid = getuid();
    gid = getgid();
    if(uid != 0) {
        retval = capng_get_caps_process();
        when_failed_trace(retval, exit, ERROR, "Failed to get capabilities.");
        retval = capng_change_id(0, 0, CAPNG_DROP_SUPP_GRP);
        when_failed_trace(retval, exit, ERROR, "Failed to set root UID.");
    }

    retval = write_core_pattern();
    if(uid != 0) {
        capng_clear(CAPNG_SELECT_BOTH);
        capng_update(CAPNG_ADD, CAPNG_EFFECTIVE | CAPNG_PERMITTED, CAP_DAC_OVERRIDE);
        retval = capng_change_id(uid, gid, CAPNG_DROP_SUPP_GRP);
        when_failed_trace(retval, exit, ERROR, "Failed to set non-root UID.");
    }

exit:
    return retval;
}

static int init(amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 1;

    app.dm = dm;
    app.parser = parser;
    app.root_object = get_object("ProcessFaults");

    ftx_init(filetransfer_fdset_cb);

    retval = amxc_string_init(&app.object_name, 0);
    retval |= amxc_string_setf(&app.object_name, "%s", ROOT_OBJECT_NAME);
    retval |= ( app.root_object == NULL);

    retval |= init_core_pattern();

    return retval;
}

static int cleanup(void) {
    ftx_clean();
    amxc_string_clean(&app.object_name);
    app.dm = NULL;
    app.parser = NULL;
    return 0;
}

int _faultmonitor_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 0;

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "Starting faultmonitor plugin");
        retval = init(dm, parser);
        break;
    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "Stopping faultmonitor plugin");
        retval = cleanup();
        break;
    }
    return retval;

}
