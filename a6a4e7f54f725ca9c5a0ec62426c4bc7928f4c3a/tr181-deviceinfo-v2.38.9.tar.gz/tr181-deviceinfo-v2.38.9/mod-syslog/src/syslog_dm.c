/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxp/amxp_slot.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "syslog_dm.h"
#include "syslog_events.h"
#include "syslog_helpers.h"
#include "mod_syslog.h"

static bool waiting_for_syslog = false;

static void track_syslog_dm(void) {
    init_syslog_subscriptions();
    populate_deviceinfo_vendorlogfiles();
}

static void wait_done_cb(UNUSED const char* const signal,
                         UNUSED const amxc_var_t* const date,
                         UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "wait:done received");

    amxp_slot_disconnect(NULL, "wait:done", wait_done_cb);
    waiting_for_syslog = false;

    track_syslog_dm();
    SAH_TRACEZ_OUT(ME);
}

void wait_for_syslog(void) {
    SAH_TRACEZ_IN(ME);

    when_false(syslog_sync_needed(), exit);
    when_true(waiting_for_syslog, exit);
    if(amxb_be_who_has(SYSLOG_PATH) != NULL) {
        track_syslog_dm();
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "wait for " SYSLOG_PATH " object");
    amxp_slot_connect(NULL, "wait:done", NULL, wait_done_cb, NULL);
    amxb_wait_for_object(SYSLOG_PATH); // works async
    waiting_for_syslog = true;

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

static const char* syslog_logfile_object_path_to_alias(amxc_var_t* syslog_action_objects, const char* syslog_action_logfile_path) {
    const char* syslog_action_alias = NULL;
    amxc_string_t syslog_action_path;
    amxc_string_init(&syslog_action_path, 0);

    // Transform path to parent action path: Syslog.Action.{i}.LogFile. => Syslog.Action.{i}
    amxc_string_setf(&syslog_action_path, "%s", syslog_action_logfile_path);
    amxc_string_replace(&syslog_action_path, "LogFile.", "", 1);

    syslog_action_alias = GET_CHAR(GET_ARG(syslog_action_objects, amxc_string_get(&syslog_action_path, 0)), "Alias");

    amxc_string_clean(&syslog_action_path);
    return syslog_action_alias;
}

void populate_deviceinfo_vendorlogfiles(void) {
    SAH_TRACEZ_IN(ME);
    int rv = -1;
    amxb_bus_ctx_t* ctx = syslog_ctx();
    amxc_var_t* syslog_action_objects = NULL;
    amxc_var_t data;
    amxc_var_t updated_files;
    amxc_string_t deviceinfo_vendorlogfile_alias;

    amxc_var_init(&data);
    amxc_var_init(&updated_files);
    amxc_string_init(&deviceinfo_vendorlogfile_alias, 0);

    when_false(syslog_sync_needed(), exit);

    // Get existing Syslog.Action.*.Logfile instances
    when_null_trace(ctx, exit, ERROR, "Could not find Syslog bus context");
    rv = amxb_get(ctx, SYSLOG_PATH "Action.*.", INT32_MAX, &data, 5);
    when_failed_trace(rv, exit, ERROR, "amxb_get failed rv=%d", rv);

    syslog_action_objects = amxc_var_get_first(&data);
    when_null_trace(syslog_action_objects, exit, WARNING, "Unexpected data for amxb_get " SYSLOG_PATH "Action.*.");

    // Loop over syslog action logfiles and create a list of htables containing the settings for the new deviceinfo vendorlogfiles
    amxc_htable_for_each(syslog_action_objects_it, amxc_var_constcast(amxc_htable_t, syslog_action_objects)) {
        const char* syslog_action_logfile_path = amxc_htable_it_get_key(syslog_action_objects_it);
        amxc_var_t* syslog_action_logfile_parameters = amxc_var_from_htable_it(syslog_action_objects_it);
        const char* file_path = GET_CHAR(syslog_action_logfile_parameters, "FilePath");
        const char* syslog_action_alias = NULL;

        // For each added Syslog.Action.{i}.LogFile object we also have a Syslog.Action.{i}. object data in the syslog_action_objects.
        // We are only interested in FilePath data which is exclusively in Syslog.Action.{i}.LogFile
        when_str_empty(file_path, continue_loop);

        syslog_action_alias = syslog_logfile_object_path_to_alias(syslog_action_objects, syslog_action_logfile_path);
        when_str_empty_trace(syslog_action_alias, continue_loop, WARNING, "Missing Alias for %s", syslog_action_logfile_path);
        amxc_string_setf(&deviceinfo_vendorlogfile_alias, VENDORLOGFILE_SYSLOG_ALIAS_PREFIX "%s", syslog_action_alias);

        populate_logfile_settings_htable("add", &updated_files, file_path, syslog_action_logfile_path, amxc_string_get(&deviceinfo_vendorlogfile_alias, 0));
continue_loop:
        continue;
    }

    // Update DeviceInfo and Syslog Datamodels
    update_datamodels(&updated_files);
exit:
    amxc_string_clean(&deviceinfo_vendorlogfile_alias);
    amxc_var_clean(&updated_files);
    amxc_var_clean(&data);
    SAH_TRACEZ_OUT(ME);
}

int update_datamodels(amxc_var_t* updated_files) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t ret;
    int rv = -1;

    amxc_var_init(&ret);
    when_false_status(syslog_sync_needed(), exit, rv = 0);

    if(sync_vendorlogfiles_allowed()) {
        rv = amxm_execute_function("self", MOD_CORE, "update-vendorlogfile", updated_files, &ret);
        when_failed_trace(rv, exit, WARNING, "Mod %s, func 'update-vendorlogfile' returned %d", MOD_CORE, rv);
    }

    if(sync_logrotate_allowed()) {
        rv = amxm_execute_function("self", MOD_CORE, "update-logrotate", updated_files, &ret);
        when_failed_trace(rv, exit, WARNING, "Mod %s, func 'update-logrotate' returned %d", MOD_CORE, rv);
    }
exit:
    amxc_var_clean(&ret);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
