#ifndef __TEST_LIST_H__
#define __TEST_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif

int test_setup(void** state);
int test_teardown(void** state);

void test_add_allowed_device(void** state);
void test_change_allowed_device(void** state);
void test_remove_allowed_device(void** state);
void test_add_device(void** state);
void test_change_intf(void** state);
void test_remove_intf(void** state);
void test_remove_device(void** state);

#ifdef __cplusplus
}
#endif

#endif // __TEST_LIST_H__
