/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


/**
 * @file cthulhu_user_role.c
 * @brief User role management implementation for the Cthulhu Capabilities plugin.
 *
 * Implements the user_role_t struct and functions for managing user roles and their capabilities.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <amxc/amxc_llist.h>
#include <lcm/lcm_assert.h>

#include "cthulhu_user_role.h"
#include "cthulhu_capabilities_common.h"

#define ME "capabilities"

static amxc_llist_t user_role_list = { .head = NULL, .tail = NULL };

/**
 * @brief Gets the global list of user roles.
 * @return Pointer to the linked list of user roles.
 */
amxc_llist_t* get_user_role_list(void) {
    return &user_role_list;
}

/**
 * @brief Frees all resources associated with a user role struct.
 * @param role Pointer to the user role to clean.
 */
static void user_role_clean(user_role_t* role) {
    ASSERT_NOT_NULL(role, return );
    free_null(role->name);
    free_null(role->indexed_path);
    free_null(role->named_path);
    amxc_var_clean(&(role->capabilities));
}

/**
 * @brief Deletes a user role and frees its resources.
 * @param role Pointer to the user role pointer to delete.
 * @return 0 on success, non-zero on failure.
 */
int user_role_delete(user_role_t** role) {
    int res = -1;
    ASSERT_NOT_NULL(role, goto exit);
    ASSERT_NOT_NULL(*role, goto exit);
    amxc_llist_it_take(&(*role)->it);
    user_role_clean(*role);
    free(*role);
    *role = NULL;

    res = 0;
exit:
    return res;
}

/**
 * @brief Allocates and initializes a new user role.
 * @param role Pointer to the new user role pointer.
 * @return 0 on success, non-zero on failure.
 */
int user_role_new(user_role_t** role) {
    int res = -1;
    ASSERT_NOT_NULL(role, goto exit);
    when_not_null(*role, exit);

    *role = (user_role_t*) calloc(1, sizeof(user_role_t));
    ASSERT_NOT_NULL(*role, goto exit);
    amxc_llist_append(&user_role_list, &(*role)->it);
    res = 0;

exit:
    return res;
}

/**
 * @brief Adds a user role to the global list.
 * @param role Pointer to the new user role pointer.
 * @param name Name of the user role.
 * @param indexed_path Indexed path in the data model.
 * @param capabilities CSV string of capabilities.
 * @return 0 on success, non-zero on failure.
 */
int user_role_add(user_role_t** role, const char* name, const char* indexed_path, const char* capabilities) {
    int res = -1;
    ASSERT_NOT_NULL(role, goto exit);
    ASSERT_STR_NOT_EMPTY(name, goto exit);
    ASSERT_STR_NOT_EMPTY(indexed_path, goto exit);

    *role = user_role_find_by_name(name);
    if(*role) {
        user_role_clean(*role);
    } else {
        ASSERT_SUCCESS(user_role_new(role), goto exit, "Could not create new user role");
    }

    (*role)->name = strdup(name);
    (*role)->indexed_path = strdup(indexed_path);
    if(asprintf(&((*role)->named_path), "%s[RoleName==\"%s\"]", ROLE_DM, name) < 0) {
        SAH_TRACEZ_ERROR(ME, "Could not create string role->path");
        user_role_delete(role);
        goto exit;
    }
    if(capabilities) {
        const char* reason = NULL;
        if(csv_string_to_list(capabilities, &((*role)->capabilities), &reason)) {
            SAH_TRACEZ_ERROR(ME, "Could not convert string [%s] to list. Error (%s)", capabilities, reason);
            user_role_delete(role);
            goto exit;
        }
    }

    res = 0;
exit:
    return res;
}

/**
 * @brief Finds a user role by its name.
 * @param name Name of the user role.
 * @return Pointer to the user role, or NULL if not found.
 */
user_role_t* user_role_find_by_name(const char* name) {
    user_role_t* role = NULL;
    ASSERT_STR_NOT_EMPTY(name, goto exit);
    amxc_llist_for_each(it, (&user_role_list)) {
        role = amxc_llist_it_get_data(it, user_role_t, it);
        if(strcmp(role->name, name) == 0) {
            break;
        }
        role = NULL;
    }
exit:
    return role;
}

/**
 * @brief Finds a user role by its indexed path.
 * @param indexed_path Indexed path in the data model.
 * @return Pointer to the user role, or NULL if not found.
 */
user_role_t* user_role_find_by_indexed_path(const char* indexed_path) {
    user_role_t* role = NULL;
    ASSERT_STR_NOT_EMPTY(indexed_path, goto exit);
    amxc_llist_for_each(it, (&user_role_list)) {
        role = amxc_llist_it_get_data(it, user_role_t, it);
        if(strcmp(role->indexed_path, indexed_path) == 0) {
            break;
        }
        role = NULL;
    }
exit:
    return role;
}

/**
 * @brief Helper to free a user role from a linked list iterator.
 * @param it Linked list iterator pointing to a user role.
 */
static void role_list_it_free(amxc_llist_it_t* it) {
    user_role_t* role = amxc_llist_it_get_data(it, user_role_t, it);
    user_role_delete(&role);
}

/**
 * @brief Cleans the global user role list and frees all resources.
 */
void user_role_list_clean(void) {
    amxc_llist_clean(&user_role_list, role_list_it_free);
}

/**
 * @brief Adds a role to the provided name and path lists.
 * @param role Name of the role to add.
 * @param role_name_list List to append the role name to.
 * @param role_path_list List to append the role path to.
 * @return 0 on success, non-zero on failure.
 */
int add_role_to_list(const char* role, amxc_var_t* role_name_list, amxc_var_t* role_path_list) {
    int res = -1;

    user_role_t* user_role = user_role_find_by_name(role);
    ASSERT_NOT_NULL(user_role, goto exit, "User role [%s] does not exist or is disabled.", role);
    ASSERT_NOT_NULL(amxc_var_add_new_cstring_t(role_name_list, user_role->name), goto exit,
                    "Failed to add name for user role [%s:%s]", role, user_role->name);
    ASSERT_NOT_NULL(amxc_var_add_new_cstring_t(role_path_list, user_role->named_path), goto exit,
                    "Failed to add path for user role [%s:%s]", role, user_role->named_path);
    res = 0;
exit:
    return res;
}