/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "homeplug.h"

#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/if_packet.h>
#include <net/if.h>
#include <fcntl.h>
#include <unistd.h>


#define FRAME_SIZE_MAX (1518 - ETHER_HDR_LEN)
#define ETHERTYPE_HOMEPLUG_AV 0x88e1

/**
   @brief Receives a raw frame from a socket.

   Reads a frame from the specified raw socket into the provided buffer
   and stores the sender's link-layer address.

   @param socket_fd      File descriptor of the raw socket to read from.
   @param frame          Pointer to the buffer where the received frame will be stored.
   @param maxframelen    Maximum number of bytes that can be written to the buffer.
   @param address        Pointer to a sockaddr_ll structure to store the source address.
   @param framelength    Pointer to a variable to store the actual length of the received frame.

   @return true if a valid frame was successfully received and is not outgoing; false otherwise.
 */
static bool get_frame(int socket_fd, uint8_t* frame, ssize_t maxframelen, struct sockaddr_ll* address, ssize_t* framelength) {
    ssize_t rdlen = -1;
    bool retval = false;
    socklen_t addrlen = sizeof(struct sockaddr_ll);

    SAH_TRACEZ_INFO(ME, "get frame");
    when_null_trace(frame, exit, ERROR, "frame is a NULL pointer");
    when_null_trace(address, exit, ERROR, "address is a NULL pointer");
    when_null_trace(framelength, exit, ERROR, "framelength is a NULL pointer");
    when_false_trace((socket_fd >= 0), exit, ERROR, "socket fd <0");

    memset(address, 0, addrlen);

    /* read responses */
    rdlen = recvfrom(socket_fd, frame, maxframelen, MSG_TRUNC, (struct sockaddr*) address, &addrlen);
    if(rdlen == -1) {
        switch(errno) {
        case EAGAIN:
            SAH_TRACEZ_ERROR(ME, "No more data available (%d)", errno);
            goto exit;
            break;
        default:
            SAH_TRACEZ_ERROR(ME, "Failed to read data (%d)", errno);
            retval = false;
            goto exit;
            break;
        }
    }
    when_false_trace(rdlen <= maxframelen, exit, INFO,
                     "received jumbo frame of %zd bytes len, truncated", rdlen);
    when_false_trace(address->sll_pkttype != PACKET_OUTGOING, exit,
                     INFO, "Received outgoing frame, do not handle these");

    retval = true;

exit:

    if(framelength) {
        *framelength = rdlen;
    }
    return retval;
}

void homeplug_socket_read_socket_cb(int socket_fd, void* priv) {
    uint8_t frame[FRAME_SIZE_MAX];
    struct sockaddr_ll address;
    ssize_t frame_length = 0;
    SAH_TRACEZ_INFO(ME, "read socket cb");
    when_null_trace(priv, exit, ERROR, "priv is a NULL pointer");
    homeplug_socket_t* sock = (homeplug_socket_t*) priv;
    if(get_frame(socket_fd, frame, FRAME_SIZE_MAX, &address, &frame_length)) {
        SAH_TRACEZ_INFO(ME, "rcvd frame length: %d", (int) frame_length);
        if(address.sll_protocol == htons(ETHERTYPE_HOMEPLUG_AV)) {
            SAH_TRACEZ_INFO(ME, "correct protocol identified, handle homeplug rcvd msg");
            homeplug_av_protocol_handle_rcvd_msg(sock, frame, frame_length, (uint8_t*) &address.sll_addr);
        }
    }
exit:
    return;
}

homeplug_socket_t* homeplug_socket_new(const char* dev_name) {

    int ret = -1;
    int flags = 0;
    int i = 0;
    struct ifreq ifr;
    homeplug_socket_t* sock = NULL;

    when_str_empty_trace(dev_name, error, ERROR, "empty dev_name");
    SAH_TRACEZ_INFO(ME, "Create new socket on interface: %s", dev_name);

    memset(&ifr, 0, sizeof(struct ifreq));

    sock = calloc(1, sizeof(homeplug_socket_t));
    when_null_trace(sock, error, ERROR, "Out of mem");
    sock->socket_fd = -1;

    sock->addr = (struct sockaddr_ll*) calloc(1, sizeof(struct sockaddr_ll) + 4);
    when_null_trace(sock->addr, error, ERROR, "Out of mem");

    sock->socket_fd = socket(PF_PACKET, SOCK_DGRAM, htons(ETHERTYPE_HOMEPLUG_AV));
    when_false_trace(sock->socket_fd != -1, error, ERROR, "Failed to create socket: %d %s", errno, strerror(errno));

    if(dev_name && *dev_name) {
        /* Bind to interface */
        strncpy(ifr.ifr_name, dev_name, IFNAMSIZ - 1);
        ret = ioctl(sock->socket_fd, SIOCGIFINDEX, &ifr);
        when_false_trace(ret != -1, error, ERROR, "Failed to get interface index for name %s: %d %s", dev_name, errno, strerror(errno));
        sock->devname = strdup(dev_name);
        when_null_trace(sock->devname, error, ERROR, "Out of Mem");
    }
    sock->addr->sll_family = AF_PACKET;
    sock->addr->sll_protocol = htons(ETHERTYPE_HOMEPLUG_AV);
    sock->addr->sll_ifindex = ifr.ifr_ifindex;
    ret = bind(sock->socket_fd, (struct sockaddr*) sock->addr, sizeof(struct sockaddr_ll));
    when_false_trace(ret != -1, error, ERROR, "Failed to bind: %d %s", errno, strerror(errno));

    sock->addr->sll_halen = 8;
    for(i = 0; i < 8; i++) {
        sock->addr->sll_addr[i] = 0xFF;
    }

    // set non-blocking
    flags = fcntl(sock->socket_fd, F_GETFL, 0);
    when_false_trace(flags >= 0, error, ERROR, "socket fnctl F_GETFL failed: %d %s", errno, strerror(errno));
    ret = fcntl(sock->socket_fd, F_SETFL, flags | O_NONBLOCK);
    when_false_trace(ret >= 0, error, ERROR, "socket fnctl F_SETFL failed %d %s", errno, strerror(errno));

    ret = amxo_connection_add(homeplug_get_parser(), sock->socket_fd, homeplug_socket_read_socket_cb, NULL, AMXO_CUSTOM, sock);
    when_failed_trace(ret, error, ERROR, "amxo_connection_add() failed %d", ret);
    return sock;

error:
    homeplug_socket_delete(sock);
    return NULL;
}

void homeplug_socket_delete(homeplug_socket_t* sock) {
    SAH_TRACEZ_INFO(ME, "socket delete");
    when_null_trace(sock, exit, ERROR, "sock is NULL pointer");
    amxo_connection_remove(homeplug_get_parser(), sock->socket_fd);
    close(sock->socket_fd);
    free(sock->addr);
    free(sock->devname);
    free(sock);
exit:
    return;
}

void homeplug_socket_send_associated_devices_request(homeplug_socket_t* sock, const uint8_t addr[8]) {

    size_t messagesize = 0;
    bool ret = false;

    uint8_t* message = NULL;
    SAH_TRACEZ_INFO(ME, "send associated device request");
    when_null_trace(sock, exit, ERROR, "sock is NULL pointer");
    message = homeplug_av_protocol_create_cm_nw_stats_req(&messagesize);
    when_null_trace(message, exit, ERROR, "Can not create_cm_nw_stats_req");
    ret = homeplug_socket_send_request(sock, addr, message, messagesize);
    when_false_trace(ret, exit, ERROR, "Failed to send create_cm_nw_stats_req message on interface %s", sock->devname);

    free(message);

    message = homeplug_av_protocol_create_vs_nw_info_req(&messagesize);
    when_null_trace(message, exit, ERROR, "Can not create vs_nw_info_req");
    ret = homeplug_socket_send_request(sock, addr, message, messagesize);
    when_false_trace(ret, exit, ERROR, "Failed to send vs_nw_info_req  message on interface %s", sock->devname);

    free(message);

    message = homeplug_av_protocol_create_cm_hfid_req(0, NULL, 0, NULL, 0, &messagesize);
    when_null_trace(message, exit, ERROR, "Can not create cm_hfid_info_req");
    ret = homeplug_socket_send_request(sock, addr, message, messagesize);
    when_false_trace(ret, exit, ERROR, "Failed to send cm_hfid_info_req  message on interface %s", sock->devname);

exit:
    free(message);
}

void homeplug_socket_send_discovery_request(homeplug_socket_t* sock) {
    size_t messagesize = 0;
    bool ret = false;
    uint8_t broadcast_addr[8] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00};
    uint8_t* message = NULL;
    SAH_TRACEZ_INFO(ME, "socket send discovery request");
    when_null_trace(sock, exit, ERROR, "sock is NULL pointer");
    message = homeplug_av_protocol_create_cm_brg_info_req(&messagesize);
    when_null_trace(message, exit, ERROR, "Can not allocate cm brg info req");
    ret = homeplug_socket_send_request(sock, broadcast_addr, message, messagesize);
    when_false_trace(ret, exit, ERROR, "Failed to send homeplug av broadcast discovery request message on interface %s", sock->devname);
exit:
    free(message);
}

