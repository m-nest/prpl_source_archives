/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <fcntl.h>
#include <yajl/yajl_gen.h>
#include <amxc/amxc.h>
#include <amxj/amxj_variant.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include "trcr_unit_test.h"
#include "ip_diagnostics.h"
#include "mod_ipd_trcr_common.h"
#include "mod_ipd_trcr.h"
#include "mod_ipd_common.h"

void test_trcr_find_interface_ipv4(UNUSED void** state) {
    amxc_string_t line;
    amxc_string_init(&line, 0);
    char* interface_ip = NULL;
    char* test_ip = NULL;

    test_ip = mod_ipd_find_interface_ip_address("172.217.168.238");
    amxc_string_setf(&line, "traceroute to google.com (172.217.168.238), 30 hops max, 46 byte packets");
    interface_ip = trcr_find_ip_address_used(&line);
    assert_string_equal(interface_ip, test_ip);

    free(interface_ip);
    free(test_ip);
    amxc_string_clean(&line);
}

void test_trcr_find_interface_ipv6(UNUSED void** state) {
    amxc_string_t line;
    amxc_string_init(&line, 0);
    char* interface_ip = NULL;
    char* test_ip = NULL;

    test_ip = mod_ipd_find_interface_ip_address("2a00:1450:400e:801::200e");

    amxc_string_setf(&line, "traceroute to google.com(2a00:1450:400e:801::200e) , 30 hops max, 80 byte packets");
    interface_ip = trcr_find_ip_address_used(&line);
    assert_string_equal(interface_ip, test_ip);

    free(interface_ip);
    free(test_ip);
    amxc_string_clean(&line);
}

static void test_trcr_script_array_it_free(amxc_array_it_t* it) {
    free(it->data);
}

void test_trcr_datablocksize_min(UNUSED void** state) {
    amxc_var_t param;
    amxc_array_t cmd_argv;

    amxc_var_init(&param);
    amxc_array_init(&cmd_argv, 1);
    amxc_var_set(jstring_t, &param, "{\"ProtocolVersion\":\"IPv4\",\"NumberOfTries\":1,\"Timeout\":5000,\"MaxHopCount\":10,\"Host\":\"127.0.0.1\",\"DataBlockSize\":18}");
    amxc_var_cast(&param, AMXC_VAR_ID_ANY);

    assert_int_equal(trcr_create_command(&param, &cmd_argv), 0);

    assert_int_not_equal(atoi(amxc_array_it_get_data(amxc_array_get_last(&cmd_argv))), 18);

    amxc_array_clean(&cmd_argv, test_trcr_script_array_it_free);
    amxc_var_clean(&param);
}