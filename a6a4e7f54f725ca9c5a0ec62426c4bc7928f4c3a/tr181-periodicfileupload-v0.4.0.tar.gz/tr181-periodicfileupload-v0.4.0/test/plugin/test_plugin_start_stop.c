/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_sahtrace.h>

#include "test_plugin_start_stop.h"
#include "tr181-periodicfileupload.h"

int test_setup(UNUSED void** state) {
    amxut_bus_setup(state);

    amxo_parser_parse_string(amxut_bus_parser(), "%config{import-dirs=[\"../output/x86_64-linux-gnu/\",\"/usr/lib/amx/modules\"];include-dirs=[\".\"];}import \"mod-dmext.so\";", amxd_dm_get_root(amxut_bus_dm()));
    amxo_resolver_ftab_add(amxut_bus_parser(), "app_start", AMXO_FUNC(_app_start));
    amxo_resolver_ftab_add(amxut_bus_parser(), "ForceTransfer", AMXO_FUNC(_ForceTransfer));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_filetransfer_enable", AMXO_FUNC(_dm_filetransfer_enable));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_transfer_destroyed", AMXO_FUNC(_dm_transfer_destroyed));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_transfer_added", AMXO_FUNC(_dm_transfer_added));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_transfer_changed", AMXO_FUNC(_dm_transfer_changed));
    amxo_resolver_ftab_add(amxut_bus_parser(), "dm_transfer_status_done", AMXO_FUNC(_dm_transfer_status_done));

    amxut_dm_load_odl("../../odl/tr181-periodicfileupload_definition.odl");
    amxut_dm_load_odl("../../odl/tr181-periodicfileupload_transfer_definition.odl");
    amxut_dm_load_odl("profile.odl");  // Create profile
    amxut_dm_load_odl("transfer.odl"); // Create transfer

    assert_int_equal(_main(0, amxut_bus_dm(), amxut_bus_parser()), 0);
    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_main(1, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);
    return 0;
}

void test_can_start_plugin(UNUSED void** state) {
    amxp_sigmngr_emit_signal(&amxut_bus_dm()->sigmngr, "app:start", NULL);
    amxut_bus_handle_events();
}

void test_can_stop_plugin(UNUSED void** state) {
    amxp_sigmngr_emit_signal(&amxut_bus_dm()->sigmngr, "app:stop", NULL);
}

static void _test_forcetransfer_cb(UNUSED const amxc_var_t* const data, UNUSED void* const priv) {
    amxd_object_t* transfer = (amxd_object_t*) priv;
    free(transfer->priv);
    transfer->priv = NULL;
}

void test_profile_compression(UNUSED void** state) {
    amxd_object_t* transfer = amxd_dm_findf(amxut_bus_dm(), "PeriodicFileTransfer.Transfer.compression_test.");
    amxd_object_t* profile = NULL;
    amxc_string_t cleaned_path;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_string_init(&cleaned_path, 0);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    assert_non_null(transfer);
    amxc_string_setf(&cleaned_path, "%s", GET_CHAR(amxd_object_get_param_value(transfer, "ProfileReference"), NULL));
    amxc_string_replace(&cleaned_path, "Device.", "", 1);
    profile = amxd_dm_findf(amxut_bus_dm(), "%s.HTTP.", amxc_string_get(&cleaned_path, 0));
    assert_non_null(profile);
    assert_string_equal(GET_CHAR(amxd_object_get_param_value(profile, "Compression"), NULL), "GZIP");
    assert_int_equal(amxd_object_invoke_function(transfer, "ForceTransfer", &args, &ret), amxd_status_deferred);
    amxd_function_set_deferred_cb(amxc_var_get_uint64_t(&ret), _test_forcetransfer_cb, transfer);
    amxut_bus_handle_events();
    amxc_string_clean(&cleaned_path);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}