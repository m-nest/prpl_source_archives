/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "sfp_ethdata.h"

/* System headers */
#include <errno.h>
#include <stdio.h>  /* popen() */
#include <string.h> /* strerror() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h>

/* Own headers */
#include "sfpmgr_trace.h"

/**
 * Wrapper around fgets(): it replaces a '\n' with '\0'.
 *
 * The parameters have the same meaning as the parameters of fgets().
 *
 * Reason for this wrapper: fgets() also reads in a newline. Developers rarely
 * want that. We also don't want it here. This wrapper function replaces the
 * newline with '\0' if there is one.
 *
 * @return true if fgets() succeeds, i.e. does not return NULL
 * @return false if fgets() returns NULL. fgets() returns NULL on error or when
 *         end of file occurs while no characters have been read.
 */
static bool fgets_wrapper(char* buf, int size, FILE* file) {
    if(!fgets(buf, size, file)) {
        return false;
    }
    char* const newline = strchr(buf, '\n');
    if(newline) {
        *newline = '\0';
    }
    return true;
}

/**
 * Remove leading and trailing white spaces.
 *
 * @param[in] input: string to be trimmed
 * @param[in,out] output: trimmed string
 */
static void trim_string(const char* input, amxc_string_t* output) {

    amxc_string_setf(output, "%s", input);
    amxc_string_trim(output, /*amxc_string_is_char_fn_t=*/ NULL);
}

/**
 * Retrieve the SFP data.
 *
 * @param[in] command: command to get the SFP data. This is normally an
 *     "ethtool -m devname" command to dump the EEPROM of the SFP. When running
 *      the unit tests, it's normally a 'cat' command to print the contents of a
 *      file with example output of such an ethtool command.
 * @param[in,out] table: the caller must pass an hash table. The function parses
 *      the output of @a command: it splits each line in 2  parts using ":" as
 *      delimiter, and adds them as a key-value pair to @a htable.
 *
 * @return true on success, else false
 */
bool retrieve_sfp_data(const char* command, amxc_var_t* table) {

    bool rv = false;
#define MAX_LINE_LENGTH 1024
    char ethtool_output[MAX_LINE_LENGTH] = {0};
    FILE* fp = NULL;
    char* key;
    char* value;
    amxc_string_t key_trimmed;
    amxc_string_t value_trimmed;
    const char* key_trimmed_cstr;
    const char* value_trimmed_cstr;
    amxc_var_t* v;

    amxc_string_init(&key_trimmed, 0);
    amxc_string_init(&value_trimmed, 0);

    when_false_trace(amxc_var_type_of(table) == AMXC_VAR_ID_HTABLE, exit, ERROR,
                     "Arg for 'table' is not an htable");

    SAH_TRACEZ_INFO(ME, "command='%s'", command);
    fp = popen(command, "r");
    when_null_trace(fp, exit, ERROR, "popen() failed: %s", strerror(errno));

    /* update info */
    while(fgets_wrapper(ethtool_output, sizeof(ethtool_output), fp)) {
        key = strtok(ethtool_output, ":");
        when_null(key, end_of_loop);
        value = strtok(NULL, "");
        when_null(value, end_of_loop);

        trim_string(key, &key_trimmed);
        key_trimmed_cstr = amxc_string_get(&key_trimmed, 0);

        when_true(strcmp(key_trimmed_cstr, "Option") == 0, end_of_loop);

        trim_string(value, &value_trimmed);
        value_trimmed_cstr = amxc_string_get(&value_trimmed, 0);

        SAH_TRACEZ_INFO(ME, "key='%s' value='%s'", key_trimmed_cstr, value_trimmed_cstr);
        v = amxc_var_add_key(cstring_t, table, key_trimmed_cstr, value_trimmed_cstr);
        when_null_trace(v, end_of_loop, ERROR, "Failed to add key='%s'", key_trimmed_cstr);
end_of_loop:
        continue;
    }
    rv = true;
exit:
    if(fp) {
        pclose(fp);
    }
    amxc_string_clean(&key_trimmed);
    amxc_string_clean(&value_trimmed);

    return rv;
}

