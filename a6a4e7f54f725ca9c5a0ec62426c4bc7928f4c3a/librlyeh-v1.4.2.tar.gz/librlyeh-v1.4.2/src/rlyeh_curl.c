/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include <rlyeh_priv.h>
#include <debug/sahtrace.h>

#include <rlyeh/rlyeh_curl.h>
#include <rlyeh/rlyeh_status.h>
#include <rlyeh/rlyeh_utils.h>
#include <lcm/lcm_assert.h>

#include <lcm/lcm_assert.h>

#define ME "rlyeh_copy"

static CURL* curl = NULL;

static inline int apply_curl_certificate_verification(bool enable) {
    if(enable) {
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    } else {
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    }
    return 0;
}

static size_t write_curl_call_back_in_char(void* data, size_t size, size_t nmemb, void* ctx) {
    static size_t sz = 0;
    size_t currsz = size * nmemb;

    // Reset sz between two Rlyeh.pull()
    if(*(char**) ctx == NULL) {
        sz = 0;
    }

    size_t prevsz = sz;
    sz += currsz;
    void* tmp = realloc(*(char**) ctx, sz);
    if(tmp == NULL) {
        // handle error
        free(*(char**) ctx);
        *(char**) ctx = NULL;
        return 0;
    }
    *(char**) ctx = (char*) tmp;

    // The last line of the token causes memory leaks. Its original content is "\r\n\0"
    // Overwritting the last line to "/0" solves the problem.
    if(strcmp((char*) data, "\r\n\0") == 0) {
        memcpy(*(char**) ctx + prevsz, (char*) data + 2, currsz);
    } else {
        memcpy(*(char**) ctx + prevsz, data, currsz);
    }
    return currsz;
}

static size_t write_curl_call_back_in_file(void* contents, size_t size, size_t nmemb, void* userp) {
    FILE* fd = (FILE*) userp;
    size_t ret = fwrite(contents, size, nmemb, fd);
    if(ret < (size * nmemb)) {
        SAH_TRACEZ_ERROR(ME, "Cannot write to file (%d) : %s", errno, strerror(errno));
    }

    return ret;
}

static rlyeh_status_t map_curlcode_to_rlyehstatus(CURLcode value) {
    rlyeh_status_t status = RLYEH_NO_ERROR;
    switch(value) {
    case CURLE_OK:
        status = RLYEH_NO_ERROR;
        break;
    case CURLE_OPERATION_TIMEDOUT:
        status = RLYEH_ERROR_CURL_OPERATION_TIMEDOUT;
        break;
    case CURLE_COULDNT_RESOLVE_HOST:
        status = RLYEH_ERROR_CURL_COULDNT_RESOLVE_HOST;
        break;
    case CURLE_WRITE_ERROR:
        status = RLYEH_ERROR_DISK_SPACE;
        break;
    case CURLE_SSL_CERTPROBLEM:
    case CURLE_PEER_FAILED_VERIFICATION:
        status = RLYEH_ERROR_CERTIFICATE_CHECK_FAILED;
        break;
    default:
        status = RLYEH_ERROR_DOWNLOAD_FAILED;
        break;
    }
    return status;
}

rlyeh_status_t rlyeh_curl_download_content(const rlyeh_curl_parameters_t* parameters, const amxc_string_t* url, void* data, curl_off_t* size, char* err_msg) {
    CURLcode res = CURLE_OK;
    struct curl_slist* list = NULL;
    rlyeh_status_t status = RLYEH_NO_ERROR;
    char curl_err_str[CURL_ERROR_SIZE] = {0};
    amxc_string_t opt_token;
    const char* destination = amxc_string_get(url, 0);

    ASSERT_STR_NOT_EMPTY(destination, return RLYEH_ERROR_INVALID_ARGUMENTS,
                         "Can't use an empty URL");

    if(!curl) {
        SAH_TRACEZ_ERROR(ME, "Call rlyeh_curl_init before calling this function");
        return RLYEH_ERROR_UNKNOWN_ERROR;
    }
    curl_easy_reset(curl);

    if(parameters->type == FILE_TYPE_MANIFEST) {
        list = curl_slist_append(list, "Accept: application/vnd.oci.image.manifest.v1+json");
        list = curl_slist_append(list, "Accept: application/vnd.docker.distribution.manifest.v2+json");
    }

    switch(parameters->auth_type) {
    case BASIC_AUTHENTICATION:
        curl_easy_setopt(curl, CURLOPT_USERNAME, parameters->username);
        curl_easy_setopt(curl, CURLOPT_PASSWORD, parameters->password);
        break;
    case BEARER_AUTHENTICATION:
        amxc_string_init(&opt_token, 0);
        amxc_string_setf(&opt_token, "Authorization: Bearer %s", parameters->token);
        list = curl_slist_append(list, opt_token.buffer);
        amxc_string_clean(&opt_token);
        break;
    case NO_AUTHENTICATION:
    default:
        SAH_TRACEZ_WARNING(ME, "Downloading with NO_AUTHENTICATION");
        break;
    }

    curl_easy_setopt(curl, CURLOPT_URL, destination);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, data);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, (void*) write_curl_call_back_in_file);
    // follow redirection
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    /* abort if slower than 30 bytes/sec during 10 seconds */
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 30L);

    curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_err_str);

    apply_curl_certificate_verification(parameters->cv);

    SAH_TRACEZ_INFO(ME, "curl_easy_perform url: %s", destination);
    res = curl_easy_perform(curl);
    switch(res) {
    case CURLE_OK:
        curl_easy_getinfo(curl, CURLINFO_SIZE_DOWNLOAD_T, size);
        break;
    case CURLE_WRITE_ERROR:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s] - cannot write to file - disk full?", curl_err_str, destination);
        break;
    default:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s]", curl_err_str, destination);
        break;
    }
    status = map_curlcode_to_rlyehstatus(res);

    curl_slist_free_all(list);

    return status;
}

rlyeh_status_t rlyeh_curl_head(const rlyeh_curl_parameters_t* parameters, const amxc_string_t* url, void* data, curl_off_t* size, char* err_msg) {
    CURLcode res = CURLE_OK;
    struct curl_slist* list = NULL;
    rlyeh_status_t status = RLYEH_NO_ERROR;
    char curl_err_str[CURL_ERROR_SIZE] = {0};
    amxc_string_t opt_token;
    const char* destination = amxc_string_get(url, 0);

    ASSERT_STR_NOT_EMPTY(destination, return RLYEH_ERROR_INVALID_ARGUMENTS,
                         "Can't use an empty URL");

    if(!curl) {
        SAH_TRACEZ_ERROR(ME, "Call rlyeh_curl_init before calling this function");
        return RLYEH_ERROR_UNKNOWN_ERROR;
    }
    curl_easy_reset(curl);

    if(parameters->type == FILE_TYPE_MANIFEST) {
        list = curl_slist_append(list, "Accept: application/vnd.oci.image.manifest.v1+json");
        list = curl_slist_append(list, "Accept: application/vnd.docker.distribution.manifest.v2+json");
    }


    switch(parameters->auth_type) {
    case BASIC_AUTHENTICATION:
        curl_easy_setopt(curl, CURLOPT_USERNAME, parameters->username);
        curl_easy_setopt(curl, CURLOPT_PASSWORD, parameters->password);
        break;
    case BEARER_AUTHENTICATION:
        amxc_string_init(&opt_token, 0);
        amxc_string_setf(&opt_token, "Authorization: Bearer %s", parameters->token);
        list = curl_slist_append(list, opt_token.buffer);
        amxc_string_clean(&opt_token);
        break;
    case NO_AUTHENTICATION:
    default:
        break;
    }

    curl_easy_setopt(curl, CURLOPT_URL, destination);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
    curl_easy_setopt(curl, CURLOPT_HEADER, 1L);
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, data);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, (void*) write_curl_call_back_in_file);
    // follow redirection
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    /* abort if slower than 30 bytes/sec during 10 seconds */
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 30L);

    curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_err_str);

    apply_curl_certificate_verification(parameters->cv);

    SAH_TRACEZ_INFO(ME, "curl_easy_perform url: [%s]", destination);
    // fprintf(stderr, "curl_easy_perform url: [%s]", destination);
    res = curl_easy_perform(curl);
    switch(res) {
    case CURLE_OK:
        curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD_T, size);
        break;
    case CURLE_WRITE_ERROR:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s] - cannot write to file - disk full?", curl_err_str, destination);
        break;
    default:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s]", curl_err_str, destination);
        break;
    }
    status = map_curlcode_to_rlyehstatus(res);


    curl_slist_free_all(list);

    return status;
}

rlyeh_status_t rlyeh_curl_get_httpauthentication(const amxc_string_t* url, void* buf, long* auth, char* err_msg, bool cv) {
    CURLcode res = CURLE_OK;
    rlyeh_status_t status = RLYEH_NO_ERROR;
    char curl_err_str[CURL_ERROR_SIZE] = {0};
    const char* destination = amxc_string_get(url, 0);

    ASSERT_STR_NOT_EMPTY(destination, return RLYEH_ERROR_INVALID_ARGUMENTS,
                         "Can't use an empty URL");

    if(!curl) {
        SAH_TRACEZ_ERROR(ME, "Call rlyeh_curl_init before calling this function");
        return RLYEH_ERROR_UNKNOWN_ERROR;
    }
    curl_easy_reset(curl);

    curl_easy_setopt(curl, CURLOPT_URL, destination);
    curl_easy_setopt(curl, CURLOPT_HEADER, 1L);
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, buf);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, (void*) write_curl_call_back_in_char);
    // follow redirection
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    /* abort if slower than 30 bytes/sec during 10 seconds */
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 30L);
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_err_str);
    apply_curl_certificate_verification(cv);

    SAH_TRACEZ_INFO(ME, "curl_easy_perform url: [%s]", destination);
    res = curl_easy_perform(curl);
    switch(res) {
    case CURLE_OK:
        curl_easy_getinfo(curl, CURLINFO_HTTPAUTH_AVAIL, auth);
        break;
    case CURLE_WRITE_ERROR:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s] - cannot write to file - disk full?", curl_err_str, destination);
        break;
    default:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s]", curl_err_str, destination);
        break;
    }

    status = map_curlcode_to_rlyehstatus(res);

    return status;
}

rlyeh_status_t rlyeh_curl_get(const amxc_string_t* url, rlyeh_image_parameters_t* src, void* data, char* err_msg, bool cv) {
    CURLcode res = CURLE_OK;
    rlyeh_status_t status = RLYEH_NO_ERROR;
    char curl_err_str[CURL_ERROR_SIZE] = {0};
    const char* destination = amxc_string_get(url, 0);

    ASSERT_STR_NOT_EMPTY(destination, return RLYEH_ERROR_INVALID_ARGUMENTS,
                         "Can't use an empty URL");

    if(!curl) {
        SAH_TRACEZ_ERROR(ME, "Call rlyeh_curl_init before calling this function");
        return RLYEH_ERROR_UNKNOWN_ERROR;
    }
    curl_easy_reset(curl);

    if(!STRING_EMPTY(src->username)) {
        curl_easy_setopt(curl, CURLOPT_USERNAME, src->username);
    }

    if(!STRING_EMPTY(src->password)) {
        curl_easy_setopt(curl, CURLOPT_PASSWORD, src->password);
    }

    curl_easy_setopt(curl, CURLOPT_URL, destination);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, data);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, (void*) write_curl_call_back_in_file);
    // follow redirection
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    /* abort if slower than 30 bytes/sec during 10 seconds */
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 30L);
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_err_str);
    curl_easy_setopt(curl, CURLOPT_FAILONERROR, 1L);

    apply_curl_certificate_verification(cv);

    SAH_TRACEZ_INFO(ME, "curl_easy_perform url: [%s]", destination);
    res = curl_easy_perform(curl);
    switch(res) {
    case CURLE_WRITE_ERROR:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s] - cannot write to file - disk full?", curl_err_str, destination);
        break;
    default:
        set_err_msg(err_msg, "Curl download content error [%s] URL [%s]", curl_err_str, destination);
        break;
    }
    status = map_curlcode_to_rlyehstatus(res);

    return status;
}

int rlyeh_curl_init(void) {
    if(curl) {
        SAH_TRACEZ_INFO(ME, "CURL is already initialized");
        return 0;
    }
    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();
    return 0;
}

void rlyeh_curl_cleanup(void) {
    if(curl) {
        curl_easy_cleanup(curl);
        curl_global_cleanup();
    }
    curl = NULL;
}

/**
 * Splits the given path into a base path and a version string.
 */
static bool split_path(const char* path, char** version) {
    ASSERT_STR_NOT_EMPTY_NL(path, return false);
    char* pos = strchr(path, ':');
    if(pos != NULL) {
        *version = strdup(pos + 1);
        *pos = '\0';
        return true;
    }
    return false;
}

static void clear_uri_data(rlyeh_image_parameters_t* image_params) {
    ASSERT_NOT_NULL(image_params, return );

    free_null(image_params->image_dir);
    free_null(image_params->image_name);
    free_null(image_params->transport);
    free_null(image_params->version);
    free_null(image_params->server);
}

static int valid_scheme(const char* scheme) {
    ASSERT_STR_NOT_EMPTY_NL(scheme, return false);

    const char* valid_schemes[] = {"oci", "docker", "https"};
    for(size_t i = 0; i < sizeof(valid_schemes) / sizeof(valid_schemes[0]); ++i) {
        if(!strcmp(scheme, valid_schemes[i])) {
            return true;
        }
    }
    SAH_TRACEZ_ERROR(ME, "Scheme [%s] is not known or supported", scheme);
    return false;
}

static int local_scheme(const char* scheme) {
    CHECK_STR_EMPTY_LOG(INFO, scheme, return false, "Scheme is empty");
    return !strcmp(scheme, "oci"); // Local scheme is "oci"
}

static inline bool is_fqdn(const char* host) {
    ASSERT_STR_NOT_EMPTY(host, return false);
    return strchr(host, '.') ? true : false;
}

/*
 * Parses OCI image URIs supported by rlyeh.
 *
 * Supported URI formats:
 * 1. Remote URIs: transport://hostname[:port]/[image_path][:version]
 *    - 'transport' must be one of the schemes defined in valid_scheme (e.g., "docker", "https")
 *    - 'hostname' is the remote server hosting the OCI image.
 *      - If 'hostname' is not a FQDN, it is treated as part of the image path,
 *        and the hostname is guessed from the configuration (registry-auth.json).
 *    - 'port' is optional; defaults to HTTPS port if not specified.
 *    - 'image_path' is optional.
 *    - 'version' is optional; defaults to "latest".
 *
 * 2. Local URIs: transport://image_directory_path[:version]
 *    - 'transport' is defined by the local_scheme function (e.g., "oci").
 *    - 'image_directory_path' points to the local directory containing the OCI image.
 *    - 'version' is optional; defaults to "latest".
 */
rlyeh_error_t rlyeh_curl_parse_uri(const char* uri, rlyeh_image_parameters_t* image_params) {
    CURLU* curlu = NULL;
    rlyeh_error_t ret = RLYEH_INVALID_SOURCE_OR_DESTINATION;
    char* scheme = NULL;
    char* host = NULL;
    char* port = NULL;
    char* path = NULL;
    char* original_path = NULL;
    char* version = NULL;
    amxc_string_t image_path;

    ASSERT_NOT_NULL(image_params, return RLYEH_INVALID_INPUT_PARAMETER, "image_params is NULL");
    ASSERT_NOT_NULL(curl, return RLYEH_INVALID_INPUT_PARAMETER, "Libcurl is not initialized");
    ASSERT_STR_NOT_EMPTY(uri, return RLYEH_INVALID_INPUT_PARAMETER);

    // clear data to be added by the current parsing function
    clear_uri_data(image_params);
    amxc_string_init(&image_path, 0);

    curlu = curl_url();
    if(curl && curlu) {
        CURLUcode rc = curl_url_set(curlu, CURLUPART_URL, uri, CURLU_NON_SUPPORT_SCHEME);
        CHECK_NOT_EQUAL_LOG(ERROR, rc, CURLUE_OK, goto end,
                            "Provided URI is invalid: [%s]", uri);

        // Extract scheme and host
        curl_url_get(curlu, CURLUPART_HOST, &host, 0);
        curl_url_get(curlu, CURLUPART_SCHEME, &scheme, 0);
        CHECK_TRUE_LOG(ERROR, !scheme || !valid_scheme(scheme), goto end, "Cannot parse URI");
        CHECK_NULL_LOG(ERROR, host, goto end, "Cannot extract host from URI");

        if(CURLUE_OK == curl_url_get(curlu, CURLUPART_PORT, &port, 0)) { // check optional port
            image_params->port_number = atoi(port);
        }

        ASSERT_EQUAL(curl_url_get(curlu, CURLUPART_PATH, &original_path, 0), CURLUE_OK,
                     goto end, "Failed to extract URI path");
        path = original_path + 1; // libcurl prepend the path with "/" in all cases, it needs to be ignored

        image_params->transport = strdup(scheme);
        split_path(original_path, &version);
        image_params->version = strdup(STRING_EMPTY(version)? "latest" : version); // no version -> assign latest

        if(local_scheme(scheme)) {
            // For local schemes, the host contains the first part of the path
            // Reconstruct the image directory path accordingly
            amxc_string_setf(&image_path, "%s%s/%s", strstr(uri, "///") ? "/" : "", host, path);
            image_params->image_dir = amxc_string_take_buffer(&image_path);
        } else {
            // For remote addresses/schemes, an FQDN of the remote server is required. If not provided,
            // the "host" part is treated as part of the path, and the remote server will be "guessed"
            // from the configuration file (registry-auth.json). This approach is maintained for backward compatibility.
            if(is_fqdn(host)) {
                image_params->server = strdup(host);
                image_params->image_name = strlen(path) > 0 ? strdup(path) : NULL;
            } else {
                amxc_string_setf(&image_path, "%s/%s", host, path);
                image_params->image_dir = amxc_string_take_buffer(&image_path);
            }
        }

        ret = RLYEH_OK;
    }

end:
    curl_url_cleanup(curlu);
    curl_free(scheme);
    curl_free(host);
    curl_free(port);
    curl_free(original_path);
    curl_free(version);
    amxc_string_clean(&image_path);
    if(ret != RLYEH_OK) {
        clear_uri_data(image_params);
    }

    return ret;
}



