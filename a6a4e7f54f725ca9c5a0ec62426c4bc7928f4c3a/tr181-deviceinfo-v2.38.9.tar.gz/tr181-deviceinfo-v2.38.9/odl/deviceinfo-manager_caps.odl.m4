%config {
    %global privileges = {
        user = "USER_ID", group = "GROUP_ID"
    };
}