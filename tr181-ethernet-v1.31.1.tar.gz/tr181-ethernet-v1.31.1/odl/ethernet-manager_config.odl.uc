%config {
{%      for ( let Itf in BD.Interfaces ) : if ( Itf.Type == "ethernet" ) : %}
    {% if (Itf.CPUPort) : %}
    %global cpu-port = "Ethernet.Interface.{{Itf.Alias}}.";
    {% endif %}
{% endif; endfor; %}
}
