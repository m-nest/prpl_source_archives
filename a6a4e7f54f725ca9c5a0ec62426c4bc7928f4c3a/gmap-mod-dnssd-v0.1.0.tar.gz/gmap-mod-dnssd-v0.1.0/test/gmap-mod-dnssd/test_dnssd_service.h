/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_MOD_DNSSD_SERVICE_H__)
#define __GMAP_MOD_DNSSD_SERVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <gmap/gmap_devices.h>
#include <gmap/gmap_device.h>
#include <gmap/gmap.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>

amxd_status_t _setTag(amxd_object_t* object,
                      AMXB_UNUSED amxd_function_t* func,
                      amxc_var_t* args,
                      AMXB_UNUSED amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Handles a GET operation for a DNSSD data model object.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the arguments passed to the function.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _get(amxd_object_t* object,
                   amxd_function_t* func,
                   amxc_var_t* args,
                   amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Creates a new DNNSD device instance.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _createDevice(amxd_object_t* object,
                            amxd_function_t* func,
                            amxc_var_t* args,
                            amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Destroys an existing DNSSD device instance.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _destroyDevice(amxd_object_t* object,
                             amxd_function_t* func,
                             amxc_var_t* args,
                             amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Adds a link between DNSSD device instances.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _linkAdd(amxd_object_t* object,
                       amxd_function_t* func,
                       amxc_var_t* args,
                       amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Removes a link between DNSSD device instances.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _linkRemove(amxd_object_t* object,
                          amxd_function_t* func,
                          amxc_var_t* args,
                          amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Retrieves the DNSSD device topology.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _topology(amxd_object_t* object,
                        amxd_function_t* func,
                        amxc_var_t* args,
                        amxc_var_t* ret);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Executes a search operation in the DNSSD hierarchy.
 *
 * @param object  Pointer to the AMXD object instance.
 * @param func    Pointer to the function metadata.
 * @param args    Pointer to the function arguments.
 * @param ret     Pointer to the return variable.
 *
 * @return AMXD status code.
 */
amxd_status_t _find(amxd_object_t* object,
                    amxd_function_t* func,
                    amxc_var_t* args,
                    amxc_var_t* ret);



/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Test setup function. Allocates and initializes test resources.
 *
 * @param state  CMocka test state pointer.
 *
 * @return 0 on success.
 */
int test_mod_dnssd_setup(void** state);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Test teardown function. Frees all allocated test resources.
 *
 * @param state  CMocka test state pointer.
 *
 * @return 0 on success.
 */
int test_mod_dnssd_teardown(void** state);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Tests that default services exist at startup.
 *
 * @param state  CMocka test state pointer.
 */
void test_dnssd_default_service(void** state);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Tests that default services exist at startup.
 *
 * @param state  CMocka test state pointer.
 */
void test_dnssd_default_service_gmap(void** state);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Tests that added services are added to gmap.
 *
 * @param state  CMocka test state pointer.
 */
void test_dnssd_add_service(void** state);

/**
 * @ingroup gmap_mod_dnssd_tests
 *
 * @brief Tests that removed services are removed from gmap.
 *
 * @param state  CMocka test state pointer.
 */
void test_dnssd_remove_service(void** state);



#ifdef __cplusplus
}
#endif

#endif  /* __GMAP_MOD_DNSSD_SERVICE_H__ */
