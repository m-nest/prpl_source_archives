/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dm_dnssd_advertisement.h"
#include "dnssd_advertisement.h"

/**
 * @brief
 * add a text entry to the service
 *
 * @param text_record string variant text record formated as key=value
 * @param service the service object to add the text record to
 * @return amxd_status_t 0 if success
 */
static void add_text_entry(amxc_var_t* text_record, amxd_trans_t* trans) {
    amxd_trans_add_inst(trans, 0, amxc_var_key(text_record));

    amxd_trans_set_value(cstring_t, trans, "Key", amxc_var_key(text_record));
    amxd_trans_set_value(cstring_t, trans, "Value", GET_CHAR(text_record, NULL));

    amxd_trans_select_pathf(trans, ".^");
    return;
}

/**
 * @brief
 * add a service to advertise
 *
 * @param object The DNSSD.Advertise object
 * @param func Function call
 * @param args The argument for the service to add
 * @param ret The return variant
 * @return amxd_status_t 0 if success
 */
amxd_status_t _service_start_advertise(amxd_object_t* object,
                                       UNUSED amxd_function_t* func,
                                       amxc_var_t* args,
                                       amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_ok;
    const char* instance_name = NULL;
    const char* application_protocol = NULL;
    const char* transport_protocol = NULL;
    uint32_t port = 0;

    /* mandatory parameters */
    instance_name = GET_CHAR(args, "instance_name");
    when_str_empty_trace(instance_name, exit, ERROR, "No instance name given for the service to advertise.");
    application_protocol = GET_CHAR(args, "application_protocol");
    when_str_empty_trace(application_protocol, exit, ERROR, "No protocol for the application given for the service to advertise.");
    transport_protocol = GET_CHAR(args, "transport_protocol");
    when_str_empty_trace(transport_protocol, exit, ERROR, "No transport protocol given for the service to advertise.");

    /* optional parameters */
    port = GET_UINT32(args, "port");

    if(!amxd_object_findf(object, ".[InstanceName=='%s' && ApplicationProtocol=='%s' && TransportProtocol=='%s']", instance_name, application_protocol, transport_protocol)) {
        amxd_trans_t trans;
        amxd_trans_init(&trans);
        amxd_trans_select_object(&trans, object);
        amxd_trans_add_inst(&trans, 0, instance_name);
        amxd_trans_set_value(bool, &trans, "Enable", true);
        amxd_trans_set_value(cstring_t, &trans, "InstanceName", instance_name);
        amxd_trans_set_value(cstring_t, &trans, "ApplicationProtocol", application_protocol);
        amxd_trans_set_value(cstring_t, &trans, "TransportProtocol", transport_protocol);
        amxd_trans_set_value(uint32_t, &trans, "Port", port);

        amxd_trans_select_pathf(&trans, ".TextRecord.");

        amxc_var_for_each(text_record, GET_ARG(args, "text_record")) {
            add_text_entry(text_record, &trans);
        }

        retval = amxd_trans_apply(&trans, dnssd_advertisement_get_dm());
        if(retval != amxd_status_ok) {
            SAH_TRACEZ_ERROR(ME, "Cannot fill datamodel with service entry.");
        }
        amxd_trans_clean(&trans);
    }

exit:
    amxc_var_set(uint32_t, ret, retval);
    return retval;
}

/**
 * @brief
 * Stop to advertise a service
 *
 * @param object The DNSSD.Advertise object
 * @param func The function name
 * @param args The name of the service to remove
 * @param ret The return variant
 * @return amxd_status_t 0 if success
 */
amxd_status_t _service_stop_advertise(amxd_object_t* object,
                                      UNUSED amxd_function_t* func,
                                      amxc_var_t* args,
                                      amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_unknown_error;
    amxd_trans_t trans;
    const char* instance_name = NULL;

    amxd_trans_init(&trans);

    instance_name = GET_CHAR(args, "instance_name");
    when_str_empty_trace(instance_name, exit, ERROR, "No instance name given for the service to remove.");

    amxd_trans_select_object(&trans, object);
    amxd_trans_del_inst(&trans, 0, instance_name);
    retval = amxd_trans_apply(&trans, dnssd_advertisement_get_dm());
    when_failed_trace(retval, exit, ERROR, "Cannot update datamodel with service removing.");
exit:
    amxd_trans_clean(&trans);
    amxc_var_set(uint32_t, ret, retval);
    return retval;
}
