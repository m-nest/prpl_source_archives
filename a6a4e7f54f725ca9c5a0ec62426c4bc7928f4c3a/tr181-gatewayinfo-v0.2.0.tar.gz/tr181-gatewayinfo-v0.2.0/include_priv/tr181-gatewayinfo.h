/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef TR181_GATEWAYINFO_H
#define TR181_GATEWAYINFO_H
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>
#include <stdint.h>

#define NETMODEL_INTF "NetModelIntfName"
#define DEFAULT_STRING_BUFFER_SIZE 256
#define BUS_OPERATION_TIMEOUT 5

/**
 * @file tr181-gatewayinfo.h
 * @brief Implementation of the TR-181 GatewayInfo. object.
 */

/**
 * DHCP-obtained information about the gateway
 */
struct DHCPGatewayInformation {
    /**
     * ManufacturerOUI of the gateway
     */
    amxc_string_t DeviceManufacturerOUI;

    /**
     * SerialNumber of the gateway
     */
    amxc_string_t DeviceSerialNumber;

    /**
     * ProductClass of the gateway
     */
    amxc_string_t DeviceProductClass;
};

/**
 * Initialize the DHCPGatewayInformation struct
 *
 * @param[in] gateway_information instance of DHCPGatewayInformation to init
 */
void DHCPGatewayInformation_init(struct DHCPGatewayInformation* gateway_information);

/**
 * Deinitialize the DHCPGatewayInformation struct
 *
 * @param[in] gateway_information instance of DHCPGatewayInformation to deinit
 */
void DHCPGatewayInformation_deinit(struct DHCPGatewayInformation* gateway_information);

/**
 * Reset every parameter of the DHCPGatewayInformation struct.
 * Since it contains only amxc_string_t variables, every one of them
 * would be reset to an empty one.
 *
 * @param[in] gateway_information instance of DHCPGatewayInformation to reset
 */
void DHCPGatewayInformation_reset(struct DHCPGatewayInformation* gateway_information);

/**
 * Copy one instance of DHCPGatewayInformation to another
 *
 * @param[in] src source, copy-from
 * @param[out] dst destination, copy-to
 */
void DHCPGatewayInformation_copy(const struct DHCPGatewayInformation* src, struct DHCPGatewayInformation* dst);

/**
 * Check, whether two instances of DHCPGatewayInformation
 * are equal
 *
 * @param[in] lhs first instance
 * @param[out] rhs seconds instance
 *
 * @return whether two instances are equal
 */
bool DHCPGatewayInformation_equal(const struct DHCPGatewayInformation* lhs, const struct DHCPGatewayInformation* rhs);

/**
 * Checks, whether DHCPGatewayInformation is empty
 *
 * @param[in] gateway_information DHCPGatewayInformation instance to check
 *
 * @return whether the instance is empty
 */
bool DHCPGatewayInformation_is_emtpy(const struct DHCPGatewayInformation* gateway_information);

/**
 * Information about running application
 */
struct App {
    /**
     * Discovered via DHCPv4 information about the gateway
     */
    struct DHCPGatewayInformation dhcpv4_gateway;

    /**
     * Discovered via DHCPv6 information about the gateway
     */
    struct DHCPGatewayInformation dhcpv6_gateway;
};

/**
 * DHCP types
 */
enum DHCPType { DHCPv4, DHCPv6 };

/**
 * Initialize the App structure
 *
 * @param[in] app instance to initialize
 */
void app_init(struct App* app);

/**
 * The entrypoint for the amxrt runtime: start
 * gatewayinfo application, subscribe to changes in DHCP
 * options and update the model, if needed
 *
 * @param reason the reason for call (either start or stop)
 * @param dm (unused) datamodel of the gatewayinfo component
 * @param parser (unused) parser for ODL files
 * @return 0 if no error happens
 */
int _gatewayinfo_main(int reason, UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser);

extern struct App app;

#endif
