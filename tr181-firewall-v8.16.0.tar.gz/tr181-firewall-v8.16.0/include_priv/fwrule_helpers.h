/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef FWRULE_HELPERS_H__
#define FWRULE_HELPERS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <fwrules/fw_rule.h>
#include <fwrules/fw_folder.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <schedules/schedule.h>
#include "netmodel.h"           // for firewall_interface_t
#include "ip_address.h"         // for ipversion_t
#include "firewall_utilities.h" // for status_t

#define TABLE_FILTER "filter"
#define TABLE_NAT "nat"
#define TABLE_RAW "raw"

/**
 * @enum flags_t
 * @brief Change-tracking flags for firewall-related objects.
 *
 * This enum is used as a bitmask to indicate how an object has changed.
 * Multiple flags may be combined with bitwise OR.
 */
typedef enum {
    FW_NEW = 1,      /**< Object was newly created and not yet applied. */
    FW_DELETED = 2,  /**< Object was deleted or marked for removal. */
    FW_MODIFIED = 4, /**< Object was modified after initial creation. */
} flags_t;


/**
 * @enum target_t
 * @brief Possible firewall jump / verdict targets for a rule.
 *
 * These values typically map to actions in the firewall backend
 * (e.g. ACCEPT, DROP, ...).
 */
typedef enum {
    TARGET_NONE,   /**< No explicit target / no-op. */
    TARGET_DROP,   /**< Drop the packet without reply. */
    TARGET_ACCEPT, /**< Accept the packet. */
    TARGET_CHAIN,  /**< Jump to a user-defined chain. */
    TARGET_REJECT, /**< Reject the packet and actively respond (ICMP/TCP RST). */
    TARGET_RETURN, /**< Return from the current chain to the caller. */
    TARGET_LOG,    /**< Log the packet (without necessarily changing verdict). */
} target_t;

/**
 * @enum log_filter_t
 * @brief Filter mode for which packets should generate log events.
 */
typedef enum {
    LOG_FILTER_ALL,     /**< Log all matching packets. */
    LOG_FILTER_ALLOWED, /**< Log only packets that were allowed/accepted. */
    LOG_FILTER_DENIED,  /**< Log only packets that were denied/dropped/rejected. */
    LOG_FILTER_LOG      /**< Log all packets matching the filter, irrespective of whether they are allowed, denied, or dropped. */
} log_filter_t;

/**
 * @struct log_info_t
 * @brief Per-rule/per-object logging configuration.
 *
 * Describes how logging should be performed (level, prefix, controllers, ...).
 */
typedef struct _log_info_ {
    int log_level;               /**< Logging level / severity (syslog-style). */
    int flags;                   /**< Log-related flags/attributes. */
    bool enable;                 /**< true if logging is enabled. */
    amxc_string_t* log_prefix;   /**< Prefix string to include in log messages. */
    amxc_var_t* log_controllers; /**< Optional set/list of logging controllers (Firewall.Log.). */
} log_info_t;

/**
 * @struct log_t
 * @brief Runtime logging state and metadata container for a firewall folder.
 *
 * This structure keeps both the previous logging configuration and
 * the current one, along with contextual data to manage subscriptions
 * and callbacks.
 */
typedef struct _log_ {
    log_info_t old_log_info;             /**< Previous logging config (before changes). */
    log_info_t log_info;                 /**< Current logging config. */
    log_filter_t rule_policy;            /**< Which traffic should be logged (see log_filter_t). */
    firewall_interface_t* src_interface; /**< Source interface for log scoping. */
    bool exclude_src_interface;          /**< If true, exclude the source interface instead of matching it. */
    firewall_interface_t* dst_interface; /**< Destination interface for log scoping. */
    bool exclude_dst_interface;          /**< If true, exclude the destination interface instead of matching it. */
    bool use_log_controller_interface;   /**< If true, use controller(s) linked to an interface instead of explicit list. */
    amxd_object_t* object;               /**< Management object this log config is bound to. */
} log_t;

/**
 * @struct folder_wrapper_t
 * @brief Helper wrapper around one logical log context and its associated rule folders.
 *
 * Keeps IPv4 and IPv6 folders together with a logging context.
 */
typedef struct _folder_wrapper_ {
    log_t log;            /**< Logging context associated with these folders. */
    fw_folder_t* folder;  /**< Primary (e.g. IPv4) firewall folder / chain / table reference. */
    fw_folder_t* folder6; /**< IPv6 equivalent firewall folder / chain / table reference. */
} folder_wrapper_t;

/**
 * @struct folder_container_t
 * @brief Aggregates folder groups and logging state for a firewall entity.
 *
 * Used to bundle the runtime log folders, rule folders, and associated metadata
 * so higher-level objects (like rules, policies, services) can manage them as a unit.
 */
typedef struct _folder_container_ {
    folder_wrapper_t log_folders;  /**< Folders used specifically for logging rules. */
    folder_wrapper_t rule_folders; /**< Folders used for the actual enforcement rules. */
    log_t log;                     /**< Global / shared logging state and metadata for this container. */
    bool just_log;                 /**< If true, only log_folders are used (no rule_folders). */
    void* priv_data;               /**< Backend-private data pointer (opaque to higher layers). */
} folder_container_t;

/**
 * @struct common_t
 * @brief Common metadata shared by firewall objects (rules, policies, services, etc).
 *
 * This is a high-level bundle of lifecycle flags, runtime state, bindings to
 * interfaces/folders, and scheduling.
 *
 * Many firewall-related objects embed this struct as their "base class".
 */
typedef struct common {
    flags_t flags;                      /**< Change-tracking flags (new/modified/deleted). See flags_t. */
    bool enable;                        /**< If false, this object is administratively disabled. */
    bool suspend;                       /**< If true, temporarily suspend effect without clearing config. */
    bool validated;                     /**< true if validation/sanity check has completed successfully. */
    status_t status;                    /**< Current operational status (backend-defined). */
    folder_container_t folders;         /**< Rule/log folders and logging context for this object. */
    amxc_var_t protocols;               /**< Protocols/protocol groups associated with this object. */
    ipversion_t ipversion;              /**< IP version context (IPv4, IPv6, or dual). */
    amxd_object_t* object;              /**< mgmt / data model object bound to this instance. */
    firewall_interface_t dest_fwiface;  /**< Destination interface context (IPv4). */
    firewall_interface_t src_fwiface;   /**< Source interface context (IPv4). */
    firewall_interface_t dest6_fwiface; /**< Destination interface context (IPv6). */
    firewall_interface_t src6_fwiface;  /**< Source interface context (IPv6). */
    void* priv_data;                    /**< Implementation-specific private pointer. */
    schedule_t* schedule;               /**< Optional schedule controlling when this object is active. */
    schedule_status_t schedule_status;  /**< Runtime evaluation of @ref schedule. */
    char* object_path;                  /**< Path of this object in the mgmt/data model hierarchy. */
} common_t;

typedef struct {
    const char* chain;
    struct {
        address_t* src_address;
        address_t* dest_address;
        amxc_llist_t* src_ports;
        amxc_llist_t* dest_ports;
        amxc_var_t* protocols;
    } match;
    struct {
        address_t* address;
        amxc_llist_t* src_ports;
        amxc_llist_t* dest_ports;
    } target;
} dnat_args_t;

typedef struct {
    ipversion_t ipversion;
    bool reverse;
    const char* chain;
    struct {
        const char* iface;
        amxc_var_t* protocols;
        address_t* src_address;
        address_t* dest_address;
        amxc_llist_t* src_ports;
        amxc_llist_t* dest_ports;
    } match;
    struct {
        target_t verdict;
    } target;
} filter_args_t;

target_t string_to_target(const char* target);

bool fw_rule_callback(const fw_rule_t* const rule, const fw_rule_flag_t flag, const char* chain, const char* table, int index);

bool enable_rule(fw_folder_t* log_folder, fw_folder_t* folder, status_t* status, bool commit);

bool set_log_rule_specific_settings(fw_rule_t* r, const log_t* const log);

void common_init(common_t* common, amxd_object_t* object);
void common_clean(common_t* common);
void common_set_status(common_t* common, status_t status);

void folder_wrapper_disable_folders(folder_wrapper_t* folder_wrapper, ipversion_t ipversion);
bool folder_wrapper_delete_rules(folder_wrapper_t* folder_wrapper, ipversion_t ipversion, bool commit);
void folder_wrapper_init(folder_wrapper_t* folder_wrapper);
void folder_wrapper_clean(folder_wrapper_t* folder_wrapper);

bool is_folders_initialized(folder_container_t* folders);
void folder_container_init(folder_container_t* folders, common_t* common);
void folder_container_clean(folder_container_t* folders);
bool is_folders_array_ordered(folder_container_t** folder_container_array, int array_size);
bool reorder_array_folder_containers(folder_container_t** folder_container_array, int array_size);
bool folder_container_reorder(folder_container_t* folders);
bool folder_container_delete_rules(folder_container_t* folders, ipversion_t ipversion, bool commit);
void folder_container_disable_folders(folder_container_t* folders, ipversion_t ipversion);

bool folder_require_source_feature(fw_folder_t* folder, address_t* address);
bool folder_require_dest_feature(fw_folder_t* folder, address_t* address);

bool folder_default_set_source(fw_rule_t* default_rule, const char* ip, const char* netmask, bool excluded);
bool folder_default_set_destination(fw_rule_t* default_rule, const char* ip, const char* netmask, bool excluded);
bool folder_default_set_address(fw_rule_t* default_rule, address_t* address, bool ipv4, bool source, bool exclude);
bool folder_default_set_host_address(fw_rule_t* default_rule, address_t* address, bool ipv4, bool source, bool exclude);
bool folder_default_set_in_and_out_interfaces(fw_rule_t* default_rule, const char* dest, bool dest_excl, const char* src, bool src_excl, bool reverse);

bool folder_feature_set_source_mac(fw_folder_t* folder, const char* mac, bool exclude);
bool folder_feature_set_protocol(fw_folder_t* folder, amxc_var_t* protocols);
bool folder_feature_set_source_port(fw_folder_t* folder, amxc_llist_t* ports, bool exclude);
bool folder_feature_set_destination_port(fw_folder_t* folder, amxc_llist_t* ports, bool exclude);
bool folder_feature_set_target_policy(fw_folder_t* folder, fw_rule_policy_t policy);
bool folder_feature_set_address(fw_folder_t* folder, address_t* address, bool ipv4, bool source, bool exclude);
bool folder_feature_set_target(fw_folder_t* folder, target_t target, const char* chain_name);
bool folder_feature_set_source_and_destination_port(fw_folder_t* folder, amxc_llist_t* src_ports, bool sport_exclude, amxc_llist_t* dst_ports, bool dport_exclude, bool reverse);
bool folder_feature_set_dscp(fw_folder_t* folder, int32_t dscp, bool exclude);
bool folder_feature_set_source_ipset(fw_folder_t* folder, const char* source_set_path, const char* source_set_exclude_path);
bool folder_feature_set_destination_ipset(fw_folder_t* folder, const char* dest_set_path, const char* dest_set_exclude_path);
bool folder_feature_set_target_dnat(fw_folder_t* folder, const char* destination, int int_port, int int_port_max, int ext_port, int ext_port_max);
bool folder_feature_set_target_snat(fw_folder_t* folder, address_t* address, int minport, int maxport);

bool fill_folder_dnat_rule(fw_folder_t* folder, dnat_args_t* args);
bool fill_folder_container_filter_rule(folder_container_t* folders, filter_args_t* args);

#ifdef __cplusplus
}
#endif

#endif // FWRULE_HELPERS_H__
