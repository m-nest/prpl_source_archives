/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**********************************************************
* Include files
**********************************************************/

#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "tr181-syslog.h"
#include "tr181-syslog_main.h"

/**********************************************************
* Macro definitions
**********************************************************/

/**********************************************************
* Type definitions
**********************************************************/
typedef struct _syslog_app {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    const char* prefix;
    amxc_var_t prefixed_name_cache;
} syslog_app_t;

/**********************************************************
* Variable declarations
**********************************************************/

static syslog_app_t app;

/**********************************************************
* Function Prototypes
**********************************************************/

/**********************************************************
* Functions
**********************************************************/

amxd_dm_t* syslog_get_dm(void) {
    return app.dm;
}

amxo_parser_t* syslog_get_parser(void) {
    return app.parser;
}

const char* syslog_get_prefix(void) {
    const amxc_var_t* config = NULL;

    when_not_null(app.prefix, exit);

    config = amxo_parser_get_config(app.parser, "global_vendor_prefix_");
    if(config != NULL) {
        app.prefix = GET_CHAR(config, NULL);
    } else {
        app.prefix = "";
    }
exit:
    return app.prefix;
}

static amxc_var_t* syslog_build_cached_prefixed_name(const char* base_name) {
    const char* prefix = syslog_get_prefix();
    const char* prefixed_name = NULL;
    amxc_var_t* value = NULL;
    amxc_string_t builder;

    amxc_string_init(&builder, 0);
    amxc_string_setf(&builder, "%s%s", prefix, base_name);

    prefixed_name = amxc_string_get(&builder, 0);
    value = amxc_var_add_new_key(&app.prefixed_name_cache, base_name);
    amxc_var_set(cstring_t, value, prefixed_name);

    amxc_string_clean(&builder);
    return value;
}

const char* syslog_get_prefixed_name(const char* base_name) {
    amxc_var_t* value = NULL;
    const char* prefixed_name = NULL;

    when_str_empty_trace(base_name, exit, ERROR, "base_name empty");
    value = amxc_var_get_key(&app.prefixed_name_cache, base_name, AMXC_VAR_FLAG_DEFAULT);
    if(value == NULL) {
        value = syslog_build_cached_prefixed_name(base_name);
    }
    prefixed_name = GET_CHAR(value, NULL);
exit:
    return prefixed_name;
}

int _syslog_main(int reason,
                 amxd_dm_t* dm,
                 amxo_parser_t* parser) {
    int rv = 0;
    switch(reason) {
    case AMXO_START:
        app = (syslog_app_t) {
            .dm = dm,
            .parser = parser,
        };
        amxc_var_init(&app.prefixed_name_cache);
        amxc_var_set_type(&app.prefixed_name_cache, AMXC_VAR_ID_HTABLE);
        rv = syslog_init();
        break;
    case AMXO_STOP:
        rv = syslog_teardown();
        amxc_var_clean(&app.prefixed_name_cache);
        app = (syslog_app_t) {
            .dm = NULL,
            .parser = NULL,
            .prefix = NULL,
        };
        break;
    }
    return rv;
}
