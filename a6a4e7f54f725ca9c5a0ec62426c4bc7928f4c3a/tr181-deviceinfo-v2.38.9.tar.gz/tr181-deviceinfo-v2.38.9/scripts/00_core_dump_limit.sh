#!/bin/sh
echo "export ULIMIT_CONFIGURATION=\"unlimited\"" >> /var/etc/environment