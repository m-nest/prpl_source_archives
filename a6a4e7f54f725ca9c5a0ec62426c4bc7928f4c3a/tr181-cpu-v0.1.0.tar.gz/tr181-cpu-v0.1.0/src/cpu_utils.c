/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <sys/stat.h>

#include "tr181-cpu.h"
#include "cpu_utils.h"

#define ME "cpu-utils"

/**
   @ingroup  CPU Plugin
   @defgroup cpu_utils
 */

/**
   @ingroup  cpu_utils
   Global storage for original DVFS settings.

   This hash table stores the original DVFS values for each CPU before we
   make any changes. This allows us to restore the system to its original
   state when the application stops, ensuring we don't permanently modify
   system settings.
 */
static amxc_var_t cpu_dvfs_defaults;

/**
   @ingroup  cpu_utils
   DVFS parameters that need to be saved and restored.

   These are the three key parameters that control CPU frequency scaling
   behavior. We save these on startup and restore them on shutdown.
 */
static const char* file_names[NR_DEFAULTS] = { "scaling_governor", "scaling_max_freq", "scaling_min_freq" };

/**
   @ingroup  cpu_utils
   Builds the full sysfs path for a CPU's DVFS parameter file.

   Constructs paths like "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor".
   Supports custom paths via DVFS_PATH configuration for testing purposes.

   @param cpu_name The CPU identifier (e.g., "cpu0", "cpu1")
   @param filename The parameter filename (e.g., "scaling_governor")
   @param sysfs_path Output string to store the constructed path
   @return 0 on success, -1 on error
 */
static int cpu_build_path(const char* cpu_name, const char* filename, amxc_string_t* sysfs_path) {
    SAH_TRACEZ_IN(ME);
    int retval = -1;
    const char* cpu_dvfs_path = GET_CHAR(cpu_get_config("DVFS_PATH"), NULL);

    when_str_empty(cpu_name, exit);
    when_str_empty(filename, exit);

    // Use custom path if configured, otherwise use default sysfs path
    cpu_dvfs_path = cpu_dvfs_path == NULL? CPU_DVFS_PATH_FMT:cpu_dvfs_path;

    retval = amxc_string_setf(sysfs_path, cpu_dvfs_path, cpu_name, filename);

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

/**
   @ingroup  cpu_utils
   Reads a value from a CPU's sysfs file.

   This function reads DVFS parameters from the Linux kernel's sysfs interface.
   It handles files that may not exist (returns success with empty value) and
   converts space-separated values to comma-separated for easier parsing.

   Why comma-separated: Ambiorix uses CSV format for list-like parameters,
   so we convert "performance powersave ondemand" to "performance,powersave,ondemand".

   @param cpu_name The CPU identifier (e.g., "cpu0")
   @param filename The parameter filename to read
   @param value Output variant to store the read value
   @return 0 on success, -1 on error
 */
static int cpu_read_file(const char* cpu_name, const char* filename, amxc_var_t* value) {
    SAH_TRACEZ_IN(ME);
    char* line = NULL;
    ssize_t read = 0;
    size_t len = 0;
    FILE* file = NULL;
    amxc_string_t sysfs_path;
    struct stat buffer;
    int rv = 0;

    amxc_string_init(&sysfs_path, 0);

    when_failed(cpu_build_path(cpu_name, filename, &sysfs_path), exit);

    // If file doesn't exist, it's not an error - just means feature is unavailable
    if(stat(amxc_string_get(&sysfs_path, 0), &buffer) != 0) {
        goto exit;
    }

    file = fopen(amxc_string_get(&sysfs_path, 0), "r");
    if(file == NULL) {
        SAH_TRACEZ_ERROR(ME, "Failed to open file of %s. Err message: %s", amxc_string_get(&sysfs_path, 0), strerror(errno));
        goto exit;
    }
    read = getline(&line, &len, file);
    if(read == -1) {
        rv = -1;
        goto exit;
    }

    // Remove trailing whitespaces, including newline
    // No buffer copy
    // re-use variable sysfs_path
    amxc_string_clean(&sysfs_path);
    amxc_string_push_buffer(&sysfs_path, line, read + 1); // add 1 for zero terminating
    amxc_string_trim(&sysfs_path, NULL);
    amxc_string_take_buffer(&sysfs_path);

    // convert spaces to commas for CSV format
    for(ssize_t i = 0; i < read - 1; i++) {
        if(isblank(line[i]) != 0) {
            line[i] = ',';
        }
    }
    amxc_var_push(cstring_t, value, line);
    line = NULL;

exit:
    if(file != NULL) {
        fclose(file);
    }
    amxc_string_clean(&sysfs_path);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
   @ingroup  cpu_utils
   Writes a value to a CPU's sysfs file.

   This function writes DVFS parameters to the Linux kernel's sysfs interface.
   Writing to these files immediately affects the system's CPU frequency behavior.
   For example, writing "performance" to scaling_governor forces the CPU to run
   at maximum frequency.

   @param cpu_name The CPU identifier (e.g., "cpu0")
   @param filename The parameter filename to write to
   @param value The value to write (will be converted to string)
   @return 0 on success, -1 on error
 */
static int cpu_write_file(const char* cpu_name, const char* filename, amxc_var_t* value) {
    int retval = -1;
    amxc_string_t sysfs_path;
    FILE* fp = NULL;
    char* str_value = amxc_var_dyncast(cstring_t, value);

    amxc_string_init(&sysfs_path, 0);

    when_failed(cpu_build_path(cpu_name, filename, &sysfs_path), exit);
    fp = fopen(amxc_string_get(&sysfs_path, 0), "w");
    when_null_trace(fp, exit, ERROR, "Error opening file %s: %s", amxc_string_get(&sysfs_path, 0), strerror(errno));
    if(fprintf(fp, "%s\n", str_value) < 0) {
        SAH_TRACEZ_ERROR(ME, "Error writing to file: %s", strerror(errno));
        fclose(fp);
        goto exit;
    }
    retval = 0;
    fflush(fp);  // Ensure data is written immediately
    fclose(fp);

exit:
    amxc_string_clean(&sysfs_path);
    free(str_value);
    return retval;
}

/**
   @ingroup  cpu_utils
   Public wrapper for reading a CPU parameter value.

   This provides a clean public interface for reading DVFS parameters,
   abstracting away the internal implementation details.
 */
int cpu_read_value(const char* cpu_name, const char* filename, amxc_var_t* value) {
    return cpu_read_file(cpu_name, filename, value);
}

/**
   @ingroup  cpu_utils
   Public wrapper for writing a CPU parameter value.

   This provides a clean public interface for writing DVFS parameters,
   abstracting away the internal implementation details.
 */
int cpu_write_value(const char* cpu_name, const char* filename, amxc_var_t* value) {
    return cpu_write_file(cpu_name, filename, value);
}

/**
   @ingroup  cpu_utils
   Checks if a CPU supports frequency scaling (DVFS).

   A CPU supports DVFS if the scaling_available_governors file exists in its
   sysfs directory. This is a reliable indicator that the kernel has loaded
   the appropriate cpufreq driver for this CPU.

   Why this check: Not all CPUs or kernel configurations support frequency scaling.
   Virtual machines, some embedded systems, or systems without proper drivers
   may not have DVFS available. We need to detect this to avoid errors.

   @param cpu_name The CPU identifier to check (e.g., "cpu0")
   @return true if DVFS is supported, false otherwise
 */
bool cpu_scaling_is_supported(const char* cpu_name) {
    SAH_TRACEZ_IN(ME);
    amxc_string_t avail_govs_path;
    struct stat buffer;
    bool is_supported = false;

    amxc_string_init(&avail_govs_path, 0);
    cpu_build_path(cpu_name, "scaling_available_governors", &avail_govs_path);
    is_supported = (stat(amxc_string_get(&avail_govs_path, 0), &buffer) == 0);
    when_false_trace(is_supported, exit, INFO, "scaling_available_governors file not found for this CPU. CPU scaling not supported!");

exit:
    amxc_string_clean(&avail_govs_path);
    SAH_TRACEZ_OUT(ME);
    return is_supported;
}

/**
   @ingroup  cpu_utils
   Saves the current DVFS settings for all CPUs.

   This function is called during application startup to capture the system's
   current DVFS configuration. We save:
   - scaling_governor: The current frequency governor
   - scaling_max_freq: The maximum allowed frequency
   - scaling_min_freq: The minimum allowed frequency

   Why save defaults: When our application stops, we want to restore the system
   to exactly the state it was in before we started. This prevents our application
   from permanently altering system behavior or interfering with other tools.
 */
void cpu_get_default_dvfs_values(void) {
    char cpu_name[CPU_SYSFS_NAME_LEN];

    amxc_var_init(&cpu_dvfs_defaults);
    amxc_var_set_type(&cpu_dvfs_defaults, AMXC_VAR_ID_HTABLE);

    // Iterate through all CPUs (cpu0, cpu1, cpu2, ...) until we find one that doesn't exist
    for(int cpu = 0; ; cpu++) {
        amxc_var_t* cpu_defaults = NULL;
        snprintf(cpu_name, sizeof(cpu_name), "cpu%d", cpu);
        if(!cpu_scaling_is_supported(cpu_name)) {
            break;
        }

        // Create an entry for this CPU and save its current DVFS settings
        cpu_defaults = amxc_var_add_key(amxc_htable_t, &cpu_dvfs_defaults, cpu_name, NULL);
        for(int i = 0; i < NR_DEFAULTS; i++) {
            amxc_var_t* value = amxc_var_add_new_key(cpu_defaults, file_names[i]);
            if(cpu_read_value(cpu_name, file_names[i], value) != 0) {
                continue;
            }
        }
    }
}

/**
   @ingroup  cpu_utils
   Restores original DVFS settings for a specific CPU.

   This function writes back the saved default values for a single CPU.
   Used when DVFS is disabled for a CPU or during application shutdown.

   Why restore per-CPU: Users may enable DVFS for some CPUs and disable it
   for others. When disabling, we only restore that specific CPU's settings.

   @param cpu_name The CPU identifier to restore (e.g., "cpu0")
 */
void cpu_reset_dvfs_default(const char* cpu_name) {
    amxc_var_t* cpu_defaults = GET_ARG(&cpu_dvfs_defaults, cpu_name);

    for(int i = 0; i < NR_DEFAULTS; i++) {
        amxc_var_t* value = GET_ARG(cpu_defaults, file_names[i]);
        if(amxc_var_is_null(value)) {
            continue;
        }
        cpu_write_value(cpu_name, file_names[i], value);
    }
}

/**
   @ingroup  cpu_utils
   Restores original DVFS settings for all CPUs.

   This function is called during application shutdown to restore the entire
   system to its original state. It iterates through all CPUs and restores
   their saved settings.

   Why restore all: On shutdown, we want to leave the system exactly as we
   found it, regardless of what changes were made during runtime.
 */
void cpu_reset_dvfs_defaults(void) {
    char cpu_name[CPU_SYSFS_NAME_LEN];

    for(int cpu = 0; ; cpu++) {
        snprintf(cpu_name, sizeof(cpu_name), "cpu%d", cpu);
        if(!cpu_scaling_is_supported(cpu_name)) {
            break;
        }

        cpu_reset_dvfs_default(cpu_name);
    }
}

/**
   @ingroup  cpu_utils
   Frees the memory used to store default DVFS values.

   This cleanup function is called after restoring all defaults during
   application shutdown. It frees the hash table and all its contents.
 */
void cpu_clean_dvfs_defaults(void) {
    SAH_TRACEZ_IN(ME);
    amxc_var_clean(&cpu_dvfs_defaults);
    SAH_TRACEZ_OUT(ME);
}