/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include "test_cpu_dm.h"
#include "tr181-cpu.h"
#include "tr181-cpu.h"
#include "cpu_utils.h"
#include "cpu_dm_utils.h"
#include "cpu_dm.h"

static const char* odl_defs = "../../odl/tr181-cpu_definition.odl";
static const char* odl_mock = "../common/mock_defaults.odl";
static const char* odl_config = "../common/mock.odl";

static amxd_dm_t dm;
static amxo_parser_t parser;


static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void copy_mock_cpu(void) {
    int ret;

    ret = system("mkdir -p /tmp/cpu/cpu0/cpufreq/");
    if(ret != 0) {
        printf("mkdir failed");
        return;
    }

    ret = system("cp -a ../common/mock_cpu/cpu0/* /tmp/cpu/cpu0/cpufreq/");
    if(ret != 0) {
        printf("cp failed");
        return;
    }

}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    copy_mock_cpu();

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "check_frequencies_are_valid", AMXO_FUNC(_check_frequencies_are_valid));
    amxo_resolver_ftab_add(&parser, "cpu_read_value", AMXO_FUNC(_cpu_read_value));
    amxo_resolver_ftab_add(&parser, "check_value_is_supported", AMXO_FUNC(_check_value_is_supported));
    amxo_resolver_ftab_add(&parser, "cpu_read_value_checked", AMXO_FUNC(_cpu_read_value_checked));
    amxo_resolver_ftab_add(&parser, "cpu_write_value", AMXO_FUNC(_cpu_write_value));
    amxo_resolver_ftab_add(&parser, "on_enable_changed", AMXO_FUNC(_on_enable_changed));

    assert_int_equal(_cpu_main(0, &dm, &parser), 0);
    _cpu_app_start(NULL, NULL, NULL);

    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_config, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_mock, root_obj), 0);
    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_cpu_main(AMXO_STOP, &dm, &parser), 0);
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

static char* load_file(const char* path) {
    char* buffer = NULL;
    long length = 0;
    FILE* f = fopen(path, "rb");
    if(!f) {
        perror("fopen");
        return NULL;
    }

    fseek(f, 0, SEEK_END);
    length = ftell(f);
    rewind(f);

    buffer = malloc(length + 1);
    if(!buffer) {
        fclose(f);
        return NULL;
    }

    size_t nread = fread(buffer, 1, length, f);
    buffer[nread] = '\0';

    fclose(f);

    if((nread > 0) && (buffer[nread - 1] == '\n')) {
        buffer[nread - 1] = '\0';
    }

    return buffer;
}

static bool file_content_equals(char* file_name, char* content) {
    char* file_content = load_file(file_name);
    bool retval = (strcmp(file_content, content) == 0);
    free(file_content);
    return retval;
}

void test_cpu_dm(UNUSED void** state) {
    amxd_object_t* dvfs = cpu_get_object("CPUs.CPU.cpe-cpu0.DVFS.");
    amxd_trans_t* trans;

    assert_non_null(cpu_get_dm());
    assert_ptr_equal(cpu_get_dm(), &dm);
    assert_non_null(dvfs);

    assert_string_equal("powersave", GET_CHAR(amxd_object_get_param_value(dvfs, "ScalingGovernor"), NULL));
    assert_int_equal(1716000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMaxFrequency"), NULL));
    assert_int_equal(624000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMinFrequency"), NULL));

    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_bool(trans, "Enable", true);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_ok);
    amxd_trans_delete(&trans);
    handle_events();

    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_cstring_t(trans, "ScalingGovernor", "performance");
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_ok);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_governor", "performance"));
    assert_string_equal("performance", GET_CHAR(amxd_object_get_param_value(dvfs, "ScalingGovernor"), NULL));

    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_cstring_t(trans, "ScalingGovernor", "wrong_scaling");
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_invalid_value);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_governor", "performance"));
    assert_string_equal("performance", GET_CHAR(amxd_object_get_param_value(dvfs, "ScalingGovernor"), NULL));

    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMaxFrequency", 1560000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_ok);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_max_freq", "1560000"));
    assert_int_equal(1560000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMaxFrequency"), NULL));

    // Test setting a ScalingMaxFrequency value that is not listed in the scaling_available_frequencies file
    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMaxFrequency", 1500000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_invalid_value);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_max_freq", "1560000"));
    assert_int_equal(1560000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMaxFrequency"), NULL));

    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMinFrequency", 780000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_ok);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_min_freq", "780000"));
    assert_int_equal(780000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMinFrequency"), NULL));

    // Test setting a ScalingMinFrequency value that is not listed in the scaling_available_frequencies file
    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMinFrequency", 700000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_invalid_value);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_min_freq", "780000"));
    assert_int_equal(780000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMinFrequency"), NULL));

    // Test setting a ScalingMinFrequency value greater than ScalingMaxFrequency
    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMinFrequency", 1716000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_invalid_value);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_min_freq", "780000"));
    assert_int_equal(780000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMinFrequency"), NULL));

    // Test setting a ScalingMaxFrequency value lower than ScalingMinFrequency
    amxd_trans_new(&trans);
    amxd_trans_select_object(trans, dvfs);
    amxd_trans_set_uint64_t(trans, "ScalingMaxFrequency", 624000);
    assert_int_equal(amxd_trans_apply(trans, &dm), amxd_status_invalid_value);
    amxd_trans_delete(&trans);
    handle_events();

    assert_true(file_content_equals("/tmp/cpu/cpu0/cpufreq/scaling_max_freq", "1560000"));
    assert_int_equal(1560000, GET_UINT64(amxd_object_get_param_value(dvfs, "ScalingMaxFrequency"), NULL));

}

