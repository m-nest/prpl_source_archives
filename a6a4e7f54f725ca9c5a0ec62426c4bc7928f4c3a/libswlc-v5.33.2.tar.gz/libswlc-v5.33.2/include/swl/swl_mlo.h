/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef SRC_INCLUDE_SWL_SWL_MLO_H_
#define SRC_INCLUDE_SWL_SWL_MLO_H_

#include <stdint.h>

#include "swl_typeEnum.h"

typedef enum {
    SWL_MLO_MODE_UNKNOWN,        // Mode is not set.
    SWL_MLO_MODE_NA,             // There is no MLO or WiFi7 at all
    SWL_MLO_MODE_ACTIVE_UNKNOWN, // MLO is active, but mode not yet determined.
    SWL_MLO_MODE_SINGLE_LINK,    // There is only a "one link fake MLO"
    SWL_MLO_MODE_EMLSR,
    SWL_MLO_MODE_NSTR,
    SWL_MLO_MODE_STR,
    SWL_MLO_MODE_EMLMR,
    SWL_MLO_MODE_MAX
} swl_mlo_mode_e;

extern const char* swl_mlo_mode_str[];
typedef uint16_t swl_mlo_mode_m;

SWL_TYPE_ENUM_H(gtSwl_type_mlo_mode, swl_mlo_mode_e);

bool swl_mlo_isMloActive(swl_mlo_mode_e mode);

typedef enum {
    SWL_MLO_ROLE_NONE,
    SWL_MLO_ROLE_PRIMARY,
    SWL_MLO_ROLE_AUXILIARY,
    SWL_MLO_ROLE_MAX
} swl_mlo_role_e;

extern const char* swl_mlo_role_str[];

typedef enum {
    SWL_MLO_INTF_MLD_STATUS_UNKNOWN,
    SWL_MLO_INTF_MLD_STATUS_UNSUPPORTED,
    SWL_MLO_INTF_MLD_STATUS_UNCONFIGURED,
    SWL_MLO_INTF_MLD_STATUS_STANDARD_DISABLED,
    SWL_MLO_INTF_MLD_STATUS_INVALID_MLD_CONFIG,
    SWL_MLO_INTF_MLD_STATUS_INVALID_OTHER_CONFIG,
    SWL_MLO_INTF_MLD_STATUS_BSS_DISABLED,
    SWL_MLO_INTF_MLD_STATUS_READY,
    SWL_MLO_INTF_MLD_STATUS_MAX
} swl_mlo_intfMldStatus_e;

extern const char* swl_mlo_intfMldStatus_str[];

#endif /* SRC_INCLUDE_SWL_SWL_MLO_H_ */
