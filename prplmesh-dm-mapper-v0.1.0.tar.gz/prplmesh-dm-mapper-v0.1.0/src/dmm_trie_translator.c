/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_trie_translator.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief DMM trie translatior implementation allows translating
 * requests and responses using trie.
 * @version 1.0.0
 * @date 2025-12-03
 *
 * @copyright Copyright (c) 2025 Inango
 */

#include <ctype.h>
#include <stddef.h>
#include <string.h>

#include "dmm.h"
#include "dmm_trie.h"
#include "dmm_trie_translator.h"

#include <amxc/amxc_macros.h>
#include <amxc/amxc_htable.h>
#include <amxc/amxc_string.h>
#include <amxc/amxc_variant.h>
#include <amxd/amxd_types.h>
#include <debug/sahtrace.h>

#define ME "dmm" /*!< Tracezone Prefix for SAH logger method */

void clean_path_action(PathAction* action) {
    amxc_string_clean(&action->rename_to);
}

void clean_translate_req_result(TranslateReqResult* result) {
    amxc_string_clean(&result->translated);
}

/**
 * @brief Iterate through the tree and fill path action for the path:
 *   - if at least one object in path needs renaming, all path would be renamed
 *   - if at least one object in path needs hidings, all path would be hidden
 *
 * @param[in] root root of the tree to iterate through
 * @param[in] object_path object path to translate, it would be changed during iteration
 * @param[in,out] action resulting action for the path
 *
 * @return last element of path that is represented in the tree
 */
static const TreeNode* find_object_build_result_path(const TreeNode* root, char* object_path, PathAction* action) {
    const TreeNode* node = NULL;

    when_null(root, exit);
    when_null(object_path, exit);
    when_null(action, exit);

    char* saveptr;
    char* pch = strtok_r(object_path, ".", &saveptr);
    node = root;
    while(pch != NULL) {

        amxc_htable_it_t* node_it = amxc_htable_get(&node->nonterminals, pch);
        if(node_it == NULL) {
            // if previous node is a multiinstance one, copy whatever is next
            // and continue with next part
            if(node->is_multiinstance) {
                amxc_string_appendf(&action->rename_to, "%s.", pch);
                pch = strtok_r(NULL, ".", &saveptr);
                if(pch == NULL) {
                    break;
                }
                node_it = amxc_htable_get(&node->nonterminals, pch);
            } else {
                break;
            }
        }
        if(node_it == NULL) {
            break;
        }
        node = amxc_htable_it_get_data(node_it, TreeNode, hit);

        // if an upper node is hidden, all children nodes are hidden
        if(node->action == NodeAction_Hide) {
            action->action = HidePathAction;
            // if node is hidden, no need to iterate anymore
            goto exit;
        }
        if(node->rename_to) {
            amxc_string_appendf(&action->rename_to, "%s", amxc_string_get(node->rename_to, 0));
            action->action = RenamePathAction;
        } else {
            amxc_string_appendf(&action->rename_to, "%s.", pch);
        }
        pch = strtok_r(NULL, ".", &saveptr);
    }

    if(pch != NULL) {
        amxc_string_appendf(&action->rename_to, "%s.", pch);
    }

    if((saveptr != NULL) && (*saveptr != '\0')) {
        amxc_string_appendf(&action->rename_to, "%s", saveptr);
    }

    if(action->action == RenamePathAction) {
        size_t length = amxc_string_text_length(&action->rename_to);
        if(length == 0) {
            SAH_TRACEZ_WARNING(ME, "Action is rename, but renamed length is '0'");
            goto exit;
        }
        if(*amxc_string_get(&action->rename_to, length - 1) != '.') {
            amxc_string_append(&action->rename_to, ".", 1);
        }
    }


exit:
    return node;
}

PathAction translate_nonterminal_path(const TreeNode* root, const char* nonterminals_path) {
    PathAction action;
    action.action = NoActionPathAction;
    amxc_string_init(&action.rename_to, 0);
    action.node = NULL;

    char nonterminals_path_copy[MAX_PATH_LEN];
    snprintf(nonterminals_path_copy, sizeof(nonterminals_path_copy), "%s", nonterminals_path);

    const TreeNode* node = find_object_build_result_path(root, nonterminals_path_copy, &action);
    action.node = node;
    return action;
}

/**
 * @brief Retrieves a TreeNode from the given hash table by its key
 *
 * @param[in] table Hash table to search in
 * @param[in] key Key of the TreeNode to search for
 *
 * @return TreeNode* The TreeNode associated with the given key, or NULL if not found
 */
static const TreeNode* get_node_from_htable(
    const amxc_htable_t* table,
    const char* key
    ) {
    const TreeNode* ret = NULL;

    amxc_htable_it_t* it = amxc_htable_get(table, key);
    when_null(it, exit);

    // Both terminals and non-terminals are referenced by hit
    ret = amxc_htable_it_get_data(it, TreeNode, hit);

exit:
    return ret;
}


/**
 * @brief Find the end of a name in a given path
 *
 * @param[in] path Path to search for the end of a name
 *
 * @return const char* Pointer to the end of the name in the path, or NULL if no name is present
 *
 * @details the name is defined as [A-Za-z_] [A-Za-z_0-9-]*
 * @note TR-369 does not support '-' in names, but we do
 */
static const char* find_name_end(const char* path) {
    if(!(isalnum(*path) || (*path == '_'))) {
        return NULL;
    }

    const char* end = path + 1;
    while(isalnum(*end) || *end == '_' || *end == '-') {
        end++;
    }

    return end;
}

/**
 * @brief Skips over whitespace characters in a string, updating the pointer
 *
 * @param[in,out] str Pointer to the pointer to the string to skip over
 * @param[out] translated Translated string
 */
static void skip_whitespaces(const char** str, amxc_string_t* translated) {
    while(isspace(**str)) {
        amxc_string_append(translated, (*str)++, 1);
    }
}

/**
 * @brief Translate expression component (::= relpath oper value)
 *
 * @param[in] fwd Forward trie node of the multiinstance object
 * @param[in] bwd Backward trie node of the multiinstance object
 * @param[in,out] exprcomp Expression component to translate
 * @param[out] translated Translated string
 *
 * @return amxd_status_ok if no error happened,
 *         or error code indicating the entity which caused it
 *
 * @note *exprcomp is updated to point past the value.
 *       Consumes whitespaces before/after the exprcomp
 */
static amxd_status_t translate_exprcomp(
    const TreeNode* fwd,
    const TreeNode* bwd,
    const char** exprcomp,
    amxc_string_t* translated
    ) {
    char name[MAX_PATH_LEN];

    skip_whitespaces(exprcomp, translated);

    // relpath   ::= name (reffollow? '.' name )*
    // but IDK how should reffollows in search expressions work,
    // they do not seem to work in ba-cli (with ubus)
    // so I'll exit the loop when I see the first reffollow
    while(isalnum(**exprcomp) || **exprcomp == '_') {
        const char* name_end = find_name_end(*exprcomp);

        size_t name_len = name_end - *exprcomp;
        memcpy(name, *exprcomp, name_len);
        name[name_len] = '\0';

        bool is_terminal_or_refollow = *name_end != '.';
        const amxc_htable_t* fwd_htable;
        const amxc_htable_t* bwd_htable;
        if(fwd) {
            fwd_htable = is_terminal_or_refollow ? &fwd->terminals : &fwd->nonterminals;
        }
        if(bwd) {
            bwd_htable = is_terminal_or_refollow ? &bwd->terminals : &bwd->nonterminals;
        }

        // handle renaming
        const TreeNode* new_fwd = fwd ? get_node_from_htable(fwd_htable, name) : NULL;
        if(new_fwd && (new_fwd->action == NodeAction_Rename)) {
            const char* rename_to = amxc_string_get(new_fwd->rename_to, 0);
            size_t rename_to_len = amxc_string_text_length(new_fwd->rename_to);
            amxc_string_append(translated, rename_to, rename_to_len);

            memcpy(name, rename_to, rename_to_len - !is_terminal_or_refollow);
            name[rename_to_len - !is_terminal_or_refollow] = '\0';

            fwd = new_fwd;
            bwd = get_node_from_htable(bwd_htable, name);
        } else {
            // Check if uses original name or is hidden
            const TreeNode* new_bwd = bwd ? get_node_from_htable(bwd_htable, name) : NULL;
            if(new_bwd && ((new_bwd->action == NodeAction_Rename) || (new_bwd->action == NodeAction_Hide))) {
                return is_terminal_or_refollow ? amxd_status_parameter_not_found : amxd_status_object_not_found;
            }

            // Use the original name
            amxc_string_appendf(translated, "%s", name);
            if(!is_terminal_or_refollow) {
                amxc_string_append(translated, ".", 1);
            }
        }

        (*exprcomp) = name_end + !is_terminal_or_refollow;
        if(is_terminal_or_refollow) {
            break;
        }
    }

    // we might have exited the loop because of a reffollow
    // so we can't just skip whitespaces, we have to copy everything until
    // oper      ::= '==' | '!=' | '~=' | '<' | '>' | '<=' | '>='
#define OPER_CHARS "=!~<>"
    while(!strchr(OPER_CHARS, **exprcomp)) {
        amxc_string_append(translated, (*exprcomp)++, 1);
    }
    // then copy the oper
    while(strchr(OPER_CHARS, **exprcomp)) {
        amxc_string_append(translated, (*exprcomp)++, 1);
    }
#undef OPER_CHARS

    skip_whitespaces(exprcomp, translated);

    // copy the value, which is either a string or a number
    if(isdigit(**exprcomp) || (**exprcomp == '-')) {
        amxc_string_append(translated, (*exprcomp)++, 1);
        while(isdigit(**exprcomp)) {
            amxc_string_append(translated, (*exprcomp)++, 1);
        }
    } else if((**exprcomp == '"') || (**exprcomp == '\'')) {
        char open_quote = **exprcomp;
        amxc_string_append(translated, (*exprcomp)++, 1);

        while(**exprcomp != open_quote) {
            bool escape = **exprcomp == '\\';
            amxc_string_append(translated, *exprcomp, 1 + escape);
            (*exprcomp) += 1 + escape;
        }

        amxc_string_append(translated, (*exprcomp)++, 1);
    } else { // ubus can have unquoted strings
        while(!strchr("&]", **exprcomp)) {
            amxc_string_append(translated, (*exprcomp)++, 1);
        }
    }

    skip_whitespaces(exprcomp, translated);

    return amxd_status_ok;
}

/**
 * @brief Translate an expression (::= '[' (exprcomp ( '&&' exprcomp )*) ']')
 *
 * @param[in] fwd Forward trie node of the multiinstance object
 * @param[in] bwd Backward trie node of the multiinstance object
 * @param[in,out] expr Expression to translate
 * @param[out] translated Translated string
 *
 * @return amxd_status_ok if no error happened,
 *         or error code indicating the entity which caused it
 *
 * @note *expr is updated to point past the ']'
 */
static amxd_status_t translate_expr(
    const TreeNode* fwd,
    const TreeNode* bwd,
    const char** expr,
    amxc_string_t* translated
    ) {
    amxc_string_append(translated, (*expr)++, 1); // consume '['

    do {
        amxd_status_t ret = translate_exprcomp(fwd, bwd, expr, translated);
        if(ret != amxd_status_ok) {
            return ret;
        }

        if(**expr == ']') {
            break;
        }

        if(**expr == '&') {
            amxc_string_append(translated, "&&", 2);
            (*expr) += 2; // consume '&&'
        }
    } while(true);

    amxc_string_append(translated, (*expr)++, 1); // consume ']'

    return amxd_status_ok;
}

TranslateReqResult translate_nonterminal_request_path(
    const TreeNode* forward_root,
    const TreeNode* backward_root,
    const char* objpath // ::= name '.' (name (('.' inst)|(reffollow '.' name) )? '.')*
    ) {
    TranslateReqResult ret = { .status = amxd_status_ok, .fwd_node = NULL };
    amxc_string_init(&ret.translated, 0);

    char name[MAX_PATH_LEN];

    // name '.'
    // i.e. the first name (the root) shall always exist
    const char* name_end = find_name_end(objpath);
    if(!name_end || (*name_end != '.')) {
        ret.status = amxd_status_invalid_arg;
        goto exit;
    }
    size_t name_len = name_end - objpath;
    memcpy(name, objpath, name_len);
    name[name_len] = '\0';

    const TreeNode* fwd = get_node_from_htable(&forward_root->nonterminals, name);
    const TreeNode* bwd = get_node_from_htable(&backward_root->nonterminals, name);
    if(!fwd || !bwd) {
        ret.status = amxd_status_invalid_arg;
        goto exit;
    }

    // root is never renamed
    amxc_string_append(&ret.translated, objpath, name_len + 1);
    objpath += name_len + 1;

    // (name (('.' inst)|(reffollow '.' name) )? '.')*
    // i.e. the repeating 0+ times part
    while(*objpath) {
        name_end = find_name_end(objpath);
        if(!name_end) {
            ret.status = amxd_status_invalid_arg;
            goto exit;
        }
        name_len = name_end - objpath;
        memcpy(name, objpath, name_len);
        name[name_len] = '\0';

        // handle renaming
        const TreeNode* new_fwd = fwd ? get_node_from_htable(&fwd->nonterminals, name) : NULL;
        if(new_fwd && (new_fwd->action == NodeAction_Rename)) {
            const char* rename_to = amxc_string_get(new_fwd->rename_to, 0);
            size_t rename_to_len = amxc_string_text_length(new_fwd->rename_to);
            amxc_string_append(&ret.translated, rename_to, rename_to_len);

            memcpy(name, rename_to, rename_to_len - 1);
            name[rename_to_len - 1] = '\0';

            ret.fwd_node = fwd = new_fwd;
            ret.bwd_node = bwd = get_node_from_htable(&bwd->nonterminals, name);
        } else {
            // Check if uses original name or is hidden
            const TreeNode* new_bwd = get_node_from_htable(&bwd->nonterminals, name);
            if(new_bwd && ((new_bwd->action == NodeAction_Rename) || (new_bwd->action == NodeAction_Hide))) {
                ret.status = amxd_status_object_not_found;
                goto exit;
            }

            if(!new_fwd && !new_bwd) {
                // Renamings have ended, append the rest as-is
                amxc_string_appendf(&ret.translated, "%s", objpath);
                ret.fwd_node = ret.bwd_node = NULL;
                goto exit;
            }
            // Use the original name
            amxc_string_appendf(&ret.translated, "%s.", name);
            ret.fwd_node = fwd = new_fwd;
            ret.bwd_node = bwd = new_bwd;
        }

        objpath += name_len + 1;

        // (('.' inst)|(reffollow '.' name) )?
        // but reffolows are resolved by the caller
        // so we don't see them
        // so need to check only for inst
        if(((fwd && fwd->is_multiinstance) || (bwd && bwd->is_multiinstance)) && *(name_end + 1)) {
            // '.' inst
            // i.e. we have inst optional part
            // inst ::= posnum | expr | '*'
            const char* inst = name_end + 1;

            if(*inst == '[') { // expr
                if((ret.status = translate_expr(fwd, bwd, &inst, &ret.translated)) != amxd_status_ok) {
                    goto exit;
                }
                amxc_string_append(&ret.translated, ".", 1);
            } else { // posnum | '*'
                while(*inst != '.') {
                    inst++;
                }
                amxc_string_append(&ret.translated, name_end + 1, inst - name_end);
            }

            objpath = inst + 1;
        }
    }

exit:
    return ret;
}

/**
 * @brief Type of direct child of the object
 */
enum DirectChild {
    FunctionDirectChild,    /*!< Direct child that is a function (with no suffix) */
    EventDirectChild,       /*!< Direct child that is an event (with no suffix) */
    TerminalDirectChild,    /*!< Direct child that is a terminal (paramter/event/function, with suffix)*/
    NonTerminalDirectChild  /*!< Direct child that is a nonterminal (object)*/
};

/**
 * @brief Translate direct child (any kind) of the object
 *
 * @param[in] children hashtable of children nodes to use
 * @param[in] name name of the direct child
 * @param[in,out] action action to fill
 * @param[in] child_type type of the child to translate
 */
static void translate_direct_child(const amxc_htable_t* children, const char* name, PathAction* action, enum DirectChild child_type) {
    when_null(children, exit);
    when_null(name, exit);
    when_null(action, exit);

    amxc_htable_it_t* terminal_node_it = amxc_htable_get(children, name);
    if(terminal_node_it == NULL) {
        goto exit;
    }

    switch(child_type) {
    case FunctionDirectChild:
        action->node = amxc_htable_it_get_data(terminal_node_it, TreeNode, hit_function);
        break;
    case EventDirectChild:
        action->node = amxc_htable_it_get_data(terminal_node_it, TreeNode, hit_event);
        break;
    case TerminalDirectChild:
    case NonTerminalDirectChild:
        action->node = amxc_htable_it_get_data(terminal_node_it, TreeNode, hit);
        break;
    }

    switch(action->node->action) {
    case NodeAction_Hide:
        action->action = HidePathAction;
        break;
    case NodeAction_Rename:
        switch(child_type) {
        case FunctionDirectChild:
        case EventDirectChild:
            amxc_string_set(&action->rename_to, amxc_string_get(action->node->rename_to_no_suffix, 0));
            break;
        case TerminalDirectChild:
        case NonTerminalDirectChild:
            amxc_string_set(&action->rename_to, amxc_string_get(action->node->rename_to, 0));
            break;
        }

        action->action = RenamePathAction;
        break;
    default:
        action->action = NoActionPathAction;
        break;
    }

exit:
    return;
}

PathAction translate_nonterminal_name(const TreeNode* object_node, const char* nonterminal_name) {
    PathAction action;
    action.action = NoActionPathAction;
    amxc_string_init(&action.rename_to, 0);
    action.node = NULL;

    when_null(object_node, exit);
    when_null(nonterminal_name, exit);

    translate_direct_child(&object_node->nonterminals, nonterminal_name, &action, NonTerminalDirectChild);

exit:
    return action;
}

void print_path_action(PathAction action) {
    const char* action_str = NULL;
    switch(action.action) {
    case HidePathAction:
        action_str = "hide";
        break;
    case RenamePathAction:
        action_str = "rename";
        break;
    default:
        action_str = "none";
        break;
    }

    SAH_TRACEZ_ERROR(ME, "Action is %s, renamed to '%s'", action_str, amxc_string_get(&action.rename_to, 0));
}

/**
 * @brief get default (empty) path action
 *
 * @return PathAction with action= no action, empty node and rename_to fileds
 */
static PathAction empty_path_action() {
    PathAction action;
    action.action = NoActionPathAction;
    amxc_string_init(&action.rename_to, 0);
    action.node = NULL;

    return action;
}

/**
 * @brief Translate name (direct child) of the object
 *
 * @param[in] name name of the direct child
 * @param[in] map hashtable of children nodes to use
 * @param[in] child_type type of the child to translate
 *
 * @return PathAction for the name
 */
static PathAction translate_name(const char* name, const amxc_htable_t* map, enum DirectChild child_type) {
    PathAction action = empty_path_action();

    when_null(name, exit);
    when_null(map, exit);

    translate_direct_child(map, name, &action, child_type);

exit:
    return action;
}

PathAction translate_terminal_name(const TreeNode* object_node, const char* terminal_name) {
    if(!object_node) {
        return empty_path_action();
    }

    return translate_name(terminal_name, &object_node->terminals, TerminalDirectChild);
}

PathAction translate_event_name(const TreeNode* object_node, const char* event_name) {
    if(!object_node) {
        return empty_path_action();
    }

    return translate_name(event_name, &object_node->terminals, EventDirectChild);
}

PathAction translate_rpc_name(const TreeNode* object_node, const char* rpc_name) {
    if(!object_node) {
        return empty_path_action();
    }
    return translate_name(rpc_name, &object_node->functions, FunctionDirectChild);
}

/**
 * @brief translate child nonterminals that are stored inside a map
 *
 * @param[in,out] response_map response map that contains child terminals
 * @param[in] object_node object node to the object that holds mapping to the nonterminal
 * @param[in] translator function used to get path action for each terminal
 * @param[in] change_name_param whether to change name parameter of each terminal (e.g. not only key but also 'name' parameter)
 */
static void translate_map(amxc_var_t* response_map, const TreeNode* object_node, dmm_translator_f translator, bool change_name_param) {
    when_null(response_map, exit);

    amxc_var_type_id_t type = amxc_var_type_of(response_map);
    amxc_var_t* response_map_tmp;
    amxc_var_new(&response_map_tmp);

    amxc_var_move(response_map_tmp, response_map);

    amxc_var_set_type(response_map, type);

    amxc_var_for_each(response_element, response_map_tmp) {
        const char* terminal_name = "";
        if(type == AMXC_VAR_ID_HTABLE) {
            terminal_name = amxc_var_key(response_element);
        }
        if(type == AMXC_VAR_ID_LIST) {
            terminal_name = GET_CHAR(response_element, NULL);
        }

        PathAction action = translator(object_node, terminal_name);

        switch(action.action) {
        case HidePathAction:
            // just dont move it
            break;
        case RenamePathAction:
            if(type == AMXC_VAR_ID_HTABLE) {
                amxc_var_take_it(response_element);
                amxc_var_set_key(response_map, amxc_string_get(&action.rename_to, 0), response_element, AMXC_VAR_FLAG_DEFAULT);
            }
            if(type == AMXC_VAR_ID_LIST) {
                amxc_var_set(cstring_t, response_element, amxc_string_get(&action.rename_to, 0));
                amxc_var_add_value(response_map, response_element);
            }
            if(!change_name_param) {
                break;
            }
            amxc_var_t* name = GET_ARG(response_element, "name");
            amxc_var_set(cstring_t, name, amxc_string_get(&action.rename_to, 0));
            break;
        default:
            if(type == AMXC_VAR_ID_HTABLE) {
                amxc_var_take_it(response_element);
                amxc_var_set_key(response_map, terminal_name, response_element, AMXC_VAR_FLAG_DEFAULT);
            }
            if(type == AMXC_VAR_ID_LIST) {
                amxc_var_add_value(response_map, response_element);
            }
            break;
        }

        clean_path_action(&action);
    }

    amxc_var_delete(&response_map_tmp);

exit:
    return;
}

/**
 * @brief translate child terminals that are stored inside a map
 *
 * @param[in,out] terminals response map that contains child terminals
 * @param[in] object_node object node to the object that holds mapping to the nonterminal
 * @param[in] change_name_param whether to change name parameter of each terminal (e.g. not only key but also 'name' parameter)
 */
static void translate_terminals_map(amxc_var_t* terminals, const TreeNode* object_node, bool change_name_param) {
    translate_map(terminals, object_node, translate_terminal_name, change_name_param);
}

/**
 * @brief translate child functions that are stored inside a map
 *
 * @param[in,out] terminals response map that contains child terminals
 * @param[in] object_node object node to the object that holds mapping to the nonterminal
 * @param[in] change_name_param whether to change name parameter of each terminal (e.g. not only key but also 'name' parameter)
 */
static void translate_functions_map(amxc_var_t* terminals, const TreeNode* object_node, bool change_name_param) {
    translate_map(terminals, object_node, translate_rpc_name, change_name_param);
}

/**
 * @brief translate child terminals that are stored inside a list (e.g. object with 'name' attr)
 *
 * @param[in,out] terminal_list response map that contains child terminals
 * @param[in] name name attr that stores name of the terminal
 * @param[in] object_node object node to the object that holds mapping to the nonterminal
 */
static void translate_get_supported_terminal_list_with_name(amxc_var_t* terminal_list, const char* name, const TreeNode* object_node) {
    when_null(terminal_list, exit);
    when_null(name, exit);
    when_null(object_node, exit);

    amxc_var_for_each(terminal, terminal_list) {
        amxc_var_t* name_var = GET_ARG(terminal, name);
        if(!name_var) {
            continue;
        }

        const char* original_name = GET_CHAR(terminal, name);
        if(!original_name) {
            continue;
        }

        PathAction terminal_action = translate_terminal_name(object_node, original_name);

        switch(terminal_action.action) {
        case HidePathAction:
            amxc_var_delete(&terminal);
            break;
        case RenamePathAction:
            amxc_var_set(cstring_t, name_var, amxc_string_get(&terminal_action.rename_to, 0));
            break;
        default:
            break;
        }
        clean_path_action(&terminal_action);
    }
exit:
    return;
}

int translate_get_supported_response(amxc_var_t* response) {
    int rc = 1;

    amxc_var_t* response_tmp;
    amxc_var_new(&response_tmp);
    amxc_var_move(response_tmp, response);

    amxc_var_set_type(response, AMXC_VAR_ID_HTABLE);

    amxc_var_for_each(object, response_tmp) {
        // canonical (original) path
        const char* original_object_name = amxc_var_key(object);
        const char* renamed_object_name = original_object_name;

        PathAction object_action = translate_nonterminal_path(&backward_tree, original_object_name);

        // if nothing to be done with object and its parameters continue
        if((object_action.action == NoActionPathAction) && !object_action.node) {
            goto move_object;
        }

        // if object to be hidden --- remove it from the response
        if(object_action.action == HidePathAction) {
            amxc_var_delete(&object);
            goto clean_object_action;
        }

        if(object_action.action == RenamePathAction) {
            renamed_object_name = amxc_string_get(&object_action.rename_to, 0);
        }

        if(!object_action.node) {
            goto move_object;
        }

        translate_get_supported_terminal_list_with_name(GET_ARG(object, "supported_params"), "param_name", object_action.node);
        translate_get_supported_terminal_list_with_name(GET_ARG(object, "supported_commands"), "command_name", object_action.node);
        translate_terminals_map(GET_ARG(object, "supported_events"), object_action.node, false);

move_object:
        amxc_var_take_it(object);
        amxc_var_set_key(response, renamed_object_name, object, AMXC_VAR_FLAG_DEFAULT);

clean_object_action:
        clean_path_action(&object_action);
        continue;
    }

    amxc_var_delete(&response_tmp);

    rc = 0;

exit:
    return rc;
}

int translate_get_response(amxc_var_t* response) {
    int rc = 1;

    amxc_var_t* response_tmp;
    amxc_var_new(&response_tmp);
    amxc_var_move(response_tmp, response);

    amxc_var_set_type(response, AMXC_VAR_ID_HTABLE);

    amxc_var_for_each(object, response_tmp) {
        // canonical (original) path
        const char* original_object_name = amxc_var_key(object);
        const char* renamed_object_name = original_object_name;

        PathAction object_action = translate_nonterminal_path(&backward_tree, original_object_name);

        // if nothing to be done with object and its parameters continue
        if((object_action.action == NoActionPathAction) && !object_action.node) {
            goto move_object;
        }

        // if object to be hidden --- remove it from the response
        if(object_action.action == HidePathAction) {
            amxc_var_delete(&object);
            goto clean_object_action;
        }

        if(object_action.action == RenamePathAction) {
            renamed_object_name = amxc_string_get(&object_action.rename_to, 0);
        }

        if(!object_action.node) {
            goto move_object;
        }

        translate_terminals_map(object, object_action.node, false);

move_object:
        amxc_var_take_it(object);
        amxc_var_set_key(response, renamed_object_name, object, AMXC_VAR_FLAG_DEFAULT);

clean_object_action:
        clean_path_action(&object_action);
        continue;
    }

    amxc_var_delete(&response_tmp);

    rc = 0;

exit:
    return rc;
}

int translate_set_response(amxc_var_t* response) {
    return translate_get_response(response);
}

int translate_get_instances_response(amxc_var_t* response) {
    return translate_get_response(response);
}

int translate_add_response(amxc_var_t* response) {
    int rc = 1;

    amxc_var_t* path_arg = GET_ARG(response, "path");
    when_null_trace(path_arg, exit, WARNING, "Processing add response, but no 'path' found");

    const char* path = GET_CHAR(path_arg, NULL);
    when_null_trace(path, exit, WARNING, "Processing add response, but 'path' is not a cstring");

    PathAction path_action = translate_nonterminal_path(&backward_tree, path);

    // if nothing to be done with object and its parameters continue
    if((path_action.action == NoActionPathAction) && !path_action.node) {
        rc = 0;
        goto exit;
    }

    // should in fact be cleared out when processing request
    if(path_action.action == HidePathAction) {
        SAH_TRACEZ_WARNING(ME, "Translated '%s' path should have been hidden in the first place", path);
        amxc_var_set_type(response, AMXC_VAR_ID_NULL);
        rc = 0;
        goto clean_action;
    }

    if(path_action.action == RenamePathAction) {
        amxc_var_set(cstring_t, path_arg, amxc_string_get(&path_action.rename_to, 0));
        {
            amxc_var_t* object_arg = GET_ARG(response, "object");
            when_null_trace(object_arg, clean_action, WARNING, "Processing add response, but no 'object' found");

            const char* object = GET_CHAR(object_arg, NULL);
            when_null_trace(object, clean_action, WARNING, "Processing add response, but 'object' is not a cstring");

            PathAction object_action = translate_nonterminal_path(&backward_tree, object);

            if(object_action.action != RenamePathAction) {
                SAH_TRACEZ_WARNING(ME, "action for 'path' is rename, but action for object is '%d'", object_action.action);
                clean_path_action(&object_action);
                goto clean_action;
            }

            amxc_var_set(cstring_t, object_arg, amxc_string_get(&object_action.rename_to, 0));
            clean_path_action(&object_action);
        }
    }

    translate_terminals_map(GET_ARG(response, "parameters"), path_action.node, false);

    rc = 0;

clean_action:
    clean_path_action(&path_action);

exit:
    return rc;
}

int translate_del_response(amxc_var_t* response) {
    amxc_var_for_each(object, response) {
        // canonical (original) path
        const char* deleted_path = amxc_var_constcast(cstring_t, object);
        if(!deleted_path) {
            SAH_TRACEZ_WARNING(ME, "Cannot get path for delete response");
            continue;
        }

        PathAction deleted_path_action = translate_nonterminal_path(&backward_tree, deleted_path);
        switch(deleted_path_action.action) {
        case RenamePathAction:
            amxc_var_set(cstring_t, object, amxc_string_get(&deleted_path_action.rename_to, 0));
            break;
        case HidePathAction:
            amxc_var_delete(&object);
            break;
        case NoActionPathAction:
            break;
        }
        clean_path_action(&deleted_path_action);
    }

    return 0;
}


/**
 * @brief Translate additional path parameter in the response
 *
 * @param response response to translate in
 * @param key key for the parameter
 *
 * @return 0 if no error happens
 */
static int translate_additional_rename_path(amxc_var_t* response, const char* key) {
    int rc = 1;
    amxc_var_t* object_arg = GET_ARG(response, key);
    when_null_trace(object_arg, exit, WARNING, "Processing add response, but no '%s' found", key);

    const char* object = GET_CHAR(object_arg, NULL);
    when_null_trace(object, exit, WARNING, "Processing add response, but '%s' is not a cstring", key);

    PathAction object_action = translate_nonterminal_path(&backward_tree, object);

    if(object_action.action != RenamePathAction) {
        SAH_TRACEZ_WARNING(ME, "action for 'path' is rename, but action for '%s' is '%d'", key, object_action.action);
        clean_path_action(&object_action);
        goto exit;
    }

    amxc_var_set(cstring_t, object_arg, amxc_string_get(&object_action.rename_to, 0));
    clean_path_action(&object_action);

    rc = 0;

exit:
    return rc;
}

int translate_event_response(amxc_var_t* response) {
    int rc = 1;

    amxc_var_t* path_arg = GET_ARG(response, "path");
    when_null_trace(path_arg, exit, WARNING, "Processing add response, but no 'path' found");

    const char* path = GET_CHAR(path_arg, NULL);
    when_null_trace(path, exit, WARNING, "Processing add response, but 'path' is not a cstring");

    PathAction path_action = translate_nonterminal_path(&backward_tree, path);

    // if nothing to be done with object and its parameters continue
    if((path_action.action == NoActionPathAction) && !path_action.node) {
        rc = 0;
        goto exit;
    }

    // should in fact be cleared out when processing request
    if(path_action.action == HidePathAction) {
        SAH_TRACEZ_WARNING(ME, "Translated '%s' path should have been hidden in the first place", path);
        amxc_var_set_type(response, AMXC_VAR_ID_NULL);
        rc = 0;
        goto clean_action;
    }

    if(path_action.action == RenamePathAction) {
        amxc_var_set(cstring_t, path_arg, amxc_string_get(&path_action.rename_to, 0));
        if(translate_additional_rename_path(response, "object")) {
            SAH_TRACEZ_WARNING(ME, "Failed to translate 'object'");
        }
        if(translate_additional_rename_path(response, "eobject")) {
            SAH_TRACEZ_WARNING(ME, "Failed to translate 'eobject'");
        }
    }

    translate_terminals_map(GET_ARG(response, "parameters"), path_action.node, false);
    translate_terminals_map(GET_ARG(response, "keys"), path_action.node, false);

    rc = 0;

clean_action:
    clean_path_action(&path_action);

exit:
    return rc;
}

int translate_list_response(const TreeNode* backward_node, amxc_var_t* response) {
    if(!backward_node) {
        return 0;
    }

    translate_map(GET_ARG(response, "events"), backward_node, translate_terminal_name, false);
    translate_map(GET_ARG(response, "functions"), backward_node, translate_rpc_name, false);
    translate_map(GET_ARG(response, "objects"), backward_node, translate_nonterminal_name, false);
    translate_map(GET_ARG(response, "parameters"), backward_node, translate_terminal_name, false);

    return 0;
}

int translate_describe_response(amxc_var_t* response) {
    int rc = 1;

    amxc_var_t* path_arg = GET_ARG(response, "path");
    when_null_trace(path_arg, exit, WARNING, "Processing describe response, but no 'path' found");

    const char* path = GET_CHAR(path_arg, NULL);
    when_null_trace(path, exit, WARNING, "Processing describe response, but 'path' is not a cstring");

    PathAction path_action = translate_nonterminal_path(&backward_tree, path);

    // if nothing to be done with object and its parameters continue
    if((path_action.action == NoActionPathAction) && !path_action.node) {
        rc = 0;
        goto clean_action;
    }

    // should in fact be cleared out when processing request
    if(path_action.action == HidePathAction) {
        SAH_TRACEZ_WARNING(ME, "Translated '%s' path should have been hidden in the first place", path);
        amxc_var_set_type(response, AMXC_VAR_ID_NULL);
        rc = 0;
        goto clean_action;
    }

    if(path_action.action == RenamePathAction) {
        amxc_var_set(cstring_t, path_arg, amxc_string_get(&path_action.rename_to, 0));
        amxc_var_t* object_arg = GET_ARG(response, "object");
        when_null_trace(object_arg, clean_action, WARNING, "Processing describe response, but no 'object' found");

        const char* object = GET_CHAR(object_arg, NULL);
        when_null_trace(object, clean_action, WARNING, "Processing describe response, but 'object' is not a cstring");

        PathAction object_action = translate_nonterminal_path(&backward_tree, object);

        if(object_action.action != RenamePathAction) {
            SAH_TRACEZ_WARNING(ME, "action for 'path' is rename, but action for object is '%d'", object_action.action);
            clean_path_action(&object_action);
            goto clean_action;
        }

        amxc_var_set(cstring_t, object_arg, amxc_string_get(&object_action.rename_to, 0));
        clean_path_action(&object_action);

        amxc_var_t* name = GET_ARG(response, "name");
        amxc_var_set(cstring_t, name, amxc_string_get(path_action.node->rename_to_no_suffix, 0));
    }

    translate_terminals_map(GET_ARG(response, "parameters"), path_action.node, true);
    translate_terminals_map(GET_ARG(response, "events"), path_action.node, false);
    translate_functions_map(GET_ARG(response, "functions"), path_action.node, true);
    translate_map(GET_ARG(response, "objects"), path_action.node, translate_nonterminal_name, false);

    rc = 0;

clean_action:
    clean_path_action(&path_action);

exit:
    return rc;
}

