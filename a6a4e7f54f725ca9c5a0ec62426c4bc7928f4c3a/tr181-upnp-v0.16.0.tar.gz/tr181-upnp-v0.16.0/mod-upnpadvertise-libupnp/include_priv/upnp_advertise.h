/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __MOD_UPNP_ADVERTISE_H__
#define __MOD_UPNP_ADVERTISE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define BASE_RESTART_TIME 1000
#define MAX_RESTART_TIME 32000
#define UPNPADVERT_FIREWALL_LISTEN_RULE "tr181-upnpadvert-listen"

/**
 * @brief Module initialization function for the UPnP plugin.
 *
 * This function initializes variables and timers needed for the module,
 * including the root devices variable, interface string, and restart timer.
 */
void module_init(void);

/**
 * @brief Module cleanup function for the UPnP plugin.
 *
 * This function stops advertising if active, closes network queries,
 * cleans up variables, deletes timers, and releases resources.
 */
void module_exit(void);

/**
 * @brief Starts the UPnP advertising process.
 *
 * This function initializes UPnP, registers root devices, and sends advertisements.
 * It handles network errors by scheduling retries with exponential backoff.
 *
 * @return Returns 0 on success, or a negative error code on failure.
 */
int start_advertising(void);

/**
 * @brief Stops the UPnP advertising process.
 *
 * This function finalizes UPnP operations, destroys related firewall rules,
 * and updates the advertising state flags.
 *
 * @return Returns the result of UpnpFinish(), typically 0 on success.
 */
int stop_advertising(void);

/**
 * @brief Initializes the plugin configuration.
 *
 * This function copies the provided configuration into the plugin's global configuration,
 * and opens a network query for the LAN address based on the configuration.
 *
 * @param config The configuration to initialize from.
 */
void init_config(amxc_var_t* config);

/**
 * @brief Converts an amxc_var_t variable to its XML string representation.
 *
 * This function serializes a variable of type AMXC_VAR_ID_HTABLE into XML format.
 * It handles nested tables and lists, and adds UUIDs for "device" elements.
 *
 * @param var The variable to convert, must be of type AMXC_VAR_ID_HTABLE.
 * @param output The string to append the XML representation to.
 * @return Returns 0 on success, or -1 if the variable type is incorrect.
 */
int amxc_var_to_xml_string(amxc_var_t* var, amxc_string_t* output);

/**
 * @brief Adds a new root device to the list.
 *
 * This function adds a root device with the specified "id" and "rootdevice" data to the root devices list.
 * If a device with the same "id" already exists, it is replaced.
 *
 * @param args Arguments containing "id" and "rootdevice" data.
 * @return Returns 0 on success, or -1 if required arguments are missing.
 */
int add_rootdevice(amxc_var_t* args);

/**
 * @brief Deletes a root device from the list.
 *
 * This function removes the root device identified by the "id" argument from the root devices list.
 *
 * @param args Arguments containing the "id" of the device to delete.
 * @return Returns 0 on success, or -1 if the arguments are invalid or the device does not exist.
 */
int del_rootdevice(amxc_var_t* args);

/**
 * @brief Sets the interface name used for advertising.
 *
 * This function updates the interface name string with the provided name.
 *
 * @param name The interface name to set.
 */
void set_advertise_intf_name(const char* name);

#ifdef __cplusplus
}
#endif

#endif // __MOD_UPNP_ADVERTISE_H__
