/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#if !defined(__LOGICAL_API_UTILS_H__)
#define __LOGICAL_API_UTILS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc.h>
#include <amxb/amxb.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_transaction.h>

#define str_empty(txt) ((txt == NULL) || (*txt == 0))
#define CLOSE_QUERY(Q) do { \
        if((Q != NULL) && (*Q != NULL)) { \
            netmodel_closeQuery(*Q); \
            *Q = NULL; \
        } \
} while(0);

amxc_var_t* find_addrs_by_flag(const char* intf, const char* flag);
amxc_var_t* htable_values_to_list(amxc_var_t* src);

amxb_bus_ctx_t* device_get_context(void);
amxb_bus_ctx_t* ra_get_context(void);
amxb_bus_ctx_t* dhcpv4_get_context(void);
amxb_bus_ctx_t* dhcpv6_get_context(void);
amxb_bus_ctx_t* bridging_get_context(void);
amxb_bus_ctx_t* routing_get_context(void);
amxb_bus_ctx_t* ip_get_context(void);

amxc_var_t* find_ip_intfs(const char* intf);
amxc_var_t* find_eth_link_intfs(const char* intf);
amxc_var_t* find_bridge_intfs(const char* intf);
amxc_var_t* find_gpon_intfs(const char* intf);
char* get_eth_link_intf(const char* intf);
char* get_bridge_intf(const char* intf);
char* get_ip_intf(const char* intf);
const char* get_gpon_intf(const char* link_type, amxc_var_t* intf_info);
bool get_status(const char* intf, bool gpon);
char* get_connection_status(const char* intf, bool ppp, bool v4);
char* get_last_conn_error(const char* intf);
char* get_ipv4_router(const char* intf);
char* get_ipv6prefix(const char* intf);

char* get_multi_instance_obj(const char* instance_obj_path);

const char* logical_get_prefix(void);

amxd_status_t trans_apply(amxd_trans_t* trans);
amxd_trans_t* trans_create(const amxd_object_t* const object);

bool iface_has_tag(amxd_object_t* iface_obj, const char* tag);

amxc_string_t* join_strings_csv(const char* str1, const char* str2);
const char* skip_prefix(const char* path);

#ifdef __cplusplus
}
#endif

#endif // __LOGICAL_API_UTILS_H__
