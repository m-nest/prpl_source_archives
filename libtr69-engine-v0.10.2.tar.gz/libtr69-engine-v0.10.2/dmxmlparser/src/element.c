/*
 * ----------------------------------------------------------------------------
 *                                 Apache License
 *                           Version 2.0, January 2004
 *                        http://www.apache.org/licenses/
 *
 *   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
 *
 *   1. Definitions.
 *
 *      "License" shall mean the terms and conditions for use, reproduction,
 *      and distribution as defined by Sections 1 through 9 of this document.
 *
 *      "Licensor" shall mean the copyright owner or entity authorized by
 *      the copyright owner that is granting the License.
 *
 *      "Legal Entity" shall mean the union of the acting entity and all
 *      other entities that control, are controlled by, or are under common
 *      control with that entity. For the purposes of this definition,
 *      "control" means (i) the power, direct or indirect, to cause the
 *      direction or management of such entity, whether by contract or
 *      otherwise, or (ii) ownership of fifty percent (50%) or more of the
 *      outstanding shares, or (iii) beneficial ownership of such entity.
 *
 *      "You" (or "Your") shall mean an individual or Legal Entity
 *      exercising permissions granted by this License.
 *
 *      "Source" form shall mean the preferred form for making modifications,
 *      including but not limited to software source code, documentation
 *      source, and configuration files.
 *
 *      "Object" form shall mean any form resulting from mechanical
 *      transformation or translation of a Source form, including but
 *      not limited to compiled object code, generated documentation,
 *      and conversions to other media types.
 *
 *      "Work" shall mean the work of authorship, whether in Source or
 *      Object form, made available under the License, as indicated by a
 *      copyright notice that is included in or attached to the work
 *      (an example is provided in the Appendix below).
 *
 *      "Derivative Works" shall mean any work, whether in Source or Object
 *      form, that is based on (or derived from) the Work and for which the
 *      editorial revisions, annotations, elaborations, or other modifications
 *      represent, as a whole, an original work of authorship. For the purposes
 *      of this License, Derivative Works shall not include works that remain
 *      separable from, or merely link (or bind by name) to the interfaces of,
 *      the Work and Derivative Works thereof.
 *
 *      "Contribution" shall mean any work of authorship, including
 *      the original version of the Work and any modifications or additions
 *      to that Work or Derivative Works thereof, that is intentionally
 *      submitted to Licensor for inclusion in the Work by the copyright owner
 *      or by an individual or Legal Entity authorized to submit on behalf of
 *      the copyright owner. For the purposes of this definition, "submitted"
 *      means any form of electronic, verbal, or written communication sent
 *      to the Licensor or its representatives, including but not limited to
 *      communication on electronic mailing lists, source code control systems,
 *      and issue tracking systems that are managed by, or on behalf of, the
 *      Licensor for the purpose of discussing and improving the Work, but
 *      excluding communication that is conspicuously marked or otherwise
 *      designated in writing by the copyright owner as "Not a Contribution."
 *
 *      "Contributor" shall mean Licensor and any individual or Legal Entity
 *      on behalf of whom a Contribution has been received by Licensor and
 *      subsequently incorporated within the Work.
 *
 *   2. Grant of Copyright License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      copyright license to reproduce, prepare Derivative Works of,
 *      publicly display, publicly perform, sublicense, and distribute the
 *      Work and such Derivative Works in Source or Object form.
 *
 *   3. Grant of Patent License. Subject to the terms and conditions of
 *      this License, each Contributor hereby grants to You a perpetual,
 *      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
 *      (except as stated in this section) patent license to make, have made,
 *      use, offer to sell, sell, import, and otherwise transfer the Work,
 *      where such license applies only to those patent claims licensable
 *      by such Contributor that are necessarily infringed by their
 *      Contribution(s) alone or by combination of their Contribution(s)
 *      with the Work to which such Contribution(s) was submitted. If You
 *      institute patent litigation against any entity (including a
 *      cross-claim or counterclaim in a lawsuit) alleging that the Work
 *      or a Contribution incorporated within the Work constitutes direct
 *      or contributory patent infringement, then any patent licenses
 *      granted to You under this License for that Work shall terminate
 *      as of the date such litigation is filed.
 *
 *   4. Redistribution. You may reproduce and distribute copies of the
 *      Work or Derivative Works thereof in any medium, with or without
 *      modifications, and in Source or Object form, provided that You
 *      meet the following conditions:
 *
 *      (a) You must give any other recipients of the Work or
 *          Derivative Works a copy of this License; and
 *
 *      (b) You must cause any modified files to carry prominent notices
 *          stating that You changed the files; and
 *
 *      (c) You must retain, in the Source form of any Derivative Works
 *          that You distribute, all copyright, patent, trademark, and
 *          attribution notices from the Source form of the Work,
 *          excluding those notices that do not pertain to any part of
 *          the Derivative Works; and
 *
 *      (d) If the Work includes a "NOTICE" text file as part of its
 *          distribution, then any Derivative Works that You distribute must
 *          include a readable copy of the attribution notices contained
 *          within such NOTICE file, excluding those notices that do not
 *          pertain to any part of the Derivative Works, in at least one
 *          of the following places: within a NOTICE text file distributed
 *          as part of the Derivative Works; within the Source form or
 *          documentation, if provided along with the Derivative Works; or,
 *          within a display generated by the Derivative Works, if and
 *          wherever such third-party notices normally appear. The contents
 *          of the NOTICE file are for informational purposes only and
 *          do not modify the License. You may add Your own attribution
 *          notices within Derivative Works that You distribute, alongside
 *          or as an addendum to the NOTICE text from the Work, provided
 *          that such additional attribution notices cannot be construed
 *          as modifying the License.
 *
 *      You may add Your own copyright statement to Your modifications and
 *      may provide additional or different license terms and conditions
 *      for use, reproduction, or distribution of Your modifications, or
 *      for any such Derivative Works as a whole, provided Your use,
 *      reproduction, and distribution of the Work otherwise complies with
 *      the conditions stated in this License.
 *
 *   5. Submission of Contributions. Unless You explicitly state otherwise,
 *      any Contribution intentionally submitted for inclusion in the Work
 *      by You to the Licensor shall be under the terms and conditions of
 *      this License, without any additional terms or conditions.
 *      Notwithstanding the above, nothing herein shall supersede or modify
 *      the terms of any separate license agreement you may have executed
 *      with Licensor regarding such Contributions.
 *
 *   6. Trademarks. This License does not grant permission to use the trade
 *      names, trademarks, service marks, or product names of the Licensor,
 *      except as required for reasonable and customary use in describing the
 *      origin of the Work and reproducing the content of the NOTICE file.
 *
 *   7. Disclaimer of Warranty. Unless required by applicable law or
 *      agreed to in writing, Licensor provides the Work (and each
 *      Contributor provides its Contributions) on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *      implied, including, without limitation, any warranties or conditions
 *      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
 *      PARTICULAR PURPOSE. You are solely responsible for determining the
 *      appropriateness of using or redistributing the Work and assume any
 *      risks associated with Your exercise of permissions under this License.
 *
 *   8. Limitation of Liability. In no event and under no legal theory,
 *      whether in tort (including negligence), contract, or otherwise,
 *      unless required by applicable law (such as deliberate and grossly
 *      negligent acts) or agreed to in writing, shall any Contributor be
 *      liable to You for damages, including any direct, indirect, special,
 *      incidental, or consequential damages of any character arising as a
 *      result of this License or out of the use or inability to use the
 *      Work (including but not limited to damages for loss of goodwill,
 *      work stoppage, computer failure or malfunction, or any and all
 *      other commercial damages or losses), even if such Contributor
 *      has been advised of the possibility of such damages.
 *
 *   9. Accepting Warranty or Additional Liability. While redistributing
 *      the Work or Derivative Works thereof, You may choose to offer,
 *      and charge a fee for, acceptance of support, warranty, indemnity,
 *      or other liability obligations and/or rights consistent with this
 *      License. However, in accepting such obligations, You may act only
 *      on Your own behalf and on Your sole responsibility, not on behalf
 *      of any other Contributor, and only if You agree to indemnify,
 *      defend, and hold each Contributor harmless for any liability
 *      incurred by, or claims asserted against, such Contributor by reason
 *      of your accepting any such warranty or additional liability.
 *
 *   END OF TERMS AND CONDITIONS
 *
 *   APPENDIX: How to apply the Apache License to your work.
 *
 *      To apply the Apache License to your work, attach the following
 *      boilerplate notice, with the fields enclosed by brackets "[]"
 *      replaced with your own identifying information. (Don't include
 *      the brackets!)  The text should be enclosed in the appropriate
 *      comment syntax for the file format. We also recommend that a
 *      file or class name and description of purpose be included on the
 *      same "printed page" as the copyright notice for easier
 *      identification within third-party archives.
 *
 *   Copyright [2025] [SoftAtHome]
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 * ---------------------------------------------------------------------------
 */
///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2000-2003 Intel Corporation
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation
// and/or other materials provided with the distribution.
// * Neither name of Intel Corporation nor the names of its contributors
// may be used to endorse or promote products derived from this software
// without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////

#include <dmxmlparser/ixmlparser.h>

/*================================================================
 *   ixmlElement_Init
 *       Initializes an element node.
 *       External function.
 *
 *=================================================================*/
void
ixmlElement_init(IN IXML_Element* element) {
    if(element != NULL) {
        memset(element, 0, sizeof( IXML_Element ));
    }
}

/*================================================================
 *   ixmlElement_getTagName
 *       Gets the element node's tagName
 *       External function.
 *
 *=================================================================*/
const DOMString
ixmlElement_getTagName(IN IXML_Element* element) {

    if(element != NULL) {
        return element->tagName;
    } else {
        return NULL;
    }
}

/*================================================================
 *   ixmlElement_setTagName
 *       Sets the given element's tagName.
 *   Parameters:
 *       tagName: new tagName for the element.
 *
 *=================================================================*/
int
ixmlElement_setTagName(IN IXML_Element* element,
                       IN const char* tagName) {
    int rc = IXML_SUCCESS;

    assert(( element != NULL ) && ( tagName != NULL ));
    if(( element == NULL ) || ( tagName == NULL )) {
        return IXML_FAILED;
    }

    if(element->tagName != NULL) {
        free(element->tagName);
    }

    element->tagName = strdup(tagName);
    if(element->tagName == NULL) {
        rc = IXML_INSUFFICIENT_MEMORY;
    }

    return rc;

}

/*================================================================
 *   ixmlElement_getAttribute
 *       Retrievea an attribute value by name.
 *       External function.
 *   Parameters:
 *       name: the name of the attribute to retrieve.
 *   Return Values:
 *       attribute value as a string, or the empty string if that attribute
 *       does not have a specified value.
 *
 *=================================================================*/
const DOMString
ixmlElement_getAttribute(IN IXML_Element* element,
                         IN const DOMString name) {
    IXML_Node* attrNode;

    if(( element == NULL ) || ( name == NULL )) {
        return NULL;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, name) == 0) { // found it
            return attrNode->nodeValue;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return NULL;
}

/*================================================================
 *   ixmlElement_setAttribute
 *       Adds a new attribute.  If an attribute with that name is already
 *       present in the element, its value is changed to be that of the value
 *       parameter. If not, a new attribute is inserted into the element.
 *
 *       External function.
 *   Parameters:
 *       name: the name of the attribute to create or alter.
 *       value: value to set in string form
 *   Return Values:
 *       IXML_SUCCESS or failure code.
 *
 *=================================================================*/
int
ixmlElement_setAttribute(IN IXML_Element* element,
                         IN const char* name,
                         IN const char* value) {
    IXML_Node* attrNode;
    IXML_Attr* newAttrNode;
    short errCode = IXML_SUCCESS;

    if(( element == NULL ) || ( name == NULL ) || ( value == NULL )) {
        errCode = IXML_INVALID_PARAMETER;
        goto ErrorHandler;
    }

    if(Parser_isValidXmlName(name) == FALSE) {
        errCode = IXML_INVALID_CHARACTER_ERR;
        goto ErrorHandler;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, name) == 0) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode == NULL) {  // add a new attribute
        errCode =
            ixmlDocument_createAttributeEx(( IXML_Document* ) element->n.
                                           ownerDocument, name,
                                           &newAttrNode);
        if(errCode != IXML_SUCCESS) {
            goto ErrorHandler;
        }

        attrNode = ( IXML_Node* ) newAttrNode;

        attrNode->nodeValue = strdup(value);
        if(attrNode->nodeValue == NULL) {
            ixmlAttr_free(newAttrNode);
            errCode = IXML_INSUFFICIENT_MEMORY;
            goto ErrorHandler;
        }

        errCode =
            ixmlElement_setAttributeNode(element, newAttrNode, NULL);
        if(errCode != IXML_SUCCESS) {
            ixmlAttr_free(newAttrNode);
            goto ErrorHandler;
        }

    } else {
        if(attrNode->nodeValue != NULL) { // attribute name has a value already
            free(attrNode->nodeValue);
        }

        attrNode->nodeValue = strdup(value);
        if(attrNode->nodeValue == NULL) {
            errCode = IXML_INSUFFICIENT_MEMORY;
        }
    }

ErrorHandler:
    return errCode;
}

/*================================================================
 *   ixmlElement_removeAttribute
 *       Removes an attribute value by name. The attribute node is
 *       not removed.
 *       External function.
 *   Parameters:
 *       name: the name of the attribute to remove.
 *   Return Values:
 *       IXML_SUCCESS or error code.
 *
 *=================================================================*/
int
ixmlElement_removeAttribute(IN IXML_Element* element,
                            IN const char* name) {

    IXML_Node* attrNode;

    if(( element == NULL ) || ( name == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, name) == 0) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode != NULL) {  // has the attribute
        if(attrNode->nodeValue != NULL) {
            free(attrNode->nodeValue);
            attrNode->nodeValue = NULL;
        }
    }

    return IXML_SUCCESS;
}

/*================================================================
 *   ixmlElement_getAttributeNode
 *       Retrieve an attribute node by name.
 *       External function.
 *   Parameters:
 *       name: the name(nodeName) of the attribute to retrieve.
 *   Return Value:
 *       The attr node with the specified name (nodeName) or NULL if
 *       there is no such attribute.
 *
 *=================================================================*/
IXML_Attr*
ixmlElement_getAttributeNode(IN IXML_Element* element,
                             IN const char* name) {

    IXML_Node* attrNode;

    if(( element == NULL ) || ( name == NULL )) {
        return NULL;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, name) == 0) { // found it
            break;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return ( IXML_Attr* ) attrNode;

}

/*================================================================
 *   ixmlElement_setAttributeNode
 *       Adds a new attribute node.  If an attribute with that name(nodeName)
 *       is already present in the element, it is replaced by the new one.
 *       External function.
 *   Parameters:
 *       The attr node to add to the attribute list.
 *   Return Value:
 *       if newAttr replaces an existing attribute, the replaced
 *       attr node is returned, otherwise NULL is returned.
 *
 *=================================================================*/
int
ixmlElement_setAttributeNode(IN IXML_Element* element,
                             IN IXML_Attr* newAttr,
                             OUT IXML_Attr** rtAttr) {

    IXML_Node* attrNode;
    IXML_Node* node;
    IXML_Node* nextAttr = NULL;
    IXML_Node* prevAttr = NULL;
    IXML_Node* preSib,
        * nextSib;

    if(( element == NULL ) || ( newAttr == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    if(newAttr->n.ownerDocument != element->n.ownerDocument) {
        return IXML_WRONG_DOCUMENT_ERR;
    }

    if(newAttr->ownerElement != NULL) {
        return IXML_INUSE_ATTRIBUTE_ERR;
    }

    newAttr->ownerElement = element;
    node = ( IXML_Node* ) newAttr;

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, node->nodeName) == 0) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode != NULL) {  // already present, will replace by newAttr
        preSib = attrNode->prevSibling;
        nextSib = attrNode->nextSibling;

        if(preSib != NULL) {
            preSib->nextSibling = node;
        }

        if(nextSib != NULL) {
            nextSib->prevSibling = node;
        }

        if(element->n.firstAttr == attrNode) {
            element->n.firstAttr = node;
        }

        if(rtAttr != NULL) {
            *rtAttr = ( IXML_Attr* ) attrNode;
        }
    } else {                // add this attribute
        if(element->n.firstAttr != NULL) {
            prevAttr = element->n.firstAttr;
            nextAttr = prevAttr->nextSibling;
            while(nextAttr != NULL) {
                prevAttr = nextAttr;
                nextAttr = prevAttr->nextSibling;
            }
            prevAttr->nextSibling = node;
            node->prevSibling = prevAttr;
        } else {        // this is the first attribute node
            element->n.firstAttr = node;
            node->prevSibling = NULL;
            node->nextSibling = NULL;
        }

        if(rtAttr != NULL) {
            *rtAttr = NULL;
        }
    }

    return IXML_SUCCESS;
}

/*================================================================
 *   ixmlElement_findAttributeNode
 *       Find a attribute node whose contents are the same as the oldAttr.
 *       Internal only to parser.
 *   Parameter:
 *       oldAttr: the attribute node to match
 *   Return:
 *       if found it, the attribute node is returned,
 *       otherwise, return NULL.
 *
 *=================================================================*/
IXML_Node*
ixmlElement_findAttributeNode(IN IXML_Element* element,
                              IN IXML_Attr* oldAttr) {
    IXML_Node* attrNode;
    IXML_Node* oldAttrNode = ( IXML_Node* ) oldAttr;

    assert(( element != NULL ) && ( oldAttr != NULL ));

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) { // parentNode, prevSib, nextSib and ownerDocument doesn't matter
        if(ixmlNode_compare(attrNode, oldAttrNode) == TRUE) {
            break;            //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return attrNode;

}

/*================================================================
 *   ixmlElement_removeAttributeNode
 *       Removes the specified attribute node.
 *       External function.
 *
 *   Parameters:
 *       oldAttr: the attr node to remove from the attribute list.
 *
 *   Return Value:
 *       IXML_SUCCESS or failure
 *
 *=================================================================*/
int
ixmlElement_removeAttributeNode(IN IXML_Element* element,
                                IN IXML_Attr* oldAttr,
                                OUT IXML_Attr** rtAttr) {
    IXML_Node* attrNode;
    IXML_Node* preSib,
        * nextSib;

    if(( element == NULL ) || ( oldAttr == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    attrNode = ixmlElement_findAttributeNode(element, oldAttr);
    if(attrNode != NULL) {  // has the attribute
        preSib = attrNode->prevSibling;
        nextSib = attrNode->nextSibling;

        if(preSib != NULL) {
            preSib->nextSibling = nextSib;
        }

        if(nextSib != NULL) {
            nextSib->prevSibling = preSib;
        }

        if(element->n.firstAttr == attrNode) {
            element->n.firstAttr = nextSib;
        }

        /* ( IXML_Attr * ) */ attrNode->parentNode = NULL;
        /* ( IXML_Attr * ) */ attrNode->prevSibling = NULL;
        /* ( IXML_Attr * ) */ attrNode->nextSibling = NULL;
        *rtAttr = ( IXML_Attr* ) attrNode;
        return IXML_SUCCESS;

    } else {
        return IXML_NOT_FOUND_ERR;
    }

}

/*================================================================
 *   ixmlElement_getElementsByTagName
 *       Returns a nodeList of all descendant Elements with a given
 *       tag name, in the order in which they are encountered in a preorder
 *       traversal of this element tree.
 *       External function.
 *
 *   Parameters:
 *       tagName: the name of the tag to match on. The special value "*"
 *       matches all tags.
 *
 *   Return Value:
 *       a nodeList of matching element nodes.
 *
 *=================================================================*/
IXML_NodeList*
ixmlElement_getElementsByTagName(IN IXML_Element* element,
                                 IN const char* tagName) {
    IXML_NodeList* returnNodeList = NULL;

    if(( element != NULL ) && ( tagName != NULL )) {
        ixmlNode_getElementsByTagName(( IXML_Node* ) element, tagName,
                                      &returnNodeList);
    }
    return returnNodeList;
}

/*================================================================
 *   ixmlElement_getAttributeNS
 *       Retrieves an attribute value by local name and namespace URI.
 *       External function.
 *
 *   Parameters:
 *       namespaceURI: the namespace URI of the attribute to retrieve.
 *       localName: the local name of the attribute to retrieve.
 *
 *   Return Value:
 *       the attr value as a string, or NULL if that attribute does
 *       not have the specified value.
 *
 *=================================================================*/
const DOMString
ixmlElement_getAttributeNS(IN IXML_Element* element,
                           IN const DOMString namespaceURI,
                           IN const DOMString localName) {
    IXML_Node* attrNode;

    if(( element == NULL ) || ( namespaceURI == NULL )
       || ( localName == NULL )) {
        return NULL;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, localName) == 0) && (strcmp(attrNode->namespaceURI, namespaceURI) == 0)) { // found it
            return attrNode->nodeValue;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return NULL;

}

/*================================================================
 *   ixmlElement_setAttributeNS
 *       Adds a new attribute. If an attribute with the same local name
 *       and namespace URI is already present on the element, its prefix
 *       is changed to be the prefix part of the qualifiedName, and its
 *       value is changed to be the value parameter.  This value is a
 *       simple string.
 *       External function.
 *
 *   Parameter:
 *       namespaceURI: the namespace of the attribute to create or alter.
 *       qualifiedName: the qualified name of the attribute to create or alter.
 *       value: the value to set in string form.
 *
 *   Return Value:
 *       IXML_SUCCESS or failure
 *
 *=================================================================*/
int
ixmlElement_setAttributeNS(IN IXML_Element* element,
                           IN const DOMString namespaceURI,
                           IN const DOMString qualifiedName,
                           IN const DOMString value) {
    IXML_Node* attrNode = NULL;
    IXML_Node newAttrNode;
    IXML_Attr* newAttr;
    int rc;

    if(( element == NULL ) || ( namespaceURI == NULL ) ||
       ( qualifiedName == NULL ) || ( value == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    if(Parser_isValidXmlName(qualifiedName) == FALSE) {
        return IXML_INVALID_CHARACTER_ERR;
    }

    ixmlNode_init(&newAttrNode);

    newAttrNode.nodeName = strdup(qualifiedName);
    if(newAttrNode.nodeName == NULL) {
        return IXML_INSUFFICIENT_MEMORY;
    }

    rc = Parser_setNodePrefixAndLocalName(&newAttrNode);
    if(rc != IXML_SUCCESS) {
        Parser_freeNodeContent(&newAttrNode);
        return rc;
    }
    // see DOM 2 spec page 59
    if(((newAttrNode.prefix != NULL) && (namespaceURI == NULL)) ||
       ( newAttrNode.prefix && namespaceURI && ( strcmp(newAttrNode.prefix, "xml") == 0) &&
         ( strcmp(namespaceURI,
                  "http://www.w3.org/XML/1998/namespace") != 0))
       || (( strcmp(qualifiedName, "xmlns") == 0)
           && ( strcmp(namespaceURI,
                       "http://www.w3.org/2000/xmlns/") != 0))) {
        Parser_freeNodeContent(&newAttrNode);
        return IXML_NAMESPACE_ERR;
    }


    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, newAttrNode.localName) == 0) &&
           ( strcmp(attrNode->namespaceURI, namespaceURI) == 0)) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode != NULL) {
        if(attrNode->prefix != NULL) {
            free(attrNode->prefix); // remove the old prefix
        }
        // replace it with the new prefix
        attrNode->prefix = strdup(newAttrNode.prefix ? newAttrNode.prefix : "");
        if(attrNode->prefix == NULL) {
            Parser_freeNodeContent(&newAttrNode);
            return IXML_INSUFFICIENT_MEMORY;
        }

        if(attrNode->nodeValue != NULL) {
            free(attrNode->nodeValue);
        }

        attrNode->nodeValue = strdup(value);
        if(attrNode->nodeValue == NULL) {
            free(attrNode->prefix);
            Parser_freeNodeContent(&newAttrNode);
            return IXML_INSUFFICIENT_MEMORY;
        }

    } else {
        // add a new attribute
        rc = ixmlDocument_createAttributeNSEx(( IXML_Document* )
                                              element->n.ownerDocument,
                                              namespaceURI, qualifiedName,
                                              &newAttr);
        if(rc != IXML_SUCCESS) {
            return rc;
        }

        newAttr->n.nodeValue = strdup(value);
        if(newAttr->n.nodeValue == NULL) {
            ixmlAttr_free(newAttr);
            return IXML_INSUFFICIENT_MEMORY;
        }

        if(ixmlElement_setAttributeNodeNS(element, newAttr, NULL) !=
           IXML_SUCCESS) {
            ixmlAttr_free(newAttr);
            return IXML_FAILED;
        }

    }

    Parser_freeNodeContent(&newAttrNode);
    return IXML_SUCCESS;
}

/*================================================================
 *   ixmlElement_removeAttributeNS
 *       Removes an attribute by local name and namespace URI. The replacing
 *       attribute has the same namespace URI and local name, as well as
 *       the original prefix.
 *       External function.
 *
 *   Parameters:
 *       namespaceURI: the namespace URI of the attribute to remove.
 *       localName: the local name of the atribute to remove.
 *
 *   Return Value:
 *       IXML_SUCCESS or failure.
 *
 *=================================================================*/
int
ixmlElement_removeAttributeNS(IN IXML_Element* element,
                              IN const DOMString namespaceURI,
                              IN const DOMString localName) {
    IXML_Node* attrNode;

    if(( element == NULL ) || ( namespaceURI == NULL )
       || ( localName == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, localName) == 0) &&
           ( strcmp(attrNode->namespaceURI, namespaceURI) == 0)) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode != NULL) {  // has the attribute
        if(attrNode->nodeValue != NULL) {
            free(attrNode->nodeValue);
            attrNode->nodeValue = NULL;
        }
    }

    return IXML_SUCCESS;

}

/*================================================================
 *   ixmlElement_getAttributeNodeNS
 *       Retrieves an attr node by local name and namespace URI.
 *       External function.
 *
 *   Parameter:
 *       namespaceURI: the namespace of the attribute to retrieve.
 *       localName: the local name of the attribute to retrieve.
 *
 *   Return Value:
 *       The attr node with the specified attribute local name and
 *       namespace URI or null if there is no such attribute.
 *
 *=================================================================*/
IXML_Attr*
ixmlElement_getAttributeNodeNS(IN IXML_Element* element,
                               IN const DOMString namespaceURI,
                               IN const DOMString localName) {

    IXML_Node* attrNode;

    if(( element == NULL ) || ( namespaceURI == NULL )
       || ( localName == NULL )) {
        return NULL;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, localName) == 0) && (strcmp(attrNode->namespaceURI, namespaceURI) == 0)) { // found it
            break;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return ( IXML_Attr* ) attrNode;

}

/*================================================================
 *   ixmlElement_setAttributeNodeNS
 *       Adds a new attribute. If an attribute with that local name and
 *       that namespace URI is already present in the element, it is replaced
 *       by the new one.
 *       External function.
 *
 *   Parameter:
 *       newAttr: the attr node to add to the attribute list.
 *
 *   Return Value:
 *       If the newAttr attribute replaces an existing attribute with the
 *       same local name and namespace, the replaced attr node is returned,
 *       otherwise null is returned.
 *
 *=================================================================*/
int
ixmlElement_setAttributeNodeNS(IN IXML_Element* element,
                               IN IXML_Attr* newAttr,
                               OUT IXML_Attr** rtAttr) {
    IXML_Node* attrNode;
    IXML_Node* node;
    IXML_Node* prevAttr = NULL,
        * nextAttr = NULL;
    IXML_Node* preSib,
        * nextSib;

    if(( element == NULL ) || ( newAttr == NULL )) {
        return IXML_INVALID_PARAMETER;
    }

    if(newAttr->n.ownerDocument != element->n.ownerDocument) {
        return IXML_WRONG_DOCUMENT_ERR;
    }

    if(( newAttr->ownerElement != NULL )
       && ( newAttr->ownerElement != element )) {
        return IXML_INUSE_ATTRIBUTE_ERR;
    }

    newAttr->ownerElement = element;
    node = ( IXML_Node* ) newAttr;

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, node->localName) == 0) &&
           ( strcmp(attrNode->namespaceURI, node->namespaceURI) == 0)) {
            break;  //found it
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    if(attrNode != NULL) {  // already present, will replace by newAttr
        preSib = attrNode->prevSibling;
        nextSib = attrNode->nextSibling;

        if(preSib != NULL) {
            preSib->nextSibling = node;
        }

        if(nextSib != NULL) {
            nextSib->prevSibling = node;
        }

        if(element->n.firstAttr == attrNode) {
            element->n.firstAttr = node;
        }

        if(rtAttr != NULL) {
            *rtAttr = ( IXML_Attr* ) attrNode;
        }

    } else {                               // add this attribute
        if(element->n.firstAttr != NULL) { // element has attribute already
            prevAttr = element->n.firstAttr;
            nextAttr = prevAttr->nextSibling;
            while(nextAttr != NULL) {
                prevAttr = nextAttr;
                nextAttr = prevAttr->nextSibling;
            }
            prevAttr->nextSibling = node;
        } else {        // this is the first attribute node
            element->n.firstAttr = node;
            node->prevSibling = NULL;
            node->nextSibling = NULL;
        }

        if(rtAttr != NULL) {
            *rtAttr = NULL;
        }
    }

    return IXML_SUCCESS;
}

/*================================================================
 *   ixmlElement_getElementsByTagNameNS
 *       Returns a nodeList of all the descendant Elements with a given
 *       local name and namespace in the order in which they are encountered
 *       in a preorder traversal of the element tree.
 *       External function.
 *
 *   Parameters:
 *       namespaceURI: the namespace URI of the elements to match on. The
 *               special value "*" matches all namespaces.
 *       localName: the local name of the elements to match on. The special
 *               value "*" matches all local names.
 *
 *   Return Value:
 *       A new nodeList object containing all the matched Elements.
 *
 *=================================================================*/
IXML_NodeList*
ixmlElement_getElementsByTagNameNS(IN IXML_Element* element,
                                   IN const DOMString namespaceURI,
                                   IN const DOMString localName) {
    IXML_Node* node = ( IXML_Node* ) element;
    IXML_NodeList* nodeList = NULL;

    if(( element != NULL ) && ( namespaceURI != NULL )
       && ( localName != NULL )) {
        ixmlNode_getElementsByTagNameNS(node, namespaceURI, localName,
                                        &nodeList);
    }

    return nodeList;
}

/*================================================================
 *   ixmlElement_hasAttribute
 *       Returns true when an attribute with a given name is specified on
 *       this element, false otherwise.
 *       External function.
 *
 *   Parameters:
 *       name: the name of the attribute to look for.
 *
 *   Return Value:
 *       ture if an attribute with the given name is specified on this
 *       element, false otherwise.
 *
 *=================================================================*/
BOOL
ixmlElement_hasAttribute(IN IXML_Element* element,
                         IN const DOMString name) {

    IXML_Node* attrNode;

    if(( element == NULL ) || ( name == NULL )) {
        return FALSE;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if(strcmp(attrNode->nodeName, name) == 0) {
            return TRUE;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return FALSE;
}

/*================================================================
 *   ixmlElement_hasAttributeNS
 *       Returns true when attribute with a given local name and namespace
 *       URI is specified on this element, false otherwise.
 *       External function.
 *
 *   Parameters:
 *       namespaceURI: the namespace URI of the attribute to look for.
 *       localName: the local name of the attribute to look for.
 *
 *   Return Value:
 *       true if an attribute with the given local name and namespace URI
 *       is specified, false otherwise.
 *
 *=================================================================*/
BOOL
ixmlElement_hasAttributeNS(IN IXML_Element* element,
                           IN const DOMString namespaceURI,
                           IN const DOMString localName) {

    IXML_Node* attrNode;

    if(( element == NULL ) || ( namespaceURI == NULL )
       || ( localName == NULL )) {
        return FALSE;
    }

    attrNode = element->n.firstAttr;
    while(attrNode != NULL) {
        if((strcmp(attrNode->localName, localName) == 0) &&
           ( strcmp(attrNode->namespaceURI, namespaceURI) == 0)) {
            return TRUE;
        } else {
            attrNode = attrNode->nextSibling;
        }
    }

    return FALSE;
}

/*================================================================
 *   ixmlElement_free
 *       frees a element node.
 *       External function.
 *
 *=================================================================*/
void
ixmlElement_free(IN IXML_Element* element) {
    if(element != NULL) {
        ixmlNode_free(( IXML_Node* ) element);
    }
}
