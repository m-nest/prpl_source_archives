/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__LCM_REMOTE_OBJECT_H__)
#define __LCM_REMOTE_OBJECT_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_lqueue.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb_types.h>

/**
 * @brief Structure representing a remote object
 *
 * This structure maintains the state and context of a remote object in the system.
 */
typedef struct {
    char* object_dm_name;            /**< Data model name of the remote object */
    amxb_bus_ctx_t* bus_ctx;         /**< Bus context for communication */
} remote_object_t;

/**
 * @brief Register a new remote object
 *
 * Creates and initializes a new remote object instance with the specified data model name.
 *
 * @param object_dm_name The data model name for the remote object
 * @return remote_object_t* Pointer to the newly created remote object, or NULL on failure
 */
remote_object_t* lcm_remote_object_register(const char* object_dm_name);

/**
 * @brief Unregister and free a remote object
 *
 * Cleans up and releases all resources associated with the remote object.
 *
 * @param remote_object Pointer to the remote object pointer to unregister (will be set to NULL)
 */
void lcm_remote_object_unregister(remote_object_t** remote_object);

/**
 * @brief Add a new instance to a remote object
 *
 * Creates a new instance at the specified path with given values.
 *
 * @param remote_object The remote object context
 * @param object_path Path where the new instance should be created
 * @param values Initial values for the new instance
 * @param path Output parameter to store the created instance path
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_add(remote_object_t* remote_object,
                          const char* object_path,
                          amxc_var_t* values,
                          char** path);

/**
 * @brief Set values on a remote object
 *
 * Updates the values of parameters in the specified remote object.
 *
 * @param remote_object The remote object context
 * @param object_path Path to the target object
 * @param values Values to be set on the object
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_set(remote_object_t* remote_object,
                          const char* object_path,
                          amxc_var_t* values);

/**
 * @brief Remove a remote object instance
 *
 * Deletes the specified remote object instance from the system.
 *
 * @param remote_object The remote object context
 * @param object_path Path to the object to be removed
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_remove(remote_object_t* remote_object,
                             const char* object_path);

/**
 * @brief Get values from a remote object
 *
 * Retrieves all values from the object specified by the object_path.
 *
 * @param remote_object The remote object context
 * @param object_path Path to the target object
 * @param ret Output parameter to store the retrieved values
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_get(remote_object_t* remote_object,
                          const char* object_path,
                          amxc_var_t* ret);

/**
 * @brief Get a single value from a remote object
 *
 * Retrieves a single value from the specified remote object path.
 *
 * @param remote_object The remote object context
 * @param object_path Path to the target object
 * @param ret Output parameter to store the retrieved value
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_get_one(remote_object_t* remote_object,
                              const char* object_path,
                              amxc_var_t* ret);

/**
 * @brief Get values matching an expression from a remote object
 *
 * Retrieves values that match the specified expression from the remote object.
 *
 * @param remote_object The remote object context
 * @param object_path Base path for the search
 * @param expression Expression to filter the values
 * @param ret Output parameter to store the retrieved values
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_get_by_expression(remote_object_t* remote_object,
                                        const char* object_path,
                                        const char* expression,
                                        amxc_var_t* ret);

/**
 * @brief Get values from a remote object using an alias
 *
 * Retrieves values from the remote object identified by the specified alias.
 *
 * @param remote_object The remote object context
 * @param object_path Base path for the search
 * @param alias Alias identifying the target object
 * @param path Output parameter to store the resolved path
 * @param ret Output parameter to store the retrieved values
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_get_by_alias(remote_object_t* remote_object,
                                   const char* object_path,
                                   const char* alias,
                                   char** path,
                                   amxc_var_t* ret);

/**
 * @brief Delete an instance on a remote object
 *
 * Removes the specified instance from the remote object.
 *
 * @param remote_object The remote object context
 * @param object_path Path to the object to be deleted
 * @param ret Output parameter to store the operation result
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_del(remote_object_t* remote_object,
                          const char* object_path,
                          amxc_var_t* ret);

/**
 * @brief Subscribe to events from a remote object
 *
 * Sets up event subscription for the specified remote object path and expression.
 *
 * @param remote_object The remote object context
 * @param object_path Path to subscribe to
 * @param expression Expression to filter events
 * @param slot_cb Callback function to handle events
 * @param priv Private data passed to the callback
 * @return int Returns 0 on success, non-zero on failure
 */
int lcm_remote_object_subscribe(remote_object_t* remote_object,
                                const char* object_path,
                                const char* expression,
                                amxp_slot_fn_t slot_cb,
                                void* priv);

/**
 * @brief Unsubscribe a callback function from the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to unsubscribe from.
 * @param slot_cb The callback function used during subscription.
 * @param priv Private data used during subscription.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_unsubscribe(remote_object_t* remote_object,
                                  const char* object_path,
                                  amxp_slot_fn_t slot_cb,
                                  void* priv);
/**
 * @brief Parse index from path
 *
 * To correlate an index of a multi instance object, this function will help to parse the index of the path
 *
 * @param path The path to parse the index from, should start with the number
 * @param index Output index where we will store the index of the path when parsed correctly
 * @param check_end If true then check if there is a dot '.' in the path after the parsed number
 * @return bool Returns true on success, false on failure
 */
bool get_index_from_path(const char* path, uint32_t* index, bool check_end);

#ifdef __cplusplus
}
#endif

#endif // __LCM_REMOTE_OBJECT_H__
