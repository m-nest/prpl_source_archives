/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_path.h>
#include <amxd/amxd_object_event.h>

#include <amxo/amxo.h>

#include <amxb/amxb.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>

#include <gmap/gmap_main.h>
#include <gmap/gmap_query.h>
#include "gmap_ext_util.h"
#include "mock.h"

typedef struct {
    amxc_htable_it_t it;
    char* name;
    char* expression;
    uint32_t id;
    uint32_t index;
    amxd_object_t* obj;
    amxc_set_t devices;
} dummy_query_t;

typedef struct {
    amxc_htable_it_t it;
    char* key;
    char* tags;
    amxd_object_t* obj;
} dummy_device_t;

static amxd_dm_t* gmap_bus_dm = NULL;
static amxc_htable_t* queries = NULL;
static amxc_htable_t* devices = NULL;


static amxd_status_t _dummy_bool(UNUSED amxd_object_t* object,
                                 UNUSED amxd_function_t* func,
                                 UNUSED amxc_var_t* args,
                                 amxc_var_t* ret) {
    amxc_var_set(bool, ret, true);
    return amxd_status_ok;
}

static amxd_status_t _dummy_void(UNUSED amxd_object_t* object,
                                 UNUSED amxd_function_t* func,
                                 UNUSED amxc_var_t* args,
                                 UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

/** Verifies that all given tags are set on a device. */
static bool s_device_has_tag(const dummy_device_t* device,
                             const char* tags) {
    bool result = false;
    amxc_set_t device_tags;
    amxc_set_t test_tags;

    assert_non_null(device);
    assert_non_null(tags);

    amxc_set_init(&device_tags, false);
    amxc_set_init(&test_tags, false);

    assert_success(amxc_set_parse(&device_tags, device->tags));
    assert_success(amxc_set_parse(&test_tags, tags));

    amxc_set_intersect(&device_tags, &test_tags);
    result = amxc_set_get_count(&device_tags, NULL) == amxc_set_get_count(&test_tags, NULL);

    amxc_set_clean(&device_tags);
    amxc_set_clean(&test_tags);

    return result;
}

static amxp_expr_status_t s_expression_getter(amxp_expr_t* expr,
                                              amxc_var_t* value,
                                              const char* path,
                                              void* priv) {
    const dummy_device_t* device = priv;

    assert_non_null(expr);
    assert_non_null(value);
    assert_non_null(path);
    assert_string_not_equal(path, "");
    assert_non_null(device);

    assert_false((*path == '.') && "Mocked gmap doesn't support expressions on device parameters");
    amxc_var_set_bool(value, s_device_has_tag(device, path));

    return amxp_expr_status_ok;
}

static bool s_expression_matches_device(const char* expression,
                                        const dummy_device_t* device) {
    bool result = false;
    amxp_expr_status_t status = amxp_expr_status_unknown_error;
    amxp_expr_t parsed;

    assert_non_null(expression);
    assert_string_not_equal(expression, "");
    assert_non_null(device);

    assert_success(amxp_expr_init(&parsed, expression));
    result = amxp_expr_evaluate(&parsed, s_expression_getter, (void*) device, &status);
    assert_success(status);

    amxp_expr_clean(&parsed);

    return result;
}

static void s_device_get_data(amxd_object_t* root,
                              amxc_var_t* target) {
    uint32_t index = amxd_object_get_index(root);
    if(root->type != amxd_object_template) {
        amxd_object_get_params(root, target, amxd_dm_access_protected);
    }
    if(index != 0) {
        amxc_var_add_key(uint32_t, target, "Index", index);
    }

    amxd_object_iterate(child, it, root) {
        amxd_object_t* child_obj = amxc_container_of(it, amxd_object_t, it);
        const char* child_name = amxd_object_get_name(child_obj, AMXD_OBJECT_NAMED);
        //if template add list otherwise add htable
        if(child_obj->type == amxd_object_template) {
            amxc_var_t* template_var = amxc_var_add_key(amxc_llist_t, target, child_name, NULL);
            amxd_object_iterate(instance, inst, child_obj) {
                amxd_object_t* child_inst = amxc_container_of(inst, amxd_object_t, it);
                amxc_var_t* child_params = amxc_var_add(amxc_htable_t, template_var, NULL);
                s_device_get_data(child_inst, child_params);
            }
        } else {
            amxc_var_t* child_params = amxc_var_add_key(amxc_htable_t, target, child_name, NULL);
            s_device_get_data(child_obj, child_params);
        }
    }
}

static void add_matching_devices(dummy_query_t* query,
                                 amxc_var_t* matching_devices) {
    amxc_var_set_type(matching_devices, AMXC_VAR_ID_LIST);
    amxc_htable_for_each(it, devices) {
        const char* devicekey = amxc_htable_it_get_key(it);
        dummy_device_t* dummy_device = amxc_htable_it_get_data(it, dummy_device_t, it);
        if(s_expression_matches_device(query->expression, dummy_device)) {
            amxc_var_t* device = amxc_var_add_new(matching_devices);
            s_device_get_data(dummy_device->obj, device);
            amxc_set_add_flag(&query->devices, devicekey);
        }
    }
}

static dummy_device_t* s_device_create(const char* key,
                                       const char* tags) {
    dummy_device_t* device;

    assert_non_null(key);
    assert_string_not_equal(key, "");
    assert_non_null(tags);

    if(devices == NULL) {
        amxc_htable_new(&devices, 0);
    }

    assert_null(amxc_htable_get(devices, key));

    device = calloc(1, sizeof(dummy_device_t));
    device->key = strdup(key);
    device->tags = strdup(tags);
    assert_non_null(device->key);
    assert_non_null(device->tags);

    assert_success(amxc_htable_insert(devices, device->key, &device->it));

    return device;
}

static void s_device_clean(UNUSED const char* key,
                           amxc_htable_it_t* it) {
    dummy_device_t* device = amxc_htable_it_get_data(it, dummy_device_t, it);

    free(device->tags);
    free(device->key);
    free(device);
}

static void s_query_emit(dummy_query_t* query,
                         dummy_device_t* device,
                         gmap_query_action_t action) {
    amxc_var_t sig_data;
    amxc_var_t* data = NULL;
    amxc_var_t* device_data = NULL;
    amxc_var_init(&sig_data);

    /* May be called for subobjects from a device that doesn't exist anymore,
     * don't send events. */
    when_true(action != gmap_query_expression_stop_matching &&
              amxd_dm_findf(gmap_bus_dm, "Devices.Device.%s.", device->key) == NULL,
              exit);

    amxc_var_set_type(&sig_data, AMXC_VAR_ID_HTABLE);
    data = amxc_var_add_new_key(&sig_data, "Result");
    amxc_var_set_type(data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, data, "Id", query->id);
    amxc_var_add_key(uint32_t, data, "Index", query->index);
    amxc_var_add_key(uint32_t, data, "Action", action);
    amxc_var_add_key(cstring_t, data, "Key", device->key);
    if(action != gmap_query_expression_stop_matching) {
        device_data = amxc_var_add_key(amxc_htable_t, data, "Device", NULL);
        s_device_get_data(device->obj, device_data);
    }
    amxd_object_emit_signal(query->obj, "gmap_query", &sig_data);
    amxut_bus_handle_events();

exit:
    amxc_var_clean(&sig_data);
}

static void s_queries_evaluate(dummy_device_t* device) {
    when_null(queries, exit);

    amxc_htable_for_each(it, queries) {
        dummy_query_t* query = amxc_htable_it_get_data(it, dummy_query_t, it);
        bool matches = s_expression_matches_device(query->expression, device);
        size_t pre_change = amxc_set_get_count(&query->devices, NULL);
        size_t post_change;
        if(matches) {
            amxc_set_add_flag(&query->devices, device->key);
        } else {
            amxc_set_remove_flag(&query->devices, device->key);
        }
        post_change = amxc_set_get_count(&query->devices, NULL);
        if(pre_change > post_change) {
            s_query_emit(query, device, gmap_query_expression_stop_matching);
        } else if(pre_change < post_change) {
            s_query_emit(query, device, gmap_query_expression_start_matching);
        } else {
            s_query_emit(query, device, gmap_query_device_updated);
        }
    }

    amxut_bus_handle_events();

exit:
    return;
}

static void s_queries_evaluate_key(const char* key) {
    amxc_htable_it_t* it = amxc_htable_get(devices, key);
    if(it != NULL) {
        s_queries_evaluate(amxc_htable_it_get_data(it, dummy_device_t, it));
    }
}

static void s_queries_remove(dummy_device_t* device) {
    when_null(queries, exit);

    amxc_htable_for_each(it, queries) {
        dummy_query_t* query = amxc_htable_it_get_data(it, dummy_query_t, it);
        size_t pre_change = amxc_set_get_count(&query->devices, NULL);
        size_t post_change;
        amxc_set_remove_flag(&query->devices, device->key);
        post_change = amxc_set_get_count(&query->devices, NULL);
        if(pre_change > post_change) {
            s_query_emit(query, device, gmap_query_expression_stop_matching);
        }
    }

    amxut_bus_handle_events();

exit:
    return;
}

static void _mock_device_added(UNUSED const char* const sig_name,
                               const amxc_var_t* const data,
                               UNUSED void* const priv) {
    dummy_device_t* device = NULL;
    amxc_htable_it_t* it;
    amxc_var_t* params = GET_ARG(data, "parameters");
    uint32_t index = GET_UINT32(data, "index");
    const char* key = GET_CHAR(params, "Key");
    const char* tags = GET_CHAR(params, "Tags");

    assert_int_not_equal(index, 0);
    assert_non_null(key);
    assert_string_not_equal(key, "");
    assert_non_null(tags);

    it = amxc_htable_get(devices, key);
    if(it == NULL) {
        device = s_device_create(key, tags);
    } else {
        device = amxc_htable_it_get_data(it, dummy_device_t, it);
    }

    assert_non_null(device);

    assert_null(device->obj);
    device->obj = amxd_dm_findf(gmap_bus_dm, "Devices.Device.%u.", index);
    assert_non_null(device->obj);

    s_queries_evaluate(device);
}

static void _mock_device_removed(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    dummy_device_t* device = NULL;
    amxc_htable_it_t* it;
    const char* key = GET_CHAR(data, "name");

    assert_non_null(key);
    assert_string_not_equal(key, "");

    it = amxc_htable_get(devices, key);
    when_null(it, exit);
    device = amxc_htable_it_get_data(it, dummy_device_t, it);

    device->obj = NULL;
    s_queries_remove(device);
    amxc_htable_it_clean(it, s_device_clean);

exit:
    return;
}

static void _mock_device_changed(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    s_queries_evaluate_key(GET_CHAR(data, "name"));
}

static void _mmock_device_subobject_update(UNUSED const char* const sig_name,
                                           const amxc_var_t* const data,
                                           UNUSED void* const priv) {
    const char* path = GET_CHAR(data, "object");
    const char* path_end;
    amxc_string_t key;

    amxc_string_init(&key, 0);

    assert_non_null(path);
    path = strchr(path, '.');
    assert_non_null(path);
    ++path;
    path = strchr(path, '.');
    assert_non_null(path);
    ++path;
    path_end = strchr(path, '.');
    assert_non_null(path_end);
    assert_true(path != path_end);
    amxc_string_append(&key, path, path_end - path);

    /* It's possible that the original object no longer exists.
     * In that case, don't re-evaluate but let the regular instance-removed event
     * do its query matching device cleanup work. */
    when_null(amxd_dm_findf(gmap_bus_dm, "Devices.Device.%s.", amxc_string_get(&key, 0)), exit);
    s_queries_evaluate_key(amxc_string_get(&key, 0));

exit:
    amxc_string_clean(&key);
}

static amxd_status_t _createDevice(amxd_object_t* object,
                                   amxd_function_t* func,
                                   amxc_var_t* args,
                                   amxc_var_t* ret) {

    amxd_status_t amxd_status = amxd_status_ok;
    const char* key = GET_CHAR(args, "key");
    const char* tags = GET_CHAR(args, "tags");

    amxd_trans_t trans;

    s_device_create(key, tags);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Device.");
    amxd_trans_add_inst(&trans, 0, key);
    amxd_trans_set_value(cstring_t, &trans, "Key", key);
    amxd_trans_set_value(cstring_t, &trans, "Tags", tags);
    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);

    amxut_bus_handle_events();

    amxd_status = _dummy_bool(object, func, args, ret);
    return amxd_status;
}

static amxd_status_t _destroyDevice(amxd_object_t* object,
                                    amxd_function_t* func,
                                    amxc_var_t* args,
                                    amxc_var_t* ret) {

    amxd_status_t amxd_status = amxd_status_ok;
    amxc_htable_it_t* it = NULL;

    it = amxc_htable_take(devices, GET_CHAR(args, "key"));
    if(it) {
        dummy_device_t* device = amxc_htable_it_get_data(it, dummy_device_t, it);
        amxd_trans_t trans;

        amxd_trans_init(&trans);
        amxd_trans_select_object(&trans, amxd_object_get_parent(device->obj));
        amxd_trans_del_inst(&trans, 0, device->key);
        assert_success(amxd_trans_apply(&trans, gmap_bus_dm));
        amxd_trans_clean(&trans);

        amxc_htable_it_clean(it, s_device_clean);
    }
    if(amxc_htable_is_empty(devices)) {
        amxc_htable_delete(&devices, NULL);
    }

    amxd_status = _dummy_bool(object, func, args, ret);
    return amxd_status;
}

static amxd_status_t _matchingDevices(amxd_object_t* object,
                                      UNUSED amxd_function_t* func,
                                      UNUSED amxc_var_t* args,
                                      amxc_var_t* ret) {
    amxd_status_t amxd_status = amxd_status_ok;
    char* expression = amxd_object_get_value(cstring_t, object, "Expression", NULL);
    assert_non_null(expression);
    amxc_var_set_type(ret, AMXC_VAR_ID_LIST);
    amxc_htable_for_each(it, devices) {
        const char* devicekey = amxc_htable_it_get_key(it);
        dummy_device_t* dummy_device = amxc_htable_it_get_data(it, dummy_device_t, it);
        if(s_expression_matches_device(expression, dummy_device)) {
            amxc_var_add(cstring_t, ret, devicekey);
        }
    }
    free(expression);
    return amxd_status;
}

static amxd_status_t _openQuery(UNUSED amxd_object_t* object,
                                UNUSED amxd_function_t* func,
                                amxc_var_t* args,
                                amxc_var_t* ret) {

    amxd_status_t amxd_status = amxd_status_ok;
    amxd_object_t* query_obj = NULL;
    amxd_trans_t trans;
    dummy_query_t* query = NULL;
    amxc_var_t* matching_devices = NULL;

    if(queries == NULL) {
        amxc_htable_new(&queries, 0);
    }

    query = calloc(1, sizeof(dummy_query_t));
    query->expression = strdup(GET_CHAR(args, "expression"));
    query->name = strdup(GET_CHAR(args, "name"));
    amxc_set_init(&query->devices, false);
    assert_non_null(query->expression);
    assert_non_null(query->name);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Query.");
    amxd_trans_add_inst(&trans, 0, query->name);
    amxd_trans_set_value(cstring_t, &trans, "Expression", query->expression);
    amxd_trans_set_value(cstring_t, &trans, "Name", query->name);
    assert_int_equal(amxd_trans_apply(&trans, gmap_bus_dm), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    query_obj = amxd_dm_findf(gmap_bus_dm, "Devices.Query.%s.", query->name);
    assert_non_null(query_obj);
    query->index = amxd_object_get_index(query_obj);
    query->id = 1;
    query->obj = query_obj;
    char index_str[5];
    sprintf(index_str, "%d", query->index);
    amxc_htable_insert(queries, index_str, &query->it);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, ret, "id", query->id);
    amxc_var_add_key(uint32_t, ret, "index", query->index);
    amxc_var_add_key(cstring_t, ret, "name", query->name);

    matching_devices = amxc_var_add_new_key(ret, "devices");
    add_matching_devices(query, matching_devices);

    return amxd_status;

}

static amxd_status_t _closeQuery(amxd_object_t* object,
                                 amxd_function_t* func,
                                 amxc_var_t* args,
                                 amxc_var_t* ret) {
    amxc_htable_it_t* it = NULL;
    amxd_status_t amxd_status = amxd_status_ok;

    uint32_t index = GET_INT32(args, "index");
    char index_str[5];
    sprintf(index_str, "%d", index);

    it = amxc_htable_take(queries, index_str);
    if(it != NULL) {
        dummy_query_t* q = amxc_htable_it_get_data(it, dummy_query_t, it);
        amxc_htable_it_clean(&q->it, NULL);
        it = NULL;
        amxc_set_clean(&q->devices);
        free(q->expression);
        free(q->name);
        free(q);
        if(amxc_htable_is_empty(queries)) {
            amxc_htable_delete(&queries, NULL);
        }
    }
    amxd_status = _dummy_void(object, func, args, ret);
    return amxd_status;
}

static amxd_status_t _notify(UNUSED amxd_object_t* object,
                             UNUSED amxd_function_t* func,
                             amxc_var_t* args,
                             UNUSED amxc_var_t* ret) {
    const char* key = GET_CHAR(args, "key");
    uint32_t event_id = GET_UINT32(args, "id");
    // const char* event_name = GET_CHAR(args, "name");
    amxc_var_t* data = GET_ARG(args, "data");
    amxc_var_t sig_data;
    amxc_var_t* event_data = NULL;
    amxd_object_t* device_obj = NULL;
    assert_non_null(key);
    assert_string_not_equal(key, "");
    amxc_var_init(&sig_data);
    amxc_var_set_type(&sig_data, AMXC_VAR_ID_HTABLE);
    event_data = amxc_var_add_new_key(&sig_data, "Data");
    amxc_var_copy(event_data, data);
    amxc_var_add_key(uint32_t,
                     (amxc_var_t*) &sig_data,
                     "EventId", event_id);
    amxc_var_add_key(cstring_t,
                     (amxc_var_t*) &sig_data,
                     "Key", key);
    device_obj = amxd_dm_findf(gmap_bus_dm, "Devices.Device.%s.", "dummy");
    assert_non_null(device_obj);
    amxd_object_emit_signal(device_obj, "gmap_event", &sig_data);
    amxc_var_clean(&sig_data);
    return amxd_status_ok;
}

static amxd_status_t _setFunction(UNUSED amxd_object_t* object,
                                  UNUSED amxd_function_t* func,
                                  UNUSED amxc_var_t* args,
                                  amxc_var_t* ret) {
    amxc_var_set(bool, ret, true);
    return amxd_status_ok;
}

static amxd_status_t _removeFunction(UNUSED amxd_object_t* object,
                                     UNUSED amxd_function_t* func,
                                     UNUSED amxc_var_t* args,
                                     amxc_var_t* ret) {
    amxc_var_set(bool, ret, true);
    return amxd_status_ok;
}

static amxd_status_t _isImplemented(UNUSED amxd_object_t* object,
                                    UNUSED amxd_function_t* func,
                                    UNUSED amxc_var_t* args,
                                    amxc_var_t* ret) {
    amxc_var_set(bool, ret, true);
    return amxd_status_ok;
}

static amxd_status_t _csiFinished(UNUSED amxd_object_t* object,
                                  UNUSED amxd_function_t* func,
                                  UNUSED amxc_var_t* args,
                                  UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

static amxd_object_t* s_find_ip_obj(amxd_object_t* ip_template_obj, const char* ip) {
    assert_non_null(ip_template_obj);
    assert_non_null(ip);
    assert_string_not_equal(ip, "");
    assert_null(strchr(ip, '\''));
    return amxd_object_findf(ip_template_obj, "[Address ^= '%s']", ip);
}

static void s_dm_del_address(amxd_object_t* template,
                             const char* address) {
    amxd_trans_t transaction;
    amxd_object_t* instance = s_find_ip_obj(template, address);
    when_null(instance, exit);

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, template);
    amxd_trans_del_inst(&transaction, amxd_object_get_index(instance), NULL);
    assert_success(amxd_trans_apply(&transaction, gmap_bus_dm));

    amxd_trans_clean(&transaction);

exit:
    return;
}

static uint32_t __wrap_deleteAddressInstance(amxd_object_t* object,
                                             UNUSED amxd_function_t* func,
                                             amxc_var_t* args,
                                             UNUSED amxc_var_t* ret) {
    const char* address = GET_CHAR(args, "address");
    int result = (int) mock();

    check_expected(address);

    when_failed(result, exit);
    s_dm_del_address(object, address);

exit:
    return result;
}

static void s_dm_add_address(amxd_object_t* template,
                             const char* address,
                             const char* source,
                             const char* status,
                             const char* scope,
                             bool reserved) {
    amxd_trans_t transaction;

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, template);
    amxd_trans_add_inst(&transaction, 0, NULL);
    amxd_trans_set_value(cstring_t, &transaction, "Address", address);
    amxd_trans_set_value(cstring_t, &transaction, "AddressSource", source);
    if(scope != NULL) {
        amxd_trans_set_value(cstring_t, &transaction, "Scope", scope);
    }
    if(status != NULL) {
        amxd_trans_set_value(cstring_t, &transaction, "Status", status);
    }
    if(strcmp(amxd_object_get_name(template, AMXD_OBJECT_NAMED), "IPv4Address") == 0) {
        amxd_trans_set_value(bool, &transaction, "Reserved", reserved);
    }

    assert_success(amxd_trans_apply(&transaction, gmap_bus_dm));

    amxd_trans_clean(&transaction);
}

static uint32_t __wrap_addAddressInstance(amxd_object_t* object,
                                          UNUSED amxd_function_t* func,
                                          amxc_var_t* args,
                                          UNUSED amxc_var_t* ret) {
    int result = (int) mock();
    const char* address = GET_CHAR(args, "address");
    const char* source = GET_CHAR(args, "source");
    const char* status = GET_CHAR(args, "status");
    const char* scope = GET_CHAR(args, "scope");
    bool reserved = GET_BOOL(args, "reserved");

    check_expected(address);
    check_expected(status);
    check_expected(scope);
    check_expected(source);
    check_expected(reserved);

    when_failed(result, exit);
    s_dm_add_address(object, address, source, status, scope, reserved);

exit:
    return result;
}

static void s_dm_mod_address(amxd_object_t* template,
                             const char* address,
                             const char* source,
                             const char* status,
                             const char* scope,
                             const amxc_var_t* reserved) {
    amxd_trans_t transaction;
    amxd_object_t* instance = s_find_ip_obj(template, address);
    when_null(instance, exit);

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_select_object(&transaction, instance);
    if(source != NULL) {
        amxd_trans_set_value(cstring_t, &transaction, "AddressSource", source);
    }
    if(scope != NULL) {
        amxd_trans_set_value(cstring_t, &transaction, "Scope", scope);
    }
    if(status != NULL) {
        amxd_trans_set_value(cstring_t, &transaction, "Status", status);
    }
    if((reserved != NULL) && (strcmp(amxd_object_get_name(template, AMXD_OBJECT_NAMED), "IPv4Address") == 0)) {
        amxd_trans_set_value(bool, &transaction, "Reserved", GET_BOOL(reserved, NULL));
    }

    assert_success(amxd_trans_apply(&transaction, gmap_bus_dm));

    amxd_trans_clean(&transaction);

exit:
    return;
}

static uint32_t __wrap_setAddressInstance(UNUSED amxd_object_t* object,
                                          UNUSED amxd_function_t* func,
                                          amxc_var_t* args,
                                          UNUSED amxc_var_t* ret) {
    int result = (int) mock();
    const char* address = GET_CHAR(args, "address");
    const char* source = GET_CHAR(args, "source");
    const char* status = GET_CHAR(args, "status");
    const char* scope = GET_CHAR(args, "scope");
    bool reserved = GET_BOOL(args, "reserved");

    check_expected(address);
    check_expected(status);
    check_expected(scope);
    check_expected(source);
    check_expected(reserved);

    when_failed(result, exit);
    s_dm_mod_address(object, address, source, status, scope, GET_ARG(args, "reserved"));

exit:
    return result;
}

void mock_init_gmap(void) {
    amxb_bus_ctx_t* bus_ctx = amxut_bus_ctx();
    amxd_dm_t* bus_dm = amxut_bus_dm();
    amxo_parser_t* bus_parser = amxut_bus_parser();

    assert_non_null(bus_ctx);
    assert_non_null(bus_dm);
    assert_non_null(bus_parser);

    gmap_bus_dm = bus_dm;

    /* internal bookkeeping */
    amxo_resolver_ftab_add(bus_parser, "mock_device_added", AMXO_FUNC(_mock_device_added));
    amxo_resolver_ftab_add(bus_parser, "mock_device_removed", AMXO_FUNC(_mock_device_removed));
    amxo_resolver_ftab_add(bus_parser, "mock_device_changed", AMXO_FUNC(_mock_device_changed));
    amxo_resolver_ftab_add(bus_parser, "mock_device_subobject_update", AMXO_FUNC(_mmock_device_subobject_update));

    /* gmap-server rpc implementation */
    amxo_resolver_ftab_add(bus_parser, "openQuery", AMXO_FUNC(_openQuery));
    amxo_resolver_ftab_add(bus_parser, "closeQuery", AMXO_FUNC(_closeQuery));
    amxo_resolver_ftab_add(bus_parser, "createDevice", AMXO_FUNC(_createDevice));
    amxo_resolver_ftab_add(bus_parser, "destroyDevice", AMXO_FUNC(_destroyDevice));
    amxo_resolver_ftab_add(bus_parser, "matchingDevices", AMXO_FUNC(_matchingDevices));
    amxo_resolver_ftab_add(bus_parser, "notify", AMXO_FUNC(_notify));
    amxo_resolver_ftab_add(bus_parser, "setFunction", AMXO_FUNC(_setFunction));
    amxo_resolver_ftab_add(bus_parser, "removeFunction", AMXO_FUNC(_removeFunction));
    amxo_resolver_ftab_add(bus_parser, "isImplemented", AMXO_FUNC(_isImplemented));
    amxo_resolver_ftab_add(bus_parser, "csiFinished", AMXO_FUNC(_csiFinished));
    amxo_resolver_ftab_add(bus_parser, "deleteAddressInstance", AMXO_FUNC(__wrap_deleteAddressInstance));
    amxo_resolver_ftab_add(bus_parser, "addAddressInstance", AMXO_FUNC(__wrap_addAddressInstance));
    amxo_resolver_ftab_add(bus_parser, "setAddressInstance", AMXO_FUNC(__wrap_setAddressInstance));

    gmap_client_set_mib_server_dm(bus_dm);

    amxut_dm_load_odl("../common/mock_gmap.odl");

    amxut_bus_handle_events();
}

void mock_clean_gmap(void) {
    amxc_htable_delete(&devices, s_device_clean);
    gmap_ipquery_cleanup();
    gmap_bus_dm = NULL;
}
