/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <math.h>

#include "processmonitor.h"

static processmonitor_t processmonitor;

amxd_dm_t* get_dm(void) {
    return processmonitor.dm;
}

amxo_parser_t* processmonitor_get_parser(void) {
    return processmonitor.parser;
}

static void pm_reboot(const char* reason) {
    amxb_bus_ctx_t* bus_ctx = NULL;
    amxc_var_t args;
    amxc_var_t ret;
    int rv = -1;

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_init(&ret);

    bus_ctx = amxb_be_who_has("Device.");
    when_null_trace(bus_ctx, exit, ERROR, "Failed to get the context bus.");

    amxc_var_add_key(cstring_t, &args, "Cause", "LocalReboot");
    amxc_var_add_key(cstring_t, &args, "Reason", reason);
    rv = amxb_call(bus_ctx, "Device.", "Reboot", &args, &ret, 5);
    when_failed_trace(rv, exit, ERROR, "Failed to call Device.Reboot() for object: %d", rv);

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return;
}

static void pm_do_reboot_debug(processmonitor_t* pm) {
    struct stat statbuf;
    time_t now;
    struct tm reboot_start = {0};

    time(&now);
    amxc_ts_to_tm_utc(&pm->reboot_start, &reboot_start);

    if(!stat(PM_DEBUG_INFORMATION_FILE, &statbuf)) {
        SAH_TRACEZ_ERROR(ME, "Debug information is in, executing NMC reboot.");

        pm_reboot("ProcessMonitor");
        pm->reboot_stage = PM_REBOOT_STAGE_NMC;
        amxp_timer_start(pm->reboot, PM_REBOOT_STAGE_TIMEOUT);

        SAH_TRACEZ_ERROR(ME, "System entered the NetModeConfig Reboot stage");
    } else if(now >= timegm(&reboot_start) + PM_GET_DEBUG_MAX_TIMEOUT) {
        SAH_TRACEZ_ERROR(ME, "Debug information not yet in after %d seconds, executing NMC reboot.", PM_GET_DEBUG_MAX_TIMEOUT);

        pm_reboot("ProcessMonitor");
        pm->reboot_stage = PM_REBOOT_STAGE_NMC;
        amxp_timer_start(pm->reboot, PM_REBOOT_STAGE_TIMEOUT);

        SAH_TRACEZ_ERROR(ME, "System entered the NetModeConfig Reboot stage");
    } else {
        SAH_TRACEZ_ERROR(ME, "Debug information not yet in, waiting ...");
        amxp_timer_start(pm->reboot, PM_REBOOT_DEBUG_TIMEOUT);
    }
}

static void pm_do_reboot_stage(UNUSED amxp_timer_t* timer, void* priv) {
    processmonitor_t* pm = (processmonitor_t*) priv;

    when_null_trace(pm, exit, ERROR, "Programming error, unexpected NULL pointer");

    switch(pm->reboot_stage) {
    case PM_REBOOT_STAGE_DEBUG:
        pm_do_reboot_debug(pm);

        break;
    case PM_REBOOT_STAGE_NMC:
        SAH_TRACEZ_ERROR(ME, "System still active after NetModeConfig reboot, trying with Shell reboot");

        if(system("reboot") < 0) {
            SAH_TRACEZ_ERROR(ME, "Error executing the reboot command");
        }

        pm->reboot_stage = PM_REBOOT_STAGE_SHELL;
        amxp_timer_start(pm->reboot, PM_REBOOT_STAGE_TIMEOUT);

        SAH_TRACEZ_ERROR(ME, "System entered the Shell Reboot stage");
        break;
    default:
        break;
    }

exit:
    return;
}

/**
 * @brief   Callback to compute the minimum test interval for PM tests using the AMX timer.
 *
 * @details This function determines the next test to execute by comparing
 *          difftime(last_check + test_current_test_interval, now) against each test's
 *          current_test_interval. It selects the test with the minimum interval
 *          and updates pm->next_test accordingly for execution via pm_do_test.
 *
 *          Additionally it takes care to update pm_num_valid_test & pm_last_test when getting
 *          called from pm_handle_test_update() with controlled bt ` pm_test_update` flag
 *
 *          If the computed test interval is less than or equal to 3 seconds,
 *          it defaults to 3 seconds to avoid overly frequent checks.
 *
 * @param   pm  Pointer to the process monitor (PM) data structure.
 * @param   pm_test_update bool flag to indicate its being called for pm_test_handle_update() or not
 * @return void
 */
void pm_compute_test_interval(processmonitor_t* pm, bool pm_test_update) {
    struct tm tm_last_check_since = {0};
    time_t next_check_scheduled;
    time_t now;
    time_t last_check;
    uint32_t min_test_interval;
    test_t* initial_test = NULL;

    when_null_trace(pm, exit, ERROR, "PM is NULL");
    when_null_trace(pm->object, exit, ERROR, "PM object is NULL");

    pm->test_interval = 0;
    time(&now);
    amxc_llist_for_each(lit, &(pm->tests)) {
        test_t* temp_test = amxc_llist_it_get_data(lit, test_t, it);
        if(temp_test->valid_conf != 0) {
            if(temp_test->current_test_interval > 0) {
                min_test_interval = temp_test->current_test_interval;
                amxc_ts_to_tm_utc(&temp_test->last_check, &tm_last_check_since);
                last_check = timegm(&tm_last_check_since);
                if(last_check > 0) {
                    next_check_scheduled = last_check + temp_test->current_test_interval;
                    min_test_interval = (now > next_check_scheduled)? 0:difftime(next_check_scheduled, now);
                }

                if(initial_test == NULL) {
                    pm->next_test = lit;
                    pm->test_interval = min_test_interval;
                    initial_test = temp_test;
                } else {
                    if(!temp_test->initialized && !pm_test_update && (last_check < 0)) {
                        pm->next_test = lit;
                        pm->test_interval = 0;
                        break;
                    }
                    if(min_test_interval < pm->test_interval) {
                        pm->test_interval = min_test_interval;
                        pm->next_test = lit;
                    }
                }
            }

            if(pm_test_update) {
                pm->num_valid_tests++;
                // stores the last valid test within pm framework on each pm_handle_test_update()
                pm->last_test = lit;
            }
        }
    }

    pm->test_interval = (((int32_t) pm->test_interval) > PM_MINIMUM_TEST_INTERVAL_TIMER)? pm->test_interval:PM_MINIMUM_TEST_INTERVAL_TIMER;

exit:
    return;
}

/**
 * @brief reschedules the amx timer if the new interval is less than the remaining timei
 * on the current timer.
 *
 * This function compares new pm_test_interval with the previously set interval.
 * If the new interval is shorter than the current one, it computes the remaining time
 * on the active timer and adjusts the timer to trigger the next callback earlier.
 *
 * The adjustment ensures that the test logic remains responsive to dynamic
 * interval changes without waiting for the original timer to expire.
 *
 * @param pm  Pointer to the process monitor (PM) data structure.
 * @return void
 *
 */
void pm_test_reschedule_timer_with_new_computed_interval(uint32_t prev_test_interval, uint32_t cur_test_interval) {
    uint32_t diff = 0;
    uint32_t rem = 0;

    processmonitor_t* pm = pm_get_process_monitor();
    if(pm->testing_active && (amxp_timer_get_state(pm->timer_test) == amxp_timer_running) && (cur_test_interval < prev_test_interval)) {
        diff = (prev_test_interval - cur_test_interval) * 1000;
        rem = amxp_timer_remaining_time(pm->timer_test);

        if(rem > diff) {
            amxp_timer_start(pm->timer_test, rem - diff);
        } else {
            amxp_timer_start(pm->timer_test, 0);
        }
    }
}

processmonitor_t* pm_get_process_monitor(void) {
    return &processmonitor;
}

/**
 * @brief   Callback function to retrieve the initialized static process monitor batch test data context from pm container.
 *
 * @details This function returns a pointer to the statically initialized process monitor batch test data container
 *          which holds the configuration  - batch test start flag, batch_in_test, batch_complete_test for handling
 *          batch test operations. It is typically used to access shared processmonitor batch test resources
 *
 * @return  Pointer to the static process monitor batch test data context.
 */
processmonitor_batch_test_t* pm_get_process_monitor_batch_test(void) {
    return &processmonitor.processmonitor_batch_test;
}

/**
 * @brief   Retrieves the static Amx bus context for service event handling.
 * @details This callback function returns a pointer to the statically initialized process monitor
 *          Amx bus context container. It encapsulates the Amx bus context used for managing service events
 *          and provides access to shared process monitor resources.
 *
 * @return  Pointer to the static process monitor Amx bus context.
 */
amxb_bus_ctx_t* PRIVATE pm_get_service_ctx(void) {
    processmonitor_t* pm = pm_get_process_monitor();
    pm->bus_ctx = amxb_be_who_has("service");
    return pm->bus_ctx;
}

bool pm_select_next_test(processmonitor_t* pm) {
    bool res = false;
    amxc_llist_it_t* test = NULL;

    if(pm->num_valid_tests == 0) {
        pm->next_test = NULL;
        goto exit;
    }

    if(pm->next_test != NULL) {
        test = amxc_llist_it_get_next(pm->next_test);
    } else {
        test = amxc_llist_get_first(&(pm->tests));
    }

    // move to next valid test or end of list (test == NULL)
    for(; test && !(((test_t*) amxc_container_of(test, test_t, it))->valid_conf); test = amxc_llist_it_get_next(test)) {
    }

    // if end of list, start from the beginning and search for a valid test
    if(test == NULL) {
        for(test = amxc_llist_get_first(&(pm->tests)); test && !(((test_t*) amxc_container_of(test, test_t, it))->valid_conf); test = amxc_llist_it_get_next(test)) {
        }
    }

    pm->next_test = test;
    when_null_trace(test, exit, ERROR, "Programming error - There should be a valid test, but I can't find it!");

    res = true;

exit:
    return res;
}

bool pm_handle_test_update(processmonitor_t* pm, test_t* test) {
    bool res = false;

    when_null(pm->timer_test, exit);

    // update valid tests & compute the pm->test_interval, reschedule amxp timer if computed interval < current interval
    pm->num_valid_tests = 0;
    uint32_t prev_test_interval = pm->test_interval;
    if(!test->initialized || !pm->next_test) {
        pm_compute_test_interval(pm, true);
        pm_test_reschedule_timer_with_new_computed_interval(prev_test_interval, pm->test_interval);
    }

    SAH_TRACEZ_NOTICE(ME, "Total PM Test: %d, Total Valid PM Test: %d, Computed PM Test Interval: %d", pm->num_tests, pm->num_valid_tests, pm->test_interval);

    if((&(test->it) == pm->next_test) && (test->valid_conf == false)) {
        pm_select_next_test(pm);
    }

    if(pm->testing_active && !pm->num_valid_tests) {
        SAH_TRACEZ_NOTICE(ME, "No valid configurations, stop testing");
        amxp_timer_stop(pm->timer_test);
        pm->testing_active = false;
    } else if(!pm->testing_active && pm->num_valid_tests) {
        SAH_TRACEZ_NOTICE(ME, "Valid configurations, start testing");
        if(pm->next_test == NULL) {
            pm_select_next_test(pm);
        }
        amxp_timer_start(pm->timer_test, 0);
        pm->testing_active = true;
    }
    res = true;

exit:
    return res;
}

void pm_perform_reboot(processmonitor_t* pm, const char* reason, amxc_ts_t ts_now) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    when_true_trace(pm->reboot_stage != PM_REBOOT_STAGE_NONE, exit, ERROR, "Got new reboot request, but system is already in reboot stage");

    amxd_trans_select_object(&trans, pm->object);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    /* Stop the tests! */
    amxp_timer_stop(pm->timer_test);

    amxd_trans_set_value(amxc_ts_t, &trans, "LastReboot", &ts_now);
    amxd_trans_set_value(cstring_t, &trans, "RebootReason", reason);

    if(amxd_trans_apply(&trans, get_dm()) != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed");
    }

    SAH_TRACEZ_ERROR(ME, "Rebooting the system: '%s'", reason);
    SAH_TRACEZ_ERROR(ME, "Retrieving debug information...");

    unlink(PM_DEBUG_INFORMATION_FILE);
    if(system("(/bin/getDebugInformation " PM_DEBUG_INFORMATION_FILE ".tmp; mv -f " PM_DEBUG_INFORMATION_FILE ".tmp " PM_DEBUG_INFORMATION_FILE ") &") < 0) {
        SAH_TRACEZ_ERROR(ME, "Error executing the getDebugInformation command");
    }

    pm->reboot_stage = PM_REBOOT_STAGE_DEBUG;
    pm->reboot_start = ts_now;
    amxp_timer_start(pm->reboot, PM_REBOOT_DEBUG_TIMEOUT);

    SAH_TRACEZ_ERROR(ME, "System entered the Debug Reboot stage");

exit:
    amxd_trans_clean(&trans);
}


/**
 * @brief Fetches respawn param configured for PM test and populate them in their Amx datamodel.
 *
 * This function queries the UBUS call service list on PM test to gather its respawn params and it populates those
 * configured respawn param with its corresponding Amx datamodel configuration [pm->test[i].Respawn].
 *
 * if respawn params not configured/process monitor flag not enabled, will set it to -1 else will do ubus query as
 * stated above. The respawn parameters typically include settings such as restart thresholds, retry intervals, and
 * failure handling policies, which are essential for ensuring robust process management during testing scenarios.
 *
 * @note This function assumes that the Amx datamodel is properly initialized and
 * accessible, and that the UBUS service list contains valid entries for PM test processes.
 *
 * @param test pointer to the current PM Test
 *
 * @return void
 */

void pm_test_update_process_respawn_params(test_t* test) {

    amxb_bus_ctx_t* bus_ctx = NULL;
    amxc_var_t result;
    amxc_var_t args;
    amxd_trans_t transaction;
    int rv = -1;
    int32_t process_respawn_threshold = -1;
    int32_t process_respawn_retry = -1;
    int32_t process_respawn_timeout = -1;

    amxc_var_init(&args);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", test->name);

    amxc_var_init(&result);

    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);

    amxd_object_t* respawnObj = amxd_object_get_child(test->object, "ProcessRespawnParams");
    when_null(respawnObj, exit);

    amxd_trans_select_object(&transaction, respawnObj);

    bus_ctx = amxb_be_who_has(PM_PROCESS_SUPERVISOR_ROOT_OBJ);
    when_null_trace(bus_ctx, exit, ERROR, "Failed to get amx bus ctx for process/service events");

    rv = amxb_call(bus_ctx, "service.", "list", &args, &result, 5);

    when_failed_trace(rv, exit, ERROR, "Failed to call service.list() for service:%s with error code: %d", test->name, rv);
    when_null_trace(&result, exit, ERROR, "Failed to fetch the result from ubus call service list for service:%s", test->name);

    amxc_var_t* pm_test_data = amxc_var_get_first(amxc_var_get_first(&result));
    when_null_trace(pm_test_data, exit, NOTICE, "Procd seems not configured for service:%s", test->name);

    amxc_var_t* pm_respawn_params = GET_ARG(amxc_var_get_first(amxc_var_get_first(pm_test_data)), "respawn");
    when_null_trace(pm_respawn_params, exit, INFO, "Procd configured but respawn doesnt for service:%s", test->name);

    process_respawn_threshold = GET_INT32(pm_respawn_params, "threshold");
    process_respawn_timeout = GET_INT32(pm_respawn_params, "timeout");
    process_respawn_retry = GET_INT32(pm_respawn_params, "retry");

exit:
    amxd_trans_set_value(int32_t, &transaction, "Threshold", process_respawn_threshold);
    amxd_trans_set_value(int32_t, &transaction, "Timeout", process_respawn_timeout);
    amxd_trans_set_value(int32_t, &transaction, "RetryAttempts", process_respawn_retry);

    if(amxd_trans_apply(&transaction, get_dm()) != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Transaction failed on Respawn param update for Test: %s", test->name);
    }
    amxd_trans_clean(&transaction);
    amxc_var_clean(&args);
    amxc_var_clean(&result);
    return;
}

/**
 * @brief Initializes and executes the next test in the ProcessMonitor batch sequence.
 *
 * This function manages the progression of batch test execution within the ProcessMonitor (PM) framework.
 * It performs the following operations:
 *
 * - Sets the `pm_batch_test_start` flag to `true` to initiate batch processing for up to
 *   `PM_TEST_BATCH_SIZE` (15) jobs when the number of pending jobs is less than
 *   `PM_TEST_BATCH_MIN_PENDING_THRESHOLD` (<3). Otherwise, the flag is set to `false` to wait
 *   until pending jobs are reduced.
 *
 * - Resets `batch_in_test` to `batch_in_test - batch_complete_test` and sets `batch_complete_test`
 *   to 0 at the start of each batch iteration to maintain synchronization.
 *
 * - Executes `pm->next_test` as the current test if it is valid and not already active.
 *
 * - Initially, `pm->next_test` points to the first test in the sequence and is updated to the next
 *   valid test ready for execution using pm_check_if_perform_test() . Once the sequence completes,
 *   it cycles back to the first test.
 *
 * - For each valid `pm->next_test`, the test is executed and a timer is restarted with a default
 *   interval of 500ms to continue the looped execution.
 *
 * - After completing a batch, the timer is restarted with a 3-second interval to monitor readiness
 *   for the next batch, based on the condition: pending jobs <= `PM_TEST_BATCH_MIN_PENDING_THRESHOLD`.
 *
 * - Once all tests in the sequence(first_test..pm_last_test) are completed, the function computes the
 *   minimum test interval and restarts the timer with that interval to begin the next sequence.
 *
 * @return void
 */

void pm_do_test(amxp_timer_t* timer, void* priv) {
    processmonitor_t* pm = (processmonitor_t*) priv;
    processmonitor_batch_test_t* pm_batch_test = &pm->processmonitor_batch_test;
    bool pm_next_test_availed = false;

    when_null_trace(pm, exit, ERROR, "Programming error, unexpected NULL pointer");
    when_null_trace(pm_batch_test, exit, ERROR, "Programming error, unexpected NULL pointer");
    when_null_trace(pm->next_test, exit, INFO, "pm->next_test seems to be not available to start pm_do_test");

    SAH_TRACEZ_INFO(ME, "Do Test() - pm_batch_in_test: (%d) , pm_batch_complete_test:(%d)", pm_batch_test->pm_batch_in_tests, pm_batch_test->pm_batch_complete_tests);

    // Sets the `pm_batch_test_start` flag to `true` to initiate batch processing up to `PM_TEST_BATCH_SIZE` (10) jobs when the number of pending jobs is less than `PM_TEST_BATCH_MIN_PENDING_THRESHOLD` (<=3)
    if(!pm_batch_test->pm_batch_test_start && (pm_batch_test->pm_batch_in_tests - pm_batch_test->pm_batch_complete_tests <= PM_TEST_BATCH_MIN_PENDING_THRESHOLD)) {
        SAH_TRACEZ_INFO(ME, "Setting pm_batch_test : true, satisfying condition pm_batch_in_test - pm_batch_complete_test (%d - %d) < 5", pm_batch_test->pm_batch_in_tests, pm_batch_test->pm_batch_complete_tests);
        pm_batch_test->pm_batch_test_start = true;
        pm_batch_test->pm_batch_in_tests = pm_batch_test->pm_batch_in_tests - pm_batch_test->pm_batch_complete_tests;
        pm_batch_test->pm_batch_complete_tests = 0;
    }
    //else Sets `pm_batch_test_start` flag to `false` to hold on once the outstanding pending jobs came below `PM_TEST_BATCH_MIN_PENDING_THRESHOLD`
    else {
        if(pm_batch_test->pm_batch_test_start && (pm_batch_test->pm_batch_in_tests >= PM_TEST_BATCH_SIZE)) {
            SAH_TRACEZ_INFO(ME, "Setting pm_batch_test : false, satisfying condition pm_batch_in_test(%d) > %d & current pm_batch_complete_test are %d for reference", pm_batch_test->pm_batch_in_tests, PM_TEST_BATCH_SIZE, pm_batch_test->pm_batch_complete_tests);
            pm_batch_test->pm_batch_test_start = false;
        }
    }

    // Initialize & execute pm->next_test once its available.
    // it defaults to 1st test if null (or) point to next valid test ready for execution once initialized
    if(pm_batch_test->pm_batch_test_start) {
        test_t* cur_test = (test_t*) amxc_container_of(pm->next_test, test_t, it);
        if(!cur_test->active && cur_test->valid_conf) {
            pm_initialize_test(cur_test);
            pm_perform_test(cur_test, pm_batch_test);
        }

        // if pm->last_test once executed, compute test interval and restart timer with computed test interval
        if(pm->next_test == pm->last_test) {
            pm_compute_test_interval(pm, false);
            amxp_timer_start(timer, pm->test_interval * 1000);
        } else {
            // Use pm_check_if _perform_test() to get the next valid test ready for execution. Skip the not ready execution tests till it computes the first. Also if test in not initialized though, take into account for next validation
            pm_select_next_test(pm);
            for(; pm->next_test != NULL; pm_select_next_test(pm)) {
                test_t* pm_next_test = (test_t*) amxc_container_of(pm->next_test, test_t, it);
                if(!pm_next_test->initialized || (!pm_next_test->active &&
                                                  pm_check_if_perform_test(pm_next_test))) {
                    pm_next_test_availed = true;
                    break;
                }
                if(pm->next_test == pm->last_test) {
                    pm_select_next_test(pm);
                    break;
                }
            }
            if(pm_next_test_availed) {
                // After above computation If pm->next_test points to next test in same sequence , start back the Timer with default timer as 500ms
                amxp_timer_start(timer, PM_TEST_DEFAULT_CHECK_TIMER);

            } else {
                // If pm->next_test cycles back to first test on next sequence , compute minimum test interval and start back the Timer with the same for next iteration
                pm_compute_test_interval(pm, false);
                amxp_timer_start(timer, pm->test_interval * 1000);
            }
        }
    }
    // wait for PM_TEST_BATCH_COMPLETION_CHECK_TIMER seconds (3s) to check for next batch readiness once the current batch completed
    else {
        amxp_timer_start(timer, PM_TEST_BATCH_COMPLETION_CHECK_TIMER * 1000);
    }

exit:
    return;
}

static int32_t initialize(amxd_dm_t* dm, amxo_parser_t* parser) {
    int32_t res = -1;
    processmonitor.dm = dm;
    processmonitor.parser = parser;
    processmonitor.object = amxd_dm_get_object(dm, "ProcessMonitor");

    amxc_llist_init(&(processmonitor.tests));
    //calling pm_subscribe_service_events() to enable subscription for service/process events
    res = pm_subscribe_service_events();
    when_failed_trace(res, exit, ERROR, "Failed to subscribe for service/process events via amxb subscribe call");

    when_failed_trace(amxp_timer_new(&processmonitor.timer_test, pm_do_test, &processmonitor), exit, ERROR, "Failed to create timer for do_test");

    when_failed_trace(amxp_timer_new(&processmonitor.reboot, pm_do_reboot_stage, &processmonitor), exit, ERROR, "Failed to create timer for do_reboot_stage");

    res = 0;

exit:
    return res;
}

static void test_delete(amxc_llist_it_t* it) {
    test_t* test = amxc_container_of(it, test_t, it);
    pm_release_test(test);
}

static int32_t cleanup(void) {
    amxp_timer_delete(&(processmonitor.timer_test));
    amxp_timer_delete(&(processmonitor.reboot));
    amxc_llist_clean(&(processmonitor.tests), test_delete);
    //calling pm_unsubscribe_service_events() to disable subscription for service/process events during exit process
    pm_unsubscribe_service_events();
    processmonitor.dm = NULL;
    processmonitor.parser = NULL;
    return 0;
}

amxd_status_t _pm_read_test_interval(UNUSED amxd_object_t* object,
                                     UNUSED amxd_param_t* param,
                                     amxd_action_t reason,
                                     UNUSED const amxc_var_t* const args,
                                     amxc_var_t* const retval,
                                     UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_ok;
    processmonitor_t* pm = pm_get_process_monitor();

    when_true_status(reason != action_param_read, exit, status = amxd_status_function_not_implemented);

    amxc_var_set_uint32_t(retval, (uint32_t) (pm->test_interval));
exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}


int _processmonitor_main(int reason,
                         amxd_dm_t* dm,
                         amxo_parser_t* parser) {
    int retval = 0;
    switch(reason) {
    case 0:     // START
        SAH_TRACEZ_INFO(ME, "Starting %s", ME);
        retval = initialize(dm, parser);
        break;
    case 1:     // STOP
        SAH_TRACEZ_INFO(ME, "Stoping %s", ME);
        retval = cleanup();
        break;
    }

    return retval;
}
