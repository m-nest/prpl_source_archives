/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "conntrackingquery.h"
#include <amxp/amxp_subproc.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

/* ct query flows command, process args */
#define CT_ARG_LENGTH 128
#define CT_MAX_CMD_ARGS 20
#define CT_PROCESS_TIMEOUT   30000

/* JSON record parameters */
#define CT_MAX_RECORDS 256
#define MAX_LINE_LEN 512
#define MAX_JSON_LEN 8192

static int16_t ct_max_entries;

/**
 * @brief Allocate Memory for the records
 *
 * This function allocates memory for the record structure , where the results will be filled
 *
 * @param filename		Retrieve Command filename where the results are popluated
 * @param records_list	Pointer to the retrieve list where the results are stored as list
 *
 * @return Record*		Pointer to the allocated memory
 */
static Record* allocate_records (int record_count) {
    return (calloc(record_count, sizeof(Record)));
}

/**
 * @brief free Memory for the record
 *
 * This function frees the memory for the allocated record structure
 *
 * @param Record*		Pointer to the record whose memory has to be freed
 */
static void free_records (Record* records) {
    free(records);
}

/**
 * @brief converts the ct_query results in to record objects
 *
 * This function reads through the ct_query results, line by line
 * and creates record objects.  It allocates only up to the max entries size.
 *
 * @param	filename		Retrieve Command filename where the results are popluated
 * @param	records_list	Pointer to the retrieve list where the results are stored as list
 *
 * @return	int			number of records populated
 */
static int populate_records_from_ct_results (const char* filename, Record** records_list) {

    FILE* file = fopen(filename, "r");
    char line[MAX_LINE_LEN];
    int record_count = 0;
    Record* records = NULL;

    when_null_trace(file, exit, ERROR, "ct results file couldnt be opened\n");
    records = allocate_records(ct_max_entries);
    when_null_trace(records, exit, ERROR, "ct results file couldnt be opened\n");

    while(fgets(line, sizeof(line), file) && record_count < ct_max_entries) {
        Record r;
        memset(&r, 0, sizeof(r));
        sscanf(line, "src=%31s dst=%31s proto=%7s sport=%7s dport=%7s packets=%d bytes=%d packets=%d bytes=%d",
               r.src, r.dst, r.proto, r.sport, r.dport, &(r.o_packets), &(r.o_bytes), &(r.r_packets), &(r.r_bytes));
        records[record_count++] = r;
    }
    fclose(file);
    *records_list = records;

exit:
    return record_count;
}

/**
 * @brief Stops the worker process associated with the given query.
 *
 * This function checks if the worker process is running and attempts to
 * terminate it gracefully using SIGTERM. If the process does not stop within
 * the timeout, it forcefully kills it using SIGKILL. Logs are generated to
 * indicate the status of the operation.
 *
 * @param  query	Pointer to ther query
 * @return bools	Returns true if the worker was successfully stopped or was already stopped,
 *         false otherwise.
 */
bool stop_notify_query_worker (query_t* query) {
    int rv = -1;
    when_null(query, exit);

    when_null_status(query->process, exit, rv = 0);

    if(!amxp_subproc_is_running(query->process)) {
        SAH_TRACEZ_ERROR(ME, "worker already stopped");
        rv = 0;
        goto cleanup;
    }

    SAH_TRACEZ_INFO(ME, "Killing the worker process");
    amxp_subproc_kill(query->process, SIGTERM);
    rv = amxp_subproc_wait(query->process, 1000);
    if(rv != 0) {
        SAH_TRACEZ_WARNING(ME, "worker won't stop, send SIGKILL");
        amxp_subproc_kill(query->process, SIGKILL);
        amxp_subproc_wait(query->process, 500);
    } else {
        SAH_TRACEZ_INFO(ME, "Stopping worker");
    }

cleanup:
    amxp_subproc_delete(&query->process);

exit:
    return rv == 0;
}

/**
 * @brief Starts a worker subprocess based on the parameters in the given query.
 *
 * This function initializes a new subprocess and constructs a command-line
 * argument list using the query's protocol, source/destination IPs, and ports.
 * It then launches the worker process with these arguments and logs the status.
 *
 * @param query		pointer to the query object
 *
 * @return bool		true if the worker process was successfully started, false otherwise.
 */
bool start_notify_query_worker(query_t* query) {

    bool retval = false;
    when_null(query, exit);

    when_failed_trace(amxp_subproc_new(&query->process), exit, ERROR, "amxp_subprocess: conntrack_worker_notify malloc failed");

    SAH_TRACEZ_INFO(ME, "amxp_subprocess: conntrack_worker_notify memory allocation successful");
    amxc_array_t cmd;
    amxc_array_init(&cmd, CT_MAX_CMD_ARGS);
    amxc_array_append_data(&cmd, (void*) "/usr/bin/conntrack_worker_notify");

    char arg_string[CT_MAX_CMD_ARGS - 1][CT_ARG_LENGTH];
    int arg = 0;

    if(!amxc_string_is_empty(&(query->protocol))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--proto=%s", amxc_string_get(&(query->protocol), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;

    }
    if(!amxc_string_is_empty(&(query->src_ip))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--src-ip=%s", amxc_string_get(&(query->src_ip), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(!amxc_string_is_empty(&(query->dst_ip))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--dst-ip=%s", amxc_string_get(&(query->dst_ip), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(!amxc_string_is_empty(&(query->src_port))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--sport=%s", amxc_string_get(&(query->src_port), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(!amxc_string_is_empty(&(query->dst_port))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--dport=%s", amxc_string_get(&(query->dst_port), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(!amxc_string_is_empty(&(query->event))) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        sprintf(arg_string[arg], "--event=%s", amxc_string_get(&(query->event), 0));
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }

    if(amxp_subproc_astart(query->process, &cmd) != 0) {
        SAH_TRACEZ_ERROR(ME, "amxp_subprocess: conntrack_worker_notify start failed");
        amxp_subproc_delete(&query->process);
        amxc_array_clean(&cmd, NULL);
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "amxp_subprocess: conntrack_worker_notify started successfully");
    amxc_array_clean(&cmd, NULL);
    retval = true;

exit:
    return retval;
}

/**
 * @brief Parses a text file containing network connection records and converts them to a list of records
 *
 * This function reads each line from the specified file, extracts connection details such as
 * source/destination IPs, protocol, and ports.
 *
 *
 * @param  filename		Path to the input file containing connection records.
 * @return amxc_var_t*	A pointer to the list of records, or NULL on failure.
 */
static amxc_var_t* parse_ctquery_results_to_varlist(const char* filename) {
    Record* records = NULL;
    int record_count = populate_records_from_ct_results(filename, &records);
    amxc_var_t* list_var = NULL;

    when_failed_trace(amxc_var_new(&list_var), exit, ERROR, "Failed to create amxc_var");
    amxc_var_set_type(list_var, AMXC_VAR_ID_LIST);

    if(record_count == 0) {
        SAH_TRACEZ_ERROR(ME, "Returning Empty Records");
        amxc_var_delete(&list_var);
        goto exit;
    }

    for(int i = 0; i < record_count; i++) {
        amxc_var_t* htable_var = amxc_var_add(amxc_htable_t, list_var, NULL);
        amxc_var_set_type(htable_var, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, htable_var, "SourceIP", records[i].src);
        amxc_var_add_key(cstring_t, htable_var, "DestIP", records[i].dst);
        amxc_var_add_key(cstring_t, htable_var, "Protocol", records[i].proto);
        amxc_var_add_key(cstring_t, htable_var, "SourcePort", records[i].sport);
        amxc_var_add_key(cstring_t, htable_var, "DestPort", records[i].dport);
        amxc_var_add_key(uint32_t, htable_var, "TxPackets", records[i].o_packets);
        amxc_var_add_key(uint32_t, htable_var, "TxBytes", records[i].o_bytes);
        amxc_var_add_key(uint32_t, htable_var, "RxPackets", records[i].r_packets);
        amxc_var_add_key(uint32_t, htable_var, "RxBytes", records[i].r_bytes);
    }

exit:
    free_records(records);
    return list_var;
}

/**
 * @brief Starts and and execute a conntrack query
 *
 * This function spawns a process and executes the passed cmd
 *
 * @param  cmd Array of command parameters
 * @return int returns 1 on success and -1 on failure
 */
static int start_and_execute_ctworker(amxc_array_t* cmd) {
    amxp_subproc_t* process = NULL;
    pid_t child_pid;
    int retval = -1;

    when_failed_trace(amxp_subproc_new(&process), exit, ERROR, "amxp_subprocess: conntrack_worker_retrieve malloc failed");

    SAH_TRACEZ_INFO(ME, "amxp_subprocess: conntrack_worker_retrieve successful Memory allocation");

    int ret_status = amxp_subproc_astart(process, cmd);
    if(ret_status != 0) {
        SAH_TRACEZ_ERROR(ME, "amxp_subprocess: conntrack_worker_retrieve, failed to start");
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "amxp_subprocess: conntrack_worker_retrieve, subprocess started");
    child_pid = amxp_subproc_get_pid(process);
    SAH_TRACEZ_INFO(ME, "subprocess :%d started", child_pid);
    if(amxp_subproc_is_running(process)) {
        SAH_TRACEZ_INFO(ME, "retrieve subprocess running");
    }
    /* Wait for the subprocess to finish */
    amxp_subproc_wait(process, CT_PROCESS_TIMEOUT);
    retval = 1;

exit:
    amxp_subproc_delete(&process);
    return retval;
}

/**
 * @brief Parses the input parameters, creates the command and spawns a subprocess
 *
 * This function parses the input parameters, creates the command and spawns a
 * subprocess using start_and_execute_ctworker
 *
 * @param  args Arguments recived from the dm query
 * @return int returns 1 on success and -1 on failure
 */
static int execute_ctquery (amxc_var_t* args) {
    amxc_var_t* protocol = GET_ARG(args, "Protocol");
    amxc_var_t* src_ip = GET_ARG(args, "SourceIP");
    amxc_var_t* dst_ip = GET_ARG(args, "DestIP");
    amxc_var_t* src_port = GET_ARG(args, "SourcePort");
    amxc_var_t* dst_port = GET_ARG(args, "DestPort");
    amxc_var_t* max_retrieve_entries = GET_ARG(args, "MaxRtrvEntries");

    char* proto_txt = amxc_var_dyncast(cstring_t, protocol);
    char* src_ip_txt = amxc_var_dyncast(cstring_t, src_ip);
    char* dst_ip_txt = amxc_var_dyncast(cstring_t, dst_ip);
    char* src_port_txt = amxc_var_dyncast(cstring_t, src_port);
    char* dst_port_txt = amxc_var_dyncast(cstring_t, dst_port);
    ct_max_entries = amxc_var_dyncast(int16_t, max_retrieve_entries);
    if((ct_max_entries == 0)) {
        ct_max_entries = CT_MAX_RECORDS;
    }

    amxc_array_t cmd;
    amxc_array_init(&cmd, CT_MAX_CMD_ARGS);
    amxc_array_append_data(&cmd, (void*) "/usr/bin/conntrack_worker_retrieve");

    char arg_string[CT_MAX_CMD_ARGS - 1][CT_ARG_LENGTH];
    int arg = 0;

    if(proto_txt != NULL) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--proto=%s", proto_txt);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(src_ip_txt != NULL) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--src-ip=%s", src_ip_txt);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(dst_ip_txt != NULL) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--dst-ip=%s", dst_ip_txt);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(src_port_txt != NULL) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--sport=%s", src_port_txt);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }
    if(dst_port_txt != NULL) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--dport=%s", dst_port_txt);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;
    }

    if(ct_max_entries) {
        memset(arg_string[arg], 0, CT_ARG_LENGTH);
        snprintf(arg_string[arg], CT_ARG_LENGTH, "--r_size=%d", ct_max_entries);
        amxc_array_append_data(&cmd, arg_string[arg]);
        arg++;

    }

    /* now execute with the command line formed*/
    int retval = start_and_execute_ctworker(&cmd);

    free(proto_txt);
    free(src_ip_txt);
    free(dst_ip_txt);
    free(src_port_txt);
    free(dst_port_txt);
    amxc_array_clean(&cmd, NULL);
    return retval;
}

/**
 * @brief Executes a subprocess to retrieve network flow data based on input parameters and returns the result.
 *
 * This function constructs a command with optional filtering arguments (protocol, IPs, ports),
 * launches a subprocess to retrieve connection tracking data, waits for its completion,
 * parses and returns the result.
 *
 * @param ct_obj Unused object reference.
 * @param	func	Unused function reference.
 * @param	args	Input arguments containing optional filters for the flow retrieval.
 * @param	ret		returns the results in hashtable format.
 * @return	amxd_status_t	amxd_status_ok on success, or an appropriate error status on failure.
 */
amxd_status_t _ConnectionTrackingQuery_RetrieveFlows(UNUSED amxd_object_t* ct_obj,
                                                     UNUSED amxd_function_t* func,
                                                     UNUSED amxc_var_t* args,
                                                     amxc_var_t* ret) {


    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t localArgs;
    amxc_var_init(&localArgs);
    amxc_var_set_type(&localArgs, AMXC_VAR_ID_HTABLE);

    if(execute_ctquery(args) > 0) {
        amxc_var_t* list_var = parse_ctquery_results_to_varlist(CT_DEF_FILENAME);
        if(list_var) {
            amxc_var_add_key(cstring_t, &localArgs, "Status", "Complete");
            amxc_var_t* results = amxc_var_add_new_key(&localArgs, "Results");
            when_null_status(results, cleanup, amxc_var_delete(&list_var));
            amxc_var_move(results, list_var);
        } else {
            amxc_var_add_key(cstring_t, &localArgs, "Status", "No Records found");
        }
        amxc_var_delete(&list_var);

        amxc_var_move(ret, &localArgs);
        SAH_TRACEZ_INFO(ME, "Successfully executed query");
        status = amxd_status_ok;

    } else {
        SAH_TRACEZ_ERROR(ME, "Could not execute ctquery retrieve flows");
    }

cleanup:
    amxc_var_clean(&localArgs);
    return status;

}
