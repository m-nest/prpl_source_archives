# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.4.6 - 2024-08-08(09:41:51 +0000)

### Other

- add support for multiple runlevels

## Release v0.4.5 - 2024-07-05(08:04:59 +0000)

### Other

- share component on gitlab.com

## Release v0.4.4 - 2024-06-18(14:14:24 +0000)

### Other

- - [tr181-dnssd] strengthening of tr181-dnssd plugin

## Release v0.4.3 - 2024-02-02(13:04:54 +0000)

### Fixes

- DNS.SD TextRecord remove Alias parameter

## Release v0.4.2 - 2024-02-01(14:45:38 +0000)

### Fixes

- DNS.SD TextRecord remove Alias parameter

## Release v0.4.1 - 2023-11-13(09:10:47 +0000)

## Release v0.4.0 - 2023-10-12(11:28:03 +0000)

### New

- Update Licenses in oss components

## Release v0.3.4 - 2023-09-07(13:06:58 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release v0.3.3 - 2023-03-17(19:09:47 +0000)

### Other

- [baf] Correct typo in config option

## Release v0.3.2 - 2023-03-17(09:12:12 +0000)

### Other

- Install odl files in new location

## Release v0.3.1 - 2023-03-15(11:08:05 +0000)

### Fixes

- [TR181-DNSSD] Memory leak detected

## Release v0.3.0 - 2023-02-21(15:44:29 +0000)

### Other

- [PRPL] Make MSS work on prpl config

## Release v0.2.4 - 2023-02-20(09:49:19 +0000)

### Fixes

- [tr181-dnssd] DNSSD is not enabled

## Release v0.2.3 - 2023-01-09(10:17:52 +0000)

### Fixes

- avoidable copies of strings, htables and lists

## Release v0.2.2 - 2022-12-12(12:40:25 +0000)

### Other

- [tr181-dnssd] creat rpc methode to creat a service to advertise [add]

## Release v0.2.1 - 2022-12-02(17:15:20 +0000)

### Other

- [tr181-dnssd] remove vendor prefix from dnssd.Advertise [add]

## Release v0.2.0 - 2022-09-06(11:55:58 +0000)

### New

- [tr181-dnssd] add dnssd advertisement module

## Release v0.1.1 - 2022-09-06(09:10:05 +0000)

### Other

- Rename component to mod-dnssd-advertisement

## Release v0.1.0 - 2022-08-29(13:45:52 +0000)

### New

- [tr181-dnssd] add advertisement datamodel

