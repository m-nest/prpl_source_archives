/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm_trie.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief DMM trie implementation allows parsing mapping into trie
 * @version 1.0.0
 * @date 2025-12-03
 *
 * @copyright Copyright (c) 2025 Inango
 */

#include <stdlib.h>
#include <string.h>

#include "dmm.h"
#include "dmm_methods.h"
#include "dmm_connect_mngr.h"
#include "dmm_trie.h"

#include <amxc/amxc_macros.h>
#include <amxc/amxc_htable.h>
#include <amxrt/amxrt.h>
#include <amxc/amxc_variant.h>
#include <debug/sahtrace.h>

#define ME "dmm" /*!< Tracezone Prefix for SAH logger method */

TreeNode forward_tree;
TreeNode backward_tree;

/**
 * @brief initializes trie node
 *
 * @param[out] node node to initialize
 * @param action action for the node
 * @param rename_to new name for the node (optional)
 *
 * @return 0 if no error
 */
static int tree_node_init(TreeNode* node, NodeAction action, const char* rename_to) {
    when_null(node, exit_error);
    when_failed(amxc_htable_it_init(&node->hit), exit_error);
    when_failed(amxc_htable_it_init(&node->hit_parameter), exit_error);
    when_failed(amxc_htable_it_init(&node->hit_function), exit_error);
    when_failed(amxc_htable_it_init(&node->hit_event), exit_error);

    // if rename_to is filled, the action MUST be rename
    if(rename_to) {
        when_false(action == NodeAction_Rename, clean_it);
    }
    node->action = action;
    node->rename_to = NULL;
    node->rename_to_no_suffix = NULL;
    node->is_multiinstance = false;

    if(rename_to) {
        amxc_string_new(&node->rename_to, MAX_PATH_LEN);
        amxc_string_set(node->rename_to, rename_to);
    }

    when_failed(amxc_htable_init(&node->terminals, NODE_RESERVER_COUNT), clean_terminals);
    when_failed(amxc_htable_init(&node->nonterminals, NODE_RESERVER_COUNT), clean_nonterminals);
    when_failed(amxc_htable_init(&node->parameters, NODE_RESERVER_COUNT), clean_parameters);
    when_failed(amxc_htable_init(&node->functions, NODE_RESERVER_COUNT), clean_functions);
    when_failed(amxc_htable_init(&node->events, NODE_RESERVER_COUNT), clean_events);

    goto exit;

clean_events:
    amxc_htable_clean(&node->events, NULL);
clean_functions:
    amxc_htable_clean(&node->functions, NULL);
clean_parameters:
    amxc_htable_clean(&node->parameters, NULL);
clean_nonterminals:
    amxc_htable_clean(&node->nonterminals, NULL);
clean_terminals:
    amxc_htable_clean(&node->terminals, NULL);
clean_it:
    amxc_htable_it_clean(&node->hit_event, NULL);
    amxc_htable_it_clean(&node->hit_function, NULL);
    amxc_htable_it_clean(&node->hit_parameter, NULL);
    amxc_htable_it_clean(&node->hit, NULL);
exit_error:
    return 1;
exit:
    return 0;

}

/**
 * @brief allocates and initializes trie node
 *
 * @param action action for the node
 * @param rename_to new name for the node (optional)
 *
 * @return tree node itself, NULL if error happened
 */
static TreeNode* tree_node_new(NodeAction action, const char* rename_to) {
    TreeNode* node = malloc(sizeof(TreeNode));
    when_null(node, exit);

    if(tree_node_init(node, action, rename_to)) {
        free(node);
        node = NULL;
    }

exit:
    return node;
}

/**
 * @brief delete function for htable, dot not removes data recusively
 *
 * @param[in] key key of the node
 * @param[in] it iterator for the node (to extract node)
 */
static void tree_node_htable_delte_f(const char* key, amxc_htable_it_t* it) {
    TreeNode* node = amxc_htable_it_get_data(it, TreeNode, hit);
    amxc_htable_clean(&node->terminals, NULL);
    amxc_htable_clean(&node->nonterminals, NULL);

    amxc_htable_clean(&node->parameters, NULL);
    amxc_htable_clean(&node->functions, NULL);
    amxc_htable_clean(&node->events, NULL);

}

/**
 * @brief Cleans the single node, dot not removes data recusively
 *
 * @param[in,out] node node to clean
 */
static void tree_node_clean(TreeNode* node) {
    amxc_htable_it_clean(&node->hit, tree_node_htable_delte_f);
}

/**
 * @brief Deletes the single node, dot not removes data recusively
 *
 * @param[in,out] node node to clean aand delete
 */
static void tree_node_delete(TreeNode** node) {
    amxc_htable_it_clean(&(*node)->hit_parameter, NULL);
    amxc_htable_it_clean(&(*node)->hit_function, NULL);
    amxc_htable_it_clean(&(*node)->hit_event, NULL);

    amxc_htable_it_clean(&(*node)->hit, tree_node_htable_delte_f);
    free(*node);
    *node = NULL;
}

const TreeNode* find_exact_node(const TreeNode* root, const char* nonterminals, const char* terminal) {
    const TreeNode* node = NULL;
    char* nonterminals_path = NULL;
    if(!nonterminals) {
        goto find_terminal;
    }

    nonterminals_path = strdup(nonterminals);

    char* pch = strtok(nonterminals_path, ".");
    const TreeNode* current_node = root;
    while(pch != NULL) {
        amxc_htable_it_t* node_it = amxc_htable_get(&current_node->nonterminals, pch);
        when_null(node_it, exit);
        current_node = amxc_htable_it_get_data(node_it, TreeNode, hit);
        pch = strtok(NULL, ".");
    }

find_terminal:
    // if searched for object, no need to search terminals
    if(!terminal) {
        node = current_node;
        goto exit;
    }

    amxc_htable_it_t* terminal_node_it = amxc_htable_get(&root->terminals, terminal);
    when_null(terminal_node_it, exit);
    node = amxc_htable_it_get_data(terminal_node_it, TreeNode, hit);

exit:
    free(nonterminals_path);
    return node;
}

/**
 * @brief Split full parameter path (Foo.Bar.Buzz) into object path and parameter name.
 * This function will modify path and insert '\0' at the last '.', if parmeter path
 * is provided: 'Foo.Bar.Buzz\0' -> 'Foo.Bar\0Buzz\0'.
 *
 * @param[in,out] path full path
 *
 * @return pointer to parameter name or NULL if object path was provided.
 */
static const char* split_path_to_object_and_parameter_parts(char* path) {
    const char* parameter = NULL;

    when_null(path, exit);

    const size_t path_len = strlen(path);
    // when object provided --- exit immidiately
    when_true(path[path_len - 1] == '.', exit);

    char* last_dot = strrchr(path, '.');
    when_null(last_dot, exit);

    *last_dot = '\0';
    parameter = last_dot + 1;

exit:
    return parameter;
}

/**
 * @brief Create and insert object path node. Will create subnodes on it's way.
 *
 * @param tree tree to insert into
 * @param object_path object path
 *
 * @return created node or NULL, if an error happened
 */
static TreeNode* create_and_insert_object_path_node(TreeNode* tree, char* object_path) {
    TreeNode* node = NULL;

    when_null(tree, exit);
    when_null(object_path, exit);

    char* pch = strtok(object_path, ".");
    amxc_htable_it_t* node_it = NULL;
    TreeNode* current_node = tree;
    while(pch != NULL) {
        if(!strcmp(pch, "{i}")) {
            current_node->is_multiinstance = true;
            // if multiinstance --- ignore specifier when searching for node
            pch = strtok(NULL, ".");
            continue;
        }
        node_it = amxc_htable_get(&current_node->nonterminals, pch);
        if(!node_it) {
            SAH_TRACEZ_INFO(ME, "Cannot found '%s' node in '%s'", pch, amxc_htable_it_get_key(&current_node->hit));
            break;
        }
        current_node = amxc_htable_it_get_data(node_it, TreeNode, hit);
        pch = strtok(NULL, ".");
    }

    // if exact object is found return it
    if(node_it) {
        node = current_node;
        goto exit;
    }

    // if object is not found, start inserting objects
    // node_it is NULL
    // current_node points to last node (that was found)
    // pch points to name of the first node that was not found
    while(pch != NULL) {
        if(!strcmp(pch, "{i}")) {
            current_node->is_multiinstance = true;
            pch = strtok(NULL, ".");
            continue;
        }

        SAH_TRACEZ_INFO(ME, "Creating node path '%s'", pch);
        TreeNode* node_to_insert = tree_node_new(NodeAction_Empty, NULL);
        when_null(node_to_insert, exit);

        if(amxc_htable_insert(&current_node->nonterminals, pch, &node_to_insert->hit)) {
            tree_node_delete(&node_to_insert);
            goto exit;
        }

        current_node = node_to_insert;
        pch = strtok(NULL, ".");
    }

    node = current_node;

exit:
    return node;
}

/**
 * @brief check whether string has suffix
 *
 * @param[in] string string to check
 * @param[in] suffix suffix to check
 *
 * @return wehtehr string has suffix
 */
static bool has_suffix(const char* string, const char* suffix) {
    size_t string_length = strlen(string);
    size_t suffix_length = strlen(suffix);
    if(string_length < suffix_length) {
        return false;
    }

    return strncmp(string + (string_length - suffix_length), suffix, suffix_length) == 0;

}

/**
 * @brief get string copy without suffix
 *
 * @param[in] string stirng to get without suffix
 * @param[in] suffix suffix to remove from string
 *
 * @return copy of the string without suffix
 */
static char* get_string_without_suffix(const char* string, const char* suffix) {
    size_t string_length = strlen(string);
    size_t suffix_length = strlen(suffix);
    if(string_length < suffix_length) {
        return NULL;
    }

    char* string_without_suffix = strdup(string);
    string_without_suffix[string_length - suffix_length] = '\0';

    return string_without_suffix;
}

/**
 * @brief copy string andremove suffix from it
 *
 * @param[in] string_with_suffix stirng to get without suffix
 * @param[in] suffix suffix to remove from string
 *
 * @return copy of the string without suffix
 */
char* remove_suffix(const char* string_with_suffix, const char* suffix) {
    if(!string_with_suffix || !suffix) {
        return NULL;
    }

    if(!has_suffix(string_with_suffix, suffix)) {
        return NULL;
    }

    return get_string_without_suffix(string_with_suffix, suffix);
}


/**
 * @brief Insert node by it's full path into tree.
 *
 * @param[in] tree tree to insert into
 * @param[in] node_path complete path of the node to insert into tree
 *
 * @return inserted node or NULL, if an error happened
 */
static TreeNode* insert_node(TreeNode* tree, char* node_path) {
    TreeNode* node = NULL;

    when_null(tree, exit);
    when_null(node_path, exit);

    char* object_path = node_path;
    const char* terminal_name = split_path_to_object_and_parameter_parts(node_path);

    TreeNode* object_node = create_and_insert_object_path_node(tree, object_path);

    when_null(object_node, exit);

    if(!terminal_name) {
        node = object_node;
        goto exit;
    }

    TreeNode* parameter_node = tree_node_new(NodeAction_Empty, NULL);
    when_null(parameter_node, exit);

    if(amxc_htable_insert(&object_node->terminals, terminal_name, &parameter_node->hit)) {
        tree_node_delete(&parameter_node);
        goto exit;
    }

    char* function_name = remove_suffix(terminal_name, "()");
    char* event_name = remove_suffix(terminal_name, "!");

    if(function_name) {
        if(amxc_htable_insert(&object_node->functions, function_name, &parameter_node->hit_function)) {
            tree_node_delete(&parameter_node);
            goto clean_terminal_names;
        }
    } else if(event_name) {
        if(amxc_htable_insert(&object_node->events, event_name, &parameter_node->hit_event)) {
            tree_node_delete(&parameter_node);
            goto clean_terminal_names;
        }
    } else {
        if(amxc_htable_insert(&object_node->parameters, terminal_name, &parameter_node->hit_parameter)) {
            tree_node_delete(&parameter_node);
            goto clean_terminal_names;
        }
    }

    node = parameter_node;

clean_terminal_names:
    free(event_name);
    free(function_name);
exit:
    return node;
}

int init_tree() {
    when_failed(tree_node_init(&forward_tree, NodeAction_Empty, NULL), exit_error);
    when_failed(tree_node_init(&backward_tree, NodeAction_Empty, NULL), exit_error);

    goto exit;
exit_error:
    return 1;
exit:
    return 0;
}

static void tree_node_clean_f(const char* key, amxc_htable_it_t* it);

/**
 * @brief recusively clean tree node and all its children
 *
 * @param[in, out] node node to clean
 */
static void clean_tree_node(TreeNode* node) {
    amxc_htable_it_clean(&node->hit, NULL);
    amxc_htable_it_clean(&node->hit_parameter, NULL);
    amxc_htable_it_clean(&node->hit_function, NULL);
    amxc_htable_it_clean(&node->hit_event, NULL);

    amxc_string_delete(&node->rename_to);
    amxc_string_delete(&node->rename_to_no_suffix);

    amxc_htable_clean(&node->terminals, tree_node_clean_f);
    amxc_htable_clean(&node->nonterminals, tree_node_clean_f);
    amxc_htable_clean(&node->parameters, NULL);
    amxc_htable_clean(&node->events, NULL);
    amxc_htable_clean(&node->functions, NULL);

}

/**
 * @brief recusively clean tree node iterator
 *
 * @param[in] key key to the node
 * @param[in] it itertor of the node
 */
static void tree_node_clean_f(const char* key, amxc_htable_it_t* it) {
    TreeNode* node = amxc_htable_it_get_data(it, TreeNode, hit);
    clean_tree_node(node);
    free(node);
}


void clean_tree() {
    clean_tree_node(&forward_tree);
    clean_tree_node(&backward_tree);
}

/**
 * @brief Get last part of the path. Only the last part is renamed/hidden.
 *
 * @param original_path original path
 * @param renamed_path renamed path
 *
 * @return copy of the renamed part or NULL, if nothing is renamed (last parts are equal)
 */
char* get_renamed_part(const char* original_path, const char* renamed_path) {
    char* last_part = NULL;
    when_null(original_path, exit);
    when_null(renamed_path, exit);

    amxd_path_t original;
    when_failed(amxd_path_init(&original, original_path), exit);
    amxd_path_t renamed;
    when_failed(amxd_path_init(&renamed, renamed_path), clean_original);

    if(amxd_path_get_param(&original)) {
        when_null(amxd_path_get_param(&renamed), exit);
        if(!strcmp(amxd_path_get_param(&original), amxd_path_get_param(&renamed))) {
            SAH_TRACEZ_WARNING(ME, "Looks liks renaming to the original name: '%s' -> '%s'", original_path, renamed_path);
            goto exit;
        }
        last_part = strdup(amxd_path_get_param(&renamed));
        goto clean_renamed;
    } else {
        char* original_last = amxd_path_get_last(&original, true);
        char* renamed_last = amxd_path_get_last(&renamed, true);
        if(!strcmp(original_last, renamed_last)) {
            SAH_TRACEZ_WARNING(ME, "Looks liks renaming to the original name: '%s' -> '%s'", original_path, renamed_path);
            free(original_last);
            free(renamed_last);
            goto exit;
        }
        last_part = renamed_last;
        free(original_last);
        goto clean_renamed;
    }

clean_renamed:
    amxd_path_clean(&renamed);
clean_original:
    amxd_path_clean(&original);
exit:
    return last_part;
}

/**
 * @brief remove suffix from renamed_part for prepare node->rename_to_no_suffix
 *
 * @param[in,out] node node for processing
 * @param[in] renamed_part string to get without suffix
 * @param[in] suffix suffix to remove from string
 */
void remove_suffix_from_rename_val(TreeNode* node, const char* renamed_part, const char* suffix) {

    char* name_no_suffix = remove_suffix(renamed_part, suffix);
    if(name_no_suffix) {
        amxc_string_new(&node->rename_to_no_suffix, MAX_PATH_LEN);
        amxc_string_set(node->rename_to_no_suffix, name_no_suffix);
        free(name_no_suffix);
    }
}

/**
 * @brief create tree node by its path in tree
 *
 * @param[in,out] tree root of the tree to insert new node
 * @param[in] tree_path full nonterminal path to the node
 * @param[in] action action for the node
 * @param[in] rename_to new name for the node
 *
 * @return created node or NULL if error happens
 */
static TreeNode* create_node(TreeNode* tree, const char* tree_path, NodeAction action, const char* rename_to) {
    TreeNode* node = NULL;
    char* renamed_part = NULL;

    when_null(tree_path, exit);
    if(rename_to) {
        renamed_part = get_renamed_part(tree_path, rename_to);
        when_null_trace(renamed_part, exit, WARNING, "Cannot find rename part for the '%s'", tree_path);
    }
    char* tree_path_copy = strdup(tree_path);

    node = insert_node(tree, tree_path_copy);
    free(tree_path_copy);

    when_null_trace(node, exit, WARNING, "Cannot insert node by path '%s'", tree_path);

    node->action = action;
    if(renamed_part) {
        amxc_string_new(&node->rename_to, MAX_PATH_LEN);
        amxc_string_set(node->rename_to, renamed_part);
    }

    remove_suffix_from_rename_val(node, renamed_part, "!");
    remove_suffix_from_rename_val(node, renamed_part, "()");
    remove_suffix_from_rename_val(node, renamed_part, ".");

exit:
    free(renamed_part);
    return node;
}

/**
 * @brief parse hide mapping and fills backward trie
 */
static void parse_hide() {
    const amxc_var_t* hide_list = GET_ARG(amxrt_get_config(), DMM_OBJECTS_HIDE);

    amxc_var_for_each(path_to_hide, hide_list) {
        SAH_TRACEZ_INFO(ME, "Creating '%s' HIDE trie nodes", amxc_var_constcast(cstring_t, path_to_hide));

        // backward
        {
            TreeNode* node = create_node(&backward_tree, amxc_var_constcast(cstring_t, path_to_hide), NodeAction_Hide, NULL);

            if(!node) {
                SAH_TRACEZ_WARNING(ME, "Cannot create tree node '%s' on backward tree", amxc_var_constcast(cstring_t, path_to_hide));
                continue;
            }
        }
    }
}

/**
 * @brief parse rename mapping and fills backward and forward tries
 */
static void parse_rename() {
    const amxc_var_t* rename_map = GET_ARG(amxrt_get_config(), DMM_OBJECTS_RENAME);

    amxc_var_for_each(renamed_path_var, rename_map) {
        const char* renamed_path = amxc_var_constcast(cstring_t, renamed_path_var);
        const char* original_path = amxc_var_key(renamed_path_var);
        SAH_TRACEZ_INFO(ME, "Creating '%s -> %s' RENAME trie nodes", original_path, renamed_path);

        // forward
        {
            TreeNode* node = create_node(&forward_tree, renamed_path, NodeAction_Rename, original_path);

            if(!node) {
                SAH_TRACEZ_WARNING(ME, "Cannot create tree node '%s' on forward tree", renamed_path);
                continue;
            }
        }

        // backward
        {
            TreeNode* node = create_node(&backward_tree, original_path, NodeAction_Rename, renamed_path);

            if(!node) {
                SAH_TRACEZ_WARNING(ME, "Cannot create tree node '%s' on backward tree", original_path);
                continue;
            }
        }
    }
}

int parse_mapping() {
    parse_rename();
    parse_hide();

    return 0;
}

/**
 * @brief print information about node (rename, hide mapping basically)
 *
 * @param[in] node node to print info for
 * @param[in] name name of the node
 * @param add_space whetehr to add space before name of the node
 */
static void print_node_info(const TreeNode* node, const char* name, bool add_space) {
    const char* type = NULL;
    switch(node->action) {
    case NodeAction_Empty:
        return;
        break;
    case NodeAction_Hide:
        type = "<HIDE>";
        break;
    case NodeAction_Rename:
        type = amxc_string_get(node->rename_to, 0);
        break;
    }
    SAH_TRACEZ_INFO(ME, "%s%s -> %s", (add_space ? "    " : ""), name, type);
}

/**
 * @brief print terminal children of the node
 *
 * @param[in] node node to print terminal children for
 */
static void print_terminals(const TreeNode* node) {
    amxc_htable_for_each(it, &node->terminals) {
        const TreeNode* node = amxc_htable_it_get_data(it, TreeNode, hit);
        const char* key = amxc_htable_it_get_key(it);
        print_node_info(node, key, true);
    }
    amxc_htable_for_each(it, &node->parameters) {
        const char* key = amxc_htable_it_get_key(it);
        SAH_TRACEZ_INFO(ME, "\tP: %s", key);
    }
    amxc_htable_for_each(it, &node->functions) {
        const char* key = amxc_htable_it_get_key(it);
        SAH_TRACEZ_INFO(ME, "\tF: %s", key);
    }
    amxc_htable_for_each(it, &node->events) {
        const char* key = amxc_htable_it_get_key(it);
        SAH_TRACEZ_INFO(ME, "\tE: %s", key);
    }

}

/**
 * @brief print part of the tree
 *
 * @param[in] node current root of the tree to start from
 * @param[in] prefix prefix to use when printing nodes
 */
static void print_tree(const TreeNode* node, const char* prefix) {
    char full_path[MAX_PATH_LEN];
    snprintf(full_path, MAX_PATH_LEN, "%s%s.", prefix, amxc_htable_it_get_key(&node->hit));
    SAH_TRACEZ_INFO(ME, "%s (%s)", full_path, (node->is_multiinstance ? "{i}" : ""));
    print_node_info(node, full_path, false);
    print_terminals(node);

    amxc_htable_for_each(it, &node->nonterminals) {
        const TreeNode* node = amxc_htable_it_get_data(it, TreeNode, hit);
        print_tree(node, full_path);
    }
}

void print_trees() {
    SAH_TRACEZ_INFO(ME, "==============================FORWARD===========================");
    print_tree(&forward_tree, "");
    SAH_TRACEZ_INFO(ME, "==============================BACKWARD===========================");
    print_tree(&backward_tree, "");
}