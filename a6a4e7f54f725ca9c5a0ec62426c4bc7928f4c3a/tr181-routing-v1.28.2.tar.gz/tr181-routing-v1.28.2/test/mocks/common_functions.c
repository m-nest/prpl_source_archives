/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <stdio.h>

#include "common_functions.h"

#include "routing_ipvforwarding.h"
#include "routing_route_information_netmodel.h"
#include "routing_route_information.h"
#include "routing_manager.h"
#include "routing_policy_events.h"
#include "routing_router_discovery.h"

static void _dummy(UNUSED const char* const event_name,
                   UNUSED const amxc_var_t* const event_data,
                   UNUSED void* const priv) {
    return;
}

void resolver_add_all_functions(amxo_parser_t* parser) {
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_ipv6forwarding_3gpp_nas_status_changed", AMXO_FUNC(_routing_ipv6forwarding_3gpp_nas_status_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_ipvforwarding_added", AMXO_FUNC(_routing_ipvforwarding_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_ipvforwarding_changed", AMXO_FUNC(_routing_ipvforwarding_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_ipvforwarding_global_enable_changed", AMXO_FUNC(_routing_ipvforwarding_global_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "route_forwarding_deleted_ipvx_route", AMXO_FUNC(_route_forwarding_deleted_ipvx_route)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "route_information_deleted", AMXO_FUNC(_route_information_deleted)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "last_advertisement_onread", AMXO_FUNC(_last_advertisement_onread)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "route_information_interface_added", AMXO_FUNC(_route_information_interface_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "route_information_object_changed", AMXO_FUNC(_route_information_object_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "route_information_enable_changed", AMXO_FUNC(_route_information_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "default_router_status_changed", AMXO_FUNC(_default_router_status_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_router_added", AMXO_FUNC(_routing_router_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "router_deleted", AMXO_FUNC(_router_deleted)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_table_id_changed", AMXO_FUNC(_routing_table_id_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_policy_added", AMXO_FUNC(_routing_policy_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_policy_enable_changed", AMXO_FUNC(_routing_policy_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_policy_changed", AMXO_FUNC(_routing_policy_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "routing_policy_deleted", AMXO_FUNC(_routing_policy_deleted)), 0);

    // Dummy functions
    assert_int_equal(amxo_resolver_ftab_add(parser, "print_event", AMXO_FUNC(_dummy)), 0);
}
