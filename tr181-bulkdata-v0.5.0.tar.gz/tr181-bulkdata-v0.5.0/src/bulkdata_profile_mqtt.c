/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <debug/sahtrace_macros.h>
#include <imtp/imtp_connection.h>

#include "bulkdata.h"
#include "bulkdata_utils.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_mqtt.h"

#define ME "mqtt"

/**
   List to track all mqtt_connection_t structs
 */
static amxc_llist_t mqtt_con_list;

static int bulkdata_mqtt_connection_new(mqtt_connection_t** mqtt_con,
                                        const char* reference,
                                        imtp_connection_t* icon) {
    int retval = -1;

    when_null(mqtt_con, exit);
    when_str_empty(reference, exit);
    when_null(icon, exit);

    *mqtt_con = (mqtt_connection_t*) calloc(1, sizeof(mqtt_connection_t));
    (*mqtt_con)->reference = strdup(reference);
    (*mqtt_con)->icon = icon;
    (*mqtt_con)->counter = 1;

    retval = 0;
exit:
    return retval;
}

static void bulkdata_mqtt_connection_delete(mqtt_connection_t** mqtt_con) {
    when_null(mqtt_con, exit);
    when_null(*mqtt_con, exit);

    imtp_connection_delete(&(*mqtt_con)->icon);
    free((*mqtt_con)->reference);
    free(*mqtt_con);
    *mqtt_con = NULL;

exit:
    return;
}

static void bulkdata_mqtt_con_it_free(amxc_llist_it_t* it) {
    mqtt_connection_t* mqtt_con = amxc_llist_it_get_data(it, mqtt_connection_t, it);
    bulkdata_mqtt_connection_delete(&mqtt_con);
}

CONSTRUCTOR static void mqtt_con_llist_init(void) {
    amxc_llist_init(&mqtt_con_list);
}

DESTRUCTOR static void mqtt_con_llist_cleanup(void) {
    amxc_llist_clean(&mqtt_con_list, bulkdata_mqtt_con_it_free);
}

static int bulkdata_mqtt_enable_reference(amxc_string_t* reference) {
    int retval = -1;
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has("MQTT");
    amxc_var_t values;
    amxc_var_t ret;

    amxc_var_init(&values);
    amxc_var_init(&ret);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, "Enable", true);

    retval = amxb_set(bus_ctx, amxc_string_get(reference, 0), &values, &ret, 5);

    amxc_var_clean(&ret);
    amxc_var_clean(&values);
    return retval;
}

static int bulkdata_mqtt_connect(amxd_object_t* mqtt_obj,
                                 const char* reference,
                                 amxc_string_t* uri) {
    int retval = -1;
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has("MQTT");
    const char* method = "CreateListenSocket";
    amxc_var_t args;
    amxc_var_t ret;
    amxc_string_t* stripped_ref = bulkdata_utils_add_dot(reference);
    imtp_connection_t* icon = NULL;
    mqtt_connection_t* mqtt_con = NULL;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    // Need to strip Device. prefix, because CreateListenSocket is not available under Device. object on sop
    if(bulkdata_utils_device_prefix_check(reference)) {
        bulkdata_utils_device_prefix_strip(stripped_ref);
    }

    bulkdata_mqtt_enable_reference(stripped_ref);

    SAH_TRACEZ_INFO(ME, "Setting up IMTP connection to %s", reference);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "uri", amxc_string_get(uri, 0));
    retval = amxb_call(bus_ctx, amxc_string_get(stripped_ref, 0), method, &args, &ret, 5);
    if(retval != 0) {
        SAH_TRACEZ_WARNING(ME, "Could not call CreateListenSocket, retval = [%d]", retval);
        goto exit;
    }

    retval = imtp_connection_connect(&icon, NULL, amxc_string_get(uri, 0));
    if(retval != 0) {
        SAH_TRACEZ_WARNING(ME, "Could not connect to [%s], retval = [%d]", amxc_string_get(uri, 0), retval);
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Connected to fd: [%d]", imtp_connection_get_fd(icon));
    bulkdata_mqtt_connection_new(&mqtt_con, reference, icon);
    amxc_llist_append(&mqtt_con_list, &mqtt_con->it);
    mqtt_obj->priv = mqtt_con;

exit:
    amxc_string_delete(&stripped_ref);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return retval;
}

static mqtt_connection_t* bulkdata_mqtt_get_con(const char* reference) {
    mqtt_connection_t* mqtt_con = NULL;
    amxc_llist_for_each(it, &mqtt_con_list) {
        mqtt_connection_t* current = amxc_llist_it_get_data(it, mqtt_connection_t, it);
        if((current->reference != NULL) && (strcmp(current->reference, reference) == 0)) {
            mqtt_con = current;
            break;
        }
    }
    return mqtt_con;
}

static void bulkdata_mqtt_add_props(imtp_frame_t* frame) {
    imtp_tlv_t* tlv_mqtt_props = NULL;
    amxc_var_t mqtt_props;
    const char* json_str;

    amxc_var_init(&mqtt_props);
    amxc_var_set_type(&mqtt_props, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &mqtt_props, "content-type", "application/json; charset=UTF-8");

    amxc_var_cast(&mqtt_props, AMXC_VAR_ID_JSON);
    json_str = amxc_var_constcast(jstring_t, &mqtt_props);

    imtp_tlv_new(&tlv_mqtt_props, imtp_tlv_type_mqtt_props, strlen(json_str),
                 (char*) json_str, 0, IMTP_TLV_COPY);
    imtp_frame_tlv_add(frame, tlv_mqtt_props);

    amxc_var_clean(&mqtt_props);
}

int bulkdata_profile_mqtt_init(amxd_object_t* profile) {
    int retval = -1;
    amxc_string_t uri;
    mqtt_connection_t* mqtt_con = NULL;
    amxd_object_t* mqtt_obj = amxd_object_findf(profile, "MQTT");
    char* reference = amxd_object_get_value(cstring_t, mqtt_obj, "Reference", NULL);
    uint32_t index = amxd_object_get_index(profile);
    amxo_parser_t* parser = bulkdata_get_parser();
    const char* socket_dir = amxc_var_constcast(cstring_t,
                                                amxo_parser_get_config(parser, "mqtt-socket-dir"));

    amxc_string_init(&uri, 0);

    when_str_empty(reference, exit);
    when_str_empty(socket_dir, exit);

    // If connection to MQTT Client exists, reuse connection
    mqtt_con = bulkdata_mqtt_get_con(reference);
    if(mqtt_con != NULL) {
        SAH_TRACEZ_INFO(ME, "Found existing MQTT client connection, reusing it");
        mqtt_obj->priv = mqtt_con;
        mqtt_con->counter++;
        retval = 0;
        goto exit;
    }

    amxc_string_setf(&uri, "usp:%s/bulkdata-mqtt-%d.sock", socket_dir, index);
    retval = bulkdata_mqtt_connect(mqtt_obj, reference, &uri);

exit:
    amxc_string_clean(&uri);
    free(reference);
    return retval;
}

void bulkdata_profile_mqtt_clean(amxd_object_t* mqtt_obj) {
    mqtt_connection_t* mqtt_con = NULL;

    when_null(mqtt_obj, exit);
    mqtt_con = mqtt_obj->priv;
    when_null(mqtt_con, exit);

    if(mqtt_con->counter == 1) {
        amxc_llist_it_take(&mqtt_con->it);
        bulkdata_mqtt_connection_delete(&mqtt_con);
    } else {
        mqtt_con->counter--;
    }
    mqtt_obj->priv = NULL;

exit:
    return;
}

int bulkdata_profile_mqtt_send_data(amxd_object_t* profile, amxc_var_t* data) {
    int retval = -1;
    amxd_object_t* mqtt_obj = NULL;
    mqtt_connection_t* mqtt_con = NULL;
    imtp_frame_t* frame = NULL;
    imtp_tlv_t* tlv_json = NULL;
    imtp_tlv_t* tlv_topic = NULL;
    const char* string_to_send = NULL;
    char* topic = NULL;
    const cstring_t encoding_type = NULL;

    mqtt_obj = amxd_object_findf(profile, "MQTT");
    when_null_trace(mqtt_obj, exit, ERROR, "Unable to get MQTT object");

    mqtt_con = mqtt_obj->priv;
    when_null(mqtt_con, exit);

    encoding_type = bulkdata_profile_get_encoding_type(profile);
    when_null_trace(encoding_type, exit, ERROR, "Unable to get the EncodingType (%s)", amxd_object_get_path(profile, AMXD_OBJECT_NAMED));

    if(strncmp(encoding_type, "JSON", strlen("JSON")) == 0) {
        amxc_var_cast(data, AMXC_VAR_ID_JSON);
        string_to_send = amxc_var_constcast(jstring_t, data);
    } else if(strncmp(encoding_type, "CSV", strlen("CSV")) == 0) {
        amxc_var_cast(data, AMXC_VAR_ID_CSTRING);
        string_to_send = amxc_var_constcast(cstring_t, data);
    }

    SAH_TRACEZ_INFO(ME, "Sending BulkData report to MQTT client");
    when_str_empty_trace(string_to_send, exit, ERROR, "Nothing to send, skip the operation");

    topic = amxd_object_get_value(cstring_t, mqtt_obj, "PublishTopic", NULL);
    if((topic == NULL) || (*topic == 0)) {
        SAH_TRACEZ_ERROR(ME, "Missing MQTT Publish topic, not sending data");
        goto exit;
    }

    imtp_frame_new(&frame);
    imtp_tlv_new(&tlv_json, imtp_tlv_type_json, strlen(string_to_send),
                 (char*) string_to_send, 0, IMTP_TLV_COPY);
    imtp_frame_tlv_add(frame, tlv_json);
    imtp_tlv_new(&tlv_topic, imtp_tlv_type_topic, strlen(topic),
                 topic, 0, IMTP_TLV_COPY);
    imtp_frame_tlv_add(frame, tlv_topic);
    bulkdata_mqtt_add_props(frame);

    retval = imtp_connection_write_frame(mqtt_con->icon, frame);
    if(retval != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to send BulkData report to MQTT client");
    }

exit:
    free(topic);
    imtp_frame_delete(&frame);
    return retval;
}
