/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <math.h>

#include <amxc/amxc.h>

#include <amxc/amxc_variant.h>
#include "amxut/amxut_origin.h"

#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>
#include "common_functions.h"
#include "test_ctquery.h"
#include "conntrackingquery.h"

int test_setup_ctquery(void** state) {
    amxut_bus_setup(state);
    resolver_add_all_functions();

    amxd_dm_t* dm = amxut_bus_dm();
    amxo_parser_t* parser = amxut_bus_parser();
    assert_non_null(dm);
    assert_non_null(parser);

    amxd_object_t* root = amxd_dm_get_root(dm);
    assert_non_null(root);

    test_setup_parse_odl(ODL_DEFS);
    test_setup_parse_odl(ODL_MOCK_MAIN);
    test_setup_parse_odl(ODL_DEFAULTS);

    _connectiontrackingquery_main(AMXO_START, dm, parser);
    handle_events();
    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);

    return 0;
}
void test_start(UNUSED void** state) {

}

void test_notify_flow_add(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);


    // Set the type of `args` to HTABLE
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    // Add a sub-htable under "parameters"
    amxc_var_t* params = amxc_var_add_new_key(&args, "parameters");

    // Set its type to HTABLE as well
    amxc_var_set_type(params, AMXC_VAR_ID_HTABLE);

    // Add key-value pairs to the "parameters" htable


    amxc_var_add_key(cstring_t, params, "Name", "sample3");
    amxc_var_add_key(cstring_t, params, "DestIP", "8.8.4.4");

    amxut_dm_invoke("ConnectionTrackingQuery.NotifyFlow", "_add", &args, &ret);
    amxut_bus_handle_events();

    // Validate instance exists
    assert_true(_amxut_dm_object_exists("ConnectionTrackingQuery.NotifyFlow.1"));

    // Validate parameters
    amxut_dm_assert_str("ConnectionTrackingQuery.NotifyFlow.1.", "Name", "sample3");
    amxut_dm_assert_str("ConnectionTrackingQuery.NotifyFlow.1.", "DestIP", "8.8.4.4");

    // Optional: validate default values
    _amxut_dm_param_equals(bool, "ConnectionTrackingQuery.NotifyFlow.1.", "Enable", 1);
    amxut_dm_assert_uint32("ConnectionTrackingQuery.NotifyFlow.1.", "LastChange", 0);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}


int test_teardown_ctquery(void** state) {
    _connectiontrackingquery_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser());
    amxut_bus_teardown(state);
    return 0;
}
