/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


/**
 * @file dmm_subscribe.c
 *
 * @author Inango (inango@inango-systems.com)
 * @brief File contains implementation for processing subscriptuons on different events.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#include <stdlib.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_variant.h>
#include <amxc/amxc_llist.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>

#include "dmm.h"
#include "dmm_methods.h"
#include "dmm_info.h"
#include "dmm_connect_mngr.h"
#include "dmm_trie_translator.h"

#define ME "dmm"                      /*!< Prefix for SAH logger method */
#define AMXB_BUS_TIMEOUT 10           /*!< bus timeout for GSDM call on the component */

static amxc_var_t root_subscriptions; /*!< hashtable of subscription per single DM root */

void dmm_subscription_init() {
    amxc_var_init(&root_subscriptions);
    amxc_var_set_type(&root_subscriptions, AMXC_VAR_ID_HTABLE);
}

/**
 * @brief Cleans up and deletes a single subscription item.
 *
 * This function is typically used as a callback for list cleanup. It extracts
 * the `amxb_subscription_t` from the list iterator, handles the associated
 * `map_info_t` reference counting (decrements and deletes if refs reach 0),
 * removes the subscription from the list, and finally frees the subscription structure.
 *
 * @param it Pointer to the amxc_llist_it_t (list iterator) for the subscription to be removed.
 */
static void dmm_remove_subscription(amxc_llist_it_t* it) {
    amxb_subscription_t* subscription = amxc_container_of(it, amxb_subscription_t, it);
    map_info_t* minfo = (map_info_t*) subscription->priv;
    if(minfo != NULL) {
        minfo->refs = 1;
        dmm_delete_info(&minfo);
    }

    amxc_llist_it_take(&subscription->it);
    amxb_subscription_delete(&subscription);
}

static void dmm_handle_event(UNUSED const char* const sig_name,
                             const amxc_var_t* const data,
                             void* const priv) {
    map_info_t* minfo = (map_info_t*) priv;
    amxc_var_t proxy_data;
    amxd_dm_t* dm = dmm_get_dm();
    const char* notification = GET_CHAR(data, "notification");

    amxc_var_init(&proxy_data);

    SAH_TRACEZ_INFO(ME, "Recieved event [%s] - translate and forward", notification);
    amxc_var_copy(&proxy_data, data);
    dmm_reply_transl_data(minfo, &proxy_data);

    if(translate_event_response(&minfo->ret)) {
        SAH_TRACEZ_INFO(ME, "Failed to translate [%s] event", notification);
    }

    amxp_sigmngr_trigger_signal(&dm->sigmngr, notification, &minfo->ret);

    amxc_var_clean(&proxy_data);
}


/**
 * @brief handle event from prplmesh component without any real action
 *
 * This stub is used to provide a no-op event handler for subscription.
 * Events would be handler in a single root subscription handler (dmm_handle_event).
 *
 * @param sig_name (unused) name of the event's signal
 * @param data (unused) ambiorix event
 * @param priv (unused) map_info_t structure of the subscription.
 */
static void dmm_handle_event_no_op(UNUSED const char* const sig_name,
                                   UNUSED const amxc_var_t* const data,
                                   UNUSED void* const priv) {
}

/**
 * @brief Subscribe to add and del events on path.
 *
 * @param[in] ctx context for the subscription
 * @param[in] path path that was used to create subscription
 * @param mapped mapped root that is used in the subscription
 * @param subs_table subscription's table for the root
 * @param subs_list subscription's list for the root
 */
static void subscribe_to_add_del_events(amxb_bus_ctx_t* ctx, amxd_path_t* path, const char* mapped_root, amxc_var_t* subs_table, amxc_llist_t* subs_list) {
    char* fixed = NULL;

    when_false(amxd_path_is_supported_path(path), exit);

    fixed = amxd_path_get_fixed_part(path, false);

    when_not_null(GET_ARG(subs_table, fixed), exit);

    SAH_TRACEZ_INFO(ME, "Subscribing to '%s' ADD/DEL events", fixed);

    map_info_t* minfo = NULL;
    dmm_new_info(&minfo, mapped_root);

    amxb_subscription_t* subscription = NULL;
    amxb_subscription_new_ex(&subscription, ctx, fixed, -1, AMXB_BE_EVENT_TYPE_ADD | AMXB_BE_EVENT_TYPE_DEL, NULL, dmm_handle_event_no_op, minfo);
    when_null(subscription, exit);

    amxc_llist_append(subs_list, &subscription->it);
    amxc_var_add_new_key(subs_table, fixed);

exit:
    free(fixed);
    return;
}

/**
 * @brief Subscribe for all events on object.
 *
 * @param[in] ctx context for the subscription
 * @param[in] path path that was used to create subscription
 * @param mapped mapped root that is used in the subscription
 * @param subs_table subscription's table for the root
 * @param subs_list subscription's list for the root
 */
static void subscribe_to_object(amxb_bus_ctx_t* ctx, const char* search_path, amxd_path_t* object_path, const amxc_var_t* object, const char* mapped_root, amxc_var_t* subs_table, amxc_llist_t* subs_list) {
    if(GET_BOOL(object, "is_multi_instance")) {
        subscribe_to_add_del_events(ctx, object_path, mapped_root, subs_table, subs_list);
    }
}

/**
 * @brief Subscribe to value change events on root object.
 *
 * @param[in] ctx context for the subscription
 * @param[in] root_path original root path of the component
 * @param[in,out] minfo map_info_t structure for the subscription
 * @param subs_table subscription's table for the root
 * @param subs_list subscription's list for the root
 */
static void subscribe_to_root(amxb_bus_ctx_t* ctx, const char* root_path, map_info_t* minfo, amxc_var_t* subs_table, amxc_llist_t* subs_list) {
    SAH_TRACEZ_INFO(ME, "Subscribing to '%s' root for ValueChange, Event, OperationComplete events", root_path);

    amxb_subscription_t* subscription = NULL;
    amxb_subscription_new_ex(&subscription, ctx, root_path, -1, AMXB_BE_EVENT_TYPE_CHANGE | AMXB_BE_EVENT_TYPE_EVENT | AMXB_BE_EVENT_TYPE_COMPL, NULL, dmm_handle_event, minfo);
    when_null(subscription, exit);

    amxc_llist_append(subs_list, &subscription->it);
    amxc_var_add_new_key(subs_table, root_path);

exit:
    return;
}


void dmm_subscribe_root(amxb_bus_ctx_t* ctx, const char* root, const char* mapped_root) {
    when_not_null_trace(GET_ARG(&root_subscriptions, root), exit, WARNING, "Subscribing to the '%s' root which already contains subscriptions!", root);

    amxc_var_t ret;
    amxc_var_init(&ret);

    int res = amxb_get_supported(ctx, root, AMXB_FLAG_FUNCTIONS | AMXB_FLAG_EVENTS, &ret, AMXB_BUS_TIMEOUT);
    when_failed_trace(res, exit, WARNING, "Failed to call get_supported on '%s', got '%d'", root, res);

    amxc_var_t* subscription = amxc_var_add_new_key(&root_subscriptions, root);
    amxc_var_set_type(subscription, AMXC_VAR_ID_HTABLE);

    amxc_var_t* subs_table = amxc_var_add_new_key(subscription, "table");
    amxc_var_set_type(subs_table, AMXC_VAR_ID_HTABLE);

    amxc_var_t* subs_list = amxc_var_add_new_key(subscription, "list");
    amxc_var_set_type(subs_list, AMXC_VAR_ID_LIST);

    {
        map_info_t* minfo = NULL;
        dmm_new_info(&minfo, mapped_root);
        subscribe_to_root(ctx, root, minfo, subs_table, (amxc_llist_t*) amxc_var_constcast(amxc_llist_t, subs_list));
    }

    amxc_var_for_each(object, GETI_ARG(&ret, 0)) {
        const char* object_path = amxc_var_key(object);
        amxd_path_t path;
        amxd_path_init(&path, object_path);

        char* search_path = amxd_path_build_search_path(&path);

        subscribe_to_object(ctx, search_path, &path, object, mapped_root, subs_table, (amxc_llist_t*) amxc_var_constcast(amxc_llist_t, subs_list));

        free(search_path);
        amxd_path_clean(&path);
    }

exit:
    amxc_var_clean(&ret);

    return;
}

void dmm_unsubscribe_root(const char* root) {
    amxc_var_t* existing_subscriptions = amxc_var_take_key(&root_subscriptions, root);
    when_null(existing_subscriptions, exit);

    amxc_var_t* list = GET_ARG(existing_subscriptions, "list");
    amxc_llist_t* subs_list = (amxc_llist_t*) amxc_var_constcast(amxc_llist_t, list);

    amxc_llist_clean(subs_list, dmm_remove_subscription);
    amxc_llist_init(subs_list);

    amxc_var_delete(&existing_subscriptions);

exit:
    return;
}

amxd_status_t dmm_subscribe(UNUSED amxd_object_t* object,
                            UNUSED amxd_function_t* func,
                            amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

/**
 * @brief Public function implementing the AMX Data Model `_unsubscribe` functionality.
 *
 * This is the entry point for unsubscribing from events.
 * 1. Determines the full path for the unsubscription.
 * 2. Finds the bus context associated with the fixed part of the real path.
 * 3. Iterates through the local list of subscriptions (`subscriptions`).
 * 4. If a matching subscription is found:
 * a. Decrements the reference count of the associated `map_info_t`.
 * b. If the reference count drops to zero, calls `dmm_remove_subscription`
 * to remove the subscription from the bus and the local list.
 *
 * @param object The amxd_object_t for which the unsubscription is called.
 * @param func Unused.
 * @param args amxc_var_t containing unsubscription arguments (e.g., "rel_path").
 * @param ret Unused.
 * @return amxd_status_t Returns amxd_status_ok on success, or an error status.
 */
amxd_status_t dmm_unsubscribe(UNUSED amxd_object_t* object,
                              UNUSED amxd_function_t* func,
                              amxc_var_t* args,
                              UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

void dmm_remove_subscriptions(void) {
    amxc_var_for_each(subscription, &root_subscriptions) {
        const char* root = amxc_var_key(subscription);
        dmm_unsubscribe_root(root);
    }
    amxc_var_clean(&root_subscriptions);
}
