MACHINE = $(shell $(CC) -dumpmachine)
TARGET = run_test

SRCDIR += $(realpath ../../src)
OBJDIR = $(realpath ../../output/$(MACHINE)/coverage)
INCDIR += $(realpath ../../include_priv ../common)

SOURCES = $(wildcard $(SRCDIR)/*.c)

COMMON_TEST_SRC_DIR = ../common
COMMON_TEST_SOURCES = $(wildcard $(COMMON_TEST_SRC_DIR)/*.c)
COMMON_TEST_OBJ_DIR = $(OBJDIR)/common
COMMON_TEST_OBJECTS += $(addprefix $(COMMON_TEST_OBJ_DIR)/,$(notdir $(COMMON_TEST_SOURCES:.c=.o)))

CFLAGS += -Werror -Wall -Wextra -Wno-attributes\
          -g3 -Wmissing-declarations \
		  $(addprefix -I ,$(INCDIR)) \
		  -fkeep-inline-functions -fkeep-static-functions \
		  -Wno-format-nonliteral \
		  $(shell pkg-config --cflags cmocka) -pthread \
		  -D_GNU_SOURCE \
		  -DSAHTRACES_ENABLED -DSAHTRACES_LEVEL_DEFAULT=500

LDFLAGS += -fkeep-inline-functions -fkeep-static-functions \
		   $(shell pkg-config --libs cmocka) \
		   -lamxb -lamxc -lamxp -lamxd -lamxo -lamxm \
		   -lsahtrace -ldl -lpthread -lcrypt -lamxj

ifeq ($(CC_NAME),g++)
    CFLAGS += -std=c++2a
else
	CFLAGS += -std=gnu11
endif
