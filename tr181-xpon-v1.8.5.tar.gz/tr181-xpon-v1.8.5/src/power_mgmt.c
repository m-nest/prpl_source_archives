/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "power_mgmt.h"

/* System headers */
#include <stdbool.h>
#include <stdlib.h> /* free() */
#include <string.h> /* strstr() */

/* Other libraries' headers */
#include <amxc/amxc_macros.h>           /* UNUSED */
#include <amxd/amxd_function.h>         /* amxd_function_defer() */
#include <amxd/amxd_object.h>           /* AMXD_OBJECT_INDEXED */
#include <amxd/amxd_object_hierarchy.h> /* amxd_object_get_path() */
#include <amxp/amxp_timer.h>            /* amxp_timer_t */

/* Own headers */
#include "dm_info.h"
#include "onu_priv.h"   /* onu_priv_t */
#include "pon_ctrl.h"   /* pon_ctrl_change_power_mode() */
#include "xpon_mngr.h"  /* xpon_mngr_get_dm() */
#include "xpon_trace.h"

static const uint32_t CHANGE_POWER_MODE_TIMEOUT_MS = 5000;
static const uint32_t TIMEOUT_MARGIN_MS = 100;

/**
 * Reset all members of an object of type @c cpm_data_t.
 */
static void reset_cpm_data(cpm_data_t* cpm_data) {
    cpm_data->call_busy = false;
    cpm_data->call_id_tr181 = 0;
    amxp_timer_stop(cpm_data->timer);
    /* Do not reset call_id_internal */
}

/**
 * Declare the ChangePowerMode() call timed out.
 *
 * @param[in] priv: pointer to object of type @c cpm_data_t with info about the
 *                  ChangePowerMode() call
 *
 * This function is called if tr181-xpon did not receive a reply from the vendor
 * module within a specific timeout period to the change_power_mode() call. This
 * function causes XPON.ONU.{i}.ChangePowerMode() to return a timeout to the
 * caller.
 */
static void change_power_mode_timeout(UNUSED amxp_timer_t* timer, void* priv) {
    when_null_trace(priv, exit, ERROR, "priv is NULL");
    cpm_data_t* const cpm_data = (cpm_data_t*) priv;
    when_false_trace(cpm_data->call_busy, exit, ERROR,
                     "No ChangePowerMode() call in progress");
    SAH_TRACEZ_DEBUG(ME, "ChangePowerMode() for call_id_internal=%d timed out",
                     cpm_data->call_id_internal);
    amxd_function_deferred_done(cpm_data->call_id_tr181, amxd_status_timeout,
                                NULL, NULL);
    reset_cpm_data(cpm_data);

exit:
    return;
}

/**
 * Check if the value @a power_state is supported by an ONU.
 *
 * @param[in] power_state: power state. This is typically "On", "Off" or
 *                         "LowPower".
 * @param[in] object: ONU instance
 *
 * The function queries the value of "PowerCapability" of the ONU referred by
 * @a object. It specifies the power states supported by the ONU. The function
 * returns true if @a power_state occurs in the list.
 *
 * @retval true if @a power_state is supported by the ONU
 * @retval false if @a power_state is not supported by the ONU or if an error
 *               occurs, e.g. if the function fails to query the value of
 *               "PowerCapability".
 */
static bool check_power_state(const char* power_state,
                              const amxd_object_t* const object) {

    bool rv = false;
    const amxc_var_t* capability =
        amxd_object_get_param_value(object, "PowerCapability");
    when_null_trace(capability, exit, ERROR, "PowerCapability not found");

    const char* const capability_cstr = GET_CHAR(capability, NULL);
    when_null_trace(capability_cstr, exit, ERROR,
                    "Failed to get cstring for PowerCapability");

    const char* const substr = strstr(capability_cstr, power_state);
    when_null_trace(substr, exit, ERROR,
                    "PowerState='%s' does not occur in PowerCapability='%s'",
                    power_state, capability_cstr);
    rv = true;
exit:
    return rv;
}

/**
 * Set the power state of the ONU asynchronously.
 *
 * @param[in,out] object: ONU object for which ChangePowerMode() is called
 * @param[in] func: pointer to amxd_function_t with info about the
 *     ChangePowerMode() call. E.g., func->name is "ChangePowerMode".
 * @param[in] args: arguments of the ChangePowerMode() call. The function has 1
 *     parameter: "PowerState".
 * @param[in] ret: return value of the ChangePowerMode() call
 *
 * The function first calls amxd_function_deferred_done() if another
 * ChangePowerMode() call is in progress.
 *
 * Then the function:
 * - calls amxd_function_defer().
 * - forwards the requested power state to the vendor module (VM)
 * - starts a timer (with a timeout of CHANGE_POWER_MODE_TIMEOUT_MS) to declare
 *   the ChangePowerMode() call as timed out if the VM will not gave feedback
 *   within that timeout period.
 *
 * @return amxd_status_deferred if the function called amxd_function_defer().
 * @return amxd_status_invalid_arg if the value for "PowerState" is invalid
 * @return some other error code if another error occurred
 */
amxd_status_t change_power_mode(amxd_object_t* object, amxd_function_t* func,
                                amxc_var_t* args, amxc_var_t* ret) {

    int rc;
    amxd_status_t rv = amxd_status_unknown_error;
    char* path = NULL;
    when_null_trace(object, exit, ERROR, "object is NULL");
    when_null_trace(object->priv, exit, ERROR, "object->priv is NULL");
    onu_priv_t* const onu_priv = (onu_priv_t*) object->priv;
    cpm_data_t* const cpm_data = (cpm_data_t*) (&(onu_priv->cpm_data));
    path = amxd_object_get_path(object, AMXD_OBJECT_INDEXED);
    when_null_trace(path, exit, ERROR, "path is NULL");
    const object_id_t oid = dm_get_object_id(path);
    when_false_trace(oid_onu == oid, exit, ERROR,
                     "ChangePowerMode() is not called for an ONU (path='%s')",
                     path);

    const char* const power_state = GET_CHAR(args, "PowerState");
    when_null_trace(power_state, exit, ERROR, "Failed to get PowerState value");

    const bool power_state_ok = check_power_state(power_state, object);
    when_false_status(power_state_ok, exit, rv = amxd_status_invalid_arg);

    SAH_TRACEZ_DEBUG(ME, "path=%s PowerState='%s' call_busy=%d", path,
                     power_state, cpm_data->call_busy);
    if(cpm_data->call_busy) {
        amxd_function_deferred_done(cpm_data->call_id_tr181,
                                    amxd_status_ok, NULL, NULL);
        reset_cpm_data(cpm_data);
    }

    rv = amxd_function_defer(func, &cpm_data->call_id_tr181, ret,
                             /* cancel_fn = */ NULL, /* priv= */ NULL);
    when_failed_trace(rv, exit, ERROR, "amxd_function_defer() failed; rv=%d", rv);
    rv = amxd_status_unknown_error;
    cpm_data->call_busy = true;

    if(!cpm_data->timer) {
        rc = amxp_timer_new(&cpm_data->timer, change_power_mode_timeout, cpm_data);
        when_failed_trace(rc, exit, ERROR, "Failed to create timer");
    }
    /**
     * tr181-xpon further below calls pon_ctrl_change_power_mode() with
     * CHANGE_POWER_MODE_TIMEOUT_MS as value for the parameter timeout_ms:
     * it expects a reply via `set_change_power_mode_result()` within
     * CHANGE_POWER_MODE_TIMEOUT_MS ms. Take a little bit of extra margin,
     * namely TIMEOUT_MARGIN_MS ms, before declaring a timeout.
     */
    rc = amxp_timer_start(cpm_data->timer,
                          CHANGE_POWER_MODE_TIMEOUT_MS + TIMEOUT_MARGIN_MS);
    when_failed_trace(rc, exit, ERROR, "Failed to start timer");

    /**
     * Increment call_id_internal before doing the pon_ctrl_change_power_mode()
     * call. If the code would increment it after the call, call_id_internal
     * would become one higher than the value used in the call.
     */
    ++cpm_data->call_id_internal;
    rc = pon_ctrl_change_power_mode(path, cpm_data->call_id_internal,
                                    power_state, CHANGE_POWER_MODE_TIMEOUT_MS);
    when_failed_trace(rc, exit, ERROR, "change_power_mode() failed: rc=%d", rc);

    rv = amxd_status_deferred;
exit:
    if(path) {
        free(path);
    }
    return rv;
}

#define NR_OF_KEYS_REQUIRED 3
static const char* KEYS_REQUIRED[NR_OF_KEYS_REQUIRED] = { "index", "call_id", "result" };

/**
 * Set the result of the asynchronous ChangePowerMode() call.
 *
 * @param[in] args: htable which must have the keys 'index', 'call_id' and
 *     'result'. 'index' identifies the ONU. E.g., index 1 means the result
 *     is for XPON.ONU.1
 *
 * The function is a no-op if one of the following conditions is true:
 * - one of the required keys is missing from @a args
 * - the ONU object has no private data
 * - no ChangePowerMode() call is busy for the ONU
 * - the 'call_id' in @a args is different from the call_id if the
 *   ChangePowerMode() in progress for the ONU.
 *
 * If none of these conditions is true, and hence this function reports the
 * result for an ongoing ChangePowerMode() call, the function calls
 * amxd_function_deferred_done(). Its sets the parameter 'status' of
 * amxd_function_deferred_done() to amxd_status_ok if
 * 'result' in @a args is 0, else it sets the parameter 'status' to
 * amxd_status_unknown_error.
 *
 * @return 0 on success, else -1.
 */
int pwr_set_change_power_mode_result(const amxc_var_t* args) {
    int rc = -1;

    SAH_TRACEZ_DEBUG(ME, "called");

    when_null_trace(args, exit, ERROR, "args is NULL");

    const amxc_htable_t* const htable = amxc_var_constcast(amxc_htable_t, args);
    when_null_trace(htable, exit, ERROR, "args is not an htable");

    int i;
    bool has_key;
    for(i = 0; i < NR_OF_KEYS_REQUIRED; ++i) {
        has_key = amxc_htable_contains(htable, KEYS_REQUIRED[i]);
        when_false_trace(has_key, exit, ERROR, "args does not contain key '%s'",
                         KEYS_REQUIRED[i]);
    }
    const uint32_t onu_index = GET_UINT32(args, "index");
    const uint32_t call_id = GET_UINT32(args, "call_id");
    const uint32_t result = GET_UINT32(args, "result");
    SAH_TRACEZ_DEBUG(ME, "onu_index=%u call_id=%u result=%u", onu_index,
                     call_id, result);

#define ONU_PATH_LEN 16
    char path[ONU_PATH_LEN];
    int rc2 = snprintf(path, ONU_PATH_LEN, "XPON.ONU.%u", onu_index);
    when_true_trace(rc2 < 0 || rc2 >= ONU_PATH_LEN, exit, ERROR,
                    "snprintf() failed");

    amxd_dm_t* const dm = xpon_mngr_get_dm();
    when_null_trace(dm, exit, ERROR, "Failed to get DM");

    const amxd_object_t* const onu_instance = amxd_dm_findf(dm, "%s", path);
    when_null_trace(onu_instance, exit, ERROR, "Failed to find '%s'", path);
    when_null_trace(onu_instance->priv, exit, ERROR, "%s has no private data", path);

    onu_priv_t* const onu_priv = (onu_priv_t*) onu_instance->priv;
    cpm_data_t* const cpm_data = (cpm_data_t*) (&(onu_priv->cpm_data));
    when_false_trace(cpm_data->call_busy, exit, ERROR,
                     "%s: no ChangePowerMode() in progress", path);

    when_false_trace(cpm_data->call_id_internal == call_id, exit, ERROR,
                     "%s: call ID received [%u] != call ID expected [%u]",
                     path, call_id, cpm_data->call_id_internal);
    const amxd_status_t status = (result == 0) ? amxd_status_ok : amxd_status_unknown_error;

    amxp_timer_stop(cpm_data->timer);
    rc2 = amxd_function_deferred_done(cpm_data->call_id_tr181, status, NULL, NULL);
    when_failed_trace(rc2, exit, ERROR, "%s: amxd_function_deferred_done() failed: rc=%d",
                      path, rc2);
    reset_cpm_data(cpm_data);

    rc = 0;

exit:
    return rc;
}
