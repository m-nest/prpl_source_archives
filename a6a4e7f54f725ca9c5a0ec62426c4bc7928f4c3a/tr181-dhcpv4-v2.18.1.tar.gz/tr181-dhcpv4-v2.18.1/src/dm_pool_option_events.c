/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "dns_utility.h"
#include "dm_pool_option_events.h"
#include "pool_info.h"
#include "pools.h"

#define ME "pool_option_events"

/**
 * @brief
 * Validate a condition and mark the option as invalid if it fails.
 *
 * If @p cond evaluates to true, an error is logged and the provided
 * status variable is set to @ref amxd_status_invalid_value.
 *
 * @param cond        Condition indicating an invalid state.
 * @param status_var  Status variable to update on failure.
 * @param fmt         format string for the error message.
 * @param ...         Optional arguments for the format string.
 */
#define VALIDATE_OPTION_LENGTH_COND(cond, status_var, fmt, ...) \
    if(cond) { \
        SAH_TRACEZ_ERROR(ME, fmt, ## __VA_ARGS__); \
        (status_var) = amxd_status_invalid_value; \
    }

void _pool_option_added_or_removed(UNUSED const char* const event_name,
                                   const amxc_var_t* const event_data,
                                   UNUSED void* const priv) {
    amxd_object_t* pool = NULL;
    amxd_object_t* option_templ = NULL;
    amxd_dm_t* dm = NULL;
    pool_info_t* info = NULL;
    bool enabled = false;

    dm = dhcp_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DHCPv4 data model.");
    option_templ = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(option_templ, exit, ERROR, "Cannot get DHCPv4 pool option object.");

    enabled = GETP_BOOL(event_data, "parameters.Enable");

    pool = amxd_object_get_parent(option_templ);
    when_null_trace(pool, exit, ERROR, "Can't get DHCPv4 pool object");

    info = (pool_info_t*) pool->priv;
    when_null_trace(info, exit, ERROR, "DHCPv4 pool private data is NULL");

    if((info->flags.bit.enable == 1) && enabled) {
        when_failed_trace(pools_update_pool_status(pool), exit, ERROR, "Failed to update DHCPv4 pool status");
    }
exit:
    return;
}

void _pool_option_changed(UNUSED const char* const event_name,
                          const amxc_var_t* const event_data,
                          UNUSED void* const priv) {
    amxd_object_t* pool = NULL;
    amxd_object_t* option = NULL;
    amxd_dm_t* dm = NULL;
    pool_info_t* info = NULL;

    dm = dhcp_get_dm();
    when_null_trace(dm, exit, ERROR, "Cannot get DHCPv4 data model.");
    option = amxd_dm_signal_get_object(dm, event_data);
    when_null_trace(option, exit, ERROR, "Cannot get DHCPv4 pool option object.");

    pool = amxd_object_findf(option, "^.^.");
    when_null_trace(pool, exit, ERROR, "Can't get DHCPv4 pool object");

    info = (pool_info_t*) pool->priv;
    when_null_trace(info, exit, ERROR, "DHCPv4 pool private data is NULL");

    if(info->flags.bit.enable == 1) {
        when_failed_trace(pools_update_pool_status(pool), exit, ERROR, "Failed to update DHCPv4 pool status");
    }

exit:
    return;
}

/**
 * @brief
 * Validate the length of a DHCPv4 option value against its option tag.
 *
 * This function checks whether the provided option value length complies with
 * the expected format defined for a given DHCPv4 option tag.
 *
 * @param[in] length   Length of the option value in bytes.
 * @param[in] tag_val  DHCP option tag number.
 *
 * @return amxd_status_ok if the length is valid for the given tag.
 * @return amxd_status_invalid_value if the length does not meet the minimum expected length
 */
static amxd_status_t check_option_minimal_value_length(uint32_t length, uint32_t tag_val) {
    amxd_status_t status = amxd_status_ok;
    SAH_TRACE_IN();
    switch(tag_val) {
    // IPv4 address (4 bytes)
    case 1:
    case 16:
    case 28:
    case 32:
    case 50:
    case 54:
        VALIDATE_OPTION_LENGTH_COND((length != 4), status, "Option %u expects exactly 4 bytes (one IPv4 address)", tag_val);
        break;
    // IPv4 addresses list (multiple of 4 bytes)
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 41:
    case 42:
    case 44:
    case 45:
    case 48:
    case 49:
    case 65:
    case 68:
    case 69:
    case 70:
    case 71:
    case 72:
    case 73:
    case 74:
    case 75:
    case 76:
        VALIDATE_OPTION_LENGTH_COND(((length == 0) || (length % 4 != 0)), status, "Option %u expects multiple of 4 bytes (IPv4 addresses)", tag_val);
        break;
    // 32-bit integer options (4 bytes)
    case 2:
    case 24:
    case 35:
    case 51:
    case 58:
    case 59:
        VALIDATE_OPTION_LENGTH_COND((length != 4), status, "Option %u expects exactly 4 bytes (32-bit integer)", tag_val);
        break;
    // ASCII string options (per RFC, must not be empty; length >= 1)
    case 12:
    case 14:
    case 15:
    case 17:
    case 18:
    case 40:
    case 47:
    case 56:
    case 64:
    case 66:
    case 67:
        VALIDATE_OPTION_LENGTH_COND((length < 1), status, "Option %u cannot be empty (ASCII string)", tag_val);
        break;
    // Unsigned byte / Boolean (1 byte)
    case 19:
    case 20:
    case 23:
    case 27:
    case 29:
    case 30:
    case 31:
    case 34:
    case 36:
    case 37:
    case 39:
    case 52:
    case 53:
        VALIDATE_OPTION_LENGTH_COND((length != 1), status, "Option %u expects exactly 1 byte (boolean/unsigned byte)", tag_val);
        break;
    // IPv4 pairs (multiple of 8 bytes)
    case 21:
    case 33:
        VALIDATE_OPTION_LENGTH_COND(((length == 0) || (length % 8 != 0)), status,
                                    "Option %u expects multiple of 8 bytes (IPv4 pairs: IPv4+Mask or Dest+Router)", tag_val);
        break;
    // 16-bit integer options (2 bytes)
    case 13:
    case 22:
    case 26:
    case 57:
        VALIDATE_OPTION_LENGTH_COND((length != 2), status, "Option %u expects exactly 2 bytes (16-bit integer)", tag_val);
        break;
    // Path MTU Table (multiple of 2 bytes)
    case 25:
        VALIDATE_OPTION_LENGTH_COND(((length == 0) || (length % 2 != 0)), status, "Option %u expects multiple of 2 bytes (16-bit entries)", tag_val);
        break;
    // Vendor-specific (>= 2 bytes)
    case 43:
        VALIDATE_OPTION_LENGTH_COND((length < 2), status, "Option %u expects at least 2 bytes (vendor-specific: code + length)", tag_val);
        break;
    // Parameter Request List / Client Identifier / User Class Identifier/ Domain Search / SIP Servers (>= 1 byte)
    case 55:
    case 61:
    case 77:
    case 119:
    case 120:
        VALIDATE_OPTION_LENGTH_COND((length < 1), status, "Option %u expects at least 1 byte", tag_val);
        break;
    // Authentication (>= 11 bytes)
    case 90:
        VALIDATE_OPTION_LENGTH_COND((length < 11), status, "Option %u expects at least 11 bytes (DHCP Authentication)", tag_val);
        break;
    // Classless Static Route / Vendor Class ID / Vendor-Specific Info (>= 5 bytes)
    case 121:
    case 124:
    case 125:
        VALIDATE_OPTION_LENGTH_COND((length < 5), status, "Option %u expects at least 5 bytes", tag_val);
        break;
    // 6rd option (>= 22 bytes)
    case 212:
        VALIDATE_OPTION_LENGTH_COND((length < 22), status, "Option %u expects at least 22 bytes", tag_val);
        break;
    // MQTT / Configuration (>= 2 bytes)
    case 252:
        VALIDATE_OPTION_LENGTH_COND((length < 2), status, "Option %u expects at least 2 bytes", tag_val);
        break;
    // Allow any binary length
    case 46:
    case 60:
    default:
        SAH_TRACEZ_INFO(ME, "Option %u: no specific length check, accepting length=%u", tag_val, length);
        break;
    }

    SAH_TRACE_OUT();
    return status;
}

/**
 * @brief
 * validation callback to ensure a string has an even length.
 *
 * @param[in]  object  object owning the parameter.
 * @param[in]  param   Parameter being validated.
 * @param[in]  reason  The action identifier.
 * @param[in]  args    Parameter value data.
 * @param[out] retval  Variant to store the result of the action.
 * @param[in]  priv    NULL
 *
 * @return amxd_status_ok if the string length is even.
 * @return amxd_status_invalid_value if the string length is odd.
 */
amxd_status_t _is_length_even(UNUSED amxd_object_t* object,
                              amxd_param_t* param,
                              amxd_action_t reason,
                              const amxc_var_t* const args,
                              amxc_var_t* const retval,
                              void* priv) {
    SAH_TRACE_IN();
    amxd_status_t status = amxd_status_unknown_error;
    const char* str_val = NULL;

    when_null(param, exit);
    when_null(args, exit);
    when_true_status(reason != action_param_validate &&
                     reason != action_describe_action,
                     exit,
                     status = amxd_status_function_not_implemented);
    status = amxd_action_describe_action(reason, retval, "is_length_even", priv);
    when_true(status == amxd_status_ok, exit);

    str_val = amxc_var_constcast(cstring_t, args);
    status = (str_val && ((strlen(str_val) % 2) == 0))
        ? amxd_status_ok
        : amxd_status_invalid_value;
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Invalid value: length should be even!");
exit:
    SAH_TRACE_OUT();
    return status;
}

/**
 * @brief
 * Validate a DHCPv4 Option object
 *
 * object-level validation: ensures that an enabled DHCPv4 Option has:
 * - A non-empty value
 * - A value minimum length compatible with the configured DHCP option tag
 *
 * Validation is skipped when the option is disabled.
 *
 * @param[in]  object  DHCP Option object being validated.
 * @param[in]  param   Unused.
 * @param[in]  reason  The action identifier.
 * @param[in]  args    Unused.
 * @param[out] retval  Unused.
 * @param[in]  priv    Unused
 *
 * @return amxd_status_ok if the object is valid or disabled.
 * @return amxd_status_invalid_value if validation fails.
 */
amxd_status_t _validate_option_object(amxd_object_t* object,
                                      UNUSED amxd_param_t* param,
                                      amxd_action_t reason,
                                      UNUSED const amxc_var_t* const args,
                                      UNUSED amxc_var_t* const retval,
                                      UNUSED void* priv) {
    SAH_TRACE_IN();
    amxd_status_t status = amxd_status_ok;
    bool enable = false;
    uint32_t tag = 0;
    uint32_t length = 0;
    const char* str_val = NULL;
    unsigned char* option = NULL;


    when_true_status(reason != action_object_validate, exit,
                     status = amxd_status_function_not_implemented);

    enable = GET_BOOL(amxd_object_get_param_value(object, "Enable"), NULL);
    when_true_trace(enable == false, exit, INFO, "Option not enabled, skipping validation");

    tag = GET_UINT32(amxd_object_get_param_value(object, "Tag"), NULL);

    str_val = GET_CHAR(amxd_object_get_param_value(object, "Value"), NULL);
    when_str_empty_trace(str_val, exit, ERROR, "Can't parse option %u, value is empty", tag);

    length = strlen(str_val) / 2;
    status = check_option_minimal_value_length(length, tag);
    when_true_trace(status != amxd_status_ok, exit, ERROR, "Validation failed for DHCPv4 option tag=%u", tag);

exit:
    free(option);
    SAH_TRACE_OUT();
    return status;
}