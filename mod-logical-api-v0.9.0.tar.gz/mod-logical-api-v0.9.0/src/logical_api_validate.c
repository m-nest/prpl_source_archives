/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 The prpl Foundation contributors (see AUTHORS.md)
** This code is subject to the terms of the BSD-2-Clause-Patent license.
** See LICENSE file for more details.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxc/amxc_macros.h>
#include <amxb/amxb.h>
#include <ipat/ipat.h>

#include "logical_api_validate.h"
#include "logical_api_utils.h"
#include "logical_api.h"
#include "logical_api_getters.h"
#include "logical_api_component.h"

#define ME "validate"

static bool is_address_allowed(const char* address) {
    bool rv = false;
    amxd_object_t* logical_config = NULL;
    const amxc_var_t* whitelist_csv = NULL;
    const amxc_var_t* blacklist_csv = NULL;
    amxc_var_t lvalid;
    amxc_var_t linvalid;

    amxc_var_init(&lvalid);
    amxc_var_init(&linvalid);

    when_str_empty_trace(address, exit, ERROR, "address is empty");
    logical_config = amxd_dm_findf(logical_get_dm(), "Logical.%sSubnet.Config.", logical_get_prefix());
    when_null_trace(logical_config, exit, ERROR, "Failed to find object Logical.%sSubnet.Config.", logical_get_prefix());

    whitelist_csv = amxd_object_get_param_value(logical_config, "ValidSubnets");
    blacklist_csv = amxd_object_get_param_value(logical_config, "InvalidSubnets");
    amxc_var_convert(&lvalid, whitelist_csv, AMXC_VAR_ID_LIST);
    amxc_var_convert(&linvalid, blacklist_csv, AMXC_VAR_ID_LIST);

    if(!amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, &lvalid))) { // Whitelist entries
        amxc_var_for_each(valid, &lvalid) {
            const char* subnet = GET_CHAR(valid, NULL);
            if(ipat_text_in_subnet(address, subnet)) {
                // Match in whitelist -> allow address
                rv = true;
                goto exit;
            }
        }
        // No match in whitelist -> do not allow address
        rv = false;
    } else if(!amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, &linvalid))) { // Blacklist entries
        amxc_var_for_each(invalid, &linvalid) {
            const char* subnet = GET_CHAR(invalid, NULL);
            if(ipat_text_in_subnet(address, subnet)) {
                // Match in blacklist -> do not allow address
                rv = false;
                goto exit;
            }
        }
        // No match in the blacklist -> allow the address
        rv = true;
    } else { // No entries in both whitelist and blacklist -> allow the address
        rv = true;
    }

exit:
    amxc_var_clean(&linvalid);
    amxc_var_clean(&lvalid);
    return rv;
}

static char* ip_addr_to_subnet(const char* ip_addr, const char* subnet_mask) {
    amxc_string_t ip;
    char* subnet = NULL;

    amxc_string_init(&ip, 0);
    when_str_empty(ip_addr, exit);
    when_str_empty(subnet_mask, exit);

    amxc_string_setf(&ip, "%s/%s", ip_addr, subnet_mask);
    subnet = ipat_text_to_subnet(amxc_string_get(&ip, 0));

exit:
    amxc_string_clean(&ip);
    return subnet;
}

static bool conflicting_subnet_exists(const char* addr, const char* ip_intf) {
    amxc_string_t private_address_search_path;
    bool rv = false;
    amxc_var_t result;
    const char* alias = NULL;

    amxc_string_init(&private_address_search_path, 0);
    amxc_var_init(&result);

    when_str_empty_trace(addr, exit, ERROR, "IP address in empty");
    when_str_empty_trace(ip_intf, exit, ERROR, "IP interface is empty");

    component_get_param(&result, skip_prefix(ip_intf), ip_get_context(), "Alias");
    alias = GETP_CHAR(&result, "0.0.Alias");

    when_str_empty_trace(alias, exit, ERROR, "Couldn't find alias for IP interface %s", ip_intf);

    amxc_string_setf(&private_address_search_path,
                     "IP.Interface.*.IPv4Address.[TypeFlags == '@private' && AddressingType == 'Static' && Alias != '%s'].", alias);

    amxc_var_clean(&result);
    amxc_var_init(&result);

    when_failed_trace(multiple_components_get_parameters(&result, amxc_string_get(&private_address_search_path, 0), ip_get_context()),
                      exit, ERROR, "Failed to get all private LAN IP addresses");

    amxc_var_for_each(var, GETI_ARG(&result, 0)) {
        const char* ip_addr = GET_CHAR(var, "IPAddress");
        const char* subnet_mask = GET_CHAR(var, "SubnetMask");
        char* subnet = ip_addr_to_subnet(ip_addr, subnet_mask);

        if(subnet == NULL) {
            continue;
        } else {
            if(ipat_text_in_subnet(addr, subnet)) {
                SAH_TRACEZ_ERROR(ME, "conflicting subnet '%s' with ip address '%s'", subnet, addr);
                free(subnet);
                goto exit;
            }
        }
        free(subnet);
    }
    rv = true;
exit:
    amxc_var_clean(&result);
    amxc_string_clean(&private_address_search_path);
    return rv;
}

/**
   @brief
   Check that IP is in a reserved address list

   @param ip[in] IP in text format
   @param reserved_addresses_list[in] variant that contains the list of reserved addresses

   @return
   - true if IP is in at least 1 of the reserved addresses subnet.
   - false if IP is NOT in any of the reserved addresses subnet.
 */
static bool is_ip_in_reserved_addresses(const char* ip, amxc_var_t* reserved_addresses_list) {
    amxc_var_for_each(reserved_address, reserved_addresses_list) {
        const char* reserved_subnet = GET_CHAR(reserved_address, NULL);
        if(ipat_text_in_subnet(ip, reserved_subnet)) {
            SAH_TRACEZ_ERROR(ME, "IP Address '%s' is in the reserved DHCP subnet '%s'.", ip, reserved_subnet);
            return true;
        }
    }
    return false;
}

/**
   @brief
   Check that subnet_mask is allowed
   masks in /32 or /31 are not allowed because their host IP range is null

   @param subnet_mask[in] subnet_mask in text format (NOT in CIDR notation) ex: 255.255.255.0

   @return
   - true if subnet range is null.
   - false if subnet_mask is NOT null.
 */
static bool is_empty_subnet_range(const char* subnet_mask) {
    return (subnet_mask == NULL) || (!*subnet_mask) ||
           (strcmp(subnet_mask, "255.255.255.255") == 0) || (strcmp(subnet_mask, "255.255.255.254") == 0);
}

/**
   @brief
   Check if IP is a reserved address of the subnet (ie subnet address or broadcast address)

   @param ip_to_check[in] IP in text format
   @param subnet_address[in] subnet address
   @param broadcast_address[in] broadcast address

   @return
   - true if ip_to_check is a reserved address.
   - false if ip_to_check is NOT a reserved address.
 */
static bool is_ip_in_subnet_reserved_addresses(const char* ip_to_check, ipat_t* subnet_address,
                                               ipat_t* broadcast_address) {
    ipat_t ip = IPAT_INITIALIZE;
    int comp;

    ipat_pton(&ip, AF_INET, ip_to_check);

    comp = ipat_compare(&ip, subnet_address, false);
    if((comp == IPAT_COMPARE_EQUAL) || (comp == IPAT_COMPARE_ERROR)) {
        return false;
    }

    comp = ipat_compare(&ip, broadcast_address, false);
    if((comp == IPAT_COMPARE_EQUAL) || (comp == IPAT_COMPARE_ERROR)) {
        return false;
    }

    ipat_cleanup(&ip);
    return true;
}

/**
   @brief
   Check if IP is valid inside the subnet (ie not the subnet address nor the broadcast address)

   @param ip_to_test[in] ip address to test (in text format)
   @param ip_addr[in] router ip address in text format
   @param subnet_mask[in] subnet address

   @return
   - true if ip_addr is valid.
   - false if ip_addr is NOT valid.
 */
static bool is_address_valid_within_subnet(const char* ip_to_test, const char* ip_addr, const char* subnet_mask) {
    ipat_t subnet_address = IPAT_INITIALIZE;
    ipat_t broadcast_address = IPAT_INITIALIZE;
    bool rv = false;

    // compute subnet address and broadcast address
    get_subnet_reserved_addresses(ip_addr, subnet_mask, &subnet_address, &broadcast_address);

    // check that ip_addr is different from subnet address and broadcast address
    if(!is_ip_in_subnet_reserved_addresses(ip_to_test, &subnet_address, &broadcast_address)) {
        char* subnet_address_str = ipat_ntop_alloc(&subnet_address, false);
        char* broadcast_address_str = ipat_ntop_alloc(&broadcast_address, false);
        SAH_TRACEZ_ERROR(ME, "IPAddress '%s' must be different from subnet address '%s' and from broadcast address '%s'.",
                         ip_to_test, subnet_address_str, broadcast_address_str);
        free(subnet_address_str);
        free(broadcast_address_str);
        goto exit;
    }

    rv = true;

exit:
    ipat_cleanup(&subnet_address);
    ipat_cleanup(&broadcast_address);

    return rv;
}

static bool is_valid_subnet(const char* ip_addr, const char* subnet_mask, const char* ip_intf) {
    bool rv = false;
    char* subnet = NULL;

    subnet = ip_addr_to_subnet(ip_addr, subnet_mask);
    when_null_trace(subnet, exit,
                    ERROR, "subnet cannot be computed, subnet_mask value '%s' must be wrong.", subnet_mask);

    when_true_trace(is_empty_subnet_range(subnet_mask), exit,
                    ERROR, "subnet_mask value '%s' is not supported.", subnet_mask);

    when_false_trace(is_address_allowed(ip_addr), exit,
                     ERROR, "IPAddress '%s' is not in a supported subnet.", ip_addr);

    when_false(is_address_valid_within_subnet(ip_addr, ip_addr, subnet_mask), exit);

    when_false(conflicting_subnet_exists(subnet, ip_intf), exit);

    rv = true;

exit:
    free(subnet);
    return rv;

}

static bool are_ip_and_dhcp_pool_consistent(const char* ip_address, const char* subnet_mask, const char* min_address,
                                            const char* max_address, const char* dhcpv4_pool) {
    amxc_var_t reserved_addresses_list;
    bool rv = false;
    char* subnet = NULL;
    int min = IPAT_COMPARE_ERROR;
    int max = IPAT_COMPARE_ERROR;
    int comp = IPAT_COMPARE_ERROR;

    amxc_var_init(&reserved_addresses_list);
    if(dhcpv4_pool != NULL) {

        // check if min_address is in lan pool subnet
        subnet = ip_addr_to_subnet(ip_address, subnet_mask);
        when_false_trace(ipat_text_in_subnet(min_address, subnet), exit,
                         ERROR, "MinAddress '%s' is not in the lan pool subnet '%s'.", min_address, subnet);

        // check if max_address is in lan pool subnet
        when_false_trace(ipat_text_in_subnet(max_address, subnet), exit,
                         ERROR, "MaxAddress '%s' is not in the lan pool subnet '%s'.", max_address, subnet);

        // retrieve DHCPv4 reserved subnet addresses
        when_false(get_dhcpv4_pool_reserved_addresses(dhcpv4_pool, &reserved_addresses_list), exit);

        // check ip_address not in DHCPv4 reserved addresses
        when_true_trace(is_ip_in_reserved_addresses(ip_address, &reserved_addresses_list), exit,
                        ERROR, "IPAddress '%s' is included in the reserved addresses of DHCP lan pool '%s'.",
                        ip_address, dhcpv4_pool);

        // check min_address not in DHCPv4 reserved addresses
        when_true_trace(is_ip_in_reserved_addresses(min_address, &reserved_addresses_list), exit,
                        ERROR, "MinAddress '%s' is included in DHCP lan pool reserved addresses.", min_address);

        // check max_address not in DHCPv4 reserved addresses
        when_true_trace(is_ip_in_reserved_addresses(max_address, &reserved_addresses_list), exit,
                        ERROR, "MaxAddress '%s' is included in DHCP lan pool reserved addresses.", max_address);

        // check min_address < max_address
        comp = ipat_text_compare(min_address, max_address, false);
        when_false_trace(((comp == IPAT_COMPARE_LESS) || (comp == IPAT_COMPARE_EQUAL)), exit,
                         ERROR, "MinAddress '%s' is not less than max_address '%s'", min_address, max_address);

        // check ip_address < min_address or ip_address > max_address
        when_true_trace(((min_address == NULL) || (max_address == NULL)), exit,
                        ERROR, "min_address '%s' and max_address '%s' should not be null", min_address, max_address);
        min = ipat_text_compare(ip_address, min_address, false);
        max = ipat_text_compare(ip_address, max_address, false);
        when_true_trace((!((min == IPAT_COMPARE_LESS) || (max == IPAT_COMPARE_GREATER)) ||
                         (min == IPAT_COMPARE_ERROR) || (max == IPAT_COMPARE_ERROR)),
                        exit,
                        ERROR, "IPAddress '%s' is not outside the range [min_address, max_address] '[%s, %s]'",
                        ip_address, min_address, max_address);

        when_false(is_address_valid_within_subnet(min_address, ip_address, subnet_mask), exit);

        when_false(is_address_valid_within_subnet(max_address, ip_address, subnet_mask), exit);
    }

    rv = true;

exit:
    amxc_var_clean(&reserved_addresses_list);
    free(subnet);
    return rv;
}

static bool retrieve_subnet_params_to_validate(amxc_var_t* ip_params, const char* ip_intf,
                                               uint32_t ip_index, char** ip_addr, char** subnet_mask) {
    amxc_var_t current_ip_params;
    bool rv = false;

    amxc_var_init(&current_ip_params);
    when_null_trace(ip_addr, exit, ERROR, "No valid pointer to char* provided for ip addr.");
    when_null_trace(subnet_mask, exit, ERROR, "No valid pointer to char* provided for subnet mask.");

    amxc_var_set_type(&current_ip_params, AMXC_VAR_ID_HTABLE);
    when_str_empty_trace(ip_intf, exit, ERROR, "IP interface is empty");

    // retrieve subnet parameters: if some parameters are null, fall back on interface current parameters values
    when_failed_trace(get_ip_params(ip_intf, ip_index, &current_ip_params),
                      exit, ERROR, "Failed to collect missing IP parameters for validation");

    when_false_trace(get_ipv4_address_by_key(ip_params, "IPAddress", ip_addr), exit,
                     ERROR, "ip_addr format is not correct.");
    if(*ip_addr == NULL) {
        *ip_addr = strdup(GET_CHAR(&current_ip_params, "IPAddress"));
    }
    when_null_trace(*ip_addr, exit,
                    ERROR, "ip_addr is still null after trying to complete it");

    when_false_trace(get_ipv4_address_by_key(ip_params, "SubnetMask", subnet_mask), exit,
                     ERROR, "subnet_mask format is not correct.");
    if(*subnet_mask == NULL) {
        *subnet_mask = strdup(GET_CHAR(&current_ip_params, "SubnetMask"));
    }
    when_null_trace(*subnet_mask, exit,
                    ERROR, "subnet_mask is still null after trying to complete it");

    rv = true;

exit:
    amxc_var_clean(&current_ip_params);
    return rv;
}

static bool retrieve_ip_and_dhcp_params_to_validate(amxc_var_t* dhcpv4_params, const char* curr_dhcpv4_pool,
                                                    const char* new_pool_alias, char** min_address, char** max_address,
                                                    char** dhcp_pool_to_update) {
    bool rv = false;
    amxc_string_t new_pool;

    amxc_string_init(&new_pool, 0);

    when_null_trace(min_address, exit, ERROR, "No valid pointer to char* provided for min addr.");
    when_null_trace(max_address, exit, ERROR, "No valid pointer to char* provided for max addr.");
    when_null_trace(dhcp_pool_to_update, exit, ERROR, "No valid pointer to char* provided for the new dhcp pool to update.");

    when_true_trace((str_empty(curr_dhcpv4_pool) && str_empty(new_pool_alias)), exit,
                    ERROR, "Can't update pool parameters, current pool and new pool alias are both empty");

    when_false_trace(get_ipv4_address_by_key(dhcpv4_params, "MinAddress", min_address), exit,
                     ERROR, "min_address format is not correct.");

    when_false_trace(get_ipv4_address_by_key(dhcpv4_params, "MaxAddress", max_address), exit,
                     ERROR, "max_address format is not correct.");

    if(!str_empty(curr_dhcpv4_pool) && str_empty(new_pool_alias)) {
        *dhcp_pool_to_update = strdup(curr_dhcpv4_pool);
        retrieve_dhcp_fallback_value(curr_dhcpv4_pool, "MinAddress", min_address);
        when_null_trace(*min_address, exit,
                        ERROR, "Fail to get a correct IP V4 value for min_address");

        retrieve_dhcp_fallback_value(curr_dhcpv4_pool, "MaxAddress", max_address);
        when_null_trace(*max_address, exit,
                        ERROR, "Fail to get a correct IP V4 value for MaxAddress");

    } else if(!str_empty(new_pool_alias)) {
        char* new_pool_path = NULL;

        // search if a "new_pool_alias" dhcp pool already exists
        amxc_string_setf(&new_pool, "DHCPv4Server.Pool.%s.", new_pool_alias);
        new_pool_path = component_get_path_instance(dhcpv4_get_context(), amxc_string_get(&new_pool, 0));
        if(!str_empty(new_pool_path)) {
            // "new_pool_alias" dhcp pool already exists
            *dhcp_pool_to_update = new_pool_path;
            retrieve_dhcp_fallback_value(amxc_string_get(&new_pool, 0), "MinAddress", min_address);
            when_null_trace(*min_address, exit,
                            ERROR, "Fail to get a correct IP V4 value for min_address");

            retrieve_dhcp_fallback_value(amxc_string_get(&new_pool, 0), "MaxAddress", max_address);
            when_null_trace(*max_address, exit,
                            ERROR, "Fail to get a correct IP V4 value for MaxAddress");
        }
    }

    rv = true;

exit:
    amxc_string_clean(&new_pool);

    return rv;
}

bool is_valid_config(amxc_var_t* ip_params, amxc_var_t* dhcpv4_params,
                     const char* curr_dhcpv4_pool, const char* new_pool_alias,
                     bool need_ip_update, bool need_dhcp_update,
                     const char* ip_intf, uint32_t ip_index, char** dhcp_pool_to_update) {
    char* ip_addr = NULL;
    char* subnet_mask = NULL;
    char* min_address = NULL;
    char* max_address = NULL;
    bool rv = false;

    if(dhcp_pool_to_update == NULL) {
        SAH_TRACEZ_ERROR(ME, "no pointer to char* provided for dhcp_pool_to_update.");
        return rv;
    }

    *dhcp_pool_to_update = NULL;

    when_false(retrieve_subnet_params_to_validate(ip_params, ip_intf, ip_index, &ip_addr, &subnet_mask), exit);

    // check subnet parameters validity
    if(need_ip_update) {
        when_false(is_valid_subnet(ip_addr, subnet_mask, ip_intf), exit);
    }

    if(need_dhcp_update) {
        when_false(retrieve_ip_and_dhcp_params_to_validate(dhcpv4_params, curr_dhcpv4_pool,
                                                           new_pool_alias, &min_address, &max_address,
                                                           dhcp_pool_to_update), exit);
        // check ip and dhcp parameters consistency
        when_false_trace(are_ip_and_dhcp_pool_consistent(ip_addr, subnet_mask,
                                                         min_address, max_address, new_pool_alias),
                         exit,
                         ERROR, "IPAddress '%s' and dhcp pool '%s' are not consistent", ip_addr, curr_dhcpv4_pool);
    }
    rv = true;

exit:
    free(min_address);
    free(max_address);
    free(ip_addr);
    free(subnet_mask);

    return rv;
}
