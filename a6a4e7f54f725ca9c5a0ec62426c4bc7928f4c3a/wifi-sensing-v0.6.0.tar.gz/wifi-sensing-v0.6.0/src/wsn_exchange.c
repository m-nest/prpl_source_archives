/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wsn_common.h"
#include "wsn_exchange.h"
#include "wsn_main.h"
#include "wsn_utils.h"
#include "wsn_error.h"
#include "wsn_events.h"
#include "wsn_socket.h"

#define ME "sensing"

amxc_llist_t sensingCaps;
amxc_llist_t supportedRadioBandwidth;
amxc_llist_t headerInfo;

static int s_findBandwidthInSupportedBandwidths(unsigned int bandwidth, const char* supportedBandwidths) {
    for(swl_radBw_e rbw = SWL_RAD_BW_AUTO; rbw < SWL_RAD_BW_MAX; rbw++) {
        if((swl_chanspec_radBwToInt(rbw) == bandwidth) &&
           (swl_strlst_contains(supportedBandwidths, ",", swl_radBw_str[rbw]))) {
            return 1;
        }
    }
    return 0;

}

static int s_querySupportedBandwidthOfRadio(char* radioPath, unsigned int bandwidth) {
    amxc_var_t ret;
    amxc_var_init(&ret);
    amxc_string_t query;
    amxc_string_init(&query, 0);
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");
    int rv = -1;

    amxc_string_setf(&query, "%sSupportedOperatingChannelBandwidth", radioPath);
    rv = amxb_get(ctx, amxc_string_get(&query, 0), 0, &ret, 0);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get SupportedOperatingChannelBandwidth");
        amxc_string_clean(&query);
        return 0;
    }

    wsn_supportedRadioBandwidth_t* supportedBandwidth = calloc(1, sizeof(wsn_supportedRadioBandwidth_t));
    if(!supportedBandwidth) {
        SAH_TRACEZ_ERROR(ME, "calloc failed");
        amxc_string_clean(&query);
        amxc_var_clean(&ret);
        return -1;
    }

    const char* supportedBandwidths = GETP_CHAR(&ret, "0.0.SupportedOperatingChannelBandwidth");

    SAH_TRACEZ_INFO(ME, "SupportedOperatingChannelBandwidth retrieved is %s", supportedBandwidths);

    supportedBandwidth->radioPath = strdup(radioPath);
    if(!supportedBandwidth->radioPath) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", radioPath);
        free(supportedBandwidth);
        amxc_string_clean(&query);
        amxc_var_clean(&ret);
        return -1;
    }

    supportedBandwidth->operatingBandwidths = strdup(supportedBandwidths);
    if((supportedBandwidths != NULL) && (!supportedBandwidth->operatingBandwidths)) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", supportedBandwidths);
        free(supportedBandwidth);
        amxc_string_clean(&query);
        amxc_var_clean(&ret);
        return -1;
    }

    amxc_llist_it_init(&supportedBandwidth->it);
    amxc_llist_append(&supportedRadioBandwidth, &supportedBandwidth->it);

    amxc_string_clean(&query);

    if(s_findBandwidthInSupportedBandwidths(bandwidth, supportedBandwidths)) {
        amxc_var_clean(&ret);
        return 1;
    }

    amxc_var_clean(&ret);
    return 0;
}

static int s_findSupportedBandwidth(char* radio_path, unsigned int bandwidth) {
    amxc_llist_for_each(it, &supportedRadioBandwidth) {
        wsn_supportedRadioBandwidth_t* supportedBandwidth = amxc_container_of(it, wsn_supportedRadioBandwidth_t, it);
        SAH_TRACEZ_INFO(ME, "radio path from supported bandwidth list is %s", supportedBandwidth->radioPath);
        if(strcmp(radio_path, supportedBandwidth->radioPath) == 0) {
            SAH_TRACEZ_INFO(ME, "Found radio path in list");
            if(s_findBandwidthInSupportedBandwidths(bandwidth, supportedBandwidth->operatingBandwidths)) {
                SAH_TRACEZ_INFO(ME, "Bandwidth is present in SupportedOperatingBandwidth list");
                return 1;
            } else {
                SAH_TRACEZ_WARNING(ME, "Bandwidth is not present in SupportedOperatingBandwidth list");
                return 0;
            }
        }
    }
    SAH_TRACEZ_INFO(ME, "Radio path not found in list");
    return -1;
}

static int s_findSensingTypeInSupportedCaps(char* type, const char* supportedTypes) {
    if(swl_strlst_contains(supportedTypes, ",", type)) {
        SAH_TRACEZ_INFO(ME, "Type %s is present in SupportedSensingTypes", type);
        return 1;
    } else {
        SAH_TRACEZ_WARNING(ME, "Type %s is not present in SupportedSensingTypes", type);
        return 0;
    }
}

static int s_querySupportedSensingTypes(char* radioPath, char* exchangeType, char* dataType) {

    amxc_var_t ret1;
    amxc_var_init(&ret1);
    amxc_var_t ret2;
    amxc_var_init(&ret2);
    amxc_string_t query;
    amxc_string_init(&query, 0);
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");
    int rv = -1;

    amxc_string_setf(&query, "%sSupportedSensingDataTypes", radioPath);
    rv = amxb_get(ctx, amxc_string_get(&query, 0), 0, &ret1, 0);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get SupportedSensingDataTypes");
        amxc_string_clean(&query);
        return 0;
    }

    amxc_string_setf(&query, "%sSupportedSensingExchangeTypes", radioPath);
    rv = amxb_get(ctx, amxc_string_get(&query, 0), 0, &ret2, 0);
    if(rv != amxd_status_ok) {
        SAH_TRACEZ_ERROR(ME, "Failed to get SupportedSensingExchangeTypes");
        amxc_string_clean(&query);
        amxc_var_clean(&ret1);
        return 0;
    }

    wsn_sensingCaps_t* caps = calloc(1, sizeof(wsn_sensingCaps_t));
    if(!caps) {
        SAH_TRACEZ_ERROR(ME, "calloc failed");
        amxc_string_clean(&query);
        amxc_var_clean(&ret1);
        amxc_var_clean(&ret2);
        return -1;
    }

    const char* supportedDataTypes = GETP_CHAR(&ret1, "0.0.SupportedSensingDataTypes");
    const char* supportedExchangeTypes = GETP_CHAR(&ret2, "0.0.SupportedSensingExchangeTypes");

    SAH_TRACEZ_INFO(ME, "SupportedSensingExchangeTypes retrieved is %s", supportedExchangeTypes);
    SAH_TRACEZ_INFO(ME, "SupportedSensingDataTypes retrieved is %s", supportedDataTypes);

    caps->radioPath = strdup(radioPath);
    if(!caps->radioPath) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", radioPath);
        free(caps);
        amxc_string_clean(&query);
        amxc_var_clean(&ret1);
        amxc_var_clean(&ret2);
        return -1;
    }
    caps->supportedDataTypes = strdup(supportedDataTypes);
    if((supportedDataTypes != NULL) && (!caps->supportedDataTypes)) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", supportedDataTypes);
        free(caps);
        amxc_string_clean(&query);
        amxc_var_clean(&ret1);
        amxc_var_clean(&ret2);
        return -1;
    }
    caps->supportedExchangeTypes = strdup(supportedExchangeTypes);
    if((supportedExchangeTypes != NULL) && (!caps->supportedExchangeTypes)) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", supportedExchangeTypes);
        free(caps);
        amxc_string_clean(&query);
        amxc_var_clean(&ret1);
        amxc_var_clean(&ret2);
        return -1;
    }

    amxc_llist_it_init(&caps->it);
    amxc_llist_append(&sensingCaps, &caps->it);

    amxc_string_clean(&query);
    if(exchangeType != NULL) {
        if(s_findSensingTypeInSupportedCaps(exchangeType, supportedExchangeTypes)) {
            amxc_var_clean(&ret1);
            amxc_var_clean(&ret2);
            return 1;
        }
    }

    if(dataType != NULL) {
        if(s_findSensingTypeInSupportedCaps(dataType, supportedDataTypes)) {
            amxc_var_clean(&ret1);
            amxc_var_clean(&ret2);
            return 1;
        }
    }

    amxc_var_clean(&ret1);
    amxc_var_clean(&ret2);
    return 0;
}

static int s_findSensingCapsOfRadio(char* radio_path, char* exchangeType, char* dataType) {
    amxc_llist_for_each(it, &sensingCaps) {
        wsn_sensingCaps_t* caps = amxc_container_of(it, wsn_sensingCaps_t, it);
        SAH_TRACEZ_INFO(ME, "Cap radio path is %s", caps->radioPath);
        if(strcmp(radio_path, caps->radioPath) == 0) {
            SAH_TRACEZ_INFO(ME, "Found radio path in list");
            if(dataType != NULL) {
                if(s_findSensingTypeInSupportedCaps(dataType, caps->supportedDataTypes)) {
                    SAH_TRACEZ_INFO(ME, "DataType is present in SupportedSensingDataTypes");
                    return 1;
                } else {
                    SAH_TRACEZ_WARNING(ME, "DataType is not present in SupportedSensingDataTypes");
                    return 0;
                }
            } else {
                if(s_findSensingTypeInSupportedCaps(exchangeType, caps->supportedExchangeTypes)) {
                    SAH_TRACEZ_INFO(ME, "ExchangeType is present in SupportedSensingExchangeTypes");
                    return 1;
                } else {
                    SAH_TRACEZ_WARNING(ME, "ExchangeType is not present in SupportedSensingExchangeTypes");
                    return 0;
                }
            }
        }
    }
    SAH_TRACEZ_INFO(ME, "Radio path not found in list");
    return -1;
}

/**
 * @brief s_errorCodeToStr
 *
 * Converts error code to char
 *
 * @param code contains error code
 * @return
 *     - error code in char format
 */
static const char* s_errorCodeToStr(wsn_error_e code) {
    static const char* strings[] = { "SUCCESS", "NOT_PRESENT", "NOT_IN_SAME_BSS", "DENIED_NO_ASSOCIATION_EXISTS", "REFUSED_TEMPORARILY", "INVALID_PARAMETERS"};
    if(code < SWL_ARRAY_SIZE(strings)) {
        return strings[code];
    }
    return "";
}

/*
 * Exchange instance addition action handler
 */
amxd_status_t _wsn_Sensing_createExchange_oaf(amxd_object_t* object,
                                              amxd_param_t* param,
                                              amxd_action_t reason,
                                              const amxc_var_t* const args,
                                              amxc_var_t* const retval,
                                              void* priv) {

    SAH_TRACEZ_IN(ME);

    amxd_status_t status = amxd_action_object_add_inst(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "Exchange instance creation failed with error: %d", status);

    wsn_exchange_t* newexchange = calloc(1, sizeof(wsn_exchange_t));
    ASSERT_NOT_NULL(newexchange, amxd_status_out_of_mem, ME, "NULL");

    SAH_TRACEZ_INFO(ME, "Adding new Exchange");
    newexchange->object = object;
    object->priv = newexchange;

    SAH_TRACEZ_OUT(ME);
    return status;
}

static void s_addExchangeInst_oaf(void* priv _UNUSED, amxd_object_t* object, const amxc_var_t* const initialParamValues _UNUSED) {
    SAH_TRACEZ_IN(ME);

    uint32_t index = amxd_object_get_index(object);
    SAH_TRACEZ_INFO(ME, "Instance index is %u", index);

    ASSERT_TRUE(swl_typeUInt32_commitObjectParam(object, "ExchangeID", index), , ME, "Failed to set ExchangeID");

    SAH_TRACEZ_OUT(ME);
}

SWLA_DM_HDLRS(sExchangeDmHdlrs,
              ARR(),
              .instAddedCb = s_addExchangeInst_oaf, );

void _wsn_exchange_setConf_ocf(const char* const sig_name,
                               const amxc_var_t* const data,
                               void* const priv) {
    swla_dm_procObjEvtOfLocalDm(&sExchangeDmHdlrs, sig_name, data, priv);
}

/**
 * @brief _AddExchange
 *
 * Add a sensing measurement exchange between two STA’s
 *
 * @param args argument list
 *     - Rate : Inter-measurement interval in multiples of 10ms
 *     - Bandwidth : Requested bandwidth, in MHz, on which to report
 *     - ExchangeType : Exchange Type for the radio to which the Transmitter is associated
 *     - DataType : Exchange Type for the radio to which the Receiver is associated
 *     - Transmitter : MAC address of the STA transmitting the frame on which CSI data will be gathered
 *     - Receiver : MAC address of the STA receiving the frame on which CSI data will be gathered
 * @param retval variant that must contain the return value
 * @return
 *     - function execution state
 */
amxd_status_t _AddExchange(amxd_object_t* obj,
                           amxd_function_t* func _UNUSED,
                           amxc_var_t* args,
                           amxc_var_t* retval) {

    SAH_TRACEZ_IN(ME);

    amxd_status_t status = amxd_status_ok;
    wsn_error_e errcode = INVALID_PARAMETERS;
    unsigned int exchangeid = 0;
    unsigned int rate = 0;
    const char* error = NULL;
    char* transmitterRadioPath = NULL;
    char* receiverRadioPath = NULL;
    int rv = -1;
    int value = -1;
    amxc_var_t functionArgs;
    amxc_var_init(&functionArgs);
    amxc_var_set_type(&functionArgs, AMXC_VAR_ID_HTABLE);

    amxc_var_t ret;
    amxc_var_init(&ret);

    amxc_string_t path;
    amxc_string_init(&path, 0);

    amxd_trans_t* trans;
    amxd_object_t* templateObj = amxd_object_findf(obj, "Exchange");
    ASSERT_NOT_NULL(templateObj, amxd_status_unknown_error, ME, "Exchange object not found");

    SAH_TRACEZ_INFO(ME, "Getting wifi context");
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");

    const char* transmitter = GET_CHAR(args, "Transmitter");

    if(transmitter == NULL) {
        SAH_TRACEZ_WARNING(ME, "No transmitter in input arguments");
        goto exit;
    }
    if(!swl_mac_charIsValidStaMac((swl_macChar_t*) transmitter)) {
        SAH_TRACEZ_WARNING(ME, "Invalid transmitter");
        goto exit;
    }

    const char* receiver = GET_CHAR(args, "Receiver");
    if((receiver != NULL) && !swl_mac_charIsValidStaMac((swl_macChar_t*) receiver)) {
        SAH_TRACEZ_WARNING(ME, "Invalid receiver");
        goto exit;
    }

    rate = GET_UINT32(args, "Rate");
    unsigned int bandwidth = GET_UINT32(args, "Bandwidth");
    unsigned int nTx = GET_UINT32(args, "NTx");
    unsigned int nRx = GET_UINT32(args, "NRx");
    char* exchangetype = GET_CHAR(args, "ExchangeType");
    char* datatype = GET_CHAR(args, "DataType");
    int transmitterApInstance = 0;
    int receiverApInstance = 0;

    if(rate > MAX_RATE) {
        SAH_TRACEZ_WARNING(ME, "Invalid rate %u", rate);
        errcode = INVALID_PARAMETERS;
        goto exit;
    }

    transmitterApInstance = wsn_util_getApInstanceOfAssociatedStation(transmitter, true);

    if((receiver == NULL) && (transmitterApInstance == 0)) {
        errcode = NOT_PRESENT;
        goto exit;
    }

    if(receiver != NULL) {
        receiverApInstance = wsn_util_getApInstanceOfAssociatedStation(receiver, true);
        SAH_TRACEZ_WARNING(ME, "Transmitter ap instance is %d and receiver ap instance is %d", transmitterApInstance, receiverApInstance);
        if((transmitterApInstance == 0) || (receiverApInstance == 0)) {
            errcode = DENIED_NO_ASSOCIATION_EXISTS;
            goto exit;
        }
        if(transmitterApInstance != receiverApInstance) {
            errcode = NOT_IN_SAME_BSS;
            goto exit;
        }
    }

    //Find Radio which transmitter is connected to, then call that Radio's addClient
    SAH_TRACEZ_INFO(ME, "Getting radio for specified transmitter");

    transmitterRadioPath = wsn_util_getRadioPathOfAssociatedStation(transmitter, true);

    if(bandwidth > 0) {
        value = s_findSupportedBandwidth(transmitterRadioPath, bandwidth);
        if(value == 0) {
            goto exit;
        }
        if(value == -1) {
            rv = s_querySupportedBandwidthOfRadio(transmitterRadioPath, bandwidth);
            if(rv == -1) {
                free(transmitterRadioPath);
                return amxd_status_out_of_mem;
            } else if(rv == 0) {
                SAH_TRACEZ_INFO(ME, "Bandwidth not supported");
                goto exit;
            } else {
                SAH_TRACEZ_INFO(ME, "Bandwidth supported");
            }
        } else {
            SAH_TRACEZ_INFO(ME, "Bandwidth supported and present in list");
        }
    }


    if(datatype != NULL) {
        receiverRadioPath = wsn_util_getRadioPathOfAssociatedStation(receiver, true);
        if(receiverRadioPath == NULL) {
            SAH_TRACEZ_ERROR(ME, "Radio Path of receiver not found");
            goto exit;
        }

        value = s_findSensingCapsOfRadio(receiverRadioPath, NULL, datatype);
        if(value == 0) {
            goto exit;
        }
        if(value == -1) {
            rv = s_querySupportedSensingTypes(receiverRadioPath, NULL, datatype);
            if(rv == -1) {
                free(transmitterRadioPath);
                free(receiverRadioPath);
                return amxd_status_out_of_mem;
            } else if(rv == 0) {
                SAH_TRACEZ_INFO(ME, "Data Type not supported");
                goto exit;
            } else {
                SAH_TRACEZ_INFO(ME, "Data Type supported");
            }
        } else {
            SAH_TRACEZ_INFO(ME, "Data Type supported and present in list");
        }
    }

    SAH_TRACEZ_INFO(ME, "Setting rate");
    amxc_var_t* var = GET_ARG(args, "Rate");
    if(var == NULL) {
        //Rate not provided as input. Consider default value of rate
        rate = DEFAULT_RATE;
    }

    if(rate == 0) {
        SAH_TRACEZ_WARNING(ME, "Since rate is %u, returning error code REFUSED_TEMPORARILY", rate);
        errcode = REFUSED_TEMPORARILY;
        goto exit;
    }

    if(exchangetype != NULL) {
        if(transmitterRadioPath == NULL) {
            SAH_TRACEZ_ERROR(ME, "Radio Path of transmitter not found");
            goto exit;
        }

        value = s_findSensingCapsOfRadio(transmitterRadioPath, exchangetype, NULL);
        if(value == 0) {
            goto exit;
        }
        if(value == -1) {
            rv = s_querySupportedSensingTypes(transmitterRadioPath, exchangetype, NULL);
            if(rv == -1) {
                free(transmitterRadioPath);
                return amxd_status_out_of_mem;
            } else if(rv == 0) {
                SAH_TRACEZ_INFO(ME, "Exchange Type not supported");
                goto exit;
            } else {
                SAH_TRACEZ_INFO(ME, "Exchange Type supported");
            }
        } else {
            SAH_TRACEZ_INFO(ME, "Exchange Type supported and present in list");
        }
    }

    unsigned int monitorinterval = rate * 10;

    SAH_TRACEZ_INFO(ME, "Setting arguments for addClient");

    amxc_var_add_key(int16_t, &functionArgs, "MonitorInterval", monitorinterval);
    amxc_var_add_key(cstring_t, &functionArgs, "MACAddress", transmitter);
    amxc_var_add_key(cstring_t, &functionArgs, "Receiver", receiver);
    amxc_var_add_key(uint32_t, &functionArgs, "Bandwidth", bandwidth);
    amxc_var_add_key(cstring_t, &functionArgs, "ExchangeType", exchangetype);
    amxc_var_add_key(cstring_t, &functionArgs, "DataType", datatype);
    amxc_var_add_key(uint32_t, &functionArgs, "NTx", nTx);
    amxc_var_add_key(uint32_t, &functionArgs, "NRx", nRx);

    amxc_var_init(&ret);
    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "%sSensing.", transmitterRadioPath);

    SAH_TRACEZ_INFO(ME, "Path for addClient is %s", amxc_string_get(&path, 0));
    status = amxb_call(ctx, amxc_string_get(&path, 0), "addClient", &functionArgs, &ret, 3);
    if(status == amxd_status_ok) {
        errcode = SUCCESS;
    }

exit:
    SAH_TRACEZ_INFO(ME, "Entering exit block");
    error = s_errorCodeToStr(errcode);
    //Calling ExchangeTerminated! event if errorcode is not SUCCESS
    if(swl_str_matches(error, "SUCCESS")) {

        wsn_headerInfo_t* header = calloc(1, sizeof(wsn_headerInfo_t));
        if(!header) {
            SAH_TRACEZ_ERROR(ME, "calloc failed");
            return amxd_status_out_of_mem;
        }

        wsn_eventInfo_t* info = calloc(1, sizeof(wsn_eventInfo_t));
        if(!info) {
            SAH_TRACEZ_ERROR(ME, "calloc failed");
            return amxd_status_out_of_mem;
        }

        SAH_TRACEZ_INFO(ME, "Create new Exchange with Transmitter %s", transmitter);
        swla_trans_t tmpTrans;
        trans = swla_trans_init(&tmpTrans, NULL, templateObj);
        if(trans == NULL) {
            SAH_TRACEZ_ERROR(ME, "trans init failure");
            free(header);
            free(info);
            return amxd_status_unknown_error;
        }

        amxd_trans_select_object(trans, templateObj);
        amxd_trans_add_inst(trans, 0, NULL);
        amxd_trans_set_value(cstring_t, trans, "Transmitter", transmitter);
        amxd_trans_set_value(uint8_t, trans, "Rate", rate);

        SAH_TRACEZ_INFO(ME, "Updating Exchange object with provided arguments");
        const char* validArgs = "Rate,Bandwidth,NTx,NRx,ExchangeType,DataType,Transmitter,Receiver";
        amxc_var_for_each(newValue, args) {
            const char* pname = amxc_var_key(newValue);
            //skip arguments not matching instance's parameter names
            //to avoid transaction applying issue
            if(!swl_strlst_contains(validArgs, ",", pname)) {
                SAH_TRACEZ_WARNING(ME, "skip unknown argument %s", pname);
                continue;
            }
            //we assume known args and obj params types are matching
            amxd_trans_set_param(trans, pname, newValue);
        }

        swl_rc_ne rc = swla_trans_finalize(&tmpTrans, swl_lib_getLocalDm());
        if(rc == SWL_RC_ERROR) {
            SAH_TRACEZ_ERROR(ME, "trans apply failure");
            free(header);
            free(info);
            return amxd_status_unknown_error;
        }

        amxd_object_t* instObj = NULL;
        amxc_llist_it_t* it = amxc_llist_get_last(&templateObj->instances);
        if(it != NULL) {
            instObj = amxc_container_of(it, amxd_object_t, it);
        }
        uint32_t index = amxd_object_get_index(instObj);

        exchangeid = index;

        SAH_TRACEZ_INFO(ME, "Setting private data");
        if(datatype != NULL) {
            swl_str_copy(header->datatype, sizeof(header->datatype), datatype);
        }

        header->exchange_id = exchangeid;

        if(transmitter != NULL) {
            if(swl_typeMacBin_fromChar(&header->tx_sta_mac, transmitter)) {
                SAH_TRACEZ_INFO(ME, "Transitter in macBin is %s", swl_typeMacBin_toBuf32Ref(&header->tx_sta_mac).buf);
            }
        }

        if(receiver != NULL) {
            if(swl_typeMacBin_fromChar(&header->rx_sta_mac, receiver)) {
                SAH_TRACEZ_INFO(ME, "Receiver in macBin is ", swl_typeMacBin_toBuf32Ref(&header->rx_sta_mac).buf);
            }
        }

        amxc_llist_it_init(&header->it);
        amxc_llist_append(&headerInfo, &header->it);

        int ret = -1;

        info->exchange_id = exchangeid;
        if(transmitterRadioPath != NULL) {
            info->radio_path = strdup(transmitterRadioPath);
            if(!info->radio_path) {
                SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", transmitterRadioPath);
                free(info);
                return amxd_status_out_of_mem;
            }
        }
        info->exchangeObj = amxd_object_findf(obj, "Exchange");

        swl_macChar_t strMac = g_swl_macChar_null;
        swl_typeMacChar_fromChar(&strMac, transmitter);
        info->staMac = strdup(strMac.cMac);

        if(!info->staMac) {
            SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", strMac.cMac);
            free(info);
            return amxd_status_out_of_mem;
        }
        amxc_string_t expr;
        amxc_string_init(&expr, 0);
        amxc_string_setf(&expr, "notification == 'Disassociation'");

        SAH_TRACEZ_INFO(ME, "Subscribing to client Disassociation event");
        ret = amxb_subscribe(ctx, "WiFi.AccessPoint.", amxc_string_get(&expr, 0), wsn_events_cb, info);

        if(ret != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to subscribe to Disassociation event");
        } else {
            SAH_TRACEZ_INFO(ME, "Subscribed to Disassociation event");
        }

        //Subscribing to object-changed event for Radio
        SAH_TRACEZ_WARNING(ME, "Subscribing to object-changed event for Radio");

        amxc_string_init(&expr, 0);
        amxc_string_setf(&expr, "notification == 'dm:object-changed' && contains('parameters.Status')");

        ret = amxb_subscribe(ctx, transmitterRadioPath, amxc_string_get(&expr, 0), wsn_events_cb, info);

        if(ret != 0) {
            SAH_TRACEZ_ERROR(ME, "Failed to subscribe to object changed event");
        } else {
            SAH_TRACEZ_WARNING(ME, "Subscribed to object-changed event");
        }

        amxc_string_clean(&expr);
    } else {
        amxc_var_t notifMap;
        amxc_var_init(&notifMap);
        amxc_var_set_type(&notifMap, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(uint32_t, &notifMap, "ExchangeID", exchangeid);
        amxc_var_add_key(cstring_t, &notifMap, "Cause", error);

        SAH_TRACEZ_INFO(ME, "Calling ExchangeTerminated event");
        amxd_object_trigger_signal(templateObj, "ExchangeTerminated!", &notifMap);
        amxc_var_clean(&notifMap);

        SAH_TRACEZ_INFO(ME, "Calling ExchangeTerminated event callback");
        amxc_var_t val;
        amxc_var_init(&val);
        amxc_var_set_type(&val, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(uint32_t, &val, "ExchangeID", exchangeid);
        wsn_exchangeTerminated_event_cb(NULL, &val, templateObj);
        amxc_var_clean(&val);
    }

ret:
    free(transmitterRadioPath);
    free(receiverRadioPath);
    amxc_string_clean(&path);
    amxc_var_clean(&functionArgs);
    amxc_var_clean(&ret);

    SAH_TRACEZ_INFO(ME, "Setting return values for addExchange");

    //Returning newly created ExchangeID and ErrorCcode
    amxc_var_set_type(retval, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, retval, "ExchangeID", exchangeid);
    amxc_var_add_key(cstring_t, retval, "ErrorCode", error);

    SAH_TRACEZ_OUT(ME);
    return status;
}

/*
 * Exchange instance deletion action handler
 */
amxd_status_t _wsn_Sensing_deleteExchange_odf(amxd_object_t* object,
                                              amxd_param_t* param _UNUSED,
                                              amxd_action_t reason _UNUSED,
                                              const amxc_var_t* const args _UNUSED,
                                              amxc_var_t* const retval _UNUSED,
                                              void* priv _UNUSED) {
    SAH_TRACEZ_IN(ME);

    amxc_var_t params;
    amxc_var_init(&params);
    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    swla_object_paramsToMap(&params, object);

    char* radiopath = NULL;
    const char* transmitter = GET_CHAR(&params, "Transmitter");
    SAH_TRACEZ_INFO(ME, "Transmitter mac to be deleted is %s", transmitter);

    radiopath = wsn_util_getRadioPathOfAssociatedStation(transmitter, false);

    SAH_TRACEZ_INFO(ME, "Setting arguments for delClient");
    amxc_var_t functionArgs;
    amxc_var_init(&functionArgs);
    amxc_var_set_type(&functionArgs, AMXC_VAR_ID_HTABLE);

    amxc_var_t ret;
    amxc_var_init(&ret);
    amxc_var_set_type(&ret, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &functionArgs, "MACAddress", transmitter);

    SAH_TRACEZ_INFO(ME, "Getting wifi context");
    amxb_bus_ctx_t* ctx = amxb_be_who_has("WiFi.");

    amxc_string_t path;
    amxc_string_init(&path, 0);

    amxc_string_setf(&path, "%sSensing.", radiopath);

    SAH_TRACEZ_INFO(ME, "Path for delClient is %s", amxc_string_get(&path, 0));
    if(amxb_call(ctx, amxc_string_get(&path, 0), "delClient", &functionArgs, &ret, 3) != amxd_status_ok) {
        SAH_TRACEZ_WARNING(ME, "Not able to delete client");
    }

    swl_macBin_t macAddr;
    swl_typeMacBin_fromChar(&macAddr, transmitter);
    wsn_headerInfo_t* data = wsn_findMacAddressInList(macAddr);

    if(data == NULL) {
        SAH_TRACEZ_INFO(ME, "MACAddress is not found in list headerInfo");
    } else {
        SAH_TRACEZ_INFO(ME, "MACAddress found in list. Removing entry");
        amxc_llist_it_take(&data->it);
        free(data);
    }

    int rv = -1;
    wsn_eventInfo_t* info = calloc(1, sizeof(wsn_eventInfo_t));
    if(!info) {
        SAH_TRACEZ_ERROR(ME, "calloc failed");
        return amxd_status_out_of_mem;
    }

    info->exchange_id = GET_UINT32(&params, "ExchangeID");
    if(radiopath != NULL) {
        info->radio_path = strdup(radiopath);
        if(!info->radio_path) {
            SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", radiopath);
            free(info);
            return amxd_status_out_of_mem;
        }
    }
    info->exchangeObj = amxd_object_findf(amxd_object_get_parent(amxd_object_get_parent(object)), "Exchange");

    if(info->exchangeObj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Exchange object is NULL");
    }
    swl_macChar_t strMac = g_swl_macChar_null;
    swl_typeMacChar_fromChar(&strMac, transmitter);
    info->staMac = strdup(strMac.cMac);

    if(!info->staMac) {
        SAH_TRACEZ_ERROR(ME, "strdup(%s) failed", strMac.cMac);
        free(info);
        return amxd_status_out_of_mem;
    }

    rv = amxb_unsubscribe(ctx, "WiFi.AccessPoint.", wsn_events_cb, info);

    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to unsubscribe to Disassociation event");
    } else {
        SAH_TRACEZ_INFO(ME, "Unsubscribed to Disassociation event");
    }

    rv = amxb_unsubscribe(ctx, info->radio_path, wsn_events_cb, info);

    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to unsubscribe to object changed event");
    } else {
        SAH_TRACEZ_INFO(ME, "Unsubscribed to object-changed event");
    }

    free(info);
    free(radiopath);
    amxc_string_clean(&path);
    amxc_var_clean(&functionArgs);
    amxc_var_clean(&ret);
    amxc_var_clean(&params);

    amxd_status_t status = amxd_action_object_destroy(object, param, reason, args, retval, priv);
    ASSERT_EQUALS(status, amxd_status_ok, status, ME, "Fail to destroy obj instance st:%d", status);
    ASSERTS_EQUALS(amxd_object_get_type(object), amxd_object_instance, status, ME, "obj is not instance");

    wsn_exchange_t* exchange = (wsn_exchange_t*) object->priv;
    object->priv = NULL;
    ASSERTS_NOT_NULL(exchange, amxd_status_ok, ME, "No internal ctx");

    free(exchange);

    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
 * @brief _RemoveExchange
 *
 * Terminate an exchange
 *
 * @return
 *     - function execution state
 */
amxd_status_t _RemoveExchange(amxd_object_t* obj,
                              amxd_function_t* func _UNUSED,
                              amxc_var_t* args,
                              amxc_var_t* retval _UNUSED) {
    SAH_TRACEZ_IN(ME);

    amxd_status_t status = swl_object_delInstWithTransOnLocalDm(obj);
    if(status == amxd_status_ok) {
        SAH_TRACEZ_INFO(ME, "Exchange instance deleted successfully");
    }

    SAH_TRACEZ_OUT(ME);
    return status;
}

/**
 * @brief wsn_exchangeTerminated_event_cb
 *
 * Callback function for ExchangeTerminated! event
 *
 * @param sig_name the name of the signal
 * @param data the data of the signal
 * @param priv a pointer to some data, provided when connecting
 */
void wsn_exchangeTerminated_event_cb(const char* const sig_name _UNUSED,
                                     const amxc_var_t* const data,
                                     void* const priv _UNUSED) {

    //Need to extract ExchangeID and call RemoveExchange for the specified ExchangeID
    SAH_TRACEZ_IN(ME);

    unsigned int exchangeid = 0;
    amxd_status_t ret;

    exchangeid = GET_UINT32(data, "ExchangeID");
    SAH_TRACEZ_INFO(ME, "ExchangeID from event data : %u", exchangeid);

    if(exchangeid == 0) {
        SAH_TRACEZ_INFO(ME, "Exiting since AddExchange doesnt return SUCCESS Error code");
        return;
    }

    amxd_object_t* templateObj = (amxd_object_t*) priv;
    amxd_function_t* function = NULL;
    amxc_var_t* arguments = NULL;
    amxc_var_t* returnval = NULL;
    if(templateObj != NULL) {
        SAH_TRACEZ_INFO(ME, "Exchange object found");
        amxd_object_for_each(instance, it, templateObj) {
            amxd_object_t* exchangeObj = amxc_container_of(it, amxd_object_t, it);
            uint32_t index = amxd_object_get_index(exchangeObj);
            if(index == exchangeid) {
                SAH_TRACEZ_INFO(ME, "Found exchange instance");
                ret = _RemoveExchange(exchangeObj, function, arguments, returnval);
                if(ret == amxd_status_ok) {
                    SAH_TRACEZ_INFO(ME, "RemoveExchange call was successful");
                } else {
                    SAH_TRACEZ_ERROR(ME, "RemoveExchange call failed");
                }
                return;
            }
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "Exchange object not found");
    }

    SAH_TRACEZ_OUT(ME);
    return;
}

