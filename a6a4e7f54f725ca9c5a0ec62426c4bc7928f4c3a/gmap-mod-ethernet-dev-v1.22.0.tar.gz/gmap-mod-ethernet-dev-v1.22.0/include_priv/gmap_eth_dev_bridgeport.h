/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__GMAP_ETH_DEV_BRIDGEPORT_H__)
#define __GMAP_ETH_DEV_BRIDGEPORT_H__

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file Reads from netdev datamodel and monitors which Link instance belongs
 * to which master.
 */


#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb.h>
#include <stdint.h>
#include <stdbool.h>

typedef struct gmap_eth_dev_bridgeport gmap_eth_dev_bridgeport_t;

void PRIVATE gmap_eth_dev_bridgeport_new(gmap_eth_dev_bridgeport_t** port, amxb_bus_ctx_t* ctx);
void PRIVATE gmap_eth_dev_bridgeport_delete(gmap_eth_dev_bridgeport_t** port);

/**
 * Called when a port<->master match changes.
 * @param port gmap_eth_dev_bridge_port_t instance that invoked the callback.
 * @param path Full path of the bridge port instance.
 * @param master Master index for which the callback was subscribed.
 * @param matching @code true if the link at the given path is assigned to the subscription interface,
 *                 @code false if the link is no longer assigned to the subscription interface.
 * @param priv private data pointer set on the subscription.
 */
typedef void (* gmap_eth_dev_bridgeport_cb_t) (gmap_eth_dev_bridgeport_t* port,
                                               const char* path,
                                               uint32_t master,
                                               bool matching,
                                               void* const priv);
/**
 * Subscribes the given callback for matching ports.
 * The callback will be called for any ports already matching before this function returns.
 */
bool PRIVATE gmap_eth_dev_bridgeport_subscribe(gmap_eth_dev_bridgeport_t* port,
                                               uint32_t master,
                                               gmap_eth_dev_bridgeport_cb_t cb,
                                               void* priv);
/**
 * Unsubscribes the given callback for the given master.
 * The callback will NOT be called for any ports still matching.
 */
void PRIVATE gmap_eth_dev_bridgeport_unsubscribe(gmap_eth_dev_bridgeport_t* port,
                                                 uint32_t master,
                                                 gmap_eth_dev_bridgeport_cb_t cb,
                                                 void* priv);

gmap_eth_dev_bridgeport_t* PRIVATE gmap_eth_dev_get_bridgeport(void);

#ifdef __cplusplus
}
#endif

#endif