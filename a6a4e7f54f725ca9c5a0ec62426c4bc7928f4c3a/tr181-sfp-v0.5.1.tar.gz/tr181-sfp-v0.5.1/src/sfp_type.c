/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "sfp_type.h"

/* System headers */
#include <string.h> /* strcmp() */

static const char* const SFP_TYPE_UNSUPPORTED = "Unsupported";
static const char* const SFP_TYPE_GPON = "G-PON";
static const char* const SFP_TYPE_XGPON = "XG-PON";
static const char* const SFP_TYPE_NGPON2 = "NG_PON2";
static const char* const SFP_TYPE_XGSPON = "XGS-PON";
static const char* const SFP_TYPE_EPON = "EPON";
static const char* const SFP_TYPE_MOCA = "MoCA";
static const char* const SFP_TYPE_OPTICAL_ETHERNET = "Optical Ethernet";
static const char* const SFP_TYPE_ELECTRICAL_ETHERNET = "Electrical Ethernet";

const char* sfp_type_to_cstring(sfp_types_e sfp_type) {
    switch(sfp_type) {
    case SFP_GPON: return SFP_TYPE_GPON;
    case SFP_XGPON: return SFP_TYPE_XGPON;
    case SFP_NGPON2: return SFP_TYPE_NGPON2;
    case SFP_XGSPON: return SFP_TYPE_XGSPON;
    case SFP_EPON: return SFP_TYPE_EPON;
    case SFP_MOCA: return SFP_TYPE_MOCA;
    case SFP_OPTICAL_ETHERNET: return SFP_TYPE_OPTICAL_ETHERNET;
    case SFP_ELECTRICAL_ETHERNET: return SFP_TYPE_ELECTRICAL_ETHERNET;
    case SFP_UNSUPPORTED:
    default:
        break;
    }
    return SFP_TYPE_UNSUPPORTED;
}

sfp_types_e sfp_type_str_to_enum(const char* sfp_type) {
    if(strcmp(SFP_TYPE_GPON, sfp_type) == 0) {
        return SFP_GPON;
    } else if(strcmp(SFP_TYPE_XGPON, sfp_type) == 0) {
        return SFP_XGPON;
    } else if(strcmp(SFP_TYPE_NGPON2, sfp_type) == 0) {
        return SFP_NGPON2;
    } else if(strcmp(SFP_TYPE_XGSPON, sfp_type) == 0) {
        return SFP_XGSPON;
    } else if(strcmp(SFP_TYPE_EPON, sfp_type) == 0) {
        return SFP_EPON;
    } else if(strcmp(SFP_TYPE_MOCA, sfp_type) == 0) {
        return SFP_MOCA;
    } else if(strcmp(SFP_TYPE_OPTICAL_ETHERNET, sfp_type) == 0) {
        return SFP_OPTICAL_ETHERNET;
    } else if(strcmp(SFP_TYPE_ELECTRICAL_ETHERNET, sfp_type) == 0) {
        return SFP_ELECTRICAL_ETHERNET;
    }
    return SFP_UNSUPPORTED;
}

