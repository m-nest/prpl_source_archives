/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxrt/amxrt.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_util.h>
#include <amxut/amxut_verify.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <limits.h>

#include "tr181-gatewayinfo.h"
#include "event_handler.h"

#include "event_handler_test.h"
#include "../common/functions.h"

#define ME "gatewayinfo"

int test_setup(void** state) {
    assert_int_equal(amxut_bus_setup(state), 0);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

netmodel_query_t* __wrap_netmodel_openQuery(const char* intf,
                                            const char* subscriber,
                                            const char* function,
                                            const amxc_var_t* args,
                                            netmodel_callback_t handler,
                                            void* userdata) {

    check_expected_ptr(intf);
    check_expected_ptr(subscriber);
    check_expected_ptr(function);
    check_expected_ptr(args);
    check_expected(handler);
    check_expected(userdata);

    return mock_ptr_type(netmodel_query_t*);
}

void test_setup_subscriptions(UNUSED void** state) {
    expect_string(__wrap_netmodel_openQuery, intf, "ip-wan");
    expect_string(__wrap_netmodel_openQuery, subscriber, "gatewayinfo");
    expect_string(__wrap_netmodel_openQuery, function, "getDHCPOption");
    expect_check(__wrap_netmodel_openQuery, args, check_amxc_json, "{ \"tag\": 125, \"traverse\": \"down\", \"type\": \"req\" }");
    expect_value(__wrap_netmodel_openQuery, handler, &option_125_changed);
    expect_value(__wrap_netmodel_openQuery, userdata, NULL);
    will_return(__wrap_netmodel_openQuery, "netmodel_query_t*");

    expect_string(__wrap_netmodel_openQuery, intf, "ip-wan");
    expect_string(__wrap_netmodel_openQuery, subscriber, "gatewayinfo");
    expect_string(__wrap_netmodel_openQuery, function, "getDHCPOption");
    expect_check(__wrap_netmodel_openQuery, args, check_amxc_json, "{ \"tag\": 17, \"traverse\": \"down\", \"type\": \"req6\" }");
    expect_value(__wrap_netmodel_openQuery, handler, &option_17_changed);
    expect_value(__wrap_netmodel_openQuery, userdata, NULL);
    will_return(__wrap_netmodel_openQuery, "netmodel_query_t*");

    amxc_var_t* config = amxrt_get_config();
    amxc_var_set_type(config, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, config, "NetModelIntfName", "ip-wan");
    assert_int_equal(setup_subscriptions(), 0);
    amxc_var_clean(config);
}

int __wrap_dm_update_gatewayinfo(const struct DHCPGatewayInformation* gatewayinfo) {
    check_expected_ptr(gatewayinfo);

    return mock_type(int);
}

static int dhcp_gatewayinformation_is_the_same(const uintmax_t value, const uintmax_t check_value_data) {
    struct DHCPGatewayInformation* got_value = (struct DHCPGatewayInformation*) (uintptr_t) (value);
    assert_non_null(got_value);

    struct DHCPGatewayInformation* expected_value = (struct DHCPGatewayInformation*) (uintptr_t) (check_value_data);
    assert_non_null(expected_value);

    return DHCPGatewayInformation_equal(got_value, expected_value);
}

static void add_cstring_t_dhcp_option(amxc_var_t* option, uint32_t option_code, const char* option_data) {
    amxc_var_t* suboption = amxc_var_add(amxc_htable_t, option, NULL);
    amxc_var_add_key(uint32_t, suboption, "Code", option_code);
    amxc_var_add_key(cstring_t, suboption, "Data", option_data);
}

static amxc_var_t* get_netmodel_dhcp_option_changed_event(const char* DeviceManufacturerOUI,
                                                          const char* DeviceProductClass,
                                                          const char* DeviceSerialNumber,
                                                          enum DHCPType dhcp_type) {
    amxc_var_t* data;
    amxc_var_new(&data);
    amxc_var_set_type(data, AMXC_VAR_ID_LIST);

    amxc_var_t* event = amxc_var_add_new_amxc_htable_t(data, NULL);
    amxc_var_t* option = amxc_var_add_key(amxc_llist_t, event, "Data", NULL);

    if(DeviceManufacturerOUI) {
        add_cstring_t_dhcp_option(option, (dhcp_type == DHCPv4) ? DHCPv4_SUBOPT_MANUFACTURER_OUI : DHCPv6_SUBOPT_MANUFACTURER_OUI, DeviceManufacturerOUI);
    }
    if(DeviceProductClass) {
        add_cstring_t_dhcp_option(option, (dhcp_type == DHCPv4) ? DHCPv4_SUBOPT_PRODUCT_CLASS : DHCPv6_SUBOPT_PRODUCT_CLASS, DeviceProductClass);
    }
    if(DeviceSerialNumber) {
        add_cstring_t_dhcp_option(option, (dhcp_type == DHCPv4) ? DHCPv4_SUBOPT_SERIAL_NUMBER : DHCPv6_SUBOPT_SERIAL_NUMBER, DeviceSerialNumber);
    }
    return data;
}


void test_option_125_changed(UNUSED void** state) {
    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
        amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
        amxc_string_set(&gateway_info.DeviceSerialNumber, "DeviceSerialNumber");

        expect_check(__wrap_dm_update_gatewayinfo, gatewayinfo, dhcp_gatewayinformation_is_the_same, &gateway_info);
        will_return(__wrap_dm_update_gatewayinfo, 0);

        amxc_var_t* data = get_netmodel_dhcp_option_changed_event("DeviceManufacturerOUI", "DeviceProductClass", "DeviceSerialNumber", DHCPv4);

        option_125_changed(NULL, data, NULL);

        amxc_var_delete(&data);
        DHCPGatewayInformation_deinit(&gateway_info);
    }

    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        expect_check(__wrap_dm_update_gatewayinfo, gatewayinfo, dhcp_gatewayinformation_is_the_same, &gateway_info);
        will_return(__wrap_dm_update_gatewayinfo, 0);

        amxc_var_t* data = get_netmodel_dhcp_option_changed_event(NULL, NULL, NULL, DHCPv4);

        option_125_changed(NULL, data, NULL);

        amxc_var_delete(&data);
        DHCPGatewayInformation_deinit(&gateway_info);
    }
}

void test_option_17_changed(UNUSED void** state) {
    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        amxc_string_set(&gateway_info.DeviceManufacturerOUI, "DeviceManufacturerOUI");
        amxc_string_set(&gateway_info.DeviceProductClass, "DeviceProductClass");
        amxc_string_set(&gateway_info.DeviceSerialNumber, "DeviceSerialNumber");

        expect_check(__wrap_dm_update_gatewayinfo, gatewayinfo, dhcp_gatewayinformation_is_the_same, &gateway_info);
        will_return(__wrap_dm_update_gatewayinfo, 0);

        amxc_var_t* data = get_netmodel_dhcp_option_changed_event("DeviceManufacturerOUI", "DeviceProductClass", "DeviceSerialNumber", DHCPv6);

        option_17_changed(NULL, data, NULL);

        amxc_var_delete(&data);
        DHCPGatewayInformation_deinit(&gateway_info);
    }

    {
        struct DHCPGatewayInformation gateway_info;
        DHCPGatewayInformation_init(&gateway_info);

        expect_check(__wrap_dm_update_gatewayinfo, gatewayinfo, dhcp_gatewayinformation_is_the_same, &gateway_info);
        will_return(__wrap_dm_update_gatewayinfo, 0);

        amxc_var_t* data = get_netmodel_dhcp_option_changed_event(NULL, NULL, NULL, DHCPv6);

        option_17_changed(NULL, data, NULL);

        amxc_var_delete(&data);
        DHCPGatewayInformation_deinit(&gateway_info);
    }
}