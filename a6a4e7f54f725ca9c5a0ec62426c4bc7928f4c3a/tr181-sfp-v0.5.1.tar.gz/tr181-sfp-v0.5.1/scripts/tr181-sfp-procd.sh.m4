#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-sfp"
PROG="/usr/bin/tr181-sfp"
datamodel_root="SFPs"
PROG_OPTIONS=""

#Guideline- this function has the instructions to execute
#before starting this service
#End

preservice_hook() {
    logger -s "pre-service hook ${name}"
    /bin/sh /lib/sfp/populate_cage.sh
}

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End
#
#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook()
}

debuginfo() {
    if [ -n "$datamodel_root" ]; then
        process_debug_info ${datamodel_root}
        process_debug_info "Optical"
    else
        logger -s "Error: debuginfo() failed ... DataModel root invalid."
    fi
}
