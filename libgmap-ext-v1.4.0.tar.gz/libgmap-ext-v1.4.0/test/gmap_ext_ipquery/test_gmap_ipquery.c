/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "test_gmap_ipquery.h"
#include "gmap/extensions/ip/gmap_ext_ipquery.h"

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>
#include <malloc.h>
#include <string.h>

#include <arpa/inet.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxb/amxb.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>

#include <gmap/gmap.h>

#include "../common/test-setup.h"

#ifndef ARRAY_CONST_SIZE
#define ARRAY_CONST_SIZE(X) (sizeof(X) / sizeof((X)[0]))
#endif

static amxd_dm_t* dm;
static amxb_bus_ctx_t* bus_ctx = NULL;

int test_gmap_ipquery_setup(UNUSED void** state) {
    test_setup(state); // Note: also reads ../common/mock_gmap.odl

    bus_ctx = amxb_be_who_has("Devices");
    dm = amxut_bus_dm();
    gmap_client_init(bus_ctx);
    return 0;
}

int test_gmap_ipquery_teardown(UNUSED void** state) {
    test_teardown(state);
    dm = NULL;
    bus_ctx = NULL;

    return 0;
}

typedef struct {
    char* dev_key;
    char* ip;
    bool exists;
    amxc_llist_it_t it;
} seen_item_t;

typedef struct {
    const char* dev_key;
    const char* ip;
    bool exists;
} expected_item_t;

/** @implements gmap_ipquery_cb_t  */
static void s_ipquery_cb(const char* dev_key,
                         const char* ip,
                         bool ip_exists,
                         void* const userdata) {
    amxc_llist_t* seen_list = userdata;
    seen_item_t* seen_item;
    assert_non_null(seen_list);
    assert_non_null(dev_key);
    assert_non_null(ip);

    seen_item = calloc(1, sizeof(seen_item_t));
    assert_non_null(seen_item);
    amxc_llist_it_init(&seen_item->it);

    seen_item->dev_key = strdup(dev_key);
    seen_item->ip = strdup(ip);
    seen_item->exists = ip_exists;
    assert_non_null(seen_item->dev_key);
    assert_non_null(seen_item->ip);

    amxc_llist_append(seen_list, &seen_item->it);
}

static void print_seen_list(amxc_llist_t* seen_list) {
    print_message("observed = ((expected_item_t[]){\n");
    amxc_llist_for_each(it, seen_list) {
        seen_item_t* seen = amxc_llist_it_get_data(it, seen_item_t, it);
        print_message("    {.dev_key=\"%s\", .ip=\"%s\", .exists=%s},\n",
                      seen->dev_key, seen->ip, seen->exists ? "true" : "false");
    }
    print_message("    { 0 }\n}\n");
}

static void _assert_seen_list(amxc_llist_t* seen_list,
                              const expected_item_t* expected,
                              const char* file,
                              int line) {
    size_t index = 0;

    _assert_true(seen_list != NULL, "seen_list == NULL", file, line);
    _assert_true(expected != NULL, "expected == NULL", file, line);

    amxc_llist_for_each(it, seen_list) {
        seen_item_t* seen = amxc_llist_it_get_data(it, seen_item_t, it);

        if((expected->dev_key == NULL) || (expected->ip == NULL)) {
            print_seen_list(seen_list);
            print_error("Unexpected item seen at index %zu:\n"
                        "  observed: {.dev_key=\"%s\", .ip=\"%s\", .exists=%d}\n"
                        "  expected: End of List\n",
                        index, seen->dev_key, seen->ip, seen->exists);
            _fail(file, line);
            return;
        }
        if((strcmp(seen->dev_key, expected->dev_key) != 0) ||
           (strcmp(seen->ip, expected->ip) != 0) ||
           (seen->exists != expected->exists)) {
            print_seen_list(seen_list);
            print_error("Item mismatch seen at index %zu:\n"
                        "  observed: {.dev_key=\"%s\", .ip=\"%s\", .exists=%d}\n"
                        "  expected: {.dev_key=\"%s\", .ip=\"%s\", .exists=%d}\n",
                        index,
                        seen->dev_key, seen->ip, seen->exists,
                        expected->dev_key, expected->ip, expected->exists);
            _fail(file, line);
            return;
        }

        ++index;
        ++expected;
    }

    if((expected->dev_key != NULL) || (expected->ip != NULL)) {
        print_error("Expected more items starting at index %zu:\n"
                    "  observed: End of List\n"
                    "  expected: {.dev_key=\"%s\", .ip=\"%s\", .exists=%d}\n",
                    index, expected->dev_key, expected->ip, expected->exists);
        _fail(file, line);
        return;
    }
}

#define assert_seen_list(actual, expected) _assert_seen_list(actual, expected, __FILE__, __LINE__)


/** @implements amxc_llist_it_delete_t */
static void s_delete_seen_item(amxc_llist_it_t* it) {
    assert_non_null(it);
    seen_item_t* item = amxc_llist_it_get_data(it, seen_item_t, it);
    assert_non_null(it);
    free(item->dev_key);
    free(item->ip);
    free(item);
}

static void s_clear_seen_list(amxc_llist_t* seen) {
    amxc_llist_clean(seen, s_delete_seen_item);
}

void test_gmap_ipquery__new_ip(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);

    // GIVEN an ipquery
    ok = gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_cb, &seen_list);
    assert_true(ok);
    assert_non_null(ipquery);

    // WHEN a new IP exists that matches the query criteria
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_dev1ip1_ipv4.odl");
    amxut_bus_handle_events();

    // THEN the callback is called for that IP
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

void test_gmap_ipquery__delete_ip(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    amxd_trans_t trans;
    amxc_llist_init(&seen_list);

    // GIVEN IPs and an ipquery
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_dev1ip1_ipv4.odl");
    amxut_bus_handle_events();

    gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_cb, &seen_list);
    assert_int_equal(1, amxc_llist_size(&seen_list));

    // WHEN an IP is deleted
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Device.dev1.IPv4Address.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_status_ok, amxd_trans_apply(&trans, dm));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    // THEN the callback is called for that IP
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = false },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

void test_gmap_ipquery__change_ip(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    amxd_trans_t trans;
    amxc_llist_init(&seen_list);

    // GIVEN IPs and an ipquery
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_dev1ip1_ipv4.odl");
    amxut_bus_handle_events();

    gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_cb, &seen_list);
    assert_int_equal(1, amxc_llist_size(&seen_list));

    // WHEN an IP changes to another IP
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Device.dev1.IPv4Address.1.");
    amxd_trans_set_cstring_t(&trans, "Address", "192.168.5.5");
    assert_int_equal(amxd_status_ok, amxd_trans_apply(&trans, dm));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    // THEN the callback was called for the initial list (not relevant here),
    //      the removal of the old IP
    //      and addition of the new IP (in that order)
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = false },
        { .dev_key = "dev1", .ip = "192.168.5.5", .exists = true },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

void test_gmap_ipquery__filtering(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);

    // Filtering addresses based on the device tag is currently no longer supported.
    // Therefore, all addresses will be reported in this test.

    // GIVEN an ipquery
    ok = gmap_ipquery_new(&ipquery, AF_INET6, NULL, s_ipquery_cb, &seen_list);
    assert_true(ok);
    assert_non_null(ipquery);

    // WHEN a lot of IP addresses are added in gmap but only one matches the "tag2" tag and ipv6 family:
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_all_ips.odl");
    amxut_bus_handle_events();

    // THEN the callback is called for the matching IP,
    //      so not for 192.168.1.22 (ip family mismatch)
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "fe80::a2b5:49ff:fe0a:1001", .exists = true },
        { .dev_key = "dev2", .ip = "fe80::a2b5:49ff:fe0a:2001", .exists = true },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);

    amxut_bus_handle_events();
}

void test_gmap_ipquery__initialpopulation(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);

    // GIVEN a bunch of IP addresses
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_all_ips.odl");
    amxut_bus_handle_events();

    // WHEN creating an ipquery
    ok = gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_cb, &seen_list);
    assert_true(ok);
    assert_non_null(ipquery);
    amxut_bus_handle_events();

    // THEN the callback is called for the initially already-existing IP adresses
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        { .dev_key = "dev2", .ip = "192.168.1.22", .exists = true },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

void test_gmap_ipquery__delete_device(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    amxd_trans_t trans;
    amxc_llist_init(&seen_list);

    // GIVEN IPs and an ipquery
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_dev1ip1_ipv4.odl");
    amxut_bus_handle_events();

    gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_cb, &seen_list);
    assert_int_equal(1, amxc_llist_size(&seen_list));

    // WHEN an IP is deleted
    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Device.");
    amxd_trans_del_inst(&trans, 0, "dev1");
    assert_int_equal(amxd_status_ok, amxd_trans_apply(&trans, dm));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    // THEN the callback is called for that IP
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = false },
        { 0 }
    }));

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

void test_gmap_ipquery__bad_inputs(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    amxc_llist_init(&seen_list);

    assert_false(gmap_ipquery_new(NULL, AF_INET, NULL, s_ipquery_cb, &seen_list));
    assert_false(gmap_ipquery_new(&ipquery, 0x7e57, NULL, s_ipquery_cb, &seen_list));
    assert_false(gmap_ipquery_new(&ipquery, AF_INET, NULL, NULL, &seen_list));
    assert_null(ipquery);
    gmap_ipquery_delete(NULL);
    gmap_ipquery_delete(&ipquery);

    s_clear_seen_list(&seen_list);
    gmap_ipquery_delete(&ipquery);
}

typedef struct {
    const char* ip_addr;
    amxc_llist_t* seen_list;
    gmap_ipquery_t** backref;
} closing_cb_data_t;

static void s_ipquery_closing_cb(const char* dev_key,
                                 const char* ip,
                                 bool ip_exists,
                                 void* const userdata) {
    closing_cb_data_t* data = userdata;
    assert_non_null(dev_key);
    assert_string_not_equal(dev_key, "");
    assert_non_null(ip);
    assert_string_not_equal(ip, "");
    assert_non_null(userdata);

    s_ipquery_cb(dev_key, ip, ip_exists, data->seen_list);
    if((data->ip_addr != NULL) && (strcmp(data->ip_addr, ip) == 0)) {
        gmap_ipquery_delete(data->backref);
        s_ipquery_cb("ipquery", "closed", false, data->seen_list);
        *data->backref = NULL;
    }
}

void test_gmap_ipquery__close_from_callback(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);
    closing_cb_data_t userdata = {
        .ip_addr = "192.168.1.11",
        .seen_list = &seen_list,
        .backref = &ipquery,
    };

    // GIVEN an ipquery
    ok = gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_closing_cb, &userdata);
    assert_true(ok);
    assert_non_null(ipquery);

    // WHEN a new IP exists that matches the query criteria
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_all_ips.odl");
    amxut_bus_handle_events();

    // THEN the callback is called for that IP only
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        // AND the query was closed after the matching IP
        { .dev_key = "ipquery", .ip = "closed", .exists = false },
        { 0 }
    }));
    assert_null(ipquery);

    s_clear_seen_list(&seen_list);
}

void test_gmap_ipquery__close_from_callback_remaining_addresses(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);
    closing_cb_data_t userdata = {
        .ip_addr = "192.168.2.1",
        .seen_list = &seen_list,
        .backref = &ipquery,
    };

    // GIVEN an ipquery
    ok = gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_closing_cb, &userdata);
    assert_true(ok);
    assert_non_null(ipquery);

    // WHEN a new IP exists that matches the query criteria and that device has
    //      more addresses.
    amxut_dm_load_odl("mockdata_gmap_dev5.odl");
    amxut_bus_handle_events();

    // THEN the callback is called for that IP only
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev5", .ip = "192.168.2.1", .exists = true },
        // AND the query was closed after the matching IP
        { .dev_key = "ipquery", .ip = "closed", .exists = false },
        { 0 }
    }));
    assert_null(ipquery);

    s_clear_seen_list(&seen_list);
}

void test_gmap_ipquery__close_from_callback_on_init(UNUSED void** state) {
    amxc_llist_t seen_list;
    gmap_ipquery_t* ipquery = NULL;
    bool ok = false;
    amxc_llist_init(&seen_list);
    closing_cb_data_t userdata = {
        .ip_addr = "192.168.1.11",
        .seen_list = &seen_list,
        .backref = &ipquery,
    };

    // GIVEN a datamodel with existing ip addresses
    amxut_dm_load_odl("mockdata_gmap_devs.odl");
    amxut_dm_load_odl("mockdata_gmap_all_ips.odl");
    amxut_bus_handle_events();

    // WHEN an ipquery is created, that closes itself when matching one of these addresses
    ok = gmap_ipquery_new(&ipquery, AF_INET, NULL, s_ipquery_closing_cb, &userdata);

    // THEN creation is successful, but the ip query object remains NULL
    assert_true(ok);
    assert_null(ipquery);

    // THEN the callback is called for that IP only
    assert_seen_list(&seen_list, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.11", .exists = true },
        // AND the query was closed after the matching IP
        { .dev_key = "ipquery", .ip = "closed", .exists = false },
        { 0 }
    }));
    assert_null(ipquery);

    s_clear_seen_list(&seen_list);
}

void test_gmap_ipquery__scenario(UNUSED void** state) {
    // This test will play a small scenario of connecting/disconnecting devices,
    // with multiple queries becoming active throughout the scenario.
    // The intention of this more complex test is to verify that the individual
    // parts still work together.
    // Additionally, this test can serve as a blueprint to test specific edge
    // cases when bugs are discovered.

    amxc_llist_t seen_lists[3];
    gmap_ipquery_t* ipqueries[ARRAY_CONST_SIZE(seen_lists)];
    amxd_trans_t trans;

    // Some utility macros to keep things tidy and readable
#define SCENARIO_CLEAR_SEEN_LISTS do {                              \
        for(size_t i = 0; i < ARRAY_CONST_SIZE(seen_lists); ++i) {  \
            s_clear_seen_list(seen_lists + i);                      \
        }                                                           \
} while(0)

    for(size_t i = 0; i < ARRAY_CONST_SIZE(seen_lists); ++i) {
        amxc_llist_init(seen_lists + i);
        ipqueries[i] = NULL;
    }

    // STEP 0
    // - initial state with no ip queries active.
    amxut_dm_load_odl("mockdata_gmap_scenario_0.odl");
    amxut_bus_handle_events();

    // - Two ip queries come online, one for ipv4 and one for ipv6
    assert_true(gmap_ipquery_new(ipqueries + 0, AF_INET, NULL, s_ipquery_cb, seen_lists + 0));
    assert_true(gmap_ipquery_new(ipqueries + 1, AF_INET6, NULL, s_ipquery_cb, seen_lists + 1));

    // - Each receives callbacks for its ip addresses
    assert_seen_list(seen_lists + 0, ((expected_item_t[]) {
        { .dev_key = "dev1", .ip = "192.168.1.2", .exists = true },
        { .dev_key = "dev3", .ip = "192.168.1.255", .exists = true },
        { 0 }
    }));
    assert_seen_list(seen_lists + 1, ((expected_item_t[]) {
        { .dev_key = "dev2", .ip = "fe80::a2b5:49ff:fe0a:1004", .exists = true },
        { .dev_key = "dev3", .ip = "fe80::a2b5:49ff:fe0a:1001", .exists = true },
        { 0 }
    }));
    assert_seen_list(seen_lists + 2, ((expected_item_t[]) {
        { 0 }
    }));

    // - always clean up the lists after each step.
    SCENARIO_CLEAR_SEEN_LISTS;


    // STEP 1
    // - Some addresses change values.
    amxut_dm_load_odl("mockdata_gmap_scenario_1.odl");
    amxut_bus_handle_events();

    // - Each receives callbacks for its ip addresses
    //   Note: object modifications are parsed left-recursively.
    //         Therefore, they are applied in reverse order.
    assert_seen_list(seen_lists + 0, ((expected_item_t[]) {
        {.dev_key = "dev3", .ip = "192.168.1.255", .exists = false},
        {.dev_key = "dev3", .ip = "192.168.1.13", .exists = true},
        {.dev_key = "dev1", .ip = "192.168.1.2", .exists = false},
        {.dev_key = "dev1", .ip = "192.168.1.3", .exists = true},
        { 0 }
    }));
    assert_seen_list(seen_lists + 1, ((expected_item_t[]) {
        {.dev_key = "dev2", .ip = "fe80::a2b5:49ff:fe0a:1004", .exists = false},
        { 0 }
    }));
    assert_seen_list(seen_lists + 2, ((expected_item_t[]) {
        { 0 }
    }));

    // - always clean up the lists after each step.
    SCENARIO_CLEAR_SEEN_LISTS;


    // STEP 2 a third ip query is created
    assert_true(gmap_ipquery_new(ipqueries + 2, AF_INET, NULL, s_ipquery_cb, seen_lists + 2));

    // - Only the new ip query received events to make it up to date with the
    //   current situation.
    //   Note: order of events here is in order that objects were created in the
    //         datamodel, so _not_ reversed.
    assert_seen_list(seen_lists + 0, ((expected_item_t[]) {
        { 0 }
    }));
    assert_seen_list(seen_lists + 1, ((expected_item_t[]) {
        { 0 }
    }));
    assert_seen_list(seen_lists + 2, ((expected_item_t[]) {
        {.dev_key = "dev1", .ip = "192.168.1.3", .exists = true},
        {.dev_key = "dev3", .ip = "192.168.1.13", .exists = true},
        { 0 }
    }));

    // - always clean up the lists after each step.
    SCENARIO_CLEAR_SEEN_LISTS;


    // STEP 3
    // - Some addresses change values and addresses and a device is added.
    amxut_dm_load_odl("mockdata_gmap_scenario_3.odl");
    amxut_bus_handle_events();

    // - Each receives callbacks for its ip addresses
    //   Note: object modifications are parsed left-recursively.
    //         Therefore, they are applied in reverse order.
    //         instance addition follows other ordring rules and are sometimes
    //         applied first.
    assert_seen_list(seen_lists + 0, ((expected_item_t[]) {
        {.dev_key = "dev5", .ip = "192.168.2.1", .exists = true},
        {.dev_key = "dev3", .ip = "192.168.1.100", .exists = true},
        {.dev_key = "dev1", .ip = "192.168.1.3", .exists = false},
        {.dev_key = "dev1", .ip = "192.168.1.12", .exists = true},
        { 0 }
    }));
    assert_seen_list(seen_lists + 1, ((expected_item_t[]) {
        {.dev_key = "dev5", .ip = "fe80::a2b5:49ff:fe0b:fe23", .exists = true},
        { 0 }
    }));
    assert_seen_list(seen_lists + 2, ((expected_item_t[]) {
        {.dev_key = "dev5", .ip = "192.168.2.1", .exists = true},
        {.dev_key = "dev3", .ip = "192.168.1.100", .exists = true},
        {.dev_key = "dev1", .ip = "192.168.1.3", .exists = false},
        {.dev_key = "dev1", .ip = "192.168.1.12", .exists = true},
        { 0 }
    }));

    // - always clean up the lists after each step.
    SCENARIO_CLEAR_SEEN_LISTS;


    // STEP 4
    // - Delete a gmap ip query, then delete a device and an ip address
    gmap_ipquery_delete(ipqueries + 0);
    assert_null(ipqueries[0]);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "Devices.Device.");
    amxd_trans_del_inst(&trans, 0u, "dev1");
    amxd_trans_select_pathf(&trans, "Devices.Device.dev5.IPv4Address.");
    amxd_trans_del_inst(&trans, 1u, NULL);
    assert_success(amxd_trans_apply(&trans, dm));
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    // - Each receives callbacks for its ip addresses
    assert_seen_list(seen_lists + 0, ((expected_item_t[]) {
        { 0 }
    }));
    assert_seen_list(seen_lists + 1, ((expected_item_t[]) {
        { 0 }
    }));
    assert_seen_list(seen_lists + 2, ((expected_item_t[]) {
        {.dev_key = "dev1", .ip = "192.168.1.12", .exists = false},
        {.dev_key = "dev5", .ip = "192.168.2.1", .exists = false},
        { 0 }
    }));

    // - always clean up the lists after each step.
    SCENARIO_CLEAR_SEEN_LISTS;


    // STEP -1 final cleanup
    for(size_t i = 0; i < ARRAY_CONST_SIZE(seen_lists); ++i) {
        gmap_ipquery_delete(ipqueries + i);
        s_clear_seen_list(seen_lists + i);
    }

# undef SCENARIO_CLEAR_SEEN_LISTS
}
