#!/bin/sh

# Check if ethtool command is available
if ! command -v ethtool -m >/dev/null 2>&1; then
    echo "ethtool is not installed"
    exit 1
fi

# Check if the user provided an argument (interface name)
if [ -z "$1" ]; then
  echo "Error: No interface name provided."
  echo "Usage: $0 <interface-name>"
  exit 2
fi

# Get the interface name from the first argument
ifname=$1

# Execute ethtool command and capture the output
output=$(ethtool -m "$ifname" hex on)

# Extract the value at offset 0x0000 for buffer[0]
buffer_0=$(echo "$output" | grep "0x0000:" | awk '{print $2}')
buffer_0=${buffer_0:-0}

# Extract the value at offset 0x0003 for buffer[3]
buffer_3=$(echo "$output" | grep "0x0000:" | awk '{print $5}')
buffer_3=${buffer_3:-0}

# Extract the value at offset 0x0006 for buffer[6]
buffer_6=$(echo "$output" | grep "0x0000:" | awk '{print $8}')
buffer_6=${buffer_6:-0}

# Extract the value at offset 0x000C for buffer[12]
buffer_12=$(echo "$output" | grep "0x0000:" | awk '{print $14}')
buffer_12=${buffer_12:-0}

# Print the extracted values
echo "$buffer_0" "$buffer_3" "$buffer_6" "$buffer_12"
