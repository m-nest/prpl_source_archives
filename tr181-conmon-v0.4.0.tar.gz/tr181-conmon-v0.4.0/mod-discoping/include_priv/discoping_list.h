/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__DISCOPING_LIST_H__)
#define __DISCOPING_LIST_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>

#include "mod_discoping.h"

/**
   @file
   @brief
   Discoping header for handeling the active discoping item list
 */

/**
   @ingroup mod_discoping
   @defgroup discoping_list Discoping module list utility

   Functions to manipulate the active discoping list of items
 */

/**
   @ingroup discoping_list
   @brief
   Function to return the current size of the active discoping list

   @return
   The sise_t of the list
 */
size_t discoping_list_size(void);

/**
   @ingroup discoping_list
   @brief
   Function to initialize the memory of the active discoping list
 */
void discoping_list_init(void);

/**
   @ingroup discoping_list
   @brief
   Function to delete and free the memory of an active discoping list item

   @param alias The alias of the active discoping item

   @return
   0 on successfull delition
 */
int discoping_list_delete(const char* alias);

/**
   @ingroup discoping_list
   @brief
   Function to find an active discoping list item by its alias

   @param alias The alias of the active discoping item to find

   @return
   An active_discoping_t pointer to the active discoping item with the corresponding alias
 */
active_discoping_t* discoping_list_find(const char* alias);

/**
   @ingroup discoping_list
   @brief
   Function to add an active discoping list item

   @param args The variant containing :
   - ip_version : The ip version of the ConMon.Entry.i object
   - alias : The Alias of the ConMon.Entry.i object
   @param main_cb The callback of the main timer
   @param response_cb The callback to call in case of no response on the chosen protocol
   @param deadline_cb The callback to call in case the retry timer is exhausted

   @return
   The active discoping entry added
 */
active_discoping_t* discoping_list_add(amxc_var_t* args, amxp_timer_cb_t main_cb, amxp_timer_cb_t response_cb, amxp_timer_cb_t deadline_cb);

/**
   @ingroup discoping_list
   @brief
   Function to delete and free the memory of the active discoping list
 */
void discoping_list_delete_all(void);

#ifdef __cplusplus
}
#endif

#endif // __DISCOPING_LIST_H__
