/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxrt/amxrt.h>
#include <amxd/amxd_dm.h>
#include <amxo/amxo.h>

#include <amxm/amxm.h>

#include "mod_discoping.h"
#include "discoping_utils.h"
#include "discoping_calls.h"
#include "discoping_list.h"
#include "discoping_dm.h"

static void check_response_timer(amxp_timer_t* timer, void* priv);
static void do_routine(amxp_timer_t* timer, void* priv);
static void deadline_reached(amxp_timer_t* timer, void* priv);

amxo_parser_t* get_parser(void) {
    return amxrt_get_parser();
}

static void deadline_reached(UNUSED amxp_timer_t* timer, void* priv) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = (active_discoping_t*) priv;
    when_null(entry, exit);

    if(entry->ip_version == 4) {
        arp_socket_delete(&entry->arp_socket);
    } else if(entry->ip_version == 6) {
        ndp_socket_delete(&entry->ndp_socket);
    } else {
        goto exit;
    }

    SAH_TRACEZ_WARNING(ME, "[%s] Deadline reached for %s response", entry->alias, entry->ip_version == 4 ? "ARP" : "ND");
    entry->response_received = false;

exit:
    SAH_TRACEZ_OUT(ME);
}

static void verify_state(active_discoping_t* entry) {
    SAH_TRACEZ_IN(ME);

    int timeout = 0;

    when_null(entry, exit);

    switch(entry->state) {
    case MAINLOOP:
        if(entry->response_received == false) {
            //increase fail count and change_state to retry
            entry->retry_current++;
            entry->arpns_total_fail++;
            change_state(entry, RETRY);
            update_dm(entry);
        } else {
            // entry found, so stay in mainloop timing
            entry->retry_current = 0;
            timeout = entry->main_interval - entry->fail_interval;
        }
        break;
    case RETRY:
        if(entry->response_received == false) {
            //increase fail count
            entry->retry_current++;
            entry->arpns_total_fail++;
            if(entry->retry_current >= entry->retries_max) {
                SAH_TRACEZ_ERROR(ME, "[%s] Reached max retries: %u", entry->alias, entry->retry_current);
                // reinit arp/nd
                change_state(entry, REINIT);
                timeout = 0;
            }
            update_dm(entry);
        } else {
            // entry found, so return to mainloop timing
            entry->retry_current = 0;
            timeout = entry->main_interval - entry->fail_interval;
            change_mainloop(entry, false);
        }
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "[%s] Impossible state reached: %s", entry->alias, state_as_string(entry->state));
        break;
    }

    if(timeout < 0) {
        timeout = 0;
    }

    entry->isdeferring = true;
    amxp_timer_start(entry->main_timer, timeout);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

static void check_response_timer(UNUSED amxp_timer_t* timer, void* priv) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = (active_discoping_t*) priv;
    verify_state(entry);

    SAH_TRACEZ_OUT(ME);
}

static void do_routine(UNUSED amxp_timer_t* timer, void* priv) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = (active_discoping_t*) priv;
    when_null(entry, exit);
    entry->isdeferring = false;
    SAH_TRACEZ_INFO(ME, "[%s] Processing state: %s", entry->alias, state_as_string(entry->state));

    when_true(entry->ip_version != 4 && entry->ip_version != 6, exit);
    switch(entry->state) {
    case DISABLED:
    case LINK_DOWN:
    case WAN_DOWN:
        if(entry->ip_version == 4) {
            arp_socket_delete(&entry->arp_socket);
        } else {  // entry->ip_version == 6
            ndp_socket_delete(&entry->ndp_socket);
        }
        amxp_timer_stop(entry->main_timer);
        amxp_timer_stop(entry->response_timer);
        amxp_timer_stop(entry->deadline_timer);
        break;
    case MAINLOOP:
    case RETRY:
        if(entry->ip_version == 4) {
            send_ipv4(entry);
        } else {  // entry->ip_version == 6
            send_ipv6_ns(entry);
        }
        break;
    case REINIT:
        entry->retry_current = 0;
        entry->total_dhcp_restarts++;
        toggle_dhcp(entry);
        update_dm(entry);
        change_state(entry, WAN_DOWN);
        break;
    default:
        SAH_TRACEZ_ERROR(ME, "[%s] Reached impossible state!", entry->alias);
        break;
    }

exit:
    SAH_TRACEZ_OUT(ME);
}


active_discoping_t* find_or_add_discoping_item(amxc_var_t* args) {
    SAH_TRACEZ_IN(ME);

    active_discoping_t* entry = NULL;
    const char* alias = NULL;

    when_null(args, exit);

    alias = GET_CHAR(args, "alias");
    entry = discoping_list_find(alias);
    if(entry == NULL) {
        entry = discoping_list_add(args, do_routine, check_response_timer, deadline_reached);
    }

exit:
    return entry;
    SAH_TRACEZ_OUT(ME);
}

int update_config(UNUSED const char* function_name,
                  amxc_var_t* args,
                  UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    int retval = -1;
    active_discoping_t* entry = find_or_add_discoping_item(args);

    when_null(entry, exit);
    update_entry(entry, args);

    retval = 0;
exit:

    SAH_TRACEZ_OUT(ME);
    return retval;
}

int stop(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    SAH_TRACEZ_IN(ME);

    int retval = -1;
    const char* alias = NULL;

    when_null(args, exit);

    alias = GET_CHAR(args, "alias");
    discoping_list_delete(alias);

    retval = 0;

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

static AMXM_CONSTRUCTOR conmon_start(void) {
    SAH_TRACEZ_IN(ME);
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxm_module_register(&mod, so, MOD_CONMON_CTRL);
    amxm_module_add_function(mod, "update-config", update_config);
    amxm_module_add_function(mod, "stop", stop);

    discoping_list_init();

    SAH_TRACEZ_OUT(ME);
    return 0;
}

static AMXM_DESTRUCTOR conmon_stop(void) {
    SAH_TRACEZ_IN(ME);

    cleanup_active_connections();

    SAH_TRACEZ_OUT(ME);
    return 0;
}
