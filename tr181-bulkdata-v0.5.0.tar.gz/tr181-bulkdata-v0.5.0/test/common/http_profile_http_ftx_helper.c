/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>

#include "mock.h"
#include "test_common.h"
#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_profile.h"
#include "bulkdata_profile_http.h"
#include "filetransfer/filetransfer.h"
#include "mock_lib_filetransfer.h"
#include "http_profile_http_ftx_helper.h"

static bool verify_http_uris_std(amxc_llist_t* url_parts, const cstring_t object_path, const cstring_t param, const cstring_t pattern) {
    printf("verify_http_uris_std  object_path %s, param %s,  pattern %s \n", object_path, param, pattern);
    fflush(stdout);

    amxc_string_t full_oui;
    amxc_string_t obj_path;
    amxc_string_t param_var_path;
    amxc_var_t var;
    bool found = false;

    amxc_var_init(&var);
    amxc_string_init(&full_oui, 0);
    amxc_string_init(&obj_path, 0);
    amxc_string_init(&param_var_path, 0);

    amxc_string_setf(&obj_path, "%s.%s", object_path, param);
    assert_int_equal(amxb_get(test_get_bus_ctx(), amxc_string_get(&obj_path, 0), 0, &var, 3), 0);

    amxc_string_setf(&param_var_path, "0.0.%s", param);

    assert_non_null(GETP_CHAR(&var, amxc_string_get(&param_var_path, 0)));
    amxc_string_setf(&full_oui, "%s=%s", pattern, GETP_CHAR(&var, amxc_string_get(&param_var_path, 0)));

    amxc_llist_for_each(sub_it, url_parts) {
        amxc_string_t* sub_element = amxc_string_from_llist_it(sub_it);

        if(strncmp(amxc_string_get(&full_oui, 0), amxc_string_get(sub_element, 0), amxc_string_text_length(sub_element)) == 0) {
            found = true;
            break;
        }
    }

    amxc_var_clean(&var);
    amxc_string_clean(&full_oui);
    amxc_string_clean(&obj_path);
    amxc_string_clean(&param_var_path);
    return found;
}

static void verify_http_uris_extra(amxc_llist_t* url_parts, const cstring_t profile_path) {
    amxc_var_t var;

    amxc_var_init(&var);
    get_bulkdata_profile(profile_path, "HTTP.RequestURIParameter.", &var);

    amxc_var_for_each(it, GETI_ARG(&var, 0)) {
        const char* wanted_pattern = GET_CHAR(it, "Name");
        const char* reference = GET_CHAR(it, "Reference");
        if((NULL != wanted_pattern) && (NULL != reference)) {
            amxc_string_t obj_path;
            amxc_string_t param_name;
            int dot_last = 0;
            int dot_pos = 0;

            amxc_string_init(&obj_path, 0);
            amxc_string_init(&param_name, 0);

            amxc_string_setf(&obj_path, "%s", reference);
            dot_pos = amxc_string_search(&obj_path, ".", dot_last + 1);
            while(dot_pos >= 0) {
                dot_last = dot_pos;
                dot_pos = amxc_string_search(&obj_path, ".", dot_last + 1);
            }
            amxc_string_setf(&param_name, "%s", amxc_string_get(&obj_path, dot_last + 1));
            amxc_string_remove_at(&obj_path, dot_last, UINT32_MAX);
            // check extra uri
            assert_true(verify_http_uris_std(url_parts, amxc_string_get(&obj_path, 0), amxc_string_get(&param_name, 0), wanted_pattern));

            amxc_string_clean(&obj_path);
            amxc_string_clean(&param_name);
        }

    }
    amxc_var_clean(&var);
}

static void verify_http_request(ftx_request_t* req, bool is_json) {
    assert_non_null(req);
    assert_non_null(req->userdata);
    amxc_var_t ret;
    amxc_llist_t list;
    amxc_string_t str_url;
    amxc_var_t* ftx_userdata = NULL;
    const cstring_t object_path = NULL;
    const cstring_t encoding = NULL;
    const cstring_t compression = NULL;
    const cstring_t method = NULL;
    const cstring_t report_format = NULL;
    const cstring_t url = NULL;
    const cstring_t certificate = NULL;
    bool retry_enabled = false;
    bool user_date_header = false;
    int retry_interval_multiplier = 0;
    int retry_minimum_wait_interval = 0;

    amxc_var_init(&ret);
    amxc_llist_init(&list);
    amxc_string_init(&str_url, 0);
    ftx_userdata = (amxc_var_t*) req->userdata;
    object_path = GET_CHAR(ftx_userdata, "path");
    assert_non_null(object_path);

    /******************* Profile *******************/
    get_bulkdata_profile(object_path, NULL, &ret);
    encoding = GET_CHAR(ftx_userdata, "encoding");
    assert_string_equal(encoding, GETP_CHAR(&ret, "0.0.EncodingType"));

    /******************* Profile.HTTP. *******************/
    get_bulkdata_profile(object_path, "HTTP.", &ret);

    compression = GET_CHAR(ftx_userdata, "compression");
    assert_string_equal(compression, GETP_CHAR(&ret, "0.0.Compression"));

    certificate = GET_CHAR(ftx_userdata, "certificate");
    if(certificate != NULL) {
        assert_string_equal(certificate, GETP_CHAR(&ret, "0.0.CACertificate"));
    } else {
        const char* dm_certificate = GETP_CHAR(&ret, "0.0.CACertificate");
        assert_string_equal(dm_certificate, "");
    }

    retry_enabled = GET_BOOL(ftx_userdata, "retry_enabled");
    assert_true(retry_enabled == GETP_BOOL(&ret, "0.0.RetryEnable"));

    method = GET_CHAR(ftx_userdata, "method");
    assert_string_equal(method, GETP_CHAR(&ret, "0.0.Method"));

    user_date_header = GET_BOOL(ftx_userdata, "user_date_header");
    assert_true(user_date_header == GETP_BOOL(&ret, "0.0.UseDateHeader"));

    retry_interval_multiplier = GET_INT32(ftx_userdata, "retry_interval_multiplier");
    assert_int_equal(retry_interval_multiplier, GETP_INT32(&ret, "0.0.RetryIntervalMultiplier"));

    retry_minimum_wait_interval = GET_INT32(ftx_userdata, "retry_minimum_wait_interval");
    assert_int_equal(retry_minimum_wait_interval, GETP_INT32(&ret, "0.0.RetryMinimumWaitInterval"));

    retry_enabled = GET_BOOL(ftx_userdata, "retry_enabled");
    assert_true(retry_enabled == GETP_BOOL(&ret, "0.0.RetryEnable"));

    if(true == is_json) {
        /******************* Profile.JSONEncoding *******************/
        get_bulkdata_profile(object_path, "JSONEncoding.", &ret);

        report_format = GET_CHAR(ftx_userdata, "report_format");
        assert_string_equal(report_format, GETP_CHAR(&ret, "0.0.ReportFormat"));
    } else {
        /******************* Profile.CSVEncoding *******************/
        get_bulkdata_profile(object_path, "CSVEncoding.", &ret);

        report_format = GET_CHAR(ftx_userdata, "report_format");
        assert_string_equal(report_format, GETP_CHAR(&ret, "0.0.ReportFormat"));
    }

    /******************* Profile.URL + URIs *******************/
    url = GET_CHAR(ftx_userdata, "url");
    assert_non_null(url);
    printf("profile %s: full url : %s \n", object_path, url);
    fflush(stdout);

    amxc_string_setf(&str_url, "%s", url);
    assert_int_equal(amxc_string_split_to_llist(&str_url, &list, '?'), 0);
    amxc_llist_for_each(it, &list) {
        amxc_llist_t sub_list;
        amxc_llist_init(&sub_list);
        int present = -1;

        amxc_string_t* element = amxc_string_from_llist_it(it);
        present = amxc_string_search(element, "oui", 0);
        if(0 == present) {
            assert_int_equal(amxc_string_split_to_llist(element, &sub_list, '&'), 0);
            // check ManufacturerOUI
            assert_true(verify_http_uris_std(&sub_list, "DeviceInfo", "ManufacturerOUI", "oui"));
            // check ProductClass
            assert_true(verify_http_uris_std(&sub_list, "DeviceInfo", "ProductClass", "pc"));
            // check SerialNumber
            assert_true(verify_http_uris_std(&sub_list, "DeviceInfo", "SerialNumber", "sn"));
            // extra uris
            verify_http_uris_extra(&sub_list, object_path);
        }
        amxc_llist_clean(&sub_list, amxc_string_list_it_free);
    }

    amxc_var_clean(&ret);
    amxc_llist_clean(&list, amxc_string_list_it_free);
    amxc_string_clean(&str_url);
}


void parseResponseUserData(ftx_request_t* req) {
    amxc_var_t* ftx_userdata = NULL;
    const cstring_t object_path = NULL;
    bool explicit_error = false;

    ftx_userdata = (amxc_var_t*) req->userdata;
    assert_non_null(ftx_userdata);
    object_path = GET_CHAR(ftx_userdata, "path");
    assert_non_null(object_path);


    printf("will dump ftx_userdata !!!!  %s \n", object_path);
    fflush(stdout);
    amxc_var_dump(ftx_userdata, 1);

    if(strstr(object_path, "JSON") != NULL) {
        verify_http_request(req, true);
    } else if(strstr(object_path, "CSV") != NULL) {
        verify_http_request(req, false);
    } else {
        assert_true(explicit_error);
    }

    if(strstr(object_path, "Retry") != NULL) {
        // force the negative response
        req->state = ftx_request_state_done;
        req->result.error_code = 1000;

        // more checks about the retry number + retry timers
        amxd_object_t* profile = amxd_dm_findf(mock_get_dm(), "%s", object_path);
        assert_non_null(profile);
        profile_priv_t* profile_private_data = profile->priv;
        assert_non_null(profile_private_data);
        printf("--> profile [%s] with retry entries [retry_time %d|retry_attempts %d] \n", object_path, profile_private_data->retry_time, profile_private_data->retry_attempts);
        fflush(stdout);
        assert_true(profile_private_data->retry_attempts < 6);
        assert_true(profile_private_data->retry_time < 80);
    }

    // todo: add more test about:
    //      wildcard
    //      parsing body of message + check components
}
