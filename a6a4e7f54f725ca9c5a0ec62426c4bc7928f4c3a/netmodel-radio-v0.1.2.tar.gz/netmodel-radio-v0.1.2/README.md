# netmodel-radio

This netmodel client handles the synchronization between netmodel interfaces marked with the radio flag and the WiFi.Radio. instances.
