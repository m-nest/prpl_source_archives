#!/bin/sh
# Script used to generate a simple network layout description fro uci configuration
# It is intended to provide a default working layout description as input for default odl templates

NETLAYOUT=/etc/networklayout.json

. /usr/share/libubox/jshn.sh
. /lib/functions.sh
. /lib/functions/netlayout_from_uci.sh

# Bridges Naming
brLan="br-lan"
brGuest="br-guest"
brLcm="br-lcm"

# if not present, generate a default network layout description from uci config
if [ ! -s $NETLAYOUT ]; then
	netlayout_init
	netlayout_add_wan_itf
	netlayout_add_wwan_itf
	netlayout_add_mxl_updk_pon_itf
	netlayout_add_lan_bridged_itfs
	netlayout_add_lan_dsa_bridged_itfs
	wait_for_uci_wireless
	netlayout_add_wireless_itfs

	json_dump -i > $NETLAYOUT
fi
