/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__CONMON_UTILS_H__)
#define __CONMON_UTILS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "conmon.h"

#define RESOLVE_RETRY_INTERVAL 5000

/**
   @file
   @brief
   General tool box for tr181-conmon plugin
 */

/**
   @ingroup conmon
   @defgroup conmon_utils ConMon tool box

   Functions used by conmon plugins across the different files
 */

/**
   @ingroup conmon_utils
   @brief
   Set the correct internal value of a conmon_info_t state structure with the value available in the ConMon.Entry.i object and other dependent datamodel object.

   @param conmon The conmon_info_t object to update
 */
void set_intf_info(conmon_info_t* conmon);

/**
   @ingroup conmon_utils
   @brief
   Inititialise and allocate memory for a new conmon_info_t structure related to a ConMon.Entry.i object

   @param conmon The conmon_info_t object to initialise

   @return
   amxd_status_ok if memory was allocated
   amxd_status_invalid_function_argument elsewhere
 */
amxd_status_t conmon_info_new(conmon_info_t** conmon);

/**
   @ingroup conmon_utils
   @brief
   Clean and free memory for a created conmon_info_t structure related to a ConMon.Entry.i object

   @param conmon The conmon_info_t object to clean

   @return
   amxd_status_ok
 */
amxd_status_t conmon_info_clean(conmon_info_t** conmon);

/**
   @ingroup conmon_utils
   @brief
   Helper to update the ConMon.Entry.i data model object from the back-end module

   @param function_name The name of this function on the bus
   @param args Variant containing :
        - alias [mandatory] : the alias of the ConMonEntry.i object to update
        - Status : the status to set for ConMon.Entry.i.Status
        - arpns_total_fail : the number of arp connection fails
        - total_dhcp_restarts : the number of dhcp cycle restarts
        - arpns_errors_sent : the number of arp connection errors
   @param ret Variant containing extra return paramater. This return variable is not use in this function.

   @return
   0 when the data model was correctly updated, -1 elsewhere
 */
int conmon_update_dm(const char* function_name, amxc_var_t* args, amxc_var_t* ret);

/**
   @ingroup conmon_utils
   @brief
   Helper to update the ConMon.Entry.i.Status data model parameter

   @param entry The conmon_info_t pointer corresponding to a ConMon.Entry.i data model object
   @param status The status to be set in ConMon.Entry.i.Status parameter

   @return
   0 when the status parameter was correctly updated, -1 elsewhere
 */
int conmon_set_status(conmon_info_t* entry, const char* status);

/**
   @ingroup conmon_utils
   @brief
   Helper to get the ConMon.Entry.i. internal status

   @param entry The conmon_info_t pointer corresponding to a ConMon.Entry.i data model object
   @param dhcp_up The status of the dhcp_up flag for the interface connected to the corresponding ConMon.Entry.i datamodel object

   @return
   "Enabled" when the ConMon.Entry.i is enabled
   "Error" when the ConMon.Entry.i is enabled but the dhcp connection on the interface is down
   "Disabled" when the ConMon.Entry.i is disabled
 */
const char* conmon_get_status(conmon_info_t* entry, bool dhcp_up);

#ifdef __cplusplus
}
#endif

#endif // __CONMON_UTILS_H__
