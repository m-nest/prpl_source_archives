/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "test_promise.h"

static amxp_promise_t* p1 = NULL;
static amxp_promise_t* p2 = NULL;
static amxp_promise_t* p3 = NULL;

static uint32_t number1 = 1;
static uint32_t number2 = 2;
static uint32_t number3 = 3;

int test_promise_aggr_setup(UNUSED void** state) {
    // create 3 promises in pending state
    assert_int_equal(amxp_promise_new(&p1, cancel_callback, wait_fulfill, &number1), 0);
    assert_int_equal(amxp_promise_new(&p2, cancel_callback, wait_fulfill, &number2), 0);
    assert_int_equal(amxp_promise_new(&p3, cancel_callback, wait_fulfill, &number3), 0);

    return 0;
}

int test_promise_aggr_teardown(UNUSED void** state) {
    // do not delete the sub-promises
    // they are added to the aggregated promise in the test function
    // reset the pointers to NULL here
    p1 = p2 = p3 = NULL;

    return 0;
}

void test_promise_aggr_can_create_all_type(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_any_type(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated any promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_any, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_race_type(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated race promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_race, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_all_settled_type(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all_settled promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all_settled, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_is_rejected_as_soon_as_a_subpromise_is_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // when a sub-promise is rejected
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // and the correct installed callback must be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 102);
    expect_value(rejected_callback, promise, a);

    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);

    // and the aggregated all is rejected as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 102);

    // and the sub-promises that were pending are all rejected now with status canceled
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_CANCELED);
    assert_true(amxp_promise_is_rejected(p3));
    assert_int_equal(amxp_promise_get_status(p3), AMXP_PROMISE_STATUS_CANCELED);

    amxp_promise_delete(&a);
}

void test_promise_aggr_any_is_rejected_when_all_subpromises_are_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated any promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_any, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // the correct installed callback must be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 102);
    expect_value(rejected_callback, promise, a);

    // when all sub-promises are rejected
    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // the aggregated all is rejected as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 102);

    amxp_promise_delete(&a);
}

void test_promise_aggr_race_is_rejected_if_the_first_settled_sub_promise_is_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated race promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_race, p1, p2, p3, NULL), 3); // returns the number of aggregated promises

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when a sub-promise is rejected
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // and the correct installed callback must be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 102);
    expect_value(rejected_callback, promise, a);

    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);

    // and the aggregated all is rejected as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 102);

    // and the sub-promises that were pending are all rejected now with status canceled
    assert_true(amxp_promise_is_rejected(p1));
    assert_int_equal(amxp_promise_get_status(p1), AMXP_PROMISE_STATUS_CANCELED);
    assert_true(amxp_promise_is_rejected(p3));
    assert_int_equal(amxp_promise_get_status(p3), AMXP_PROMISE_STATUS_CANCELED);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_settled_is_fulfilled_when_all_sub_promises_are_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all_settled promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all_settled, p1, p2, p3, NULL), 3); // returns the number of aggregated promises

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when all sub-promise are rejected
    // the correct installed callback must be called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, 0);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // and the aggregated is fulfilled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_is_fulfilled_as_soon_as_all_subpromises_are_fulfulled(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // when all sub-promises are fulfilled
    // the correct installed callback must be called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, 0);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);

    // the aggregated all is fulfilled as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 0);

    amxp_promise_delete(&a);
}

void test_promise_aggr_any_is_fulfilled_as_soon_as_a_subpromise_is_fulfilled(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_any, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // when a sub-promise is fulfilled
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // and the correct installed callback must be called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);

    // the aggregated all is fulfilled as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_race_is_fulfilled_if_the_first_settled_sub_promise_is_fulfilled(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated race promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_race, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // when a sub-promise is fulfilled
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // and the correct installed callback must be called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);

    // and the aggregated all is fulfilled as well
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_settled_is_fulfilled_when_all_sub_promises_are_settled(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated all_settled promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all_settled, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // when all sub-promise are settled
    // the correct installed callback must be called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // the aggregated is fulfilled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_using_array_of_promises(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when creating an aggregated race promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_race, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_using_array_of_promises_containing_null_pointers(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[5] = { p2, NULL, p3, NULL, p1 };

    // when creating an aggregated race promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_race, 5, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    amxp_promise_delete(&a);
}

void test_promise_aggr_can_create_using_list_of_promises(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxc_llist_t promises;

    amxc_llist_init(&promises);
    amxc_llist_append(&promises, &p3->it);
    amxc_llist_append(&promises, &p1->it);
    amxc_llist_append(&promises, &p2->it);

    // when creating an aggregated any promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate_list(&a, amxp_promise_aggregate_any, &promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be pending as well.
    assert_true(amxp_promise_is_pending(a));
    assert_false(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));
    // and the list is now empty
    assert_true(amxc_llist_is_empty(&promises));

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_is_rejected_at_creation_if_a_subpromise_is_already_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when rejection at least one of the promises
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated all promise
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all, 3, promises), 3); // returns the number of aggregated promises

    // the aggregated all is rejected immediately
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // and when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 103);
    expect_value(rejected_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 103);

    // and the sub-promises that were pending are all rejected now with status canceled
    assert_true(amxp_promise_is_rejected(p2));
    assert_int_equal(amxp_promise_get_status(p2), AMXP_PROMISE_STATUS_CANCELED);


    amxp_promise_delete(&a);
}

void test_promise_aggr_any_is_rejected_at_creation_if_all_subpromises_are_already_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when all promises are rejected
    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated any promise
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_any, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be rejected
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 102);
    expect_value(rejected_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // and the status is the rejection status of the first rejected
    assert_int_equal(amxp_promise_get_status(a), 102);

    amxp_promise_delete(&a);
}

void test_promise_aggr_race_is_rejected_at_creation_if_the_first_settled_is_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when rejecting a promise
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);
    // the next in the list is not taken into account
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated race promise
    // all remaining pending sub-promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_race, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be rejected
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, 103);
    expect_value(rejected_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    // and the status must match the rejected promise
    assert_int_equal(amxp_promise_get_status(a), 103);

    // and the sub-promises that were pending are all rejected now with status canceled
    assert_true(amxp_promise_is_rejected(p2));
    assert_int_equal(amxp_promise_get_status(p2), AMXP_PROMISE_STATUS_CANCELED);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_settled_is_fulfilled_at_creation_when_all_sub_promises_are_rejected(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when all sub-promise are rejected
    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated all_settled promise
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all_settled, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be fulfilled.
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_is_fulfilled_at_creation_when_subpromises_are_fulfulled(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when all sub-promises are fulfilled
    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated all promise
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be fulfilled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_any_is_fulfilled_at_creation_if_at_least_one_subpromise_is_fulfilled(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when at least one subpromise is fulfilled
    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);

    // and creating an aggregated any promise
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_any, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be fulfilled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_race_is_fulfilled_at_creation_if_the_first_settled_subpromise_is_fulfilled(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when the first_settled promise is fulfilled
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p1, 101), AMXP_PROMISE_STATUS_OK);

    // when creating an aggregated race promise
    // the remaining pending sub-promises must be canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_race, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be fulfilled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_all_settled_is_fulfilled_at_creation_when_all_sub_promises_are_settled(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when all promises are fulfilled
    assert_int_equal(amxp_promise_reject(p2, 102), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_reject(p3, 103), AMXP_PROMISE_STATUS_OK);

    // when creating an aggregated all_settled promise and all sub-promises are pending
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all_settled, 3, promises), 3); // returns the number of aggregated promises
    // the aggregated promise must be fulfilled.
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    // when callbacks are set
    // the correct installed callback must be called immediately
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_not_allowed_to_reject_or_fulfill_directly(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { p2, p3, p1 };

    // when creating an aggregated  promise
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all_settled, 3, promises), 3); // returns the number of aggregated promises

    // then reject must return not supported
    assert_int_equal(amxp_promise_reject(a, 666), AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // and fulfill must return not supported
    assert_int_equal(amxp_promise_fulfill(a, NULL), AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // when deleting the promise
    // the cancel callback must be called on all pending sub-promises
    // in the order they were added
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    amxp_promise_delete(&a);
}

void test_promise_aggr_is_waitable_if_all_subpromises_are_waitable(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated promise and all sub-promises are waitable
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_race, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the subpromise must be waitable as well
    assert_true(amxp_promise_is_waitable(a));

    // when waiting until aggregate is settled
    // as soon as the aggregated can be settled
    // the remaining pending promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // the wait callbacks must be called for each of the pending promises
    // until the aggregated is settled
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number1);

    assert_int_equal(amxp_promise_wait(a, 5000), AMXP_PROMISE_STATUS_OK);

    // and the aggregated is settled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_wait_keeps_looping_until_aggregated_is_settled(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when creating an aggregated promise and all sub-promises are waitable
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the subpromise must be waitable as well
    assert_true(amxp_promise_is_waitable(a));

    // the wait callbacks must be called for each of the pending promises
    // until the aggregated is settled
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number1);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number2);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number3);

    assert_int_equal(amxp_promise_wait(a, 5000), AMXP_PROMISE_STATUS_OK);

    // and the aggregated is settled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_wait_skips_already_settled_subpromises(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when a subpromise is already settled
    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);
    // and creating an aggregated promise and all sub-promises are waitable
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3); // returns the number of aggregated promises
    // the subpromise must be waitable as well
    assert_true(amxp_promise_is_waitable(a));

    // the wait callbacks must be called for each of the pending promises
    // until the aggregated is settled
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number1);
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number3);

    assert_int_equal(amxp_promise_wait(a, 5000), AMXP_PROMISE_STATUS_OK);

    // and the aggregated is settled
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_false(amxp_promise_is_rejected(a));
    assert_true(amxp_promise_is_fulfilled(a));

    amxp_promise_delete(&a);
}

void test_promise_aggr_if_a_subpromise_wait_fails_the_aggregated_wait_must_fail(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* p4 = NULL;

    // when a promise for witch the wait fails
    assert_int_equal(amxp_promise_new(&p4, cancel_callback, wait_fail, NULL), AMXP_PROMISE_STATUS_OK);
    // and an aggregated promise is created with subpromises that are all waitable
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p4, p2, p3, NULL), 4); // returns the number of aggregated promises
    // the subpromise must be waitable as well
    assert_true(amxp_promise_is_waitable(a));

    // the wait callbacks must be called for each of the pending promises
    // until the the wait of a subpromise fails
    expect_function_call(wait_fulfill);
    expect_value(wait_fulfill, provider_priv, &number1);
    expect_function_call(wait_fail);
    expect_value(wait_fail, provider_priv, NULL);

    // when wait fails
    // the remaining pending promises are canceled
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // and the wait on the aggregated must fail
    assert_int_equal(amxp_promise_wait(a, 5000), 1001);

    // and the aggregated must be rejected
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));

    assert_int_equal(amxp_promise_get_status(a), 1001);

    amxp_promise_delete(&a);
}

void test_promise_aggr_is_not_waitable_if_one_of_the_subpromises_is_not_waitable_at_creation(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* p4 = NULL;

    // when a non-waitable promise is created
    assert_int_equal(amxp_promise_new(&p4, cancel_callback, NULL, NULL), AMXP_PROMISE_STATUS_OK);
    // and an aggregated promise is created with that promise
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p4, p2, p3, NULL), 4); // returns the number of aggregated promises
    // the subpromise must not be waitable as well
    assert_false(amxp_promise_is_waitable(a));

    // and the wait must return not supported
    assert_int_equal(amxp_promise_wait(a, 5000), AMXP_PROMISE_STATUS_NOT_SUPPORTED);

    // fulfill all promises now
    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p4, NULL), AMXP_PROMISE_STATUS_OK);

    amxp_promise_delete(&a);
}

void test_promise_aggr_api_can_handle_null_pointers_as_input(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    assert_int_equal(amxp_promise_new_aggregate(NULL, amxp_promise_aggregate_all, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_array(NULL, amxp_promise_aggregate_all, 0, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all, 0, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all, 1, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_list(NULL, amxp_promise_aggregate_all, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_list(&a, amxp_promise_aggregate_all, NULL), -1);
}

void test_promise_aggr_create_without_promises_fail(UNUSED void** state) {
    amxp_promise_t* a = NULL;
    amxp_promise_t* promises[3] = { NULL, NULL, NULL};
    amxc_llist_t empty;

    amxc_llist_init(&empty);

    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, NULL), -1);
    assert_int_equal(amxp_promise_new_aggregate_array(&a, amxp_promise_aggregate_all, 3, promises), -1);
    assert_int_equal(amxp_promise_new_aggregate_list(&a, amxp_promise_aggregate_all, &empty), -1);
}

void test_promise_aggr_is_automatically_rejected_after_timeout(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(a, 1000), AMXP_PROMISE_STATUS_OK);
    // a timer must be set on the promise
    assert_non_null(a->reject_timer);

    // the promise is rejected if not settled within the given time
    // and the rejected callback is expected to be called
    expect_function_call(rejected_callback);
    expect_value(rejected_callback, status, AMXP_PROMISE_STATUS_TIMEOUT);
    expect_value(rejected_callback, promise, a);
    // and the cancel callback is expected to be called for all
    // remaining pending sub-promises
    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p1);
    expect_value(cancel_callback, provider_priv, &number1);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p2);
    expect_value(cancel_callback, provider_priv, &number2);

    expect_function_call(cancel_callback);
    expect_value(cancel_callback, status, AMXP_PROMISE_STATUS_CANCELED);
    expect_value(cancel_callback, promise, p3);
    expect_value(cancel_callback, provider_priv, &number3);

    // emulate event-loop and watch SIGALRM
    read_sigalrm();
    // and the timer is deleted
    assert_null(p1->reject_timer);

    // after the timeout the promise must be rejected
    assert_false(amxp_promise_is_pending(a));
    assert_true(amxp_promise_is_settled(a));
    assert_true(amxp_promise_is_rejected(a));
    assert_false(amxp_promise_is_fulfilled(a));
    // and the status is set to timeout
    assert_int_equal(amxp_promise_get_status(a), AMXP_PROMISE_STATUS_TIMEOUT);

    amxp_promise_delete(&a);
}

void test_promise_aggr_timer_is_deleted_when_aggregate_settles_before_timeout(UNUSED void** state) {
    amxp_promise_t* a = NULL;

    // when a promise is created
    assert_int_equal(amxp_promise_new_aggregate(&a, amxp_promise_aggregate_all, p1, p2, p3, NULL), 3);
    // and when callbacks are set
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_rejected, rejected_callback, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_when(a, amxp_promise_state_fulfilled, fulfilled_callback, NULL), AMXP_PROMISE_STATUS_OK);
    // and when a reject timeout is set
    assert_int_equal(amxp_promise_reject_after(a, 1000), AMXP_PROMISE_STATUS_OK);
    // a timer must be set on the promise
    assert_non_null(a->reject_timer);

    // when the aggregated settles
    // the correct callback is called
    expect_function_call(fulfilled_callback);
    expect_value(fulfilled_callback, status, AMXP_PROMISE_STATUS_OK);
    expect_value(fulfilled_callback, promise, a);

    assert_int_equal(amxp_promise_fulfill(p1, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p2, NULL), AMXP_PROMISE_STATUS_OK);
    assert_int_equal(amxp_promise_fulfill(p3, NULL), AMXP_PROMISE_STATUS_OK);

    // and the timer is deleted
    assert_null(a->reject_timer);

    amxp_promise_delete(&a);
}