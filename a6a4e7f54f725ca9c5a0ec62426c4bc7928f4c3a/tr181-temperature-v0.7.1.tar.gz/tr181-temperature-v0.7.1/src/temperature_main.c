/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

#define ME "tmp_mn"

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    char* unknown_time;
    int32_t bad_temp;
    int32_t hysteresis;
    uint32_t overheated_sensors;
    uint32_t underheated_sensors;
} app_t;

static app_t app;

amxd_dm_t* get_dm(void) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_OUT(ME);
    return app.dm;
}

amxo_parser_t* get_parser(void) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_OUT(ME);
    return app.parser;
}

amxc_var_t* get_config(void) {
    SAH_TRACEZ_IN(ME);
    amxo_parser_t* parser = get_parser();
    SAH_TRACEZ_OUT(ME);
    return parser != NULL ? &(parser->config) : NULL;
}

amxd_object_t* get_object(const char* path) {
    SAH_TRACEZ_IN(ME);
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(get_dm(), "%s", path);
exit:
    SAH_TRACEZ_OUT(ME);
    return object;
}

int32_t get_bad_temp(void) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_OUT(ME);
    return app.bad_temp;
}

int32_t get_retry(void) {
    return amxd_object_get_int32_t(amxd_dm_findf(get_dm(), TEMPSTATUS_TR181_PATH), "PollingMaxRetry", NULL);
}

char* get_unknown_time(void) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_OUT(ME);
    return app.unknown_time;
}

const char* get_prefix(void) {
    SAH_TRACEZ_IN(ME);
    amxc_var_t* setting = amxo_parser_get_config(get_parser(), "global_vendor_prefix_");
    SAH_TRACEZ_OUT(ME);
    return amxc_var_constcast(cstring_t, setting);
}

uint32_t get_hysteresis(void) {
    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_OUT(ME);
    return (uint32_t) app.hysteresis;
}

void set_overheated_sensors(uint32_t s) {
    app.overheated_sensors = s;
}

void set_underheated_sensors(uint32_t s) {
    app.underheated_sensors = s;
}

uint32_t get_overheated_sensors(void) {
    return app.overheated_sensors;
}

uint32_t get_underheated_sensors(void) {
    return app.underheated_sensors;
}

amxd_status_t tempsensor_info_clean(tempsensor_info_t** tempsensor_info) {
    SAH_TRACEZ_IN(ME);

    if((tempsensor_info == NULL) || (*tempsensor_info == NULL)) {
        goto exit;
    }

    amxp_timer_delete(&(*tempsensor_info)->polling_timer);
    free((*tempsensor_info)->name);
    free((*tempsensor_info)->hwmon_name);
    free((*tempsensor_info)->hwmon_complete_sensor_path);
    free(*tempsensor_info);
    *tempsensor_info = NULL;

exit:
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

static char* find_substring_regex(const char* input, const char* pattern) {
    regex_t regex;
    regmatch_t match;
    char* matched_substring = NULL;
    int start = 0;
    int end = 0;

    when_str_empty_trace(input, exit, ERROR, "Empty input for regex identification");
    when_str_empty_trace(pattern, exit, ERROR, "Empty pattern for regex identification");

    if(regcomp(&regex, pattern, REG_EXTENDED) != 0) {
        return NULL;
    }

    if(regexec(&regex, input, 1, &match, 0) == 0) {
        start = match.rm_so;
        end = match.rm_eo;

        matched_substring = (char*) malloc((end - start + 1) * sizeof(char));
        if(matched_substring == NULL) {
            regfree(&regex);
            return NULL;
        }

        strncpy(matched_substring, input + start, end - start);
        matched_substring[end - start] = '\0';
    }

    regfree(&regex);
exit:
    return matched_substring;
}

static bool delete_substring_regex(char* input, const char* pattern) {
    regex_t regex;
    regmatch_t match;
    int start = 0;
    int end = 0;
    bool match_bool = false;

    when_str_empty_trace(input, exit, ERROR, "Empty input for regex identification");
    when_str_empty_trace(pattern, exit, ERROR, "Empty pattern for regex identification");

    if(regcomp(&regex, pattern, REG_EXTENDED) != 0) {
        return match_bool;
    }

    if(regexec(&regex, input, 1, &match, 0) == 0) {
        start = match.rm_so;
        end = match.rm_eo;

        memmove(input + start, input + end, strlen(input) - end + 1);
        match_bool = true;
    }

    regfree(&regex);
exit:
    return match_bool;
}

//Conversion function for hwmon* sensors
void hwmon_path_to_name(tempsensor_info_t* tempsensor_info, const char* path) {
    char* str = NULL;
    const char* hwmon_pattern = HWMON_STR_VAL;
    const char* hwmon_temp_pattern = HWMON_TEMP_VAL;

    when_str_empty_trace(path, exit, ERROR, "Empty path provided");
    when_null_trace(tempsensor_info, exit, ERROR, "Tempsensor structure empty");
    str = (char*) malloc(strlen(path) + 1);
    if(str == NULL) {
        free(tempsensor_info->name);
        tempsensor_info->name = strdup(path);
        goto exit;
    }
    strcpy(str, path);
    tempsensor_info->hwmon_dev = delete_substring_regex(str, hwmon_pattern);
    free(tempsensor_info->name);
    tempsensor_info->name = str;
    free(tempsensor_info->hwmon_name);
    tempsensor_info->hwmon_name = tempsensor_info->hwmon_dev ? find_substring_regex(path, hwmon_temp_pattern) : NULL;
exit:
    return;
}

/**
 * @brief Function that brings all the data from the object to the priv structure
 *
 * @param tempsensor_instance Temperature sensor object
 * @return int
 */
static int init_tempsensors(amxd_object_t* tempsensor_instance) {
    SAH_TRACEZ_IN(ME);
    tempsensor_info_t* tempsensor_info = NULL;
    amxc_var_t tempsensor_params;
    int retval = 1;
    uint32_t interval = 0;
    char* def_time_string = get_unknown_time();
    amxc_var_init(&tempsensor_params);

    when_null(tempsensor_instance, exit);
    when_null(tempsensor_instance->priv, exit);

    retval = amxd_object_get_params(tempsensor_instance, &tempsensor_params, amxd_dm_access_protected);

    when_failed_trace(retval, exit, ERROR, "Could not read parameters from temp sensor object");

    tempsensor_info = tempsensor_instance->priv;
    //Function that aims to support changing hwmon* entries
    hwmon_path_to_name(tempsensor_info, GET_CHAR(&tempsensor_params, "Name"));
    tempsensor_info->enabled = GET_BOOL(&tempsensor_params, "Enable");
    tempsensor_info->scaling_parameter = GET_UINT32(&tempsensor_params, "ScalingParameter");

    interval = GET_INT32(&tempsensor_params, "PollingInterval") * 1000;
    tempsensor_info->def_polling_interval = GET_INT32(&tempsensor_params, "DefaultPollingInterval") * 1000;
    tempsensor_info->polling_interval = (interval > 0) ? interval : tempsensor_info->def_polling_interval;
    tempsensor_info->polling_retry_count = 0;

    tempsensor_info->low_alarm_value = GET_INT32(&tempsensor_params, "LowAlarmValue");
    tempsensor_info->high_alarm_value = GET_INT32(&tempsensor_params, "HighAlarmValue");

    tempsensor_info->max_value = GET_INT32(&tempsensor_params, "MaxValue");
    tempsensor_info->min_value = GET_INT32(&tempsensor_params, "MinValue");
    tempsensor_info->alarm_enabled = GET_BOOL(&tempsensor_params, "AlarmEnabled");
    tempsensor_info->high_alarm_state = false;
    tempsensor_info->low_alarm_state = false;
    tempsensor_info->high_hysteresis = 0;
    tempsensor_info->low_hysteresis = 0;

    tempsensor_info->high_alarm_set = true;
    tempsensor_info->low_alarm_set = true;

    amxc_ts_parse(&(tempsensor_info->low_alarm_time), def_time_string, strlen(def_time_string));
    amxc_ts_parse(&(tempsensor_info->high_alarm_time), def_time_string, strlen(def_time_string));

    //Check that the temp sensor exists
    if(!tempsensor_device_exists(tempsensor_info)) {
        SAH_TRACEZ_ERROR(ME, "Temperature sensor %s does not exist", tempsensor_info->name);
        tempsensor_info->err = true;
    }

exit:
    amxc_var_clean(&tempsensor_params);
    SAH_TRACEZ_OUT(ME);
    return retval;
}

int tempsensor_init(amxd_object_t* tempsensor_instance) {
    SAH_TRACEZ_IN(ME);
    tempsensor_info_t* priv_data = NULL;
    int retval = 1;

    if(tempsensor_instance->priv == NULL) {
        priv_data = calloc(1, sizeof(tempsensor_info_t));
        when_null(priv_data, exit);
        tempsensor_instance->priv = priv_data;

        when_failed(init_tempsensors(tempsensor_instance), exit);

        when_failed(amxp_timer_new(&(priv_data->polling_timer), update_temp_dm_n_struct, tempsensor_instance), exit);
        amxp_timer_set_interval(priv_data->polling_timer, priv_data->polling_interval);
        retval = amxp_timer_start(priv_data->polling_timer, 0);
    } else {
        retval = 0;
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return retval;
}

int tempsensor_init_all(void) {
    SAH_TRACEZ_IN(ME);
    int retval = 0;

    SAH_TRACEZ_INFO(ME, "Initializing temperature sensors");
    amxd_object_for_each(instance, it, get_object(TEMPSENSOR_TR181_PATH)) {
        retval |= tempsensor_init(amxc_llist_it_get_data(it, amxd_object_t, it));
    }
    SAH_TRACEZ_OUT(ME);
    return retval;
}

static int init(amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    app.dm = dm;
    app.parser = parser;
    amxc_var_t* unknown_time = amxo_parser_get_config(parser, "unknown_time");
    amxc_var_t* bad_temp = amxo_parser_get_config(parser, "bad_temp");
    amxc_var_t* hysteresis = amxo_parser_get_config(parser, "hysteresis");
    app.unknown_time = amxc_var_dyncast(cstring_t, unknown_time);
    app.bad_temp = amxc_var_dyncast(int32_t, bad_temp);
    app.hysteresis = amxc_var_dyncast(int32_t, hysteresis);
    app.overheated_sensors = 0;
    app.underheated_sensors = 0;
    SAH_TRACEZ_OUT(ME);
    return 0;
}

static int cleanup(void) {
    SAH_TRACEZ_IN(ME);
    int retval = amxd_status_ok;
    free(app.unknown_time);
    app.unknown_time = NULL;
    app.dm = NULL;
    app.parser = NULL;
    SAH_TRACEZ_OUT(ME);
    return retval;
}

int _tempsensor_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    SAH_TRACEZ_IN(ME);
    int retval = 0;

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "Starting tr181-temperature plugin");
        retval = init(dm, parser);
        break;
    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "Stopping tr181-temperature plugin");
        retval = cleanup();
        break;
    }
    SAH_TRACEZ_OUT(ME);
    return retval;
}
