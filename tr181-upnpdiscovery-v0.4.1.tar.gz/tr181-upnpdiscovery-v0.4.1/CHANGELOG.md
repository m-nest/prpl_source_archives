# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release master_v0.10.0 - 2025-08-19(08:51:53 +0000)

### Other

- Issue: NET-7132 - [upnpdiscovery] UPnPDiscovery plugin makes ubus-cli hang

## Release master_v0.9.3 - 2025-08-06(10:04:35 +0000)

### Fixes

- Issue: HOP-10539 - [CHR30A][PRPL][4.1.6.34] Multiple core dumps seen

## Release master_v0.9.2 - 2025-08-05(13:19:39 +0000)

## Release master_v0.9.1 - 2025-07-30(07:03:31 +0000)

## Release master_v0.9.0 - 2025-07-29(17:04:19 +0000)

## Release master_v0.8.1 - 2025-05-23(15:12:11 +0000)

### Other

- Issue: HOP-9491 [Plugin shutdown] Plugins Accessing Already-Stopped Dependencies

## Release master_v0.8.0 - 2025-02-20(19:34:45 +0000)

### New

- Issue: HOP-6356 - [upnp][discovery] UPnP deviceInstances are not added after a reboot.

## Release master_v0.7.4 - 2024-10-25(12:13:51 +0000)

### Other

- Issue: NET-6026 [gmap][mod-upnp] fill in server value

## Release master_v0.7.3 - 2024-10-23(08:22:24 +0000)

### Other

- Issue: HOP-7729 tr181-upnpdiscovery crash

## Release master_v0.7.2 - 2024-09-10(07:12:29 +0000)

### Other

- Issue: HOP-7340 [AppArmor] Create AppAmor profile for plugins

## Release master_v0.7.1 - 2024-09-06(13:07:42 +0000)

### Other

- Issue: HOP-7363 - fix crash caused by a self-closing xml tag (no value)

## Release master_v0.7.0 - 2024-08-23(12:19:33 +0000)

### Other

- Issue: NET-5986 [upnp][description] include an add/remove rpc for UPnPDescription.DeviceInstance/ServiceInstance

## Release master_v0.6.10 - 2024-07-29(06:10:39 +0000)

### Other

- Issue: HOP-4680 - [amx] Failing to restart processes with init scripts

## Release master_v0.6.9 - 2024-07-08(08:02:26 +0000)

## Release master_v0.6.8 - 2024-07-05(10:02:06 +0000)

### Other

- Issue: HOP-7000 TR181: UPnP illegal AMX key syntax

## Release master_v0.6.7 - 2024-07-01(10:56:26 +0000)

### Other

- Issue: HOP-6243 TR-181 Device.UPnP data model issues 19.03.2024

## Release master_v0.6.6 - 2024-06-25(07:37:40 +0000)

### Other

- Issue: HOP-6586 amx plugin should not run as root user

## Release master_v0.6.5 - 2024-05-31(12:37:11 +0000)

### Other

- Issue: HOP-6733 --> tr181-upnpdiscovery crash

## Release master_v0.6.4 - 2024-05-02(08:14:33 +0000)

### Other

- Issue: HOP-6438 - [UPnP] Add global enable [add]

## Release master_v0.6.3 - 2024-04-10(07:12:29 +0000)

### Changes

- Issue: HOP-6338 Make amxb timeouts configurable

## Release master_v0.6.2 - 2024-03-19(12:58:36 +0000)

### Other

- Issue: HOP-6111 Rework TR-181 interface stacks indexing number

## Release master_v0.6.1 - 2024-02-16(14:25:32 +0000)

## Release master_v0.6.0 - 2024-02-05(16:19:13 +0000)

### New

- Issue: HOP-5396 Add tr181-device proxy odl files to components

## Release master_v0.5.0 - 2024-01-17(09:31:03 +0000)

### New

- Issue: HOP-5396 Add tr181-device proxy odl files to components

## Release master_v0.4.2 - 2024-01-11(11:13:03 +0000)

### Other

- Issue: HOP-5533 - [prpl][tr181-upnpdiscovery] Typo in ModelNumber acquisition

## Release master_v0.4.1 - 2023-10-13(13:46:50 +0000)

### Changes

- Issue: HOP-4560  All applications using sahtrace logs should use default log levels

## Release master_v0.4.0 - 2023-10-12(11:55:42 +0000)

### New

- Issue: HOP-4547 Update Licenses in oss components

## Release master_v0.3.4 - 2023-09-07(11:55:25 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release master_v0.3.3 - 2023-09-07(10:15:41 +0000)

### Fixes

- Issue: HOP-4073 - [tr181-UPNP] use TR-181 paths

### Other

- Remove miniupnpd as a runtime dependency

## Release master_v0.3.2 - 2023-08-18(12:41:17 +0000)

### Fixes

- Issue: HOP-3978 - [TR181-UPNP Discovery] When changing the LAN IP address, a process running on port 49152  is not correctly restarted

## Release master_v0.3.1 - 2023-08-10(07:58:56 +0000)

### Fixes

- Issue: HOP-4073 - [tr181-UPNP] use TR-181 paths

## Release master_v0.3.0 - 2023-07-10(13:51:30 +0000)

### New

- Issue: HOP-3848 - [prpl][tr181-upnpdiscovery] implement UPnP Description logic

## Release master_v0.2.3 - 2023-06-26(09:27:26 +0000)

### Other

- Issue: HOP-3280 [UPnP] Move back firewall SSDP UDP port 1900

## Release master_v0.2.2 - 2023-06-26(08:58:20 +0000)

### Fixes

- Issue: HOP-3787 - [prpl][tr181-upnpdiscovery] libupnp initialization fail at boot

## Release master_v0.2.1 - 2023-06-16(12:34:12 +0000)

### Other

- Issue: NET-4872 [upnpdiscovery] Remove the defaults.d requirement from the odl

## Release master_v0.2.0 - 2023-04-28(11:53:52 +0000)

### Other

- Issue: NET-4360 [gmap][UPNPDiscovery] Add UPNP support in gMap

## Release master_v0.1.2 - 2023-04-05(10:14:38 +0000)

### Other

- [CI] Disable opensourcing component

## Release master_v0.1.1 - 2023-04-05(07:21:58 +0000)

### Other

- Issue: HOP-3272 [prpl][tr181-upnpdiscovery] compile error when compiling without --disable-largefile

## Release master_v0.1.0 - 2023-03-29(06:26:16 +0000)

### New

- Issue: HOP-2688 - [prpl][tr181-upnpdiscovery] UPnP.Discovery and UPnP.Description are not implemented

