/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include "processmonitor.h"
#include "dm_processmonitor.h"

static const char* expression = "notification in ['service.start', 'instance.start', 'instance.respawn', 'instance.stop', 'instance.fail', 'service.stop']";

/**
 * @brief  Logs UBUS service event and dumps updated PM DataModel
 *
 * @details Retrieves updated DataModel via Amxb get for the PM test triggered by the event,
 * and logs it using amxj parser for debugging (e.g., respawn/fail events).
 *
 * @param test  pointer to the PM test for which event triggered
 * @param test_idx  retreived index of the PM test
 * @param event . constant pointer to the event name received
 * @param pm_test_data.  Optional dump data; if NULL, data will be retrieved

 */

static void log_dump_service_event(UNUSED test_t* test, int test_idx, UNUSED const char* event) {
    amxc_string_t templ_str;
    amxc_string_t data;
    amxc_var_t res;
    amxc_var_t respawn_res;
    amxc_var_t* pm_test_data;
    int rv = -1;
    amxc_string_init(&templ_str, 0);
    amxc_string_setf(&templ_str, "ProcessMonitor.Test.%d.", test_idx);

    amxc_string_init(&data, 0);
    amxc_var_init(&res);
    amxc_var_init(&respawn_res);

    amxb_bus_ctx_t* bus_ctx = pm_get_service_ctx();
    when_null_trace(bus_ctx, exit, ERROR, "Amx bus ctx retreived for process/service events seems to be NULL");
    rv = amxb_get(bus_ctx, amxc_string_get(&templ_str, 0), 0, &res, 5);
    when_failed_trace(rv, exit, ERROR, "Failed to get 'ProcessMonitor.Test.%d.' dm from bus: %d", test_idx, rv);
    pm_test_data = amxc_var_get_first(amxc_var_get_first(&res));

    when_null_trace(pm_test_data, exit, WARNING, "Failed to parse the'ProcessMonitor.Test.%d.' Amx Data received from amxb_bus call", test_idx);

    amxc_string_setf(&data, "Name=%s, ", GET_CHAR(pm_test_data, "Name"));
    amxc_string_appendf(&data, "Type=%s, ", GET_CHAR(pm_test_data, "Type"));
    amxc_string_appendf(&data, "TestInterval=%d, ", GET_UINT32(pm_test_data, "TestInterval"));
    amxc_string_appendf(&data, "Health=%s, ", GET_CHAR(pm_test_data, "Health"));
    amxc_string_appendf(&data, "LastFailReason=%s, ", GET_CHAR(pm_test_data, "LastFailReason"));
    amxc_string_appendf(&data, "NumProcessFail=%d, ", GET_UINT32(pm_test_data, "NumProcessFail"));
    amxc_string_appendf(&data, "NumProcessRespawn=%d, ProcessRespawnParams:{", GET_UINT32(pm_test_data, "NumProcessRespawn"));

    amxc_string_appendf(&templ_str, "ProcessRespawnParams.");
    rv = amxb_get(bus_ctx, amxc_string_get(&templ_str, 0), 0, &respawn_res, 5);
    when_failed_trace(rv, exit, ERROR, "Failed to get 'ProcessMonitor.Test.%d.ProcessRespawnParams.' dm from bus: %d", test_idx, rv);
    amxc_var_t* pm_test_respawn_data = amxc_var_get_first(amxc_var_get_first(&respawn_res));

    when_null_trace(pm_test_respawn_data, exit, WARNING, "Failed to parse the'ProcessMonitor.Test.%d.ProcessRespawnParams' Amx Data received from amxb_bus call", test_idx);

    amxc_var_for_each(pm_respawn, pm_test_respawn_data) {
        const char* amxc_key = amxc_var_key(pm_respawn);
        amxc_string_appendf(&data, "%s=%d, ", amxc_key, GET_UINT32(pm_test_respawn_data, amxc_key));
    }
    amxc_string_appendf(&data, "Subject=%s", GET_CHAR(pm_test_data, "Subject"));
    SAH_TRACEZ_WARNING(AMX_PROC_MON_ME, "Received UBUS Notification on service event: %s for the prpl service:%s.., Dumping the Minimal DataModel - ProcessMonitor.Test.%d for reference\n{%s}", event, test->name, test_idx, amxc_string_get(&data, 0));

exit:
    amxc_var_clean(&respawn_res);
    amxc_var_clean(&res);
    amxc_string_clean(&templ_str);
    amxc_string_clean(&data);
    return;
}

/**
 * @brief
 * Callback function invoked upon subscription to process/service events via UBUS.
 *
 * @details
 * This function handles incoming UBUS event data by extracting the triggered service and method.
 * It then performs a PM test for the identified service, applies event-specific handling through
 * pm_apply_process_event_update(), and logs the event using log_dump_service_event() to aid in
 * debugging scenarios such as instance respawn or failure.
 *
 * @param signame Pointer to the signal name received from the UBUS subscription.
 * @param data Pointer to the event data associated with the signal.
 * @param priv Pointer to private data passed during the AMXB subscription call.
 * @return void
 */
static void process_events_subscribe_cb(UNUSED const char* signame,
                                        const amxc_var_t* const data,
                                        UNUSED void* const priv) {

    const char* event = NULL;
    const char* service = NULL;
    test_t* current_test = NULL;
    int current_test_idx = 0;

    when_null_trace(data, exit, ERROR, "'%s' ubus event data is NULL, Hence exiting the callback handler", PM_PROCESS_SUPERVISOR_ROOT_OBJ);
    event = GET_CHAR(data, "notification");
    when_null_trace(event, exit, ERROR, "'%s' ubus event data missing notification field", PM_PROCESS_SUPERVISOR_ROOT_OBJ);
    service = GET_CHAR(data, PM_PROCESS_SUPERVISOR_ROOT_OBJ);
    when_null_trace(service, exit, ERROR, "'%s' ubus event data missing %s field", PM_PROCESS_SUPERVISOR_ROOT_OBJ, PM_PROCESS_SUPERVISOR_ROOT_OBJ);

    processmonitor_t* pm = pm_get_process_monitor();
    amxc_llist_for_each(lit, &(pm->tests)) {
        current_test = amxc_llist_it_get_data(lit, test_t, it);
        current_test_idx++;
        if(!strcmp(current_test->name, service)) {
            break;
        }
    }
    when_null_trace(current_test, exit, ERROR, "Test object for service: %s may not configured with Amx Process Monitor.", service);
    when_false_trace(current_test->process_monitor_enabled, exit, WARNING, "Process monitoring disabled for service: %s. Skipping event handler and stats.", current_test->name);
    when_true_trace(pm->reboot_stage > PM_REBOOT_STAGE_NONE, exit, WARNING, "System in reboot mode. Skipping handler and stats for service: %s.", current_test->name);
    SAH_TRACEZ_WARNING(ME, "Service: %s | Event: %s | Invoking handler: pm_handle_service_%s_event()", current_test->name, event, event);
    pm_apply_process_event_update(current_test, event);

exit:
    if(current_test && current_test->log_entry_enabled && (!strcmp(event, "instance.fail") || !strcmp(event, "instance.respawn"))) {
        log_dump_service_event(current_test, current_test_idx, event);
    }
    return;
}

/**
 * @brief Unsubscribes from service events during exit or cleanup.
 *
 * This routine is invoked as part of the shutdown process triggered by
 * amxrt_exit. It ensures that any active subscriptions to service-level
 * events are properly removed to prevent dangling callbacks, resource
 * leaks, or unintended signal handling after termination.
 *
 * Typically used in test teardown or service cleanup routines to maintain
 * system integrity and avoid residual event triggers.
 *
 * @param void
 * @return int Status code indicating success or failure of the AMX unsubscription setup.
 * @note Should be called before releasing bus context or destroying objects
 */
int pm_unsubscribe_service_events(void) {

    int ret = amxd_status_unknown_error;

    amxb_bus_ctx_t* bus_ctx = pm_get_service_ctx();
    when_null_trace(bus_ctx, exit, ERROR, "Amx bus ctx retreived for process/service events seems to be NULL");

    // Unsubscribe to service event during the shutdown process on amxrt_exit during teardown
    ret = amxb_unsubscribe(bus_ctx, "service.", process_events_subscribe_cb, NULL);

    when_true_trace(ret != AMXB_STATUS_OK, exit, ERROR, "Failed to unsubscribe for the '%s' events : exit error: %i", PM_PROCESS_SUPERVISOR_ROOT_OBJ, ret);

exit:
    return ret;
}

/**
 * @brief
 * Initializes AMX subscription for the 'service' event to monitor and manage prplware/process state transitions.
 *
 * @details
 * This function sets up the AMX bus context, subscribes to the 'service' event, and registers a callback
 * to handle incoming events related to process or service lifecycle changes.
 *
 * @param void
 * @return int Status code indicating success or failure of the AMX subscription setup.
 *
 * @note
 * Uses SAH_TRACEZ macros for logging function entry, exit, and error conditions.
 *
 */
int pm_subscribe_service_events(void) {

    int ret = amxd_status_unknown_error;

    // Initialize amx bus context
    amxb_bus_ctx_t* bus_ctx = pm_get_service_ctx();
    when_null_trace(bus_ctx, exit, ERROR, "Failed to get amx bus ctx for process/service ubus events");

    // Subscribe to service event to track and handle operational state changes with prplWare/processes.
    ret = amxb_subscribe(bus_ctx, "service.", expression, process_events_subscribe_cb, NULL);

    when_true_trace(ret != AMXB_STATUS_OK, exit, ERROR, "Failed to subscribe for the '%s' events using amxb_subscribe() : exit error: %i", PM_PROCESS_SUPERVISOR_ROOT_OBJ, ret);

exit:
    return ret;
}
