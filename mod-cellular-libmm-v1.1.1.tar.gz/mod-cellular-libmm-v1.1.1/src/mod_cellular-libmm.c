/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include <ipat/ipat.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "mod_cellular-libmm.h"

#define ME "libmm"

#define CHECK_MANAGER_OWNER_PERIOD  60   /* seconds */
#define MODEM_RECONNECT_PERIOD      30   /* seconds */
#define ICCID_MIN_LENGTH 6

static GMutex libmm_lock;
static GDBusConnection* libmm_connection = NULL;
static MMManager* libmm_manager = NULL;
static GCancellable* libmm_cancellable = NULL;
static GMainLoop* libmm_loop = NULL;
static GThread* libmm_thread = NULL;

static amxc_llist_t* libmm_cell_ifaces = NULL;

static void libmm_get_manager (GTask* task);
static void libmm_modem_added (MMManager* manager, MMObject* obj);
static void libmm_modem_removed (MMManager* manager, MMObject* obj);

static void reset_libmm_cell_bearer(libmm_cell_bearer_t* bearer);

static void
libmm_exit(void) {
    if(libmm_cancellable) {
        g_cancellable_cancel(libmm_cancellable);
        g_object_unref(libmm_cancellable);
        libmm_cancellable = NULL;
    }
    if(libmm_loop) {
        g_main_loop_quit(libmm_loop);
        g_main_loop_unref(libmm_loop);
        libmm_loop = NULL;
    }
    if(libmm_thread) {
        g_thread_join(libmm_thread);
        g_thread_unref(libmm_thread);
        libmm_thread = NULL;
    }
    if(libmm_connection) {
        g_object_unref(libmm_connection);
        libmm_connection = NULL;
    }
    g_mutex_lock(&libmm_lock);
    if(libmm_manager) {
        g_object_unref(libmm_manager);
        libmm_manager = NULL;
    }
    g_mutex_unlock(&libmm_lock);
}

static void
libmm_dm_read_interface_last_change(libmm_cell_iface_t* cell_iface) {
    amxc_string_t last_change_sel_str;
    amxc_var_t values;
    amxb_bus_ctx_t* bus_ctx;

    amxc_string_init(&last_change_sel_str, 0);
    amxc_var_init(&values);

    when_null_trace(cell_iface->object_path, exit, ERROR, "Object path not specified");
    bus_ctx = amxb_be_who_has(cell_iface->object_path);
    when_null_trace(bus_ctx, exit, ERROR, "Failed to find amxb context");

    /* Trigger Cellular.Interface object state update by reading its LastChange parameter */
    amxc_string_setf(&last_change_sel_str, "%s.LastChange", cell_iface->object_path);
    amxb_get(bus_ctx, amxc_string_get(&last_change_sel_str, 0), 0, &values, 5);
    when_null_trace(amxc_var_key(GETP_ARG(&values, "0.0")), exit, ERROR, "Failed to read LastChange");

exit:
    amxc_string_clean(&last_change_sel_str);
    amxc_var_clean(&values);
}

static void detach_modem_from_cell_iface(libmm_cell_iface_t* cell_iface) {
    when_null(cell_iface, exit);
    SAH_TRACEZ_NOTICE(ME, "Detach modem %s from libmm cell iface %s", cell_iface->name, cell_iface->object_path);

    /* Remove bearer information */
    if(cell_iface->bearer.name[0]) {
        memset(cell_iface->bearer.name, 0, sizeof(cell_iface->bearer.name));
        reset_libmm_cell_bearer(&cell_iface->bearer);
    }
    if(cell_iface->bearer_object) {
        g_object_unref(cell_iface->bearer_object);
        cell_iface->bearer_object = NULL;
    }

    /* Unassign modem from cellular interface, so it could be reassigned to it when it reconnects */
    memset(&cell_iface->name, 0, sizeof(cell_iface->name));
    g_object_unref(cell_iface->modem_object);
    cell_iface->modem_object = NULL;
    cell_iface->reconnect_timer_armed = false;

    /* Reset operational status */
    strcpy(cell_iface->status, "NotPresent");
    strcpy(cell_iface->usim.status, "None");
exit:
    return;
}

static gboolean check_manager_owner(GTask* task) {
    gchar* name_owner;
    libmm_cell_iface_t* cell_iface;

    g_mutex_lock(&libmm_lock);

    when_null(libmm_manager, error);

    name_owner = g_dbus_object_manager_client_get_name_owner(G_DBUS_OBJECT_MANAGER_CLIENT(libmm_manager));
    when_null_trace(name_owner, error, ERROR, "modemmanager has stopped");
    g_free(name_owner);

    g_mutex_unlock(&libmm_lock);

    return G_SOURCE_CONTINUE;

error:
    if(libmm_manager != NULL) {
        g_signal_handlers_disconnect_by_func(libmm_manager, G_CALLBACK(libmm_modem_added), NULL);
        g_signal_handlers_disconnect_by_func(libmm_manager, G_CALLBACK(libmm_modem_removed), NULL);
        g_object_unref(libmm_manager);
        libmm_manager = NULL;
    }

    /* Reset all interfaces operational status */
    amxc_llist_for_each(it, libmm_cell_ifaces) {
        cell_iface = amxc_container_of(it, libmm_cell_iface_t, it);

        detach_modem_from_cell_iface(cell_iface);

        /* Instruct cellular manager to update Cellular.Interface object state */
        libmm_dm_read_interface_last_change(cell_iface);
    }

    g_mutex_unlock(&libmm_lock);

    /* Reattempt to get the pointer to MManager object */
    libmm_get_manager(task);

    return G_SOURCE_REMOVE;
}

static GList*
libmm_get_modems(void) {
    GList* modems = NULL;

    when_null(libmm_manager, error);

    modems = g_dbus_object_manager_get_objects(G_DBUS_OBJECT_MANAGER(libmm_manager));

error:
    return modems;
}

static void
libmm_manager_new_ready (UNUSED GObject* source, GAsyncResult* res, GTask* task) {
    MMManager* manager = NULL;
    gchar* name_owner = NULL;
    GError* error = NULL;
    GList* modems;
    GList* elem;

    g_mutex_lock(&libmm_lock);

    /* Shouldn't happen */
    when_true_trace(libmm_manager != NULL, exit, ERROR, "libmm_manager != NULL");

    manager = mm_manager_new_finish(res, &error);
    when_null_trace(manager, exit, ERROR, "Manager creation failed: %s",
                    error ? error->message : "unknown error");

    name_owner = g_dbus_object_manager_client_get_name_owner(G_DBUS_OBJECT_MANAGER_CLIENT(manager));
    when_null_trace(name_owner, exit, ERROR, "modemmanager is not running");

    libmm_manager = manager;
    g_signal_connect(libmm_manager,
                     "object-added",
                     G_CALLBACK(libmm_modem_added),
                     NULL);
    g_signal_connect(libmm_manager,
                     "object-removed",
                     G_CALLBACK(libmm_modem_removed),
                     NULL);

    SAH_TRACEZ_INFO(ME, "Connected to modem manager daemon");

    modems = g_dbus_object_manager_get_objects(G_DBUS_OBJECT_MANAGER(libmm_manager));
    g_mutex_unlock(&libmm_lock);

    /* Trigger libmm_modem_added for each modem currently listed by libmm_manager */
    elem = modems;
    while(elem) {
        MMObject* obj;

        obj = MM_OBJECT(elem->data);
        libmm_modem_added(manager, obj);
        elem = g_list_next(elem);
    }
    g_list_free_full(modems, g_object_unref);

exit:
    if(name_owner) {
        g_free(name_owner);
    } else {
        /* mutex was not unlocked yet in this case */
        g_mutex_unlock(&libmm_lock);
    }

    g_clear_error(&error);
    if(manager != libmm_manager) {
        /* Error case, release all manager objects */
        g_object_unref(manager);
        manager = NULL;
        g_object_unref(libmm_manager);
        libmm_manager = NULL;
    }

    /* Start timer to
     *   - reattempt to obtain pointer to MManager object in case of error
     *   - check that modem manager daemon still runs after retrieving MManager object */
    g_timeout_add(CHECK_MANAGER_OWNER_PERIOD * 1000, (GSourceFunc) check_manager_owner, task);
}

static void
libmm_get_manager (GTask* task) {
    SAH_TRACEZ_INFO(ME, "libmm_get_manager entry");
    mm_manager_new(libmm_connection,
                   G_DBUS_OBJECT_MANAGER_CLIENT_FLAGS_DO_NOT_AUTO_START,
                   libmm_cancellable,
                   (GAsyncReadyCallback) libmm_manager_new_ready,
                   task);
    SAH_TRACEZ_INFO(ME, "libmm_get_manager exit");
}

/*
 * This function is executed by libmm_thread, which has the following tasks:
 *   - retrieve asynchronously the pointer to MManager object, needed for the following tasks
 *   - when modem manager daemon (i.e. owner of MManager object) is no longer running, it frees
 *     the current MManager pointer and trigger another libmm_get_manager task; owner of MManager
 *     object is retrieved by polling it at every 15 seconds
 *   - register event handlers for modem add/remove/state-changed events; all these event handlers
 *     along with check_manager_owner and libmm_modem_reconnect timer handlers) are called from the
 *     context of this thread, since this is the thread were GLib main loop is executed
 *   - when modem gets disconnected, reconnection will be attempted every 30 seconds as long as
 *     cell_iface remains enabled
 */
static gpointer
libmm_main_thread (UNUSED gpointer data) {
    GTask* task = g_task_new(libmm_connection, libmm_cancellable, NULL, NULL);

    SAH_TRACEZ_INFO(ME, "libmm_main_thread has been started");

    libmm_get_manager(task);

    g_main_loop_run(libmm_loop);

    /* Application is shutting down, free task object */
    g_task_return_pointer(task, libmm_connection, NULL);
    g_object_unref(task);

    return NULL;
}

static int
libmm_init(void) {
    GError* error = NULL;

    if(!libmm_connection) {
        libmm_connection = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, &error);
        when_null_trace(libmm_connection, exit_error, ERROR, "Couldn't get dbus: %s", error ? error->message : "unknown error");
    }

    if(!libmm_loop) {
        libmm_loop = g_main_loop_new(NULL, FALSE);
        when_null_trace(libmm_loop, exit_error, ERROR, "GMainLoop allocation failed");
    }

    if(!libmm_cancellable) {
        libmm_cancellable = g_cancellable_new();
        when_null_trace(libmm_cancellable, exit_error, ERROR, "GCancellable allocation failed");
    }

    if(!libmm_thread) {
        libmm_thread = g_thread_new("libmm_main_thread", libmm_main_thread, NULL);
        when_null_trace(libmm_thread, exit_error, ERROR, "GThread creation failed");
    }

    g_clear_error(&error);
    return 0;

exit_error:
    g_clear_error(&error);
    libmm_exit();

    return -1;
}

static void
libmm_modem_capability_build_string_from_mask (char* str, MMModemCapability mask) {

    if(mask & MM_MODEM_CAPABILITY_CDMA_EVDO) {
        strcat(str, "CDMA2000HRPD,");
    }

    if(mask & MM_MODEM_CAPABILITY_GSM_UMTS) {
        strcat(str, "UMTS,");
    }

    if(mask & MM_MODEM_CAPABILITY_LTE) {
        strcat(str, "LTE,");
    }

    if(mask & MM_MODEM_CAPABILITY_5GNR) {
        strcat(str, "NR,");
    }
}

static void
libmm_common_build_capabilities_string (char* str, const MMModemCapability* capabilities,
                                        guint n_capabilities) {
    guint i;

    str[0] = '\0';

    if(!capabilities || !n_capabilities) {
        return;
    }

    for(i = 0; i < n_capabilities; i++) {
        libmm_modem_capability_build_string_from_mask(str, capabilities[i]);
    }

    if(strlen(str) > 0) {
        str[strlen(str) - 1] = '\0';
    }
}

static void
libmm_modem_preferred_mode_build_string (char* str, MMModemMode preferred_mode, MMModemCapability capability_mask) {

    str[0] = '\0';

    if(!capability_mask) {
        strcpy(str, "Auto");
        return;
    }

    switch(preferred_mode) {
    case MM_MODEM_MODE_2G:
        if(capability_mask & MM_MODEM_CAPABILITY_GSM_UMTS) {
            strcpy(str, "EDGE");
        }
        break;
    case MM_MODEM_MODE_3G:
        if(capability_mask & MM_MODEM_CAPABILITY_GSM_UMTS) {
            strcpy(str, "UMTS");
        } else if(capability_mask & MM_MODEM_CAPABILITY_CDMA_EVDO) {
            strcpy(str, "CDMA2000OneX");
        }
        break;
    case MM_MODEM_MODE_4G:
        if(capability_mask & MM_MODEM_CAPABILITY_LTE) {
            strcpy(str, "LTE");
        }
        break;
    case MM_MODEM_MODE_5G:
        if(capability_mask & MM_MODEM_CAPABILITY_5GNR) {
            strcpy(str, "NR");
        }
        break;
    default:
        strcpy(str, "Auto");
        break;
    }
}

static void libmm_access_technology_build_csv_string_from_mask(char* str, MMModemAccessTechnology mask) {

    str[0] = '\0';

    if(mask & MM_MODEM_ACCESS_TECHNOLOGY_GPRS) {
        strcat(str, "GPRS,");
    }

    if(mask & MM_MODEM_ACCESS_TECHNOLOGY_EDGE) {
        strcat(str, "EDGE,");
    }

    if(mask & MM_MODEM_ACCESS_TECHNOLOGY_UMTS) {
        strcat(str, "UMTS,");
    }

    if((mask & MM_MODEM_ACCESS_TECHNOLOGY_HSDPA) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_HSUPA) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_HSPA) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_HSPA_PLUS)) {
        strcat(str, "UMTSHSPA,");
    }

    if(mask & MM_MODEM_ACCESS_TECHNOLOGY_1XRTT) {
        strcat(str, "CDMA2000OneX,");
    }

    if((mask & MM_MODEM_ACCESS_TECHNOLOGY_EVDO0) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_EVDOA) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_EVDOB)) {
        strcat(str, "CDMA2000HRPD,");
    }

    if((mask & MM_MODEM_ACCESS_TECHNOLOGY_LTE) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_LTE_CAT_M) ||
       (mask & MM_MODEM_ACCESS_TECHNOLOGY_LTE_NB_IOT)) {
        strcat(str, "LTE,");
    }

    if(mask & MM_MODEM_ACCESS_TECHNOLOGY_5GNR) {
        strcat(str, "NR,");
    }

    if(strlen(str) > 0) {
        str[strlen(str) - 1] = '\0';
    }
}

static gboolean
mm_modem_run_sync (MMModem* modem, libmm_cell_iface_t* cell_iface, gboolean connect_flag) {
    GError* error = NULL;
    gboolean result = FALSE, delete_result;

    when_null(cell_iface, exit);

    if(connect_flag) {
        when_null(cell_iface->bearer_properties, exit);

        cell_iface->unsupported_bearer_config = false;

        /* Create bearer */
        cell_iface->bearer_object = mm_modem_create_bearer_sync(modem, cell_iface->bearer_properties, NULL, &error);
        when_null_trace(cell_iface->bearer_object, exit, ERROR, "Bearer creation failed with error: %s", error ? error->message : "unknown");
        g_clear_error(&error);
        strncpy(cell_iface->bearer.name, mm_bearer_get_path(cell_iface->bearer_object), sizeof(cell_iface->bearer.name) - 1);
        SAH_TRACEZ_INFO(ME, "Bearer %s has been created", cell_iface->bearer.name);

        /* Connect bearer */
        result = mm_bearer_connect_sync(cell_iface->bearer_object, NULL, &error);
        if(result) {
            cell_iface->bearer.connected = true;
            SAH_TRACEZ_INFO(ME, "Bearer %s has been connected", cell_iface->bearer.name);
        } else {
            SAH_TRACEZ_ERROR(ME, "Bearer %s connection failed with error: %s",
                             cell_iface->bearer.name, error ? error->message : "unknown");

            /* Fallthrough: Delete bearer that failed to connect */
        }
    }

    if(!connect_flag || !result) {
        if(!cell_iface->enable) {
            /* Flush old bearer properties */
            g_object_unref(cell_iface->bearer_properties);
            cell_iface->bearer_properties = NULL;
        }

        if(cell_iface->bearer.name[0]) {

            g_clear_error(&error);
            cell_iface->bearer.connected = false;
            mm_bearer_disconnect_sync(cell_iface->bearer_object, NULL, NULL);
            delete_result = mm_modem_delete_bearer_sync(modem, cell_iface->bearer.name, NULL, &error);
            if(!connect_flag) {
                result = delete_result;
            }
            if(delete_result) {
                SAH_TRACEZ_INFO(ME, "Bearer %s has been deleted", cell_iface->bearer.name);
            } else {
                SAH_TRACEZ_ERROR(ME, "Bearer %s deletion failed with error: %s", cell_iface->bearer.name, error ? error->message : "unknown");
            }

            /* Clear the bearer information from the interface entry */
            memset(cell_iface->bearer.name, 0, sizeof(cell_iface->bearer.name));
            reset_libmm_cell_bearer(&cell_iface->bearer);
            g_object_unref(cell_iface->bearer_object);
            cell_iface->bearer_object = NULL;
        }
    }

exit:
    g_clear_error(&error);

    return result;
}

static const char*
libmm_bearer_method_build_string(MMBearerIpMethod method) {
    switch(method) {
    case MM_BEARER_IP_METHOD_STATIC:
        return "Static";
    case MM_BEARER_IP_METHOD_PPP:
        return "PPP";
    case MM_BEARER_IP_METHOD_DHCP:
        return "DHCP";
    default:
        return "Unknown";
    }
}

static bool
libmm_fetch_bearer_info_sync_ipcfg(MMBearerIpConfig* ip_config, libmm_cell_bearer_ipcfg_t* cell_bearer_ipcfg) {
    bool rc = false;
    cell_bearer_ipcfg->method = mm_bearer_ip_config_get_method(ip_config);
    if(cell_bearer_ipcfg->method != MM_BEARER_IP_METHOD_UNKNOWN) {
        const gchar* address = mm_bearer_ip_config_get_address(ip_config);
        const gchar* gateway = mm_bearer_ip_config_get_gateway(ip_config);
        int ip_family = ipat_text_family(address);
        guint prefixlen = mm_bearer_ip_config_get_prefix(ip_config);
        uint prefixlen_max = (ip_family == AF_INET) ? 30 : 64;

        when_false((cell_bearer_ipcfg->method == MM_BEARER_IP_METHOD_DHCP) ||
                   (cell_bearer_ipcfg->method == MM_BEARER_IP_METHOD_STATIC &&
                    ip_family != AF_INET_INVALID && 0 < prefixlen && prefixlen <= prefixlen_max), exit);

        strncpy(cell_bearer_ipcfg->addr, address ? address : "", sizeof(cell_bearer_ipcfg->addr) - 1);
        strncpy(cell_bearer_ipcfg->gateway, gateway ? gateway : "", sizeof(cell_bearer_ipcfg->gateway) - 1);

        strncpy(cell_bearer_ipcfg->prefix, "", sizeof(cell_bearer_ipcfg->prefix) - 1);
        char* pref_or_mask = NULL;
        char prefixlen_str[4] = { '\0' };
        switch(ip_family) {
        case AF_INET:
            pref_or_mask = ipat_text_mask_create(ip_family, prefixlen, ipat_bits_upper, false);
            break;
        case AF_INET6:
            pref_or_mask = ipat_text_mask_apply_direct(cell_bearer_ipcfg->addr, prefixlen, ipat_bits_upper, ipat_oper_and, false);
            snprintf(prefixlen_str, sizeof(prefixlen_str) - 1, "%hhu", (unsigned char) prefixlen);
            pref_or_mask = realloc(pref_or_mask, strlen(pref_or_mask) + strlen(prefixlen_str) + 2);
            strncat(pref_or_mask, "/", 1);
            strncat(pref_or_mask, prefixlen_str, strlen(prefixlen_str));
            break;
        default:
            break;
        }
        strncpy(cell_bearer_ipcfg->prefix, pref_or_mask ? pref_or_mask : "", sizeof(cell_bearer_ipcfg->prefix) - 1);
        free(pref_or_mask);

        cell_bearer_ipcfg->mtu = mm_bearer_ip_config_get_mtu(ip_config);

        rc = true; /* bearer config is supported */
    }

exit:
    return rc;
}

static void
append_csv(gchar* csv_dst, const gchar** src, int dst_size) {
    gchar* result = NULL;
    gchar* csv_src = NULL;

    when_true_trace(csv_dst == NULL, exit, ERROR, "Destination csv list is NULL");
    when_true_trace(src == NULL, exit, ERROR, "Source csv list is NULL");

    csv_src = g_strjoinv(",", (gchar**) src);
    when_str_empty(csv_src, exit);

    if(*csv_dst == '\0') {
        result = g_strdup(csv_src);
    } else {
        result = g_strjoin(",", csv_dst, csv_src, NULL);
    }

    when_null_trace(result, exit, ERROR, "Result from appending lists %s and %s is NULL", csv_dst, csv_src);

    g_strlcpy(csv_dst, result, dst_size);

exit:
    g_free(csv_src);
    g_free(result);
    return;
}

static bool
libmm_fetch_bearer_info_sync(MMBearer* bearer, libmm_cell_bearer_t* cell_bearer) {
    bool rc4 = false, rc6 = false;
    MMBearerIpConfig* ipv4_config = NULL;
    MMBearerIpConfig* ipv6_config = NULL;

    when_null_trace(cell_bearer, exit, ERROR, "Interface can not be null, invalid argument");
    when_null(bearer, exit);
    SAH_TRACEZ_INFO(ME, "Fetching info for bearer name %s", cell_bearer->name);

    reset_libmm_cell_bearer(cell_bearer);

    ipv4_config = mm_bearer_get_ipv4_config(bearer);
    if(ipv4_config) {
        rc4 = libmm_fetch_bearer_info_sync_ipcfg(ipv4_config, &cell_bearer->ipv4);
        if(rc4) {
            append_csv(cell_bearer->dns_servers, mm_bearer_ip_config_get_dns(ipv4_config), sizeof(cell_bearer->dns_servers));
        }
    }

    ipv6_config = mm_bearer_get_ipv6_config(bearer);
    if(ipv6_config) {
        rc6 = libmm_fetch_bearer_info_sync_ipcfg(ipv6_config, &cell_bearer->ipv6);
        if(rc6) {
            append_csv(cell_bearer->dns_servers, mm_bearer_ip_config_get_dns(ipv6_config), sizeof(cell_bearer->dns_servers));
        }
    }

exit:
    g_object_unref(ipv4_config);
    g_object_unref(ipv6_config);

    return rc4 || rc6;
}


static bool
copy_numeric_string(char* dst, const char* src, unsigned min_len, unsigned max_len, bool replace_plus_prefix) {
    bool res = false;
    unsigned i = 0, j = 0;
    char c;

    when_null(dst, exit);
    when_false(0 < min_len && min_len <= max_len, exit);
    when_str_empty_status(src, exit, res = true);

    if(replace_plus_prefix && (src[0] == '+')) {
        when_true(max_len < 2, exit);
        j++;
        dst[i++] = '0';
        dst[i++] = '0';
    }

    while(i <= max_len) {
        c = src[j++];
        if(c == '\0') {
            break;
        }

        when_false(isdigit(c), exit);

        dst[i++] = c;
    }

    res = (min_len <= i && i <= max_len);

exit:
    if(dst != NULL) {
        dst[res ? i : 0] = '\0';
    }
    return res;
}

static bool
libmm_fetch_usim_info_sync(MMModem* modem, libmm_cell_usim_t* cell_usim) {
    bool rc = false;
    GError* error = NULL;
    MMSim* sim = NULL;
    const gchar* imsi;
    const gchar* iccid;

    when_null_trace(modem, exit, ERROR, "modem can not be null, invalid argument");
    when_null_trace(cell_usim, exit, ERROR, "interface can not be null, invalid argument");
    when_str_empty(cell_usim->name, exit);

    SAH_TRACEZ_INFO(ME, "Fetching info for SIM name %s", cell_usim->name);

    sim = mm_modem_get_sim_sync(modem, NULL, &error);
    if(sim == NULL) {
        SAH_TRACEZ_NOTICE(ME, "Failed to retrieve SIM object with %s error",
                          error ? error->message : "unknown");
    }

    strcpy(cell_usim->status, sim != NULL && mm_sim_get_active(sim) ? (cell_usim->unlocked ? "Valid" : "Available") : "None");
    imsi = sim != NULL ? mm_sim_get_imsi(sim) : NULL;
    iccid = sim != NULL ? mm_sim_get_identifier(sim) : NULL;
    if(!copy_numeric_string(cell_usim->imsi, imsi,
                            sizeof(cell_usim->imsi) - 2, sizeof(cell_usim->imsi) - 1, false)) {
        SAH_TRACEZ_ERROR(ME, "Invalid IMSI value '%s'", imsi ? imsi : "<NULL>");
    }
    if(!copy_numeric_string(cell_usim->iccid, iccid,
                            ICCID_MIN_LENGTH, sizeof(cell_usim->iccid) - 1, false)) {
        SAH_TRACEZ_ERROR(ME, "Invalid ICCID value '%s'", iccid ? iccid : "<NULL>");
    }

    rc = true;

exit:
    g_clear_error(&error);
    g_object_unref(sim);
    return rc;
}

static bool
libmm_fetch_modem_info_sync(libmm_cell_iface_t* cell_iface) {
    bool rc = false;
    MMModem* modem = NULL;
    MMModem3gpp* modem_3gpp = NULL;
    MMModemCdma* modem_cdma = NULL;
    MMModemSignal* modem_signal = NULL;
    MMSim* sim = NULL;
    GError* error = NULL;
    MMModemAccessTechnology access_technology = MM_MODEM_ACCESS_TECHNOLOGY_UNKNOWN;
    MMModemCapability* capabilities = NULL;
    guint n_capabilities = 0;
    MMSignal* signal;
    gdouble signal_value = MM_SIGNAL_UNKNOWN;
    MMModemMode allowed_modes;
    gchar* allowed_modes_string = NULL;
    MMModemMode preferred_mode;
    const gchar* imei = NULL;
    const gchar* operator_name = NULL;
    const gchar* sim_path = NULL;
    gchar** own_numbers = NULL;
    gchar* own_numbers_string = NULL;

    when_null_trace(cell_iface, exit, ERROR, "Interface can not be null, invalid argument");
    when_str_empty(cell_iface->name, exit);
    when_null(cell_iface->modem_object, exit);

    SAH_TRACEZ_INFO(ME, "Fetching info for modem %s", cell_iface->name);

    /* Get modem objects */
    modem = mm_object_get_modem(cell_iface->modem_object);
    when_null_trace(modem, exit, NOTICE, "Modem %s not found", cell_iface->name);
    modem_3gpp = mm_object_get_modem_3gpp(cell_iface->modem_object);
    modem_cdma = mm_object_get_modem_cdma(cell_iface->modem_object);
    modem_signal = mm_object_get_modem_signal(cell_iface->modem_object);

    mm_modem_get_supported_capabilities(modem, &capabilities, &n_capabilities);
    libmm_common_build_capabilities_string(cell_iface->supported_access_tech, capabilities, n_capabilities);
    g_free(capabilities);

    own_numbers = mm_modem_dup_own_numbers(modem);
    own_numbers_string = g_strjoinv(",", own_numbers);

    if(mm_modem_get_current_modes(modem, &allowed_modes, &preferred_mode)) {
        allowed_modes_string = mm_modem_mode_build_string_from_mask(allowed_modes);
        libmm_modem_preferred_mode_build_string(cell_iface->preferred_access_tech, preferred_mode, mm_modem_get_current_capabilities(modem));
    }

    access_technology = mm_modem_get_access_technologies(modem);
    libmm_access_technology_build_csv_string_from_mask(cell_iface->current_access_tech, access_technology);

    if(modem_3gpp) {
        imei = mm_modem_3gpp_get_imei(modem_3gpp);
        operator_name = mm_modem_3gpp_get_operator_name(modem_3gpp);
    }

    if(!copy_numeric_string(cell_iface->imei, imei,
                            sizeof(cell_iface->imei) - 1, sizeof(cell_iface->imei) - 1, false)) {
        SAH_TRACEZ_ERROR(ME, "Invalid IMEI value '%s'", imei ? imei : "<NULL>");
    }
    if(!copy_numeric_string(cell_iface->usim.msisdn, own_numbers_string,
                            sizeof(cell_iface->usim.msisdn) - 2, sizeof(cell_iface->usim.msisdn) - 1, true)) {
        SAH_TRACEZ_ERROR(ME, "Invalid MSISDN value '%s'", own_numbers_string ? own_numbers_string : "<NULL>");
    }

    cell_iface->rssi = 0;
    cell_iface->rsrp = 0;
    cell_iface->rsrq = 0;
    switch(access_technology) {
    case MM_MODEM_ACCESS_TECHNOLOGY_POTS:
    case MM_MODEM_ACCESS_TECHNOLOGY_GSM:
    case MM_MODEM_ACCESS_TECHNOLOGY_GSM_COMPACT:
    case MM_MODEM_ACCESS_TECHNOLOGY_GPRS:
    case MM_MODEM_ACCESS_TECHNOLOGY_EDGE:
        signal = mm_modem_signal_peek_gsm(modem_signal);
        if(signal) {
            signal_value = mm_signal_get_rssi(signal);
            cell_iface->rssi = (signal_value == MM_SIGNAL_UNKNOWN) ? RSSI_GSM_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
        } else {
            cell_iface->rssi = RSSI_GSM_LOWER_LIMIT_LEVEL;
        }
        break;

    case MM_MODEM_ACCESS_TECHNOLOGY_UMTS:
    case MM_MODEM_ACCESS_TECHNOLOGY_HSDPA:
    case MM_MODEM_ACCESS_TECHNOLOGY_HSUPA:
    case MM_MODEM_ACCESS_TECHNOLOGY_HSPA:
    case MM_MODEM_ACCESS_TECHNOLOGY_HSPA_PLUS:
    case MM_MODEM_ACCESS_TECHNOLOGY_1XRTT:
        signal = mm_modem_signal_peek_umts(modem_signal);
        if(signal) {
            signal_value = mm_signal_get_rssi(signal);
            cell_iface->rssi = (signal_value == MM_SIGNAL_UNKNOWN) ? RSSI_UMTS_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
        } else {
            cell_iface->rssi = RSSI_UMTS_LOWER_LIMIT_LEVEL;
        }
        break;

    case MM_MODEM_ACCESS_TECHNOLOGY_EVDO0:
    case MM_MODEM_ACCESS_TECHNOLOGY_EVDOA:
    case MM_MODEM_ACCESS_TECHNOLOGY_EVDOB:
        signal = mm_modem_signal_peek_evdo(modem_signal);
        if(signal) {
            signal_value = mm_signal_get_rssi(signal);
            cell_iface->rssi = (signal_value == MM_SIGNAL_UNKNOWN) ? RSSI_UMTS_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
        } else {
            cell_iface->rssi = RSSI_UMTS_LOWER_LIMIT_LEVEL;
        }
        break;

    case MM_MODEM_ACCESS_TECHNOLOGY_LTE:
    case MM_MODEM_ACCESS_TECHNOLOGY_LTE_CAT_M:
    case MM_MODEM_ACCESS_TECHNOLOGY_LTE_NB_IOT:
        signal = mm_modem_signal_peek_lte(modem_signal);
        if(signal) {
            signal_value = mm_signal_get_rssi(signal);
            SAH_TRACEZ_INFO(ME, "lte_rssi:%.2lf", signal_value);
            cell_iface->rssi = (signal_value == MM_SIGNAL_UNKNOWN) ? RSSI_LTE_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
            signal_value = mm_signal_get_rsrp(signal);
            SAH_TRACEZ_INFO(ME, "lte_rsrp:%.2lf", signal_value);
            cell_iface->rsrp = (signal_value == MM_SIGNAL_UNKNOWN) ? RSRP_LTE_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
            signal_value = mm_signal_get_rsrq(signal);
            SAH_TRACEZ_INFO(ME, "lte_rsrq:%.2lf", signal_value);
            cell_iface->rsrq = (signal_value == MM_SIGNAL_UNKNOWN) ? RSRQ_LTE_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
        } else {
            SAH_TRACEZ_INFO(ME, "lte: Signal is NULL");
            cell_iface->rssi = RSSI_LTE_LOWER_LIMIT_LEVEL;
            cell_iface->rsrp = RSRP_LTE_LOWER_LIMIT_LEVEL;
            cell_iface->rsrq = RSRQ_LTE_LOWER_LIMIT_LEVEL;
        }
        break;

    case MM_MODEM_ACCESS_TECHNOLOGY_5GNR:
        signal = mm_modem_signal_peek_nr5g(modem_signal);
        if(signal) {
            signal_value = mm_signal_get_rssi(signal);
            cell_iface->rssi = (signal_value == MM_SIGNAL_UNKNOWN) ? RSSI_5GNR_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
            signal_value = mm_signal_get_rsrp(signal);
            cell_iface->rsrp = (signal_value == MM_SIGNAL_UNKNOWN) ? RSRP_5GNR_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
            signal_value = mm_signal_get_rsrq(signal);
            cell_iface->rsrq = (signal_value == MM_SIGNAL_UNKNOWN) ? RSRQ_5GNR_LOWER_LIMIT_LEVEL : (int32_t) signal_value;
        } else {
            cell_iface->rssi = RSSI_5GNR_LOWER_LIMIT_LEVEL;
            cell_iface->rsrp = RSRP_5GNR_LOWER_LIMIT_LEVEL;
            cell_iface->rsrq = RSRQ_5GNR_LOWER_LIMIT_LEVEL;
        }
        break;

    default:
        cell_iface->rssi = RSSI_GSM_LOWER_LIMIT_LEVEL;
        break;
    }

    /* Sanitize RSSI, RSRP and RSRQ values, otherwise their validation will fail */
    if((cell_iface->rssi < RSSI_5GNR_LOWER_LIMIT_LEVEL) || (cell_iface->rssi > RSSI_UPPER_LIMIT_LEVEL)) {
        cell_iface->rssi = RSSI_5GNR_LOWER_LIMIT_LEVEL;
    }
    if((cell_iface->rsrp < RSRP_5GNR_LOWER_LIMIT_LEVEL) || (cell_iface->rsrp > RSRP_UPPER_LIMIT_LEVEL)) {
        cell_iface->rsrp = RSRP_5GNR_LOWER_LIMIT_LEVEL;
    }
    if((cell_iface->rsrq < RSRQ_5GNR_LOWER_LIMIT_LEVEL) || (cell_iface->rsrq > RSRQ_UPPER_LIMIT_LEVEL)) {
        cell_iface->rsrq = RSRQ_5GNR_LOWER_LIMIT_LEVEL;
    }

    cell_iface->upstream_max_bitrate = 50000;
    cell_iface->downstream_max_bitrate = 100000;

    /* Retrieve SIM name */
    sim_path = mm_modem_get_sim_path(modem);
    SAH_TRACEZ_INFO(ME, "Modem %s SIM path is %s", cell_iface->name, sim_path ? sim_path : "<NULL>");
    strncpy(cell_iface->usim.name, sim_path ? sim_path : "", sizeof(cell_iface->usim.name) - 1);

    /* If operator name is NULL, retrieve it from MMSim */
    if(sim_path && *sim_path && (operator_name == NULL)) {
        sim = mm_modem_get_sim_sync(modem, NULL, &error);
        if(sim) {
            operator_name = mm_sim_get_operator_name(sim);
        } else {
            SAH_TRACEZ_ERROR(ME, "Failed to retrieve SIM object with %s error",
                             error ? error->message : "unknown");
        }
    }

    strncpy(cell_iface->network_in_use, operator_name ? operator_name : "", sizeof(cell_iface->network_in_use) - 1);

    rc = true;

exit:
    g_clear_error(&error);
    g_object_unref(sim);
    g_object_unref(modem_signal);
    g_object_unref(modem_cdma);
    g_object_unref(modem_3gpp);
    g_object_unref(modem);

    g_free(allowed_modes_string);
    g_strfreev(own_numbers);
    g_free(own_numbers_string);
    return rc;
}

static void libmm_iface_delete(amxc_llist_it_t* it) {
    libmm_cell_iface_t* cell_iface = amxc_container_of(it, libmm_cell_iface_t, it);

    /* Delete current bearer before deleting the cell interface */
    if(cell_iface->name[0] && cell_iface->bearer.name[0]) {
        MMModem* modem = NULL;

        /* Disconnect interface before removing it */
        if(cell_iface->modem_object) {
            modem = mm_object_get_modem(cell_iface->modem_object);
            cell_iface->enable = false;
            mm_modem_run_sync(modem, cell_iface, FALSE);
            g_object_unref(cell_iface->modem_object);
            cell_iface->modem_object = NULL;
        }

        g_object_unref(modem);
    }

    SAH_TRACEZ_NOTICE(ME, "Deallocating libmm cell iface for %s", cell_iface->name);
    free(cell_iface);
}


static libmm_cell_iface_t* find_libmm_cell_iface_by_object_path(const char* object_path) {
    libmm_cell_iface_t* cell_iface;

    when_str_empty(object_path, exit);

    SAH_TRACEZ_INFO(ME, "Searching for %s", object_path);
    amxc_llist_for_each(it, libmm_cell_ifaces) {
        cell_iface = amxc_container_of(it, libmm_cell_iface_t, it);
        SAH_TRACEZ_INFO(ME, "Comparing with %s", cell_iface->object_path);
        if(!strcmp(cell_iface->object_path, object_path)) {
            return cell_iface;
        }
    }

exit:
    return NULL;
}

static libmm_cell_iface_t* find_libmm_cell_iface_by_name(const char* ifname) {
    libmm_cell_iface_t* cell_iface;

    when_str_empty(ifname, exit);

    SAH_TRACEZ_INFO(ME, "Searching for %s", ifname);
    amxc_llist_for_each(it, libmm_cell_ifaces) {
        cell_iface = amxc_container_of(it, libmm_cell_iface_t, it);
        SAH_TRACEZ_INFO(ME, "Comparing with %s", cell_iface->name);
        if(!strcmp(cell_iface->name, ifname)) {
            return cell_iface;
        }
    }

exit:
    return NULL;
}

static libmm_cell_iface_t* find_libmm_cell_iface_by_netdev_name(const char* netdev_name) {
    libmm_cell_iface_t* cell_iface;

    when_str_empty(netdev_name, exit);

    SAH_TRACEZ_INFO(ME, "Searching for %s", netdev_name);
    amxc_llist_for_each(it, libmm_cell_ifaces) {
        cell_iface = amxc_container_of(it, libmm_cell_iface_t, it);
        SAH_TRACEZ_INFO(ME, "Comparing with %s", cell_iface->netdev_name);
        if(!strcmp(cell_iface->netdev_name, netdev_name)) {
            return cell_iface;
        }
    }

exit:
    return NULL;
}

static int assign_modem_to_cell_iface(libmm_cell_iface_t* cell_iface) {
    GList* modems = libmm_get_modems();
    GList* elem = modems;
    bool match_netdev_name = false;
    int rv = -1;

    when_null_trace(cell_iface, exit, ERROR, "Interface can not be null, invalid argument");
    when_str_empty_trace(cell_iface->netdev_name, exit, ERROR, "Empty netdev, invalid argument");

    /*
     * Assign the modem to the cell iface with matching netdev name.
     * Check that name is not referred in any cell_iface.
     */
    while(elem) {
        MMObject* obj;
        MMModem* modem;
        const gchar* modem_path;
        MMModemPortInfo* ports = NULL;
        guint n_ports = 0;

        obj = MM_OBJECT(elem->data);
        modem = mm_object_peek_modem(obj);
        if(!modem) {
            goto next;
        }

        modem_path = mm_object_get_path(obj);
        if((modem_path == NULL) || find_libmm_cell_iface_by_name(modem_path)) {
            goto next;
        }

        mm_modem_get_ports(modem, &ports, &n_ports);
        if(ports) {
            for(guint i = 0; i < n_ports; i++) {
                if((ports[i].type == MM_MODEM_PORT_TYPE_NET) &&
                   (strcmp(cell_iface->netdev_name, ports[i].name) == 0)) {
                    match_netdev_name = true;
                    break;
                }
            }
        }
        mm_modem_port_info_array_free(ports, n_ports);
        if(!match_netdev_name) {
            goto next;
        }

        /* Gotcha, assign the modem to this cell_iface */
        SAH_TRACEZ_NOTICE(ME, "Assign modem %s to libmm cell iface %s", modem_path, cell_iface->object_path);
        strncpy(cell_iface->name, modem_path, sizeof(cell_iface->name) - 1);
        cell_iface->modem_object = g_object_ref(obj);
        cell_iface->usim.unlocked = (mm_modem_get_unlock_required(modem) != MM_MODEM_LOCK_SIM_PIN);
        rv = 0;
        break;

next:
        elem = g_list_next(elem);
    }

exit:
    g_list_free_full(modems, g_object_unref);
    return rv;
}

static void reset_libmm_cell_bearer(libmm_cell_bearer_t* bearer) {
    memset(bearer->dns_servers, 0, sizeof(bearer->dns_servers));
    bearer->connected = false;
    memset(&bearer->ipv4, 0, sizeof(bearer->ipv4));
    bearer->ipv4.method = MM_BEARER_IP_METHOD_UNKNOWN;
    memset(&bearer->ipv6, 0, sizeof(bearer->ipv6));
    bearer->ipv6.method = MM_BEARER_IP_METHOD_UNKNOWN;
}

static int init_libmm_cell_iface(libmm_cell_iface_t* cell_iface, const char* obj_path, const char* netdev_name) {
    int rv = -1;

    when_str_empty(obj_path, exit);
    when_str_empty(netdev_name, exit);
    SAH_TRACEZ_INFO(ME, "Initializing libmm cell iface for object %s netdev %s", obj_path, netdev_name);
    when_null_trace(cell_iface, exit, ERROR, "Interface can not be null, invalid argument");

    strncpy(cell_iface->object_path, obj_path, sizeof(cell_iface->object_path) - 1);
    strncpy(cell_iface->netdev_name, netdev_name, sizeof(cell_iface->netdev_name) - 1);
    assign_modem_to_cell_iface(cell_iface);

    /* Avoid validation failures */
    cell_iface->rssi = RSSI_5GNR_LOWER_LIMIT_LEVEL;
    cell_iface->rsrp = RSRP_5GNR_LOWER_LIMIT_LEVEL;
    cell_iface->rsrq = RSRQ_5GNR_LOWER_LIMIT_LEVEL;
    strcpy(cell_iface->usim.status, "None");
    strcpy(cell_iface->usim.pin_check, "Off");
    cell_iface->bearer.ipv4.method = MM_BEARER_IP_METHOD_UNKNOWN;
    cell_iface->bearer.ipv6.method = MM_BEARER_IP_METHOD_UNKNOWN;

    if(libmm_fetch_modem_info_sync(cell_iface)) {
        strcpy(cell_iface->status, "Down");
    } else {
        strcpy(cell_iface->status, "NotPresent");
    }

    rv = 0;

exit:
    return rv;
}

int libmm_iface_create(UNUSED const char* function_name,
                       amxc_var_t* args,
                       amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    const char* netdev_name = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");

    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "Args is not an htable");
    obj_path = GET_CHAR(args, "ObjectPath");
    when_str_empty_trace(obj_path, exit, ERROR, "Passed object path is empty");
    netdev_name = GET_CHAR(args, "Name");
    when_str_empty_trace(obj_path, exit, ERROR, "Passed name is empty");
    when_true_trace(find_libmm_cell_iface_by_object_path(obj_path) != NULL, exit, ERROR,
                    "Cannot create libmm cell iface info for object_path: %s, iface already exist with this path", obj_path);
    when_true_trace(find_libmm_cell_iface_by_netdev_name(netdev_name) != NULL, exit, ERROR,
                    "Cannot create libmm cell iface info for netdev: %s, iface already exist with this netdev name", netdev_name);

    SAH_TRACEZ_INFO(ME, "Creating libmm cell iface info for object %s", obj_path);

    libmm_cell_iface_t* cell_iface = calloc(1, sizeof(libmm_cell_iface_t));
    when_null_trace(cell_iface, exit, ERROR, "Unable to allocate memory");

    retval = init_libmm_cell_iface(cell_iface, obj_path, netdev_name);
    when_failed_trace(retval, clean, ERROR, "Failed to initialize libmm cell interface %s", obj_path);

    amxc_llist_append(libmm_cell_ifaces, &cell_iface->it);

    SAH_TRACEZ_NOTICE(ME, "Allocated libmm cell iface for %s", cell_iface->object_path);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->name);

    retval = 0;

clean:
    if(retval != 0) {
        free(cell_iface);
    }
exit:
    g_mutex_unlock(&libmm_lock);
    return retval;
}


int libmm_iface_destroy(UNUSED const char* function_name,
                        amxc_var_t* args,
                        UNUSED amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");

    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "Args is not an htable");
    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    SAH_TRACEZ_INFO(ME, "Destroy libmm cell iface %s", obj_path);

    libmm_cell_iface_t* cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    amxc_llist_it_clean(&cell_iface->it, libmm_iface_delete);

    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);
    return retval;
}

int libmm_iface_destroy_all(UNUSED const char* function_name,
                            UNUSED amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    g_mutex_lock(&libmm_lock);
    SAH_TRACEZ_NOTICE(ME, "Destroy all libmm cell interfaces");
    amxc_llist_delete(&libmm_cell_ifaces, libmm_iface_delete);
    g_mutex_unlock(&libmm_lock);

    return 0;
}

static MMBearerIpFamily
libmm_bearer_ipfamily_from_string(const char* ip_family) {
    if(strcmp(ip_family, "ipv4") == 0) {
        return MM_BEARER_IP_FAMILY_IPV4;
    } else if(strcmp(ip_family, "ipv6") == 0) {
        return MM_BEARER_IP_FAMILY_IPV6;
    } else if(strcmp(ip_family, "ipv4v6") == 0) {
        return MM_BEARER_IP_FAMILY_IPV4V6;
    } else {
        return MM_BEARER_IP_FAMILY_NONE;
    }
}

int libmm_iface_set(UNUSED const char* function_name,
                    amxc_var_t* args,
                    UNUSED amxc_var_t* ret) {
    MMModem* modem = NULL;
    MMModem3gpp* modem_3gpp = NULL;
    MMModemSignal* modem_signal = NULL;
    MMBearerProperties* init_bearer_props_3gpp = NULL;
    GError* error = NULL;
    int retval = -1;
    const char* obj_path = NULL;
    libmm_cell_iface_t* cell_iface = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");
    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    /* Locate modem */
    if(cell_iface->modem_object) {
        modem = mm_object_get_modem(cell_iface->modem_object);
        modem_3gpp = mm_object_get_modem_3gpp(cell_iface->modem_object);
        modem_signal = mm_object_get_modem_signal(cell_iface->modem_object);
    }

    if(GET_ARG(args, "Enable")) {
        gboolean run_result;
        bool prev_enable = cell_iface->enable;
        cell_iface->enable = GET_BOOL(args, "Enable");
        if(cell_iface->enable && !prev_enable) {
            if(modem_3gpp) {
                init_bearer_props_3gpp = mm_modem_3gpp_get_initial_eps_bearer_settings(modem_3gpp);
                if(init_bearer_props_3gpp && (mm_bearer_properties_get_ip_type(init_bearer_props_3gpp) != MM_BEARER_IP_FAMILY_IPV4V6)) {
                    mm_bearer_properties_set_ip_type(init_bearer_props_3gpp, MM_BEARER_IP_FAMILY_IPV4V6);
                    if(!mm_modem_3gpp_set_initial_eps_bearer_settings_sync(modem_3gpp, init_bearer_props_3gpp, NULL, &error)) {
                        SAH_TRACEZ_ERROR(ME, "mm_modem_3gpp_set_initial_eps_bearer_settings_sync: failed with %s", error ? error->message : "unknown error");
                        g_clear_error(&error);
                    }
                }
            }

            g_object_unref(cell_iface->bearer_properties);
            cell_iface->bearer_properties = mm_bearer_properties_new();
            if(cell_iface->bearer_properties) {
                SAH_TRACEZ_NOTICE(ME, "Connecting interface: %s APN:%s IP-Type:%s", cell_iface->name, GET_CHAR(args, "APN"), GET_CHAR(args, "IPType"));
                mm_bearer_properties_set_apn(cell_iface->bearer_properties, GET_CHAR(args, "APN"));
                MMBearerIpFamily iptype = libmm_bearer_ipfamily_from_string(GET_CHAR(args, "IPType"));
                mm_bearer_properties_set_ip_type(cell_iface->bearer_properties, iptype);
                mm_bearer_properties_set_allow_roaming(cell_iface->bearer_properties, GET_BOOL(args, "RoamingEnabled"));
                mm_bearer_properties_set_user(cell_iface->bearer_properties, GET_CHAR(args, "Username"));
                mm_bearer_properties_set_password(cell_iface->bearer_properties, GET_CHAR(args, "Password"));
                if(modem) {
                    run_result = mm_modem_run_sync(modem, cell_iface, TRUE);
                    strcpy(cell_iface->status, run_result ? "Up" : "Error");
                }
            } else {
                SAH_TRACEZ_ERROR(ME, "mm_bearer_properties_new returns NULL");
            }
        } else if(!cell_iface->enable && prev_enable) {
            if(modem) {
                SAH_TRACEZ_NOTICE(ME, "Disconnecting interface: %s", cell_iface->name);
                run_result = mm_modem_run_sync(modem, cell_iface, FALSE);
                strcpy(cell_iface->status, run_result ? "Down" : "Error");
            }
        }
        SAH_TRACEZ_INFO(ME, "Set enable=%d, status is %s", cell_iface->enable, cell_iface->status);
    } else if(GET_ARG(args, "SignalQualityPollingRate")) {
        cell_iface->signal_quality_polling_rate = GET_UINT32(args, "SignalQualityPollingRate");
        if(modem_signal) {
            if(!mm_modem_signal_setup_sync(modem_signal,
                                           cell_iface->signal_quality_polling_rate,
                                           NULL,
                                           &error)) {
                SAH_TRACEZ_ERROR(ME, "mm_modem_signal_setup_sync: failed with %s", error ? error->message : "unknown error");
                g_clear_error(&error);
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "modem_signal is not initialized");
        }
        SAH_TRACEZ_INFO(ME, "Set signal_quality_polling_rate=%u", (unsigned) cell_iface->signal_quality_polling_rate);
    } else if(GET_ARG(args, "PreferredAccessTechnology")) {
        strncpy(cell_iface->preferred_access_tech, GET_CHAR(args, "PreferredAccessTechnology"), sizeof(cell_iface->preferred_access_tech) - 1);
        SAH_TRACEZ_INFO(ME, "Set preferred_access_tech=%s", cell_iface->preferred_access_tech);
    } else if(GET_ARG(args, "NetworkRequested")) {
        strncpy(cell_iface->network_requested, GET_CHAR(args, "NetworkRequested"), sizeof(cell_iface->network_requested) - 1);
        SAH_TRACEZ_INFO(ME, "Set network_requested=%s", cell_iface->network_requested);
    }

    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);

    g_clear_error(&error);
    g_object_unref(modem_signal);
    g_object_unref(modem);
    g_object_unref(modem_3gpp);
    g_object_unref(init_bearer_props_3gpp);
    return retval;
}

int libmm_iface_retrieve(UNUSED const char* function_name,
                         amxc_var_t* args,
                         amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    libmm_cell_iface_t* cell_iface = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    SAH_TRACEZ_INFO(ME, "get data for %s", obj_path);
    cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    libmm_fetch_modem_info_sync(cell_iface);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, ret, "Enable", cell_iface->enable);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->name);
    amxc_var_add_key(cstring_t, ret, "Status", cell_iface->status);
    amxc_var_add_key(cstring_t, ret, "IMEI", cell_iface->imei);
    amxc_var_add_key(cstring_t, ret, "SupportedAccessTechnologies", cell_iface->supported_access_tech);
    amxc_var_add_key(cstring_t, ret, "PreferredAccessTechnology", cell_iface->preferred_access_tech);
    amxc_var_add_key(cstring_t, ret, "CurrentAccessTechnology", cell_iface->current_access_tech);
    amxc_var_add_key(cstring_t, ret, "AvailableNetworks", cell_iface->available_networks);
    amxc_var_add_key(cstring_t, ret, "NetworkRequested", cell_iface->network_requested);
    amxc_var_add_key(cstring_t, ret, "NetworkInUse", cell_iface->network_in_use);
    amxc_var_add_key(int32_t, ret, "RSSI", cell_iface->rssi);
    amxc_var_add_key(int32_t, ret, "RSRP", cell_iface->rsrp);
    amxc_var_add_key(int32_t, ret, "RSRQ", cell_iface->rsrq);
    amxc_var_add_key(uint32_t, ret, "UpstreamMaxBitRate", cell_iface->upstream_max_bitrate);
    amxc_var_add_key(uint32_t, ret, "DownstreamMaxBitRate", cell_iface->downstream_max_bitrate);

    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);
    return retval;
}

int libmm_usim_set(UNUSED const char* function_name,
                   amxc_var_t* args,
                   UNUSED amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    libmm_cell_iface_t* cell_iface = NULL;
    MMModem* modem = NULL;
    MMSim* sim = NULL;
    GError* error = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "Setting for USIM %s", cell_iface->usim.name);
    modem = mm_object_get_modem(cell_iface->modem_object);
    if(modem) {
        sim = mm_modem_get_sim_sync(modem, NULL, &error);
        if(sim == NULL) {
            SAH_TRACEZ_ERROR(ME, "Failed to retrieve SIM object with %s error",
                             error ? error->message : "unknown");
        }
    }

    if(GET_ARG(args, "PIN")) {
        strncpy(cell_iface->usim.pin, GET_CHAR(args, "PIN"), sizeof(cell_iface->usim.pin) - 1);
        SAH_TRACEZ_INFO(ME, "Provided pin=%s", cell_iface->usim.pin);

        // Unlock the SIM if needed
        if(!cell_iface->usim.unlocked && (sim != NULL)) {
            g_clear_error(&error);
            if(mm_sim_send_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                SAH_TRACEZ_NOTICE(ME, "SIM accepted the PIN code");
                cell_iface->usim.unlocked = true;
            } else {
                SAH_TRACEZ_ERROR(ME, "SIM refused the PIN code with %s error",
                                 error ? error->message : "unknown");
            }
        }
    }

    if(GET_ARG(args, "PINCheck")) {
        bool enable_pin_check = (strcmp(GET_CHAR(args, "PINCheck"), "Off") != 0);
        if(!enable_pin_check || *cell_iface->usim.pin) {
            // We support only check the PIN with first access after (re)boot
            strncpy(cell_iface->usim.pin_check, enable_pin_check ? "Reboot" : "Off", sizeof(cell_iface->usim.pin_check) - 1);
            SAH_TRACEZ_INFO(ME, "Setting pin_check to %s", cell_iface->usim.pin_check);

            if(cell_iface->usim.unlocked && (sim != NULL) && *cell_iface->usim.pin) {
                g_clear_error(&error);
                if(enable_pin_check) {
                    if(mm_sim_enable_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                        SAH_TRACEZ_NOTICE(ME, "PIN Check is enabled");
                    } else {
                        SAH_TRACEZ_ERROR(ME, "Failed to enable PIN Check with %s error",
                                         error ? error->message : "unknown");
                    }
                } else {
                    if(mm_sim_disable_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                        SAH_TRACEZ_NOTICE(ME, "PIN Check is disabled");
                    } else {
                        SAH_TRACEZ_ERROR(ME, "Failed to disable PIN Check with %s error",
                                         error ? error->message : "unknown");
                    }
                }
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "PIN has to be provided to set PINCheck to Reboot");
        }
    }
    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);

    g_object_unref(sim);
    g_object_unref(modem);
    g_clear_error(&error);
    return retval;
}

int libmm_usim_retrieve(UNUSED const char* function_name,
                        amxc_var_t* args,
                        amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    libmm_cell_iface_t* cell_iface = NULL;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    SAH_TRACEZ_INFO(ME, "get data for %s", cell_iface->usim.name);
    libmm_fetch_usim_info_sync(mm_object_peek_modem(cell_iface->modem_object), &cell_iface->usim);

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->usim.name);
    amxc_var_add_key(cstring_t, ret, "Status", cell_iface->usim.status);
    amxc_var_add_key(cstring_t, ret, "IMSI", cell_iface->usim.imsi);
    amxc_var_add_key(cstring_t, ret, "ICCID", cell_iface->usim.iccid);
    amxc_var_add_key(cstring_t, ret, "MSISDN", cell_iface->usim.msisdn);
    amxc_var_add_key(cstring_t, ret, "PINCheck", cell_iface->usim.pin_check);
    amxc_var_add_key(cstring_t, ret, "PIN", cell_iface->usim.pin);

    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);
    return retval;
}

int libmm_bearer_retrieve(UNUSED const char* function_name,
                          amxc_var_t* args,
                          amxc_var_t* ret) {
    int retval = -1;
    const char* obj_path = NULL;
    libmm_cell_iface_t* cell_iface = NULL;
    amxc_var_t* ipv4_addr;
    amxc_var_t* ipv6_addr;

    g_mutex_lock(&libmm_lock);

    when_null_trace(args, exit, ERROR, "Passed args is NULL");
    when_null_trace(ret, exit, ERROR, "Passed ret is NULL");
    when_failed_trace((amxc_var_type_of(args) != AMXC_VAR_ID_HTABLE), exit, ERROR,
                      "args is not an htable");

    obj_path = GET_CHAR(args, "ObjectPath");
    when_null_trace(obj_path, exit, ERROR, "Passed object path is NULL");

    cell_iface = find_libmm_cell_iface_by_object_path(obj_path);
    when_null_trace(cell_iface, exit, ERROR, "libmm cell interface %s not found", obj_path);

    if(cell_iface->bearer_object) {
        SAH_TRACEZ_INFO(ME, "get data for %s", cell_iface->bearer.name);

        /* Check bearer config is supported */
        if(!libmm_fetch_bearer_info_sync(cell_iface->bearer_object, &cell_iface->bearer) && !cell_iface->unsupported_bearer_config) {
            SAH_TRACEZ_ERROR(ME, "Bearer %s configuration not supported", cell_iface->bearer.name);

            /* Disconnect the modem and don't attempt to reconnect anymore */
            cell_iface->unsupported_bearer_config = true;
            mm_modem_run_sync(mm_object_peek_modem(cell_iface->modem_object), cell_iface, FALSE);
            strcpy(cell_iface->status, "Error");

            /* Instruct cellular manager to update Cellular.Interface object state */
            libmm_dm_read_interface_last_change(cell_iface);
        }
    }

    amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ret, "InternalName", cell_iface->bearer.name);
    amxc_var_add_key(cstring_t, ret, "DNSServers", cell_iface->bearer.dns_servers);
    ipv4_addr = amxc_var_add_new_key(ret, "IPv4");
    amxc_var_set_type(ipv4_addr, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ipv4_addr, "Method", libmm_bearer_method_build_string(cell_iface->bearer.ipv4.method));
    amxc_var_add_key(cstring_t, ipv4_addr, "Address", cell_iface->bearer.ipv4.addr);
    amxc_var_add_key(cstring_t, ipv4_addr, "GatewayIPAddress", cell_iface->bearer.ipv4.gateway);
    amxc_var_add_key(cstring_t, ipv4_addr, "SubnetMask", cell_iface->bearer.ipv4.prefix);
    amxc_var_add_key(uint32_t, ipv4_addr, "MTU", cell_iface->bearer.ipv4.mtu);

    ipv6_addr = amxc_var_add_new_key(ret, "IPv6");
    amxc_var_set_type(ipv6_addr, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, ipv6_addr, "Method", libmm_bearer_method_build_string(cell_iface->bearer.ipv6.method));
    amxc_var_add_key(cstring_t, ipv6_addr, "Address", cell_iface->bearer.ipv6.addr);
    amxc_var_add_key(cstring_t, ipv6_addr, "NextHop", cell_iface->bearer.ipv6.gateway);
    amxc_var_add_key(cstring_t, ipv6_addr, "Prefix", cell_iface->bearer.ipv6.prefix);
    amxc_var_add_key(uint32_t, ipv6_addr, "MTU", cell_iface->bearer.ipv6.mtu);

    retval = 0;

exit:
    g_mutex_unlock(&libmm_lock);
    return retval;
}

static void
libmm_modem_reconnect(MMModem* modem) {
    const gchar* modem_path;
    libmm_cell_iface_t* cell_iface;
    gboolean run_result;

    g_mutex_lock(&libmm_lock);

    when_null_trace(modem, exit, ERROR, "modem can not be null, invalid argument");
    modem_path = mm_modem_get_path(modem);

    SAH_TRACEZ_NOTICE(ME, "Reconnect modem %s", modem_path);
    when_str_empty(modem_path, exit);

    cell_iface = find_libmm_cell_iface_by_name(modem_path);
    when_null(cell_iface, exit);

    cell_iface->reconnect_timer_armed = false;
    when_true(!cell_iface->enable ||
              cell_iface->modem_object == NULL ||
              cell_iface->bearer_properties == NULL ||
              cell_iface->bearer_object != NULL ||
              cell_iface->bearer.name[0] ||
              cell_iface->unsupported_bearer_config ||
              cell_iface->bearer.connected ||
              strcmp(cell_iface->status, "NotPresent") == 0, exit);

    /* Attempt to reconnect the modem */
    run_result = mm_modem_run_sync(modem, cell_iface, TRUE);
    strcpy(cell_iface->status, run_result ? "Up" : "Error");

    /* Instruct cellular manager to update Cellular.Interface object state */
    libmm_dm_read_interface_last_change(cell_iface);

    SAH_TRACEZ_NOTICE(ME, "Modem %s reconnection %s", modem_path, run_result ? "succeded" : "failed");

exit:
    g_mutex_unlock(&libmm_lock);
    g_object_unref(modem);
}

static const gchar*
libmm_get_state_reason_string (MMModemStateChangeReason reason) {
    switch(reason) {
    default:
    case MM_MODEM_STATE_CHANGE_REASON_UNKNOWN:
        return "None or unknown";
    case MM_MODEM_STATE_CHANGE_REASON_USER_REQUESTED:
        return "User request";
    case MM_MODEM_STATE_CHANGE_REASON_SUSPEND:
        return "Suspend";
    case MM_MODEM_STATE_CHANGE_REASON_FAILURE:
        return "Failure";
    }
}

static void
libmm_modem_state_changed (MMModem* modem,
                           MMModemState old_state,
                           MMModemState new_state,
                           MMModemStateChangeReason reason) {
    const gchar* modem_path;
    libmm_cell_iface_t* cell_iface;

    g_mutex_lock(&libmm_lock);

    modem_path = mm_modem_get_path(modem);
    SAH_TRACEZ_INFO(ME, "Modem %s state changed, '%s' --> '%s' (reason: %s)",
                    modem_path,
                    mm_modem_state_get_string(old_state),
                    mm_modem_state_get_string(new_state),
                    libmm_get_state_reason_string(reason));

    /* Handle only the disconnecting events */
    when_true((old_state != MM_MODEM_STATE_CONNECTING && old_state != MM_MODEM_STATE_CONNECTED) ||
              (new_state != MM_MODEM_STATE_DISCONNECTING && new_state != MM_MODEM_STATE_ENABLED), exit);

    cell_iface = find_libmm_cell_iface_by_name(modem_path);
    when_null(cell_iface, exit);

    /* Attempt to reconnect bearer only when interface is enabled and bearer config is supported */
    when_true(!cell_iface->enable ||
              cell_iface->bearer_properties == NULL ||
              cell_iface->unsupported_bearer_config ||
              cell_iface->reconnect_timer_armed ||
              mm_modem_get_state(modem) == MM_MODEM_STATE_CONNECTED, exit);

    /* Delete the current bearer */
    mm_modem_run_sync(modem, cell_iface, FALSE);

    /* Attempt reconnection after a short delay, which gives cellular
     * manager enough time to update LastChange */
    SAH_TRACEZ_NOTICE(ME, "Will attempt modem %s reconnection in %d seconds", modem_path, MODEM_RECONNECT_PERIOD);
    g_timeout_add_once(MODEM_RECONNECT_PERIOD * 1000, (GSourceOnceFunc) libmm_modem_reconnect, g_object_ref(modem));
    cell_iface->reconnect_timer_armed = true;

    /* Instruct cellular manager to update Cellular.Interface object state */
    libmm_dm_read_interface_last_change(cell_iface);

exit:
    g_mutex_unlock(&libmm_lock);
}

static void
libmm_modem_added (UNUSED MMManager* manager,
                   MMObject* obj) {
    MMModem* modem = NULL;
    libmm_cell_iface_t* cell_iface = NULL;
    const gchar* modem_path = NULL;
    MMModemPortInfo* ports = NULL;
    guint n_ports = 0;

    g_mutex_lock(&libmm_lock);

    modem = mm_object_peek_modem(obj);
    when_null(modem, exit);

    modem_path = mm_object_get_path(obj);
    SAH_TRACEZ_INFO(ME, "Modem %s has been added", modem_path);
    when_str_empty(modem_path, exit);

    g_signal_connect(modem,
                     "state-changed",
                     G_CALLBACK(libmm_modem_state_changed),
                     NULL);

    /* Allocate modem to the cell interface that has the same netdev name */
    mm_modem_get_ports(modem, &ports, &n_ports);
    if(ports) {
        for(guint i = 0; i < n_ports; i++) {
            if(ports[i].type == MM_MODEM_PORT_TYPE_NET) {
                cell_iface = find_libmm_cell_iface_by_netdev_name(ports[i].name);
                if(cell_iface) {
                    break;
                }
            }
        }
    }
    mm_modem_port_info_array_free(ports, n_ports);
    when_null(cell_iface, exit);

    /* Update name and modem_object, dongles get new path each time they're plugged in */
    SAH_TRACEZ_NOTICE(ME, "Assign modem %s to libmm cell iface %s", modem_path, cell_iface->object_path);
    strncpy(cell_iface->name, modem_path, sizeof(cell_iface->name) - 1);
    g_object_unref(cell_iface->modem_object);
    cell_iface->modem_object = g_object_ref(obj);

    /* Reconfigure signal quality polling rate */
    if(cell_iface->signal_quality_polling_rate) {
        GError* error = NULL;
        MMModemSignal* modem_signal = mm_object_get_modem_signal(cell_iface->modem_object);

        if(modem_signal) {
            if(!mm_modem_signal_setup_sync(modem_signal,
                                           cell_iface->signal_quality_polling_rate,
                                           NULL,
                                           &error)) {
                SAH_TRACEZ_ERROR(ME, "mm_modem_signal_setup_sync: failed with %s", error ? error->message : "unknown error");
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "modem_signal is not initialized");
        }

        g_object_unref(modem_signal);
        g_clear_error(&error);
    }

    /* Reconfigure the SIM */
    cell_iface->usim.unlocked = (mm_modem_get_unlock_required(modem) != MM_MODEM_LOCK_SIM_PIN);
    if(*cell_iface->usim.pin) {
        GError* error = NULL;
        MMSim* sim = mm_modem_get_sim_sync(modem, NULL, &error);

        if(sim) {
            if(cell_iface->usim.unlocked) {
                if(strcmp(cell_iface->usim.pin_check, "Off") != 0) {
                    // We support only check the PIN with first access after (re)boot
                    if(mm_sim_enable_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                        SAH_TRACEZ_NOTICE(ME, "PIN Check is enabled");
                        strncpy(cell_iface->usim.pin_check, "Reboot", sizeof(cell_iface->usim.pin_check) - 1);
                    } else {
                        SAH_TRACEZ_ERROR(ME, "Failed to enable PIN Check with %s error",
                                         error ? error->message : "unknown");
                    }
                }
            } else {
                if(mm_sim_send_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                    SAH_TRACEZ_NOTICE(ME, "SIM accepted the PIN code");
                    cell_iface->usim.unlocked = true;

                    g_clear_error(&error);
                    if(strcmp(cell_iface->usim.pin_check, "Off") == 0) {
                        if(mm_sim_disable_pin_sync(sim, cell_iface->usim.pin, NULL, &error)) {
                            SAH_TRACEZ_NOTICE(ME, "PIN Check is disabled");
                        } else {
                            SAH_TRACEZ_ERROR(ME, "Failed to disable PIN Check with %s error",
                                             error ? error->message : "unknown");
                        }
                    }
                } else {
                    SAH_TRACEZ_ERROR(ME, "SIM refused the PIN code with %s error",
                                     error ? error->message : "unknown");
                }
            }
        } else {
            SAH_TRACEZ_ERROR(ME, "Failed to retrieve SIM object with %s error",
                             error ? error->message : "unknown");
        }

        g_object_unref(sim);
        g_clear_error(&error);
    }

    /* Reconnect modem if it is enabled */
    if(cell_iface->enable) {
        gboolean run_result = mm_modem_run_sync(modem, cell_iface, TRUE);
        strcpy(cell_iface->status, run_result ? "Up" : "Error");
        SAH_TRACEZ_NOTICE(ME, "Modem %s reconnected, status is %s", cell_iface->name, cell_iface->status);
    } else {
        strcpy(cell_iface->status, "Down");
    }

    /* Instruct cellular manager to update Cellular.Interface object state */
    libmm_dm_read_interface_last_change(cell_iface);

exit:
    g_mutex_unlock(&libmm_lock);
}

static void
libmm_modem_removed (UNUSED MMManager* manager,
                     MMObject* obj) {
    MMModem* modem;
    libmm_cell_iface_t* cell_iface;
    const gchar* modem_path;

    g_mutex_lock(&libmm_lock);

    modem = mm_object_peek_modem(obj);
    when_null(modem, exit);

    modem_path = mm_object_get_path(obj);
    SAH_TRACEZ_INFO(ME, "Modem %s has been removed", modem_path);

    g_signal_handlers_disconnect_by_func(modem, G_CALLBACK(libmm_modem_state_changed), NULL);

    cell_iface = find_libmm_cell_iface_by_name(modem_path);
    when_null(cell_iface, exit);

    detach_modem_from_cell_iface(cell_iface);

    /* Instruct cellular manager to update Cellular.Interface object state */
    libmm_dm_read_interface_last_change(cell_iface);

exit:
    g_mutex_unlock(&libmm_lock);
}

static AMXM_CONSTRUCTOR libmm_module_start(void) {
    int retval = -1;
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    amxc_llist_new(&libmm_cell_ifaces);

    retval = libmm_init();
    when_failed_trace(retval, exit, ERROR, "libmm_init failed");

    amxm_module_register(&mod, so, MOD_CELLULAR_CTRL);
    amxm_module_add_function(mod, "create-cell-iface", libmm_iface_create);
    amxm_module_add_function(mod, "destroy-cell-iface", libmm_iface_destroy);
    amxm_module_add_function(mod, "destroy-all-cell-ifaces", libmm_iface_destroy_all);
    amxm_module_add_function(mod, "set-cell-iface-info", libmm_iface_set);
    amxm_module_add_function(mod, "retrieve-cell-iface-info", libmm_iface_retrieve);
    amxm_module_add_function(mod, "set-cell-usim-info", libmm_usim_set);
    amxm_module_add_function(mod, "retrieve-cell-usim-info", libmm_usim_retrieve);
    amxm_module_add_function(mod, "retrieve-cell-bearer-info", libmm_bearer_retrieve);

    SAH_TRACEZ_NOTICE(ME, "Module loaded");

exit:
    return retval;
}

static AMXM_DESTRUCTOR libmm_module_stop(void) {

    SAH_TRACEZ_NOTICE(ME, "Module stopped");

    libmm_exit();

    g_mutex_lock(&libmm_lock);
    amxc_llist_delete(&libmm_cell_ifaces, libmm_iface_delete);
    g_mutex_unlock(&libmm_lock);
    return 0;
}
