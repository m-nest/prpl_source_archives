/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxb/amxb_register.h>

#include "button.h"
#include "dm_button.h"
#include "mock.h"
#include "test_action.h"


#define BUTTON_TEST_DM_DEFAULTS "button_action.odl"

static amxd_dm_t dm;
static amxo_parser_t parser;

static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void handle_alarm(int sig) {
    printf("sig %d\n", sig);
}

static amxd_status_t invoke_release_fn(amxd_object_t* button_obj) {
    amxc_var_t args;
    amxc_var_t ret;
    int retval = amxd_status_unknown_error;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    retval = amxd_object_invoke_function(button_obj,
                                         "Release",
                                         &args,
                                         &ret);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return retval;
}

static amxd_status_t invoke_push_fn(amxd_object_t* button_obj) {
    amxc_var_t args;
    amxc_var_t ret;
    int retval = amxd_status_unknown_error;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    retval = amxd_object_invoke_function(button_obj,
                                         "Push",
                                         &args,
                                         &ret);

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return retval;
}

static amxd_status_t _TestMethod(amxd_object_t* button_object, UNUSED amxd_function_t* func, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    amxd_status_t retval = amxd_status_ok;
    when_null(button_object, exit);
    assert_int_equal(GET_UINT32(args, "arg1"), 12345);
    assert_string_equal(GET_CHAR(args, "arg2"), "arg2_value");

exit:
    return retval;
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;
    amxb_bus_ctx_t* bus_ctx = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);
    assert_int_equal(test_register_dummy_be(), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "button_event_changed", AMXO_FUNC(_button_event_changed));
    amxo_resolver_ftab_add(&parser, "button_event_added", AMXO_FUNC(_button_event_added));
    amxo_resolver_ftab_add(&parser, "button_event_removed", AMXO_FUNC(_button_event_removed));
    amxo_resolver_ftab_add(&parser, "Push", AMXO_FUNC(_Push));
    amxo_resolver_ftab_add(&parser, "Release", AMXO_FUNC(_Release));
    amxo_resolver_ftab_add(&parser, "TestMethod", AMXO_FUNC(_TestMethod));
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    assert_int_equal(amxo_connection_add(&parser, amxb_get_fd(bus_ctx), test_connection_read,
                                         "dummy:/tmp/dummy.sock", AMXO_BUS, bus_ctx), 0);

    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, BUTTON_TEST_DM_DEFAULTS, root_obj), 0);
    assert_int_equal(amxb_register(bus_ctx, &dm), 0);
    assert_int_equal(_button_main(AMXO_START, &dm, &parser), 0);

    signal(SIGALRM, handle_alarm);
    _button_app_start(NULL, NULL, NULL);
    wait_for_sigalarm(1);
    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_button_main(AMXO_STOP, &dm, &parser), 0);
    amxo_resolver_import_close_all();
    assert_int_equal(test_unregister_dummy_be(), 0);
    amxm_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_action_set(UNUSED void** state) {
    amxd_object_t* button_root = NULL;
    amxd_object_t* button_device = NULL;
    amxc_var_t params;

    amxc_var_init(&params);

    button_root = amxd_dm_findf(&dm, "Buttons.");
    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_root);
    assert_non_null(button_device);

    assert_int_equal(amxd_object_get_params(button_root, &params, amxd_dm_access_protected), 0);
    assert_int_equal(GET_UINT32(&params, "TestParameter"), 0);

    assert_int_equal(invoke_push_fn(button_device), amxd_status_ok);
    handle_events();
    wait_for_sigalarm(3);
    assert_int_equal(amxd_object_get_params(button_root, &params, amxd_dm_access_protected), 0);
    assert_int_equal(GET_UINT32(&params, "TestParameter"), 12345);

    assert_int_equal(invoke_release_fn(button_device), amxd_status_ok);
    handle_events();
    wait_for_sigalarm(1);
    assert_int_equal(amxd_object_get_params(button_root, &params, amxd_dm_access_protected), 0);
    assert_int_equal(GET_UINT32(&params, "TestParameter"), 55555);

    amxc_var_clean(&params);
}

void test_action_exec(UNUSED void** state) {
    amxd_object_t* button_root = NULL;
    amxd_object_t* button_device = NULL;

    button_root = amxd_dm_findf(&dm, "Buttons.");
    button_device = amxd_dm_findf(&dm, "Buttons.Button.Reset.");
    assert_non_null(button_root);
    assert_non_null(button_device);

    assert_int_equal(invoke_push_fn(button_device), amxd_status_ok);
    handle_events();
    wait_for_sigalarm(6);
}
