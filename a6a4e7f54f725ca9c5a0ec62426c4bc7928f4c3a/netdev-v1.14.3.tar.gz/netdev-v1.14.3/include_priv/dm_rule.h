/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__DM_RULE_H__)
#define __DM_RULE_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <net/if.h>

#include "netdev_util.h"
#include "dm_convert.h"

typedef struct _rule {
    amxc_llist_it_t it;
    unsigned char family;
    unsigned char dstlen;
    unsigned char srclen;
    unsigned char table;
    unsigned char src[ADDRSPACE];
    unsigned char dst[ADDRSPACE];
    char iif[IF_NAMESIZE];
    char oif[IF_NAMESIZE];
    unsigned int ipproto;
    unsigned int sport;
    unsigned int sport_max;
    unsigned int dport;
    unsigned int dport_max;
    unsigned int fwmark;
    unsigned int fwmask;
    unsigned int dyn_index;
    unsigned int index;
    bool active;
    amxp_timer_t* mercytimer;
    amxd_object_t* object;
} rule_t;

converter_t* init_rule_table_converter(void);
converter_t* init_rule_protocol_converter(void);
converter_t* init_rule_scope_converter(void);
converter_t* init_rule_type_converter(void);

amxd_status_t _rule_destroy(amxd_object_t* object,
                            amxd_param_t* param,
                            amxd_action_t reason,
                            const amxc_var_t* const args,
                            amxc_var_t* const retval,
                            void* priv);

rule_t* rule_find(rule_t* ref);
void rule_destroy(rule_t* rule, bool delete);
rule_t* rule_create(void);
int rule_copy(rule_t* dst, rule_t* src);
int msg2rule(rule_t* rule, rtnlmsg_t* msg);

amxd_trans_t* create_transaction_from_rule(rule_t* rule, bool new_inst);

int handle_new_rule(rtnlmsg_t* msg);
int handle_del_rule(rtnlmsg_t* msg);

void rule_init_converters(void);

bool rule_init(void);
bool rule_start(void);
void rule_cleanup(void);
void rule_clear(void);


#ifdef __cplusplus
}
#endif

#endif // __DM_RULE_H__

