/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "dm_gni_manager.h"
#include "gni_utils.h"

#define ME "gniutils"

/**
 * @brief Retrieves and updates the initial link state of a network device.
 *
 * This function queries the current state of a network interface using the AMXB bus context.
 * If the state is successfully retrieved, it updates the internal status of the interface.
 * If the state cannot be determined/invalid value, it defaults to "Unknown".
 * If the netdev interface is not available or removed, then its "NotPresent"
 *
 * @param[in] gni Pointer to the GNI (Generic Network Interface) information structure.
 * @param[in] ctx Pointer to the AMXB bus context used for querying the device state.
 *
 * @note This function uses SAH_TRACEZ macros for logging entry, exit, and errors.
 *       It also ensures proper cleanup of dynamically allocated strings and variables.
 */

static void netdev_link_get_initial_state(gni_info_t* gni, amxb_bus_ctx_t* ctx) {
    int rv = AMXB_ERROR_UNKNOWN;
    amxc_var_t data;
    const char* new_state = NULL;
    amxc_string_t rel_path;

    SAH_TRACEZ_IN(ME);
    amxc_string_init(&rel_path, 0);
    amxc_var_init(&data);

    when_null(gni, exit);

    if(ctx != NULL) {
        amxc_string_setf(&rel_path, "NetDev.Link.[Name==\"%s\"].State", gni->netdev_intf);
        rv = amxb_get(ctx, amxc_string_get(&rel_path, 0), 0, &data, 1);
        if(rv != AMXB_STATUS_OK) {
            SAH_TRACEZ_ERROR(ME, "NetDev link[%s] not found", gni->netdev_intf);
        } else {
            new_state = GETP_CHAR(&data, "0.0.State");
        }
    }
    if(new_state == NULL) {
        SAH_TRACEZ_ERROR(ME, "netdev status for %s could not be found", gni->netdev_intf);
        new_state = "notpresent";
    }

    gni_interface_status_update(gni, new_state);

exit:
    amxc_string_clean(&rel_path);
    amxc_var_clean(&data);
    SAH_TRACEZ_OUT(ME);
}
/**
 * @brief   Callback function for network device link state changes.
 *
 * @details This function is triggered upon changes to the network interface's link state.
 *          It receives signal metadata and related data payload, while the signal name
 *          and private data are marked as unused.
 *
 * @param   sig_name  Unused. Constant pointer to the name of the signal triggering the callback.
 * @param   data      Constant pointer to an AMXC variable containing link state information.
 * @param   priv      Pointer to private user-defined data, if applicable.
 */
static void _netdev_link_state_cb(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    SAH_TRACEZ_IN(ME);
    gni_info_t* gni = NULL;
    const char* new_state = NULL;
    const char* old_state = NULL;
    const char* notification = GET_CHAR(data, "notification");
    when_str_empty(notification, exit);

    SAH_TRACEZ_INFO(ME, "_netdev_link_state_cb Started");

    when_null_trace(priv, exit, ERROR, "private data should contain data");

    gni = (gni_info_t*) priv;

    SAH_TRACEZ_INFO(ME, "_netdev_link_state_cb signal %s", notification);

    if(strcmp(notification, "dm:instance-removed") == 0) {
        SAH_TRACEZ_INFO(ME, "_netdev_link_state_cb netdev interface removed");
        gni_interface_status_update(gni, "notpresent");
        goto exit;
    }

    old_state = GETP_CHAR(data, "parameters.State.from");

    when_null_trace(old_state, exit, ERROR, "old_state of netdev is NULL");

    new_state = GETP_CHAR(data, "parameters.State.to");

    when_null_trace(new_state, exit, ERROR, "new_state of netdev is NULL");

    SAH_TRACEZ_ERROR(ME, "%s State changed from %s to %s", gni->object->name, old_state, new_state);

    gni_interface_status_update(gni, new_state);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief   Retrieves the system uptime in seconds.
 *
 * @details This function uses the Linux `sysinfo` API to fetch the system's uptime.
 *          If the call fails, an error is logged and zero is returned as a fallback.
 *
 * @return  unsigned long  Number of seconds the system has been up since last boot.
 *                         Returns 0 if retrieval fails.
 */
unsigned long get_sysuptime(void) {
    struct sysinfo si;

    if(sysinfo(&si) != 0) {
        SAH_TRACEZ_ERROR(ME, "Error in sysinfo %d", errno);
        return ((unsigned long) 0);
    }

    return (unsigned long) (si.uptime);
}

/**
 * @brief   Creates a subscription to monitor network device link state changes.
 *
 * @details This function initializes a subscription expression for a specific network
 *          interface and sets up a link state monitoring mechanism. It verifies the
 *          interface name, locates the appropriate bus context, and constructs the
 *          expression to track link state parameter updates. If an existing subscription
 *          is present, it is safely deleted before proceeding.
 *
 * @param   gni  Pointer to a gni_info_t structure containing network interface details.
 */
void gni_subscribe_netdev_link_state(gni_info_t* gni) {
    SAH_TRACEZ_IN(ME);
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t expr;

    amxc_string_init(&expr, 0);

    when_null(gni, exit);

    when_str_empty_trace(gni->netdev_intf, exit, ERROR, "not a valid netdev interface");

    ctx = amxb_be_who_has("NetDev.");

    when_null_trace(ctx, exit, WARNING, "ctx not known, no subscription created");

    amxc_string_setf(&expr, "(eobject == 'NetDev.Link.[%s].' && "
                     "contains('parameters.State')) || "
                     "(notification == 'dm:instance-removed' && "
                     "eobject == 'NetDev.Link.' && contains('keys.Alias')"
                     "&& keys.Alias == '%s')",
                     gni->netdev_intf, gni->netdev_intf);

    if(gni->netdev_status_subscription != NULL) {
        amxb_subscription_delete(&(gni->netdev_status_subscription));
    }

    amxb_subscription_new(&(gni->netdev_status_subscription), ctx, "NetDev.Link.", amxc_string_get(&expr, 0), _netdev_link_state_cb, gni);

    when_null_trace(gni->netdev_status_subscription, exit, WARNING, "failed to create subscription");
    netdev_link_get_initial_state(gni, ctx);

exit:
    amxc_string_clean(&expr);
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief   Allocates and initializes a new GNI info structure.
 *
 * @details This function validates input parameters and creates a new
 *          `gni_info_t` instance. It checks for null or empty values in
 *          the network interface string, logs errors as needed, and
 *          allocates memory for the structure. The newly allocated
 *          structure is returned via the output pointer.
 *
 * @param   gni           Double pointer to the newly created `gni_info_t` structure.
 * @param   netdev_intf   Constant string representing the network device interface name.
 *
 * @return  amxd_status_t Status of the operation:
 *                        - `amxd_status_ok` on success
 *                        - `amxd_status_invalid_function_argument` if input is invalid
 *                        - Other relevant status codes on failure
 */
amxd_status_t gni_info_new(gni_info_t** gni, const char* netdev_intf) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_invalid_function_argument;

    when_null_trace(gni, exit, ERROR, "interface can not be null, invalid argument");

    when_str_empty(netdev_intf, exit);

    *gni = (gni_info_t*) calloc(1, sizeof(gni_info_t));

    when_null_status(*gni, exit, rv = amxd_status_out_of_mem);

    (*gni)->last_change = get_sysuptime();
    (*gni)->netdev_intf = strndup(netdev_intf, 64);

    when_null_status((*gni)->netdev_intf, clean, rv = amxd_status_unknown_error);

    rv = amxd_status_ok;

clean:
    if(rv != amxd_status_ok) {
        free(*gni);
        *gni = NULL;
    }
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief   Cleans up and deallocates the GNI info structure.
 *
 * @details This function safely frees resources associated with a `gni_info_t` instance.
 *          It checks for null pointers, deletes any active subscriptions related to
 *          network link state, frees the allocated interface string, and finally
 *          releases the memory for the `gni_info_t` structure itself.
 *
 * @param   gni  Double pointer to the `gni_info_t` structure to be cleaned up.
 *
 * @return  amxd_status_t  Status of the cleanup operation. Always returns `amxd_status_ok`.
 */
amxd_status_t gni_info_clean(gni_info_t** gni) {
    SAH_TRACEZ_IN(ME);
    if(!gni || !(*gni)) {
        goto exit;
    }

    free((*gni)->netdev_intf);
    amxb_subscription_delete(&(*gni)->netdev_status_subscription);
    amxb_subscription_delete(&(*gni)->netdev_new_link_subscription);
    free(*gni);

    *gni = NULL;

exit:
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

/**
 * @brief   Updates the interface status for a given GNI object.
 *
 * @details This function sets the status of the network interface by interpreting
 *          its current state and updating the corresponding AMXD object parameter.
 *          It validates input parameters and maps known `netdev_state` strings to
 *          internal status representations. Transactional updates are applied via
 *          the AMXD data model.
 *
 * @param   gni           Pointer to the `gni_info_t` structure containing interface metadata.
 * @param   netdev_state  Unused annotation applied. Const string representing the interface's raw status.
 *
 * @return  amxd_status_t  Status of the operation:
 *                         - `amxd_status_ok` on successful update
 *                         - `amxd_status_invalid_function_argument` if inputs are invalid
 *                         - Other relevant error codes depending on internal failures
 */
amxd_status_t gni_interface_status_update(gni_info_t* gni, const char* netdev_state) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxd_dm_t* dm = gni_get_dm();
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    const char* new_status = NULL;

    when_null_trace(gni, exit, ERROR, "gni info can not be NULL, can not change state");
    when_null_trace(gni->object, exit, ERROR, "object should not be NULL, can not change state");
    when_str_empty(netdev_state, exit);

    if(strcmp(netdev_state, "notpresent") == 0) {
        new_status = "NotPresent";
    } else if(strcmp(netdev_state, "down") == 0) {
        new_status = "Down";
    } else if(strcmp(netdev_state, "lowerlayerdown") == 0) {
        new_status = "LowerLayerDown";
    } else if(strcmp(netdev_state, "dormant") == 0) {
        new_status = "Dormant";
    } else if(strcmp(netdev_state, "up") == 0) {
        new_status = "Up";
    } else if(strcmp(netdev_state, "Error") == 0) {
        new_status = "Error";
    } else {
        new_status = "Unknown";
    }

    SAH_TRACEZ_INFO(ME, "GNI manager interface status: %s", netdev_state);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    amxd_trans_select_object(&trans, gni->object);

    amxd_trans_set_value(cstring_t, &trans, "Status", new_status);

    rv = amxd_trans_apply(&trans, dm);
    when_failed_trace(rv, exit, ERROR, "Problem applying data model transaction");

    gni->last_change = get_sysuptime();

exit:
    amxd_trans_clean(&trans);
    SAH_TRACEZ_OUT(ME);
    return rv;
}
