/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <amxc/amxc_variant.h>
#include <amxm/amxm.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_lqueue.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_types.h>
#include <amxp/amxp_slot.h>
#include <amxb/amxb_be_mngr.h>
#include <amxb/amxb.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "oopsmonitor.h"
#include "mod_parsing_default.h"

#define ME "def_parsing"

#define MINIMUM_LENGTH 6

int mod_get_process_ID(UNUSED const char* function_name,
                       amxc_var_t* data,
                       amxc_var_t* ret_data) {
    const char* line_log;
    int retval = 1;

    line_log = GET_CHAR(data, GET_PROCESS_ID_INPUT);

    when_str_empty(line_log, exit);

    when_true_trace(strlen(line_log) < 5, exit, ERROR, "Oops parsing isn't possible, unexpected format");

    if(strncmp("CPU: ", line_log, 5) == 0) {
        char* process_ID = NULL;

        process_ID = calloc(strlen(line_log) + 1, sizeof(char));

        when_null(process_ID, exit);

        if(sscanf(line_log, "CPU: %*d PID: %*d Comm: %s Tainted:", process_ID) > 0) {
            SAH_TRACEZ_INFO(ME, "process: %s", process_ID);
            amxc_var_add_key(cstring_t, ret_data, GET_PROCESS_ID_OUTPUT, process_ID);
            retval = 0;
        }

        free(process_ID);
    }

exit:
    return retval;
}

int mod_get_last_instruction(UNUSED const char* function_name,
                             amxc_var_t* data,
                             amxc_var_t* ret_data) {
    const char* line_log = NULL;
    int retval = 1;

    line_log = GET_CHAR(data, GET_LAST_INSTRUCTION_INPUT);

    when_str_empty(line_log, exit);

    when_true_trace(strlen(line_log) < 5, exit, ERROR, "Oops parsing isn't possible, unexpected format");

    if(strncasecmp("LR : ", line_log, 5) == 0) {
        SAH_TRACEZ_INFO(ME, "lastinstr: %s", line_log + 5);
        amxc_var_add_key(cstring_t, ret_data, GET_LAST_INSTRUCTION_OUTPUT, line_log + 5);
        retval = 0;
    }

exit:
    return retval;
}

int mod_get_reason(UNUSED const char* function_name,
                   amxc_var_t* data,
                   amxc_var_t* ret_data) {
    const char* line_log = NULL;
    int retval = 1;

    /* Mention more specific reasons first. */
    static const struct {const char* msg; const char* name;} REASONS[] = {
        {" invoked oom-killer:", "oom"},
        {"Kernel panic - not syncing: Out of memory", "oom"},
        {"Kernel panic - not syncing: sysrq triggered crash", "SysRq triggered crash"},
        {"SysRq : Trigger a crash", "SysRq triggered crash"},
        {"Unable to handle kernel NULL pointer dereference", "null pointer"},
        {"Unable to handle kernel paging request", "paging request"},
        {"Kernel panic - not syncing: Fatal exception", "fatal exception"},
    };

    line_log = GET_CHAR(data, GET_REASON_INPUT);

    when_str_empty(line_log, exit);

    for(size_t i = 0; i < sizeof(REASONS) / sizeof(*REASONS); i++) {
        if(NULL != strstr(line_log, REASONS[i].msg)) {
            SAH_TRACEZ_INFO(ME, "reason: %s", REASONS[i].name);
            amxc_var_add_key(cstring_t, ret_data, GET_REASON_OUTPUT, REASONS[i].name);
            retval = 0;
            break;
        }
    }

exit:
    return retval;
}

int mod_get_useful_log(UNUSED const char* function_name,
                       amxc_var_t* data,
                       amxc_var_t* ret_data) {
    const char* line_log = NULL;
    char* useful_log = NULL;
    int retval = 1;

    line_log = GET_CHAR(data, GET_USEFUL_LOG_INPUT);
    when_str_empty(line_log, exit);

    when_true_trace(strlen(line_log) < MINIMUM_LENGTH, exit, ERROR, "Oops parsing isn't possible, unexpected format");

    //Format = '<x>[timestamp] LOG', x (log level) can be on 2 digit
    if((strncmp(">[", line_log + 2, 2) == 0) || (strncmp(">[", line_log + 3, 2) == 0)) {
        useful_log = strchr(line_log + 4, ']');
        when_null(useful_log, exit);
        if(strlen(useful_log) < 2) {
            SAH_TRACEZ_ERROR(ME, "Oops parsing isn't possible, unexpected format");
            goto exit;
        }
        useful_log += 2;
        amxc_var_add_key(cstring_t, ret_data, GET_USEFUL_LOG_OUTPUT, useful_log);
        retval = 0;
    }

exit:
    return retval;
}

static AMXM_CONSTRUCTOR parsing_default_start(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    int ret = 1;

    amxm_module_register(&mod, so, MODULE_NAME);
    ret = amxm_module_add_function(mod, GET_PROCESS_ID_FUNC, mod_get_process_ID);
    ret |= amxm_module_add_function(mod, GET_LAST_INSTRUCTION_FUNC, mod_get_last_instruction);
    ret |= amxm_module_add_function(mod, GET_REASON_FUNC, mod_get_reason);
    ret |= amxm_module_add_function(mod, GET_USEFUL_LOG_FUNC, mod_get_useful_log);

    return ret;
}

static AMXM_DESTRUCTOR parsing_default_stop(void) {
    return 0;
}
