/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "flash_health.h"
#include "emmc_health.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#define ME "emmc"

/**
 * @brief Removes the trailing newline character from a string, if present.
 *
 * @param str Pointer to the null-terminated string to be trimmed.
 */
void trim_newline(char* str) {
    size_t len = strlen(str);
    if(len && (str[len - 1] == '\n')) {
        str[len - 1] = '\0';
    }
}

/**
 * @var const char *lifetimeStr[]
 * @brief String representations for eMMC device lifetime usage levels.
 */
const char* lifetimeStr[] =
{
    "Not Defined",
    "0% - 10% device life time used",
    "10% - 20% device life time used",
    "20% - 30% device life time used",
    "30% - 40% device life time used",
    "40% - 50% device life time used",
    "50% - 60% device life time used",
    "60% - 70% device life time used",
    "70% - 80% device life time used",
    "80% - 90% device life time used",
    "90% - 100% device life time used",
    "Exceeded its maximum estimated device life time",
    "Reserved"
};

/**
 * @var const char *preEolStr[]
 * @brief String representations for eMMC pre-EOL (End Of Life) information.
 */
const char* preEolStr[] =
{
    "Not Defined",
    "Normal",
    "Warning",
    "Urgent",
    "Reserved"
};

/**
 * @brief Converts a lifetime hex value to its corresponding string representation.
 *
 * @param hex The hex value representing device lifetime usage.
 * @param hexstr Pointer to the buffer where the string representation will be stored.
 */
void convert_lifetimehex_to_string (uint8_t hex, char* hexstr) {
    SAH_TRACEZ_IN(ME);
    if(hexstr == NULL) {
        return;
    }
    if(hex <= 0x0B) {
        strcpy(hexstr, lifetimeStr [hex]);
    } else {
        strcpy(hexstr, "Reserved");
    }
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Converts a pre-EOL hex value to its corresponding string representation.
 *
 * @param hex The hex value representing pre-EOL information.
 * @param hexstr Pointer to the buffer where the string representation will be stored.
 */
void convert_preeolinfo_to_string (uint8_t hex, char* hexstr) {
    SAH_TRACEZ_IN(ME);
    if(hexstr == NULL) {
        return;
    }
    if(hex <= 0x03) {
        strcpy(hexstr, preEolStr [hex]);
    } else {
        strcpy(hexstr, "Reserved");
    }
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Compares the current eMMC health values against configured thresholds and sets the health status.
 *
 * @param fh Pointer to the flash_health_t structure containing health information and thresholds.
 */
void emmc_compare_thresholds (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    FlashHealthStatus status = HEALTH_STATUS_NORMAL;
    if(fh == NULL) {
        return;
    }

    if((fh->preEolHex != 0) && (fh->preEolHex >= fh->preEolThreshold)) {
        status = HEALTH_STATUS_CRITICAL;
    }
    if((fh->lifeTimeAHex != 0) && (fh->lifeTimeAHex >= (fh->lifeTimeAThreshold))) {
        status = HEALTH_STATUS_CRITICAL;
    }
    if((fh->lifeTimeBHex != 0) && (fh->lifeTimeBHex >= (fh->lifeTimeBThreshold))) {
        status = HEALTH_STATUS_CRITICAL;
    }
    set_health_status(fh, status);
    SAH_TRACEZ_OUT(ME);
}

/**
 * @brief Retrieves eMMC lifetime and pre-EOL information from EXT_CSD register.
 *
 * Reads EXT_CSD register from the eMMC device, extracts lifetime and pre-EOL values,
 * and updates the flash_health_t structure.
 *
 * @param fh Pointer to the flash_health_t structure to be updated.
 * @return 0 on success, -1 on failure.
 */
int32_t flash_health_emc_get_lifetime (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    char path[BUFFER_SIZE], buffer[BUFFER_SIZE];
    if(fh == NULL) {
        return false;
    }
    const char* base_name = strrchr(fh->path, '/');
    if(!base_name || (strncmp(base_name + 1, "mmc", 3) != 0)) {
        SAH_TRACEZ_ERROR(ME, "Invalid eMMC device path: %s", fh->path);
        return false;
    }
    char mmc_name[32];
    strncpy(mmc_name, base_name + 1, sizeof(mmc_name) - 1);
    mmc_name[sizeof(mmc_name) - 1] = '\0';

    // Read pre_eol_info
    snprintf(path, sizeof(path), "%s%s/device/pre_eol_info", SYS_BLOCK_PATH, mmc_name);
    FILE* eol = fopen(path, "rb");
    if(eol) {
        if(fgets(buffer, sizeof(buffer), eol) != NULL) {
            trim_newline(buffer);
            sscanf(buffer, "0x%hhx", &(fh->preEolHex));
            fclose(eol);
        }
    } else {
        fh->preEolHex = 0xFF;
    }

    // Read life_time
    snprintf(path, sizeof(path), "%s%s/device/life_time", SYS_BLOCK_PATH, mmc_name);
    FILE* life = fopen(path, "rb");
    if(life) {
        if(fgets(buffer, sizeof(buffer), life) != NULL) {
            trim_newline(buffer);
            sscanf(buffer, "0x%hhx 0x%hhx", &(fh->lifeTimeAHex), &(fh->lifeTimeBHex));
            fclose(life);
        }
    } else {
        fh->lifeTimeAHex = 0xFF;
        fh->lifeTimeBHex = 0xFF;
    }

    convert_lifetimehex_to_string(fh->lifeTimeAHex, fh->lifeTimeA);
    convert_lifetimehex_to_string(fh->lifeTimeBHex, fh->lifeTimeB);
    convert_preeolinfo_to_string(fh->preEolHex, fh->emmcPreEolInfo);

    SAH_TRACEZ_OUT(ME);
    return 0;
}

/**
 * @brief Checks the eMMC health by reading EXT_CSD and updating health status.
 *
 * @param fh Pointer to the flash_health_t structure to be checked and updated.
 */
void fh_emmc_check (flash_health_t* fh) {
    SAH_TRACEZ_IN(ME);
    if(fh == NULL) {
        return;
    }
    if(flash_health_emc_get_lifetime(fh) == 0) {
        emmc_compare_thresholds(fh);
    } else {
        SAH_TRACEZ_ERROR(ME, "Error in retrieving Flash health check");
    }
    SAH_TRACEZ_OUT(ME);
}
