/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>

#include "qos-assert.h"
#include "dm_tr181-qos.h"
#include "qos-config.h"

#include "test_qos_config.h"

static amxd_dm_t dm;
static amxo_parser_t parser;
static const char* odl_defs = "qos_config_test.odl";

static void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
}

int test_qos_config_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    assert_int_equal(amxo_resolver_ftab_add(&parser, "qos_main",
                                            AMXO_FUNC(_qos_main)), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);

    _qos_main(0, &dm, &parser);
    _qos_app_start(NULL, NULL, NULL);
    handle_events();

    return 0;
}

int test_qos_config_teardown(UNUSED void** state) {
    _qos_main(1, &dm, &parser);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_qos_config_get_iptables_target(UNUSED void** state) {
    const char* target = NULL;

    assert_string_equal(QOS_CONFIG_IPTABLES_PREROUTING_TARGET, "prerouting-target");
    assert_string_equal(QOS_CONFIG_IPTABLES_FORWARD_TARGET, "forward-target");
    assert_string_equal(QOS_CONFIG_IPTABLES_POSTROUTING_TARGET, "postrouting-target");
    assert_string_equal(QOS_CONFIG_IPTABLES_OUTPUT_TARGET, "output-target");

    target = qos_config_get_iptables_target(NULL);
    assert_null(target);

    target = qos_config_get_iptables_target("non_existing_option");
    assert_null(target);

    target = qos_config_get_iptables_target(QOS_CONFIG_IPTABLES_PREROUTING_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "PREROUTING_class");

    target = qos_config_get_iptables_target(QOS_CONFIG_IPTABLES_FORWARD_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "FORWARD_class");

    target = qos_config_get_iptables_target(QOS_CONFIG_IPTABLES_POSTROUTING_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "POSTROUTING_class");

    target = qos_config_get_iptables_target(QOS_CONFIG_IPTABLES_OUTPUT_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "OUTPUT_class");
}

void test_qos_config_get_ip6tables_target(UNUSED void** state) {
    const char* target = NULL;

    assert_string_equal(QOS_CONFIG_IP6TABLES_PREROUTING_TARGET, "prerouting6-target");
    assert_string_equal(QOS_CONFIG_IP6TABLES_FORWARD_TARGET, "forward6-target");
    assert_string_equal(QOS_CONFIG_IP6TABLES_POSTROUTING_TARGET, "postrouting6-target");
    assert_string_equal(QOS_CONFIG_IP6TABLES_OUTPUT_TARGET, "output6-target");

    target = qos_config_get_ip6tables_target(NULL);
    assert_null(target);

    target = qos_config_get_ip6tables_target("non_existing_option");
    assert_null(target);

    target = qos_config_get_ip6tables_target(QOS_CONFIG_IP6TABLES_PREROUTING_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "PREROUTING6_class");

    target = qos_config_get_ip6tables_target(QOS_CONFIG_IP6TABLES_FORWARD_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "FORWARD6_class");

    target = qos_config_get_ip6tables_target(QOS_CONFIG_IP6TABLES_POSTROUTING_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "POSTROUTING6_class");

    target = qos_config_get_ip6tables_target(QOS_CONFIG_IP6TABLES_OUTPUT_TARGET);
    assert_non_null(target);
    assert_string_equal(target, "OUTPUT6_class");
}

void test_qos_config_get_prefixed_parameter(UNUSED void** state) {
    amxc_string_t* result = NULL;

    result = qos_config_get_prefixed_parameter(NULL);
    assert_null(result);

    result = qos_config_get_prefixed_parameter("");
    assert_null(result);

    result = qos_config_get_prefixed_parameter("Direction");
    assert_non_null(result);
    assert_string_equal(amxc_string_get(result, 0), "X_TEST-COM_Direction");

    amxc_string_delete(&result);
}

void test_qos_config_get_name(UNUSED void** state) {
    assert_string_equal(qos_config_get_name(), "tr181-qos");
}
