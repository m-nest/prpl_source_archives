/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <cmocka.h>

#include "common.h"

#define HASH_LEN 65

const char* flatten_xml(const char* filename) {
    FILE* f = NULL;
    int first = 1;
    size_t linesize = 0;
    size_t result_len = 0;
    size_t addlen = 0;
    char* line = NULL;
    char* start = NULL;
    char* end = NULL;
    char* result = NULL;
    const char* out = "/tmp/expected_message_sent_flat.xml";

    if(!filename || !*filename) {
        return out;
    }

    f = fopen(filename, "r");
    if(!f) {
        return out;
    }

    while(getline(&line, &linesize, f) != -1) {
        start = line;
        if(first) {
            first = 0;
        } else {
            /* Remove leading/trailing whitespace */
            while(*start == ' ' || *start == '\t' || *start == '\n' || *start == '\r') {
                start++;
            }
            end = start + strlen(start) - 1;
            while(end > start && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r')) {
                *end-- = '\0';
            }
        }
        addlen = strlen(start);

        result = realloc(result, result_len + addlen + 1);
        if(!result) {
            goto exit;
        }

        memcpy(result + result_len, start, addlen);
        result_len += addlen;
        result[result_len] = '\0';
    }

    /* add newline at the end */
    result = realloc(result, result_len + 2);
    if(!result) {
        goto exit;
    }
    result[result_len++] = '\n';
    result[result_len] = '\0';


    /* Write the flattened XML content to the file */
    fclose(f);
    f = fopen(out, "w");
    if(!f) {
        goto exit;
    }
    fputs(result, f);
exit:
    free(line);
    fclose(f);
    free(result);
    return out;
}

static void get_sha256(const char* filename, char* out_hash) {
    char command[512];
    FILE* fp = NULL;
    snprintf(command, sizeof(command), "sha256sum \"%s\"", filename);
    fp = popen(command, "r");
    if(!fp) {
        print_message("popen failed");
        return;
    }
    if(fscanf(fp, "%64s", out_hash) != 1) {
        print_message("Failed to read SHA256 hash\n");
        pclose(fp);
        return;
    }
    pclose(fp);
}

int compare_files_sha256(const char* file1, const char* file2) {
    int retval = 0;
    char hash1[HASH_LEN], hash2[HASH_LEN];
    get_sha256(file1, hash1);
    get_sha256(file2, hash2);
    retval = strcmp(hash1, hash2);
    if(retval != 0) {
        print_message("Files differ: %s != %s\n", file1, file2);
    }
    return retval;
}