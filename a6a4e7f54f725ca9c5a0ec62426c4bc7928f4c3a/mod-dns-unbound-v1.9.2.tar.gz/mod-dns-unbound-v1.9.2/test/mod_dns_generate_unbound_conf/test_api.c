/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <string.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>

#include "test_generate_unbound_conf.h"
#include "modunbound.h"

#define MOD_UNBOUND NULL // NULL -> amxm namespace of current process because module is not ".so" file in unit tests

static struct {
    const char* iface;
    bool added;
} ifaces[] = {
    {"br-lan", false},
    {"br-guest", false},
};
static const int sizeof_ifaces = ARRAY_SIZE(ifaces);

static struct {
    const char* name;
    const char* zone;
    bool added;
} servers[] = {
    {"srv-1", ".", false},
    {"foo", ".", false},
    // limitation: if you add an entry with zone != "." then be aware that set-server always uses zone "."
};
static const int sizeof_servers = ARRAY_SIZE(servers);

static struct {
    const char* name;
    const char* iface;
    const char* list_ipv4;
    const char* list_ipv6;
    bool added;
} hosts[] = {
    {"laptop", "br-lan", "192.168.1.100,192.168.1.101", "fe80::100,fe80::101", false},
    {"laptop", "br-guest", "192.168.2.100,192.168.2.101", "fe80::2:100,fe80::2:101", false},
    {"printer", "br-lan", "192.168.1.105,192.168.1.106", "fe80::105,fe80::106", false},
    {"printer", "br-guest", "192.168.2.105,192.168.2.106", "fe80::2:105,fe80::2:106", false},
};
static const int sizeof_hosts = ARRAY_SIZE(hosts);

static struct {
    const char* domains;
    const char* ip;
    bool enabled;
} protections[] = {
    {"192.168.18.0/24,192.168.5.0/24", "example.com,example.org", true},
    {"192.168.18.0/24,192.168.5.0/24", "example.com,example.org", false},
    {"", "example.com,example.org", true},
    {"192.168.18.0/24,192.168.5.0/24", "", true},
    {"", "", true},
    {"", "example.com,example.org", false},
    {"192.168.18.0/24,192.168.5.0/24", "", false},
    {"", "", false},
};
static const int sizeof_protections = ARRAY_SIZE(protections);

static const char* options[] = {
    "[\"log-queries: yes\", \"log-replies: yes\", \"verbosity: 1\"]",
    "[]"
    "",
    NULL,
};
static const int sizeof_options = ARRAY_SIZE(options);

static struct {
    int ttl_max;
    int ttl_min;
    int cache_size;
} cache[] = {
    {0, 0, 0},
    {-1, -1, -1},
    {1000, 1000, 1000},
    {100, 200, 1000},
    {200, 100, 1000},
    {200, 0, 1000},
    {0, 200, 1000},
};
static const int sizeof_cache = ARRAY_SIZE(cache);

static bool enabled = true;

static const char* domains[] = {
    "{\"interface\":\"br-lan\",\"domain_name\":\"home\"}",
    "{\"interface\":\"br-lan\",\"domain_name\":\"com\"}",
    "{\"interface\":\"br-lan\",\"domain_name\":\"\"}",    // allowed
    "{\"interface\":\"br-lan\"}",                         // not allowed
    "{\"interface\":\"\",\"domain_name\":\"\"}",          // not allowed
    "{\"interface\":\"\",\"domain_name\":\"home\"}",      // not allowed
    "{\"domain_name\":\"home\"}",                         // not allowed
    NULL,
};
static const int sizeof_domains = ARRAY_SIZE(domains);

static bool set_iface(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    i %= sizeof_ifaces;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "interface", ifaces[i].iface);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "set-interface", &args, &ret);
    amxut_bus_handle_events();
    if(rv == 0) {
        ifaces[i].added = true;
    }

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool remove_iface(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;
    bool expect_ok = false;

    i %= sizeof_ifaces;
    expect_ok = ifaces[i].added;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "interface", ifaces[i].iface);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "remove-interface", &args, &ret);
    amxut_bus_handle_events();

    ifaces[i].added = false;

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

static bool set_server(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* table = NULL;
    amxc_var_t* server = NULL;
    int rv = 0;

    i %= sizeof_servers;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &args, "enable", true);
    amxc_var_add_key(int32_t, &args, "timeout", -1);
    amxc_var_add_key(int32_t, &args, "repeat", -1);
    table = amxc_var_add_key(amxc_htable_t, &args, "servers", NULL);
    assert_non_null(table);
    server = amxc_var_add_key(amxc_htable_t, table, servers[i].name, NULL);
    amxc_var_add_key(cstring_t, server, "server", "8.8.8.8");

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "set-server", &args, &ret);
    amxut_bus_handle_events();
    if(rv == 0) {
        for(int j = 0; j < sizeof_servers; j++) {
            if(strcmp(servers[i].zone, servers[j].zone) != 0) {
                continue;
            }
            servers[j].added = false; // with set-server only 1 server can be active in zone
        }
        servers[i].added = true;
    }

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool add_server(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;
    bool expect_ok = false;

    i %= sizeof_servers;
    expect_ok = !servers[i].added;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", servers[i].name);
    amxc_var_add_key(cstring_t, &args, "zone_name", servers[i].zone);
    amxc_var_add_key(cstring_t, &args, "server", "8.8.8.8");
    amxc_var_add_key(bool, &args, "enable", true);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "add-server", &args, &ret);
    amxut_bus_handle_events();
    if(rv == 0) {
        servers[i].added = true;
    }

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

static bool remove_server(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;
    bool expect_ok = false;

    i %= sizeof_servers;
    expect_ok = servers[i].added;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", servers[i].name);
    amxc_var_add_key(cstring_t, &args, "zone_name", servers[i].zone);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "remove-server", &args, &ret);
    amxut_bus_handle_events();
    servers[i].added = false;

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

/**
 * helper for add-host and set-host as they share a common api
 */
static int set_host_impl(const char* function, int i) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* addresses = NULL;
    amxc_var_t list;
    int rv = 0;

    i %= sizeof_hosts;

    amxc_var_init(&args);
    amxc_var_init(&list);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", hosts[i].name);
    amxc_var_add_key(cstring_t, &args, "interface", hosts[i].iface);

    addresses = amxc_var_add_key(amxc_llist_t, &args, "ipv4_addresses", NULL);
    amxc_var_set(csv_string_t, &list, hosts[i].list_ipv4);
    amxc_var_cast(&list, AMXC_VAR_ID_LIST);
    amxc_var_move(addresses, &list);

    addresses = amxc_var_add_key(amxc_llist_t, &args, "ipv6_addresses", NULL);
    amxc_var_set(csv_string_t, &list, hosts[i].list_ipv6);
    amxc_var_cast(&list, AMXC_VAR_ID_LIST);
    amxc_var_move(addresses, &list);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", function, &args, &ret);
    amxut_bus_handle_events();
    if(rv == 0) {
        hosts[i].added = true;
    }

    amxc_var_clean(&args);
    amxc_var_clean(&list);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool set_host(int i) {
    return set_host_impl("set-host", i);
}

static bool add_host(int i) {
    return set_host_impl("add-host", i);
}

static bool remove_host(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;
    bool expect_ok = false;

    i %= sizeof_hosts;
    expect_ok = hosts[i].added;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", hosts[i].name);
    amxc_var_add_key(cstring_t, &args, "interface", hosts[i].iface);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "remove-host", &args, &ret);
    amxut_bus_handle_events();

    hosts[i].added = false;

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

static bool remove_host_address(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* addresses = NULL;
    int rv = 0;
    amxc_var_t* backend_host = NULL;
    char key[200] = {0};
    bool ipv4 = (rand() % 2) == 0;
    bool expect_ok = false;

    i %= sizeof_hosts;

    // I tried to limit the usage of testhelper_get_config but for this test I have to know which addresses are still in use (not removed yet by this function)
    snprintf(key, sizeof(key), "views.%s.hosts.%s.", hosts[i].iface, hosts[i].name);
    backend_host = GETP_ARG(testhelper_get_config(NULL), key);

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "name", hosts[i].name);
    amxc_var_add_key(cstring_t, &args, "interface", hosts[i].iface);

    addresses = amxc_var_add_key(amxc_llist_t, &args, "ipv4_addresses", NULL);
    if(ipv4) {
        const char* first = GETP_CHAR(backend_host, "ipv4_addresses.0");
        if(first != NULL) {
            amxc_var_add(cstring_t, addresses, first);
            expect_ok = true;
        }
    }

    addresses = amxc_var_add_key(amxc_llist_t, &args, "ipv6_addresses", NULL);
    if(!ipv4) {
        const char* first = GETP_CHAR(backend_host, "ipv6_addresses.0");
        if(first != NULL) {
            amxc_var_add(cstring_t, addresses, first);
            expect_ok = true;
        }
    }

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "remove-host-address", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

static bool enable_changed(UNUSED int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "enable-changed", &args, &ret);
    amxut_bus_handle_events();

    enabled = false;

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool set_options(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    i %= sizeof_options;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    if(options[i] != NULL) {
        assert_int_equal(amxc_var_set(jstring_t, &args, options[i]), 0);
    }

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "set-options", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool set_cache(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    i %= sizeof_cache;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "interface", "lo");
    amxc_var_add_key(uint32_t, &args, "ttl_max", cache[i].ttl_max);
    amxc_var_add_key(uint32_t, &args, "ttl_min", cache[i].ttl_min);
    amxc_var_add_key(uint32_t, &args, "cache_size", cache[i].cache_size);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "set-cache", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool flush_cache(UNUSED int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "interface", "lo");

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "flush-cache", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0; // unbound is not running
}

static bool rebind_changed(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;

    i %= sizeof_protections;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &args, "Enable", protections[i].enabled);
    amxc_var_add_key(csv_string_t, &args, "DomainExceptions", protections[i].domains);
    amxc_var_add_key(csv_string_t, &args, "IPExceptions", protections[i].ip);

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "rebind-changed", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == 0;
}

static bool set_domain_name(int i) {
    amxc_var_t args;
    amxc_var_t ret;
    int rv = 0;
    bool expect_ok = false;
    const char* iface = NULL;

    i %= sizeof_domains;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    if(domains[i] != NULL) {
        assert_int_equal(amxc_var_set(jstring_t, &args, domains[i]), 0);
        iface = GET_CHAR(&args, "interface");
        if(!STRING_EMPTY(iface) &&
           (GET_CHAR(&args, "domain_name") != NULL)) {
            expect_ok = true;
        }
    }

    rv = amxm_execute_function(MOD_UNBOUND, "dns", "set-domain-name", &args, &ret);
    amxut_bus_handle_events();

    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    return rv == (expect_ok ? 0 : -1);
}

test_api_t set1[] = {
    set_iface,
    remove_iface,
    set_server,
    add_server,
    remove_server,
    set_host,
    add_host,
    remove_host,
    remove_host_address,
    enable_changed,
    set_options,
    set_cache,
    flush_cache,
    rebind_changed,
    set_domain_name,
};

const int sizeof_set1 = ARRAY_SIZE(set1);