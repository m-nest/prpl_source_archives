/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "lcm/lcm_remote_object.h"

#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <limits.h>
#include <errno.h>

#include <debug/sahtrace.h>
#include <amxb/amxb.h>
#include <amxb/amxb_be_intf.h>
#include "lcm/lcm_assert.h"
#include "lcm/lcm_helpers.h"

#define ME "remote_object"

#define TIMEOUT 5

/* function declarations */
static int lcm_remote_object_probe(remote_object_t* remote_object);
static void lcm_remote_available_event(const char* const sig_name,
                                       const amxc_var_t* const data,
                                       void* priv);

/**
 * @brief Removes the trailing dot from a path string if present.
 *
 * @param path The path string to modify.
 * @return The modified path string.
 */
static char* path_remove_trailing_dot(char* path) {
    if(STRING_EMPTY(path)) {
        return path;
    }
    size_t len = strlen(path);
    if(path[len - 1] == '.') {
        path[len - 1] = '\0';
    }
    return path;
}

/**
 * @brief Creates a new remote object structure.
 *
 * @param remote_object Pointer to the remote object pointer to allocate.
 * @param object_dm_name The data model name for the object.
 * @return 0 on success, -1 on failure.
 */
static int remote_object_new(remote_object_t** remote_object, const char* object_dm_name) {
    int res = -1;
    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(object_dm_name, goto exit);

    *remote_object = (remote_object_t*) calloc(1, sizeof(remote_object_t));
    ASSERT_NOT_NULL(*remote_object, goto exit);
    (*remote_object)->bus_ctx = NULL;
    (*remote_object)->object_dm_name = strdup(object_dm_name);

    res = 0;
exit:
    return res;
}

/**
 * @brief Deletes a remote object structure and frees its resources.
 *
 * @param remote_object Pointer to the remote object pointer to delete.
 */
static void remote_object_delete(remote_object_t** remote_object) {
    ASSERT_NOT_NULL(remote_object, return );
    ASSERT_NOT_NULL((*remote_object), return );

    free((*remote_object)->object_dm_name);
    free_null(*remote_object);
}

/**
 * @brief Get the wait event name
 *
 * This is the event that will be sent by the datamodel when an object
 * appears on the bus
 *
 * if object_dm_name is "Users" then this function will return "wait:Users"
 *
 * @param object_dm_name object name
 * @return char* wait event
 */
static char* get_wait_event(const char* object_dm_name) {
    char* wait_event = NULL;
    const char* wait = "wait:";
    wait_event = malloc(strlen(wait) + strlen(object_dm_name) + 1);
    if(sprintf(wait_event, "%s%s", wait, object_dm_name) < 0) {
        SAH_TRACEZ_ERROR(ME, "Could not create string");
        free_null(wait_event);
    }
    return wait_event;
}

/**
 * @brief Unsubscribe from the event of an object appearing on the bus
 *
 * @param remote_object
 */
static void lcm_remote_unsubscribe_wait_event(remote_object_t* remote_object) {
    ASSERT_NOT_NULL(remote_object, return );
    char* wait_event = get_wait_event(remote_object->object_dm_name);
    ASSERT_NOT_NULL(wait_event, return );
    amxp_slot_disconnect(NULL, wait_event, lcm_remote_available_event);
    free(wait_event);

}

/**
 * @brief Callback when a specific object appears on the bus
 *
 * @param sig_name the name of the signal
 * @param data the data of the signal
 * @param priv a pointer to some data, provided when connecting
 */
static void lcm_remote_available_event(UNUSED const char* const sig_name,
                                       UNUSED const amxc_var_t* const data,
                                       void* priv) {
    ASSERT_NOT_NULL(priv, return );
    remote_object_t* remote_object = (remote_object_t*) priv;

    lcm_remote_object_probe(remote_object);
    lcm_remote_unsubscribe_wait_event(remote_object);
}

/**
 * @brief Wait for a remote object to appear on the bus
 *
 * @param remote_object
 * @return int
 */
static int lcm_remote_wait_and_connect(remote_object_t* remote_object) {
    int res = -1;
    char* wait_event = NULL;
    ASSERT_NOT_NULL(remote_object, goto exit);
    wait_event = get_wait_event(remote_object->object_dm_name);
    ASSERT_NOT_NULL(wait_event, goto exit);

    ASSERT_SUCCESS(amxp_slot_connect_filtered(NULL, wait_event, NULL, lcm_remote_available_event, remote_object),
                   goto exit, "[%s] Could not subscribe to wait event", remote_object->object_dm_name);

    amxb_wait_for_object(remote_object->object_dm_name);
    res = 0;
exit:
    free(wait_event);
    return res;
}

/**
 * @brief Callback when an object is deleted on the bus
 *
 * @param sig_name the name of the signal
 * @param data the data of the signal
 * @param priv a pointer to some data, provided when connecting
 */
static void connection_deleted_callback(UNUSED const char* const sig_name,
                                        const amxc_var_t* const data,
                                        void* priv) {
    ASSERT_NOT_NULL(priv, return );
    remote_object_t* remote_object = (remote_object_t*) priv;
    if(amxc_var_type_of(data) != AMXC_VAR_ID_FD) {
        return;
    }

    if(remote_object->bus_ctx && (amxb_get_fd(remote_object->bus_ctx) == amxc_var_dyncast(fd_t, data))) {
        SAH_TRACEZ_WARNING(ME, "[%s] Connection to bus lost", remote_object->object_dm_name);
        remote_object->bus_ctx = NULL;
    }
}

/**
 * @brief Callback when an remoe object app stops
 *
 * @param sig_name the name of the signal
 * @param data the data of the signal
 * @param priv a pointer to some data, provided when connecting
 */
static void remote_app_stopped(UNUSED const char* const sig_name,
                               UNUSED const amxc_var_t* const data,
                               void* const priv) {
    ASSERT_NOT_NULL(priv, return );
    remote_object_t* remote_object = (remote_object_t*) priv;
    SAH_TRACEZ_NOTICE(ME, "[%s] app stopped, trying to recover when it gets back up", remote_object->object_dm_name);
    remote_object->bus_ctx = NULL;
    lcm_remote_wait_and_connect(remote_object);
}

/**
 * @brief Get the remote bus context.
 *
 * @param remote_object
 * @return int
 */
static int lcm_remote_busctx_fetch(remote_object_t* remote_object) {
    int res = -1;
    ASSERT_NOT_NULL(remote_object, goto exit);
    CHECK_NOT_NULL_LOG(NOTICE, remote_object->bus_ctx, res = 0; goto exit, "[%s] Remote object is already fetched", remote_object->object_dm_name);
    remote_object->bus_ctx = amxb_be_who_has_ex(remote_object->object_dm_name, true);
    CHECK_NULL_LOG(WARNING, remote_object->bus_ctx, goto exit, "[%s] Remote object is not present in the datamodel", remote_object->object_dm_name);
    amxp_slot_connect(NULL, "connection-deleted", NULL, connection_deleted_callback, remote_object);
    res = 0;
exit:
    return res;
}

/**
 * @brief Probes for the remote object and sets up subscriptions.
 *
 * @param remote_object The remote object to probe.
 * @return 0 on success, -1 on failure.
 */
static int lcm_remote_object_probe(remote_object_t* remote_object) {
    int res = -1;

    CHECK_FAILURE_LOG(WARNING, lcm_remote_busctx_fetch(remote_object), goto exit);

    res = amxb_subscribe_ex(remote_object->bus_ctx, remote_object->object_dm_name, 0,
                            AMXB_BE_EVENT_TYPE_EVENT, "notification == 'app:stop'", remote_app_stopped, remote_object);

    ASSERT_EQUAL(res, AMXB_STATUS_OK, NO_INSTRUCTION, "[%s] Could not subscribe to stop event", remote_object->object_dm_name);
    res = 0;
exit:
    return res;
}

/**
 * @brief Registers a remote object for communication.
 *
 * This function creates and registers a remote object with the given data model name.
 * It attempts to probe for the object immediately, and if not found, waits for it to become available.
 *
 * @param object_dm_name The data model name of the remote object.
 * @return A pointer to the registered remote object, or NULL on failure.
 */
remote_object_t* lcm_remote_object_register(const char* object_dm_name) {
    remote_object_t* remote_object = NULL;
    ASSERT_STR_NOT_EMPTY(object_dm_name, goto exit);
    ASSERT_SUCCESS(remote_object_new(&remote_object, object_dm_name), goto exit);
    if(lcm_remote_object_probe(remote_object) != 0) {
        ASSERT_SUCCESS(lcm_remote_wait_and_connect(remote_object), goto exit);
    }

exit:
    return remote_object;
}

/**
 * @brief Unregisters and deletes a remote object.
 *
 * This function unsubscribes from events and deletes the remote object.
 * The remote object will be deleted, so do not access it anymore after calling this function!
 *
 * @param remote_object A pointer to the remote object pointer to unregister and delete.
 */
void lcm_remote_object_unregister(remote_object_t** remote_object) {
    ASSERT_NOT_NULL(remote_object, return );
    ASSERT_NOT_NULL((*remote_object), return );

    lcm_remote_unsubscribe_wait_event(*remote_object);
    if((*remote_object)->bus_ctx) {
        amxb_unsubscribe((*remote_object)->bus_ctx, (*remote_object)->object_dm_name, remote_app_stopped, NULL);
    }
    remote_object_delete(remote_object);
}

/**
 * @brief Adds a new object to the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path where to add the object.
 * @param values The values to set for the new object.
 * @param path Optional output parameter for the path of the added object.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_add(remote_object_t* remote_object, const char* object_path, amxc_var_t* values, char** path) {
    int res = -1;
    amxc_var_t ret;

    amxc_var_init(&ret);

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_add(remote_object->bus_ctx, object_path, 0, NULL, values, &ret, TIMEOUT);
    ASSERT_EQUAL(res, amxd_status_ok, goto exit, "Failed to add to [%s] [%d]", object_path, res);

    if(path) {
        amxc_var_t* ret_object = amxc_var_get_first(&ret);
        if(!ret_object) {
            goto exit;
        }
        amxc_var_t* path_var = GET_ARG(ret_object, "path");
        when_null_log(path_var, exit);
        *path = amxc_var_get_cstring_t(path_var);
        path_remove_trailing_dot(*path);
    }
    res = 0;
exit:
    amxc_var_clean(&ret);
    return res;
}

/**
 * @brief Sets values for an object in the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to set values for.
 * @param values The values to set.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_set(remote_object_t* remote_object, const char* object_path, amxc_var_t* values) {
    int res = -1;
    amxc_var_t ret;

    amxc_var_init(&ret);

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_set(remote_object->bus_ctx, object_path, values, &ret, TIMEOUT);
exit:
    amxc_var_clean(&ret);
    return res;
}

/**
 * @brief Removes an object from the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to remove.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_remove(remote_object_t* remote_object, const char* object_path) {
    int res = -1;
    amxc_var_t ret;

    amxc_var_init(&ret);

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_del(remote_object->bus_ctx, object_path, 0, NULL, &ret, TIMEOUT);
exit:
    amxc_var_clean(&ret);
    return res;
}

/**
 * @brief Retrieves data from the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to retrieve.
 * @param ret The variable to store the retrieved data.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_get(remote_object_t* remote_object, const char* object_path, amxc_var_t* ret) {
    int res = -1;
    amxc_string_t search_path;

    amxc_string_init(&search_path, 0);

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_get(remote_object->bus_ctx, object_path, 0, ret, TIMEOUT);
exit:
    amxc_string_clean(&search_path);
    return res;
}

/**
 * @brief Retrieves the first element from the remote data model query.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to query.
 * @param ret The variable to store the first retrieved element.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_get_one(remote_object_t* remote_object, const char* object_path, amxc_var_t* ret) {
    int res = -1;

    amxc_var_t ret_all;
    amxc_var_init(&ret_all);

    ASSERT_SUCCESS(lcm_remote_object_get(remote_object, object_path, &ret_all), goto exit);
    amxc_var_t* first_element = GETP_ARG(&ret_all, "0.0");
    ASSERT_NOT_NULL_NL(first_element, goto exit);
    amxc_var_move(ret, first_element);

    res = 0;
exit:
    amxc_var_clean(&ret_all);
    return res;
}



/**
 * @brief Retrieves data from the remote data model using an expression.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to query.
 * @param expression The expression to filter the results.
 * @param ret The variable to store the retrieved data.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_get_by_expression(remote_object_t* remote_object, const char* object_path, const char* expression, amxc_var_t* ret) {
    int res = -1;
    amxc_string_t search_path;

    amxc_string_init(&search_path, 0);

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);
    ASSERT_STR_NOT_EMPTY(expression, goto exit);

    amxc_string_appendf(&search_path, "%s.[ %s ]", object_path, expression);
    res = amxb_get(remote_object->bus_ctx, amxc_string_get(&search_path, 0), 0, ret, TIMEOUT);
exit:
    amxc_string_clean(&search_path);
    return res;
}

/**
 * @brief Retrieves an object from the remote data model by its alias.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to query.
 * @param alias The alias to search for.
 * @param path Optional output parameter for the path of the found object.
 * @param data Optional output parameter for the data of the found object.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_get_by_alias(remote_object_t* remote_object, const char* object_path, const char* alias, char** path, amxc_var_t* data) {
    int res = -1;
    amxc_var_t ret;
    amxc_string_t search_expression;

    amxc_var_init(&ret);
    amxc_string_init(&search_expression, 0);

    ASSERT_STR_NOT_EMPTY(alias, goto exit);

    amxc_string_appendf(&search_expression, "Alias == '%s'", alias);
    res = lcm_remote_object_get_by_expression(remote_object, object_path, amxc_string_get(&search_expression, 0), &ret);
    ASSERT_EQUAL_NL(res, amxd_status_ok, goto exit);

    res = -1;

    amxc_var_t* first_element = GETP_ARG(&ret, "0.0");
    ASSERT_NOT_NULL_NL(first_element, goto exit);
    if(path) {
        *path = strdup(amxc_var_key(first_element));
        path_remove_trailing_dot(*path);
    }
    if(data) {
        amxc_var_move(data, first_element);
    }

    res = 0;
exit:
    amxc_var_clean(&ret);
    amxc_string_clean(&search_expression);
    return res;
}

/**
 * @brief Deletes an object from the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to delete.
 * @param ret The variable to store the result of the deletion.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_del(remote_object_t* remote_object, const char* object_path, amxc_var_t* ret) {
    int res = -1;

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_del(remote_object->bus_ctx, object_path, 0, NULL, ret, TIMEOUT);

exit:
    return res;
}

/**
 * @brief Subscribes to events on the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to subscribe to.
 * @param expression The expression for filtering events.
 * @param slot_cb The callback function for events.
 * @param priv Private data to pass to the callback.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_subscribe(remote_object_t* remote_object,
                                const char* object_path,
                                const char* expression,
                                amxp_slot_fn_t slot_cb,
                                void* priv) {
    int res = -1;

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_subscribe(remote_object->bus_ctx, object_path, expression, slot_cb, priv);

exit:
    return res;
}

/**
 * @brief Unsubscribe a callback function from the remote data model.
 *
 * @param remote_object The remote object context.
 * @param object_path The path of the object to unsubscribe from.
 * @param slot_cb The callback function used during subscription.
 * @param priv Private data used during subscription.
 * @return 0 on success, -1 on failure.
 */
int lcm_remote_object_unsubscribe(remote_object_t* remote_object,
                                  const char* object_path,
                                  amxp_slot_fn_t slot_cb,
                                  void* priv) {
    int res = -1;

    ASSERT_NOT_NULL(remote_object, goto exit);
    ASSERT_NOT_NULL(remote_object->bus_ctx, goto exit);
    ASSERT_STR_NOT_EMPTY(object_path, goto exit);

    res = amxb_unsubscribe(remote_object->bus_ctx, object_path, slot_cb, priv);

exit:
    return res;
}

bool get_index_from_path(const char* path, uint32_t* index, bool check_end) {
    char* end;
    unsigned long val;

    ASSERT_NOT_NULL(path, return false);
    ASSERT_NOT_NULL(index, return false);

    val = strtoul(path, &end, 10);

    if(end == path) {
        return false;
    }

    if(((val == ULONG_MAX) && (errno == ERANGE)) || (val > UINT32_MAX)) {
        return false;
    }

    if((check_end == true) && (*end != '.')) {
        return false;
    }

    *index = (uint32_t) val;
    return true;
}
