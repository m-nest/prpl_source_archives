/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__CONMON_H__)
#define __CONMON_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
   @file
   @brief
   Conmon main header file
 */

/**
   @ingroup tr181-conmon
   @defgroup conmon ConMon entry point
 */

#define ME "conmon"

#include <stdint.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include <amxb/amxb.h>

#include <amxo/amxo.h>

#include <netmodel/client.h>

// Name of the module namespace that you want to use to execute the functions
#define MOD_CONMON_CTRL "conmon-ctrl"

// Core mod name
#define MOD_CORE "mod-conmon"

#define PLUGIN_NAME "tr181-conmon"

#define STATUS_ENABLED "Enabled"
#define STATUS_DISABLED "Disabled"
#define STATUS_ERROR "Error"

#define IPV4_TYPE "ARP"
#define IPV6_TYPE "ND"

#define str_empty(x) ((x == NULL) || (*x == 0))
#define is_ipv4(type) ((str_empty(type) == false) && (strcmp(type, IPV4_TYPE) == 0))
#define is_ipv6(type) ((str_empty(type) == false) && (strcmp(type, IPV6_TYPE) == 0))

/**
   @file
   @brief
   Main conmon header file
 */

/**
   @defgroup conmon

   Functions relatives to the start and shutdown of the tr181-conmon plugin
 */

/**
   @ingroup conmon
   @brief
   Main structure containing the state variable of a conmon entry object.
 */
typedef struct conmon_info {
    // From datamodel
    char* logical_path;                                    /**< Device.Logical.[]. */
    char* alias;

    amxd_object_t* entry;                                  /**< Pointer to ConMon.Entry.{i}. */

    amxp_timer_t* resolve_timer;                           /**< Timer to wait till logical is resolvable */

    // Queries and Subscriptions
    netmodel_query_t* wan_defaultroute;                    /**< NetModel.Intf.[].getDHCPOption("req", 3, this) */
    netmodel_query_t* wan_physdowntimeout;                 /**< NetModel.Intf.[].getFirstParameter("ResetOnPhysDownTimeout") */
    netmodel_query_t* wan_isup;                            /**< NetModel.Intf.[].isUp() */
    netmodel_query_t* wan_intf;                            /**< NetModel.Intf.[].getLuckyIntf(netdev) */
    netmodel_query_t* local_ip;                            /**< NetModel.Intf.[]. */
    netmodel_query_t* ll_interface_path_changed;           /**< NetModel.Intf.[]. */
    netmodel_query_t* dhcp_isup;                           /**< NetModel.Intf.[]. */
    amxb_subscription_t* netdev_link_added_subscription;   /**< Netdev link added subscription. */
    amxb_subscription_t* netdev_link_removed_subscription; /**< Netdev link removed subscription */

    char* interface_name;                                  /**< Netdev name of the interface. */
} conmon_info_t;

/**
   @ingroup conmon
   @brief
   Internal function to get the data model structure pointer where tr181-conmon plugin register.

   @return
   The conmon plugin root data model
 */
amxd_dm_t* PRIVATE conmon_get_dm(void);

/**
   @ingroup conmon
   @brief
   Internal function to get the parser structure pointer used by tr181-conmon plugin process.

   @return
   The conmon plugin parser
 */
amxo_parser_t* PRIVATE conmon_get_parser(void);


/**
   @ingroup conmon
   @brief
   Entry point function for the tr181-conmon plugin.
   This function initialise the plugin and all its dependencies when it start.
   This function close and free the memory when the plugin shut down.

   @param reason The reason of the entry point call
   @param dm The conmon root datamodel
   @param parser The conmon plugin process parser

   @return 0 on success
 */
int _conmon_main(int reason,
                 amxd_dm_t* dm,
                 amxo_parser_t* parser);

#ifdef __cplusplus
}
#endif

#endif // __CONMON_H__
