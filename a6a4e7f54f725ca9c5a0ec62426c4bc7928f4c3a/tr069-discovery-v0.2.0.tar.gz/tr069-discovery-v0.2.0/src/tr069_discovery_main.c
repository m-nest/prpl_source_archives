/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/client.h>

#include "tr069_discovery.h"

#define ME "discovery"

tr069_discovery_app_t app;

static int tr069_discovery_read_state(void) {
    int rc = -1;

    amxd_status_t status;
    amxd_object_t* object = amxd_dm_findf(app.dm, ACS_DISCOVERY_STATE);
    when_null_trace(object, exit, ERROR, "Failed to get object \"%s\"", ACS_DISCOVERY_STATE);

    char* first_successful_provision_str = amxd_object_get_cstring_t(object, FIRST_SUCCESSFUL_PROVISION, &status);
    when_failed_trace(status, exit, ERROR, "Failed to get \"%s\", status=%d", FIRST_SUCCESSFUL_PROVISION, status);
    app.first_successful_provision = provision_type_from_string(first_successful_provision_str);
    when_failed_trace(app.first_successful_provision < 0, exit, ERROR, "Unexpected value: parameter_name=%s, value=%s",
                      FIRST_SUCCESSFUL_PROVISION, first_successful_provision_str);
    free(first_successful_provision_str);

    app.dhcp_provision_in_use = amxd_object_get_bool(object, DHCP_PROVISION_IN_USE, &status);
    when_failed_trace(status, exit, ERROR, "Failed to get \"%s\", status=%d", DHCP_PROVISION_IN_USE, status);

    SAH_TRACEZ_INFO(ME, "init state: %s=\"%s\", %s=%d",
                    FIRST_SUCCESSFUL_PROVISION, first_successful_provision_str,
                    DHCP_PROVISION_IN_USE, app.dhcp_provision_in_use);

    rc = 0;
exit:
    return rc;
}

static int tr069_discovery_read_config(amxc_var_t* config_var) {
    int rc = -1;

    app.name = (char*) GET_CHAR(config_var, CONFIG_NAME_PARAM);
    when_null_trace(app.name, exit, ERROR, "service name is not defined");

    const char* dhcpv4_client_ref = (char*) GET_CHAR(config_var, CONFIG_DHCP4_CLIENT_REF);
    when_null_trace(dhcpv4_client_ref, exit, ERROR, "%s is not defined", CONFIG_DHCP4_CLIENT_REF);
    snprintf(app.dhcpv4_client_ref, sizeof(app.dhcpv4_client_ref), "%s", dhcpv4_client_ref);

    const char* dhcpv6_client_ref = (char*) GET_CHAR(config_var, CONFIG_DHCP6_CLIENT_REF);
    when_null_trace(dhcpv6_client_ref, exit, ERROR, "%s is not defined", CONFIG_DHCP6_CLIENT_REF);
    snprintf(app.dhcpv6_client_ref, sizeof(app.dhcpv6_client_ref), "%s", dhcpv6_client_ref);

    app.dhcp_rediscovery_interval_s = GET_UINT32(config_var, DHCP_REDISCOVERY_INTERVAL);

    const char* netmodel_intf_alias = (char*) GET_CHAR(config_var, CONFIG_NETMODEL_INTF_ALIAS);
    when_null_trace(netmodel_intf_alias, exit, ERROR, "%s is not defined", CONFIG_NETMODEL_INTF_ALIAS);
    snprintf(app.netmodel_intf_alias, sizeof(app.netmodel_intf_alias), "%s", netmodel_intf_alias);

    app.dhcpv6_wait_time_ms = GET_UINT32(config_var, CONFIG_DHCP6_WAIT_TIME);

    SAH_TRACEZ_INFO(ME, "init config: %s=\"%s\", %s=\"%s\", %s=\"%s\"",
                    CONFIG_DHCP4_CLIENT_REF, app.dhcpv4_client_ref,
                    CONFIG_DHCP6_CLIENT_REF, app.dhcpv6_client_ref,
                    CONFIG_NETMODEL_INTF_ALIAS, app.netmodel_intf_alias);

    rc = 0;
exit:
    return rc;
}

static void handle_dhcpv6_wait_timer(amxp_timer_t* timer, UNUSED void* priv) {
    if(timer != app.dhcpv6_wait_timer) {
        SAH_TRACEZ_ERROR(ME, "Invalid timer used, something went terribly wrong");
        return;
    }

    if(dhcp_provisioning_start()) {
        SAH_TRACEZ_ERROR(ME, "Failed to start DHCP provisioning");
    }
    amxp_timer_delete(&app.dhcpv6_wait_timer);
}

static void schedule_dhcp_provisioning_start(void) {
    amxp_timer_new(&app.dhcpv6_wait_timer, handle_dhcpv6_wait_timer, NULL);
    amxp_timer_start(app.dhcpv6_wait_timer, app.dhcpv6_wait_time_ms);
}

int _tr069_discovery_start(UNUSED int reason,
                           UNUSED amxd_dm_t* dm,
                           UNUSED amxo_parser_t* parser) {
    int rc = register_cwmp_dm();
    when_failed_trace(rc, exit, ERROR, "Failed to register CWMP datamodel");

    rc = tr069_discovery_read_state();
    when_failed_trace(rc, exit, ERROR, "Failed to read state");
    rc = tr069_discovery_read_config(amxrt_get_config());
    when_failed_trace(rc, exit, ERROR, "Failed to read config");
    schedule_dhcp_provisioning_start();

    SAH_TRACEZ_INFO(ME, "***********************************");
    SAH_TRACEZ_INFO(ME, "*     tr069-discovery started     *");
    SAH_TRACEZ_INFO(ME, "***********************************");

exit:
    return rc;
}

int _tr069_discovery_stop(UNUSED int reason,
                          UNUSED amxd_dm_t* dm,
                          UNUSED amxo_parser_t* parser) {
    int rc = deregister_cwmp_dm();
    when_failed_trace(rc, exit, ERROR, "Failed to deregister CWMP datamodel");

    rc = dhcp_provisioning_stop();
    when_failed_trace(rc, exit, ERROR, "Failed to stop DHCP provisioning");

    if(app.dhcpv6_wait_timer) {
        amxp_timer_delete(&app.dhcpv6_wait_timer);
    }

    if(app.session_timer) {
        amxp_timer_delete(&app.session_timer);
    }

    SAH_TRACEZ_INFO(ME, "***********************************");
    SAH_TRACEZ_INFO(ME, "*     tr069-discovery stopped     *");
    SAH_TRACEZ_INFO(ME, "***********************************");

exit:
    return rc;
}

int _tr069_discovery_main(int reason,
                          amxd_dm_t* dm,
                          UNUSED amxo_parser_t* parser) {
    int rc = -1;

    switch(reason) {
    case AMXO_START:
        memset((void*) &app, 0, sizeof(tr069_discovery_app_t));
        app.dm = dm;
        when_false_trace(netmodel_initialize(), exit, ERROR, "Failed to initialize libnetmodel");
        break;
    case AMXO_STOP:
        app.dm = NULL;
        netmodel_cleanup();
        break;
    }

    rc = 0;
exit:
    return rc;
}
