#!/bin/bash

set +e
IS_UDPST_RUNNING=$(pgrep udpst)
if [ ! -z "${IS_UDPST_RUNNING}" -a "${IS_UDPST_RUNNING}" != "" -a "${IS_UDPST_RUNNING}" != " " ]; then
	echo "Stopping UDP Speed Test server..."
	pkill udpst
fi