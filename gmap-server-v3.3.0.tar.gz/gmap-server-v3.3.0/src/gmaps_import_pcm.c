/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "gmaps_import_pcm.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxc/amxc_variant.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include "gmaps_devices.h"

#define ME "gmaps"

static bool s_set_tags_of_device(const char* alias, amxd_object_t* device_template_obj, const amxc_var_t* device_data) {
    amxc_var_t params;
    bool ok = false;
    const char* tags = GET_CHAR(device_data, "Tags");
    amxc_var_init(&params);
    when_str_empty_trace(alias, exit, ERROR, "Device without alias");
    when_str_empty_trace(tags, exit, ERROR, "Device %s without tags", alias);
    when_null_trace(device_template_obj, exit, ERROR, "NULL argument");

    amxc_var_set_type(&params, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &params, "Tags", tags);
    amxc_var_add_key(cstring_t, &params, "Alias", alias);
    amxc_var_add_key(cstring_t, &params, "Key", alias);

    amxd_object_t* device = NULL;
    when_failed_trace(amxd_object_new_instance(&device, device_template_obj, alias, 0, &params),
                      exit,
                      ERROR, "Error creating device object instance");
    amxd_object_set_params(device, &params);
    gmaps_store_device(device);

    /* Emit the expected 'dm:instance-added' event so that mod-pcm-svc remembers it.
     *
     * Internally, mod-pcm-svc relies on events sent by default by the transactions
     * it executes. This is normally fine when it creates all the objects itself.
     *
     * However, gmap-server has to pre-empt this so that the mibs are properly
     * loaded on the instance before mod-pcm-svc tries to restore mib parameters.
     *
     * Note that amxo_parser_apply_mibs emits events for all objects, instances
     * and parameters that are added from the mib, so logically, the containing
     * object must have been created already.
     */
    amxd_object_emit_add_inst(device);

    amxo_parser_apply_mibs(gmap_get_parser(), device, gmaps_device_matches);

    ok = true;

exit:
    amxc_var_clean(&params);
    return ok;
}


static bool s_merge_tags(amxd_object_t* local,
                         amxc_var_t* device_data) {
    /* Tags are merged to their superset. */
    bool success = false;
    amxc_var_t* new_tags;
    amxc_set_t* tags = NULL;

    new_tags = amxc_var_take_key(device_data, "Tags");
    when_null_status(new_tags, exit, success = true);

    tags = gmaps_device_tag_parse(GET_CHAR(new_tags, NULL));
    when_null_status(tags, exit, success = false);

    /* This will apply the mibs as needed */
    when_false(gmaps_device_tag_set(local, tags), exit);
    success = true;

exit:
    amxc_set_delete(&tags);
    amxc_var_delete(&new_tags);
    return success;
}

static bool s_merge_timestamp(amxd_object_t* local,
                              amxc_var_t* device_data,
                              const char* name,
                              bool keep_oldest) {
    /* If the current value must be changed, this function keeps the device_data
     * as-is so that the regular restore process takes care of that.
     * If the current value is good, the to-be-restored value is deleted.
     */
    bool success = false;
    amxc_var_t zero;
    amxc_var_t* new_ts;
    const amxc_var_t* old_ts;
    int result;

    amxc_var_init(&zero);

    new_ts = GET_ARG(device_data, name);
    when_null_status(new_ts, exit, success = true);

    /* If the restored ts is the default, keep the old value. */
    amxc_var_set_type(&zero, AMXC_VAR_ID_TIMESTAMP);
    when_failed_trace(amxc_var_compare(new_ts, &zero, &result), exit, ERROR,
                      "Failed to check restored %s parameter", name);
    if(result == 0) {
        amxc_var_delete(&new_ts);
        success = true;
        goto exit;
    }

    /* If the old ts is the default, always overwrite. */
    old_ts = amxd_object_get_param_value(local, name);
    when_failed_trace(amxc_var_compare(old_ts, &zero, &result), exit, ERROR,
                      "Failed to check current %s parameter", name);
    when_true_status(result == 0, exit, success = true);

    /* If the old ts is newer than the restored ts, always overwrite. */
    when_failed_trace(amxc_var_compare(old_ts, new_ts, &result), exit, ERROR,
                      "Failed to compare %s parameters", name);
    when_true_status((keep_oldest && result >= 0) || (!keep_oldest && result <= 0),
                     exit, success = true);

    /* The restored timestamp is newer or the same, keep the old value. */
    amxc_var_delete(&new_ts);
    success = true;

exit:
    amxc_var_clean(&zero);
    return success;
}


static bool s_merge_device(amxd_object_t* local,
                           amxc_var_t* device_data) {
    amxc_var_t* tmp;
    bool success = s_merge_tags(local, device_data);
    success = success && s_merge_timestamp(local, device_data, "FirstSeen", true);
    success = success && s_merge_timestamp(local, device_data, "LastConnection", false);
    /* TODO: Merge names by using setName. */

    if(success) {
        /* Remove the Key, Alias and PhysAddress parameters if present, they must never be overwritten. */
        tmp = GET_ARG(device_data, "Key");
        amxc_var_delete(&tmp);
        tmp = GET_ARG(device_data, "Alias");
        amxc_var_delete(&tmp);
        tmp = GET_ARG(device_data, "PhysAddress");
        amxc_var_delete(&tmp);
    }

    return success;
}

/**
 * @brief Attempts to merge an imported device into the current list of devices.
 *
 * When restoring import data, the gmap server may already contain some devices.
 * These devices may or may not correspond with an equivalent device in the
 * imported data. The goal is to not end up with duplicates or a failed import.
 *
 * In gmap, devices may be identified in two ways: through their object alias,
 * or through their PhysAddress parameter for devices with a MAC address.
 *
 * It is assumed that the same MAC address will always denote the same physical
 * object connected into the network, even across HGW factory resets. The alias
 * is not stable across a factory reset because it is randomly generated each
 * time a device is (re-)discovered.
 *
 * Therefore when attempting to restore a device, the following algorithm is used:
 * * Completely unknown devices are always restored.
 * * If the device is to be merged into a 'self' device, discard it silently as
 *   these devices are recreated at boot.
 * * If the alias is already used by a device, but that device has a different
 *   physical address, discard the data as an error in case the back-up data got
 *   corrupted. Likewise if two different devices are known for the alias and
 *   physical address respectively.
 * * If the physical address is already used by a known device, merge the restored
 *   data into that device. The device alias in the restored data is changed into
 *   that of the known device.
 *
 * @param device htable variant containing the device data. It must be of the form
 *               `{alias: device_data}`. This function may modify this variant.
 * @param alias The device alias under which the device is imported. This is the
 *              initial key of the variant structure passed into @p device_data.
 * @param device_data htable variant containing the device parameters and subobjects
 *                    that need to be restored. This variant must be a member of
 *                    the variant passed into @p device.
 * @param bool[out] If set to true by this function, the device does not need
 *                  further restoration.
 *
 * @retval 0 No device was merged and a new device should be created.
 * @retval < 0 an error was encountered and the data restoration must be aborted.
 * @retval > 0 The device data was (partly) restored into an existing object.
 */
static int s_try_merge_device_from_import(amxc_var_t* device,
                                          const char* alias,
                                          amxc_var_t* device_data,
                                          bool* out_can_remove) {
    int result;
    amxd_object_t* device_alias = gmaps_get_device(alias);
    const char* phys_address = GET_CHAR(device_data, "PhysAddress");
    amxd_object_t* device_physaddr = gmaps_get_device_for_mac(phys_address);

    *out_can_remove = false;

    if((device_physaddr == NULL) && (device_alias == NULL)) {
        /* Previously completely unknown device, needs to be added as-is. */
        result = 0;
    } else if(gmaps_device_tag_has(device_alias, GMAPS_DEVICES_TAG_SELF) ||
              gmaps_device_tag_has(device_physaddr, GMAPS_DEVICES_TAG_SELF)) {
        /* Never restore any of the self devices. Silently ignore it. */
        *out_can_remove = true;
        result = 1;
    } else if(device_physaddr == NULL) {
        /* Device known under its alias, but with a different (or no) physical address. */
        SAH_TRACEZ_ERROR(ME, "To-be-imported device (alias: '%s', mac: '%s') differs from known device of same key.",
                         alias, phys_address);
        result = -1;
    } else if(device_alias == NULL) {
        /* Device known under different alias, rename then merge the data into that one. */
        SAH_TRACEZ_WARNING(ME, "Restoring data from backed-up device '%s' to current device '%s' for physical address '%s'.",
                           alias, amxd_object_get_name(device_physaddr, AMXD_OBJECT_NAMED), phys_address);
        alias = amxd_object_get_name(device_physaddr, AMXD_OBJECT_NAMED);
        amxc_var_set_key(device, alias, device_data, AMXC_VAR_FLAG_DEFAULT);
        goto do_merge;
    } else if(device_physaddr != device_alias) {
        /* Different devices are known for the alias and the mac address. */
        SAH_TRACEZ_ERROR(ME, "To-be-imported device (alias: '%s', mac: '%s') is known, but its mac is known under another key '%s'.",
                         alias, phys_address, amxd_object_get_name(device_physaddr, AMXD_OBJECT_NAMED));
        result = -1;
    } else {
        /* The device is already known with that (mac, alias) combination. Still needs to be merged */
do_merge:
        result = s_merge_device(device_physaddr, device_data) ? 1 : -1;
        *out_can_remove = amxc_htable_is_empty(amxc_var_constcast(amxc_htable_t, device_data));
    }

    return result;
}

static bool s_prepare_import_device_data(amxc_var_t* devices,
                                         bool allow_merge) {
    bool ok = true;
    when_null_trace(devices, exit, ERROR, "NULL argument");
    when_false_trace(amxc_var_type_of(devices) == AMXC_VAR_ID_HTABLE || amxc_var_type_of(devices) == AMXC_VAR_ID_LIST,
                     exit, ERROR, "Expected devices list or htable");

    amxd_object_t* device_template_obj = gmap_dm_get_devices_device();
    when_null_trace(device_template_obj, exit, ERROR, "Device template object not found");

    amxc_var_for_each(device, devices) {
        amxc_var_t* device_parameters = amxc_var_get_first(device);
        const char* alias = amxc_var_key(device_parameters);
        bool can_remove = false;
        int result = allow_merge ? s_try_merge_device_from_import(device, alias, device_parameters, &can_remove)
                                 : 0;
        if(result == 0) {
            ok &= s_set_tags_of_device(alias, device_template_obj, device_parameters);
        } else if(result < 0) {
            ok = false;
        } else {
            if(can_remove) {
                amxc_var_delete(&device);
            }
        }
    }

exit:
    return ok;
}

static bool s_can_merge_import_pcm(amxc_var_t* data) {
    bool status = false;
    const char* type = GET_CHAR(data, "type");

    when_str_empty(type, exit);
    status = (strcmp(type, "upc") == 0 || strcmp(type, "usersetting") == 0);

exit:
    return status;
}

/**
 * Sets the tags of the devices contained in the given persistentconfiguration-manager data.
 *
 * We have to set the tags first, because they have to be set before setting parameters,
 * because some parameters are defined in mibs, and the mibs are only loaded after
 * the tags are set.
 */
static bool s_prepare_devices_data_import_pcm(amxc_var_t* pcm_data) {
    bool ok = true;
    const bool may_merge = s_can_merge_import_pcm(pcm_data);
    amxc_var_t* devices = GETP_ARG(pcm_data, "set.hgwconfig.Devices.Device.");

    if(devices != NULL) {
        ok &= s_prepare_import_device_data(devices, may_merge);
    }

    return ok;
}

amxd_status_t gmaps_import_pcm(amxc_var_t* args, amxc_var_t* ret) {
    int status = amxd_status_unknown_error;
    bool ok = false;
    amxc_var_t* pcm_data = GET_ARG(args, "data");
    when_null_trace(pcm_data, exit, ERROR, "'data' parameter not found");

    // First, prepare the existing data model
    ok = s_prepare_devices_data_import_pcm(pcm_data);
    when_false_trace(ok, exit, ERROR, "Error importing reboot-persistent data");

    // Now that the tags are set, and parameters defined in mibs exist for the device,
    // it's safe for PCM to fill in the other parameters:
    status = amxb_call(amxb_be_who_has("Devices"),
                       "Devices.",
                       "PcmImport",
                       args,
                       ret,
                       15);
    when_failed_trace(status, exit, ERROR, "Error calling PcmImport");

exit:
    return status;
}
