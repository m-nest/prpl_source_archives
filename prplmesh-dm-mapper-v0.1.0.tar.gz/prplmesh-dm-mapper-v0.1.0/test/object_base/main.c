/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxo/amxo.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>


#include "dmm.h"
#include "dmm_methods.h"

int test_setup(void** state) {
    amxut_bus_setup(state);

    return 0;
}

int test_teardown(void** state) {
    amxut_bus_handle_events();
    amxut_bus_teardown(state);

    return 0;
}

prpl_dmm_t* __wrap_dmm_get_info(void) {
    function_called();

    return mock_ptr_type(prpl_dmm_t*);
}

amxd_status_t __real_amxd_object_new(amxd_object_t** object,
                                     const amxd_object_type_t type,
                                     const char* name);

void __real_amxd_object_free(amxd_object_t** object);


amxd_status_t __wrap_amxd_object_new(amxd_object_t** object,
                                     const amxd_object_type_t type,
                                     const char* name) {
    function_called();
    check_expected(object);
    check_expected(type);
    check_expected(name);

    amxd_status_t expected = mock_type(amxd_status_t);
    assert_int_equal(__real_amxd_object_new(object, type, name), expected);

    return expected;
}


void test_dmm_object_create(UNUSED void** state) {
    prpl_dmm_t mapper;

    expect_function_call(__wrap_dmm_get_info);
    will_return(__wrap_dmm_get_info, &mapper);

    expect_function_call(__wrap_amxd_object_new);
    expect_value(__wrap_amxd_object_new, object, &mapper.map_base);
    expect_value(__wrap_amxd_object_new, type, amxd_object_singleton);
    expect_string(__wrap_amxd_object_new, name, "map_base");
    will_return(__wrap_amxd_object_new, amxd_status_ok);

    dmm_object_create();

    assert_true(amxd_object_get_function(mapper.map_base, "_get")->impl == &dmm_rpc_transl_path_optional_sync);
    assert_true(amxd_object_get_function(mapper.map_base, "_set")->impl == &dmm_rpc_transl_path);
    assert_true(amxd_object_get_function(mapper.map_base, "_add")->impl == &dmm_rpc_transl_data_multiple);
    assert_true(amxd_object_get_function(mapper.map_base, "_del")->impl == &dmm_rpc_del);
    assert_true(amxd_object_get_function(mapper.map_base, "_list")->impl == &dmm_rpc_list);
    assert_true(amxd_object_get_function(mapper.map_base, "_describe")->impl == &dmm_rpc_transl_data);
    assert_true(amxd_object_get_function(mapper.map_base, "_exec")->impl == &dmm_rpc);
    assert_true(amxd_object_get_function(mapper.map_base, "_get_supported")->impl == &dmm_rpc_transl_path);
    assert_true(amxd_object_get_function(mapper.map_base, "_get_instances")->impl == &dmm_rpc_transl_path);

    assert_true(amxd_object_get_function(mapper.map_base, "_subscribe")->impl == &dmm_subscribe);
    assert_true(amxd_object_get_function(mapper.map_base, "_unsubscribe")->impl == &dmm_unsubscribe);

    __real_amxd_object_free(&mapper.map_base);
}

void __wrap_amxd_object_free(amxd_object_t** object) {
    function_called();
    check_expected(object);

    __real_amxd_object_free(object);
}

void test_dmm_object_delete(UNUSED void** state) {
    prpl_dmm_t mapper;
    __real_amxd_object_new(&mapper.map_base, amxd_object_singleton, "map_base");

    expect_function_call(__wrap_dmm_get_info);
    will_return(__wrap_dmm_get_info, &mapper);

    expect_function_call(__wrap_amxd_object_free);
    expect_value(__wrap_amxd_object_free, object, &mapper.map_base);

    dmm_object_delete();
}


int main() {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_dmm_object_create),
        cmocka_unit_test(test_dmm_object_delete)
    };

    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
