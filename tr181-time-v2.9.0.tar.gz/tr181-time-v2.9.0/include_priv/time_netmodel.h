/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__TIME_SERVER_NETMODEL_H__)
#define __TIME_SERVER_NETMODEL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include "netmodel/client.h"

/**********************************************************
* Type definitions
**********************************************************/

typedef struct server_info {
    netmodel_query_t* query;
    netmodel_query_t* addr_query;
    bool state;
    char* intf_interface;
    amxd_object_t* obj;
} server_info_t;

typedef struct client_info {
    netmodel_query_t* query;
    bool state;
    bool initial_sync;
    uint32_t retries;
    amxc_var_t* addr_l;
    amxd_object_t* obj;
} client_info_t;

/**********************************************************
* Function Prototypes
**********************************************************/

amxd_status_t PRIVATE create_server_info(amxd_object_t* obj);
amxd_status_t PRIVATE update_server_info(amxd_object_t* obj);
void PRIVATE clear_server_info(server_info_t* info);

amxd_status_t PRIVATE create_client_info(amxd_object_t* obj);
amxd_status_t PRIVATE update_client_info(amxd_object_t* obj);
void PRIVATE clear_client_info(client_info_t* info);

void PRIVATE time_netmodel_init(void);

void PRIVATE time_netmodel_cleanup(void);

bool PRIVATE nm_get_state_server(server_info_t* info);
bool PRIVATE nm_get_state_client(client_info_t* client);

uint32_t PRIVATE nm_get_client_retries(amxd_object_t* obj);
void PRIVATE nm_inc_client_retries(amxd_object_t* obj);
void PRIVATE nm_reset_client_retries(amxd_object_t* obj);

#ifdef __cplusplus
}
#endif

#endif // __TIME_SERVER_NETMODEL_H__
