/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#define _GNU_SOURCE
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>
#include <amxc/amxc_string.h>

#include "mqtt_get_certificate_uri.h"

int get_certificate_uri(const char* fullpath, char** certuri, char** keyuri) {
    amxc_var_t inargs;
    amxc_var_t outargs;
    int ret = -1;

    amxc_var_init(&inargs);
    amxc_var_init(&outargs);

    ret = amxb_call(amxb_be_who_has(fullpath), fullpath, "GetCertificateURI", &inargs, &outargs, 3);

    if(ret == 0) {
        amxc_var_t* outputs = amxc_var_get_first(&outargs); // string error/status
        outputs = amxc_var_get_next(outputs);               // map
        const char* cert = amxc_var_constcast(cstring_t, amxc_var_get_key(outputs, "CertificateURI", AMXC_VAR_FLAG_DEFAULT));
        const char* key = amxc_var_constcast(cstring_t, amxc_var_get_key(outputs, "PrivateKeyURI", AMXC_VAR_FLAG_DEFAULT));

        if(cert) {
            *certuri = strdup(cert);
        }
        if(key) {
            *keyuri = strdup(key);
        }

        ret = 0;
    }

    amxc_var_clean(&inargs);
    amxc_var_clean(&outargs);
    return ret;
}
