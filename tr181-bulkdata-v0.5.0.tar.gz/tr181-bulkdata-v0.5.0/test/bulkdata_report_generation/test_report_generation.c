/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>

#include <amxo/amxo.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"

#include "mock.h"
#include "test_common.h"
#include "test_report_generation.h"
#include "bulkdata_profile_parameter.h"
#include "bulkdata_profile_encoding.h"
#include "bulkdata_profile_json_encoding.h"
#include "bulkdata_profile_csv_encoding.h"

int test_report_setup(UNUSED void** state) {
    const char* odl_bulkdata = "tr181-bulkdata_reports.odl";
    const char* odl_device = "../common/test_device.odl";
    const char* odl_mqtt = "../common/tr181-mqtt.odl";
    const char* odl_deviceInfo = "../common/tr181-deviceInfo.odl";
    static const char* la_definition = "../common/tr181-localagent_definition.odl";
    static const char* la_defaults = "../common/tr181-localagent_mtp_enabled.odl";
    amxo_parser_t* parser = NULL;

    test_setup(NULL);
    capture_sigalrm();

    parser = test_get_parser();
    assert_int_equal(amxo_parser_parse_file(parser, odl_bulkdata, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_device, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_mqtt, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, odl_deviceInfo, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, la_definition, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(parser, la_defaults, amxd_dm_get_root(mock_get_dm())), 0);
    return 0;
}

int test_report_teardown(UNUSED void** state) {
    go_to_future_ms(10000);
    test_teardown(NULL);
    return 0;
}

static void prepare_and_check_report(const char* profile_path, const char* report_type, const char* expected_report) {
    amxc_var_t* var = NULL;
    amxc_var_t* var_json_data = NULL;
    amxc_var_t* var_json_report = NULL;
    const cstring_t string = NULL;
    amxd_object_t* profile = NULL;

    amxc_var_new(&var);

    profile = amxd_dm_findf(mock_get_dm(), profile_path);
    assert_non_null(profile);
    var_json_data = bulkdata_retrieve_parameters(profile, PROFILE_ENCODING_CSV);
    assert_non_null(var_json_data);

    var_json_report = bulkdata_csv_format_data(profile, var_json_data);
    assert_non_null(var_json_report);
    amxc_var_cast(var_json_report, AMXC_VAR_ID_CSV_STRING);

    string = amxc_var_constcast(cstring_t, var_json_report);
    assert_non_null(string);
    get_bulkdata_profile(profile_path, "Parameter.1.", var);
    printf("CSV report (%s) for Parameter [Name: '%s'] [Reference '%s'] \n%s\n", report_type, GETP_CHAR(var, "0.0.Name"), GETP_CHAR(var, "0.0.Reference"), string);
    fflush(stdout);

    assert_string_equal(string, expected_report);

    amxc_var_delete(&var_json_data);
    var_json_data = NULL;
    amxc_var_delete(&var_json_report);
    var_json_report = NULL;

    amxc_var_delete(&var);
}

void test_generate_csv_report_ParameterPerColumn(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;

    amxc_var_new(&var);
    get_bulkdata_profile("BulkData.Profile.csv_1.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerColumn");

    prepare_and_check_report("BulkData.Profile.csv_1.", report_type, "ReportTimestamp,DeviceTimeEnable\r\n" \
                             "1747901699331,true\r\n");

    delete_profile("BulkData.Profile.csv_1.");
    amxc_var_delete(&var);
}

void test_generate_csv_report_ParameterPerColumn_object(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;
    amxc_var_new(&var);

    get_bulkdata_profile("BulkData.Profile.csv_2.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerColumn");

    prepare_and_check_report("BulkData.Profile.csv_2.", report_type, "ReportTimestamp,DeviceTimeObject.Enable,DeviceTimeObject.Status\r\n" \
                             "1747901699331,true,Unsynchronized\r\n");

    delete_profile("BulkData.Profile.csv_2.");

    amxc_var_delete(&var);
}

void test_generate_csv_report_ParameterPerRow(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;

    amxc_var_new(&var);
    get_bulkdata_profile("BulkData.Profile.csv_3.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerRow");

    prepare_and_check_report("BulkData.Profile.csv_3.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,DeviceTimeEnable,true,boolean\r\n");

    delete_profile("BulkData.Profile.csv_3.");

    amxc_var_delete(&var);
}

void test_generate_csv_report_ParameterPerRow_object(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;

    amxc_var_new(&var);
    get_bulkdata_profile("BulkData.Profile.csv_4.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerRow");

    prepare_and_check_report("BulkData.Profile.csv_4.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,DeviceTimeObject.Enable,true,boolean\r\n" \
                             "1747901699331,DeviceTimeObject.Status,Unsynchronized,string\r\n");

    delete_profile("BulkData.Profile.csv_4.");
    amxc_var_delete(&var);
}


void test_generate_csv_report_ParameterPerColumn_empty_param_name(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;

    amxc_var_new(&var);
    get_bulkdata_profile("BulkData.Profile.csv_5.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerColumn");

    prepare_and_check_report("BulkData.Profile.csv_5.", report_type, "ReportTimestamp,Device.Time.Enable\r\n" \
                             "1747901699331,true\r\n");

    delete_profile("BulkData.Profile.csv_5.");

    amxc_var_delete(&var);
}

void test_generate_csv_report_ParameterPerRow_empty_param_name(UNUSED void** state) {
    amxc_var_t* var = NULL;
    const char* report_type = NULL;
    amxc_var_new(&var);

    get_bulkdata_profile("BulkData.Profile.csv_6.", "CSVEncoding.", var);
    report_type = GETP_CHAR(var, "0.0.ReportFormat");
    assert_string_equal(report_type, "ParameterPerRow");

    prepare_and_check_report("BulkData.Profile.csv_6.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.Time.Enable,true,boolean\r\n" \
                             "1747901699331,Device.Time.Status,Unsynchronized,string\r\n");
    delete_profile("BulkData.Profile.csv_6.");

    amxc_var_delete(&var);
}

void test_generate_csv_report_wildcard_ParameterPerColumn(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_7.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerColumn");

    // TC-1 : report for wildcard reference with parameter name filled
    prepare_and_check_report("BulkData.Profile.csv_7.", report_type, "ReportTimestamp,MTP_Enable.1.2,MTP_Enable.1.1\r\n" \
                             "1747901699331,true,true\r\n");

    // TC-2 : report for wildcard reference with parameter name empty
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_7.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_7.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.2.Enable,Device.LocalAgent.Controller.1.MTP.1.Enable\r\n" \
                             "1747901699331,true,true\r\n");

    // TC-3 : report for wildcard reference with parameter name filled
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "Agent_Controller_MTPs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.1.MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_7.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_7.", report_type, "ReportTimestamp,Agent_Controller_MTPs.1.AgentMTPReference,Agent_Controller_MTPs.1.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.1.MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_7.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_7.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    // delete the profile
    delete_profile("BulkData.Profile.csv_7.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}

void test_generate_csv_report_wildcard_ParameterPerColumn_2(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_8.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerColumn");

    // TC-1 : report for wildcard reference with parameter name filled + referece to single parameter
    prepare_and_check_report("BulkData.Profile.csv_8.",
                             report_type,
                             "ReportTimestamp,MTP_MQTT_Enable.1.1\r\n" \
                             "1747901699331,true\r\n");

    // TC-2 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_8.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_8.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.1.Enable\r\n" \
                             "1747901699331,true\r\n");

    // TC-3 : report for wildcard reference with parameter name filled + reference to object
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "MTP_MQTTs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_8.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_8.", report_type, "ReportTimestamp,MTP_MQTTs.1.1.AgentMTPReference,MTP_MQTTs.1.1.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_8.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_8.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    delete_profile("BulkData.Profile.csv_8.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}

void test_generate_csv_report_wildcard_ParameterPerColumn_3(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_9.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerColumn");

    // TC-1 : report for wildcard reference with parameter name filled + referece to single parameter
    prepare_and_check_report("BulkData.Profile.csv_9.", report_type, "ReportTimestamp,MTP_Enabled_Alias.1,MTP_Enabled_Alias.2\r\n" \
                             "1747901699331,mtp-test,mtp-usd\r\n");

    // TC-2 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_9.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_9.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.1.Alias,Device.LocalAgent.Controller.1.MTP.2.Alias\r\n" \
                             "1747901699331,mtp-test,mtp-usd\r\n");

    // TC-3 : report for wildcard reference with parameter name filled + reference to object
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "MTP_MQTTs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.1.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_9.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_9.", report_type, "ReportTimestamp,MTP_MQTTs.1.AgentMTPReference,MTP_MQTTs.1.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.1.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_9.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_9.", report_type, "ReportTimestamp,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic\r\n" \
                             "1747901699331,Device.LocalAgent.MTP.1,controller_test\r\n");

    delete_profile("BulkData.Profile.csv_9.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}

void test_generate_csv_report_wildcard_ParameterPerRow(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_10.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerRow");

    // TC-1 : report for wildcard reference with parameter name filled
    prepare_and_check_report("BulkData.Profile.csv_10.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,MTP_Enable.1.2,true,boolean\r\n" \
                             "1747901699331,MTP_Enable.1.1,true,boolean\r\n");


    // TC-2 : report for wildcard reference with parameter name empty
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_10.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_10.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.2.Enable,true,boolean\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.Enable,true,boolean\r\n");

    // TC-3 : report for wildcard reference with parameter name filled
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "Agent_Controller_MTPs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.1.MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_10.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_10.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Agent_Controller_MTPs.1.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,Agent_Controller_MTPs.1.Topic,controller_test,string\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.1.MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_10.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_10.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic,controller_test,string\r\n");

    // delete the profile
    delete_profile("BulkData.Profile.csv_10.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}

void test_generate_csv_report_wildcard_ParameterPerRow_2(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_11.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerRow");

    // TC-1 : report for wildcard reference with parameter name filled + referece to single parameter
    prepare_and_check_report("BulkData.Profile.csv_11.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,MTP_MQTT_Enable.1.1,true,boolean\r\n");

    // TC-2 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_11.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_11.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.Enable,true,boolean\r\n");

    // TC-3 : report for wildcard reference with parameter name filled + reference to object
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "MTP_MQTTs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_11.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_11.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,MTP_MQTTs.1.1.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,MTP_MQTTs.1.1.Topic,controller_test,string\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.*.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_11.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_11.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic,controller_test,string\r\n");

    delete_profile("BulkData.Profile.csv_11.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}

void test_generate_csv_report_wildcard_ParameterPerRow_3(UNUSED void** state) {
    amxc_var_t* var = NULL;
    char* report_type = NULL;
    amxc_var_t* values = NULL;

    amxc_var_new(&var);
    amxc_var_new(&values);
    get_bulkdata_profile("BulkData.Profile.csv_12.", "CSVEncoding.", var);
    report_type = strdup(GETP_CHAR(var, "0.0.ReportFormat"));
    assert_string_equal(report_type, "ParameterPerRow");

    // TC-1 : report for wildcard reference with parameter name filled + referece to single parameter
    prepare_and_check_report("BulkData.Profile.csv_12.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,MTP_Enabled_Alias.1,mtp-test,string\r\n" \
                             "1747901699331,MTP_Enabled_Alias.2,mtp-usd,string\r\n");


    // TC-2 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_12.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_12.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.Alias,mtp-test,string\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.2.Alias,mtp-usd,string\r\n");

    // TC-3 : report for wildcard reference with parameter name filled + reference to object
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "MTP_MQTTs");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.1.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_12.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_12.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,MTP_MQTTs.1.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,MTP_MQTTs.1.Topic,controller_test,string\r\n");

    // TC-4 : report for wildcard reference with parameter name empty + referece to single parameter
    amxc_var_set_type(values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, values, "Name", "");
    amxc_var_add_key(cstring_t, values, "Reference", "Device.LocalAgent.Controller.1.MTP.[Protocol == 'MQTT'].MQTT.");
    assert_int_equal(amxb_set(test_get_bus_ctx(), "BulkData.Profile.csv_12.Parameter.1.", values, var, 3), 0);

    prepare_and_check_report("BulkData.Profile.csv_12.", report_type, "ReportTimestamp,ParameterName,ParameterValue,ParameterType\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.AgentMTPReference,Device.LocalAgent.MTP.1,string\r\n" \
                             "1747901699331,Device.LocalAgent.Controller.1.MTP.1.MQTT.Topic,controller_test,string\r\n");

    delete_profile("BulkData.Profile.csv_12.");

    amxc_var_delete(&var);
    amxc_var_delete(&values);
    free(report_type);
}
