/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <sys/sysinfo.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_transaction.h>

#include "tr181-logical_priv.h"
#include "netmodel_intf_name.h"

#define ME "logical-intf"

static void logical_interface_status(amxd_object_t* obj, bool enable) {
    amxd_trans_t transaction;
    const char* alias = NULL;
    amxd_dm_t* dm = logical_get_dm();
    amxd_trans_init(&transaction);
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);

    alias = amxc_var_constcast(cstring_t, amxd_object_get_param_value(obj, "Alias"));
    amxd_trans_select_object(&transaction, obj);
    if(enable) {
        amxd_trans_set_value(cstring_t, &transaction, "Status", "Up");
        SAH_TRACE_WARNING("Logical Interface[%s] change Status(Up)", alias);
    } else {
        amxd_trans_set_value(cstring_t, &transaction, "Status", "Down");
        SAH_TRACE_WARNING("Logical Interface[%s] change Status(Down)", alias);
    }
    amxd_trans_apply(&transaction, dm);
    amxd_trans_clean(&transaction);
}

int logical_interface_set_netdevname(amxd_object_t* intf_obj, const char* name) {
    amxd_trans_t* trans = NULL;
    int rv = -1;

    rv = amxd_trans_new(&trans);
    when_failed_trace(rv, exit, ERROR, "Failed to allocate memory for transaction");

    amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    amxd_trans_set_attr(trans, amxd_tattr_change_prot, true);
    amxd_trans_select_object(trans, intf_obj);
    amxd_trans_set_value(cstring_t, trans, "NetDevName", name);

    rv = amxd_trans_apply(trans, logical_get_dm());
    when_failed_trace(rv, exit, ERROR, "Failed to set new interface name '%s' in datamodel, return '%d'", name, rv);

exit:
    amxd_trans_delete(&trans);
    return rv;
}

void _logical_interface_enabled(UNUSED const char* const sig_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxd_dm_t* dm = logical_get_dm();
    amxd_object_t* obj = amxd_dm_signal_get_object(dm, data);
    logical_interface_status(obj, true);
    netmodel_open_query(obj);
}

void _logical_interface_disabled(UNUSED const char* const sig_name,
                                 const amxc_var_t* const data,
                                 UNUSED void* const priv) {
    amxd_dm_t* dm = logical_get_dm();
    amxd_object_t* obj = amxd_dm_signal_get_object(dm, data);
    logical_interface_status(obj, false);
    netmodel_close_query(obj, true);
}

void _logical_interface_added(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    SAH_TRACEZ_IN(ME);
    logical_intf_priv_t* intf = NULL;
    amxd_dm_t* dm = logical_get_dm();
    amxd_object_t* obj = amxd_dm_signal_get_object(dm, data);
    amxd_object_t* inst = amxd_object_get_instance(obj, NULL, GET_UINT32(data, "index"));
    logical_interface_status(inst, amxd_object_get_value(bool, inst, "Enable", NULL));
    intf = logical_intf_priv_t_ctor(inst);
    when_null_trace(intf, exit, ERROR, "Failed to create interface priv structure");
    inst->priv = intf;
    netmodel_open_query(inst);
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

void _logical_interface_lower_layers_changed(UNUSED const char* const sig_name,
                                             const amxc_var_t* const data,
                                             UNUSED void* const priv) {
    amxd_dm_t* dm = logical_get_dm();
    amxd_object_t* obj = amxd_dm_signal_get_object(dm, data);
    when_null_trace(obj, exit, ERROR, "Failed to get interface object");
    SAH_TRACEZ_INFO(ME, "Changing LowerLayer from '%s' to '%s'", GETP_CHAR(data, "parameters.LowerLayers.from"), GETP_CHAR(data, "parameters.LowerLayers.to"));
    netmodel_open_query(obj);
exit:
    return;
}

uint32_t get_system_uptime(void) {
    uint32_t uptime = 0;
    struct sysinfo info;
    when_failed_trace(sysinfo(&info), exit, ERROR, "Could not read total uptime of the system");
    uptime = info.uptime;
exit:
    return uptime;
}

logical_intf_priv_t* logical_intf_priv_t_ctor(amxd_object_t* intf) {
    SAH_TRACEZ_IN(ME);
    logical_intf_priv_t* priv = NULL;

    when_null(intf, exit);
    priv = (logical_intf_priv_t*) calloc(1, sizeof(logical_intf_priv_t));
    when_null(priv, exit);

    priv->last_change = get_system_uptime();
    priv->obj = intf;

exit:
    SAH_TRACEZ_OUT(ME);
    return priv;
}

amxd_status_t _lastchange_on_read(amxd_object_t* const object,
                                  UNUSED amxd_param_t* const param,
                                  amxd_action_t reason,
                                  UNUSED const amxc_var_t* const args,
                                  amxc_var_t* const retval,
                                  UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_unknown_error;
    logical_intf_priv_t* intf_priv = NULL;
    uint32_t since_change = 0;
    uint32_t uptime = 0;

    if(reason != action_param_read) {
        SAH_TRACEZ_NOTICE(ME, "wrong reason, expected action_param_read(%d) got %d", action_param_read, reason);
        rv = amxd_status_invalid_action;
        goto exit;
    }

    when_null_trace(object, skip, ERROR, "object can not be NULL");
    // when a parent object of port gets read,
    // this function will also be called for the template object
    when_null(object->priv, skip);
    intf_priv = (logical_intf_priv_t*) object->priv;
    uptime = get_system_uptime();
    when_true_trace(uptime < intf_priv->last_change, skip, ERROR, "UpTime is smaller than last change");
    since_change = uptime - intf_priv->last_change;
    rv = amxd_status_ok;

skip:
    when_failed_trace(amxc_var_set_uint32_t(retval, since_change),
                      exit, ERROR, "failed to set parameter lastchange");
exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}

amxd_status_t _interface_destroy(amxd_object_t* intf,
                                 UNUSED amxd_param_t* param,
                                 amxd_action_t reason,
                                 UNUSED const amxc_var_t* const args,
                                 UNUSED amxc_var_t* const retval,
                                 UNUSED void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t status = amxd_status_unknown_error;
    amxd_object_type_t intf_type = amxd_object_invalid;
    logical_intf_priv_t* intf_priv = NULL;

    when_false_trace(reason == action_object_destroy, exit, NOTICE, "Wrong reason, expected action_object_destroy(%d) got %d", action_object_destroy, reason);

    intf_type = amxd_object_get_type(intf);
    when_false_trace(intf_type == amxd_object_instance, exit, NOTICE, "Wrong type, expected amxd_object_instance(%d) got %d", amxd_object_instance, intf_type);

    when_null_trace(intf, exit, ERROR, "Interface can not be NULL");
    intf_priv = (logical_intf_priv_t*) intf->priv;
    when_null_trace(intf_priv, exit, ERROR, "intf_priv has not been allocated");
    netmodel_close_query(intf, false);
    SAH_TRACEZ_INFO(ME, "Deleting interface %s", amxd_object_get_name(intf, AMXD_OBJECT_NAMED));
    logical_interface_destructor(intf_priv);
    intf->priv = NULL;
    status = amxd_status_ok;

exit:
    SAH_TRACEZ_OUT(ME);
    return status;
}

void logical_interface_destructor(logical_intf_priv_t* priv) {
    SAH_TRACEZ_IN(ME);
    if(priv != NULL) {
        free(priv);
        priv = NULL;
    }
    SAH_TRACEZ_OUT(ME);
}