/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <fcntl.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include "../common/mock.h"
#include "test_unit_common.h"

#include "ip_diagnostics.h"

#include "mod_ipd_common.h"
#include "mod_ipd_iplcap_common.h"

void test_iplcap_create_command_downstream_ipv6_multi_connections(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -d -6 -C 2 -f json -T -a test_auth_code -m 0 -I @500 -t 5 -P 1 -A B -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 [::1]:25000 [::1]:25001 [::1]:25002";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_downstream.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

void test_iplcap_create_command_upstream_ipv4_multi_connections(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -u -C 3-6 -f json -j -T -X -B 1000 -i 1 -o -R -K /etc/server_keys.csv -m 63 -I @0 -t 5 -P 1 -A C -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 127.0.0.1:25000 127.0.0.1:25001 127.0.0.1:25002";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_upstream.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

void test_iplcap_create_command_ipv4_single_connection_authcode_authalias(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -d -f json -T -a test_auth_code -y 1 -m 0 -I @500 -t 5 -P 1 -A B -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 127.0.0.1:25000";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_authcode_authalias.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

void test_iplcap_create_command_only_authalias(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -d -4 -f json -T -a test_auth_key -y 1 -m 0 -I @500 -t 5 -P 1 -A B -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 127.0.0.1:25000";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_only_authalias.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

void test_iplcap_create_command_authalias_authkeyfile(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -d -f json -T -y 1 -K /etc/server_keys.csv -m 0 -I @500 -t 5 -P 1 -A B -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 127.0.0.1:25000";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_authalias_authkeyfile.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

static void array_it_free(amxc_array_it_t* it) {
    void* data = amxc_array_it_get_data(it);
    if(data != NULL) {
        free(data);
    }
}

static void assert_create_sh_script(amxc_string_t* cmd, int expected_rv) {
    amxc_var_t params;
    amxc_array_t sh_script;
    int rv = -1;
    amxc_var_init(&params);
    amxc_array_init(&sh_script, 0);
    rv = iplcap_create_sh_script(&params, cmd, &sh_script);
    assert_int_equal(rv, expected_rv);
    iplcap_delete_test_script();
    amxc_array_clean(&sh_script, array_it_free);
    amxc_var_clean(&params);
}

void test_iplcap_create_sh_script_safe_command(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "udpst -d -f json 127.0.0.1:25000");
    assert_create_sh_script(&cmd, 0);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_semicolon(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst; rm -rf /");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_pipe(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst | cat");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_and(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst && echo hacked");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_redirect(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst > /tmp/x");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_backtick(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst `id`");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_cmd_subst(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst $(id)");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_parens(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst (echo)");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_dollar(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst $HOME");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_newline(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst\nrm -rf /");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_backslash(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst \\");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_bad_first_token(UNUSED void** state) {
    amxc_string_t cmd;
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", "/usr/bin/udpst* -d");
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_sh_script_reject_overlong(UNUSED void** state) {
    amxc_string_t cmd;
    char buf[5000];
    memset(buf, 'a', sizeof(buf));
    buf[sizeof(buf) - 1] = '\0';
    amxc_string_init(&cmd, 0);
    amxc_string_setf(&cmd, "%s", buf);
    assert_create_sh_script(&cmd, -1);
    amxc_string_clean(&cmd);
}

void test_iplcap_create_command_authcode_authalias_authkeyfile(UNUSED void** state) {
    amxc_var_t params;
    amxc_string_t cmd;
    const char* expected_cmd = "udpst -d -f json -T -a test_auth_code -y 1 -m 0 -I @500 -t 5 -P 1 -A B -L 30 -U 90 -F 50 -c 3 -h 10 -q 10 127.0.0.1:25000";
    amxc_var_init(&params);
    amxc_string_init(&cmd, 0);

    // Read test data from JSON file
    amxc_var_t* data = dummy_read_json_from_file("../common/test_data/test_iplcap_authcode_authalias_authkeyfile.json");
    assert_non_null(data);
    amxc_var_copy(&params, data);
    amxc_var_delete(&data);

    iplcap_create_command(&params, &cmd);

    assert_string_equal(amxc_string_get(&cmd, 0), expected_cmd);

    amxc_string_clean(&cmd);
    amxc_var_clean(&params);
}

void test_iplcap_map_error_message_to_status(UNUSED void** state) {
    struct error_test_case {
        const char* error_message;
        iplcap_test_status_t expected_status;
    };

    struct error_test_case test_cases[] = {
        // Error_CannotResolveHostName
        { "ERROR: Server hostname or IP address required when client", iplcap_test_error_err_cannot_resolve_host_name },
        { "ERROR: Invalid format for IPv6 address with port number", iplcap_test_error_err_cannot_resolve_host_name },
        { "ERROR: Specified IP address does not match address family", iplcap_test_error_err_cannot_resolve_host_name },

        // Error_NoRouteToHost
        { "ERROR: Socket mgmt, action 1 failure for 127.0.0.1:25000", iplcap_test_error_err_no_route_to_host },
        { "SOCKET ERROR: Connection refused (127.0.0.1:25000)", iplcap_test_error_err_no_route_to_host },
        { "BIND ERROR: Address already in use (127.0.0.1:25000)", iplcap_test_error_err_no_route_to_host },
        { "[1]CONNECT ERROR: Connection refused", iplcap_test_error_err_no_route_to_host },
        { "ERROR: Connection allocation failure on server", iplcap_test_error_err_no_route_to_host },
        { "ERROR: Max connections exceeded", iplcap_test_error_err_no_route_to_host },
        { "ERROR: Minimum required connections (4) unavailable", iplcap_test_error_err_no_route_to_host },
        { "ERROR: Multi-connection parameters rejected by server", iplcap_test_error_err_no_route_to_host },

        // Error_InitConnectionFailed
        { "ERROR: Unable to open epoll file descriptor", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Unable to modify standard I/O FDs", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Unable to install exit signal handler", iplcap_test_error_err_init_connection_failed },
        { "ERROR: fork() failed", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Memory allocation(s) failed", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Sending rate table build failure (overrun)", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Invalid multi-connection parameters (1,2) in setup request from", iplcap_test_error_err_init_connection_failed },
        { "ERROR: Client protocol version (1) not accepted by server (2)", iplcap_test_error_err_init_connection_failed },

        // Error_NoResponse
        { "ERROR: Unexpected CRSP (5) in setup response from server", iplcap_test_error_err_no_response },
        { "ERROR: Requested test parameter(s) rejected by server 127.0.0.1:25000", iplcap_test_error_err_no_response },
        { "ERROR: Invalid version (1) in setup request from", iplcap_test_error_err_no_response },
        { "ERROR: Invalid jumbo datagram option in setup request from", iplcap_test_error_err_no_response },
        { "ERROR: Invalid traditional MTU option in setup request from", iplcap_test_error_err_no_response },
        { "ERROR: Required bandwidth not specified in setup request from", iplcap_test_error_err_no_response },
        { "ERROR: Server count exceeds maximum (10)", iplcap_test_error_err_no_response },

        // Error_PasswordRequestFailed
        { "ERROR: Authentication key exceeds 64 characters", iplcap_test_error_err_password_request_failed },
        { "ERROR: Authentication key ID requires authentication key or key file", iplcap_test_error_err_password_request_failed },
        { "ERROR: Authentication key ID (1) not found in key file", iplcap_test_error_err_password_request_failed },
        { "ERROR: No authentication keys found in key file", iplcap_test_error_err_password_request_failed },
        { "ERROR: Built without authentication functionality", iplcap_test_error_err_password_request_failed },
        { "ERROR: Authentication key and key file are mutually exclusive", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry has insufficient field count (line 1)", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry has invalid numeric ID (line 1)", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry has out-of-range ID (line 1)", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry has duplicate ID (line 1)", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry has oversized key (line 1)", iplcap_test_error_err_password_request_failed },
        { "ERROR: Key file entry count exceeds maximum (line 1)", iplcap_test_error_err_password_request_failed },

        // Error_LoginFailed
        { "ERROR: Authentication verification failed at server", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication failure of setup request from", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication time invalid in setup request from", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication time outside time window of server", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication not configured on server", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication required by server", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication method does not match server", iplcap_test_error_err_login_failed },
        { "ERROR: Unexpected authentication in setup request from", iplcap_test_error_err_login_failed },
        { "ERROR: Authentication missing in setup request from", iplcap_test_error_err_login_failed },
        { "ERROR: Invalid authentication method in setup request from", iplcap_test_error_err_login_failed },

        // Error_RejectedByRemote
        { "ERROR: Required max bandwidth exceeds available capacity on server", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Max bandwidth option required by server", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Capacity exceeded (100.0) by required bandwidth (200) in setup request from", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Client jumbo datagram size option does not match server", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Client traditional MTU option does not match server", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Server only allows one local bind address or hostname", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: One test execution only valid when server", iplcap_test_error_err_rejected_by_remote },
        { "ERROR: Log file only valid when server", iplcap_test_error_err_rejected_by_remote },

        // Error_IncorrectSize
        { "ERROR: Parameter <1> out-of-range (1-100)", iplcap_test_error_err_incorrect_size },
        { "ERROR: Low delay variation threshold > upper delay variation threshold", iplcap_test_error_err_incorrect_size },
        { "ERROR: Sub-interval period is greater than test interval time", iplcap_test_error_err_incorrect_size },
        { "ERROR: Minimum connection count > maximum connection count", iplcap_test_error_err_incorrect_size },
        { "ERROR: Bimodal count must be less than total sub-intervals", iplcap_test_error_err_incorrect_size },
        { "ERROR: Output file name length exceeds maximum", iplcap_test_error_err_incorrect_size },
        { "ERROR: Maximum from local interface requires local interface option", iplcap_test_error_err_incorrect_size },
        { "ERROR: GSO incompatible with IP fragmentation (disable jumbo sizes or increase MTU)", iplcap_test_error_err_incorrect_size },

        // Error_Timeout
        { "ERROR: Clock resolution (1000000 ns) out of range [see compile-time option DISABLE_INT_TIMER]", iplcap_test_error_err_timeout },
        { "CLOCK_GETRES ERROR: Invalid argument", iplcap_test_error_err_timeout },
        { "SIGALRM ERROR: Invalid argument", iplcap_test_error_err_timeout },
        { "ITIMER ERROR: Invalid argument", iplcap_test_error_err_timeout },
        { "ERROR: Invalid epoll_wait user data 1", iplcap_test_error_err_timeout },
        { "WARNING: Timeout awaiting response from server 127.0.0.1:25000", iplcap_test_error_err_timeout },

        // Error_Internal
        { "ERROR: client and server options are mutually exclusive", iplcap_test_error_err_internal },
        { "ERROR: Multi-connection count only set by client", iplcap_test_error_err_internal },
        { "ERROR: Ouput format options only available to client", iplcap_test_error_err_internal },
        { "ERROR: Log file only supported when executing as daemon", iplcap_test_error_err_internal },
        { "ERROR: Debug only available when used with verbose", iplcap_test_error_err_internal },
        { "ERROR: Verbose not available with JSON output format option", iplcap_test_error_err_internal },
        { "ERROR: 'invalid' is not a valid output format", iplcap_test_error_err_internal },
        { "ERROR: 'invalid' is not a valid rate adjustment algorithm", iplcap_test_error_err_internal },
        { "ERROR: Invalid number of rate adjustment algorithm identifiers", iplcap_test_error_err_internal },
        { "ERROR: Null pointer for rate adjustment algorithm identifier", iplcap_test_error_err_internal },
        { "ERROR: Output file not defined", iplcap_test_error_err_internal },
        { "ERROR: Maximum multi-connection count must be >= server count", iplcap_test_error_err_internal },
        { "ERROR: Execution as daemon only valid when server", iplcap_test_error_err_internal },

        // Error_Other
        { "OPEN ERROR: No such file or directory (/tmp/test.log)", iplcap_test_error_err_other },
        { "FOPEN ERROR: < /tmp/test.log > Permission denied", iplcap_test_error_err_other },
        { "FSTAT ERROR: < /tmp/test.log > No such file or directory", iplcap_test_error_err_other },
        { "[1]F_SETFL ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]EPOLL_CTL ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]SET SO_REUSEADDR ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]SET SO_SNDBUF ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]SET SO_RCVBUF ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]GET SO_SNDBUF ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]GET SO_RCVBUF ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]GETSOCKNAME ERROR: Invalid argument", iplcap_test_error_err_other },
        { "[1]GETPEERNAME ERROR: Invalid argument", iplcap_test_error_err_other },
        { "IPV6_V6ONLY ERROR: Invalid argument", iplcap_test_error_err_other },
        { "ERROR: Failure setting IP ToS/TClass (1) Invalid argument", iplcap_test_error_err_other },

        // Edge cases
        { NULL, iplcap_test_error_err_other },
        { "", iplcap_test_error_err_other },
        { "ERROR: Unknown error message that doesn't match any pattern", iplcap_test_error_err_other }
    };

    int num_test_cases = sizeof(test_cases) / sizeof(test_cases[0]);
    for(int i = 0; i < num_test_cases; i++) {
        struct error_test_case* test_case = &test_cases[i];
        iplcap_test_status_t result = iplcap_map_error_message_to_status(test_case->error_message);
        assert_int_equal(result, test_case->expected_status);
    }
}
