/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include <string.h>
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_bridging.h"
#include <amxo/amxo.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_timer.h>

#include "../common/test-util.h"
#include "mock_bridging.h"

/*
 *
 */

static void s_discovery_cb(gmap_eth_dev_bridging_discovery_result_t result) {
    function_called();
    assert_int_equal(result, BRIDGING_DISCOVERY_SUPPORTED);
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());
}

void bridging_setup_discovered(void) {
    if(amxp_sigmngr_find_signal(NULL, "wait:Bridging.") == NULL) {
        assert_success(amxp_sigmngr_add_signal(NULL, "wait:Bridging."));
    }

    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    expect_string(__wrap_amxb_be_who_has, object_path, "Bridging.");
    will_return(__wrap_amxb_be_who_has, amxut_bus_ctx());
    expect_function_call(s_discovery_cb);

    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    assert_success(amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL));
    amxut_bus_handle_events();

    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());
}

void bridging_teardown_discovered(void) {
    amxp_signal_t* signal = amxp_sigmngr_find_signal(NULL, "wait:Bridging.");
    amxp_signal_delete(&signal);
    gmap_eth_dev_bridging_reset_discovery();
}

/* wrap fetching the netdev context so that we don't have to initialize the
 * entire gmap-mod-ethernet-dev module. */
amxb_bus_ctx_t* __wrap_gmap_eth_dev_get_ctx_netdev(void);

amxb_bus_ctx_t* __wrap_gmap_eth_dev_get_ctx_netdev(void) {
    return amxut_bus_ctx();
}

void bridging_setup_netdev(void) {
    amxut_dm_load_odl("../common/dummy-netdev.odl");
    amxut_dm_load_odl("../common/netdev-data.odl");
}



typedef struct s_mac_list {
    amxc_htable_it_t it;
    amxc_set_t macs;
} s_mac_list_t;

static struct {
    /* table path -> set[mac addresses]. */
    amxc_htable_t* macs;
} s_mock_data = {
    .macs = NULL,
};

static void s_mock_mac_list_clean(UNUSED const char* key,
                                  amxc_htable_it_t* it) {
    s_mac_list_t* list = amxc_htable_it_get_data(it, s_mac_list_t, it);

    when_null(it, exit);
    amxc_set_clean(&list->macs);
    free(list);

exit:
    return;
}

static s_mac_list_t* s_mock_find_or_create(const char* path) {
    amxc_htable_it_t* it;
    s_mac_list_t* list;

    assert_non_null(s_mock_data.macs);

    it = amxc_htable_get(s_mock_data.macs, path);
    if(it == NULL) {
        list = malloc(sizeof(s_mac_list_t));
        assert_non_null(list);
        assert_success(amxc_htable_it_init(&list->it));
        assert_success(amxc_set_init(&list->macs, false));
        assert_success(amxc_htable_insert(s_mock_data.macs, path, &list->it));
    } else {
        list = amxc_htable_it_get_data(it, s_mac_list_t, it);
    }

    return list;
}

static amxd_object_t* s_mock_find_port(const char* bridge,
                                       const char* port) {
    assert_non_null(bridge);
    assert_non_null(port);

    return amxd_dm_findf(amxut_bus_dm(),
                         "Bridging.Bridge.[.Port.1.Name=='%s'].Port.[Name=='%s'].",
                         bridge, port);
}

static s_mac_list_t* s_mock_for_port(const amxd_object_t* port) {
    char* path;
    s_mac_list_t* list;

    assert_non_null(port);

    path = amxd_object_get_path(port, AMXD_OBJECT_INDEXED);
    assert_non_null(path);

    list = s_mock_find_or_create(path);

    free(path);
    return list;
}

static void s_mock_emit_macevent(amxd_object_t* port,
                                 const char* mac,
                                 const char* action) {
    amxc_var_t event_data;
    amxc_var_t* event_params = NULL;
    amxd_object_t* bridge = amxd_object_get_parent(amxd_object_get_parent(port));

    assert_non_null(port);

    amxc_var_init(&event_data);
    amxc_var_set_type(&event_data, AMXC_VAR_ID_HTABLE);
    event_params = amxc_var_add_key(amxc_htable_t, &event_data, "data", NULL);
    assert_non_null(event_params);

    if(mac != NULL) {
        amxc_var_add_key(cstring_t, event_params, "MACAddress", mac);
    }
    if(action != NULL) {
        amxc_var_add_key(cstring_t, event_params, "Action", action);
    }

    if(bridge != NULL) {
        amxc_var_push(cstring_t, amxc_var_add_new_key(event_params, "Bridge"),
                      amxd_object_get_path(bridge, AMXD_OBJECT_INDEXED));
    }

    amxd_object_send_signal(port, "MACEvent!", &event_data, false);
    amxc_var_clean(&event_data);
}

static amxd_status_t s_mock_get_mac_list(amxd_object_t* object,
                                         UNUSED amxd_function_t* func,
                                         amxc_var_t* args,
                                         UNUSED amxc_var_t* ret) {
    s_mac_list_t* macs = s_mock_for_port(object);
    amxc_var_t* mac_list = amxc_var_add_key(amxc_llist_t, args, "mac_list", NULL);

    assert_non_null(macs);

    amxc_set_iterate(flag, &macs->macs) {
        if((flag->flag != NULL) && (*flag->flag != 0)) {
            amxc_var_add(cstring_t, mac_list, flag->flag);
        }
    }

    return amxd_status_ok;
}


void bridging_setup_mock_minimal(void) {
    assert_null(s_mock_data.macs);

    amxc_htable_new(&s_mock_data.macs, 0);
    assert_non_null(s_mock_data.macs);

    amxut_resolve_function("GetMACList", s_mock_get_mac_list);
    amxut_dm_load_odl("../common/bridging-base-dm.odl");
}

void bridging_setup_mock(void) {
    assert_null(s_mock_data.macs);

    bridging_setup_mock_minimal();
    amxut_dm_load_odl("../common/bridging-macevent.odl");
    amxut_dm_load_odl("../common/bridging-getmaclist.odl");
}

void bridging_teardown_mock(void) {
    amxc_htable_delete(&s_mock_data.macs, s_mock_mac_list_clean);
}

void bridging_mock_add_mac(const char* bridge,
                           const char* port,
                           const char* mac) {
    amxd_object_t* obj;
    s_mac_list_t* list;

    assert_non_null(s_mock_data.macs);
    assert_non_null(bridge);
    assert_non_null(port);
    assert_non_null(mac);

    obj = s_mock_find_port(bridge, port);
    assert_non_null(obj);

    list = s_mock_for_port(obj);
    assert_non_null(list);

    amxc_set_add_flag(&list->macs, mac);

    s_mock_emit_macevent(obj, mac, "MAC_Added");
}

void bridging_mock_remove_mac(const char* bridge,
                              const char* port,
                              const char* mac) {
    amxd_object_t* obj;
    s_mac_list_t* list;

    assert_non_null(s_mock_data.macs);
    assert_non_null(bridge);
    assert_non_null(port);
    assert_non_null(mac);

    obj = s_mock_find_port(bridge, port);
    assert_non_null(obj);

    list = s_mock_for_port(obj);
    assert_non_null(list);

    amxc_set_remove_flag(&list->macs, mac);

    s_mock_emit_macevent(obj, mac, "MAC_Removed");
}

void bridging_mock_clear_mac(const char* bridge,
                             const char* port,
                             bool notify) {
    amxd_object_t* obj;
    s_mac_list_t* list;

    assert_non_null(s_mock_data.macs);
    assert_non_null(bridge);
    assert_non_null(port);

    obj = s_mock_find_port(bridge, port);
    assert_non_null(obj);

    list = s_mock_for_port(obj);
    assert_non_null(list);

    if(notify) {
        amxc_set_iterate(flag, &list->macs) {
            s_mock_emit_macevent(obj, flag->flag, "MAC_Removed");
        }
    }
    amxc_set_reset(&list->macs);

}

void bridging_mock_send_mac(const char* bridge,
                            const char* port,
                            const char* mac,
                            const char* action) {
    amxd_object_t* obj;

    assert_non_null(s_mock_data.macs);
    assert_non_null(bridge);
    assert_non_null(port);

    obj = s_mock_find_port(bridge, port);
    assert_non_null(obj);

    s_mock_emit_macevent(obj, mac, action);
}
