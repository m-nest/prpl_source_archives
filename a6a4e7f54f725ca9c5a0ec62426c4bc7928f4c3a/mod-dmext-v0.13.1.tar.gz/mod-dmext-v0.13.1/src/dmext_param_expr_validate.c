/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>

#include "dmext_priv.h"
#include "dmext_assert.h"

amxd_status_t _check_expression(amxd_object_t* object,
                                amxd_param_t* param,
                                amxd_action_t reason,
                                const amxc_var_t* const args,
                                amxc_var_t* const retval,
                                void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t* data = (amxc_var_t*) priv;
    const char* expr_str = NULL;
    amxc_var_t var_value;
    amxc_var_t* value = NULL;
    amxp_expr_t* expr = NULL;

    amxc_var_init(&var_value);

    when_null(param, exit);
    when_true_status(reason != action_param_validate &&
                     reason != action_describe_action,
                     exit,
                     status = amxd_status_function_not_implemented);
    when_null_status(data, exit, status = amxd_status_invalid_arg);
    when_true_status(amxc_var_type_of(data) != AMXC_VAR_ID_CSTRING, exit,
                     status = amxd_status_invalid_arg);

    status = amxd_action_describe_action(reason, retval, "check_expression", priv);
    when_true(status == amxd_status_ok, exit);

    status = amxd_action_param_validate(object, param, reason, args, retval, priv);
    when_failed(status, exit);

    expr_str = amxc_var_constcast(cstring_t, data);
    when_str_empty_status(expr_str, exit, status = amxd_status_invalid_arg);

    when_true_status(amxp_expr_new(&expr, expr_str) != 0, exit, status = amxd_status_invalid_arg);
    amxc_var_set_type(&var_value, AMXC_VAR_ID_HTABLE);
    value = amxc_var_add_new_key(&var_value, "value");
    amxc_var_copy(value, args);

    if(!amxp_expr_eval_var(expr, &var_value, NULL)) {
        status = amxd_status_invalid_value;
    }

exit:
    amxp_expr_delete(&expr);
    amxc_var_clean(&var_value);
    return status;
}

amxd_status_t _check_is_nullvalue_or_in(amxd_object_t* object,
                                        amxd_param_t* param,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        amxc_var_t* const retval, void* priv) {
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t* priv_var = (amxc_var_t*) priv;

    if((priv_var == NULL) ||
       (amxc_var_type_of(priv_var) != AMXC_VAR_ID_LIST) ||
       (GETI_ARG(priv_var, 0) == NULL) ||
       (GETI_ARG(priv_var, 1) == NULL)) {
        return amxd_status_invalid_function_argument;
    }
    status = amxd_action_param_check_is_in(object, param, reason, args, retval, GETI_ARG(priv_var, 0));
    if(status != amxd_status_ok) {
        char* input = amxc_var_dyncast(cstring_t, args);
        if((input != NULL) && (strcmp(input, GETI_CHAR(priv_var, 1)) == 0)) {
            status = amxd_status_ok;
        }
        free(input);
    } else if(reason == action_describe_action) {
        amxc_var_t* description = GETP_ARG(retval, "check_is_in");
        amxc_var_take_it(description);
        amxc_var_set_key(retval, "check_is_nullvalue_or_in", description, AMXC_VAR_FLAG_DEFAULT);
    }
    return status;
}

amxd_status_t _check_is_empty_or_in(amxd_object_t* object,
                                    amxd_param_t* param,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv) {
    amxd_status_t status = amxd_status_unknown_error;

    status = amxd_action_param_check_is_in(object, param, reason, args, retval, priv);
    if(status != amxd_status_ok) {
        char* input = amxc_var_dyncast(cstring_t, args);
        if((input == NULL) || (*input == 0)) {
            status = amxd_status_ok;
        }
        free(input);
    } else if(reason == action_describe_action) {
        amxc_var_t* description = GETP_ARG(retval, "check_is_in");
        amxc_var_take_it(description);
        amxc_var_set_key(retval, "check_is_empty_or_in", description, AMXC_VAR_FLAG_DEFAULT);
    }

    return status;
}

amxd_status_t _check_is_empty_or_length_equal_to(amxd_object_t* object,
                                                 amxd_param_t* param,
                                                 amxd_action_t reason,
                                                 const amxc_var_t* const args,
                                                 amxc_var_t* const retval,
                                                 void* priv) {
    amxd_status_t status;

    when_true_status(reason != action_param_validate,
                     exit,
                     status = amxd_status_function_not_implemented);

    status = amxd_action_param_check_maximum(object, param, reason, args, retval, priv);
    status |= amxd_action_param_check_minimum(object, param, reason, args, retval, priv);
    if(status != amxd_status_ok) {
        const char* input = amxc_var_constcast(cstring_t, args);
        status = ((input == NULL) || (*input == 0)) ? amxd_status_ok : amxd_status_invalid_value;
    }

exit:
    return status;
}