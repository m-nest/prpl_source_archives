/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Other libraries' headers */
#include <amxc/amxc.h>        /* to satisfy include of amxm/amxm.h */
#include <amxc/amxc_macros.h> /* when_false() */
#include <amxm/amxm.h>        /* AMXM_CONSTRUCTOR */

/* Own headers */
#include "cleanup.h"   /* do_clean_up_all() */
#include "dm_info.h"   /* dm_info_init() */
#include "notif.h"     /* notif_init() */
#include "pon_ctrl.h"  /* pon_ctrl_init() */

#include "mod_xpon_trace.h"

/**
 * Initialize this mod_xpon-prpl module.
 *
 * This function is called when the tr181-xpon plugin loads this module,
 * which is normally at startup.
 */
static AMXM_CONSTRUCTOR mod_xpon_prpl_start(void) {

    int rc = -1;
    bool rv;

    SAH_TRACEZ_INFO(ME, "start");

    rv = dm_info_init();
    when_false(rv, exit);

    notif_init();

    rv = pon_ctrl_init();
    when_false(rv, exit);

    rc = 0; /* success */

exit:
    return rc;
}

/**
 * Clean up this mod_xpon-prpl module.
 *
 * This function is called when the tr181-xpon plugin unloads this module,
 * which is normally at shutdown/reboot.
 *
 * More specifically:
 *
 * - on a system with glibc the destructor is called when tr181-xpon unloads
 *   this module with amxm_so_close(), which calls dlclose().
 *
 * - on a system with musl a C library dlclose() is a no-op. The destructor is
 *   called when tr181-xpon exits. On such a system tr181-xpon should have
 *   called clean_up_all() before calling amxm_so_close(). Then this destructor
 *   no longer has to do any work. SAH_TRACE log statements will not appear
 *   because amxrt will already have closed logging.
 */
static AMXM_DESTRUCTOR mod_xpon_prpl_stop(void) {

    SAH_TRACEZ_INFO(ME, "stop");
    do_clean_up_all();
    return 0;
}

