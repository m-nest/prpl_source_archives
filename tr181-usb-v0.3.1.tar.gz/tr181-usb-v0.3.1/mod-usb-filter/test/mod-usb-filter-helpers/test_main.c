#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_helpers.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_set_hex_value),
        cmocka_unit_test(test_int_to_hex_value),
        cmocka_unit_test(test_create_usb_device_interface),
        cmocka_unit_test(test_valid_hex_value),
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
