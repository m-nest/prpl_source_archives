/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include <string.h>
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_bridging.h"
#include <amxo/amxo.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_timer.h>

#include "../common/test-setup.h"
#include "../common/test-util.h"
#include "../common/mock_gmap.h"
#include "test_bridging.h"
#include "mock_bridging.h"
#include <arpa/inet.h>

int test_setup_bridging_discovery(UNUSED void** state) {
    int result = amxut_bus_setup(state);
    if(amxp_sigmngr_find_signal(NULL, "wait:Bridging.") == NULL) {
        assert_success(amxp_sigmngr_add_signal(NULL, "wait:Bridging."));
    }
    return result;
}

int test_teardown_bridging_discovery(UNUSED void** state) {
    /* Tear down anything the test may add in order to not influence the next tests. */
    bridging_teardown_discovered();
    bridging_teardown_mock();
    return amxut_bus_teardown(state);
}

static void s_discovery_cb(gmap_eth_dev_bridging_discovery_result_t result) {
    check_expected(result);
}

static void s_discovery_cb_2(gmap_eth_dev_bridging_discovery_result_t result) {
    check_expected(result);
}


void test_gmap_eth_dev_bridging_discovery__no_bridging(UNUSED void** state) {
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN no Bridging. data model

    // WHEN trying to discover Bridging.
    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));

    // THEN the callback isn't called until the timeout runs out
    amxut_timer_go_to_future_ms(4990);

    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_NOT_SUPPORTED);
    amxut_timer_go_to_future_ms(11);

    // FINALLY the result is saved and a restart returns immediately.
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_NOT_SUPPORTED);
    assert_null(gmap_eth_dev_bridging_ctx());
    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_NOT_SUPPORTED);
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
}

static void s_test_support(bool load_events, bool load_funcs, int result) {
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN the basic, standard-only Bridging. data model with optional extra parts
    bridging_setup_mock_minimal();
    if(load_events) {
        amxut_dm_load_odl("../common/bridging-macevent.odl");
    }
    if(load_funcs) {
        amxut_dm_load_odl("../common/bridging-getmaclist.odl");
    }

    // WHEN trying to discover Bridging.
    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    amxut_bus_handle_events();

    // THEN the callback is executed immediately
    amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL);

    expect_string(__wrap_amxb_be_who_has, object_path, "Bridging.");
    will_return(__wrap_amxb_be_who_has, amxut_bus_ctx());
    expect_value(s_discovery_cb, result, result);
    amxut_bus_handle_events();

    assert_int_equal(gmap_eth_dev_bridging_discovered(), result);
    if(result == BRIDGING_DISCOVERY_SUPPORTED) {
        assert_non_null(gmap_eth_dev_bridging_ctx());
    } else {
        assert_null(gmap_eth_dev_bridging_ctx());
    }

    // AND no callback is executed after the timeout runs out
    amxut_timer_go_to_future_ms(8000);

    // FINALLY the result is saved and a restart returns immediately.
    expect_value(s_discovery_cb, result, result);
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    assert_int_equal(gmap_eth_dev_bridging_discovered(), result);
    if(result == BRIDGING_DISCOVERY_SUPPORTED) {
        assert_non_null(gmap_eth_dev_bridging_ctx());
    } else {
        assert_null(gmap_eth_dev_bridging_ctx());
    }
}

void test_gmap_eth_dev_bridging_discovery__unsupported_bridging(UNUSED void** state) {
    s_test_support(false, false, BRIDGING_DISCOVERY_NOT_SUPPORTED);
}

void test_gmap_eth_dev_bridging_discovery__unsupported_bridging_event(UNUSED void** state) {
    s_test_support(true, false, BRIDGING_DISCOVERY_NOT_SUPPORTED);
}

void test_gmap_eth_dev_bridging_discovery__unsupported_bridging_func(UNUSED void** state) {
    s_test_support(false, true, BRIDGING_DISCOVERY_NOT_SUPPORTED);
}

void test_gmap_eth_dev_bridging_discovery__supported_bridging(UNUSED void** state) {
    s_test_support(true, true, BRIDGING_DISCOVERY_SUPPORTED);
}

void test_gmap_eth_dev_bridging_discovery__delayed_bridging(UNUSED void** state) {
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN no Bridging. data model

    // WHEN trying to discover Bridging.
    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    amxut_bus_handle_events();

    // THEN the callback is not executed immediately...
    amxut_timer_go_to_future_ms(3000);

    // ...but only when the data model was loaded
    bridging_setup_mock();
    amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL);

    expect_string(__wrap_amxb_be_who_has, object_path, "Bridging.");
    will_return(__wrap_amxb_be_who_has, amxut_bus_ctx());
    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_SUPPORTED);
    amxut_bus_handle_events();

    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());

    // AND no callback is executed after the timeout runs out
    amxut_timer_go_to_future_ms(8000);

    // FINALLY the result is saved and a restart returns immediately.
    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_SUPPORTED);
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());
}

void test_gmap_eth_dev_bridging_discovery__canceled_bridging(UNUSED void** state) {
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN the full Bridging. data model
    bridging_setup_mock();
    amxut_bus_handle_events();

    // WHEN a discovery is started and canceled immediately
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    gmap_eth_dev_bridging_cancel_discovery();

    /* EXPECT no callback called */
    amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(8000);
}

void test_gmap_eth_dev_bridging_discovery__delayed_canceled_bridging(UNUSED void** state) {
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN the full Bridging. data model
    bridging_setup_mock();
    amxut_bus_handle_events();

    // WHEN a discovery is started and canceled after a delay
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    amxut_timer_go_to_future_ms(2000);
    gmap_eth_dev_bridging_cancel_discovery();

    /* EXPECT no callback called */
    amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL);
    amxut_bus_handle_events();
    amxut_timer_go_to_future_ms(8000);
}

void test_gmap_eth_dev_bridging_discovery__bad_param(UNUSED void** state) {
    assert_int_not_equal(gmap_eth_dev_bridging_start_discovery(NULL, 5000), 0);

    amxut_timer_go_to_future_ms(8000);
    /* EXPECT no callback called */
}

void test_gmap_eth_dev_bridging_discovery__twice(UNUSED void** state) {
    // Same scenario as test_gmap_eth_dev_bridging_discovery__delayed_bridging,
    // with added checks for trying to start a second discovery at various points.
    // AT START, bridging wasn't discovered
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_UNKNOWN);
    assert_null(gmap_eth_dev_bridging_ctx());

    // GIVEN no Bridging. data model

    // WHEN trying to discover Bridging.
    expect_string(__wrap_amxb_wait_for_object, object_path, "Bridging.");
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));

    assert_int_not_equal(gmap_eth_dev_bridging_start_discovery(s_discovery_cb_2, 5000), 0);
    amxut_bus_handle_events();
    assert_int_not_equal(gmap_eth_dev_bridging_start_discovery(s_discovery_cb_2, 5000), 0);

    // THEN the callback is not executed immediately...
    amxut_timer_go_to_future_ms(3000);
    assert_int_not_equal(gmap_eth_dev_bridging_start_discovery(s_discovery_cb_2, 5000), 0);

    // ...but only when the data model was loaded
    bridging_setup_mock();
    amxp_sigmngr_emit_signal(NULL, "wait:Bridging.", NULL);

    expect_string(__wrap_amxb_be_who_has, object_path, "Bridging.");
    will_return(__wrap_amxb_be_who_has, amxut_bus_ctx());
    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_SUPPORTED);
    amxut_bus_handle_events();

    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());

    // AND no callback is executed after the timeout runs out
    amxut_timer_go_to_future_ms(8000);

    // FINALLY the result is saved and a restart returns immediately.
    expect_value(s_discovery_cb, result, BRIDGING_DISCOVERY_SUPPORTED);
    assert_success(gmap_eth_dev_bridging_start_discovery(s_discovery_cb, 5000));
    assert_int_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_non_null(gmap_eth_dev_bridging_ctx());
}
