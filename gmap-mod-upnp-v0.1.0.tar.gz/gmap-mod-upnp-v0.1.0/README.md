# gmap-mod-upnp

[[_TOC_]]

## Description

This gmap module will copy any entries from the upnp. datamodel into the gmap-server datamodel of their respective devices.

## compile and install

```
make
sudo make install
```

# test
make test


### compile/install build dependencies: (make + sudo make install)

 * libamxb
 * libamxc
 * libamxp
 * libamxd
 * libamxo
 * libamxs
 * libgmap-client
 * libgmap-ext
 * libsahtrace
 * yajl

### runtime dependencies

 * libamxb
 * libamxc
 * libamxp
 * libamxd
 * libamxo
 * libamxs
 * libgmap-client
 * libgmap-ext
 * libsahtrace
 * yajl
