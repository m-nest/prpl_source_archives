/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "oopsmonitor_priv.h"
#include "oopsmonitor.h"

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc_macros.h>
#include <amxd/amxd_object.h>
#include <amxm/amxm.h>
#include <filetransfer/filetransfer.h>

#include <sys/sendfile.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>

#define ME DEFAULT_TRACE_ZONE_NAME

#define BUFFER_SIZE 8192  // Adjust buffer size for performance

typedef struct {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
    amxd_object_t* root_object;
} app_t;

static app_t app;

amxd_dm_t* get_dm(void) {
    return app.dm;
}

amxo_parser_t* get_parser(void) {
    return app.parser;
}

amxd_object_t* get_root_object(void) {
    return app.root_object;
}

amxd_object_t* get_object(const char* path) {
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(get_dm(), "%s", path);
exit:
    return object;
}

int copy(const char* spath, const char* dpath, bool del_source) {
    FILE* src_file = NULL;
    FILE* dest_file = NULL;
    int retval = 1;
    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    struct stat sb = {0};
    struct timeval times[2];

    when_null(spath, exit);
    when_null(dpath, exit);

    when_failed_trace(stat(spath, &sb), exit, ERROR, "Invalid file %s", spath);

    src_file = fopen(spath, "rb");
    when_null_trace(src_file, exit, ERROR, "Error opening source file (%s)", spath);

    dest_file = fopen(dpath, "wb");
    when_null_trace(dest_file, exit, ERROR, "Error opening destination file (%s)", dpath);

    while((bytes_read = fread(buffer, 1, BUFFER_SIZE, src_file)) > 0) {
        size_t bytes_written = fwrite(buffer, 1, bytes_read, dest_file);
        when_false_trace(bytes_written == bytes_read, exit, ERROR, "Error writing to destination file %s", dpath);
    }

    times[0].tv_sec = sb.st_atim.tv_sec;
    times[0].tv_usec = sb.st_atim.tv_nsec / 1000;
    times[1].tv_sec = sb.st_mtim.tv_sec;
    times[1].tv_usec = sb.st_mtim.tv_nsec / 1000;
    utimes(dpath, times);
    if(del_source) {
        unlink(spath);
    }
    sync();

    retval = 0;

exit:
    if(src_file != NULL) {
        fclose(src_file);
    }
    if(dest_file != NULL) {
        fclose(dest_file);
    }

    return retval;
}

static int dmesg_filter_files(const struct dirent* dirent) {
    return (strncmp(dirent->d_name, "dmesg-ramoops-", 14) == 0 );
}

static int dmesg_compare_files(const struct dirent** da, const struct dirent** db) {
    return strverscmp((*da)->d_name, (*db)->d_name);
}

static int get_process_ID(const char* line_log, dmesg_info_t* dmesg_info) {
    amxc_var_t ret_data;
    amxc_var_t data;
    const char* process_ID = NULL;
    int retval = 1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    when_null(line_log, exit);
    when_null(dmesg_info, exit);

    if(dmesg_info->process == NULL) {
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &data, GET_PROCESS_ID_INPUT, line_log);

        amxm_execute_function(SHARED_OBJ_NAME, MODULE_NAME, GET_PROCESS_ID_FUNC, &data, &ret_data);

        process_ID = GET_CHAR(&ret_data, GET_PROCESS_ID_OUTPUT);

        when_str_empty(process_ID, exit);

        dmesg_info->process = calloc(strlen(process_ID) + 1, sizeof(char));

        if(dmesg_info->process != NULL) {
            strcpy(dmesg_info->process, process_ID);
        }
    }

    retval = 0;

exit:
    amxc_var_clean(&ret_data);
    amxc_var_clean(&data);

    return retval;
}

static int get_last_instruction(const char* line_log, dmesg_info_t* dmesg_info) {
    amxc_var_t ret_data;
    amxc_var_t data;
    const char* lastinstr = NULL;
    int retval = 1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    when_null(line_log, exit);
    when_null(dmesg_info, exit);

    if(dmesg_info->lastinstr == NULL) {
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &data, GET_LAST_INSTRUCTION_INPUT, line_log);

        amxm_execute_function(SHARED_OBJ_NAME, MODULE_NAME, GET_LAST_INSTRUCTION_FUNC, &data, &ret_data);

        lastinstr = GET_CHAR(&ret_data, GET_LAST_INSTRUCTION_OUTPUT);

        when_str_empty(lastinstr, exit);

        dmesg_info->lastinstr = calloc(strlen(lastinstr) + 1, sizeof(char));
        if(dmesg_info->lastinstr != NULL) {
            strcpy(dmesg_info->lastinstr, lastinstr);
        }
    }

    retval = 0;

exit:
    amxc_var_clean(&ret_data);
    amxc_var_clean(&data);

    return retval;
}

static int get_reason(const char* line_log, dmesg_info_t* dmesg_info) {
    amxc_var_t ret_data;
    amxc_var_t data;
    const char* reason = NULL;
    int retval = 1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    when_null(line_log, exit);
    when_null(dmesg_info, exit);

    if(dmesg_info->reason == NULL) {
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

        amxc_var_add_key(cstring_t, &data, GET_REASON_INPUT, line_log);

        amxm_execute_function(SHARED_OBJ_NAME, MODULE_NAME, GET_REASON_FUNC, &data, &ret_data);

        reason = GET_CHAR(&ret_data, GET_REASON_OUTPUT);

        when_str_empty(reason, exit);

        dmesg_info->reason = calloc(strlen(reason) + 1, sizeof(char));
        if(dmesg_info->reason != NULL) {
            strcpy(dmesg_info->reason, reason);
        }
    }

    retval = 0;

exit:
    amxc_var_clean(&ret_data);
    amxc_var_clean(&data);

    return retval;
}

static int get_useful_log(char* line_log, char** useful_log) {
    amxc_var_t ret_data;
    amxc_var_t data;
    int retval = 1;

    amxc_var_init(&data);
    amxc_var_init(&ret_data);

    when_null(line_log, exit);

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_set_type(&ret_data, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, &data, GET_USEFUL_LOG_INPUT, line_log);

    amxm_execute_function(SHARED_OBJ_NAME, MODULE_NAME, GET_USEFUL_LOG_FUNC, &data, &ret_data);

    amxc_var_t* var_name = amxc_var_get_path(&ret_data, GET_USEFUL_LOG_OUTPUT, AMXC_VAR_FLAG_DEFAULT);
    *useful_log = amxc_var_take(cstring_t, var_name);

    retval = 0;

exit:
    amxc_var_clean(&ret_data);
    amxc_var_clean(&data);

    return retval;
}

int dmesg_parse_file(const char* file_path, dmesg_info_t* dmesg_info) {
    int retval = 1;
    char* line = NULL;
    char* line_log = NULL;
    size_t line_size = 0;
    struct stat status;
    FILE* file_d = NULL;

    when_null(file_path, exit);
    when_null(dmesg_info, exit);
    when_failed(stat(file_path, &status), exit);

    file_d = fopen(file_path, "r");
    when_null_trace(file_d, exit, WARNING, "Failed retrieving file information (%s)", file_path);

    while(getline(&line, &line_size, file_d) > 0) {
        get_useful_log(line, &line_log);
        if(line_log != NULL) {
            get_process_ID(line_log, dmesg_info);
            get_last_instruction(line_log, dmesg_info);
            get_reason(line_log, dmesg_info);
            free(line_log);
            line_log = NULL;
        }
    }

    if(dmesg_info->lastinstr == NULL) {
        dmesg_info->lastinstr = strdup("Unknown");
    }
    if(dmesg_info->process == NULL) {
        dmesg_info->process = strdup("Unknown");
    }
    if(dmesg_info->reason == NULL) {
        dmesg_info->reason = strdup("Unknown");
    }

    retval = 0;

    fclose(file_d);
    gmtime_r(&status.st_mtim.tv_sec, &dmesg_info->time);

exit:
    free(line);
    return retval;
}

static char* getSoftwareVersion(void) {
    int ret = -1;
    amxc_var_t bus_get;
    amxc_var_init(&bus_get);
    amxb_bus_ctx_t* bus_ctx = amxb_be_who_has("DeviceInfo.");
    char* swversion = NULL;

    if(bus_ctx != NULL) {
        ret = amxb_get(bus_ctx, "DeviceInfo.SoftwareVersion", 0, &bus_get, 5);
        if(ret != AMXB_STATUS_OK) {
            SAH_TRACEZ_ERROR(ME, "Failed to get %s", "DeviceInfo.SoftwareVersion");
        } else {
            if(!amxc_var_is_null(&bus_get)) {
                swversion = strdup(GETP_CHAR(&bus_get, "0.'DeviceInfo.'.SoftwareVersion"));
            } else {
                SAH_TRACEZ_ERROR(ME, "bus_get(DeviceInfo.SoftwareVersion) is NULL. Swupdate unable to start!");
            }
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "No bus_ctx of DeviceInfo returned. Swupdate unable to start!");
    }

    amxc_var_clean(&bus_get);
    return swversion;
}

int oops_add_instance(amxd_trans_t* trans, dmesg_info_t* dmesg_info, const char* file_name) {
    int retval = 1;
    amxc_ts_t time_var;
    char* version_s = NULL;

    when_null(dmesg_info, exit);
    when_null(file_name, exit);

    amxd_trans_select_pathf(trans, ".KernelFault");
    amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    amxd_trans_add_inst(trans, 0, NULL);
    amxd_trans_set_value(cstring_t, trans, "FaultLocation", file_name);
    amxd_trans_set_value(cstring_t, trans, "LastInstruction", dmesg_info->lastinstr);
    if(amxc_ts_from_tm(&time_var, &dmesg_info->time) == 0) {
        amxd_trans_set_value(amxc_ts_t, trans, "TimeStamp", &time_var);
    }
    version_s = getSoftwareVersion();
    if(version_s != NULL) {
        amxd_trans_set_value(cstring_t, trans, "FirmwareVersion", version_s);
        free(version_s);
    }
    amxd_trans_set_value(cstring_t, trans, "ProcessName", dmesg_info->process);
    amxd_trans_set_value(cstring_t, trans, "Reason", dmesg_info->reason);
    amxd_trans_select_pathf(trans, ".^.^"); // restore path
    retval = 0;
exit:
    return retval;
}

static void free_dmesg_info(dmesg_info_t* dmesg_info) {
    if(dmesg_info->lastinstr != NULL) {
        free(dmesg_info->lastinstr);
    }
    if(dmesg_info->process != NULL) {
        free(dmesg_info->process);
    }
    if(dmesg_info->reason != NULL) {
        free(dmesg_info->reason);
    }
    memset(dmesg_info, 0, sizeof(dmesg_info_t));
}

static void move_dmesg_file(const char* file_path, const char* destination_dir, const char* file_name) {
    char* save_path = NULL;

    when_null(file_path, exit);
    when_null(destination_dir, exit);
    when_null(file_name, exit);

    save_path = calloc(strlen(destination_dir) + strlen(file_name) + 2, sizeof(char));
    when_null(save_path, exit);

    sprintf(save_path, "%s/%s", destination_dir, file_name);
    copy(file_path, save_path, true);
    free(save_path);

exit:
    return;
}

int scan_oops_dir(const char* path) {
    int retval = 1;
    int nb_oopses = 0;
    uint32_t upgrade_count = 0;
    uint32_t max_adds = 0;
    char file_path[256];
    struct dirent** namelist = NULL;
    dmesg_info_t dmesg_info;
    amxc_var_t params;
    amxd_trans_t trans;
    amxd_object_t* object = get_root_object();
    amxd_status_t trans_rv = amxd_status_unknown_error;

    amxc_var_init(&params);
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null(path, exit);
    when_failed(amxd_object_get_params(object, &params, amxd_dm_access_protected), exit);

    amxd_trans_select_object(&trans, object);

    nb_oopses = scandir(path, &namelist, dmesg_filter_files, dmesg_compare_files);

    amxd_trans_set_value(uint32_t, &trans, "PreviousBootCount", nb_oopses);
    upgrade_count = GET_UINT32(&params, "LastUpgradeCount");
    amxd_trans_set_value(uint32_t, &trans, "LastUpgradeCount", upgrade_count + nb_oopses);

    max_adds = GET_UINT32(&params, "MaxKernelFaultEntries") - GET_UINT32(&params, "KernelFaultNumberOfEntries");
    memset(&dmesg_info, 0, sizeof(dmesg_info_t));

    for(int i = 0; i < nb_oopses; i++) {
        if((max_adds > 0) && (snprintf(file_path, sizeof(file_path), "%s/%s", path, namelist[i]->d_name) < (int) sizeof(file_path))) {
            char* destination_name = NULL;
            int rv = asprintf(&destination_name, "dmesg-ramoops-%u", upgrade_count + i);
            if(rv != -1) {
                if((dmesg_parse_file(file_path, &dmesg_info) == 0) &&
                   (oops_add_instance(&trans, &dmesg_info, destination_name) == 0)) {
                    move_dmesg_file(file_path, GET_CHAR(&params, "StoragePath"), destination_name);
                    max_adds--;
                }
                free(destination_name);
                free_dmesg_info(&dmesg_info);
            }
        }
        free(namelist[i]);
    }
    free(namelist);

    trans_rv = amxd_trans_apply(&trans, get_dm());
    when_failed_trace(trans_rv, exit, ERROR, "Transaction failed");
    retval = 0;

exit:
    amxc_var_clean(&params);
    amxd_trans_clean(&trans);
    return retval;
}

static void filetransfer_event_cb(int fd, UNUSED void* priv) {
    ftx_fd_event_handler(fd);
}

static int filetransfer_fdset_cb(int fd, bool add) {
    int retval = -1;
    if(add) {
        retval = amxo_connection_add(get_parser(), fd, filetransfer_event_cb, NULL, AMXO_LISTEN, NULL);
    } else {
        retval = amxo_connection_remove(get_parser(), fd);
    }
    SAH_TRACEZ_INFO(ME, "%s connection fd %d %s", add ? "add" : "remove", fd, (retval == 0) ? "success" : "failure");
    return retval;
}

static int init(amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 1;
    app.dm = dm;
    app.parser = parser;
    app.root_object = get_object("KernelFaults");

    ftx_init(filetransfer_fdset_cb);

    retval = ( app.root_object == NULL);
    return retval;
}

static int cleanup(void) {
    ftx_clean();
    app.dm = NULL;
    app.parser = NULL;
    return 0;
}

int _oopsmonitor_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser) {
    int retval = 0;

    switch(reason) {
    case AMXO_START:
        SAH_TRACEZ_NOTICE(ME, "Starting oopsmonitor plugin");
        const char* path_s = NULL;
        amxm_shared_object_t* so = NULL;

        amxc_var_t* module_path = amxo_parser_get_config(parser, "module_path");
        path_s = amxc_var_constcast(cstring_t, module_path);
        retval = amxm_so_open(&so, SHARED_OBJ_NAME, path_s);
        if(retval != 0) {
            SAH_TRACEZ_ERROR(ME, "Error in amxm_so_open with module: %s (%s)", SHARED_OBJ_NAME, path_s);
            goto exit;
        }

        retval = init(dm, parser);

        break;
    case AMXO_STOP:
        SAH_TRACEZ_NOTICE(ME, "Stopping oopsmonitor plugin");
        retval = cleanup();
        break;
    }

exit:
    return retval;
}
