/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>

#include <debug/sahtrace.h>

#include <yajl/yajl_gen.h>
#include <yajl/yajl_parse.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>
#include <amxj/amxj_variant.h>

#include <lcm/lcm_assert.h>
#include <lcm/lcm_helpers.h>

#include "cthulhu_lpm_defines.h"
#include "utils.h"
#include "ctr_policy.h"

#define ME "lpm"


#define CTR_LIST_CREATE "create"
#define CTR_LIST_UPGRADE "upgrade"
#define CTR_LIST_REMOVE "remove"
#define IMG_LIST_REMOVE "imageremove"

static amxc_var_t* policydesc = NULL;

static const char* policy_event_list[] = {
    "ERROR",
    "onNew",
    "onExisting",
    "onExistingUpgrade",
    "onExistingDowngrade",
    "onUnknown"
};

static const char* policy_action_list[] = {
    "Invalid",
    "Install",
    "Uninstall",
    "Update",
    "Ignore"
};

static const char* policy_event_to_string(policy_event_t policy_event) {
    return policy_event_list[policy_event];
}

static policy_action_t policy_action_from_string(const char* policy_action) {
    for(size_t i = 0; i < sizeof(policy_action_list) / sizeof(policy_action_list[0]); i++) {
        if(!strcasecmp(policy_action_list[i], policy_action)) {
            return i;
        }
    }
    return PA_ERROR;
}

amxd_status_t load_json(const char* path, amxc_var_t** var) {
    amxd_status_t status = amxd_status_unknown_error;
    variant_json_t* reader = NULL;
    int read_length = 0;
    int fd = 0;

    ASSERT_NOT_NULL(var, goto exit);

    fd = open(path, O_RDONLY);
    ASSERT_TRUE(fd != -1, goto exit, "Can't open file [%s]", path);

    ASSERT_SUCCESS(amxj_reader_new(&reader), goto exit);
    ASSERT_NOT_NULL(reader, goto exit);

    do {
        read_length = amxj_read(reader, fd);
    } while(read_length > 0);

    *var = amxj_reader_result(reader);
    ASSERT_NOT_NULL(*var, goto exit);

    status = amxd_status_ok;
exit:
    close(fd);
    amxj_reader_delete(&reader);
    return status;
}

policy_action_t get_policy_action(policy_event_t policy_event, const char* id, amxc_var_t* desc, const char* idkey, policylog_t* log) {
    const char* global_policy_app = NULL;
    const char* policy = policy_event_to_string(policy_event);
    amxc_var_t* applications = GET_ARG(desc, POLICY_JSON_APPLICATIONS);
    if(!applications) {
        applications = GET_ARG(desc, POLICY_JSON_SANDBOXES);
        ASSERT_NOT_NULL(applications, goto error);
    }
    amxc_var_t* global = GET_ARG(desc, POLICY_JSON_GLOBAL);
    ASSERT_NOT_NULL(global, goto error);
    ASSERT_NOT_NULL(policy, goto error);

    if(id) {
        const amxc_llist_t* llist_applications = amxc_var_constcast(amxc_llist_t, applications);
        amxc_llist_for_each(it, llist_applications) {
            amxc_var_t* var_app = amxc_var_from_llist_it(it);
            const char* id_app = GET_CHAR(var_app, idkey);
            ASSERT_NOT_NULL(id_app, goto error, "No key [%s] found in policy", idkey);
            if(!strcmp(id, id_app)) {
                const char* policy_app = GET_CHAR(var_app, policy);
                if(policy_app) {
                    policy_action_t found_policy_action = policy_action_from_string(policy_app);
                    const char* found_policy_action_str = policy_action_list[found_policy_action];
                    SAH_TRACEZ_INFO(ME, "Policy [%s] found for %s [%s] : [%s]", policy, idkey, id, found_policy_action_str);
                    if(log != NULL) {
                        log->policy_scope = POLICY_SCOPE_APPLICATION;
                        log->policy_action = found_policy_action_str;
                    }
                    return found_policy_action;
                } else {
                    SAH_TRACEZ_INFO(ME, "Policy [%s] not found for %s [%s]", policy, idkey, id);
                    break;
                }
            }
        }
    }
    global_policy_app = GET_CHAR(global, policy);
    if(global_policy_app) {
        policy_action_t found_policy_action = policy_action_from_string(global_policy_app);
        const char* found_policy_action_str = policy_action_list[found_policy_action];
        SAH_TRACEZ_INFO(ME, "Using global policy [%s] : [%s]", policy, found_policy_action_str);
        if(log != NULL) {
            log->policy_scope = POLICY_SCOPE_GLOBAL;
            log->policy_action = found_policy_action_str;
        }
        return found_policy_action;
    } else {
        add_log_error_info(log, "Global policy [%s] not found for %s [%s]", policy, idkey, id);
        goto error;
    }


error:
    return PA_ERROR;
}

static policy_event_t get_policy_event(amxc_var_t* o, amxc_var_t* n, const char* versionkey, policylog_t* log) {
    bool currently_installed = (o != NULL);
    bool on_new_firmware = (n != NULL);
    const char* over = GET_CHAR(o, versionkey);
    const char* nver = GET_CHAR(n, versionkey);

    if(log != NULL) {
        log->old_version = over;
        log->new_version = nver;
    }

    if(currently_installed && !on_new_firmware) {
        return PE_ONUNKNOWN;
    } else if(!currently_installed && on_new_firmware) {
        if(is_valid_version_string(nver) != amxd_status_ok) {
            add_log_error_info(log, "Onboarded container has invalid version [%s], but ignoring and installing anyway", nver);
        }
        return PE_ONNEW;
    } else if(currently_installed && on_new_firmware) {
        // upgrade
        SAH_TRACEZ_INFO(ME, "Comparing versions: old [%s] <> new [%s]", over, nver);
        if(is_valid_version_string(over) != amxd_status_ok) {
            add_log_error_info(log, "Previously installed container has invalid version [%s], but continuing and considering it as [0.0.0]", over);
            over = "0.0.0";
        }
        if(is_valid_version_string(nver) != amxd_status_ok) {
            add_log_error_info(log, "Invalid new version [%s]", nver);
            goto exit;
        }
        int comp = compare_version_string(over, nver);
        if(comp < 0) {
            return PE_ONEXISTINGUPGRADE;
        } else if(comp > 0) {
            return PE_ONEXISTINGDOWNGRADE;
        } else {
            SAH_TRACEZ_INFO(ME, "New and old container/sandbox have same version [%s]", nver);
            return PE_ONEXISTING;
        }
    } else {
        SAH_TRACEZ_WARNING(ME, "Invalid policy request");
    }

exit:
    return PE_ERROR;
}

static amxc_var_t* find_var_by_id(amxc_var_t* varlist, const char* id, const char* key) {
    const amxc_llist_t* llist_ci = amxc_var_constcast(amxc_llist_t, varlist);
    amxc_llist_for_each(it, llist_ci) {
        amxc_var_t* var_inst = amxc_var_from_llist_it(it);
        const char* var_id = GET_CHAR(var_inst, key);
        if(!strcmp(var_id, id)) {
            return var_inst;
        }
    }
    return NULL;
}

static amxd_status_t add_to_resultlist(amxc_var_t* resultlist, const char* sublist, amxc_var_t* item) {
    amxd_status_t ret = amxd_status_unknown_error;
    amxc_var_t* subvar = NULL;
    amxc_var_t* slist = GET_ARG(resultlist, sublist);

    ASSERT_NOT_NULL(slist, goto exit, "sublist [%s] not found", sublist);

    if(item) {
        subvar = amxc_var_add(amxc_htable_t, slist, NULL);
        amxc_var_copy(subvar, item);
    }

    ret = amxd_status_ok;
exit:
    return ret;
}

static const char* container_get_duid(amxc_var_t* ctr) {
    const char* ret = GET_CHAR(ctr, CTHULHU_CONTAINER_ID);
    return (ret ? ret : "");
}

static amxd_status_t apply_policy_action(policy_action_t policy_action, amxc_var_t* olditem, amxc_var_t* newitem, amxc_var_t* resultlist) {
    amxd_status_t status = amxd_status_unknown_error;
    switch(policy_action) {
    case PA_INSTALL:
        // add to list, so ctr will be installed
        ASSERT_NOT_NULL(newitem, goto exit);
        status = add_to_resultlist(resultlist, CTR_LIST_CREATE, newitem);
        if(olditem) {
            if(strcmp(container_get_duid(olditem), container_get_duid(newitem))) {
                // only mark old image for removal if it's not the same as the new one
                status |= add_to_resultlist(resultlist, IMG_LIST_REMOVE, olditem);
            }
        }
        break;
    case PA_UPDATE:
        // add to list, so ctr will be updated
        ASSERT_NOT_NULL(newitem, goto exit);
        status = add_to_resultlist(resultlist, CTR_LIST_UPGRADE, newitem);
        if(strcmp(container_get_duid(olditem), container_get_duid(newitem))) {
            // only mark old image for removal if it's not the same as the new one
            status |= add_to_resultlist(resultlist, IMG_LIST_REMOVE, olditem);
        }
        break;
    case PA_IGNORE:
        // keep old if it exists
        // mark new for removal if it exists
        status = add_to_resultlist(resultlist, CTR_LIST_CREATE, olditem);
        status |= add_to_resultlist(resultlist, IMG_LIST_REMOVE, newitem);
        break;
    case PA_UNINSTALL:
        // add old to removal list, so ctr will be removed
        // mark both old and new images for removal if any exists
        status = add_to_resultlist(resultlist, CTR_LIST_REMOVE, olditem);
        status |= add_to_resultlist(resultlist, IMG_LIST_REMOVE, olditem);
        status |= add_to_resultlist(resultlist, IMG_LIST_REMOVE, newitem);
        break;
    case PA_ERROR:
        // the policy file has an invalid action listed
        goto exit;
    }

exit:
    return status;
}

static amxd_status_t handle_policy(const char* id, amxc_var_t* oi, amxc_var_t* ni, const char* version_field, const char* jsonid_field, const char* policy_name, const char* typestr, amxc_var_t* handledlist, amxc_var_t* resultlist, policylog_t* log) {
    amxd_status_t status = amxd_status_unknown_error;
    policy_action_t policy_action = PA_ERROR;
    policy_event_t policy_event = get_policy_event(oi, ni, version_field, log);
    log->policy_event = policy_event_to_string(policy_event);
    if(policy_event == PE_ERROR) {
        SAH_TRACEZ_ERROR(ME, "Problem occured while determining policy event, using policy action IGNORE");
        policy_action = PA_IGNORE;
    } else {
        policy_action = get_policy_action(policy_event, id, GET_ARG(policydesc, policy_name), jsonid_field, log);

        SAH_TRACEZ_NOTICE(ME, "Retrieved policy [%d/%s] for %s [%s] => action [%d/%s]",
                          policy_event, policy_event_to_string(policy_event), typestr, id, policy_action, policy_action_list[policy_action]);
    }
    log->execenv = GET_CHAR(ni, "Sandbox");
    add_action_entry_to_dm(get_dm(), log, id);

    // mark item as handled
    amxc_var_add_key(bool, handledlist, id, true);

    // apply action here
    ASSERT_SUCCESS(apply_policy_action(policy_action, oi, ni, resultlist), goto exit);

    status = amxd_status_ok;
exit:
    return status;
}

amxd_status_t apply_policy(amxc_var_t* oldlist, amxc_var_t* newlist, amxc_var_t* resultlist, policy_type_t listtype) {
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t handledlist;
    const amxc_llist_t* llist_ci = NULL;
    policylog_t log = {0};
    const char* id_field = NULL;
    const char* version_field = NULL;
    const char* jsonid_field = NULL;
    const char* policy_name = NULL;
    const char* typestr = NULL;

    if(listtype == PT_CONTAINER) {
        id_field = CTHULHU_CONTAINER_LINKED_UUID;
        version_field = CTHULHU_CONTAINER_MODULEVERSION;
        jsonid_field = "uuid";
        policy_name = "containerpolicy";
        typestr = "container";
    } else if(listtype == PT_SANDBOX) {
        id_field = CTHULHU_SANDBOX_ID;
        version_field = CTHULHU_SANDBOX_VERSION;
        jsonid_field = "sandboxid";
        policy_name = "sandboxpolicy";
        typestr = "sandbox";
    }

    amxc_var_init(&handledlist);
    amxc_var_set_type(&handledlist, AMXC_VAR_ID_HTABLE);

    amxc_string_init(&log.error_info, 0);
    SAH_TRACEZ_INFO(ME, "Handling old list");
    llist_ci = amxc_var_constcast(amxc_llist_t, oldlist);
    amxc_llist_for_each(it, llist_ci) {
        amxc_var_t* oi = amxc_var_from_llist_it(it); // old item (sandbox or container)
        const char* id = GET_CHAR(oi, id_field);
        ASSERT_STR_NOT_EMPTY(id, goto exit, "Param [%s] not found", id_field);
        SAH_TRACEZ_INFO(ME, "Handling old item [%s]", id);
        amxc_var_t* ni = find_var_by_id(newlist, id, id_field); // new item (sandbox or container)
        ASSERT_SUCCESS(handle_policy(id, oi, ni, version_field, jsonid_field, policy_name, typestr, &handledlist, resultlist, &log), goto exit);
    }

    amxc_string_init(&log.error_info, 0);
    SAH_TRACEZ_INFO(ME, "Handling new list");
    llist_ci = amxc_var_constcast(amxc_llist_t, newlist);
    amxc_llist_for_each(it, llist_ci) {
        amxc_var_t* ni = amxc_var_from_llist_it(it); // new item (sandbox or container)
        const char* id = GET_CHAR(ni, id_field);
        ASSERT_STR_NOT_EMPTY(id, goto exit, "Param [%s] not found", id_field);
        bool handled = GET_BOOL(&handledlist, id);
        SAH_TRACEZ_INFO(ME, "Handling new item [%s] [%d]", id, handled);
        if(!handled) {
            ASSERT_SUCCESS(handle_policy(id, NULL, ni, version_field, jsonid_field, policy_name, typestr, &handledlist, resultlist, &log), goto exit);
        }
    }

    status = amxd_status_ok;
exit:
    amxc_var_clean(&handledlist);
    return status;
}

amxd_status_t apply_container_policy(amxc_var_t* oldctrlist, amxc_var_t* newctrlist, amxc_var_t* resultlist) {
    return apply_policy(oldctrlist, newctrlist, resultlist, PT_CONTAINER);
}

static void load_onboarded_container_configs(amxc_var_t** ctrlist) {
    DIR* d = NULL;
    struct dirent* dir = NULL;
    amxd_object_t* cthulhuobj = amxd_dm_findf(get_dm(), LPMC);
    char* onboard_path = amxd_object_get_cstring_t(cthulhuobj, CTHULHU_ONBOARDING_LOCATION, NULL);

    ASSERT_STR_NOT_EMPTY(onboard_path, return , "Invalid onboarding location");

    //load all json files in this directory
    amxc_var_new(ctrlist);
    amxc_var_set_type(*ctrlist, AMXC_VAR_ID_LIST);

    SAH_TRACEZ_INFO(ME, "Onboarding files path = %s", onboard_path);
    d = opendir(onboard_path);
    ASSERT_NOT_NULL(d, goto exit, "Cannot open onboarding path [%s]", onboard_path);

    while((dir = readdir(d)) != NULL) {
        amxc_string_t filepath;
        amxc_var_t* filejson = NULL;
        amxc_var_t* subvar = NULL;
        const char* filename = dir->d_name;
        if(!filename) {
            continue;
        }
        SKIP_DOTTED_DIRS(filename);

        amxc_string_init(&filepath, 0);
        amxc_string_appendf(&filepath, "%s/%s", onboard_path, filename);
        if(lcm_filetype(amxc_string_get(&filepath, 0)) == FILE_TYPE_REGULAR) {
            if(!strcmp(filename, "sandboxes.json")) {
                amxc_string_clean(&filepath);
                continue;
            } else if((strlen(filename) >= 5) && !strcmp(filename + strlen(filename) - 5, ".json")) {
                amxd_status_t ret = load_json(amxc_string_get(&filepath, 0), &filejson);
                subvar = amxc_var_add(amxc_htable_t, *ctrlist, NULL);
                if((ret == amxd_status_ok) && filejson) {
                    amxc_var_move(subvar, filejson);
                    amxc_var_delete(&filejson);
                } else {
                    SAH_TRACEZ_ERROR(ME, "cannot parse [%s]", amxc_string_get(&filepath, 0));
                }
            }
        }
        amxc_string_clean(&filepath);
    }
    closedir(d);

exit:
    free(onboard_path);
}

amxd_status_t load_policyfile(void) {
    amxd_status_t status = amxd_status_unknown_error;
    char* policyfile = NULL;
    amxd_object_t* pluginobj = NULL;

    pluginobj = amxd_dm_findf(get_dm(), LPMC);
    ASSERT_NOT_NULL(pluginobj, goto exit)

    policyfile = amxd_object_get_cstring_t(pluginobj, POLICYFILEOVERRIDE, NULL);

    if(STRING_EMPTY(policyfile) || (lcm_filetype(policyfile) != FILE_TYPE_REGULAR)) {
        // if the override policy file (for testing/debugging) is not set or does not exist,
        // then use the normal policy file
        free(policyfile);
        policyfile = amxd_object_get_cstring_t(pluginobj, POLICYFILE, NULL);
    }

    ASSERT_STR_NOT_EMPTY(policyfile, goto exit, "Missing policy file location");
    SAH_TRACEZ_INFO(ME, "Using policy file: %s", policyfile);
    ASSERT_SUCCESS(load_json(policyfile, &policydesc), goto exit, "Could not load policy json [%s]", policyfile);

    status = amxd_status_ok;
exit:
    free(policyfile);
    return status;
}

amxd_status_t update_ctr_list(amxc_var_t* ctrcreatelist,
                              amxc_var_t* ctrupgradelist,
                              amxc_var_t* ctrremovelist,
                              amxc_var_t* imageremovelist) {

    // ctrcreatelist is the input list of old containers,
    // but the list should be updated in place, so it is also one of 3 resulting lists.
    amxd_status_t status = amxd_status_unknown_error;

    amxc_var_t* oldctrlist = ctrcreatelist;
    amxc_var_t* newctrlist = NULL;
    amxc_var_t* resultctrlist = NULL;

    print_variant_as_trace("Input ctr list", ctrcreatelist);

    amxc_var_new(&resultctrlist);
    amxc_var_set_type(resultctrlist, AMXC_VAR_ID_HTABLE);
    add_new_sublist(resultctrlist, CTR_LIST_CREATE);
    add_new_sublist(resultctrlist, CTR_LIST_UPGRADE);
    add_new_sublist(resultctrlist, CTR_LIST_REMOVE);
    add_new_sublist(resultctrlist, IMG_LIST_REMOVE);

    load_onboarded_container_configs(&newctrlist);
    ASSERT_SUCCESS(apply_container_policy(oldctrlist, newctrlist, resultctrlist),
                   goto exit,
                   "Could not apply container policies");

    print_variant_as_trace("New container lists", resultctrlist);

    amxc_var_move(ctrcreatelist, GET_ARG(resultctrlist, CTR_LIST_CREATE));
    amxc_var_move(ctrupgradelist, GET_ARG(resultctrlist, CTR_LIST_UPGRADE));
    amxc_var_move(ctrremovelist, GET_ARG(resultctrlist, CTR_LIST_REMOVE));
    amxc_var_move(imageremovelist, GET_ARG(resultctrlist, IMG_LIST_REMOVE));

    status = amxd_status_ok;
exit:
    amxc_var_delete(&newctrlist);
    amxc_var_delete(&resultctrlist);

    return status;
}

void cleanup_policy(void) {
    amxc_var_delete(&policydesc);
}
