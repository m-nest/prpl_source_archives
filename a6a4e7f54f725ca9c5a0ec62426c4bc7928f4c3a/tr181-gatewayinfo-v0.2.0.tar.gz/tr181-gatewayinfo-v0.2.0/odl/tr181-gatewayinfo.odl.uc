{%
    // find out how many wan interfaces we have
    let wan_interfaces=0;
    for (let Itf in BD.Interfaces) {
        if (Itf.Upstream == "true" || Itf.DefaultUpstream == "true") {
            wan_interfaces++;
        }
    }
%}

#include "mod_sahtrace.odl";
#include "global_variables.odl";

%config {
    // Application name
    name = "tr181-gatewayinfo";

    sahtrace = {
        type = "syslog",
        level = "${default_log_level}"
    };

    trace-zones = {
        gatewayinfo = "${default_trace_zone_level}"
    };
    
    definition_file = "${name}_definition.odl";

    NetModelIntfName = "{% (wan_interfaces == 0) ? print("ip-lan") : print("ip-wan") %}";
}

include "${definition_file}";

import "${name}.so" as "${name}";

%define {
    entry-point tr181-gatewayinfo.gatewayinfo_main;
}
