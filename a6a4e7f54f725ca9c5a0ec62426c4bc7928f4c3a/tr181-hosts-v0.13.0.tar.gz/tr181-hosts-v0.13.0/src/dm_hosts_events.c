/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "hosts_manager.h"
#include "dm_hosts_accesscontrol.h"
#include "hosts_accesscontroller.h"
#include "hosts_scheduler.h"
#include "hosts_utils.h"
#include "hosts_sync.h"

#include <gmap/gmap.h>
#include "gmap/gmap_devices.h"
#include <debug/sahtrace_macros.h>

#define ME "hosts-dm-ac"

/**
   @brief Finds the AccessControl object associated with a given host.

   Traverses up the data model hierarchy to locate the AccessControl list,
   then iterates through its instances to find an AccessControl object whose
   PhysAddress and PhysAddressMask intersect with the host's MAC address.

   @param host_obj The host object whose associated AccessControl is sought.

   @return Pointer to the matching AccessControl object if found, otherwise NULL.
 */
static amxd_object_t* find_ac_by_host(amxd_object_t* host_obj) {
    amxd_object_t* acs_obj = amxd_object_findf(host_obj, ".^.^.AccessControl.");
    amxd_object_t* ac_obj = NULL;
    const char* host_mac = NULL;
    uint64_t host_mac_byte = 0;


    when_null_trace(acs_obj, exit, WARNING, "Cannot get list of access controller object");

    host_mac = GET_CHAR(amxd_object_get_param_value(host_obj, "PhysAddress"), NULL);
    when_str_empty_trace(host_mac, exit, ERROR, "Cannot get the phys address of the host");

    host_mac_byte = convert_str2mac(host_mac);

    amxd_object_for_each(instance, it, acs_obj) {
        amxd_object_t* obj = amxc_llist_it_get_data(it, amxd_object_t, it);
        const char* macaddr = GET_CHAR(amxd_object_get_param_value(obj, "PhysAddress"), NULL);
        const char* macaddr_mask = GET_CHAR(amxd_object_get_param_value(obj, "PhysAddressMask"), NULL);
        uint64_t macaddr_byte = 0;
        uint64_t macaddr_mask_byte = 0;
        uint64_t intersect = 1;

        if(!str_empty(macaddr)) {
            when_str_empty_trace(macaddr_mask, exit, ERROR, "Cannot get the PhysAddressMask of one AccessControl object");

            macaddr_byte = convert_str2mac(macaddr);
            macaddr_mask_byte = convert_str2mac(macaddr_mask);

            intersect = host_mac_byte & (macaddr_byte & macaddr_mask_byte);
            if(intersect != 0) {
                ac_obj = obj;
                goto exit;
            }
        }
    }
exit:
    return ac_obj;
}

/**
   @brief Retrieves the gmap key associated with a host's MAC address.

   Extracts the "PhysAddress" parameter from the given host object and uses it
   to look up the corresponding gmap device key.

   @param host_obj The host object to extract the MAC address from.

   @return The gmap key string if found, otherwise NULL.
 */
static cstring_t find_gmapkey_from_host(amxd_object_t* host_obj) {
    const amxc_var_t* tmp = amxd_object_get_param_value(host_obj, "PhysAddress");
    const cstring_t hostmac = amxc_var_constcast(cstring_t, tmp);
    cstring_t key = NULL;
    when_null_trace(hostmac, exit, ERROR, "Couldn't parse PhysAddress");
    key = gmap_devices_findByMac(hostmac);

exit:
    return key;
}

/**
   @brief Returns the primary IP address from a list of IP objects.

   Iterates through all instances in @p ip_addr and selects the IP address
   with the highest priority based on its scope and status. Global and reachable
   addresses are preferred.

   Priority rules:
   - Global scope contributes 1 point.
   - Reachable status contributes 2 points.
   The address with the highest total priority is returned.

   @param ip_addr Pointer to the object containing IP address instances.

   @return The selected primary IP address as a C string, or NULL if none found.
 */
static const char* hosts_get_primary_ip(const amxd_object_t* ip_addr) {
    /* Priorities of different aspects of an address. The final priority is a sum
     * of the priorities of components. */
    typedef enum _priority {
        EMPTY = -1,
        ZERO = 0,
        GLOBAL = 1,
        REACHABLE = 2,
    } address_priority_t;

    address_priority_t best_priority = EMPTY;
    const char* best_address = NULL;

    amxd_object_for_each(instance, it, ip_addr) {
        amxd_object_t* inst = amxc_container_of(it, amxd_object_t, it);
        address_priority_t priority = ZERO;
        const char* scope = GET_CHAR(amxd_object_get_param_value(inst, "Scope"), NULL);
        const char* status = GET_CHAR(amxd_object_get_param_value(inst, "Status"), NULL);
        const char* addr = GET_CHAR(amxd_object_get_param_value(inst, "IPAddress"), NULL);

        if((scope != NULL) && (strcmp(scope, "global") == 0)) {
            priority += GLOBAL;
        }
        if((status != NULL) && (strcmp(status, "reachable") == 0)) {
            priority += REACHABLE;
        }
        if(priority > best_priority) {
            best_priority = priority;
            best_address = addr;
        }
    }

    return best_address;
}

/**
   @brief Sets the primary IP address of a host object in the data model.

   Selects the primary IP address by first checking IPv4 addresses, then IPv6
   if no IPv4 address is available. Updates the host object's "IPAddress" field
   in the data model using a transaction.

   @param obj Pointer to the host object. Must not be NULL.
 */
static void hosts_dm_set_primary_ip(amxd_object_t* obj) {
    amxd_object_t* ipv4_obj = amxd_object_get(obj, "IPv4Address");
    amxd_object_t* ipv6_obj = amxd_object_get(obj, "IPv6Address");
    const char* address = NULL;
    amxd_trans_t trans;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(obj, exit, ERROR, "Object is NULL");

    address = hosts_get_primary_ip(ipv4_obj);
    address = address != NULL ? address : hosts_get_primary_ip(ipv6_obj);
    address = address != NULL ? address : "";

    amxd_trans_select_object(&trans, obj);
    amxd_trans_set_value(cstring_t, &trans, "IPAddress", address);
    when_failed_trace(amxd_trans_apply(&trans, hosts_manager_get_dm()), exit, ERROR,
                      "Failed to update IPAddress");

exit:
    amxd_trans_clean(&trans);
    return;
}

/**
   @brief Handles changes to a host's "Active" status.

   This callback is triggered when a host object's "Active" parameter changes.
   It retrieves the host object associated with the event and the corresponding
   access controller (AC) object. Based on the new active state:
    - If active, starts the scheduler timer for the AC.
    - If inactive, stops the scheduler timer for the AC.

   @param event_name  The name of the event (unused).
   @param event_data  The event data containing the new "Active" state.
   @param priv        User-defined private data (unused).
 */
void _hosts_active_changed(UNUSED const cstring_t const event_name,
                           const amxc_var_t* const event_data,
                           UNUSED void* const priv) {
    amxd_object_t* host_obj = NULL;
    amxd_object_t* ac_obj = NULL;
    bool active = GETP_BOOL(event_data, "parameters.Active.to");

    host_obj = amxd_dm_signal_get_object(hosts_manager_get_dm(), event_data);
    when_null_trace(host_obj, exit, ERROR, "No Host object found");

    ac_obj = find_ac_by_host(host_obj);
    when_null_trace(ac_obj, exit, INFO, "No access controller bound to the host %s",
                    amxd_object_get_name(host_obj, AMXD_OBJECT_NAMED))

    if(active) {
        hosts_scheduler_flex_start_timer(ac_obj);
    } else {
        hosts_scheduler_flex_stop_timer(ac_obj);
    }

exit:
    return;
}

/**
   @brief Handles changes to a host's "Protected" status.

   This callback is triggered when a host object's "Protected" parameter changes.
   It retrieves the host object from the event data and determines the corresponding
   device key in GMAP. Based on the new protected state:
    - If protected, sets the "protected" tag on the GMAP device.
    - If not protected, clears the "protected" tag on the GMAP device.

   @param event_name  The name of the event (unused).
   @param event_data  The event data containing the new "Protected" state.
   @param priv        User-defined private data (unused).
 */
void _hosts_protected_changed(UNUSED const cstring_t const event_name,
                              const amxc_var_t* const event_data,
                              UNUSED void* const priv) {
    amxd_object_t* host_obj = NULL;
    amxc_string_t param;
    bool protected;
    cstring_t dev_key = NULL;
    const char* prefix = GET_CHAR(amxo_parser_get_config(hosts_manager_get_parser(), "global_vendor_prefix_"), NULL);

    amxc_string_init(&param, 0);
    amxc_string_setf(&param, "parameters.%sProtected.to", prefix);

    protected = GETP_BOOL(event_data, amxc_string_get(&param, 0));
    host_obj = amxd_dm_signal_get_object(hosts_manager_get_dm(), event_data);
    when_null_trace(host_obj, exit, ERROR, "No Host object found");
    dev_key = find_gmapkey_from_host(host_obj);
    when_null_trace(dev_key, exit, ERROR, "No gmap device key found");

    if(protected) {
        gmap_device_setTag(dev_key, "protected", NULL, gmap_traverse_this);
    } else {
        gmap_device_clearTag(dev_key, "protected", NULL, gmap_traverse_this);
    }
    free(dev_key);
exit:
    amxc_string_clean(&param);

    return;
}

/**
   @brief Handles the addition of a new host object.

   This callback is triggered when a host object is added to the system. It retrieves
   the host object from the event data and determines the associated access controller (AC) object.
   Based on the host's "Active" state:
    - If active, starts the scheduler timer for the associated AC.
    - If inactive, stops the scheduler timer for the associated AC.

   @param event_name  The name of the event (unused).
   @param event_data  The event data containing the new host parameters.
   @param priv        User-defined private data (unused).
 */
void _hosts_added(UNUSED const cstring_t const event_name,
                  const amxc_var_t* const event_data,
                  UNUSED void* const priv) {
    amxd_object_t* host_obj = NULL;
    amxd_object_t* ac_obj = NULL;
    bool active = GETP_BOOL(event_data, "parameters.Active");

    host_obj = amxd_dm_signal_get_object(hosts_manager_get_dm(), event_data);
    when_null_trace(host_obj, exit, ERROR, "No Host object found");

    ac_obj = find_ac_by_host(host_obj);

    if(active) {
        hosts_scheduler_flex_start_timer(ac_obj);
    } else {
        hosts_scheduler_flex_stop_timer(ac_obj);
    }
exit:
    return;
}

/**
   @brief Handles the removal of a host object.

   This callback is triggered when a host object is removed from the system. It retrieves
   the host object from the event data and determines the associated access controller (AC) object.
   The scheduler timer for the associated AC is stopped to ensure no further scheduled actions
   are executed for the removed host.

   @param event_name  The name of the event (unused).
   @param event_data  The event data containing the host parameters.
   @param priv        User-defined private data (unused).
 */
void _hosts_removed(UNUSED const cstring_t const event_name,
                    const amxc_var_t* const event_data,
                    UNUSED void* const priv) {
    amxd_object_t* host_obj = NULL;
    amxd_object_t* ac_obj = NULL;
    host_obj = amxd_dm_signal_get_object(hosts_manager_get_dm(), event_data);
    when_null_trace(host_obj, exit, ERROR, "No Host object found");

    ac_obj = find_ac_by_host(host_obj);

    hosts_scheduler_flex_stop_timer(ac_obj);
exit:
    return;
}

/**
   @brief Updates the primary IP address of a host when IP information changes.

   This callback is triggered when an IP address object is added or changed. It determines
   the associated host object (going up the object hierarchy if needed) and updates its
   primary IP address in the data model accordingly.

   @param event_name  The name of the event triggering this callback.
   @param event_data  The event data containing the IP address object.
   @param priv        User-defined private data (unused).
 */
void _ip_info_updated(const cstring_t const event_name,
                      const amxc_var_t* const event_data,
                      UNUSED void* const priv) {
    amxd_object_t* host_obj = NULL;
    amxd_object_t* ip_addr_obj = amxd_dm_signal_get_object(hosts_manager_get_dm(), event_data);

    when_null_trace(ip_addr_obj, exit, ERROR, "No IP Address object found");

    if(strcmp(event_name, "dm:object-changed") == 0) {
        // ip_addr_obj is an instance, need to go up one level higher
        host_obj = amxd_object_get_parent(amxd_object_get_parent(ip_addr_obj));
    } else {
        host_obj = amxd_object_get_parent(ip_addr_obj);
    }

    when_null_trace(host_obj, exit, ERROR, "No Host object found");

    hosts_dm_set_primary_ip(host_obj);

exit:
    return;
}

/**
   @brief Handles changes to the CleanupHostsThreshold parameter.

   This callback is triggered when the CleanupHostsThreshold parameter changes. It ensures
   that the number of inactive hosts in the system does not exceed the specified threshold.
   A threshold of -1 indicates that inactive hosts should not be removed.

   @param event_name  The name of the event triggering this callback.
   @param event_data  The event data containing the new threshold value.
   @param priv        User-defined private data (unused).
 */
void _hosts_CleanUpHostsThreshold_changed(UNUSED const cstring_t const event_name,
                                          const amxc_var_t* const event_data,
                                          UNUSED void* const priv) {
    int cleanup_threshold = GETP_INT32(event_data, "parameters.CleanupHostsThreshold.to");
    when_true_trace(cleanup_threshold < 0, exit, INFO, "CleanupHostsThreshold = -1, Not removing inactive Hosts");

    hosts_sync_ensure_inactive_host_count(cleanup_threshold);
exit:
    return;
}
