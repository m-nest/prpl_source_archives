/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/**
 * @file dmm.h
 *
 * @author Inango (inango@inango-systems.com)
 * @brief General header file describes structures, macro definitions and function prototypes
 *          for generic functions used across the DataModel Mapper.
 * @version 1.0.0
 * @date 2025-11-26
 *
 * @copyright   Copyright (c) 2023 SoftAtHome
 *              Copyright (c) 2025 Inango
 *
 */

#if !defined(__DMM_H__)
#define __DMM_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include <amxc/amxc_macros.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_path.h>
#include <amxd/amxd_object_event.h>

#include <amxo/amxo.h>
#include <amxo/amxo_save.h>

#include <amxb/amxb.h>
#include <amxb/amxb_types.h>
#include <amxb/amxb_be_intf.h>
#include "dmm_trie.h"

/**
 * @brief Main structure of the DataModel mapper
 *
 */
typedef struct {
    amxd_dm_t* dm;               /*!< Pointer to the Mapper internal datamodel */
    amxo_parser_t* parser;       /*!< Pointer to the configured ambiorix datamodel parser */
    amxd_object_t* map_base;     /*!< Pointer to the base object of the datamodel */
    amxc_array_t* mapping_paths; /*!< Array of the root mapping path for define proper connection */
} prpl_dmm_t;

#define DMM_OBJECTS_CONFIG  "dmm-object"                        /*!< Parameter in the ODL mapping file, describes general mapping rules*/
#define DMM_OBJECTS_POST_TRANSLATE_CONFIG  "dmm-post-translate" /*!< Parameter in the ODL mapping file, post translate mapping which would connect response root with the mapped component root*/
#define DMM_OBJECTS_PENDING "pending-dmm-object"                /*!< Pending mapping objects */
#define DMM_OBJECTS         "active-dmm-object"                 /*!< Active mapping objects */
#define DMM_OBJECTS_RENAME  "dmm-object-rename"                 /*!< Parameter in the ODL mapping file, describes datamodel objects and parameters that should be renamed */
#define DMM_OBJECTS_HIDE    "dmm-object-hide"                   /*!< Parameter in the ODL mapping file, describes datamodel objects and parameters that should be hidden*/
#define DMM_ROOTOBJ_RETRY_COUNT "dmm-rootobj-retry-count"       /*!< Parameter in the ODL mapping file, describes retru count for getting root object from a connected component*/
#define DMM_ROOTOBJ_RETRY_INTERVAL "dmm-rootobj-retry-interval" /*!< Parameter in the ODL mapping file, interval between retries */

#define MAX_PATH_LEN 256                                        /*!< Maximum length of the datamodel path*/
#define I_PLACEHOLDER_LEN 3                                     /*!< Length of the {i} placeholder */

/**
 * @brief Enum describe types of downstream requests including specific requests from ba-cli
 *
 */
typedef enum {
    DMM_GET,           /*!< Determine get request */
    DMM_SET,           /*!< Determine set request*/
    DMM_ADD,           /*!< Determine add request */
    DMM_DEL,           /*!< Determine delete request */
    DMM_LIST,          /*!< Determine list request */
    DMM_DESCRIBE,      /*!< Determine describe request */
    DMM_EXEC,          /*!< Determine exec request */
    DMM_GET_SUPPORTED, /*!< Determine get supported request */
    DMM_GET_INSTANCES, /*!< Determine get instances request */
    DMM_SUBSCRIBE,     /*!< Determine subscribe request */
    DMM_UNSUBSCRIBE,   /*!< Determine unsubscribe request */
    DMM_RQT_UNKNOWN    /*!< Unknown request detected */
} dmm_downstream_request_type;

/**
 * @brief Structure describes mapping node for object or RPC.
 *
 */
typedef struct {
    amxc_llist_it_t it;                     /*!< Helps iterate through ambiorix list */
    uint64_t call_id;                       /*!< Identifier for called RPC. Unique value */
    const char* map_obj;                    /*!< Current mapping object */
    amxb_request_t* request;                /*!< Current async forwarded request. Handles RPC */
    int32_t refs;                           /*!< Keeps track of number of subscribers */

    amxb_be_done_cb_fn_t done_fn;           /*!< Callback for related RPC. Called when RPC finished job*/
    amxc_llist_t child_requests;            /*!< Lis of child async forwarded requests */

    amxc_var_t ret;                         /*!< Keeps return value of the executed RPC */

    amxp_timer_t* wait_timer;               /*!< Timer for delayed RPC calls */
    dmm_downstream_request_type ds_rq_type; /*!< Flag shows current request type */

    const TreeNode* backward_node;          /*!<  Pointer required for processing _list response */
} map_info_t;

/**
 * @brief Enum describe types of the moving and renaming for datamodel path
 *
 */
typedef enum {
    DMM_RENAME_SAME,      /*!< Used when rename/move rule is the same*/
    DMM_RN_PARAM,         /*!< Rule for renaming parameter */
    DMM_RN_OBJ,           /*!< Rule for renaming object */
    DMM_RN_OBJ_RN_PARAM,  /*!<Rule for renaming object and parameter */
    DMM_RN_DOWN,          /*!< Rule for renaming previous object */
    DMM_RN_DOWN_PARAM,    /*!< Rule for renaming previous object with child parameter */
    DMM_RN_DOWN_RN_PARAM, /*!< Rule for renaming previous object and parameter */
    DMM_MV_UP,            /*!< Rule for moving object up on 1 stage */
    DMM_MV_UP_PARAM,      /*!< Rule for moving parameter up on 1 stage */
    DMM_MV_UP_RN_PARAM,   /*!< Rule for moving object with parameter up on 1 stage */
    DMM_RN_UNKNOWN        /*!< Unknown rule detected */
} mv_rn_type;

/**
 * @brief Cleans up the DMM translator component.
 *
 * This function releases all resources held by the DMM.
 * 1. Calls `dmm_remove_subscriptions` to clean up all active and pending subscriptions.
 * 2. Resets the pointers to the DM and parser.
 * 3. Deletes the sorted mapping paths array.
 * 4. Calls `dmm_object_delete` to free the DMM's internal base object.
 *
 * @param dm Unused. The local AMX Data Model.
 * @param parser Unused. The AMX Open parser.
 * @return int Returns 0 on success.
 */
int dmm_translator_cleanup(UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser);

/**
 * @brief Initializes the DMM translator component.
 *
 * Sets up the internal DMM state (`mapper` structure) using the provided DM and parser.
 * It ensures necessary configuration tables (`DMM_OBJECTS_CONFIG`, `DMM_OBJECTS_PENDING`,
 * `DMM_OBJECTS`, `DMM_OBJECTS_RENAME`) exist and populates the active objects list.
 * It iterates through the configured objects: if a real path is defined, the object
 * is moved to `DMM_OBJECTS_PENDING` for verification; otherwise, `dmm_update_dm` is called
 * immediately. Finally, it builds the sorted array of mapping paths.
 *
 * @param dm Pointer to the local AMX Data Model.
 * @param parser Pointer to the AMX Open parser containing DMM configuration.
 * @return int Returns 0 on success, or -1 on failure.
 */
int dmm_translator_init(UNUSED amxd_dm_t* dm, UNUSED amxo_parser_t* parser);

/**
 * @brief Translates a local Data Model path to the real (backend) object path.
 *
 * This function iterates through the sorted list of mapping paths (`mapper.mapping_paths`)
 * to find the longest matching prefix of the local path.
 * If a match is found:
 * 1. It retrieves the corresponding real path from the configuration.
 * 2. It replaces the matched prefix in the local path with the real path string.
 * 3. The `amxd_path_t` structure is updated in place with the real path.
 *
 * @param path The amxd_path_t structure containing the local path, which will be updated
 * to hold the real path on the bus.
 * @return const char* Returns the mapping path (the local path prefix that matched) on success, or NULL.
 */
const char* dmm_get_real_path(amxd_path_t* path);

/**
 * @brief Retrieves the real (backend) path associated with a mapped object path.
 *
 * A simple lookup function to get the real path value from the DMM configuration
 * given the local mapped path key.
 *
 * @param map_obj The local mapped object path (e.g., "MyDevice.Device.").
 * @return const char* Returns the real path string, or NULL if not found.
 */
const char* dmm_get_translate_path(const char* map_obj);

/**
 * @brief Checks if a given object/path combination is mapped to a real path.
 *
 * Constructs the full local path (`object` path + `rel_path`) and checks
 * if there is a non-empty corresponding real path in the DMM configuration.
 *
 * @param object The amxd_object_t of the current context.
 * @param rel_path The relative path extension (can be NULL or empty string).
 * @return bool Returns true if the resulting path is mapped, false otherwise.
 */
bool dmm_is_mapped(amxd_object_t* object, const char* rel_path);

/**
 * @brief Removes the mapped prefix from a full real object path.
 *
 * This function is used for reverse path translation (post-translation) on
 * responses from the backend.
 * 1. It first checks for a `DMM_OBJECTS_POST_TRANSLATE_CONFIG` entry for the mapped path.
 * 2. It calculates the depth of the mapped path.
 * 3. It strips the corresponding number of path segments from the front of the `real_obj` path.
 * 4. If the posttranslate path exists, it will be used instead of mapped path.
 *
 * @param mapped The local mapped object path that was used for the RPC call.
 * @param real_obj The full path received in the response from the backend.
 * @return char* Returns a newly allocated string containing `real_obj` without the mapped prefix.
 */
char* dmm_strip_mapped(const char* mapped, const char* real_obj);

/**
 * @brief Unregisters a mapping by the local mapping path.
 *
 * Removes the mapping entry from the active `DMM_OBJECTS` configuration.
 * Rebuilds the sorted mapping paths array.
 * Calls `dmm_remove_object` to attempt cleaning up the corresponding object hierarchy
 * in the local Data Model.
 *
 * @param mapping_path The local mapping path (key in the DMM config).
 * @return int Returns 0 on success, or -1 on failure.
 */
int dmm_unregister(const char* mapping_path);

/**
 * @brief Unregisters a mapping by the real (backend) object path.
 *
 * Retrieves the local mapping path from the `DMM_OBJECTS_PENDING` list using the
 * `real_path` as the key, and then calls `dmm_unregister` with the retrieved mapping path.
 *
 * @param real_path The real (backend) object path.
 * @return int Returns 0 on success, or -1 on failure.
 */
int dmm_unregister_by_real_path(const char* real_path);

/**
 * @brief Gets a pointer to the local Data Model structure.
 *
 * @return amxd_dm_t* Returns the pointer to the Data Model (`mapper.dm`).
 */
amxd_dm_t* dmm_get_dm(void);

/**
 * @brief Gets a pointer to the DMM's main info structure.
 *
 * @return prpl_dmm_t* Returns the pointer to the global DMM structure (`mapper`).
 */
prpl_dmm_t* dmm_get_info(void);

/**
 * @brief Initializes and configures the DMM's base object (`map_base`).
 *
 * This function creates the special `map_base` singleton object, which serves as the
 * **base class (template)** for all objects created by the DMM. It overrides the
 * default AMX Data Model functions with DMM-specific RPC handlers:
 * 1. Creates the `mapper->map_base` singleton object.
 * 2. Replaces standard functions (_get, _set, _add, _del, _list, etc.) with corresponding DMM
 * RPC wrappers (e.g., `dmm_rpc_transl_path`, `dmm_rpc_del`).
 * 3. Adds the specific subscription functions (`_subscribe` and `_unsubscribe`).
 */
void dmm_object_create(void);


/**
 * @brief Cleans up and deletes the DMM's base object.
 *
 * Frees the `mapper->map_base` object. Since all mapped objects in the local
 * Data Model are derived from this base object, freeing `map_base` automatically
 * deletes all the objects and functions derived from it, effectively cleaning up
 * the DMM's footprint in the Data Model.
 */
void dmm_object_delete(void);

size_t dmm_print_mapping_paths();

void SAH_TRACEZ_LOG_VARIANT(const amxc_var_t* var);

/**
 * @brief Generic startup function in AMXRT app.
 * @param reason application startup reason (AMXO_START or AMXO_STOP)
 * @param dm pointer to the application datamodel
 * @param parser pointer to the pre-configured datamodel parser
 * @return Always return successfull error code 0
 */
int _main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);

extern amxb_bus_ctx_t* l_bus_ctx;        /*!< USP context to accept connection from prplMesh component */
extern amxc_llist_t* bus_ctx_list;       /*!< List of the contexts for each connected service */

extern const amxc_llist_t* hide_po_list; /*!< List for hidden datamodel objects and parameters */
extern amxc_var_t* rename_po;            /*!< List for renamed datamodel objects and parameters*/

#ifdef __cplusplus
}
#endif

#endif // __DMM_H__
