# gmap-mod-dnssd

[[_TOC_]]

## Description

This gmap module will copy any entries from the DNSSD. datamodel into the gmap-server datamodel of their respective devices. It will also copy all TXT records and add the MDNS hostname to the device names in gmap-server.

## compile and install

```
make
sudo make install
```

### compile/install build dependencies: (make + sudo make install)

 * libamxb
 * libamxc
 * libamxp
 * libamxd
 * libamxo
 * libamxs
 * libgmap-client
 * libgmap-ext
 * libsahtrace


### runtime dependencies

 * libamxb
 * libamxc
 * libamxp
 * libamxd
 * libamxo
 * libamxs
 * libgmap-client
 * libgmap-ext
 * libsahtrace
 * amxrt
