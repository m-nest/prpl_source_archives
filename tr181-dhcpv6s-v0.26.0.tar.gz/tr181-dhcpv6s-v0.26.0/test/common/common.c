/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc_macros.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include "../mocks/mock_amxm.h"
#include "../mocks/mock_dns.h"

#include "../../include_priv/dm_dhcp6.h"
#include "../../include_priv/dhcp6_priv.h"

#include "common.h"
#include "test_dm.h"

// 'empty' replacements for functions in mod-dmext.so
static int _matches_regexp(void) {
    return AMXB_STATUS_OK;
}
static int _is_valid_ipv6(void) {
    return AMXB_STATUS_OK;
}


static void resolver_add_all_functions(amxo_parser_t* parser) {

    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_pool_added",
                                            AMXO_FUNC(_dhcpv6s_pool_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_pool_changed",
                                            AMXO_FUNC(_dhcpv6s_pool_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_interface_changed",
                                            AMXO_FUNC(_dhcpv6s_interface_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_option_add_or_remove",
                                            AMXO_FUNC(_dhcpv6s_option_add_or_remove)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_option_changed",
                                            AMXO_FUNC(_dhcpv6s_option_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcps_client_option_hostname_added",
                                            AMXO_FUNC(_dhcps_client_option_hostname_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcps_client_option_destroy",
                                            AMXO_FUNC(_dhcps_client_option_destroy)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcps_client_option_hostname_ipaddress_changed",
                                            AMXO_FUNC(_dhcps_client_option_hostname_ipaddress_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_ia_changed",
                                            AMXO_FUNC(_dhcpv6s_ia_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_pool_option_23_changed",
                                            AMXO_FUNC(_dhcpv6s_pool_option_23_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_pool_option_23_interface",
                                            AMXO_FUNC(_dhcpv6s_pool_option_23_interface)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcp6_remove_pool",
                                            AMXO_FUNC(_dhcp6_remove_pool)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "check_is_empty_or_in",
                                            AMXO_FUNC(_check_is_empty_or_in)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "matches_regexp",
                                            AMXO_FUNC(_matches_regexp)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "is_valid_ipv6",
                                            AMXO_FUNC(_is_valid_ipv6)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "check_elem_empty_or_in",
                                            AMXO_FUNC(_check_elem_empty_or_in)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "dhcpv6s_pool_option_23_destroy",
                                            AMXO_FUNC(_dhcpv6s_pool_option_23_destroy)), 0);
}

static void load_external_definition(amxo_parser_t* parser) {

    // mock DNS
    assert_int_equal(amxo_resolver_ftab_add(parser, "SetHost", AMXO_FUNC(_SetHost)), 0);
    assert_int_equal(amxo_resolver_ftab_add(parser, "RemoveHost", AMXO_FUNC(_RemoveHost)), 0);

    amxut_dm_load_odl("../common/external_odl.odl");
}

int test_setup(void** state) {
    amxut_bus_setup(state);

    amxo_parser_t* parser = amxut_bus_parser();
    resolver_add_all_functions(parser);

    amxut_dm_load_odl("../common/dhcpv6s-manager-test.odl");
    amxut_dm_load_odl("../../odl/dhcpv6s-manager_definition.odl");

    assert_int_equal(_dhcp6_main(0, amxut_bus_dm(), parser), 0);

    amxut_dm_load_odl("../common/defaults.d/00_main.odl");
    amxut_dm_load_odl("../common/defaults.d/01_default_pools.odl");

    load_external_definition(parser);

    amxut_dm_load_odl("../common/defaults.d/02_client_receivedoption.odl");

    // first set to disable then call back enable the pool
    expect_amxm_execute_function_module_nb("disable-pool", 1);
    expect_amxm_execute_function_module_nb("enable-pool", 2);
    // doing that for both pool (lan and guest )
    expect_amxm_execute_function_module_nb("disable-pool", 1);
    expect_amxm_execute_function_module_nb("enable-pool", 2);
    // GUA configuration update
    expect_amxm_execute_function_module_nb("enable-pool", 2);
    amxut_bus_handle_events();
    assert_dm_param_equal(bool, "DHCPv6Server.", "Enable", true);
    return 0;
}

int test_teardown(UNUSED void** state) {
    amxut_bus_handle_events();

    assert_int_equal(_dhcp6_main(1, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_handle_events();
    amxut_bus_teardown(state);
    return 0;
}