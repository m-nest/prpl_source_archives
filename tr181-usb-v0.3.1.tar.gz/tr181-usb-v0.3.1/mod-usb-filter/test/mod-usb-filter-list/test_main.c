#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_list.h"

int main(void) {
    const struct CMUnitTest tests[] = {
        // test dm
        cmocka_unit_test(test_add_device),
        cmocka_unit_test(test_change_intf),
        cmocka_unit_test(test_remove_intf),
        cmocka_unit_test(test_add_allowed_device),
        cmocka_unit_test(test_change_allowed_device),
        cmocka_unit_test(test_remove_allowed_device),
        cmocka_unit_test(test_remove_device),

        // scenarios
        // cmocka_unit_test(test_)
    };
    return cmocka_run_group_tests(tests, test_setup, test_teardown);
}
