/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "mock_res_functions.h"
static const char* mock_meminfo_lines[] = {
    "MemTotal:       8000000 kB\n",
    "MemAvailable:   2000000 kB\n",
    "Cached:         1000000 kB\n",
    NULL
};

static const char* mock_cpu_stat_lines[] = {
    "cpu0 250 0 250 250 0 0 0 250\n",  // total = 1000, idle = 250
    "cpu 150 0 150 150 0 0 0 0\n",
    NULL
};

static int mem_line_index = 0;
static int cpu_line_index = 0;
static int is_mock_meminfo = 0;
static int is_mock_cpustat = 0;

FILE* __wrap_fopen(const char* filename, const char* mode) {

    if(strncmp(filename, "/proc/meminfo", strlen("/proc/meminfo")) == 0) {
        is_mock_meminfo = 1;
        is_mock_cpustat = 0;
        mem_line_index = 0;
        return (FILE*) 1;
    } else if(strncmp(filename, "/proc/stat", strlen("/proc/stat")) == 0) {
        is_mock_cpustat = 1;
        is_mock_meminfo = 0;
        cpu_line_index = 0;
        return (FILE*) 1;
    } else {
        is_mock_meminfo = 0;
        is_mock_cpustat = 0;
        return __real_fopen(filename, mode);
    }
}

char* __wrap_fgets(char* buf, int size, FILE* stream) {

    if(is_mock_meminfo) {
        if(mock_meminfo_lines[mem_line_index] == NULL) {
            return NULL;
        }
        strncpy(buf, mock_meminfo_lines[mem_line_index], size - 1);
        buf[size - 1] = '\0';
        mem_line_index++;
        return buf;
    } else if(is_mock_cpustat) {

        if(mock_cpu_stat_lines[cpu_line_index] == NULL) {
            return NULL;
        }
        prev_total[0] = 0;
        prev_idle[0] = 0;
        prev_agg_idle[0] = 0;
        prev_agg_user[0] = 0;
        prev_agg_system[0] = 0;
        prev_agg_total[0] = 0;
        strncpy(buf, mock_cpu_stat_lines[cpu_line_index], size - 1);
        buf[size - 1] = '\0';
        cpu_line_index++;
        return buf;

    } else {
        return __real_fgets(buf, size, stream);
    }
}

int __wrap_fclose(FILE* stream) {

    if(is_mock_meminfo || is_mock_cpustat) {
        return 0;
    } else {
        return __real_fclose(stream);
    }
}
