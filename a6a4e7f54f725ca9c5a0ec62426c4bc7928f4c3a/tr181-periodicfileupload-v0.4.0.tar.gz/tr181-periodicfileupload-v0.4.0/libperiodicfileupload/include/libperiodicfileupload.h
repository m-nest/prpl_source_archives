/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __LIBPERIODICFILEUPLOAD_H__
#define __LIBPERIODICFILEUPLOAD_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>
#include <amxo/amxo_types.h>

/**
 * @file
 * @brief
 * Libperiodicfileupload API header file
 */

/**
 * @mainpage
 * Libperiodicfileupload is a library providing an API to register files that will be periodically uploaded to some remote server.
 *
 */

/**
 * @brief
 * Initialize the periodic file upload context.
 *
 * Initializes memory to store and manage periodic file upload requests.
 * This function allocates memory from the stack.
 * Once the periodic file upload context is initialized, subsequent calls to this function will succeed.
 *
 * @note
 * @ref periodicfileupload_deinit to cleanup the memory
 *
 * @param parser The parser provided by amxrt. This will be used to register callback on file descriptor used by libfiletransfer.
 *
 * @return
 * -1 if an error occured. 0 on success
 */
int periodicfileupload_init(amxo_parser_t* parser);

/**
 * @brief
 * Deinitialize the periodic file upload context.
 *
 * Deinitialize the periodic file upload context and deallocate memory.
 *
 * @note
 * If files are being periodically uploaded this can be called without calling @ref periodicfileupload_unregister_file
 */
void periodicfileupload_deinit(void);

/**
 * @brief
 * Allocate and register a new file.
 *
 * Allocate and register to the periodic file upload context a new file.
 * This function allocates memory from the heap.
 *
 * @note
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 * use @ref periodicfileupload_deregister_file to free the memory.
 *
 * @param id a string containing a unique id for the registered file.
 * @param internal_path a string containing the filesystem path of the file that will be uploaded.
 * @param profile_path a csv_string containing tr181 paths to profiles to which the file will be periodically uploaded to.
 *
 * @return
 * -1 if an error occurred. 0 on success
 */
int periodicfileupload_register_file(const char* id, const char* internal_path, const char* profile_path);

/**
 * @brief
 * Set interval to a registered file.
 *
 * The interval will be used to calculate how frequently the file will be uploaded.
 *
 * @note
 * Default interval is 86400 (a day)
 * The interval will be used with the TimeReference argument.
 * If the time_ref argument is NULL, "1970-01-01T00:00:00Z" will be used a default.
 * The ID must have been successfuly registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 * @param interval a value in seconds that will be used to determine the periodicity.
 * @param time_ref a pointer containing a time that will be used to set the “phase” of the file upload intervals.
 *
 * @return
 * -1 if an error occurred. 0 on success
 */
int periodicfileupload_set_interval(const char* id, uint32_t interval, amxc_ts_t* time_ref);

typedef void (* periodicfileupload_transfer_cb_t)(const amxc_var_t* const status, void* const priv);

/**
 * @brief State machine values for periodic file transfers
 *
 * Defines the possible states of a file transfer during its lifecycle
 * in the periodic file upload process.
 */
typedef enum periodicfileupload_state_e {
    pfu_state_idle = 0,     /**< Transfer is idle, waiting to start */
    pfu_state_creating,     /**< Creating/preparing the file for upload */
    pfu_state_uploading,    /**< File upload is in progress */
    pfu_state_success,      /**< Upload completed successfully */
    pfu_state_retrying,     /**< Retrying upload after failure */
    pfu_state_error,        /**< Upload failed with error */
} periodicfileupload_state_t;

/**
 * @brief Sets transfer callback for a file upload
 *
 * Registers a callback function to be called during transfer state changes
 * for the specified file upload.
 *
 * @param[in] id File transfer identifier
 * @param[in] callback Callback function to register
 * @param[in] priv Private data to pass to callback
 */
void periodicfileupload_set_transfer_cb(const char* id, periodicfileupload_transfer_cb_t callback, void* priv);

/**
 * @brief
 * Start to periodically upload the file.
 *
 * Start the timer to periodically upload the file.
 *
 * @note
 * If no profiles are valid the call will fail.
 * The file doesn't have to exist at the start.
 * The first iteration MAY start earlier than the interval value based on the Profile TimeReference parameter.
 * Profiles parameter will be fetched after each interval. However if the TimeReference is changed,
 * the file needs to be restarted with @ref periodicfileupload_stop and @ref periodicfileupload_start for that the value change be effective.
 * The ID must have been successfully registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 *
 * @return
 * -1 if an error occurred. 0 on success
 */
int periodicfileupload_start(const char* id);

/**
 * @brief
 * Stop the periodically uploaded file.access
 *
 * Stop the timer of the periodically uploaded file.
 *
 * @note
 * The File must have been started successfully with @ref periodicfileupload_start
 * The ID must have been successfully registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 *
 * @return
 * -1 if an error occurred. 0 on success
 */
int periodicfileupload_stop(const char* id);

/**
 * @brief
 * Deregister and deallocate the memory of the file.
 *
 * Deallocate and deregister a file to the periodic upload context.
 *
 * @note
 * If ID is NULL or doesn't exist in the context this function will do nothing
 * If the file hasn't been stopped using @ref periodicfileupload_stop it will be stopped upon this call.
 * The ID must have been successfully registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 */
void periodicfileupload_deregister_file(const char* id);

/**
 * @brief
 * Enumeration of the return value for @ref periodicfileupload_cb_t
 *
 * Enumerate the return status of the callback to have more control about the flow of execution.
 *
 * @note
 * PFU_CB_ERROR: Indicates an error happened during the callback. If used as status for preupload callback, the upload will not be performed.
 * PFU_CB_OK: Indicates no error happened during the callback. If used as status for preupload callback, the upload will be performed afterward.
 * PFU_CB_DELAY: Indicates the upload needs to be delayed. Subsequent call to @ref periodicfileupload_perform_delayed_upload (not implemented yet) to resume download.
 */
typedef enum periodicfileupload_cb_status_e {
    PFU_CB_ERROR = -1,
    PFU_CB_OK,
    PFU_CB_DELAY,
} periodicfileupload_cb_status_t;


typedef periodicfileupload_cb_status_t (* periodicfileupload_cb_t)(const char* id, void* priv);

/**
 * @brief
 * Set a preupload callback to a registered file.
 *
 * The callback will be called before the file is uploaded.
 *
 * @note
 * The ID must have been successfuly registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 * @param callback a function that will be called before the upload. Use NULL to remove the callback.
 * @param priv a pointer to a data that will be passed to the callback as parameter.
 *
 */
void periodicfileupload_preupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv);

/**
 * @brief
 * Set a postupload callback to a registered file.
 *
 * The callback will be called after the file is uploaded.
 *
 * @note
 * The ID must have been successfuly registered with @ref periodicfileupload_register_file
 * The periodic file upload context must have been initialized with @ref periodicfileupload_init
 *
 * @param id a string containing a unique id for the registered file.
 * @param callback a function that will be called after the upload. Use NULL to remove the callback.
 * @param priv a pointer to a data that will be passed to the callback as parameter.
 *
 */
void periodicfileupload_postupload_cb(const char* id, periodicfileupload_cb_t callback, void* priv);

#ifndef PFU_SCRIPT_TIMEOUT_DURATION_MS
# define PFU_SCRIPT_TIMEOUT_DURATION_MS 300000
#endif

/**
 * @brief
 * Callback that can be used to execute a script.
 *
 * The function is here as an helper function to execute a script.
 * It can be used as the callback parameter of @ref periodicfileupload_preupload_cb or @ref periodicfileupload_postupload_cb
 *
 * @note
 * This function will execute the script asynchronously and continue the transfer once done
 * The script execution will timeout after @ref SCRIPT_TIMEOUT_DURATION_MS millisecond
 *
 * @param id a string containing a unique id for the registered file.
 * @param priv a pointer to the data previously passed as an argument while registering the callback.
 *
 * @return
 * PFU_CB_OK if the script execution went well, otherwise PFU_CB_ERROR.
 */
periodicfileupload_cb_status_t periodicfileupload_exec_script_cb(const char* id, void* priv);

/**
 * @brief
 * Resume the transfer of a delayed file.
 *
 * Resumes the transfer of a file. That is been stopped when a preupload callback returned @ref PFU_CB_DELAY
 *
 * @note
 * This function isn't implemented and is here as placeholder
 *
 * @param id a string containing a unique id for the registered file.
 *
 * @return
 * -1 if an error occured, 0 otherwise.
 */
int periodicfileupload_perform_delayed_transfer(const char* id);

#ifdef __cplusplus
}
#endif

#endif // __LIBPERIODICFILEUPLOAD_H__