/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "reboot.h"
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxm/amxm.h>

static amxd_dm_t* reboot_dm = NULL;
static amxo_parser_t* reboot_parser = NULL;
static amxb_bus_ctx_t* reboot_ctx = NULL;
static amxd_object_t* root_object = NULL;

amxd_dm_t* reboot_get_dm(void) {
    return reboot_dm;
}

amxo_parser_t* reboot_get_parser(void) {
    return reboot_parser;
}

amxb_bus_ctx_t* reboot_get_ctx(void) {
    return reboot_ctx;
}

amxc_var_t* reboot_get_config(void) {
    return reboot_parser ? &reboot_parser->config : NULL;
}

amxd_object_t* get_root_object(void) {
    return root_object;
}

amxd_object_t* get_object(const char* path) {
    amxd_object_t* object = NULL;

    when_str_empty(path, exit);
    object = amxd_dm_findf(reboot_get_dm(), "%s", path);
exit:
    return object;
}

const cstring_t reboot_get_vendor_prefix(void) {
    amxc_var_t* setting = amxo_parser_get_config(reboot_get_parser(), "global_vendor_prefix_");
    const cstring_t prefix = amxc_var_constcast(cstring_t, setting);
    return (prefix != NULL) ? prefix : "";
}

static int reboot_load_modules(void) {
    int retval = -1;
    const char* mod_dir = GET_CHAR(reboot_get_config(), "mod-dir");
    const char* mod_name = GET_CHAR(reboot_get_config(), "mod-name");
    amxm_shared_object_t* so = NULL;
    amxc_string_t mod_path;

    amxc_string_init(&mod_path, 0);
    when_null(mod_dir, exit);
    amxc_string_setf(&mod_path, "%s/%s.so", mod_dir, mod_name);

    SAH_TRACEZ_INFO(ME, "Loading module '%s' (file = %s)", mod_name, amxc_string_get(&mod_path, 0));
    retval = amxm_so_open(&so, mod_name, amxc_string_get(&mod_path, 0));
    when_failed_trace(retval, exit, ERROR, "Failed to load module '%s'", mod_name);

exit:
    amxc_string_clean(&mod_path);

    return retval;
}

int _reboot_main(int reason,
                 amxd_dm_t* dm,
                 amxo_parser_t* parser) {
    switch(reason) {
    case 0:     // START
        SAH_TRACEZ_INFO(ME, "**************************************");
        SAH_TRACEZ_INFO(ME, "*        reboot service started      *");
        SAH_TRACEZ_INFO(ME, "**************************************");
        reboot_dm = dm;
        reboot_parser = parser;
        reboot_ctx = amxb_be_who_has(DM_REBOOT_ROOT_PATH);
        root_object = get_object(DM_REBOOT_ROOT_PATH);
        reboot_load_modules();
        break;
    case 1:     // STOP
        reboot_dm = NULL;
        reboot_parser = NULL;
        reboot_ctx = NULL;
        amxm_close_all();
        SAH_TRACEZ_INFO(ME, "**************************************");
        SAH_TRACEZ_INFO(ME, "*        reboot service stopped      *");
        SAH_TRACEZ_INFO(ME, "**************************************");
        break;
    }

    return 0;
}
