# netmodel-optical

## Introduction
`netmodel-optical` is a NetModel client used to synchronize Optical Interface data to NetModel.

## Architecture

The `netmodel-optical` code is loaded by the netmodel-clients process and will be invoked when the optical MIB is added or removed to/from a NetModel interface.


### Components

1. **netmodel-optical**:
    - Starts synchronizing data from the Optical interface to the NetModel interface when the optical MIB is loaded in NetModel.
    - Stops synchronizing data from the Optical interface to the NetModel interface when the optical MIB is unloaded in NetModel.


## Building, Installing, and Testing

### Docker Container

You can install all the necessary tools for testing and developing on your local machine or use a pre-configured environment. A pre-configured environment is available as a Docker container.

1. **Install Docker**:

    Docker must be installed on your system. Here are some links that could help you:

    - [Get Docker Engine - Community for Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
    - [Get Docker Engine - Community for Debian](https://docs.docker.com/install/linux/docker-ce/debian/)
    - [Get Docker Engine - Community for Fedora](https://docs.docker.com/install/linux/docker-ce/fedora/)
    - [Get Docker Engine - Community for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

    Make sure your user ID is added to the Docker group:

        sudo usermod -aG docker $USER

2. **Fetch the Container Image**:

    To get access to the pre-configured environment, pull the image and launch a container.

    Pull the image:

        docker pull registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    Before launching the container, create a directory that will be shared between your local machine and the container.

        mkdir -p ~/amx/libraries/

    Launch the container:

        docker run -ti -d \
            --name oss-dbg \
            --restart=always \
            --cap-add=SYS_PTRACE \
            --sysctl net.ipv6.conf.all.disable_ipv6=1 \
            -e "USER=$USER" \
            -e "UID=$(id -u)" \
            -e "GID=$(id -g)" \
            -v ~/amx:/home/$USER/amx \
            registry.gitlab.com/soft.at.home/docker/oss-dbg:latest

    The `-v` option bind mounts the local directory for the AMX project in the container, at the exact same place. The `-e` options create environment variables in the container. These variables are used to create a user name with the same user ID and group ID in the container as on your local host (user mapping).

    You can open as many terminals/consoles as you like:

        docker exec -ti --user $USER oss-dbg /bin/bash

### Building

#### Prerequisites

`netmodel-optical` depends on the following libraries:

 * amxrt
 * libamxc
 * libamxd
 * libamxm
 * libamxo
 * libamxp
 * libamxrt
 * libamxs
 * libnetmodel
 * libsahtrace

These libraries can be installed in the container:

    sudo apt-get install libamxb libamxc libamxd libamxm libamxo libamxp libamxs mod-sahtrace sah-lib-sahtrace-dev libnetmodel

### Testing

#### Prerequisites

No extra components are needed for testing `netmodel-optical`.

#### Run tests

You can run the tests by executing the following command:

    ```bash
    cd ~/amx/plugins/netmodel-optical/test
    make
    ```

Or this command if you also want the coverage tests to run:

    ```bash
    cd ~/amx/plugins/netmodel-optical/tests
    make run coverage
    ```

You can combine both commands:

    ```bash
    cd ~/amx/plugins/netmodel-optical
    make test
    ```

#### Coverage reports

The coverage target will generate coverage reports using [gcov](https://gcc.gnu.org/onlinedocs/gcc/Gcov.html) and [gcovr](https://gcovr.com/en/stable/guide.html).

A summary for each C file is printed in your console after the tests are run. An HTML version of the coverage reports is also generated. These reports are available in the output directory of the compiler used. For example, when using native gcc, the output of `gcc -dumpmachine` is `x86_64-linux-gnu`, the HTML coverage reports can be found at `~/amx/plugins/netmodel-optical/output/x86_64-linux-gnu/coverage/report`.

You can easily access the reports in your browser. In the container, start a python3 HTTP server in the background.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/netmodel-optical/output/<MACHINE>/coverage/report
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/netmodel-optical$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/netmodel-optical/output/x86_64-linux-gnu/coverage/report/`

### Documentation

#### Prerequisites

To generate the documentation, [Doxygen](https://www.doxygen.nl) is required and already available in the container. In case you want to install this on your local machine:

    ```bash
    sudo apt-get install doxygen
    ```

#### Paths

The documentation is split into two parts, starting from the repository path:

    ```bash
    cd ~/amx/plugins/netmodel-optical
    ```

Here, you can find:

- `README.md`: This file is used on GitLab and is the main page for the Doxygen documentation.
- `docs` directory: Contains the Doxygen settings, code examples, and additional pages used in Doxygen.

The code itself is documented in the appropriate header and source files.

#### Generate documentation

To generate the documentation, Doxygen needs to be installed. Alternatively, `amxo-cg` and `amxo-xml-to` packages can be installed to generate the documentation. You can generate the documentation by executing the following command:

    ```bash
    cd ~/amx/plugins/netmodel-optical
    make doc
    ```

The full documentation is available in the `output` directory. You can easily access the documentation in your browser. As described in the coverage reports section, you can start an HTTP server in the container.

    ```bash
    cd ~/amx/
    python3 -m http.server 8080 &
    ```

Use the following URL to access the reports:

    ```bash
    http://<IP ADDRESS OF YOUR CONTAINER>:8080/plugins/netmodel-optical/output/html/index.html
    ```

You can find the IP address of your container by using the `ip -br a` command in the container.

Example:

    ```bash
    USER@<CID>:~/amx/plugins/netmodel-optical$ ip -br a
    lo              UNKNOWN        127.0.0.1/8
    eth0            UP             172.17.0.3/16
    ```

In this case, the IP address of the container is `172.17.0.3`. So the URL you should use is: `http://172.17.0.3:8080/plugins/netmodel-optical/output/html/index.html`

Alternatively, you can open the documentation via command:

    ```bash
    xdg-open netmodel-optical/output/html/index.html
    `
