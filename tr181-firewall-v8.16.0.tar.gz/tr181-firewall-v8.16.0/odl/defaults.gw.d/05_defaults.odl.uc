{%
let has_failover = (BDfn.getFailoverInterfaceIndex() != "-1");
let wan_interfaces = [ "WAN" ];
if (has_failover) {
    push(wan_interfaces, "WANCELLULAR");
}
let lan_interfaces = [ "LAN", "GUEST" ];
let low_policies = [];
let medium_policies = [];
let high_policies = [];
let custom_policies = [];
for(i in lan_interfaces) {
    for (j in wan_interfaces) {
        push(low_policies, "Firewall.Policy.[Alias=='" + j + "2" + i + "_low']");
        push(low_policies, "Firewall.Policy.[Alias=='IPV6_" + j + "2" + i + "_low']");
        push(medium_policies, "Firewall.Policy.[Alias=='" + j + "2" + i + "_medium']");
        push(medium_policies, "Firewall.Policy.[Alias=='IPV6_" + j + "2" + i + "_medium']");
        push(high_policies, "Firewall.Policy.[Alias=='" + j + "2" + i + "_high']");
        push(high_policies, "Firewall.Policy.[Alias=='IPV6_" + j + "2" + i + "_high']");
        push(custom_policies, "Firewall.Policy.[Alias=='" + j + "2" + i + "_Custom']");
        push(custom_policies, "Firewall.Policy.[Alias=='IPV6_" + j + "2" + i + "_Custom']");
    }
}
%}
%populate {
    object Firewall {
        parameter Config = "Policy";
        parameter PolicyLevel = "Firewall.Level.[Alias=='Medium']";

        object Level {
            instance add(Alias=Low, Name=Low) {
                parameter Policies = "{{join(',', low_policies)}}";
            }
            instance add(Alias=Medium, Name=Medium) {
                parameter Policies = "{{join(',', medium_policies)}}";
            }
            instance add(Alias=High, Name=High) {
                parameter Policies = "{{ join(',', high_policies)}}";
            }
            instance add(Alias=Custom, Name=Custom) {
                parameter Policies = "{{join(',', custom_policies)}}";
            }
        }

        object Chain {
            instance add(Name=FORWARD_Sentinel) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
            }
            instance add(Alias=Low, Name=FORWARD_L_Low) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add() {
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                }
            }
            instance add(Alias=Medium, Name=FORWARD_L_Medium) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=cstate) {
                        parameter Target = "Accept";
                        parameter ConnectionState = "RELATED,ESTABLISHED";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                }
            }
            instance add(Alias=High, Name=FORWARD_L_High) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=cstate) {
                        parameter Target = "Accept";
                        parameter ConnectionState = "RELATED,ESTABLISHED";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                }
            }
            instance add(Alias=IPV6_Low, Name=FORWARD6_L_Low) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add() {
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                }
            }
            instance add(Alias=IPV6_Medium, Name=FORWARD6_L_Medium) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=cstate) {
                        parameter Target = "Accept";
                        parameter ConnectionState = "RELATED,ESTABLISHED";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                }
            }
            instance add(Alias=IPV6_High, Name=FORWARD6_L_High) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=cstate) {
                        parameter Target = "Accept";
                        parameter ConnectionState = "RELATED,ESTABLISHED";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                }
            }
            instance add(Alias=High_Out, Name=FORWARD_L_High_Out) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=ftp-data) {
                        parameter Protocol = 6;
                        parameter DestPort = 20;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=ftp) {
                        parameter Protocol = 6;
                        parameter DestPort = 21;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=ssh) {
                        parameter Protocol = 6;
                        parameter DestPort = 22;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=smtp) {
                        parameter Protocol = 6;
                        parameter DestPort = 25;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=dns-udp) {
                        parameter Protocol = 17;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=dns-tcp) {
                        parameter Protocol = 6;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=http) {
                        parameter Protocol = 6;
                        parameter DestPort = 80;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=pop3) {
                        parameter Protocol = 6;
                        parameter DestPort = 110;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=ntp) {
                        parameter Protocol = 17;
                        parameter DestPort = 123;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }

                    instance add(Alias=imap) {
                        parameter Protocol = 6;
                        parameter DestPort = 143;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=https) {
                        parameter Protocol = 6;
                        parameter DestPort = 443;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=ip_stb) {
                        parameter '${global_vendor_prefix_}VendorClassID' = "IP-STB";
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=last-tcp-rule) {
                        parameter Protocol = 6;
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=last-rule) {
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                }
            }
            instance add(Alias=IPV6_High_Out, Name=FORWARD6_L_High_Out) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=ftp-data) {
                        parameter Protocol = 6;
                        parameter DestPort = 20;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=ftp) {
                        parameter Protocol = 6;
                        parameter DestPort = 21;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=ssh) {
                        parameter Protocol = 6;
                        parameter DestPort = 22;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=smtp) {
                        parameter Protocol = 6;
                        parameter DestPort = 25;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=dns-udp) {
                        parameter Protocol = 17;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=dns-tcp) {
                        parameter Protocol = 6;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=http) {
                        parameter Protocol = 6;
                        parameter DestPort = 80;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=pop3) {
                        parameter Protocol = 6;
                        parameter DestPort = 110;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=ntp) {
                        parameter Protocol = 17;
                        parameter DestPort = 123;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=imap) {
                        parameter Protocol = 6;
                        parameter DestPort = 143;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=https) {
                        parameter Protocol = 6;
                        parameter DestPort = 443;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=ip_stb) {
                        parameter '${global_vendor_prefix_}VendorClassID' = "IP-STB";
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=last-tcp-rule) {
                        parameter Protocol = 6;
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                    instance add(Alias=last-rule) {
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 6;
                    }
                }
            }
            instance add(Alias=Custom_In, Name=FORWARD_L_Custom_In) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=cstate) {
                        parameter Target = "Accept";
                        parameter ConnectionState = "RELATED,ESTABLISHED";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                }
            }
            instance add(Alias=Custom_Out, Name=FORWARD_L_Custom_Out) {
                parameter Enable = 1;
                parameter Creator = "Defaults";
                object Rule {
                    instance add(Alias=ftp-data) {
                        parameter Protocol = 6;
                        parameter DestPort = 20;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=ftp) {
                        parameter Protocol = 6;
                        parameter DestPort = 21;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=ssh) {
                        parameter Protocol = 6;
                        parameter DestPort = 22;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=smtp) {
                        parameter Protocol = 6;
                        parameter DestPort = 25;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=dns-udp) {
                        parameter Protocol = 17;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=dns-tcp) {
                        parameter Protocol = 6;
                        parameter DestPort = 53;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=http) {
                        parameter Protocol = 6;
                        parameter DestPort = 80;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=pop3) {
                        parameter Protocol = 6;
                        parameter DestPort = 110;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=ntp) {
                        parameter Protocol = 17;
                        parameter DestPort = 123;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                        parameter IPVersion = 4;
                    }
                    instance add(Alias=imap) {
                        parameter Protocol = 6;
                        parameter DestPort = 143;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=https) {
                        parameter Protocol = 6;
                        parameter DestPort = 443;
                        parameter Target = "Accept";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=last-tcp-rule) {
                        parameter Protocol = 6;
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                    instance add(Alias=last-rule) {
                        parameter Target = "Reject";
                        parameter SourceAllInterfaces = 1;
                        parameter DestAllInterfaces = 1;
                        parameter Enable = 1;
                    }
                }
            }
        }
    }
}
