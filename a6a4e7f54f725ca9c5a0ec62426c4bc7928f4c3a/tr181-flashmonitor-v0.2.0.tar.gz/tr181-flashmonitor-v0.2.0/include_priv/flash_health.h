/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Capgemini America
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__CPU_INFO_H__)
#define __CPU_INFO_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>

#include <amxo/amxo.h>
#include <amxo/amxo_save.h>
#include <string.h>

#define PRIVATE __attribute__ ((visibility("hidden")))
#define UNUSED __attribute__((unused))
#define CONSTRUCTOR __attribute__((constructor))
#define DESTRUCTOR __attribute__((destructor))


#define FH_TIMER_TIMEOUT   300000


/**
 * @brief Structure representing the Flash Health application context.
 *
 * This structure holds references to the data model and parser used
 * by the Flash Health application.
 */
typedef struct _flash_health_app {
    /**
     * @brief Pointer to the AMX data model.
     *
     * This is used to interact with the underlying data model.
     */
    amxd_dm_t* dm;

    /**
     * @brief Pointer to the AMXO parser.
     *
     * This is used to parse configuration or command files.
     */
    amxo_parser_t* parser;
} flash_health_app_t;


int _fh_main(int reason,
             amxd_dm_t* dm,
             amxo_parser_t* parser);

amxd_dm_t* fh_get_dm(void);

typedef enum {
    FLASH_TYPE_NAND,
    FLASH_TYPE_NOR,
    FLASH_TYPE_EMMC,
    FLASH_TYPE_SPI,
    FLASH_TYPE_UNKNOWN
} FlashType;

typedef enum {
    STATUS_ENABLED,
    STATUS_ERRORED,
    STATUS_NOT_SUPPORTED
} FlashMonitoringStatus;

typedef enum {
    HEALTH_STATUS_NORMAL,
    HEALTH_STATUS_CRITICAL
} FlashHealthStatus;

/**
 * @brief Structure representing the health status and metadata of a flash device.
 */
typedef struct {
    amxd_object_t* object;                  /**< Pointer to the associated AMX object. */
    FlashType type;                         /**< Type of the flash device. */
    char name[128];                         /**< Name of the flash device. */
    char version[128];                      /**< Firmware or software version. */
    char path[128];                         /**< Path to the flash device in the system. */
    bool enabled;                           /**< Indicates whether monitoring is enabled. */
    FlashHealthStatus healthStatus;         /**< Current health status of the flash device. */
    FlashMonitoringStatus monitoringStatus; /**< Current monitoring status of the flash device. */
    char emmcPreEolInfo[128];               /**< Pre-EOL info for eMMC devices. */
    char lifeTimeA[64];                     /**< Lifetime A info as a string. */
    char lifeTimeB[64];                     /**< Lifetime B info as a string. */
    uint32_t lifeTimeAThreshold;            /**< Threshold for Lifetime A. */
    uint32_t lifeTimeBThreshold;            /**< Threshold for Lifetime B. */
    uint32_t preEolThreshold;               /**< Threshold for Pre-EOL status. */
    uint32_t totalGoodBlocks;               /**< Total number of good blocks. */
    uint32_t totalBadBlocks;                /**< Total number of bad blocks. */
    uint32_t badBlocksThreshold;            /**< Threshold for bad blocks. */
    amxp_timer_t* fh_timer;                 /**< Timer for periodic health monitoring. */
    uint8_t lifeTimeAHex;                   /**< Lifetime A value in hex. */
    uint8_t lifeTimeBHex;                   /**< Lifetime B value in hex. */
    uint8_t preEolHex;                      /**< Pre-EOL value in hex. */
} flash_health_t;



void flash_device_init (void);
void flash_health_cleanup(amxd_object_t* object);
void flash_device_cleanup(void);

void set_health_status (flash_health_t* fh, FlashHealthStatus status);

void fh_nand_check (flash_health_t* fh);
void fh_perform_test (flash_health_t* fh);
void fh_check (amxp_timer_t* fh_timer, void* priv);
void fh_emmc_check (flash_health_t* fh);

amxd_trans_t* fh_trans_create(amxd_object_t* object);

amxd_status_t fh_trans_apply(amxd_trans_t* trans);

void flash_device_info (flash_health_t* fh, amxd_object_t* object);

void flash_health_restore_config (flash_health_t* fh, amxd_object_t* object);

void enable_flash_monitoring (flash_health_t* fh);

void disable_flash_monitoring (flash_health_t* fh);

void flash_set_default_status (flash_health_t* fh);

#define SYS_BLOCK_PATH "/sys/class/block/"
#define SYS_MTD_PATH   "/sys/class/mtd/"
#define BUFFER_SIZE    256


int get_emmc_version(const char* device_path, char* version_buf, size_t buf_size);
void check_emmc(const char* device);
void check_nand(const char* device);
void flash_details(void);
void trim_newline(char* str);
#ifdef __cplusplus
}
#endif

#endif // __FLASH_HEALTH_H_
