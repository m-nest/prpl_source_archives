/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxb/amxb_be.h>
#include <amxb/amxb_operators.h>
#include <amxrt/amxrt.h>
#include <netmodel/common_api.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <uriparser/Uri.h>
#include <stdlib.h>

#include "event_handler.h"
#include "obuspa_interface.h"
#include "usp_discovery.h"

#define ME "usp_discovery"

/**
 * @file obuspa_interface.c
 * @brief Configure (add, update, remove) USP controller for OBUSPA.
 */

/**
 * Get bus context for the given object path
 *
 * @param[in] path to the object
 *
 * @return bus context
 */
static amxb_bus_ctx_t* get_bus_context(const char* path) {
    return amxb_be_who_has(path);
}

/**
 * Convert URI text range to string
 *
 * @param text_range text range of a URI
 *
 * @return string representation of the range
 */
static char* uri_text_range_to_string(UriTextRangeA text_range) {
    if(!text_range.first || !text_range.afterLast) {
        return NULL;
    }
    size_t length = text_range.afterLast - text_range.first;
    char* str = malloc(length + 1);
    memcpy(str, text_range.first, length);
    str[length] = '\0';

    return str;
}

/**
 * get MTP from the URI
 *
 * @param [in] URL url to get MTP from
 *
 * @return obuspa's representation of the MTP
 */
static const char* url_get_obuspa_mtp(const char* URL) {
    const char* mtp = NULL;
    UriUriA uri;
    const char* errorPos;

    if(uriParseSingleUriA(&uri, URL, &errorPos) != URI_SUCCESS) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse '%s' URL, error at %s", URL, errorPos);
        return NULL;
    }

    char* scheme = uri_text_range_to_string(uri.scheme);
    if((strcmp(scheme, "mqtt") == 0) || (strcmp(scheme, "mqtts") == 0)) {
        mtp = "MQTT";
        goto exit;
    } else if(strcmp(scheme, "stomp") == 0) {
        mtp = "STOMP";
        goto exit;
    } else if((strcmp(scheme, "ws") == 0) || (strcmp(scheme, "wss") == 0)) {
        mtp = "WebSocket";
    }

exit:
    free(scheme);
    uriFreeUriMembersA(&uri);
    return mtp;
}

/**
 * Collect URI path into single string
 *
 * @param path_head head of the URI path linked list
 *
 * @return string representation of the URI path
 */
static char* collect_uri_path_to_string(UriPathSegmentA* path_head) {
    amxc_string_t path;
    amxc_string_init(&path, PATH_BUFFER_SIZE);

    for(const UriPathSegmentA* current_path_segment = path_head; current_path_segment; current_path_segment = current_path_segment->next) {
        char* path_segment = uri_text_range_to_string(current_path_segment->text);
        amxc_string_appendf(&path, "/%s", path_segment);
        free(path_segment);
    }
    char* path_cstring = amxc_string_take_buffer(&path);
    amxc_string_clean(&path);

    return path_cstring;
}

/**
 * MTP connection representation
 */
struct MTPConnectionInfo {
    /**
     * MTP protocol for connection
     */
    enum MTP mtp_protocol;

    /**
     * Host to connect to
     */
    char* host;

    /**
     * Port to connect
     */
    char* port;

    /**
     * Path for connection (used in WebSocket)
     */
    char* path;

    /**
     * Username for authentication
     */
    char* username;

    /**
     * Password for authentication
     */
    const char* password;
};

/**
 * Structure to represent MTP reference in obuspa datamodel
 */
struct MTPReference {
    /**
     * Path to MTP instance
     */
    char* path;

    /**
     * MTP connection info used to create MTP instance
     */
    struct MTPConnectionInfo connection_info;
};

/**
 * Convert MTP enum to obuspa MTP representation
 *
 * @param mtp MTP to convert to
 *
 * @return obuspa MTP representation, or empty string if cannot convert
 */
static const char* MTP_to_obuspa_MTP(enum MTP mtp) {
    switch(mtp) {
        #ifdef SUPPORT_MQTT_MTP
    case MTP_MQTT:
    case MTP_MQTTS:
        return "MQTT";
        #endif
        #ifdef SUPPORT_STOMP_MTP
    case MTP_STOMP:
        return "STOMP";
        #endif
    case MTP_WS:
    case MTP_WSS:
        return "WebSocket";
    default:
        return "";
    }
}

/**
 * Create new instance of MTPConnectionInfo
 *
 * @return instance of MTPConnectionInfo
 */
static struct MTPConnectionInfo new_mtp_connection_info(void) {
    struct MTPConnectionInfo mtp;
    memset(&mtp, 0, sizeof(struct MTPConnectionInfo));
    mtp.mtp_protocol = MTP_Unknown;

    return mtp;
}

/**
 * Free instance of MTPConnectionInfo
 *
 * @param[in] mtp MTPConnectionInfo to clean
 */
static void free_mtp_connection_info(struct MTPConnectionInfo mtp) {
    free(mtp.host);
    free(mtp.port);
    free(mtp.path);
    free(mtp.username);
}

/**
 * Parse URI into MTPConnectionInfo struct
 *
 * @param uri URI to parse
 *
 * @return instance MTPConnectionInfo to represent MTP connection
 */
static struct MTPConnectionInfo parse_mtp(UriUriA uri) {
    struct MTPConnectionInfo mtp = new_mtp_connection_info();

    mtp.host = uri_text_range_to_string(uri.hostText);
    mtp.port = uri_text_range_to_string(uri.portText);
    mtp.path = collect_uri_path_to_string(uri.pathHead);

    if(uri.userInfo.first && uri.userInfo.afterLast) {
        mtp.username = uri_text_range_to_string(uri.userInfo);
        char* delim = strchr(mtp.username, ':');
        if(delim) {
            *delim = '\0';
            if(*(delim + 1)) {
                mtp.password = delim + 1;
            }
        }
    }

    char* scheme = uri_text_range_to_string(uri.scheme);

    #ifdef SUPPORT_MQTT_MTP
    if(!strcmp(scheme, "mqtt")) {
        mtp.mtp_protocol = MTP_MQTT;
    } else if(!strcmp(scheme, "mqtts")) {
        mtp.mtp_protocol = MTP_MQTTS;
    } else
    #endif
    #ifdef SUPPORT_STOMP_MTP
    if(!strcmp(scheme, "stomp")) {
        mtp.mtp_protocol = MTP_STOMP;
    } else
    #endif
    if(!strcmp(scheme, "ws")) {
        mtp.mtp_protocol = MTP_WS;
    } else if(!strcmp(scheme, "wss")) {
        mtp.mtp_protocol = MTP_WSS;
    }
    free(scheme);

    return mtp;
}

#ifdef SUPPORT_MQTT_MTP

/**
 * Create a parameters for creating/updating Device.MQTT.Client.
 * instance from the MTPConnectionInfo struct
 *
 * @param[in] mtp_connection_info MTP connection
 * @param[in] Alias alias for the instances
 * @param update whether it is creation or update
 *
 * @return parameters for creating or updating Device.MQTT.Client.
 */
static amxc_var_t* mqtt_mtp_parameters(const struct MTPConnectionInfo* mtp_connection_info, const char* Alias,
                                       bool update) {
    amxc_var_t* parameters = NULL;
    amxc_var_new(&parameters);
    amxc_var_set_type(parameters, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, parameters, "BrokerAddress", mtp_connection_info->host);
    if(mtp_connection_info->port) {
        amxc_var_add_key(cstring_t, parameters, "BrokerPort", mtp_connection_info->port);
    }
    if(mtp_connection_info->username) {
        amxc_var_add_key(cstring_t, parameters, "Username", mtp_connection_info->username);
    }
    if(mtp_connection_info->password) {
        amxc_var_add_key(cstring_t, parameters, "Password", mtp_connection_info->password);
    }
    amxc_var_add_key(cstring_t, parameters, "TransportProtocol", (mtp_connection_info->mtp_protocol == MTP_MQTT) ? "TCP/IP" : "TLS");

    const char* mqtt_protocol_version = GET_CHAR(amxrt_get_config(), MQTT_PROTOCOL_VERSION);
    if(mqtt_protocol_version && strlen(mqtt_protocol_version)) {
        amxc_var_add_key(cstring_t, parameters, "ProtocolVersion", mqtt_protocol_version);
    }

    if(!update) {
        amxc_var_add_key(cstring_t, parameters, "Alias", Alias);
    }
    amxc_var_add_key(bool, parameters, "Enable", false);

    return parameters;
}

/**
 * Create or update MQTT MTP instance Device.MQTT.Client.
 *
 * @param[in] mtp_connection_info MTP connection
 * @param[in] Alias alias for the instances
 * @param update whether it is creation or update
 *
 * @return path to created/updated instance or NULL if error
 */
static char* create_or_update_mqtt_mtp(const struct MTPConnectionInfo* mtp_connection_info, const char* Alias,
                                       bool update) {
    char* mtp_ref = NULL;
    amxb_bus_ctx_t* ctx = get_bus_context("Device.MQTT.Client.");
    when_null_trace(ctx, exit, ERROR, "Cannot get bus context for MQTT client");

    if(update) {
        amxc_var_t* parameters = mqtt_mtp_parameters(mtp_connection_info, Alias, update);
        amxc_string_t mqtt_path;

        amxc_string_init(&mqtt_path, PATH_BUFFER_SIZE);
        amxc_string_setf(&mqtt_path, "Device.MQTT.Client.[Alias==%s].", Alias);

        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_set(ctx, amxc_string_get(&mqtt_path, 0), parameters, &ret, BUS_OPERATION_TIMEOUT);
        {
            amxc_string_t mtp_path;
            amxc_string_init(&mtp_path, PATH_BUFFER_SIZE);
            amxc_string_setf(&mtp_path, "%s", amxc_var_key(amxc_var_get_first(amxc_var_get_first(&ret))));
            mtp_ref = amxc_string_take_buffer(&mtp_path);
            amxc_string_clean(&mtp_path);
        }

        amxc_var_clean(&ret);
        amxc_string_clean(&mqtt_path);
        amxc_var_delete(&parameters);

        when_failed_trace(status, exit, WARNING,
                          "Cannot update MQTT client, got %d", status);
        when_null_trace(mtp_ref, exit, WARNING,
                        "Cannot extract reference to an MQTT.Client instance");
        goto exit;
    } else {
        // Creation of the Device.MQTT.Client.{i}. instance
        {
            amxc_var_t* parameters = mqtt_mtp_parameters(mtp_connection_info, Alias, update);
            amxc_var_t ret;
            amxc_var_init(&ret);

            int status = amxb_add(ctx, "Device.MQTT.Client.", 0, Alias, parameters, &ret, BUS_OPERATION_TIMEOUT);
            mtp_ref = amxc_var_dyncast(cstring_t, GETP_ARG(&ret, "0.path"));

            amxc_var_clean(&ret);
            amxc_var_delete(&parameters);

            when_failed_trace(status, exit, WARNING, "Cannot add MQTT client, got %d", status);
            when_null_trace(mtp_ref, exit, WARNING, "Cannot extract reference to an MQTT.Client instance");
        }
        // Creation of the Device.LocalAgent.MTP.{i}.MQTT. instance
        {
            amxc_var_t parameters;

            amxc_var_init(&parameters);
            amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

            if(GETP_CHAR(amxrt_get_config(), MQTT_CONTROLLER_SUBSCRIBE_TOPIC) && strlen(GETP_CHAR(amxrt_get_config(), MQTT_CONTROLLER_SUBSCRIBE_TOPIC))) {
                amxc_var_add_key(cstring_t, &parameters, "MQTT.ResponseTopicConfigured",
                                 GETP_CHAR(amxrt_get_config(), MQTT_CONTROLLER_SUBSCRIBE_TOPIC));
            }

            amxc_var_add_key(cstring_t, &parameters, "MQTT.Reference", mtp_ref);
            amxc_var_add_key(bool, &parameters, "Enable", true);
            amxc_var_add_key(cstring_t, &parameters, "Protocol", "MQTT");
            amxc_var_add_key(cstring_t, &parameters, "Alias", Alias);

            amxc_var_t ret;
            amxc_var_init(&ret);

            int status = amxb_add(ctx, "Device.LocalAgent.MTP.", 0, Alias,
                                  &parameters, &ret, BUS_OPERATION_TIMEOUT);

            amxc_var_clean(&ret);
            amxc_var_clean(&parameters);

            when_failed_trace(
                status, exit, WARNING,
                "Cannot add Device.LocalAgent.MTP.%s.MQTT instance , got %d", Alias,
                status);
        }
    }
exit:
    return mtp_ref;
}

#endif

#ifdef SUPPORT_STOMP_MTP

/**
 * Create a parameters for creating/updating Device.STOMP.Connection.
 * instance from the MTPConnectionInfo struct
 *
 * @param[in] mtp_connection_info MTP connection
 * @param[in] Alias alias for the instances
 * @param update whether it is creation or update
 *
 * @return parameters for creating or updating Device.STOMP.Connection.
 */
static amxc_var_t* stomp_mtp_parameters(const struct MTPConnectionInfo* mtp_connection_info, const char* Alias,
                                        bool update) {
    amxc_var_t* parameters = NULL;
    amxc_var_new(&parameters);
    amxc_var_set_type(parameters, AMXC_VAR_ID_HTABLE);

    amxc_var_add_key(cstring_t, parameters, "Host", mtp_connection_info->host);
    if(mtp_connection_info->port) {
        amxc_var_add_key(cstring_t, parameters, "Port", mtp_connection_info->port);
    }
    if(mtp_connection_info->username) {
        amxc_var_add_key(cstring_t, parameters, "Username", mtp_connection_info->username);
    }
    if(mtp_connection_info->password) {
        amxc_var_add_key(cstring_t, parameters, "BrokerPort", mtp_connection_info->password);
    }
    if(GETP_BOOL(amxrt_get_config(), STOMP_FORCE_NO_ENCRYPTION)) {
        amxc_var_add_key(bool, parameters, "EnableEncryption", false);
    }
    if(!update) {
        // amxc_var_add_key(bool, parameters, "Enable", true);
        amxc_var_add_key(cstring_t, parameters, "Alias", Alias);
    }

    return parameters;
}

/**
 * Create or update MQTT MTP instance Device.STOMP.Connection.
 *
 * @param[in] mtp_connection_info MTP connection
 * @param[in] Alias alias for the instances
 * @param update whether it is creation or update
 *
 * @return path to created/updated instance or NULL if error
 */
static char* create_or_update_stomp_mtp(const struct MTPConnectionInfo* mtp_connection_info, const char* Alias,
                                        bool update) {
    char* mtp_ref = NULL;
    amxb_bus_ctx_t* ctx = get_bus_context("Device.STOMP.Connection.");
    when_null_trace(ctx, exit, ERROR, "Cannot get bus context for STOMP client");

    if(update) {

        amxc_var_t* parameters = stomp_mtp_parameters(mtp_connection_info, Alias, update);
        amxc_string_t stomp_path;
        amxc_string_init(&stomp_path, PATH_BUFFER_SIZE);
        amxc_string_setf(&stomp_path, "Device.STOMP.Connection.[Alias==%s].", Alias);
        amxc_var_t ret;
        amxc_var_init(&ret);

        int status = amxb_set(ctx, amxc_string_get(&stomp_path, 0), parameters, &ret, BUS_OPERATION_TIMEOUT);
        {
            amxc_string_t mtp_path;
            amxc_string_init(&mtp_path, PATH_BUFFER_SIZE);
            amxc_string_setf(&mtp_path, "%s", amxc_var_key(amxc_var_get_first(amxc_var_get_first(&ret))));
            mtp_ref = amxc_string_take_buffer(&mtp_path);
            amxc_string_clean(&mtp_path);
        }

        amxc_var_clean(&ret);
        amxc_string_clean(&stomp_path);
        amxc_var_delete(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot update STOMP connection, got %d", status);
        when_null_trace(mtp_ref, exit, WARNING, "Cannot extract reference to an STOMP.Connection instance");

        goto exit;
    } else {
        // Creation of the Device.STOMP.Connection.{i}. instance
        {
            amxc_var_t* parameters = stomp_mtp_parameters(mtp_connection_info, Alias, update);
            amxc_var_t ret;
            amxc_var_init(&ret);

            int status = amxb_add(ctx, "Device.STOMP.Connection.", 0, Alias, parameters, &ret, BUS_OPERATION_TIMEOUT);

            mtp_ref = amxc_var_dyncast(cstring_t, GETP_ARG(&ret, "0.path"));

            amxc_var_clean(&ret);
            amxc_var_delete(&parameters);

            when_failed_trace(status, exit, WARNING, "Cannot add STOMP connection, got %d", status);
            when_null_trace(mtp_ref, exit, WARNING, "Cannot extract reference to an STOMP.Connection instance");
        }
        // Creation of the Device.LocalAgent.MTP.{i}.STOMP. instance
        {
            amxc_var_t parameters;
            amxc_var_init(&parameters);
            amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

            amxc_var_add_key(cstring_t, &parameters, "STOMP.Reference", mtp_ref);
            amxc_var_add_key(cstring_t, &parameters, "STOMP.Destination", GETP_CHAR(amxrt_get_config(), STOMP_CONTROLLER_AGENT_DESTINATION));
            amxc_var_add_key(bool, &parameters, "Enable", true);
            amxc_var_add_key(cstring_t, &parameters, "Protocol", "STOMP");
            amxc_var_add_key(cstring_t, &parameters, "Alias", Alias);

            amxc_var_t ret;
            amxc_var_init(&ret);

            int status = amxb_add(ctx, "Device.LocalAgent.MTP.", 0, Alias, &parameters, &ret, BUS_OPERATION_TIMEOUT);

            amxc_var_clean(&ret);
            amxc_var_clean(&parameters);

            when_failed_trace(
                status, exit, WARNING,
                "Cannot add Device.LocalAgent.MTP.%s.STOMP instance , got %d", Alias,
                status);
        }
    }
exit:
    return mtp_ref;
}

#endif

/**
 * Add or replace MTP instance
 *
 * @param[in] Alias alias for created instance
 * @param[in] URL URI to connect to MTP
 * @param[in/out] mtp_ref MTPReference to fill
 * @param update whether it is update
 *
 * @return 0 if no error happened
 */
static int add_or_replace_MTP(
    #if !defined(SUPPORT_MQTT_MTP) && !defined(SUPPORT_STOMP_MTP)
    UNUSED
    #endif
    const char* Alias,
    const char* URL,
    struct MTPReference* mtp_ref,
    #if !defined(SUPPORT_MQTT_MTP) && !defined(SUPPORT_STOMP_MTP)
    UNUSED
    #endif
    bool update
    ) {
    int rc = -1;
    UriUriA uri;
    const char* errorPos;

    if(uriParseSingleUriA(&uri, URL, &errorPos) != URI_SUCCESS) {
        SAH_TRACEZ_WARNING(ME, "Cannot parse '%s' URL, error at %s", URL, errorPos);
        return rc;
    }

    mtp_ref->connection_info = parse_mtp(uri);

    #ifdef SUPPORT_MQTT_MTP
    if((mtp_ref->connection_info.mtp_protocol == MTP_MQTT) || (mtp_ref->connection_info.mtp_protocol == MTP_MQTTS)) {
        mtp_ref->path = create_or_update_mqtt_mtp(&(mtp_ref->connection_info), Alias, update);
    } else
    #endif
    #ifdef SUPPORT_STOMP_MTP
    if(mtp_ref->connection_info.mtp_protocol == MTP_STOMP) {
        mtp_ref->path = create_or_update_stomp_mtp(&(mtp_ref->connection_info), Alias, update);
    } else
    #endif
    if((mtp_ref->connection_info.mtp_protocol == MTP_WS) || (mtp_ref->connection_info.mtp_protocol == MTP_WSS)) {
        mtp_ref->path = NULL;
        rc = 0;
    } else if(mtp_ref->connection_info.mtp_protocol == MTP_Unknown) {
        SAH_TRACEZ_WARNING(ME, "Unknown MTP provided: '%s'", URL);
    }
    rc = mtp_ref->path ? 0 : rc;

    uriFreeUriMembersA(&uri);
    return rc;
}

/**
 * Find path to USP controller path, indexed by instances
 * using Alias to search in Device.LocalAgent.Controller
 *
 * @param[in] ctx bus context to search in
 * @param[in] Alias to find controller
 *
 * @return USP Controller path with instance as identifiers, or NULL if controller cannot be found
 */
static char* find_controller_path(amxb_bus_ctx_t* ctx, const char* Alias) {
    amxc_string_t controller_path;
    amxc_string_init(&controller_path, PATH_BUFFER_SIZE);
    amxc_string_t alias_postprocessed = search_path_alias_postprocess_function(Alias);
    amxc_string_setf(&controller_path, "Device.LocalAgent.Controller.[Alias==%s].", amxc_string_get(&alias_postprocessed, 0));
    amxc_string_clean(&alias_postprocessed);

    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_get(ctx, amxc_string_get(&controller_path, 0), 0, &ret, BUS_OPERATION_TIMEOUT);
    char* result = (status || !amxc_var_get_first(amxc_var_get_first(&ret))) ? NULL : amxc_string_take_buffer(&controller_path);

    amxc_var_clean(&ret);
    amxc_string_clean(&controller_path);

    return result;
}

/**
 * Get parameters to create/update instance of Device.LocalAgent.Controller.
 *
 * @param[in] controller information about the controller
 * @param[in] Alias alias to use in the new instance
 * @param enable whether to enable new instance
 * @param update whether it is update
 *
 * @return list of parameters
 */
static amxc_var_t* controller_parameters(struct DHCPControllerInformation* controller, const char* Alias, bool enable, bool update) {
    amxc_var_t* parameters = NULL;
    amxc_var_new(&parameters);
    amxc_var_set_type(parameters, AMXC_VAR_ID_HTABLE);

    if(!update) {
        amxc_var_add_key(cstring_t, parameters, "Alias", Alias);
        amxc_var_add_key(bool, parameters, "Enable", enable);
    }
    amxc_var_add_key(cstring_t, parameters, "EndpointID", controller->EndpointID);
    if(controller->ProvisioningCode) {
        amxc_var_add_key(cstring_t, parameters, "ProvisioningCode",
                         controller->ProvisioningCode);
    }
    if(controller->USPNotifRetryMinimumWaitInterval) {
        amxc_var_add_key(uint16_t, parameters, "USPNotifRetryMinimumWaitInterval",
                         controller->USPNotifRetryMinimumWaitInterval);
    }
    if(controller->USPNotifRetryIntervalMultiplier) {
        amxc_var_add_key(uint16_t, parameters, "USPNotifRetryIntervalMultiplier",
                         controller->USPNotifRetryIntervalMultiplier);
    }

    return parameters;
}

/**
 * Set state of the 'Enable' parameter in the object
 *
 * @param[in] ctx bus context to use
 * @param[in] path path to the object
 * @param enable value for the 'Enable' param
 *
 * @return 0 if no error happened
 */
static int set_enable_state(amxb_bus_ctx_t* ctx,
                            const char* path, bool enable) {
    int rc = -1;

    amxc_var_t parameters;
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &parameters, "Enable", enable);

    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_set(ctx, path, &parameters, &ret, BUS_OPERATION_TIMEOUT);

    amxc_var_clean(&ret);
    amxc_var_clean(&parameters);
    when_failed_trace(status, exit, WARNING, "Cannot enable controller, got %d", status);

    rc = 0;

exit:
    return rc;
}

/**
 * Get the parameters for Device.LocalAgent.Controller.{i}.MTP.{i}
 *
 * @param[in] mtp_ref MTP reference to use
 * @param[in] Alias alias to use
 * @param update whether it is update
 *
 * @return list of parameters
 */
static amxc_var_t* controller_mtp_parameters(struct MTPReference mtp_ref,
                                             const char* Alias, bool update) {
    amxc_var_t* parameters = NULL;
    amxc_var_new(&parameters);
    amxc_var_set_type(parameters, AMXC_VAR_ID_HTABLE);

    if(!update) {
        amxc_var_add_key(cstring_t, parameters, "Alias", Alias);
        amxc_var_add_key(bool, parameters, "Enable", true);
    }
    amxc_var_add_key(cstring_t, parameters, "Protocol", MTP_to_obuspa_MTP(mtp_ref.connection_info.mtp_protocol));
    #ifdef SUPPORT_MQTT_MTP
    if((mtp_ref.connection_info.mtp_protocol == MTP_MQTT) || (mtp_ref.connection_info.mtp_protocol == MTP_MQTTS)) {
        amxc_var_add_key(cstring_t, parameters, "MQTT.Reference", mtp_ref.path);
        amxc_var_add_key(cstring_t, parameters, "MQTT.Topic",
                         GETP_CHAR(amxrt_get_config(), MQTT_AGENT_REPLY_TOPIC));
    }
    #endif
    #ifdef SUPPORT_STOMP_MTP
    if(mtp_ref.connection_info.mtp_protocol == MTP_STOMP) {
        amxc_var_add_key(cstring_t, parameters, "STOMP.Reference", mtp_ref.path);
        amxc_var_add_key(cstring_t, parameters, "STOMP.Destination",
                         GETP_CHAR(amxrt_get_config(), STOMP_AGENT_CONTROLLER_DESTINATION));
    }
    #endif
    if((mtp_ref.connection_info.mtp_protocol == MTP_WS) || (mtp_ref.connection_info.mtp_protocol == MTP_WSS)) {
        amxc_var_add_key(cstring_t, parameters, "WebSocket.Host", mtp_ref.connection_info.host);
        amxc_var_add_key(cstring_t, parameters, "WebSocket.Port", mtp_ref.connection_info.port);
        amxc_var_add_key(cstring_t, parameters, "WebSocket.Path", mtp_ref.connection_info.path);
        amxc_var_add_key(bool, parameters, "WebSocket.EnableEncryption", (mtp_ref.connection_info.mtp_protocol == MTP_WSS));
    }

    return parameters;
}

/**
 * Add USP controller instance to the Device.LocalAgent.Controller.
 *
 * @param[in] ctx bus context to use
 * @param[in] Alias alias to use when creating instances
 * @param controller USP controller information
 * @param mtp_ref MTP reference for use in Controller instance
 *
 * @return 0 if no error happened
 */
static int add_controller(amxb_bus_ctx_t* ctx, const char* Alias,
                          struct DHCPControllerInformation* controller,
                          struct MTPReference mtp_ref) {
    int rc = -1;

    // Adding Device.LocalAgent.Controller.{i}. instance
    amxc_string_t controller_path;
    amxc_string_init(&controller_path, PATH_BUFFER_SIZE);
    {
        amxc_var_t* parameters = controller_parameters(controller, Alias, (mtp_ref.connection_info.mtp_protocol != MTP_WS && mtp_ref.connection_info.mtp_protocol != MTP_WSS), false);

        amxc_var_t ret;
        amxc_var_init(&ret);
        int status = amxb_add(ctx, "Device.LocalAgent.Controller.", 0, Alias,
                              parameters, &ret, BUS_OPERATION_TIMEOUT);

        amxc_string_set(&controller_path, GETP_CHAR(&ret, "0.path"));

        amxc_var_clean(&ret);
        amxc_var_delete(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot add Controller instance, got %d", status);
    }
    // Adding Device.LocalAgent.Controller.{i}.MTP. instance
    {
        amxc_var_t* parameters = controller_mtp_parameters(mtp_ref, Alias, false);

        amxc_var_t ret;
        amxc_var_init(&ret);

        amxc_string_t mtp_path;
        amxc_string_init(&mtp_path, PATH_BUFFER_SIZE);
        amxc_string_setf(&mtp_path, "%sMTP.", amxc_string_get(&controller_path, 0));

        int status = amxb_add(ctx, amxc_string_get(&mtp_path, 0), 0, Alias,
                              parameters, &ret, BUS_OPERATION_TIMEOUT);

        amxc_string_clean(&mtp_path);
        amxc_var_clean(&ret);
        amxc_var_delete(&parameters);

        when_failed_trace(status, exit, WARNING, "Cannot add MTP instance, got %d",
                          status);
    }

    if((mtp_ref.connection_info.mtp_protocol == MTP_WS) || (mtp_ref.connection_info.mtp_protocol == MTP_WSS)) {
        set_enable_state(ctx, amxc_string_get(&controller_path, 0), true);
    }
    rc = 0;

exit:
    amxc_string_clean(&controller_path);
    return rc;
}

/**
 * Update USP controller instance identified by Alias in
 * the Device.LocalAgent.Controller. table
 *
 * @param[in] ctx bus context to use
 * @param[in] Alias alias to use when creating instances
 * @param controller USP controller information
 * @param mtp_ref MTP reference for use in Controller instance
 *
 * @return 0 if no error happened

 */
static int update_controller(amxb_bus_ctx_t* ctx, const char* Alias,
                             const char* controller_path,
                             struct DHCPControllerInformation* controller, struct MTPReference mtp_ref) {
    int rc = -1;
    // Update Device.LocalAgent.Controller.{i}. instance
    amxc_var_t* parameters = controller_parameters(controller, Alias, true, true);
    when_null_trace(parameters, exit, WARNING, "Cannot get update parameters for Controller '%s'", Alias);

    amxc_var_t* mtp_parameters = controller_mtp_parameters(mtp_ref, Alias, true);
    amxc_var_for_each(mtp_parameter, mtp_parameters) {
        amxc_string_t mtp_parameter_path;
        amxc_string_init(&mtp_parameter_path, PATH_BUFFER_SIZE);
        amxc_string_setf(&mtp_parameter_path, "%s%s", "MTP.1.", amxc_var_key(mtp_parameter));
        amxc_var_t* controller_mtp_parameter = amxc_var_add_new_key(parameters, amxc_string_get(&mtp_parameter_path, 0));
        amxc_string_clean(&mtp_parameter_path);
        amxc_var_copy(controller_mtp_parameter, mtp_parameter);
    }

    amxc_var_delete(&mtp_parameters);

    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_set(ctx, controller_path, parameters, &ret, BUS_OPERATION_TIMEOUT);

    amxc_var_clean(&ret);
    amxc_var_delete(&parameters);

    when_failed_trace(status, exit, WARNING, "Cannot update Controller instance, got %d", status);
    rc = 0;

exit:
    return rc;
}

/**
 * Check whether USP controller has change it's MTP
 *
 * @param[in] ctx bus context to use
 * @param[in] Alias alias for the USP controller to check
 * @param controller USP Controller information from the DHCP option
 *
 * @return whether USP Controller has changed MTP
 */
static bool controller_changed_mtp(amxb_bus_ctx_t* ctx, const char* Alias,
                                   struct DHCPControllerInformation* controller) {
    bool rc = false;

    amxc_string_t current_mtp_path;
    amxc_string_init(&current_mtp_path, PATH_BUFFER_SIZE);
    amxc_string_t alias_postprocessed = search_path_alias_postprocess_function(Alias);
    amxc_string_setf(&current_mtp_path,
                     "Device.LocalAgent.Controller.[Alias==%s].MTP.1.Protocol",
                     amxc_string_get(&alias_postprocessed, 0));
    amxc_string_clean(&alias_postprocessed);

    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_get(ctx, amxc_string_get(&current_mtp_path, 0), 1, &ret, BUS_OPERATION_TIMEOUT);
    when_failed_trace(status, exit, INFO,
                      "Cannot get controller's MTP by path %s",
                      amxc_string_get(&current_mtp_path, 0));

    const char* current_mtp = GET_CHAR(amxc_var_get_first(amxc_var_get_first(&ret)), "Protocol");
    when_null_trace(current_mtp, exit, INFO, "Cannot get controller's MTP by path %s, 'Protocol' cannot be found", amxc_string_get(&current_mtp_path, 0));

    const char* new_mtp = url_get_obuspa_mtp(controller->URL);
    when_null_trace(new_mtp, exit, WARNING, "Cannot new obuspa mtp for the URL"); \

    const char* obuspa_mtp = url_get_obuspa_mtp(controller->URL);
    when_null_trace(obuspa_mtp, exit, WARNING, "Cannot extract current obuspa mtp for the URL");

    rc = strcmp(new_mtp, current_mtp);

exit:
    amxc_var_clean(&ret);
    amxc_string_clean(&current_mtp_path);
    return rc;
}

int add_or_replace_controller(const char* Alias,
                              struct DHCPControllerInformation* controller) {
    int rc = -1;

    char* controller_search_path = NULL;

    amxb_bus_ctx_t* ctx = get_bus_context("Device.LocalAgent.Controller.");
    when_null_trace(ctx, exit, ERROR, "Cannot get bus context for Controller");

    controller_search_path = find_controller_path(ctx, Alias);

    struct MTPReference mtp_ref;
    memset(&mtp_ref, 0, sizeof(struct MTPReference));

    bool mtp_changed = controller_changed_mtp(ctx, Alias, controller);
    if(mtp_changed) {
        when_failed_trace(remove_controller(Alias), exit, WARNING, "Cannot remove controller by Alias '%s'", Alias);
    }

    if(controller_search_path && !mtp_changed) {
        if(add_or_replace_MTP(Alias, controller->URL, &mtp_ref, true)) {
            SAH_TRACEZ_WARNING(ME, "Cannot update MTP");
            goto exit;
        }
        if(update_controller(ctx, Alias, controller_search_path, controller, mtp_ref)) {
            SAH_TRACEZ_WARNING(ME, "Cannot update Controller");
            goto exit;
        }
        if(mtp_ref.path && set_enable_state(ctx, mtp_ref.path, true)) {
            SAH_TRACEZ_WARNING(ME, "Cannot enable MTP at %s", mtp_ref.path);
            goto exit;
        }

    } else {
        if(add_or_replace_MTP(Alias, controller->URL, &mtp_ref, false)) {
            SAH_TRACEZ_WARNING(ME, "Cannot add MTP");
            goto exit;
        }
        if(add_controller(ctx, Alias, controller, mtp_ref)) {
            SAH_TRACEZ_WARNING(ME, "Cannot add Controller");
            goto exit;
        }
        if(mtp_ref.path && set_enable_state(ctx, mtp_ref.path, true)) {
            SAH_TRACEZ_WARNING(ME, "Cannot enable MTP at %s", mtp_ref.path);
            goto exit;
        }
    }
    rc = 0;

exit:
    free(mtp_ref.path);
    free_mtp_connection_info(mtp_ref.connection_info);
    free(controller_search_path);
    return rc;
}

/**
 * Remove instance in table using alias as identification
 *
 * @param[in] ctx bus context to use
 * @param[in] table_path path to table in which search for instance
 * @param[in] Alias alias of the instance to remove
 * @param disable_before_removal whether set 'Enable=false' parameter before removing
 *
 * @return 0 if no error happened
 */
static int remove_instance(amxb_bus_ctx_t* ctx, const char* table_path, const char* Alias, bool disable_before_removal) {
    amxc_string_t instance_path;
    amxc_string_init(&instance_path, PATH_BUFFER_SIZE);
    amxc_string_t alias_postprocessed = search_path_alias_postprocess_function(Alias);
    amxc_string_setf(&instance_path, "%s[Alias==%s].", table_path, amxc_string_get(&alias_postprocessed, 0));
    amxc_string_clean(&alias_postprocessed);

    if(disable_before_removal && set_enable_state(ctx, amxc_string_get(&instance_path, 0), false)) {
        SAH_TRACEZ_WARNING(ME, "Failed to diabled %s before removal", amxc_string_get(&instance_path, 0));
    }

    amxc_var_t ret;
    amxc_var_init(&ret);
    int status = amxb_del(ctx, amxc_string_get(&instance_path, 0), 0, NULL, &ret, BUS_OPERATION_TIMEOUT);
    amxc_var_clean(&ret);
    amxc_string_clean(&instance_path);

    return status;
}

/**
 * Get MTP type used by the USP Controller
 *
 * @param[in] ctx bus context to use
 * @param[in] Alias alias of the USP controller
 *
 * @return MTP type of the USP controller
 */
static enum MTP get_mtp_for_controller(amxb_bus_ctx_t* ctx, const char* Alias) {
    enum MTP mtp = MTP_Unknown;

    amxc_string_t current_mtp_path;
    amxc_string_init(&current_mtp_path, PATH_BUFFER_SIZE);
    amxc_string_t alias_postprocessed = search_path_alias_postprocess_function(Alias);
    amxc_string_setf(&current_mtp_path, "Device.LocalAgent.Controller.[Alias==%s].MTP.1.Protocol", amxc_string_get(&alias_postprocessed, 0));
    amxc_string_clean(&alias_postprocessed);
    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_get(ctx, amxc_string_get(&current_mtp_path, 0), 10, &ret, BUS_OPERATION_TIMEOUT);

    when_failed_trace(status, exit, INFO,
                      "Cannot get controller's MTP by path %s, got %d",
                      amxc_string_get(&current_mtp_path, 0), status);

    const char* current_mtp = GET_CHAR(amxc_var_get_first(amxc_var_get_first(&ret)), "Protocol");
    when_null_trace(current_mtp, exit, INFO, "Cannot get MTP, got NULL instead");

    #ifdef SUPPORT_MQTT_MTP
    if(!strcmp(current_mtp, "MQTT")) {
        mtp = MTP_MQTT;
    } else
    #endif
    #ifdef SUPPORT_STOMP_MTP
    if(!strcmp(current_mtp, "STOMP")) {
        mtp = MTP_STOMP;
    } else
    #endif
    if(!strcmp(current_mtp, "WebSocket")) {
        mtp = MTP_WS;
    }
exit:
    amxc_var_clean(&ret);
    amxc_string_clean(&current_mtp_path);
    return mtp;
}

int remove_controller(const char* Alias) {
    int rc = -1;

    amxb_bus_ctx_t* ctx = get_bus_context("Device.LocalAgent.Controller.");
    when_null_trace(ctx, exit, ERROR, "Cannot get bus context for Controller");

    enum MTP mtp = get_mtp_for_controller(ctx, Alias);
    const char* mtp_instance_path = NULL;
    switch(mtp) {
    #ifdef SUPPORT_MQTT_MTP
    case MTP_MQTT:
    case MTP_MQTTS:
        mtp_instance_path = "Device.MQTT.Client.";
        break;
    #endif
    #ifdef SUPPORT_STOMP_MTP
    case MTP_STOMP:
        mtp_instance_path = "Device.STOMP.Connection.";
        break;
    #endif
    case MTP_WS:
    case MTP_WSS:
        mtp_instance_path = NULL;
        break;
    default:
        goto exit;
    }

    int status = remove_instance(ctx, "Device.LocalAgent.Controller.", Alias, true);

    when_failed_trace(
        status, exit, WARNING,
        "Cannot remove Device.LocalAgent.Controller.%s instance, got %d", Alias,
        status);

    remove_instance(ctx, "Device.LocalAgent.MTP.", Alias, false);

    if(mtp_instance_path) {
        status = remove_instance(ctx, mtp_instance_path, Alias, false);

        when_failed_trace(status, exit, WARNING,
                          "Cannot remove %s%s instance, got %d", mtp_instance_path,
                          Alias, status);
    }
    rc = 0;

exit:
    return rc;
}

/**
 * Remove all instances associated with the usp_discovery in table
 *
 * @param[in] table_path path to table to clean
 *
 * @return 0 if no error happened
 */
static int remove_all_instances(const char* table_path) {
    int rc = -1;

    amxb_bus_ctx_t* ctx = get_bus_context(table_path);
    when_null_trace(ctx, exit, ERROR, "Cannot get USP bus context");

    amxc_var_t ret;
    amxc_var_init(&ret);

    int status = amxb_get_instances(ctx, table_path, 0, &ret, BUS_OPERATION_TIMEOUT);
    when_failed_trace(status, clean_ret, WARNING, "Cannot get instances for '%s', got %d", table_path, status);

    amxc_var_t* instances = amxc_var_get_first(&ret);
    when_null_trace(instances, clean_ret, WARNING, "Cannot extract list of instances for '%s'", table_path);
    amxc_var_for_each(instance, instances) {
        const char* key = amxc_var_key(instance);
        const char* alias = GET_CHAR(instance, "Alias");
        if(!key || !alias) {
            continue;
        }
        if(strstr(alias, "usp_discovery") != alias) {
            continue;
        }
        status = remove_instance(ctx, table_path, alias, true);
        when_failed_trace(status, clean_ret, WARNING, "Cannot remove '%s' instance", key);
    }

    rc = 0;
clean_ret:
    amxc_var_clean(&ret);
exit:
    return rc;
}

int remove_all_controllers(void) {
    int rc = 0;
    const char* tables_to_clean[] = {
#if defined(SUPPORT_MQTT_MTP) || defined(SUPPORT_STOMP_MTP)
        "Device.LocalAgent.MTP.",
#endif
#ifdef SUPPORT_MQTT_MTP
        "Device.MQTT.Client.",
        #endif
#ifdef SUPPORT_STOMP_MTP
        "Device.STOMP.Connection.",
#endif
        "Device.LocalAgent.Controller."
    };
    for(size_t i = 0; i != sizeof(tables_to_clean) / sizeof(tables_to_clean[0]); ++i) {
        if(remove_all_instances(tables_to_clean[i])) {
            SAH_TRACEZ_WARNING(ME, "Cannot remove all instances, created by the usp_discovery in the '%s' table", tables_to_clean[i]);
            rc = -1;
            break;
        }
    }
    return rc;
}

#ifndef IGNORE_STACK_REFERENCE
int set_stack_preference(enum DHCPType dhcp_type) {
    int rc = -1;

    amxb_bus_ctx_t* ctx = get_bus_context("Internal.");
    when_null_trace(ctx, exit, ERROR, "Cannot get bus context for 'Internal.DualStackPreference'");

    amxc_var_t parameters;
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &parameters, "DualStackPreference", (dhcp_type == DHCPType_DHCPv6) ? "IPv6" : "IPv4");

    amxc_var_t ret;
    amxc_var_init(&ret);

    rc = amxb_set(ctx, "Internal.", &parameters, &ret, BUS_OPERATION_TIMEOUT);

    amxc_var_clean(&ret);
    amxc_var_clean(&parameters);

exit:
    return rc;
}
#endif