/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>

#include "usb.h"
#include "usb-pwr.h"

int amxm_execute_function(const char* so_name,
                          const char* module,
                          const char* function_name,
                          amxc_var_t* data,
                          amxc_var_t* ret) {
    (void) so_name;

    if((module == NULL) || (function_name == NULL)) {
        return -1;
    }

    if(strcmp(module, MOD_PWR_CTRL) != 0) {
        return -1;
    }

    if(strcmp(function_name, "pwr-capabilities-get") == 0) {
        const char* port_name = GET_CHAR(data, "port_name");
        if((port_name == NULL) || (port_name[0] == '\0')) {
            return -1;
        }
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(csv_string_t, ret, "power_capabilities", "On,Off,LowPower");
        return 0;
    }

    if(strcmp(function_name, "pwr-status-get") == 0) {
        const char* port_name = GET_CHAR(data, "port_name");
        if((port_name == NULL) || (port_name[0] == '\0')) {
            return -1;
        }
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, ret, "power_status", "On");
        return 0;
    }

    if(strcmp(function_name, "pwr-mode-set") == 0) {
        const char* port_name = GET_CHAR(data, "port_name");
        const char* power_mode = GET_CHAR(data, "power_mode");
        if((port_name == NULL) || (port_name[0] == '\0') || (power_mode == NULL) || (power_mode[0] == '\0')) {
            return -1;
        }
        amxc_var_set_type(ret, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(cstring_t, ret, "power_status", power_mode);
        return 0;
    }

    if(strcmp(function_name, "pwr-async-done") == 0) {
        // In real module this is emitted asynchronously. Here we just forward.
        return usb_async_change_power_mode_status_set_done(function_name, data, ret);
    }

    return -1;
}

