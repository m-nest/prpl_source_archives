# `tr181-gatewayinfo`
TR-369 standard specifies [use of DHCP to exchange information about GatewayInfo](https://usp.technology/specification/index.htm#sec:gatewayinfo), the `tr181-gatewayinfo` is a service intended to support TR-181 `Device.GatewayInfo.` model per TR-069 and TR-369 standards. The following DHCP options are supported:

|   Encapsulated Option | DHCPv4 Option 125 | DHCPv6 Option 17 | Parameter in the Device:2 Data Model |
|----------------------:|:-----------------:|:----------------:|--------------------------------------|
| DeviceManufacturerOUI | 1                 | 11               | Device.DeviceInfo.ManufacturerOUI    |
| DeviceSerialNumber    | 2                 | 12               | Device.DeviceInfo.SerialNumber       |
| DeviceProductClass    | 3                 | 13               | Device.DeviceInfo.ProductClass       |

For USP parameter `Device.GatewayInfo.ManagementProtocol` is also supported to have either empty string or 'CWMP' string inside.
For USP the `Device.GatewayInfo.CWMPGatewayDiscovered!` event is supported. For ACS active notifications are sent when change in the `Device.GatewayInfo.` parameters happens.
