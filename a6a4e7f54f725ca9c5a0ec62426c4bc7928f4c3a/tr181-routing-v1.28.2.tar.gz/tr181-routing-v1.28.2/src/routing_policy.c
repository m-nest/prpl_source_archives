/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "routing_policy.h"
#include "routing_manager.h"

// Defined by prpl LL-API
#define FORWARDING_POLICY_MASK 0x00003FC0

typedef struct {
    netmodel_query_t* iif_query;
    netmodel_query_t* oif_query;
    cstring_t iif; // Input interface
    cstring_t oif; // Output interface
    amxd_object_t* obj;
    amxc_var_t* last_set_args;
} routing_policy_t;

static bool param_not_empty(amxd_object_t* object, const cstring_t param) {
    cstring_t val = NULL;
    bool ret = false;

    when_null(object, exit);
    when_str_empty(param, exit);

    val = amxd_object_get_value(cstring_t, object, param, NULL);
    ret = !str_empty(val);

exit:
    free(val);
    return ret;
}

static void get_policy_args(amxd_object_t* object, amxc_var_t* data) {
    routing_policy_t* policy = NULL;
    amxc_string_t routing_table;
    amxd_object_t* routing_table_obj = NULL;
    amxc_var_t* to_delete = NULL;

    amxc_string_init(&routing_table, 0);

    when_null_trace(data, exit, ERROR, "Output variant parameter is NULL");
    when_null_trace(object, exit, ERROR, "Routing policy object is NULL");
    when_null_trace(object->priv, exit, ERROR, "Routing policy private data is NULL");

    amxd_object_get_params(object, data, amxd_dm_access_protected);

    amxc_string_set(&routing_table, GET_CHAR(data, "RouterRef"));
    amxc_string_replace(&routing_table, "Device.", "", UINT32_MAX);
    routing_table_obj = amxd_dm_findf(routing_manager_get_dm(), "%s", amxc_string_get(&routing_table, 0));
    if(routing_table_obj != NULL) {
        amxc_var_add_key(uint32_t, data, "ID",
                         amxd_object_get_value(uint32_t, routing_table_obj, "ID", NULL));
    }

    policy = object->priv;
    if(!str_empty(policy->iif)) {
        amxc_var_add_key(cstring_t, data, "iif", policy->iif);
    }
    if(!str_empty(policy->oif)) {
        amxc_var_add_key(cstring_t, data, "oif", policy->oif);
    }

    if(GET_INT32(data, "ForwardingPolicy") > 0) {
        amxc_var_add_key(uint32_t, data, "FwMask", FORWARDING_POLICY_MASK);
    }

    to_delete = amxc_var_take_key(data, "Alias");
    amxc_var_delete(&to_delete);
    to_delete = amxc_var_take_key(data, "Origin");
    amxc_var_delete(&to_delete);
    to_delete = amxc_var_take_key(data, "RouterRef");
    amxc_var_delete(&to_delete);
    to_delete = amxc_var_take_key(data, "DestInterface");
    amxc_var_delete(&to_delete);
    to_delete = amxc_var_take_key(data, "SourceInterface");
    amxc_var_delete(&to_delete);
    to_delete = amxc_var_take_key(data, "Status");
    amxc_var_delete(&to_delete);
exit:
    amxc_string_clean(&routing_table);
    return;
}

amxd_status_t set_routing_policy(amxd_object_t* object) {
    routing_policy_t* policy = NULL;
    amxd_status_t status = amxd_status_unknown_error;
    amxc_var_t policy_args;
    int vars_equal = -1;

    amxc_var_init(&policy_args);
    when_null(object, exit);
    when_null(object->priv, exit);

    policy = object->priv;

    // The query callback functions will call set_routing_policy when the interface names are available
    when_true_trace(((str_empty(policy->iif)) && (param_not_empty(object, "SourceInterface"))) ||
                    ((str_empty(policy->oif)) && (param_not_empty(object, "DestInterface"))),
                    exit, INFO, "Interface name(s) being resolved");

    get_policy_args(object, &policy_args);
    amxc_var_compare(&policy_args, policy->last_set_args, &vars_equal);
    when_true_status(vars_equal == 0, exit, status = amxd_status_ok);

    // delete previously set policy if applicable
    remove_routing_policy(object);

    status = routing_manager_call_ctrl(object, ROUTING_POLICY_SET, &policy_args);
    when_failed_trace(status, exit, ERROR, "Failed to set routing policy");
    amxc_var_move(policy->last_set_args, &policy_args);
exit:
    policy_set_status(object, status == amxd_status_ok ? STATUS_ENABLED : STATUS_ERROR);
    amxc_var_clean(&policy_args);
    return status;
}

amxd_status_t remove_routing_policy(amxd_object_t* object) {
    routing_policy_t* policy = NULL;
    amxd_status_t status = amxd_status_unknown_error;

    when_null(object, exit);
    when_null(object->priv, exit);

    policy = object->priv;

    if(!amxc_var_is_null(policy->last_set_args)) {
        status = routing_manager_call_ctrl(object, ROUTING_POLICY_REMOVE, policy->last_set_args);
        when_failed_trace(status, exit, ERROR, "Failed to delete policy");
        amxc_var_clean(policy->last_set_args);
    }

exit:
    return status;
}

static void routing_policy_iif_cb(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    routing_policy_t* policy = priv;
    const cstring_t ifname = amxc_var_constcast(cstring_t, data);

    free(policy->iif);
    policy->iif = str_empty(ifname)? NULL : strdup(ifname);
    set_routing_policy(policy->obj);
}

static void routing_policy_oif_cb(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    routing_policy_t* policy = priv;
    const cstring_t ifname = amxc_var_constcast(cstring_t, data);

    free(policy->oif);
    policy->oif = str_empty(ifname)? NULL : strdup(ifname);
    set_routing_policy(policy->obj);
}

static void open_if_query(routing_policy_t* policy, netmodel_query_t** query, const cstring_t interface, netmodel_callback_t cb) {
    when_null_trace(policy, exit, ERROR, "Policy info is NULL");
    if(*query != NULL) {
        netmodel_closeQuery(*query);
        *query = NULL;
    }
    when_str_empty_trace(interface, exit, INFO, "Interface is empty");


    *query = netmodel_openQuery_getFirstParameter(interface, "routing-manager",
                                                  "NetDevName", "netdev-bound",
                                                  netmodel_traverse_down, cb,
                                                  policy);
    when_null_trace(*query, exit, ERROR, "Failed to open netdev query for interface %s", interface);
exit:
    return;
}

void open_iif_query(amxd_object_t* object) {
    routing_policy_t* policy = NULL;
    cstring_t intf = NULL;

    when_null(object, exit);
    when_null(object->priv, exit);

    intf = amxd_object_get_value(cstring_t, object, "SourceInterface", NULL);
    policy = object->priv;
    free(policy->iif);
    policy->iif = NULL;
    open_if_query(policy, &policy->iif_query, intf, routing_policy_iif_cb);
exit:
    free(intf);
    return;
}

void open_oif_query(amxd_object_t* object) {
    routing_policy_t* policy = NULL;
    cstring_t intf = NULL;

    when_null(object, exit);
    when_null(object->priv, exit);

    intf = amxd_object_get_value(cstring_t, object, "DestInterface", NULL);

    policy = object->priv;
    free(policy->oif);
    policy->oif = NULL;
    open_if_query(policy, &policy->oif_query, intf, routing_policy_oif_cb);
exit:
    free(intf);
    return;
}

void create_policy_info(amxd_object_t* object) {
    routing_policy_t* policy = NULL;
    when_null(object, exit);

    if(object->priv != NULL) {
        destroy_policy_info(object);
        object->priv = NULL;
    }

    policy = calloc(1, sizeof(routing_policy_t));
    when_null_trace(policy, exit, ERROR, "Failed to allocate memory for routing policy");
    object->priv = policy;
    policy->obj = object;

    amxc_var_new(&policy->last_set_args);

    open_iif_query(object);
    open_oif_query(object);
exit:
    return;
}

void destroy_policy_info(amxd_object_t* object) {
    routing_policy_t* policy = NULL;

    when_null(object, exit);
    when_null(object->priv, exit);

    policy = object->priv;

    free(policy->iif);
    if(policy->iif_query != NULL) {
        netmodel_closeQuery(policy->iif_query);
    }
    free(policy->oif);
    if(policy->oif_query != NULL) {
        netmodel_closeQuery(policy->oif_query);
    }
    amxc_var_delete(&policy->last_set_args);
    free(policy);

    object->priv = NULL;
exit:
    return;
}

static const cstring_t status_to_str(policy_status_t status) {
    const cstring_t ret = "Error";
    switch(status) {
    case STATUS_ENABLED:
        ret = "Enabled";
        break;
    case STATUS_DISABLED:
        ret = "Disabled";
        break;
    default:
        ret = "Error";
        break;
    }
    return ret;
}

void policy_set_status(amxd_object_t* object, policy_status_t status) {
    amxd_trans_t trans;
    amxd_status_t rv = amxd_status_unknown_error;
    amxd_trans_init(&trans);

    when_null(object, exit);
    amxd_trans_select_object(&trans, object);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_value(cstring_t, &trans, "Status", status_to_str(status));
    rv = amxd_trans_apply(&trans, routing_manager_get_dm());
    when_failed_trace(rv, exit, ERROR, "Failed to apply transaction with status code %u", rv);

exit:
    amxd_trans_clean(&trans);
}

