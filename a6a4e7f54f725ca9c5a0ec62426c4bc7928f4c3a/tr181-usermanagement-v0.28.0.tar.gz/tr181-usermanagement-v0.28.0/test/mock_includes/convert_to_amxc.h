/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __CONVERT_TO_AMXC_H__
#define __CONVERT_TO_AMXC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>

typedef struct _group_dm_object_t {
    uint32_t m_index;
    const char* m_alias;
    bool m_enable;
    uint32_t m_group_id;
    const char* m_group_name;
    const char* m_role_participation;
    bool m_static_group;
} group_dm_object_t;

typedef struct _user_dm_object_t {
    uint32_t m_index;
    const char* m_alias;
    bool m_enable;
    uint32_t m_user_id;
    const char* m_username;
    char* m_password;
    char* m_hashed_password;
    const char* m_group_participation;
    const char* m_role_participation;
    bool m_static_user;
    const char* m_language;
    const char* m_homedir;
    const char* m_shell;
} user_dm_object_t;

typedef struct _shell_dm_object_t {
    const char* m_alias;
    const uint32_t m_index;
    const char* m_name;
    bool m_enable;
} shell_dm_object_t;

typedef struct _role_dm_object_t {
    uint32_t m_index;
    const char* m_alias;
    bool m_enable;
    uint32_t m_role_id;
    const char* m_role_name;
    const char* m_required_capabilities;
    bool m_static_role;
} role_dm_object_t;

void fill_group_parameters(amxc_var_t* const p_to_fill, const group_dm_object_t* p_group, bool enable_id);
amxc_var_t* convert_group_to_amxc_var(const group_dm_object_t*, bool enable_id);
amxc_var_t* convert_group_to_amxc_var_edit_string(const group_dm_object_t* p_user, const char*, const char* before, const char*);

void fill_user_parameters(amxc_var_t* const p_to_fill, const user_dm_object_t* p_user);
amxc_var_t* convert_user_to_amxc_var(const user_dm_object_t*);
amxc_var_t* convert_user_to_amxc_var_edit_string(const user_dm_object_t*, const char*, const char*, const char*);

void fill_shell_parameters(amxc_var_t* const to_fill, const shell_dm_object_t* p_shell);

void fill_role_parameters(amxc_var_t* const p_to_fill, const role_dm_object_t* p_role, bool enable_id);

#ifdef __cplusplus
}
#endif

#endif // __CONVERT_TO_AMXC_H__
