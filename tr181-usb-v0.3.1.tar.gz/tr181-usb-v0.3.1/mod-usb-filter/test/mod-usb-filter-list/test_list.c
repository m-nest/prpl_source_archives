#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>

#include "test_list.h"

#include "device.h"
#include "mod_usb_filter.h"
#include "filter_dm.h"
#include "helpers.h"
#include "device_list.h"

int test_setup(void** state) {
    amxd_object_t* root = NULL;
    amxd_trans_t trans;

    amxut_bus_setup(state);

    amxd_trans_init(&trans);

    root = amxd_dm_get_root(amxut_bus_dm());
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_filter_enable_changed", AMXO_FUNC(_usb_filter_enable_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_added", AMXO_FUNC(_usb_device_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_changed", AMXO_FUNC(_usb_device_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_removed", AMXO_FUNC(_usb_device_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_added", AMXO_FUNC(_usb_device_interface_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_changed", AMXO_FUNC(_usb_device_interface_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_device_interface_removed", AMXO_FUNC(_usb_device_interface_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_added", AMXO_FUNC(_usb_allowed_device_added)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_changed", AMXO_FUNC(_usb_allowed_device_changed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "usb_allowed_device_removed", AMXO_FUNC(_usb_allowed_device_removed)), 0);
    assert_int_equal(amxo_resolver_ftab_add(amxut_bus_parser(), "filter_app_start", AMXO_FUNC(_filter_app_start)), 0);
    assert_int_equal(amxo_resolver_import_open(amxut_bus_parser(), "/usr/lib/amx/modules/mod-dmext.so", "mod-dmext", 0), 0);

    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../../odl/tr181-usb_definition.odl", root), 0);
    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../odl/mod-usb-filter_definition.odl", root), 0);
    assert_int_equal(amxo_parser_parse_file(amxut_bus_parser(), "../../../odl/defaults.d/00_tr181-usb_default.odl", root), 0);
    assert_int_equal(amxo_parser_parse_string(amxut_bus_parser(), "\%populate { on event \"app:start\" call filter_app_start;}", amxd_dm_get_root(amxut_bus_dm())), 0);

    assert_int_equal(_filter_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxp_sigmngr_emit_signal(&(amxut_bus_dm()->sigmngr), "app:start", NULL);

    amxut_bus_handle_events();

    // Add first host
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.");
    amxd_trans_add_inst(&trans, 0, "usb-Host-1");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_filter_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);

    return 0;
}

void test_add_device(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_device_entry = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", "00");
    amxd_trans_set_value(cstring_t, &trans, "DeviceProtocol", "00");
    amxd_trans_set_value(cstring_t, &trans, "DeviceSubClass", "00");
    amxd_trans_set_value(uint32_t, &trans, "ProductID", 2049);
    amxd_trans_set_value(uint32_t, &trans, "VendorID", 11388);
    amxd_trans_set_value(cstring_t, &trans, "SysfsId", "2-1.4");
    amxd_trans_select_pathf(&trans, ".Configuration.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_select_pathf(&trans, ".Interface.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceClass", "ff");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceNumber", "0");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceProtocol", "30");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceSubClass", "ff");
    amxd_trans_select_pathf(&trans, ".^.");
    amxd_trans_add_inst(&trans, 0, NULL);
    amxd_trans_set_value(cstring_t, &trans, "InterfaceClass", "00");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceNumber", "1");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceProtocol", "20");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceSubClass", "00");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_string_equal(usb_device_entry->device->product_id, "801");
    assert_string_equal(usb_device_entry->device->vendor_id, "2C7C");
    assert_int_equal(usb_device_entry->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device_entry->device), 2);
}

void test_change_intf(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_device_entry = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.1.Configuration.1.Interface.1.");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceProtocol", "03");
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.1.Configuration.1.Interface.2.");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceClass", "1f");
    amxd_trans_set_value(cstring_t, &trans, "InterfaceSubClass", "f1");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_int_equal(usb_device_entry->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device_entry->device), 2);
}

void test_remove_intf(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_device_entry = NULL;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.1.Configuration.1.Interface.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 0);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_device_entry = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device_entry);
    assert_int_equal(usb_device_entry->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device_entry->device), 1);
}

void test_add_allowed_device(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_allowed_device_test1 = NULL;
    usb_device_list_entry_t* usb_allowed_device_test2 = NULL;
    usb_device_list_entry_t* usb_device = NULL;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.");
    amxd_trans_add_inst(&trans, 0, "test1");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", "FF");
    amxd_trans_set_value(cstring_t, &trans, "DeviceProtocol", "F*");
    amxd_trans_set_value(cstring_t, &trans, "DeviceSubClass", "");
    amxd_trans_set_value(cstring_t, &trans, "ProductID", "55");
    amxd_trans_set_value(cstring_t, &trans, "VendorID", "*");

    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.");
    amxd_trans_add_inst(&trans, 0, "test2");
    amxd_trans_set_value(bool, &trans, "Enable", true);
    amxd_trans_set_value(cstring_t, &trans, "DeviceClass", "*0");
    amxd_trans_set_value(cstring_t, &trans, "DeviceProtocol", "*");
    amxd_trans_set_value(cstring_t, &trans, "DeviceSubClass", "00");
    amxd_trans_set_value(cstring_t, &trans, "ProductID", "801");
    amxd_trans_set_value(cstring_t, &trans, "VendorID", "2C7C");
    amxd_trans_set_value(cstring_t, &trans, "Interfaces", "*:*:*0");

    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 2);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_allowed_device_test1 = usb_device_list_find(ALLOWED_DEVICE, "test1");
    assert_non_null(usb_allowed_device_test1);
    assert_int_equal(usb_interface_list_size(usb_allowed_device_test1->device), 0);

    usb_allowed_device_test2 = usb_device_list_find(ALLOWED_DEVICE, "test2");
    assert_non_null(usb_allowed_device_test2);
    assert_int_equal(usb_interface_list_size(usb_allowed_device_test2->device), 1);

    usb_device = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device);
    assert_int_equal(usb_device->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device->device), 1);
}

void test_change_allowed_device(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_allowed_device_test1 = NULL;
    usb_device_list_entry_t* usb_allowed_device_test2 = NULL;
    usb_device_list_entry_t* usb_device = NULL;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.2");
    amxd_trans_set_value(bool, &trans, "Enable", false);
    amxd_trans_set_value(cstring_t, &trans, "Interfaces", "45:CD:BD,44:CD:BD");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 2);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_allowed_device_test1 = usb_device_list_find(ALLOWED_DEVICE, "test1");
    assert_non_null(usb_allowed_device_test1);
    assert_int_equal(usb_interface_list_size(usb_allowed_device_test1->device), 0);

    usb_allowed_device_test2 = usb_device_list_find(ALLOWED_DEVICE, "test2");
    assert_non_null(usb_allowed_device_test2);
    assert_int_equal(usb_interface_list_size(usb_allowed_device_test2->device), 2);

    usb_device = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device);
    assert_int_equal(usb_device->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device->device), 1);
}

void test_remove_allowed_device(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_allowed_device_test2 = NULL;
    usb_device_list_entry_t* usb_device = NULL;

    amxd_trans_init(&trans);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.AllowedDevice.");
    amxd_trans_del_inst(&trans, 0, "test1");
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();
    assert_int_equal(usb_device_list_size(ALLOWED_DEVICE), 1);
    assert_int_equal(usb_device_list_size(DEVICE), 1);

    usb_allowed_device_test2 = usb_device_list_find(ALLOWED_DEVICE, "test2");
    assert_non_null(usb_allowed_device_test2);
    assert_int_equal(usb_interface_list_size(usb_allowed_device_test2->device), 2);

    usb_device = usb_device_list_find(DEVICE, "2-1.4");
    assert_non_null(usb_device);
    assert_int_equal(usb_device->device->authorized, 1);
    assert_int_equal(usb_interface_list_size(usb_device->device), 1);
}

void test_remove_device(UNUSED void** state) {
    amxd_trans_t trans;
    usb_device_list_entry_t* usb_device = NULL;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.USBHosts.Host.1.Device.");
    amxd_trans_del_inst(&trans, 1, NULL);
    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);
    amxd_trans_clean(&trans);
    amxut_bus_handle_events();

    usb_device = usb_device_list_find(DEVICE, "2-1.4");
    assert_null(usb_device);
}
