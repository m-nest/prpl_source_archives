/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <debug/sahtrace.h>

#include <dmengine/DM_ENG_RPC.h>
#include <dmxmlparser/ixml.h>
#include <dmcom/dm_com.h>
#include <dmengine/DM_ENG_InformMessageScheduler.h>

#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_sahtrace.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_util.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <yajl/yajl_gen.h>
#include <amxj/amxj_variant.h>

#include <dmengine/DM_ENG_Device.h>
#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/debugXML.h>

#include "test_gpv.h"
#include "../common/common.h"

#define HASH_LEN 65

extern device_adapter_t* device_adapter;

int test_setup(UNUSED void** state) {
    sahTraceSetLevel(200);
    sahTraceAddZone(200, "CWMPD");
    sahTraceOpen("TEST", TRACE_TYPE_STDOUT);
    LIBXML_TEST_VERSION
    return 0;
}

int test_teardown(UNUSED void** state) {
    xmlCleanupParser();
    sahTraceClose();
    return 0;
}

int FAKE_DM_ENG_Device_GPV(char* parameterNames[], dm_eng_pvs_list_t* pvs_list);
int FAKE_DM_ENG_Device_GPV(char* parameterNames[], dm_eng_pvs_list_t* pvs_list) {
    dm_eng_pvs_t* pvs = NULL;
    struct {
        const char* name;
        unsigned int type;
        const char* value;
    } result[] = {
        {"Device.TypeCheck.P_b", dm_eng_data_type_boolean, "true"},
        {"Device.TypeCheck.P_d", dm_eng_data_type_datetime, "0001-01-01T00:00:00Z"},
        {"Device.TypeCheck.P_i16", dm_eng_data_type_int, "-16"},
        {"Device.TypeCheck.P_i32", dm_eng_data_type_int, "-32"},
        {"Device.TypeCheck.P_i64", dm_eng_data_type_int, "-64"},
        {"Device.TypeCheck.P_i8", dm_eng_data_type_int, "-8"},
        {"Device.TypeCheck.P_s", dm_eng_data_type_string, "string"},
        {"Device.TypeCheck.P_s_csv", dm_eng_data_type_string, "csv,string"},
        {"Device.TypeCheck.P_s_ssv", dm_eng_data_type_string, "ssv string"},
        {"Device.TypeCheck.P_ui16", dm_eng_data_type_unsigned_int, "16"},
        {"Device.TypeCheck.P_ui32", dm_eng_data_type_unsigned_int, "32"},
        {"Device.TypeCheck.P_ui64", dm_eng_data_type_unsigned_int, "64"},
        {"Device.TypeCheck.P_ui8", dm_eng_data_type_unsigned_int, "8"},
        {"Device.Time.Status", dm_eng_data_type_string, "Synchronized"},
        {"Device.Bridging.Bridge.1.Port.1.LowerLayers", dm_eng_data_type_string, "Device.Bridging.Bridge.1.Port.2,Device.Bridging.Bridge.1.Port.3"},
        {"Device.Bridging.Bridge.1.Port.1.Stats.BytesReceived", dm_eng_data_type_unsigned_int, "3704849"},
        {"Device.Bridging.Bridge.1.Port.1.Stats.BytesSent", dm_eng_data_type_unsigned_int, "156363898"},
        {"Device.Bridging.Bridge.1.Port.2.LowerLayers", dm_eng_data_type_string, "Device.Ethernet.Interface.2"},
        {"Device.Bridging.Bridge.1.Port.2.Stats.BytesReceived", dm_eng_data_type_unsigned_int, "1993381"},
        {"Device.Bridging.Bridge.1.Port.2.Stats.BytesSent", dm_eng_data_type_unsigned_int, "164344324"},
        {"Device.Bridging.Bridge.1.Port.3.LowerLayers", dm_eng_data_type_string, "Device.Ethernet.Interface.3"},
        {"Device.Bridging.Bridge.1.Port.3.Stats.BytesReceived", dm_eng_data_type_unsigned_int, "1991638"},
        {"Device.Bridging.Bridge.1.Port.3.Stats.BytesSent", dm_eng_data_type_unsigned_int, "164345241"},
        {NULL, 0, NULL}
    };

    assert_string_equal(parameterNames[0], "Device.TypeCheck.");
    assert_string_equal(parameterNames[1], "Device.Time.Status");
    assert_string_equal(parameterNames[2], "Device.Bridging.Bridge.1.Port.*.LowerLayers");
    assert_string_equal(parameterNames[3], "Device.Bridging.Bridge.1.Port.*.Stats.BytesReceived");
    assert_string_equal(parameterNames[4], "Device.Bridging.Bridge.1.Port.*.Stats.BytesSent");
    assert_null(parameterNames[5]);


    size_t i = 0;
    while(result[i].name) {
        pvs = dm_eng_pvs_list_get(pvs_list, result[i].name);
        if(!pvs) {
            pvs = dm_eng_pvs_pvs_new(result[i].name, result[i].type, result[i].value);
            dm_eng_pvs_list_add(pvs_list, pvs);
        }
        i++;
    }
    return 0;
}

static void expect_and_return_FAKE_DM_ENG_Device_GetConfigValue(const char* value, DM_ENG_SystemParameter_t parameter) {
    char* servervalue = strdup(value);
    expect_value(FAKE_DM_ENG_Device_GetConfigValue, parameter, parameter);
    will_return(FAKE_DM_ENG_Device_GetConfigValue, servervalue);
}

int FAKE_DM_ENG_Device_GetConfigValue(DM_ENG_SystemParameter_t parameter, char** pResult);
int FAKE_DM_ENG_Device_GetConfigValue(DM_ENG_SystemParameter_t parameter, char** pResult) {
    check_expected(parameter);
    *pResult = mock_ptr_type(char*);
    return 0;
}

int FAKE_DM_ENG_Device_SetConfigValue(DM_ENG_SystemParameter_t parameter, const char* pValue);
int FAKE_DM_ENG_Device_SetConfigValue(UNUSED DM_ENG_SystemParameter_t parameter, UNUSED const char* pValue) {
    return 0;
}

void test_gpv(UNUSED void** state) {
    int retval = 0;
    device_adapter_t da;
    device_adapter = &da;
    device_adapter->DM_ENG_Device_GetConfigValue = FAKE_DM_ENG_Device_GetConfigValue;
    device_adapter->DM_ENG_Device_GPV = FAKE_DM_ENG_Device_GPV;
    device_adapter->DM_ENG_Device_SetConfigValue = FAKE_DM_ENG_Device_SetConfigValue;

    const char* parameter_name[] = {
        "Device.TypeCheck.",
        "Device.Time.Status",
        "Device.Bridging.Bridge.1.Port.*.LowerLayers",
        "Device.Bridging.Bridge.1.Port.*.Stats.BytesReceived",
        "Device.Bridging.Bridge.1.Port.*.Stats.BytesSent",
        NULL,
    };

    expect_and_return_FAKE_DM_ENG_Device_GetConfigValue("21", DM_ENG_GETPARAMETERVALUEREQUESTS);

    unlink("/tmp/message_sent.xml");
    retval = DM_SUB_GetParameterValues("Just-A-Test", parameter_name);
    assert_int_equal(retval, 0);
    assert_int_equal(compare_files_sha256("/tmp/message_sent.xml", "./files/message_sent.xml"), 0);
    DM_COM_STOP();
    assert_int_equal(retval, 0);
}
