#!/bin/sh

event2usb $(env)
