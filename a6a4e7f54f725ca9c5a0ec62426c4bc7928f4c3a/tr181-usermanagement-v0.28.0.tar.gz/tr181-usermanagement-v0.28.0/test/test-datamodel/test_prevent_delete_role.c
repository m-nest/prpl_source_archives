/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "test_datamodel.h"
#include "test_environment.h"
#include "dm_usermanagement.h"

#include <stdio.h>

#include <amxd/amxd_transaction.h>


static void set_object_param_cstring(const char* obj_path, const char* param, const char* value) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    assert_int_equal(amxd_trans_select_pathf(&trans, obj_path), amxd_status_ok);
    assert_int_equal(amxd_trans_set_cstring_t(&trans, param, value), amxd_status_ok);
    assert_int_equal(amxd_trans_apply(&trans, get_test_datamodel()), amxd_status_ok);
    amxd_trans_clean(&trans);
}

static amxd_status_t remove_instance(const char* tmpl_path, int idx, const char* name) {
    amxd_status_t rv = amxd_status_unknown_error;
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    assert_int_equal(amxd_trans_select_pathf(&trans, tmpl_path), amxd_status_ok);
    assert_int_equal(amxd_trans_del_inst(&trans, idx, name), amxd_status_ok);
    rv = amxd_trans_apply(&trans, get_test_datamodel());
    amxd_trans_clean(&trans);
    return rv;
}

void test_check_prevent_delete_role(UNUSED void** state) {
    setup_default_dm(get_test_datamodel());

    // deleting of in use role is blocked
    assert_int_equal(remove_instance("Users.Role.", 10, DEFAULT_ROLE_ALIAS), amxd_status_invalid_action);

    // allow deleting if role is no longer in use
    set_object_param_cstring("SoftwareModules.ExecutionUnit.test.", "RequiredUserRoles", "");
    assert_int_equal(remove_instance("Users.Role.", 10, DEFAULT_ROLE_ALIAS), amxd_status_ok);
}
