# libtr69-engine

## Installation

You can build and install libtr69-engine
```
make && sudo make install
```
