/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
** SPDX-FileCopyrightText: Copyright (c) 2025 Consult Red
** This code is subject to the terms of the BSD+Patent license.
** See LICENSE file for more details.
**
****************************************************************************/

#if !defined(__DM_FUNCTIONS_H__)
#define __DM_FUNCTIONS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define CERTIFICATE_URI_OUTPUT "CertificateURI"
#define PRIVATE_KEY_URI_OUTPUT "PrivateKeyURI"
#define CERTIFICATE_URI_FIELD "CertificateURI"
#define PRIVATE_KEY_URI_FIELD "PrivateKeyURI"

amxd_status_t _GetCertificateURI(UNUSED amxd_object_t* object, UNUSED amxd_function_t* func, amxc_var_t* args, UNUSED amxc_var_t* ret);
amxd_status_t _CADir(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);
amxd_status_t _CAFile(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);

#ifdef __cplusplus
}
#endif

#endif // __DM_FUNCTIONS_H__