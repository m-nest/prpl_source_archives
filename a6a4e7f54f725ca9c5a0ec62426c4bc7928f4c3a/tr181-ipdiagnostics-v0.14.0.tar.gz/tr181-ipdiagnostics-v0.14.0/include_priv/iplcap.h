/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek Technology Co., Ltd.
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__IP_DIAGNOSTICS_IPLCAP_H__)
#define __IP_DIAGNOSTICS_IPLCAP_H__

#ifdef __cplusplus
extern "C"
{
#endif

//functions
#define IPD_IPLCAP_TEST_START "start-iplcap"
#define IPD_IPLCAP_TEST_CHECK "check-iplcap"
#define IPD_IPLCAP_TEST_STOP  "stop-iplcap"
#define IPD_IPLCAP_TEST_ABORT "abort-iplcap"

//Process object
#define IPLCAP_RET_KEY_PROC                "Process"
#define IPLCAP_RET_KEY_PROC_PID            "ID"
#define IPLCAP_RET_KEY_PROC_FD_STDOUT      "FDStdOut"
#define IPLCAP_RET_KEY_PROC_FD_STDERR      "FDStdErr"

// Protected parameters
#define IPLCAP_RET_KEY_CMD                  "Command"
#define IPLCAP_RET_KEY_CTRL                 "Controller"

// Basic configuration parameters
#define IPLCAP_RET_KEY_DST                 "DiagnosticsState"
#define IPLCAP_RET_KEY_STATUS              "Status"
#define IPLCAP_RET_KEY_MAX_CONN            "IPLayerMaxConnections"
#define IPLCAP_RET_KEY_MAX_INC_RES         "IPLayerMaxIncrementalResult"
#define IPLCAP_RET_KEY_SUPP_SW_VER         "IPLayerCapSupportedSoftwareVersion"
#define IPLCAP_RET_KEY_SUPP_CTRL_VER       "IPLayerCapSupportedControlProtocolVersion"
#define IPLCAP_RET_KEY_SUPP_METRICS        "IPLayerCapSupportedMetrics"
#define IPLCAP_RET_KEY_AUTH_CODE_ENTRIES   "IPLayerCapacityAuthCodeNumberOfEntries"

// Connection parameters
#define IPLCAP_RET_KEY_INTF                "Interface"
#define IPLCAP_RET_KEY_ROLE                "Role"
#define IPLCAP_RET_KEY_SERVER_LIST         "ServerList"
#define IPLCAP_RET_KEY_JUMBO_FRAMES        "JumboFramesPermitted"
#define IPLCAP_RET_KEY_MTU                 "MTU"
#define IPLCAP_RET_KEY_LOCAL_RATE          "LocalInterfaceRateIncluded"

// Authentication parameters
#define IPLCAP_RET_KEY_AUTH_ENABLED        "AuthenticationEnabled"
#define IPLCAP_RET_KEY_AUTH_CODE           "AuthenticationCode"
#define IPLCAP_RET_KEY_AUTH_ALIAS          "AuthenticationAlias"
#define IPLCAP_RET_KEY_AUTH_KEY_FILE       "AuthenticationKeyFileLocation"

// Flow control parameters
#define IPLCAP_RET_KEY_FLOW_COUNT          "FlowCount"
#define IPLCAP_RET_KEY_MAX_FLOWS           "MaximumFlows"

// Network parameters
#define IPLCAP_RET_KEY_ETH_PRIORITY        "EthernetPriority"
#define IPLCAP_RET_KEY_DSCP                "DSCP"
#define IPLCAP_RET_KEY_PRTCLV              "ProtocolVersion"

// UDP configuration
#define IPLCAP_RET_KEY_UDP_PAYLOAD_MIN     "UDPPayloadMin"
#define IPLCAP_RET_KEY_UDP_PAYLOAD_MAX     "UDPPayloadMax"
#define IPLCAP_RET_KEY_UDP_PAYLOAD_CONTENT "UDPPayloadContent"

// Port configuration
#define IPLCAP_RET_KEY_PORT_MIN            "PortMin"
#define IPLCAP_RET_KEY_PORT_MAX            "PortMax"
#define IPLCAP_RET_KEY_PORT_OPT_MIN        "PortOptionalMin"
#define IPLCAP_RET_KEY_PORT_OPT_MAX        "PortOptionalMax"

// Test configuration
#define IPLCAP_RET_KEY_TEST_TYPE           "TestType"
#define IPLCAP_RET_KEY_IPDV_ENABLE         "IPDVEnable"
#define IPLCAP_RET_KEY_IPRR_ENABLE         "IPRREnable"
#define IPLCAP_RET_KEY_RIPR_ENABLE         "RIPREnable"
#define IPLCAP_RET_KEY_PREAMBLE_DUR        "PreambleDuration"
#define IPLCAP_RET_KEY_MAX_BANDWIDTH       "MaximumTestBandwidth"
#define IPLCAP_RET_KEY_START_RATE          "StartSendingRate"
#define IPLCAP_RET_KEY_START_RATE_INDEX    "StartSendingRateIndex"
#define IPLCAP_RET_KEY_NUM_SUB_INTERVALS   "NumberTestSubIntervals"
#define IPLCAP_RET_KEY_NUM_FIRST_MODE      "NumberFirstModeTestSubIntervals"
#define IPLCAP_RET_KEY_SUB_INTERVAL        "TestSubInterval"
#define IPLCAP_RET_KEY_FEEDBACK_INTERVAL   "StatusFeedbackInterval"

// Timeout and timing parameters
#define IPLCAP_RET_KEY_TIMEOUT_NO_TEST_TRAFFIC     "TimeoutNoTestTraffic"
#define IPLCAP_RET_KEY_TIMEOUT_NO_STATUS_MESSAGE   "TimeoutNoStatusMessage"
#define IPLCAP_RET_KEY_TMAX                        "Tmax"
#define IPLCAP_RET_KEY_TMAX_RTT                    "TmaxRTT"
#define IPLCAP_RET_KEY_TIMESTAMP_RES               "TimestampResolution"

// Test thresholds and algorithms
#define IPLCAP_RET_KEY_SEQ_ERR_THRESH      "SeqErrThresh"
#define IPLCAP_RET_KEY_REORD_DUP_IGNORE    "ReordDupIgnoreEnable"
#define IPLCAP_RET_KEY_LOWER_THRESH        "LowerThresh"
#define IPLCAP_RET_KEY_UPPER_THRESH        "UpperThresh"
#define IPLCAP_RET_KEY_RETRY_THRESH        "RetryThresh"
#define IPLCAP_RET_KEY_HIGH_SPEED_DELTA    "HighSpeedDelta"
#define IPLCAP_RET_KEY_RATE_ADJ_ALGO       "RateAdjAlgorithm"
#define IPLCAP_RET_KEY_SLOW_ADJ_THRESH     "SlowAdjThresh"
#define IPLCAP_RET_KEY_HSPEED_THRESH       "HSpeedThresh"

// Test results
#define IPLCAP_RET_KEY_STATUS_CODE         "StatusCode"
#define IPLCAP_RET_KEY_INC_RES_ENTRIES     "IncrementalResultNumberOfEntries"
#define IPLCAP_RET_KEY_MODAL_RES_ENTRIES   "ModalResultNumberOfEntries"
#define IPLCAP_RET_KEY_STATUS_MSG          "StatusMessage"
#define IPLCAP_RET_KEY_BOM_TIME            "BOMTime"
#define IPLCAP_RET_KEY_EOM_TIME            "EOMTime"
#define IPLCAP_RET_KEY_TMAX_USED           "TmaxUsed"
#define IPLCAP_RET_KEY_TEST_INTERVAL       "TestInterval"
#define IPLCAP_RET_KEY_ACTIVE_FLOWS        "ActiveFlows"

// Maximum capacity results
#define IPLCAP_RET_KEY_MAX_IP_CAP          "MaxIPLayerCapacity"
#define IPLCAP_RET_KEY_TIME_OF_MAX         "TimeOfMax"
#define IPLCAP_RET_KEY_MAX_ETH_NO_FCS      "MaxETHCapacityNoFCS"
#define IPLCAP_RET_KEY_MAX_ETH_WITH_FCS    "MaxETHCapacityWithFCS"
#define IPLCAP_RET_KEY_MAX_ETH_WITH_VLAN   "MaxETHCapacityWithFCSVLAN"
#define IPLCAP_RET_KEY_LOSS_RATIO_MAX      "LossRatioAtMax"
#define IPLCAP_RET_KEY_RTT_RANGE_MAX       "RTTRangeAtMax"
#define IPLCAP_RET_KEY_PDV_RANGE_MAX       "PDVRangeAtMax"
#define IPLCAP_RET_KEY_MIN_OWD_MAX         "MinOnewayDelayAtMax"
#define IPLCAP_RET_KEY_REORD_RATIO_MAX     "ReorderedRatioAtMax"
#define IPLCAP_RET_KEY_REPL_RATIO_MAX      "ReplicatedRatioAtMax"
#define IPLCAP_RET_KEY_RTT_MIN_MAX         "RTTMinAtMax"
#define IPLCAP_RET_KEY_RTT_MAX_MAX         "RTTMaxAtMax"
#define IPLCAP_RET_KEY_ETH_MBPS_MAX        "InterfaceEthMbpsAtMax"

// Summary results
#define IPLCAP_RET_KEY_IP_CAP_SUMMARY      "IPLayerCapacitySummary"
#define IPLCAP_RET_KEY_LOSS_RATIO_SUM      "LossRatioSummary"
#define IPLCAP_RET_KEY_RTT_RANGE_SUM       "RTTRangeSummary"
#define IPLCAP_RET_KEY_PDV_RANGE_SUM       "PDVRangeSummary"
#define IPLCAP_RET_KEY_MIN_OWD_SUM         "MinOnewayDelaySummary"
#define IPLCAP_RET_KEY_MIN_RTT_SUM         "MinRTTSummary"
#define IPLCAP_RET_KEY_REORD_RATIO_SUM     "ReorderedRatioSummary"
#define IPLCAP_RET_KEY_REPL_RATIO_SUM      "ReplicatedRatioSummary"
#define IPLCAP_RET_KEY_ETH_MBPS_SUM        "InterfaceEthMbpsSummary"

// Used parameters
#define IPLCAP_RET_KEY_TMAX_RTT_USED       "TmaxRTTUsed"
#define IPLCAP_RET_KEY_TS_RES_USED         "TimestampResolutionUsed"

// Auth code table parameters
#define IPLCAP_RET_KEY_AUTH_CODE_OBJECT    "IPLayerCapacityAuthCode"
#define IPLCAP_RET_KEY_AUTH_CODE_ALIAS     "Alias"
#define IPLCAP_RET_KEY_AUTH_KEY            "AuthenticationKey"

// Modal result table parameters
#define IPLCAP_RET_KEY_MODAL                    "ModalResult"
#define IPLCAP_RET_KEY_MODAL_MAX_IP_CAP         "MaxIPLayerCapacity"
#define IPLCAP_RET_KEY_MODAL_TIME_MAX           "TimeOfMax"
#define IPLCAP_RET_KEY_MODAL_MAX_ETH_NO_FCS     "MaxETHCapacityNoFCS"
#define IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_FCS   "MaxETHCapacityWithFCS"
#define IPLCAP_RET_KEY_MODAL_MAX_ETH_WITH_VLAN  "MaxETHCapacityWithFCSVLAN"
#define IPLCAP_RET_KEY_MODAL_LOSS_RATIO         "LossRatioAtMax"
#define IPLCAP_RET_KEY_MODAL_RTT_RANGE          "RTTRangeAtMax"
#define IPLCAP_RET_KEY_MODAL_PDV_RANGE          "PDVRangeAtMax"
#define IPLCAP_RET_KEY_MODAL_MIN_OWD            "MinOnewayDelayAtMax"
#define IPLCAP_RET_KEY_MODAL_REORD_RATIO        "ReorderedRatioAtMax"
#define IPLCAP_RET_KEY_MODAL_REPL_RATIO         "ReplicatedRatioAtMax"
#define IPLCAP_RET_KEY_MODAL_ETH_MBPS           "InterfaceEthMbpsAtMax"

// Incremental result
#define IPLCAP_RET_KEY_INC                 "IncrementalResult"
#define IPLCAP_RET_KEY_INC_IP_CAP          "IPLayerCapacity"
#define IPLCAP_RET_KEY_INC_TIME            "TimeOfSubInterval"
#define IPLCAP_RET_KEY_INC_LOSS_RATIO      "LossRatio"
#define IPLCAP_RET_KEY_INC_RTT_RANGE       "RTTRange"
#define IPLCAP_RET_KEY_INC_PDV_RANGE       "PDVRange"
#define IPLCAP_RET_KEY_INC_MIN_OWD         "MinOnewayDelay"
#define IPLCAP_RET_KEY_INC_REORD_RATIO     "ReorderedRatio"
#define IPLCAP_RET_KEY_INC_REPL_RATIO      "ReplicatedRatio"
#define IPLCAP_RET_KEY_INC_ETH_MBPS        "InterfaceEthMbps"

// Status defines
#define IPLCAP_STATUS_NONE             "None"
#define IPLCAP_STATUS_COMPLETE         "Complete"
#define IPLCAP_STATUS_REQUESTED        "Requested"
#define IPLCAP_STATUS_CANCELED         "Canceled"
#define IPLCAP_STATUS_ERROR            "Error"
#define IPLCAP_STATUS_ERR_HOST_NAME    "Error_CannotResolveHostName"
#define IPLCAP_STATUS_ERR_ROUTE        "Error_NoRouteToHost"
#define IPLCAP_STATUS_ERR_INIT_CONN    "Error_InitConnectionFailed"
#define IPLCAP_STATUS_ERR_NO_RESP      "Error_NoResponse"
#define IPLCAP_STATUS_ERR_PWD_REQ      "Error_PasswordRequestFailed"
#define IPLCAP_STATUS_ERR_LOGIN        "Error_LoginFailed"
#define IPLCAP_STATUS_ERR_REJECTED     "Error_RejectedByRemote"
#define IPLCAP_STATUS_ERR_SIZE         "Error_IncorrectSize"
#define IPLCAP_STATUS_ERR_TIMEOUT      "Error_Timeout"
#define IPLCAP_STATUS_ERR_INTERNAL     "Error_Internal"
#define IPLCAP_STATUS_ERR_OTHER        "Error_Other"
#define IPLCAP_STATUS_NOT_COMPLETE     "Not_Complete"

typedef enum _iplcap_test_status_ {
    iplcap_test_none,
    iplcap_test_error_complete,
    iplcap_test_error_requested,
    iplcap_test_error_canceled,
    iplcap_test_error_error,
    // Enhanced error statuses matching TR-181 specification
    iplcap_test_error_err_cannot_resolve_host_name,    // Error_CannotResolveHostName
    iplcap_test_error_err_no_route_to_host,            // Error_NoRouteToHost
    iplcap_test_error_err_init_connection_failed,      // Error_InitConnectionFailed
    iplcap_test_error_err_no_response,                 // Error_NoResponse
    iplcap_test_error_err_password_request_failed,     // Error_PasswordRequestFailed
    iplcap_test_error_err_login_failed,                // Error_LoginFailed
    iplcap_test_error_err_rejected_by_remote,          // Error_RejectedByRemote
    iplcap_test_error_err_incorrect_size,              // Error_IncorrectSize
    iplcap_test_error_err_timeout,                     // Error_Timeout
    iplcap_test_error_err_internal,                    // Error_Internal
    iplcap_test_error_err_other,                       // Error_Other
    iplcap_test_not_complete,
    iplcap_test_num_of_status
} iplcap_test_status_t;

#ifdef __cplusplus
}
#endif

#endif // __IP_DIAGNOSTICS_IPLCAP_H__