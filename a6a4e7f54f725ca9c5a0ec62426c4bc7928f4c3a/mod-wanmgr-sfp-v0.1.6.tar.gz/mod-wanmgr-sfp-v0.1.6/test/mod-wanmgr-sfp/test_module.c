/**
 * @file test_module.c
 *
 * @brief This file contains unit test of network selector
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>
#include <signal.h>

#include <amxc/amxc.h>
#include <amxrt/amxrt.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_types.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_action.h>

#include <amxb/amxb.h>
#include <amxb/amxb_be_mngr.h>
#include <amxb/amxb_register.h>
#include <amxb/amxb_connect.h>

#include "test_module.h"
#include "mod_wanmgr_sfp.h"

static amxd_dm_t dm;
static amxo_parser_t parser;
static amxb_bus_ctx_t* bus_ctx = NULL;
amxd_object_t* root = NULL;
int sfp_type_callback_done = 0;

amxd_dm_t* get_dm(void);
int component_set_params(const char* component, amxb_bus_ctx_t* bus, amxc_var_t* values);
int component_set_str_param(const char* component, amxb_bus_ctx_t* bus, const char* param, const char* value);
int component_get_param(amxc_var_t* ret_var, const char* component, amxb_bus_ctx_t* bus, const char* parameter);
static void handle_events(void);

/**
 * @brief Get the data management (DM) context.
 *
 * Returns a pointer to the DM context used for managing data operations.
 *
 * @return amxd_dm_t* Pointer to the DM context.
 */
amxd_dm_t* get_dm(void) {
    return &dm;
}

/**
 * @brief Handle incoming events.
 *
 * Waits for a termination signal and exits when it is received.
 */
static void handle_events(void) {
    while(amxp_signal_read() == 0) {
    }
    return;
}

/**
 * @brief Tests the behavior of the system when the SFP Type changes.
 *
 * This function:
 * - Simulates a change in the `SFPType` of the data model.
 * - Generates a data model event.
 * - Verifies that the callback is triggered through amxb-subscription.
 *
 * @param state Unused state parameter for test framework.
 */
void test_sfp_type_change(UNUSED void** state) {
    assert_int_equal(sfp_type_callback_done, 0);

    // Changing the SFPType of the data model to generate dm event
    // and checking if it's callback is received because of amxb-subscription.
    amxd_trans_t trans;
    assert_int_equal(amxd_trans_init(&trans), 0);
    amxd_trans_select_pathf(&trans, TR181_SFPCAGE_PATH);
    amxd_trans_set_value(cstring_t, &trans, "SFPType", "Electrical Ethernet");
    assert_int_equal(amxd_trans_apply(&trans, get_dm()), 0);
    amxd_trans_clean(&trans);

    handle_events();
    assert_int_not_equal(sfp_type_callback_done, 0);

}

/**
 * @brief Sets parameters for a specific component on the bus.
 *
 * This function sends a set request to a specified component on the bus
 * with the provided values and checks the result.
 *
 * @param component The name of the component to update.
 * @param bus       Pointer to the bus context for communication.
 * @param values    The parameters and their values to set.
 * @return int      Returns 0 on success, or a non-zero error code on failure.
 */
int component_set_params(const char* component, amxb_bus_ctx_t* bus, amxc_var_t* values) {
    int rc = -1;
    amxc_var_t ret;
    amxc_var_init(&ret);

    assert_non_null(bus);
    assert_non_null(values);
    assert_non_null(component);

    rc = amxb_set(bus, component, values, &ret, TIMEOUT_20);
    assert_int_equal(rc, 0);
    amxc_var_clean(&ret);
    return rc;
}

/**
 * @brief Sets a single string parameter for a specific component on the bus.
 *
 * This function creates a key-value pair for a single parameter and uses
 * `component_set_params` to apply it to the specified component.
 *
 * @param component The name of the component to update.
 * @param bus       Pointer to the bus context for communication.
 * @param param     The parameter name to set.
 * @param value     The string value to assign to the parameter.
 * @return int      Returns 0 on success, or a non-zero error code on failure.
 */
int component_set_str_param(const char* component, amxb_bus_ctx_t* bus, const char* param, const char* value) {
    int rc = -1;

    amxc_var_t parameters;
    amxc_var_init(&parameters);
    amxc_var_set_type(&parameters, AMXC_VAR_ID_HTABLE);

    assert_non_null(bus);
    assert_non_null(value);
    assert_non_null(param);
    assert_non_null(component);

    amxc_var_add_key(cstring_t, &parameters, param, value);
    rc = component_set_params(component, bus, &parameters);
    assert_int_equal(rc, 0);
    amxc_var_clean(&parameters);
    return rc;
}

/**
 * @brief Retrieves a parameter value from a specific component on the bus.
 *
 * This function constructs the parameter path using the component name and parameter name,
 * then retrieves the value using the bus context.
 *
 * @param ret_var   Pointer to the variable to store the retrieved value.
 * @param component Name of the component to query.
 * @param bus       Pointer to the bus context for communication.
 * @param parameter The specific parameter to retrieve.
 * @return int      Returns 0 on success, or a non-zero error code on failure.
 */
int component_get_param(amxc_var_t* ret_var, const char* component, amxb_bus_ctx_t* bus, const char* parameter) {
    int rc = -1;
    amxc_string_t param_path;
    amxc_string_init(&param_path, 0);

    assert_non_null(bus);
    assert_non_null(parameter);
    assert_non_null(component);
    amxc_string_setf(&param_path, "%s.%s", component, parameter);

    rc = amxb_get(bus, amxc_string_get(&param_path, 0), 0, ret_var, 5);
    assert_int_equal(rc, 0);
    amxc_string_clean(&param_path);
    return rc;
}

/**
 * @brief Callback function to update the SFP type.
 *
 * This function is invoked as part of a callback mechanism and increments
 * a counter to indicate the callback execution.
 *
 * @return int Always returns 0.
 */
static int wanmgr_update_sfp_type(UNUSED const char* function_name,
                                  UNUSED amxc_var_t* args,
                                  UNUSED amxc_var_t* ret) {
    // Increment the variable everytime, there is a callback
    sfp_type_callback_done++;
    return 0;
}

/**
 * @brief Registers a dummy core function for testing or initialization purposes.
 *
 * This function registers the "update-sfp-type" function in the dummy module.
 *
 * @return int Returns 0 on successful registration, or a non-zero error code on failure.
 */
static int register_dummy_core_functions(void) {
    amxm_shared_object_t* so = amxm_get_so("self");
    amxm_module_t* mod = NULL;
    assert_non_null(so);
    assert_int_equal(amxm_module_register(&mod, so, MOD_DM_MNGR), 0);
    assert_int_equal(amxm_module_add_function(mod, "update-sfp-type", wanmgr_update_sfp_type), 0);
    return 0;
}

/**
 * @brief Initializes the test setup environment.
 *
 * This function sets up the environment for unit tests, including initializing
 * the data model, setting up trace zones, and registering dummy functions and parsers.
 *
 * @return int Returns 0 on successful setup.
 */
int test_setup(UNUSED void** state) {
#if defined(SAHTRACES_ENABLED)
    sahTraceOpen("unittest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "mod-wanmgr-sfp");
#endif

    amxd_dm_init(&dm);
    amxo_parser_init(&parser);
    root = amxd_dm_get_root(&dm);
    assert_non_null(root);

    register_dummy_core_functions();

    system("ubusd &");
    assert_int_equal(amxb_be_load("/usr/bin/mods/amxb/mod-amxb-ubus.so"), 0);
    assert_int_equal(amxb_connect(&bus_ctx, "ubus:"), 0);
    amxb_set_access(bus_ctx, amxd_dm_access_public);
    amxb_register(bus_ctx, &dm);
    amxo_parser_parse_file(&parser, "../mocks/datamodel/remote_dm.odl", root);
    return 0;
}

/**
 * @brief Test to verify the retrieval of SFP type.
 *
 * This test checks if the "get-sfp-type" function works as expected:
 * 1. Ensures the default SFP type is "Unsupported".
 * 2. Validates the callback functionality.
 * 3. Confirms that after an update, the SFP type changes to "Optical Ethernet".
 *
 * @param state Unused parameter for testing.
 */
void test_get_sfp_type(UNUSED void** state) {
    // Reading the SFPType default value should be "Unsupported"
    int rc = 0;
    const char* sfptype = NULL;
    amxc_var_t data;
    amxc_var_t ret;

    //Initializing the varaible
    amxc_var_init(&data);
    amxc_var_init(&ret);

    assert_int_equal(sfp_type_callback_done, 0);

    // Calling the function
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_WANMGR_SFP, "get-sfp-type", &data, &ret), 0);

    // Validate the default SFP type is "Unsupported".
    sfptype = GETP_CHAR(&data, "SFPType");
    assert_non_null(sfptype);
    assert_int_equal(strncmp("Unsupported", sfptype, sizeof("Unsupported")), 0);
    assert_int_not_equal(sfp_type_callback_done, 0);

    // Update the SFP ype to "Unsupported" and validate.
    rc = component_set_str_param("SFPs.SFPCage.1.",
                                 amxb_be_who_has("SFPs."),
                                 "SFPType",
                                 "Optical Ethernet");
    assert_int_equal(rc, 0);
    handle_events();

    // Call the function again to validate the updated SFP ype.
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_WANMGR_SFP, "get-sfp-type", &data, &ret), 0);

    // Validate the updated SFP ype is "Optical Ethernet".
    sfptype = GETP_CHAR(&data, "SFPType");
    assert_non_null(sfptype);
    assert_int_equal(strncmp("Optical Ethernet", sfptype, sizeof("Optical Ethernet")), 0);

    // cleaning the variables
    amxc_var_clean(&ret);
    amxc_var_clean(&data);

    // Verify the callback count and reset it.
    assert_int_not_equal(sfp_type_callback_done, 0);
    sfp_type_callback_done = 0;
}

/**
 * @brief Test subscription to SFP ype changes.
 *
 * This test ensures that the "sfp-type-change" function can be executed
 * successfully and cleans up all variables after execution.
 *
 * @param state Unused parameter for testing.
 */
void test_subscribe_sfp_type_change(UNUSED void** state) {
    // function to test subscription
    int rc = 0;
    amxc_var_t data;
    amxc_var_t ret;

    //Initializing the varaible
    amxc_var_init(&data);
    amxc_var_init(&ret);

    rc = amxm_execute_function(MOD_NAME, MOD_WANMGR_SFP, "sfp-type-change", &data, &ret);

    // cleaning the variables
    amxc_var_clean(&ret);
    amxc_var_clean(&data);

    assert_int_equal(rc, 0);
}

/**
 * @brief Test for the presence of required functions.
 *
 * This test verifies that the following functions are available:
 * - "sfp-type-change"
 * - "get-sfp-type"
 *
 * @param state Unused parameter for testing.
 */
void test_has_functions(UNUSED void** state) {
    // Check if the function is present
    assert_true(amxm_has_function(MOD_NAME, MOD_WANMGR_SFP, "sfp-type-change"));
    assert_true(amxm_has_function(MOD_NAME, MOD_WANMGR_SFP, "get-sfp-type"));
    assert_true(amxm_has_function(MOD_NAME, MOD_WANMGR_SFP, "read-sfp-type"));
}

/**
 * @brief Test to validate module loading.
 *
 * This test ensures that the "mod-wanmgr-sfp" module is successfully loaded.
 *
 * @param state Unused parameter for testing.
 */
void test_can_load_module(UNUSED void** state) {
    // Loading the mod wanmgr sfp module
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

/**
 * @brief Test to validate module unloading.
 *
 * This test ensures that all modules, including "mod-wanmgr-sfp," are unloaded successfully.
 *
 * @param state Unused parameter for testing.
 */
void test_can_close_module(UNUSED void** state) {
    // unloading the mod wanmgr sfp module
    assert_int_equal(amxm_close_all(), 0);
}

/**
 * @brief Teardown function for cleaning up test resources.
 *
 * This function stops the `ubusd` process and performs cleanup
 * for the parser, data model, and backend components.
 *
 * @param state Unused parameter for the test framework.
 * @return Always returns 0 to indicate successful teardown.
 */
int test_teardown(UNUSED void** state) {
    /* Stopping the the ubusd process
     * in the test teardown */
    system("killall ubusd");
    amxb_be_remove_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
    return 0;
}
