
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "generator.h"

static int repeat_previous_timepoint(struct timepoints_t* tp) {
    return tp->tps[tp->i - 1];
}

static int current_timepoint(struct timepoints_t* tp) {
    return tp->tps[tp->i] == REPEAT_LAST_TIMEPOINT ? tp->tps[tp->i - 1] : tp->tps[tp->i];
}

static int next_timepoint(struct timepoints_t* tp) {
    int value = current_timepoint(tp);
    if(tp->i < tp->size - 1) {
        tp->i++;
    } else {
        /* We are at the last entry so might as well change the function pointer
           so we don't have to deal with this if statement next time. */
        tp->next = tp->tps[tp->size - 1] == REPEAT_LAST_TIMEPOINT ? repeat_previous_timepoint : NULL;
    }
    return value;
}

static void reset_iterator(struct timepoints_t* tp) {
    if(tp == NULL) {
        return;
    }

    tp->i = 0;
    tp->next = next_timepoint;
}

timepoints_t* initialize_timepoints(const char* timepoints) {
    const char* delimiter = ",";
    int arr[40];

    char* copy = strdup(timepoints);
    int i = 0;
    char* token = strtok(copy, delimiter);

    while(token != NULL) {
        arr[i] = atoi(token);
        token = strtok(NULL, delimiter);
        i++;
    }
    free(copy);

    timepoints_t* tp = malloc(sizeof(timepoints_t));

    tp->size = i;
    tp->reset = reset_iterator;
    tp->tps = malloc(sizeof(int) * tp->size);
    memcpy(tp->tps, &arr[0], tp->size * sizeof(int));

    tp->reset(tp);

    return tp;
}

timepoints_t* generate_timepoints(int timeout_value, int max_transmits) {
    #define ARR_SIZE 1024
    char str[ARR_SIZE];
    int pos = 0;

    for(int k = 0; k < max_transmits - 1; k++) {
        pos += snprintf(&str[pos], ARR_SIZE - pos, "%d,", timeout_value);
    }
    pos += snprintf(&str[pos], ARR_SIZE - pos, "%d", timeout_value);
    return initialize_timepoints(str);
}

int next(timepoints_t* t) {
    return (t == NULL || t->next == NULL) ? ERROR_NO_TIMEPOINT_LEFT : t->next(t);
}

int peek(timepoints_t* t) {
    return (t == NULL || t->next == NULL) ? ERROR_NO_TIMEPOINT_LEFT : current_timepoint(t);
}

void reset(timepoints_t* t) {
    if (t == NULL) {
        return;
    }

    t->reset(t);
}

void cleanup_timepoints(timepoints_t** t) {
    if (t == NULL || *t == NULL) {
        return;
    }

    free((*t)->tps);
    (*t)->tps = NULL;
    free(*t);
    *t = NULL;
}
