#ifndef __HELPERS_H__
#define __HELPERS_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "device.h"

#include <stdbool.h>

#define SAFE_DELETE(x) free(x); x = NULL;
#define STR_EMPTY(x) (((x) == NULL) || ((x)[0] == '\0'))

/**
 * @brief Return hex value or empty string.
 *
 * @param src String that may contain a hexadecimal value.
 * @return Hexadecimal value or empty string ("").
 */
char* set_hex_value(const char* src);

/**
 * @brief Converts a number to a hexadecimal string.
 *
 * @param i unsigned integer value
 * @return Hexadecimal value or empty string ("").
 */
char* int_to_hex_value(uint32_t i);

/**
 * @brief Verifies whether a hexadecimal string is allowed or not.
 *
 * @param allowed_str String containing hexadecimal characters and or wildcards as defined in tr181.
 * @param value Hexadecimal string that needs to be verified.
 * @return true when valid, false otherwise.
 */
bool is_valid_hex_number(char* allowed_str, char* value);

/**
 * @brief Verifies whether a USB device interface is allowed or not.
 *
 * @param allowed_intf Internal usb interface structure containing hexadecimal values and/or wildcards.
 * @param value Internal usb interface that needs to be verified
 * @return true when valid, false otherwise
 */
bool is_valid_interface(usb_device_interface_t* allowed_intf, usb_device_interface_t* value);

#ifdef __cplusplus
}
#endif

#endif // __HELPERS_H__
