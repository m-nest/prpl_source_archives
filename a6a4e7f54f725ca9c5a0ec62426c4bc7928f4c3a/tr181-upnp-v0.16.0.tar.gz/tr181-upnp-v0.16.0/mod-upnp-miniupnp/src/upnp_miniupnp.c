/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include <debug/sahtrace.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_transaction.h>
#include <amxm/amxm.h>
#include <amxb/amxb.h>
#include <netmodel/client.h>
#include <debug/sahtrace_macros.h>

#include "upnp_miniupnp.h"

#define ME "upnp"
#define string_empty(X) ((X == NULL) || (*X == '\0'))
#define DELAY_RESTART 2000
#define UUID_LEN 36
#define UUID_BUF_SIZE 256
#ifdef UNIT_TEST
#define INTERNAL_API
#else
#define INTERNAL_API static
#endif

static amxm_module_t* mod = NULL;
static amxp_timer_t* restart_timer;
static amxp_timer_t* reload_timer;
static bool alt_com = false;
INTERNAL_API char* ext_ifname = NULL;
INTERNAL_API char* ext_ifname6 = NULL;
INTERNAL_API char* listening_ip = NULL;
static int bitrate_down = 1024;
static int bitrate_up = 512;
static int miniupnpd_port = 5000;
INTERNAL_API char* miniupnpd_uuid = NULL;
static amxp_subproc_t* miniupnpd_proc = NULL;
static netmodel_query_t* lan_query = NULL;
static netmodel_query_t* wan_ip_query = NULL;
static netmodel_query_t* lan_ip_query = NULL;
static netmodel_query_t* wan_query = NULL;
static netmodel_query_t* wan6_query = NULL;
INTERNAL_API amxc_var_t* plugin_config = NULL;
INTERNAL_API amxc_var_t* external_config = NULL;

/**
 * @brief Generates a UUID for miniupnpd by reading from the system's UUID source.
 *
 * This function reads a UUID string from "/proc/sys/kernel/random/uuid" and stores
 * it in the global variable `miniupnpd_uuid`. If reading fails, the function exits silently.
 */
INTERNAL_API void generate_miniupnpd_uuid(void) {
    int fd = -1;
    int retval;
    char buf[UUID_LEN + 1] = {0};

    fd = open("/proc/sys/kernel/random/uuid", O_RDONLY);
    when_true(fd == -1, exit);
    retval = read(fd, buf, UUID_LEN);
    if(retval == UUID_LEN) {
        miniupnpd_uuid = strdup(buf);
    }
    close(fd);
exit:
    return;
}

/**
 * @brief Creates and writes the configuration file for miniupnpd.
 *
 * This function generates a configuration file at the specified path, populating it
 * with various settings based on current system and external configurations.
 * It returns 0 on success and -1 on failure.
 *
 * @return 0 if the configuration file was successfully created and written, -1 otherwise.
 */
INTERNAL_API int create_miniupnpd_conf_file(void) {
    int fd = open(MINIUPNP_CONF_FILE, O_CREAT | O_TRUNC | O_WRONLY, 0644);
    FILE* override_fd;
    int retval = -1;
    amxc_string_t buffer;
    amxc_var_t tmp_csv;
    bool enable_natpmp = false;
    bool enable_ipv6 = false;
    bool allow_reserved_addr = false;
    char buf[UUID_BUF_SIZE];
    int n;

    amxc_string_init(&buffer, 0);
    amxc_var_init(&tmp_csv);
    when_true(fd == -1, exit);
    free(miniupnpd_uuid);

    // Ensure that UUID is persistent across reboots
    miniupnpd_uuid = NULL;
    override_fd = fopen(MINIUPNP_CONF_OVERRIDE_FILE, "r");
    if(override_fd == NULL) {
        generate_miniupnpd_uuid();
        override_fd = fopen(MINIUPNP_CONF_OVERRIDE_FILE, "w");
        if(override_fd == NULL) {
            SAH_TRACEZ_ERROR(ME, "Failed to open file for writing: %s", MINIUPNP_CONF_OVERRIDE_FILE);
        } else {
            n = snprintf(buf, sizeof("uuid=") + UUID_LEN + 1, "uuid=%s\n", miniupnpd_uuid);

            n = fwrite(buf, 1, n, override_fd);
            if(n != sizeof("uuid=") + UUID_LEN) {
                SAH_TRACEZ_ERROR(ME, "Failed to write UUID to %s", MINIUPNP_CONF_OVERRIDE_FILE);
            }

            fclose(override_fd);
        }
    } else {
        n = fread(buf, 1, sizeof("uuid=") + UUID_LEN, override_fd);
        if(n != sizeof("uuid=") + UUID_LEN) {
            SAH_TRACEZ_ERROR(ME, "Failed to read UUID from %s", MINIUPNP_CONF_OVERRIDE_FILE);
        }

        if((strncmp("uuid=", buf, sizeof("uuid=") - 1) != 0) || (buf[sizeof("uuid=") - 1 + UUID_LEN] != '\n')) {
            SAH_TRACEZ_ERROR(ME, "Failed to parse UUID from %s: invalid format", MINIUPNP_CONF_OVERRIDE_FILE);
        } else {
            buf[sizeof("uuid=") - 1 + UUID_LEN] = '\0';
            miniupnpd_uuid = malloc(UUID_LEN + 1);
            strncpy(miniupnpd_uuid, buf + sizeof("uuid=") - 1, UUID_LEN);
            miniupnpd_uuid[UUID_LEN] = '\0';
        }

        fclose(override_fd);
    }

    enable_natpmp = GET_BOOL(external_config, "enable_natpmp");
    enable_ipv6 = GET_BOOL(external_config, "enable_ipv6");
    allow_reserved_addr = GET_BOOL(external_config, "allow_reserved_addr");
    when_null_trace(external_config, exit, ERROR, "External miniupnpd config null");
    when_str_empty_trace(listening_ip, exit, ERROR, "listening_ip interface isn't bound yet");
    amxc_string_appendf(&buffer, "ext_ifname=%s\n", (ext_ifname) ? ext_ifname : "");
    amxc_string_appendf(&buffer, "ext_ifname6=%s\n", (ext_ifname6) ? ext_ifname6 : "");
    amxc_string_appendf(&buffer, "listening_ip=%s\n", (listening_ip) ? listening_ip : "");
    amxc_string_appendf(&buffer, "enable_natpmp=%s\n", (enable_natpmp) ? "yes" : "no");
    amxc_string_appendf(&buffer, "pf_allow_reserved_addr=%s\n", (allow_reserved_addr) ? "yes" : "no");
    amxc_string_appendf(&buffer, "ipv6_disable=%s\n", (enable_ipv6) ? "no" : "yes");
    amxc_string_appendf(&buffer, "%s\n", "enable_upnp=yes");
    amxc_string_appendf(&buffer, "%s\n", "secure_mode=yes");
    amxc_string_appendf(&buffer, "%s\n", "system_uptime=yes");
    amxc_string_appendf(&buffer, "%s\n", "force_igd_desc_v1=no");
    amxc_string_appendf(&buffer, alt_com ? "bitrate_down=%d\n" : "bitrate_download=%d\n", bitrate_down * 1024 * 8);
    amxc_string_appendf(&buffer, alt_com ? "bitrate_up=%d\n" : "bitrate_upload=%d\n", bitrate_up * 1024 * 8);
    amxc_string_appendf(&buffer, "port=%d\n", miniupnpd_port);
    amxc_string_appendf(&buffer, "uuid=%s\n", miniupnpd_uuid);
    amxc_var_copy(&tmp_csv, GET_ARG(plugin_config, "backends"));
    amxc_var_cast(&tmp_csv, AMXC_VAR_ID_CSV_STRING);
    amxc_string_appendf(&buffer, "amx_backend_urls=%s\n", amxc_var_constcast(cstring_t, &tmp_csv));
    amxc_var_copy(&tmp_csv, GET_ARG(plugin_config, "uris"));
    amxc_var_cast(&tmp_csv, AMXC_VAR_ID_CSV_STRING);
    amxc_string_appendf(&buffer, "amx_sock_urls=%s\n", amxc_var_constcast(cstring_t, &tmp_csv));
    if((GET_CHAR(external_config, "ext_stun_host") != NULL) && (GET_CHAR(external_config, "ext_stun_host")[0] != '\0')) {
        amxc_string_appendf(&buffer, "%s\n", "ext_perform_stun=yes");
        amxc_string_appendf(&buffer, "ext_stun_host=%s\n", GET_CHAR(external_config, "ext_stun_host"));
    } else {
        amxc_string_appendf(&buffer, "%s\n", "ext_perform_stun=no");
    }
    if(GET_BOOL(external_config, "auto_cleanup_enable")) {
        amxc_string_appendf(&buffer, "max_lifetime=%lu\n", (unsigned long) GET_UINT32(external_config, "max_lifetime"));
        amxc_string_appendf(&buffer, "clean_ruleset_interval=%lu\n", (unsigned long) GET_UINT32(external_config, "clean_ruleset_interval"));
    }
    if(!string_empty(GET_CHAR(external_config, "friendly_name"))) {
        amxc_string_appendf(&buffer, "friendly_name=%s\n", GET_CHAR(external_config, "friendly_name"));
    }
    if(!string_empty(GET_CHAR(external_config, "manufacturer_name"))) {
        amxc_string_appendf(&buffer, "manufacturer_name=%s\n", GET_CHAR(external_config, "manufacturer_name"));
    }
    if(!string_empty(GET_CHAR(external_config, "manufacturer_url"))) {
        amxc_string_appendf(&buffer, "manufacturer_url=%s\n", GET_CHAR(external_config, "manufacturer_url"));
    }
    if(!string_empty(GET_CHAR(external_config, "model_name"))) {
        amxc_string_appendf(&buffer, "model_name=%s\n", GET_CHAR(external_config, "model_name"));
    }
    if(!string_empty(GET_CHAR(external_config, "model_description"))) {
        amxc_string_appendf(&buffer, "model_description=%s\n", GET_CHAR(external_config, "model_description"));
    }
    if(!string_empty(GET_CHAR(external_config, "model_url"))) {
        amxc_string_appendf(&buffer, "model_url=%s\n", GET_CHAR(external_config, "model_url"));
    }
    if(!string_empty(GET_CHAR(external_config, "model_number"))) {
        amxc_string_appendf(&buffer, "model_number=%s\n", GET_CHAR(external_config, "model_number"));
    }
    if(!string_empty(GET_CHAR(external_config, "serial"))) {
        amxc_string_appendf(&buffer, "serial=%s\n", GET_CHAR(external_config, "serial"));
    }
    if(!string_empty(GET_CHAR(external_config, "upnp_amx_wan_interface"))) {
        amxc_string_appendf(&buffer, "upnp_amx_wan_interface=%s\n", GET_CHAR(external_config, "upnp_amx_wan_interface"));
    }
    if(!string_empty(GET_CHAR(external_config, "wan_access_provider"))) {
        amxc_string_appendf(&buffer, "wan_access_provider=%s\n", GET_CHAR(external_config, "wan_access_provider"));
    }
    amxc_string_appendf(&buffer, "%s\n", "allow 1024-65535 0.0.0.0/0 1024-65535");
    amxc_string_appendf(&buffer, "%s\n", "deny 0-65535 0.0.0.0/0 0-65535");
    retval = write(fd, amxc_string_get(&buffer, 0), amxc_string_text_length(&buffer));
    fsync(fd);
    close(fd);
    sync();
    when_true(retval != (int) amxc_string_text_length(&buffer), exit);
    retval = 0;
exit:
    amxc_var_clean(&tmp_csv);
    amxc_string_clean(&buffer);
    return retval;
}

/**
 * @brief Cleanup UPnP port mappings from firewall rules.
 *
 * This function removes all UPnP port mappings that were created by the
 * miniupnpd service, these mappings are identified by their origin being either
 * "UPnP" or deprecated "UPnP_IWF".
 */
static void cleanup_upnp_portmappings(void) {
    int res = amxb_del(amxb_be_who_has("NAT."),
                       "NAT.PortMapping.[Origin == \"UPnP_IWF\" || Origin == \"UPnP\"].", 0,
                       NULL, NULL, 5);

    SAH_TRACEZ_INFO(ME, "Cleanup UPnP port mappings: %d", res);

    res = amxb_del(amxb_be_who_has("PCP."),
                   "PCP.Client.*.Server.*.InboundMapping.[Origin == \"UPnP_IWF\" || Origin == \"UPnP\"].", 0,
                   NULL, NULL, 5);

    SAH_TRACEZ_INFO(ME, "Cleanup PCP port mappings: %d", res);

    return;
}

/**
 * @brief Starts the miniupnpd process.
 *
 * This function creates the configuration file, then attempts to start the miniupnpd process
 * with the generated configuration. It logs success or failure accordingly.
 */
static void start_miniupnpd(void) {
    int rv = 0;

    rv = create_miniupnpd_conf_file();
    when_failed_trace(rv, exit, WARNING, "Didn't start miniupnpd, conf is invalid (at boot it can be because interfaces aren't bind yet)");
    amxp_subproc_new(&miniupnpd_proc);
    rv = amxp_subproc_start(miniupnpd_proc, (char*) "miniupnpd", "-f", MINIUPNP_CONF_FILE, NULL);
    if(rv == 0) {
        SAH_TRACEZ_INFO(ME, "miniupnpd has successfuly started (pid[%d])", amxp_subproc_get_pid(miniupnpd_proc));
    } else {
        SAH_TRACEZ_ERROR(ME, "Couldn't start miniupnpd (%d)", rv);
    }
exit:
    return;
}

/**
 * @brief Stops the miniupnpd process if it is running.
 *
 * This function checks if the miniupnpd process exists and is active,
 * then terminates it and releases associated resources.
 */
static void stop_miniupnpd(void) {
    if(miniupnpd_proc != NULL) {
        if(miniupnpd_proc->is_running) {
            amxp_subproc_kill(miniupnpd_proc, 9);
        }
        amxp_subproc_delete(&miniupnpd_proc);
    }
}

/**
 * @brief Handles changes to the LAN interface.
 *
 * This callback function updates the listening IP address based on the provided data,
 * logs the change, and restarts a timer to handle the restart delay.
 *
 * @param sig_name Name of the signal (unused).
 * @param data Pointer to the variable containing the new LAN interface information.
 * @param priv User data (unused).
 */
static void lan_intf_changed(UNUSED const char* sig_name, const amxc_var_t* data, UNUSED void* priv) {
    free(listening_ip);
    if((amxc_var_type_of(data) != AMXC_VAR_ID_NULL) && !string_empty(GET_CHAR(data, NULL))) {
        listening_ip = strdup(GET_CHAR(data, NULL));
    } else {
        listening_ip = NULL;
    }
    SAH_TRACEZ_INFO(ME, "LAN interface changed: %s", listening_ip);
    amxp_timer_start(restart_timer, DELAY_RESTART);
}

/**
 * @brief Handles changes to the network IP address.
 *
 * This callback function logs the IP change event and restarts a timer to handle the restart delay.
 *
 * @param sig_name Name of the signal (unused).
 * @param data Pointer to the variable containing the new IP information (unused).
 * @param priv User data, expected to be a string describing the IP change.
 */
static void network_ip_changed(UNUSED const char* sig_name, UNUSED const amxc_var_t* data, void* priv) {
    SAH_TRACEZ_INFO(ME, "%s IP changed", (const char*) priv);
    amxp_timer_start(reload_timer, DELAY_RESTART);
}

/**
 * @brief Callback executed when the LAN network IP address changes.
 *
 * This function is triggered by a signal indicating that the LAN IP has changed.
 * It logs the event, cleans up existing UPnP port mappings, and schedules
 * a delayed restart using a timer.
 *
 * @param sig_name  Unused. Name of the signal that triggered the callback.
 * @param data      Unused. Additional signal data (if any).
 * @param priv      A pointer passed to the callback, typically containing
 *                  context information such as the network interface name.
 *
 */
static void lan_network_ip_changed(UNUSED const char* sig_name, UNUSED const amxc_var_t* data, void* priv) {
    SAH_TRACEZ_INFO(ME, "%s IP changed", (const char*) priv);
    cleanup_upnp_portmappings();
    amxp_timer_start(restart_timer, DELAY_RESTART);
}

/**
 * @brief Handles changes to the WAN interface.
 *
 * This function updates the external interface name based on the provided data,
 * logs the change, and restarts a timer to handle the restart delay.
 *
 * @param sig_name Name of the signal (unused).
 * @param data Pointer to the variable containing the new WAN interface information.
 * @param priv User data (unused).
 */
static void wan_intf_changed(UNUSED const char* sig_name, const amxc_var_t* data, UNUSED void* priv) {
    free(ext_ifname);
    if((amxc_var_type_of(data) != AMXC_VAR_ID_NULL) && !string_empty(GET_CHAR(data, NULL))) {
        ext_ifname = strdup(GET_CHAR(data, NULL));
    } else {
        ext_ifname = NULL;
    }
    SAH_TRACEZ_INFO(ME, "WAN interface changed: %s", ext_ifname);
    /* If WAN interface changes (ex: changing from PON to WAN Ethernet), we must
     * cleanup the port mappings created by miniupnpd */
    cleanup_upnp_portmappings();
    amxp_timer_start(restart_timer, DELAY_RESTART);
}

/**
 * @brief Handles changes to the IPv6 WAN interface.
 *
 * This function updates the external IPv6 interface name based on the provided data,
 * logs the change, and restarts a timer to handle the restart delay.
 *
 * @param sig_name Name of the signal (unused).
 * @param data Pointer to the variable containing the new IPv6 WAN interface information.
 * @param priv User data (unused).
 */
static void wan6_intf_changed(UNUSED const char* sig_name, const amxc_var_t* data, UNUSED void* priv) {
    free(ext_ifname6);
    if((amxc_var_type_of(data) != AMXC_VAR_ID_NULL) && !string_empty(GET_CHAR(data, NULL))) {
        ext_ifname6 = strdup(GET_CHAR(data, NULL));
    } else {
        ext_ifname6 = NULL;
    }
    SAH_TRACEZ_INFO(ME, "WAN6 interface changed: %s", ext_ifname6);
    /* If WAN interface changes (ex: changing from PON to WAN Ethernet), we must
     * cleanup the port mappings created by miniupnpd */
    cleanup_upnp_portmappings();
    amxp_timer_start(restart_timer, DELAY_RESTART);
}

/**
 * @brief Initializes network interface queries for LAN and WAN interfaces.
 *
 * This function sets up queries to monitor the status and addresses of LAN, WAN, and IPv6 WAN interfaces,
 * and registers callback functions to handle interface changes.
 */
static void start_netmodel_callback(void) {
    lan_query = netmodel_openQuery_getFirstParameter(GET_CHAR(plugin_config, "ip_intf_lan"), MOD_NAME, "NetDevName", "netdev-bound", "down", lan_intf_changed, NULL);
    wan_ip_query = netmodel_openQuery_getAddrs(GET_CHAR(plugin_config, "logical_intf_wan"), MOD_NAME, "global", "down", network_ip_changed, (void*) "WAN");
    lan_ip_query = netmodel_openQuery_getAddrs(GET_CHAR(plugin_config, "ip_intf_lan"), MOD_NAME, "global", "down", lan_network_ip_changed, (void*) "LAN");
    wan_query = netmodel_openQuery_getFirstParameter(GET_CHAR(plugin_config, "logical_intf_wan"), MOD_NAME, "NetDevName", "netdev-bound && ipv4", "down", wan_intf_changed, NULL);
    wan6_query = netmodel_openQuery_getFirstParameter(GET_CHAR(plugin_config, "logical_intf_wan"), MOD_NAME, "NetDevName", "netdev-bound && ipv6", "down", wan6_intf_changed, NULL);
}

/**
 * @brief Cleans up and closes network interface queries.
 *
 * This function releases resources associated with LAN, WAN, and IPv6 WAN interface queries
 * by closing each query and setting their pointers to NULL.
 */
static void stop_netmodel_callback(void) {
    netmodel_closeQuery(lan_query);
    lan_query = NULL;
    netmodel_closeQuery(wan_ip_query);
    wan_ip_query = NULL;
    netmodel_closeQuery(lan_ip_query);
    lan_ip_query = NULL;
    netmodel_closeQuery(wan_query);
    wan_query = NULL;
    netmodel_closeQuery(wan6_query);
    wan6_query = NULL;
}

/**
 * @brief Handles changes to the IGD (Internet Gateway Device) configuration.
 *
 * This function updates the external configuration based on the provided arguments,
 * stops or starts the miniupnpd service accordingly, and manages related timers.
 *
 * @param function_name Name of the function (unused).
 * @param args Arguments containing the new configuration.
 * @param ret Return value (unused).
 * @return Always returns 0.
 */
static int igd_changed(UNUSED const char* function_name,
                       amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    bool enabled = GET_BOOL(args, "enable");
    amxc_var_delete(&external_config);
    amxc_var_new(&external_config);
    amxc_var_copy(external_config, args);

    amxp_timer_stop(restart_timer);
    amxp_timer_stop(reload_timer);

    if(enabled) {
        if(amxp_subproc_is_running(miniupnpd_proc)) {
            SAH_TRACEZ_NOTICE(ME, "Restarting miniupnpd");
            stop_miniupnpd();
        } else {
            SAH_TRACEZ_NOTICE(ME, "Starting miniupnpd");
            start_netmodel_callback();
        }
        start_miniupnpd();
    } else {
        SAH_TRACEZ_NOTICE(ME, "Shutting down miniupnpd");
        stop_miniupnpd();
        stop_netmodel_callback();
    }
    return 0;
}

/**
 * @brief Initializes the plugin configuration.
 *
 * This function creates and copies the provided configuration arguments into the plugin configuration variable.
 * If the configuration is already initialized, it does nothing.
 *
 * @param function_name Name of the function (unused).
 * @param args Arguments containing the configuration data.
 * @param ret Return value (unused).
 * @return Always returns 0.
 */
INTERNAL_API int init_config(UNUSED const char* function_name,
                             amxc_var_t* args,
                             UNUSED amxc_var_t* ret) {
    if(plugin_config) {
        return 0;
    }
    amxc_var_new(&plugin_config);
    amxc_var_copy(plugin_config, args);

    return 0;
}

/**
 * @brief Retrieves the capabilities of the plugin.
 *
 * This function adds a key-value pair indicating the plugin's capabilities to the return variable.
 *
 * @param function_name Name of the function (unused).
 * @param args Arguments (unused).
 * @param ret Variable where the capabilities are stored.
 * @return Always returns 0.
 */
static int get_capabilities(UNUSED const char* function_name,
                            UNUSED amxc_var_t* args,
                            amxc_var_t* ret) {
    amxc_var_add_key(uint32_t, ret, "UPnPIGD", 2);

    return 0;
}

/**
 * @brief Callback to restart the miniupnpd process.
 *
 * This function stops the reload timer, terminates the miniupnpd process if it is running,
 * and then starts it again.
 *
 * @param timer Timer object (unused).
 * @param priv User data (unused).
 */
static void restart_miniupnpd_cb(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    amxp_timer_stop(reload_timer);
    if(amxp_subproc_is_running(miniupnpd_proc)) {
        stop_miniupnpd();
    }
    start_miniupnpd();
}

/**
 * @brief Callback to reload the miniupnpd configuration.
 *
 * This function checks if the restart timer is active; if so, it exits.
 * If miniupnpd is running, it sends a SIGUSR1 signal to reload its configuration.
 * Otherwise, it starts the miniupnpd process.
 *
 * @param timer Timer object (unused).
 * @param priv User data (unused).
 */
static void reload_miniupnpd_cb(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    when_true(amxp_timer_get_state(restart_timer) == amxp_timer_running, exit);
    if(amxp_subproc_is_running(miniupnpd_proc)) {
        kill(miniupnpd_proc->pid, SIGUSR1);
        SAH_TRACEZ_INFO(ME, "Reload config");
    } else {
        start_miniupnpd();
    }
exit:
    return;
}

/**
 * @brief Module initialization function for the UPnP plugin.
 *
 * This function registers the module, adds functions, creates timers for restart and reload,
 * and retrieves the miniupnpd version to determine configuration details.
 *
 * @return Returns 0 on success, or a different value on failure.
 */
static AMXM_CONSTRUCTOR module_init(void) {
    amxm_shared_object_t* so = NULL;
    int rv = -1;
    FILE* fp;
    char version[128];
    char* vers_num = NULL;

    so = amxm_so_get_current();
    when_null(so, exit);

    rv = amxm_module_register(&mod, so, "upnp");
    when_false(0 == rv, exit);

    rv = amxm_module_add_function(mod, "igd-changed", igd_changed);
    rv += amxm_module_add_function(mod, "init", init_config);
    rv += amxm_module_add_function(mod, "get_capabilities", get_capabilities);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to add functions to module");
    }

    amxp_timer_new(&restart_timer, restart_miniupnpd_cb, NULL);
    amxp_timer_new(&reload_timer, reload_miniupnpd_cb, NULL);

    fp = popen("miniupnpd --version", "r");
    when_null_trace(fp, exit, ERROR, "Failed to get miniupnpd version");
    if(fgets(version, sizeof(version), fp) != NULL) {
        vers_num = strstr(version, MINIUPNP_CONF_VERSION);
        alt_com = vers_num != NULL;
    }
    pclose(fp);

exit:
    return rv;
}

/**
 * @brief Module cleanup function for the UPnP plugin.
 *
 * This function stops the miniupnpd process, frees allocated resources,
 * deletes timers, and cleans up configuration variables.
 *
 * @return Always returns 0.
 */
static AMXM_DESTRUCTOR module_exit(void) {
    stop_miniupnpd();
    free(ext_ifname);
    free(ext_ifname6);
    free(miniupnpd_uuid);
    free(listening_ip);
    amxc_var_delete(&plugin_config);
    amxc_var_delete(&external_config);
    amxp_timer_delete(&restart_timer);
    amxp_timer_delete(&reload_timer);
    return 0;
}
