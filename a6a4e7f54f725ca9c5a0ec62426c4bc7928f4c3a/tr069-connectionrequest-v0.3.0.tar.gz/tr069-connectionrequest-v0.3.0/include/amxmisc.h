/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef AMXMISC_H_INCLUDED
#define AMXMISC_H_INCLUDED

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>

/**
 * @file amxmisc.h
 * @brief The module for access to Ambiorix.
 */

/**
 * @enum ip_mode_t
 * Enumeration of IP mode
 */
typedef enum {
    IP_MODE_IPV4 = 0,    /**< IPv4 only */
    IP_MODE_IPV6         /**< IPv6 only */
} ip_mode_t;

/**
 * @brief Destroy Ambiorix context and disconnect from bus.
 */
void ShutdownAmx(void);
/**
 * @brief Initialize Ambiorix context and connect to bus.
 *
 * @return 0 on success, -1 or error code on error.
 */
int InitAmx(void);
/**
 * @brief Get ManagementServer.ConnRequest.ConnRequestPort.
 *
 * @return port number
 */
unsigned short GetAmxAgentPort(void);
/**
 * @brief Get ManagementServer.State.ACSIP.
 *
 * @return ACS IP as a string
 */
char* GetAmxAgentAcsIp(void);
/**
 * @brief Get ManagementServer.Stats.SessionsSinceReboot.
 *
 * @return Number of sessions succesfully established with ACS since reboot
 */
uint32_t GetAmxAgentAcsStatsSessions(void);
/**
 * @brief Get IPv4 Address of the extender.
 *
 * @return IPv4 as string
 */
char* GetAmxAgentIp4(void);
/**
 * @brief Get IPv6 Address of the extender.
 *
 * @return IPv6 as string
 */
char* GetAmxAgentIp6(void);
/**
 * @brief Check if IPv6 address of the extender is set
 *
 * @return 1 if IPv6 is set
 * @return 0 if IPv6 is not set
 */
int GetAmxAgentIsSetIp6(void);
/**
 * @brief Check if IPv4 address of the extender is set.
 *
 * @return 1 if IPv4 is set
 * @return 0 if IPv4 is not set
 */
int GetAmxAgentIsSetIp4(void);
/**
 * @brief Get IPv6 Address of the IGD.
 *
 * @return IPv6 as string
 */
char* GetAmxAgentServerAddressIp6(void);
/**
 * @brief Get IPv4 Address of the IGD.
 *
 * @return IPv4 as string
 */
char* GetAmxAgentServerAddressIp4(void);
/**
 * @brief Create necessary firewall rules in the extender.
 *
 * @param [in] portv4 The IPv4 port
 * @param [in] portv6 The IPv6 port
 * @param [in] portv6global The IPv6 global port
 * @param [in] isIPv6 The mode of the extender
 */
void CreateUpnpFirewallRules(
    unsigned short portv4,
    unsigned short portv6,
    unsigned short portv6global,
    ip_mode_t isIPv6);
/**
 * @brief Delete Firewall rules in the extender.
 *
 * @param [in] isIPv6 The mode of the extender
 */
void DeleteUpnpFirewallRule(ip_mode_t isIPv6);
/**
 * @brief Update ConnectionRequestURL field value in data model.
 *
 * @param [in] host The IP address of the host
 * @param [in] port The IP port
 * @return 1 if FAIL
 * @return 0 if SUCCESS
 */
int CallAmxUpdateConnectionRequestURL(const char* host, const char* port);

#endif

