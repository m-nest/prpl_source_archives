/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "modunbound.h"

/**
 * @brief String validation strategy for UnboundControl output.
 *
 * UnboundControl typically returns a single string (often terminated by '\n').
 * Depending on the command, the module either expects a fixed prefix (e.g. "ok")
 * or needs to verify that a certain substring is present in more verbose output.
 */

typedef enum {
    expects = 0,
    contains
} validate_t;

/**
 * @brief Resolve the Ambiorix bus context that hosts the Unbound management object for an interface.
 *
 * Higher-level TR-181 actions are performed against an Unbound instance that is represented on the
 * bus by an object name derived from @p intf (see @c UNBOUND_OBJECT_NAME). Because multiple bus
 * backends may be present, this helper asks Ambiorix which backend "owns" that object and returns
 * the corresponding bus context.
 *
 * @param[in] intf Interface identifier used to format the Unbound object path.
 *
 * @return The bus context to use for subsequent @c amxb_call() invocations, or @c NULL if @p intf is
 *         empty or no backend currently advertises the required object.
 */
amxb_bus_ctx_t* get_unbound_ctx(const char* intf) {
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t object_name;

    amxc_string_init(&object_name, 0);
    when_str_empty(intf, exit);

    amxc_string_setf(&object_name, UNBOUND_OBJECT_NAME, intf);
    ctx = amxb_be_who_has(amxc_string_get(&object_name, 0));

exit:
    amxc_string_clean(&object_name);
    return ctx;
}

/**
 * @brief Issue a raw `UnboundControl` RPC call for a given interface and command.
 *
 * This is the lowest-level RPC wrapper used by the TR-181 ⇄ Unbound integration. It formats the
 * Unbound object name for @p intf, builds the RPC arguments (`{ "cmd": <cmd> }`), and calls the
 * `UnboundControl` method through Ambiorix.
 *
 * The commands used are the same listed by NLNet for `unbound-control`.
 * (https://www.nlnetlabs.nl/documentation/unbound/unbound-control/)
 *
 * Some other commands are added via patches in unbound.
 *
 * Command-specific interpretation (for example, checking for "ok") is handled by higher-level
 * helpers.
 *
 * @param[in]  intf Interface identifier used to locate the correct Unbound instance on the bus.
 * @param[in]  cmd  Unbound control command string to execute (passed as the `"cmd"` RPC argument).
 * @param[out] ret  Variant that receives the RPC return value.
 *
 * @return One of the following status values:
 * - @c unbound_ok: RPC succeeded and returned a non-NULL string result.
 * - @c unbound_ctx_error: @p intf was empty or the Unbound object could not be resolved to a bus ctx.
 * - @c unbound_amxb_error: the underlying @c amxb_call() failed.
 * - @c unbound_ret_error: the return variant did not change compared to its pre-call value.
 * - @c unbound_validation_error: the return variant did not contain a valid string at index 0.
 */
static unbound_status_t unbound_call(const char* intf, const char* cmd, amxc_var_t* ret) {
    unbound_status_t status = unbound_ctx_error;
    int rv = -1;
    int compare_result = -1;
    amxc_string_t object_name;
    amxc_var_t args;
    amxc_var_t* ret_copy = NULL;
    const char* result = NULL;
    amxb_bus_ctx_t* ctx = get_unbound_ctx(intf);
    bool verbose = sahTraceZoneLevel(sahTraceGetZone(ME)) >= TRACE_LEVEL_INFO;

    amxc_var_init(&args);
    amxc_var_new(&ret_copy);
    amxc_string_init(&object_name, 0);

    when_str_empty(intf, exit);
    when_null_trace(ctx, exit, ERROR, "Unexpected empty bus context for "UNBOUND_OBJECT_NAME, intf);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "cmd", cmd);

    if(verbose) {
        SAH_TRACEZ_INFO(ME, "call UnboundControl");
        amxc_var_log(&args);
    }

    amxc_var_copy(ret_copy, ret);
    status = unbound_amxb_error;
    amxc_string_setf(&object_name, UNBOUND_OBJECT_NAME, intf);
    rv = amxb_call(ctx, amxc_string_get(&object_name, 0), "UnboundControl", &args, ret, 5);
    when_failed_trace(rv, exit, ERROR, "failed amxb_call %d", rv);

    if(verbose) {
        SAH_TRACEZ_INFO(ME, "retval of UnboundControl");
        amxc_var_log(ret);
    }

    status = unbound_ret_error;
    if(amxc_var_compare(ret, ret_copy, &compare_result) == 0) {
        when_true(compare_result == 0, exit);
    }

    status = unbound_validation_error;
    result = GETI_CHAR(ret, 0);
    when_null(result, exit);

    status = unbound_ok;
exit:
    amxc_var_clean(&args);
    amxc_var_delete(&ret_copy);
    amxc_string_clean(&object_name);
    return status;
}

/**
 * @brief Execute an UnboundControl command and validate the returned string against allowed patterns.
 *
 * Many `unbound-control` commands return a single-line status string (often with a trailing newline).
 * This helper centralizes the common logic:
 * 1. Execute the command via @ref unbound_call().
 * 2. Strip newline characters from the returned string.
 * 3. Compare the normalized result with each candidate in @p list_strings using the configured
 *    @p type:
 *    - @c expects: the result must start with the candidate string (prefix match).
 *    - @c contains: the result must contain the candidate string (substring match).
 *
 * @p ignore_validation_error controls logging behavior in mismatch scenarios. It is typically enabled
 * for "best-effort" commands where failures are handled upstream and verbose logs would be noise.
 *
 * @param[in] intf Interface identifier used to locate the Unbound instance.
 * @param[in] cmd  Unbound control command to execute.
 * @param[in] list_strings Optional variant list of allowed strings. If @c NULL, any non-NULL result
 *                         is accepted.
 * @param[in] ignore_validation_error When @c true, suppresses mismatch traces and treats validation
 *                                    failure as a status return only.
 * @param[in] type Matching strategy (prefix vs substring).
 *
 * @return @c unbound_ok if the command succeeded and the returned string matches one of the allowed
 *         patterns (or @p list_strings is @c NULL). Otherwise returns the propagated call error
 *         (@c unbound_ctx_error/@c unbound_amxb_error/...) or @c unbound_validation_error on mismatch.
 */
static unbound_status_t _unbound_call_validate_string(const char* intf, const char* cmd, amxc_var_t* list_strings, bool ignore_validation_error, validate_t type) {
    amxc_var_t ret;
    amxc_string_t ret_without_nl;
    unbound_status_t status = unbound_other_error;
    const char* result = NULL;
    bool matched_string = false;

    amxc_var_init(&ret);
    amxc_string_init(&ret_without_nl, 0);

    status = unbound_call(intf, cmd, &ret);
    when_false(status == unbound_ok, exit);
    amxc_string_setf(&ret_without_nl, "%s", GETI_CHAR(&ret, 0));
    amxc_string_replace(&ret_without_nl, "\n", "", UINT32_MAX);
    result = amxc_string_get(&ret_without_nl, 0);

    if(list_strings == NULL) {
        matched_string = true;
    } else {
        when_null(result, exit);
    }

    status = unbound_validation_error;
    amxc_var_for_each(string, list_strings) {
        const char* expected_string = GET_CHAR(string, NULL);
        int length = strlen(expected_string);
        bool ok = false;

        if(string_empty(expected_string)) {
            if(string_empty(result)) {
                ok = true;
            }
        } else {
            switch(type) {
            case expects:
                ok = (strncmp(result, expected_string, length) == 0);
                break;
            case contains:
                ok = (strstr(result, expected_string) != NULL);
                break;
            default:
                break;
            }
        }
        if(!ok) {
            if(!ignore_validation_error) {
                SAH_TRACEZ_INFO(ME, "unexpected return value '%s' - it expected a string '%s'", result != NULL ? result : "empty retval", expected_string);
            } else {
                continue;
            }
        } else {
            matched_string = true;
            break;
        }

    }

    if(!ignore_validation_error) {
        when_false_trace(matched_string, exit, ERROR, "Failed to match the expected value with '%s'", result != NULL ? result : "empty retval");
    } else {
        when_false(matched_string, exit);
    }

    status = unbound_ok;
exit:
    amxc_var_clean(&ret);
    amxc_string_clean(&ret_without_nl);
    return status;
}


/**
 * @brief Validate that an UnboundControl result starts with one of the provided strings.
 *
 * Internal wrapper around @ref _unbound_call_validate_string() using the @c expects strategy.
 */
static unbound_status_t unbound_call_expected_string(const char* intf, const char* cmd, amxc_var_t* list_strings, bool ignore_validation_error) {
    return _unbound_call_validate_string(intf, cmd, list_strings, ignore_validation_error, expects);
}

/**
 * @brief Validate that an UnboundControl result contains one of the provided substrings.
 *
 * Internal wrapper around @ref _unbound_call_validate_string() using the @c contains strategy.
 */
static unbound_status_t unbound_call_contains_string(const char* intf, const char* cmd, amxc_var_t* list_strings, bool ignore_validation_error) {
    return _unbound_call_validate_string(intf, cmd, list_strings, ignore_validation_error, contains);
}

/**
 * @brief Convenience helper for commands that are considered successful when Unbound returns "ok".
 *
 * Many `unbound-control` commands acknowledge success with an "ok" line. This helper executes
 * @p cmd and validates that the result starts with "ok" (after newline stripping).
 *
 * @param[in] intf Interface identifier used to locate the Unbound instance.
 * @param[in] cmd  Unbound control command to execute.
 *
 * @return @c unbound_ok when the command succeeded and returned "ok", otherwise an appropriate
 *         @ref unbound_status_t error code.
 */
unbound_status_t unbound_call_ok(const char* intf, const char* cmd) {
    unbound_status_t status = unbound_other_error;
    amxc_var_t str_list;
    amxc_var_init(&str_list);
    amxc_var_set_type(&str_list, AMXC_VAR_ID_LIST);

    amxc_var_add(cstring_t, &str_list, "ok");
    status = unbound_call_expected_string(intf, cmd, &str_list, true);
    amxc_var_clean(&str_list);
    return status;
}

/**
 * @brief Execute an UnboundControl command and verify that the result starts with an expected string.
 *
 * This is the public entry point used by the mod-dns-unbound layer when a command's success can be recognized
 * by a stable prefix (for example "ok", "error", or other well-known status tokens).
 *
 * @param[in] intf Interface identifier used to locate the Unbound instance.
 * @param[in] cmd  Unbound control command to execute.
 * @param[in] list_strings Variant list containing allowed prefixes.
 * @param[in] ignore_validation_error When @c true, suppresses mismatch traces; the mismatch is still
 *                                    reported via the return status.
 *
 * @return @c unbound_ok if the RPC succeeds and the returned string starts with one of the candidate
 *         strings, otherwise an error status.
 */
unbound_status_t unbound_call_expected(const char* intf, const char* cmd, amxc_var_t* list_strings, bool ignore_validation_error) {
    return unbound_call_expected_string(intf, cmd, list_strings, ignore_validation_error);
}

/**
 * @brief Execute an UnboundControl command and verify that the result contains an expected substring.
 *
 * Some `unbound-control` commands produce more verbose output where only part of the text is stable.
 * This helper validates such output by searching for one of the provided substrings.
 *
 * @param[in] intf Interface identifier used to locate the Unbound instance.
 * @param[in] cmd  Unbound control command to execute.
 * @param[in] list_strings Variant list containing allowed substrings.
 * @param[in] ignore_validation_error When @c true, suppresses mismatch traces; the mismatch is still
 *                                    reported via the return status.
 *
 * @return @c unbound_ok if the RPC succeeds and the returned string contains one of the candidate
 *         strings, otherwise an error status.
 */
unbound_status_t unbound_call_contains(const char* intf, const char* cmd, amxc_var_t* list_strings, bool ignore_validation_error) {
    return unbound_call_contains_string(intf, cmd, list_strings, ignore_validation_error);
}

/**
 * @brief Build a unique set of DNS server strings from a variant container.
 *
 * In the TR-181 DNS ⇄ Unbound integration, server addresses can originate from multiple sources
 * (e.g. per-interface DNS server lists, forwarded servers, or derived configuration). When writing
 * Unbound configuration, duplicates are undesirable and can cause noisy diffs/restarts. This helper
 * normalizes an Ambiorix variant structure into a de-duplicated set of server strings.
 *
 * The function iterates over @p var and, for each element, reads the `"server"` field. Non-empty
 * values are added to an @ref amxc_set_t, which guarantees uniqueness.
 *
 * @param[in] var Variant container to iterate. Each entry is expected to expose a `"server"` key
 *                containing a C string.
 *
 * @return A newly allocated set containing the unique server strings, or @c NULL if no valid
 *         `"server"` values were present.
 *
 * @note Ownership of the returned set is transferred to the caller, who must delete it using the
 *       appropriate amxc_set cleanup function.
 */
amxc_set_t* aggregate_servers(amxc_var_t* var) {
    amxc_set_t* set = NULL;

    amxc_var_for_each(server_var, var) {
        const char* server = GET_CHAR(server_var, "server");
        if(string_empty(server)) {
            continue;
        }

        if(set == NULL) {
            amxc_set_new(&set, false);
        }

        amxc_set_add_flag(set, server);
    }

    return set;
}