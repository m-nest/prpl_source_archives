/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <upnp/upnp.h>
#include <string.h>
#include <stdlib.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>
#include <hosts/client.h>
#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"
#include "tr181-description.h"

#define ME "dm-disc"

static char* discovery_service_get_uuid_from_usn(amxd_object_t* service) {
    char* uuid = NULL;
    const char* usn = GET_CHAR(amxd_object_get_param_value(service, "USN"), NULL);
    const char* tmp = NULL;
    uint32_t len = 0;

    when_str_empty(usn, exit);
    when_false(strlen(usn) >= (strlen(UUID_LABEL) + UUID_LEN), exit);
    when_null(strstr(usn, UUID_LABEL), exit);
    when_null(strstr(usn, UUID_LABEL), exit);
    tmp = strstr(usn, UUID_LABEL) + strlen(UUID_LABEL);
    when_str_empty(tmp, exit);
    len = (strchr(tmp, ':') != NULL) ? (uint32_t) (strchr(tmp, ':') - tmp) : strlen(tmp);
    uuid = malloc(sizeof(*uuid) * (len + 1));
    when_null(uuid, exit);
    strncpy(uuid, tmp, len);
    uuid[len] = '\0';
exit:
    return uuid;
}

static int discovery_service_update_parent_path(amxd_object_t* service) {
    int rv = -1;
    amxd_object_t* parent = NULL;
    char* service_uuid;
    amxc_string_t parent_path;

    amxc_string_init(&parent_path, 0);
    service_uuid = discovery_service_get_uuid_from_usn(service);
    when_null(service_uuid, exit);
    parent = upnp_disc_get_item_by_key(amxd_dm_findf(get_dm(), UPNP_DISCOVERY_DEVICE_OBJ_PATH), service_uuid, "UUID");
    if(!parent) {
        parent = upnp_disc_get_item_by_key(amxd_dm_findf(get_dm(), UPNP_DISCOVERY_ROOTDEVICE_OBJ_PATH), service_uuid, "UUID");
        when_null(parent, exit);
        amxc_string_setf(&parent_path, "%s%d", UPNP_DISCOVERY_ROOTDEVICE_USP_PATH, amxd_object_get_index(parent));
    } else {
        amxc_string_setf(&parent_path, "%s%d", UPNP_DISCOVERY_DEVICE_USP_PATH, amxd_object_get_index(parent));
    }
    when_failed(amxd_object_set_cstring_t(service, "ParentDevice", amxc_string_get(&parent_path, 0)), exit);
    rv = 0;
exit:
    amxc_string_clean(&parent_path);
    free(service_uuid);
    return rv;
}

static int set_status(amxd_object_t* object, const char* status) {
    amxd_trans_t trans;
    int rv = -1;

    when_failed_trace(amxd_trans_init(&trans), exit, ERROR, "amxd_trans_init failed");
    when_failed_trace(amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true), clean, ERROR, "amxd_trans_set_attr failed");
    when_failed_trace(amxd_trans_select_object(&trans, object), clean, ERROR, "amxd_trans_select_object failed");
    when_failed_trace(amxd_trans_set_value(cstring_t, &trans, "Status", status), clean, ERROR, "amxd_trans_set_value failed");

    rv = amxd_trans_apply(&trans, get_dm());

clean:
    amxd_trans_clean(&trans);
exit:
    return rv;
}

static int set_last_update(amxd_object_t* object, amxc_ts_t* ts) {
    amxd_trans_t trans;
    int rv = -1;

    when_failed_trace(amxd_trans_init(&trans), exit, ERROR, "amxd_trans_init failed");
    when_failed_trace(amxd_trans_select_object(&trans, object), clean, ERROR, "amxd_trans_select_object failed");
    when_failed_trace(amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true), clean, ERROR, "amxd_trans_set_attr failed");
    when_failed_trace(amxd_trans_set_amxc_ts_t(&trans, "LastUpdate", ts), clean, ERROR, "amxd_trans_set_value failed");

    rv = amxd_trans_apply(&trans, get_dm());

clean:
    amxd_trans_clean(&trans);
exit:
    return rv;
}

static void upnp_discovery_lease_expired(UNUSED amxp_timer_t* timer, void* priv) {
    amxd_object_t* object = (amxd_object_t*) priv;

    set_status(object, "LeaseExpired");
    SAH_TRACEZ_NOTICE(ME, "%s: UPnP Discovery item lease has expired", GET_CHAR(amxd_object_get_param_value(object, "USN"), NULL));
}

static void upnp_discovery_item_start_lease_timer(amxd_object_t* item, int64_t diff_sec) {
    upnp_discovery_item_t* data = (upnp_discovery_item_t*) item->priv;

    when_null_trace(data, exit, ERROR, "Trying to start a lease timer for an uninitialized object: %s", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
    if(data->lease == NULL) {
        amxp_timer_new(&data->lease, upnp_discovery_lease_expired, item);
    }
    amxp_timer_start(data->lease, diff_sec * 1000);
    SAH_TRACEZ_INFO(ME, "%s: UPnP Discovery item lease timer has started", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
exit:
    return;
}

static void upnp_discovery_item_start_lease(amxd_object_t* item) {
    amxc_ts_t now;
    amxc_ts_t* last_update;

    last_update = amxc_var_dyncast(amxc_ts_t, amxd_object_get_param_value(item, "LastUpdate"));
    when_null_trace(last_update, exit, ERROR, "%s: LastUpdate is NULL", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
    last_update->sec += GET_UINT32(amxd_object_get_param_value(item, "LeaseTime"), NULL);
    amxc_ts_now(&now);
    switch(amxc_ts_compare(&now, last_update)) {
    case 1:
        set_status(item, "LeaseExpired");
        break;
    case -1:
        upnp_discovery_item_start_lease_timer(item, last_update->sec - now.sec);
        break;
    case 0:
    default:
        SAH_TRACEZ_ERROR(ME, "Time manipulation LastUpdate + LeaseTime failed");
    }
exit:
    free(last_update);
    return;
}

void upnp_discovery_item_alive(amxd_object_t* item) {
    amxc_ts_t now;

    when_null(item, exit);
    amxc_ts_now(&now);
    set_last_update(item, &now);
    if(strcmp(GET_CHAR(amxd_object_get_param_value(item, "Status"), NULL), "LeaseActive") != 0) {
        SAH_TRACEZ_NOTICE(ME, "%s: Item is back alive", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
        set_status(item, "LeaseActive");
    }
    upnp_discovery_item_start_lease_timer(item, GET_UINT32(amxd_object_get_param_value(item, "LeaseTime"), NULL));
exit:
    return;
}

static void upnp_discovery_item_stop_lease_timer(amxd_object_t* item) {
    upnp_discovery_item_t* data = (upnp_discovery_item_t*) item->priv;

    when_null_trace(data, exit, ERROR, "Trying to stop a lease timer for an uninitialized object");
    if(data->lease != NULL) {
        amxp_timer_stop(data->lease);
    }
    SAH_TRACEZ_INFO(ME, "%s: UPnP Discovery item lease timer has been stopped", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
exit:
    return;
}

void upnp_discovery_item_byebye(amxd_object_t* item) {
    amxc_ts_t now;

    when_null(item, exit);
    SAH_TRACEZ_NOTICE(ME, "%s: Byebye Received", GET_CHAR(amxd_object_get_param_value(item, "USN"), NULL));
    amxc_ts_now(&now);
    set_last_update(item, &now);
    set_status(item, "ByebyeReceived");
    upnp_discovery_item_stop_lease_timer(item);
exit:
    return;
}

upnp_discovery_item_t* upnp_discovery_item_new(void) {
    upnp_discovery_item_t* item = NULL;

    item = malloc(sizeof(*item));
    if(item) {
        memset(item, 0, sizeof(*item));
    }
    return item;
}

void upnp_discovery_item_delete(amxd_object_t* object) {
    upnp_discovery_item_t* item = NULL;

    when_null(object, exit);
    when_null(object->priv, exit);
    item = (upnp_discovery_item_t*) object->priv;
    if(item->lease) {
        amxp_timer_delete(&item->lease);
    }
    free(item);
    object->priv = NULL;
exit:
    return;
}


amxd_status_t _dm_discovery_item_destroyed(amxd_object_t* object,
                                           UNUSED amxd_param_t* param,
                                           amxd_action_t reason,
                                           UNUSED const amxc_var_t* const args,
                                           amxc_var_t* const retval,
                                           UNUSED void* priv) {
    amxd_status_t status = amxd_status_ok;

    if(reason != action_object_destroy) {
        status = amxd_status_function_not_implemented;
        goto leave;
    }
    upnp_discovery_item_delete(object);
    amxc_var_clean(retval);
leave:
    return status;
}

void upnp_discovery_service_added(amxd_object_t* service) {
    when_not_null(service->priv, exit);
    service->priv = upnp_discovery_item_new();
    when_null(service->priv, exit);
    if(discovery_service_update_parent_path(service)) {
        SAH_TRACEZ_ERROR(ME, "Service parent device couldn't be found (%s)", GET_CHAR(amxd_object_get_param_value(service, "USN"), NULL));
    }
    upnp_discovery_item_start_lease(service);
exit:
    return;
}

static void upnp_discovery_check_description_service(amxd_object_t* service) {
    amxd_object_t* desc_serv = NULL;

    when_null(service, exit);
    desc_serv = amxd_dm_findf(get_dm(), "UPnPDescription.ServiceInstance.[ServiceType in \"%s\"].",
                              GET_CHAR(amxd_object_get_param_value(service, "USN"), NULL));
    when_null(desc_serv, exit);
    upnp_description_update_service_discovery(desc_serv);
exit:
    return;
}

static bool hostquery_is_host_deleted(const amxc_var_t* data) {
    bool deleted = false;
    const char* notification = NULL;

    notification = GETP_CHAR(data, "notification");
    when_null_trace(notification, exit, ERROR, "NULL");
    deleted = (strcmp(notification, "dm:instance-removed") == 0);

exit:
    return deleted;
}

static int reset_host(const amxd_object_t* device) {
    amxd_trans_t* trans = NULL;
    int rv = -1;

    when_failed_trace(amxd_trans_new(&trans), exit, ERROR, "amxd_trans_new failed");
    when_failed_trace(amxd_trans_set_attr(trans, amxd_tattr_change_ro, true), clean, ERROR, "amxd_trans_set_attr failed");
    when_failed_trace(amxd_trans_select_object(trans, device), clean, ERROR, "amxd_trans_select_object failed");
    when_failed_trace(amxd_trans_set_value(cstring_t, trans, "Host", ""), clean, ERROR, "amxd_trans_set_value failed");

    rv = amxd_trans_apply(trans, get_dm());

clean:
    amxd_trans_delete(&trans);
exit:
    return rv;
}

static void open_hostquery_cb(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              void* const priv) {
    amxd_object_t* device = (amxd_object_t*) priv;

    if(hostquery_is_host_deleted(data) == true) {
        reset_host(device);
    }
    return;
}

static void upnp_discovery_host_subscription(amxd_object_t* obj) {
    char ip[IP_V4_LEN];

    if(sscanf(GET_CHAR(amxd_object_get_param_value(obj, "Location"), NULL), "http://%49[^:]:%*s", ip) == 1) {
        open_hostquery(ip, open_hostquery_cb, (void*) obj);
    }

    return;
}

void _upnp_discovery_service_added(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv) {
    amxd_object_t* service = NULL;

    service = amxd_dm_findf(get_dm(), "%s%d.", GET_CHAR(data, "object"), GET_UINT32(data, "index"));
    SAH_TRACEZ_NOTICE(ME, "%s: UPnP Discovery service has been added", GET_CHAR(amxd_object_get_param_value(service, "USN"), NULL));
    upnp_discovery_service_added(service);
    upnp_discovery_check_description_service(service);
    upnp_discovery_host_subscription(service);
}

void upnp_discovery_device_added(amxd_object_t* device) {
    when_not_null(device->priv, exit);
    device->priv = upnp_discovery_item_new();
    when_null(device->priv, exit);
    upnp_discovery_item_start_lease(device);
exit:
    return;
}

void upnp_discovery_check_device_services(amxd_object_t* device) {
    amxd_object_t* services = amxd_dm_findf(get_dm(), "UPnPDiscovery.Service.");
    const char* device_uuid = GET_CHAR(amxd_object_get_param_value(device, "UUID"), NULL);
    amxc_string_t path;

    amxc_string_init(&path, 0);
    amxc_string_setf(&path, "%s%d", UPNP_DISCOVERY_DEVICE_USP_PATH, amxd_object_get_index(device));
    amxd_object_for_each(instance, it, services) {
        amxd_object_t* service = amxc_container_of(it, amxd_object_t, it);
        amxc_var_t param;

        amxc_var_init(&param);
        if(strstr(GET_CHAR(amxd_object_get_param_value(service, "USN"), NULL), device_uuid) != 0) {
            amxc_var_set(cstring_t, &param, amxc_string_get(&path, 0));
            amxd_object_set_param(service, "ParentDevice", &param);
        }
        amxc_var_clean(&param);
    }
    amxc_string_clean(&path);
}

static void upnp_discovery_check_description_device(amxd_object_t* device) {
    amxd_object_t* desc_dev = NULL;

    when_null(device, exit);
    desc_dev = amxd_dm_findf(get_dm(), "UPnPDescription.DeviceInstance.[DeviceType in \"%s\"].",
                             GET_CHAR(amxd_object_get_param_value(device, "USN"), NULL));
    when_null(desc_dev, exit);
    upnp_description_update_device_discovery(desc_dev);
exit:
    return;
}

void _upnp_discovery_device_added(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  UNUSED void* const priv) {
    amxd_object_t* device = NULL;

    device = amxd_dm_findf(get_dm(), "%s%d.", GET_CHAR(data, "object"), GET_UINT32(data, "index"));
    SAH_TRACEZ_NOTICE(ME, "%s: UPnP Discovery device has been added", GET_CHAR(amxd_object_get_param_value(device, "USN"), NULL));
    upnp_discovery_device_added(device);
    upnp_discovery_check_device_services(device);
    upnp_discovery_check_description_device(device);
    upnp_discovery_host_subscription(device);
}