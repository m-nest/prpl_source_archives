/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#include <upnp/upnp.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_object.h>
#include <hosts/client.h>
#include "tr181-upnpdiscovery.h"
#include "tr181-discovery.h"

#define ME "disc"
#define BASE_RESTART_TIME 1000
#define MAX_RESTART_TIME 32000

int upnp_client_cb(Upnp_EventType type, const void* event, void* cookie);

static UpnpDevice_Handle upnp_hnd;
static bool upnp_initialized = false;
static amxp_timer_t* restart_timer;
static uint32_t restart_time = BASE_RESTART_TIME;

static void upnp_fill_data_with_event(amxc_var_t* data, const UpnpDiscovery* event) {
    amxc_string_t usn;

    when_null(event, exit);
    amxc_var_add_key(int32_t, data, UPNP_DISC_ERRCODE, UpnpDiscovery_get_ErrCode(event));
    amxc_var_add_key(int32_t, data, UPNP_DISC_EXPIRES, UpnpDiscovery_get_Expires(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_DEVID, UpnpDiscovery_get_DeviceID_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_DEVTYPE, UpnpDiscovery_get_DeviceType_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_SERVICETYPE, UpnpDiscovery_get_ServiceType_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_SERVICEVER, UpnpDiscovery_get_ServiceVer_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_LOCATION, UpnpDiscovery_get_Location_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_OS, UpnpDiscovery_get_Os_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_DATE, UpnpDiscovery_get_Date_cstr(event));
    amxc_var_add_key(cstring_t, data, UPNP_DISC_EXT, UpnpDiscovery_get_Ext_cstr(event));
    amxc_string_init(&usn, 0);
    if(!string_empty(GET_CHAR(data, UPNP_DISC_DEVTYPE))) {
        amxc_string_appendf(&usn, "%s::%s", GET_CHAR(data, UPNP_DISC_DEVID), GET_CHAR(data, UPNP_DISC_DEVTYPE));
    } else if(!string_empty(GET_CHAR(data, UPNP_DISC_SERVICETYPE))) {
        amxc_string_appendf(&usn, "%s::%s", GET_CHAR(data, UPNP_DISC_DEVID), GET_CHAR(data, UPNP_DISC_SERVICETYPE));
    } else {
        amxc_string_appendf(&usn, "%s", GET_CHAR(data, UPNP_DISC_DEVID));
    }
    amxc_var_push(cstring_t, amxc_var_add_new_key(data, UPNP_DISC_USN), amxc_string_take_buffer(&usn));
    amxc_string_clean(&usn);
exit:
    return;
}

int upnp_client_cb(Upnp_EventType type, const void* event, UNUSED void* cookie) {
    UpnpDiscovery* discovery = NULL;
    amxc_var_t data;

    switch(type) {
    case UPNP_DISCOVERY_SEARCH_RESULT:
    case UPNP_DISCOVERY_ADVERTISEMENT_ALIVE:
        discovery = (UpnpDiscovery*) event;
        amxc_var_init(&data);
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        upnp_fill_data_with_event(&data, discovery);
        amxp_sigmngr_emit_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_INFO, &data);
        amxc_var_clean(&data);
        break;
    case UPNP_DISCOVERY_ADVERTISEMENT_BYEBYE:
        discovery = (UpnpDiscovery*) event;
        amxc_var_init(&data);
        amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
        upnp_fill_data_with_event(&data, discovery);
        amxp_sigmngr_emit_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_BYEBYE, &data);
        amxc_var_clean(&data);
        break;
    case UPNP_DISCOVERY_SEARCH_TIMEOUT:
        break;
    default:
        SAH_TRACEZ_WARNING(ME, "Unhandled event type: %d", type);
    }
    return 0;
}

static bool upnp_disc_is_in_subnet(const amxc_var_t* data) {
    ipat_t upnp_ip;
    char ip_str[100] = {0};
    int port;
    bool in_range = false;

    ipat_initialize(&upnp_ip);
    when_str_empty(GET_CHAR(data, "location"), exit);
    sscanf(GET_CHAR(data, "location"), "http://%99[^:]:%d/", ip_str, &port);
    when_str_empty(ip_str, exit);
    ipat_pton(&upnp_ip, AF_INET_ANY, ip_str);
    amxc_llist_for_each(lan_range_it, get_lan_addrs()) {
        lan_range_t* lan_range = (lan_range_t*) amxc_llist_it_get_data(lan_range_it, lan_range_t, it);
        if(ipat_in_subnet(&upnp_ip, &lan_range->range)) {
            in_range = true;
            break;
        }
    }
exit:
    return in_range;
}

static upnp_discovery_type_e upnp_disc_get_item_type(const amxc_var_t* data) {
    upnp_discovery_type_e type = UPNP_DISCOVERY_TYPE_UNKNOWN;
    const char* usn = GET_CHAR(data, "usn");

    if(!string_empty(usn)) {
        if(strstr(usn, ":rootdevice") != NULL) {
            type = UPNP_DISCOVERY_TYPE_ROOTDEVICE;
        } else if(strstr(usn, ":device") != NULL) {
            type = UPNP_DISCOVERY_TYPE_DEVICE;
        } else if(strstr(usn, ":service") != NULL) {
            type = UPNP_DISCOVERY_TYPE_SERVICE;
        } else if((strncmp(usn, UUID_LABEL, strlen(UUID_LABEL)) == 0)) {
            type = UPNP_DISCOVERY_TYPE_ROOTDEVICE;
        }
    }
    return type;
}

amxd_object_t* upnp_disc_get_item_by_key(const amxd_object_t* list, const char* value, const char* key) {
    when_str_empty(key, exit);
    when_str_empty(value, exit);
    amxd_object_for_each(instance, obj_it, list) {
        amxd_object_t* obj = amxc_container_of(obj_it, amxd_object_t, it);
        const char* obj_value = GET_CHAR(amxd_object_get_param_value(obj, key), NULL);
        if(obj_value && (strcmp(obj_value, value) == 0)) {
            return obj;
        }
    }
exit:
    return NULL;
}

static amxd_object_t* upnp_disc_get_item(const amxc_var_t* data) {
    upnp_discovery_type_e type = upnp_disc_get_item_type(data);
    amxd_object_t* item = NULL;

    switch(type) {
    case UPNP_DISCOVERY_TYPE_ROOTDEVICE:
        item = upnp_disc_get_item_by_key(amxd_dm_findf(get_dm(), UPNP_DISCOVERY_ROOTDEVICE_OBJ_PATH), GET_CHAR(data, "device_id") + 5, "UUID");
        break;
    case UPNP_DISCOVERY_TYPE_DEVICE:
        item = upnp_disc_get_item_by_key(amxd_dm_findf(get_dm(), UPNP_DISCOVERY_DEVICE_OBJ_PATH), GET_CHAR(data, "device_id") + 5, "UUID");
        break;
    case UPNP_DISCOVERY_TYPE_SERVICE:
        item = upnp_disc_get_item_by_key(amxd_dm_findf(get_dm(), UPNP_DISCOVERY_SERVICE_OBJ_PATH), GET_CHAR(data, "usn"), "USN");
        break;
    default:
        break;
    }
    return item;
}

static int upnp_disc_fill_new_item_params(amxd_trans_t* trans, const amxc_var_t* data, upnp_discovery_type_e type) {
    int rv = -1;
    int ret = -1;
    amxc_ts_t ts;
    char ip[IP_V6_LEN];
    const char* tmp = NULL;
    const char* location = NULL;

    amxc_ts_now(&ts);
    if(type != UPNP_DISCOVERY_TYPE_SERVICE) {
        tmp = GET_CHAR(data, "device_id");
        when_str_empty(tmp, exit);
        tmp = strstr(tmp, UUID_LABEL);
        when_null(tmp, exit);
        amxd_trans_set_value(cstring_t, trans, "UUID", tmp + strlen(UUID_LABEL));
    }
    location = GET_CHAR(data, "location");
    amxd_trans_set_value(cstring_t, trans, "USN", GET_CHAR(data, "usn"));
    amxd_trans_set_value(uint32_t, trans, "LeaseTime", GET_UINT32(data, "expires"));
    amxd_trans_set_value(cstring_t, trans, "Location", location);
    amxd_trans_set_value(cstring_t, trans, "Server", GET_CHAR(data, "os"));
    amxd_trans_set_amxc_ts_t(trans, "LastUpdate", &ts);
    SAH_TRACEZ_INFO(ME, "Retreive host start");

    ret = sscanf(location, (strstr(location, "[") != NULL) ? "http://[%39[^]]]" : "http://%15[^:]", ip);

    if(ret == 1) {
        char* host = NULL;
        SAH_TRACEZ_INFO(ME, "Call get_host with ip: %s", ip);
        get_host(ip, &host);
        if(host != NULL) {
            amxd_trans_set_value(cstring_t, trans, "Host", host);
            free(host);
        }
    }
    SAH_TRACEZ_INFO(ME, "Retreive host end");
    rv = 0;
exit:
    return rv;
}

static int upnp_disc_add_item_to_dm(const amxc_var_t* data) {
    upnp_discovery_type_e type = upnp_disc_get_item_type(data);
    amxd_object_t* item_list = NULL;
    amxd_trans_t* trans;
    int rv = -1;

    amxd_trans_new(&trans);
    rv = amxd_trans_set_attr(trans, amxd_tattr_change_ro, true);
    switch(type) {
    case UPNP_DISCOVERY_TYPE_ROOTDEVICE:
        item_list = amxd_dm_findf(get_dm(), UPNP_DISCOVERY_ROOTDEVICE_OBJ_PATH);
        break;
    case UPNP_DISCOVERY_TYPE_DEVICE:
        item_list = amxd_dm_findf(get_dm(), UPNP_DISCOVERY_DEVICE_OBJ_PATH);
        break;
    case UPNP_DISCOVERY_TYPE_SERVICE:
        item_list = amxd_dm_findf(get_dm(), UPNP_DISCOVERY_SERVICE_OBJ_PATH);
        break;
    case UPNP_DISCOVERY_TYPE_UNKNOWN:
    default:
        SAH_TRACEZ_INFO(ME, "SSDP message has no type: %s", GET_CHAR(data, "usn"));
        rv = 0; // Don't mark it as an error
        goto exit;
        break;
    }
    when_null(item_list, exit);
    amxd_trans_select_object(trans, item_list);
    amxd_trans_add_inst(trans, 0, NULL);
    upnp_disc_fill_new_item_params(trans, data, type);
    rv = amxd_trans_apply(trans, get_dm());
exit:
    amxd_trans_delete(&trans);
    return rv;
}

static int set_location(amxd_object_t* object, const char* location) {
    amxd_trans_t trans;
    int rv = -1;

    when_failed_trace(amxd_trans_init(&trans), exit, ERROR, "amxd_trans_init failed");
    when_failed_trace(amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true), clean, ERROR, "amxd_trans_set_attr failed");
    when_failed_trace(amxd_trans_select_object(&trans, object), clean, ERROR, "amxd_trans_select_object failed");
    when_failed_trace(amxd_trans_set_value(cstring_t, &trans, "Location", location), clean, ERROR, "amxd_trans_set_value failed");

    rv = amxd_trans_apply(&trans, get_dm());

clean:
    amxd_trans_clean(&trans);
exit:
    return rv;
}

static int set_lease_time(amxd_object_t* object, uint32_t lease_time) {
    amxd_trans_t trans;
    int rv = -1;

    when_failed_trace(amxd_trans_init(&trans), exit, ERROR, "amxd_trans_init failed");
    when_failed_trace(amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true), clean, ERROR, "amxd_trans_set_attr failed");
    when_failed_trace(amxd_trans_select_object(&trans, object), clean, ERROR, "amxd_trans_select_object failed");
    when_failed_trace(amxd_trans_set_value(uint32_t, &trans, "LeaseTime", lease_time), clean, ERROR, "amxd_trans_set_value failed");

    rv = amxd_trans_apply(&trans, get_dm());

clean:
    amxd_trans_clean(&trans);
exit:
    return rv;
}

static void upnp_disc_update_item_info(amxd_object_t* item, UNUSED const amxc_var_t* data) {
    if(strcmp(GET_CHAR(data, UPNP_DISC_LOCATION), GET_CHAR(amxd_object_get_param_value(item, "Location"), NULL)) != 0) {
        set_location(item, GET_CHAR(data, UPNP_DISC_LOCATION));
    }
    if(GET_UINT32(data, UPNP_DISC_EXPIRES) != GET_UINT32(amxd_object_get_param_value(item, "LeaseTime"), NULL)) {
        set_lease_time(item, GET_UINT32(data, UPNP_DISC_EXPIRES));
    }
    upnp_discovery_item_alive(item);
}

static void upnp_disc_info(UNUSED const char* sig_name, const amxc_var_t* data, UNUSED void* priv) {
    amxd_object_t* item = NULL;

    if(upnp_disc_is_in_subnet(data)) {
        item = upnp_disc_get_item(data);
        if(item == NULL) {
            if(upnp_disc_add_item_to_dm(data) != 0) {
                SAH_TRACEZ_ERROR(ME, "Couldn't add new item to the data-model: %s", GET_CHAR(data, "usn"));
            }
        } else {
            upnp_disc_update_item_info(item, data);
        }
    }
}

static void upnp_disc_byebye(UNUSED const char* sig_name, UNUSED const amxc_var_t* data, UNUSED void* priv) {
    amxd_object_t* item = NULL;

    item = upnp_disc_get_item(data);
    if(item != NULL) {
        upnp_discovery_item_byebye(item);
    } else {
        SAH_TRACEZ_ERROR(ME, "Byebye receive for non-existing UPnP item: %s", GET_CHAR(data, "usn"));
    }
}

static void upnp_discovery_restart(UNUSED amxp_timer_t* timer, UNUSED void* priv) {
    upnp_discovery_start();
}

int upnp_discovery_init(void) {
    int rv = -1;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    hosts_initialize();

    when_failed(amxp_sigmngr_add_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_INFO), exit);
    when_failed(amxp_sigmngr_add_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_BYEBYE), exit);
    when_failed(amxp_slot_connect(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_INFO, NULL, upnp_disc_info, NULL), exit);
    when_failed(amxp_slot_connect(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_BYEBYE, NULL, upnp_disc_byebye, NULL), exit);
    when_failed(amxp_timer_new(&restart_timer, upnp_discovery_restart, NULL), exit);
    rv = 0;
exit:
    return rv;
}

int upnp_discovery_start(void) {
    int rv = -1;
    const char* intf = get_lan_intf();

    when_str_empty(intf, check_error);
    if(upnp_initialized) {
        upnp_discovery_stop();
    }
    rv = UpnpInit2(intf, 0);
    when_failed_trace(rv, check_error, ERROR, "Couldn't initialize libupnp: %d", rv);
    upnp_initialized = true;
    when_failed_trace(UpnpRegisterClient(upnp_client_cb, NULL, &upnp_hnd), exit, ERROR, "Couldn't register the plugin as a upnp client");
    when_failed_trace(UpnpSearchAsync(upnp_hnd, 0, "ssdp:all", NULL), exit, ERROR, "Couldn't start ssdp device search");
    rv = 0;
check_error:
    if(rv != UPNP_E_SUCCESS) {
        amxp_timer_start(restart_timer, restart_time);
        SAH_TRACEZ_ERROR(ME, "Error while initializing libupnp (%d): retry in %dsec(s)...", rv, restart_time / 1000);
        restart_time = ((restart_time >= MAX_RESTART_TIME) ? (MAX_RESTART_TIME) : (restart_time * 2));
    } else {
        restart_time = BASE_RESTART_TIME;
    }
exit:
    return rv;
}

int upnp_discovery_cleanup(void) {
    amxp_signal_t* sig;

    amxp_timer_delete(&restart_timer);
    sig = amxp_sigmngr_find_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_INFO);
    amxp_signal_delete(&sig);
    sig = amxp_sigmngr_find_signal(&get_dm()->sigmngr, UPNP_SIGNAL_DISC_BYEBYE);
    amxp_signal_delete(&sig);

    hosts_cleanup();
    curl_global_cleanup();

    return 0;
}

void upnp_discovery_stop(void) {
    if(upnp_initialized) {
        if(UpnpUnRegisterClient(upnp_hnd) != UPNP_E_SUCCESS) {
            SAH_TRACEZ_WARNING(ME, "Couldn't unregister the plugin from being a client");
        }
        upnp_hnd = 0;
        UpnpFinish();
        upnp_initialized = false;
    }
}