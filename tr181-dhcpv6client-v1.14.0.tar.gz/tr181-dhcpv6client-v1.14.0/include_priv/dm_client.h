/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__DM_CLIENT_H__)
#define __DM_CLIENT_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "dhcpv6client.h"

typedef enum _dhcpv6c_status {
    dhcpv6c_status_disabled,
    dhcpv6c_status_enabled,
    dhcpv6c_status_error_misconfigure,
    dhcpv6c_status_last
} dhcpv6c_status_t;

typedef enum _dhcpv6c_action {
    DHCPV6_ACTION_TIMING,
    DHCPV6_ACTION_STARTED,
    DHCPV6_ACTION_INFORMED,
    DHCPV6_ACTION_BOUND,
    DHCPV6_ACTION_REBOUND,
    DHCPV6_ACTION_RENEWED,
    DHCPV6_ACTION_RECONFIGURED,
    DHCPV6_ACTION_UNBOUND,
    DHCPV6_ACTION_STOPPED,
    DHCPV6_ACTION_NB
} dhcpv6c_action_t;

void dm_client_status(amxd_object_t* client, dhcpv6c_status_t status);
void dm_client_dhcp_status(amxd_object_t* client, dhcpv6c_action_t action);
void dm_client_set_ia_status(amxd_object_t* client, amxc_var_t* data);
amxd_object_t* dm_get_client(amxc_var_t* args);
void dm_client_init(amxd_object_t* client);

#ifdef __cplusplus
}
#endif

#endif // __DM_CLIENT_H__
