/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <string.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "ethernet.h"
#include "ethernet_utils.h"
#include "ethernet_soc_utils.h"
#include "ethernet_sfp.h"

#define ME "sfp"
#define BUS_TIMEOUT 5

/**
 * @brief
 * Helper to update the intern structure of an ethernet interface with an sfp interface
 *
 * @param ethernet The ethernet internal structure to update
 * @param sfp_path the path to the sfp data model
 *
 * @return
 * 0 on success
 */
static int ethernet_sfp_update(ethernet_info_t* ethernet, const char* sfp_path) {
    SAH_TRACEZ_IN(ME);
    amxb_bus_ctx_t* ctx = NULL;
    int rv = -1;
    amxc_var_t data;
    amxc_var_t l_sfp_supported_type;
    const amxc_var_t* sfp_supported_type = NULL;
    const char* sfp_type = NULL;
    bool sfp_present = false;
    bool sfp_type_ok = false;

    amxc_var_init(&data);
    amxc_var_init(&l_sfp_supported_type);

    when_null_trace(ethernet, exit, ERROR, "Ethernet structure should not be NULL");
    when_null_trace(ethernet->object, exit, ERROR, "Ethernet interface object should not be NULL");
    when_str_empty_trace(sfp_path, check, ERROR, "SFP path should not be empty");

    ctx = amxb_be_who_has("SFPs.");
    when_null_trace(ctx, exit, ERROR, "Failed to get bus context for SFPs");

    rv = amxb_get(ctx, sfp_path, 0, &data, BUS_TIMEOUT);
    when_failed_trace(rv, check, ERROR, "Failed to get SFP '%s'", sfp_path);

    sfp_present = GETP_BOOL(&data, "0.0.SFPPresent");
    sfp_type = GETP_CHAR(&data, "0.0.SFPType");
    when_str_empty_trace(sfp_type, check, ERROR, "SFPType is empty for SFP '%s'", sfp_path);

    if(sfp_present) {
        // Check if the SFP type is the one expected
        sfp_supported_type = amxd_object_get_param_value(ethernet->object, "SFPSupportedType");
        rv = amxc_var_convert(&l_sfp_supported_type, sfp_supported_type, AMXC_VAR_ID_LIST);
        when_failed_trace(rv, check, ERROR, "Failed to convert SFPSupportedType variant to list");
        amxc_var_for_each(type, &l_sfp_supported_type) {
            const char* type_str = GET_CHAR(type, NULL);
            if(!str_empty(type_str) && (strcmp(type_str, sfp_type) == 0)) {
                sfp_type_ok = true;
                break;
            }
        }
    }

check:
    if(sfp_type_ok) {
        SAH_TRACEZ_INFO(ME, "SFP %s is ready", sfp_path);
        ethernet_interface_init(ethernet);
    } else {
        SAH_TRACEZ_INFO(ME, "SFP %s not ready (SFPType : %s, SFPPresent : %d)", sfp_path, sfp_type, sfp_present);
        // Clean all subscriptions in case the cage is reconnected later
        amxs_sync_ctx_delete(&ethernet->sync_to_switch);
        amxs_sync_ctx_delete(&ethernet->sync_from_switch);
        amxs_sync_ctx_delete(&ethernet->sync_from_cpu_port);
        amxb_subscription_delete(&ethernet->netdev_status_subscription);
        amxb_subscription_delete(&ethernet->netdev_new_link_subscription);
        amxb_subscription_delete(&ethernet->netdev_mac_subscription);
        dm_ethernet_update_status(ethernet, "notpresent");
        dm_ethernet_interface_reset(ethernet);
    }

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&l_sfp_supported_type);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief
 * Callback function for when the referenced SFP cage changed
 *
 * @param sig_name The signa name send on the bus
 * @param data The data send on the bus
 * @param priv The private data send on the bus, this is a pointer to the corresponding ethernet internal structure
 */
static void _ethernet_sfp_cage_cb(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    SAH_TRACEZ_IN(ME);
    ethernet_info_t* ethernet = NULL;

    when_null_trace(priv, exit, ERROR, "Private data should contain ethernet info");
    ethernet = (ethernet_info_t*) priv;

    ethernet_sfp_update(ethernet, GETP_CHAR(data, "object"));
exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief
 * Subscribe to a sfp data model entry to sync with the ethernet internal structure
 *
 * @param ethernet The ethernet internal structure
 *
 * @return
 * 0 on success
 */
static int ethernet_sfp_subscribe(ethernet_info_t* ethernet) {
    SAH_TRACEZ_IN(ME);
    amxc_string_t sfp_path_dot;
    amxb_bus_ctx_t* ctx = NULL;
    int rv = -1;

    amxc_string_init(&sfp_path_dot, 0);

    when_null_trace(ethernet, exit, ERROR, "Ethernet structure should not be NULL");

    ctx = amxb_be_who_has("SFPs.");
    when_null_trace(ctx, exit, ERROR, "Failed to get bus context for SFPs");

    amxc_string_setf(&sfp_path_dot, "%s.", ethernet->sfp_path);
    amxb_subscription_delete(&(ethernet->sfp_subscription));
    amxb_subscription_new(&(ethernet->sfp_subscription), ctx, amxc_string_get(&sfp_path_dot, 0), "contains('parameters.SFPPresent')", _ethernet_sfp_cage_cb, ethernet);
    when_null_trace(ethernet->sfp_subscription, exit, WARNING, "Failed to create subscription for %s", amxc_string_get(&sfp_path_dot, 0));
    when_failed_trace(ethernet_sfp_update(ethernet, amxc_string_get(&sfp_path_dot, 0)), exit, ERROR, "Update Ethernet Status Failed !");

    rv = 0;
exit:
    amxc_string_clean(&sfp_path_dot);
    SAH_TRACEZ_OUT(ME);
    return rv;
}

/**
 * @brief
 * Callback for waiting the update of the sfp data model update
 *
 * @param signal The signal name send on the bus
 * @param data The data send on the bus
 * @param priv The ethernet internal structure corresponding to the sfp link
 */
static void ethernet_sfp_wait_done_cb(UNUSED const char* const signal,
                                      UNUSED const amxc_var_t* const data,
                                      void* const priv) {
    SAH_TRACEZ_IN(ME);
    ethernet_info_t* ethernet = (ethernet_info_t*) priv;
    amxb_bus_ctx_t* ctx = NULL;

    when_null_trace(ethernet, exit, ERROR, "Ethernet structure should not be NULL");
    amxp_slot_disconnect_with_priv(NULL, ethernet_sfp_wait_done_cb, ethernet);

    ctx = amxb_be_who_has("SFPs.");
    when_null_trace(ctx, exit, ERROR, "Failed to get bus context for SFPs");

    ethernet_sfp_subscribe(ethernet);

exit:
    SAH_TRACEZ_OUT(ME);
    return;
}

/**
 * @brief Create a new subscription on SFP cage referenced from SFPReferenceList that listen to SFP presence and type
 * @param ethernet pointer to the ethernet info structure where to store the subscription
 * @param sfp_path path to the SFP cage
 */
int ethernet_sfp_init(ethernet_info_t* ethernet, const char* sfp_path) {
    SAH_TRACEZ_IN(ME);
    amxb_bus_ctx_t* ctx = NULL;
    int rv = -1;

    when_null_trace(ethernet, exit, ERROR, "Ethernet structure should not be NULL");
    when_null_trace(sfp_path, exit, ERROR, "SFP path should not be NULL");

    free(ethernet->sfp_path);
    ethernet->sfp_path = strdup(sfp_path);
    when_null_trace(ethernet->sfp_path, exit, ERROR, "OOM: cannot allocate memory");

    ctx = amxb_be_who_has("SFPs.");
    if(ctx == NULL) {
        amxp_slot_connect_filtered(NULL, "^wait:SFPs.$", NULL, ethernet_sfp_wait_done_cb, ethernet);
        rv = amxb_wait_for_object("SFPs.");
        when_failed_trace(dm_ethernet_update_status(ethernet, "notpresent"), exit, ERROR, "Update Ethernet Status Failed !");
    } else {
        rv = ethernet_sfp_subscribe(ethernet);
    }

exit:
    SAH_TRACEZ_OUT(ME);
    return rv;
}