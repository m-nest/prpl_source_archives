/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

/* Related header */
#include "setup_and_teardown.h"

/* System headers */
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

/* Other libraries' headers */
#include <amxc/amxc_macros.h> /* when_false() */
#include <amxd/amxd_dm.h>     /* amxd_dm_init() */
#include <amxo/amxo.h>        /* amxo_parser_init() */

/* Own headers */
#include "common_functions.h" /* handle_events() */
#include "dm_events.h"        /* _sfp_mgr_app_start() */
#include "sfpmgr_main.h"      /* _sfpmgr_main() */

static const char* const odl_file = "../common/tr181-sfp_test.odl";

/**
 * Do some setup common among the unit tests.
 *
 * @param[in,out] dm: data model
 * @param[in,out] parser
 * @param[in] invoke_main_entry_point: if true, call _sfpmgr_main() with
 *                                     AMXO_START as reason
 * @param[in] extra_odl_file: path to extra odl file to load. This is typically
 *     a file with default values, e.g. a file with entries to add to the SFP DB
 *     in the SFP DM.
 *
 * The function:
 * - initializes the DM and the parser
 * - loads ../common/tr181-sfp_test.odl and the odl files it includes
 * - loads @a extra_odl_file if not NULL
 * - returns 0 now if @a invoke_main_entry_point is false
 * - calls _sfpmgr_main(AMXO_START, ..)
 * - sends the app:start event
 * - calls handle_events() to trigger _sfp_mgr_app_start(), which is the event
 *   handler for the app:start event
 *
 * @return 0
 */
static int do_setup_common(amxd_dm_t* dm, amxo_parser_t* parser,
                           bool invoke_main_entry_point,
                           const char* extra_odl_file) {
    amxd_object_t* root_obj = NULL;

    sahTraceOpen("mytest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "sfpmgr");
    sahTraceAddZone(500, "runtest");

    assert_int_equal(amxd_dm_init(dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(parser), 0);

    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    /* events */
    assert_int_equal(amxo_resolver_ftab_add(parser, "sfp_mgr_app_start", AMXO_FUNC(_sfp_mgr_app_start)), 0);

    assert_int_equal(amxo_parser_parse_file(parser, odl_file, root_obj), 0);

    if(extra_odl_file) {
        assert_int_equal(amxo_parser_parse_file(parser, extra_odl_file, root_obj), 0);
    }

    when_false(invoke_main_entry_point, exit);

    const int rc = _sfpmgr_main(AMXO_START, dm, parser);
    assert_int_equal(rc, 0);

    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);
    handle_events();

exit:
    return 0;
}

/**
 * Do some setup common among the unit tests.
 *
 * @param[in,out] dm: data model
 * @param[in,out] parser
 * @param[in] invoke_main_entry_point: if true, call _sfpmgr_main() with
 *                                     AMXO_START as reason
 *
 * The function:
 * - initializes the DM and the parser
 * - loads ../common/tr181-sfp_test.odl and the odl files it includes
 * - returns 0 now if @a invoke_main_entry_point is false
 * - calls _sfpmgr_main(AMXO_START, ..)
 * - sends the app:start event
 * - calls handle_events() to trigger _sfp_mgr_app_start(), which is the event
 *   handler for the app:start event
 *
 * @return 0
 */
int setup_common(amxd_dm_t* dm, amxo_parser_t* parser,
                 bool invoke_main_entry_point) {

    return do_setup_common(dm, parser, invoke_main_entry_point, NULL);
}

/**
 * Do the same as setup_common() but pass extra odl file to load.
 *
 * @param[in,out] dm: data model
 * @param[in,out] parser
 * @param[in] invoke_main_entry_point: if true, call _sfpmgr_main() with
 *                                     AMXO_START as reason
 * @param[in] extra_odl_file: path to extra odl file to load. This is typically
 *     a file with default values, e.g. a file with entries to add to the SFP DB
 *     in the SFP DM. If you don't need this, call  setup_common() instead.
 *
 * See do_setup_common() for extra doc.
 *
 * @return 0
 */
int setup_common_with_extra_odl(amxd_dm_t* dm, amxo_parser_t* parser,
                                bool invoke_main_entry_point,
                                const char* extra_odl_file) {
    return do_setup_common(dm, parser, invoke_main_entry_point, extra_odl_file);
}

/**
 * Do some teardown common among the unit tests.
 *
 * @param[in,out] dm: data model
 * @param[in,out] parser
 * @param[in] invoke_main_entry_point: if true, call _sfpmgr_main() with
 *                                     AMXO_STOP as reason
 *
 * The function:
 * - calls _sfpmgr_main(AMXO_STOP, ..) if @a invoke_main_entry_point is true
 * - cleans up the parser and the DM
 *
 * @return 0
 */
int teardown_common(amxd_dm_t* dm, amxo_parser_t* parser,
                    bool invoke_main_entry_point) {
    if(invoke_main_entry_point) {
        const int rc = _sfpmgr_main(AMXO_STOP, dm, parser);
        assert_int_equal(rc, 0);
    }
    amxo_parser_clean(parser);
    amxd_dm_clean(dm);
    return 0;
}

