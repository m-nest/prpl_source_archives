#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc_macros.h>

#include <amxut/amxut_bus.h>

#include "test_helpers.h"

#include "mod_usb_filter.h"
#include "helpers.h"

int test_setup(void** state) {
    amxut_bus_setup(state);

    assert_int_equal(_filter_main(AMXO_START, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_filter_main(AMXO_STOP, amxut_bus_dm(), amxut_bus_parser()), 0);

    amxut_bus_teardown(state);

    return 0;
}

void test_set_hex_value(UNUSED void** state) {
    char* result = NULL;

    result = set_hex_value("FF:02:02,*E:FB:*");
    assert_string_equal(result, "FF:02:02,*E:FB:*");
    free(result);

    result = set_hex_value(NULL);
    assert_string_equal(result, "");
    free(result);

    result = set_hex_value("FF");
    assert_string_equal(result, "FF");
    free(result);

    result = set_hex_value("ABCDEFgh");
    assert_string_equal(result, "ABCDEFgh");
    free(result);

    result = set_hex_value("");
    assert_string_equal(result, "");
    free(result);
}

void test_int_to_hex_value(UNUSED void** state) {
    char* result = NULL;

    result = int_to_hex_value(0);
    assert_string_equal(result, "0");
    free(result);

    result = int_to_hex_value(5);
    assert_string_equal(result, "5");
    free(result);

    result = int_to_hex_value(2049);
    assert_string_equal(result, "801");
    free(result);

    result = int_to_hex_value(11);
    assert_string_equal(result, "B");
    free(result);

    result = int_to_hex_value(11388);
    assert_string_equal(result, "2C7C");
    free(result);

    result = int_to_hex_value(65535);
    assert_string_equal(result, "FFFF");
    free(result);

    result = int_to_hex_value(0x1FFFF);
    assert_string_equal(result, "");
    free(result);
}

void test_create_usb_device_interface(UNUSED void** state) {
    usb_device_interface_t intf;

    intf = create_usb_device_interface("FF:02:01");
    assert_string_equal(intf.interface_class, "FF");
    assert_string_equal(intf.interface_subclass, "02");
    assert_string_equal(intf.interface_protocol, "01");
    usb_device_interface_clean(&intf);

    intf = create_usb_device_interface("1*:*:A5");
    assert_string_equal(intf.interface_class, "1*");
    assert_string_equal(intf.interface_subclass, "*");
    assert_string_equal(intf.interface_protocol, "A5");
    usb_device_interface_clean(&intf);

    intf = create_usb_device_interface("*:");
    assert_string_equal(intf.interface_class, "*");
    assert_string_equal(intf.interface_subclass, "");
    assert_string_equal(intf.interface_protocol, "");
    usb_device_interface_clean(&intf);
}

void test_valid_hex_value(UNUSED void** state) {
    /* Exact matches */
    assert_true(is_valid_hex_number("54", "54"));
    assert_false(is_valid_hex_number("54", "53"));

    /* Wildcard last char */
    assert_true(is_valid_hex_number("5*", "54"));
    assert_true(is_valid_hex_number("5*", "5A"));
    assert_true(is_valid_hex_number("5*", "50"));
    assert_false(is_valid_hex_number("5*", "60"));

    /* Wildcard first char */
    assert_true(is_valid_hex_number("*4", "54"));
    assert_true(is_valid_hex_number("*4", "A4"));
    assert_false(is_valid_hex_number("*4", "AB"));

    /* All wildcards */
    assert_true(is_valid_hex_number("**", "54"));
    assert_true(is_valid_hex_number("**", "FF"));

    /* 3-character tests */
    assert_true(is_valid_hex_number("ABC", "ABC"));
    assert_true(is_valid_hex_number("AB*", "ABE"));
    assert_true(is_valid_hex_number("A*F", "ACF"));
    assert_false(is_valid_hex_number("A*F", "AB0"));
    assert_true(is_valid_hex_number("*B*", "1B2"));
    assert_true(is_valid_hex_number("*B*", "ABF"));
    assert_false(is_valid_hex_number("*B*", "AXY"));
    assert_true(is_valid_hex_number("***", "1A2"));   /* All wildcard */
    assert_true(is_valid_hex_number("***", "FFF"));
    assert_true(is_valid_hex_number("*A*", "BA9"));   /* Middle fixed */
    assert_false(is_valid_hex_number("*A*", "B0C"));  /* Middle mismatch */
    assert_true(is_valid_hex_number("**C", "99C"));   /* Last fixed */
    assert_false(is_valid_hex_number("**C", "99D"));  /* Last mismatch */
    assert_true(is_valid_hex_number("A**", "A1B"));   /* First fixed */
    assert_false(is_valid_hex_number("A**", "B1B"));  /* First mismatch */

    /* 4-character tests */
    assert_true(is_valid_hex_number("1234", "1234"));
    assert_true(is_valid_hex_number("12*4", "12A4"));
    assert_true(is_valid_hex_number("1**4", "1FF4"));
    assert_true(is_valid_hex_number("****", "9ABC"));
    assert_true(is_valid_hex_number("*2*4", "A2B4"));  /* Wildcards at edges */
    assert_false(is_valid_hex_number("*2*4", "A3B4")); /* Middle mismatch */
    assert_true(is_valid_hex_number("**3*", "AB3F"));  /* Two wildcards start */
    assert_false(is_valid_hex_number("**3*", "AB4F")); /* Fixed char mismatch */
    assert_true(is_valid_hex_number("*B**", "1B34"));  /* Second char fixed */
    assert_false(is_valid_hex_number("*B**", "1C34")); /* Second char mismatch */

    /* Length mismatches */
    assert_false(is_valid_hex_number("12*4", "12"));
    assert_false(is_valid_hex_number("AB", "ABC"));
    assert_true(is_valid_hex_number("**1", "1"));
    assert_true(is_valid_hex_number("*A*", "A1"));
    assert_true(is_valid_hex_number("**A*C3", "1A5C3"));
    assert_true(is_valid_hex_number("****3", "A5C3"));
    assert_true(is_valid_hex_number("****3", "5C3"));
    assert_true(is_valid_hex_number("****3", "C3"));
    assert_true(is_valid_hex_number("****3", "3"));

    /* Case-insensitivity */
    assert_true(is_valid_hex_number("A*", "aF"));
    assert_true(is_valid_hex_number("AB", "ab"));
}
