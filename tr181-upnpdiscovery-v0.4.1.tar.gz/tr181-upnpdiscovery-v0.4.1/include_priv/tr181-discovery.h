/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef __TR181_DISCOVERY_H__
#define __TR181_DISCOVERY_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <sys/socket.h>
#include <net/ethernet.h>
#include <ipat/ipat.h>
#include <amxp/amxp.h>
#include <amxc/amxc.h>
#include <amxd/amxd_object.h>

#define UUID_LEN 36
#define UUID_LABEL "uuid:"

#define IP_V4_LEN 16
#define IP_V6_LEN 40

#define UPNP_DISC_ERRCODE "error_code"
#define UPNP_DISC_EXPIRES "expires"
#define UPNP_DISC_DEVID "device_id"
#define UPNP_DISC_DEVTYPE "device_type"
#define UPNP_DISC_SERVICETYPE "service_type"
#define UPNP_DISC_SERVICEVER "service_version"
#define UPNP_DISC_LOCATION "location"
#define UPNP_DISC_OS "os"
#define UPNP_DISC_DATE "date"
#define UPNP_DISC_EXT "ext"
#define UPNP_DISC_USN "usn"

#define UPNP_SIGNAL_DISC_INFO "disc_info"
#define UPNP_SIGNAL_DISC_BYEBYE "disc_byebye"

typedef enum {
    UPNP_DISCOVERY_TYPE_ROOTDEVICE = 0,
    UPNP_DISCOVERY_TYPE_DEVICE,
    UPNP_DISCOVERY_TYPE_SERVICE,
    UPNP_DISCOVERY_TYPE_UNKNOWN
} upnp_discovery_type_e;

#define UPNP_DISCOVERY_ROOTDEVICE_OBJ_PATH "UPnPDiscovery.RootDevice."
#define UPNP_DISCOVERY_DEVICE_OBJ_PATH "UPnPDiscovery.Device."
#define UPNP_DISCOVERY_SERVICE_OBJ_PATH "UPnPDiscovery.Service."
#define UPNP_DISCOVERY_DEVICE_USP_PATH "Device.UPnP.Discovery.Device."
#define UPNP_DISCOVERY_SERVICE_USP_PATH "Device.UPnP.Discovery.Service."
#define UPNP_DISCOVERY_ROOTDEVICE_USP_PATH "Device.UPnP.Discovery.RootDevice."
#define UPNP_DESCRIPTION_DEVICE_USP_PATH "Device.UPnP.Description.DeviceInstance."

/**
 * @brief Structure representing a LAN IP range.
 *
 * Contains an iterator and an IP address range.
 */
typedef struct lan_range_s {
    amxc_llist_it_t it;   /**< Iterator for linked list traversal */
    ipat_t range;         /**< IP address range */
} lan_range_t;

/**
 * @brief Structure representing a UPnP discovery item.
 *
 * Contains a timer for lease management.
 */
typedef struct upnp_discovery_item_s {
    amxp_timer_t* lease; /**< Pointer to the lease timer */
} upnp_discovery_item_t;

/**
 * @brief Initializes the UPnP discovery subsystem.
 *
 * Sets up host management, registers the necessary UPnP discovery signals,
 * connects signal handlers for device discovery and byebye events, and
 * initializes a timer for restarting discovery if needed.
 *
 * @return Returns 0 on success, or a negative value on failure.
 */
int upnp_discovery_init(void);

/**
 * @brief Cleans up the UPnP discovery subsystem.
 *
 * Deletes the restart timer, removes registered UPnP discovery signals,
 * and performs host subsystem cleanup.
 *
 * @return Always returns 0.
 */
int upnp_discovery_cleanup(void);

/**
 * @brief Starts the UPnP discovery process.
 *
 * Initializes the UPnP library on the LAN interface, registers the plugin
 * as a UPnP client, and begins an asynchronous SSDP device search. If
 * initialization fails, a restart timer is started to retry discovery.
 *
 * @return Returns 0 on success, or a negative value if initialization fails.
 */
int upnp_discovery_start(void);

/**
 * @brief Stops the UPnP discovery process.
 *
 * Unregisters the plugin as a UPnP client, finalizes the UPnP library,
 * and marks the discovery subsystem as uninitialized.
 */
void upnp_discovery_stop(void);

/**
 * @brief Allocates and initializes a new UPnP discovery item.
 *
 * Allocates memory for a new @c upnp_discovery_item_t structure and
 * initializes all fields to zero.
 *
 * @return Pointer to the newly allocated and zero-initialized
 *         @c upnp_discovery_item_t structure, or NULL if allocation fails.
 */
upnp_discovery_item_t* upnp_discovery_item_new(void);

/**
 * @brief Deletes a UPnP discovery item and frees associated resources.
 *
 * Deletes the lease timer if it exists, frees the memory allocated for
 * the @c upnp_discovery_item_t structure, and clears the object's
 * private pointer.
 *
 * @param object The object containing the discovery item to delete.
 *               Must not be NULL.
 */
void upnp_discovery_item_delete(amxd_object_t* object);

/**
 * @brief Marks a UPnP discovery item as alive and resets its lease timer.
 *
 * Updates the last update timestamp of the given item, sets its status
 * to "LeaseActive" if it was not already, and starts or refreshes the
 * lease timer based on the item's lease time.
 *
 * @param item The UPnP discovery item to update. Must not be NULL.
 */
void upnp_discovery_item_alive(amxd_object_t* item);

/**
 * @brief Handles the reception of a UPnP byebye notification for an item.
 *
 * Updates the last update timestamp, sets the item's status to
 * "ByebyeReceived", stops its lease timer, and logs a notice that
 * the item has gone offline.
 *
 * @param item The UPnP discovery item that received the byebye notification.
 *             Must not be NULL.
 */
void upnp_discovery_item_byebye(amxd_object_t* item);

/**
 * @brief Retrieves a UPnP discovery item from a list by matching a key/value pair.
 *
 * Iterates over the given list of UPnP discovery items and returns the first
 * item where the specified key's value matches the provided string.
 *
 * @param list  The list of UPnP discovery items to search. Must not be NULL.
 * @param value The value to match. Must not be NULL or empty.
 * @param key   The key whose value will be compared against @p value. Must not be NULL or empty.
 *
 * @return The first matching UPnP discovery item if found, or NULL otherwise.
 */
amxd_object_t* upnp_disc_get_item_by_key(const amxd_object_t* list, const char* value, const char* key);

/**
 * @brief Handles a newly added UPnP service for discovery tracking.
 *
 * Allocates a new discovery item for the given service object, sets up
 * its parent device path, and starts the lease timer for automatic updates.
 *
 * @param service The UPnP service object that was added. Must not be NULL.
 */
void upnp_discovery_service_added(amxd_object_t* service);

/**
 * @brief Handles a newly added UPnP device for discovery tracking.
 *
 * Allocates a new discovery item for the given device object and
 * starts the lease timer for automatic updates.
 *
 * @param device The UPnP device object that was added. Must not be NULL.
 */
void upnp_discovery_device_added(amxd_object_t* device);

/**
 * @brief Updates UPnP service objects to associate them with the given device.
 *
 * Iterates over all discovered services and sets the `ParentDevice` parameter
 * for any service whose USN matches the UUID of the provided device.
 *
 * @param device The UPnP device object whose services are to be checked. Must not be NULL.
 */
void upnp_discovery_check_device_services(amxd_object_t* device);

/**
 * @brief Callback invoked when a UPnP discovery service object is added.
 *
 * This function is triggered by the device manager when a new service object
 * is created. It performs the following actions:
 * - Logs that the service has been added.
 * - Initializes the service for UPnP discovery.
 * - Checks and updates the service description.
 * - Sets up host subscription for the service.
 *
 * @param sig_name The signal name that triggered this callback (unused).
 * @param data     Event data containing the service object information.
 * @param priv     User-provided private data (unused).
 */
void _upnp_discovery_service_added(UNUSED const char* const sig_name,
                                   const amxc_var_t* const data,
                                   UNUSED void* const priv);

/**
 * @brief Callback invoked when a UPnP discovery device object is added.
 *
 * This function is triggered by the device manager when a new device object
 * is created. It performs the following actions:
 * - Logs that the device has been added.
 * - Initializes the device for UPnP discovery.
 * - Checks and updates the services associated with the device.
 * - Updates the device description.
 * - Sets up host subscription for the device.
 *
 * @param sig_name The signal name that triggered this callback (unused).
 * @param data     Event data containing the device object information.
 * @param priv     User-provided private data (unused).
 */
void _upnp_discovery_device_added(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  UNUSED void* const priv);

/**
 * @brief Callback invoked when a UPnP discovery item object is destroyed.
 *
 * This function is triggered when an object is being removed from the device
 * manager. If the destruction reason matches @c action_object_destroy, the
 * associated discovery item is deleted and the return value is cleared.
 *
 * @param object The object being destroyed. Must not be NULL.
 * @param param  Parameters for the action (unused).
 * @param reason The reason for the action. Only @c action_object_destroy is handled.
 * @param args   Additional arguments (unused).
 * @param retval Pointer to a variable to store the return value. Will be cleaned.
 * @param priv   User-provided private data (unused).
 *
 * @return @c amxd_status_ok if successfully handled, otherwise
 *         @c amxd_status_function_not_implemented.
 */
amxd_status_t _dm_discovery_item_destroyed(amxd_object_t* object,
                                           UNUSED amxd_param_t* param,
                                           amxd_action_t reason,
                                           UNUSED const amxc_var_t* const args,
                                           amxc_var_t* const retval,
                                           UNUSED void* priv);

#ifdef __cplusplus
}
#endif

#endif // __TR181_DISCOVERY_H__
