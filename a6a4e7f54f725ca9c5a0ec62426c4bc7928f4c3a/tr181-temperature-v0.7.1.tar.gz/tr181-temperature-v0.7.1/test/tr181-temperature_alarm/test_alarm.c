/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxc/amxc_macros.h>
#include <amxo/amxo.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxb/amxb.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_timer.h>
#include <amxut/amxut_macros.h>

#include "test_alarm.h"
#include "dm_tr181-temperature.h"
#include "tr181-temperature.h"

static const char* odl_defs = "../../odl/tr181-temperature_definition.odl";
static const char* odl_config = "../common/mock.odl";
static const char* odl_mock = "../common/mock_defaults.odl";

bool oh_status = false;

static void handle_overheat(UNUSED const char* const event_name,
                            const amxc_var_t* const event_data,
                            UNUSED void* const priv) {
    oh_status = GET_BOOL(event_data, "Status");
}

int test_setup(void** state) {
    amxut_bus_setup(state);

    amxut_resolve_function("tempsensor_update", _tempsensor_update);
    amxut_resolve_function("Reset", _Reset);
    amxut_resolve_function("tempsensor_toggled", _tempsensor_toggled);
    amxut_resolve_function("tempsensor_app_start", _tempsensor_app_start);
    amxut_resolve_function("tempsensor_destroy", _tempsensor_destroy);

    amxut_dm_load_odl(odl_config);
    amxut_dm_load_odl(odl_defs);
    amxut_dm_load_odl(odl_mock);
    assert_int_equal(_tempsensor_main(0, amxut_bus_dm(), amxut_bus_parser()), 0);

    _tempsensor_app_start(NULL, NULL, NULL);
    amxb_subscribe(amxut_bus_ctx(), "TemperatureStatus.", "notification == 'HighTemperatureAlarm!'", handle_overheat, NULL);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(void** state) {
    assert_int_equal(_tempsensor_main(1, amxut_bus_dm(), amxut_bus_parser()), 0);
    amxut_bus_teardown(state);

    return 0;
}

void test_wait_for_alarm(UNUSED void** state) {
    amxc_var_t* hyst = amxo_parser_get_config(amxut_bus_parser(), "hysteresis");
    amxd_object_t* tempsensor_obj = amxd_dm_findf(amxut_bus_dm(), "TemperatureStatus.TemperatureSensor.1.");
    tempsensor_info_t* tempsensor_info = NULL;
    int hysteresis = amxc_var_dyncast(int32_t, hyst);

    assert_non_null(tempsensor_obj);
    tempsensor_info = (tempsensor_info_t*) tempsensor_obj->priv;
    assert_non_null(tempsensor_info);

    amxut_dm_param_set(bool, "TemperatureStatus.TemperatureSensor.1.", "Enable", true);
    amxut_bus_handle_events();

    /* Setup TempSensor so that it detects overheating */
    amxut_dm_param_set(bool, "TemperatureStatus.TemperatureSensor.1.", "AlarmEnabled", true);
    amxut_dm_param_set(int32_t, "TemperatureStatus.TemperatureSensor.1.", "HighAlarmValue", 49);

    /* Check that 1 second before the hysteresis oh_status is false */
    amxut_timer_go_to_future_ms(tempsensor_info->polling_interval * (hysteresis - 1) - 1000);
    assert_false(oh_status);

    /* ~1 secs later we get the signal */
    amxut_timer_go_to_future_ms(2000);
    assert_true(oh_status);

    /* Finally raise the threshold to turn off the overheating and go back to
     * normal */
    amxut_dm_param_set(int32_t, "TemperatureStatus.TemperatureSensor.1.", "HighAlarmValue", 51);
    amxut_timer_go_to_future_ms(tempsensor_info->polling_interval * hysteresis);
    assert_false(oh_status);
}
