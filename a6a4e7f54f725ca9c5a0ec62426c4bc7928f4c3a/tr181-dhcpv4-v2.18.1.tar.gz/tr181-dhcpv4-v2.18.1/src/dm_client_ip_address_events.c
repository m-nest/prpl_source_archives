/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "dm_client_ip_address_events.h"
#include "dns_utility.h"


#define ME "client_ip_address_events"

static void update_dns_host(amxd_object_t* ipaddress) {
    amxd_object_t* option_12 = amxd_object_findf(ipaddress, ".^.^.Option.[Tag == 12].");
    when_null(option_12, exit);
    dns_set_host(option_12, DNS_HOST_ARG_CLIENT | DNS_HOST_ARG_POOL);
exit:
    return;
}

/**
 * @brief Set the IsStatic parameter of a lease
 *
 * @param lease the lease object to set the IsStatic parameter
 */
static void set_is_static(amxd_object_t* lease) {
    amxd_trans_t trans;
    amxd_object_t* client = NULL;
    amxd_object_t* static_ips = NULL;
    amxd_object_t* static_ip = NULL;
    amxo_parser_t* parser = dhcp_get_parser();
    amxc_string_t static_ip_param;
    char* ip = NULL;
    char* mac = NULL;
    const char* vendor_pref = GET_CHAR(&parser->config, VENDOR_PREFIX);

    amxc_string_init(&static_ip_param, 0);
    amxc_string_setf(&static_ip_param, "%sIsStatic", vendor_pref ? vendor_pref : "");
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    static_ips = amxd_object_findf(lease, "^.^.^.^.StaticAddress.");
    when_null_trace(static_ips, exit, ERROR, "Cannot get static ips object");
    client = amxd_object_findf(lease, "^.^.");
    when_null_trace(client, exit, ERROR, "Cannot get client object");

    ip = amxd_object_get_value(cstring_t, lease, "IPAddress", NULL);
    when_str_empty_trace(ip, exit, ERROR, "Cannot get lease ip");
    mac = amxd_object_get_value(cstring_t, client, "Chaddr", NULL);
    when_str_empty_trace(mac, exit, ERROR, "Cannot get client mac address");

    static_ip = amxd_object_findf(static_ips, "[Chaddr=='%s' && Yiaddr=='%s' && Enable==1]", mac, ip);
    if(static_ip == NULL) {
        TO_UPPER(mac);
        static_ip = amxd_object_findf(static_ips, "[Chaddr=='%s' && Yiaddr=='%s' && Enable==1]", mac, ip);
    }

    amxd_trans_select_object(&trans, lease);

    if(static_ip == NULL) {
        SAH_TRACEZ_INFO(ME, "No static ip for %s : %s", mac, ip);
        amxd_trans_set_value(bool, &trans, amxc_string_get(&static_ip_param, 0), false);
    } else {
        SAH_TRACEZ_INFO(ME, "Static ip found for %s : %s", mac, ip);
        amxd_trans_set_value(bool, &trans, amxc_string_get(&static_ip_param, 0), true);
    }

    when_failed_trace(amxd_trans_apply(&trans, dhcp_get_dm()), exit, ERROR, "Cannot change IsStatic");
exit:
    amxc_string_clean(&static_ip_param);
    amxd_trans_clean(&trans);
    free(mac);
    free(ip);
    return;
}

/**
 * @brief
 * Whenever a new lease is added, check if it comes from a static address rule to set its IsStatic parameter
 *
 * @param event_name name of the event
 * @param event_data data of the event, the lease added
 * @param priv NULL
 */
void _client_ip_address_check_if_static(UNUSED const char* const event_name,
                                        const amxc_var_t* const event_data,
                                        UNUSED void* const priv) {
    uint32_t index = 0;
    amxd_object_t* templ = NULL;
    amxd_object_t* lease = NULL;

    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");

    index = GET_UINT32(event_data, "index");
    when_false_trace(index != 0, exit, ERROR, "Cannot get object index.");

    templ = amxd_dm_signal_get_object(dhcp_get_dm(), event_data);
    when_null_trace(templ, exit, ERROR, "Cannot get template for IPv4Address object.");
    lease = amxd_object_get_instance(templ, NULL, index);
    set_is_static(lease);
exit:
    return;
}

/**
 * @brief
 * Whenever a lease is updated, check if it comes from a static address rule to set its IsStatic parameter
 *
 * @param event_name name of the event
 * @param event_data data of the event, the lease added
 * @param priv NULL
 */
void _client_ip_address_lease_changed(UNUSED const char* const event_name,
                                      const amxc_var_t* const event_data,
                                      UNUSED void* const priv) {
    amxd_object_t* lease = NULL;

    when_null_trace(event_data, exit, ERROR, "Invalid event_data argument");

    lease = amxd_dm_signal_get_object(dhcp_get_dm(), event_data);
    when_null_trace(lease, exit, ERROR, "Cannot get IPv4Address object.");

    set_is_static(lease);
exit:
    return;
}

void _client_ip_address_added(UNUSED const char* const event_name,
                              const amxc_var_t* const data,
                              UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(dhcp_get_dm(), data);
    amxd_object_t* ipaddress = amxd_object_get_instance(templ, NULL, GET_UINT32(data, "index"));
    update_dns_host(ipaddress);
}

void _client_ip_address_changed(UNUSED const char* const event_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxd_object_t* ipaddress = amxd_dm_signal_get_object(dhcp_get_dm(), data);
    const char* ip_rm = GETP_CHAR(data, "parameters.IPAddress.from");
    if(!str_empty(ip_rm)) {
        amxd_object_t* option_12 = amxd_object_findf(ipaddress, ".^.^.Option.[Tag == 12].");
        when_null_trace(option_12, exit, ERROR, "No option 12 found to remove ip address");
        dns_remove_host_ip(option_12, ip_rm);
    }
    update_dns_host(ipaddress);
exit:
    return;
}

void _client_ip_address_removed(UNUSED const char* const event_name,
                                const amxc_var_t* const data,
                                UNUSED void* const priv) {
    amxd_object_t* templ = amxd_dm_signal_get_object(dhcp_get_dm(), data);
    amxd_object_t* option_12 = amxd_object_findf(templ, ".^.Option.[Tag == 12].");
    when_null_trace(option_12, exit, ERROR, "No option 12 found to remove ip address");
    dns_remove_host_ip(option_12, GETP_CHAR(data, "parameters.IPAddress"));
exit:
    return;
}