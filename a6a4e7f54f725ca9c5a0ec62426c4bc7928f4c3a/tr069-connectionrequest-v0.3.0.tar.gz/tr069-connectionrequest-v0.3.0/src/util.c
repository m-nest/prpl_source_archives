/*******************************************************************************
 *
 * Copyright (c) 2000-2003 Intel Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * - Neither name of Intel Corporation nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/
/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "util.h"

#include <stdarg.h>
#include <stdio.h>

/**
 * @file util.c
 * @brief The auxiliary functions.
 */

/**
 * Maximum length of output string
 */
#define MAX_BUF (8 * 1024)

static int initialize_init = 1;
static int initialize_register = 1;

/** Function pointers to use for displaying formatted strings.
 * Set on Initialization of device. */
print_string gPrintFun = NULL;

/** mutex to control displaying of events */
ithread_mutex_t display_mutex;

int Util_Initialize(print_string print_function) {
    if(initialize_init) {
        ithread_mutexattr_t attr;

        ithread_mutexattr_init(&attr);
        ithread_mutexattr_setkind_np(&attr, ITHREAD_MUTEX_RECURSIVE_NP);
        ithread_mutex_init(&display_mutex, &attr);
        ithread_mutexattr_destroy(&attr);
        /* To shut up valgrind mutex warning. */
        ithread_mutex_lock(&display_mutex);
        gPrintFun = print_function;
        ithread_mutex_unlock(&display_mutex);
        /* Finished initializing. */
        initialize_init = 0;
    }

    return UPNP_E_SUCCESS;
}

int Util_Finish() {
    ithread_mutex_destroy(&display_mutex);
    gPrintFun = NULL;
    initialize_init = 1;
    initialize_register = 1;

    return UPNP_E_SUCCESS;
}

char* Util_GetElementValue(IXML_Element* element) {
    IXML_Node* child = ixmlNode_getFirstChild((IXML_Node*) element);
    char* temp = NULL;

    if((child != 0) && (ixmlNode_getNodeType(child) == eTEXT_NODE)) {
        temp = strdup(ixmlNode_getNodeValue(child));
    }

    return temp;
}

char* Util_GetFirstDocumentItem(IXML_Document* doc, const char* item) {
    IXML_NodeList* nodeList = NULL;
    IXML_Node* textNode = NULL;
    IXML_Node* tmpNode = NULL;
    const char* nodeValue = NULL;
    char* ret = NULL;

    nodeList = ixmlDocument_getElementsByTagName(doc, (char*) item);
    if(nodeList) {
        tmpNode = ixmlNodeList_item(nodeList, 0);
        if(tmpNode) {
            textNode = ixmlNode_getFirstChild(tmpNode);
            if(!textNode) {
                Util_Print("%s(%d): (BUG) "
                           "ixmlNode_getFirstChild("
                           "tmpNode) returned NULL\n",
                           __FILE__,
                           __LINE__);
                ret = strdup("");
                goto epilogue;
            }
            nodeValue = ixmlNode_getNodeValue(textNode);
            if(!nodeValue) {
                Util_Print(
                    "%s(%d): ixmlNode_getNodeValue "
                    "returned NULL\n",
                    __FILE__,
                    __LINE__);
                ret = strdup("");
                goto epilogue;
            }
            ret = strdup(nodeValue);
            if(!ret) {
                Util_Print("%s(%d): Error allocating "
                           "memory for XML Node value\n",
                           __FILE__,
                           __LINE__);
                ret = strdup("");
            }
        } else {
            Util_Print("%s(%d): ixmlNodeList_item(nodeList, "
                       "0) returned NULL\n",
                       __FILE__,
                       __LINE__);
        }
    } else {
        Util_Print("%s(%d): Error finding %s in XML Node\n",
                   __FILE__,
                   __LINE__,
                   item);
    }

epilogue:
    if(nodeList) {
        ixmlNodeList_free(nodeList);
    }

    return ret;
}

char* Util_GetFirstElementItem(IXML_Element* element, const char* item) {
    IXML_NodeList* nodeList = NULL;
    IXML_Node* textNode = NULL;
    IXML_Node* tmpNode = NULL;
    char* ret = NULL;

    nodeList = ixmlElement_getElementsByTagName(element, (char*) item);
    if(nodeList == NULL) {
        Util_Print("%s(%d): Error finding %s in XML Node\n",
                   __FILE__,
                   __LINE__,
                   item);
        return NULL;
    }
    tmpNode = ixmlNodeList_item(nodeList, 0);
    if(!tmpNode) {
        Util_Print("%s(%d): Error finding %s value in XML Node\n",
                   __FILE__,
                   __LINE__,
                   item);
        ixmlNodeList_free(nodeList);
        return NULL;
    }
    textNode = ixmlNode_getFirstChild(tmpNode);
    ret = strdup(ixmlNode_getNodeValue(textNode));
    if(!ret) {
        Util_Print(
            "%s(%d): Error allocating memory for %s in XML Node\n",
            __FILE__,
            __LINE__,
            item);
        ixmlNodeList_free(nodeList);
        return NULL;
    }
    ixmlNodeList_free(nodeList);

    return ret;
}

void Util_PrintEventType(Upnp_EventType S) {
    switch(S) {
    /* Discovery */
    case UPNP_DISCOVERY_ADVERTISEMENT_ALIVE:
        Util_Print("UPNP_DISCOVERY_ADVERTISEMENT_ALIVE\n");
        break;
    case UPNP_DISCOVERY_ADVERTISEMENT_BYEBYE:
        Util_Print("UPNP_DISCOVERY_ADVERTISEMENT_BYEBYE\n");
        break;
    case UPNP_DISCOVERY_SEARCH_RESULT:
        Util_Print("UPNP_DISCOVERY_SEARCH_RESULT\n");
        break;
    case UPNP_DISCOVERY_SEARCH_TIMEOUT:
        Util_Print("UPNP_DISCOVERY_SEARCH_TIMEOUT\n");
        break;
    /* SOAP */
    case UPNP_CONTROL_ACTION_REQUEST:
        Util_Print("UPNP_CONTROL_ACTION_REQUEST\n");
        break;
    case UPNP_CONTROL_ACTION_COMPLETE:
        Util_Print("UPNP_CONTROL_ACTION_COMPLETE\n");
        break;
    case UPNP_CONTROL_GET_VAR_REQUEST:
        Util_Print("UPNP_CONTROL_GET_VAR_REQUEST\n");
        break;
    case UPNP_CONTROL_GET_VAR_COMPLETE:
        Util_Print("UPNP_CONTROL_GET_VAR_COMPLETE\n");
        break;
    /* GENA */
    case UPNP_EVENT_SUBSCRIPTION_REQUEST:
        Util_Print("UPNP_EVENT_SUBSCRIPTION_REQUEST\n");
        break;
    case UPNP_EVENT_RECEIVED:
        Util_Print("UPNP_EVENT_RECEIVED\n");
        break;
    case UPNP_EVENT_RENEWAL_COMPLETE:
        Util_Print("UPNP_EVENT_RENEWAL_COMPLETE\n");
        break;
    case UPNP_EVENT_SUBSCRIBE_COMPLETE:
        Util_Print("UPNP_EVENT_SUBSCRIBE_COMPLETE\n");
        break;
    case UPNP_EVENT_UNSUBSCRIBE_COMPLETE:
        Util_Print("UPNP_EVENT_UNSUBSCRIBE_COMPLETE\n");
        break;
    case UPNP_EVENT_AUTORENEWAL_FAILED:
        Util_Print("UPNP_EVENT_AUTORENEWAL_FAILED\n");
        break;
    case UPNP_EVENT_SUBSCRIPTION_EXPIRED:
        Util_Print("UPNP_EVENT_SUBSCRIPTION_EXPIRED\n");
        break;
    }
}

int Util_PrintEvent(Upnp_EventType EventType, const void* Event) {
    ithread_mutex_lock(&display_mutex);

    Util_Print("====================================================="
               "=================\n"
               "-----------------------------------------------------"
               "-----------------\n");
    Util_PrintEventType(EventType);
    switch(EventType) {
    /* SSDP */
    case UPNP_DISCOVERY_ADVERTISEMENT_ALIVE:
    case UPNP_DISCOVERY_ADVERTISEMENT_BYEBYE:
    case UPNP_DISCOVERY_SEARCH_RESULT: {
        UpnpDiscovery* d_event = (UpnpDiscovery*) Event;
        Util_Print("ErrCode     =  %d\n"
                   "Expires     =  %d\n"
                   "DeviceId    =  %s\n"
                   "DeviceType  =  %s\n"
                   "Type =  %s\n"
                   "ServiceVer  =  %s\n"
                   "Location    =  %s\n"
                   "OS          =  %s\n"
                   "Date        =  %s\n"
                   "Ext         =  %s\n",
                   UpnpDiscovery_get_ErrCode(d_event),
                   UpnpDiscovery_get_Expires(d_event),
                   UpnpString_get_String(
                       UpnpDiscovery_get_DeviceID(d_event)),
                   UpnpString_get_String(
                       UpnpDiscovery_get_DeviceType(d_event)),
                   UpnpString_get_String(
                       UpnpDiscovery_get_ServiceType(d_event)),
                   UpnpString_get_String(
                       UpnpDiscovery_get_ServiceVer(d_event)),
                   UpnpString_get_String(
                       UpnpDiscovery_get_Location(d_event)),
                   UpnpString_get_String(UpnpDiscovery_get_Os(d_event)),
                   UpnpString_get_String(UpnpDiscovery_get_Date(d_event)),
                   UpnpString_get_String(UpnpDiscovery_get_Ext(d_event)));
        break;
    }
    case UPNP_DISCOVERY_SEARCH_TIMEOUT:
        /* Nothing to print out here */
        break;
    /* SOAP */
    case UPNP_CONTROL_ACTION_REQUEST: {
        UpnpActionRequest* a_event = (UpnpActionRequest*) Event;
        IXML_Document* actionRequestDoc = NULL;
        IXML_Document* actionResultDoc = NULL;
        char* xmlbuff = NULL;

        Util_Print("ErrCode     =  %d\n"
                   "ErrStr      =  %s\n"
                   "ActionName  =  %s\n"
                   "UDN         =  %s\n"
                   "ServiceID   =  %s\n",
                   UpnpActionRequest_get_ErrCode(a_event),
                   UpnpString_get_String(
                       UpnpActionRequest_get_ErrStr(a_event)),
                   UpnpString_get_String(
                       UpnpActionRequest_get_ActionName(a_event)),
                   UpnpString_get_String(
                       UpnpActionRequest_get_DevUDN(a_event)),
                   UpnpString_get_String(
                       UpnpActionRequest_get_ServiceID(a_event)));
        actionRequestDoc = UpnpActionRequest_get_ActionRequest(a_event);
        if(actionRequestDoc) {
            xmlbuff = ixmlPrintNode((IXML_Node*) actionRequestDoc);
            if(xmlbuff) {
                Util_Print(
                    "ActRequest  =  %s\n", xmlbuff);
                ixmlFreeDOMString(xmlbuff);
            }
            xmlbuff = NULL;
        } else {
            Util_Print("ActRequest  =  (null)\n");
        }
        actionResultDoc = UpnpActionRequest_get_ActionResult(a_event);
        if(actionResultDoc) {
            xmlbuff = ixmlPrintNode((IXML_Node*) actionResultDoc);
            if(xmlbuff) {
                Util_Print(
                    "ActResult   =  %s\n", xmlbuff);
                ixmlFreeDOMString(xmlbuff);
            }
            xmlbuff = NULL;
        } else {
            Util_Print("ActResult   =  (null)\n");
        }
        break;
    }
    case UPNP_CONTROL_ACTION_COMPLETE: {
        UpnpActionComplete* a_event = (UpnpActionComplete*) Event;
        char* xmlbuff = NULL;
        int errCode = UpnpActionComplete_get_ErrCode(a_event);
        const char* ctrlURL = UpnpString_get_String(
            UpnpActionComplete_get_CtrlUrl(a_event));
        IXML_Document* actionRequest =
            UpnpActionComplete_get_ActionRequest(a_event);
        IXML_Document* actionResult =
            UpnpActionComplete_get_ActionResult(a_event);

        Util_Print("ErrCode     =  %d\n"
                   "CtrlUrl     =  %s\n",
                   errCode,
                   ctrlURL);
        if(actionRequest) {
            xmlbuff = ixmlPrintNode((IXML_Node*) actionRequest);
            if(xmlbuff) {
                Util_Print(
                    "ActRequest  =  %s\n", xmlbuff);
                ixmlFreeDOMString(xmlbuff);
            }
            xmlbuff = NULL;
        } else {
            Util_Print("ActRequest  =  (null)\n");
        }
        if(actionResult) {
            xmlbuff = ixmlPrintNode((IXML_Node*) actionResult);
            if(xmlbuff) {
                Util_Print(
                    "ActResult   =  %s\n", xmlbuff);
                ixmlFreeDOMString(xmlbuff);
            }
            xmlbuff = NULL;
        } else {
            Util_Print("ActResult   =  (null)\n");
        }
        break;
    }
    case UPNP_CONTROL_GET_VAR_REQUEST: {
        UpnpStateVarRequest* sv_event = (UpnpStateVarRequest*) Event;

        Util_Print("ErrCode     =  %d\n"
                   "ErrStr      =  %s\n"
                   "UDN         =  %s\n"
                   "ServiceID   =  %s\n"
                   "StateVarName=  %s\n"
                   "CurrentVal  =  %s\n",
                   UpnpStateVarRequest_get_ErrCode(sv_event),
                   UpnpString_get_String(
                       UpnpStateVarRequest_get_ErrStr(sv_event)),
                   UpnpString_get_String(
                       UpnpStateVarRequest_get_DevUDN(sv_event)),
                   UpnpString_get_String(
                       UpnpStateVarRequest_get_ServiceID(sv_event)),
                   UpnpString_get_String(
                       UpnpStateVarRequest_get_StateVarName(sv_event)),
                   UpnpStateVarRequest_get_CurrentVal(sv_event));
        break;
    }
    case UPNP_CONTROL_GET_VAR_COMPLETE: {
        UpnpStateVarComplete* sv_event = (UpnpStateVarComplete*) Event;

        Util_Print("ErrCode     =  %d\n"
                   "CtrlUrl     =  %s\n"
                   "StateVarName=  %s\n"
                   "CurrentVal  =  %s\n",
                   UpnpStateVarComplete_get_ErrCode(sv_event),
                   UpnpString_get_String(
                       UpnpStateVarComplete_get_CtrlUrl(sv_event)),
                   UpnpString_get_String(
                       UpnpStateVarComplete_get_StateVarName(
                           sv_event)),
                   UpnpStateVarComplete_get_CurrentVal(sv_event));
        break;
    }
    /* GENA */
    case UPNP_EVENT_SUBSCRIPTION_REQUEST: {
        UpnpSubscriptionRequest* sr_event =
            (UpnpSubscriptionRequest*) Event;

        Util_Print("ServiceID   =  %s\n"
                   "UDN         =  %s\n"
                   "SID         =  %s\n",
                   UpnpString_get_String(
                       UpnpSubscriptionRequest_get_ServiceId(
                           sr_event)),
                   UpnpString_get_String(
                       UpnpSubscriptionRequest_get_UDN(sr_event)),
                   UpnpString_get_String(
                       UpnpSubscriptionRequest_get_SID(sr_event)));
        break;
    }
    case UPNP_EVENT_RECEIVED: {
        UpnpEvent* e_event = (UpnpEvent*) Event;
        char* xmlbuff = NULL;

        xmlbuff = ixmlPrintNode(
            (IXML_Node*) UpnpEvent_get_ChangedVariables(e_event));
        Util_Print("SID         =  %s\n"
                   "EventKey    =  %d\n"
                   "ChangedVars =  %s\n",
                   UpnpString_get_String(UpnpEvent_get_SID(e_event)),
                   UpnpEvent_get_EventKey(e_event),
                   xmlbuff);
        ixmlFreeDOMString(xmlbuff);
        break;
    }
    case UPNP_EVENT_RENEWAL_COMPLETE: {
        UpnpEventSubscribe* es_event = (UpnpEventSubscribe*) Event;

        Util_Print("SID         =  %s\n"
                   "ErrCode     =  %d\n"
                   "TimeOut     =  %d\n",
                   UpnpString_get_String(
                       UpnpEventSubscribe_get_SID(es_event)),
                   UpnpEventSubscribe_get_ErrCode(es_event),
                   UpnpEventSubscribe_get_TimeOut(es_event));
        break;
    }
    case UPNP_EVENT_SUBSCRIBE_COMPLETE:
    case UPNP_EVENT_UNSUBSCRIBE_COMPLETE: {
        UpnpEventSubscribe* es_event = (UpnpEventSubscribe*) Event;

        Util_Print("SID         =  %s\n"
                   "ErrCode     =  %d\n"
                   "PublisherURL=  %s\n"
                   "TimeOut     =  %d\n",
                   UpnpString_get_String(
                       UpnpEventSubscribe_get_SID(es_event)),
                   UpnpEventSubscribe_get_ErrCode(es_event),
                   UpnpString_get_String(
                       UpnpEventSubscribe_get_PublisherUrl(es_event)),
                   UpnpEventSubscribe_get_TimeOut(es_event));
        break;
    }
    case UPNP_EVENT_AUTORENEWAL_FAILED:
    case UPNP_EVENT_SUBSCRIPTION_EXPIRED: {
        UpnpEventSubscribe* es_event = (UpnpEventSubscribe*) Event;

        Util_Print("SID         =  %s\n"
                   "ErrCode     =  %d\n"
                   "PublisherURL=  %s\n"
                   "TimeOut     =  %d\n",
                   UpnpString_get_String(
                       UpnpEventSubscribe_get_SID(es_event)),
                   UpnpEventSubscribe_get_ErrCode(es_event),
                   UpnpString_get_String(
                       UpnpEventSubscribe_get_PublisherUrl(es_event)),
                   UpnpEventSubscribe_get_TimeOut(es_event));
        break;
    }
    }
    Util_Print("-----------------------------------------------------"
               "-----------------\n"
               "====================================================="
               "=================\n"
               "\n\n\n");

    ithread_mutex_unlock(&display_mutex);

    return 0;
}

int Util_FindAndParseService(IXML_Document* DescDoc,
                             const char* location,
                             const char* serviceType,
                             char** serviceId,
                             char** eventURL,
                             char** controlURL) {
    unsigned int i, j;
    unsigned long length;
    int found = 0;
    int ret;
    char* tempServiceType = NULL;
    const char* base = NULL;
    char* relcontrolURL = NULL;
    char* releventURL = NULL;
    IXML_NodeList* serviceList = NULL;
    IXML_Element* service = NULL;

    IXML_NodeList* servlistnodelist = NULL;
    IXML_Node* servlistnode = NULL;

    base = location;
    servlistnodelist = ixmlDocument_getElementsByTagName(DescDoc, "serviceList");
    if(servlistnodelist && ixmlNodeList_length(servlistnodelist)) {
        for(j = 0; j < ixmlNodeList_length(servlistnodelist); j++) {
            servlistnode = ixmlNodeList_item(servlistnodelist, j);
            serviceList = ixmlElement_getElementsByTagName(
                (IXML_Element*) servlistnode, "service");
            length = ixmlNodeList_length(serviceList);
            for(i = 0; i < length; i++) {
                service = (IXML_Element*) ixmlNodeList_item(serviceList, i);
                tempServiceType = Util_GetFirstElementItem(
                    (IXML_Element*) service, "serviceType");
                if(tempServiceType &&
                   (strcmp(tempServiceType, serviceType) == 0)) {
                    Util_Print("Found service: %s\n", serviceType);
                    *serviceId = Util_GetFirstElementItem(
                        service, "serviceId");
                    Util_Print("serviceId: %s\n", *serviceId);
                    relcontrolURL = Util_GetFirstElementItem(
                        service, "controlURL");
                    releventURL = Util_GetFirstElementItem(
                        service, "eventSubURL");
                    ret = UpnpResolveURL2(base, relcontrolURL, controlURL);
                    if(ret != UPNP_E_SUCCESS) {
                        Util_Print("Error generating controlURL "
                                   "from %s + %s\n",
                                   base,
                                   relcontrolURL);
                    }
                    ret = UpnpResolveURL2(base, releventURL, eventURL);
                    if(ret != UPNP_E_SUCCESS) {
                        Util_Print("Error generating eventURL "
                                   "from %s + %s\n",
                                   base,
                                   releventURL);
                    }
                    free(relcontrolURL);
                    free(releventURL);
                    relcontrolURL = NULL;
                    releventURL = NULL;
                    found = 1;
                    break;
                }
                free(tempServiceType);
                tempServiceType = NULL;
            }
            free(tempServiceType);
            tempServiceType = NULL;
            if(serviceList) {
                ixmlNodeList_free(serviceList);
            }
            serviceList = NULL;
        }
    }

    if(servlistnodelist) {
        ixmlNodeList_free(servlistnodelist);
    }

    return found;
}

int Util_Print(const char* fmt, ...) {
    va_list ap;
    static char buf[MAX_BUF];
    int rc;

    /* Protect both the display and the static buffer with the mutex */
    ithread_mutex_lock(&display_mutex);

    va_start(ap, fmt);
    rc = vsnprintf(buf, MAX_BUF, fmt, ap);
    va_end(ap);
    if(gPrintFun) {
        gPrintFun("%s", buf);
    }

    ithread_mutex_unlock(&display_mutex);

    return rc;
}

/**
 * @brief Prints a string to standard out.
 */
void linux_print(const char* format, ...) {
    va_list argList;

    va_start(argList, format);
    vfprintf(stdout, format, argList);
    fflush(stdout);
    va_end(argList);
}
