/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Gemtek
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__TR_IPDIAGNOSTICS_PRIV_IPLCAP_H__)
#define __TR_IPDIAGNOSTICS_PRIV_IPLCAP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc_macros.h>
#include <amxc/amxc.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_function.h>

/**
 * @brief Root object name for IPLayerCapacity results in the data model.
 */
#define IPD_IPLCAP_CONFIG "IPLayerCapacityMetrics"

/**
 * @brief Scheduler state for a running IPLayerCapacity test.
 *
 * @details Tracks process descriptors, PID and deferred call identifier.
 */
typedef struct _ipd_iplcap_scheduler {
    int32_t fd_stdout;   /**< @brief Stdout file descriptor of the test process. */
    int32_t fd_stderr;   /**< @brief Stderr file descriptor of the test process. */
    int32_t pid;         /**< @brief Process identifier of the test subprocess. */
    uint64_t call_id;    /**< @brief Deferred function call identifier. */
    bool prev_test;      /**< @brief True when handling a previously running test. */
} ipd_iplcap_scheduler_t;

/**
 * @brief IPLayerCapacity RPC entry point.
 *
 * @param[in]  object Data model object executing the function.
 * @param[in]  func   Function descriptor from the data model.
 * @param[in]  args   Input arguments for the RPC.
 * @param[out] ret    Output/result arguments.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t _IPLayerCapacity(amxd_object_t* object, amxd_function_t* func, amxc_var_t* args, amxc_var_t* ret);
/**
 * @brief Event handler for DiagnosticState changes.
 *
 * @param[in] event_name Name of the emitted event.
 * @param[in] event_data Event payload with state information.
 * @param[in] priv       Optional user data.
 */
void _ipd_iplcap_check_dst(UNUSED const char* const event_name,
                           const amxc_var_t* const event_data,
                           UNUSED void* const priv);
/**
 * @brief Start an IPLayerCapacity test.
 *
 * @param[in]  check_function Callback to process status/output updates.
 * @param[in]  scheduler      Scheduler state holder.
 * @param[in]  args           Input arguments for the test.
 * @param[out] ret            Output/result variant.
 *
 * @return amxd_status_t Deferred on success or error code.
 */
amxd_status_t ipd_iplcap_start(void (* check_function)(int, void*),
                               ipd_iplcap_scheduler_t* scheduler,
                               amxc_var_t* args, amxc_var_t* ret);
/**
 * @brief Stop a running IPLayerCapacity test.
 *
 * @param[in] sch Scheduler containing process handles to stop.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t ipd_iplcap_stop(ipd_iplcap_scheduler_t* sch);
/**
 * @brief Check callback bound to process output.
 *
 * @param[in] fd   File descriptor used to read process output.
 * @param[in] priv Optional user data.
 */
void ipd_iplcap_check(int fd, void* priv);
/**
 * @brief Scheduler callback to poll status and finalize when complete.
 *
 * @details Fetches parameters from the data model, runs a check RPC,
 *          persists results, and when terminal, removes any connection
 *          and completes the deferred function call.
 *
 * @param[in] fd   File descriptor for connection removal (optional).
 * @param[in] priv Unused private pointer.
 * @param[in] sch  Scheduler state reference.
 */
void ipd_iplcap_sched_check(int fd, void* priv, ipd_iplcap_scheduler_t* scheduler);
/**
 * @brief Persist results to the data model.
 *
 * @param[in] ret        Source variant containing results.
 * @param[in] ipd_iplcap Target object where values are written.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t ipd_iplcap_save_result_to_dm(amxc_var_t* ret, amxd_object_t* ipd_iplcap);
/**
 * @brief Persist only DiagnosticState to the data model.
 *
 * @param[in] ret        Source variant containing DiagnosticState.
 * @param[in] ipd_iplcap Target object where the state is written.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t ipd_iplcap_save_status_to_dm(amxc_var_t* ret, amxd_object_t* ipd_iplcap);
/**
 * @brief Clean previous results from the data model.
 *
 * @param[in] iplcap_object IPLayerCapacity object to clean.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t ipd_iplcap_clean_result_from_dm(amxd_object_t* iplcap_object);
/**
 * @brief Handler for writable DM changes impacting IPLayerCapacity.
 *
 * @param[in] event_name Name of the emitted event.
 * @param[in] event_data Associated event payload.
 * @param[in] priv       Optional user data.
 */
void _ipd_iplcap_writable_dm_changed(const char* const event_name,
                                     const amxc_var_t* const event_data,
                                     void* const priv);
/**
 * @brief Validation/write callback for IPLayerCapacity state parameters.
 *
 * @param[in]  object Data model object being modified.
 * @param[in]  param  Parameter being written/validated.
 * @param[in]  reason Action context (validate, write, etc.).
 * @param[in]  args   Input arguments of the action.
 * @param[out] retval Optional return value container.
 * @param[in]  priv   Optional user data.
 *
 * @return amxd_status_t Status code indicating success or failure.
 */
amxd_status_t _write_iplcapstate_params(amxd_object_t* object,
                                        amxd_param_t* param,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        amxc_var_t* const retval,
                                        void* priv);
#ifdef __cplusplus
}
#endif

#endif // __TR_IPDIAGNOSTICS_PRIV_IPLCAP_H__