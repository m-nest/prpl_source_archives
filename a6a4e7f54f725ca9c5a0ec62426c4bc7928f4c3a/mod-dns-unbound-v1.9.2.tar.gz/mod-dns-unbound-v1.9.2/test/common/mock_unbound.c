/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <string.h>
#include <signal.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb.h>
#include <amxut/amxut_bus.h>

#include "mock.h"

#define PROC_LIST_SIZE 20

typedef struct {
    amxc_string_t intf;
    amxp_subproc_t* subproc;
} process_t;

amxc_var_t* proc_map = NULL;
amxp_subproc_t* subproc_opened_fd = NULL;

process_t proc_list[PROC_LIST_SIZE];

static uint32_t restarts = 0;

static void init_proc_list(void) {
    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        proc_list[i].subproc = NULL;
    }
}

int amxp_subproc_new(amxp_subproc_t** subproc) {
    *subproc = calloc(1, sizeof(amxp_subproc_t));
    return 0;
}

bool ut_is_proc_running_by_intf(const char* intf) {
    when_str_empty(intf, exit);
    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        if(proc_list[i].subproc != NULL) {
            if(strcmp(amxc_string_get(&proc_list[i].intf, 0), intf) == 0) {
                return true;
            }
        }
    }
exit:
    return false;
}

static bool is_proc_running(const amxp_subproc_t* const subproc) {
    when_null(subproc, exit);
    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        if(proc_list[i].subproc != NULL) {
            if(proc_list[i].subproc == subproc) {
                return true;
            }
        }
    }
exit:
    return false;
}

int amxp_subproc_delete(amxp_subproc_t** subproc) {
    int rv = -1;
    const amxc_htable_t* ht_proc_map = NULL;
    int index = -1;
    amxc_string_t index_str;
    amxc_var_t* tmp = NULL;

    amxc_string_init(&index_str, 0);

    when_null(*subproc, exit);
    when_null(proc_map, exit);

    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        if(proc_list[i].subproc != NULL) {
            if(proc_list[i].subproc == *subproc) {
                index = i;
                amxc_string_setf(&index_str, "%d", index);
                break;
            }
        }
    }
    when_true(index == -1, exit);

    tmp = GET_ARG(proc_map, amxc_string_get(&index_str, 0));
    when_null(tmp, exit);
    amxc_var_delete(&tmp);

    ht_proc_map = amxc_var_constcast(amxc_htable_t, proc_map);
    if(amxc_htable_size(ht_proc_map) == 0) {
        amxc_var_delete(&proc_map);
        proc_map = NULL;
    }

    proc_list[index].subproc = NULL;
    amxc_string_clean(&proc_list[index].intf);
    free(*subproc);
    (*subproc) = NULL;

    rv = 0;
exit:
    if((*subproc) != NULL) {
        free(*subproc);
        (*subproc) = NULL;
    }
    amxc_string_clean(&index_str);
    return rv;
}

int amxp_subproc_kill(const amxp_subproc_t* const subproc, const int sig) {
    int rv = -1;
    const amxc_htable_t* ht_proc_map = NULL;
    int index = -1;
    amxc_string_t index_str;
    amxc_var_t* tmp = NULL;

    amxc_string_init(&index_str, 0);

    assert_true(is_proc_running(subproc)); // expect only 1 process per interface at a time?
    assert_non_null(subproc);
    assert_int_equal(sig, SIGTERM);

    // emit signal 'stop' to unsubscribe from 'unbound:client-response'
    // otherwise the latter is handled too many times (once extra for every start of unbound)
    amxp_sigmngr_emit_signal(subproc->sigmngr, "stop", NULL);

    when_null(subproc, exit);
    when_null(proc_map, exit);

    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        if(proc_list[i].subproc != NULL) {
            if(proc_list[i].subproc == subproc) {
                index = i;
                amxc_string_setf(&index_str, "%d", index);
                break;
            }
        }
    }
    when_true(index == -1, exit);

    tmp = GET_ARG(proc_map, amxc_string_get(&index_str, 0));
    when_null(tmp, exit);
    amxc_var_delete(&tmp);

    ht_proc_map = amxc_var_constcast(amxc_htable_t, proc_map);
    if(amxc_htable_size(ht_proc_map) == 0) {
        amxc_var_delete(&proc_map);
        proc_map = NULL;
    }

    proc_list[index].subproc = NULL;
    amxc_string_clean(&proc_list[index].intf);

    rv = 0;
exit:
    amxc_string_clean(&index_str);
    return rv;
}

static char* extract_intf_from_cmd(char* cmd) {
    const char* marker = "unbound-";
    const char* start;
    const char* end;
    size_t len;
    char* iface;

    if(cmd == NULL) {
        return NULL;
    }

    start = strstr(cmd, marker);
    if(!start) {
        return NULL;
    }

    start += strlen(marker);

    end = strstr(start, ".conf");
    if(!end || (end == start)) {
        return NULL;
    }

    len = (size_t) (end - start);

    iface = malloc(len + 1);
    if(!iface) {
        return NULL;
    }

    memcpy(iface, start, len);
    iface[len] = '\0';

    return iface;
}

static void map_process(amxp_subproc_t* subproc, char* cmd) {
    int index = -1;
    char* intf = NULL;
    amxc_string_t index_str;
    amxc_var_t* tmp = NULL;

    assert_non_null(cmd);
    intf = extract_intf_from_cmd(cmd);
    assert_non_null(intf);
    assert_string_not_equal(intf, "");

    amxc_string_init(&index_str, 0);

    if(proc_map == NULL) {
        amxc_var_new(&proc_map);
        amxc_var_set_type(proc_map, AMXC_VAR_ID_HTABLE);
        init_proc_list();
    }

    for(int i = 1; i < PROC_LIST_SIZE; i++) {
        if(proc_list[i].subproc == subproc) {
            index = i;
            amxc_string_setf(&index_str, "%d", index);
            break;
        }
    }

    if(index == -1) {
        for(int i = 1; i < PROC_LIST_SIZE; i++) {
            if(proc_list[i].subproc == NULL) {
                index = i;
                amxc_string_setf(&index_str, "%d", index);
                break;
            }
        }
    } else {
        tmp = GET_ARG(proc_map, amxc_string_get(&index_str, 0));
        assert_non_null(tmp);
        amxc_var_delete(&tmp);
    }

    assert_int_not_equal(index, -1);
    proc_list[index].subproc = subproc;
    amxc_string_init(&proc_list[index].intf, 0);
    amxc_string_setf(&proc_list[index].intf, "%s", intf);

    amxc_var_add_key(cstring_t, proc_map, amxc_string_get(&index_str, 0), cmd);
    amxc_string_clean(&index_str);

    free(intf);
    return;
}

int amxp_subproc_vstart(amxp_subproc_t* const subproc, char** argv) {
    amxc_string_t str;

    amxc_string_init(&str, 0);

    assert_non_null(subproc);
    assert_false(is_proc_running(subproc)); // expect only 1 process per interface at a time?
    assert_non_null(argv);
    assert_non_null(argv[0]);
    amxc_string_appendf(&str, "%s", argv[0]);
    for(int i = 1; argv[i] != NULL; i++) {
        amxc_string_appendf(&str, " %s", argv[i]);
    }

    map_process(subproc, (char*) amxc_string_get(&str, 0));
    amxc_string_clean(&str);
    restarts++;

    return 0;
}

bool amxp_subproc_is_running(UNUSED const amxp_subproc_t* const subproc) {
    return is_proc_running(subproc);
}

uint32_t ut_get_number_of_subproc_restarts(void) {
    return restarts;
}

amxp_subproc_t* amxp_subproc_find(const int pid) {
    amxp_subproc_t* ret = NULL;

    when_true(pid < 0, exit);
    when_true(pid >= PROC_LIST_SIZE, exit);

    ret = proc_list[pid].subproc;
exit:
    return ret;
}

int ut_processes_running(void) {
    int size = 0;
    const amxc_htable_t* ht_proc_map = NULL;

    when_null(proc_map, exit);
    ht_proc_map = amxc_var_constcast(amxc_htable_t, proc_map);
    when_null(ht_proc_map, exit);

    size = (int) amxc_htable_size(ht_proc_map);
exit:
    return size;
}

bool use_wrapped_fprintf = false;

static const char* unbound_extensions[] = {
    "private-exception:",
    "bind-interfaces:",
    "interface:",
};

/**
 * on CPE we use a patched version of Unbound with custom config options.
 * For the unit tests to be able to use the non-patched unbound-checkconf,
 * the patch specific config options are commented out.
 *
 * This assumes fprintf is used to write unbound.conf.
 */
int testhelper_fprintf(FILE* fp, const char* format, ...) {
    va_list args;
    int len = 0;
    char buf[1000] = {0};
    int rv = 0;

    va_start(args, format);

    len = strlen(format);
    assert_true((len > 0) && (len < (int) sizeof(buf)));

    snprintf(buf, sizeof(buf), "%s", format);

    if(!use_wrapped_fprintf) {
        goto exit;
    }

    for(int i = 0; i < ((int) (sizeof(unbound_extensions) / sizeof(unbound_extensions[0]))); i++) {
        if(strstr(format, unbound_extensions[i]) != NULL) {
            buf[0] = '#'; // comment character in unbound.conf
            break;
        }
    }

exit:
    rv = vfprintf(fp, buf, args);

    va_end(args);

    return rv;
}
