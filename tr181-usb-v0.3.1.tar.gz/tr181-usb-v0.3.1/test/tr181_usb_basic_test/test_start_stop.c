/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: 2025 Sagemcom
**
** This code is subject to the terms of the BSD+Patent license.
**
** See LICENSE file for more details.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxo/amxo.h>
#include <amxm/amxm.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <yajl/yajl_gen.h>
#include <amxj/amxj_variant.h>

#include "usb-dm.h"
#include "usb.h"
#include "usb-pwr.h"
#include "usb-actions.h"
#include "test_start_stop.h"
#define ARRAY_SIZE(array) (int) (sizeof(array) / sizeof(array[0]))

static void init_resolver(amxo_parser_t* parser) {
    struct {
        const char* name;
        amxo_fn_ptr_t impl;
    } func[] = {
        {"addDev", AMXO_FUNC(_addDev)},
        {"delDev", AMXO_FUNC(_delDev)},
        {"unbindDev", AMXO_FUNC(_unbindDev)},
        {"eject", AMXO_FUNC(_eject)},
        {"addBus", AMXO_FUNC(_addBus)},
        {"Reset", AMXO_FUNC(_Reset)},
        {"host_reset_changed", AMXO_FUNC(_host_reset_changed)},
        {"usb_port_added", AMXO_FUNC(_usb_port_added)},
        {"ChangePowerMode", AMXO_FUNC(_ChangePowerMode)},
        {"app_start", AMXO_FUNC(_app_start)},
        {"check_is_in_power_capability_or_error", AMXO_FUNC(_check_is_in_power_capability_or_error)},
    };

    //events
    for(int i = 0; i < ARRAY_SIZE(func); i++) {
        assert_int_equal(amxo_resolver_ftab_add(parser, func[i].name, func[i].impl), 0);
    }
    assert_int_equal(amxo_resolver_import_open(parser, "/usr/lib/amx/modules/mod-dmext.so", "mod-dmext", 0), 0);
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root = NULL;
    amxd_dm_t* dm = NULL;
    amxo_parser_t* parser = NULL;
    int retval = 0;

    amxut_bus_setup(NULL);
    sahTraceSetLevel(TRACE_LEVEL_INFO);
    sahTraceAddZone(TRACE_LEVEL_INFO, "usb");

    dm = amxut_bus_dm();
    parser = amxut_bus_parser();
    assert_non_null(dm);
    assert_non_null(parser);
    root = amxd_dm_get_root(dm);
    assert_non_null(root);

    init_resolver(parser);

    retval = amxo_parser_parse_file(parser, "../../odl/tr181-usb_definition.odl", root);
    printf("PARSER MESSAGE = %s\n", amxc_string_get(&parser->msg, 0));
    assert_int_equal(retval, 0);

    retval = amxo_parser_parse_file(parser, "../../odl/defaults.d/00_tr181-usb_default.odl", root);
    printf("PARSER MESSAGE = %s\n", amxc_string_get(&parser->msg, 0));
    assert_int_equal(retval, 0);

    retval = amxo_parser_parse_file(parser, "./test_events.odl", root);
    printf("PARSER MESSAGE = %s\n", amxc_string_get(&parser->msg, 0));
    assert_int_equal(retval, 0);
    assert_int_equal(_main(AMXO_START, dm, amxut_bus_parser()), 0);

    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:start", NULL);
    amxut_bus_handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    amxd_dm_t* dm = NULL;

    dm = amxut_bus_dm();
    assert_non_null(dm);

    amxp_sigmngr_emit_signal(&dm->sigmngr, "app:stop", NULL);
    amxut_bus_handle_events();

    assert_int_equal(_main(AMXO_STOP, dm, amxut_bus_parser()), 0);

    // Close all dynamically loaded modules to prevent memory leaks
    amxm_close_all();

    amxut_bus_teardown(NULL);

    return 0;
}

void test_exec_addBus(UNUSED void** state) {
    amxd_object_t* usb = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    usb = amxd_dm_findf(amxut_bus_dm(), "%s", "USB");
    assert_non_null(usb);

    // some bad cases
    assert_int_not_equal(amxd_object_invoke_function(usb, "addBus", NULL, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addBus", NULL, &ret), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addBus", &args, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addBus", &args, &ret), 0);

    // a good case
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "busnum", "2");
    amxc_var_add_key(cstring_t, &args, "usbversion", "3.10");
    amxc_var_add_key(cstring_t, &args, "usbtype", "xHCI");
    assert_int_equal(amxd_object_invoke_function(usb, "addBus", &args, &ret), 0);

    // Check Added USB host Parameters
    amxut_dm_param_equals(cstring_t, "USB.USBHosts.Host.2.", "USBVersion", "3.10");
    amxut_dm_param_equals(cstring_t, "USB.USBHosts.Host.2.", "Type", "xHCI");
    amxut_dm_param_equals(bool, "USB.USBHosts.Host.2.", "Enable", true);

    // display USB Host data model
    if(amxb_get(amxb_be_who_has("USB."), "USB.USBHosts.Host.", 20, &ret, 10) == AMXB_STATUS_OK) {
        amxc_var_cast(&ret, AMXC_VAR_ID_JSON);
        const char* ret_str = amxc_var_constcast(jstring_t, &ret);
        SAH_TRACEZ_ERROR("TEST", "USB Hosts : %s", ret_str);
    }

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_exec_addDev(UNUSED void** state) {
    amxd_object_t* usb = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    usb = amxd_dm_findf(amxut_bus_dm(), "%s", "USB");
    assert_non_null(usb);

    // some bad cases
    assert_int_not_equal(amxd_object_invoke_function(usb, "addDev", NULL, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addDev", NULL, &ret), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addDev", &args, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "addDev", &args, &ret), 0);

    // a good case
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "type", "disk");
    amxc_var_add_key(cstring_t, &args, "sysfs", "2-1");
    amxc_var_add_key(cstring_t, &args, "name", "sda");
    assert_int_equal(amxd_object_invoke_function(usb, "addDev", &args, &ret), 0);

    // display USB Host Device data model
    if(amxb_get(amxb_be_who_has("USB."), "USB.USBHosts.Host.*.Device.", 20, &ret, 10) == AMXB_STATUS_OK) {
        amxc_var_cast(&ret, AMXC_VAR_ID_JSON);
        const char* ret_str = amxc_var_constcast(jstring_t, &ret);
        SAH_TRACEZ_ERROR("TEST", "USB Devices : %s", ret_str);
    }

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_exec_delDev(UNUSED void** state) {
    amxd_object_t* usb = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    usb = amxd_dm_findf(amxut_bus_dm(), "%s", "USB");
    assert_non_null(usb);

    // some bad cases
    assert_int_not_equal(amxd_object_invoke_function(usb, "delDev", NULL, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "delDev", NULL, &ret), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "delDev", &args, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "delDev", &args, &ret), 0);

    // a good case
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "type", "disk");
    amxc_var_add_key(cstring_t, &args, "sysfs", "2-1");
    amxc_var_add_key(cstring_t, &args, "name", "sda");
    assert_int_equal(amxd_object_invoke_function(usb, "delDev", &args, &ret), 0);

    // display USB Host Device data model
    if(amxb_get(amxb_be_who_has("USB."), "USB.USBHosts.Host.*.Device.", 20, &ret, 10) == AMXB_STATUS_OK) {
        amxc_var_cast(&ret, AMXC_VAR_ID_JSON);
        const char* ret_str = amxc_var_constcast(jstring_t, &ret);
        SAH_TRACEZ_ERROR("TEST", "USB Devices : %s", ret_str);
    }
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_exec_reset(UNUSED void** state) {
    amxd_object_t* host = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    host = amxd_dm_findf(amxut_bus_dm(), "%s", "USB.USBHosts.Host.2.");
    assert_non_null(host);


    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &args, "Reset", 1);
    int rv = 0;
    if((rv = amxb_set(amxb_be_who_has("USB."), "USB.USBHosts.Host.2.", &args, &ret, 5)) != AMXB_STATUS_OK) {
        SAH_TRACEZ_ERROR("TEST", "Reset Host Failed rv (%d)", rv);
        goto exit;
    }

    // Check USB host Reset Parameter
    amxut_dm_param_equals(bool, "USB.USBHosts.Host.2.", "Reset", true);

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_exec_eject(UNUSED void** state) {
    amxd_object_t* usb = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    usb = amxd_dm_findf(amxut_bus_dm(), "%s", "USB");
    assert_non_null(usb);

    // some bad cases
    assert_int_not_equal(amxd_object_invoke_function(usb, "eject", NULL, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "eject", NULL, &ret), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "eject", &args, NULL), 0);
    assert_int_not_equal(amxd_object_invoke_function(usb, "eject", &args, &ret), 0);

    // a good case
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "device", "USB.USBHosts.Host.2.Device.1.");
    amxc_var_add_key(bool, &args, "force", 0);
    assert_int_equal(amxd_object_invoke_function(usb, "eject", &args, &ret), 0);

    // display USB Host Device data model
    if(amxb_get(amxb_be_who_has("USB."), "USB.USBHosts.Host.*.Device.", 20, &ret, 10) == AMXB_STATUS_OK) {
        amxc_var_cast(&ret, AMXC_VAR_ID_JSON);
        const char* ret_str = amxc_var_constcast(jstring_t, &ret);
        SAH_TRACEZ_ERROR("TEST", "USB Devices : %s", ret_str);
    }
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_pwr_status(UNUSED void** state) {
    amxd_object_t* port = NULL;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    port = amxd_dm_findf(amxut_bus_dm(), "%s", "USB.Port.1.");
    assert_non_null(port);

    const amxc_var_t* name = amxd_object_get_param_value(port, "Name");
    const amxc_var_t* std = amxd_object_get_param_value(port, "Standard");
    assert_non_null(name);
    assert_non_null(std);
    assert_string_equal(GET_CHAR(name, NULL), "usb-Port-1");
    assert_string_equal(GET_CHAR(std, NULL), "2.0");

    // app:start should have triggered dm_usb_soc_set_pwr via dm_usb_ports_pwr_init
    const amxc_var_t* cap = amxd_object_get_param_value(port, "PowerCapability");
    const amxc_var_t* status = amxd_object_get_param_value(port, "PowerStatus");
    assert_non_null(cap);
    assert_non_null(status);
    assert_string_equal(GET_CHAR(cap, NULL), "On,Off,LowPower");
    assert_string_equal(GET_CHAR(status, NULL), "On");

    // Change power mode asynchronously to Off and verify update
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "Off");
    int rv = amxd_object_invoke_function(port, "ChangePowerMode", &args, &ret);
    assert_int_equal(rv, amxd_status_deferred);

    // Mock async completion
    amxc_var_t dummy;
    amxc_var_init(&dummy);
    amxm_execute_function(NULL, MOD_PWR_CTRL, "pwr-async-done", &dummy, &ret);
    amxc_var_clean(&dummy);

    // Verify PowerStatus has been updated to Off
    status = amxd_object_get_param_value(port, "PowerStatus");
    assert_non_null(status);
    assert_string_equal(GET_CHAR(status, NULL), "Off");

    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_power_state_validator(UNUSED void** state) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_init(&args);
    amxc_var_init(&ret);

    const char* path = "USB.Port.1.";

    // Valid values from PowerCapability
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "On");
    assert_int_equal(amxb_set(amxb_be_who_has("USB."), path, &args, &ret, 5), AMXB_STATUS_OK);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "Off");
    assert_int_equal(amxb_set(amxb_be_who_has("USB."), path, &args, &ret, 5), AMXB_STATUS_OK);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "LowPower");
    assert_int_equal(amxb_set(amxb_be_who_has("USB."), path, &args, &ret, 5), AMXB_STATUS_OK);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    // Invalid value not in capabilities
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "InvalidValue");
    assert_int_not_equal(amxb_set(amxb_be_who_has("USB."), path, &args, &ret, 5), AMXB_STATUS_OK);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);

    // Allowed fallback value provided via validator (Error)
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "PowerState", "Error");
    assert_int_equal(amxb_set(amxb_be_who_has("USB."), path, &args, &ret, 5), AMXB_STATUS_OK);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}

void test_usb_port_added(UNUSED void** state) {
    // Create a new USB.Port instance with index 2 and Name "2"
    amxd_trans_t trans;
    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_select_pathf(&trans, "USB.Port.");
    amxd_trans_add_inst(&trans, 2, NULL);
    amxd_trans_set_value(cstring_t, &trans, "Name", "2");

    assert_int_equal(amxd_trans_apply(&trans, amxut_bus_dm()), 0);

    amxut_bus_handle_events();

    // Verify the handler triggered power init on the new port
    amxut_dm_param_equals(csv_string_t, "USB.Port.2.", "PowerCapability", "On,Off,LowPower");
    amxut_dm_param_equals(cstring_t, "USB.Port.2.", "PowerStatus", "On");

    amxd_trans_clean(&trans);
}
