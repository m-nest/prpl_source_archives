/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <inttypes.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_expression.h>
#include <amxd/amxd_parameter.h>
#include <amxo/amxo.h>
#include <amxo/amxo_mibs.h>

#include "amxo_version.h"
#include "test_parse_large_file.h"

#define UNUSED __attribute__((unused))

static void event_handler(UNUSED const char* const sig_name, UNUSED const amxc_var_t* const data, UNUSED void* const priv) {
}

static amxd_status_t action_handler(amxd_object_t* object,
                                    amxd_param_t* param,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv) {
    amxd_status_t status = amxd_status_ok;
    switch(reason) {
    case action_param_read:
        status = amxd_action_param_read(object, param, reason, args, retval, priv);
        break;
    case action_param_write:
        status = amxd_action_param_write(object, param, reason, args, retval, priv);
        break;
    case action_param_validate:
        status = amxd_action_param_validate(object, param, reason, args, retval, priv);
        break;
    case action_param_describe:
        status = amxd_action_param_describe(object, param, reason, args, retval, priv);
        break;
    case action_param_destroy:
        status = amxd_action_param_destroy(object, param, reason, args, retval, priv);
        break;
    case action_object_read:
        status = amxd_action_object_read(object, param, reason, args, retval, priv);
        break;
    case action_object_write:
        status = amxd_action_object_write(object, param, reason, args, retval, priv);
        break;
    case action_object_validate:
        status = amxd_action_object_validate(object, param, reason, args, retval, priv);
        break;
    case action_object_list:
        status = amxd_action_object_list(object, param, reason, args, retval, priv);
        break;
    case action_object_describe:
        status = amxd_action_object_describe(object, param, reason, args, retval, priv);
        break;
    case action_object_add_inst:
        status = amxd_action_object_add_inst(object, param, reason, args, retval, priv);
        break;
    case action_object_del_inst:
        status = amxd_action_object_del_inst(object, param, reason, args, retval, priv);
        break;
    case action_object_destroy:
        status = amxd_action_object_destroy(object, param, reason, args, retval, priv);
        break;
    default:
        status = amxd_status_function_not_implemented;
    }
    return status;
}

static amxd_status_t method(UNUSED amxd_object_t* object,
                            UNUSED amxd_function_t* func,
                            UNUSED amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    return amxd_status_ok;
}

void test_read_abspeedtest(UNUSED void** state) {
    amxd_dm_t dm;
    amxo_parser_t parser;
    int retval = 0;

    amxd_dm_init(&dm);
    amxo_parser_init(&parser);

    amxo_resolver_ftab_add(&parser, "dummy_handler", AMXO_FUNC(event_handler));
    retval = amxo_parser_parse_file(&parser, "./odl/abspeedtest/tr181-abspeedtest.odl", amxd_dm_get_root(&dm));

    if(retval != 0) {
        printf("%s\n", amxo_parser_get_message(&parser));
    }
    assert_int_equal(retval, 0);

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

void test_read_tr181_bridging(UNUSED void** state) {
    amxd_dm_t dm;
    amxo_parser_t parser;
    int retval = 0;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    amxd_dm_init(&dm);
    amxo_parser_init(&parser);

    amxo_resolver_ftab_add(&parser, "dummy_action", AMXO_FUNC(action_handler));
    amxo_resolver_ftab_add(&parser, "dummy_handler", AMXO_FUNC(event_handler));
    amxo_resolver_ftab_add(&parser, "AddPort", AMXO_FUNC(method));
    amxo_resolver_ftab_add(&parser, "DisablePort", AMXO_FUNC(method));
    amxo_resolver_ftab_add(&parser, "GetMACList", AMXO_FUNC(method));
    retval = amxo_parser_parse_file(&parser, "./odl/tr181-bridging/tr181-bridging.odl", amxd_dm_get_root(&dm));

    if(retval != 0) {
        printf("%s\n", amxo_parser_get_message(&parser));
    }
    assert_int_equal(retval, 0);

    object = amxd_dm_findf(&dm, "Bridging.Bridge.Port.");
    assert_non_null(object);
    param = amxd_object_get_param_def(object, "Type");
    assert_non_null(param);
    assert_true(amxd_param_has_action(param, action_param_validate));

    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);
}

