/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>

#include <amxc/amxc.h>
#include <amxm/amxm.h>
#include <amxp/amxp_signal.h>
#include <amxd/amxd_transaction.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>

#include <lcm/lcm_remote_object.h>
#include <lcm/lcm_assert.h>
#include "lcm_priv.h"
#include "test_lcm_remote_object.h"
#include "log.h"
#include "lcm_bus.h"

#define ME "test"

static const char* main = "main";
static lcm_bus_t* main_bus = NULL;

const char* users_odl = "\
%define {\
    object Users{\
        object User[]{\
            string Alias;\
        }\
    }\
}\
%populate {\
    object \"Users.User\" {\
        instance add(1) {\
            parameter 'Alias' = \"User1\";\
        }\
        instance add(2) {\
            parameter 'Alias' = \"User2\";\
        }\
    }\
}\
";



/**
 * @brief Setup function for LCM remote object tests.
 *
 * Initializes tracing, creates the main bus, and adds necessary signals.
 *
 * @param state Test state (unused).
 * @return 0 on success.
 */
int test_lcm_remote_object_setup(UNUSED void** state) {
    sahTraceOpen("test", TRACE_TYPE_STDOUT);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "all");
    main_bus = lcm_bus_create(main);
    assert_int_equal(amxp_sigmngr_add_signal(NULL, "app:start"), 0);
    assert_int_equal(amxp_sigmngr_add_signal(NULL, "app:stop"), 0);
    amxp_sigmngr_add_signal(NULL, "wait:done");
    amxp_sigmngr_add_signal(NULL, "wait:available");

    return 0;
}

/**
 * @brief Teardown function for LCM remote object tests.
 *
 * Deletes the main bus and closes tracing.
 *
 * @param state Test state (unused).
 * @return 0 on success.
 */
int test_lcm_remote_object_teardown(UNUSED void** state) {
    lcm_bus_delete(&main_bus, true);
    sahTraceClose();
    return 0;
}

/**
 * @brief Test registering a remote object with no object name.
 *
 * Verifies that passing NULL to lcm_remote_object_register returns NULL.
 *
 * @param state Test state (unused).
 */
void test_lro_register_remote_no_object(UNUSED void** state) {
    LOG_ENTRY

    remote_object_t* remote_object = lcm_remote_object_register(NULL);
    assert_null(remote_object);


    LOG_EXIT
}

/**
 * @brief Test registering a remote object when the object is not present at start.
 *
 * Registers a remote object for "Users." which is not present initially.
 *
 * @param state Test state (unused).
 */
void test_lro_register_remote_absent_at_start(UNUSED void** state) {
    LOG_ENTRY

    const char* object_dm_name = "Users.";

    remote_object_t* remote_object = lcm_remote_object_register(object_dm_name);
    assert_non_null(remote_object);
    assert_null(remote_object->bus_ctx);
    assert_string_equal(remote_object->object_dm_name, object_dm_name);

    // load DM
    // -> dummy backend has no support for wait_for so this code cannot be tested in this environment

    // lcm_bus_t* bus_users = lcm_bus_create("users");
    // assert_true(bus_users);
    // if(amxo_parser_parse_string(&bus_users->parser, users_odl, amxd_dm_get_root(&bus_users->dm))) {
    //     SAH_TRACEZ_ERROR(ME, "%s", amxo_parser_get_message(&bus_users->parser));
    //     assert_true(0);
    // }

    lcm_remote_object_unregister(&remote_object);

    LOG_EXIT
}

/**
 * @brief Test registering a remote object when the object is present at start.
 *
 * Registers a remote object for "Users." which is present.
 *
 * @param state Test state (unused).
 */
void test_lro_register_remote_present_at_start(UNUSED void** state) {
    LOG_ENTRY

    const char* object_dm_name = "Users.";

    lcm_bus_t* bus_users = lcm_bus_create("users");
    assert_true(bus_users);
    if(amxo_parser_parse_string(&bus_users->parser, users_odl, amxd_dm_get_root(&bus_users->dm))) {
        SAH_TRACEZ_ERROR(ME, "%s", amxo_parser_get_message(&bus_users->parser));
        assert_true(0);
    }


    remote_object_t* remote_object = lcm_remote_object_register(object_dm_name);
    assert_non_null(remote_object);
    assert_non_null(remote_object->bus_ctx);
    assert_string_equal(remote_object->object_dm_name, object_dm_name);

    lcm_remote_object_unregister(&remote_object);

    lcm_bus_delete(&bus_users, false);
    LOG_EXIT
}

#define PATH_PREFIX "Users.User."

void test_get_index_from_path(UNUSED void** state) {
    LOG_ENTRY
    bool ret;
    uint32_t index;

    const char* first_path = PATH_PREFIX "1.";
    const char* second_path = PATH_PREFIX "255.";
    const char* third_path_without_dot = PATH_PREFIX "1099";
    const char* overflow_path = PATH_PREFIX "18446744073709551615.";
    const char* fourth_path_without_dot = PATH_PREFIX "9999";

    ret = get_index_from_path(NULL, NULL, true);
    assert_false(ret);

    ret = get_index_from_path((first_path + sizeof(PATH_PREFIX) - 1), NULL, true);
    assert_false(ret);

    ret = get_index_from_path(NULL, &index, true);
    assert_false(ret);

    ret = get_index_from_path((third_path_without_dot + sizeof(PATH_PREFIX) - 1), &index, true);
    assert_false(ret);

    ret = get_index_from_path((overflow_path + sizeof(PATH_PREFIX) - 1), &index, true);
    assert_false(ret);

    ret = get_index_from_path((first_path + sizeof(PATH_PREFIX) - 1), &index, true);
    assert_true(ret);
    assert_int_equal(index, 1);

    ret = get_index_from_path((second_path + sizeof(PATH_PREFIX) - 1), &index, true);
    assert_true(ret);
    assert_int_equal(index, 255);

    ret = get_index_from_path((third_path_without_dot + sizeof(PATH_PREFIX) - 1), &index, false);
    assert_true(ret);
    assert_int_equal(index, 1099);

    ret = get_index_from_path((fourth_path_without_dot + sizeof(PATH_PREFIX) - 1), &index, false);
    assert_true(ret);
    assert_int_equal(index, 9999);

    LOG_EXIT
}
