/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>

#include "gmap_mod_dnssd.h"
#include "gmap_mod_dnssd_utils.h"

#define ME "gmap-mod-dnssd"
#define DNSSD_SERVICE_ADD_DELAY_MS 2000
#define DNSSD_SERVICE_PATH "DNSSD.Service."
#define TEXT_RECORD_PATH "TextRecord."
#define GMAP_DEVICES_DEVICE_PATH "Devices.Device."
#define GMAP_DNSSD_DM_ROOT_PATH "DNSSD."

/**
 * @ingroup gmap_mod_dnssd
 * @brief Structure representing the DNSSD module context.
 *
 * This structure holds the main context for the gmap-mod-dnssd module,
 * including references to the device management and parser instances.
 */
typedef struct _mod_dnssd {
    amxd_dm_t* dm;         /**< Pointer to the device management context. */
    amxo_parser_t* parser; /**< Pointer to the AMXO parser instance. */
} mod_dnssd_t;

/**
 * @ingroup gmap_mod_dnssd
 * @brief Main DNSSD module context.
 *
 * Holds the global state for the gmap-mod-dnssd module, including
 * device management and parser references.
 */
static mod_dnssd_t mod_dnssd;

/**
 * @ingroup gmap_mod_dnssd
 * @brief GMAP bus context pointer.
 *
 * Points to the global GMAP bus context used for inter-module communication.
 */
static amxb_bus_ctx_t* gmap_ctx;

/**
 * @ingroup gmap_mod_dnssd
 * @brief DNSSD bus context pointer.
 *
 * Points to the DNSSD bus context used for module-specific messaging.
 */
static amxb_bus_ctx_t* dnssd_ctx;

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Deferred handler for adding a service.
 *
 * This function is triggered by a timer callback. It forwards the stored data
 * to the `service_addition()` function, then cleans up the timer and the
 * associated data structure.
 *
 * @param timer  Pointer to the AMX timer that triggered the callback.
 *               This timer will be deleted inside this function.
 * @param priv   Private data passed to the callback. Expected to be an
 *               `amxc_var_t*` containing service information. This data
 *               will be freed by this function.
 *
 * @note This function takes ownership of both `timer` and `priv`.
 *       After the call, both are deleted and must not be used again.
 */
static void service_addition_deferred(amxp_timer_t* timer, void* priv) {
    amxc_var_t* data = (amxc_var_t*) priv;
    service_addition(data);
    amxp_timer_delete(&timer);
    amxc_var_delete(&data);
}

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Deferred callback used to add a TXT record.
 *
 * This function is executed when the timer expires. It forwards the provided
 * data to `txt_record_addition()`, then frees both the timer and the data.
 *
 * @param timer Pointer to the AMX timer that triggered this callback.
 * @param priv  Private data passed to the callback (expected to be an
 *              `amxc_var_t*`). It will be deleted inside this function.
 */
static void txt_record_addition_deferred(amxp_timer_t* timer, void* priv) {
    amxc_var_t* data = (amxc_var_t*) priv;
    txt_record_addition(data);
    amxp_timer_delete(&timer);
    amxc_var_delete(&data);
}

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Notification handler triggered when a DNSSD instance is added.
 *
 * This callback is invoked on instance addition events (services or TXT
 * records). Depending on the notification path, it schedules a deferred timer
 * to process the addition of either:
 *   - a DNSSD service (`DNSSD.Service.`)
 *   - a DNSSD TXT record (`TextRecord.`)
 *
 * For both cases, the function:
 *   - Creates a copy of the incoming data.
 *   - Allocates a deferred timer.
 *   - Starts the timer with a 2-second delay.
 *
 * @param sig_name  Unused. Name of the received signal.
 * @param data      Notification data containing the DNSSD instance path.
 * @param sub_data  Unused. Subscriber-specific private data.
 *
 * @note This function does not directly process service/TXT record additions.
 *       It defers the work to timer callbacks:
 *       - ::service_addition_deferred
 *       - ::txt_record_addition_deferred
 *
 * @warning Memory ownership for `timer_data` is transferred to the timer
 *          callback, which is responsible for freeing it.
 */
static void instance_addition_notify_handler(UNUSED const char* const sig_name,
                                             const amxc_var_t* const data,
                                             UNUSED void* const sub_data) {
    const char* path = GET_CHAR(data, "path");

    when_str_empty_trace(path, exit, ERROR, "No notification path found");
    if(strcmp(path, DNSSD_SERVICE_PATH) == 0) {
        amxp_timer_t* timer = NULL;
        amxc_var_t* timer_data = NULL;
        amxc_var_new(&timer_data);
        amxc_var_copy(timer_data, data);
        amxp_timer_new(&timer, service_addition_deferred, timer_data);
        amxp_timer_start(timer, DNSSD_SERVICE_ADD_DELAY_MS);
    }

    if(strstr(path, TEXT_RECORD_PATH) != NULL) {
        amxp_timer_t* timer = NULL;
        amxc_var_t* timer_data = NULL;
        amxc_var_new(&timer_data);
        amxc_var_copy(timer_data, data);
        amxp_timer_new(&timer, txt_record_addition_deferred, timer_data);
        amxp_timer_start(timer, DNSSD_SERVICE_ADD_DELAY_MS);
    }

exit:
    return;
}

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Notification handler triggered when a DNSSD instance is removed.
 *
 * This function is invoked when a DNSSD service instance is deleted. If the
 * notification path corresponds to `DNSSD.Service.`, the function forwards the
 * event to `service_removal()`.
 * TXT Record removals are not handled here.
 *
 * @param sig_name  Unused. Name of the emitted signal.
 * @param data      Notification data containing the DNSSD instance path.
 * @param sub_data  Unused. Subscriber-specific private data.
 *
 * @note This handler performs the removal immediately, unlike additions which
 *       use deferred timers.
 *
 * @warning The function expects `data` to contain a valid `"path"` field.
 */
static void instance_removal_notify_handler(UNUSED const char* const sig_name,
                                            const amxc_var_t* const data,
                                            UNUSED void* const sub_data) {

    const char* path = GET_CHAR(data, "path");
    when_str_empty_trace(path, error, ERROR, "No notification path found");
    if(strcmp(path, DNSSD_SERVICE_PATH) == 0) {
        service_removal(data);
    }
error:
    return;
}

/**
 * @ingroup gmap_mod_dnssd
 *
 * @brief Initializes the GMAP DNSSD module.
 *
 * This function initializes the module by:
 *  - Storing the data model and parser references.
 *  - Retrieving the GMAP context (`Devices.Device.`).
 *  - Initializing the GMAP client.
 *  - Retrieving the DNSSD context (`DNSSD.`).
 *  - Subscribing to DNSSD service instance addition and removal notifications.
 *  - Performing initial DNSSD service synchronization.
 *
 * @param dm      Pointer to the AMX data model associated with the module.
 * @param parser  Pointer to the parser instance used during module loading.
 *
 * @return 0 on success, or -1 if initialization failed.
 *
 * @note Subscriptions use the following notifications:
 *       - `dm:instance-added` → ::instance_addition_notify_handler
 *       - `dm:instance-removed` → ::instance_removal_notify_handler
 *
 * @warning The function expects the backend to expose the objects
 *          `"Devices.Device."` and `"DNSSD."`. If not found, initialization
 *          fails.
 */
static int gmap_mod_dnssd_init(amxd_dm_t* dm, amxo_parser_t* parser) {
    gmap_ctx = NULL;
    int ret = 0;

    mod_dnssd.dm = dm;
    mod_dnssd.parser = parser;

    gmap_ctx = amxb_be_who_has(GMAP_DEVICES_DEVICE_PATH);
    when_null_trace(gmap_ctx, error, ERROR, "Could not find Devices.Device");

    gmap_client_init(gmap_ctx);


    dnssd_ctx = amxb_be_who_has(GMAP_DNSSD_DM_ROOT_PATH);
    when_null_trace(dnssd_ctx, error, ERROR, "Could not find DNSSD.");
    when_failed_trace(amxb_subscribe(dnssd_ctx, DNSSD_SERVICE_PATH, "notification in ['dm:instance-added']", instance_addition_notify_handler, NULL), error, ERROR, "Could not create addition subscription");
    when_failed_trace(amxb_subscribe(dnssd_ctx, DNSSD_SERVICE_PATH, "notification in ['dm:instance-removed']", instance_removal_notify_handler, NULL), error, ERROR, "Could not create deletion subscription");
    service_initialization();

    return ret;

error:
    ret = -1;
    return ret;
}

/**
 * @brief Cleans and shuts down the GMAP DNSSD module.
 *
 * This function removes all subscriptions created during initialization,
 * releases backend contexts, and resets internal module pointers.
 * It is typically called when the module is unloaded.
 *
 * The function performs the following steps:
 * - Unsubscribes from DNSSD.Service instance-addition and instance-removal notifications.
 * - Clears references to the device manager and parser.
 * - Resets global backend contexts (gmap_ctx and dnssd_ctx) to NULL.
 *
 * @note All unsubscribe operations are performed only if the DNSSD backend
 *       context is valid.
 *
 * @return void
 */
static void gmap_mod_dnssd_clean(void) {
    mod_dnssd.dm = NULL;
    mod_dnssd.parser = NULL;

    amxb_unsubscribe(dnssd_ctx, "DNSSD.Service.", instance_addition_notify_handler, NULL);
    amxb_unsubscribe(dnssd_ctx, "DNSSD.Service.", instance_removal_notify_handler, NULL);
    gmap_ctx = NULL;
    dnssd_ctx = NULL;
}

amxb_bus_ctx_t* retrieve_gmap_ctx(void) {
    return gmap_ctx;
}

amxb_bus_ctx_t* retrieve_dnssd_ctx(void) {
    return dnssd_ctx;
}

int _gmap_mod_dnssd_entrypoint(int reason,
                               amxd_dm_t* datamodel,
                               amxo_parser_t* parser) {
    int ret = 0;

    switch(reason) {
    case AMXO_START:
        ret = gmap_mod_dnssd_init(datamodel, parser);
        break;
    case AMXO_STOP:
        gmap_mod_dnssd_clean();
        break;
    default:
        break;
    }

    return ret;
}