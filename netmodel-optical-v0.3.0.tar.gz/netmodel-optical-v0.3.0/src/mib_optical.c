/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_path.h>
#include <amxs/amxs.h>
#include <amxm/amxm.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>
#include <netmodel/client.h>
#include <netmodel/mib.h>
#include "mib_optical.h"

#define ME "optical_mib"
#define MOD "optical"
#define string_empty(x) ((x == NULL) || (*x == '\0'))

/**
 * @brief Updates the specified flag for a network model interface.
 *
 * @param netmodel_intf The network model interface to update.
 * @param flag The name of the flag to set or clear.
 * @param set A boolean indicating whether to set (true) or clear (false) the flag.
 */
static void update_flag(const char* netmodel_intf, const char* flag, bool set) {
    amxc_var_t args;
    amxc_var_t ret;
    int status = AMXB_ERROR_UNKNOWN;
    const char* function = set ? "setFlag" : "clearFlag";

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "flag", flag);

    status = amxb_call(netmodel_get_amxb_bus(), netmodel_intf, function, &args, &ret, 5);
    when_failed_trace(status, exit, ERROR, "Failed to call %s%s(flag='%s')", netmodel_intf, function, flag);

exit:
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
}


/**
 * @brief Callback function triggered by MIB actions for status updates.
 *
 * @param sync_entry The synchronization entry related to this callback.
 * @param direction The synchronization direction (A to B or B to A).
 * @param data The data associated with the synchronization.
 * @param priv Private data, unused in this function.
 * @return Returns amxs_status_ok to indicate success.
 */
static amxs_status_t status_action_cb(const amxs_sync_entry_t* sync_entry UNUSED,
                                      amxs_sync_direction_t direction,
                                      amxc_var_t* data,
                                      void* priv UNUSED) {
    const char* netmodel_intf = GET_CHAR(data, "path");
    const char* status = GETP_CHAR(data, "parameters.Status");
    bool is_up = false;

    SAH_TRACEZ_INFO(ME, "Mib action triggered");

    when_false((direction == amxs_sync_a_to_b), exit);

    is_up = !string_empty(status) && (strcmp(status, "Up") == 0);

    update_flag(netmodel_intf, "optical-up", is_up);
exit:
    return amxs_status_ok;
}

/**
 * @brief Callback function triggered for upstream action synchronization.
 *
 * @param sync_entry The synchronization entry related to this callback.
 * @param direction The synchronization direction (A to B or B to A).
 * @param data The data associated with the synchronization.
 * @param priv Private data, unused in this function.
 * @return Returns amxs_status_ok to indicate success.
 */
static amxs_status_t upstream_action_cb(const amxs_sync_entry_t* sync_entry UNUSED, amxs_sync_direction_t direction, amxc_var_t* data, void* priv UNUSED) {
    const char* netmodel_intf = GET_CHAR(data, "path");

    when_false((direction == amxs_sync_a_to_b), exit);

    amxs_sync_param_copy_action_cb(sync_entry, direction, data, priv);

    update_flag(netmodel_intf, "upstream", GETP_BOOL(data, "parameters.Upstream"));
exit:
    return amxs_status_ok;
}


/**
 * @brief Sets up synchronization parameters for MIB actions.
 *
 * @param ctx The synchronization context to set up parameters in.
 * @return Returns the status of the operation.
 */
static amxs_status_t setup_parameters_sync(amxs_sync_ctx_t* ctx) {
    amxs_status_t status = amxs_status_unknown_error;

    status = amxs_sync_ctx_add_new_param(ctx, "Upstream", "Upstream", AMXS_SYNC_ONLY_A_TO_B, amxs_sync_param_copy_trans_cb, upstream_action_cb, NULL);
    status |= amxs_sync_ctx_add_new_param(ctx, "Status", "Status", AMXS_SYNC_ONLY_A_TO_B, amxs_sync_param_copy_trans_cb, status_action_cb, NULL);

    return status;
}

static netmodel_mib_t mib = {
    .name = ME,
    .root = "Optical.",
    .add_sync_parameters = setup_parameters_sync,
};

/**
 * @brief Callback function invoked when a MIB is added.
 *
 * @param function_name The name of the function being added (unused).
 * @param args The arguments for the MIB addition.
 * @param ret The return value (unused).
 * @return Returns 0 on success.
 */
int mib_added(UNUSED const char* const function_name,
              amxc_var_t* args,
              UNUSED amxc_var_t* ret) {
    netmodel_subscribe(args, &mib);

    return 0;
}

/**
 * @brief Callback function invoked when a MIB is removed.
 *
 * @param function_name The name of the function being removed (unused).
 * @param args The arguments for the MIB removal.
 * @param ret The return value (unused).
 * @return Returns 0 on success.
 */
int mib_removed(UNUSED const char* const function_name,
                amxc_var_t* args,
                UNUSED amxc_var_t* ret) {
    netmodel_unsubscribe(args, &mib);
    update_flag(GET_CHAR(args, "object"), "upstream optical-up", false);

    return 0;
}

/**
 * @brief Initializes the MIB.
 *
 * @return Returns 0 on success.
 */
static AMXM_CONSTRUCTOR mib_init(void) {
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;

    SAH_TRACEZ_INFO(ME, "Mib init triggered");

    amxm_module_register(&mod, so, MOD);
    amxm_module_add_function(mod, "mib-added", mib_added);
    amxm_module_add_function(mod, "mib-removed", mib_removed);

    netmodel_initialize();

    return 0;
}

/**
 * @brief Cleans up the MIB during module destruction.
 *
 * @return Returns 0 on success.
 */
static AMXM_DESTRUCTOR mib_clean(void) {
    SAH_TRACEZ_INFO(ME, "Mib clean triggered");

    netmodel_cleanup();

    return 0;
}
