/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__IP_MANAGER_IP_H_)
#define __IP_MANAGER_IP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ipv6_utils.h"

#define STATUS_ENABLED "Enabled"
#define STATUS_DISABLED "Disabled"
#define IPV4_STATUS_PARAM "IPv4Status"
#define IPV6_STATUS_PARAM "IPv6Status"
#define STATUS_ERROR "Error"
#define STATUS_UP "Up"
#define STATUS_DOWN "Down"
#define STATUS_NOTPRESENT "NotPresent"
#define IP_VERSION_4 4
#define IP_VERSION_6 6
#define IP_VERSION_4_FLAG "ipv4-up"
#define IP_VERSION_6_FLAG "ipv6-up"
#define NAS_3GPP_FLAG "cellular"

amxd_status_t ip_manager_status_notpresent(amxd_object_t* intf_obj);
amxd_status_t ip_manager_set_status(const amxd_object_t* instance, const char* status);
amxd_status_t ip_manager_intf_set_status(amxd_object_t* instance, const char* status);
int subscribe_if_added_to_netdev(amxd_object_t* intf_obj, amxd_object_t* addr_obj, const char* ip_addr, uint8_t ip_family);
int nm_open_dhcpoption_query(amxd_object_t* intf_obj,
                             netmodel_query_t** query,
                             const char* type,
                             int option,
                             netmodel_callback_t nm_cb,
                             void* userdata);
int nm_open_3gppnas_query(amxd_object_t* intf_obj,
                          netmodel_query_t** query,
                          const char* param,
                          netmodel_callback_t nm_cb,
                          void* userdata);
void nm_close_query(netmodel_query_t** query);
amxd_status_t make_ip_address_empty(amxd_object_t* addr_obj, uint8_t ip_family);
int update_ipv6_address(ipv6_addr_info_t* addr_info);

#ifdef __cplusplus
}
#endif

#endif // __IP_MANAGER_IP_H_
