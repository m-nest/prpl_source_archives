/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__GMAP_ETH_DEV_MOCK_H__)
#define __GMAP_ETH_DEV_MOCK_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_types.h>
#include <amxb/amxb_types.h>
#include <amxb/amxb_be.h>
#include <amxo/amxo.h>

#include <amxc/amxc_macros.h>
#include <amxd/amxd_dm.h>
#include <amxb/amxb_register.h>
#include <amxb/amxb_connect.h>

#include <gmap/gmap.h>
#include <linux/netlink.h>
#include <stdint.h>
#include <unistd.h>

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#define UNUSED __attribute__((unused))

/* Test Devices.Device[] entry aliases */
#define GMAP_DEV_ALIAS_2 "ID-c434b692-66e3-42a8-8c03-5e99a7099d13"
#define GMAP_DEV_ALIAS_3 "ID-c434b692-66e3-42a8-8c03-5e99a7089d13"
#define GMAP_DEV_ALIAS_4 "ID-c434b692-66e3-42a8-8c03-5e99a7089d14"
#define GMAP_DEV_ALIAS_8 "ID-c434b692-66e3-42a8-ceef-5e99a7099b19"
#define GMAP_DEV_ALIAS_9 "ID-c434b692-66e3-42a8-ceef-5e99a7089b17"
#define GMAP_DEV_ALIAS_10 "ID-c434b692-66e3-42a8-ceef-5e99a7089b18"

int _dummy_main(int reason, amxd_dm_t* dm, amxo_parser_t* parser);
void test_init_dummy_fn_resolvers(amxo_parser_t* parser);

/**
 * Transparent type.
 */
typedef struct {
    const char* will_return_key;
    bool will_return_already_exists;
    /** returnvalue of @ref gmap_devices_createDeviceOrGetKey() */
    bool will_return_success;
    const char* expected_key1;
    const char* expected_value_string1;
} mock_gmap_devices_createDeviceOrGetKey_mockdata_t;

/**
 *
 * `mock()` value is copied and must be of type @ref amxc_var_t of type @ref AMXC_VAR_ID_HTABLE.
 * Actual return value of @ref gmap_device_get will be of type @ref AMXC_VAR_ID_LIST.
 */

gmap_query_t* __wrap_gmap_query_open_ext(const char* expression, const char* name,
                                         gmap_query_cb_t fn, void* user_data);
bool __wrap_gmap_query_open_ext_2(gmap_query_t** query,
                                  const char* expression,
                                  const char* name,
                                  gmap_query_flags_t flags,
                                  gmap_query_cb_t fn,
                                  void* user_data);
void __wrap_gmap_query_close(gmap_query_t* query);
void gmap_query_exec_callback(gmap_query_t* query,
                              const char* key,
                              gmap_query_action_t action);


int __wrap_system(const char* __command);
int __wrap_amxc_ts_now(amxc_ts_t* tsp);
bool __wrap_is_ntp_time_synchronized(void);

bool __wrap_gmap_device_clearTag(const char* key, const char* tags, const char* expression, gmap_traverse_mode_t mode);
bool __wrap_gmap_device_setTag(const char* key, const char* tags, const char* expression, gmap_traverse_mode_t mode);
char* __wrap_gmap_devices_findByMac(const char* mac);
void __wrap_gmap_devices_destroyDevice(const char* key);

void mock_gmap_make_alternative(const char* master,
                                const char* alternative);
void mock_gmap_remove_alternative(const char* master,
                                  const char* alternative);

void mock_gmap_set_active(const char* key, bool active);

#ifdef __cplusplus
}
#endif

#endif // __GMAP_ETH_DEV_MOCK_H__
