/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdarg.h> // needed for cmocka
#include <setjmp.h> // needed for cmocka
#include <unistd.h> // needed for cmocka
#include <cmocka.h>

#include <string.h>
#include "gmap_eth_dev.h"
#include "gmap_eth_dev_bridging.h"
#include <amxo/amxo.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>
#include <amxut/amxut_bus.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_macros.h>
#include <amxut/amxut_timer.h>

#include "../common/test-setup.h"
#include "../common/test-util.h"
#include "../common/mock_gmap.h"
#include "test_bridging.h"
#include "mock_bridging.h"
#include <arpa/inet.h>


/**
 * @defgroup callbacks
 *
 * Utility to collect and verify callbacks.
 *
 * Every call to a callback pushes an item onto a list of @ref s_seen_item_t objects.
 *
 * Verification then compares this list with a predetermined null-item-terminated
 * list and prints out detailed error messages if the lists differ.
 *
 * @{
 */

typedef struct {
    char* bridge;
    uint32_t bridge_index;
    char* port;
    uint32_t port_index;
    char* mac;
    bool added;

    amxc_llist_it_t it;
} s_seen_item_t;

typedef struct {
    const char* bridge;
    uint32_t bridge_index;
    const char* port;
    uint32_t port_index;
    const char* mac;
    bool added;
} s_expected_item_t;

static bool s_expected_is_null(const s_expected_item_t* expected) {
    return (expected->bridge == NULL) && (expected->port == NULL) && (expected->mac == NULL);
}

static bool s_str_equals(const char* lhs,
                         const char* rhs) {
    return lhs == rhs || (lhs != NULL && rhs != NULL && strcmp(lhs, rhs) == 0);
}

static bool s_seen_is_expected(const s_seen_item_t* seen,
                               const s_expected_item_t* expected) {
    return s_str_equals(seen->bridge, expected->bridge) &&
           s_str_equals(seen->port, expected->port) &&
           s_str_equals(seen->mac, expected->mac) &&
           (seen->bridge_index == expected->bridge_index) &&
           (seen->port_index == expected->port_index) &&
           (seen->added == expected->added);
}

/** Converts the expected item to a string of valid C code showing its contents. */
static void s_expected_item_to_string(amxc_string_t* out,
                                      const s_expected_item_t* item) {
    assert_non_null(out);
    assert_non_null(item);
    if(item->bridge == NULL) {
        amxc_string_appendf(out, "{.bridge = NULL, ");
    } else {
        amxc_string_appendf(out, "{.bridge = \"%s\", ", item->bridge);
    }
    amxc_string_appendf(out, ".bridge_index = %" PRIu32 ", ", item->bridge_index);
    if(item->port == NULL) {
        amxc_string_appendf(out, ".port = NULL, ");
    } else {
        amxc_string_appendf(out, ".port = \"%s\", ", item->port);
    }
    amxc_string_appendf(out, ".port_index = %" PRIu32 ", ", item->port_index);
    if(item->mac == NULL) {
        amxc_string_appendf(out, ".mac = NULL, ");
    } else {
        amxc_string_appendf(out, ".mac = \"%s\", ", item->mac);
    }
    amxc_string_appendf(out, ".added = %s}", item->added ? "true" : "false");
}

/** Converts the seen item to a string of valid C code showing its contents. */
static void s_seen_item_to_string(amxc_string_t* out,
                                  const s_seen_item_t* seen) {
    assert_non_null(seen);
    s_expected_item_t expected = {
        .bridge = seen->bridge,
        .bridge_index = seen->bridge_index,
        .port = seen->port,
        .port_index = seen->port_index,
        .mac = seen->mac,
        .added = seen->added,
    };
    s_expected_item_to_string(out, &expected);
}

/** Print the entire recorded list of seen items as a piece of C code to create
 * the corresponding list of expected items. */
static void s_seen_list_print(amxc_llist_t* seen_list) {
    print_message("expected = ((s_expected_item_t[]) {\n");
    amxc_llist_for_each(it, seen_list) {
        s_seen_item_t* seen = amxc_llist_it_get_data(it, s_seen_item_t, it);
        amxc_string_t txt;
        amxc_string_init(&txt, 0);
        s_seen_item_to_string(&txt, seen);
        print_message("    %s,\n", amxc_string_get(&txt, 0));
        amxc_string_clean(&txt);
    }
    print_message("    { 0 }\n});\n");
}

static void _assert_seen_list(amxc_llist_t* seen_list,
                              const s_expected_item_t* expected,
                              const char* file,
                              int line) {
    size_t index = 0;

    _assert_true(seen_list != NULL, "seen_list == NULL", file, line);
    _assert_true(expected != NULL, "expected == NULL", file, line);

    amxc_llist_for_each(it, seen_list) {
        s_seen_item_t* seen = amxc_llist_it_get_data(it, s_seen_item_t, it);

        if(s_expected_is_null(expected)) {
            amxc_string_t tmp;
            amxc_string_init(&tmp, 0);
            s_seen_item_to_string(&tmp, seen);
            s_seen_list_print(seen_list);
            print_error("Unexpected item seen at index %zu:\n"
                        "  observed: %s\n"
                        "  expected: End of List\n",
                        index, amxc_string_get(&tmp, 0));
            amxc_string_clean(&tmp);

            _fail(file, line);
            return;
        }
        if(!s_seen_is_expected(seen, expected)) {
            amxc_string_t tmp1;
            amxc_string_init(&tmp1, 0);
            s_seen_item_to_string(&tmp1, seen);
            amxc_string_t tmp2;
            amxc_string_init(&tmp2, 0);
            s_expected_item_to_string(&tmp2, expected);
            s_seen_list_print(seen_list);
            print_error("Item mismatch seen at index %zu:\n"
                        "  observed: %s\n"
                        "  expected: %s\n",
                        index,
                        amxc_string_get(&tmp1, 0),
                        amxc_string_get(&tmp2, 0));
            amxc_string_clean(&tmp1);
            amxc_string_clean(&tmp2);

            _fail(file, line);
            return;
        }

        ++index;
        ++expected;
    }

    if(!s_expected_is_null(expected)) {
        amxc_string_t tmp;
        amxc_string_init(&tmp, 0);
        s_expected_item_to_string(&tmp, expected);
        print_error("Expected more items starting at index %zu:\n"
                    "  observed: End of List\n"
                    "  expected: %s\n",
                    index, amxc_string_get(&tmp, 0));
        amxc_string_clean(&tmp);

        _fail(file, line);
        return;
    }

}

#define assert_seen_list(actual, expected) _assert_seen_list(actual, expected, __FILE__, __LINE__)


/** @implements amxc_llist_it_delete_t */
static void s_delete_seen_item(amxc_llist_it_t* it) {
    s_seen_item_t* item = amxc_llist_it_get_data(it, s_seen_item_t, it);
    assert_non_null(it);
    free(item->bridge);
    free(item->port);
    free(item->mac);
    free(item);
}

static void s_seen_list_clear(amxc_llist_t* seen) {
    amxc_llist_clean(seen, s_delete_seen_item);
}

static void s_seen_list_push(amxc_llist_t* seen_list,
                             const char* bridge,
                             uint32_t bridge_index,
                             const char* port,
                             uint32_t port_index,
                             const char* mac,
                             bool added) {
    assert_non_null(seen_list);
    s_seen_item_t* seen_item;

    seen_item = calloc(1, sizeof(s_seen_item_t));
    assert_non_null(seen_item);
    amxc_llist_it_init(&seen_item->it);

    if(bridge != NULL) {
        seen_item->bridge = strdup(bridge);
        assert_non_null(seen_item->bridge);
    }
    seen_item->bridge_index = bridge_index;
    if(port != NULL) {
        seen_item->port = strdup(port);
        assert_non_null(seen_item->port);
    }
    seen_item->port_index = port_index;
    if(mac != NULL) {
        seen_item->mac = strdup(mac);
        assert_non_null(seen_item->mac);
    }
    seen_item->added = added;

    amxc_llist_append(seen_list, &seen_item->it);
}

static void s_test_port_cb(const gmap_eth_dev_bridging_port_data_t* data,
                           bool added,
                           void* priv) {
    amxc_llist_t* seen_list = priv;

    assert_non_null(data);
    assert_non_null(seen_list);

    s_seen_list_push(seen_list,
                     data->bridge, data->bridge_index,
                     data->port, data->port_index,
                     NULL,
                     added);
}

typedef struct {
    amxc_llist_t* seen_list;
    const char* bridge;
    const char* port;
} s_test_addr_cb_priv_t;

static void s_test_addr_cb(const char* mac_address,
                           bool added,
                           void* const priv) {
    s_test_addr_cb_priv_t* data = priv;

    assert_non_null(priv);
    assert_non_null(mac_address);

    s_seen_list_push(data->seen_list,
                     data->bridge, 0u,
                     data->port, 0u,
                     mac_address,
                     added);
}

/** @} */ // end group callbacks


int test_setup_bridging_listener(UNUSED void** state) {
    int result = amxut_bus_setup(state);
    when_false(result == 0, exit);

    bridging_setup_netdev();
    bridging_setup_mock();
    bridging_setup_discovered();

exit:
    return result;
}

int test_teardown_bridging_listener(UNUSED void** state) {
    bridging_teardown_discovered();
    bridging_teardown_mock();

    return amxut_bus_teardown(state);
}

void test_gmap_eth_dev_bridging_listener__init_no_bridging(UNUSED void** state) {
    // GIVEN bridging was not (yet) properly discovered
    assert_int_not_equal(gmap_eth_dev_bridging_discovered(), BRIDGING_DISCOVERY_SUPPORTED);
    assert_null(gmap_eth_dev_bridging_ctx());

    // THEN initializing the main bridging listener will fail
    assert_int_not_equal(gmap_eth_dev_bridging_init(), 0);

    // cleanup (no-op)
    gmap_eth_dev_bridging_clean();
}

void test_gmap_eth_dev_bridging_listener__init_twice(UNUSED void** state) {
    // GIVEN a discovered bridging in the test setup

    // THEN initializing the main bridging lsitener will succeed
    assert_int_equal(gmap_eth_dev_bridging_init(), 0);

    // AND initializing a second time will not fail
    assert_int_equal(gmap_eth_dev_bridging_init(), 0);

    // cleanup
    gmap_eth_dev_bridging_clean();
}

void test_gmap_eth_dev_bridging_listener__initial_fetch(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };
    s_test_addr_cb_priv_t port_brlan_eth0_0 = {
        .bridge = "br-lan",
        .port = "eth0_0",
        .seen_list = &events,
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* eth0_0_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");

    // AND some attached mac addresses
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_add_mac("br-guest", "wlan0.2", "22:22:33:44:55:02");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up some listeners, their callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        // No bridges we're not listening for
        // No ports without name
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        // no mac addresses for unwatched (bridge, port) combinations
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    gmap_eth_dev_bridging_subscribe_mac(&eth0_0_cb, "br-lan", "eth0_0", s_test_addr_cb, &port_brlan_eth0_0);
    expected = ((s_expected_item_t[]) {
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__mac_add(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };
    s_test_addr_cb_priv_t port_brlan_eth0_0 = {
        .bridge = "br-lan",
        .port = "eth0_0",
        .seen_list = &events,
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* eth0_0_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up some listeners, there are no mac addresses yet
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_0_cb, "br-lan", "eth0_0", s_test_addr_cb, &port_brlan_eth0_0);
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events));

    // WHEN adding some addresses, some reported multiple times
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_add_mac("br-guest", "wlan0.2", "22:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN only the adresses we listened to are added once
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        // no mac addresses for unwatched (bridge, port) combinations
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__mac_remove(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };
    s_test_addr_cb_priv_t port_brlan_eth0_0 = {
        .bridge = "br-lan",
        .port = "eth0_0",
        .seen_list = &events,
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* eth0_0_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up some listeners, there are no mac addresses yet
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_0_cb, "br-lan", "eth0_0", s_test_addr_cb, &port_brlan_eth0_0);
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events));

    // WHEN adding some addresses,
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:03");
    bridging_mock_add_mac("br-guest", "wlan0.2", "22:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN only the adresses we listened to are added and removed, with unknown macs ignored
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        // no mac addresses for unwatched (bridge, port) combinations
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__mac_bad_event(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up some listeners, there are no mac addresses yet
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events));

    // WHEN sending some bad events,
    bridging_mock_add_mac("br-lan", "eth0_1", "");
    bridging_mock_remove_mac("br-lan", "eth0_1", "");
    bridging_mock_send_mac("br-lan", "eth0_1", "11:22:33:44:55:02", "blablabla");
    bridging_mock_send_mac("br-lan", "eth0_1", "11:22:33:44:55:02", "");
    bridging_mock_send_mac("br-lan", "eth0_1", "", "");
    bridging_mock_send_mac("br-lan", "eth0_1", NULL, "MAC_Added");
    bridging_mock_send_mac("br-lan", "eth0_1", "11:22:33:44:55:02", NULL);
    amxut_bus_handle_events();

    // THEN the bad events are ignored
    assert_true(amxc_llist_is_empty(&events));

    // AND the subscription is not disrupted
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    amxut_bus_handle_events();
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__mac_bad_subscribe(UNUSED void** state) {
    amxc_llist_t events;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "eth0_1", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up some listeners, bad parameters don't cause crashes or
    //      undefined behavior (see also valgrind output)
    gmap_eth_dev_bridging_subscribe_mac(NULL, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, NULL, "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", NULL, s_test_addr_cb, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "", s_test_addr_cb, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", NULL, &port_brlan_eth0_1);
    assert_null(eth0_1_cb);

    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events));

    gmap_eth_dev_bridging_unsubscribe_mac(&eth0_1_cb);
    gmap_eth_dev_bridging_unsubscribe_mac(NULL);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__mac_second_subscription(UNUSED void** state) {
    amxc_llist_t events[2];
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events[0],
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events[1],
        },
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb[2] = {NULL, NULL};

    amxc_llist_init(&events[0]);
    amxc_llist_init(&events[1]);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up the listeners, there are no mac addresses yet
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb[0], "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1[0]);
    assert_non_null(eth0_1_cb[0]);
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events[0]));

    // WHEN adding and removing some addresses
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:03");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN the callback was called for each event
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:03", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        { 0 }
    });
    assert_seen_list(&events[0], expected);
    assert_true(amxc_llist_is_empty(&events[1]));
    s_seen_list_clear(&events[0]);
    s_seen_list_clear(&events[1]);

    // WHEN a second callback is then added,
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb[1], "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1[1]);
    assert_non_null(eth0_1_cb[1]);
    amxut_bus_handle_events();

    // It is made up-to-date to the current situation
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:03", .added = true},
        { 0 }
    });
    assert_true(amxc_llist_is_empty(&events[0]));
    assert_seen_list(&events[1], expected);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events[0]);
    s_seen_list_clear(&events[1]);
}

void test_gmap_eth_dev_bridging_listener__mac_unsubscribe(UNUSED void** state) {
    amxc_llist_t events[2];
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan_eth0_1[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events[0],
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events[1],
        },
    };

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb[2] = {NULL, NULL};

    amxc_llist_init(&events[0]);
    amxc_llist_init(&events[1]);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // WHEN setting up the listeners, there are no mac addresses yet
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb[0], "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1[0]);
    assert_non_null(eth0_1_cb[0]);
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events[0]));

    // WHEN adding and removing some addresses
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:03");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN the callback was called for each event
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:03", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        { 0 }
    });
    assert_seen_list(&events[0], expected);
    assert_true(amxc_llist_is_empty(&events[1]));
    s_seen_list_clear(&events[0]);
    s_seen_list_clear(&events[1]);

    // WHEN a second callback is then added,
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb[1], "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1[1]);
    assert_non_null(eth0_1_cb[1]);
    amxut_bus_handle_events();

    // It is made up-to-date to the current situation
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:03", .added = true},
        { 0 }
    });
    assert_true(amxc_llist_is_empty(&events[0]));
    assert_seen_list(&events[1], expected);
    s_seen_list_clear(&events[1]);

    // WHEN unsubscribing a listener,
    gmap_eth_dev_bridging_unsubscribe_mac(&eth0_1_cb[0]);
    assert_null(eth0_1_cb[0]);

    // AND new events come in
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    amxut_bus_handle_events();

    // THEN only the remaining listener is notified
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        { 0 }
    });
    assert_true(amxc_llist_is_empty(&events[0]));
    assert_seen_list(&events[1], expected);
    s_seen_list_clear(&events[1]);

    // WHEN unsubscribing the remaining listener,
    gmap_eth_dev_bridging_unsubscribe_mac(&eth0_1_cb[1]);
    assert_null(eth0_1_cb[1]);

    // THEN it too is no longer notified
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events[0]));
    assert_true(amxc_llist_is_empty(&events[1]));

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events[0]);
}

static void _expect_mac_addresses(const amxc_htable_t* observed,
                                  uint32_t port,
                                  const char** addresses,
                                  const char* file,
                                  int line) {
    amxc_set_t found_macs;
    amxc_set_t required_macs;
    amxc_set_t required_macs_2;
    bool failed = false;

    amxc_set_init(&found_macs, false);
    amxc_set_init(&required_macs, false);
    amxc_set_init(&required_macs_2, false);

    /* Build a set of required flags */
    assert_non_null(addresses);
    while(*addresses != NULL) {
        amxc_set_add_flag(&required_macs, *addresses);
        amxc_set_add_flag(&required_macs_2, *addresses);
        ++addresses;
    }

    /* Build a set of found flags */
    amxc_htable_for_each(it, observed) {
        const char* mac = amxc_htable_it_get_key(it);
        uint32_t idx = GET_UINT32(amxc_var_from_htable_it(it), NULL);
        if(amxc_set_get_count(&found_macs, mac) != 0) {
            print_error("ERROR: Duplicate entry '%s' in received macs for port.\n", mac);
            _fail(file, line);
        }
        amxc_set_add_flag(&found_macs, mac);
        if(idx != port) {
            print_error("ERROR: Found entry '%s' in received macs for port has "
                        "incorrect port netdev index %" PRIu32 "\n",
                        mac, idx);
            _fail(file, line);
        }
    }

    amxc_set_subtract(&required_macs, &found_macs);
    amxc_set_subtract(&found_macs, &required_macs_2);

    if(amxc_set_get_count(&required_macs, NULL)) {
        print_error("ERROR: missing %" PRIu32 " expected items from macs for port:\n",
                    amxc_set_get_count(&required_macs, NULL));
        failed = true;
        amxc_set_iterate(flag, &required_macs) {
            print_error("* '%s'\n", flag->flag);
        }
    }

    if(amxc_set_get_count(&found_macs, NULL)) {
        print_error("ERROR: found %" PRIu32 " unexpected items from macs for port:\n",
                    amxc_set_get_count(&found_macs, NULL));
        failed = true;
        amxc_set_iterate(flag, &found_macs) {
            print_error("* '%s'\n", flag->flag);
        }
    }

    if(failed) {
        _fail(file, line);
    }

    amxc_set_clean(&found_macs);
    amxc_set_clean(&required_macs);
    amxc_set_clean(&required_macs_2);
}

#define expect_mac_addresses(observed, port, addresses) _expect_mac_addresses(observed, port, addresses; __FILE__, __LINE__)

static void _assert_macs_for_port(uint32_t netdev_idx,
                                  const char** expected,
                                  const char* file,
                                  int line) {
    amxc_htable_t* table = gmap_eth_dev_bridging_macs_for_port(netdev_idx);

    if(expected == NULL) {
        _assert_true(table == NULL || amxc_htable_is_empty(table),
                     "table == NULL || amxc_htable_is_empty(table)",
                     file, line);
    } else {
        _assert_true(table != NULL,
                     "table != NULL",
                     file, line);
        _expect_mac_addresses(table, netdev_idx, expected, file, line);
    }

    amxc_htable_delete(&table, variant_htable_it_free);
}

#define assert_macs_for_port(netdev_idx, expected) _assert_macs_for_port(netdev_idx, expected, __FILE__, __LINE__)

void test_gmap_eth_dev_bridging_listener__macs_for_port(UNUSED void** state) {

    amxc_llist_t events;
    s_test_addr_cb_priv_t port_brlan_eth0_1 = {
        .bridge = "br-lan",
        .port = "eth0_1",
        .seen_list = &events,
    };
    uint32_t port_eth0_1 = 12;
    uint32_t port_eth1 = 15;
    uint32_t port_bad = 999;

    gmap_eth_dev_bridging_mac_subscription_t* eth0_1_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    // NULL must be returned when bridging isn't properly initialized
    assert_null(gmap_eth_dev_bridging_macs_for_port(port_eth0_1));

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());

    // INITIALLY, there are no mac addresses to be found
    assert_macs_for_port(port_eth0_1, NULL);
    assert_macs_for_port(port_eth1, NULL);
    assert_macs_for_port(port_bad, NULL);

    // WHEN adding and removing some mac addresses
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:03");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN the result gets updated
    assert_macs_for_port(port_eth0_1,
                         ((const char*[]) {
        "11:22:33:44:55:01",
        "11:22:33:44:55:03",
        NULL
    }));
    assert_macs_for_port(port_eth1, NULL);

    // WHEN setting up some listeners, the result remains valid
    gmap_eth_dev_bridging_subscribe_mac(&eth0_1_cb, "br-lan", "eth0_1", s_test_addr_cb, &port_brlan_eth0_1);
    assert_non_null(eth0_1_cb);
    amxut_bus_handle_events();
    assert_macs_for_port(port_eth0_1,
                         ((const char*[]) {
        "11:22:33:44:55:01",
        "11:22:33:44:55:03",
        NULL
    }));
    assert_macs_for_port(port_eth1, NULL);

    // WHEN adding some more events
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:01");
    amxut_bus_handle_events();

    // THEN the function still returns up-to-date information
    assert_macs_for_port(port_eth0_1,
                         ((const char*[]) {
        "11:22:33:44:55:02",
        "11:22:33:44:55:03",
        "11:22:33:44:55:04",
        "11:22:33:44:55:05",
        NULL
    }));
    assert_macs_for_port(port_eth1, NULL);

    // AFTER unsubscribing the last listener for eth0_1
    gmap_eth_dev_bridging_unsubscribe_mac(&eth0_1_cb);
    assert_null(eth0_1_cb);
    amxut_bus_handle_events();

    // THEN the function still returns up-to-date information
    assert_macs_for_port(port_eth0_1,
                         ((const char*[]) {
        "11:22:33:44:55:02",
        "11:22:33:44:55:03",
        "11:22:33:44:55:04",
        "11:22:33:44:55:05",
        NULL
    }));
    assert_macs_for_port(port_eth1, NULL);

    // FINALLY, when new events are added
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:02");
    bridging_mock_remove_mac("br-lan", "eth0_1", "11:22:33:44:55:04");

    // THEN the function still returns up-to-date information
    assert_macs_for_port(port_eth0_1,
                         ((const char*[]) {
        "11:22:33:44:55:03",
        NULL
    }));
    assert_macs_for_port(port_eth1, NULL);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__port_bad_subscribe(UNUSED void** state) {
    amxc_llist_t events;
    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();

    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    assert_null(port_cb);

    // AND a discovered bridging in the test setup
    assert_success(gmap_eth_dev_bridging_init());
    gmap_eth_dev_bridging_subscribe_port(NULL, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "", s_test_port_cb, &events);
    assert_null(port_cb);
    gmap_eth_dev_bridging_subscribe_port(&port_cb, NULL, s_test_port_cb, &events);
    assert_null(port_cb);
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", NULL, &events);
    assert_null(port_cb);

    amxut_bus_handle_events();
    assert_true(amxc_llist_is_empty(&events));

    gmap_eth_dev_bridging_unsubscribe_port(&port_cb);
    gmap_eth_dev_bridging_unsubscribe_port(NULL);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__rename_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN ports are renamed
    amxut_dm_load_odl("./bridging-data-brlan-named-wifi.odl");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan0.1", .port_index = 35, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.1", .port_index = 42, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan4.1", .port_index = 45, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN ports are renamed again
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan0.1", .port_index = 35, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.1", .port_index = 42, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan4.1", .port_index = 45, .mac = NULL, .added = false},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a port changes name without going through no name
    amxut_dm_load_odl("./bridging-data-brlan-moca-newname.odl");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port. A rename like this is considered
    //      as one port disappearing and another unrelatedport appearing in its
    //      place, therefore requiring two events.
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "mcdev0", .port_index = 16, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__rename_port_with_macs(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[3] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
        [2] = {
            .bridge = "br-lan",
            .port = "mcdev0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[3] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);
    /* Note: this port doesn't exist yet, but subscribing on it is perfectly valid. */
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[2], port_brlan[2].bridge, port_brlan[2].port, s_test_addr_cb, &port_brlan[2]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a port changes name without going through no name
    amxut_dm_load_odl("./bridging-data-brlan-moca-newname.odl");
    /* shortcoming of mock: when changing bridge or port name, the backing list
     * of mac addresses is not automatically cleared. Don't send events for this. */
    bridging_mock_clear_mac("br-lan", "mcdev0", false);
    bridging_mock_add_mac("br-lan", "mcdev0", "11:22:33:44:55:11");
    bridging_mock_add_mac("br-lan", "mcdev0", "11:22:33:44:55:12");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "mcdev0", .port_index = 16, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "mcdev0", .port_index = 0, .mac = "11:22:33:44:55:11", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "mcdev0", .port_index = 0, .mac = "11:22:33:44:55:12", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__rename_management_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[3] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
        [2] = {
            .bridge = "br-lanparty",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb[2] = { 0 };
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[3] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb[0], "br-lan", s_test_port_cb, &events);
    /* Note: this bridge doesn't exist yet, but subscribing on it is perfectly valid. */
    gmap_eth_dev_bridging_subscribe_port(&port_cb[1], "br-lanparty", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);
    /* Note: this port doesn't exist yet, but subscribing on it is perfectly valid. */
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[2], port_brlan[2].bridge, port_brlan[2].port, s_test_addr_cb, &port_brlan[2]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a management port changes name without going through no name
    amxut_dm_load_odl("./bridging-data-brlan-newname.odl");
    /* shortcoming of mock: when changing bridge or port name, the backing list
     * of mac addresses is not automatically cleared. Don't send events for this. */
    bridging_mock_clear_mac("br-lanparty", "eth0_0", false);
    bridging_mock_add_mac("br-lanparty", "eth0_0", "11:22:33:44:55:11");
    bridging_mock_add_mac("br-lanparty", "eth0_0", "11:22:33:44:55:12");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        {.bridge = "br-lanparty", .bridge_index = 99, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lanparty", .bridge_index = 99, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lanparty", .bridge_index = 99, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lanparty", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:11", .added = true},
        {.bridge = "br-lanparty", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:12", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__clear_management_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[2] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN the management port loses its management status
    amxut_dm_load_odl("./bridging-data-brlan-no-management.odl");
    /* shortcoming of mock: when changing bridge or port name, the backing list
     * of mac addresses is not automatically cleared. Don't send events for this. */
    bridging_mock_clear_mac("br-lan", "eth0_0", false);
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:11");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:12");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

static void s_delete_port(const char* bridge_alias,
                          const char* port_alias) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    amxd_trans_select_pathf(&trans, "Bridging.Bridge.[%s].Port.", bridge_alias);
    amxd_trans_del_inst(&trans, 0, port_alias);

    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);
}

void test_gmap_eth_dev_bridging_listener__remove_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[2] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a management port is removed
    s_delete_port("lan", "eth_port1");
    amxut_bus_handle_events();

    // THEN an event is emitted for each removed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = false},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__remove_management_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[2] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a management port is removed
    s_delete_port("lan", "lan_bridge");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

static void s_delete_bridge(const char* bridge_alias) {
    amxd_trans_t trans;
    amxd_trans_init(&trans);

    amxd_trans_select_pathf(&trans, "Bridging.Bridge.");
    amxd_trans_del_inst(&trans, 0, bridge_alias);

    assert_success(amxd_trans_apply(&trans, amxut_bus_dm()));
    amxd_trans_clean(&trans);
}

void test_gmap_eth_dev_bridging_listener__remove_bridge(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[2] = { 0 };

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port with associated mac addresses
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);

    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN a complete bridge is removed
    s_delete_bridge("lan");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = false},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = false},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = false},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__add_ports(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    s_test_addr_cb_priv_t port_brlan[2] = {
        [0] = {
            .bridge = "br-lan",
            .port = "eth0_1",
            .seen_list = &events,
        },
        [1] = {
            .bridge = "br-lan",
            .port = "eth0_0",
            .seen_list = &events,
        },
    };

    gmap_eth_dev_bridging_port_subscription_t* port_cb[2] = { 0 };
    gmap_eth_dev_bridging_mac_subscription_t* mac_cb[2] = { 0 };

    amxc_llist_init(&events);

    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb[0], "br-lan", s_test_port_cb, &events);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[0], port_brlan[0].bridge, port_brlan[0].port, s_test_addr_cb, &port_brlan[0]);
    gmap_eth_dev_bridging_subscribe_mac(&mac_cb[1], port_brlan[1].bridge, port_brlan[1].port, s_test_addr_cb, &port_brlan[1]);

    // WHEN ports and mac addresses are added, but no management port yet
    amxut_dm_load_odl("./bridging-data-brlan-bare.odl");
    amxut_dm_load_odl("./bridging-data-brlan-ports-0.odl");
    amxut_bus_handle_events();

    // THEN none of the subscribers are notified
    assert_true(amxc_llist_is_empty(&events));
    s_seen_list_clear(&events);

    // WHEN the management port is added
    amxut_dm_load_odl("./bridging-data-brlan-ports-mgmt.odl");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:04");
    bridging_mock_add_mac("br-lan", "eth0_1", "11:22:33:44:55:05");
    amxut_bus_handle_events();

    // THEN an event is emitted for each available port and MAC address
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:04", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_1", .port_index = 0, .mac = "11:22:33:44:55:05", .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan0.1", .port_index = 35, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.1", .port_index = 42, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan4.1", .port_index = 45, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN more ports and mac addresses are added
    amxut_dm_load_odl("./bridging-data-brlan-ports-1.odl");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:01");
    bridging_mock_add_mac("br-lan", "eth0_0", "11:22:33:44:55:02");
    amxut_bus_handle_events();

    // THEN an event is emitted for each available port and MAC address
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:01", .added = true},
        {.bridge = "br-lan", .bridge_index = 0, .port = "eth0_0", .port_index = 0, .mac = "11:22:33:44:55:02", .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}

void test_gmap_eth_dev_bridging_listener__unsubscribe_port(UNUSED void** state) {
    amxc_llist_t events;
    s_expected_item_t* expected = NULL;
    gmap_eth_dev_bridging_port_subscription_t* port_cb = NULL;

    amxc_llist_init(&events);

    // GIVEN some existing bridges and port
    amxut_dm_load_odl("./bridging-data-brlan.odl");
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_dm_load_odl("./bridging-data-other-bridges.odl");
    amxut_bus_handle_events();
    gmap_eth_dev_bridging_init();

    // WHEN setting up a port listener, its callbacks are executed immediately
    gmap_eth_dev_bridging_subscribe_port(&port_cb, "br-lan", s_test_port_cb, &events);
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.2", .port_index = 43, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_1", .port_index = 12, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "eth0_0", .port_index = 11, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN ports are renamed
    amxut_dm_load_odl("./bridging-data-brlan-named-wifi.odl");
    amxut_bus_handle_events();

    // THEN an event is emitted for each changed port
    expected = ((s_expected_item_t[]) {
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan0.1", .port_index = 35, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan2.1", .port_index = 42, .mac = NULL, .added = true},
        {.bridge = "br-lan", .bridge_index = 19, .port = "wlan4.1", .port_index = 45, .mac = NULL, .added = true},
        { 0 }
    });
    assert_seen_list(&events, expected);
    s_seen_list_clear(&events);

    // WHEN the subscription is removed
    gmap_eth_dev_bridging_unsubscribe_port(&port_cb);
    assert_null(port_cb);

    // WHEN ports are renamed again
    amxut_dm_load_odl("./bridging-data-brlan-anon-wifi.odl");
    amxut_bus_handle_events();

    // THEN no event is emitted for each changed port
    assert_true(amxc_llist_is_empty(&events));
    s_seen_list_clear(&events);

    // cleanup
    gmap_eth_dev_bridging_clean();
    s_seen_list_clear(&events);
}
