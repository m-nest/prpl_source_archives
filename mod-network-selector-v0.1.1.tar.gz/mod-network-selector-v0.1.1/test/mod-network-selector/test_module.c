/**
 * @file test_module.c
 *
 * @brief This file contains unit test of network selector
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 *
 * SPDX-FileCopyrightText: Copyright (c) 2025 AT&T
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 *
 * Subject to the terms and conditions of this license, each
 * copyright holder and contributor hereby grants to those receiving
 * rights under this license a perpetual, worldwide, non-exclusive,
 * no-charge, royalty-free, irrevocable (except for failure to
 * satisfy the conditions of this license) patent license to make,
 * have made, use, offer to sell, sell, import, and otherwise
 * transfer this software, where such license applies only to those
 * patent claims, already acquired or hereafter acquired, licensable
 * by such copyright holder or contributor that are necessarily
 * infringed by:
 *
 * (a) their Contribution(s) (the licensed copyrights of copyright
 * holders and non-copyrightable additions of contributors, in
 * source or binary form) alone; or
 *
 * (b) combination of their Contribution(s) with the work of
 * authorship to which such Contribution(s) was added by such
 * copyright holder or contributor, if, at the time the Contribution
 * is added, such addition causes such combination to be necessarily
 * infringed. The patent license shall not apply to any other
 * combinations which include the Contribution.
 *
 * Except as expressly stated above, no rights or licenses from any
 * copyright holder or contributor is granted under this license,
 * whether expressly, by implication, estoppel or otherwise.
 *
 * DISCLAIMER
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include "../common/common_functions.h"
#include <string.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxm/amxm.h>
#if defined(SAHTRACES_ENABLED)
#include <debug/sahtrace.h>
#endif
#include <amxp/amxp_signal.h>

#include "test_module.h"
#include "mod-network-selector.h"

#define MOD_NAME "target_module"
#define MOD_PATH "../modules_under_test/" MOD_NAME ".so"

int mode_selected = 0;
char selected_wanmode[32] = {0};

/*
 * This test verifies the selection of Ethernet WAN mode.
 * Expectations:
 *      * Ethernet mode is correctly selected based on the provided data.
 *      * The `detect-network` function should return successfully.
 *      * The selected mode matches the expected value.
 */
void test_select_ethernet_wanmode(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);


    data = read_json_from_file("test_data/test_ethernet_wanmode.json");
    // Execute the detect-network function and check return value
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(strncmp("demo_wanmode", selected_wanmode, sizeof("demo_wanmode")), 0);
    assert_int_equal(mode_selected, 1);
    mode_selected = 0;

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies the selection of SFP WAN mode.
 * Expectations:
 *      * SFP mode is correctly selected based on the provided data.
 *      * The `detect-network` function should return successfully.
 *      * The selected mode matches the expected value.
 */
void test_select_sfp_wanmode(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_sfp_wanmode.json");
    // Execute the detect-network function and check return value
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(strncmp("demo_vlanmode", selected_wanmode, sizeof("demo_vlanmode")), 0);
    assert_int_equal(mode_selected, 1);
    mode_selected = 0;


    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies the selection of SFP or Ethernet WAN mode.
 * Expectations:
 *      * Either SFP or Ethernet mode is selected based on the provided data.
 *      * The `detect-network` function should return successfully.
 *      * The selected mode matches one of the expected values.
 */
void test_select_sfp_ethernet_wanmode(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_sfp_wanmode_2.json");
    // Execute the detect-network function and check return value
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(strncmp("demo_vlanmode", selected_wanmode, sizeof("demo_vlanmode")), 0);
    assert_int_equal(mode_selected, 1);
    mode_selected = 0;

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies behavior when no WAN mode is available.
 * Expectations:
 *      * The `detect-network` function should handle the case where no WAN mode is present gracefully.
 *      * No mode should be selected as there are no available WAN modes in the input data.
 */
void test_select_no_wanmode(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_no_wanmode.json");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies that the GPON WAN mode is selected correctly.
 * Expectations:
 *      * The `detect-network` function should identify and select the GPON WAN mode from the input data.
 *      * The selected mode should match "demo_vlanmode".
 *      * The `mode_selected` variable should indicate success by being set to 1.
 */
void test_select_gpon_wanmode(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;

    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_sfp_wanmode_3.json");
    // Execute the detect-network function and check return value
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(strncmp("demo_vlanmode", selected_wanmode, sizeof("demo_vlanmode")), 0);
    assert_int_equal(mode_selected, 1);
    mode_selected = 0;

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies behavior when no SFP is available.
 * Expectations:
 *      * The `detect-network` function should return successfully even if no SFP modes are available.
 *      * The `mode_selected` variable should remain 0, indicating no mode was selected.
 */
void test_select_no_sfp(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_no_sfp.json");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(mode_selected, 0);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies behavior when no physical interfaces (PHY) are available.
 * Expectations:
 *      * The `detect-network` function should complete successfully even if no PHYs are available.
 *      * The `mode_selected` variable should remain 0, indicating no mode was selected.
 */
void test_select_no_phy(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_no_phy.json");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), 0);
    assert_int_equal(mode_selected, 0);

    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

/*
 * This test verifies behavior when no modes are provided in the input data.
 * Expectations:
 *      * The `detect-network` function should fail gracefully, returning -1 to indicate an error.
 *      * Proper cleanup should occur without selecting any mode.
 */
void test_select_no_modes(UNUSED void** state) {

    amxc_var_t* data = NULL;
    amxc_var_t ret;
    amxc_var_init(&ret);

    data = read_json_from_file("test_data/test_no_modes.json");
    assert_int_equal(amxm_execute_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network", data, &ret), -1);
    amxc_var_clean(&ret);
    amxc_var_delete(&data);
}

static int network_set_wan_mode(UNUSED const char* function_name,
                                UNUSED amxc_var_t* args,
                                UNUSED amxc_var_t* ret) {
    assert_non_null(args);
    mode_selected = 0;
    memset(selected_wanmode, 0, sizeof(selected_wanmode));

    const char* alias = GET_CHAR(args, "Alias");

    if((alias != NULL) && (strlen(alias) > 0 )) {
        mode_selected = 1;
        strncpy(selected_wanmode, alias, sizeof(selected_wanmode));
    }

    return 0;
}

static int register_dummy_core_functions(void) {
    amxm_shared_object_t* so = amxm_get_so("self");
    amxm_module_t* mod = NULL;
    assert_non_null(so);
    assert_int_equal(amxm_module_register(&mod, so, MOD_DM_MNGR), 0);
    assert_int_equal(amxm_module_add_function(mod, "set-wan-mode", network_set_wan_mode), 0);
    return 0;
}

// Check if the function is present
void test_has_functions(UNUSED void** state) {
    assert_true(amxm_has_function(MOD_NAME, MOD_NETWORK_CTRL, "detect-network"));
}

// Loading the network selector module
void test_can_load_module(UNUSED void** state) {
    amxm_shared_object_t* so = NULL;
    assert_int_equal(amxm_so_open(&so, MOD_NAME, MOD_PATH), 0);
}

// unloading the network selector module
void test_can_close_module(UNUSED void** state) {
    assert_int_equal(amxm_close_all(), 0);
}

int test_setup(UNUSED void** state) {
    register_dummy_core_functions();
#if defined(SAHTRACES_ENABLED)
    sahTraceOpen("unittest", 0);
    sahTraceSetLevel(500);
    sahTraceAddZone(500, "mod-network-selector");
#endif
    return 0;
}

int test_teardown(UNUSED void** state) {
    return 0;
}
