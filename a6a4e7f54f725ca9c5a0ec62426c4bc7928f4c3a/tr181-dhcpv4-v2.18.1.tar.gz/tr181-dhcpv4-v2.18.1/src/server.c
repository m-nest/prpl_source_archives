/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <string.h>
#include <stdlib.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_object_event.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "dhcp.h"
#include "server.h"

#define ME "server"

/**
 * @brief
 * Update the remaining lease time of a lease by comparaison of the old system time and the new one gets on the system
 *
 * @param template Pools template for instances
 * @param lease The lease object to change
 * @param priv The transaction object
 * @return int 0 if success to update
 */
static int dhcp_lease_sys_time_updated(UNUSED amxd_object_t* template,
                                       amxd_object_t* lease,
                                       void* priv) {
    int ret = 1;
    amxd_trans_t* trans = (amxd_trans_t*) priv;
    amxc_ts_t new_time_sys;
    amxc_ts_t* old_time_sys = NULL;
    amxc_ts_t* expires = NULL;
    u_int64_t delta = 0;

    when_null_trace(lease, exit, ERROR, "Lease to update is NULL");

    old_time_sys = amxd_object_get_value(amxc_ts_t, lease, "LastUpdate", NULL);
    expires = amxd_object_get_value(amxc_ts_t, lease, "LeaseTimeRemaining", NULL);
    amxc_ts_now(&new_time_sys);
    delta = new_time_sys.sec - old_time_sys->sec;
    expires->sec += delta;

    amxd_trans_select_object(trans, lease);

    amxd_trans_set_value(amxc_ts_t, trans, "LastUpdate", &new_time_sys);
    amxd_trans_set_value(amxc_ts_t, trans, "LeaseTimeRemaining", expires);

    ret = 0;
exit:
    free(old_time_sys);
    free(expires);
    return ret;
}

/**
 * @brief
 * Update all the leases by comparing the previous system date with the new one
 *
 * @param event_name not used
 * @param event_data not used
 * @param priv not used
 */
void server_sys_time_updated(UNUSED const char* const event_name,
                             const amxc_var_t* const event_data,
                             UNUSED void* const priv) {
    amxd_object_t* pools = amxd_dm_findf(dhcp_get_dm(), "DHCPv4Server.Pool.");
    amxd_trans_t trans;
    amxc_var_t* status = NULL;
    int rv = 0;

    amxd_trans_init(&trans);
    amxd_trans_set_attr(&trans, amxd_tattr_change_prot, true);
    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);

    when_null_trace(pools, exit, WARNING, "No pools to update");
    when_null_trace(event_data, exit, ERROR, "No data given in the event");

    status = GETP_ARG(event_data, "parameters.Status");
    when_null_trace(status, exit, INFO, "No status updated");

    when_false_trace(strcmp(GET_CHAR(status, "to"), "Synchronized") == 0, exit, INFO, "Not updating base time as system time was not update");

    amxd_object_for_all(pools, ".*.Client.*.IPv4Address.*", dhcp_lease_sys_time_updated, (void*) &trans);

    rv = amxd_trans_apply(&trans, dhcp_get_dm());
    when_failed_trace(rv, exit, ERROR, "Cannot update lease with system time");
exit:
    amxd_trans_clean(&trans);
    return;
}