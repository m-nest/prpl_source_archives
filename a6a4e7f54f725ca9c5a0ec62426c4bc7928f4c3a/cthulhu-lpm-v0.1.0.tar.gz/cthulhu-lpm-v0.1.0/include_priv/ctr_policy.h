/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#if !defined(__CTR_POLICY_H__)
#define __CTR_POLICY_H__

/**
 * @brief clean up policy
 */
void cleanup_policy(void);

/**
 * @brief load policy file from disk
 *
 * Helper function to load the policy file and store it in a variant
 *
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t load_policyfile(void);

/**
 * @brief load json file from disk
 *
 * Helper function to load any json file and store it in a variant
 *
 * @param path file path
 * @param var resulting variant
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t load_json(const char* path, amxc_var_t** var);

/**
 * @brief apply the container policy
 *
 * This is a helper funtion which will combine
 * a list of previously installed containers and
 * a list of containers embedded in the newly installed firmware image
 * into a new container list based on the container policy.
 *
 * @param oldctrlist  previously installed container list
 * @param newctrlist  list of containers embedded in the newly installed firmware image
 * @param resultlist  resulting container list with the policy applied
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t apply_container_policy(amxc_var_t* oldctrlist,
                                     amxc_var_t* newctrlist,
                                     amxc_var_t* resultlist);

/**
 * @brief apply a policy
 *
 * This is a helper funtion which will combine
 * a list of previously installed containers/sandboxes and
 * a list of containers/sandboxes embedded in the newly installed firmware image
 * into a new container/sandbox list based on the container/sandbox policy.
 *
 * @param oldctrlist  previously installed list
 * @param newctrlist  list embedded in the newly installed firmware image
 * @param resultlist  resulting list with the policy applied
 * @param type  container or sandbox
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t apply_policy(amxc_var_t* oldlist,
                           amxc_var_t* newlist,
                           amxc_var_t* resultlist,
                           policy_type_t listtype);

/**
 * @brief update container lists
 *
 * This is the main function which will take
 * a list of previously installed containers,
 * and it will return 3 lists (create list, upgrade list, remove list) with applied policy
 * for further handling in Cthulhu.
 *
 * @param ctrcreatelist   input list of previously installed container, to be modified in place to include only
 *                        new containers to be created using "Container.create"
 * @param ctrupgradelist  output list of containers to be upgraded
 * @param ctrremovelist   output list of containers to be removed
 * @param imageremovelist output list of images to be removed
 * @return 0 on success, non-zero on failure.
 */
amxd_status_t update_ctr_list(amxc_var_t* ctrcreatelist,
                              amxc_var_t* ctrupgradelist,
                              amxc_var_t* ctrremovelist,
                              amxc_var_t* imageremovelist);

/**
 * @brief get a policy action for a supplied event
 *
 * This function gets a policy action (eg: install, ignore, upgrade, uninstall)
 * for a policy event (onNew, onUnknown, ...)
 * using the policy rules in the policy file.
 * It will first look for application-specific policies.
 * If these do not exists for the given container,
 * the general policy will be used.
 *
 * @param policy_event policy event
 * @param desc container descriptor for which to policy needs to be looked up
 * @param idkey key name to match the container descriptor with the application-specific policy, eg "UUID"
 * @param log log object to log all policy actions and errors
 * @return policy action
 */
policy_action_t get_policy_action(policy_event_t policy_event,
                                  const char* id, amxc_var_t* desc,
                                  const char* idkey, policylog_t* log);

#endif // __CTR_POLICY_H__
