%populate {
    object 'WANManager.WAN' {
        instance add ("Ethernet_PPP"){
            parameter Alias = "Ethernet_PPP";
            parameter PhysicalType = "Ethernet";
            parameter PhysicalReference = "Device.Ethernet.Interface.{{ BDfn.getUpstreamInterfaceIndex() + 1 }}";
        }
    }

    object 'WANManager.WAN.Ethernet_PPP.Intf'{
        instance add(0,"wan"){
            parameter Type = "vlan";
            parameter IPv4Mode = "ppp4";
            parameter DefaultRouteReference = "Device.Routing.Router.1.IPv4Forwarding.1.";
            parameter IPv6Mode = "dhcp6";
            parameter Name = "wan";
            parameter VlanID = 100;
            parameter VlanPriority = 0;
            parameter IPv4Reference = "${ip_intf_wan}";
            parameter IPv6Reference = "${ip_intf_wan6}";
            parameter NeighborDiscoveryReference = "Device.NeighborDiscovery.InterfaceSetting.1";
            parameter PPPv4Reference = "Device.PPP.Interface.1";
            parameter DHCPv6Reference = "Device.DHCPv6.Client.1.";
            parameter DeferredIPv6Instances = "${ip_intf_lan},${ip_intf_guest},${ip_intf_lcm}";
            parameter UserName = "softathome";
            parameter Password = "softathome";
        }

        instance add(0,"voip"){
            parameter Type = "vlan";
            parameter IPv4Mode = "dhcp4";
            parameter IPv6Mode = "none";
            parameter Name = "voip";
            parameter VlanID = 101;
            parameter VlanPriority = 0;
            parameter IPv4Reference = "${ip_intf_voip}";
            parameter IPv6Reference = "${ip_intf_voip}";
            parameter DHCPv4Reference = "Device.DHCPv4.Client.2.";
        }

        instance add(0,"iptv"){
            parameter Type = "vlan";
            parameter IPv4Mode = "dhcp4";
            parameter IPv6Mode = "none";
            parameter Name = "iptv";
            parameter VlanID = 102;
            parameter VlanPriority = 0;
            parameter IPv4Reference = "${ip_intf_iptv}";
            parameter IPv6Reference = "${ip_intf_iptv}";
            parameter DHCPv4Reference = "Device.DHCPv4.Client.3.";
        }

        instance add(0,"mgmt"){
            parameter Type = "vlan";
            parameter IPv4Mode = "dhcp4";
            parameter IPv6Mode = "none";
            parameter Name = "mgmt";
            parameter VlanID = 103;
            parameter VlanPriority = 0;
            parameter IPv4Reference = "${ip_intf_mgmt}";
            parameter IPv6Reference = "${ip_intf_mgmt}";
            parameter DHCPv4Reference = "Device.DHCPv4.Client.4.";
        }
    }
}
