#!/bin/sh

. /usr/lib/amx/scripts/amx_init_functions.sh

name="oopsmonitor"
datamodel_root="KernelFaults"

mount_pstore(){
        [ ! -z "$(grep pstore /proc/mounts)" ] || mount -t pstore pstore /sys/fs/pstore
}

case $1 in
    boot)
        mount_pstore
        process_boot ${name} -D
        ;;
    start)
        mount_pstore
        process_start ${name} -D
        ;;
    stop)
        process_stop ${name}
        ;;
    shutdown)
        process_shutdown ${name}
        ;;
    restart)
        $0 stop
        $0 start
        ;;
    debuginfo)
        process_debug_info ${datamodel_root}
        ;;
    *)
        echo "Usage : $0 [start|boot|stop|shutdown|debuginfo|restart]"
        ;;
esac
