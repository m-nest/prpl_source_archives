/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/


#include <netmodel/client.h>

#include "dm_homeplug.h"
#include "homeplug.h"

#define HOMEPLUG_SCAN_INTERVAL_MS 10000
typedef struct _homeplug {
    amxd_dm_t* dm;
    amxo_parser_t* parser;
} homeplug_t;

static homeplug_t app;
static amxp_timer_t* scan_timer;
static bool homeplug_enabled = false;

static void homeplug_search_devices(UNUSED amxp_timer_t* const timer,
                                    UNUSED void* data) {

    SAH_TRACEZ_INFO(ME, "homeplug search devices");
    homeplug_interface_cleanup_inactive_devices();
    homeplug_interface_send_discovery_request();
}

void homeplug_enable(void) {
    int ret_value = -1;
    if(!homeplug_enabled) {
        amxp_timer_set_interval(scan_timer, HOMEPLUG_SCAN_INTERVAL_MS);
        ret_value = amxp_timer_start(scan_timer, HOMEPLUG_SCAN_INTERVAL_MS);
        when_failed_trace(ret_value, exit, ERROR, "Failed to start the timer");
        homeplug_enabled = true;
        SAH_TRACEZ_INFO(ME, "enable homeplug");
    }
exit:
    return;
}

void homeplug_disable(void) {
    if(homeplug_enabled) {
        amxp_timer_stop(scan_timer);
        SAH_TRACEZ_INFO(ME, "disable homeplug");
        homeplug_enabled = false;
    }
    /* when homeplug is disabled, detected device entries stay in data model, they are not deleted */
}

amxd_dm_t* homeplug_get_dm(void) {
    return app.dm;
}

amxo_parser_t* homeplug_get_parser(void) {
    return app.parser;
}

int _homeplug_main(int reason,
                   amxd_dm_t* dm,
                   amxo_parser_t* parser) {

    switch(reason) {
    case 0:     // START
        app.dm = dm;
        app.parser = parser;
        netmodel_initialize();
        homeplug_interface_initialize();
        amxp_timer_new(&scan_timer, homeplug_search_devices, NULL);
        break;
    case 1:     // STOP
        app.dm = NULL;
        amxp_timer_delete(&scan_timer);
        homeplug_interface_cleanup();
        netmodel_cleanup();
        app.dm = NULL;
        app.parser = NULL;
        scan_timer = NULL;
        break;
    }

    return 0;
}
