/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <debug/sahtrace.h>

#include "timingila/timingila_defines.h"
#include "lcm/lcm_dump_rpc.h"

#include "softwaremodules_priv.h"
#include "timingila_priv.h"

#define ME "softwaremodules_du"

/**
 * @brief Sets fault information in a DU state change event and triggers an error event.
 *
 * Logs a warning message with event details and marks the event as failed
 * and unresolved before triggering the DU state change event.
 *
 * @param dustatechange_data Pointer to the DU state change data structure
 *                           containing event information and fault details
 */
static inline void dustatechange_event_error(amxc_var_t* dustatechange_data) {
    ASSERT_NOT_NULL(dustatechange_data, return );
    SAH_TRACEZ_WARNING(ME, "Event error: UUID: %s, Operation: %s, FaultType: %" PRIu32 ", Fault: %s",
                       GET_CHAR(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID),
                       GET_CHAR(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION),
                       GET_UINT32(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_FAULTCODE),
                       GET_CHAR(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_FAULTSTRING));


    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_CURRENTSTATE, SM_DM_EVENT_DUSTATECHANGE_FAILED);
    amxc_var_add_key(bool, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_RESOLVED, false);

    timingila_dm_mngr_event_dustatechange(NULL, dustatechange_data, NULL);
}

/**
 * @brief Initializes DU state change event data structure.
 *
 * Populates the dustatechange_data table with UUID, version, operation type,
 * start time, and deployment unit reference information.
 *
 * @param dustatechange_data Pointer to hash table to be initialized with event data
 * @param uuid UUID of the deployment unit (optional)
 * @param version Version of the deployment unit (optional)
 * @param operation Operation type (install, update, uninstall)
 * @param start_time Timestamp when the operation started
 * @param object Pointer to the deployment unit object (optional)
 *
 * @return 0 on success, -1 on failure
 */
static int init_dustatechange_data(amxc_var_t* dustatechange_data,
                                   const char* uuid,
                                   const char* version,
                                   const char* operation,
                                   amxc_ts_t* start_time,
                                   amxd_object_t* object) {
    int res = -1;
    char* duref = NULL;
    char* euref = NULL;
    char* duid = NULL;

    ASSERT_NOT_NULL(dustatechange_data, goto exit);
    ASSERT_EQUAL(amxc_var_type_of(dustatechange_data), AMXC_VAR_ID_HTABLE, goto exit);
    ASSERT_NOT_NULL(operation, goto exit);
    ASSERT_NOT_NULL(start_time, goto exit);

    if(uuid) {
        amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, uuid);
    }
    if(version) {
        amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_VERSION, version);
    }
    amxc_var_add_key(amxc_ts_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_STARTTIME, start_time);
    amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_OPERATION, operation);

    if(object) {
        duref = get_object_path_named(object);
        euref = get_object_devices_path(object);
        amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_DEPLOYMENTUNITREF, duref);
        amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_EUREFLIST, euref);
        duid = amxd_object_get_cstring_t(object, SM_DM_DU_DUID, NULL);
        if(!STRING_EMPTY(duid)) {
            amxc_var_add_key(cstring_t, dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_DUID, duid);
        }
    }
    res = 0;
exit:
    free(duref);
    free(euref);
    free(duid);
    return res;
}

/**
 * @brief Updates a uint32_t value in a variable table, creating it if it doesn't exist.
 *
 * Attempts to get an existing key from the table and update its value. If the key
 * doesn't exist, creates a new entry with the provided data.
 *
 * @param var_table Pointer to the variable hash table
 * @param key Key name in the table
 * @param data uint32_t value to set or add
 *
 * @return 0 on success, -1 on failure
 */
static int update_var_data_uint32_t(amxc_var_t* var_table, const char* key, uint32_t data) {
    amxc_var_t* var = amxc_var_get_key(var_table, key, AMXC_VAR_FLAG_DEFAULT);
    if(var) {
        return amxc_var_set(uint32_t, var, data);
    }
    ASSERT_NOT_NULL_NL(amxc_var_add_key(uint32_t, var_table, key, data), return -1);
    return 0;
}

/**
 * @brief Updates a string value in a variable table, creating it if it doesn't exist.
 *
 * Attempts to get an existing key from the table and update its value. If the key
 * doesn't exist, creates a new entry with the provided string data.
 *
 * @param var_table Pointer to the variable hash table
 * @param key Key name in the table
 * @param data String value to set or add
 *
 * @return 0 on success, -1 on failure
 */
static int update_var_data_cstring_t(amxc_var_t* var_table, const char* key, const char* data) {
    amxc_var_t* var = amxc_var_get_key(var_table, key, AMXC_VAR_FLAG_DEFAULT);
    if(var) {
        return amxc_var_set(cstring_t, var, data);
    }
    ASSERT_NOT_NULL_NL(amxc_var_add_key(cstring_t, var_table, key, data), return -1);
    return 0;
}

/**
 * @brief Sets fault code and fault string in DU state change data.
 *
 * Updates the fault code and fault string in the dustatechange_data structure,
 * creating new entries if they don't exist.
 *
 * @param dustatechange_data Pointer to the DU state change data structure
 * @param faultcode Error code to set
 * @param faultstring Error message to set
 */
static void dustatechange_set_fault(amxc_var_t* dustatechange_data, uint32_t faultcode, const char* faultstring) {
    ASSERT_NOT_NULL(dustatechange_data, return );

    update_var_data_uint32_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_FAULTCODE, faultcode);
    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_FAULTSTRING, faultstring);
}

/**
 * @brief Retrieves a deployment unit object by DUID.
 *
 * Searches the data model for a deployment unit with the specified DUID.
 *
 * @param duid Deployment Unit ID to search for
 *
 * @return Pointer to the deployment unit object, or NULL if not found
 */
static inline amxd_object_t* get_du(const char* duid) {
    amxd_object_t* du = NULL;
    amxd_dm_t* dm = timingila_get_dm();
    du = amxd_dm_findf(dm, SOFTWAREMODULES_DM_DU ".[" SM_DM_DU_DUID " == '%s'].", duid);
    return du;
}

/**
 * @brief Validates UUID format compliance with RFC 4122 version 5.
 *
 * Checks if the UUID matches the required pattern for version 5 UUIDs:
 * xxxxxxxx-xxxx-5xxx-Nxxx-xxxxxxxxxxxx where x is hexadecimal and N is 8,9,a,b,A,B.
 * Sets appropriate fault information if validation fails.
 *
 * @param uuid UUID string to validate
 * @param dustatechange_data Pointer to DU state change data for error reporting
 *
 * @return amxd_status_ok on valid UUID, amxd_status_invalid_arg on validation failure
 */
inline amxd_status_t check_uuid(const char* uuid, amxc_var_t* dustatechange_data) {
    // a uuid should have this pattern, with
    // x = 0-9|a-f|A-Z
    // N = 8,9,a,b,A,B
    // other characters should be litterally equal
    static const char* pattern = "xxxxxxxx-xxxx-5xxx-Nxxx-xxxxxxxxxxxx";
    if(uuid == NULL) {
        SAH_TRACEZ_ERROR(ME, "Empty " SM_DM_DU_UUID);
        goto error;
    }
    if(strlen(uuid) != strlen(pattern)) {
        SAH_TRACEZ_ERROR(ME, "UUID has wrong size. [%s] should have pattern %s", uuid, pattern);
        goto error;
    }
    for(size_t pos = 0; pos < strlen(pattern); ++pos) {
        bool err = false;
        if((pattern[pos] == 'x')) {
            if(!isxdigit(uuid[pos])) {
                err = true;
            }
        } else if(pattern[pos] == 'N') {
            if(!((uuid[pos] == '8') || (uuid[pos] == '9') ||
                 (uuid[pos] == 'a') || (uuid[pos] == 'b') ||
                 (uuid[pos] == 'A') || (uuid[pos] == 'B'))) {
                err = true;
            }
        } else if(pattern[pos] != uuid[pos]) {
            err = true;
        }
        if(err) {
            SAH_TRACEZ_ERROR(ME, "UUID is wrong on position %ld. [%s] should have pattern %s", pos, uuid, pattern);
            goto error;
        }
    }
    return amxd_status_ok;
error:
    dustatechange_set_fault(dustatechange_data, ERR_UUID_FORMAT_NON_COMPLIANT, ERR_UUID_FORMAT_NON_COMPLIANT_STR);
    dustatechange_event_error(dustatechange_data);
    return amxd_status_invalid_arg;

}

/**
 * @brief Validates that an execution environment reference is provided.
 *
 * Checks if the execution environment reference is not NULL or empty.
 * Sets appropriate fault information if validation fails.
 *
 * @param executionenvref Execution environment reference to validate
 * @param dustatechange_data Pointer to DU state change data for error reporting
 *
 * @return amxd_status_ok on valid reference, amxd_status_invalid_arg if missing
 */
static inline amxd_status_t check_executionenvref(const char* executionenvref,
                                                  amxc_var_t* dustatechange_data) {
    if(STRING_EMPTY(executionenvref)) {
        SAH_TRACEZ_ERROR(ME, "Empty or missing " SM_DM_DU_EE_REF);

        dustatechange_set_fault(dustatechange_data, ERR_MISSING_EXECUTION_ENVIRONMENT, ERR_MISSING_EXECUTION_ENVIRONMENT_STR);
        dustatechange_event_error(dustatechange_data);
        return amxd_status_invalid_arg;
    }
    return amxd_status_ok;
}

/**
 * @brief Validates that the specified execution environment is enabled.
 *
 * Checks if the execution environment exists in the data model and is not disabled.
 * Sets appropriate fault information if the EE is disabled or not found.
 *
 * @param executionenvref Name of the execution environment to check
 * @param dustatechange_data Pointer to DU state change data for error reporting
 *
 * @return amxd_status_ok if EE is enabled, amxd_status_invalid_arg if disabled/not found
 */
static inline amxd_status_t check_ee_disabled(const char* executionenvref,
                                              amxc_var_t* dustatechange_data) {
    amxd_dm_t* dm = timingila_get_dm();
    amxc_var_t ee_obj_params;
    const char* ee_status = NULL;
    int compareret = 0;
    amxd_object_t* ee_obj = amxd_dm_findf(dm, SOFTWAREMODULES_DM_EE ".[" SM_DM_EE_NAME " == '%s'].", executionenvref);
    if(ee_obj == NULL) {
        SAH_TRACEZ_ERROR(ME, "Cannot find EE '%s'", executionenvref);

        dustatechange_set_fault(dustatechange_data, ERR_MISSING_EXECUTION_ENVIRONMENT, ERR_MISSING_EXECUTION_ENVIRONMENT_STR);
        dustatechange_event_error(dustatechange_data);

        return amxd_status_invalid_arg;
    }

    amxc_var_init(&ee_obj_params);
    amxd_object_get_params(ee_obj, &ee_obj_params, amxd_dm_access_public);
    ee_status = GET_CHAR(&ee_obj_params, SM_DM_EE_STATUS);
    compareret = strcmp(ee_status, SM_DM_EE_STATUS_DISABLED);
    amxc_var_clean(&ee_obj_params);
    if(compareret == 0) {
        SAH_TRACEZ_ERROR(ME, "EE '%s' is not enabled, so we will return error", executionenvref);

        dustatechange_set_fault(dustatechange_data, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH_STR);
        dustatechange_event_error(dustatechange_data);

        return amxd_status_invalid_arg;
    }
    return amxd_status_ok;
}
#ifdef TIMINGILA_DEBUG
/**
 * @brief Prints optional string argument for debug purposes.
 *
 * Only available in debug builds (TIMINGILA_DEBUG). Retrieves and logs
 * a string argument if it exists in the arguments table.
 *
 * @param args Variable table containing arguments
 * @param key Key name to retrieve and print
 */
static void print_optional_arg_cstring_t(amxc_var_t* args, const char* const key) {
    amxc_var_t* var = NULL;
    if(( var = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT)) != NULL) {
        SAH_TRACEZ_INFO(ME, "%s: %s", key, amxc_var_get_const_cstring_t(var));
    }
}

/**
 * @brief Prints optional integer argument for debug purposes.
 *
 * Only available in debug builds (TIMINGILA_DEBUG). Retrieves and logs
 * an integer argument if it exists in the arguments table.
 *
 * @param args Variable table containing arguments
 * @param key Key name to retrieve and print
 */
static void print_optional_arg_int32_t(amxc_var_t* args, const char* const key) {
    amxc_var_t* var = NULL;
    if(( var = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT)) != NULL) {
        SAH_TRACEZ_INFO(ME, "%s: %d", key, amxc_var_get_int32_t(var));
    }
}

/**
 * @brief Prints optional boolean argument for debug purposes.
 *
 * Only available in debug builds (TIMINGILA_DEBUG). Retrieves and logs
 * a boolean argument if it exists in the arguments table.
 *
 * @param args Variable table containing arguments
 * @param key Key name to retrieve and print
 */
static void print_optional_arg_bool(amxc_var_t* args, const char* const key) {
    amxc_var_t* var = NULL;
    if(( var = amxc_var_get_key(args, key, AMXC_VAR_FLAG_DEFAULT)) != NULL) {
        SAH_TRACEZ_INFO(ME, "%s: %s", key, amxc_var_get_bool(var) ? "true" : "false");
    }
}
#endif

/**
 * @brief Handles execution environment reference as a path and converts it to a name.
 *
 * If the execution environment reference is provided as a path (contains dots),
 * this function resolves it to the actual EE object and extracts its name.
 * Supports both device-prefixed and direct software modules paths.
 * Sets appropriate fault information if path resolution fails.
 *
 * @param executionenvref Pointer to execution environment reference string.
 *                        Will be freed and replaced with EE name if path is detected
 * @param args Arguments table to be updated with resolved EE reference
 * @param dustatechange_data Pointer to DU state change data for error reporting
 *
 * @return amxd_status_ok on success, amxd_status_invalid_arg on path resolution failure
 */
static amxd_status_t handle_executionenvref_path(char** executionenvref, amxc_var_t* args, amxc_var_t* dustatechange_data) {
    amxd_object_t* ee_obj = NULL;
    const char* eeref_parsed = (*executionenvref);
    for(unsigned int i = 0; (*executionenvref)[i] != '\0'; i++) {
        if((*executionenvref)[i] == '.') {
            SAH_TRACEZ_INFO(ME, SM_DM_DU_EE_REF " is a path: '%s'", eeref_parsed);
            if(string_starts_with_device_prefix(eeref_parsed)) {
                eeref_parsed = (const char*) (eeref_parsed + (sizeof(DEVICE_DM_PREFIX) - (size_t) 1));
            }

            if(string_starts_with_sm_prefix(eeref_parsed) == false) {
                SAH_TRACEZ_ERROR(ME, SM_DM_DU_EE_REF " (%s) doesnt contain '" SOFTWAREMODULES_DM ".'", eeref_parsed);
                dustatechange_set_fault(dustatechange_data, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH_STR);
                dustatechange_event_error(dustatechange_data);
                return amxd_status_invalid_arg;
            }

            ee_obj = amxd_dm_findf(timingila_get_dm(), "%s", eeref_parsed);
            if(ee_obj) {
                free(*executionenvref);
                (*executionenvref) = amxd_object_get_value(cstring_t, ee_obj, SM_DM_EE_NAME, NULL);
            } else {
                SAH_TRACEZ_ERROR(ME, "Cannot resolve '%s'", eeref_parsed);
                dustatechange_set_fault(dustatechange_data, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH, ERR_DEPLOYMENT_UNIT_TO_EXECUTION_ENVIRONMENT_MISMATCH_STR);
                dustatechange_event_error(dustatechange_data);
                return amxd_status_invalid_arg;
            }

            update_var_data_cstring_t(args, SM_DM_DU_EE_REF, *executionenvref);
            break;
        }
    }

    return amxd_status_ok;
}

/**
 * @brief RPC handler for installing a software deployment unit.
 *
 * Validates installation arguments (UUID, execution environment, URL), generates
 * a DUID, checks for duplicate installations, and defers the installation process.
 * Sends appropriate events for success or failure.
 *
 * @param object Unused object parameter
 * @param func Function descriptor for deferral
 * @param args RPC arguments containing UUID, URL, EE reference, etc. Will be updated with generated DUID and deferred call ID
 * @param[out] ret Return value structure for deferred call
 *
 * @return amxd_status_deferred if installation is deferred successfully,
 *         amxd_status_invalid_arg on validation failure,
 *         amxd_status_unknown_error on other errors
 */
amxd_status_t _SoftwareModules_InstallDU(UNUSED amxd_object_t* object,
                                         amxd_function_t* func,
                                         amxc_var_t* args,
                                         amxc_var_t* ret) {
    lcm_dump_rpc(object, func, args, "Password");
    bool retb = false;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_status_t helpstatus = amxd_status_unknown_error;
    uint64_t callid;
    const char* uuid = GET_CHAR(args, SM_DM_DU_UUID);
    const char* oldexecutionenvref = GET_CHAR(args, SM_DM_DU_EE_REF);
    const char* operation = SM_DM_EVENT_DUSTATECHANGE_OPERATION_INSTALL;
    const char* url = GET_CHAR(args, SM_DM_DU_URL);
    char* executionenvref = NULL;
    char* duid = NULL;
    amxd_object_t* du_obj = NULL;
    executionenvref = strdup(oldexecutionenvref);
    amxc_ts_t start_time = {0, 0, 0};
    amxc_var_t* dustatechange_data = NULL;
    amxc_ts_now(&start_time);

    dustatechange_data = amxc_var_add_key(amxc_htable_t, args, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    init_dustatechange_data(dustatechange_data, uuid, NULL, operation, &start_time, NULL);

    if(check_uuid(uuid, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    if(check_executionenvref(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    helpstatus = handle_executionenvref_path(&executionenvref, args, dustatechange_data);
    if(helpstatus != amxd_status_ok) {
        status = helpstatus;
        goto exitfree;
    }

    duid = generate_duid(uuid, executionenvref);
    if(duid == NULL) {
        SAH_TRACEZ_ERROR(ME, "Cannot generate " SM_DM_DU_DUID);
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    amxc_var_add_key(cstring_t, args, SM_DM_DU_DUID, duid);
    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_DUID, duid);

#ifdef TIMINGILA_DEBUG
    print_optional_arg_cstring_t(args, SM_DM_DU_URL);
    print_optional_arg_cstring_t(args, SM_DM_DU_UUID);
    print_optional_arg_cstring_t(args, SM_DM_DU_USERNAME);
    print_optional_arg_cstring_t(args, SM_DM_DU_PASSWORD);
    print_optional_arg_cstring_t(args, SM_DM_DU_EE_REF);
    print_optional_arg_int32_t(args, SM_DM_DU_ALLOCCPUPERCENT);
    print_optional_arg_int32_t(args, SM_DM_DU_ALLOCMEM);
    print_optional_arg_int32_t(args, SM_DM_DU_ALLOCDISKSPACE);
    print_optional_arg_bool(args, SM_DM_DU_AUTOSTART);
    print_optional_arg_cstring_t(args, SM_DM_DU_DUID);
    print_optional_arg_cstring_t(args, SM_DM_DU_REQUIRED_ROLES);
    print_optional_arg_cstring_t(args, SM_DM_DU_OPTIONAL_ROLES);
#endif // TIMINGILA_DEBUG

    // check if DU already exists
    du_obj = get_du(duid);
    free(duid);
    duid = NULL;
    if(du_obj) {
        const char* du_url = amxd_object_get_value(cstring_t, du_obj, SM_DM_DU_URL, NULL);
        SAH_TRACEZ_ERROR(ME, "Found DU with DUID");
        if(strcmp(du_url, url) == 0) {
            SAH_TRACEZ_ERROR(ME, "URL's match, so we throw ERR_DUPLICATE_DEPLOYMENT_UNIT error: %d", ERR_DUPLICATE_DEPLOYMENT_UNIT);
            dustatechange_set_fault(dustatechange_data, ERR_DUPLICATE_DEPLOYMENT_UNIT, ERR_DUPLICATE_DEPLOYMENT_UNIT_STR);
            dustatechange_event_error(dustatechange_data);
            status = amxd_status_invalid_arg;
            goto exitfree;
        } else {
            SAH_TRACEZ_ERROR(ME, "URL's don't match, so we throw ERR_DUPLICATE_DEPLOYMENT_UNIT_MULTIPLE_VERSION: %d", ERR_DUPLICATE_DEPLOYMENT_UNIT_MULTIPLE_VERSION);
            // TODO: Introduce compile switch to turn this error off
            dustatechange_set_fault(dustatechange_data, ERR_DUPLICATE_DEPLOYMENT_UNIT_MULTIPLE_VERSION, ERR_DUPLICATE_DEPLOYMENT_UNIT_MULTIPLE_VERSION_STR);
            dustatechange_event_error(dustatechange_data);
            status = amxd_status_invalid_arg;
            goto exitfree;
        }
    }

    // check if EE is disabled
    if(check_ee_disabled(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }
    amxd_function_defer(func, &callid, ret, NULL, NULL);
    amxc_var_add_key(uint64_t, args, AMXB_DEFERRED_CALLID, callid);

    retb = container_eu_validateinstallargs(args);
    when_false(retb, exitdeferred);
    status = amxd_status_deferred;
    goto exitfree;
exitdeferred:
    amxd_function_deferred_remove(callid);
    // This can be that the module (packager) is not loaded or,
    // the package is not happy with the arguments provided (and thus returns)
    // or the object is missing in this call
    dustatechange_set_fault(dustatechange_data, ERR_USP_INTERNAL_ERROR, ERR_USP_INTERNAL_ERROR_STR);
    dustatechange_event_error(dustatechange_data);
exitfree:
    free(executionenvref);
    return status;
}

/**
 * @brief RPC handler for updating an existing software deployment unit.
 *
 * Retrieves deployment unit parameters from the object, validates UUID and
 * execution environment, prepares update arguments, and defers the update process.
 * Sends appropriate events for success or failure.
 *
 * @param object Deployment unit object to update
 * @param func Unused function descriptor for deferral
 * @param args RPC arguments. Will be updated with DU parameters and deferred call ID
 * @param ret Return value structure for deferred call
 *
 * @return amxd_status_deferred if update is deferred successfully,
 *         amxd_status_invalid_arg on validation failure,
 *         amxd_status_unknown_error on other errors
 */
amxd_status_t _DeploymentUnit_Update(amxd_object_t* object,
                                     UNUSED amxd_function_t* func,
                                     UNUSED amxc_var_t* args,
                                     amxc_var_t* ret) {
    lcm_dump_rpc(object, func, args, "Password");
    bool retb = false;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_status_t helpstatus = amxd_status_unknown_error;
    const char* uuid = NULL;
    const char* oldexecutionenvref = NULL;
    const char* version = NULL;
    const char* operation = SM_DM_EVENT_DUSTATECHANGE_OPERATION_UPDATE;
    const char* duid = NULL;
    char* executionenvref = NULL;
    uint64_t callid;
    amxc_var_t params;
    amxc_var_t* dustatechange_data = NULL;
    amxc_ts_t start_time = {0, 0, 0};

    amxc_ts_now(&start_time);
    dustatechange_data = amxc_var_add_key(amxc_htable_t, args, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    init_dustatechange_data(dustatechange_data, uuid, NULL, operation, &start_time, object);

    amxc_var_init(&params);
    when_null(object, exiterror);

    amxd_object_get_params(object, &params, amxd_dm_access_public);

    uuid = GET_CHAR(&params, SM_DM_DU_UUID);
    oldexecutionenvref = GET_CHAR(&params, SM_DM_DU_EE_REF);
    executionenvref = strdup(oldexecutionenvref);
    version = GET_CHAR(&params, SM_DM_DU_VERSION);
    duid = GET_CHAR(&params, SM_DM_DU_DUID);

    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, uuid);

    if(check_uuid(uuid, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    if(check_executionenvref(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }


    helpstatus = handle_executionenvref_path(&executionenvref, args, dustatechange_data);
    if(helpstatus != amxd_status_ok) {
        status = helpstatus;
        goto exitfree;
    }

    // check if EE is disabled
    if(check_ee_disabled(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    amxc_var_add_key(cstring_t, args, SM_DM_DU_UUID, uuid);
    amxc_var_add_key(cstring_t, args, SM_DM_DU_EE_REF, executionenvref);
    // Current version -> new version to be deduced from url
    amxc_var_add_key(cstring_t, args, SM_DM_DU_VERSION, version);
    amxc_var_add_key(cstring_t, args, SM_DM_DU_DUID, duid);
    if(GET_ARG(args, SM_DM_DU_URL) == NULL) {
        const char* url = GET_CHAR(&params, SM_DM_DU_URL);
        if(url) {
            SAH_TRACEZ_WARNING(ME, "No " SM_DM_DU_URL " included, lets include the one from the dm: '%s'", url);
            amxc_var_add_key(cstring_t, args, SM_DM_DU_URL, url);
        } else {
            SAH_TRACEZ_ERROR(ME, "No " SM_DM_DU_URL " included, and cannot find it in the dm");
        }
    }

    amxd_function_defer(func, &callid, ret, NULL, NULL);
    amxc_var_add_key(uint64_t, args, AMXB_DEFERRED_CALLID, callid);

    retb = container_eu_validateupdateargs(args);
    when_false(retb, exitdeferred);

    status = amxd_status_deferred;
    goto exitfree;
exitdeferred:
    amxd_function_deferred_remove(callid);
exiterror:
    // This can be that the module (packager) is not loaded or,
    // the package is not happy with the arguments provided (and thus returns)
    // or the object is missing in this call
    dustatechange_set_fault(dustatechange_data, ERR_USP_INTERNAL_ERROR, ERR_USP_INTERNAL_ERROR_STR);
    dustatechange_event_error(dustatechange_data);
exitfree:
    amxc_var_clean(&params);
    free(executionenvref);
    return status;
}

/**
 * @brief RPC handler for uninstalling a software deployment unit.
 *
 * Retrieves deployment unit parameters from the object, validates UUID and
 * execution environment, checks if EE is enabled, and defers the uninstall process.
 * Sends appropriate events for success or failure.
 *
 * @param object Deployment unit object to uninstall
 * @param func Unused function descriptor for deferral
 * @param args RPC arguments containing RetainData parameter. Will be updated with deferred call ID
 * @param ret Return value structure for deferred call
 *
 * @return amxd_status_deferred if uninstall is deferred successfully,
 *         amxd_status_invalid_arg on validation failure,
 *         amxd_status_unknown_error on other errors
 */
amxd_status_t _DeploymentUnit_Uninstall(amxd_object_t* object,
                                        UNUSED amxd_function_t* func,
                                        UNUSED amxc_var_t* args,
                                        amxc_var_t* ret) {
    lcm_dump_rpc(object, func, args, NULL);
    bool retb = false;
    amxd_status_t status = amxd_status_unknown_error;
    amxd_status_t helpstatus = amxd_status_unknown_error;
    bool retaindata = GET_BOOL(args, SM_DM_DU_RPC_RETAINDATA);
    const char* uuid = NULL;
    const char* oldexecutionenvref = NULL;
    const char* version = NULL;
    const char* operation = SM_DM_EVENT_DUSTATECHANGE_OPERATION_UNINSTALL;
    char* executionenvref = NULL;
    amxc_var_t params;
    uint64_t callid;
    amxc_var_t* dustatechange_data = NULL;
    amxc_ts_t start_time = {0, 0, 0};

    amxc_ts_now(&start_time);

    amxc_var_init(&params);

    when_null(object, exiterror);

    amxd_object_get_params(object, &params, amxd_dm_access_public);
    dustatechange_data = amxc_var_add_key(amxc_htable_t, &params, SM_DM_EVENT_DUSTATECHANGE_DATA, NULL);
    init_dustatechange_data(dustatechange_data, uuid, NULL, operation, &start_time, object);

    uuid = GET_CHAR(&params, SM_DM_DU_UUID);
    oldexecutionenvref = GET_CHAR(&params, SM_DM_DU_EE_REF);
    executionenvref = strdup(oldexecutionenvref);
    version = GET_CHAR(&params, SM_DM_DU_VERSION);

    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_UUID, uuid);
    update_var_data_cstring_t(dustatechange_data, SM_DM_EVENT_DUSTATECHANGE_VERSION, version);

    if(check_uuid(uuid, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    if(check_executionenvref(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    helpstatus = handle_executionenvref_path(&executionenvref, args, dustatechange_data);
    if(helpstatus != amxd_status_ok) {
        status = helpstatus;
        goto exitfree;
    }

#ifdef TIMINGILA_DEBUG
    const char* name = GET_CHAR(&params, SM_DM_DU_NAME);
    const char* vendor = GET_CHAR(&params, SM_DM_DU_VENDOR);
    const char* version = GET_CHAR(&params, SM_DM_DU_VERSION);
    const char* duid = GET_CHAR(&params, SM_DM_DU_DUID);

    SAH_TRACEZ_ERROR(ME, SM_DM_DU_RPC_RETAINDATA ": %d", retaindata);

    SAH_TRACEZ_INFO(ME, SM_DM_DU_UUID ": %s", uuid);
    SAH_TRACEZ_INFO(ME, SM_DM_DU_NAME ": %s", name);
    SAH_TRACEZ_INFO(ME, SM_DM_DU_VENDOR ": %s", vendor);
    SAH_TRACEZ_INFO(ME, SM_DM_DU_VERSION ": %s", version);
    SAH_TRACEZ_INFO(ME, SM_DM_DU_EE_REF ": %s", executionenvref);
    SAH_TRACEZ_INFO(ME, SM_DM_DU_DUID ": %s", duid);
#endif // TIMINGILA_DEBUG

    // check if EE is disabled
    if(check_ee_disabled(executionenvref, dustatechange_data)) {
        status = amxd_status_invalid_arg;
        goto exitfree;
    }

    amxd_function_defer(func, &callid, ret, NULL, NULL);
    amxc_var_add_key(uint64_t, &params, AMXB_DEFERRED_CALLID, callid);
    amxc_var_add_key(bool, &params, SM_DM_DU_RPC_RETAINDATA, retaindata);

    retb = container_UninstallDu(&params);
    when_false(retb, exitdeferred);

    status = amxd_status_deferred;
    goto exitfree;
exitdeferred:
    amxd_function_deferred_remove(callid);
exiterror:
    // This can be that the module (packager) is not loaded or,
    // the package is not happy with the arguments provided (and thus returns)
    // or the object is missing in this call
    dustatechange_set_fault(dustatechange_data, ERR_USP_INTERNAL_ERROR, ERR_USP_INTERNAL_ERROR_STR);
    dustatechange_event_error(dustatechange_data);
exitfree:
    amxc_var_clean(&params);
    free(executionenvref);
    return status;
}
