/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <limits.h>

#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxp/amxp_dir.h>
#include <amxd/amxd_dm.h>
#include <amxm/amxm.h>
#include <amxb/amxb.h>
#include <amxo/amxo.h>
#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "modunbound.h"
#include "modunbound_cmd.h"

#define DELAY_TIME 500                  //milliseconds - 500 miliseconds waiting to initialize unbound (to avoid multiple retriggers)
#define WAIT_FOR_CHILD_IN_SEC 5         //seconds - wait a maximum 5 seconds for the unbound instance to be running
#define MODUNBOUND_SERVFAIL 2           //rcode of unbound's SERVFAIL
#define INI_BACKOFF_WAIT_TIME 1000      //milliseconds - 1 second is the initial backoff delay
#define MAX_BACKOFF_WAIT_TIME 180000    //milliseconds - 3 minutes is the maximum backoff delay
#define THRESHOLD_RESET_BACKOFF 1800000 //milliseconds - 30 minutes after the last unbound start

#ifndef DNS_UNBOUND_CONFIG_PATH
#define DNS_UNBOUND_CONFIG_PATH "/tmp/etc/unbound"
#endif

#ifndef DNS_UNBOUND_CONFIG_FILE
#define DNS_UNBOUND_CONFIG_FILE DNS_UNBOUND_CONFIG_PATH "/unbound-%s.conf"
#endif

#ifndef DNS_UNBOUND_REDIRECT_FILE
#define DNS_UNBOUND_REDIRECT_FILE DNS_UNBOUND_CONFIG_PATH "/redirect.conf"
#endif

typedef enum {
    STOPPED = 0,
    WAIT_START_TIMER,
    STARTING,
    RUNNING,
} state_t;

/**
 * @brief Convert an internal Unbound instance state to a human-readable string.
 *
 * This helper exists purely for observability: it turns the state machine enum into a stable,
 * readable label that can be included in traces and logs while managing the Unbound process.
 *
 * @param[in] state Current state value.
 *
 * @return A constant string describing @p state (never @c NULL).
 */
static const char* strstate(state_t state) {
    const char* states[] = {"STOPPED", "WAIT_TIMER", "STARTING", "RUNNING"};
    return state > RUNNING ? "unknown state" : states[state];
}

/**
 * @brief Global DNS rebind-protection configuration (TR-181 security policy).
 *
 * @details
 * DNS rebind protection is a security feature that blocks responses which map public names to
 * private/routed addresses (a common attack technique). The TR-181 DNS plugin exposes this as a
 * module-wide toggle with exception lists.
 *
 * This structure stores that policy in memory so it can be rendered into generated Unbound
 * configuration files and used to converge running instances (via the module lifecycle/state
 * machine and, when applicable, UnboundControl).
 */
typedef struct {
    bool enable;        /**< Enable/disable rebind protection globally. */
    amxc_var_t domains; /**< List of domain exceptions that bypass rebind protection. */
    amxc_var_t ips;     /**< List of IP exceptions that bypass rebind protection. */
} globals_rebind_t;

/**
 * @brief Per-interface Unbound instance context (runtime state + staged configuration).
 *
 * @details
 * This module manages Unbound instances per interface/view as part of translating TR-181 DNS
 * configuration into concrete Unbound behaviour. Each instance:
 * - maintains a staged configuration subtree used to generate an instance-specific Unbound config file;
 * - tracks operational state (enabled, interface up/down, process state machine);
 * - coordinates restarts/reloads and crash recovery (including burst-coalescing and exponential backoff);
 * - interacts with the backend through a wrapped UnboundControl ubus RPC when live updates are possible.
 *
 * The lifecycle handler (@ref handle_unbound) uses this structure to decide when to start/stop/restart
 * the Unbound subprocess and how to handle config changes that occur while an instance is starting.
 */
typedef struct {
    bool enable;                  /**< Effective enable state for this instance (global enable AND interface up). */
    bool is_intf_up;              /**< Cached interface operational state (true when interface is up/usable). */
    bool out_of_sync;             /**< Config changed while STARTING; forces a restart once the child is ready. */
    bool stopping;                /**< Instance is being stopped intentionally (used to distinguish crash vs stop). */
    bool fail_stop;               /**< Stop requested as part of a failure-recovery path (affects stop bookkeeping). */

    amxc_var_t config;            /**< Per-interface configuration subtree (views/hosts/cache, etc.) used for file generation. */

    amxp_timer_t* backoff_timer;  /**< Timer used to reset exponential-backoff after prolonged stability. */
    uint32_t backoff_delay;       /**< Current exponential-backoff delay before attempting a restart (ms). */

    amxp_subproc_t* process;      /**< Managed Unbound subprocess handle for this interface instance. */
    state_t state;                /**< Current lifecycle state (STOPPED/WAIT_START_TIMER/STARTING/RUNNING). */

    amxp_timer_t* start_timer;    /**< Coalescing timer to batch bursts of restart-triggering events. */
    uint32_t start_timer_in_ms;   /**< Delay used by @c start_timer to postpone (re)start (ms). */
    amxp_timer_t* wait_for_child; /**< Guard timer while waiting for the child process/object to become ready. */

    amxc_string_t intf;           /**< Interface identifier for this instance (key used across config/state/ubus). */
    amxc_htable_it_t it;          /**< Hashtable iterator node for storage in @c g.unbound_intf_per_intf. */
} unbound_intf_t;

/**
 * @brief Module-wide state shared across all interfaces (TR-181 → Unbound translation context).
 *
 * @details
 * The module keeps a global state container to:
 * - store shared configuration that applies across instances (forward zones, ODL options, etc.);
 * - keep module-wide resolver behaviour knobs (timeout/repeat) that influence generated Unbound config;
 * - track the global security policy (rebind protection);
 * - maintain the registry of per-interface Unbound instances managed by this module.
 *
 * This is the central “source of truth” that TR-181 entry points update. The module then converges
 * on-disk configuration and runtime behaviour by regenerating instance config files and steering the
 * per-interface lifecycle state machine (which may also use UnboundControl to push live updates).
 */
typedef struct {
    bool enable;                         /**< Global enable flag for the DNS resolver service (applies to all instances). */
    amxc_var_t config;                   /**< Global configuration tree (fwzones/interfaces/views/options, etc.). */
    globals_rebind_t rebind;             /**< Global rebind-protection policy and exception lists. */
    int32_t timeout;                     /**< Outbound query timeout used for generated Unbound config (-1 = Unbound default). */
    int32_t repeat;                      /**< Outbound retry count used for generated Unbound config (-1 = Unbound default). */
    amxc_htable_t unbound_intf_per_intf; /**< Map: interface name -> @ref unbound_intf_t (managed instances). */
} globals_t;

/**
 * @brief One-time logging guard for specific Unbound options.
 *
 * @details
 * Some Unbound options may be overridden or constrained by this module (for example, to ensure
 * compatibility across versions or to enforce a consistent policy). When that happens, it can be
 * useful to inform operators — but only once to avoid log flooding.
 *
 * This small helper structure tracks which option notice has already been emitted.
 */
typedef struct {
    const char* text; /**< Option name or identifier used to match/log (e.g. config keyword). */
    bool logged;      /**< Set once the corresponding warning/info has been logged. */
} unbound_option_t;

static globals_t g;
static const char* ipaddr_types[] = {"ipv4_addresses", "ipv6_addresses", NULL};
static unbound_option_t unbound_opt[] = {
    {"outbound-msg-timeout", false},
    {NULL, false}
};

static void handle_unbound(unbound_intf_t* unbound, const char* caller);
static bool stop_unbound(unbound_intf_t* unbound, state_t next_state);
static unbound_intf_t* get_unbound_intf(const char* intf);
static void unbound_intf_delete(unbound_intf_t** unbound);
static unbound_intf_t* unbound_intf_new(const char* intf, bool enable);
static unbound_intf_t* add_unbound_intf(const char* intf, bool enable);

#ifdef TESTING
/**
 * @brief Test helper to access the active configuration tree for a given interface.
 *
 * In production the module keeps configuration split between global settings (shared across
 * instances) and per-interface settings (views/cache for a specific Unbound instance). Unit
 * tests need a way to inspect those internal variant trees without exposing additional runtime
 * APIs on the bus.
 *
 * When @p intf is empty, the function returns the global configuration container. Otherwise it
 * returns the configuration container associated with the matching per-interface Unbound instance.
 *
 * @param[in] intf Interface identifier to select the corresponding Unbound instance; may be empty.
 *
 * @return Pointer to the requested config variant, or @c NULL when @p intf does not match any
 *         known instance.
 */
amxc_var_t* testhelper_get_config(const cstring_t intf) {
    if(string_empty(intf)) {
        return &g.config;
    }
    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        if(strcmp(amxc_string_get(&unbound->intf, 0), intf) == 0) {
            return &unbound->config;
        }
    }
    return NULL;
}
#endif

/**
 * @brief Apply a state transition to an Unbound instance.
 *
 * This module runs Unbound instances as managed subprocesses and needs to reliably convey why an
 * instance changed state (configuration update, enable toggle, crash recovery, etc.). Centralizing
 * the update ensures state changes are consistently logged with the same context.
 *
 * @param[in,out] unbound Unbound instance object to update.
 * @param[in]     state  New state to set on @p unbound.
 * @param[in]     reason Short textual reason (typically a function name or scenario label).
 */
static void update_state(unbound_intf_t* unbound, state_t state, const char* reason) {
    when_null(unbound, exit);
    SAH_TRACEZ_INFO(ME, "state change for %s %s -> %s timer %d (reason: %s)", amxc_string_get(&unbound->intf, 0), strstate(unbound->state), strstate(state), amxp_timer_get_state(unbound->start_timer), reason);
    unbound->state = state;
exit:
    return;
}

/**
 * @brief Format the current local date/time for inclusion in generated config files.
 *
 * Generated Unbound configuration files include a timestamp header so operators and tests can
 * quickly confirm *when* the module last regenerated the file as part of TR-181 configuration
 * application.
 *
 * @param[out] date      Destination buffer to receive the formatted date/time string.
 * @param[in]  date_size Size of @p date in bytes.
 *
 * @return @p date for convenience.
 */
static char* get_date(char* date, size_t date_size) {
    time_t t;
    struct tm result;
    struct tm* tm = NULL;

    t = time(NULL);
    if((t != -1) && ((tm = localtime_r(&t, &result)) != NULL)) {
        strftime(date, date_size, "%F %T", tm);
    } else {
        snprintf(date, date_size, "0000-00-00 00:00");
    }

    return date;
}

/**
 * @brief Write rebind-protection directives to an Unbound configuration stream.
 *
 * When DNS Rebind protection is enabled through TR-181, the module instructs Unbound to treat
 * private address ranges as "private-address" and optionally allow exceptions. This prevents DNS
 * answers from resolving to private networks unless explicitly permitted (domains/IP exceptions).
 *
 * @param[in] unbound Unbound instance the configuration applies to (used for contextual checks/logs).
 * @param[in] file   Open output stream for the Unbound configuration file.
 */
static void config_file_populate_private_addresses(unbound_intf_t* unbound, FILE* file) {
    when_null(unbound, exit);
    // Protect private addresses from rebind attacks
    when_false(g.rebind.enable, exit);

    // Site local address space
    fprintf(file, "    private-address: 10.0.0.0/8\n");     // IPv4 rfc1918
    fprintf(file, "    private-address: 172.16.0.0/12\n");  // IPv4 rfc1918
    fprintf(file, "    private-address: 192.168.0.0/16\n"); // IPv4 rfc1918
    fprintf(file, "    private-address: fd00::/8\n");       // IPv6

    // Link local address space
    fprintf(file, "    private-address: 169.254.0.0/16\n"); // IPv4
    fprintf(file, "    private-address: fe80::/10\n");      // IPv6

    // Device local
    //   leaving this enabled might hinder many spam-blocklists (RBL)!
    fprintf(file, "    private-address: 127.0.0.0/8\n");    // IPv4
    fprintf(file, "    private-address: ::1/128\n");        // IPv6

    // IPv4 ranges mapped on IPv6
    fprintf(file, "    private-address: ::ffff:0:0/96\n");

    // Domain exceptions
    amxc_var_for_each(domain, &g.rebind.domains) {
        fprintf(file, "    private-domain: %s\n", GET_CHAR(domain, NULL));
    }

    // IP exceptions
    amxc_var_for_each(ip, &g.rebind.ips) {
        fprintf(file, "    private-exception: %s\n", GET_CHAR(ip, NULL));
    }

exit:
    return;
}

/**
 * @brief Generate (or update) the Unbound configuration file for a specific interface instance.
 *
 * @details
 * The TR-181 DNS model expresses high-level resolver settings (global options, forwarding zones,
 * per-interface views, host records, cache tuning, rebind protection, etc.). Unbound consumes these
 * settings through its textual configuration. This function translates the current in-memory config
 * into an Unbound configuration file for @p unbound.
 *
 * Operationally, it writes to a temporary “.new” file and then renames it into place to keep updates
 * atomic. It also maintains an included redirect file that Unbound reads via an `include:` directive.
 * The resulting config is what the module later uses to start/restart the Unbound process for the
 * interface.
 *
 * @param[in] unbound Unbound instance (interface, per-instance config) to generate config for.
 *
 * @return @c true when the configuration file was successfully written and moved into place,
 *         @c false otherwise.
 */
static bool create_config_file(unbound_intf_t* unbound) {
    amxc_var_t* options = GET_ARG(&g.config, "options");
    amxc_var_t* fwzones = GET_ARG(&g.config, "fwzones");
    amxc_var_t* views = NULL;
    amxc_var_t* view = NULL;
    amxc_var_t* cache = NULL;
    amxc_set_t* set_of_address_fwzone = NULL;
    FILE* redirect_file = NULL;
    amxc_string_t unbound_config_file;
    amxc_string_t unbound_config_file_new;
    FILE* file = NULL;
    const char* interface = NULL;
    const char* domain_name = NULL;
    char date[64];
    int rv = -1;

    amxc_string_init(&unbound_config_file, 0);
    amxc_string_init(&unbound_config_file_new, 0);

    when_null(unbound, exit);
    cache = GET_ARG(&unbound->config, "cache");
    views = GET_ARG(&unbound->config, "views");
    interface = amxc_string_get(&unbound->intf, 0);

    amxc_string_setf(&unbound_config_file, DNS_UNBOUND_CONFIG_FILE, interface);
    amxc_string_setf(&unbound_config_file_new, DNS_UNBOUND_CONFIG_FILE ".new", interface);
    file = fopen(amxc_string_get(&unbound_config_file_new, 0), "w");
    when_null_trace(file, exit, ERROR, "Could not open file %s for writing", amxc_string_get(&unbound_config_file_new, 0));

    redirect_file = fopen(DNS_UNBOUND_REDIRECT_FILE, "a");
    when_null_trace(redirect_file, exit, ERROR, "Could not open file " DNS_UNBOUND_REDIRECT_FILE " for writing");

    fprintf(file, "# unbound configuration file for interface %s, generated by tr181-dns on %s.\n", interface, get_date(date, sizeof(date)));
    fprintf(file, "\n");

    fprintf(file, "server:\n");
    fprintf(file, "# ODL {\n");
    amxc_var_for_each(option, options) {
        int ignore = -1;
        // because of backward compatibility, it is possible that some options are set in out of date odl files
        for(int i = 0; unbound_opt[i].text != NULL; i++) {
            if((strstr(GET_CHAR(option, NULL), unbound_opt[i].text) != NULL) && (g.timeout != -1)) {
                if(!unbound_opt[i].logged) {
                    SAH_TRACEZ_WARNING(ME, "please remove option '%s' from ODL", unbound_opt[i].text);
                    unbound_opt[i].logged = true; // logging once is enough
                }
                ignore = i;
                break;
            }
        }
        fprintf(file, "%c   %s\n", (ignore >= 0) ? '#' : ' ', GET_CHAR(option, NULL)); // assume option is not already be configured by default
    }
    fprintf(file, "# }\n");
    fprintf(file, "    username: \"\"\n");
    fprintf(file, "    chroot: \"\"\n");
    fprintf(file, "    directory: \"/var/lib\"\n"); // otherwise unbound stops because /var/lib/unbound/ doesn't exist
    fprintf(file, "    do-daemonize: no\n");
    fprintf(file, "    module-config: \"iterator\"\n");
    fprintf(file, "    max-udp-size: 4096\n");
    if(cache != NULL) {
        uint32_t ttl_max = GET_UINT32(cache, "ttl_max");
        uint32_t ttl_min = GET_UINT32(cache, "ttl_min");
        uint32_t cache_size = GET_UINT32(cache, "cache_size");
        // for now use the cache-size for all caches instead of having some sort of distribution key
        fprintf(file, "    rrset-cache-size: %uk\n", cache_size);
        fprintf(file, "    msg-cache-size: %uk\n", cache_size);
        fprintf(file, "    key-cache-size: %uk\n", cache_size);
        fprintf(file, "    neg-cache-size: %uk\n", cache_size);
        if(ttl_max > 0) {
            fprintf(file, "    cache-max-ttl: %u\n", ttl_max);
        }
        if(ttl_min > 0) {
            fprintf(file, "    cache-min-ttl: %u\n", ttl_min);
        }
    }
    fprintf(file, "    infra-cache-numhosts: %u\n", 100);   // unbound.conf manpage says the default value is 10k which seems a bit much?
    fprintf(file, "    infra-keep-probing: yes\n");         // otherwise Unbound will stop (if delegation point with 1 address) after 1 retry and not all outbound-msg-retry
    fprintf(file, "    bind-interfaces: yes\n");
    fprintf(file, "    access-control: 0.0.0.0/0 allow\n"); // shoud be ok since using bind-interfaces
    fprintf(file, "    access-control: ::0/0 allow\n");     // shoud be ok since using bind-interfaces
    if(g.timeout != -1) {
        fprintf(file, "    outbound-msg-timeout: %d\n", g.timeout);
    }
    if(g.repeat != -1) {
        fprintf(file, "    outbound-msg-retry: %d\n", g.repeat);
    }
    fprintf(file, "    interface: %s\n", interface);
    config_file_populate_private_addresses(unbound, file);

    fprintf(file, "    include: \"%s\"\n", DNS_UNBOUND_REDIRECT_FILE);
    fprintf(file, "\n");

    amxc_var_for_each(fwzone, fwzones) {
        set_of_address_fwzone = aggregate_servers(fwzone);
        fprintf(file, "forward-zone:\n");
        fprintf(file, "    name: \"%s\"\n", amxc_var_key(fwzone));
        amxc_set_iterate(address, set_of_address_fwzone) {
            if(string_empty(address->flag)) {
                continue;
            }
            fprintf(file, "    forward-addr: %s\n", address->flag);
        }
        fprintf(file, "\n");
        amxc_set_delete(&set_of_address_fwzone);
    }

    fprintf(file, "view:\n");
    fprintf(file, "    name: \"%s\"\n", interface);
    fprintf(file, "    view-first: yes  # also check global local-zones\n");
    view = GET_ARG(views, interface);
    domain_name = GET_CHAR(view, "domain_name");
    amxc_var_for_each(host, GET_ARG(view, "hosts")) {
        const char* hostname = amxc_var_key(host);
        const char* local_domain = GET_CHAR(host, "local_domain");
        const char* domain = string_empty(local_domain) ? domain_name : local_domain;
        bool is_local = is_local_hostname_base(hostname);
        amxc_var_for_each(ipaddress, GET_ARG(host, "ipv4_addresses")) {
            fprintf(file, "    local-data: '%s A %s'\n", hostname, GET_CHAR(ipaddress, NULL));
            fprintf(file, "    local-data-ptr: '%s %s'\n", GET_CHAR(ipaddress, NULL), hostname);
            if(is_local && !string_empty(domain)) {
                fprintf(file, "    local-data: '%s.%s A %s'\n", hostname, domain, GET_CHAR(ipaddress, NULL));
                fprintf(file, "    local-data-ptr: '%s %s.%s'\n", GET_CHAR(ipaddress, NULL), hostname, domain);
            }
        }
        amxc_var_for_each(ipaddress, GET_ARG(host, "ipv6_addresses")) {
            fprintf(file, "    local-data: '%s AAAA %s'\n", hostname, GET_CHAR(ipaddress, NULL));
            fprintf(file, "    local-data-ptr: '%s %s'\n", GET_CHAR(ipaddress, NULL), hostname);
            if(is_local && !string_empty(domain)) {
                fprintf(file, "    local-data: '%s.%s AAAA %s'\n", hostname, domain, GET_CHAR(ipaddress, NULL));
                fprintf(file, "    local-data-ptr: '%s %s.%s'\n", GET_CHAR(ipaddress, NULL), hostname, domain);
            }
        }
    }
    fprintf(file, "\n");

    fclose(file);
    file = NULL;
    rename(amxc_string_get(&unbound_config_file_new, 0), amxc_string_get(&unbound_config_file, 0));

    rv = 0;

exit:
    if(file != NULL) {
        fclose(file);
    }

    if(redirect_file != NULL) {
        fclose(redirect_file);
        redirect_file = NULL;
    }

    amxc_set_delete(&set_of_address_fwzone);
    amxc_string_clean(&unbound_config_file);
    amxc_string_clean(&unbound_config_file_new);
    return rv == 0;
}

/**
 * @brief Notify the tr181-dns plugin about forwarding readiness based on instance runtime state.
 *
 */
static void update_forwarding_status(void) {
    amxc_var_t args;
    amxc_var_t ret;
    amxc_var_t* fwzones = GET_ARG(&g.config, "fwzones");
    bool running = true;

    amxc_var_init(&args);
    amxc_var_init(&ret);

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        if(unbound->state != RUNNING) {
            running = false;
            break;
        }
    }

    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    if(running) {
        amxc_var_copy(&args, fwzones);
    }

    amxm_execute_function(NULL, "core", "update-forwarding-status", &args, &ret);

    amxc_var_clean(&ret);
    amxc_var_clean(&args);
}

/**
 * @brief Handle Unbound “client-response” events and propagate relevant errors to the core logic.
 *
 * Unbound can emit response events (via the bus object) describing resolver outcomes. This callback
 * watches for server failure indications (e.g. SERVFAIL) and triggers the module’s higher-level
 * failure handling by calling into the “core” component (`server-failure`).
 *
 * @param[in]     sig_name Signal name (unused).
 * @param[in]     data     Event payload containing (at least) the response code.
 * @param[in,out] priv     User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void client_response_event(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  UNUSED void* const priv) {
    unbound_intf_t* unbound = (unbound_intf_t*) priv;
    when_null(unbound, exit);

    uint32_t rcode = GET_UINT32(data, "rcode");
    SAH_TRACEZ_INFO(ME, "unbound '%s' event received rcode=%u", amxc_string_get(&unbound->intf, 0), rcode);
    if(rcode == MODUNBOUND_SERVFAIL) {
        amxc_var_t args;
        amxc_var_t ret;

        amxc_var_init(&args);
        amxc_var_init(&ret);

        amxm_execute_function(NULL, "core", "server-failure", &args, &ret);

        amxc_var_clean(&ret);
        amxc_var_clean(&args);
    }

exit:
    return;
}

/**
 * @brief Reset the exponential backoff delay after a sustained stable period.
 *
 * To prevent restart storms after repeated crashes, the module increases the restart delay
 * exponentially. Once Unbound has been stable for a long enough period, this timer callback resets
 * the delay back to the initial value so normal (fast) restarts are possible again.
 *
 * @param[in]     local_timer Timer instance (unused).
 * @param[in,out] priv        User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void exponential_backoff_restart(UNUSED amxp_timer_t* local_timer, void* priv) {
    unbound_intf_t* unbound = (unbound_intf_t*) priv;
    when_null(unbound, exit);
    //Reset the the backoff algorithm after a long time without crashes.
    unbound->backoff_delay = INI_BACKOFF_WAIT_TIME;
    amxp_timer_stop(unbound->backoff_timer);
exit:
    return;
}

/**
 * @brief Schedule a restart using exponential backoff after an unexpected failure condition.
 *
 * @details
 * This is used when Unbound crashes, fails to start, cannot be subscribed to, or other
 * “unexpected” lifecycle errors occur. The goal is to keep the resolver available while avoiding
 * a tight restart loop that could overload the system.
 *
 * If the process is not running, it schedules the start timer with the current backoff delay and
 * then increases the delay for the next failure (capped by a maximum, with reset handled separately).
 * If the process is still running when backoff is requested, it attempts to stop it cleanly first.
 *
 * @param[in,out] unbound Unbound instance to restart.
 * @param[in]     reason Human-readable reason used for logging and troubleshooting.
 */
static void trigger_exponential_backoff(unbound_intf_t* unbound, const char* reason) {
    const char* interface = NULL;

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    amxp_timer_stop(unbound->backoff_timer);
    if(!amxp_subproc_is_running(unbound->process)) {
        SAH_TRACEZ_ERROR(ME, "Restarting "UNBOUND_OBJECT_NAME " in %u milliseconds after '%s'", interface, unbound->backoff_delay, reason);
        amxp_timer_start(unbound->start_timer, unbound->backoff_delay);
        update_state(unbound, WAIT_START_TIMER, __func__);
        unbound->out_of_sync = false;
        unbound->backoff_delay *= 2;                        // Exponential increase
        if(unbound->backoff_delay > MAX_BACKOFF_WAIT_TIME) {
            unbound->backoff_delay = INI_BACKOFF_WAIT_TIME; //Reset the delay when it overflows MAX_BACKOFF_WAIT_TIME
        }
    } else {
        SAH_TRACEZ_ERROR(ME, "Stopping "UNBOUND_OBJECT_NAME " after '%s'", interface, reason);
        unbound->fail_stop = true;
        stop_unbound(unbound, STOPPED);
    }
exit:
    return;
}

/**
 * @brief Process stop-event handler for a managed Unbound subprocess.
 *
 * This slot is connected to the subprocess manager and is invoked whenever the Unbound process
 * terminates. It distinguishes expected shutdown from unexpected failures (non-zero exit code),
 * updates instance state accordingly, and—when the instance is enabled—initiates a backoff-based
 * restart strategy.
 *
 * @param[in]     event_name Event name (unused).
 * @param[in]     data       Stop event payload (includes exit code).
 * @param[in,out] priv       User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void unbound_stopped(UNUSED const char* const event_name,
                            const amxc_var_t* const data,
                            void* const priv) {
    uint32_t exit_code = GET_UINT32(data, "ExitCode");
    unbound_intf_t* unbound = (unbound_intf_t*) priv;
    const char* interface = NULL;

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    if(exit_code != 0) { // this event handler is always called, even on expected restart, only handle the error cases with this function
        SAH_TRACEZ_ERROR(ME, "Unexpected "UNBOUND_OBJECT_NAME " stop: %d", interface, exit_code);
        update_state(unbound, STOPPED, __func__);
    } else {
        SAH_TRACEZ_INFO(ME, UNBOUND_OBJECT_NAME " stopped", interface);
    }
    update_forwarding_status();
    amxp_timer_stop(unbound->wait_for_child);
    if(unbound->enable && (unbound->stopping == false)) {
        trigger_exponential_backoff(unbound, "an unexpected failure or crash");
    }
    unbound->stopping = false;
    unbound->fail_stop = false;

exit:
    return;
}

/**
 * @brief Handle the “wait done” transition when Unbound becomes available on the bus.
 *
 * @details
 * After starting Unbound, the module waits until the corresponding Ambiorix bus object becomes
 * available (per interface). Receipt of the “wait done” signal indicates Unbound is ready for
 * configuration-driven operation.
 *
 * If configuration was updated while Unbound was still starting, the instance is marked out-of-sync
 * and this handler triggers a controlled restart so the running process always reflects the latest
 * TR-181 inputs. Otherwise it transitions the instance to RUNNING, updates forwarding status, and
 * subscribes to runtime events (e.g. `unbound:client-response`).
 *
 * @param[in]     s    Signal name (unused).
 * @param[in]     d    Signal data (unused).
 * @param[in,out] priv User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void unbound_wait_done(UNUSED const char* const s,
                              UNUSED const amxc_var_t* const d,
                              void* const priv) {
    amxb_bus_ctx_t* ctx = NULL;
    unbound_intf_t* unbound = (unbound_intf_t*) priv;
    const char* interface = NULL;
    amxc_string_t object_name;

    amxc_string_init(&object_name, 0);

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    when_false_trace(unbound->state == STARTING, exit, ERROR, "Ignored signal '" WAIT_DONE_SIGNAL "'", interface);

    amxp_timer_stop(unbound->wait_for_child);

    if(unbound->out_of_sync) {
        SAH_TRACEZ_INFO(ME, "Config changed while "UNBOUND_OBJECT_NAME " was starting, restart "UNBOUND_OBJECT_NAME, interface, interface);
        unbound->fail_stop = false;
        stop_unbound(unbound, STOPPED);
        unbound->out_of_sync = false;
        handle_unbound(unbound, __func__);
    } else {
        SAH_TRACEZ_INFO(ME, "Signal '" WAIT_DONE_SIGNAL "' received", interface);
        update_state(unbound, RUNNING, __func__);
        update_forwarding_status();
        ctx = get_unbound_ctx(interface);
        if(ctx == NULL) {
            SAH_TRACEZ_ERROR(ME, "Failed to subscribe on "UNBOUND_OBJECT_NAME, interface);
            trigger_exponential_backoff(unbound, "failed to subscribe.");
            goto exit;
        }
        amxc_string_setf(&object_name, UNBOUND_OBJECT_NAME, interface);
        amxb_subscribe(ctx, amxc_string_get(&object_name, 0), "notification in ['unbound:client-response']", client_response_event, unbound);
        amxp_timer_start(unbound->backoff_timer, THRESHOLD_RESET_BACKOFF); //Timer to reset the normal condition
    }

exit:
    amxc_string_clean(&object_name);
    return;
}

/**
 * @brief Stop a managed Unbound instance and transition to the requested next state.
 *
 * The module may stop Unbound as part of disable handling, configuration reload, or crash recovery.
 * This function performs the practical process shutdown (SIGTERM then SIGKILL fallback) and updates
 * the internal state machine to @p next_state. It also clears runtime subscriptions associated with
 * the running instance.
 *
 * @param[in,out] unbound     Unbound instance to stop.
 * @param[in]     next_state  State to set after issuing the stop action (e.g. STOPPED or WAIT timer).
 *
 * @return @c true when the stop sequence was initiated/handled successfully, @c false on errors.
 */
static bool stop_unbound(unbound_intf_t* unbound, state_t next_state) {
    int rv = -1;
    amxc_string_t object_name;
    const char* interface = NULL;

    amxc_string_init(&object_name, 0);

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    amxc_string_setf(&object_name, UNBOUND_OBJECT_NAME, interface);
    amxb_unsubscribe(get_unbound_ctx(interface), amxc_string_get(&object_name, 0), client_response_event, NULL);

    if(!amxp_subproc_is_running(unbound->process)) {
        SAH_TRACEZ_INFO(ME, UNBOUND_OBJECT_NAME " already stopped", interface);
        rv = 0;
        goto exit;
    }

    amxp_subproc_kill(unbound->process, SIGTERM);
    rv = amxp_subproc_wait(unbound->process, 1000);
    if(rv != 0) {
        SAH_TRACEZ_WARNING(ME, UNBOUND_OBJECT_NAME " won't stop, send SIGKILL", interface);
        amxp_subproc_kill(unbound->process, SIGKILL);
        amxp_subproc_wait(unbound->process, 500);
    } else {
        SAH_TRACEZ_INFO(ME, "Stopping "UNBOUND_OBJECT_NAME, interface);
    }
    if(!unbound->fail_stop) {
        unbound->stopping = true;
    }

    update_state(unbound, next_state, __func__);

exit:
    amxc_string_clean(&object_name);
    return rv == 0;
}

/**
 * @brief Start a managed Unbound instance for the interface using the generated config file.
 *
 * @details
 * This function launches the Unbound subprocess with the per-interface configuration file generated
 * by the module. After spawning, it transitions the instance to STARTING and waits for the Ambiorix
 * bus object/signal that indicates readiness. If startup fails, it delegates to exponential-backoff
 * recovery to avoid rapid restart loops.
 *
 * @param[in,out] unbound Unbound instance to start.
 *
 * @return @c true when the start procedure was successfully initiated, @c false if spawning failed.
 */
static bool start_unbound(unbound_intf_t* unbound) {
    int rv = -1;
    const char* cmd[] = {"unbound", "-c", "", "-i", "", "-d", NULL};
    static uint32_t count = 0;
    amxc_string_t unbound_config_file;
    amxc_string_t object_name;
    const char* interface = NULL;

    amxc_string_init(&unbound_config_file, 0);
    amxc_string_init(&object_name, 0);

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    unbound->stopping = false;
    if(amxp_subproc_is_running(unbound->process)) {
        SAH_TRACEZ_INFO(ME, UNBOUND_OBJECT_NAME " already running", interface);
        rv = 0;
        goto exit;
    }

    amxc_string_setf(&unbound_config_file, DNS_UNBOUND_CONFIG_FILE, interface);
    cmd[2] = amxc_string_get(&unbound_config_file, 0);
    cmd[4] = interface;
    rv = amxp_subproc_vstart(unbound->process, (char**) cmd);
    if(rv != 0) {
        SAH_TRACEZ_ERROR(ME, "Failed to start "UNBOUND_OBJECT_NAME, interface);
        trigger_exponential_backoff(unbound, "failed to start Unbound");
        goto exit;
    }

    count++;
    SAH_TRACEZ_INFO(ME, "Started "UNBOUND_OBJECT_NAME " (%u times)", interface, count);

    update_state(unbound, STARTING, __func__);                // works async

    SAH_TRACEZ_INFO(ME, "Wait for signal '" WAIT_DONE_SIGNAL "'", interface);
    amxp_timer_start(unbound->wait_for_child, WAIT_FOR_CHILD_IN_SEC * 1000);

    amxc_string_setf(&object_name, UNBOUND_OBJECT_NAME, interface);
    amxb_wait_for_object(amxc_string_get(&object_name, 0));

exit:
    amxc_string_clean(&unbound_config_file);
    amxc_string_clean(&object_name);
    return rv == 0;
}

/**
 * @brief Timer callback used to start Unbound after a configurable delay.
 *
 * The module uses a delayed start timer to coalesce bursts of changes (multiple TR-181 updates,
 * repeated restarts, etc.) into a single start operation. This reduces churn and prevents excessive
 * start/stop oscillation.
 *
 * @param[in]     local_timer Timer instance (unused).
 * @param[in,out] priv        User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void delayed_start(UNUSED amxp_timer_t* local_timer, void* priv) {
    unbound_intf_t* unbound = (unbound_intf_t*) priv;

    when_null(unbound, exit);

    start_unbound(unbound);
exit:
    return;
}

/**
 * @brief Main lifecycle state machine handler for a single interface’s Unbound instance.
 *
 * @details
 * This is the high-level orchestrator that translates “desired state” (enabled/disabled plus current
 * configuration) into concrete process actions (start, stop, restart). It is typically invoked after
 * TR-181 configuration changes, interface enable toggles, or internal fault handling.
 *
 * Key intents:
 * - Avoid thrashing: use a start timer to merge many restart triggers into one.
 * - Ensure correctness: if config changes while STARTING, mark out-of-sync and restart once ready.
 * - Keep status consistent: update forwarding status when instances become RUNNING or stop unexpectedly.
 *
 * @param[in,out] unbound Unbound instance to act on.
 * @param[in]     reason  Short label for why the handler was invoked (for troubleshooting).
 */
static void handle_unbound(unbound_intf_t* unbound, const char* reason) {
    SAH_TRACEZ_INFO(ME, UNBOUND_OBJECT_NAME "handle state %s (enable: %d, synced: %d, reason: %s)", amxc_string_get(&unbound->intf, 0), strstate(unbound->state), unbound->enable, !unbound->out_of_sync, reason);

    when_null(unbound, exit);

    if(!unbound->enable) {
        if(unbound->state == WAIT_START_TIMER) {
            amxp_timer_stop(unbound->start_timer);
            update_state(unbound, STOPPED, __func__);
        } else if(unbound->state > STOPPED) {
            unbound->fail_stop = false;
            stop_unbound(unbound, STOPPED);
        }
        goto exit;
    }

    // unbound->start_timer is used to handle burst of events needing restart of Unbound

    switch(unbound->state) {
    case STOPPED:
        amxp_timer_start(unbound->start_timer, unbound->start_timer_in_ms);
        update_state(unbound, WAIT_START_TIMER, __func__);
        unbound->out_of_sync = false;
        break;
    case WAIT_START_TIMER:
        amxp_timer_start(unbound->start_timer, unbound->start_timer_in_ms);
        break;
    case STARTING:
        unbound->out_of_sync = true;
        break;
    case RUNNING:
        unbound->fail_stop = false;
        stop_unbound(unbound, WAIT_START_TIMER);
        amxp_timer_start(unbound->start_timer, unbound->start_timer_in_ms);
    default:
        break;
    }

exit:
    return;
}

/**
 * @brief Update the module-wide Unbound outbound retry parameters in the in-memory configuration.
 *
 * @details
 * TR-181 may update resolver behaviour (e.g. after a DHCP renew) by changing the timeout and/or retry count
 * that Unbound uses for outbound queries. This function applies those changes to the module's global state
 * (see @c g.timeout and @c g.repeat), which in turn influences the generated Unbound configuration files.
 *
 * This function intentionally does **not** talk to the Unbound backend. Runtime updates (via
 * @c UnboundControl / @c unbound-control) and restarts are handled by the caller (e.g. @ref set_server).
 *
 * @param[in] timeout New timeout value. Use @c INT32_MIN to keep the current value. A value of -1 means
 *                    "use Unbound defaults" in this module.
 * @param[in] repeat  New retry value. Use @c INT32_MIN to keep the current value. A value of -1 means
 *                    "use Unbound defaults" in this module.
 * @param[in] changed Set to @c true when the caller detected an actual change; if @c false this function
 *                    is a no-op.
 */
static void apply_server_cfg(int32_t timeout, int32_t repeat, bool changed) {
    when_false(changed, exit);

    if(timeout != INT32_MIN) {
        g.timeout = timeout;
    }
    if(repeat != INT32_MIN) {
        g.repeat = repeat;
    }

exit:
    return;
}

/**
 * @brief Synchronize the in-memory forward-zone server list with the requested configuration.
 *
 * @details
 * The TR-181 DNS layer expresses upstream resolvers as per-zone forwarders. The module keeps an in-memory
 * representation of these forward zones in @c g.config (key @c "fwzones"), which is later used to render
 * Unbound configuration files and to decide what to push live to the backend.
 *
 * Depending on the inputs this helper will:
 * - create the forward-zone entry when it does not exist yet and @p new_servers is provided;
 * - overwrite the existing server list with @p new_servers;
 * - remove the forward-zone when @p new_servers is @c NULL.
 *
 * The root zone (@c ".") is treated specially: when cleared, the container is kept and only emptied so
 * the default zone remains present in the configuration data model.
 *
 * @param[in] name        Forward-zone name (e.g. @c "." for the default zone).
 * @param[in,out] servers Existing forward-zone entry in @c g.config (may be @c NULL).
 * @param[in] new_servers Desired server list (htable of entries containing at least a @c "server" string).
 *                        Pass @c NULL to remove/clear the zone.
 * @param[in] changed     Set to @c true when the caller detected an actual change; if @c false this function
 *                        is a no-op.
 */
static void apply_forward_servers_cfg(const char* name, amxc_var_t* servers, amxc_var_t* new_servers, bool changed) {
    amxc_var_t* fwzones = GET_ARG(&g.config, "fwzones");

    when_false(changed, exit);

    if(servers == NULL) {
        when_null(new_servers, exit);
        if((fwzones != NULL) && !string_empty(name)) {
            servers = amxc_var_add_key(amxc_htable_t, fwzones, name, NULL);
            amxc_var_copy(servers, new_servers);
        }
    } else {
        if(new_servers == NULL) {
            const char* zone_name = NULL;
            zone_name = amxc_var_key(servers);
            if((zone_name != NULL) && (strcmp(zone_name, ".") == 0)) {
                amxc_var_set_type(servers, AMXC_VAR_ID_HTABLE); // clean
            } else {
                amxc_var_delete(&servers);
            }
        } else {
            amxc_var_copy(servers, new_servers);
        }

    }

exit:
    return;
}

/**
 * @brief Apply the default forwarder list and resolver retry parameters (timeout/repeat).
 *
 * @details
 * This AMXM entry point is called by the TR-181 DNS plugin to update the upstream resolver configuration
 * for the default forward zone (@c "."). Typical triggers are WAN/DHCP changes or management actions that
 * replace the list of DNS servers and optionally adjust resolver retry behaviour.
 *
 * The function performs two steps:
 * 1. Update the module's configuration state (used for file generation) by storing the new timeout/repeat
 *    values and synchronizing @c g.config.fwzones["."] with the provided server list.
 * 2. For each Unbound instance (per interface):
 *    - regenerate the on-disk configuration file;
 *    - if the instance is running, push changes live using the UnboundControl RPC (wrapping
 *      @c unbound-control, via @ref cmd_set_server_parameters and @ref cmd_forward_set);
 *    - if a live update fails, or if the instance is enabled but not running, trigger a restart/resync
 *      through the internal state machine (@ref handle_unbound).
 *
 * The call is idempotent: if none of the relevant inputs changed, nothing is applied.
 *
 * Expected arguments in @p args:
 * - @c "timeout" (int32, optional): outbound timeout. A value of 0 is interpreted as "use Unbound defaults".
 * - @c "repeat"  (int32, optional): outbound retry count.
 * - @c "servers" (htable, optional): map of unique IDs to objects containing at least @c "server".
 *   If present, the current list is replaced:
 *   - non-empty: set forwarders to exactly this list;
 *   - empty: remove all forwarders;
 *   - missing: keep current forwarders.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          New server/timeout/repeat settings as described above.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 on success, -1 when applying the configuration failed for at least one Unbound instance.
 */
static int set_server(UNUSED const char* function_name,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    unbound_status_t status = unbound_other_error;
    amxc_var_t* servers = NULL;
    amxc_var_t* new_servers = NULL;
    const char* zone_name = ".";
    int32_t new_timeout = INT32_MIN;
    int32_t new_repeat = INT32_MIN;
    int rv = -1;
    bool servers_changed = false;
    bool tr_changed = false;

    servers = GET_ARG(GET_ARG(&g.config, "fwzones"), zone_name);
    when_null(servers, exit);

    new_servers = GET_ARG(args, "servers");
    if(new_servers != NULL) {
        SAH_TRACEZ_INFO(ME, "servers changed");
        servers_changed = true;
    }

    if(GET_ARG(args, "timeout") != NULL) {
        new_timeout = GET_INT32(args, "timeout");
        if(new_timeout == 0) {
            new_timeout = -1; // use Unbound's default value
        }
        if(g.timeout != new_timeout) {
            SAH_TRACEZ_INFO(ME, "timeout changed %d -> %d", g.timeout, new_timeout);
            tr_changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "timeout didn't change");
        }
    }

    if(GET_ARG(args, "repeat") != NULL) {
        new_repeat = GET_INT32(args, "repeat");
        if(g.repeat != new_repeat) {
            SAH_TRACEZ_INFO(ME, "repeat changed %d -> %d", g.repeat, new_repeat);
            tr_changed = true;
        } else {
            SAH_TRACEZ_INFO(ME, "repeat didn't change");
        }
    }

    when_false(tr_changed || servers_changed, exit);


    apply_server_cfg(new_timeout, new_repeat, tr_changed);
    apply_forward_servers_cfg(zone_name, servers, new_servers, servers_changed);

    rv = 0;

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        const char* interface = amxc_string_get(&unbound->intf, 0);
        create_config_file(unbound);
        if(unbound->state == RUNNING) {
            if(tr_changed) {
                status = cmd_set_server_parameters(interface, new_timeout, new_repeat, zone_name);
                if(status != unbound_ok) { //Critical error restart this unbound instance
                    handle_unbound(unbound, __func__);
                    rv = -1;
                    continue;
                }
            }

            if(servers_changed) {
                status = cmd_forward_set(interface, new_servers, zone_name);
                if(status != unbound_ok) { //Critical error restart this unbound instance
                    handle_unbound(unbound, __func__);
                    rv = -1;
                    continue;
                }
            }

        } else {
            if(unbound->enable) {
                handle_unbound(unbound, __func__);
            }
        }
    }

exit:
    amxc_var_delete(&new_servers);
    return rv;
}

/**
 * @brief Persist and apply a forward-zone server list change to all Unbound instances.
 *
 * @details
 * This helper is the common apply-path for incremental updates (see @ref add_server and @ref remove_server).
 * It updates the in-memory configuration for a given forward zone, regenerates the Unbound configuration
 * files for every interface, and—when an instance is running—pushes the updated forwarder list live using
 * UnboundControl (via @ref cmd_forward_set). If a running instance cannot be updated, it is restarted/
 * resynchronized via @ref handle_unbound so it comes back in sync with the generated file.
 *
 * @param[in,out] servers Current forward-zone entry in @c g.config for @p zone_name (may be @c NULL).
 * @param[in] new_servers Updated server list for the zone. When @c NULL, the forward-zone is removed
 *                        (or cleared for the root zone) and the backend is instructed to drop forwarding.
 * @param[in] zone_name   Forward-zone name (e.g. @c "." for the default zone).
 *
 * @return 0 on success, -1 when applying the change failed for at least one Unbound instance.
 */
static int apply_server_changes(amxc_var_t* servers, amxc_var_t* new_servers, const char* zone_name) {
    unbound_status_t status = unbound_other_error;
    int rv = -1;

    apply_forward_servers_cfg(zone_name, servers, new_servers, true);

    rv = 0;

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        const char* interface = amxc_string_get(&unbound->intf, 0);
        create_config_file(unbound);
        if(unbound->state == RUNNING) {
            status = cmd_forward_set(interface, new_servers, zone_name);
            if(status != unbound_ok) { //Critical error restart this unbound instance
                handle_unbound(unbound, __func__);
                rv = -1;
                continue;
            }
        } else {
            if(unbound->enable) {
                handle_unbound(unbound, __func__);
            }
        }
    }

    return rv;
}

/**
 * @brief Add a single forwarder entry to a forward zone and apply it to Unbound.
 *
 * @details
 * This AMXM entry point supports incremental server management from the TR-181 layer. It takes one server
 * description and adds it under a unique key to the requested forward zone (default: @c "."). The module
 * then persists the change (configuration file regeneration) and applies it live to all running Unbound
 * instances using UnboundControl.
 *
 * The function does not overwrite existing entries: if the provided @c "name" key already exists in the
 * zone, the call fails.
 *
 * Expected arguments in @p args:
 * - @c "name" (string, mandatory): unique identifier within the forward-zone table.
 * - @c "zone_name" (string, optional): zone to update. When missing, @c "." is used.
 * - additional fields describing the server; at minimum a @c "server" string is expected.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Server definition and zone selector as described above.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 on success, -1 on failure (e.g. missing name, duplicate key, or backend apply failure).
 */
static int add_server(UNUSED const char* function_name,
                      amxc_var_t* args,
                      UNUSED amxc_var_t* ret) {
    amxc_var_t* servers = NULL;
    amxc_var_t* new_servers = NULL;
    amxc_var_t* subvar = NULL;
    const char* key = GET_CHAR(args, "name");
    const char* zone_name = GET_CHAR(args, "zone_name") == NULL ? "." : GET_CHAR(args, "zone_name");
    amxc_var_t* fwzones = GET_ARG(&g.config, "fwzones");
    int rv = -1;

    amxc_var_new(&new_servers);

    servers = GET_ARG(fwzones, zone_name);
    if(servers == NULL) {
        amxc_var_set_type(new_servers, AMXC_VAR_ID_HTABLE);
    } else {
        amxc_var_copy(new_servers, servers);
    }

    when_null(new_servers, exit);
    when_str_empty_trace(key, exit, ERROR, "Can't add server without name");
    when_false_trace(GET_ARG(new_servers, key) == NULL, exit, ERROR, "Server %s already in use", key);

    subvar = amxc_var_add_key(amxc_htable_t, new_servers, key, NULL);
    amxc_var_move(subvar, args);

    SAH_TRACEZ_INFO(ME, "Server '%s' added", GET_CHAR(subvar, "server"));

    rv = apply_server_changes(servers, new_servers, zone_name);

exit:
    amxc_var_delete(&new_servers);
    return rv;
}

/**
 * @brief Remove a forwarder entry from a forward zone and apply it to Unbound.
 *
 * @details
 * This AMXM entry point supports incremental server management from the TR-181 layer. It removes the
 * server entry identified by @c "name" from the requested forward zone (default: @c "."). After updating
 * the in-memory representation, the module regenerates configuration files and applies the new forwarder
 * list live to all running Unbound instances using UnboundControl.
 *
 * If the last server of a non-root zone is removed, the forward-zone itself is deleted from the module
 * configuration (and will no longer be emitted in generated Unbound configuration files). For the root
 * zone (@c "."), the zone is kept but its server list is cleared.
 *
 * Expected arguments in @p args:
 * - @c "name" (string, mandatory): key of the server entry to remove.
 * - @c "zone_name" (string, optional): zone to update. When missing, @c "." is used.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Removal request as described above.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 on success, -1 on failure (e.g. no such zone/entry or backend apply failure).
 */
static int remove_server(UNUSED const char* function_name,
                         amxc_var_t* args,
                         UNUSED amxc_var_t* ret) {
    amxc_var_t* servers = NULL;
    amxc_var_t* new_servers = NULL;
    amxc_var_t* subvar = NULL;
    const char* key = GET_CHAR(args, "name");
    const char* zone_name = GET_CHAR(args, "zone_name") == NULL ? "." : GET_CHAR(args, "zone_name");
    amxc_var_t* fwzones = GET_ARG(&g.config, "fwzones");
    int rv = -1;

    amxc_var_new(&new_servers);

    servers = GET_ARG(fwzones, zone_name);
    when_null(servers, exit);
    amxc_var_copy(new_servers, servers);

    when_str_empty_trace(key, exit, ERROR, "Can't remove server without name");
    subvar = GET_ARG(new_servers, key);
    when_null_trace(subvar, exit, INFO, "No server '%s' to remove", key);

    amxc_var_delete(&subvar);

    if(amxc_var_get_first(new_servers) == NULL) {
        amxc_var_delete(&new_servers);
        new_servers = NULL;
    }

    rv = apply_server_changes(servers, new_servers, zone_name);
exit:
    amxc_var_delete(&new_servers);
    return rv;
}

/**
 * @brief Propagate the module-wide enable flag to all per-interface Unbound instances.
 *
 * @details
 * The TR-181 DNS layer can enable/disable the resolver service globally. This entry point translates
 * that high-level toggle into the effective enable state of each interface-specific Unbound instance.
 *
 * The effective enable for an instance is derived as:
 * - global enable (@c g.enable) AND
 * - interface operational state (@c unbound->is_intf_up)
 *
 * For each known interface instance, this function updates @c unbound->enable when needed and invokes
 * the lifecycle state machine (@ref handle_unbound) so the backend process is started/stopped/restarted
 * accordingly. This keeps runtime state in sync without directly issuing UnboundControl commands here
 * (those are orchestrated by the state machine as required).
 *
 * The call is idempotent: when the global enable value does not change, no action is taken.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Boolean value (passed as the root argument) indicating the desired global enable state.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 (the change is best-effort per interface; lifecycle errors are handled internally by the state machine).
 */
static int enable_changed(UNUSED const char* function_name,
                          amxc_var_t* args,
                          UNUSED amxc_var_t* ret) {
    bool enable = GET_BOOL(args, NULL);

    when_true(g.enable == enable, exit);

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        const char* interface = amxc_string_get(&unbound->intf, 0);
        bool unbound_enable = enable && unbound->is_intf_up;

        if(unbound->enable == unbound_enable) {
            continue;
        }

        unbound->enable = unbound_enable;

        SAH_TRACEZ_INFO(ME, "Enable changed in interface '%s' to %s (state=%s(%d))", interface, unbound->enable ? "true" : "false", strstate(unbound->state), unbound->state);

        handle_unbound(unbound, __func__);
    }

    g.enable = enable;

exit:
    return 0;
}


/**
 * @brief Update DNS redirection configuration and reload affected Unbound instances.
 *
 * @details
 * Some TR-181 deployments require redirecting all DNS queries to a specific address (typically for
 * captive-portal / walled-garden scenarios). This module implements that by maintaining a dedicated
 * include file (@c DNS_UNBOUND_REDIRECT_FILE) that is referenced from the generated Unbound
 * configuration.
 *
 * This entry point rewrites the redirect include file based on the requested state:
 * - when enabled, it emits a root-zone redirect and an A record pointing to @c IpAddr;
 * - when disabled, the file is left empty (effectively removing the redirect behaviour).
 *
 * After updating the include file, the function regenerates each interface configuration file
 * (@ref create_config_file) and triggers the lifecycle handler (@ref handle_unbound) for instances
 * that are currently enabled, ensuring the running Unbound processes pick up the change.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Variant containing:
 *                          - @c "Enabled" (bool): enable/disable redirect behaviour.
 *                          - @c "IpAddr"  (string): target IPv4 address for the redirect. An empty string is ignored.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0. Errors are logged; the configuration update is applied best-effort across interfaces.
 */
static int redirect_changed(UNUSED const char* function_name, amxc_var_t* args, UNUSED amxc_var_t* ret) {
    FILE* redirect_file = NULL;
    bool enable = false;
    const char* ip_addr = NULL;

    when_null_trace(args, exit, ERROR, "args is null");
    enable = GET_BOOL(args, "Enabled");
    ip_addr = GET_CHAR(args, "IpAddr");
    when_null_trace(ip_addr, exit, ERROR, "ip_addr is null");
    if(ip_addr[0] == '\0') {
        SAH_TRACEZ_INFO(ME, "ip_addr is an empty string");
        goto exit;
    }

    redirect_file = fopen(DNS_UNBOUND_REDIRECT_FILE, "w");
    when_null_trace(redirect_file, exit, ERROR, "Could not open file " DNS_UNBOUND_REDIRECT_FILE " for writing");
    if(enable) {
        fprintf(redirect_file, "local-zone: \".\" redirect\n");
        fprintf(redirect_file, "local-data: \". IN A %s\"\n", ip_addr);
    }
    fclose(redirect_file);
    redirect_file = NULL;

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        create_config_file(unbound);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

exit:
    return 0;
}

/**
 * @brief Apply DNS rebind protection settings and restart/resync Unbound instances as needed.
 *
 * @details
 * DNS rebind protection mitigates attacks where public names resolve to private/routed addresses.
 * The TR-181 layer can toggle this protection and provide exception lists (domains and IPs) that
 * should bypass the restriction (e.g. for legitimate internal services).
 *
 * This entry point updates the module’s in-memory rebind configuration (@c g.rebind) by:
 * - storing the enable flag;
 * - converting the provided exception containers into internal list variants.
 *
 * Once updated, it regenerates each interface configuration file and triggers the lifecycle handler
 * for enabled instances so the running Unbound process reflects the new security policy. Any live
 * updates required to converge runtime state are handled by the lifecycle/state machine and, when
 * applicable, executed through the UnboundControl RPC wrapper.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Variant containing:
 *                          - @c "Enable" (bool): enable/disable rebind protection.
 *                          - @c "DomainExceptions" (variant): list-like container of domain exceptions.
 *                          - @c "IPExceptions"     (variant): list-like container of IP exceptions.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 on success, -1 when the exception lists could not be converted/stored.
 */
static int rebind_protection_changed(UNUSED const char* function_name,
                                     amxc_var_t* args,
                                     UNUSED amxc_var_t* ret) {
    int rv = -1;
    g.rebind.enable = GET_BOOL(args, "Enable");
    SAH_TRACEZ_INFO(ME, "Rebind protection changed (%sabled|%s|%s)",
                    g.rebind.enable ? "en" : "dis",
                    GET_CHAR(args, "DomainExceptions"),
                    GET_CHAR(args, "IPExceptions"));

    rv = amxc_var_convert(&g.rebind.domains, GET_ARG(args, "DomainExceptions"), AMXC_VAR_ID_LIST);
    when_failed_trace(rv, exit, ERROR, "Failed to convert(%d) %s", rv, "DomainExceptions");
    rv = amxc_var_convert(&g.rebind.ips, GET_ARG(args, "IPExceptions"), AMXC_VAR_ID_LIST);
    when_failed_trace(rv, exit, ERROR, "Failed to convert(%d) %s", rv, "IPExceptions");

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        create_config_file(unbound);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

exit:
    return rv;
}

/**
 * @brief Check whether the new cache entry is different than the existing one.
 *
 * @param[in] cache Previous cache configuration entry.
 * @param[in] new_cache New cache configuration entry.
 *
 * @return @c true when the cache configuration is different
 *         @c false when the cache configuration is the same
 */
static bool is_cache_changed(amxc_var_t* cache, amxc_var_t* new_cache) {
    uint32_t old_cache_size = GET_UINT32(cache, "cache_size");
    uint32_t old_ttl_max = GET_UINT32(cache, "ttl_max");
    uint32_t old_ttl_min = GET_UINT32(cache, "ttl_min");
    uint32_t new_cache_size = GET_UINT32(new_cache, "cache_size");
    uint32_t new_ttl_max = GET_UINT32(new_cache, "ttl_max");
    uint32_t new_ttl_min = GET_UINT32(new_cache, "ttl_min");
    if((old_cache_size != new_cache_size) ||
       (old_ttl_max != new_ttl_max) ||
       (old_ttl_min != new_ttl_min)) {
        return true;
    }
    return false;
}

/**
 * @brief Add cache variant to the unbound configuration.
 *
 * @param[in] cache Previous cache configuration entry.
 * @param[in] new_cache New cache configuration entry.
 *
 * @return @c true when the cache configuration changed
 *         @c false when the cache configuration did not change
 */
static bool add_cache_to_unbound(unbound_intf_t* unbound, amxc_var_t* new_cache) {
    amxc_var_t* cache = NULL;
    bool added_cache = false;

    cache = GET_ARG(&unbound->config, "cache");
    if((cache == NULL) && (new_cache != NULL)) {
        cache = amxc_var_add_new_key(&unbound->config, "cache");
        when_null(cache, exit);
    }
    if(new_cache != NULL) {
        if(is_cache_changed(cache, new_cache)) {
            amxc_var_move(cache, new_cache);
            added_cache = true;
        }
    }
exit:
    return added_cache;
}

/**
 * @brief Set cache tuning parameters for one interface, or for all managed interfaces.
 *
 * @details
 * This AMXM entry point is called by the TR-181 DNS plugin when cache policy should be updated
 * (for example due to a new memory budget or management configuration change).
 *
 * The function selects the target instance by @c interface:
 * - if the interface matches a known Unbound instance, only that instance is updated;
 * - otherwise, the request is applied best-effort to all managed instances.
 *
 * The actual per-instance update is performed by @ref _set_cache, which regenerates the Unbound config
 * and triggers lifecycle handling (restart/resync) as needed.
 *
 * Expected arguments in @p args:
 * - @c "interface" (string, optional): interface/view identifier.
 * - @c "cache"     (variant, mandatory): cache configuration subtree (see @ref _set_cache).
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Cache update request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 (best-effort; errors are handled and logged per instance by the helper/lifecycle path).
 */
static int set_cache(UNUSED const char* function_name,
                     amxc_var_t* args,
                     UNUSED amxc_var_t* ret) {
    unbound_intf_t* unbound = NULL;
    amxc_var_t* new_cache = NULL;
    amxc_var_t* new_cache_size = GET_ARG(args, "cache_size");
    amxc_var_t* new_ttl_max = GET_ARG(args, "ttl_max");
    amxc_var_t* new_ttl_min = GET_ARG(args, "ttl_min");
    const char* interface = GET_CHAR(args, "interface");

    amxc_var_new(&new_cache);

    if((new_cache_size != NULL) &&
       (new_ttl_max != NULL) &&
       (new_ttl_min != NULL)) {
        amxc_var_set_type(new_cache, AMXC_VAR_ID_HTABLE);
        amxc_var_add_key(uint32_t, new_cache, "cache_size", GET_UINT32(new_cache_size, NULL));
        amxc_var_add_key(uint32_t, new_cache, "ttl_max", GET_UINT32(new_ttl_max, NULL));
        amxc_var_add_key(uint32_t, new_cache, "ttl_min", GET_UINT32(new_ttl_min, NULL));
    } else {
        goto exit;
    }

    unbound = get_unbound_intf(interface);
    if(unbound == NULL) {
        when_not_null(interface, exit);
        amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
            unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
            if(!add_cache_to_unbound(unbound, new_cache)) {
                continue;
            }
            create_config_file(unbound);
            if(unbound->enable) {
                handle_unbound(unbound, __func__);
            }
        }
    } else {
        when_false(add_cache_to_unbound(unbound, new_cache), exit);
        create_config_file(unbound);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

exit:
    amxc_var_delete(&new_cache);
    return 0;
}

/**
 * @brief Create or update the Unbound instance bound to a specific interface.
 *
 * @details
 * The module runs (or manages) Unbound instances per interface. The TR-181 DNS integration invokes
 * this entry point when an interface becomes relevant (added) or when its operational state changes
 * (up/down). The goal is to keep the set of managed instances aligned with the networking reality
 * and the TR-181 “desired state”.
 *
 * Key responsibilities:
 * - Ensure an instance exists for @c interface (create one if needed).
 * - Track interface operational state (@c interface_down) via @c unbound->is_intf_up.
 * - Derive the effective enable state as @c (g.enable && unbound->is_intf_up) and, when it changes,
 *   update @c unbound->enable.
 * - Keep per-interface “view” configuration consistent by transferring the view subtree between the
 *   global staging container (@c g.config["views"]) and the instance container (@c unbound->config["views"])
 *   when an instance is created.
 * - Optionally attach/update per-interface cache tuning settings (argument @c "cache") in the instance
 *   configuration.
 *
 * When a state transition requires action, the function regenerates the Unbound configuration file
 * (@ref create_config_file) and calls the lifecycle handler (@ref handle_unbound) which performs the
 * necessary start/stop/restart operations and any corresponding UnboundControl interactions.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Variant containing:
 *                          - @c "interface"       (string, mandatory): interface identifier.
 *                          - @c "interface_down"  (bool): whether the interface is currently down.
 *                          - @c "cache"           (variant, optional): per-interface cache configuration subtree.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0.
 */
static int set_interface(UNUSED const char* function_name,
                         amxc_var_t* args,
                         UNUSED amxc_var_t* ret) {
    unbound_intf_t* unbound = NULL;
    amxc_var_t* new_cache = GET_ARG(args, "cache");
    const char* interface = GET_CHAR(args, "interface");
    bool interface_down = GET_BOOL(args, "interface_down");
    amxc_var_t* views_unbound = NULL;
    amxc_var_t* view_unbound = NULL;
    amxc_var_t* views_global = GET_ARG(&g.config, "views");
    amxc_var_t* view_global = NULL;
    bool new_enable = true;

    when_str_empty(interface, exit);

    unbound = get_unbound_intf(interface);
    if(unbound == NULL) {
        unbound = add_unbound_intf(interface, false);
        when_null(unbound, exit);

        views_unbound = GET_ARG(&unbound->config, "views");
        view_unbound = GET_ARG(views_unbound, interface);
        view_global = GET_ARG(views_global, interface);
        if((view_unbound == NULL) && (view_global != NULL)) {
            view_unbound = amxc_var_add_key(amxc_htable_t, views_unbound, interface, NULL);
        }
        if((view_unbound != NULL) && (view_global == NULL)) {
            amxc_var_delete(&view_unbound);
        }
        if((view_unbound != NULL) && (view_global != NULL)) {
            amxc_var_move(view_unbound, view_global);
        }

        add_cache_to_unbound(unbound, new_cache);

        when_true(interface_down, exit);
    } else {
        if(unbound->is_intf_up == !interface_down) {
            if(add_cache_to_unbound(unbound, new_cache)) { //Check if the cache has changed
                SAH_TRACEZ_INFO(ME, "Interface %s already known, but cache has changed", interface);
                create_config_file(unbound);
                if(unbound->enable) {
                    handle_unbound(unbound, __func__);
                }
            } else {
                SAH_TRACEZ_INFO(ME, "Interface %s already known", interface);
            }
            goto exit;
        }
    }

    unbound->is_intf_up = !interface_down;
    new_enable = g.enable && unbound->is_intf_up;

    when_true(unbound->enable == new_enable, exit);

    unbound->enable = g.enable && unbound->is_intf_up;

    create_config_file(unbound);
    handle_unbound(unbound, __func__);

exit:
    return 0;
}

/**
 * @brief Remove the Unbound instance associated with an interface while preserving its view configuration.
 *
 * @details
 * When the TR-181 layer indicates an interface is no longer managed by the DNS service, this entry point
 * deletes the corresponding per-interface Unbound instance and its resources.
 *
 * Before deletion, the function reconciles the interface’s “view” configuration between the instance
 * and the global staging container:
 * - if the instance holds a view subtree, it is moved back into @c g.config["views"] so configuration
 *   is not lost when the instance disappears;
 * - if the global container contains stale view state for an interface that no longer has one, that
 *   subtree is removed.
 *
 * After the view state is preserved, the instance is destroyed (@c unbound_intf_delete()).
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Variant containing:
 *                          - @c "interface" (string, mandatory): interface identifier to remove.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0 on success, -1 when the interface is unknown (nothing to remove).
 */
static int remove_interface(UNUSED const char* function_name,
                            amxc_var_t* args,
                            UNUSED amxc_var_t* ret) {
    unbound_intf_t* unbound = NULL;
    const char* interface = GET_CHAR(args, "interface");
    amxc_var_t* views_unbound = NULL;
    amxc_var_t* view_unbound = NULL;
    amxc_var_t* views_global = GET_ARG(&g.config, "views");
    amxc_var_t* view_global = NULL;
    int rv = -1;

    unbound = get_unbound_intf(interface);
    when_null_trace(unbound, exit, INFO, "Interface '%s' unknown", interface);

    views_unbound = GET_ARG(&unbound->config, "views");
    view_unbound = GET_ARG(views_unbound, interface);
    view_global = GET_ARG(views_global, interface);
    if((view_global == NULL) && (view_unbound != NULL)) {
        view_global = amxc_var_add_key(amxc_htable_t, views_global, interface, NULL);
    }
    if((view_global != NULL) && (view_unbound == NULL)) {
        amxc_var_delete(&view_global);
    }
    if((view_global != NULL) && (view_unbound != NULL)) {
        amxc_var_move(view_global, view_unbound);
    }

    SAH_TRACEZ_INFO(ME, "Remove interface '%s'", interface);
    unbound_intf_delete(&unbound);

    rv = 0;
exit:
    return rv;
}

/**
 * @brief Persist a host-entry change into the per-view configuration and refresh the instance config file.
 *
 * @details
 * TR-181 host objects (typically coming from the DNS plugin / DNS.Zone) are represented in this module as
 * a per-view table: @c views[<interface>].hosts[<hostname>]. That table is the source used to (re)generate
 * the Unbound configuration file for the corresponding interface instance.
 *
 * This internal helper updates that configuration table for a single host entry and immediately triggers
 * regeneration of the on-disk Unbound configuration for @p unbound via @ref create_config_file.
 *
 * It is intentionally **persistence-only**: it does not call UnboundControl/unbound-control. Callers that
 * need an immediate runtime update use @ref cmd_add_host / @ref cmd_remove_host first, and then call this
 * helper to keep the generated file in sync. It is also used as part of failover paths where the module
 * falls back to restarting/resynchronizing the instance.
 *
 * Behaviour:
 * - If @p host is @c NULL and @p new_host is non-NULL, a new entry @c hosts[hostname] is created and filled.
 * - If @p host is non-NULL and @p new_host is non-NULL, the existing entry is overwritten.
 * - If @p host is non-NULL and @p new_host is @c NULL, the entry is removed.
 *
 * @param[in]     unbound   Target Unbound instance (per interface/view).
 * @param[in,out] hosts    Host table container (typically @c views[view].hosts).
 * @param[in]     hostname Host key within @p hosts.
 * @param[in,out] host     Existing host entry for @p hostname (may be @c NULL).
 * @param[in]     new_host New host entry to store. Pass @c NULL to delete the host entry.
 */
static void apply_host_cfg(unbound_intf_t* unbound, amxc_var_t* hosts, const char* hostname, amxc_var_t* host, amxc_var_t* new_host) {
    if(host == NULL) {
        when_null(new_host, exit);
        if((hosts != NULL) && !string_empty(hostname)) {
            host = amxc_var_add_key(amxc_htable_t, hosts, hostname, NULL);
            amxc_var_copy(host, new_host);
        }
    } else {
        if(new_host == NULL) {
            amxc_var_delete(&host);
        } else {
            amxc_var_copy(host, new_host);
        }
    }
    create_config_file(unbound);

exit:
    return;
}

/**
 * @brief Add one or more addresses to a host and apply the change to Unbound.
 *
 * @details
 * This AMXM entry point implements the TR-181 “add host address” semantics for local DNS names:
 * if the host already exists for the given interface/view, the hostname will resolve to the **old + new**
 * addresses (i.e. an additive update). Typical use-cases are incremental lease updates where additional
 * addresses become known over time.
 *
 * The function updates two planes:
 * - **Runtime plane (best-effort, for running instances):** when the interface’s Unbound instance is in
 *   @c RUNNING state, it injects the new local-data (and PTRs where applicable) through the UnboundControl
 *   RPC by calling @ref cmd_add_host.
 * - **Persistence plane:** it updates the in-memory configuration under
 *   @c views[interface].hosts[hostname] and regenerates the instance configuration file via
 *   @ref apply_host_cfg / @ref create_config_file.
 *
 * Domain handling:
 * - A host may have an individual @c local_domain; when absent, the view’s @c domain_name is used.
 * - Base hostnames may be duplicated as FQDNs by the command layer (see @ref cmd_add_host).
 *
 * Failover behaviour:
 * - When @c no_failover is false and the UnboundControl update fails with a “critical” status, the module
 *   forces a restart/resync of the instance via @ref handle_unbound to guarantee convergence.
 *
 * Expected arguments in @p args:
 * - @c "interface" (string, mandatory): interface/view identifier.
 * - @c "name"      (string, mandatory): hostname key.
 * - @c "ipv4_addresses" (list, optional): IPv4 address strings to add.
 * - @c "ipv6_addresses" (list, optional): IPv6 address strings to add.
 * - @c "local_domain"   (string, optional): per-host domain override.
 * - @c "no_failover"    (bool, optional): when true, do not force restart on runtime apply errors.
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Host update request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 on success, -1 when the request is invalid (e.g. no addresses added) or when applying the
 *         change failed and could not be handled without error.
 */
static int add_host(UNUSED const char* function_name,
                    amxc_var_t* args,
                    UNUSED amxc_var_t* ret) {
    unbound_status_t status = unbound_other_error;
    unbound_intf_t* unbound = NULL;
    amxc_var_t* views = GET_ARG(&g.config, "views");
    amxc_var_t* view_var = NULL;
    amxc_var_t* host = NULL;
    amxc_var_t* new_host = NULL;
    amxc_var_t* hosts = NULL;
    const char* view = GET_CHAR(args, "interface");
    const char* hostname = GET_CHAR(args, "name");
    const char* domain = GET_CHAR(args, "local_domain"); //individual domain for a specific host
    bool no_failover = GET_BOOL(args, "no_failover");
    int count = 0;
    int rv = -1;
    bool check_critical = false;

    amxc_var_new(&new_host);

    when_str_empty(hostname, exit);
    when_str_empty(view, exit);

    unbound = get_unbound_intf(view);
    if(unbound != NULL) {
        views = GET_ARG(&unbound->config, "views");
    }

    when_null_trace(views, exit, ERROR, "Something bad happened");

    view_var = GET_ARG(views, view);
    if(view_var == NULL) {
        view_var = amxc_var_add_key(amxc_htable_t, views, view, NULL);
        when_null_trace(amxc_var_add_key(amxc_htable_t, view_var, "hosts", NULL), exit, ERROR, "Failed to add key");
    }
    when_null_trace(view_var, exit, ERROR, "Failed to add view %s for host '%s'", view, hostname);
    hosts = GET_ARG(view_var, "hosts");
    when_null_trace(hosts, exit, ERROR, "Something bad happened");

    host = GET_ARG(hosts, hostname);
    if(host == NULL) {
        SAH_TRACEZ_INFO(ME, "Add new host '%s'", hostname);
        amxc_var_set_type(new_host, AMXC_VAR_ID_HTABLE);
        for(int i = 0; ipaddr_types[i] != NULL; i++) {
            amxc_var_add_key(amxc_llist_t, new_host, ipaddr_types[i], NULL);
        }
    } else {
        amxc_var_copy(new_host, host);
    }

    for(int i = 0; ipaddr_types[i] != NULL; i++) {
        amxc_var_t* ip_list = GET_ARG(new_host, ipaddr_types[i]);
        amxc_var_for_each(var, GET_ARG(args, ipaddr_types[i])) {
            const char* ip_address = GET_CHAR(var, NULL);
            SAH_TRACEZ_INFO(ME, "Add new address '%s' to %s", ip_address, ipaddr_types[i]);
            amxc_var_add(cstring_t, ip_list, ip_address);
            count++;
        }
    }

    when_false_trace(count > 0, exit, ERROR, "Nothing added");

    if(string_empty(domain)) {
        domain = GET_CHAR(view_var, "domain_name");
    } else {
        amxc_var_add_key(cstring_t, new_host, "local_domain", domain);
    }

    if(unbound == NULL) {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        rv = 0;
        goto exit;
    }

    if(unbound->state == RUNNING) {
        if(!no_failover) {
            check_critical = true;
        }

        status = cmd_add_host(view, hostname, domain,
                              GET_ARG(new_host, "ipv4_addresses"), GET_ARG(new_host, "ipv6_addresses"), false);
        when_failed(status, exit);
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
    } else {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

    rv = 0;
exit:
    if(check_critical && (status != unbound_ok) && (status < unbound_other_error)) {
        SAH_TRACEZ_ERROR(ME, "Critical Error: Unbound will restart.");
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        handle_unbound(unbound, __func__);
    }
    amxc_var_delete(&new_host);
    return rv;
}

/**
 * @brief Set (replace) the address list for a host and apply the change to Unbound.
 *
 * @details
 * This AMXM entry point implements the TR-181 “set host address” semantics for local DNS names:
 * if the host already exists, the hostname will resolve to **only** the newly provided address list
 * (i.e. a replacing update). This is typically used when the authoritative address set is known and
 * must overwrite previous state.
 *
 * For a running Unbound instance, the module must emulate a “replace” because UnboundControl does not
 * provide a single atomic “remove some addresses” operation for a local-data record. Therefore, when the
 * instance is @c RUNNING it performs:
 * 1) remove old host records (and associated PTRs) via @ref cmd_remove_host (UnboundControl),
 * 2) add the new records via @ref cmd_add_host (UnboundControl).
 *
 * Independently of runtime updates, the function updates the persistence plane by storing the new host
 * entry under @c views[interface].hosts[hostname] (including optional @c local_domain) and regenerating
 * the relevant configuration file through @ref apply_host_cfg.
 *
 * Domain handling:
 * - If @c local_domain is present in the request, it is stored/updated for the host (including clearing).
 * - Otherwise, the previous per-host @c local_domain is kept if present; else the view’s @c domain_name is used.
 * - The previous effective domain is tracked so removal targets the correct FQDN variants.
 *
 * Failover behaviour:
 * - When @c no_failover is false and the runtime UnboundControl operation fails with a “critical” status,
 *   the module forces a restart/resync of the instance via @ref handle_unbound.
 *
 * Expected arguments in @p args:
 * - @c "interface" (string, mandatory): interface/view identifier.
 * - @c "name"      (string, mandatory): hostname key.
 * - @c "ipv4_addresses" (list, optional): new IPv4 address set (replaces previous list).
 * - @c "ipv6_addresses" (list, optional): new IPv6 address set (replaces previous list).
 * - @c "local_domain"   (string, optional): per-host domain override; may be provided to update/clear.
 * - @c "no_failover"    (bool, optional): when true, do not force restart on runtime apply errors.
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Host update request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 on success, -1 on failure (invalid input, missing view/host in a remove path, or backend apply failure).
 */
static int set_host(UNUSED const char* function_name,
                    amxc_var_t* args,
                    UNUSED amxc_var_t* ret) {
    unbound_status_t status = unbound_other_error;
    unbound_intf_t* unbound = NULL;
    amxc_var_t* views = GET_ARG(&g.config, "views");
    amxc_var_t* view_var = NULL;
    amxc_var_t* host = NULL;
    amxc_var_t* new_host = NULL;
    amxc_var_t* hosts = NULL;
    const char* view = GET_CHAR(args, "interface");
    const char* hostname = GET_CHAR(args, "name");
    amxc_var_t* local_domain_arg = GET_ARG(args, "local_domain");
    const char* domain = GET_CHAR(local_domain_arg, NULL); //individual domain for a specific host
    amxc_var_t* old_local_domain_arg = NULL;
    char* old_domain = NULL;
    const char* global_domain = NULL;
    bool new_entry = false;

    bool no_failover = GET_BOOL(args, "no_failover");
    int rv = -1;
    bool check_critical = false;

    amxc_var_new(&new_host);

    when_str_empty(view, exit);

    unbound = get_unbound_intf(view);
    if(unbound != NULL) {
        views = GET_ARG(&unbound->config, "views");
    }

    when_null_trace(views, exit, ERROR, "Something bad happened");

    view_var = GET_ARG(views, view);
    if(view_var == NULL) {
        view_var = amxc_var_add_key(amxc_htable_t, views, view, NULL);
        when_null_trace(amxc_var_add_key(amxc_htable_t, view_var, "hosts", NULL), exit, ERROR, "Failed to add key");
    }
    when_null_trace(view_var, exit, ERROR, "Failed to add view %s for host '%s'", view, hostname);

    global_domain = GET_CHAR(view_var, "domain_name");
    if(global_domain != NULL) {
        old_domain = strdup(global_domain);
    }

    hosts = GET_ARG(view_var, "hosts");
    when_null_trace(hosts, exit, ERROR, "Something bad happened");

    host = GET_ARG(hosts, hostname);
    if(host == NULL) {
        SAH_TRACEZ_INFO(ME, "Add new host '%s'", hostname);
        new_entry = true;
        amxc_var_set_type(new_host, AMXC_VAR_ID_HTABLE);
        for(int i = 0; ipaddr_types[i] != NULL; i++) {
            amxc_var_add_key(amxc_llist_t, new_host, ipaddr_types[i], NULL);
        }
        if(!string_empty(domain)) {
            amxc_var_add_key(cstring_t, new_host, "local_domain", domain);
        }
    } else {
        amxc_var_copy(new_host, host);
        old_local_domain_arg = GET_ARG(new_host, "local_domain");
        if(!string_empty(GET_CHAR(new_host, "local_domain"))) {
            FREE(old_domain);
            old_domain = strdup(GET_CHAR(old_local_domain_arg, NULL));
        }
        if(local_domain_arg != NULL) {
            if((old_local_domain_arg == NULL) && !string_empty(domain)) {
                amxc_var_add_key(cstring_t, new_host, "local_domain", domain);
            } else if(old_local_domain_arg != NULL) {
                amxc_var_set(cstring_t, old_local_domain_arg, domain);
            }
        }
    }

    for(int i = 0; ipaddr_types[i] != NULL; i++) {
        amxc_var_t* ip_list = GET_ARG(new_host, ipaddr_types[i]);
        amxc_var_set_type(ip_list, AMXC_VAR_ID_LIST); // clean list
        amxc_var_for_each(var, GET_ARG(args, ipaddr_types[i])) {
            const char* ip_address = GET_CHAR(var, NULL);
            SAH_TRACEZ_INFO(ME, "Add new address '%s' to %s", ip_address, ipaddr_types[i]);
            amxc_var_add(cstring_t, ip_list, ip_address);
        }
    }

    if(string_empty(domain)) {
        domain = GET_CHAR(new_host, "local_domain");
    }
    if(string_empty(domain)) {
        domain = global_domain;
    }

    if(unbound == NULL) {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        rv = 0;
        goto exit;
    }

    if(unbound->state == RUNNING) {
        if(!no_failover) {
            check_critical = true;
        }
        // we could patch unbound to make it possible to remove addresses in 1 call
        status = cmd_remove_host(view, hostname, old_domain,
                                 GET_ARG(host, "ipv4_addresses"), GET_ARG(host, "ipv6_addresses"));
        if(!new_entry) {
            when_failed(status, exit);
        }
        status = cmd_add_host(view, hostname, domain,
                              GET_ARG(new_host, "ipv4_addresses"), GET_ARG(new_host, "ipv6_addresses"), false);
        when_failed(status, exit);
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
    } else {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

    rv = 0;
exit:
    if(check_critical && (status != unbound_ok) && (status < unbound_other_error)) {
        SAH_TRACEZ_ERROR(ME, "Critical Error: Unbound will restart.");
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        handle_unbound(unbound, __func__);
    }
    amxc_var_delete(&new_host);
    FREE(old_domain);
    return rv;
}

/**
 * @brief Remove a host (all local records) from a view and apply the change to Unbound.
 *
 * @details
 * This AMXM entry point removes the complete local DNS definition of a host for a given interface/view.
 * In TR-181 terms, this deletes the host object so it no longer resolves locally.
 *
 * When the corresponding Unbound instance is running, the function removes:
 * - forward local-data records for the hostname (and FQDN duplication when applicable),
 * - associated reverse PTR records for each configured address,
 * through the UnboundControl RPC by calling @ref cmd_remove_host.
 *
 * The persistence plane is then updated by deleting @c views[interface].hosts[hostname] via
 * @ref apply_host_cfg, which also regenerates the instance configuration file. If the instance is enabled
 * but not running, the lifecycle handler is triggered so the next start comes up without the removed host.
 *
 * Failover behaviour:
 * - When @c no_failover is false and a “critical” runtime removal fails, the module forces a restart/resync
 *   via @ref handle_unbound to converge to the persisted configuration.
 *
 * Expected arguments in @p args:
 * - @c "interface"  (string, mandatory): interface/view identifier.
 * - @c "name"       (string, mandatory): hostname key.
 * - @c "no_failover" (bool, optional): when true, do not force restart on runtime apply errors.
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Removal request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 on success, -1 when the view/host does not exist or when applying the change failed.
 */
static int remove_host(UNUSED const char* function_name,
                       amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    unbound_status_t status = unbound_other_error;
    unbound_intf_t* unbound = NULL;
    amxc_var_t* views = GET_ARG(&g.config, "views");
    amxc_var_t* view_var = NULL;
    amxc_var_t* host = NULL;
    amxc_var_t* hosts = NULL;
    const char* view = GET_CHAR(args, "interface");
    const char* hostname = GET_CHAR(args, "name");
    const char* domain = NULL;
    bool no_failover = GET_BOOL(args, "no_failover");
    int rv = -1;
    bool check_critical = false;

    when_str_empty(view, exit);

    unbound = get_unbound_intf(view);
    if(unbound != NULL) {
        views = GET_ARG(&unbound->config, "views");
    }

    when_null_trace(views, exit, ERROR, "Something bad happened");
    view_var = GET_ARG(views, view);
    when_null_trace(view_var, exit, INFO, "No view '%s' to remove host '%s'", view, hostname);
    hosts = GET_ARG(view_var, "hosts");
    when_null_trace(hosts, exit, ERROR, "Something bad happened");
    host = GET_ARG(hosts, hostname);
    when_null_trace(host, exit, INFO, "View '%s' has no host '%s'", view, hostname);

    domain = GET_CHAR(host, "local_domain");
    if(string_empty(domain)) {
        domain = GET_CHAR(view_var, "domain_name");
    }

    if(unbound == NULL) {
        apply_host_cfg(unbound, hosts, hostname, host, NULL);
        rv = 0;
        goto exit;
    }

    SAH_TRACEZ_INFO(ME, "Remove host '%s'", hostname);
    if(unbound->state == RUNNING) {
        if(!no_failover) {
            check_critical = true;
        }
        status = cmd_remove_host(view, hostname, domain,
                                 GET_ARG(host, "ipv4_addresses"), GET_ARG(host, "ipv6_addresses"));
        when_failed(status, exit);
        apply_host_cfg(unbound, hosts, hostname, host, NULL);
    } else {
        apply_host_cfg(unbound, hosts, hostname, host, NULL);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

    rv = 0;
exit:
    if(check_critical && (status != unbound_ok) && (status < unbound_other_error)) {
        SAH_TRACEZ_ERROR(ME, "Critical Error: Unbound will restart.");
        apply_host_cfg(unbound, hosts, hostname, host, NULL);
        handle_unbound(unbound, __func__);
    }
    return rv;
}

/**
 * @brief Remove specific address(es) from an existing host and apply the change to Unbound.
 *
 * @details
 * This AMXM entry point implements the TR-181 “remove host address” semantics: only the provided
 * IPv4/IPv6 addresses are removed from the host’s current address set, keeping the host and any other
 * addresses intact.
 *
 * Persistence plane:
 * - The host entry @c views[interface].hosts[hostname].ipv4_addresses / .ipv6_addresses is filtered to
 *   remove the requested addresses, and the configuration file for the instance is regenerated via
 *   @ref apply_host_cfg.
 *
 * Runtime plane (running instances):
 * - Because UnboundControl does not support removing a subset of addresses from a local-data record in
 *   one command, the module performs a remove-then-readd sequence:
 *   1) @ref cmd_remove_host removes the full previous record set (and PTRs),
 *   2) @ref cmd_add_host re-adds the remaining addresses; when the remaining set is empty, the command
 *      layer is allowed to no-op (see @c accept_empty_address in @ref cmd_add_host).
 *
 * This function requires that at least one address is actually removed; otherwise it fails early to
 * avoid unnecessary backend churn.
 *
 * Expected arguments in @p args:
 * - @c "interface"      (string, mandatory): interface/view identifier.
 * - @c "name"           (string, mandatory): hostname key.
 * - @c "ipv4_addresses" (list, optional): IPv4 address strings to remove.
 * - @c "ipv6_addresses" (list, optional): IPv6 address strings to remove.
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Address removal request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 on success, -1 when nothing was removed, the view/host does not exist, or when applying the
 *         change to a running backend failed.
 */
static int remove_host_address(UNUSED const char* function_name,
                               amxc_var_t* args,
                               UNUSED amxc_var_t* ret) {
    unbound_status_t status = unbound_other_error;
    unbound_intf_t* unbound = NULL;
    amxc_var_t* views = GET_ARG(&g.config, "views");
    amxc_var_t* view_var = NULL;
    amxc_var_t* host = NULL;
    amxc_var_t* new_host = NULL;
    amxc_var_t* hosts = NULL;
    const char* view = GET_CHAR(args, "interface");
    const char* hostname = GET_CHAR(args, "name");
    const char* domain = NULL;
    int count = 0;
    int rv = -1;
    bool check_critical = false;

    amxc_var_new(&new_host);

    when_str_empty(view, exit);

    unbound = get_unbound_intf(view);
    if(unbound != NULL) {
        views = GET_ARG(&unbound->config, "views");
    }

    when_null_trace(views, exit, ERROR, "Something bad happened");
    view_var = GET_ARG(views, view);
    when_null_trace(view_var, exit, INFO, "No view '%s' to remove host '%s'", view, hostname);
    hosts = GET_ARG(view_var, "hosts");
    when_null_trace(hosts, exit, ERROR, "Something bad happened");
    host = GET_ARG(hosts, hostname);
    when_null_trace(host, exit, INFO, "View '%s' has no host '%s'", view, hostname);
    amxc_var_copy(new_host, host);

    for(int i = 0; ipaddr_types[i] != NULL; i++) {
        amxc_var_for_each(var_a, GET_ARG(args, ipaddr_types[i])) {
            const char* ip_address = GET_CHAR(var_a, NULL);

            amxc_var_for_each(var_b, GET_ARG(new_host, ipaddr_types[i])) {
                if(strcmp(GET_CHAR(var_b, NULL), ip_address) == 0) {
                    SAH_TRACEZ_INFO(ME, "Remove ip address '%s' from %s", ip_address, ipaddr_types[i]);
                    amxc_var_delete(&var_b);
                    count++;
                    break;
                }
            }
        }
    }

    when_false_trace(count > 0, exit, ERROR, "Nothing removed");

    domain = GET_CHAR(new_host, "local_domain");
    if(string_empty(domain)) {
        domain = GET_CHAR(view_var, "domain_name");
    }

    if(unbound == NULL) {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        rv = 0;
        goto exit;
    }

    if(unbound->state == RUNNING) {
        // we could patch unbound to make it possible to remove addresses in 1 call
        check_critical = true;
        status = cmd_remove_host(view, hostname, domain,
                                 GET_ARG(host, "ipv4_addresses"), GET_ARG(host, "ipv6_addresses"));
        when_failed(status, exit);
        status = cmd_add_host(view, hostname, domain,
                              GET_ARG(new_host, "ipv4_addresses"), GET_ARG(new_host, "ipv6_addresses"), true);
        when_failed(status, exit);
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
    } else {
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
    }

    rv = 0;
exit:
    if(check_critical && (status != unbound_ok) && (status < unbound_other_error)) {
        SAH_TRACEZ_ERROR(ME, "Critical Error: Unbound will restart.");
        apply_host_cfg(unbound, hosts, hostname, host, new_host);
        handle_unbound(unbound, __func__);
    }
    amxc_var_delete(&new_host);
    return rv;
}

/**
 * @brief Store raw Unbound "server:" options coming from the TR-181 DNS layer.
 *
 * @details
 * The TR-181 plugin may expose a set of additional, low-level Unbound tuning knobs as free-form
 * configuration lines (ODL options). The goal of this function is to persist those options in the
 * module’s global in-memory configuration (@c g.config["options"]) so they can be rendered into the
 * generated Unbound configuration file(s) by @ref create_config_file.
 *
 * This function is intentionally a **configuration staging** step: it does not regenerate files, does
 * not restart instances, and does not call UnboundControl. Convergence to the running backend happens
 * when the module later regenerates configuration and (re)starts/reloads instances as part of normal
 * lifecycle handling.
 *
 * @param[in] function_name Name of the invoked AMXM function (unused).
 * @param[in] args          Variant containing the new option list/table as provided by the plugin.
 *                          The exact structure is consumed by @ref create_config_file.
 * @param[out] ret          Optional return value container (unused).
 *
 * @return 0.
 */
static int set_options(UNUSED const char* function_name,
                       amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    amxc_var_t* options = GET_ARG(&g.config, "options");
    amxc_var_copy(options, args);
    return 0;
}

/**
 * @brief Flush the DNS cache for a single Unbound instance (or converge it if it is not running).
 *
 * @details
 * Flushing the cache is a runtime operation typically used after configuration changes (hosts,
 * forwarding, domain/view rules) to ensure new answers become visible immediately rather than after
 * TTL expiry.
 *
 * If the instance is currently running, this helper clears the cache by issuing the UnboundControl RPC
 * (wrapping @c unbound-control) via @ref cmd_flush_cache (internally using @c flush_zone .).
 *
 * If the instance is not running, there is nothing to flush. In that case the function ensures the
 * instance configuration file is up to date and, if the instance is enabled, triggers lifecycle
 * handling (@ref handle_unbound) so the instance can restart/resync and come back consistent with the
 * staged configuration.
 *
 * @param[in,out] unbound Target Unbound instance.
 *
 * @return 0 on success, 1 on failure (e.g. invalid instance or UnboundControl command failure).
 */
static int _flush_cache(unbound_intf_t* unbound) {
    bool rv = false;

    when_null(unbound, exit);

    if(unbound->state == RUNNING) {
        if(cmd_flush_cache(amxc_string_get(&unbound->intf, 0)) == 0) {
            rv = true;
        }
    } else {
        create_config_file(unbound);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);

        }
        rv = true;
    }

exit:
    if(rv) {
        return 0;
    } else {
        return 1;
    }
}

/**
 * @brief Flush the DNS cache for one interface, or for all managed interfaces.
 *
 * @details
 * This AMXM entry point exposes a management operation to clear caches so that downstream clients see
 * updated DNS behaviour immediately. It targets either a single interface/view instance (when
 * @c "interface" is provided and known) or all managed instances (when not provided or not found).
 *
 * For running instances, flushing is performed through UnboundControl (see @ref cmd_flush_cache).
 * For non-running instances, the call is treated as a convergence trigger (regen config + lifecycle).
 *
 * Expected arguments in @p args:
 * - @c "interface" (string, optional): interface/view identifier.
 *
 * @param[in]  function_name Name of the invoked AMXM function (unused).
 * @param[in]  args          Flush request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 when at least one targeted instance was flushed/converged successfully, 1 otherwise.
 */
static int flush_cache(UNUSED const char* function_name,
                       amxc_var_t* args,
                       UNUSED amxc_var_t* ret) {
    unbound_intf_t* unbound = NULL;
    const char* interface = GET_CHAR(args, "interface");
    int rv = 1;

    unbound = get_unbound_intf(interface);
    if(unbound != NULL) {
        rv = _flush_cache(unbound);
        goto exit;
    }
    when_not_null(interface, exit);

    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        rv &= _flush_cache(unbound);
    }

exit:
    return rv;
}

/**
 * @brief Store the view (interface) domain suffix used for local host name expansion.
 *
 * @details
 * The TR-181 DNS integration supports publishing local hostnames in Unbound. For “base” hostnames
 * (see @ref is_local_hostname_base), the module can optionally publish an additional FQDN form
 * `<hostname>.<domain_name>` besides the bare hostname. This suffix is used both:
 * - when generating the Unbound configuration file (see @ref create_config_file), and
 * - when injecting records at runtime through UnboundControl (see command helpers in modunbound_cmd.c).
 *
 * This helper updates the in-memory view configuration container by setting (or creating) the
 * @c "domain_name" key under the provided view entry.
 *
 * @param[in,out] intf_var     View configuration object (typically @c views[<interface>]).
 * @param[in]     domain_name  Domain suffix to store. An empty string is allowed and disables the suffix;
 *                             @c NULL is considered invalid by callers.
 */
static void apply_domain_cfg(amxc_var_t* intf_var, const char* domain_name) {
    amxc_var_t* domain_name_var = NULL;

    when_null(intf_var, exit);

    domain_name_var = GET_ARG(intf_var, "domain_name");
    if(domain_name_var == NULL) {
        amxc_var_add_key(cstring_t, intf_var, "domain_name", domain_name);
    } else {
        amxc_var_set(cstring_t, domain_name_var, domain_name);
    }

exit:
    return;
}

/**
 * @brief Set the domain suffix for one interface/view and converge Unbound’s local host records.
 *
 * @details
 * In this module, the TR-181 “DomainName” concept is used as a *suffix expansion* for local host records:
 * when a host is configured with a base hostname and no per-host @c local_domain override, the module
 * publishes both:
 * - `<hostname>` and
 * - `<hostname>.<domain_name>`
 *
 * Changing the view’s domain suffix therefore impacts the set of local DNS records that should exist in
 * the running Unbound instance. This function ensures both the persistent configuration and the runtime
 * state converge to the new domain:
 *
 * - **Staging / persistence:** the view’s @c "domain_name" is updated in the in-memory configuration
 *   (either in the global staging container @c g.config or in the instance container @c unbound->config),
 *   and the per-interface Unbound configuration file is regenerated via @ref create_config_file.
 *
 * - **Runtime convergence (running instances):** when the target interface instance is in @c RUNNING
 *   state, host records that depend on the view domain are refreshed by:
 *   1) removing affected hosts (base hostnames with empty @c local_domain) using @ref remove_host,
 *   2) applying the new domain suffix to the view configuration,
 *   3) re-adding the same hosts and address sets using @ref add_host so the `<hostname>.<domain_name>`
 *      duplication matches the new domain.
 *
 * Hosts that are not base hostnames, or that explicitly set a per-host @c local_domain, are unaffected
 * and are not refreshed.
 *
 * **Failover intent:** this function prefers an in-place runtime update, but if that fails it falls back
 * to restarting/resynchronizing the instance through @ref handle_unbound (after updating the persisted
 * configuration). This makes the operation robust: the caller gets a successful outcome once the module
 * has ensured the backend will converge (immediately or after restart).
 *
 * Expected arguments in @p args:
 * - @c "interface"    (string, mandatory): target interface/view identifier.
 * - @c "domain_name"  (string, mandatory): new domain suffix (may be empty; must not be @c NULL).
 *
 * @param[in]  function_name Name of the invoked AMXM function (forwarded to internal helpers).
 * @param[in]  args          Domain update request as described above.
 * @param[out] ret           Optional return value container (unused).
 *
 * @return 0 when the update has been accepted and staged/applied (including restart-based convergence),
 *         -1 on invalid input or unrecoverable internal errors (e.g. missing view container).
 */
static int set_domain_name(const char* function_name,
                           amxc_var_t* args,
                           amxc_var_t* ret) {
    unbound_intf_t* unbound = NULL;
    amxc_var_t* views = GET_ARG(&g.config, "views");
    amxc_var_t* view_var = NULL;
    amxc_var_t* hosts = NULL;
    amxc_var_t* args_remove = NULL;
    amxc_var_t* args_add = NULL;
    int rv = -1;
    const char* view = GET_CHAR(args, "interface");
    const char* domain_name = GET_CHAR(args, "domain_name");

    amxc_var_new(&args_remove);
    amxc_var_new(&args_add);

    // Empty domain name is allowed, but NULL not
    when_null_trace(domain_name, exit, ERROR, "Domain Name cannot be NULL");
    when_str_empty(view, exit);

    unbound = get_unbound_intf(view);
    if(unbound != NULL) {
        views = GET_ARG(&unbound->config, "views");
    }

    when_null_trace(views, exit, ERROR, "Something bad happened");
    view_var = GET_ARG(views, view);
    if(view_var == NULL) {
        view_var = amxc_var_add_key(amxc_htable_t, views, view, NULL);
        when_null_trace(amxc_var_add_key(amxc_htable_t, view_var, "hosts", NULL), exit, ERROR, "Failed to add htable item");
    }
    when_null_trace(view_var, exit, ERROR, "No view %s for domain %s", view, domain_name);

    if(unbound == NULL) {
        apply_domain_cfg(view_var, domain_name);
        rv = 0;
        goto exit;
    }

    if(unbound->state != RUNNING) {
        apply_domain_cfg(view_var, domain_name);
        create_config_file(unbound);
        if(unbound->enable) {
            handle_unbound(unbound, __func__);
        }
        rv = 0;
        goto exit;
    }

    amxc_var_set_type(args_remove, AMXC_VAR_ID_LIST);
    amxc_var_set_type(args_add, AMXC_VAR_ID_LIST);

    hosts = GET_ARG(view_var, "hosts");
    amxc_var_for_each(host, hosts) {
        amxc_var_t* args_remove_host_address = NULL;
        amxc_var_t* args_add_host = NULL;
        const char* hostname = amxc_var_key(host);
        const char* local_domain = GET_CHAR(host, "local_domain");
        if(string_empty(hostname)) {
            continue;
        }
        if(!is_local_hostname_base(hostname)) {
            continue;
        }
        if(!string_empty(local_domain)) {
            continue;
        }
        args_remove_host_address = amxc_var_add(amxc_htable_t, args_remove, NULL);
        args_add_host = amxc_var_add(amxc_htable_t, args_add, NULL);
        amxc_var_copy(args_remove_host_address, args);
        amxc_var_copy(args_add_host, args);
        amxc_var_add_key(cstring_t, args_remove_host_address, "name", hostname);
        amxc_var_add_key(cstring_t, args_add_host, "name", hostname);
        amxc_var_add_key(bool, args_remove_host_address, "no_failover", true);
        amxc_var_add_key(bool, args_add_host, "no_failover", true);
        for(int i = 0; ipaddr_types[i] != NULL; i++) {
            amxc_var_t* ip_list = GET_ARG(args_add_host, ipaddr_types[i]);
            if(ip_list == NULL) {
                ip_list = amxc_var_add_key(amxc_llist_t, args_add_host, ipaddr_types[i], NULL);
            }
            amxc_var_for_each(address, GET_ARG(host, ipaddr_types[i])) {
                const char* ip_address = GET_CHAR(address, NULL);
                amxc_var_add(cstring_t, ip_list, ip_address);
            }
        }
    }

    amxc_var_for_each(function_args, args_remove) {
        rv = remove_host(function_name, function_args, ret);
        if(rv != 0) {
            apply_domain_cfg(view_var, domain_name);
            create_config_file(unbound);
            if(unbound->enable) {
                handle_unbound(unbound, __func__);
            }
            rv = 0;
            goto exit;
        }
    }

    apply_domain_cfg(view_var, domain_name);
    create_config_file(unbound);

    amxc_var_for_each(function_args, args_add) {
        rv = add_host(function_name, function_args, ret);
        if(rv != 0) {
            if(unbound->enable) {
                handle_unbound(unbound, __func__);
            }
            rv = 0;
            goto exit;
        }
    }

    rv = 0;
exit:
    amxc_var_delete(&args_remove);
    amxc_var_delete(&args_add);
    return rv;
}

/**
 * @brief Watchdog callback when Unbound readiness signaling is delayed or missing.
 *
 * After spawning Unbound, the module expects a readiness signal/object to appear on the bus within a
 * bounded time. This callback is fired when that time elapses. If the bus context is actually present,
 * it shortcuts into the normal “wait done” handler; otherwise it treats the situation as an abnormal
 * startup condition and engages exponential-backoff recovery.
 *
 * @param[in]     local_timer Timer instance (unused).
 * @param[in,out] priv        User pointer, expected to be the associated @c unbound_intf_t instance.
 */
static void wait_for_child(UNUSED amxp_timer_t* local_timer, void* priv) {
    unbound_intf_t* unbound = (unbound_intf_t*) priv;
    amxb_bus_ctx_t* ctx = NULL;
    const char* interface = NULL;
    amxc_string_t wait_done_signal_reason;

    amxc_string_init(&wait_done_signal_reason, 0);

    when_null(unbound, exit);
    interface = amxc_string_get(&unbound->intf, 0);

    ctx = get_unbound_ctx(interface);
    if(ctx != NULL) {
        unbound_wait_done(NULL, NULL, priv);
        goto exit;
    }

    SAH_TRACEZ_ERROR(ME, "Bug: failed to receive signal '" WAIT_DONE_SIGNAL "' after %d seconds", interface, WAIT_FOR_CHILD_IN_SEC);
    amxc_string_setf(&wait_done_signal_reason, "failed to receive signal '" WAIT_DONE_SIGNAL "'", interface);
    trigger_exponential_backoff(unbound, amxc_string_get(&wait_done_signal_reason, 0));

exit:
    amxc_string_clean(&wait_done_signal_reason);
    return;
}


/**
 * @brief Look up an existing Unbound instance object by interface key.
 *
 * The module maintains a hash table keyed by interface name, with one managed Unbound instance per
 * interface. This helper performs the lookup and returns the associated instance pointer.
 *
 * @param[in] intf Interface identifier used as key in the global instance table.
 *
 * @return Pointer to the instance when present, or @c NULL when not found.
 */
static unbound_intf_t* get_unbound_intf(const char* intf) {
    unbound_intf_t* unbound = NULL;
    amxc_htable_it_t* it_unbound = NULL;

    when_str_empty(intf, exit);

    it_unbound = amxc_htable_get(&g.unbound_intf_per_intf, intf);
    if(it_unbound != NULL) {
        unbound = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
    }

exit:
    return unbound;
}

/**
 * @brief Connect process-level signals (stop, wait-ready) to callbacks for a given instance.
 *
 * Each Unbound instance is managed via an Ambiorix subprocess object. This helper attaches the
 * lifecycle callbacks so the module can observe termination and readiness events and drive the
 * state machine accordingly.
 *
 * @param[in,out] unbound Unbound instance whose subprocess signal manager should be connected.
 */
static void slot_connect_unbound_instance(unbound_intf_t* unbound) {
    amxc_string_t wait_done_signal;

    amxc_string_init(&wait_done_signal, 0);

    when_null(unbound, exit);
    when_str_empty(amxc_string_get(&unbound->intf, 0), exit);

    if(unbound->process != NULL) {
        amxp_slot_connect(unbound->process->sigmngr, "stop", NULL, unbound_stopped, unbound);
        amxc_string_setf(&wait_done_signal, WAIT_DONE_SIGNAL, amxc_string_get(&unbound->intf, 0));
        amxp_slot_connect_filtered(unbound->process->sigmngr, amxc_string_get(&wait_done_signal, 0), NULL, unbound_wait_done, unbound);
    }

exit:
    amxc_string_clean(&wait_done_signal);
    return;
}

/**
 * @brief Release runtime resources associated with an Unbound instance without freeing the struct.
 *
 * @details
 * This function is used as the “cleanup” step for instance deletion and for hash-iterator delete
 * callbacks. It stops the process, disconnects signal slots, deletes timers/subprocess resources,
 * and clears variant/string members.
 *
 * Because some slot disconnect operations are global, it reconnects remaining instances afterwards
 * to keep their event handling intact.
 *
 * @param[in,out] unbound Address of the instance pointer to clean (must not be @c NULL).
 */
static void unbound_intf_clean(unbound_intf_t** unbound) {
    when_null(unbound, exit);
    when_null(*unbound, exit);

    (*unbound)->fail_stop = false;
    stop_unbound((*unbound), STOPPED);

    amxp_slot_disconnect_all(unbound_stopped);
    amxp_slot_disconnect_all(unbound_wait_done);
    amxc_htable_for_each(it_unbound, &g.unbound_intf_per_intf) {
        unbound_intf_t* u = amxc_htable_it_get_data(it_unbound, unbound_intf_t, it);
        if(u != *unbound) {
            slot_connect_unbound_instance(u); //reconnect the slots of all the other unbound instances
        }
    }
    amxp_sigmngr_clean((*unbound)->process->sigmngr);

    amxp_subproc_delete(&(*unbound)->process);

    amxp_timer_delete(&(*unbound)->start_timer);
    amxp_timer_delete(&(*unbound)->wait_for_child);
    amxp_timer_delete(&(*unbound)->backoff_timer);

    amxc_var_clean(&(*unbound)->config);
    amxc_string_clean(&(*unbound)->intf);

exit:
    return;
}

/**
 * @brief Fully delete an Unbound instance object, including cleanup and memory release.
 *
 * This is the owning destructor used when the module no longer needs to manage an interface’s Unbound
 * instance. It performs runtime cleanup, removes the hash-table iterator state, and frees the struct.
 *
 * @param[in,out] unbound Address of the instance pointer to delete; set to @c NULL by the function.
 */
static void unbound_intf_delete(unbound_intf_t** unbound) {
    when_null(unbound, exit);
    when_null(*unbound, exit);

    unbound_intf_clean(unbound);

    amxc_htable_it_clean(&(*unbound)->it, NULL);
    FREE((*unbound));
exit:
    return;
}

/**
 * @brief Hash-table iterator delete hook for @c unbound_intf_t entries.
 *
 * This callback is intended for use with Ambiorix hash-table cleanup APIs. It translates the iterator
 * back to the owning @c unbound_intf_t, performs standard instance cleanup, and releases the memory.
 *
 * @param[in] key Unused hash key.
 * @param[in] it  Hash-table iterator pointing to the stored @c unbound_intf_t.
 */
static void unbound_intf_it_delete(UNUSED const char* key, amxc_htable_it_t* it) {
    unbound_intf_t* unbound = amxc_htable_it_get_data(it, unbound_intf_t, it);
    unbound_intf_clean(&unbound);
    FREE(unbound);
}

/**
 * @brief Allocate and initialize a new per-interface Unbound instance container.
 *
 * @details
 * One Unbound subprocess is managed per interface. This constructor initializes all supporting
 * mechanisms needed for lifecycle management: subprocess wrapper, timers (delayed start, wait-ready,
 * and backoff reset), per-instance configuration containers, and initial state.
 *
 * @param[in] intf   Interface identifier used for config file naming and bus object naming.
 * @param[in] enable Initial enable state for the created instance.
 *
 * @return Newly allocated instance on success, or @c NULL on allocation/initialization failure.
 */
static unbound_intf_t* unbound_intf_new(const char* intf, bool enable) {
    unbound_intf_t* unbound = NULL;
    amxc_string_t reason_state;
    int rv = -1;

    amxc_string_init(&reason_state, 0);

    when_str_empty(intf, exit);
    unbound = (unbound_intf_t*) calloc(1, sizeof(unbound_intf_t));
    when_null(unbound, exit);

    rv = amxp_subproc_new(&unbound->process);
    when_failed(rv, exit);

    amxc_var_init(&unbound->config);
    amxc_var_set_type(&unbound->config, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(amxc_htable_t, &unbound->config, "views", NULL);

    amxp_timer_new(&unbound->start_timer, delayed_start, unbound);
    amxp_timer_new(&unbound->wait_for_child, wait_for_child, unbound);
    amxp_timer_new(&unbound->backoff_timer, exponential_backoff_restart, unbound);

    unbound->enable = enable;
    amxc_string_setf(&reason_state, "%s '%s'", __func__, intf);
    update_state(unbound, STOPPED, amxc_string_get(&reason_state, 0));

    unbound->start_timer_in_ms = DELAY_TIME;
    unbound->stopping = false;
    unbound->fail_stop = false;
    unbound->backoff_delay = INI_BACKOFF_WAIT_TIME;

    amxc_string_init(&unbound->intf, 0);
    amxc_string_setf(&unbound->intf, "%s", intf);

    slot_connect_unbound_instance(unbound);

    rv = 0;
exit:
    if(rv != 0) {
        unbound_intf_delete(&unbound);
    }
    amxc_string_clean(&reason_state);
    return unbound;
}


/**
 * @brief Ensure an Unbound instance exists for an interface and return it.
 *
 * This is the idempotent accessor used by higher-level code: it returns the existing instance if one
 * is already registered for @p intf, otherwise it creates a new instance and inserts it into the
 * module’s global interface-to-instance table.
 *
 * @param[in] intf   Interface identifier.
 * @param[in] enable Initial enable state for a newly created instance.
 *
 * @return Instance pointer (existing or newly created), or @c NULL on failure.
 */
static unbound_intf_t* add_unbound_intf(const char* intf, bool enable) {
    unbound_intf_t* unbound = NULL;

    unbound = get_unbound_intf(intf);
    if(unbound == NULL) {
        unbound = unbound_intf_new(intf, enable);
        when_null(unbound, exit);
        amxc_htable_insert(&g.unbound_intf_per_intf, intf, &unbound->it);
    }

exit:
    return unbound;
}

/**
 * @brief AMXM function registration entry.
 *
 * @details
 * The Ambiorix AMXM module interface exposes named entry points to the TR-181 DNS plugin.
 * During module initialization, an array of these mappings is iterated to register each handler
 * (e.g. set-server, set-host, set-interface, cache flush, security toggles, etc.).
 *
 * This struct is purely an initialization helper: it binds a stable external API name to a C callback.
 */
typedef struct {
    const char* name;          /**< External AMXM function name as invoked by the TR-181 integration. */
    amxm_callback_t callback;  /**< C function that implements the requested operation. */
} function_t;

/**
 * @brief Ambiorix module constructor: register TR-181 facing functions and initialize module state.
 *
 * @details
 * This constructor is executed when the Ambiorix shared object is loaded. Its goal is to make this
 * Unbound/TR-181 integration usable immediately by:
 * - registering an AMXM module instance named @c "dns";
 * - exposing the module API entry points (e.g. server/host/interface operations, enable toggle,
 *   cache operations, redirect/rebind settings, domain suffix updates);
 * - initializing the module’s global configuration containers used for file generation:
 *   - @c g.config["fwzones"] (with the default root zone @c "."),
 *   - @c g.config["interfaces"],
 *   - @c g.config["views"],
 *   - @c g.config["options"];
 * - initializing default operational parameters (e.g. enabled by default, retry/timeout defaults,
 *   rebind protection enabled with empty exception lists);
 * - preparing required filesystem paths for generated configuration files;
 * - creating a baseline Unbound instance for @c "lo" (loopback), generating its initial configuration,
 *   and invoking the instance lifecycle handler (@ref handle_unbound) to align runtime state.
 *
 * Runtime edits (using UnboundControl) are not performed here directly; this function primarily sets up
 * the module state and triggers the standard lifecycle path.
 *
 * @return 0 on successful initialization, non-zero if the AMXM module could not be registered.
 */
static AMXM_CONSTRUCTOR module_init(void) {
    unbound_intf_t* unbound = NULL;
    amxm_shared_object_t* so = amxm_so_get_current();
    amxm_module_t* mod = NULL;
    function_t function[] = {
        {"set-server", set_server},
        {"add-server", add_server},
        {"remove-server", remove_server},
        {"add-host", add_host}, // deprecated to be removed in later version
        {"set-host", set_host},
        {"remove-host", remove_host},
        {"remove-host-address", remove_host_address}, // deprecated to be removed in later version
        {"set-interface", set_interface},
        {"remove-interface", remove_interface},
        {"enable-changed", enable_changed},
        {"redirect-changed", redirect_changed},
        {"set-options", set_options},
        {"set-cache", set_cache},
        {"flush-cache", flush_cache},
        {"rebind-changed", rebind_protection_changed},
        {"set-domain-name", set_domain_name},
        {NULL, 0}
    };
    int rv = -1;
    amxc_var_t* var = NULL;

    memset(&g, 0, sizeof(globals_t));

    rv = amxm_module_register(&mod, so, "dns");
    when_false(0 == rv, exit);

    for(size_t i = 0; function[i].name != NULL; i++) {
        if(0 != amxm_module_add_function(mod, function[i].name, function[i].callback)) {
            SAH_TRACEZ_WARNING(ME, "Failed to register function %s", function[i].name);
        }
    }

    g.enable = true;
    g.timeout = -1;
    g.repeat = -1;
    g.rebind.enable = true;

    amxc_var_init(&g.rebind.domains);
    amxc_var_set_type(&g.rebind.domains, AMXC_VAR_ID_LIST);
    amxc_var_init(&g.rebind.ips);
    amxc_var_set_type(&g.rebind.ips, AMXC_VAR_ID_LIST);

    amxc_var_init(&g.config);
    amxc_var_set_type(&g.config, AMXC_VAR_ID_HTABLE);
    var = amxc_var_add_key(amxc_htable_t, &g.config, "fwzones", NULL);
    amxc_var_add_key(amxc_htable_t, var, ".", NULL);
    amxc_var_add_key(amxc_htable_t, &g.config, "interfaces", NULL);
    amxc_var_add_key(amxc_htable_t, &g.config, "views", NULL);
    amxc_var_add_key(amxc_llist_t, &g.config, "options", NULL);

    amxp_dir_make("/var/lib", 0755);
    amxp_dir_make(DNS_UNBOUND_CONFIG_PATH, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);

    amxc_htable_init(&g.unbound_intf_per_intf, 1);
    unbound = add_unbound_intf("lo", g.enable);
    unbound->is_intf_up = true;
    create_config_file(unbound);
    handle_unbound(unbound, __func__);

exit:
    return rv;
}

/**
 * @brief Ambiorix module destructor: stop instances and release all allocated module resources.
 *
 * @details
 * This destructor is executed when the Ambiorix shared object is unloaded. Its goal is to leave no
 * residual state behind by:
 * - cleaning the per-interface instance table (which invokes the standard instance delete hook and
 *   stops/cleans running Unbound instances as needed),
 * - releasing the rebind exception lists,
 * - cleaning the global configuration container.
 *
 * @return 0.
 */
static AMXM_DESTRUCTOR module_exit(void) {
    amxc_htable_clean(&g.unbound_intf_per_intf, unbound_intf_it_delete);
    amxc_var_clean(&g.rebind.ips);
    amxc_var_clean(&g.rebind.domains);
    amxc_var_clean(&g.config);

    return 0;
}
