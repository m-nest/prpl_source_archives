/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or without modification,
** are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
**
** Subject to the terms and conditions of this license, each copyright holder
** and contributor hereby grants to those receiving rights under this license
** a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable
** (except for failure to satisfy the conditions of this license) patent license
** to make, have made, use, offer to sell, sell, import, and otherwise transfer
** this software, where such license applies only to those patent claims, already
** acquired or hereafter acquired, licensable by such copyright holder or contributor
** that are necessarily infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright holders and
** non-copyrightable additions of contributors, in source or binary form) alone;
** or
**
** (b) combination of their Contribution(s) with the work of authorship to which
** such Contribution(s) was added by such copyright holder or contributor, if,
** at the time the Contribution is added, such addition causes such combination
** to be necessarily infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any copyright
** holder or contributor is granted under this license, whether expressly, by
** implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
** DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
** SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
** CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
** OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
** USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxut/amxut_dm.h>
#include <amxut/amxut_timer.h>

#include "bulkdata.h"
#include "bulkdata_actions.h"
#include "bulkdata_events.h"
#include "bulkdata_profile.h"

#include "test_common.h"
#include "mock.h"
#include "dummy_be.h"

static amxo_parser_t parser;
static const char* odl_defs = "../common/tr181-bulkdata_test.odl";
static const char* odl_device = "../common/test_device.odl";
static const char* odl_default_w_profile = "../common/tr181-bulkdata_test_defaults_with_profile.odl";
static amxb_bus_ctx_t* bus_ctx = NULL;
static int sfd = 0;

void handle_events(void) {
    bool signal_found = false;
    while(amxp_signal_read() == 0) {
        printf(".");
        fflush(stdout);
        signal_found = true;
    }
    if(signal_found) {
        printf("\n");
        fflush(stdout);
    }
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;
    amxd_dm_t* dm = mock_get_dm();

    assert_int_equal(amxd_dm_init(dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    test_register_dummy_be();
    assert_int_equal(amxb_connect(&bus_ctx, "dummy:/tmp/dummy.sock"), 0);
    amxo_connection_add(&parser, amxb_get_fd(bus_ctx), connection_read, "dummy:/tmp/dummy.sock", AMXO_BUS, bus_ctx);

    root_obj = amxd_dm_get_root(dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "check_reference_is_valid", AMXO_FUNC(_check_reference_is_valid));
    amxo_resolver_ftab_add(&parser, "check_is_none_or_in", AMXO_FUNC(_check_is_none_or_in));
    amxo_resolver_ftab_add(&parser, "bulkdata_enable_changed", AMXO_FUNC(_bulkdata_enable_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_enable_changed", AMXO_FUNC(_bulkdata_profile_enable_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_added", AMXO_FUNC(_bulkdata_profile_added));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_reporting_interval_changed", AMXO_FUNC(_bulkdata_profile_reporting_interval_changed));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_time_reference_changed", AMXO_FUNC(_bulkdata_profile_time_reference_changed));
    amxo_resolver_ftab_add(&parser, "ForceCollection", AMXO_FUNC(_ForceCollection));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_cleanup", AMXO_FUNC(_bulkdata_profile_cleanup));
    amxo_resolver_ftab_add(&parser, "bulkdata_profile_mqtt_cleanup", AMXO_FUNC(_bulkdata_profile_mqtt_cleanup));

    assert_int_equal(amxo_parser_parse_file(&parser, odl_defs, root_obj), 0);

    handle_events();

    assert_int_equal(amxb_register(bus_ctx, dm), 0);

    assert_int_equal(_bulkdata_main(0, dm, &parser), 0);

    return 0;
}

int test_setup_ts(UNUSED void** state) {
    test_setup(NULL);
    assert_int_equal(amxo_parser_parse_file(test_get_parser(), odl_default_w_profile, amxd_dm_get_root(mock_get_dm())), 0);
    assert_int_equal(amxo_parser_parse_file(test_get_parser(), odl_device, amxd_dm_get_root(mock_get_dm())), 0);
    go_to_future_ms(5000);
    return 0;
}

int test_teardown(UNUSED void** state) {
    amxd_dm_t* dm = mock_get_dm();

    assert_int_equal(_bulkdata_main(1, dm, &parser), 0);
    handle_events();
    amxb_free(&bus_ctx);

    amxo_parser_clean(&parser);
    amxd_dm_clean(dm);

    test_unregister_dummy_be();

    amxo_resolver_import_close_all();

    return 0;
}

amxb_bus_ctx_t* test_get_bus_ctx(void) {
    return bus_ctx;
}

amxo_parser_t* test_get_parser(void) {
    return &parser;
}

void set_bulkdata_enable(bool enable) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, ROOT_OBJECT_NAME);
    amxd_trans_set_value(bool, &transaction, "Enable", enable);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_wildcard(bool enable) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, ROOT_OBJECT_NAME);
    /* Ignore read-only attribute */
    amxd_trans_set_attr(&transaction, amxd_tattr_change_ro, true);
    amxd_trans_set_value(bool, &transaction, "ParameterWildCardSupported", enable);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_profile_enable(const cstring_t profile_path, bool enable) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%s", profile_path);
    amxd_trans_set_value(bool, &transaction, "Enable", enable);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_reporting_interval(const cstring_t profile_path, uint32_t interval) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%s", profile_path);
    amxd_trans_set_value(uint32_t, &transaction, "ReportingInterval", interval);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_time_reference(const cstring_t profile_path, const cstring_t time_reference) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%s", profile_path);
    amxd_trans_set_value(cstring_t, &transaction, "TimeReference", time_reference);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_report_timestamp(const cstring_t profile_path, const cstring_t format) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%sJSONEncoding.", profile_path);
    amxd_trans_set_value(cstring_t, &transaction, "ReportTimestamp", format);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_report_format(const cstring_t profile_path, const cstring_t format) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%sJSONEncoding.", profile_path);
    amxd_trans_set_value(cstring_t, &transaction, "ReportFormat", format);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_parameter_name(const cstring_t parameter_path, const cstring_t name) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%s", parameter_path);
    amxd_trans_set_value(cstring_t, &transaction, "Name", name);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void set_bulkdata_parameter_reference(const cstring_t parameter_path, const cstring_t reference) {
    amxd_trans_t transaction;
    amxd_trans_init(&transaction);
    amxd_trans_select_pathf(&transaction, "%s", parameter_path);
    amxd_trans_set_value(cstring_t, &transaction, "Reference", reference);
    assert_int_equal(amxd_trans_apply(&transaction, mock_get_dm()), 0);
    handle_events();
    amxd_trans_clean(&transaction);
}

void add_profile(bool enable, uint32_t interval) {
    amxc_var_t values;
    amxc_var_init(&values);
    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &values, "Enable", enable);
    amxc_var_add_key(uint32_t, &values, "ReportingInterval", interval);
    assert_int_equal(amxb_add(bus_ctx, ROOT_OBJECT_NAME "Profile.", 0, NULL, &values, NULL, 3), 0);
    amxc_var_clean(&values);
}

void delete_profile(const cstring_t profile_path) {
    assert_int_equal(amxb_del(bus_ctx, profile_path, 0, NULL, NULL, 3), 0);
}

void add_parameter(const cstring_t profile_path, const cstring_t reference, const cstring_t name) {
    char path[100];
    sprintf(path, "%sParameter.", profile_path);
    amxc_var_t values;
    amxc_var_t ret;

    amxc_var_init(&values);
    amxc_var_init(&ret);

    amxc_var_set_type(&values, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &values, "Reference", reference ? : "");
    amxc_var_add_key(cstring_t, &values, "Name", name ? : "");
    assert_int_equal(amxb_add(bus_ctx, path, 0, NULL, &values, &ret, 3), 0);
    amxc_var_dump(&ret, STDOUT_FILENO);

    amxc_var_clean(&values);
    amxc_var_clean(&ret);
}

void delete_parameter(const cstring_t parameter_path UNUSED) {
    assert_int_equal(amxb_del(bus_ctx, parameter_path, 0, NULL, NULL, 3), 0);
}

void capture_sigalrm(void) {
    sigset_t mask;

    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);

    sigprocmask(SIG_BLOCK, &mask, NULL);

    sfd = signalfd(-1, &mask, 0);
}

void go_to_future_ms(uint32_t timeoutMS) {
    amxut_timer_go_to_future_ms(timeoutMS);
    amxp_timers_calculate();
    amxp_timers_check();
    handle_events();
}

void push_event_handler(const char* const sig_name,
                        const amxc_var_t* const data,
                        void* const priv) {
    amxc_var_t* last_report = priv;
    amxc_var_t* json_data = NULL;
    printf("Event received = %s\n", sig_name);
    fflush(stdout);
    /* Convert JSON string back to htable */
    json_data = GETP_ARG(data, "data.Data");
    amxc_var_cast(json_data, AMXC_VAR_ID_HTABLE);
    amxc_var_dump(json_data, STDOUT_FILENO);
    /* Get the last report */
    amxc_var_copy(last_report, GETP_ARG(json_data, "Report.0"));
}

void debug_dump_bulkdata(void) {
    amxc_var_t ret;
    amxc_var_init(&ret);
    amxb_get(test_get_bus_ctx(), "BulkData.", INT32_MAX, &ret, 5);
    amxc_var_dump(&ret, STDOUT_FILENO);
    amxc_var_clean(&ret);
}

void get_bulkdata_profile(const char* const path, const char* const sub_object, amxc_var_t* ret) {
    assert_non_null(ret);
    assert_non_null(path);
    amxc_string_t full_obj_path;
    amxc_string_init(&full_obj_path, 0);
    amxc_string_setf(&full_obj_path, "%s.%s", path, sub_object == NULL ? "" : sub_object);

    assert_int_equal(amxb_get(test_get_bus_ctx(), amxc_string_get(&full_obj_path, 0), 0, ret, 5), 0);
    amxc_string_clean(&full_obj_path);
}
