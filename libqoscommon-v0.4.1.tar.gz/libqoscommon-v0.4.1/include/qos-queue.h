/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2021 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#if !defined(__QOS_QUEUE_H__)
#define __QOS_QUEUE_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup Queue 3. The queue type
 * @brief
 * This library provides for the QoS.Queue object a typed wrapper and functions to facilitate its use.
 * The type provided is qos_queue_t.
 *
 * The functions help for memory management during construction and destruction, as well as get and set data.
 *  - Actions of creation and destruction don't reflect on the data-model.
 *  - Actions of data manipulations are instantaneously repercuted on the data-model (no notifications triggered)
 */

#include <stdint.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>

#include <debug/sahtrace.h>

#include "qos-type.h"

#define QOS_TR181_DEVICE_QOS_QUEUE_PATH "QoS.Queue"
#define QOS_TR181_DEVICE_QOS_QUEUE_INSTANCE "QoS.Queue."
#define QOS_TR181_DEVICE_QOS_QUEUE_OBJECT_NAME "Queue"

#define QUEUE_ID "queue-id"

struct _qos_node;
struct _netmodel_query;

/**
 * @ingroup Queue
 * @brief
 * Definition of the qos_queue_t.
 */
typedef struct _qos_queue {
    amxd_object_t* dm_object;      /**< The data model object */
    struct _qos_node* node;        /**< A pointer to the node object */
    char* intf_name;               /**< The interface name given by libnetmodel */
    struct _netmodel_query* query; /**< The interface query for update */
} qos_queue_t;

/**
 * @ingroup Queue
 * @brief
 * Allocate and initiate a qos_queue_t object with an instance from the data-model.
 */
int qos_queue_new(qos_queue_t** queue, amxd_object_t* const queue_instance);

/**
 * @ingroup Queue
 * @brief
 * Destroy a qos_queue_t object previously allocated with qos_queue_new and set the pointer to NULL.
 *
 * /!\ This function doesn't destroy the data-model in itself nor the node, only the wrapper.
 */
int qos_queue_delete(qos_queue_t** queue);

/**
 * @ingroup Queue
 * @brief
 * Initiate a qos_queue_t object previously allocated.
 */
int qos_queue_init(qos_queue_t* const queue, amxd_object_t* const queue_instance);

/**
 * @ingroup Queue
 * @brief
 * Deinitiate a qos_queue_t object.
 */
int qos_queue_deinit(qos_queue_t* const queue);

/**
 * @ingroup Queue
 * @brief
 * Access data-model Enable parameter and change its value to the enable argument.
 */
int qos_queue_dm_set_enable(const qos_queue_t* const queue, const bool enable);

/**
 * @ingroup Queue
 * @brief
 * Access data-model DropAlgorithm parameter and change its value to the algorithm argument.
 */
int qos_queue_dm_set_drop_algorithm(const qos_queue_t* const queue,
                                    const qos_queue_drop_algorithm_t algorithm);

/**
 * @ingroup Queue
 * @brief
 * Access data-model Status parameter and change its value to the status argument.
 */
int qos_queue_dm_set_status(const qos_queue_t* const queue, qos_status_t status);

/**
 * @ingroup Queue
 * @brief
 * Return the data-model object.
 *
 * /!\ This function breaks the encapsulation and should be use cautiously.
 */
amxd_object_t* qos_queue_get_dm_object(const qos_queue_t* const queue);

/**
 * @ingroup Queue
 * @brief
 * Access data-model Status parameter value and return it.
 */
qos_status_t qos_queue_dm_get_status(const qos_queue_t* const queue);

/**
 * @ingroup Queue
 * @brief
 * Access data-model DropAlgorithm parameter value and return it.
 */
qos_queue_drop_algorithm_t qos_queue_dm_get_drop_algorithm(const qos_queue_t* const queue);

/**
 * @ingroup Queue
 * @brief
 * Access data-model SchedulerAlgorithm parameter value and return it.
 */
qos_scheduler_algorithm_t qos_queue_dm_get_scheduler_algorithm(const qos_queue_t* const queue);

/**
 * @ingroup Queue
 * @brief
 * Access data-model Enable parameter value and return it.
 */
static inline bool qos_queue_dm_get_enable(const qos_queue_t* const queue) {
    return queue == NULL ? false : amxd_object_get_value(bool, queue->dm_object, "Enable", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model Precedence parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_precedence(const qos_queue_t* const queue) {
    return queue == NULL ? 1 : amxd_object_get_value(uint32_t, queue->dm_object, "Precedence", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model Alias parameter value and return it.
 */
static inline const char* qos_queue_dm_get_alias(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(queue->dm_object, "Alias"));
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model TrafficClasses parameter value and return it.
 */
static inline const char* qos_queue_dm_get_traffic_classes(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(queue->dm_object, "TrafficClasses"));
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model Interface parameter value and return it.
 */
static inline const char* qos_queue_dm_get_interface(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(queue->dm_object, "Interface"));
}

/**
 * @ingroup Queue
 * @brief
 * Return the interface name referred in Interface parameter.
 */
static inline const char* qos_queue_get_interface_name(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : queue->intf_name;
}

/**
 * @ingroup Queue
 * @brief
 * Return the interface name referred in Interface parameter.
 */
static inline void qos_queue_set_interface_name(qos_queue_t* const queue, const char* const intf_name) {
    free(queue->intf_name);
    queue->intf_name = intf_name ? strdup(intf_name) : NULL;
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model AllInterfaces parameter value and return it.
 */
static inline bool qos_queue_dm_get_all_interfaces(const qos_queue_t* const queue) {
    return queue == NULL ? false : amxd_object_get_value(bool, queue->dm_object, "AllInterfaces", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model HardwareAssisted parameter value and return it.
 */
static inline bool qos_queue_dm_get_hardware_assisted(const qos_queue_t* const queue) {
    return queue == NULL ? false : amxd_object_get_value(bool, queue->dm_object, "HardwareAssisted", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model BufferLength parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_buffer_length(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "BufferLength", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model Weight parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_weight(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "Weight", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model REDThreshold parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_red_threshold(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "REDThreshold", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model REDPercentage parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_red_percentage(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "REDPercentage", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model ShapingRate parameter value and return it.
 */
static inline int32_t qos_queue_dm_get_shaping_rate(const qos_queue_t* const queue) {
    return queue == NULL ? -1 : amxd_object_get_value(int32_t, queue->dm_object, "ShapingRate", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model ShapingBurstSize parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_shaping_burst_size(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "ShapingBurstSize", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model AssuredRate parameter value and return it.
 */
static inline int32_t qos_queue_dm_get_assured_rate(const qos_queue_t* const queue) {
    return queue == NULL ? -1 : amxd_object_get_value(int32_t, queue->dm_object, "AssuredRate", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model QueueKey parameter value and return it.
 */
static inline uint32_t qos_queue_dm_get_queue_key(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_value(uint32_t, queue->dm_object, "QueueKey", NULL);
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model ClassKeyMinor parameter value and return it.
 */
static inline const char* qos_queue_dm_get_classkey_minor(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(queue->dm_object, "ClassKeyMinor"));
}

/**
 * @ingroup Queue
 * @brief
 * Access data-model QueueCtrl parameter value and return it.
 */
static inline const char* qos_queue_dm_get_queue_ctrl(const qos_queue_t* const queue) {
    return queue == NULL ? NULL : amxc_var_constcast(cstring_t, amxd_object_get_param_value(queue->dm_object, "Controller"));
}

/**
 * @ingroup Queue
 * @brief
 * Return the instance's index in the QoS.Queue list.
 */
static inline uint32_t qos_queue_dm_get_index(const qos_queue_t* const queue) {
    return queue == NULL ? 0 : amxd_object_get_index(queue->dm_object);
}

#ifdef __cplusplus
}
#endif

#endif // __QOS_QUEUE_H__
