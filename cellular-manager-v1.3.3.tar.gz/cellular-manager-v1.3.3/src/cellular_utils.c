/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2024 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>

#include <sys/ioctl.h>
#include <errno.h>
#include <net/if.h>
#include <linux/sockios.h>

#include <debug/sahtrace.h>
#include <debug/sahtrace_macros.h>

#include "cellular_priv.h"
#include "cellular_utils.h"
#include "cellular_soc_utils.h"

#define ME "utils"

/**
 * @brief callback function for when the NetDev status changes
 */
static void _netdev_link_state_cb(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    cell_iface_t* cell_iface = NULL;
    const char* new_state = NULL;
    const char* old_state = NULL;

    when_null_trace(priv, exit, ERROR, "private data should contain data");
    cell_iface = (cell_iface_t*) priv;

    old_state = GETP_CHAR(data, "parameters.State.from");
    new_state = GETP_CHAR(data, "parameters.State.to");

    SAH_TRACEZ_INFO(ME, "%s State changed from %s to %s", cell_iface->object->name, old_state, new_state);
    cell_iface_reset_update_timer(cell_iface);

exit:
    return;
}

/**
 * @brief callback function for when a new Link is added to NetDev or
 * the name of an existing link changes
 */
static void _netdev_new_link_added_cb(UNUSED const char* const sig_name,
                                      UNUSED const amxc_var_t* const data,
                                      void* const priv) {
    cell_iface_t* cell_iface = NULL;

    when_null_trace(priv, exit, ERROR, "private data should data");
    cell_iface = (cell_iface_t*) priv;

    SAH_TRACEZ_INFO(ME, "%s interface was added to NetDev", cell_iface->netdev_intf);
    cell_iface_reset_update_timer(cell_iface);

exit:
    return;
}

static int set_netdev_if_enabled(const char* name, bool enable) {
    int rv = -1;
    int fd = -1;
    struct ifreq ifreq;

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd < 0) {
        SAH_TRACEZ_ERROR(ME, "creation of socket failed with error: %s", strerror(errno));
        rv = 2;
        goto exit;
    }

    strncpy(ifreq.ifr_name, name, IF_NAMESIZE);
    ifreq.ifr_name[IF_NAMESIZE - 1] = '\0';
    SAH_TRACEZ_INFO(ME, "Set netdev_if \"%s\" %s", name, enable ? "up" : "down");
    if(ioctl(fd, SIOCGIFFLAGS, &ifreq) == -1) {
        SAH_TRACEZ_ERROR(ME, "Get flags of netdev if \"%s\" failed: %d (%s)", name, errno, strerror(errno));
        rv = 2;
        goto exit;
    }

    if(enable) {
        ifreq.ifr_flags |= IFF_UP;
    } else {
        ifreq.ifr_flags &= ~IFF_UP;
    }

    if(ioctl(fd, SIOCSIFFLAGS, &ifreq) == -1) {
        SAH_TRACEZ_ERROR(ME, "Get flags of netdev if \"%s\" failed: %d (%s)", name, errno, strerror(errno));
        rv = 3;
        goto exit;
    }
    rv = 0;

exit:
    close(fd);
    return rv;
}

/**
 * @brief Update the object status in the datamodel
 * @param cellular the pointer to cellular info structure
 * @return amxd_status_ok when the all actions are applied, otherwise an other error code and no changes in the data model are done.
 */
amxd_status_t cell_iface_update_dm(cell_iface_t* cell_iface) {
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxd_dm_t* dm = cellular_get_dm();
    const amxc_var_t* status_param;
    amxc_var_t prev_status;
    const char* status_value;
    amxd_trans_t trans;
    bool netdev_operational, status_changed;

    amxc_var_init(&prev_status);
    amxd_trans_init(&trans);

    when_null_trace(cell_iface, exit, ERROR, "cell_iface is NULL");
    when_null_trace(cell_iface->object, exit, ERROR, "object is NULL");

    status_param = amxd_object_get_param_value(cell_iface->object, "Status");
    when_null_trace(status_param, exit, ERROR, "object doesn't have parameter Status");
    amxc_var_copy(&prev_status, status_param);

    SAH_TRACEZ_INFO(ME, "Updating status of %s", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED));

    amxp_timer_stop(cell_iface->update_timer);

    amxd_trans_set_attr(&trans, amxd_tattr_change_ro, true);
    amxd_trans_set_attr(&trans, amxd_tattr_change_prot, true);
    cell_iface_fill_trans(cell_iface, &trans);
    rv = amxd_trans_apply(&trans, dm);
    when_failed_trace(rv, exit, ERROR, "Status update of %s failed with error %d", amxd_object_get_path(cell_iface->object, AMXD_OBJECT_INDEXED), rv);

    status_value = GET_CHAR(status_param, NULL);
    when_null_trace(status_value, exit, ERROR, "Status value is NULL");
    status_changed = (strcmp(status_value, GET_CHAR(&prev_status, NULL)) != 0);
    netdev_operational = (strcmp(status_value, "Up") == 0);

    if(status_changed) {
        /* Line up network device administrative state with interface status */
        set_netdev_if_enabled(cell_iface->netdev_intf, netdev_operational);

        /* Reset LastChange when Status has been updated */
        cell_iface->last_change = get_system_uptime();
    }

exit:
    amxc_var_clean(&prev_status);
    amxd_trans_clean(&trans);
    return rv;
}

/**
 * @brief Update timer callback
 * @param timer the pointer to cellular interface update_timer
 * @param priv  the pointer to cellular interface
 */
static void cell_iface_update_dm_timer_cb(amxp_timer_t* timer, void* priv) {
    cell_iface_t* cell_iface = priv;

    when_null_trace(cell_iface, exit, ERROR, "Timer private data is NULL");
    when_false_trace(cell_iface->update_timer == timer, exit, ERROR, "Unexpected timer private data value");
    cell_iface_update_dm(cell_iface);

exit:
    return;
}

/**
 * @brief Reset the update timer to 1 second
 * @param timer the pointer to cellular interface update_timer
 * @param priv  the pointer to cellular interface
 */
void cell_iface_reset_update_timer(cell_iface_t* cell_iface) {
    when_null_trace(cell_iface, exit, ERROR, "cell_iface is NULL");
    when_null_trace(cell_iface->update_timer, exit, ERROR, "update_timer is NULL");

    amxp_timer_start(cell_iface->update_timer, 1000);

exit:
    return;
}

/**
 * @brief Initialize a new cell_iface structure
 * @param cell_iface pointer to cell_iface structure
 * @param cellularif_obj pointer to cellular interface object
 * @param netdev_intf corresponding NetDev interface name
 */
amxd_status_t cell_iface_new(cell_iface_t** cell_iface, amxd_object_t* cellif_obj, const char* netdev_intf) {
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxc_var_t data;
    amxc_var_t ret;
    char* obj_path;

    when_null_trace(cell_iface, exit, ERROR, "cell_iface can not be null, invalid argument");
    when_null_trace(cellif_obj, exit, ERROR, "cellif_obj cannot be null, invalid argument");
    when_str_empty_trace(netdev_intf, exit, ERROR, "netdev_intf cannot be empty, invalid argument");

    obj_path = amxd_object_get_path(cellif_obj, AMXD_OBJECT_INDEXED);
    SAH_TRACEZ_INFO(ME, "allocating new cell_iface for object %s interface name %s", obj_path, netdev_intf);

    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");
    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");

    *cell_iface = (cell_iface_t*) calloc(1, sizeof(cell_iface_t));
    when_null_status(*cell_iface, exit, rv = amxd_status_out_of_mem);

    (*cell_iface)->last_change = get_system_uptime();
    (*cell_iface)->object = cellif_obj;
    strncpy((*cell_iface)->netdev_intf, netdev_intf, sizeof((*cell_iface)->netdev_intf) - 1);

    when_failed_trace(amxp_timer_new(&(*cell_iface)->update_timer, cell_iface_update_dm_timer_cb, *cell_iface),
                      clean, ERROR, "amxp_timer_new failed");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", obj_path);
    amxc_var_add_key(cstring_t, &data, "Name", netdev_intf);

    when_failed_trace(mod_cellular_execute_function((*cell_iface)->object, "create-cell-iface", &data, &ret),
                      clean, ERROR, "create-cell-iface failed");

    rv = amxd_status_ok;

clean:
    if(rv != amxd_status_ok) {
        if((*cell_iface)->update_timer) {
            amxp_timer_delete(&(*cell_iface)->update_timer);
            (*cell_iface)->update_timer = NULL;
        }
        free(*cell_iface);
        *cell_iface = NULL;
    }

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Cleanup a cell_iface structure
 * @param cell_iface pointer to the cell_iface structure
 */
amxd_status_t cell_iface_clean(cell_iface_t** cell_iface) {
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxc_var_t data;
    amxc_var_t ret;
    char* obj_path;

    when_null_trace(cell_iface, exit, ERROR, "Passed argument is NULL");
    when_null_trace(*cell_iface, exit, ERROR, "cell_iface can not be null, invalid argument");

    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");
    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");

    obj_path = amxd_object_get_path((*cell_iface)->object, AMXD_OBJECT_INDEXED);
    SAH_TRACEZ_INFO(ME, "freeing cell_iface info for %s", obj_path ? obj_path : "");

    amxc_var_set_type(&data, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &data, "ObjectPath", obj_path);

    when_failed_trace(mod_cellular_execute_function((*cell_iface)->object, "destroy-cell-iface", &data, &ret),
                      exit, ERROR, "destroy-cell-iface failed");

    amxb_subscription_delete(&(*cell_iface)->netdev_status_subscription);
    amxb_subscription_delete(&(*cell_iface)->netdev_new_link_subscription);
    if((*cell_iface)->update_timer) {
        amxp_timer_delete(&(*cell_iface)->update_timer);
        (*cell_iface)->update_timer = NULL;
    }
    free(*cell_iface);
    *cell_iface = NULL;

    rv = amxd_status_ok;

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Cleanup all cellular interfaces from controller module
 * @param cell_obj pointer to the cellular object
 */
amxd_status_t cell_iface_clean_all(amxd_object_t* cell_obj) {
    amxd_status_t rv = amxd_status_invalid_function_argument;
    amxc_var_t data;
    amxc_var_t ret;

    when_null_trace(cell_obj, exit, ERROR, "Passed argument is NULL");

    when_failed_trace(amxc_var_init(&data), exit, ERROR, "Failed to init data");
    when_failed_trace(amxc_var_init(&ret), exit, ERROR, "Failed to init ret");

    SAH_TRACEZ_INFO(ME, "freeing all cell_ifaces info");

    when_failed_trace(mod_cellular_execute_function(cell_obj, "destroy-all-cell-ifaces", &data, &ret),
                      exit, ERROR, "destroy-all-cell-ifaces failed");

    rv = amxd_status_ok;

exit:
    amxc_var_clean(&data);
    amxc_var_clean(&ret);
    return rv;
}

/**
 * @brief Enable or disable a cellular interface
 * @param cell_iface pointer to the cell_iface structure
 * @param enable Boolean to indicate whether the interface should be
 *               enabled or disabled
 * @return 0 in case of success, non 0 otherwise
 */
int cell_iface_set_enabled(cell_iface_t* cell_iface, bool enable) {
    int ret = -1;
    when_null_trace(cell_iface, exit, ERROR, "interface can not be null, invalid argument");

    ret = set_cell_iface_enabled(cell_iface, enable);

exit:
    return ret;
}

/**
 * @brief Create a new subscription on NetDev to listen to add events for this cell_iface instance
 * @param cell_iface pointer to the cell_iface_t structure where to store the subscription
 */
void netdev_link_added_subscription_new(cell_iface_t* cell_iface) {
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t expr;

    amxc_string_init(&expr, 0);

    when_null(cell_iface, exit);

    amxb_subscription_delete(&(cell_iface->netdev_new_link_subscription));
    when_str_empty(cell_iface->netdev_intf, exit);

    ctx = cellular_get_netdev_ctx();
    when_null_trace(ctx, exit, WARNING, "ctx not known, no subscription created");

    amxc_string_setf(&expr, "notification == 'dm:instance-added' && path == 'NetDev.Link.' " \
                     "&& parameters.Alias == '%s'", cell_iface->netdev_intf);
    amxb_subscription_new(&(cell_iface->netdev_new_link_subscription), ctx, "NetDev.Link.",
                          amxc_string_get(&expr, 0), _netdev_new_link_added_cb, cell_iface);
    when_null_trace(cell_iface->netdev_new_link_subscription, exit, WARNING, "failed to create subscription");

exit:
    amxc_string_clean(&expr);
    return;
}

/**
 * @brief Create a new subscription on NetDev that listens for changes to State
 * @param cell_iface pointer to the cell_iface info structure where to store the subscription
 */
void netdev_link_state_subscription_new(cell_iface_t* cell_iface) {
    amxb_bus_ctx_t* ctx = NULL;
    amxc_string_t expr;

    amxc_string_init(&expr, 0);

    when_null(cell_iface, exit);
    amxb_subscription_delete(&(cell_iface->netdev_status_subscription));
    when_str_empty(cell_iface->netdev_intf, exit);

    ctx = cellular_get_netdev_ctx();
    when_null_trace(ctx, exit, WARNING, "ctx not known, no subscription created");

    amxc_string_setf(&expr, "eobject == 'NetDev.Link.[%s].' && "
                     "contains('parameters.State')", cell_iface->netdev_intf);
    amxb_subscription_new(&(cell_iface->netdev_status_subscription), ctx, "NetDev.Link.",
                          amxc_string_get(&expr, 0), _netdev_link_state_cb, cell_iface);
    when_null_trace(cell_iface->netdev_status_subscription, exit, WARNING, "failed to create subscription");
    cell_iface_reset_update_timer(cell_iface);

exit:
    amxc_string_clean(&expr);
    return;
}

uint32_t get_system_uptime(void) {
    uint32_t uptime = 0;
    struct sysinfo info;
    when_failed_trace(sysinfo(&info), exit, ERROR, "Could not read total uptime of the system");
    uptime = info.uptime;
exit:
    return uptime;
}
