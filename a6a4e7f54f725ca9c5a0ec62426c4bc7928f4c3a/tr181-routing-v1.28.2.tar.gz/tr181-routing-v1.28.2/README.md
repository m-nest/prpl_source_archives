# TR181 compatible Routing manager

## Introduction

This is an Ambiorix plug-in for a TR-181 compatible Routing manager.

## Architecture

The global architecture consists of the `tr181-routing` plugin, which exposes `Device.Router.` functionality as defined by TR181 https://usp-data-models.broadband-forum.org/tr-181-2-12-0-usp.html#D.Device:2.Device.Routing.

The plugin implements the `mod-routing-lin` module to update the routing table and ip rule via netlink messages.

### Features

 1. **Multiple route tables**
    - Dynamic adding/deletion of the route tables by creating/deleting instances of Device.Routing.Router.
    - Dynamic detection and static configuration of routes by creating/deleting instances of Device.Routing.Router.{i}.IPv4|6Forwarding.
    - Route tables mapping for ID and Name lookup (defined in the `/etc/iproute2/rt_tables` file)

 2. **Policy Based Routing**
    - Add/delete/reconfigure policy based routing rule via Routing.Policy.
    - Add/delete/reconfigure policy based routing rules to direct packets to a specific routing table based on ingress/egress interface, source/destination port, source/destination IP, protocol or fwmark.

## Use cases

 1. **Ability to add/modify/delete route table rules**
    - Route added via the datamodel populates OS entries
    - Route added via the datamodel are reboot and upgrade persistent
    - Route added at the OS level or already present are automatically added to the datamodel

 2. **Ability for the host system to create a dedicated table for the application**
    - Main route table instance is already present in the datamodel
    - Custom routing table added via the datamodel are defined in `/etc/iproute2/rt_tables`
    - Route added in a custom routing table populates the correct OS table entries

## Building

### Prerequisites

- [libamxc](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxc)
- [libamxp](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxp)
- [libamxj](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxj)
- [libamxd](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxd)
- [libamxb](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxb)
- [libamxo](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxo)
- [libamxm](https://gitlab.com/prpl-foundation/components/ambiorix/libraries/libamxm)
- [libsahtrace](https://gitlab.com/soft.at.home/network/libsahtrace)
- [libnetmodel](https://gitlab.com/prpl-foundation/components/core/libraries/libnetmodel)
- [libdhcpoptions](https://gitlab.com/prpl-foundation/components/core/libraries/libdhcpoptions)
- [libipat](https://gitlab.com/prpl-foundation/components/core/libraries/libipat)
- libnl
- libnl-route

You can install these libraries from source or using their debian packages. To install them from source, refer to their corresponding repositories for more information.
To install them using debian packages, you can run

```bash
sudo apt update
sudo apt install sah-lib-sahtrace-dev libamxc libamxp libamxj libamxd libamxb libamxo libamxm libnetmodel libdhcpoptions libipat libnl libnl-route
```

### Build and install tr181-routing

1. Clone the git repository

    To be able to build it, you need the source code. So open the desired target directory and clone this plug-in in it.

    ```bash
    mkdir ~/workspace/amx/plugins
    cd ~/workspace/amx/plugins
    git clone git@gitlab.com:prpl-foundation/components/core/plugins/tr181-routing.git
    ```

1. Build it

    When using the internal gitlab, you must define an environment variable `VERSION_PREFIX` before building.

    ```bash
    export VERSION_PREFIX="master_"
    ```

    After the variable is set, you can build the plug-in.

    ```bash
    cd ~/workspace/amx/plugins/tr181-routing
    make
    ```

1. Install it

    You can use the install target in the makefile to install the plug-in

    ```bash
    cd ~/workspace/amx/plugins/tr181-routing
    sudo -E make install
    ```

### Running the plug-in

During installation a symbolic link is created to amxrt:

```text
/usr/bin/tr181-routing -> /usr/bin/amxrt
```

This allows you to run the Routing manager using the `tr181-routing` command. `amxrt` will find the relevant odl files in `/etc/amx/tr181-routing`. In the current configuration (see `odl/routing-manager.odl`) the file `/etc/amx/routing-manager/routing-manager-defaults.odl` is loaded on startup of the routing manager plug-in.
