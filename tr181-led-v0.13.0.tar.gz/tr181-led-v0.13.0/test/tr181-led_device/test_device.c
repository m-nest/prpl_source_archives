/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include <amxc/amxc.h>
#include <amxp/amxp.h>

#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_transaction.h>

#include <amxo/amxo.h>

#include "test_device.h"
#include "dm_led.h"
#include "led.h"
#include "mock.h"


static amxd_dm_t dm;
static amxo_parser_t parser;


static void handle_events(void) {
    printf("Handling events ");
    while(amxp_signal_read() == 0) {
        printf(".");
    }
    printf("\n");
}

static void handle_alarm(int sig) {
    printf("sig %d\n", sig);
}

int test_setup(UNUSED void** state) {
    amxd_object_t* root_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), amxd_status_ok);
    assert_int_equal(amxo_parser_init(&parser), 0);

    root_obj = amxd_dm_get_root(&dm);
    assert_non_null(root_obj);

    amxo_resolver_ftab_add(&parser, "cycle_element_changed", AMXO_FUNC(_cycle_element_changed));
    amxo_resolver_ftab_add(&parser, "cycle_element_added", AMXO_FUNC(_cycle_element_added));
    amxo_resolver_ftab_add(&parser, "cycle_element_removed", AMXO_FUNC(_cycle_element_removed));
    amxo_resolver_ftab_add(&parser, "led_start_cycle", AMXO_FUNC(_led_start_cycle));
    amxo_resolver_ftab_add(&parser, "led_stop_cycle", AMXO_FUNC(_led_stop_cycle));
    amxo_resolver_ftab_add(&parser, "led_app_start", AMXO_FUNC(_led_app_start));



    assert_int_equal(amxo_parser_parse_file(&parser, LED_TEST_ODL, root_obj), 0);
    assert_int_equal(amxo_parser_parse_file(&parser, LED_TEST_DEFAULTS, root_obj), 0);
    assert_int_equal(_led_main(0, &dm, &parser), 0);

    signal(SIGALRM, handle_alarm);
    _led_app_start(NULL, NULL, NULL);
    wait_for_sigalarm(1);
    init_led_files();
    handle_events();

    return 0;
}

int test_teardown(UNUSED void** state) {
    assert_int_equal(_led_main(AMXO_STOP, &dm, &parser), 0);
    amxm_close_all();
    amxo_parser_clean(&parser);
    amxd_dm_clean(&dm);

    return 0;
}

void test_led_device_exists(UNUSED void** state) {
    assert_int_equal(led_device_exists("led_orange"), 1);
    assert_int_equal(led_device_exists("led_white"), 1);
    assert_int_equal(led_device_exists("led_red"), 1);
    assert_int_equal(led_device_exists("led_green"), 1);
    assert_int_equal(led_device_exists("led_blue"), 1);
    assert_int_equal(led_device_exists("led_purple"), 0);
}
void test_set_brightness(UNUSED void** state) {
    amxd_object_t* led_instance = amxd_dm_findf(&dm, "LEDs.LED.led_front.");
    led_instance_t* led_info = led_instance->priv;
    led_set_brightness(led_info, 100, true);
    assert_true(file_content_equals(led_param(orange, brightness), "255"));
    assert_true(file_content_equals(led_param(white, brightness), "255"));
    led_set_brightness(led_info, 50, false);
    assert_true(file_content_equals(led_param(orange, brightness), "127"));
    assert_true(file_content_equals(led_param(white, brightness), "127"));
}
void test_set_fade(UNUSED void** state) {
    amxd_object_t* led_instance = amxd_dm_findf(&dm, "LEDs.LED.led_front.");
    led_instance_t* led_info = led_instance->priv;
    led_set_fade(led_info, 1000);
    assert_true(file_content_equals(led_param(orange, trigger), "timer"));
    assert_true(file_content_equals(led_param(orange, mode), "fade"));
    assert_true(file_content_equals(led_param(white, trigger), "timer"));
    assert_true(file_content_equals(led_param(white, mode), "fade"));
    assert_true(file_content_equals(led_param(orange, delay_on), "500"));
    assert_true(file_content_equals(led_param(orange, delay_off), "500"));
    assert_true(file_content_equals(led_param(white, delay_on), "500"));
    assert_true(file_content_equals(led_param(white, delay_off), "500"));

}
void test_set_color(UNUSED void** state) {
    amxd_object_t* led_instance = amxd_dm_findf(&dm, "LEDs.LED.led_front.");
    led_instance_t* led_info = led_instance->priv;
    rgb_t orange_rgb = {255, 166, 0};
    rgb_t white_rgb = {255, 255, 255};
    rgb_t off_rgb = {0, 0, 0};
    rgb_t wrong_rgb = {125, 125, 125};
    led_set_color(led_info, orange_rgb);
    assert_false(file_content_equals(led_param(orange, brightness), "0"));
    assert_true(file_content_equals(led_param(orange, brightness), "255"));
    led_set_color(led_info, white_rgb);
    assert_true(file_content_equals(led_param(white, brightness), "255"));
    // turn leds off
    led_set_color(led_info, off_rgb);
    assert_true(file_content_equals(led_param(white, brightness), "0"));
    assert_true(file_content_equals(led_param(orange, brightness), "0"));
    // unsupported color
    led_set_color(led_info, wrong_rgb);
    assert_false(file_content_equals(led_param(white, brightness), "125"));
    assert_false(file_content_equals(led_param(orange, brightness), "125"));

    amxd_object_t* led_instance_rgb = amxd_dm_findf(&dm, "LEDs.LED.led_back.");
    led_instance_t* led_info_rgb = led_instance_rgb->priv;
    rgb_t red_rgb = {255, 0, 0};
    rgb_t green_rgb = {0, 255, 0};
    rgb_t blue_rgb = {0, 0, 255};
    led_set_color(led_info_rgb, red_rgb);
    assert_true(file_content_equals(led_param(red, brightness), "255"));
    led_set_color(led_info_rgb, green_rgb);
    assert_true(file_content_equals(led_param(green, brightness), "255"));
    led_set_color(led_info_rgb, blue_rgb);
    assert_true(file_content_equals(led_param(blue, brightness), "255"));
}

