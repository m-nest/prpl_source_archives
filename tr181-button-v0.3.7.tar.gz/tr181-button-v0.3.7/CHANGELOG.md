# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v0.1.2 - 2024-08-02(20:20:50 +0000)

### Other

- - [amx] Failing to restart processes with init scripts

## Release v0.1.1 - 2024-04-10(10:04:16 +0000)

### Changes

- Make amxb timeouts configurable

## Release v0.1.0 - 2024-03-25(08:31:47 +0000)

### New

- Add tr181-device proxy odl files to components

## Release v0.0.3 - 2023-10-05(08:41:27 +0000)

### Other

- Opensource component

## Release v0.0.2 - 2023-09-07(12:44:27 +0000)

### Other

- Make component available on gitlab.softathome.com

## Release v0.0.1 - 2023-06-05(11:34:03 +0000)

### Other

- [Button Manager][prpl][amx] The different buttons and the button State should be exposed in the DM (HL API)

