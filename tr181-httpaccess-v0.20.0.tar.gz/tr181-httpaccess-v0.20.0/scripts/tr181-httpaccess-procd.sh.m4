#!/bin/sh /etc/rc.common

. /usr/lib/amx/scripts/amx_procd_init_functions.sh
[ -f /etc/environment ] && source /etc/environment
ulimit -c ${ULIMIT_CONFIGURATION:-0}

START=START_ORDER
STOP=STOP_ORDER
USE_PROCD=1

name="tr181-httpaccess"
PROG="/usr/bin/tr181-httpaccess"
datamodel_root="UserInterface"
PROG_OPTIONS=""

#Guideline- uncomment this function and place the instructions
#for functionality to execute before starting this service
#End

#preservice_hook() {
#    logger -s "pre-service hook ${name}"
#}

#Guideline- uncomment this function and place the instructions
#for functionality to execute after stopping this service
#End

#postservice_hook() {
#    logger -s "post-service hook ${name}"
#}

start_service() {
    #preservice_hook
    register_service ${name} ${PROG} ${PROG_OPTIONS}
}

stop_service() {
    deregister_service ${name}
    #postservice_hook
}

debuginfo() {
    process_debug_info ${datamodel_root}
    controller="$(ba-cli -al "protected;${datamodel_root}.Controller?" | grep 'mod-')"
    case "$controller" in
        mod-httpaccess-lighttpd)
            lighttpd_config_file="$(grep 'conf-file = ' /etc/amx/${name}/${name}_target.odl | cut -d \" -f 2)"
            lighttpd -p -f "$lighttpd_config_file"
            ;;
        *)
            ;;
    esac
}
