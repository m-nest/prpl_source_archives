# tr181-ipdiagnostics

The tr181-ipdiagnostics works based on the separation of concerns, providing diagnostics tests using the
following tools:
- Iperf
- OBUDPST (TR-471 IPLayerCapacity)

Those are the tests and the modules that implement them:
- Download speedtest (iperf)
- Upload speedtest (iperf)
- IPLayerCapacity diagnostics (UDPST)

## compile and install
```
make
sudo make install
```

## run unit tests
```
make test
```

The test uses test data from the process(iperf) output and tests the parsing, and not the module actually
running on background. If tests start to fail because of a change, then `gdb` is a good tool. The tests are
organized per topic (DownloadDiagnostics, UploadDiagnostics, common functions...) and a breakpoint can
be added at the topic's event handler to start debugging.
```
cd test/path/to/test
gdb ./run_test
```

## run integration tests

To test using a modules' process in background and test the real behavior of the program, do the following:
```
cd test
make int
```

In order to run the integration tests, the container must have Iperf3 (version 3.7) installed.

## run plugin inside a Ambiorix Docker container

Refer to the Ambiorix tutorials for the steps to launch the Ambiorix Docker container.

### compile/install dependencies: (make + sudo make install)

tr181-ipdiagnostics:
  libnetmodel
  libsahtrace

netmodel:
  mod_dmext

iperf3:
  libiperf0
  libsctp1

### run dependencies
```
# start bus
sudo ubusd&

# start dependencies
sudo ip-manager -D
sudo netmodel -D
```

### run tr181-ipdiagnostics
```
sudo tr181-ipdiagnostics -D
```

## TR-471 IPLayerCapacity

The TR-471 IPLayerCapacity test is supported in the TR-181 data model under `IPDiagnostics.IPLayerCapacityMetrics` and `IP.Diagnostics.IPLayerCapacity()`.  
Both **CWMP** and **USP** data models are supported.

To run a TR-471 test, a UDPST server must first be configured and running on a server:

**On Server:**
```bash
$ udpst -j -T
```

### Example: Run TR-471 Upload Test using CWMP Data Model

**On DUT (client setup):**
```text
$ ubus-cli
> IPDiagnostics.IPLayerCapacityMetrics.Role="Sender"
> IPDiagnostics.IPLayerCapacityMetrics.ServerList="192.168.99.100:25000"
> IPDiagnostics.IPLayerCapacityMetrics.JumboFramesPermitted=0
> IPDiagnostics.IPLayerCapacityMetrics.DiagnosticsState="Requested"
```

**Note:** `Sender` = Upload test.

### Example: Run TR-471 Download Test using USP Data Model

**On DUT (client setup):**
```text
$ ubus-cli
> IPDiagnostics.IPLayerCapacity(Role = Receiver, ServerList = 192.168.99.100:25000, JumboFramesPermitted=0)
```

**Note:** `Receiver` = Download test.

---

### tips & tricks

You can run a local iperf server in order to perform the Upload and Download tests.
```
iperf3 -s -D
```
